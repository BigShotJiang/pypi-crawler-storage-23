############################  LICENSE  #########################

# <This file is part of the CRESS (Compure REsource Sharing System).>

# Copyright (C) <2013-2021> Crowd Render Pty Limited, Sydney Australia


# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

# You can contact the creator of Crowdrender at info at
# crowdrender dot com dot au

################################################################

import asyncio
from cress.service import Service


class Logger(Service):
    """ """

    def __init__(self):

        super(Logger, self).__init__(service_name="LOGGING")
        # subscribe to all events from any client or service

        subs = [(b"", self.log_event)]
        self.set_subscriptions(subs)

    async def log_event(self, event):

        print(f"DEBUG: {self.name} recevied an event {event}")
        await asyncio.sleep(0)
