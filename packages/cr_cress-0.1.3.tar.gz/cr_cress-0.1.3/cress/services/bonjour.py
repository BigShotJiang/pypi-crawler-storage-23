############################  LICENSE  #########################

# <This file is part of the CRESS (Compure REsource Sharing System).>

# Copyright (C) <2013-2021> Crowd Render Pty Limited, Sydney Australia


# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

# You can contact the creator of Crowdrender at info at
# crowdrender dot com dot au

################################################################


from cress.service import Service


class Bonjour(Service):
    """Responds to bonjour client or worker bonjour events

    The Bonjour serviec is responsible for;
        - replying to bonjour events


    We currently use pyzmq for creating the pub/sub architecture of the cress system.
    This introduces a quirk when it comes to a client connecting. The usual way of setting
    up a pub/sub socket pair is for the pub to bind, sub then connects. This matches the
    intention of multiple subscribers hooking up to a feed.

    However, we're creating an event bus where events flow in both directions. for this to
    happen with minimal config nightmares, the sub sock for the event bus process binds, and the
    client's pub socket connects.

    This actually works fine, however at least one messge must be sent to the sub socket before
    the sub socket can actually receive anything. So an inital message is needed and it will be
    lost by the sub socket. The bonjour service exists to recieve and return a message back to the
    connecting client to indicate that the connection succeeded, including the first throwaway msg.

    A connecting client will send bonjour events to the CRESS Client Event Bus until it gets a reply,
    or times out.

    The bonjour service is incredibly simple as all it does is re-publish the same event on the bus.

    The expected format for the event is:

        b'BONJOUR_CLIENT_ID', {}

    """

    def __init__(self):

        # initialise this service, which connects it to the event bus
        super(Bonjour, self).__init__(service_name="BONJOUR")

        # subscribe our handler to any bonjour events from all clients
        subs = [(b"BONJOUR", self.handle_bonjour)]
        self.set_subscriptions(subs)

    async def handle_bonjour(self, event):
        # simply re-publish the event, causes the new event to be sent back to the requesting client
        print(f"DEBUG: {self.name} recevied an event {event}")

        await self.respond_to_event(event, event.value)
