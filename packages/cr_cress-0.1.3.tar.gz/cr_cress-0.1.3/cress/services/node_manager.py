############################  LICENSE  #########################

# <This file is part of the CRESS (Compure REsource Sharing System).>

# Copyright (C) <2013-2021> Crowd Render Pty Limited, Sydney Australia


# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

# You can contact the creator of Crowdrender at info at
# crowdrender dot com dot au

################################################################

import asyncio, json

import zmq
import zmq.asyncio

from cress.service import Service
from cress.event import Event, ALL_STATIONS
from cress.context import NodeManagerContext, ConnectError, NodeManagerContext

""" 

EVENTS PUBLISHED

NODE_$STATE$ - State changes are published as events, including updates from a node that don't effectively change the state, but may contain information the client wants, like progress on a render, file up/download.

handle_node_msg(msg):

    call a method to handle the state in the msg
    publish an event based on the node's message
    
EVENTS CONSUMED

CLIENT_REQ_POOLUPDATE - Client wants an update on the status of all nodes in its session. 

CLIENT_REQ_RENDER - Client wants nodes to render, list of nodes will be in the event/request

CLIENT_REQ_SYNC - Client wants to synchronise with a set of nodes specified in the event

handle_client_req(req):

    check that this is a request we can actually do, otherwise return an error stating that the request is not supported. 
    call the handler that services this request, the handler is responsible for returning a result via publishing an event. 
    

The node manager makes sure its local representation of nodes don't make illegal state transitions.

STATES

OFFLINE - Not connected and updates to the node pool don't include this node as active
ONLINE  - Not connected, updates to the node pool show the node is active
CONNECTING - There is an active attempt to connect to the node
CONNECTED  - The node has been connected 
SYNCING - Data is being synchronised with the node
SYNCED  - The node has reported that its hash agrees with the client/master's
SYNC_FAILED - Opposite of SYNCED
RENDERING   - The node is rendering

LEGAL STATE TRANSITIONS
OFFLINE -> ONLINE, CONNECTING, OFFLINE
ONLINE -> CONNECTING, OFFLINE, ONLINE
CONNECTING -> ONLINE, CONNECTED, OFFLINE, CONNECTING
CONNECTED -> SYNCING, ONLINE, OFFLINE, CONNECTED
SYNCING -> SYNCED, SYNC_FAILED, OFFLINE, RENDERING, SYNCING
SYNCED -> SYNCING, RENDERING, OFFLINE
SYNC_FAILED -> SYNCING, RENDERING, OFFLINE
RENDERING -> SYNCED, SYNC_FAILED, RENDERING, OFFLINE

Its important that some states can transition to themselves, such as SYNCING, since a sync will generate many events to update the user and logs as to what is being synchronised, be it a file, a block of data in memory. Each event, sent as a msg to the node manager, will be act on the node's state changing it to SYNCING, but with a different set of meta data.

CONSEQUENCES OF ILLEGAL STATE TRANSITION
What does an illegal state transition imply? Usually it means that either the node
has encountered an internal error and manaaged a true illegal state change, or a message of a prior state change was missed/lost, meaning the node and node manager are not in sync. 

If the former is true, then the node manager should request the server terminate its process and create a new one. If the second is true then all is seemingly well with the node, just a missing msg is all that occurred. However we cannot know ahead of time which of these two states is true. Its a sort of Schrödingers state game, is the node alive or corrupt? The best remedy in either case seems to be to assume the node is screwy and ask the server to kill it and start another copy of the process. 


STATE IS KEPT?
If state is kept, then it must be kept in just one place. The best location to date would be the node manager since it deals directly with messages coming from the node and publishes those as events. 

Each node should therefore live in the node manager.

What does node state look like?

Without specifying further we need to keep track of the following

1. A connection to the node for send/recv data and commands
2. Which client session does it belong to? Used for routing events to the client.
3. What is its current named state in [OFFLINE, ONLINE, etc] and any associated meta data with that stage (e.g. RENDERING, % complete for either rendering or transferring data, or SYNCING, % uploaded of a file, or data being hashed and checked?)

Everthing else is not stored at all. Its merely passed through as events. 

STATE CHANGES

A change to state happens through a setter. The setter uses a lookup table which compares the requested change to allowable ones. Illegal changes cause the setter to invoke a recovery method and publish an event marking the node as unusable.

The state LUT is a data structure that is part of the node manager class. 

e.g. 

states = {
    b'OFFLINE'    :(b'ONLINE', b'OFFLINE', b'CONNECTING'),
    b'ONLINE'     :(b'CONNECTING', b'OFFLINE', b'ONLINE'),
    b'CONNECTING' :(b'CONNECTED', b'ONLINE', b'OFFLINE', b'CONNECTING'),
    b'CONNECTED'  :(b'SYNCING', b'ONLINE', b'OFFLINE', b'CONNECTED'),
    b'SYNCING'    :(b'SYNCED', b'SYNC_FAILED', b'OFFLINE', b'RENDERING', b'SYNCING'),
    b'SYNCED'     :(b'SYNCING', b'RENDERING', b'OFFLINE', b'SYNCED'),
    b'SYNC_FAILED':(b'SYNCING', b'RENDERING', b'OFFLINE', b'SYNC_FAILED')
    b'RENDERING'  :(b'SYNCED', b'SYNC_FAILED', b'RENDERING', b'OFFLINE')
}

set_state(self, new_state):PDL

    Take the current state, and then get the allowed states which the node can transition to.
    Compare the allowed states to the new_state, if the new state is allowed, then generate and event that the node has changed state, including the meta data from the original msg that sparked the change (note this should be in new_state).
    If the new_state is not allowed, then call the recovery method


"""


class NodeManager(Service):
    """Responsible for node connection and command/resp send/recv

    The NodeManger is responsible for;
        - establishing connections with nodes
        - sending commands and receiving responses

    The node manager subscribes to requests that are published on the main bus and routs them according
    to their session id. Responses from nodes generated by those requests are published to the msg bus.

    The node runs two asyncio tasks, one is from the inherited Service class, which

    """

    def __init__(self) -> None:

        #
        super(NodeManager, self).__init__(service_name="NODE MANAGER")

        # The NodeManager forwards every event on the bus so we subscribe to all events.
        # We also subscribe to pool update events so we can connect to remote resources.

        subs = [
            (b"NODE_POOL_UPDATE", self.handle_pool_update),
        ]

        self.set_subscriptions(subs)

        # create a network context for the node manager that will assist with connections
        self.node_manager_context = NodeManagerContext()

        # create a poller so we can await on events from sockets
        self.poller = zmq.asyncio.Poller()

        self.poller.register(self.node_manager_context.internal_sub_sock, zmq.POLLIN)
        self.poller.register(self.node_manager_context.ext_sub_sock, zmq.POLLIN)
        self.poller.register(self.node_manager_context.pub_sock_monitor, zmq.POLLIN)
        self.poller.register(self.node_manager_context.sub_sock_monitor, zmq.POLLIN)

    async def handle_pool_update(self, event: Event) -> None:
        """Handles an update to the node pool

        This method is responsible for reacting to changes in the node pool.

        1. New nodes that weren't already detected on the LAN - Nodes in the cloud or remote to the
            local network won't be detected locally, but will show up through an event from the discovery
            service. The correct action is to connect to the new nodes immediately to be ready for the
            client to request a sync to them (which will be the default).

        2. Nodes that are no longer in the list but are still connected - Apart from the likely scenario that
            the node has shutdown (for any reason, including a crash), there are also some reasons why the node
            may actually still be alive. If the server is incorrect, which could happen if the node's post request
            is broken somehow, would not automatically mean the node is no longer online.

            This case is handled by ignoring it if the node is still responding with heartbeats. If there is no
            connection anymore, then the node is marked as dead and an event OFFLINE is published. The meaning of
            OFFLINE is that the node stops responding rather than it is missing in a pool update.


        Arguments:
            event = Event(b'NODE_POOL_UPDATE', value)
            event.value pydict = {
                nodes:{
                    'node_id':{
                        'node_name':user recognizable string, defaults to the computer/host name,
                        'pub_endpoint': ip:port combination for the publish socket,
                        'sub_endpoint': ip:port combination for the subscribe socket,
                    }
                }
            }

        """

        # all the interesting stuff is in the event value, get it
        ev = event.value

        # figure out which nodes we're not connected to by calculating the difference between
        # the total node pool and which nodes we have current known good connections to.
        new_nodes = {
            node_id: node
            for node_id, node in ev.nodes.items()
            if node_id not in self.connections
        }

        # for each new node,
        # make a new connection to it.
        connect_tasks = [
            asyncio.create_task(
                self.node_manager_context.connect(
                    node_id,
                    node["pub_endpoint"],
                    node["sub_endpoint"],
                )
            )
            for node_id, node in new_nodes.items()
        ]

        # await the connections
        for conn_task in connect_tasks:
            try:
                await conn_task

                # add the connection to our list of successful ones
                self.connections[conn_task["node_id"]] = {"node_name": conn_task}

                # if successful we dispatch an all stations event to alert the event bus
                # to the newly connected node's presence.
                await self.dispatch_event(
                    Event(
                        b"".join([ALL_STATIONS, b".", b"NODE_CONNECTED"]),
                        bytes(
                            json.dumps(
                                {
                                    "node_id": conn_task["node_id"],
                                    "node_name": conn_task["node_name"],
                                }
                            ),
                            "utf-8",
                        ),
                    )
                )
            except ConnectError as e:
                # Alert the event bus to the failed connection
                await self.dispatch_event(
                    Event(
                        b"".join([ALL_STATIONS, b".", b"NODE_CONNECT_FAILED"]),
                        bytes(
                            json.dumps(
                                {
                                    "node_id": conn_task["node_id"],
                                    "node_name": conn_task["node_name"],
                                    "error": f"Connect failed, error was {e}",
                                }
                            ),
                            "utf-8",
                        ),
                    )
                )

    async def run(self):
        """Handle events by forwarding them back and forth between nodes and the client's event bus

        Description:

        This method overrides the underlying service method of the same name, it does so because we need to
        extend the handling of events to forward all but a few to the remote part of the event bus.

        When a node connects to the event system across the network, we need to generate an event for other
        systems to process. During connection attempts to remote nodes, we also want to forward events on
        the progress of those connections to the event bus.



        """

        while True:

            socks = dict(await self.poller.poll())

            # if there is a message from the internal event bus
            if self.node_manager_context.internal_sub_sock in socks:

                # get the event
                event = Event.deserialise(
                    await self.node_manager_context.internal_sub_sock.recv_multipart()
                )

                handler = self.get_handler(event)

                if handler is not None:
                    asyncio.create_task(handler(event))
                else:
                    # republish it immediately as is
                    await self.node_manager_context.ext_pub_sock.send_multipart(
                        event.serialise()
                    )

            # if there is a message from the external event bus:
            if self.node_manager_context.ext_sub_sock in socks:

                # forward it to the internal msg bus
                await self.node_manager_context.internal_pub_sock.send_multipart(
                    await self.node_manager_context.ext_sub_sock.recv_multipart()
                )
