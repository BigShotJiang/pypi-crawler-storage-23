############################  LICENSE  #########################

# <This file is part of the CRESS (Compure REsource Sharing System).>

# Copyright (C) <2013-2021> Crowd Render Pty Limited, Sydney Australia


# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

# You can contact the creator of Crowdrender at info at
# crowdrender dot com dot au

################################################################

"""Beacon Actor/Service Module

This module provides beaconing and listening classes to allow for
zero config setup of connections without requring the user to
manually elect for nodes to connect to each other.

The module uses multicast UDP messages as beacons to carry information
about a client that is ready to use render nodes. Workers listen for
these beacons from a client and attempt to connect to the end point
in the beacon's payload.

This makes for a potentially more efficient setup since only the client
is going to send beacons, allowing potentially thousands of workers to
connect back to the client. It avoids network congestion due to many
workers beaconing and the client trying to connect to them.
"""

# std lib imports
import socket, struct, asyncio, errno, ipaddress, json

# pypi imports

import psutil

# CRESS imports
from cress.service import Service
from cress.utils import get_machine_uuid
from cress.protocols import BeaconProtocol
from cress.event import Event

SEND_BEACON = b"SEND_BEACON"
CLIENT_BEACON_RCVD = b"CLIENT_BEACON_RCVD"
IP_ADDR = 0
IP_PORT = 1
LISTEN_SOCK_ERR = b"L_SOCK_ERR"
NET_DOWN_EVT = b"NET_DOWN"

MCAST_GRP = "224.1.2.69"
MCAST_PORT = 9696
# regarding socket.IP_MULTICAST_TTL
# ---------------------------------
# for all packets sent, after two hops on the network the packet will not
# be re-sent/broadcast (see https://www.tldp.org/HOWTO/Multicast-HOWTO-6.html)
MULTICAST_TTL = 2
BEACON_ERROR = b"BEACON_ERROR"


class BeaconListener(Service):
    """A listener for CRESS beacons

    The Beacon listener creates a listener for each Network Interface. It is
    intended to be used on a worker machine. This allows the worker to get
    beacons from client's on any of its network interfaces.

    Users might have multiple networks attached
    to any of their computers and as such we should support this.


    """

    def __init__(self) -> None:

        # initialise this service, which connects it to the event bus
        super(BeaconListener, self).__init__(service_name="BEACON_LISTENER")

        # create a socket for listening on.
        self.beacon_listening_sckt = self.create_beacon_listeners()

    async def _handle_beacon(self, r_msg: bytes) -> None:
        """Handles a beacon"""

        beacon = BeaconProtocol.unpack(r_msg)

        # on receiving a beacon, unpack it and create a CLIENT_BEACON event to notify
        # the complimentary component of the node_manager so it will attempt a connection

        services = {
            name: (ipaddress.IPv4Address(ep[IP_ADDR]), ep[IP_PORT])
            for name, ep in beacon.services.items()
        }

        # filter out services which have an ipaddress that is
        # either the loopback or mutlicast address as these
        # arent' valid.
        valid_client_services = {
            service: endpoint
            for service, endpoint in services.items()
            if all(
                [
                    endpoint[IP_ADDR].is_private,
                    not endpoint[IP_ADDR].is_loopback,
                    not endpoint[IP_ADDR].is_multicast,
                ]
            )
        }

        for service_name, endpoints in valid_client_services.items():
            # publish an event to notify the event bus of a new client
            client_beacon_rcvd_event = Event(
                CLIENT_BEACON_RCVD,
                bytes(
                    json.dumps(
                        {service_name: (f"{endpoints[IP_ADDR]}", endpoints[IP_PORT])}
                    ),
                    "utf-8",
                ),
            )

            await self.dispatch_event(client_beacon_rcvd_event)

    async def run(self):
        """listen for beacons, generate a CLIENT_BEACON events upon receiving one"""

        # Wait for a beacon to arrive from one of the multicast beacons
        while True:

            try:
                r_msg = self.beacon_listening_sckt.recv(4096)

                await self._handle_beacon(r_msg)

            except (socket.herror, socket.gaierror) as e:

                could_not_listen_err_event = Event(
                    LISTEN_SOCK_ERR, bytes(json.dumps(e), "utf-8")
                )

                await self.dispatch_event(could_not_listen_err_event)

            except (socket.error, socket.timeout):
                await asyncio.sleep(0)

        # clean up the socket by closing it
        self.beacon_listening_sckt.close()

    def create_beacon_listeners(self) -> socket.socket:
        """Create and return"""

        IS_ALL_GROUPS = False

        beacon_listening_sckt = socket.socket(
            socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP
        )
        # beacon_listening_sckt.setsockopt(
        #     socket.SOL_SOCKET,
        #     socket.SO_BROADCAST,
        #     1
        # )
        beacon_listening_sckt.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        beacon_listening_sckt.setblocking(False)
        beacon_listening_sckt.bind(("", MCAST_PORT))

        # TODO: we'll need to test that binding to all interfaces and
        # setting socket.INADDR_ANY actually works when we have a
        # machine attached to more than one physical network.
        # otherwise we may have to add multiple memberships
        mreq = struct.pack("4sl", socket.inet_aton(MCAST_GRP), socket.INADDR_ANY)

        beacon_listening_sckt.setsockopt(
            socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq
        )

        return beacon_listening_sckt


class Beacon(Service):
    """CRESS BEACONING SERVICE


    msg             = signature, machine_uuid, *service

    signature       = string; 'CRESS_BCNPROTO'

    machine_uuid    = string; unique id for this machine

    service         = service_name, *endpoint

    service_name    = string

    endpoint        = string; dotted quad ip address and port

    ON THE WIRE

    The current implementation uses json formatted strings.

    python representation
    ['CRESS_BCNPROTO', {'service name':[bound endpoints]}]


    """

    NETWORK_DOWN = 50
    NETWORK_UNREACHABLE = 51

    def __init__(self):
        """ """

        # initialise this service, which connects it to the event bus
        super(Beacon, self).__init__(service_name="BEACON")

        # subscribe our handler to any bonjour events from all clients
        subs = [(SEND_BEACON, self.handle_send_beacon)]
        self.set_subscriptions(subs)
        self.service_endpoints = {}

        # TODO: ensure we create a socket for each network inteface we
        # find that has an IPV4 connection to a physical network. Need
        # to support multiple NICs as the client machine might need to
        # connect to each.

        # get all network interfaces
        network_ifs = self.enumerate_netifaces()
        self.multicast_socks = {}
        for net_if_name, addr in network_ifs.items():

            multicast_beacon_sock = socket.socket(
                socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP
            )
            multicast_beacon_sock.setsockopt(
                socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, MULTICAST_TTL
            )
            self.multicast_socks[net_if_name] = multicast_beacon_sock

        self.machine_uuid = get_machine_uuid()

    def enumerate_netifaces(
        self, addr_family: int = socket.AF_INET, if_addr_type: str = "address"
    ) -> dict:
        """return a mapping of network interfaces and their endpoints"""

        # enumerate all network interfaces and filter out all but the one's asked for
        ifs = psutil.net_if_addrs()
        filtered_netifs = {
            name: [
                i
                for i in interface
                if i.family == addr_family
                and getattr(i, if_addr_type, None) is not None
            ]
            for name, interface in ifs.items()
        }

        return {
            name: interface for name, interface in filtered_netifs.items() if interface
        }

    async def handle_send_beacon(self, event: Event) -> None:
        """Handles a 'BEACON_THIS' event

        A 'BEACON_THIS' event is used to signal to nearby nodes on the
        local network/s that there is a client wanting to use them.

        There are two subsystems that use this event, one for coordinating
        commands and sending small amounts of data. The other for streaming
        large binary chunks of data, so think files, or contiguous chunks of
        memory that are too big to represent using json.

        Both of these sub systems require the nearby nodes to connect to them.

        The contents of the beacon will be the endpoint to connect to and the
        type of subsystem, one of;

        a. the event bus itself
        b. a file streaming service

        The expected format of the event value should be

        {"service name as str": (ipaddr, port)} where ipaddr is a str, port is an int.
        """
        # TODO: need to deseriliase the event.value, which is a bytes string. The
        # second argument to the BeaconProtocol requires a python dictionary type
        # not a bytes string.
        services = json.loads(event.value.decode("utf-8"))

        # prepare the body of the beacon
        self.beacon_body = BeaconProtocol.pack(f"{self.machine_uuid}", services)

        try:

            # send the beacon
            for sock in self.multicast_socks.values():
                sock.sendto(self.beacon_body, (MCAST_GRP, MCAST_PORT))

        # handle specific errors such as the network being down or
        # unreachable.
        except OSError as e:

            if e.errno in [errno.ENETDOWN, errno.ENETUNREACH]:
                # The net is down, so....
                # We betta call som bodi
                net_down_event = Event(NET_DOWN_EVT, bytes(json.dumps(e), "utf-8"))

                await self.dispatch_event(net_down_event)

        # handle any unexpected exceptions
        except Exception as e:

            unexpected_err_event = Event(BEACON_ERROR, bytes(json.dumps(e), "utf-8"))
            await self.dispatch_event(unexpected_err_event)

    def close(self):

        for sock in self.multicast_socks.values():
            sock.close()
