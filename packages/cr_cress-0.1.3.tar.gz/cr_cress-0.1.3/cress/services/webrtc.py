############################  LICENSE  #########################

# <This file is part of the CRESS (Compure REsource Sharing System).>

# Copyright (C) <2013-2022> Crowd Render Pty Limited, Sydney Australia


# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

# You can contact the creator of Crowdrender at info at
# crowdrender dot com dot au

################################################################

import asyncio
import json
from typing import Any, List, Dict, Optional
from uuid import UUID, uuid4
from aiortc import RTCPeerConnection, RTCDataChannel, RTCSessionDescription

from dependency_injector.wiring import Provide, inject

from cress.constants import EVENT_BUS_PUB_ADDR, EVENT_BUS_SUB_ADDR
from cress.containers import ClientContainer
from cress.discovery import DiscoveryAPI
from cress.event import unwrap_multipart, wrap_multipart, SOURCE
from cress.instance import CRESSInstance
from cress.service import Service
from cress.startup import CLIENT, REVERSE_PROXY

import zmq
import zmq.asyncio


WEBRTC_CHANNEL_LABEL = "cress"


class WebRTCConnection:
    pc: RTCPeerConnection
    channel: RTCDataChannel
    pub_socket: zmq.asyncio.Socket
    sub_socket: zmq.asyncio.Socket

    def __init__(self, create_channel: bool, uuid: Optional[UUID] = None):
        z_ctx: zmq.asyncio.Context = zmq.asyncio.Context.instance()
        self.pub_socket = z_ctx.socket(zmq.PUB)
        self.pub_socket.connect(f"inproc://{EVENT_BUS_SUB_ADDR}")
        self.sub_socket = z_ctx.socket(zmq.SUB)
        self.sub_socket.connect(f"inproc://{EVENT_BUS_PUB_ADDR}")
        self.sub_socket.subscribe(b"")
        self.uuid = uuid or uuid4()

        self.pc = RTCPeerConnection()
        self.pc.on(
            "connectionstatechange",
            lambda: print(f"{self} webrtc state {self.pc.connectionState}"),
        )

        if create_channel:
            self.channel = self.pc.createDataChannel(WEBRTC_CHANNEL_LABEL)
            self.channel.on("open", lambda: print("channel OPEN"))
            self.channel.on("open", self.forward_messages)
        else:
            self.pc.on("datachannel", self.on_channel)

    def on_state_changed(self):
        state = self.pc.connectionState
        if state == "connected":
            self.forward_messages()

    async def create_offer(self):
        await self.pc.setLocalDescription(await self.pc.createOffer())
        return self.pc.localDescription

    async def create_answer(self, offer: RTCSessionDescription):
        await self.pc.setRemoteDescription(offer)
        answer = await self.pc.createAnswer()
        if not answer:
            raise RuntimeError("Failed to create answer")
        await self.pc.setLocalDescription(answer)
        return self.pc.localDescription

    async def connect(self, answer: RTCSessionDescription):
        await self.pc.setRemoteDescription(answer)

    def on_channel(self, channel: RTCDataChannel):
        self.channel = channel
        self.forward_messages()

    def forward_messages(self):
        asyncio.ensure_future(self.forward_from_event_bus_to_webrtc())
        self.channel.on("message", self.forward_from_webrtc_to_event_bus)

    async def forward_from_event_bus_to_webrtc(self):
        poller = zmq.asyncio.Poller()
        poller.register(self.sub_socket, zmq.POLLIN)

        while True:
            await poller.poll()
            message = await self.sub_socket.recv_multipart()
            # Do not forward messages from this service to avoid feeback loop.
            if message[SOURCE] != self.uuid.bytes:
                self.channel.send(wrap_multipart(message))

    async def forward_from_webrtc_to_event_bus(self, message: bytes):

        # set a flag to indicate that this msg has been forwarded to the ev bus
        # hosting this service
        msg = unwrap_multipart(message)
        msg[SOURCE] = self.uuid.bytes
        await self.pub_socket.send_multipart(msg)

    def signaling_state(self) -> str:
        return self.pc.signalingState


class ClientWebRTC(Service):
    cress: CRESSInstance
    discovery_api: DiscoveryAPI
    connections: Dict[UUID, WebRTCConnection]
    offers: List[Any]

    @inject
    def __init__(
        self,
        cress: CRESSInstance = Provide[ClientContainer.instance],
        discovery_api: DiscoveryAPI = Provide[ClientContainer.discovery_api],
    ):
        super().__init__(service_name="CLIENT_WEBRTC")
        self.cress = cress
        self.discovery_api = discovery_api
        self.connections = dict()
        self.offers: List[Dict] = []

    async def start(self):
        asyncio.ensure_future(self.poll_discovery())
        await super().start()

    async def poll_discovery(self):
        while True:
            machines = self.discovery_api.get_machines()
            for machine in machines:
                # context = machine["machineData"]["context"]
                # if context != REVERSE_PROXY:
                #     continue

                uuid = UUID(
                    machine["uuid"]
                )  # TODO: filter out your own machine, don't want to connect to yourself.
                if uuid not in self.connections:
                    connection = WebRTCConnection(create_channel=True)
                    self.connections[uuid] = connection
                    offer = await connection.create_offer()
                    self.offers.append(
                        {
                            "sdp": offer.sdp,
                            "type": offer.type,
                            "to": str(uuid),
                        }
                    )
                    continue

                messages = machine["machineData"]["webrtcMessages"]
                if messages is None:
                    continue

                for answer in messages:
                    if (
                        answer["type"] == "answer"
                        and "to" in answer
                        and UUID(answer["to"]) == self.cress.uuid
                    ):
                        connection = self.connections[uuid]
                        if connection.signaling_state() != "have-local-offer":
                            continue

                        answer = RTCSessionDescription(
                            sdp=answer["sdp"], type=answer["type"]
                        )
                        await connection.connect(answer)

            self.discovery_api.register_machine(
                self.cress.uuid,
                context=self.cress.context,
                webrtc_messages=self.offers,
            )

            await asyncio.sleep(1)


class ReverseProxyWebRTC(Service):
    cress: CRESSInstance
    discovery_api: DiscoveryAPI
    connections: Dict[UUID, WebRTCConnection]
    answers: List[Any]

    @inject
    def __init__(
        self,
        cress: CRESSInstance = Provide[ClientContainer.instance],
        discovery_api: DiscoveryAPI = Provide[ClientContainer.discovery_api],
    ):
        super().__init__(service_name="REVERSE_PROXY_WEBRTC")
        self.cress = cress
        self.discovery_api = discovery_api
        self.connections = dict()
        self.answers = []

    async def start(self):
        asyncio.ensure_future(self.poll_discovery())
        await super().start()

    async def poll_discovery(self):
        while True:
            machines = self.discovery_api.get_machines()
            for machine in machines:
                # context = machine["machineData"]
                # if context != CLIENT:
                #     continue

                uuid = UUID(machine["uuid"])
                if uuid in self.connections:
                    continue

                messages = machine["machineData"]["webrtcMessages"]
                if messages is None:
                    continue

                for offer in messages:
                    if (
                        offer["type"] == "offer"
                        and "to" in offer
                        and UUID(offer["to"]) == self.cress.uuid
                    ):
                        connection = WebRTCConnection(create_channel=False)
                        self.connections[uuid] = connection

                        offer = RTCSessionDescription(
                            sdp=offer["sdp"], type=offer["type"]
                        )
                        answer = await self.connections[uuid].create_answer(offer)
                        self.answers.append(
                            {
                                "sdp": answer.sdp,
                                "type": answer.type,
                                "to": str(uuid),
                            }
                        )

            self.discovery_api.register_machine(
                self.cress.uuid,
                context=self.cress.context,
                webrtc_messages=self.answers,
            )

            await asyncio.sleep(1)
