# LitAgent — AI Agent Implementation Design Plan

**Package name:** `litagent`
**Install:** `uv pip install litagent` or `pip install litagent`
**Import:** `from litagent.core import AgentLoop, LiteLLMClient, Tool`
**License:** MIT
**Repository:** [Goooyi/LitAgent](https://github.com/Goooyi/LitAgent)
**Project manager:** `uv`
**Canonical design plan location:** `docs/design-plan.md` in the LitAgent repo

## Vision

A standalone, general-purpose AI Agent harness that can be adopted by any workflow — similar to [Pi-agent](https://github.com/badlogic/pi-mono)'s philosophy but not limited to coding agents. The agent core is abstract enough to support:

- **Production AI applications** (e.g., MyQA customer support): Agent operates within deployment-time constraints, grounded by shop manuals, promotions, customer data
- **Vertical/interactive agents** (e.g., Prompt optimization agent on tldraw canvas): Agent interacts with users for brainstorming and refinement
- **Any custom workflow**: The agent ships no default tools — consumers provide their own

## Core Principle: Skills ≠ Tools

Inspired by the [MCP community discussion on Skills vs Tools](https://github.com/modelcontextprotocol/modelcontextprotocol/discussions/1779):

> - Tools are atomic actions (send email, query database)
> - Skills are strategies for combining tools
> - Skills provide the "how" and "when", tools provide the "what"
> - Skills bridge the gap between user intent and tool execution

```
Skill (strategy / context)               Tool (capability / action)
┌────────────────────────────┐            ┌──────────────────────────┐
│ "When customer asks about  │            │ name: get_product_price  │
│  pricing, first identify   │  guides    │ params: {product_id}     │
│  the product, then check   │ ───────→   │ execute(): returns price │
│  promotions, then frame    │  how to    │                          │
│  response positively..."   │  use them  │ name: get_promotions     │
│                            │            │ params: {category}       │
│  (context for the agent)   │            │ execute(): returns deals │
└────────────────────────────┘            └──────────────────────────┘
```

A skill is **context** that the agent reads — instructions, strategy, best practices.
A tool is a **capability** that the agent invokes — it executes code and returns results.
The agent loop only knows about tools. Skills enter the agent as context (system prompt or via a `read_skill` tool).

## Architecture: Two-Package Split

Following [Pi's separation](https://deepwiki.com/badlogic/pi-mono/3-@mariozechnerpi-agent-core) of `pi-agent-core` (runtime) and `pi-coding-agent` (skills, sessions, extensions):

```
src/litagent/
├── core/                                # Package 1: the runtime
│   │                                    # No opinions. No defaults. Just the loop.
│   ├── __init__.py
│   ├── loop.py                          # Agent loop + state machine
│   ├── tool.py                          # Tool protocol, Pydantic schemas
│   ├── client.py                        # LLMClient protocol + LiteLLMClient
│   ├── events.py                        # Observability hooks
│   └── types.py                         # Typed messages, AgentResult, AgentState, etc.
│
├── session/                             # Package 2: the application layer
│   │                                    # Opinions on skills, persistence, extensions.
│   ├── __init__.py
│   ├── skill.py                         # Skill loader (markdown → context string)
│   ├── memory.py                        # Persistence (pluggable backends)
│   ├── session.py                       # Session management + checkpoints
│   └── extensions.py                    # Extension system (state in sessions)
│
└── adapters/                            # Optional eval/integration adapters
    ├── __init__.py
    ├── harbor.py                        # Harbor Framework BaseAgent adapter
    └── inspect_ai.py                    # Inspect AI agent_bridge adapter
```

**`core/`** is what myqa imports. It knows about: tools, the LLM client, the loop, state, events. Nothing else.

**`session/`** is the optional layer for building standalone agent applications. It knows about: skills, extensions, persistence, compaction. Depends on `core/`.

**`adapters/`** are optional eval/integration adapters. They depend on `core/` and the external framework.

MyQA only needs `core/` + its own tool/skill wiring. Someone building a standalone prompt-optimization agent uses both packages.

## Package 1: core

### 1.1 Typed Messages

Messages are provider-agnostic typed dataclasses — not dicts, not OpenAI format. Inspired by [pi-mono's canonical types](https://github.com/badlogic/pi-mono/tree/main/packages/ai) where the framework defines its own types and each client converts between them and the provider's format.

```python
# core/types.py

@dataclass
class SystemMessage:
    content: str

@dataclass
class UserMessage:
    content: str

@dataclass
class AssistantMessage:
    content: str | None = None
    tool_calls: list[ToolCall] = field(default_factory=list)

@dataclass
class ToolResultMessage:
    tool_call_id: str
    content: str

Message = SystemMessage | UserMessage | AssistantMessage | ToolResultMessage
```

The agent loop, client protocol, and all consumer code work with these types. No code outside of a client implementation ever touches provider-specific formats.

### 1.2 Injectable LLMClient Protocol

The agent loop communicates with LLMs through an injectable `LLMClient` protocol. This is the key abstraction boundary — swap providers without changing agent code.

```python
# core/client.py

class LLMClient(Protocol):
    """Injectable protocol. Swap providers without changing agent code."""
    async def chat(
        self,
        messages: list[Message],        # our typed messages
        tools: list[Tool] | None = None,
        model: str | None = None,
        **kwargs,
    ) -> LLMResponse: ...
```

**v0.0.2 default: LiteLLMClient** — backed by [litellm](https://docs.litellm.ai/) SDK, supporting 100+ providers via `provider/model` strings. Each client implementation owns the conversion between our typed messages and the provider's format.

```python
class LiteLLMClient:
    """Default client. 100+ providers via litellm SDK."""

    def __init__(self, model: str = "openai/gpt-4o-mini", **default_kwargs):
        self.model = model
        self._default_kwargs = default_kwargs

    async def chat(self, messages: list[Message], tools=None, model=None, **kwargs) -> LLMResponse:
        from litellm import acompletion
        openai_messages = [self._to_openai_message(m) for m in messages]  # our types → OpenAI dicts
        response = await acompletion(model=model or self.model, messages=openai_messages, ...)
        return self._from_response(response)  # litellm response → our LLMResponse
```

**Abstraction layers (inspired by pi-mono):**
- **Layer 1: Canonical types** — `SystemMessage`, `UserMessage`, `AssistantMessage`, `ToolResultMessage`, `LLMResponse`
- **Layer 2: Protocol** — `LLMClient.chat(list[Message]) → LLMResponse`
- **Layer 3: Converters** — Each client converts between Layer 1 types and provider format. LiteLLMClient handles this for all litellm-supported providers. Future TensorZeroClient would handle TZ's different format.

**Usage:**

```python
# Default: litellm (100+ providers, zero config beyond API key)
from litagent.core import AgentLoop, LiteLLMClient
agent = AgentLoop(client=LiteLLMClient(model="openai/gpt-4o-mini"), ...)

# Anthropic
agent = AgentLoop(client=LiteLLMClient(model="anthropic/claude-sonnet-4-5"), ...)

# Local Ollama
agent = AgentLoop(client=LiteLLMClient(model="ollama/llama3"), ...)

# Future: TensorZero for production (observability, experiments, routing)
# async with TensorZeroClient(config_file="tensorzero.toml") as client:
#     agent = AgentLoop(client=client, ...)
```

**Why this matters:**
- Users start with `LiteLLMClient` (zero config, any provider)
- Later add `TensorZeroClient` for production observability/optimization
- Or implement their own `LLMClient` for custom providers
- The agent loop never knows or cares what's behind the protocol

### 1.3 The Agent Loop

Inspired by [Pi-agent-core's state machine](https://deepwiki.com/badlogic/pi-mono/3.1-agent-and-transport-layer) (Idle → Streaming → ProcessingTools) and [Pi's blog on minimal agent design](https://mariozechner.at/posts/2025-11-30-pi-coding-agent/).

```python
# core/loop.py

class AgentLoop:
    def __init__(self, client: LLMClient, system_prompt: str,
                 tools: list[Tool], max_turns: int = 10,
                 on_event: Callable | None = None):
        self.client = client
        self.state = AgentState.IDLE
        ...

    async def run(self, messages: list[Message]) -> AgentResult:
        """The loop. Pi-agent style: dead simple."""
        messages = list(messages)  # always copy to avoid mutating caller's list
        self.state = AgentState.STREAMING

        while turns < self.max_turns:
            response = await self.client.chat(messages=messages, tools=self.tools)

            messages.append(AssistantMessage(content=response.text, tool_calls=response.tool_calls))

            if not response.tool_calls:
                return AgentResult(text=response.text, messages=messages)

            self.state = AgentState.PROCESSING_TOOLS
            for tc in response.tool_calls:
                result = await self._execute_tool(tc)
                messages.append(ToolResultMessage(tool_call_id=tc.id, content=result))

            self.state = AgentState.STREAMING
            turns += 1

        return AgentResult(text=None, hit_max_turns=True, messages=messages)
```

### 1.4 The Tool Protocol

Tools use Pydantic for schema validation. Tool schemas are passed to the LLM via the native `tools` API parameter — **not** injected into the system prompt.

```python
# core/tool.py

class Tool(BaseModel):
    name: str
    description: str
    parameters: dict          # JSON Schema (auto-generated from Pydantic model)
    execute: Callable         # async (args) -> str

    def to_openai_schema(self) -> dict:
        """Convert to OpenAI tool format. Used by LiteLLMClient."""
        ...

    @classmethod
    def from_function(cls, fn, name=None, description=None):
        """Create a tool from a typed Python function. Sync functions auto-wrapped."""
        ...
```

### 1.5 Events / Observability

The agent loop emits events via the Observer pattern. This is the hook point for observability tools like Langfuse, LangSmith, etc.

```python
# core/events.py

class EventType(Enum):
    AGENT_START = "agent_start"
    AGENT_END = "agent_end"
    TURN_START = "turn_start"
    TURN_END = "turn_end"
    TOOL_CALL = "tool_call"
    TOOL_RESULT = "tool_result"
    LLM_CALL = "llm_call"
    LLM_RESPONSE = "llm_response"

# Usage: plug in Langfuse, or just print
agent = AgentLoop(on_event=langfuse_observer, ...)
```

Event-to-Langfuse mapping:
| Our Event | Langfuse Concept |
|---|---|
| AGENT_START → AGENT_END | Trace |
| LLM_CALL → LLM_RESPONSE | Generation |
| TOOL_CALL → TOOL_RESULT | Span |

### 1.6 Async Requirements

All I/O in agent-core MUST be async. This prevents blocking the event loop in Uvicorn/asyncio environments.

- `LLMClient.chat()` — async
- `Tool.execute()` — async (`Callable[..., Awaitable[str]]`)
- For wrapping legacy sync functions: `Tool.from_function()` auto-wraps with `asyncio.to_thread()`
- Never import `requests` — use `httpx` or the async SDK clients

## Package 2: session

### 2.1 Skills

Skills are on-demand context documents that tell the agent HOW and WHEN to use its tools. They follow the [Agent Skills](https://pi.dev/) pattern introduced by Claude and adopted by [Pi-coding-agent](https://github.com/badlogic/pi-mono/tree/main/packages/coding-agent).

A skill is NOT a tool. A skill is a markdown document with YAML frontmatter that the agent reads for strategy guidance.

```python
# session/skill.py

@dataclass
class Skill:
    name: str
    description: str
    trigger: str              # when should this skill be activated
    uses_tools: list[str]     # names of tools this skill works with (reference only)
    instructions: str         # the markdown body — strategy for the agent

    @classmethod
    def from_markdown(cls, path: str) -> "Skill":
        """Load a skill from a markdown file with YAML frontmatter."""
        ...
```

**How skills enter the agent at runtime** — two modes:

Mode A (pre-loaded, for myqa): The skill instructions are baked into the system prompt before the agent runs. No extra LLM round-trip.

```python
agent = AgentLoop(
    client=LiteLLMClient(model="openai/gpt-4o"),
    system_prompt=shop_manual + "\n\n" + skill.instructions,
    tools=[get_product_price, get_active_promotions],
    max_turns=3,
)
```

Mode B (on-demand, for general agents): A `read_skill` tool lets the agent discover and load skills during the loop.

### 2.2 Memory / Persistence

Inspired by [LangGraph's persistence](https://docs.langchain.com/oss/python/langgraph/persistence) but much simpler.

```python
# session/memory.py

class MemoryStore(Protocol):
    async def get(self, namespace: str, key: str) -> Any: ...
    async def put(self, namespace: str, key: str, value: Any): ...
    async def delete(self, namespace: str, key: str): ...
    async def list(self, namespace: str) -> list[str]: ...

class InMemoryStore(MemoryStore): ...     # for testing
class FileStore(MemoryStore): ...         # for local-first
class DBStore(MemoryStore): ...           # for server-deployed
```

### 2.3 Sessions

```python
# session/session.py

@dataclass
class Session:
    id: str
    messages: list[Message]
    metadata: dict
    parent_id: str | None = None
    checkpoint_id: str | None
```

### 2.4 Extensions

Inspired by [Pi's extension system](https://pi.dev/).

```python
# session/extensions.py

class Extension(Protocol):
    name: str
    def on_register(self, agent: AgentLoop, session: Session): ...
    def on_event(self, event: Event): ...
```

This is future work — the core loop and tools come first.

## Eval Framework Adapters

### Harbor Framework

[Harbor](https://harborframework.com/docs/agents#integrating-your-own-agent) requires implementing `BaseAgent` with `name()`, `version()`, `setup()`, and `run()` methods. Our adapter wraps an `AgentLoop` instance. ~30 lines.

### Inspect AI

[Inspect AI's Agent Bridge](https://inspect.aisi.org.uk/agent-bridge.html) intercepts OpenAI API calls via `model="inspect"`. ~40 lines.

## MyQA Integration

Integration point: `myqa/tools/answer_gen_qas.py`, replacing `intent_inqury_preset` → `execute_preset_response` → `preset_resp_by_llm`.

```python
# myqa/agent_integration.py

async def handle_intent_with_agent(context: ContextWrapper, intent: str):
    skill = skill_registry.get(intent)
    if skill is None:
        return await legacy_intent_inqury_preset(context, intent)

    tools = build_tools_for_intent(context, intent)
    agent = AgentLoop(
        client=LiteLLMClient(model="openai/gpt-4o"),
        system_prompt=get_shop_manual(context) + "\n\n" + skill.instructions,
        tools=tools,
        max_turns=3,
        on_event=langfuse_trace(context),
    )
    messages = [UserMessage(content=context.last_user_message)]
    result = await agent.run(messages)
    return AnswerMeta(answer=result.text, ...)
```

## Project Structure

```
litagent/
├── pyproject.toml
├── LICENSE                              # MIT
├── README.md
├── CLAUDE.md                            # Dev guide + known fixes
├── CHANGELOG.md
├── docs/
│   └── design-plan.md                   # This file
├── src/
│   └── litagent/
│       ├── __init__.py
│       ├── core/
│       │   ├── __init__.py
│       │   ├── loop.py
│       │   ├── tool.py
│       │   ├── client.py               # LLMClient protocol + LiteLLMClient
│       │   ├── events.py
│       │   └── types.py                # Typed message dataclasses
│       ├── session/                     # not yet implemented
│       └── adapters/                    # not yet implemented
└── tests/
    ├── features/
    │   ├── agent_loop.feature
    │   ├── litellm_client.feature
    │   └── tool.feature
    ├── test_agent_loop.py
    ├── test_litellm_client.py
    └── test_tool.py
```

```toml
# pyproject.toml — managed by uv
[project]
name = "litagent"
version = "0.0.2"
requires-python = ">=3.11"
license = "MIT"
dependencies = [
    "pydantic>=2.0",
    "litellm>=1.0",
]

[project.optional-dependencies]
inspect = ["inspect-ai"]
langfuse = ["langfuse"]
dev = [
    "pytest>=8.0",
    "pytest-asyncio>=0.24",
    "pytest-bdd>=8.0",
]
```

## Build Order

1. **Phase 1** (v0.0.1): `core/` — client.py (TensorZero + OpenAI) + loop.py + tool.py + events.py + types.py. BDD tests. **DONE**
2. **Phase 1.5** (v0.0.2): Replace TensorZero/OpenAI with litellm. Typed message dataclasses. **DONE**
3. **Phase 2**: `session/` — memory.py + session.py. Wire into myqa's existing DB for persistence
4. **Phase 3**: `session/` — skill.py. Define skill markdown files for myqa intents, load them at startup
5. **Phase 4**: `adapters/` — Inspect AI + Harbor adapters for eval
6. **Phase 5**: Observability integration (Langfuse via event hooks)
7. **Future**: Extension system, TensorZeroClient for production, streaming support, skill distribution

## Key Constraints for MyQA

- Max 2-3 agent turns per request (latency-sensitive customer support)
- Tools are data-fetching, not action-taking
- System prompt = customer support manual
- No sandbox needed (agent reads data, doesn't write to filesystem)
- Structured output via tool calls replaces current CoT `||` separator parsing
- Skills are pre-loaded (Mode A) to avoid extra LLM round-trips

## Design Decisions Log

| Decision | Chosen | Rejected | Why |
|----------|--------|----------|-----|
| Package name | `litagent` | agentkit, miniagent, tinyagent, liteagent | Available on PyPI; short; "lit" = illuminated/excellent; clean import path |
| Language | Python | TypeScript | MyQA is Python; LLM ecosystem is Python; agent loop is trivial so language perf doesn't matter for I/O-bound work |
| Framework | None (from scratch) | LangChain, Vercel AI SDK | Core loop is ~50 lines; frameworks add indirection without value |
| Package split | 2 logical packages (core + session) in 1 repo | Separate repos, monolith | Matches Pi's architecture; clean dependency direction; single `pip install` |
| LLM client (v0.0.2) | litellm SDK | TensorZero, raw OpenAI SDK | 100+ providers out of the box; no gateway deployment; stateless (no lifecycle management); TensorZero can be added later as optional production client |
| Message types | Typed dataclasses | `dict[str, Any]` | Type safety; provider-agnostic; pi-mono's canonical types pattern; catches bugs at construction not serialization |
| LLM client architecture | Injectable `LLMClient` protocol (structural subtyping) | Hardcoded client, ABC inheritance | Enables provider swapping, eval framework integration, mock testing |
| Tool formatting | Native API `tools` parameter | System prompt injection | Modern LLM APIs support native tool definitions; litellm handles provider-specific formatting |
| Observability | Event emitter (Observer pattern) via `on_event` callback | Custom OTEL implementation | Simple, extensible; Langfuse/LangSmith plug in as observers; event handler errors isolated from agent loop |
| Skills vs Tools | Separate concepts | Skills-are-tools | MCP discussion #1779 clarified: skills = strategy/context, tools = actions/capabilities |
| Skill loading for myqa | Pre-loaded (Mode A) | On-demand (Mode B) | Saves 1 LLM round-trip; intent is already known before agent runs |
| Async | All I/O must be async | Sync allowed | Uvicorn/asyncio environment; blocking calls stall the event loop |
| License | MIT | Apache 2.0, AGPL | Simplest, most permissive; Pi-agent also uses MIT |
| Project manager | `uv` | poetry, pip | Fast, modern, handles venv + deps + lockfile |
| Testing style | BDD with `pytest-bdd` | Regular pytest | Gherkin feature files make behavior explicit; scenarios map to agent behaviors |

## References

- [Pi-agent (badlogic/pi-mono)](https://github.com/badlogic/pi-mono) — The primary architectural inspiration. Minimal core, extension system, 4-tool philosophy
- [Pi: The Minimal Agent Within OpenClaw (Armin Ronacher)](https://lucumr.pocoo.org/2026/1/31/pi/) — Pi's extension system, state persistence in sessions, self-modification philosophy
- [What I learned building a minimal coding agent (Mario Zechner)](https://mariozechner.at/posts/2025-11-30-pi-coding-agent/) — Minimal system prompt, observable interactions, no sub-agents, file-based state
- [Pi-ai unified LLM API](https://github.com/badlogic/pi-mono/tree/main/packages/ai) — Inspiration for our typed message abstraction layer
- [litellm](https://docs.litellm.ai/) — Unified LLM SDK supporting 100+ providers via OpenAI-compatible interface
- [MCP Discussion #1779: Skills vs Tools](https://github.com/modelcontextprotocol/modelcontextprotocol/discussions/1779) — Key distinction: tools are atomic actions, skills are strategies for combining tools
- [LangGraph Persistence](https://docs.langchain.com/oss/python/langgraph/persistence) — Checkpoints, threads, state snapshots, cross-thread memory store
- [Harbor Framework — Agent Integration](https://harborframework.com/docs/agents#integrating-your-own-agent) — `BaseAgent` interface for containerized agent evaluation
- [Inspect AI — Agent Bridge](https://inspect.aisi.org.uk/agent-bridge.html) — Intercepts OpenAI API calls for eval; requires injectable LLM client
