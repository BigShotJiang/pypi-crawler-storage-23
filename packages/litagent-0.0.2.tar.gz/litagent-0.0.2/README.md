# LitAgent

A minimal, general-purpose AI agent harness.

```bash
pip install litagent
```

```python
from litagent.core import AgentLoop, Tool, OpenAIClient

agent = AgentLoop(
    client=OpenAIClient(),
    system_prompt="You are helpful.",
    tools=[...],
    max_turns=5,
)
result = await agent.run([{"role": "user", "content": "Hello"}])
```
