"""BDD tests for the agent loop."""

from __future__ import annotations

import asyncio
import json

import pytest
from pytest_bdd import given, when, then, scenarios, parsers

from litagent.core.events import Event, EventType
from litagent.core.loop import AgentLoop
from litagent.core.tool import Tool
from litagent.core.types import (
    LLMResponse,
    Message,
    SystemMessage,
    ToolCall,
    ToolResultMessage,
    Usage,
    UserMessage,
)

scenarios("features/agent_loop.feature")


# -- Mock LLM Client ----------------------------------------------------------

class MockClient:
    def __init__(self, responses: list[LLMResponse]):
        self.responses = list(responses)
        self.calls: list[dict] = []

    async def chat(self, messages, tools=None, model=None, **kwargs):
        self.calls.append({"messages": messages, "tools": tools})
        return self.responses.pop(0)


# -- Mock tool functions -------------------------------------------------------

async def get_weather(city: str) -> str:
    return f"25C and sunny in {city}"


async def get_price(product_id: str) -> str:
    return f"Product {product_id} costs $99.99"


async def failing_tool_fn(x: str) -> str:
    raise ValueError("Something went wrong")


# -- Fixtures ------------------------------------------------------------------

@pytest.fixture
def ctx():
    return {
        "system_prompt": "",
        "tools": [],
        "client": None,
        "max_turns": 5,
        "events": [],
        "on_event": None,
        "result": None,
    }


# -- Given steps ---------------------------------------------------------------

@given(parsers.parse('a system prompt "{prompt}"'))
def given_system_prompt(ctx, prompt):
    ctx["system_prompt"] = prompt


@given(parsers.parse('an LLM that responds with text "{text}"'))
def given_llm_text_response(ctx, text):
    ctx["client"] = MockClient([
        LLMResponse(text=text, stop_reason="end_turn"),
    ])


@given(parsers.parse('a tool "{name}" that returns "{template}"'))
def given_tool(ctx, name, template):
    if name == "get_weather":
        tool = Tool.from_function(get_weather, description=f"Get {name}")
    elif name == "get_price":
        tool = Tool.from_function(get_price, description=f"Get {name}")
    else:
        async def dynamic_tool(**kwargs) -> str:
            return template.format(**kwargs)
        dynamic_tool.__name__ = name
        tool = Tool.from_function(dynamic_tool, description=f"Tool {name}")
    ctx["tools"].append(tool)


@given(parsers.parse('a tool "{name}" that raises an error "{error_msg}"'))
def given_failing_tool(ctx, name, error_msg):
    tool = Tool.from_function(failing_tool_fn, name=name, description=f"Tool {name}")
    ctx["tools"].append(tool)


@given(parsers.cfparse(
    'an LLM that first calls tool "{tool_name}" with arguments {args} then responds with text "{text}"',
))
def given_llm_tool_then_text(ctx, tool_name, args, text):
    arguments = json.loads(args)
    ctx["client"] = MockClient([
        LLMResponse(
            text=None,
            tool_calls=[ToolCall(id="tc_1", name=tool_name, arguments=arguments)],
            stop_reason="tool_use",
        ),
        LLMResponse(text=text, stop_reason="end_turn"),
    ])


@given(parsers.cfparse(
    'an LLM that always calls tool "{tool_name}" with arguments {args}',
))
def given_llm_always_tool(ctx, tool_name, args):
    arguments = json.loads(args)
    responses = [
        LLMResponse(
            text=None,
            tool_calls=[ToolCall(id=f"tc_{i}", name=tool_name, arguments=arguments)],
            stop_reason="tool_use",
        )
        for i in range(10)
    ]
    ctx["client"] = MockClient(responses)


@given(parsers.parse("max turns is set to {n:d}"))
def given_max_turns(ctx, n):
    ctx["max_turns"] = n


@given(parsers.cfparse(
    'an LLM that calls tools "{tool1}" and "{tool2}" then responds with text "{text}"',
))
def given_llm_multi_tool_then_text(ctx, tool1, tool2, text):
    ctx["client"] = MockClient([
        LLMResponse(
            text=None,
            tool_calls=[
                ToolCall(id="tc_1", name=tool1, arguments={"city": "Tokyo"}),
                ToolCall(id="tc_2", name=tool2, arguments={"product_id": "ABC"}),
            ],
            stop_reason="tool_use",
        ),
        LLMResponse(text=text, stop_reason="end_turn"),
    ])


@given("an event listener is attached")
def given_event_listener(ctx):
    ctx["events"] = []
    ctx["on_event"] = lambda e: ctx["events"].append(e)


@given(parsers.cfparse(
    'an LLM that first calls tool "{tool_name}" with arguments {args} using {in_tok:d} input and {out_tok:d} output tokens then responds with text "{text}" using {in_tok2:d} input and {out_tok2:d} output tokens',
))
def given_llm_with_usage(ctx, tool_name, args, in_tok, out_tok, text, in_tok2, out_tok2):
    arguments = json.loads(args)
    ctx["client"] = MockClient([
        LLMResponse(
            text=None,
            tool_calls=[ToolCall(id="tc_1", name=tool_name, arguments=arguments)],
            stop_reason="tool_use",
            usage=Usage(input_tokens=in_tok, output_tokens=out_tok),
        ),
        LLMResponse(
            text=text,
            stop_reason="end_turn",
            usage=Usage(input_tokens=in_tok2, output_tokens=out_tok2),
        ),
    ])


# -- When steps ----------------------------------------------------------------

@when(parsers.parse('the agent processes the message "{message}"'), target_fixture="result")
def when_agent_processes(ctx, message):
    agent = AgentLoop(
        client=ctx["client"],
        system_prompt=ctx["system_prompt"],
        tools=ctx["tools"],
        max_turns=ctx["max_turns"],
        on_event=ctx.get("on_event"),
    )
    result = asyncio.run(agent.run([UserMessage(content=message)]))
    ctx["result"] = result
    return result


# -- Then steps ----------------------------------------------------------------

@then(parsers.parse('the result text should be "{expected}"'))
def then_result_text(ctx, expected):
    assert ctx["result"].text == expected


@then("the result text should be empty")
def then_result_text_empty(ctx):
    assert ctx["result"].text is None


@then("the agent should not hit max turns")
def then_not_hit_max_turns(ctx):
    assert not ctx["result"].hit_max_turns


@then("the agent should hit max turns")
def then_hit_max_turns(ctx):
    assert ctx["result"].hit_max_turns


@then(parsers.parse("the LLM should have been called {n:d} time"))
@then(parsers.parse("the LLM should have been called {n:d} times"))
def then_llm_called_n_times(ctx, n):
    assert len(ctx["client"].calls) == n


@then(parsers.parse('a tool result containing "{substring}" should be in the messages'))
def then_tool_result_contains(ctx, substring):
    tool_msgs = [m for m in ctx["result"].messages if isinstance(m, ToolResultMessage)]
    assert any(substring.lower() in m.content.lower() for m in tool_msgs)


@then(parsers.parse("there should be {n:d} tool result messages"))
def then_n_tool_results(ctx, n):
    tool_msgs = [m for m in ctx["result"].messages if isinstance(m, ToolResultMessage)]
    assert len(tool_msgs) == n


@then(parsers.parse('events should include "{event_type}"'))
def then_events_include(ctx, event_type):
    event_types = [e.type.value for e in ctx["events"]]
    assert event_type in event_types


@then(parsers.parse('the first message should be a SystemMessage with content "{content}"'))
def then_first_msg_system(ctx, content):
    msg = ctx["result"].messages[0]
    assert isinstance(msg, SystemMessage)
    assert msg.content == content


@then(parsers.parse("total input tokens should be {n:d}"))
def then_input_tokens(ctx, n):
    assert ctx["result"].usage.input_tokens == n


@then(parsers.parse("total output tokens should be {n:d}"))
def then_output_tokens(ctx, n):
    assert ctx["result"].usage.output_tokens == n
