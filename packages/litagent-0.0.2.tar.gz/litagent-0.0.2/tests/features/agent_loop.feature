Feature: Agent Loop
  The agent loop calls the LLM, executes tools, and repeats until done or max turns.

  Background:
    Given a system prompt "You are helpful."

  Scenario: Simple text response without tools
    Given an LLM that responds with text "Hello!"
    When the agent processes the message "Hi"
    Then the result text should be "Hello!"
    And the agent should not hit max turns
    And the LLM should have been called 1 time

  Scenario: Tool call then text response
    Given a tool "get_weather" that returns "25C and sunny in {city}"
    And an LLM that first calls tool "get_weather" with arguments {"city": "Tokyo"} then responds with text "It's 25C in Tokyo!"
    When the agent processes the message "Weather in Tokyo?"
    Then the result text should be "It's 25C in Tokyo!"
    And the agent should not hit max turns
    And the LLM should have been called 2 times
    And a tool result containing "25C" should be in the messages

  Scenario: Agent hits max turns
    Given a tool "get_weather" that returns "25C and sunny in {city}"
    And an LLM that always calls tool "get_weather" with arguments {"city": "Tokyo"}
    And max turns is set to 3
    When the agent processes the message "Weather?"
    Then the agent should hit max turns
    And the result text should be empty

  Scenario: Unknown tool returns error without crashing
    Given an LLM that first calls tool "nonexistent" with arguments {} then responds with text "Sorry, I couldn't do that."
    When the agent processes the message "Do something"
    Then the result text should be "Sorry, I couldn't do that."
    And a tool result containing "error" should be in the messages

  Scenario: Tool exception is captured as error
    Given a tool "failing_tool" that raises an error "Something went wrong"
    And an LLM that first calls tool "failing_tool" with arguments {"x": "test"} then responds with text "I encountered an error."
    When the agent processes the message "Do it"
    Then the result text should be "I encountered an error."
    And a tool result containing "Something went wrong" should be in the messages

  Scenario: Multiple tool calls in one turn
    Given a tool "get_weather" that returns "25C and sunny in {city}"
    And a tool "get_price" that returns "Product {product_id} costs $99.99"
    And an LLM that calls tools "get_weather" and "get_price" then responds with text "Done!"
    When the agent processes the message "Weather and price?"
    Then the result text should be "Done!"
    And there should be 2 tool result messages

  Scenario: Events are emitted during the loop
    Given an LLM that responds with text "Hello!"
    And an event listener is attached
    When the agent processes the message "Hi"
    Then events should include "agent_start"
    And events should include "agent_end"
    And events should include "turn_start"
    And events should include "llm_call"
    And events should include "llm_response"

  Scenario: System prompt is prepended to messages
    Given an LLM that responds with text "Hi!"
    When the agent processes the message "Hello"
    Then the first message should be a SystemMessage with content "You are helpful."

  Scenario: Usage tokens are accumulated across turns
    Given a tool "get_weather" that returns "25C and sunny in {city}"
    And an LLM that first calls tool "get_weather" with arguments {"city": "Tokyo"} using 100 input and 20 output tokens then responds with text "Done!" using 150 input and 30 output tokens
    When the agent processes the message "Weather?"
    Then total input tokens should be 250
    And total output tokens should be 50
