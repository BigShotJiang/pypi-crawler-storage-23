Feature: LiteLLM Client Message Conversion
  The LiteLLM client converts between LitAgent typed messages and OpenAI-format dicts.

  Scenario: SystemMessage converts to OpenAI format
    Given a SystemMessage with content "You are helpful."
    When the message is converted to OpenAI format
    Then the OpenAI message role should be "system"
    And the OpenAI message content should be "You are helpful."

  Scenario: UserMessage converts to OpenAI format
    Given a UserMessage with content "Hello"
    When the message is converted to OpenAI format
    Then the OpenAI message role should be "user"
    And the OpenAI message content should be "Hello"

  Scenario: AssistantMessage with text converts to OpenAI format
    Given an AssistantMessage with content "Hi there"
    When the message is converted to OpenAI format
    Then the OpenAI message role should be "assistant"
    And the OpenAI message content should be "Hi there"

  Scenario: AssistantMessage with tool calls converts to OpenAI format
    Given an AssistantMessage with a tool call "get_weather" id "tc_1" arguments {"city": "Tokyo"}
    When the message is converted to OpenAI format
    Then the OpenAI message should have a tool_calls array
    And the tool call function name should be "get_weather"
    And the tool call arguments should be a JSON string

  Scenario: ToolResultMessage converts to OpenAI format
    Given a ToolResultMessage for "tc_1" with content "25C sunny"
    When the message is converted to OpenAI format
    Then the OpenAI message role should be "tool"
    And the OpenAI message should have tool_call_id "tc_1"

  Scenario: LLM response with tool calls is parsed correctly
    Given a mock litellm response with tool call "get_weather" id "tc_1" arguments {"city": "Tokyo"}
    When the response is converted to LLMResponse
    Then the LLMResponse should have 1 tool call
    And the tool call name should be "get_weather"
    And the stop reason should be "tool_use"

  Scenario: LLM response with text is parsed correctly
    Given a mock litellm response with text "Hello!" and finish reason "stop"
    When the response is converted to LLMResponse
    Then the LLMResponse text should be "Hello!"
    And the stop reason should be "end_turn"
