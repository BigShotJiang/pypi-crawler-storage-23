Feature: Tool
  Tools are atomic actions the agent can invoke, with auto-generated JSON schemas.

  Scenario: Create tool from async function
    Given an async function "get_weather" with parameter "city" of type "str"
    When a tool is created from the function with description "Get weather for a city"
    Then the tool name should be "get_weather"
    And the tool description should be "Get weather for a city"
    And the tool parameters should have type "object"
    And "city" should be in the required parameters

  Scenario: Convert tool to OpenAI schema
    Given a tool "get_weather" with description "Get weather"
    When the tool is converted to OpenAI schema
    Then the schema type should be "function"
    And the schema function name should be "get_weather"
    And the schema should have "parameters"
