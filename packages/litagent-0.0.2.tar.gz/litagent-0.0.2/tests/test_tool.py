"""BDD tests for the Tool class."""

from __future__ import annotations

import pytest
from pytest_bdd import given, when, then, scenarios, parsers

from litagent.core.tool import Tool

scenarios("features/tool.feature")


# -- Mock functions ------------------------------------------------------------

async def get_weather(city: str) -> str:
    return f"25C and sunny in {city}"


# -- Fixtures ------------------------------------------------------------------

@pytest.fixture
def ctx():
    return {"tool": None, "schema": None}


# -- Given steps ---------------------------------------------------------------

@given(parsers.parse('an async function "{name}" with parameter "{param}" of type "{type_name}"'))
def given_async_function(ctx, name, param, type_name):
    ctx["function"] = get_weather


@given(parsers.parse('a tool "{name}" with description "{desc}"'))
def given_tool(ctx, name, desc):
    ctx["tool"] = Tool.from_function(get_weather, description=desc)


# -- When steps ----------------------------------------------------------------

@when(parsers.parse('a tool is created from the function with description "{desc}"'))
def when_tool_created(ctx, desc):
    ctx["tool"] = Tool.from_function(ctx["function"], description=desc)


@when("the tool is converted to OpenAI schema")
def when_to_openai_schema(ctx):
    ctx["schema"] = ctx["tool"].to_openai_schema()


# -- Then steps ----------------------------------------------------------------

@then(parsers.parse('the tool name should be "{name}"'))
def then_tool_name(ctx, name):
    assert ctx["tool"].name == name


@then(parsers.parse('the tool description should be "{desc}"'))
def then_tool_description(ctx, desc):
    assert ctx["tool"].description == desc


@then(parsers.parse('the tool parameters should have type "{type_name}"'))
def then_tool_params_type(ctx, type_name):
    assert ctx["tool"].parameters["type"] == type_name


@then(parsers.parse('"{param}" should be in the required parameters'))
def then_param_required(ctx, param):
    assert param in ctx["tool"].parameters["required"]


@then(parsers.parse('the schema type should be "{type_name}"'))
def then_schema_type(ctx, type_name):
    assert ctx["schema"]["type"] == type_name


@then(parsers.parse('the schema function name should be "{name}"'))
def then_schema_fn_name(ctx, name):
    assert ctx["schema"]["function"]["name"] == name


@then(parsers.parse('the schema should have "{field}"'))
def then_schema_has_field(ctx, field):
    assert field in ctx["schema"]["function"]
