"""BDD tests for LiteLLM client message conversion."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any

import pytest
from pytest_bdd import given, when, then, scenarios, parsers

from litagent.core.client import LiteLLMClient
from litagent.core.types import (
    AssistantMessage,
    SystemMessage,
    ToolCall,
    ToolResultMessage,
    UserMessage,
)

scenarios("features/litellm_client.feature")


# -- Mock litellm response objects ---------------------------------------------

@dataclass
class MockFunction:
    name: str
    arguments: str


@dataclass
class MockToolCall:
    id: str
    function: MockFunction


@dataclass
class MockMessage:
    content: str | None = None
    tool_calls: list[MockToolCall] | None = None


@dataclass
class MockUsage:
    prompt_tokens: int = 0
    completion_tokens: int = 0


@dataclass
class MockChoice:
    message: MockMessage = field(default_factory=MockMessage)
    finish_reason: str = "stop"


@dataclass
class MockResponse:
    choices: list[MockChoice] = field(default_factory=list)
    usage: MockUsage | None = None


# -- Fixtures ------------------------------------------------------------------

@pytest.fixture
def ctx():
    return {"message": None, "openai_msg": None, "mock_response": None, "llm_response": None}


# -- Given steps ---------------------------------------------------------------

@given(parsers.parse('a SystemMessage with content "{content}"'))
def given_system_message(ctx, content):
    ctx["message"] = SystemMessage(content=content)


@given(parsers.parse('a UserMessage with content "{content}"'))
def given_user_message(ctx, content):
    ctx["message"] = UserMessage(content=content)


@given(parsers.parse('an AssistantMessage with content "{content}"'))
def given_assistant_message(ctx, content):
    ctx["message"] = AssistantMessage(content=content)


@given(parsers.cfparse(
    'an AssistantMessage with a tool call "{name}" id "{tc_id}" arguments {args}',
))
def given_assistant_tool_call(ctx, name, tc_id, args):
    arguments = json.loads(args)
    ctx["message"] = AssistantMessage(
        content=None,
        tool_calls=[ToolCall(id=tc_id, name=name, arguments=arguments)],
    )


@given(parsers.parse('a ToolResultMessage for "{tc_id}" with content "{content}"'))
def given_tool_result_message(ctx, tc_id, content):
    ctx["message"] = ToolResultMessage(tool_call_id=tc_id, content=content)


@given(parsers.cfparse(
    'a mock litellm response with tool call "{name}" id "{tc_id}" arguments {args}',
))
def given_mock_response_tool_call(ctx, name, tc_id, args):
    arguments = json.loads(args)
    ctx["mock_response"] = MockResponse(
        choices=[MockChoice(
            message=MockMessage(
                content=None,
                tool_calls=[MockToolCall(
                    id=tc_id,
                    function=MockFunction(name=name, arguments=json.dumps(arguments)),
                )],
            ),
            finish_reason="tool_calls",
        )],
        usage=MockUsage(prompt_tokens=10, completion_tokens=5),
    )


@given(parsers.cfparse(
    'a mock litellm response with text "{text}" and finish reason "{reason}"',
))
def given_mock_response_text(ctx, text, reason):
    ctx["mock_response"] = MockResponse(
        choices=[MockChoice(
            message=MockMessage(content=text, tool_calls=None),
            finish_reason=reason,
        )],
        usage=MockUsage(prompt_tokens=10, completion_tokens=5),
    )


# -- When steps ----------------------------------------------------------------

@when("the message is converted to OpenAI format")
def when_convert_to_openai(ctx):
    ctx["openai_msg"] = LiteLLMClient._to_openai_message(ctx["message"])


@when("the response is converted to LLMResponse")
def when_convert_response(ctx):
    ctx["llm_response"] = LiteLLMClient._from_response(ctx["mock_response"])


# -- Then steps ----------------------------------------------------------------

@then(parsers.parse('the OpenAI message role should be "{role}"'))
def then_openai_role(ctx, role):
    assert ctx["openai_msg"]["role"] == role


@then(parsers.parse('the OpenAI message content should be "{content}"'))
def then_openai_content(ctx, content):
    assert ctx["openai_msg"]["content"] == content


@then("the OpenAI message should have a tool_calls array")
def then_openai_has_tool_calls(ctx):
    assert "tool_calls" in ctx["openai_msg"]
    assert len(ctx["openai_msg"]["tool_calls"]) > 0


@then(parsers.parse('the tool call function name should be "{name}"'))
def then_tool_call_fn_name(ctx, name):
    tc = ctx["openai_msg"]["tool_calls"][0]
    assert tc["function"]["name"] == name


@then("the tool call arguments should be a JSON string")
def then_tool_call_args_json(ctx):
    tc = ctx["openai_msg"]["tool_calls"][0]
    args_str = tc["function"]["arguments"]
    assert isinstance(args_str, str)
    json.loads(args_str)  # should not raise


@then(parsers.parse('the OpenAI message should have tool_call_id "{tc_id}"'))
def then_openai_tool_call_id(ctx, tc_id):
    assert ctx["openai_msg"]["tool_call_id"] == tc_id


@then(parsers.parse("the LLMResponse should have {n:d} tool call"))
@then(parsers.parse("the LLMResponse should have {n:d} tool calls"))
def then_llm_response_tool_calls(ctx, n):
    assert len(ctx["llm_response"].tool_calls) == n


@then(parsers.parse('the tool call name should be "{name}"'))
def then_response_tool_call_name(ctx, name):
    assert ctx["llm_response"].tool_calls[0].name == name


@then(parsers.parse('the stop reason should be "{reason}"'))
def then_stop_reason(ctx, reason):
    assert ctx["llm_response"].stop_reason == reason


@then(parsers.parse('the LLMResponse text should be "{text}"'))
def then_llm_response_text(ctx, text):
    assert ctx["llm_response"].text == text
