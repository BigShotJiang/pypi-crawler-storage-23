"""LitAgent — A minimal, general-purpose AI agent harness."""

__version__ = "0.0.1"
