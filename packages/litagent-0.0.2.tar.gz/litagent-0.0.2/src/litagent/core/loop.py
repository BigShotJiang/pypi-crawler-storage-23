"""The agent loop — the core of LitAgent."""

from __future__ import annotations

import json
from typing import Any, Callable

from litagent.core.client import LLMClient
from litagent.core.events import Event, EventType
from litagent.core.tool import Tool
from litagent.core.types import (
    AgentResult,
    AgentState,
    AssistantMessage,
    LLMResponse,
    Message,
    SystemMessage,
    ToolResultMessage,
    Usage,
)


class AgentLoop:
    """A minimal agent loop. Calls LLM, executes tools, repeats until done."""

    def __init__(
        self,
        client: LLMClient,
        system_prompt: str,
        tools: list[Tool] | None = None,
        max_turns: int = 10,
        on_event: Callable[[Event], None] | None = None,
    ):
        self.client = client
        self.system_prompt = system_prompt
        self.tools = tools or []
        self.max_turns = max_turns
        self.on_event = on_event
        self.state = AgentState.IDLE
        self._tool_map: dict[str, Tool] = {}
        for t in self.tools:
            if t.name in self._tool_map:
                raise ValueError(f"Duplicate tool name: {t.name}")
            self._tool_map[t.name] = t
        self._total_usage = Usage()

    async def run(self, messages: list[Message]) -> AgentResult:
        """Run the agent loop until the LLM stops or max_turns is reached."""
        self._emit(EventType.AGENT_START, {"max_turns": self.max_turns})
        self.state = AgentState.STREAMING
        self._total_usage = Usage()

        if not messages or not isinstance(messages[0], SystemMessage):
            messages = [SystemMessage(content=self.system_prompt), *messages]
        else:
            messages = list(messages)

        turns = 0
        try:
            while turns < self.max_turns:
                self._emit(EventType.TURN_START, {"turn": turns})

                self._emit(EventType.LLM_CALL, {"turn": turns})
                response = await self.client.chat(
                    messages=messages,
                    tools=self.tools if self.tools else None,
                )
                self._emit(EventType.LLM_RESPONSE, {
                    "stop_reason": response.stop_reason,
                    "has_tool_calls": len(response.tool_calls) > 0,
                    "text_length": len(response.text) if response.text else 0,
                })
                self._accumulate_usage(response.usage)

                assistant_msg = self._build_assistant_message(response)
                messages.append(assistant_msg)

                if not response.tool_calls:
                    reason = response.stop_reason
                    self._emit(EventType.TURN_END, {"turn": turns})
                    self._emit(EventType.AGENT_END, {"reason": reason, "turns": turns + 1})
                    return AgentResult(
                        text=response.text,
                        messages=messages,
                        usage=self._total_usage,
                    )

                self.state = AgentState.PROCESSING_TOOLS
                for tc in response.tool_calls:
                    self._emit(EventType.TOOL_CALL, {"name": tc.name, "arguments": tc.arguments})
                    result = await self._execute_tool(tc.name, tc.arguments)
                    self._emit(EventType.TOOL_RESULT, {"name": tc.name, "result": result[:200]})
                    messages.append(ToolResultMessage(tool_call_id=tc.id, content=result))

                self.state = AgentState.STREAMING
                self._emit(EventType.TURN_END, {"turn": turns})
                turns += 1

            self._emit(EventType.AGENT_END, {"reason": "max_turns", "turns": turns})
            return AgentResult(
                text=None,
                messages=messages,
                hit_max_turns=True,
                usage=self._total_usage,
            )
        finally:
            self.state = AgentState.IDLE

    async def _execute_tool(self, name: str, arguments: dict[str, Any]) -> str:
        tool = self._tool_map.get(name)
        if tool is None:
            error = f"Unknown tool: {name}"
            self._emit(EventType.TOOL_ERROR, {"name": name, "error": error})
            return json.dumps({"error": error})
        try:
            result = await tool.execute(**arguments)
            if isinstance(result, (dict, list)):
                return json.dumps(result)
            return str(result)
        except Exception as e:
            error = f"Tool '{name}' failed: {type(e).__name__}: {e}"
            self._emit(EventType.TOOL_ERROR, {"name": name, "error": error})
            return json.dumps({"error": error})

    @staticmethod
    def _build_assistant_message(response: LLMResponse) -> AssistantMessage:
        return AssistantMessage(
            content=response.text,
            tool_calls=list(response.tool_calls),
        )

    def _accumulate_usage(self, usage: Usage | None) -> None:
        if usage:
            self._total_usage.input_tokens += usage.input_tokens
            self._total_usage.output_tokens += usage.output_tokens

    def _emit(self, event_type: EventType, data: dict[str, Any] | None = None) -> None:
        if self.on_event:
            try:
                self.on_event(Event(type=event_type, data=data or {}))
            except Exception:
                pass
