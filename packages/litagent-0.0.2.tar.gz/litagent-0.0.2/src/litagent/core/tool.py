"""Tool protocol for LitAgent."""

from __future__ import annotations

import asyncio
import inspect
import functools
from typing import Any, Awaitable, Callable, get_type_hints

from pydantic import BaseModel


class Tool(BaseModel):
    """A tool that the agent can invoke.

    Tools are atomic actions — the agent calls them, they execute, they return a string result.
    """

    name: str
    description: str
    parameters: dict[str, Any]  # JSON Schema
    execute: Callable[..., Awaitable[str]]

    model_config = {"arbitrary_types_allowed": True}

    def to_openai_schema(self) -> dict:
        """Convert to OpenAI function-calling tool format."""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters,
            },
        }

    @classmethod
    def from_function(
        cls,
        fn: Callable,
        name: str | None = None,
        description: str | None = None,
        parameters: dict[str, Any] | None = None,
    ) -> Tool:
        """Create a Tool from a function (async or sync).

        Sync functions are auto-wrapped with asyncio.to_thread().
        If parameters is not provided, a basic schema is generated from type hints.
        For production use, pass an explicit JSON Schema or use a Pydantic model.
        """
        tool_name = name or fn.__name__
        tool_desc = description or fn.__doc__ or ""

        if parameters is None:
            parameters = _schema_from_hints(fn)

        if not asyncio.iscoroutinefunction(fn):
            original = fn

            @functools.wraps(original)
            async def async_wrapper(**kwargs: Any) -> str:
                return await asyncio.to_thread(original, **kwargs)

            execute = async_wrapper
        else:
            execute = fn

        return cls(
            name=tool_name,
            description=tool_desc,
            parameters=parameters,
            execute=execute,
        )

    @classmethod
    def from_pydantic(
        cls,
        fn: Callable[..., Awaitable[str]],
        params_model: type[BaseModel],
        name: str | None = None,
        description: str | None = None,
    ) -> Tool:
        """Create a Tool with parameters schema derived from a Pydantic model."""
        return cls(
            name=name or fn.__name__,
            description=description or fn.__doc__ or "",
            parameters=params_model.model_json_schema(),
            execute=fn,
        )


# Maps Python types to JSON Schema types
_TYPE_MAP: dict[type, str] = {
    str: "string",
    int: "integer",
    float: "number",
    bool: "boolean",
}


def _schema_from_hints(fn: Callable) -> dict[str, Any]:
    """Generate a basic JSON Schema from function type hints."""
    hints = get_type_hints(fn)
    properties: dict[str, Any] = {}
    required: list[str] = []

    sig = inspect.signature(fn)
    for param_name, param in sig.parameters.items():
        if param_name in ("self", "cls"):
            continue
        hint = hints.get(param_name)
        json_type = _TYPE_MAP.get(hint, "string")
        properties[param_name] = {"type": json_type}
        if param.default is inspect.Parameter.empty:
            required.append(param_name)

    return {
        "type": "object",
        "properties": properties,
        "required": required,
    }
