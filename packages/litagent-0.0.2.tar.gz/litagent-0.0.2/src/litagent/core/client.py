"""Injectable LLM client protocol and implementations."""

from __future__ import annotations

import json
from typing import Any, Protocol, runtime_checkable

from litagent.core.tool import Tool
from litagent.core.types import (
    AssistantMessage,
    LLMResponse,
    Message,
    SystemMessage,
    ToolCall,
    ToolResultMessage,
    Usage,
    UserMessage,
)


@runtime_checkable
class LLMClient(Protocol):
    """Protocol for LLM communication. Swap providers without changing agent code."""

    async def chat(
        self,
        messages: list[Message],
        tools: list[Tool] | None = None,
        model: str | None = None,
        **kwargs: Any,
    ) -> LLMResponse: ...


class LiteLLMClient:
    """LLM client backed by litellm. Supports 100+ providers via a single interface.

    Model strings use litellm's provider/model format:
        "openai/gpt-4o-mini", "anthropic/claude-sonnet-4-5", "ollama/llama3", etc.
    """

    def __init__(self, model: str = "openai/gpt-4o-mini", **default_kwargs: Any):
        self.model = model
        self._default_kwargs = default_kwargs

    async def chat(
        self,
        messages: list[Message],
        tools: list[Tool] | None = None,
        model: str | None = None,
        **kwargs: Any,
    ) -> LLMResponse:
        from litellm import acompletion

        openai_messages = [self._to_openai_message(m) for m in messages]

        call_kwargs: dict[str, Any] = {
            "model": model or self.model,
            "messages": openai_messages,
            **self._default_kwargs,
            **kwargs,
        }
        if tools:
            call_kwargs["tools"] = [t.to_openai_schema() for t in tools]

        response = await acompletion(**call_kwargs)
        return self._from_response(response)

    @staticmethod
    def _to_openai_message(msg: Message) -> dict[str, Any]:
        if isinstance(msg, SystemMessage):
            return {"role": "system", "content": msg.content}
        if isinstance(msg, UserMessage):
            return {"role": "user", "content": msg.content}
        if isinstance(msg, AssistantMessage):
            d: dict[str, Any] = {"role": "assistant", "content": msg.content}
            if msg.tool_calls:
                d["tool_calls"] = [
                    {
                        "id": tc.id,
                        "type": "function",
                        "function": {
                            "name": tc.name,
                            "arguments": json.dumps(tc.arguments),
                        },
                    }
                    for tc in msg.tool_calls
                ]
            return d
        if isinstance(msg, ToolResultMessage):
            return {
                "role": "tool",
                "tool_call_id": msg.tool_call_id,
                "content": msg.content,
            }
        raise TypeError(f"Unknown message type: {type(msg)}")

    @staticmethod
    def _from_response(response: Any) -> LLMResponse:
        if not response.choices:
            return LLMResponse(text=None, stop_reason="end_turn")
        choice = response.choices[0]
        message = choice.message

        tool_calls: list[ToolCall] = []
        if message.tool_calls:
            for tc in message.tool_calls:
                raw_args = tc.function.arguments
                if isinstance(raw_args, dict):
                    args = raw_args
                else:
                    try:
                        args = json.loads(raw_args)
                    except (json.JSONDecodeError, TypeError):
                        args = {"_raw": raw_args}
                tool_calls.append(
                    ToolCall(id=tc.id, name=tc.function.name, arguments=args)
                )

        finish = choice.finish_reason
        if finish == "tool_calls" or tool_calls:
            stop_reason = "tool_use"
        elif finish in ("length", "content_filter"):
            stop_reason = finish
        else:
            stop_reason = "end_turn"

        usage = None
        if response.usage:
            usage = Usage(
                input_tokens=response.usage.prompt_tokens,
                output_tokens=response.usage.completion_tokens,
            )

        return LLMResponse(
            text=message.content,
            tool_calls=tool_calls,
            stop_reason=stop_reason,
            usage=usage,
        )
