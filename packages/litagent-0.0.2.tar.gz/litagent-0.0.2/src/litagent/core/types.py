"""Core types for LitAgent."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Union


class AgentState(Enum):
    IDLE = "idle"
    STREAMING = "streaming"
    PROCESSING_TOOLS = "processing_tools"


@dataclass
class Usage:
    input_tokens: int = 0
    output_tokens: int = 0


@dataclass
class ToolCall:
    id: str
    name: str
    arguments: dict[str, Any]


@dataclass
class SystemMessage:
    content: str


@dataclass
class UserMessage:
    content: str


@dataclass
class AssistantMessage:
    content: str | None = None
    tool_calls: list[ToolCall] = field(default_factory=list)


@dataclass
class ToolResultMessage:
    tool_call_id: str
    content: str


Message = Union[SystemMessage, UserMessage, AssistantMessage, ToolResultMessage]


@dataclass
class LLMResponse:
    text: str | None
    tool_calls: list[ToolCall] = field(default_factory=list)
    stop_reason: str = "end_turn"
    usage: Usage | None = None


@dataclass
class AgentResult:
    text: str | None
    messages: list[Message]
    hit_max_turns: bool = False
    usage: Usage | None = None
