# LitAgent Development Guide

## Project Setup
- **Package manager**: `uv` (not pip, not poetry)
- **Run commands**: `uv run python ...`, `uv run pytest ...`
- **Install dev deps**: `uv pip install -e ".[dev]"`
- **Build**: `uv run python -m build`
- **Design plan**: `docs/design-plan.md` — read this for architecture context

## Architecture
- `core/` is the runtime (loop, client, tool, events, types)
- `session/` is the application layer (skills, memory, sessions) — not yet implemented
- `adapters/` are optional eval adapters — not yet implemented
- LiteLLMClient is the default LLM client, backed by litellm SDK
- Messages are typed dataclasses (SystemMessage, UserMessage, AssistantMessage, ToolResultMessage), NOT dicts
- LLMClient protocol is the abstraction boundary — agent loop never sees provider-specific formats

## Testing
- BDD with pytest-bdd. Feature files in `tests/features/`, step defs in `tests/test_*.py`
- Run: `uv run pytest tests/ -v`
- pytest-bdd steps do NOT support `async def` — use `asyncio.run()` in `when` steps

## Known Fixes — Do NOT Reintroduce These Bugs

1. **try/finally in AgentLoop.run()**: The loop body MUST be wrapped in try/finally to reset `self.state = AgentState.IDLE`. Without it, an LLM transport error leaves the agent in STREAMING state permanently.

2. **Auto-wrap sync tools**: `Tool.from_function()` MUST detect sync functions with `asyncio.iscoroutinefunction()` and wrap them with `asyncio.to_thread()`. The loop always `await`s tool execution.

3. **JSON parse fallback in _from_response**: `json.loads(tc.function.arguments)` MUST be wrapped in try/except. LLMs sometimes return malformed JSON in tool call arguments. Also handle the case where arguments is already a dict (some providers pre-parse).

4. **Event handler isolation**: `_emit()` MUST catch all exceptions from the callback. Observer crashes must never kill the agent loop.

5. **Always copy input messages**: `run()` MUST always operate on a copy of the input list to avoid mutating the caller's list.

6. **Validate tool name uniqueness**: AgentLoop init MUST raise on duplicate tool names. Silent overwrite causes hard-to-debug routing bugs.

7. **Tool result serialization**: `_execute_tool()` MUST use `json.dumps()` for dict/list results instead of `str()`, which produces Python repr format that confuses models.

8. **Guard empty choices**: `_from_response()` MUST check for empty `response.choices` before indexing.

## Release Process
- **CHANGELOG.md**: MUST be updated for every version bump. Use [Keep a Changelog](https://keepachangelog.com) format. Group changes under Added/Changed/Fixed/Removed.
- **Version bump**: Update `version` in `pyproject.toml`, update CHANGELOG.md, commit, then `git tag vX.Y.Z && git push --tags`
- **PyPI publish**: Automated via GitHub Actions on tag push (`.github/workflows/publish.yml`)
- **Versioning**: Semantic Versioning — patch for fixes, minor for features, major for breaking changes

## Workflow — MANDATORY
- **Before implementing**: Consult Codex MCP for architectural review of your approach. Do NOT start writing code until Codex has reviewed the plan.
- **After implementing**: Consult Codex MCP for bug review of the code you wrote. Do NOT consider a task done until Codex has reviewed it.
- **After Codex review**: Fix all HIGH and MEDIUM issues Codex identifies, then re-run tests to confirm.
- **Build order**: Read `docs/design-plan.md` for the phased build order. Check which phases are marked DONE and continue from the next one.

## Code Style
- No unnecessary comments or docstrings on obvious code
- Async-first: all I/O must be async, never use `requests`
- Type hints on public APIs, not on internal helpers
