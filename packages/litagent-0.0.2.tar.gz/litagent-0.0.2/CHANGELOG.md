# Changelog

All notable changes to this project will be documented in this file.

Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).
This project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.0.2] - 2026-02-10

### Changed
- **BREAKING: Replaced TensorZeroClient + OpenAIClient with LiteLLMClient** — single client backed by litellm SDK, supporting 100+ providers via `provider/model` strings (e.g. `"openai/gpt-4o-mini"`, `"anthropic/claude-sonnet-4-5"`)
- **BREAKING: Messages are now typed dataclasses** — `SystemMessage`, `UserMessage`, `AssistantMessage`, `ToolResultMessage` replace the old `Message = dict[str, Any]`. Agent loop and client protocol use these types exclusively.
- Dependency changed from `tensorzero` to `litellm>=1.0`
- Removed `openai` optional dependency (litellm handles all providers)

### Fixed
- **Tool arguments dict vs string**: `_from_response()` now handles both pre-parsed dict arguments and JSON string arguments from different providers
- **Input message list mutation**: `run()` now always copies the input list to avoid mutating the caller's data
- **Duplicate tool names silently overwritten**: AgentLoop init now raises `ValueError` on duplicate tool names
- **Tool result serialization**: Dict/list tool results now use `json.dumps()` instead of `str()` (Python repr)
- **Empty choices guard**: `_from_response()` returns a safe default when `response.choices` is empty

## [0.0.1] - 2026-02-11

### Added
- `AgentLoop` — core while-loop: call LLM, execute tools, repeat until done or max_turns
- `LLMClient` protocol — injectable async interface for swapping LLM providers
- `TensorZeroClient` — default client using `AsyncTensorZeroGateway.build_embedded()` for multi-provider support (OpenAI, Anthropic, Google)
- `OpenAIClient` — alternative client for OpenAI-compatible endpoints
- `Tool` class with `from_function()` (auto-generates JSON Schema from type hints) and `from_pydantic()`
- Event system (`EventType`, `Event`) with `on_event` callback for observability
- `AgentResult`, `AgentState`, `LLMResponse`, `ToolCall`, `Usage` types
- BDD tests with pytest-bdd (17 scenarios across 3 feature files)
- TensorZero message format translation (OpenAI format <-> TZ format)

### Fixed (during development, before release)
- **Race condition in lazy gateway init**: Added `asyncio.Lock` with double-checked locking to prevent multiple gateway instances when concurrent coroutines call `chat()` before init completes
- **Consecutive tool results not batched**: Multiple `role: "tool"` messages are now batched into a single `role: "user"` message with multiple `tool_result` content blocks (TZ requires alternating user/assistant)
- **Empty assistant content blocks**: Filtered out to prevent API errors from providers that reject empty content arrays
- **JSON parse crash in OpenAIClient**: `json.loads()` on tool call arguments now wrapped in try/except with `{"_raw": ...}` fallback
- **Lossy finish_reason mapping**: Now correctly maps "length", "content_filter", and "stop-with-tool-calls" cases
- **Agent loop exception cleanup**: Wrapped loop body in try/finally to guarantee `state = IDLE` and prevent stuck state on LLM transport errors
- **Sync tool functions crash at runtime**: `Tool.from_function()` now auto-wraps sync callables with `asyncio.to_thread()`
- **kwargs dropped by TensorZeroClient**: `**kwargs` from `chat()` now forwarded to TZ `inference()` call
- **Event handler crashes kill agent loop**: `_emit()` wrapped in try/except to isolate observer failures
- **block.text None check**: Added defensive guard for content blocks with None text attribute
