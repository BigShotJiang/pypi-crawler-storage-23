# anticipator
Anticipator is an open source security toolkit for multi-agent AI systems — detects credential exposure, prompt injection, and anomalous agent behavior across LangGraph, CrewAI, and AutoGen before they become incidents.
