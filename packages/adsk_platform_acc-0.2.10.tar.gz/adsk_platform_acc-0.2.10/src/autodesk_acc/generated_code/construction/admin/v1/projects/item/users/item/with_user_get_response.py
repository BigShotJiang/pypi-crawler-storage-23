from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

if TYPE_CHECKING:
    from .with_user_get_response_access_levels import WithUserGetResponse_accessLevels
    from .with_user_get_response_phone import WithUserGetResponse_phone
    from .with_user_get_response_products import WithUserGetResponse_products
    from .with_user_get_response_roles import WithUserGetResponse_roles

@dataclass
class WithUserGetResponse(Parsable):
    # A short bio about the user. This data syncs from the user's Autodesk profile.Max length: 255
    about_me: Optional[str] = None
    # Flags that identify a returned user's access levels in the account or project.
    access_levels: Optional[WithUserGetResponse_accessLevels] = None
    # The timestamp when the user was first given access to any product on the project.
    added_on: Optional[datetime.datetime] = None
    # The user's address line 1. This data syncs from the user's Autodesk profile.Max length: 255
    address_line1: Optional[str] = None
    # The user's address line 2. This data syncs from the user's Autodesk profile.Max length: 255
    address_line2: Optional[str] = None
    # Not relevant
    analytics_id: Optional[str] = None
    # The ID of the user's Autodesk profile.Max length: 255
    autodesk_id: Optional[str] = None
    # The User's city. This data syncs from the user's Autodesk profile.Max length: 255
    city: Optional[str] = None
    # The ID of the company that the user is representing in the project. To obtain a list of all company IDs associated with a project, call `GET projects/:projectId/companies </en/docs/acc/v1/reference/http/projects-:project_id-companies-GET/>`_.
    company_id: Optional[str] = None
    # The name of the company to which the user belongs.Max length: 255
    company_name: Optional[str] = None
    # The user's country. This data syncs from the user's Autodesk profile.Max length: 255
    country: Optional[str] = None
    # The email of the user.Max length: 255
    email: Optional[str] = None
    # The user's first name. This data syncs from the user's Autodesk profile.Max length: 255
    first_name: Optional[str] = None
    # The ACC ID of the user.
    id: Optional[UUID] = None
    # The URL of the user's avatar. This data syncs from the user's Autodesk profile.Max length: 255
    image_url: Optional[str] = None
    # The industry the user works in. This data syncs from the user's Autodesk profile.Max length: 255
    industry: Optional[str] = None
    # The user's job title. This data syncs from the user's Autodesk profile.Max length: 255
    job_title: Optional[str] = None
    # The user's last name. This data syncs from the user's Autodesk profile.Max length: 255
    last_name: Optional[str] = None
    # The full name of the user.Max length: 255
    name: Optional[str] = None
    # The user's phone number. This data syncs from the user's Autodesk profile.
    phone: Optional[WithUserGetResponse_phone] = None
    # The zip or postal code of the user. This data syncs from the user's Autodesk profile.Max length: 255
    postal_code: Optional[str] = None
    # Information about the products activated in the specified project for this user.
    products: Optional[list[WithUserGetResponse_products]] = None
    # A list of IDs of the roles that the user belongs to in the project.
    role_ids: Optional[list[str]] = None
    # A list of the role IDs and names that are associated with the user in the project.
    roles: Optional[list[WithUserGetResponse_roles]] = None
    # The state or province of the user. The accepted values here change depending on which country is provided. This data syncs from the user's Autodesk profile.Max length: 255
    state_or_province: Optional[str] = None
    # The status of the user in the project. A pending user could be waiting for their products to activate, or the user hasn't accepted an email to create an account with Autodesk.Possible values:- ``active``: The user has been added to the project.- ``pending``: The user is in the process of being added to the project.- ``disabled``: The user has been temporarily suspended from the project.- ``deleted``: The user has been removed from the project.
    status: Optional[str] = None
    # The timestamp when the project user was last updated, in ISO 8601 format.
    updated_at: Optional[datetime.datetime] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> WithUserGetResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: WithUserGetResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return WithUserGetResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .with_user_get_response_access_levels import WithUserGetResponse_accessLevels
        from .with_user_get_response_phone import WithUserGetResponse_phone
        from .with_user_get_response_products import WithUserGetResponse_products
        from .with_user_get_response_roles import WithUserGetResponse_roles

        from .with_user_get_response_access_levels import WithUserGetResponse_accessLevels
        from .with_user_get_response_phone import WithUserGetResponse_phone
        from .with_user_get_response_products import WithUserGetResponse_products
        from .with_user_get_response_roles import WithUserGetResponse_roles

        fields: dict[str, Callable[[Any], None]] = {
            "aboutMe": lambda n : setattr(self, 'about_me', n.get_str_value()),
            "accessLevels": lambda n : setattr(self, 'access_levels', n.get_object_value(WithUserGetResponse_accessLevels)),
            "addedOn": lambda n : setattr(self, 'added_on', n.get_datetime_value()),
            "addressLine1": lambda n : setattr(self, 'address_line1', n.get_str_value()),
            "addressLine2": lambda n : setattr(self, 'address_line2', n.get_str_value()),
            "analyticsId": lambda n : setattr(self, 'analytics_id', n.get_str_value()),
            "autodeskId": lambda n : setattr(self, 'autodesk_id', n.get_str_value()),
            "city": lambda n : setattr(self, 'city', n.get_str_value()),
            "companyId": lambda n : setattr(self, 'company_id', n.get_str_value()),
            "companyName": lambda n : setattr(self, 'company_name', n.get_str_value()),
            "country": lambda n : setattr(self, 'country', n.get_str_value()),
            "email": lambda n : setattr(self, 'email', n.get_str_value()),
            "firstName": lambda n : setattr(self, 'first_name', n.get_str_value()),
            "id": lambda n : setattr(self, 'id', n.get_uuid_value()),
            "imageUrl": lambda n : setattr(self, 'image_url', n.get_str_value()),
            "industry": lambda n : setattr(self, 'industry', n.get_str_value()),
            "jobTitle": lambda n : setattr(self, 'job_title', n.get_str_value()),
            "lastName": lambda n : setattr(self, 'last_name', n.get_str_value()),
            "name": lambda n : setattr(self, 'name', n.get_str_value()),
            "phone": lambda n : setattr(self, 'phone', n.get_object_value(WithUserGetResponse_phone)),
            "postalCode": lambda n : setattr(self, 'postal_code', n.get_str_value()),
            "products": lambda n : setattr(self, 'products', n.get_collection_of_object_values(WithUserGetResponse_products)),
            "roleIds": lambda n : setattr(self, 'role_ids', n.get_collection_of_primitive_values(str)),
            "roles": lambda n : setattr(self, 'roles', n.get_collection_of_object_values(WithUserGetResponse_roles)),
            "stateOrProvince": lambda n : setattr(self, 'state_or_province', n.get_str_value()),
            "status": lambda n : setattr(self, 'status', n.get_str_value()),
            "updatedAt": lambda n : setattr(self, 'updated_at', n.get_datetime_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("aboutMe", self.about_me)
        writer.write_object_value("accessLevels", self.access_levels)
        writer.write_datetime_value("addedOn", self.added_on)
        writer.write_str_value("addressLine1", self.address_line1)
        writer.write_str_value("addressLine2", self.address_line2)
        writer.write_str_value("analyticsId", self.analytics_id)
        writer.write_str_value("autodeskId", self.autodesk_id)
        writer.write_str_value("city", self.city)
        writer.write_str_value("companyId", self.company_id)
        writer.write_str_value("companyName", self.company_name)
        writer.write_str_value("country", self.country)
        writer.write_str_value("email", self.email)
        writer.write_str_value("firstName", self.first_name)
        writer.write_uuid_value("id", self.id)
        writer.write_str_value("imageUrl", self.image_url)
        writer.write_str_value("industry", self.industry)
        writer.write_str_value("jobTitle", self.job_title)
        writer.write_str_value("lastName", self.last_name)
        writer.write_str_value("name", self.name)
        writer.write_object_value("phone", self.phone)
        writer.write_str_value("postalCode", self.postal_code)
        writer.write_collection_of_object_values("products", self.products)
        writer.write_collection_of_primitive_values("roleIds", self.role_ids)
        writer.write_collection_of_object_values("roles", self.roles)
        writer.write_str_value("stateOrProvince", self.state_or_province)
        writer.write_str_value("status", self.status)
        writer.write_datetime_value("updatedAt", self.updated_at)
    

