from enum import Enum

class CompaniesGetResponse_results_status(str, Enum):
    Deleted = "deleted",
    Active = "active",

