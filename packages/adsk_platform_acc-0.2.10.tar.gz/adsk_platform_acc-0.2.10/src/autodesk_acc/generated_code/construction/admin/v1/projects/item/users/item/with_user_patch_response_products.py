from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .with_user_patch_response_products_access import WithUserPatchResponse_products_access
    from .with_user_patch_response_products_key import WithUserPatchResponse_products_key

@dataclass
class WithUserPatchResponse_products(Parsable):
    # The user's type of access to the product identified by ``key``. Possible values:- ``administrator``- ``member``- ``none``Note that when you're using a POST or PATCH endpoint to set this value, you must adhere to the following guidelines:- If you set a product's ``key`` to ``projectAdministration`` and you set ``access`` to ``none``, all other products should be set to ``member`` access for the user.- If you set a product's ``key`` to ``projectAdministration`` and you set ``access`` to ``administrator``, all other products should be set to ``administrator`` access for the user.- You cannot set a product's ``key`` to ``projectAdministration`` and set ``access`` to ``member``.
    access: Optional[WithUserPatchResponse_products_access] = None
    # A machine-readable identifier for the product (e.g., docs, build).Each product has a unique key used throughout the API for identification, filtering, and integration logic (e.g., in query parameters like ``filter[key]``).Possible values:ACC - ``autoSpecs``, ``build``, ``cost``, ``designCollaboration``, ``docs``, ``insight``, ``modelCoordination``, ``projectAdministration``, and ``takeoff``.BIM 360 - ``assets``, ``costManagement``, ``designCollaboration``, ``documentManagement``, ``field``, ``fieldManagement``, ``glue``, ``insight``, ``modelCoordination``, ``plan``, ``projectAdministration``, ``projectHome``, ``projectManagement``, and ``quantification``.Note that this endpoint returns only ACC products. Other endpoints, such as `GET projects </en/docs/acc/v1/reference/http/admin-accountsaccountidprojects-GET/>`_ and `GET projects/:projectId </en/docs/acc/v1/reference/http/admin-projects-projectId-GET/>`_, may return both ACC and BIM 360 projects. In those responses, product keys may include BIM 360 values.
    key: Optional[WithUserPatchResponse_products_key] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> WithUserPatchResponse_products:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: WithUserPatchResponse_products
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return WithUserPatchResponse_products()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .with_user_patch_response_products_access import WithUserPatchResponse_products_access
        from .with_user_patch_response_products_key import WithUserPatchResponse_products_key

        from .with_user_patch_response_products_access import WithUserPatchResponse_products_access
        from .with_user_patch_response_products_key import WithUserPatchResponse_products_key

        fields: dict[str, Callable[[Any], None]] = {
            "access": lambda n : setattr(self, 'access', n.get_enum_value(WithUserPatchResponse_products_access)),
            "key": lambda n : setattr(self, 'key', n.get_enum_value(WithUserPatchResponse_products_key)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("access", self.access)
        writer.write_enum_value("key", self.key)
    

