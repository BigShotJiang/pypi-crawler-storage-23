from enum import Enum

class WithUserGetResponse_phone_phoneType(str, Enum):
    Home = "home",
    Mobile = "mobile",
    Office = "office",

