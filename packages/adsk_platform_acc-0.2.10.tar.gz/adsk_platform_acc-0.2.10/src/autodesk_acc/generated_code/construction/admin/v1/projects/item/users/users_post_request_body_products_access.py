from enum import Enum

class UsersPostRequestBody_products_access(str, Enum):
    Key = "key",
    Administrator = "administrator",
    Member = "member",
    None_ = "none",
    ProjectAdministration = "projectAdministration",
    Access = "access",

