from enum import Enum

class ProjectsPostResponse_classification(str, Enum):
    Production = "production",
    Template = "template",
    Component = "component",
    Sample = "sample",

