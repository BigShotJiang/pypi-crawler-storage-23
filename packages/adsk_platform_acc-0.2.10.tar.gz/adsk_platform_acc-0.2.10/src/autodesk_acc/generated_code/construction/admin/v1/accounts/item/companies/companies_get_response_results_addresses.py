from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .companies_get_response_results_addresses_type import CompaniesGetResponse_results_addresses_type

@dataclass
class CompaniesGetResponse_results_addresses(Parsable):
    # The street address line 1.Max length: 255
    address_line1: Optional[str] = None
    # The street address line 2.Max length: 255
    address_line2: Optional[str] = None
    # City.Max length: 255
    city: Optional[str] = None
    # Only valid country names and ISO 3166-1 alpha-2 codes will be accepted.Max length: 255
    country: Optional[str] = None
    # Phone Number.Max length: 255
    phone: Optional[str] = None
    # The zip or postal code in which this address is located.Max length: 255
    postal_code: Optional[str] = None
    # The state or province location. Only valid state/province names and ISO 3166-1 alpha-2 codes will be accepted. The provided state or province must exist in the provided country.Max length: 255
    state_or_province: Optional[str] = None
    # The address type. Will always be: ``Main``
    type: Optional[CompaniesGetResponse_results_addresses_type] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> CompaniesGetResponse_results_addresses:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: CompaniesGetResponse_results_addresses
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return CompaniesGetResponse_results_addresses()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .companies_get_response_results_addresses_type import CompaniesGetResponse_results_addresses_type

        from .companies_get_response_results_addresses_type import CompaniesGetResponse_results_addresses_type

        fields: dict[str, Callable[[Any], None]] = {
            "addressLine1": lambda n : setattr(self, 'address_line1', n.get_str_value()),
            "addressLine2": lambda n : setattr(self, 'address_line2', n.get_str_value()),
            "city": lambda n : setattr(self, 'city', n.get_str_value()),
            "country": lambda n : setattr(self, 'country', n.get_str_value()),
            "phone": lambda n : setattr(self, 'phone', n.get_str_value()),
            "postalCode": lambda n : setattr(self, 'postal_code', n.get_str_value()),
            "stateOrProvince": lambda n : setattr(self, 'state_or_province', n.get_str_value()),
            "type": lambda n : setattr(self, 'type', n.get_enum_value(CompaniesGetResponse_results_addresses_type)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("addressLine1", self.address_line1)
        writer.write_str_value("addressLine2", self.address_line2)
        writer.write_str_value("city", self.city)
        writer.write_str_value("country", self.country)
        writer.write_str_value("phone", self.phone)
        writer.write_str_value("postalCode", self.postal_code)
        writer.write_str_value("stateOrProvince", self.state_or_province)
        writer.write_enum_value("type", self.type)
    

