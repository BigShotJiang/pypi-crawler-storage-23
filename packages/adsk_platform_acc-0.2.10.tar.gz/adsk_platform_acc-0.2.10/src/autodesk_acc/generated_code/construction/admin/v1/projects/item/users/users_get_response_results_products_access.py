from enum import Enum

class UsersGetResponse_results_products_access(str, Enum):
    Key = "key",
    Administrator = "administrator",
    Member = "member",
    None_ = "none",
    ProjectAdministration = "projectAdministration",
    Access = "access",

