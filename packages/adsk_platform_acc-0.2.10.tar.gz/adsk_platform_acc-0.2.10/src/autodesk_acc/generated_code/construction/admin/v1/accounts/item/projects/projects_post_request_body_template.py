from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

if TYPE_CHECKING:
    from .projects_post_request_body_template_options import ProjectsPostRequestBody_template_options

@dataclass
class ProjectsPostRequestBody_template(Parsable):
    """
    Information about a project in the current user's account that is configured as a template from which to copy products and settings when creating a new project:- If you *include* this object in a `POST accounts/:accountId/projects </en/docs/acc/v1/reference/http/admin-accountsaccountidprojects-POST/>`_ request, the cloned project's products and settings will match those of the template project.- If you *omit* this object from a `POST accounts/:accountId/projects </en/docs/acc/v1/reference/http/admin-accountsaccountidprojects-POST/>`_ request, all of the current ACC account's products are added to the cloned project and activated.
    """
    # Information about what to include when cloning a project template.
    options: Optional[ProjectsPostRequestBody_template_options] = None
    # The ID of a project template in the current ACC account from which to clone the new project and copy products and settings.Note that you cannot create a project template from another project template, but you can base it on a production project. Set this field to the project ``id`` of the production project. The new project template is not completely configured for use, but it will get you started.For more information about project templates, see `Project Templates <https://help.autodesk.com/view/BUILD/ENU/?guid=Account_Admin_Project_Templates>`_ in the Build help.
    project_id: Optional[UUID] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ProjectsPostRequestBody_template:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ProjectsPostRequestBody_template
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ProjectsPostRequestBody_template()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .projects_post_request_body_template_options import ProjectsPostRequestBody_template_options

        from .projects_post_request_body_template_options import ProjectsPostRequestBody_template_options

        fields: dict[str, Callable[[Any], None]] = {
            "options": lambda n : setattr(self, 'options', n.get_object_value(ProjectsPostRequestBody_template_options)),
            "projectId": lambda n : setattr(self, 'project_id', n.get_uuid_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_object_value("options", self.options)
        writer.write_uuid_value("projectId", self.project_id)
    

