from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class UsersGetResponse_pagination(Parsable):
    """
    Contains pagination details for the records returned by the endpoint.
    """
    # The maximum number of records returned per page. The last page may contain fewer records than the specified limit.
    limit: Optional[int] = None
    # The URL for the next page of records, if more results are available. Max length: 2000 characters.Max length: 2000
    next_url: Optional[str] = None
    # The index of the first record in the returned page. Used for pagination.
    offset: Optional[int] = None
    # The URL for the previous page of records, if applicable. Max length: 2000 characters.Max length: 2000
    previous_url: Optional[str] = None
    # The total number of records matching the request.
    total_results: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> UsersGetResponse_pagination:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: UsersGetResponse_pagination
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return UsersGetResponse_pagination()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "limit": lambda n : setattr(self, 'limit', n.get_int_value()),
            "nextUrl": lambda n : setattr(self, 'next_url', n.get_str_value()),
            "offset": lambda n : setattr(self, 'offset', n.get_int_value()),
            "previousUrl": lambda n : setattr(self, 'previous_url', n.get_str_value()),
            "totalResults": lambda n : setattr(self, 'total_results', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_int_value("limit", self.limit)
        writer.write_str_value("nextUrl", self.next_url)
        writer.write_int_value("offset", self.offset)
        writer.write_str_value("previousUrl", self.previous_url)
        writer.write_int_value("totalResults", self.total_results)
    

