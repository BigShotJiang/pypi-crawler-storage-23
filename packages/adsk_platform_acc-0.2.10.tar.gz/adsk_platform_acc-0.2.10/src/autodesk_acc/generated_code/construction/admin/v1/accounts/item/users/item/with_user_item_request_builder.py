from __future__ import annotations
from collections.abc import Callable
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.request_adapter import RequestAdapter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .products.products_request_builder import ProductsRequestBuilder
    from .projects.projects_request_builder import ProjectsRequestBuilder
    from .roles.roles_request_builder import RolesRequestBuilder

class WithUserItemRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /construction/admin/v1/accounts/{accountId}/users/{userId}
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new WithUserItemRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/construction/admin/v1/accounts/{accountId}/users/{userId}", path_parameters)
    
    @property
    def products(self) -> ProductsRequestBuilder:
        """
        The products property
        """
        from .products.products_request_builder import ProductsRequestBuilder

        return ProductsRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def projects(self) -> ProjectsRequestBuilder:
        """
        The projects property
        """
        from .projects.projects_request_builder import ProjectsRequestBuilder

        return ProjectsRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def roles(self) -> RolesRequestBuilder:
        """
        The roles property
        """
        from .roles.roles_request_builder import RolesRequestBuilder

        return RolesRequestBuilder(self.request_adapter, self.path_parameters)
    

