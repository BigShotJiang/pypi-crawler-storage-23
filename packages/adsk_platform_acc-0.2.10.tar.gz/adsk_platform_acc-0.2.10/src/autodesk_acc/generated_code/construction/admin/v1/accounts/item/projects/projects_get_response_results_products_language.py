from enum import Enum

class ProjectsGetResponse_results_products_language(str, Enum):
    Field = "field",
    En = "en",
    De = "de",
    Nl = "nl",
    Zh = "zh",

