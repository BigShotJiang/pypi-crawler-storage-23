from enum import Enum

class ProjectsPostResponse_products_status(str, Enum):
    Activating = "activating",
    ActivationFailed = "activationFailed",
    Active = "active",
    Deactivating = "deactivating",
    DeactivationFailed = "deactivationFailed",
    Inactive = "inactive",
    Available = "available",

