from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

@dataclass
class RolesGetResponse_results(Parsable):
    # The timestamp when the role was created.
    created_at: Optional[datetime.datetime] = None
    # The unique ID of the role.
    id: Optional[UUID] = None
    # The internal key used for translating predefined role names.Max length: 255
    key: Optional[str] = None
    # The name of the role. Predefined roles are localized based on the request language.Max length: 255
    name: Optional[str] = None
    # The list of projects where the user is associated with this role.
    project_ids: Optional[list[str]] = None
    # The role status. Possible values: active, inactive.
    status: Optional[str] = None
    # The timestamp when the role was last updated.
    updated_at: Optional[datetime.datetime] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> RolesGetResponse_results:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: RolesGetResponse_results
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return RolesGetResponse_results()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "createdAt": lambda n : setattr(self, 'created_at', n.get_datetime_value()),
            "id": lambda n : setattr(self, 'id', n.get_uuid_value()),
            "key": lambda n : setattr(self, 'key', n.get_str_value()),
            "name": lambda n : setattr(self, 'name', n.get_str_value()),
            "projectIds": lambda n : setattr(self, 'project_ids', n.get_collection_of_primitive_values(str)),
            "status": lambda n : setattr(self, 'status', n.get_str_value()),
            "updatedAt": lambda n : setattr(self, 'updated_at', n.get_datetime_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_datetime_value("createdAt", self.created_at)
        writer.write_uuid_value("id", self.id)
        writer.write_str_value("key", self.key)
        writer.write_str_value("name", self.name)
        writer.write_collection_of_primitive_values("projectIds", self.project_ids)
        writer.write_str_value("status", self.status)
        writer.write_datetime_value("updatedAt", self.updated_at)
    

