from enum import Enum

class ProjectsGetResponse_results_classification(str, Enum):
    Production = "production",
    Template = "template",
    Component = "component",
    Sample = "sample",

