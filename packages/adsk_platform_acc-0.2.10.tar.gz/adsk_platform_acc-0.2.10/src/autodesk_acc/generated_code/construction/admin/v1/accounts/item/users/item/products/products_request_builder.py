from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from warnings import warn

if TYPE_CHECKING:
    from .products_get_response import ProductsGetResponse

class ProductsRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /construction/admin/v1/accounts/{accountId}/users/{userId}/products
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new ProductsRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/construction/admin/v1/accounts/{accountId}/users/{userId}/products{?fields*,filter%5Bkey%5D*,filter%5BprojectId%5D*,limit*,offset*,sort*}", path_parameters)
    
    async def get(self,request_configuration: Optional[RequestConfiguration[ProductsRequestBuilderGetQueryParameters]] = None) -> Optional[ProductsGetResponse]:
        """
        Returns a list of ACC products the user is associated with in their assigned projects.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[ProductsGetResponse]
        """
        request_info = self.to_get_request_information(
            request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from .products_get_response import ProductsGetResponse

        return await self.request_adapter.send_async(request_info, ProductsGetResponse, None)
    
    def to_get_request_information(self,request_configuration: Optional[RequestConfiguration[ProductsRequestBuilderGetQueryParameters]] = None) -> RequestInformation:
        """
        Returns a list of ACC products the user is associated with in their assigned projects.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        request_info = RequestInformation(Method.GET, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        return request_info
    
    def with_url(self,raw_url: str) -> ProductsRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: ProductsRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return ProductsRequestBuilder(self.request_adapter, raw_url)
    
    @dataclass
    class ProductsRequestBuilderGetQueryParameters():
        """
        Returns a list of ACC products the user is associated with in their assigned projects.
        """
        def get_query_parameter(self,original_name: str) -> str:
            """
            Maps the query parameters names to their encoded names for the URI template parsing.
            param original_name: The original query parameter name in the class.
            Returns: str
            """
            if original_name is None:
                raise TypeError("original_name cannot be null.")
            if original_name == "filterkey":
                return "filter%5Bkey%5D"
            if original_name == "filterproject_id":
                return "filter%5BprojectId%5D"
            if original_name == "fields":
                return "fields"
            if original_name == "limit":
                return "limit"
            if original_name == "offset":
                return "offset"
            if original_name == "sort":
                return "sort"
            return original_name
        
        # List of fields to return in the response. Defaults to all fields.Possible values: ``projectIds``, ``name`` and ``icon``.
        fields: Optional[list[str]] = None

        # Filters the list of products by product key — a machine-readable identifier for an ACC product (such as ``docs``, ``build``, or ``cost``).You can specify one or more keys to return only those products the user is associated with.Example: ``filter[key]=docs,build``Possible values: ``accountAdministration``, ``autoSpecs``, ``build``, ``buildingConnected``, ``capitalPlanning``, ``cloudWorksharing``, ``cost``, ``designCollaboration``, ``docs``, ``financials``, ``insight``, ``modelCoordination``, ``projectAdministration``, ``takeoff``, and ``workshopxr``.
        filterkey: Optional[list[str]] = None

        # A list of project IDs. Only results where the user is associated with one or more of the specified projects are returned.
        filterproject_id: Optional[list[str]] = None

        # The maximum number of records to return in the response.Default: ``20``Minimum: ``1``Maximum: ``200`` (If a larger value is provided, only 200 records are returned)
        limit: Optional[int] = None

        # The index of the first record to return.Used for pagination in combination with the ``limit`` parameter.Example: ``limit=20`` and ``offset=40`` returns records 41–60.
        offset: Optional[int] = None

        # The list of fields to sort by.Each property can be followed by a direction modifier of either ``asc`` (ascending) or ``desc`` (descending). The default is ``asc``.Possible values:  ``name``.Default is the order in database.
        sort: Optional[list[str]] = None

    
    @dataclass
    class ProductsRequestBuilderGetRequestConfiguration(RequestConfiguration[ProductsRequestBuilderGetQueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

