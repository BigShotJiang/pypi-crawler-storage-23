from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

if TYPE_CHECKING:
    from .companies_get_response_results_addresses import CompaniesGetResponse_results_addresses
    from .companies_get_response_results_status import CompaniesGetResponse_results_status

@dataclass
class CompaniesGetResponse_results(Parsable):
    # The identifier of the account this company is associated with.
    account_id: Optional[UUID] = None
    # The company addresses.
    addresses: Optional[list[CompaniesGetResponse_results_addresses]] = None
    # The timestamp when this company was created.
    created_at: Optional[datetime.datetime] = None
    # The description of the company.Max length: 255
    description: Optional[str] = None
    # The ERP Partner Company ID.Max length: 255
    erp_id: Optional[str] = None
    # Id of the company.
    id: Optional[UUID] = None
    # The URL of the image associated to the company.Max length: 255
    image_url: Optional[str] = None
    # The name of the company. The company name should be unique under an account.Max length: 255
    name: Optional[str] = None
    # Original name of the company. Only returned when a company is deleted, since, in this case, the company ``name`` will be updated to ``removed at MMDDYYYY``.
    original_name: Optional[str] = None
    # The number of projects associated with the company.
    project_size: Optional[int] = None
    # The status of the company.Possible values: ``deleted``, ``active``
    status: Optional[CompaniesGetResponse_results_status] = None
    # The Tax ID.Max length: 255
    tax_id: Optional[str] = None
    # Trade or company type based on specialization.Max length: 255
    trade: Optional[str] = None
    # The timestamp when this company was last updated. This will only reflect changes to the company fields and not changes to any resources in the company.
    updated_at: Optional[datetime.datetime] = None
    # The number of users that are associated with the company.
    user_size: Optional[int] = None
    # The URL of the company website.Max length: 255
    website_url: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> CompaniesGetResponse_results:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: CompaniesGetResponse_results
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return CompaniesGetResponse_results()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .companies_get_response_results_addresses import CompaniesGetResponse_results_addresses
        from .companies_get_response_results_status import CompaniesGetResponse_results_status

        from .companies_get_response_results_addresses import CompaniesGetResponse_results_addresses
        from .companies_get_response_results_status import CompaniesGetResponse_results_status

        fields: dict[str, Callable[[Any], None]] = {
            "accountId": lambda n : setattr(self, 'account_id', n.get_uuid_value()),
            "addresses": lambda n : setattr(self, 'addresses', n.get_collection_of_object_values(CompaniesGetResponse_results_addresses)),
            "createdAt": lambda n : setattr(self, 'created_at', n.get_datetime_value()),
            "description": lambda n : setattr(self, 'description', n.get_str_value()),
            "erpId": lambda n : setattr(self, 'erp_id', n.get_str_value()),
            "id": lambda n : setattr(self, 'id', n.get_uuid_value()),
            "imageUrl": lambda n : setattr(self, 'image_url', n.get_str_value()),
            "name": lambda n : setattr(self, 'name', n.get_str_value()),
            "originalName": lambda n : setattr(self, 'original_name', n.get_str_value()),
            "projectSize": lambda n : setattr(self, 'project_size', n.get_int_value()),
            "status": lambda n : setattr(self, 'status', n.get_enum_value(CompaniesGetResponse_results_status)),
            "taxId": lambda n : setattr(self, 'tax_id', n.get_str_value()),
            "trade": lambda n : setattr(self, 'trade', n.get_str_value()),
            "updatedAt": lambda n : setattr(self, 'updated_at', n.get_datetime_value()),
            "userSize": lambda n : setattr(self, 'user_size', n.get_int_value()),
            "websiteUrl": lambda n : setattr(self, 'website_url', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_uuid_value("accountId", self.account_id)
        writer.write_collection_of_object_values("addresses", self.addresses)
        writer.write_datetime_value("createdAt", self.created_at)
        writer.write_str_value("description", self.description)
        writer.write_str_value("erpId", self.erp_id)
        writer.write_uuid_value("id", self.id)
        writer.write_str_value("imageUrl", self.image_url)
        writer.write_str_value("name", self.name)
        writer.write_str_value("originalName", self.original_name)
        writer.write_int_value("projectSize", self.project_size)
        writer.write_enum_value("status", self.status)
        writer.write_str_value("taxId", self.tax_id)
        writer.write_str_value("trade", self.trade)
        writer.write_datetime_value("updatedAt", self.updated_at)
        writer.write_int_value("userSize", self.user_size)
        writer.write_str_value("websiteUrl", self.website_url)
    

