from enum import Enum

class WithUserPatchResponse_phone_phoneType(str, Enum):
    Home = "home",
    Mobile = "mobile",
    Office = "office",

