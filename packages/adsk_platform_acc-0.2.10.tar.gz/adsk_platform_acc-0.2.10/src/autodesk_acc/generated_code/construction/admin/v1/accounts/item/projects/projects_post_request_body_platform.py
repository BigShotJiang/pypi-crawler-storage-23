from enum import Enum

class ProjectsPostRequestBody_platform(str, Enum):
    Acc = "acc",
    Bim360 = "bim360",

