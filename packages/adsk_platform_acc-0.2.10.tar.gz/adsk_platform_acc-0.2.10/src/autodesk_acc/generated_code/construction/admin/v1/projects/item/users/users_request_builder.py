from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID
from warnings import warn

if TYPE_CHECKING:
    from .get_filter_text_match_query_parameter_type import GetFilterTextMatchQueryParameterType
    from .item.with_user_item_request_builder import WithUserItemRequestBuilder
    from .users_get_response import UsersGetResponse
    from .users_post_request_body import UsersPostRequestBody
    from .users_post_response import UsersPostResponse

class UsersRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /construction/admin/v1/projects/{projectId}/users
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new UsersRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/construction/admin/v1/projects/{projectId}/users{?fields*,filterTextMatch*,filter%5BaccessLevels%5D*,filter%5BautodeskId%5D*,filter%5BcompanyId%5D*,filter%5BcompanyName%5D*,filter%5Bemail%5D*,filter%5Bid%5D*,filter%5Bname%5D*,filter%5Bproducts%5D*,filter%5BroleId%5D*,filter%5BroleIds%5D*,filter%5Bstatus%5D*,limit*,offset*,orFilters*,sort*}", path_parameters)
    
    def by_user_id(self,user_id: str) -> WithUserItemRequestBuilder:
        """
        Gets an item from the Autodesk.ACC.construction.admin.v1.projects.item.users.item collection
        param user_id: The ID of the user. To find the ID call `GET users </en/docs/acc/v1/reference/http/admin-projectsprojectId-users-GET/>`_. You can use either the ACC ID (``id``) or the Autodesk ID (``autodeskId``).
        Returns: WithUserItemRequestBuilder
        """
        if user_id is None:
            raise TypeError("user_id cannot be null.")
        from .item.with_user_item_request_builder import WithUserItemRequestBuilder

        url_tpl_params = get_path_parameters(self.path_parameters)
        url_tpl_params["userId"] = user_id
        return WithUserItemRequestBuilder(self.request_adapter, url_tpl_params)
    
    async def get(self,request_configuration: Optional[RequestConfiguration[UsersRequestBuilderGetQueryParameters]] = None) -> Optional[UsersGetResponse]:
        """
        Retrieves information about a filtered subset of users in the specified project.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[UsersGetResponse]
        """
        request_info = self.to_get_request_information(
            request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from .users_get_response import UsersGetResponse

        return await self.request_adapter.send_async(request_info, UsersGetResponse, None)
    
    async def post(self,body: UsersPostRequestBody, request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> Optional[UsersPostResponse]:
        """
        Assigns a user to the specified project.
        param body: The request body
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[UsersPostResponse]
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = self.to_post_request_information(
            body, request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from .users_post_response import UsersPostResponse

        return await self.request_adapter.send_async(request_info, UsersPostResponse, None)
    
    def to_get_request_information(self,request_configuration: Optional[RequestConfiguration[UsersRequestBuilderGetQueryParameters]] = None) -> RequestInformation:
        """
        Retrieves information about a filtered subset of users in the specified project.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        request_info = RequestInformation(Method.GET, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        return request_info
    
    def to_post_request_information(self,body: UsersPostRequestBody, request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> RequestInformation:
        """
        Assigns a user to the specified project.
        param body: The request body
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = RequestInformation(Method.POST, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        request_info.set_content_from_parsable(self.request_adapter, "application/json", body)
        return request_info
    
    def with_url(self,raw_url: str) -> UsersRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: UsersRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return UsersRequestBuilder(self.request_adapter, raw_url)
    
    @dataclass
    class UsersRequestBuilderGetQueryParameters():
        """
        Retrieves information about a filtered subset of users in the specified project.
        """
        def get_query_parameter(self,original_name: str) -> str:
            """
            Maps the query parameters names to their encoded names for the URI template parsing.
            param original_name: The original query parameter name in the class.
            Returns: str
            """
            if original_name is None:
                raise TypeError("original_name cannot be null.")
            if original_name == "filteraccess_levels":
                return "filter%5BaccessLevels%5D"
            if original_name == "filterautodesk_id":
                return "filter%5BautodeskId%5D"
            if original_name == "filtercompany_id":
                return "filter%5BcompanyId%5D"
            if original_name == "filtercompany_name":
                return "filter%5BcompanyName%5D"
            if original_name == "filteremail":
                return "filter%5Bemail%5D"
            if original_name == "filterid":
                return "filter%5Bid%5D"
            if original_name == "filtername":
                return "filter%5Bname%5D"
            if original_name == "filterproducts":
                return "filter%5Bproducts%5D"
            if original_name == "filterrole_id":
                return "filter%5BroleId%5D"
            if original_name == "filterrole_ids":
                return "filter%5BroleIds%5D"
            if original_name == "filterstatus":
                return "filter%5Bstatus%5D"
            if original_name == "filter_text_match":
                return "filterTextMatch"
            if original_name == "or_filters":
                return "orFilters"
            if original_name == "fields":
                return "fields"
            if original_name == "limit":
                return "limit"
            if original_name == "offset":
                return "offset"
            if original_name == "sort":
                return "sort"
            return original_name
        
        # A list of the project fields to include in the response. Default value: all fields.Possible values: ``name``, ``email``, ``firstName``, ``lastName``, ``autodeskId``, ``analyticsId``, ``addressLine1``, ``addressLine2``, ``city``, ``stateOrProvince``, ``postalCode``, ``country``, ``imageUrl``, ``phone``, ``jobTitle``, ``industry``, ``aboutMe``, ``companyId``, ``accessLevels``, ``roleIds``, ``roles``, ``status``, ``addedOn`` and ``products``.
        fields: Optional[list[str]] = None

        # Specifies how text-based filters should match values in supported fields.This parameter can be used in any endpoint that supports text-based filtering (e.g., ``filter[name]``, ``filter[jobNumber]``, ``filter[companyName]``, etc.).Possible values:``contains`` (default) – Matches if the field contains the specified text anywhere``startsWith`` – Matches if the field starts with the specified text``endsWith`` – Matches if the field ends with the specified text``equals`` – Matches only if the field exactly matches the specified textMatching is case-insensitive.Wildcards and regular expressions are not supported.
        filter_text_match: Optional[GetFilterTextMatchQueryParameterType] = None

        # A list of user access levels that the returned users must have.Possible values: ``accouantAdmin``, ``projectAdmin``, ``executive``.Max length: 255
        filteraccess_levels: Optional[list[str]] = None

        # A list of the Autodesk IDs of users to retrieve.
        filterautodesk_id: Optional[list[str]] = None

        # The ID of a company that the returned users must represent.Max length: 255
        filtercompany_id: Optional[str] = None

        # The name of a company that returned users must be associated with. Can be a partial match based on the value of ``filterTextMatch`` that you provide.For example: ``filter[companyName]=Sample filterTextMatch=startsWith``Max length: 255
        filtercompany_name: Optional[str] = None

        # A user email address or address pattern that the returned users must have. This can be a partial match based on the value of ``filterTextMatch`` that you provide.For example:``filter[email]=sample filterTextMatch=startsWith``Max length: 255
        filteremail: Optional[str] = None

        # A list of the ACC IDs of users to retrieve.
        filterid: Optional[list[str]] = None

        # A user name or name pattern that the returned users must have. Can be a partial match based on the value of ``filterTextMatch`` that you provide.For example:``filter[name]=Sample filterTextMatch=startsWith``Max length: 255
        filtername: Optional[str] = None

        # A comma-separated list of the products that the returned users must have access to in the specified project. Only users that have access to one or more of the specified products are returned.Note that every product in the same account as the project is activated for the project, and a separate subset of these products is active for each user. This endpoint can retrieve users from ACC or BIM 360 projects.Some products are exclusive to ACC or to BIM 360, others are available on both platforms. Specify only the products on the appropriate platform for the users you want to retrieve.Possible ACC values: ``accountAdministration``, ``autoSpecs``, ``build``, ``buildingConnected``, ``capitalPlanning``, ``cloudWorksharing``, ``cost``, ``designCollaboration``, ``docs``, ``financials``, ``insight``, ``modelCoordination``, ``projectAdministration``, ``takeoff``, and ``workshopxr``.Possible BIM 360 values: ``accountAdministration``, ``assets``, ``cloudWorksharing``, ``costManagement``, ``designCollaboration``, ``documentManagement``, ``field``, ``fieldManagement``, ``glue``, ``insight``, ``modelCoordination``, ``plan``, ``projectAdministration``, ``projectHome``, ``projectManagement``, and ``quantification``.
        filterproducts: Optional[list[str]] = None

        # The ID of a user role that the returned users must have.To obtain a role ID for this filter, you can inspect the ``roleId`` field in previous responses to this endpoint or to the `GET projects/:projectId/users/:userId </en/docs/acc/v1/reference/http/admin-projects-projectId-users-userId-GET/>`_ endpoint.Max length: 255
        filterrole_id: Optional[UUID] = None

        # A list of the IDs of user roles that the returned users must have.To obtain a role ID for this filter, you can inspect the ``roleId`` field in previous responses to this endpoint or to the `GET projects/:projectId/users/:userId </en/docs/acc/v1/reference/http/admin-projects-projectId-users-userId-GET/>`_ endpoint.
        filterrole_ids: Optional[list[str]] = None

        # A list of statuses that the returned project users must be in. The default values are ``active`` and ``pending``.Possible values: ``active``, ``pending``, and ``deleted``.
        filterstatus: Optional[list[str]] = None

        # The maximum number of records to return in the response.Default: ``20``Minimum: ``1``Maximum: ``200`` (If a larger value is provided, only 200 records are returned)
        limit: Optional[int] = None

        # The index of the first record to return.Used for pagination in combination with the ``limit`` parameter.Example: ``limit=20`` and ``offset=40`` returns records 41–60.
        offset: Optional[int] = None

        # A list of user fields to combine with the SQL *OR* operator for filtering the returned project users. The *OR* is automatically incorporated between the fields; any one of them can produce a valid match.Possible values: ``id``, ``name``, ``email``, ``autodeskId``, ``status`` and ``accessLevels``.
        or_filters: Optional[list[str]] = None

        # A list of fields to sort the returned users by. Multiple sort fields are applied in sequence order - each sort field produces groupings of projects with the same values of that field; the next sort field applies within the groupings produced by the previous sort field.Each property can be followed by a direction modifier of either ``asc`` (ascending) or ``desc`` (descending). The default is ``asc``.Possible values: ``name``, ``email``, ``firstName``, ``lastName``, ``addressLine1``, ``addressLine2``, ``city``, ``companyName``, ``stateOrProvince``, ``status``, ``phone``, ``postalCode``, ``country`` and ``addedOn``. Default value: ``name``.
        sort: Optional[list[str]] = None

    
    @dataclass
    class UsersRequestBuilderGetRequestConfiguration(RequestConfiguration[UsersRequestBuilderGetQueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    
    @dataclass
    class UsersRequestBuilderPostRequestConfiguration(RequestConfiguration[QueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

