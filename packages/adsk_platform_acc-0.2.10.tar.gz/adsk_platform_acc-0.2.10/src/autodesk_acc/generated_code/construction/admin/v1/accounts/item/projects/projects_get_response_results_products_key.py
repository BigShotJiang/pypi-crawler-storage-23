from enum import Enum

class ProjectsGetResponse_results_products_key(str, Enum):
    FilterKey = "filter[key]",
    AutoSpecs = "autoSpecs",
    Build = "build",
    Cost = "cost",
    DesignCollaboration = "designCollaboration",
    Docs = "docs",
    Insight = "insight",
    ModelCoordination = "modelCoordination",
    ProjectAdministration = "projectAdministration",
    Takeoff = "takeoff",
    Assets = "assets",
    CostManagement = "costManagement",
    DocumentManagement = "documentManagement",
    Field = "field",
    FieldManagement = "fieldManagement",
    Glue = "glue",
    Plan = "plan",
    ProjectHome = "projectHome",
    ProjectManagement = "projectManagement",
    Quantification = "quantification",

