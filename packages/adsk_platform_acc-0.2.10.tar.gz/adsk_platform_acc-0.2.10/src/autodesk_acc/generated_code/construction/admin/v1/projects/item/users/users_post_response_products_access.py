from enum import Enum

class UsersPostResponse_products_access(str, Enum):
    Key = "key",
    Administrator = "administrator",
    Member = "member",
    None_ = "none",
    ProjectAdministration = "projectAdministration",
    Access = "access",

