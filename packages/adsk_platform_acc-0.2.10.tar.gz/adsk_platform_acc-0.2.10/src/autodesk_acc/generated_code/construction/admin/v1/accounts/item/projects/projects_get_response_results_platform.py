from enum import Enum

class ProjectsGetResponse_results_platform(str, Enum):
    Acc = "acc",
    Bim360 = "bim360",

