from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .with_user_patch_response_phone_phone_type import WithUserPatchResponse_phone_phoneType

@dataclass
class WithUserPatchResponse_phone(Parsable):
    """
    The user's phone number. This data syncs from the user's Autodesk profile.
    """
    # User's phone extension.
    extension: Optional[str] = None
    # User's phone number
    number: Optional[str] = None
    # The user's phone type.Possible values: ``home``, ``mobile``, or ``office``. Default value: ``mobile``.
    phone_type: Optional[WithUserPatchResponse_phone_phoneType] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> WithUserPatchResponse_phone:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: WithUserPatchResponse_phone
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return WithUserPatchResponse_phone()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .with_user_patch_response_phone_phone_type import WithUserPatchResponse_phone_phoneType

        from .with_user_patch_response_phone_phone_type import WithUserPatchResponse_phone_phoneType

        fields: dict[str, Callable[[Any], None]] = {
            "extension": lambda n : setattr(self, 'extension', n.get_str_value()),
            "number": lambda n : setattr(self, 'number', n.get_str_value()),
            "phoneType": lambda n : setattr(self, 'phone_type', n.get_enum_value(WithUserPatchResponse_phone_phoneType)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("extension", self.extension)
        writer.write_str_value("number", self.number)
        writer.write_enum_value("phoneType", self.phone_type)
    

