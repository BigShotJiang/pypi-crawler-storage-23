from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from warnings import warn

if TYPE_CHECKING:
    from .get_filter_text_match_query_parameter_type import GetFilterTextMatchQueryParameterType
    from .roles_get_response import RolesGetResponse

class RolesRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /construction/admin/v1/accounts/{accountId}/users/{userId}/roles
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new RolesRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/construction/admin/v1/accounts/{accountId}/users/{userId}/roles{?fields*,filterTextMatch*,filter%5Bname%5D*,filter%5BprojectId%5D*,filter%5Bstatus%5D*,limit*,offset*,sort*}", path_parameters)
    
    async def get(self,request_configuration: Optional[RequestConfiguration[RolesRequestBuilderGetQueryParameters]] = None) -> Optional[RolesGetResponse]:
        """
        Returns the roles assigned to a specific user across the projects they belong to.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[RolesGetResponse]
        """
        request_info = self.to_get_request_information(
            request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from .roles_get_response import RolesGetResponse

        return await self.request_adapter.send_async(request_info, RolesGetResponse, None)
    
    def to_get_request_information(self,request_configuration: Optional[RequestConfiguration[RolesRequestBuilderGetQueryParameters]] = None) -> RequestInformation:
        """
        Returns the roles assigned to a specific user across the projects they belong to.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        request_info = RequestInformation(Method.GET, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        return request_info
    
    def with_url(self,raw_url: str) -> RolesRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: RolesRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return RolesRequestBuilder(self.request_adapter, raw_url)
    
    @dataclass
    class RolesRequestBuilderGetQueryParameters():
        """
        Returns the roles assigned to a specific user across the projects they belong to.
        """
        def get_query_parameter(self,original_name: str) -> str:
            """
            Maps the query parameters names to their encoded names for the URI template parsing.
            param original_name: The original query parameter name in the class.
            Returns: str
            """
            if original_name is None:
                raise TypeError("original_name cannot be null.")
            if original_name == "filtername":
                return "filter%5Bname%5D"
            if original_name == "filterproject_id":
                return "filter%5BprojectId%5D"
            if original_name == "filterstatus":
                return "filter%5Bstatus%5D"
            if original_name == "filter_text_match":
                return "filterTextMatch"
            if original_name == "fields":
                return "fields"
            if original_name == "limit":
                return "limit"
            if original_name == "offset":
                return "offset"
            if original_name == "sort":
                return "sort"
            return original_name
        
        # A comma-separated list of response fields to include.Defaults to all fields if not specified.Use this parameter to reduce the response size by retrieving only the fields you need.Possible values:``projectIds`` – Projects where the user holds this role``name`` – Role name``status`` – Role status (active or inactive)``key`` – Internal key used to translate the role name``createdAt`` – Timestamp when the role was created``updatedAt`` – Timestamp when the role was last updated
        fields: Optional[list[str]] = None

        # Specifies how text-based filters should match values in supported fields.This parameter can be used in any endpoint that supports text-based filtering (e.g., ``filter[name]``, ``filter[jobNumber]``, ``filter[companyName]``, etc.).Possible values:``contains`` (default) – Matches if the field contains the specified text anywhere``startsWith`` – Matches if the field starts with the specified text``endsWith`` – Matches if the field ends with the specified text``equals`` – Matches only if the field exactly matches the specified textMatching is case-insensitive.Wildcards and regular expressions are not supported.
        filter_text_match: Optional[GetFilterTextMatchQueryParameterType] = None

        # Filters roles by name.By default, this performs a partial match (case-insensitive).You can control how the match behaves by using the ``filterTextMatch`` parameter. For example, to match only names that start with (`startsWith`), end with (`endsWith`), or exactly equal (`equals`) the provided value.
        filtername: Optional[str] = None

        # A list of project IDs. Only results where the user is associated with one or more of the specified projects are returned.
        filterproject_id: Optional[list[str]] = None

        # Filters roles by their status. Accepts one or more of the following values:``active`` – The role is currently in use.``inactive`` – The role has been removed or is no longer in use.
        filterstatus: Optional[list[str]] = None

        # The maximum number of records to return in the response.Default: ``20``Minimum: ``1``Maximum: ``200`` (If a larger value is provided, only 200 records are returned)
        limit: Optional[int] = None

        # The index of the first record to return.Used for pagination in combination with the ``limit`` parameter.Example: ``limit=20`` and ``offset=40`` returns records 41–60.
        offset: Optional[int] = None

        # Sorts the results by one or more fields.Each field can be followed by a direction modifier:``asc`` – Ascending order (default)``desc`` – Descending orderPossible values: ``name``, ``createdAt``, ``updatedAt``.Default sort: ``name asc``Example: ``sort=name,updatedAt desc``
        sort: Optional[list[str]] = None

    
    @dataclass
    class RolesRequestBuilderGetRequestConfiguration(RequestConfiguration[RolesRequestBuilderGetQueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

