from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .with_user_patch_request_body_products import WithUserPatchRequestBody_products

@dataclass
class WithUserPatchRequestBody(Parsable):
    # The ID of the company that the user is representing in the project. To obtain a list of all company IDs associated with a project, call `GET projects/:projectId/companies </en/docs/acc/v1/reference/http/projects-:project_id-companies-GET/>`_.
    company_id: Optional[str] = None
    # The name of the company to which the user belongs.Max length: 255
    company_name: Optional[str] = None
    # Information about the products activated in the specified project for this user.
    products: Optional[list[WithUserPatchRequestBody_products]] = None
    # A list of IDs of the roles that the user belongs to in the project.
    role_ids: Optional[list[str]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> WithUserPatchRequestBody:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: WithUserPatchRequestBody
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return WithUserPatchRequestBody()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .with_user_patch_request_body_products import WithUserPatchRequestBody_products

        from .with_user_patch_request_body_products import WithUserPatchRequestBody_products

        fields: dict[str, Callable[[Any], None]] = {
            "companyId": lambda n : setattr(self, 'company_id', n.get_str_value()),
            "companyName": lambda n : setattr(self, 'company_name', n.get_str_value()),
            "products": lambda n : setattr(self, 'products', n.get_collection_of_object_values(WithUserPatchRequestBody_products)),
            "roleIds": lambda n : setattr(self, 'role_ids', n.get_collection_of_primitive_values(str)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("companyId", self.company_id)
        writer.write_str_value("companyName", self.company_name)
        writer.write_collection_of_object_values("products", self.products)
        writer.write_collection_of_primitive_values("roleIds", self.role_ids)
    

