from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .users_post_request_body_products import UsersPostRequestBody_products

@dataclass
class UsersPostRequestBody(Parsable):
    # The ID of the company that the user is representing in the project. To obtain a list of all company IDs associated with a project, call `GET projects/:projectId/companies </en/docs/acc/v1/reference/http/projects-:project_id-companies-GET/>`_.
    company_id: Optional[str] = None
    # The email address of the user.Max length: 255
    email: Optional[str] = None
    # Information about the products activated in the specified project for this user.
    products: Optional[list[UsersPostRequestBody_products]] = None
    # A list of IDs of the roles that the user belongs to in the project.
    role_ids: Optional[list[str]] = None
    # Suppresses project invite emails to the invited users. Defaults to false.
    suppress_administrative_emails: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> UsersPostRequestBody:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: UsersPostRequestBody
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return UsersPostRequestBody()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .users_post_request_body_products import UsersPostRequestBody_products

        from .users_post_request_body_products import UsersPostRequestBody_products

        fields: dict[str, Callable[[Any], None]] = {
            "companyId": lambda n : setattr(self, 'company_id', n.get_str_value()),
            "email": lambda n : setattr(self, 'email', n.get_str_value()),
            "products": lambda n : setattr(self, 'products', n.get_collection_of_object_values(UsersPostRequestBody_products)),
            "roleIds": lambda n : setattr(self, 'role_ids', n.get_collection_of_primitive_values(str)),
            "suppressAdministrativeEmails": lambda n : setattr(self, 'suppress_administrative_emails', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("companyId", self.company_id)
        writer.write_str_value("email", self.email)
        writer.write_collection_of_object_values("products", self.products)
        writer.write_collection_of_primitive_values("roleIds", self.role_ids)
        writer.write_bool_value("suppressAdministrativeEmails", self.suppress_administrative_emails)
    

