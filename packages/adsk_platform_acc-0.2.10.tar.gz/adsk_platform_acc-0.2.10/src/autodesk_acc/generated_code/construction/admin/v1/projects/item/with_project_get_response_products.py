from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .with_project_get_response_products_key import WithProjectGetResponse_products_key
    from .with_project_get_response_products_language import WithProjectGetResponse_products_language
    from .with_project_get_response_products_status import WithProjectGetResponse_products_status

@dataclass
class WithProjectGetResponse_products(Parsable):
    # The URL of the icon associated with the product.
    icon: Optional[str] = None
    # A machine-readable identifier for the product (e.g., docs, build).Each product has a unique key used throughout the API for identification, filtering, and integration logic (e.g., in query parameters like ``filter[key]``).Possible values:ACC - ``autoSpecs``, ``build``, ``cost``, ``designCollaboration``, ``docs``, ``insight``, ``modelCoordination``, ``projectAdministration``, and ``takeoff``.BIM 360 - ``assets``, ``costManagement``, ``designCollaboration``, ``documentManagement``, ``field``, ``fieldManagement``, ``glue``, ``insight``, ``modelCoordination``, ``plan``, ``projectAdministration``, ``projectHome``, ``projectManagement``, and ``quantification``.Note that this endpoint returns only ACC products. Other endpoints, such as `GET projects </en/docs/acc/v1/reference/http/admin-accountsaccountidprojects-GET/>`_ and `GET projects/:projectId </en/docs/acc/v1/reference/http/admin-projects-projectId-GET/>`_, may return both ACC and BIM 360 projects. In those responses, product keys may include BIM 360 values.
    key: Optional[WithProjectGetResponse_products_key] = None
    # The language for the project. Only valid for the ``field`` product.Possible values: ``en``, ``de``, ``nl``, ``zh``, ``de-CH``
    language: Optional[WithProjectGetResponse_products_language] = None
    # The name of the product.
    name: Optional[str] = None
    # The current status of the product. Possible values:- ``activating``: Product activation is in progress.- ``activationFailed``: Product activation has failed.- ``active``: Product activation is completed.- ``deactivating``: Product deactivation is in progress. (Applicable to BIM 360 only)- ``deactivationFailed``: Product deactivation has failed. (Applicable to BIM 360 only)- ``inactive``: Product deactivation is completed. (Applicable to BIM 360 only)- ``available``: Product is available for activation. (Applicable to BIM 360 only)
    status: Optional[WithProjectGetResponse_products_status] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> WithProjectGetResponse_products:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: WithProjectGetResponse_products
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return WithProjectGetResponse_products()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .with_project_get_response_products_key import WithProjectGetResponse_products_key
        from .with_project_get_response_products_language import WithProjectGetResponse_products_language
        from .with_project_get_response_products_status import WithProjectGetResponse_products_status

        from .with_project_get_response_products_key import WithProjectGetResponse_products_key
        from .with_project_get_response_products_language import WithProjectGetResponse_products_language
        from .with_project_get_response_products_status import WithProjectGetResponse_products_status

        fields: dict[str, Callable[[Any], None]] = {
            "icon": lambda n : setattr(self, 'icon', n.get_str_value()),
            "key": lambda n : setattr(self, 'key', n.get_enum_value(WithProjectGetResponse_products_key)),
            "language": lambda n : setattr(self, 'language', n.get_enum_value(WithProjectGetResponse_products_language)),
            "name": lambda n : setattr(self, 'name', n.get_str_value()),
            "status": lambda n : setattr(self, 'status', n.get_enum_value(WithProjectGetResponse_products_status)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("icon", self.icon)
        writer.write_enum_value("key", self.key)
        writer.write_enum_value("language", self.language)
        writer.write_str_value("name", self.name)
        writer.write_enum_value("status", self.status)
    

