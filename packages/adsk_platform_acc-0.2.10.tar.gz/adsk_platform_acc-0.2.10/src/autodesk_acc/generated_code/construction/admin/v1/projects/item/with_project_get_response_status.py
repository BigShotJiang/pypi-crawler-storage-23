from enum import Enum

class WithProjectGetResponse_status(str, Enum):
    Active = "active",
    Pending = "pending",
    Archived = "archived",
    Suspended = "suspended",

