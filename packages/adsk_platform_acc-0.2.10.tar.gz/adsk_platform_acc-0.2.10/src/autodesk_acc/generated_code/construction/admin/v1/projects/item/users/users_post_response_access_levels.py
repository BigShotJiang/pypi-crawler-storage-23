from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class UsersPostResponse_accessLevels(Parsable):
    """
    Flags that identify a returned user's access levels in the account or project.
    """
    # Indicates whether the user is an account administrator for the account. Possible values:- ``true``: The user is an account administrator.- ``false``: The user is not an account administrator.
    account_admin: Optional[bool] = None
    # Indicates whether the user is an executive in the account. Possible values:- ``true``: The user is an executive.- ``false``: The user is not an executive.
    executive: Optional[bool] = None
    # Indicates whether the user is a project administrator for the project. Possible values:- ``true``: The user is a project administrator.- ``false``: The user is not a project administrator.
    project_admin: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> UsersPostResponse_accessLevels:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: UsersPostResponse_accessLevels
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return UsersPostResponse_accessLevels()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "accountAdmin": lambda n : setattr(self, 'account_admin', n.get_bool_value()),
            "executive": lambda n : setattr(self, 'executive', n.get_bool_value()),
            "projectAdmin": lambda n : setattr(self, 'project_admin', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("accountAdmin", self.account_admin)
        writer.write_bool_value("executive", self.executive)
        writer.write_bool_value("projectAdmin", self.project_admin)
    

