from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from warnings import warn

if TYPE_CHECKING:
    from .get_filter_text_match_query_parameter_type import GetFilterTextMatchQueryParameterType
    from .projects_get_response import ProjectsGetResponse

class ProjectsRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /construction/admin/v1/accounts/{accountId}/users/{userId}/projects
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new ProjectsRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/construction/admin/v1/accounts/{accountId}/users/{userId}/projects{?fields*,filterTextMatch*,filter%5BaccessLevels%5D*,filter%5Bclassification%5D*,filter%5Bid%5D*,filter%5BjobNumber%5D*,filter%5Bname%5D*,filter%5Bplatform%5D*,filter%5Bstatus%5D*,filter%5Btype%5D*,filter%5BupdatedAt%5D*,limit*,offset*,sort*}", path_parameters)
    
    async def get(self,request_configuration: Optional[RequestConfiguration[ProjectsRequestBuilderGetQueryParameters]] = None) -> Optional[ProjectsGetResponse]:
        """
        Retrieves all projects for a specified user. This endpoint is compatible with both BIM 360 and Autodesk Construction Cloud (ACC) projects.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[ProjectsGetResponse]
        """
        request_info = self.to_get_request_information(
            request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from .projects_get_response import ProjectsGetResponse

        return await self.request_adapter.send_async(request_info, ProjectsGetResponse, None)
    
    def to_get_request_information(self,request_configuration: Optional[RequestConfiguration[ProjectsRequestBuilderGetQueryParameters]] = None) -> RequestInformation:
        """
        Retrieves all projects for a specified user. This endpoint is compatible with both BIM 360 and Autodesk Construction Cloud (ACC) projects.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        request_info = RequestInformation(Method.GET, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        return request_info
    
    def with_url(self,raw_url: str) -> ProjectsRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: ProjectsRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return ProjectsRequestBuilder(self.request_adapter, raw_url)
    
    @dataclass
    class ProjectsRequestBuilderGetQueryParameters():
        """
        Retrieves all projects for a specified user. This endpoint is compatible with both BIM 360 and Autodesk Construction Cloud (ACC) projects.
        """
        def get_query_parameter(self,original_name: str) -> str:
            """
            Maps the query parameters names to their encoded names for the URI template parsing.
            param original_name: The original query parameter name in the class.
            Returns: str
            """
            if original_name is None:
                raise TypeError("original_name cannot be null.")
            if original_name == "filteraccess_levels":
                return "filter%5BaccessLevels%5D"
            if original_name == "filterclassification":
                return "filter%5Bclassification%5D"
            if original_name == "filterid":
                return "filter%5Bid%5D"
            if original_name == "filterjob_number":
                return "filter%5BjobNumber%5D"
            if original_name == "filtername":
                return "filter%5Bname%5D"
            if original_name == "filterplatform":
                return "filter%5Bplatform%5D"
            if original_name == "filterstatus":
                return "filter%5Bstatus%5D"
            if original_name == "filtertype":
                return "filter%5Btype%5D"
            if original_name == "filterupdated_at":
                return "filter%5BupdatedAt%5D"
            if original_name == "filter_text_match":
                return "filterTextMatch"
            if original_name == "fields":
                return "fields"
            if original_name == "limit":
                return "limit"
            if original_name == "offset":
                return "offset"
            if original_name == "sort":
                return "sort"
            return original_name
        
        # A comma-separated list of user project fields to include in the response. If not specified, all available fields are included by default.Possible values: ``accessLevels``, ``accountId``, ``addressLine1``, ``addressLine2``, ``city``, ``constructionType``, ``country``, ``createdAt``, ``classification``, ``deliveryMethod``, ``endDate``, ``imageUrl``, ``jobNumber``, ``latitude``, ``longitude``, ``name``, ``platform``, ``postalCode``, ``projectValue``, ``sheetCount``, ``startDate``, ``stateOrProvince``, ``status``, ``thumbnailImageUrl``, ``timezone``, ``type``, ``updatedAt``, ``contractType`` and ``currentPhase``.
        fields: Optional[list[str]] = None

        # Specifies how text-based filters should match values in supported fields.This parameter can be used in any endpoint that supports text-based filtering (e.g., ``filter[name]``, ``filter[jobNumber]``, ``filter[companyName]``, etc.).Possible values:``contains`` (default) – Matches if the field contains the specified text anywhere``startsWith`` – Matches if the field starts with the specified text``endsWith`` – Matches if the field ends with the specified text``equals`` – Matches only if the field exactly matches the specified textMatching is case-insensitive.Wildcards and regular expressions are not supported.
        filter_text_match: Optional[GetFilterTextMatchQueryParameterType] = None

        # Filters projects by user access level. Possible values: ``projectAdmin``, ``projectMember``.Max length: 255
        filteraccess_levels: Optional[list[str]] = None

        # Filters projects by classification. Possible values:``production`` – Standard production projects.``template`` – Project templates that can be cloned to create production projects.``component`` – Placeholder projects that contain standardized components (e.g., forms) for use across projects. Only one component project is permitted per account. Known as a library in the ACC unified products UI.``sample`` – The single sample project automatically created upon ACC trial setup. Only one sample project is permitted per account.Max length: 255
        filterclassification: Optional[list[str]] = None

        # A list of project IDs to filter by.
        filterid: Optional[list[str]] = None

        # Filters by a user-defined project identifier. Supports partial matches when used with ``filterTextMatch``. For example, ``filter[jobNumber]=HP-0002&filterTextMatch=equals`` returns projects where the job number is exactly ``HP-0002``.Max length: 255
        filterjob_number: Optional[str] = None

        # Filters projects by name. Supports partial matches when used with ``filterTextMatch``. For example ``filter[name]=ABCco&filterTextMatch=startsWith`` returns projects whose names start with ``ABCco``.Max length: 255
        filtername: Optional[str] = None

        # Filters by platform. Possible values: ``acc`` (Autodesk Construction Cloud) and ``bim360`` (BIM 360).Max length: 255
        filterplatform: Optional[list[str]] = None

        # Filters projects by status. Possible values: ``active``, ``pending``, ``archived``, ``suspended``.
        filterstatus: Optional[list[str]] = None

        # Filters by project type. To exclude a type, prefix it with ``-`` (e.g., ``-Bridge`` excludes bridge projects).Possible values: ``Airport``, ``Assisted Living / Nursing Home``, ``Bridge``, ``Canal / Waterway``, ``Convention Center``, ``Court House``, ``Data Center``, ``Dams / Flood Control / Reservoirs``, ``Demonstration Project``, ``Dormitory``, ``Education Facility``, ``Government Building``, ``Harbor / River Development``, ``Hospital``, ``Hotel / Motel``, ``Library``, ``Manufacturing / Factory``, ``Medical Laboratory``, ``Medical Office``, ``Military Facility``, ``Mining Facility``, ``Multi-Family Housing``, ``Museum``, ``Oil & Gas``,``Plant``, ``Office``, ``OutPatient Surgery Center``, ``Parking Structure / Garage``, ``Performing Arts``, ``Power Plant``, ``Prison / Correctional Facility``, ``Rail``, ``Recreation Building``, ``Religious Building``, ``Research Facility / Laboratory``, ``Restaurant``, ``Retail``, ``Seaport``, ``Single-Family Housing``, ``Solar Farm``, ``Stadium/Arena``, ``Streets / Roads / Highways``, ``Template Project``, ``Theme Park``, ``Training Project``, ``Transportation Building``, ``Tunnel``, ``Utilities``, ``Warehouse (non-manufacturing)``, ``Waste Water / Sewers``, ``Water Supply``, ``Wind Farm``.
        filtertype: Optional[list[str]] = None

        # Filters projects updated within a specific date range in ISO 8601 format. For example:Date range: ``2023-03-02T00:00:00.000Z..2023-03-03T23:59:59 .999Z``Specific start date: ``2023-03-02T00:00:00.000Z..``Specific end date: ``..2023-03-02T23:59:59.999Z``For more details, see `JSON API Filtering <https://jsonapi.org/format/#fetching-filtering>`_.Max length: 100
        filterupdated_at: Optional[str] = None

        # The maximum number of records to return in the response.Default: ``20``Minimum: ``1``Maximum: ``200`` (If a larger value is provided, only 200 records are returned)
        limit: Optional[int] = None

        # The index of the first record to return.Used for pagination in combination with the ``limit`` parameter.Example: ``limit=20`` and ``offset=40`` returns records 41–60.
        offset: Optional[int] = None

        # A list of fields to sort the returned user projects by. Multiple sort fields are applied in sequence order — each sort field produces groupings of projects with the same values of that field; the next sort field applies within the groupings produced by the previous sort field.Each property can be followed by a direction modifier of either ``asc`` (ascending) or ``desc`` (descending). The default is ``asc``.Possible values: ``name`` (the default), ``startDate``, ``endDate``, ``type``, ``status``, ``jobNumber``, ``constructionType``, ``deliveryMethod``, ``contractType``, ``currentPhase``, ``createdAt``, ``updatedAt`` and ``platform``.
        sort: Optional[list[str]] = None

    
    @dataclass
    class ProjectsRequestBuilderGetRequestConfiguration(RequestConfiguration[ProjectsRequestBuilderGetQueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

