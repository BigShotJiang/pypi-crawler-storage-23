from enum import Enum

class UsersGetResponse_results_phone_phoneType(str, Enum):
    Home = "home",
    Mobile = "mobile",
    Office = "office",

