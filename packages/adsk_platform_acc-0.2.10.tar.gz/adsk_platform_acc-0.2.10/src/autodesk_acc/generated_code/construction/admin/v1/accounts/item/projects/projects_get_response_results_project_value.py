from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .projects_get_response_results_project_value_currency import ProjectsGetResponse_results_projectValue_currency

@dataclass
class ProjectsGetResponse_results_projectValue(Parsable):
    """
    Contains details about the estimated cost of the project, including the amount (``value``) and the currency (``currency``).
    """
    from .projects_get_response_results_project_value_currency import ProjectsGetResponse_results_projectValue_currency

    # The currency of the project value. Default: ``USD``.Possible values: ``AED``, ``AFN``, ``ALL``, ``AMD``, ``ANG``, ``AOA``, ``ARS``, ``AUD``, ``AWG``, ``AZN``, ``BAM``, ``BBD``, ``BDT``, ``BGN``, ``BHD``, ``BIF``, ``BMD``, ``BND``, ``BOB``, ``BOV``, ``BRL``, ``BSD``, ``BTN``, ``BWP``, ``BYN``, ``BYR``, ``BZD``, ``CAD``, ``CDF``, ``CHE``, ``CHF``, ``CHW``, ``CLF``, ``CLP``, ``CNY``, ``COP``, ``COU``, ``CRC``, ``CUC``, ``CUP``, ``CVE``, ``CZK``, ``DJF``, ``DKK``, ``DOP``, ``DZD``, ``EEK``, ``EGP``, ``ERN``, ``ETB``, ``EUR``, ``FJD``, ``FKP``, ``GBP``, ``GEL``, ``GHS``, ``GIP``, ``GMD``, ``GNF``, ``GTQ``, ``GYD``, ``HKD``, ``HNL``, ``HRK``, ``HTG``, ``HUF``, ``IDR``, ``ILS``, ``INR``, ``IQD``, ``IRR``, ``ISK``, ``JMD``, ``JOD``, ``JPY``, ``KES``, ``KGS``, ``KHR``, ``KMF``, ``KPW``, ``KRW``, ``KWD``, ``KYD``, ``KZT``, ``LAK``, ``LBP``, ``LKR``, ``LRD``, ``LSL``, ``LTL``, ``LVL``, ``LYD``, ``MAD``, ``MDL``, ``MGA``, ``MKD``, ``MMK``, ``MNT``, ``MOP``, ``MRU``, ``MUR``, ``MVR``, ``MWK``, ``MXN``, ``MXV``, ``MYR``, ``MZN``, ``NAD``, ``NGN``, ``NIO``, ``NOK``, ``NPR``, ``NZD``, ``OMR``, ``PAB``, ``PEN``, ``PGK``, ``PHP``, ``PKR``, ``PLN``, ``PYG``, ``QAR``, ``RON``, ``RSD``, ``RUB``, ``RWF``, ``SAR``, ``SBD``, ``SCR``, ``SDG``, ``SEK``, ``SGD``, ``SHP``, ``SLE``, ``SLL``, ``SOS``, ``SRD``, ``SSP``, ``STN``, ``SVC``, ``SYP``, ``SZL``, ``THB``, ``TJS``, ``TMT``, ``TND``, ``TOP``, ``TRL``, ``TRY``, ``TTD``, ``TWD``, ``TZS``, ``UAH``, ``UGX``, ``USD``, ``USN``, ``UYI``, ``UYU``, ``UYW``, ``UZS``, ``VED``, ``VES``, ``VND``, ``VUV``, ``WST``, ``XAF``, ``XAG``, ``XAU``, ``XBA``, ``XBB``, ``XBC``, ``XBD``, ``XCD``, ``XDR``, ``XOF``, ``XPD``, ``XPF``, ``XPT``, ``XSU``, ``XTS``, ``XUA``, ``XXX``, ``YER``, ``ZAR``, ``ZMW``, ``ZWL``
    currency: Optional[ProjectsGetResponse_results_projectValue_currency] = ProjectsGetResponse_results_projectValue_currency("USD")
    # The estimated cost of the project, based on the ``currency`` specified in the currency field. Default: ``0``.
    value: Optional[float] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ProjectsGetResponse_results_projectValue:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ProjectsGetResponse_results_projectValue
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ProjectsGetResponse_results_projectValue()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .projects_get_response_results_project_value_currency import ProjectsGetResponse_results_projectValue_currency

        from .projects_get_response_results_project_value_currency import ProjectsGetResponse_results_projectValue_currency

        fields: dict[str, Callable[[Any], None]] = {
            "currency": lambda n : setattr(self, 'currency', n.get_enum_value(ProjectsGetResponse_results_projectValue_currency)),
            "value": lambda n : setattr(self, 'value', n.get_float_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("currency", self.currency)
        writer.write_float_value("value", self.value)
    

