from enum import Enum

class UsersPostResponse_phone_phoneType(str, Enum):
    Home = "home",
    Mobile = "mobile",
    Office = "office",

