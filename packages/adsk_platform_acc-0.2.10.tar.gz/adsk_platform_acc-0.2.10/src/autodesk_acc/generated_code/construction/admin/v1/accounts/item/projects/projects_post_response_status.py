from enum import Enum

class ProjectsPostResponse_status(str, Enum):
    Active = "active",
    Pending = "pending",
    Archived = "archived",
    Suspended = "suspended",

