from __future__ import annotations
from collections.abc import Callable
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.request_adapter import RequestAdapter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

if TYPE_CHECKING:
    from .item.with_account_item_request_builder import WithAccountItemRequestBuilder

class AccountsRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /construction/admin/v1/accounts
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new AccountsRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/construction/admin/v1/accounts", path_parameters)
    
    def by_account_id(self,account_id: UUID) -> WithAccountItemRequestBuilder:
        """
        Gets an item from the Autodesk.ACC.construction.admin.v1.accounts.item collection
        param account_id: The ID of the ACC account that contains the project being created or the projects being retrieved. This corresponds to the hub ID in the `Data Management API </en/docs/data/v2/>`_. To convert a hub ID into an account ID, remove the ``**b.**`` prefix. For example, a hub ID of ``b.c8b0c73d-3ae9`` translates to an account ID of ``c8b0c73d-3ae9``.
        Returns: WithAccountItemRequestBuilder
        """
        if account_id is None:
            raise TypeError("account_id cannot be null.")
        from .item.with_account_item_request_builder import WithAccountItemRequestBuilder

        url_tpl_params = get_path_parameters(self.path_parameters)
        url_tpl_params["accountId"] = account_id
        return WithAccountItemRequestBuilder(self.request_adapter, url_tpl_params)
    

