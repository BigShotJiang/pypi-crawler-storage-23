from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .users_get_response_pagination import UsersGetResponse_pagination
    from .users_get_response_results import UsersGetResponse_results

@dataclass
class UsersGetResponse(Parsable):
    # Contains pagination details for the records returned by the endpoint.
    pagination: Optional[UsersGetResponse_pagination] = None
    # The requested page of project users.
    results: Optional[list[UsersGetResponse_results]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> UsersGetResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: UsersGetResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return UsersGetResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .users_get_response_pagination import UsersGetResponse_pagination
        from .users_get_response_results import UsersGetResponse_results

        from .users_get_response_pagination import UsersGetResponse_pagination
        from .users_get_response_results import UsersGetResponse_results

        fields: dict[str, Callable[[Any], None]] = {
            "pagination": lambda n : setattr(self, 'pagination', n.get_object_value(UsersGetResponse_pagination)),
            "results": lambda n : setattr(self, 'results', n.get_collection_of_object_values(UsersGetResponse_results)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_object_value("pagination", self.pagination)
        writer.write_collection_of_object_values("results", self.results)
    

