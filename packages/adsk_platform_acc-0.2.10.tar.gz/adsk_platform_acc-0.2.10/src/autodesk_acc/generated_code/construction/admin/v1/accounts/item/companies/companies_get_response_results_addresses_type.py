from enum import Enum

class CompaniesGetResponse_results_addresses_type(str, Enum):
    Main = "Main",

