from enum import Enum

class WithProjectGetResponse_classification(str, Enum):
    Production = "production",
    Template = "template",
    Component = "component",
    Sample = "sample",

