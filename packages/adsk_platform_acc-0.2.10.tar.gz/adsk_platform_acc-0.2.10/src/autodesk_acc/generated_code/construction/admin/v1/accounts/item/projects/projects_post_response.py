from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

if TYPE_CHECKING:
    from .projects_post_response_classification import ProjectsPostResponse_classification
    from .projects_post_response_platform import ProjectsPostResponse_platform
    from .projects_post_response_products import ProjectsPostResponse_products
    from .projects_post_response_project_value import ProjectsPostResponse_projectValue
    from .projects_post_response_status import ProjectsPostResponse_status

@dataclass
class ProjectsPostResponse(Parsable):
    # The account ID associated with the project.
    account_id: Optional[UUID] = None
    # The first line of the project’s address.Max length: 255
    address_line1: Optional[str] = None
    # Additional address details for the project location.Max length: 255
    address_line2: Optional[str] = None
    # Not relevantMax length: 25
    admin_group_id: Optional[str] = None
    # The ID of the business unit that the project is associated with.
    business_unit_id: Optional[UUID] = None
    # The city wher the project is located.Max length: 255
    city: Optional[str] = None
    # The classification of the project. Possible values:- ``production`` – Standard project.- ``template`` – A project that serves as a template for creating new projects.- ``component`` – A placeholder project containing reusable components (e.g., forms). Only one component project is allowed per account. Known as a library in the ACC UI.- ``sample`` – A single sample project automatically created for ACC trials (limited to one per account).
    classification: Optional[ProjectsPostResponse_classification] = None
    # The total number of companies associated with the project.Note that this field is relevant only in responses. It is ignored in requests.
    company_count: Optional[int] = None
    # The type of construction for the project. Recommended values: ``New Construction``, ``Renovation``. Any value is accepted.
    construction_type: Optional[str] = None
    # The type of contract for the project. For example, ``Lump Sum``, ``Cost Plus``, ``Guaranteed Maximum Price``, ``Unit Price``. Any value is accepted.
    contract_type: Optional[str] = None
    # The country where the project is located, using an ISO 3166-1 code.Max length: 255
    country: Optional[str] = None
    # The timestamp when the project was created, in ISO 8601 format. This value is set at creation and does not change.
    created_at: Optional[datetime.datetime] = None
    # The current phase of the project. Recommended values include, ``Concept``, ``Design``, ``Bidding``, ``Planning``, ``Preconstruction``, ``Construction``, ``Commissioning``, ``Warranty``, ``Complete``, ``Facility Management``, ``Operation``, ``Strategic Definition``, ``Preparation and Brief``, ``Concept Design``, ``Developed Design``, ``Technical Design``, ``Construction``, ``Handover and Close Out`` and ``In Use``.Any value is accepted.
    current_phase: Optional[str] = None
    # The method used to deliver the project. Recommended values include ``Design-Bid-Build``, ``Construction Management (CM) at Risk``, and ``Integrated Project Delivery (IPD)``. Any value is accepted.
    delivery_method: Optional[str] = None
    # The estimated end date for the project, in ISO 8601 format.
    end_date: Optional[str] = None
    # The internally generated ID for the project.
    id: Optional[UUID] = None
    # The URL of the main image associated with the project. This field can be ``null``.Max length: 255
    image_url: Optional[str] = None
    # Not relevant - we don't currently support this field.
    job_id: Optional[UUID] = None
    # A user-defined identifier for the project. This value is assigned when the project is created and can be used to filter projects. It supports partial matches when used with ``filterTextMatch``.Max length: 100
    job_number: Optional[str] = None
    # The timestamp of the last time someone signed into the project.
    last_sign_in: Optional[datetime.datetime] = None
    # The latitude coordinate of the project location.Max length: 25
    latitude: Optional[str] = None
    # The longitude coordinate of the project location.Max length: 25
    longitude: Optional[str] = None
    # The total number of members on the project.Note that this field is relevant only in responses. It is ignored in requests.
    member_count: Optional[int] = None
    # Not relevantMax length: 25
    member_group_id: Optional[str] = None
    # The name of the project.Max length: 255
    name: Optional[str] = None
    # The APS platform where the project is stored. Possible values: ``acc``, ``bim360``.Note that this field is relevant only in responses. It is ignored in requests.
    platform: Optional[ProjectsPostResponse_platform] = None
    # The postal or ZIP code of the project location.Max length: 255
    postal_code: Optional[str] = None
    # An array of the product objects associated with the project.Note that this array is relevant only in responses. It is ignored in requests.When a project is created, every product in the same account as the project is activated for the project. You can call `PATCH users/:userId </en/docs/acc/v1/reference/http/admin-projects-projectId-users-userId-PATCH/>`_ to separately activate one or more of the returned products for each user assigned to the project.
    products: Optional[list[ProjectsPostResponse_products]] = None
    # Contains details about the estimated cost of the project, including the amount (``value``) and the currency (``currency``).
    project_value: Optional[ProjectsPostResponse_projectValue] = None
    # The total number of sheets associated with the project.Note that this field is relevant only in responses. It is ignored in requests.
    sheet_count: Optional[int] = None
    # The estimated start date for the project, in ISO 8601 format.
    start_date: Optional[str] = None
    # The state or province where the project is located. It must be a valid name or an ISO 3166-2 code. The provided state or province must exist in the country of the project.Max length: 255
    state_or_province: Optional[str] = None
    # The status of the project.Possible values: ``active``, ``pending``, ``archived`` and ``suspended``.
    status: Optional[ProjectsPostResponse_status] = None
    # The ID of the project that was used as a template to create this project.
    template_id: Optional[UUID] = None
    # The URL of the project’s thumbnail image. This field can be ``null``.Max length: 255
    thumbnail_image_url: Optional[str] = None
    # The time zone where the project is located. It must be a valid IANA time zone name from the `IANA Time Zone Database <https://www.iana.org/time-zones>`_ (e.g., ``America/New_York``). If no time zone is set, this field may be ``null``.Possible values: ``Pacific/Honolulu``, ``America/Juneau``, ``America/Los_Angeles``, ``America/Phoenix``, ``America/Denver``, ``America/Chicago``, ``America/New_York``, ``America/Indiana/Indianapolis``, ``Pacific/Pago_Pago``, ``Pacific/Midway``, ``America/Tijuana``, ``America/Chihuahua``, ``America/Mazatlan``, ``America/Guatemala``, ``America/Mexico_City``, ``America/Monterrey``, ``America/Regina``, ``America/Bogota``, ``America/Lima``, ``America/Caracas``, ``America/Halifax``, ``America/Guyana``, ``America/La_Paz``, ``America/Santiago``, ``America/St_Johns``, ``America/Sao_Paulo``, ``America/Argentina/Buenos_Aires``, ``America/Godthab``, ``Atlantic/South_Georgia``, ``Atlantic/Azores``, ``Atlantic/Cape_Verde``, ``Africa/Casablanca``, ``Europe/Dublin``, ``Europe/Lisbon``, ``Europe/London``, ``Africa/Monrovia``, ``Etc/UTC``, ``Europe/Amsterdam``, ``Europe/Belgrade``, ``Europe/Berlin``, ``Europe/Bratislava``, ``Europe/Brussels``, ``Europe/Budapest``, ``Europe/Copenhagen``, ``Europe/Ljubljana``, ``Europe/Madrid``, ``Europe/Paris``, ``Europe/Prague``, ``Europe/Rome``, ``Europe/Sarajevo``, ``Europe/Skopje``, ``Europe/Stockholm``, ``Europe/Vienna``, ``Europe/Warsaw``, ``Africa/Algiers``, ``Europe/Zagreb``, ``Europe/Athens``, ``Europe/Bucharest``, ``Africa/Cairo``, ``Africa/Harare``, ``Europe/Helsinki``, ``Europe/Istanbul``, ``Asia/Jerusalem``, ``Europe/Kiev``, ``Africa/Johannesburg``, ``Europe/Riga``, ``Europe/Sofia``, ``Europe/Tallinn``, ``Europe/Vilnius``, ``Asia/Baghdad``, ``Asia/Kuwait``, ``Europe/Minsk``, ``Africa/Nairobi``, ``Asia/Riyadh``, ``Asia/Tehran``, ``Asia/Muscat``, ``Asia/Baku``, ``Europe/Moscow``, ``Asia/Tbilisi``, ``Asia/Yerevan``, ``Asia/Kabul``, ``Asia/Karachi``, ``Asia/Tashkent``, ``Asia/Kolkata``, ``Asia/Colombo``, ``Asia/Kathmandu``, ``Asia/Almaty``, ``Asia/Dhaka``, ``Asia/Yekaterinburg``, ``Asia/Rangoon``, ``Asia/Bangkok``, ``Asia/Jakarta``, ``Asia/Novosibirsk``, ``Asia/Shanghai``, ``Asia/Chongqing``, ``Asia/Hong_Kong``, ``Asia/Krasnoyarsk``, ``Asia/Kuala_Lumpur``, ``Australia/Perth``, ``Asia/Singapore``, ``Asia/Taipei``, ``Asia/Ulaanbaatar``, ``Asia/Urumqi``, ``Asia/Irkutsk``, ``Asia/Tokyo``, ``Asia/Seoul``, ``Australia/Adelaide``, ``Australia/Darwin``, ``Australia/Brisbane``, ``Australia/Melbourne``, ``Pacific/Guam``, ``Australia/Hobart``, ``Pacific/Port_Moresby``, ``Australia/Sydney``, ``Asia/Yakutsk``, ``Pacific/Noumea``, ``Asia/Vladivostok``, ``Pacific/Auckland``, ``Pacific/Fiji``, ``Asia/Kamchatka``, ``Asia/Magadan``, ``Pacific/Majuro``, ``Pacific/Guadalcanal``, ``Pacific/Tongatapu``, ``Pacific/Apia``, ``Pacific/Fakaofo``
    timezone: Optional[str] = None
    # The type of the project. Any value is accepted, but the following are recommended:Possible values: ``Convention Center``, ``Data Center``, ``Hotel / Motel``, ``Office``, ``Parking Structure / Garage``, ``Performing Arts``, ``Restaurant``, ``Retail``, ``Stadium / Arena``, ``Theme Park``, ``Warehouse (non-manufacturing)``, ``Assisted Living / Nursing Home``, ``Hospital``, ``Medical Laboratory``, ``Medical Office``, ``OutPatient Surgery Center``, ``Court House``, ``Dormitory``, ``Education Facility``, ``Government Building``, ``Library``, ``Military Facility``, ``Museum``, ``Prison / Correctional Facility``, ``Recreation Building``, ``Religious Building``, ``Research Facility / Laboratory``, ``Multi-Family Housing``, ``Single-Family Housing``, ``Airport``, ``Bridge``, ``Canal / Waterway``, ``Dams / Flood Control / Reservoirs``, ``Harbor / River Development``, ``Rail``, ``Seaport``, ``Streets / Roads / Highways``, ``Transportation Building``, ``Tunnel``, ``Waste Water / Sewers``, ``Water Supply``, ``Manufacturing / Factory``, ``Mining Facility``, ``Oil & Gas``, ``Plant``, ``Power Plant``, ``Solar Farm``, ``Utilities``, ``Wind Farm``, ``Demonstration Project``, ``Template Project`` and ``Training Project``.Max length: 255
    type: Optional[str] = None
    # The timestamp when the project was last updated, in ISO 8601 format. This reflects changes to project fields but not updates to resources within the project.
    updated_at: Optional[datetime.datetime] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ProjectsPostResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ProjectsPostResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ProjectsPostResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .projects_post_response_classification import ProjectsPostResponse_classification
        from .projects_post_response_platform import ProjectsPostResponse_platform
        from .projects_post_response_products import ProjectsPostResponse_products
        from .projects_post_response_project_value import ProjectsPostResponse_projectValue
        from .projects_post_response_status import ProjectsPostResponse_status

        from .projects_post_response_classification import ProjectsPostResponse_classification
        from .projects_post_response_platform import ProjectsPostResponse_platform
        from .projects_post_response_products import ProjectsPostResponse_products
        from .projects_post_response_project_value import ProjectsPostResponse_projectValue
        from .projects_post_response_status import ProjectsPostResponse_status

        fields: dict[str, Callable[[Any], None]] = {
            "accountId": lambda n : setattr(self, 'account_id', n.get_uuid_value()),
            "addressLine1": lambda n : setattr(self, 'address_line1', n.get_str_value()),
            "addressLine2": lambda n : setattr(self, 'address_line2', n.get_str_value()),
            "adminGroupId": lambda n : setattr(self, 'admin_group_id', n.get_str_value()),
            "businessUnitId": lambda n : setattr(self, 'business_unit_id', n.get_uuid_value()),
            "city": lambda n : setattr(self, 'city', n.get_str_value()),
            "classification": lambda n : setattr(self, 'classification', n.get_enum_value(ProjectsPostResponse_classification)),
            "companyCount": lambda n : setattr(self, 'company_count', n.get_int_value()),
            "constructionType": lambda n : setattr(self, 'construction_type', n.get_str_value()),
            "contractType": lambda n : setattr(self, 'contract_type', n.get_str_value()),
            "country": lambda n : setattr(self, 'country', n.get_str_value()),
            "createdAt": lambda n : setattr(self, 'created_at', n.get_datetime_value()),
            "currentPhase": lambda n : setattr(self, 'current_phase', n.get_str_value()),
            "deliveryMethod": lambda n : setattr(self, 'delivery_method', n.get_str_value()),
            "endDate": lambda n : setattr(self, 'end_date', n.get_str_value()),
            "id": lambda n : setattr(self, 'id', n.get_uuid_value()),
            "imageUrl": lambda n : setattr(self, 'image_url', n.get_str_value()),
            "jobId": lambda n : setattr(self, 'job_id', n.get_uuid_value()),
            "jobNumber": lambda n : setattr(self, 'job_number', n.get_str_value()),
            "lastSignIn": lambda n : setattr(self, 'last_sign_in', n.get_datetime_value()),
            "latitude": lambda n : setattr(self, 'latitude', n.get_str_value()),
            "longitude": lambda n : setattr(self, 'longitude', n.get_str_value()),
            "memberCount": lambda n : setattr(self, 'member_count', n.get_int_value()),
            "memberGroupId": lambda n : setattr(self, 'member_group_id', n.get_str_value()),
            "name": lambda n : setattr(self, 'name', n.get_str_value()),
            "platform": lambda n : setattr(self, 'platform', n.get_enum_value(ProjectsPostResponse_platform)),
            "postalCode": lambda n : setattr(self, 'postal_code', n.get_str_value()),
            "products": lambda n : setattr(self, 'products', n.get_collection_of_object_values(ProjectsPostResponse_products)),
            "projectValue": lambda n : setattr(self, 'project_value', n.get_object_value(ProjectsPostResponse_projectValue)),
            "sheetCount": lambda n : setattr(self, 'sheet_count', n.get_int_value()),
            "startDate": lambda n : setattr(self, 'start_date', n.get_str_value()),
            "stateOrProvince": lambda n : setattr(self, 'state_or_province', n.get_str_value()),
            "status": lambda n : setattr(self, 'status', n.get_enum_value(ProjectsPostResponse_status)),
            "templateId": lambda n : setattr(self, 'template_id', n.get_uuid_value()),
            "thumbnailImageUrl": lambda n : setattr(self, 'thumbnail_image_url', n.get_str_value()),
            "timezone": lambda n : setattr(self, 'timezone', n.get_str_value()),
            "type": lambda n : setattr(self, 'type', n.get_str_value()),
            "updatedAt": lambda n : setattr(self, 'updated_at', n.get_datetime_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_uuid_value("accountId", self.account_id)
        writer.write_str_value("addressLine1", self.address_line1)
        writer.write_str_value("addressLine2", self.address_line2)
        writer.write_str_value("adminGroupId", self.admin_group_id)
        writer.write_uuid_value("businessUnitId", self.business_unit_id)
        writer.write_str_value("city", self.city)
        writer.write_enum_value("classification", self.classification)
        writer.write_int_value("companyCount", self.company_count)
        writer.write_str_value("constructionType", self.construction_type)
        writer.write_str_value("contractType", self.contract_type)
        writer.write_str_value("country", self.country)
        writer.write_datetime_value("createdAt", self.created_at)
        writer.write_str_value("currentPhase", self.current_phase)
        writer.write_str_value("deliveryMethod", self.delivery_method)
        writer.write_str_value("endDate", self.end_date)
        writer.write_uuid_value("id", self.id)
        writer.write_str_value("imageUrl", self.image_url)
        writer.write_uuid_value("jobId", self.job_id)
        writer.write_str_value("jobNumber", self.job_number)
        writer.write_datetime_value("lastSignIn", self.last_sign_in)
        writer.write_str_value("latitude", self.latitude)
        writer.write_str_value("longitude", self.longitude)
        writer.write_int_value("memberCount", self.member_count)
        writer.write_str_value("memberGroupId", self.member_group_id)
        writer.write_str_value("name", self.name)
        writer.write_enum_value("platform", self.platform)
        writer.write_str_value("postalCode", self.postal_code)
        writer.write_collection_of_object_values("products", self.products)
        writer.write_object_value("projectValue", self.project_value)
        writer.write_int_value("sheetCount", self.sheet_count)
        writer.write_str_value("startDate", self.start_date)
        writer.write_str_value("stateOrProvince", self.state_or_province)
        writer.write_enum_value("status", self.status)
        writer.write_uuid_value("templateId", self.template_id)
        writer.write_str_value("thumbnailImageUrl", self.thumbnail_image_url)
        writer.write_str_value("timezone", self.timezone)
        writer.write_str_value("type", self.type)
        writer.write_datetime_value("updatedAt", self.updated_at)
    

