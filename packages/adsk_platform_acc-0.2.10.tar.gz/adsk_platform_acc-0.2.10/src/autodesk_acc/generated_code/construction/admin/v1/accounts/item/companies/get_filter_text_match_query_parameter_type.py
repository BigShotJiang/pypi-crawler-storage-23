from enum import Enum

class GetFilterTextMatchQueryParameterType(str, Enum):
    FilterName = "filter[name]",
    FilterJobNumber = "filter[jobNumber]",
    FilterCompanyName = "filter[companyName]",
    Contains = "contains",
    StartsWith = "startsWith",
    EndsWith = "endsWith",
    Equals = "equals",

