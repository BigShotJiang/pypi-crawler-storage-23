from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .products_get_response_results_key import ProductsGetResponse_results_key

@dataclass
class ProductsGetResponse_results(Parsable):
    # The URL of the icon associated with the product.
    icon: Optional[str] = None
    # A machine-readable identifier for the product (e.g., docs, build).Each product has a unique key used throughout the API for identification, filtering, and integration logic (e.g., in query parameters like ``filter[key]``).Possible values:ACC - ``autoSpecs``, ``build``, ``cost``, ``designCollaboration``, ``docs``, ``insight``, ``modelCoordination``, ``projectAdministration``, and ``takeoff``.BIM 360 - ``assets``, ``costManagement``, ``designCollaboration``, ``documentManagement``, ``field``, ``fieldManagement``, ``glue``, ``insight``, ``modelCoordination``, ``plan``, ``projectAdministration``, ``projectHome``, ``projectManagement``, and ``quantification``.Note that this endpoint returns only ACC products. Other endpoints, such as `GET projects </en/docs/acc/v1/reference/http/admin-accountsaccountidprojects-GET/>`_ and `GET projects/:projectId </en/docs/acc/v1/reference/http/admin-projects-projectId-GET/>`_, may return both ACC and BIM 360 projects. In those responses, product keys may include BIM 360 values.
    key: Optional[ProductsGetResponse_results_key] = None
    # The name of the product.
    name: Optional[str] = None
    # The list of projects IDs where the user is associated with the product.
    project_ids: Optional[list[str]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ProductsGetResponse_results:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ProductsGetResponse_results
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ProductsGetResponse_results()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .products_get_response_results_key import ProductsGetResponse_results_key

        from .products_get_response_results_key import ProductsGetResponse_results_key

        fields: dict[str, Callable[[Any], None]] = {
            "icon": lambda n : setattr(self, 'icon', n.get_str_value()),
            "key": lambda n : setattr(self, 'key', n.get_enum_value(ProductsGetResponse_results_key)),
            "name": lambda n : setattr(self, 'name', n.get_str_value()),
            "projectIds": lambda n : setattr(self, 'project_ids', n.get_collection_of_primitive_values(str)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("icon", self.icon)
        writer.write_enum_value("key", self.key)
        writer.write_str_value("name", self.name)
        writer.write_collection_of_primitive_values("projectIds", self.project_ids)
    

