from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID
from warnings import warn

if TYPE_CHECKING:
    from .item.with_model_set_item_request_builder import WithModelSetItemRequestBuilder
    from .modelsets_get_response import ModelsetsGetResponse
    from .modelsets_post_request_body import ModelsetsPostRequestBody
    from .modelsets_post_response import ModelsetsPostResponse

class ModelsetsRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /bim360/modelset/v3/containers/{containerId}/modelsets
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new ModelsetsRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/bim360/modelset/v3/containers/{containerId}/modelsets", path_parameters)
    
    def by_model_set_id(self,model_set_id: UUID) -> WithModelSetItemRequestBuilder:
        """
        Gets an item from the Autodesk.ACC.bim360.modelset.v3.containers.item.modelsets.item collection
        param model_set_id: The GUID that uniquely identifies the model set.
        Returns: WithModelSetItemRequestBuilder
        """
        if model_set_id is None:
            raise TypeError("model_set_id cannot be null.")
        from .item.with_model_set_item_request_builder import WithModelSetItemRequestBuilder

        url_tpl_params = get_path_parameters(self.path_parameters)
        url_tpl_params["modelSetId"] = model_set_id
        return WithModelSetItemRequestBuilder(self.request_adapter, url_tpl_params)
    
    async def get(self,request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> Optional[ModelsetsGetResponse]:
        """
        Retrieves model sets for the specified container. This endpoint is compatible with both BIM 360 and Autodesk Construction Cloud (ACC) projects.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[ModelsetsGetResponse]
        """
        request_info = self.to_get_request_information(
            request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from .modelsets_get_response import ModelsetsGetResponse

        return await self.request_adapter.send_async(request_info, ModelsetsGetResponse, None)
    
    async def post(self,body: ModelsetsPostRequestBody, request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> Optional[ModelsetsPostResponse]:
        """
        Currently only a single folder is supported; however, sub-folders are supported.
        param body: The request body
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[ModelsetsPostResponse]
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = self.to_post_request_information(
            body, request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from .modelsets_post_response import ModelsetsPostResponse

        return await self.request_adapter.send_async(request_info, ModelsetsPostResponse, None)
    
    def to_get_request_information(self,request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> RequestInformation:
        """
        Retrieves model sets for the specified container. This endpoint is compatible with both BIM 360 and Autodesk Construction Cloud (ACC) projects.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        request_info = RequestInformation(Method.GET, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        return request_info
    
    def to_post_request_information(self,body: ModelsetsPostRequestBody, request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> RequestInformation:
        """
        Currently only a single folder is supported; however, sub-folders are supported.
        param body: The request body
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = RequestInformation(Method.POST, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        request_info.set_content_from_parsable(self.request_adapter, "application/json", body)
        return request_info
    
    def with_url(self,raw_url: str) -> ModelsetsRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: ModelsetsRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return ModelsetsRequestBuilder(self.request_adapter, raw_url)
    
    @dataclass
    class ModelsetsRequestBuilderGetRequestConfiguration(RequestConfiguration[QueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    
    @dataclass
    class ModelsetsRequestBuilderPostRequestConfiguration(RequestConfiguration[QueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

