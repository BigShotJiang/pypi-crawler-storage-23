from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

if TYPE_CHECKING:
    from .views_post_response_job import ViewsPostResponse_job
    from .views_post_response_status import ViewsPostResponse_status

@dataclass
class ViewsPostResponse(Parsable):
    # A job.
    job: Optional[ViewsPostResponse_job] = None
    # The GUID that uniquely identifies the job.
    job_id: Optional[UUID] = None
    # The current job status. Possible values: ``Failed``, ``Running``, ``Succeeded``, ``Archived``.
    status: Optional[ViewsPostResponse_status] = None
    # The GUID that uniquely identifies the view associated with the job.
    view_id: Optional[UUID] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ViewsPostResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ViewsPostResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ViewsPostResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .views_post_response_job import ViewsPostResponse_job
        from .views_post_response_status import ViewsPostResponse_status

        from .views_post_response_job import ViewsPostResponse_job
        from .views_post_response_status import ViewsPostResponse_status

        fields: dict[str, Callable[[Any], None]] = {
            "job": lambda n : setattr(self, 'job', n.get_object_value(ViewsPostResponse_job)),
            "jobId": lambda n : setattr(self, 'job_id', n.get_uuid_value()),
            "status": lambda n : setattr(self, 'status', n.get_enum_value(ViewsPostResponse_status)),
            "viewId": lambda n : setattr(self, 'view_id', n.get_uuid_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_object_value("job", self.job)
        writer.write_uuid_value("jobId", self.job_id)
        writer.write_enum_value("status", self.status)
        writer.write_uuid_value("viewId", self.view_id)
    

