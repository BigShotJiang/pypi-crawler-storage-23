from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

if TYPE_CHECKING:
    from .with_model_set_get_response_folders import WithModelSetGetResponse_folders
    from .with_model_set_get_response_model_set_type import WithModelSetGetResponse_modelSetType

@dataclass
class WithModelSetGetResponse(Parsable):
    # The GUID that uniquely identifies the container.
    container_id: Optional[UUID] = None
    # The unique identifier of the user who created the model set.
    created_by: Optional[str] = None
    # The date and time that the model set was created.
    created_time: Optional[datetime.datetime] = None
    # A textual description of the model set. Min length: 1 Max length: 1024.
    description: Optional[str] = None
    # The ModelSetFolders that determine the documents included in the model set.
    folders: Optional[list[WithModelSetGetResponse_folders]] = None
    # If set to true, a model set version is not automatically created following changes to documents within the model set.
    is_disabled: Optional[bool] = None
    # The GUID that uniquely identifies the model set.
    model_set_id: Optional[UUID] = None
    # The type of content this model set tracks. Possible values: ``Plans``, ``ProjectFiles``.
    model_set_type: Optional[WithModelSetGetResponse_modelSetType] = None
    # The name of the model set. This name must be unique within the specified container. Min length: 1 Max length: 64.
    name: Optional[str] = None
    # The version number of the most recent version of the model set.
    tip_version: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> WithModelSetGetResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: WithModelSetGetResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return WithModelSetGetResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .with_model_set_get_response_folders import WithModelSetGetResponse_folders
        from .with_model_set_get_response_model_set_type import WithModelSetGetResponse_modelSetType

        from .with_model_set_get_response_folders import WithModelSetGetResponse_folders
        from .with_model_set_get_response_model_set_type import WithModelSetGetResponse_modelSetType

        fields: dict[str, Callable[[Any], None]] = {
            "containerId": lambda n : setattr(self, 'container_id', n.get_uuid_value()),
            "createdBy": lambda n : setattr(self, 'created_by', n.get_str_value()),
            "createdTime": lambda n : setattr(self, 'created_time', n.get_datetime_value()),
            "description": lambda n : setattr(self, 'description', n.get_str_value()),
            "folders": lambda n : setattr(self, 'folders', n.get_collection_of_object_values(WithModelSetGetResponse_folders)),
            "isDisabled": lambda n : setattr(self, 'is_disabled', n.get_bool_value()),
            "modelSetId": lambda n : setattr(self, 'model_set_id', n.get_uuid_value()),
            "modelSetType": lambda n : setattr(self, 'model_set_type', n.get_enum_value(WithModelSetGetResponse_modelSetType)),
            "name": lambda n : setattr(self, 'name', n.get_str_value()),
            "tipVersion": lambda n : setattr(self, 'tip_version', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_uuid_value("containerId", self.container_id)
        writer.write_str_value("createdBy", self.created_by)
        writer.write_datetime_value("createdTime", self.created_time)
        writer.write_str_value("description", self.description)
        writer.write_collection_of_object_values("folders", self.folders)
        writer.write_bool_value("isDisabled", self.is_disabled)
        writer.write_uuid_value("modelSetId", self.model_set_id)
        writer.write_enum_value("modelSetType", self.model_set_type)
        writer.write_str_value("name", self.name)
        writer.write_int_value("tipVersion", self.tip_version)
    

