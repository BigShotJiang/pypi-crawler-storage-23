from enum import Enum

class VersionsGetResponse_modelSetVersions_status(str, Enum):
    Pending = "Pending",
    Processing = "Processing",
    Successful = "Successful",
    Partial = "Partial",
    Failed = "Failed",

