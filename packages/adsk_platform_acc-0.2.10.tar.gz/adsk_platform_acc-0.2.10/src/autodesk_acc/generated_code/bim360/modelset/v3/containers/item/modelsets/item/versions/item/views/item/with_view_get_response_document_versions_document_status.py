from enum import Enum

class WithViewGetResponse_documentVersions_documentStatus(str, Enum):
    Succeeded = "Succeeded",
    Failed = "Failed",
    Running = "Running",
    Skipped = "Skipped",

