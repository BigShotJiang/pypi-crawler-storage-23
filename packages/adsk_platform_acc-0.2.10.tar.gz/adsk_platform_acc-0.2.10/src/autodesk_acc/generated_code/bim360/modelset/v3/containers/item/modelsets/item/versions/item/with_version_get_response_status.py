from enum import Enum

class WithVersionGetResponse_status(str, Enum):
    Pending = "Pending",
    Processing = "Processing",
    Successful = "Successful",
    Partial = "Partial",
    Failed = "Failed",

