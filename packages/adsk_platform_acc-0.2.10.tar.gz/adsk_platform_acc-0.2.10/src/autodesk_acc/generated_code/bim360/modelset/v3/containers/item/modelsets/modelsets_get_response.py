from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .modelsets_get_response_model_sets import ModelsetsGetResponse_modelSets
    from .modelsets_get_response_page import ModelsetsGetResponse_page

@dataclass
class ModelsetsGetResponse(Parsable):
    # List of model set summaries.
    model_sets: Optional[list[ModelsetsGetResponse_modelSets]] = None
    # Paging information associated with a paging response.
    page: Optional[ModelsetsGetResponse_page] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ModelsetsGetResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ModelsetsGetResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ModelsetsGetResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .modelsets_get_response_model_sets import ModelsetsGetResponse_modelSets
        from .modelsets_get_response_page import ModelsetsGetResponse_page

        from .modelsets_get_response_model_sets import ModelsetsGetResponse_modelSets
        from .modelsets_get_response_page import ModelsetsGetResponse_page

        fields: dict[str, Callable[[Any], None]] = {
            "modelSets": lambda n : setattr(self, 'model_sets', n.get_collection_of_object_values(ModelsetsGetResponse_modelSets)),
            "page": lambda n : setattr(self, 'page', n.get_object_value(ModelsetsGetResponse_page)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_object_values("modelSets", self.model_sets)
        writer.write_object_value("page", self.page)
    

