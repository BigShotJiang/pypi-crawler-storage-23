from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

if TYPE_CHECKING:
    from .with_version_get_response_document_versions import WithVersionGetResponse_documentVersions
    from .with_version_get_response_status import WithVersionGetResponse_status

@dataclass
class WithVersionGetResponse(Parsable):
    # The date and time that the model set version was created.
    create_time: Optional[datetime.datetime] = None
    # The document versions included in this version of the model set.
    document_versions: Optional[list[WithVersionGetResponse_documentVersions]] = None
    # The GUID that uniquely identifies the model set.
    model_set_id: Optional[UUID] = None
    # The creation status of the model set version. Possible values: ``Pending``, ``Processing``, ``Successful``, ``Partial``, ``Failed``.
    status: Optional[WithVersionGetResponse_status] = None
    # The model set version number.
    version: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> WithVersionGetResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: WithVersionGetResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return WithVersionGetResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .with_version_get_response_document_versions import WithVersionGetResponse_documentVersions
        from .with_version_get_response_status import WithVersionGetResponse_status

        from .with_version_get_response_document_versions import WithVersionGetResponse_documentVersions
        from .with_version_get_response_status import WithVersionGetResponse_status

        fields: dict[str, Callable[[Any], None]] = {
            "createTime": lambda n : setattr(self, 'create_time', n.get_datetime_value()),
            "documentVersions": lambda n : setattr(self, 'document_versions', n.get_collection_of_object_values(WithVersionGetResponse_documentVersions)),
            "modelSetId": lambda n : setattr(self, 'model_set_id', n.get_uuid_value()),
            "status": lambda n : setattr(self, 'status', n.get_enum_value(WithVersionGetResponse_status)),
            "version": lambda n : setattr(self, 'version', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_datetime_value("createTime", self.create_time)
        writer.write_collection_of_object_values("documentVersions", self.document_versions)
        writer.write_uuid_value("modelSetId", self.model_set_id)
        writer.write_enum_value("status", self.status)
        writer.write_int_value("version", self.version)
    

