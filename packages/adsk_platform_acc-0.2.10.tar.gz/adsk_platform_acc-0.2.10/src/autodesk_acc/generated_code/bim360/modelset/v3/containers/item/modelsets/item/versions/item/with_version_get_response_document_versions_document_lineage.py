from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class WithVersionGetResponse_documentVersions_documentLineage(Parsable):
    """
    A document from a model set.
    """
    # Indicates whether the document lineage is aligned.
    is_aligned: Optional[bool] = None
    # The URN of the document lineage.
    lineage_urn: Optional[str] = None
    # The URN of the parent folder for the document lineage.
    parent_folder_urn: Optional[str] = None
    # The tip version URN for the document lineage.
    tip_version_urn: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> WithVersionGetResponse_documentVersions_documentLineage:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: WithVersionGetResponse_documentVersions_documentLineage
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return WithVersionGetResponse_documentVersions_documentLineage()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "isAligned": lambda n : setattr(self, 'is_aligned', n.get_bool_value()),
            "lineageUrn": lambda n : setattr(self, 'lineage_urn', n.get_str_value()),
            "parentFolderUrn": lambda n : setattr(self, 'parent_folder_urn', n.get_str_value()),
            "tipVersionUrn": lambda n : setattr(self, 'tip_version_urn', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("isAligned", self.is_aligned)
        writer.write_str_value("lineageUrn", self.lineage_urn)
        writer.write_str_value("parentFolderUrn", self.parent_folder_urn)
        writer.write_str_value("tipVersionUrn", self.tip_version_urn)
    

