from enum import Enum

class IssuesPostRequestBody_pushpin_type(str, Enum):
    TwoDVectorPushpin = "TwoDVectorPushpin",

