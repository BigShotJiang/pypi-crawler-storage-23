from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

if TYPE_CHECKING:
    from .views_get_response_model_set_views_definition import ViewsGetResponse_modelSetViews_definition

@dataclass
class ViewsGetResponse_modelSetViews(Parsable):
    # The ID of the user or service that created the view.
    created_by: Optional[str] = None
    # The date and time that the view was created.
    created_time: Optional[datetime.datetime] = None
    # The definition of models in a model set view, which is used to track the same models through time. Min items: 1 Max items: 1000.
    definition: Optional[list[ViewsGetResponse_modelSetViews_definition]] = None
    # The description of the model set view. Min length: 1 Max length: 1024.
    description: Optional[str] = None
    # Determines whether the view is only accessible to its creator.
    is_private: Optional[bool] = None
    # The ID of the user or service that last modified the view.
    modified_by: Optional[str] = None
    # The date and time that the view was last modified.
    modified_time: Optional[datetime.datetime] = None
    # The name of the model set view. Min length: 1 Max length: 64.
    name: Optional[str] = None
    # The GUID that uniquely identifies the view.
    view_id: Optional[UUID] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ViewsGetResponse_modelSetViews:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ViewsGetResponse_modelSetViews
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ViewsGetResponse_modelSetViews()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .views_get_response_model_set_views_definition import ViewsGetResponse_modelSetViews_definition

        from .views_get_response_model_set_views_definition import ViewsGetResponse_modelSetViews_definition

        fields: dict[str, Callable[[Any], None]] = {
            "createdBy": lambda n : setattr(self, 'created_by', n.get_str_value()),
            "createdTime": lambda n : setattr(self, 'created_time', n.get_datetime_value()),
            "definition": lambda n : setattr(self, 'definition', n.get_collection_of_object_values(ViewsGetResponse_modelSetViews_definition)),
            "description": lambda n : setattr(self, 'description', n.get_str_value()),
            "isPrivate": lambda n : setattr(self, 'is_private', n.get_bool_value()),
            "modifiedBy": lambda n : setattr(self, 'modified_by', n.get_str_value()),
            "modifiedTime": lambda n : setattr(self, 'modified_time', n.get_datetime_value()),
            "name": lambda n : setattr(self, 'name', n.get_str_value()),
            "viewId": lambda n : setattr(self, 'view_id', n.get_uuid_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("createdBy", self.created_by)
        writer.write_datetime_value("createdTime", self.created_time)
        writer.write_collection_of_object_values("definition", self.definition)
        writer.write_str_value("description", self.description)
        writer.write_bool_value("isPrivate", self.is_private)
        writer.write_str_value("modifiedBy", self.modified_by)
        writer.write_datetime_value("modifiedTime", self.modified_time)
        writer.write_str_value("name", self.name)
        writer.write_uuid_value("viewId", self.view_id)
    

