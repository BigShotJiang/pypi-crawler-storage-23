from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .versions_get_response_model_set_versions_status import VersionsGetResponse_modelSetVersions_status

@dataclass
class VersionsGetResponse_modelSetVersions(Parsable):
    # The date and time that the model set version was created.
    create_time: Optional[datetime.datetime] = None
    # The creation status of the model set version. Possible values: ``Pending``, ``Processing``, ``Successful``, ``Partial``, ``Failed``.
    status: Optional[VersionsGetResponse_modelSetVersions_status] = None
    # The model set version number.
    version: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> VersionsGetResponse_modelSetVersions:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: VersionsGetResponse_modelSetVersions
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return VersionsGetResponse_modelSetVersions()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .versions_get_response_model_set_versions_status import VersionsGetResponse_modelSetVersions_status

        from .versions_get_response_model_set_versions_status import VersionsGetResponse_modelSetVersions_status

        fields: dict[str, Callable[[Any], None]] = {
            "createTime": lambda n : setattr(self, 'create_time', n.get_datetime_value()),
            "status": lambda n : setattr(self, 'status', n.get_enum_value(VersionsGetResponse_modelSetVersions_status)),
            "version": lambda n : setattr(self, 'version', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_datetime_value("createTime", self.create_time)
        writer.write_enum_value("status", self.status)
        writer.write_int_value("version", self.version)
    

