from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class WithModelSetPatchRequestBody(Parsable):
    # The new description of the model set. Min length: 1 Max length: 1024.
    new_description: Optional[str] = None
    # The new name of the model set. This name must be unique within the specified container. Min length: 1 Max length: 64.
    new_name: Optional[str] = None
    # The current description of the model set. Min length: 1 Max length: 1024.
    old_description: Optional[str] = None
    # The current name of the model set. Min length: 1 Max length: 64.
    old_name: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> WithModelSetPatchRequestBody:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: WithModelSetPatchRequestBody
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return WithModelSetPatchRequestBody()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "newDescription": lambda n : setattr(self, 'new_description', n.get_str_value()),
            "newName": lambda n : setattr(self, 'new_name', n.get_str_value()),
            "oldDescription": lambda n : setattr(self, 'old_description', n.get_str_value()),
            "oldName": lambda n : setattr(self, 'old_name', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("newDescription", self.new_description)
        writer.write_str_value("newName", self.new_name)
        writer.write_str_value("oldDescription", self.old_description)
        writer.write_str_value("oldName", self.old_name)
    

