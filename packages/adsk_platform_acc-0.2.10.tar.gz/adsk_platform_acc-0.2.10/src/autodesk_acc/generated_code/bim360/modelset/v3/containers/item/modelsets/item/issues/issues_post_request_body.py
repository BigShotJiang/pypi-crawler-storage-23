from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

if TYPE_CHECKING:
    from .issues_post_request_body_assigned_to_type import IssuesPostRequestBody_assignedToType
    from .issues_post_request_body_custom_attributes import IssuesPostRequestBody_customAttributes
    from .issues_post_request_body_pushpin import IssuesPostRequestBody_pushpin
    from .issues_post_request_body_status import IssuesPostRequestBody_status
    from .issues_post_request_body_view_context import IssuesPostRequestBody_viewContext

@dataclass
class IssuesPostRequestBody(Parsable):
    # The user, role or company that the new issue is assigned to.
    assigned_to: Optional[str] = None
    # Specifies the type that the assignedTo parameter refers to. Possible values: ``User``, ``Role``, ``Company``.
    assigned_to_type: Optional[IssuesPostRequestBody_assignedToType] = None
    # The list of attributes to associate with the new issue. Max items: 64.
    custom_attributes: Optional[list[IssuesPostRequestBody_customAttributes]] = None
    # The description of the new issue. Max length: 10000.
    description: Optional[str] = None
    # A document or seed file version URN with which to associate the issue. Min length: 1 Max length: 80.
    document_version_urn: Optional[str] = None
    # The date and time that the new issue is due.
    due_date: Optional[datetime.datetime] = None
    # The issue sub-type ID associated with the new issue.
    issue_sub_type_id: Optional[UUID] = None
    # The issue type ID associated with the new issue.
    issue_type_id: Optional[UUID] = None
    # The description of the location associated with the new issue.
    location_description: Optional[str] = None
    # The location ID associated with the new issue.
    location_id: Optional[UUID] = None
    # The user who owns the new issue.
    owner: Optional[str] = None
    # An issue push pin object that describes a visual marker to place an issue on the 3D model.
    pushpin: Optional[IssuesPostRequestBody_pushpin] = None
    # The root cause ID associated with the new issue.
    root_cause_id: Optional[UUID] = None
    # The unique identifiers of screenshots associated with the new issue. Max items: 5.
    screen_shots: Optional[list[str]] = None
    # The status of the new issue. Possible values: ``Open``, ``Draft``.
    status: Optional[IssuesPostRequestBody_status] = None
    # The title of the new issue. Min length: 1 Max length: 4200.
    title: Optional[str] = None
    # Provides context for when this issue is viewed. Max items: 1000.
    view_context: Optional[list[IssuesPostRequestBody_viewContext]] = None
    # The name of the viewable in the Model Derivative manifest to track along the seed file lineage. This setting is ignored if the ``lineageUrn`` is the URN of a BIM360 Docs Plans folder document. Min length: 1 Max length: 430.
    viewable_name: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> IssuesPostRequestBody:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: IssuesPostRequestBody
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return IssuesPostRequestBody()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .issues_post_request_body_assigned_to_type import IssuesPostRequestBody_assignedToType
        from .issues_post_request_body_custom_attributes import IssuesPostRequestBody_customAttributes
        from .issues_post_request_body_pushpin import IssuesPostRequestBody_pushpin
        from .issues_post_request_body_status import IssuesPostRequestBody_status
        from .issues_post_request_body_view_context import IssuesPostRequestBody_viewContext

        from .issues_post_request_body_assigned_to_type import IssuesPostRequestBody_assignedToType
        from .issues_post_request_body_custom_attributes import IssuesPostRequestBody_customAttributes
        from .issues_post_request_body_pushpin import IssuesPostRequestBody_pushpin
        from .issues_post_request_body_status import IssuesPostRequestBody_status
        from .issues_post_request_body_view_context import IssuesPostRequestBody_viewContext

        fields: dict[str, Callable[[Any], None]] = {
            "assignedTo": lambda n : setattr(self, 'assigned_to', n.get_str_value()),
            "assignedToType": lambda n : setattr(self, 'assigned_to_type', n.get_enum_value(IssuesPostRequestBody_assignedToType)),
            "customAttributes": lambda n : setattr(self, 'custom_attributes', n.get_collection_of_object_values(IssuesPostRequestBody_customAttributes)),
            "description": lambda n : setattr(self, 'description', n.get_str_value()),
            "documentVersionUrn": lambda n : setattr(self, 'document_version_urn', n.get_str_value()),
            "dueDate": lambda n : setattr(self, 'due_date', n.get_datetime_value()),
            "issueSubTypeId": lambda n : setattr(self, 'issue_sub_type_id', n.get_uuid_value()),
            "issueTypeId": lambda n : setattr(self, 'issue_type_id', n.get_uuid_value()),
            "locationDescription": lambda n : setattr(self, 'location_description', n.get_str_value()),
            "locationId": lambda n : setattr(self, 'location_id', n.get_uuid_value()),
            "owner": lambda n : setattr(self, 'owner', n.get_str_value()),
            "pushpin": lambda n : setattr(self, 'pushpin', n.get_object_value(IssuesPostRequestBody_pushpin)),
            "rootCauseId": lambda n : setattr(self, 'root_cause_id', n.get_uuid_value()),
            "screenShots": lambda n : setattr(self, 'screen_shots', n.get_collection_of_primitive_values(str)),
            "status": lambda n : setattr(self, 'status', n.get_enum_value(IssuesPostRequestBody_status)),
            "title": lambda n : setattr(self, 'title', n.get_str_value()),
            "viewContext": lambda n : setattr(self, 'view_context', n.get_collection_of_object_values(IssuesPostRequestBody_viewContext)),
            "viewableName": lambda n : setattr(self, 'viewable_name', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("assignedTo", self.assigned_to)
        writer.write_enum_value("assignedToType", self.assigned_to_type)
        writer.write_collection_of_object_values("customAttributes", self.custom_attributes)
        writer.write_str_value("description", self.description)
        writer.write_str_value("documentVersionUrn", self.document_version_urn)
        writer.write_datetime_value("dueDate", self.due_date)
        writer.write_uuid_value("issueSubTypeId", self.issue_sub_type_id)
        writer.write_uuid_value("issueTypeId", self.issue_type_id)
        writer.write_str_value("locationDescription", self.location_description)
        writer.write_uuid_value("locationId", self.location_id)
        writer.write_str_value("owner", self.owner)
        writer.write_object_value("pushpin", self.pushpin)
        writer.write_uuid_value("rootCauseId", self.root_cause_id)
        writer.write_collection_of_primitive_values("screenShots", self.screen_shots)
        writer.write_enum_value("status", self.status)
        writer.write_str_value("title", self.title)
        writer.write_collection_of_object_values("viewContext", self.view_context)
        writer.write_str_value("viewableName", self.viewable_name)
    

