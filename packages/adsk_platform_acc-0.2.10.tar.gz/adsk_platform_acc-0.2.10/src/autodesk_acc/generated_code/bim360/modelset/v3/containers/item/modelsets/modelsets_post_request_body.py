from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

if TYPE_CHECKING:
    from .modelsets_post_request_body_folders import ModelsetsPostRequestBody_folders

@dataclass
class ModelsetsPostRequestBody(Parsable):
    # A textual description of the model set. Min length: 1 Max length: 1024.
    description: Optional[str] = None
    # A single folder URN that contains a set of document lineages that are added to the model set. Min items: 1 Max items: 1.
    folders: Optional[list[ModelsetsPostRequestBody_folders]] = None
    # Indicates if new versions are created for model set changes.
    is_disabled: Optional[bool] = None
    # The GUID that uniquely identifies the model set. If this value is not supplied a new GUID is created.
    model_set_id: Optional[UUID] = None
    # The name of the model set. This name must be unique within the specified container. Min length: 1 Max length: 64.
    name: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ModelsetsPostRequestBody:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ModelsetsPostRequestBody
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ModelsetsPostRequestBody()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .modelsets_post_request_body_folders import ModelsetsPostRequestBody_folders

        from .modelsets_post_request_body_folders import ModelsetsPostRequestBody_folders

        fields: dict[str, Callable[[Any], None]] = {
            "description": lambda n : setattr(self, 'description', n.get_str_value()),
            "folders": lambda n : setattr(self, 'folders', n.get_collection_of_object_values(ModelsetsPostRequestBody_folders)),
            "isDisabled": lambda n : setattr(self, 'is_disabled', n.get_bool_value()),
            "modelSetId": lambda n : setattr(self, 'model_set_id', n.get_uuid_value()),
            "name": lambda n : setattr(self, 'name', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("description", self.description)
        writer.write_collection_of_object_values("folders", self.folders)
        writer.write_bool_value("isDisabled", self.is_disabled)
        writer.write_uuid_value("modelSetId", self.model_set_id)
        writer.write_str_value("name", self.name)
    

