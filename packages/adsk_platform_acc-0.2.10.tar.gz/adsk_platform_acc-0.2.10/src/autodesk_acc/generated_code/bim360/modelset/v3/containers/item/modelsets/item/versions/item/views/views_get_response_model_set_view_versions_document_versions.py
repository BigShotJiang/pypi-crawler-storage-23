from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .views_get_response_model_set_view_versions_document_versions_document_lineage import ViewsGetResponse_modelSetViewVersions_documentVersions_documentLineage
    from .views_get_response_model_set_view_versions_document_versions_document_status import ViewsGetResponse_modelSetViewVersions_documentVersions_documentStatus
    from .views_get_response_model_set_view_versions_document_versions_forge_type import ViewsGetResponse_modelSetViewVersions_documentVersions_forgeType

@dataclass
class ViewsGetResponse_modelSetViewVersions_documentVersions(Parsable):
    # The URN of the Model Derivative bubble for the document version.
    bubble_urn: Optional[str] = None
    # The date and time that the document version was created.
    create_time: Optional[datetime.datetime] = None
    # The unique identifier of the user who created the document version.
    create_user_id: Optional[str] = None
    # The display name of the document version.
    display_name: Optional[str] = None
    # A document from a model set.
    document_lineage: Optional[ViewsGetResponse_modelSetViewVersions_documentVersions_documentLineage] = None
    # The status of the document. Possible values: ``Succeeded``, ``Failed``, ``Running``, ``Skipped``.
    document_status: Optional[ViewsGetResponse_modelSetViewVersions_documentVersions_documentStatus] = None
    # The forge type associated with this document (used by the Document Management APIs). Possible values: ``versions:autodesk.bim360:Document``, ``versions:autodesk.bim360:File``.
    forge_type: Optional[ViewsGetResponse_modelSetViewVersions_documentVersions_forgeType] = None
    # The name of the seed file version from which this document was originally extracted.
    original_seed_file_version_name: Optional[str] = None
    # The URN of the seed file version from which this document was originally extracted.
    original_seed_file_version_urn: Optional[str] = None
    # The URN of the document version.
    version_urn: Optional[str] = None
    # The ID of the geometry node in the derivative manifest to which this document version refers.
    viewable_guid: Optional[str] = None
    # The ID of the viewable for the document version.
    viewable_id: Optional[str] = None
    # The mime type of the viewable for the document version.
    viewable_mime: Optional[str] = None
    # The name of the viewable in the Model Derivative manifest.
    viewable_name: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ViewsGetResponse_modelSetViewVersions_documentVersions:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ViewsGetResponse_modelSetViewVersions_documentVersions
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ViewsGetResponse_modelSetViewVersions_documentVersions()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .views_get_response_model_set_view_versions_document_versions_document_lineage import ViewsGetResponse_modelSetViewVersions_documentVersions_documentLineage
        from .views_get_response_model_set_view_versions_document_versions_document_status import ViewsGetResponse_modelSetViewVersions_documentVersions_documentStatus
        from .views_get_response_model_set_view_versions_document_versions_forge_type import ViewsGetResponse_modelSetViewVersions_documentVersions_forgeType

        from .views_get_response_model_set_view_versions_document_versions_document_lineage import ViewsGetResponse_modelSetViewVersions_documentVersions_documentLineage
        from .views_get_response_model_set_view_versions_document_versions_document_status import ViewsGetResponse_modelSetViewVersions_documentVersions_documentStatus
        from .views_get_response_model_set_view_versions_document_versions_forge_type import ViewsGetResponse_modelSetViewVersions_documentVersions_forgeType

        fields: dict[str, Callable[[Any], None]] = {
            "bubbleUrn": lambda n : setattr(self, 'bubble_urn', n.get_str_value()),
            "createTime": lambda n : setattr(self, 'create_time', n.get_datetime_value()),
            "createUserId": lambda n : setattr(self, 'create_user_id', n.get_str_value()),
            "displayName": lambda n : setattr(self, 'display_name', n.get_str_value()),
            "documentLineage": lambda n : setattr(self, 'document_lineage', n.get_object_value(ViewsGetResponse_modelSetViewVersions_documentVersions_documentLineage)),
            "documentStatus": lambda n : setattr(self, 'document_status', n.get_enum_value(ViewsGetResponse_modelSetViewVersions_documentVersions_documentStatus)),
            "forgeType": lambda n : setattr(self, 'forge_type', n.get_enum_value(ViewsGetResponse_modelSetViewVersions_documentVersions_forgeType)),
            "originalSeedFileVersionName": lambda n : setattr(self, 'original_seed_file_version_name', n.get_str_value()),
            "originalSeedFileVersionUrn": lambda n : setattr(self, 'original_seed_file_version_urn', n.get_str_value()),
            "versionUrn": lambda n : setattr(self, 'version_urn', n.get_str_value()),
            "viewableGuid": lambda n : setattr(self, 'viewable_guid', n.get_str_value()),
            "viewableId": lambda n : setattr(self, 'viewable_id', n.get_str_value()),
            "viewableMime": lambda n : setattr(self, 'viewable_mime', n.get_str_value()),
            "viewableName": lambda n : setattr(self, 'viewable_name', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("bubbleUrn", self.bubble_urn)
        writer.write_datetime_value("createTime", self.create_time)
        writer.write_str_value("createUserId", self.create_user_id)
        writer.write_str_value("displayName", self.display_name)
        writer.write_object_value("documentLineage", self.document_lineage)
        writer.write_enum_value("documentStatus", self.document_status)
        writer.write_enum_value("forgeType", self.forge_type)
        writer.write_str_value("originalSeedFileVersionName", self.original_seed_file_version_name)
        writer.write_str_value("originalSeedFileVersionUrn", self.original_seed_file_version_urn)
        writer.write_str_value("versionUrn", self.version_urn)
        writer.write_str_value("viewableGuid", self.viewable_guid)
        writer.write_str_value("viewableId", self.viewable_id)
        writer.write_str_value("viewableMime", self.viewable_mime)
        writer.write_str_value("viewableName", self.viewable_name)
    

