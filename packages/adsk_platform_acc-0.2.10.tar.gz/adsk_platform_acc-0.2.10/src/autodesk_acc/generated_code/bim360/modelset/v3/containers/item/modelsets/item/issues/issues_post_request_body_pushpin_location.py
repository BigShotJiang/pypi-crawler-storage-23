from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class IssuesPostRequestBody_pushpin_location(Parsable):
    """
    A vector describing where in 3D space the pushpin is located.
    """
    # The X component of the 3D vector.
    x: Optional[int] = None
    # The Y component of the 3D vector.
    y: Optional[int] = None
    # The Z component of the 3D vector.
    z: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> IssuesPostRequestBody_pushpin_location:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: IssuesPostRequestBody_pushpin_location
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return IssuesPostRequestBody_pushpin_location()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "x": lambda n : setattr(self, 'x', n.get_int_value()),
            "y": lambda n : setattr(self, 'y', n.get_int_value()),
            "z": lambda n : setattr(self, 'z', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_int_value("x", self.x)
        writer.write_int_value("y", self.y)
        writer.write_int_value("z", self.z)
    

