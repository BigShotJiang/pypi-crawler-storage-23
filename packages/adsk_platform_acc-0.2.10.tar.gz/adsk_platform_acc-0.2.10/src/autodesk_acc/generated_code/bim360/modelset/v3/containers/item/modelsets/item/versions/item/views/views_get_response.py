from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .views_get_response_model_set_view_versions import ViewsGetResponse_modelSetViewVersions
    from .views_get_response_page import ViewsGetResponse_page

@dataclass
class ViewsGetResponse(Parsable):
    # The list of model set view versions.
    model_set_view_versions: Optional[list[ViewsGetResponse_modelSetViewVersions]] = None
    # Paging information associated with a paging response.
    page: Optional[ViewsGetResponse_page] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ViewsGetResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ViewsGetResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ViewsGetResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .views_get_response_model_set_view_versions import ViewsGetResponse_modelSetViewVersions
        from .views_get_response_page import ViewsGetResponse_page

        from .views_get_response_model_set_view_versions import ViewsGetResponse_modelSetViewVersions
        from .views_get_response_page import ViewsGetResponse_page

        fields: dict[str, Callable[[Any], None]] = {
            "modelSetViewVersions": lambda n : setattr(self, 'model_set_view_versions', n.get_collection_of_object_values(ViewsGetResponse_modelSetViewVersions)),
            "page": lambda n : setattr(self, 'page', n.get_object_value(ViewsGetResponse_page)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_object_values("modelSetViewVersions", self.model_set_view_versions)
        writer.write_object_value("page", self.page)
    

