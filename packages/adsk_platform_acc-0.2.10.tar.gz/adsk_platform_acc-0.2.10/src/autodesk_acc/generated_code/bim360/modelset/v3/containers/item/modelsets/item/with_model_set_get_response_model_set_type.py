from enum import Enum

class WithModelSetGetResponse_modelSetType(str, Enum):
    Plans = "Plans",
    ProjectFiles = "ProjectFiles",

