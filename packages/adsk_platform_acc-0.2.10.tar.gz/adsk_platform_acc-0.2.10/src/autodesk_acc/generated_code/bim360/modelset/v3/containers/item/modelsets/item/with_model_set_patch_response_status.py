from enum import Enum

class WithModelSetPatchResponse_status(str, Enum):
    Failed = "Failed",
    Running = "Running",
    Succeeded = "Succeeded",
    Archived = "Archived",

