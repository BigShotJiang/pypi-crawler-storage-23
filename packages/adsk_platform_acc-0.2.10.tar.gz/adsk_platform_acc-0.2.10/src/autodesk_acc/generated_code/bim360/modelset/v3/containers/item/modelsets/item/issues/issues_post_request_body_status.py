from enum import Enum

class IssuesPostRequestBody_status(str, Enum):
    Open = "Open",
    Draft = "Draft",

