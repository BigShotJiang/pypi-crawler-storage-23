from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .issues_post_request_body_pushpin_location import IssuesPostRequestBody_pushpin_location
    from .issues_post_request_body_pushpin_type import IssuesPostRequestBody_pushpin_type
    from .issues_post_request_body_pushpin_viewer_state import IssuesPostRequestBody_pushpin_viewerState

@dataclass
class IssuesPostRequestBody_pushpin(Parsable):
    """
    An issue push pin object that describes a visual marker to place an issue on the 3D model.
    """
    # The version of the data described in the viewer state property.
    attributes_version: Optional[int] = None
    # The external ID (for example, derived from the Revit ID) of the object in the viewer with which to link this issue.
    external_id: Optional[str] = None
    # A vector describing where in 3D space the pushpin is located.
    location: Optional[IssuesPostRequestBody_pushpin_location] = None
    # The ID of the object in the viewer with which to link this issue.
    object_id: Optional[int] = None
    # The type of pushpin. Possible values: ``TwoDVectorPushpin``.
    type: Optional[IssuesPostRequestBody_pushpin_type] = None
    # An object describing the current state of the viewer, such as the camera position.
    viewer_state: Optional[IssuesPostRequestBody_pushpin_viewerState] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> IssuesPostRequestBody_pushpin:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: IssuesPostRequestBody_pushpin
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return IssuesPostRequestBody_pushpin()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .issues_post_request_body_pushpin_location import IssuesPostRequestBody_pushpin_location
        from .issues_post_request_body_pushpin_type import IssuesPostRequestBody_pushpin_type
        from .issues_post_request_body_pushpin_viewer_state import IssuesPostRequestBody_pushpin_viewerState

        from .issues_post_request_body_pushpin_location import IssuesPostRequestBody_pushpin_location
        from .issues_post_request_body_pushpin_type import IssuesPostRequestBody_pushpin_type
        from .issues_post_request_body_pushpin_viewer_state import IssuesPostRequestBody_pushpin_viewerState

        fields: dict[str, Callable[[Any], None]] = {
            "attributesVersion": lambda n : setattr(self, 'attributes_version', n.get_int_value()),
            "externalId": lambda n : setattr(self, 'external_id', n.get_str_value()),
            "location": lambda n : setattr(self, 'location', n.get_object_value(IssuesPostRequestBody_pushpin_location)),
            "objectId": lambda n : setattr(self, 'object_id', n.get_int_value()),
            "type": lambda n : setattr(self, 'type', n.get_enum_value(IssuesPostRequestBody_pushpin_type)),
            "viewerState": lambda n : setattr(self, 'viewer_state', n.get_object_value(IssuesPostRequestBody_pushpin_viewerState)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_int_value("attributesVersion", self.attributes_version)
        writer.write_str_value("externalId", self.external_id)
        writer.write_object_value("location", self.location)
        writer.write_int_value("objectId", self.object_id)
        writer.write_enum_value("type", self.type)
        writer.write_object_value("viewerState", self.viewer_state)
    

