from enum import Enum

class ViewsGetResponse_modelSetViewVersions_documentVersions_forgeType(str, Enum):
    VersionsAutodeskBim360Document = "versions:autodesk.bim360:Document",
    VersionsAutodeskBim360File = "versions:autodesk.bim360:File",

