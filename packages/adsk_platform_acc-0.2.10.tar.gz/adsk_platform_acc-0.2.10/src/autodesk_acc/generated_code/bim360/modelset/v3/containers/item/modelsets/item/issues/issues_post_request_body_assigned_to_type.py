from enum import Enum

class IssuesPostRequestBody_assignedToType(str, Enum):
    User = "User",
    Role = "Role",
    Company = "Company",

