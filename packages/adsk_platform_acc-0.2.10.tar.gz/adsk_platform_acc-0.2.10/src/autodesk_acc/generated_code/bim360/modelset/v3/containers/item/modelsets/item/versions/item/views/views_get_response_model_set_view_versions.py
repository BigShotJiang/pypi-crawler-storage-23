from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

if TYPE_CHECKING:
    from .views_get_response_model_set_view_versions_document_versions import ViewsGetResponse_modelSetViewVersions_documentVersions

@dataclass
class ViewsGetResponse_modelSetViewVersions(Parsable):
    # The document versions included in this version of the model set.
    document_versions: Optional[list[ViewsGetResponse_modelSetViewVersions_documentVersions]] = None
    # The GUID that uniquely identifies the model set.
    model_set_id: Optional[UUID] = None
    # The model set version number.
    version: Optional[int] = None
    # The GUID that uniquely identifies the view.
    view_id: Optional[UUID] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ViewsGetResponse_modelSetViewVersions:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ViewsGetResponse_modelSetViewVersions
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ViewsGetResponse_modelSetViewVersions()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .views_get_response_model_set_view_versions_document_versions import ViewsGetResponse_modelSetViewVersions_documentVersions

        from .views_get_response_model_set_view_versions_document_versions import ViewsGetResponse_modelSetViewVersions_documentVersions

        fields: dict[str, Callable[[Any], None]] = {
            "documentVersions": lambda n : setattr(self, 'document_versions', n.get_collection_of_object_values(ViewsGetResponse_modelSetViewVersions_documentVersions)),
            "modelSetId": lambda n : setattr(self, 'model_set_id', n.get_uuid_value()),
            "version": lambda n : setattr(self, 'version', n.get_int_value()),
            "viewId": lambda n : setattr(self, 'view_id', n.get_uuid_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_object_values("documentVersions", self.document_versions)
        writer.write_uuid_value("modelSetId", self.model_set_id)
        writer.write_int_value("version", self.version)
        writer.write_uuid_value("viewId", self.view_id)
    

