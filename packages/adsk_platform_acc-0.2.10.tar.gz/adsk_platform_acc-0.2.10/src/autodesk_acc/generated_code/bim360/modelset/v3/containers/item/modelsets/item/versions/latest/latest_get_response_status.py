from enum import Enum

class LatestGetResponse_status(str, Enum):
    Pending = "Pending",
    Processing = "Processing",
    Successful = "Successful",
    Partial = "Partial",
    Failed = "Failed",

