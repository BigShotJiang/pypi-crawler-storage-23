from enum import Enum

class WithViewDeleteResponse_status(str, Enum):
    Failed = "Failed",
    Running = "Running",
    Succeeded = "Succeeded",
    Archived = "Archived",

