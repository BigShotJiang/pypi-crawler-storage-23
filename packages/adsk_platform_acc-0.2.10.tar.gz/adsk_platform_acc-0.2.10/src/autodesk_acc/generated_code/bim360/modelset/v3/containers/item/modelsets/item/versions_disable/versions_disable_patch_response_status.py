from enum import Enum

class VersionsDisablePatchResponse_status(str, Enum):
    Failed = "Failed",
    Running = "Running",
    Succeeded = "Succeeded",
    Archived = "Archived",

