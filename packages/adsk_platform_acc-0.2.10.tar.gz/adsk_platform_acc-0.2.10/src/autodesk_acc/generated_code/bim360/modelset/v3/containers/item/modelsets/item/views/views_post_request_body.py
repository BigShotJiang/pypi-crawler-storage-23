from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

if TYPE_CHECKING:
    from .views_post_request_body_definition import ViewsPostRequestBody_definition

@dataclass
class ViewsPostRequestBody(Parsable):
    # The definition of models in a model set view, which is used to track the same models through time. Min items: 1 Max items: 1000.
    definition: Optional[list[ViewsPostRequestBody_definition]] = None
    # The description of the model set view. Min length: 1 Max length: 1024.
    description: Optional[str] = None
    # Determines whether the view is only accessible to its creator.
    is_private: Optional[bool] = None
    # The name of the model set view. Min length: 1 Max length: 64.
    name: Optional[str] = None
    # The GUID that uniquely identifies the view.
    view_id: Optional[UUID] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ViewsPostRequestBody:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ViewsPostRequestBody
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ViewsPostRequestBody()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .views_post_request_body_definition import ViewsPostRequestBody_definition

        from .views_post_request_body_definition import ViewsPostRequestBody_definition

        fields: dict[str, Callable[[Any], None]] = {
            "definition": lambda n : setattr(self, 'definition', n.get_collection_of_object_values(ViewsPostRequestBody_definition)),
            "description": lambda n : setattr(self, 'description', n.get_str_value()),
            "isPrivate": lambda n : setattr(self, 'is_private', n.get_bool_value()),
            "name": lambda n : setattr(self, 'name', n.get_str_value()),
            "viewId": lambda n : setattr(self, 'view_id', n.get_uuid_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_object_values("definition", self.definition)
        writer.write_str_value("description", self.description)
        writer.write_bool_value("isPrivate", self.is_private)
        writer.write_str_value("name", self.name)
        writer.write_uuid_value("viewId", self.view_id)
    

