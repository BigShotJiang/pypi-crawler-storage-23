from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

if TYPE_CHECKING:
    from .with_job_get_response_job import WithJobGetResponse_job
    from .with_job_get_response_status import WithJobGetResponse_status

@dataclass
class WithJobGetResponse(Parsable):
    # If this job tracks the creation of assigned clashes, the IDs of the created issues.
    created_issue_ids: Optional[list[str]] = None
    # The GUIDs that uniquely identify the clash groups associated with the job.
    groups: Optional[list[str]] = None
    # A job.
    job: Optional[WithJobGetResponse_job] = None
    # The GUID that uniquely identifies the job.
    job_id: Optional[UUID] = None
    # The current job status. Possible values: ``Failed``, ``Running``, ``Succeeded``, ``Archived``.
    status: Optional[WithJobGetResponse_status] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> WithJobGetResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: WithJobGetResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return WithJobGetResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .with_job_get_response_job import WithJobGetResponse_job
        from .with_job_get_response_status import WithJobGetResponse_status

        from .with_job_get_response_job import WithJobGetResponse_job
        from .with_job_get_response_status import WithJobGetResponse_status

        fields: dict[str, Callable[[Any], None]] = {
            "createdIssueIds": lambda n : setattr(self, 'created_issue_ids', n.get_collection_of_primitive_values(str)),
            "groups": lambda n : setattr(self, 'groups', n.get_collection_of_primitive_values(str)),
            "job": lambda n : setattr(self, 'job', n.get_object_value(WithJobGetResponse_job)),
            "jobId": lambda n : setattr(self, 'job_id', n.get_uuid_value()),
            "status": lambda n : setattr(self, 'status', n.get_enum_value(WithJobGetResponse_status)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_primitive_values("createdIssueIds", self.created_issue_ids)
        writer.write_collection_of_primitive_values("groups", self.groups)
        writer.write_object_value("job", self.job)
        writer.write_uuid_value("jobId", self.job_id)
        writer.write_enum_value("status", self.status)
    

