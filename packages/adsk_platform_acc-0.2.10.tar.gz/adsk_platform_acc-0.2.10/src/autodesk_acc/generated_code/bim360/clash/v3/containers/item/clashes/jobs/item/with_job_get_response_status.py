from enum import Enum

class WithJobGetResponse_status(str, Enum):
    Failed = "Failed",
    Running = "Running",
    Succeeded = "Succeeded",
    Archived = "Archived",

