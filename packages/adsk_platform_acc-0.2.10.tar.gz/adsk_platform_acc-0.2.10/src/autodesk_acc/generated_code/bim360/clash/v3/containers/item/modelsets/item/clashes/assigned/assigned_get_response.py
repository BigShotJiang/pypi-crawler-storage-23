from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .assigned_get_response_groups import AssignedGetResponse_groups
    from .assigned_get_response_page import AssignedGetResponse_page

@dataclass
class AssignedGetResponse(Parsable):
    # The set of assigned clash groups on this page.
    groups: Optional[list[AssignedGetResponse_groups]] = None
    # Paging information associated with a paging response.
    page: Optional[AssignedGetResponse_page] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> AssignedGetResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: AssignedGetResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return AssignedGetResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .assigned_get_response_groups import AssignedGetResponse_groups
        from .assigned_get_response_page import AssignedGetResponse_page

        from .assigned_get_response_groups import AssignedGetResponse_groups
        from .assigned_get_response_page import AssignedGetResponse_page

        fields: dict[str, Callable[[Any], None]] = {
            "groups": lambda n : setattr(self, 'groups', n.get_collection_of_object_values(AssignedGetResponse_groups)),
            "page": lambda n : setattr(self, 'page', n.get_object_value(AssignedGetResponse_page)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_object_values("groups", self.groups)
        writer.write_object_value("page", self.page)
    

