from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

if TYPE_CHECKING:
    from .with_test_get_response_status import WithTestGetResponse_status

@dataclass
class WithTestGetResponse(Parsable):
    # The date and time that the clash test was completed.
    completed_on: Optional[datetime.datetime] = None
    # The GUID that uniquely identifies the clash test.
    id: Optional[UUID] = None
    # The GUID that uniquely identifies the model set associated with the clash test.
    model_set_id: Optional[UUID] = None
    # The version number of the model set associated with the clash test.
    model_set_version: Optional[int] = None
    # The status of the clash test. If the status is ``Success``, the results of the clash test are available for use. Possible values: ``Pending``, ``Processing``, ``Success``, ``Failed``.
    status: Optional[WithTestGetResponse_status] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> WithTestGetResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: WithTestGetResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return WithTestGetResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .with_test_get_response_status import WithTestGetResponse_status

        from .with_test_get_response_status import WithTestGetResponse_status

        fields: dict[str, Callable[[Any], None]] = {
            "completedOn": lambda n : setattr(self, 'completed_on', n.get_datetime_value()),
            "id": lambda n : setattr(self, 'id', n.get_uuid_value()),
            "modelSetId": lambda n : setattr(self, 'model_set_id', n.get_uuid_value()),
            "modelSetVersion": lambda n : setattr(self, 'model_set_version', n.get_int_value()),
            "status": lambda n : setattr(self, 'status', n.get_enum_value(WithTestGetResponse_status)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_datetime_value("completedOn", self.completed_on)
        writer.write_uuid_value("id", self.id)
        writer.write_uuid_value("modelSetId", self.model_set_id)
        writer.write_int_value("modelSetVersion", self.model_set_version)
        writer.write_enum_value("status", self.status)
    

