from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .assigned_post_response_clash_data_clashes import AssignedPostResponse_clashData_clashes
    from .assigned_post_response_clash_data_clash_instances import AssignedPostResponse_clashData_clashInstances
    from .assigned_post_response_clash_data_documents import AssignedPostResponse_clashData_documents

@dataclass
class AssignedPostResponse_clashData(Parsable):
    # The clash instances associated with the clash groups supplied.
    clash_instances: Optional[list[AssignedPostResponse_clashData_clashInstances]] = None
    # The clashes associated with the clash groups supplied.
    clashes: Optional[list[AssignedPostResponse_clashData_clashes]] = None
    # The documents associated with the clash groups supplied.
    documents: Optional[list[AssignedPostResponse_clashData_documents]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> AssignedPostResponse_clashData:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: AssignedPostResponse_clashData
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return AssignedPostResponse_clashData()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .assigned_post_response_clash_data_clashes import AssignedPostResponse_clashData_clashes
        from .assigned_post_response_clash_data_clash_instances import AssignedPostResponse_clashData_clashInstances
        from .assigned_post_response_clash_data_documents import AssignedPostResponse_clashData_documents

        from .assigned_post_response_clash_data_clashes import AssignedPostResponse_clashData_clashes
        from .assigned_post_response_clash_data_clash_instances import AssignedPostResponse_clashData_clashInstances
        from .assigned_post_response_clash_data_documents import AssignedPostResponse_clashData_documents

        fields: dict[str, Callable[[Any], None]] = {
            "clashInstances": lambda n : setattr(self, 'clash_instances', n.get_collection_of_object_values(AssignedPostResponse_clashData_clashInstances)),
            "clashes": lambda n : setattr(self, 'clashes', n.get_collection_of_object_values(AssignedPostResponse_clashData_clashes)),
            "documents": lambda n : setattr(self, 'documents', n.get_collection_of_object_values(AssignedPostResponse_clashData_documents)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_object_values("clashInstances", self.clash_instances)
        writer.write_collection_of_object_values("clashes", self.clashes)
        writer.write_collection_of_object_values("documents", self.documents)
    

