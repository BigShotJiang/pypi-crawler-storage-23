from enum import Enum

class ResourcesGetResponse_resources_extension(str, Enum):
    JsonGz = "json.gz",
    Sqlite = "sqlite",

