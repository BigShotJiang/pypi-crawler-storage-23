from enum import Enum

class ClashesAssignPostRequestBody_assignedToType(str, Enum):
    User = "User",
    Role = "Role",
    Company = "Company",

