from enum import Enum

class WithTestGetResponse_status(str, Enum):
    Success = "Success",
    Pending = "Pending",
    Processing = "Processing",
    Failed = "Failed",

