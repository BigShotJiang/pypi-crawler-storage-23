from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

if TYPE_CHECKING:
    from .assigned_get_response_groups import AssignedGetResponse_groups
    from .assigned_get_response_page import AssignedGetResponse_page

@dataclass
class AssignedGetResponse(Parsable):
    # The list of clash groups intersected with the specified clash test.
    groups: Optional[list[AssignedGetResponse_groups]] = None
    # The GUID that uniquely identifies the model set.
    model_set_id: Optional[UUID] = None
    # The model set version number.
    model_set_version: Optional[int] = None
    # Paging information associated with a paging response.
    page: Optional[AssignedGetResponse_page] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> AssignedGetResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: AssignedGetResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return AssignedGetResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .assigned_get_response_groups import AssignedGetResponse_groups
        from .assigned_get_response_page import AssignedGetResponse_page

        from .assigned_get_response_groups import AssignedGetResponse_groups
        from .assigned_get_response_page import AssignedGetResponse_page

        fields: dict[str, Callable[[Any], None]] = {
            "groups": lambda n : setattr(self, 'groups', n.get_collection_of_object_values(AssignedGetResponse_groups)),
            "modelSetId": lambda n : setattr(self, 'model_set_id', n.get_uuid_value()),
            "modelSetVersion": lambda n : setattr(self, 'model_set_version', n.get_int_value()),
            "page": lambda n : setattr(self, 'page', n.get_object_value(AssignedGetResponse_page)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_object_values("groups", self.groups)
        writer.write_uuid_value("modelSetId", self.model_set_id)
        writer.write_int_value("modelSetVersion", self.model_set_version)
        writer.write_object_value("page", self.page)
    

