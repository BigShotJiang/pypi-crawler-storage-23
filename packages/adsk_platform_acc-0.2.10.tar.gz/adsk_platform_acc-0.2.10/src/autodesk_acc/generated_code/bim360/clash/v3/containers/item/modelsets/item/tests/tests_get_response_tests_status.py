from enum import Enum

class TestsGetResponse_tests_status(str, Enum):
    Success = "Success",
    Pending = "Pending",
    Processing = "Processing",
    Failed = "Failed",

