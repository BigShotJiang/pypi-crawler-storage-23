from enum import Enum

class ClashesAssignPostResponse_status(str, Enum):
    Failed = "Failed",
    Running = "Running",
    Succeeded = "Succeeded",
    Archived = "Archived",

