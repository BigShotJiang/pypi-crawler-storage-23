from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class AssignedPostResponse_clashData_clashInstances(Parsable):
    # The clash ID in the model set version.
    cid: Optional[int] = None
    # The left-hand-side document ID.
    ldid: Optional[int] = None
    # The left-hand-side object ID.
    loid: Optional[int] = None
    # The left-hand-side viewable ID.
    lvid: Optional[int] = None
    # The right-hand-side document ID.
    rdid: Optional[int] = None
    # The right-hand-side object ID.
    roid: Optional[int] = None
    # The left-hand-side viewable ID.
    rvid: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> AssignedPostResponse_clashData_clashInstances:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: AssignedPostResponse_clashData_clashInstances
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return AssignedPostResponse_clashData_clashInstances()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "cid": lambda n : setattr(self, 'cid', n.get_int_value()),
            "ldid": lambda n : setattr(self, 'ldid', n.get_int_value()),
            "loid": lambda n : setattr(self, 'loid', n.get_int_value()),
            "lvid": lambda n : setattr(self, 'lvid', n.get_int_value()),
            "rdid": lambda n : setattr(self, 'rdid', n.get_int_value()),
            "roid": lambda n : setattr(self, 'roid', n.get_int_value()),
            "rvid": lambda n : setattr(self, 'rvid', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_int_value("cid", self.cid)
        writer.write_int_value("ldid", self.ldid)
        writer.write_int_value("loid", self.loid)
        writer.write_int_value("lvid", self.lvid)
        writer.write_int_value("rdid", self.rdid)
        writer.write_int_value("roid", self.roid)
        writer.write_int_value("rvid", self.rvid)
    

