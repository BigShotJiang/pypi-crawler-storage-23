from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

@dataclass
class AssignedGetResponse_groups(Parsable):
    # The model set version number associated with the original clash test.
    created_at_version: Optional[int] = None
    # Clashes contained with the clash group that still exist within the specified clash test.
    existing: Optional[list[int]] = None
    # The unique identifier of the clash group.
    id: Optional[UUID] = None
    # The unique identifier of the clash test originally associated with the clash group.
    original_clash_test_id: Optional[UUID] = None
    # Clashes contained with the clash group that have been resolved.
    resolved: Optional[list[int]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> AssignedGetResponse_groups:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: AssignedGetResponse_groups
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return AssignedGetResponse_groups()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "createdAtVersion": lambda n : setattr(self, 'created_at_version', n.get_int_value()),
            "existing": lambda n : setattr(self, 'existing', n.get_collection_of_primitive_values(int)),
            "id": lambda n : setattr(self, 'id', n.get_uuid_value()),
            "originalClashTestId": lambda n : setattr(self, 'original_clash_test_id', n.get_uuid_value()),
            "resolved": lambda n : setattr(self, 'resolved', n.get_collection_of_primitive_values(int)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_int_value("createdAtVersion", self.created_at_version)
        writer.write_collection_of_primitive_values("existing", self.existing)
        writer.write_uuid_value("id", self.id)
        writer.write_uuid_value("originalClashTestId", self.original_clash_test_id)
        writer.write_collection_of_primitive_values("resolved", self.resolved)
    

