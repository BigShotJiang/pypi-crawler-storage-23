from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .resources_get_response_resources_extension import ResourcesGetResponse_resources_extension
    from .resources_get_response_resources_headers import ResourcesGetResponse_resources_headers

@dataclass
class ResourcesGetResponse_resources(Parsable):
    # The file extension used by the clash test resource. Possible values: ``json.gz``, ``sqlite``.
    extension: Optional[ResourcesGetResponse_resources_extension] = None
    # The headers used to retrieve the clash test resource.
    headers: Optional[ResourcesGetResponse_resources_headers] = None
    # The type of the clash test resource.
    type: Optional[str] = None
    # The URL used to retrieve the clash test resource.
    url: Optional[str] = None
    # The time in UTC that the request will stop working.
    valid_until: Optional[datetime.datetime] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ResourcesGetResponse_resources:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ResourcesGetResponse_resources
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ResourcesGetResponse_resources()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .resources_get_response_resources_extension import ResourcesGetResponse_resources_extension
        from .resources_get_response_resources_headers import ResourcesGetResponse_resources_headers

        from .resources_get_response_resources_extension import ResourcesGetResponse_resources_extension
        from .resources_get_response_resources_headers import ResourcesGetResponse_resources_headers

        fields: dict[str, Callable[[Any], None]] = {
            "extension": lambda n : setattr(self, 'extension', n.get_enum_value(ResourcesGetResponse_resources_extension)),
            "headers": lambda n : setattr(self, 'headers', n.get_object_value(ResourcesGetResponse_resources_headers)),
            "type": lambda n : setattr(self, 'type', n.get_str_value()),
            "url": lambda n : setattr(self, 'url', n.get_str_value()),
            "validUntil": lambda n : setattr(self, 'valid_until', n.get_datetime_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("extension", self.extension)
        writer.write_object_value("headers", self.headers)
        writer.write_str_value("type", self.type)
        writer.write_str_value("url", self.url)
        writer.write_datetime_value("validUntil", self.valid_until)
    

