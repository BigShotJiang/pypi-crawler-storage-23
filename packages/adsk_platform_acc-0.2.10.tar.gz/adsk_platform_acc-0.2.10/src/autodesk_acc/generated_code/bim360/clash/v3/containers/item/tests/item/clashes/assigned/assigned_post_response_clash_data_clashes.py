from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class AssignedPostResponse_clashData_clashes(Parsable):
    # The clash instance index ID. Min items: 2 Max items: 2.
    clash: Optional[list[int]] = None
    # The clash distance.
    dist: Optional[int] = None
    # The clash index ID.
    id: Optional[int] = None
    # The status of the clash.
    status: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> AssignedPostResponse_clashData_clashes:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: AssignedPostResponse_clashData_clashes
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return AssignedPostResponse_clashData_clashes()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "clash": lambda n : setattr(self, 'clash', n.get_collection_of_primitive_values(int)),
            "dist": lambda n : setattr(self, 'dist', n.get_int_value()),
            "id": lambda n : setattr(self, 'id', n.get_int_value()),
            "status": lambda n : setattr(self, 'status', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_primitive_values("clash", self.clash)
        writer.write_int_value("dist", self.dist)
        writer.write_int_value("id", self.id)
        writer.write_str_value("status", self.status)
    

