from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

if TYPE_CHECKING:
    from .closed_get_response_groups_reason import ClosedGetResponse_groups_reason

@dataclass
class ClosedGetResponse_groups(Parsable):
    # The unique identifier of the clash test associated with the closed clash group.
    clash_test_id: Optional[UUID] = None
    # The clashes included in the closed clash group. Min items: 1 Max items: 1000.
    clashes: Optional[list[int]] = None
    # The unique identifier of the user who created the closed clash group.
    created_by: Optional[str] = None
    # The date and time that the closed clash group was created.
    created_on: Optional[datetime.datetime] = None
    # The description of the closed clash group. Max length: 1024.
    description: Optional[str] = None
    # The unique identifier of the closed clash group.
    id: Optional[UUID] = None
    # The reason for closing this clash group. Possible values: ``OTHER``, ``VALID_INTERFACE``, ``VALID_PENETRATION``, ``MINIMAL_OVERLAP``, ``ITEM_CAN_FLEX``, ``MODEL_INACCURACY``, ``FIELD_FIX``.
    reason: Optional[ClosedGetResponse_groups_reason] = None
    # The unique identifiers of screenshots associated with the closed clash group. Max items: 5.
    screen_shots: Optional[list[str]] = None
    # The title of the closed clash group. Max length: 128.
    title: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ClosedGetResponse_groups:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ClosedGetResponse_groups
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ClosedGetResponse_groups()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .closed_get_response_groups_reason import ClosedGetResponse_groups_reason

        from .closed_get_response_groups_reason import ClosedGetResponse_groups_reason

        fields: dict[str, Callable[[Any], None]] = {
            "clashTestId": lambda n : setattr(self, 'clash_test_id', n.get_uuid_value()),
            "clashes": lambda n : setattr(self, 'clashes', n.get_collection_of_primitive_values(int)),
            "createdBy": lambda n : setattr(self, 'created_by', n.get_str_value()),
            "createdOn": lambda n : setattr(self, 'created_on', n.get_datetime_value()),
            "description": lambda n : setattr(self, 'description', n.get_str_value()),
            "id": lambda n : setattr(self, 'id', n.get_uuid_value()),
            "reason": lambda n : setattr(self, 'reason', n.get_enum_value(ClosedGetResponse_groups_reason)),
            "screenShots": lambda n : setattr(self, 'screen_shots', n.get_collection_of_primitive_values(str)),
            "title": lambda n : setattr(self, 'title', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_uuid_value("clashTestId", self.clash_test_id)
        writer.write_collection_of_primitive_values("clashes", self.clashes)
        writer.write_str_value("createdBy", self.created_by)
        writer.write_datetime_value("createdOn", self.created_on)
        writer.write_str_value("description", self.description)
        writer.write_uuid_value("id", self.id)
        writer.write_enum_value("reason", self.reason)
        writer.write_collection_of_primitive_values("screenShots", self.screen_shots)
        writer.write_str_value("title", self.title)
    

