from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

if TYPE_CHECKING:
    from .viewcontext_post_response_clash_group import ViewcontextPostResponse_clashGroup
    from .viewcontext_post_response_documents import ViewcontextPostResponse_documents

@dataclass
class ViewcontextPostResponse(Parsable):
    # A Clash Group.
    clash_group: Optional[list[ViewcontextPostResponse_clashGroup]] = None
    # The list of documents visible when the issue was created.
    documents: Optional[list[ViewcontextPostResponse_documents]] = None
    # The ID of the assigned clash group issue for retrieving the issue.
    issue_id: Optional[UUID] = None
    # The ID of the model set this assigned clash group issue is associated with.
    model_set_id: Optional[UUID] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ViewcontextPostResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ViewcontextPostResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ViewcontextPostResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .viewcontext_post_response_clash_group import ViewcontextPostResponse_clashGroup
        from .viewcontext_post_response_documents import ViewcontextPostResponse_documents

        from .viewcontext_post_response_clash_group import ViewcontextPostResponse_clashGroup
        from .viewcontext_post_response_documents import ViewcontextPostResponse_documents

        fields: dict[str, Callable[[Any], None]] = {
            "clashGroup": lambda n : setattr(self, 'clash_group', n.get_collection_of_object_values(ViewcontextPostResponse_clashGroup)),
            "documents": lambda n : setattr(self, 'documents', n.get_collection_of_object_values(ViewcontextPostResponse_documents)),
            "issueId": lambda n : setattr(self, 'issue_id', n.get_uuid_value()),
            "modelSetId": lambda n : setattr(self, 'model_set_id', n.get_uuid_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_object_values("clashGroup", self.clash_group)
        writer.write_collection_of_object_values("documents", self.documents)
        writer.write_uuid_value("issueId", self.issue_id)
        writer.write_uuid_value("modelSetId", self.model_set_id)
    

