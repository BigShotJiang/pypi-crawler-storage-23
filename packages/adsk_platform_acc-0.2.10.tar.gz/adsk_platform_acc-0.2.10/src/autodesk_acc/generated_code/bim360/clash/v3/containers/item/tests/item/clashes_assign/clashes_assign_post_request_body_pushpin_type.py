from enum import Enum

class ClashesAssignPostRequestBody_pushpin_type(str, Enum):
    TwoDVectorPushpin = "TwoDVectorPushpin",

