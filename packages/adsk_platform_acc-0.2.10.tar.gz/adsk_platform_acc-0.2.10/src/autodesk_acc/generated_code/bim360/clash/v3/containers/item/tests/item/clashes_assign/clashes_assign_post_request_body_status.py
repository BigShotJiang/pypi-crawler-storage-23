from enum import Enum

class ClashesAssignPostRequestBody_status(str, Enum):
    Open = "Open",
    Draft = "Draft",

