from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

@dataclass
class ViewcontextPostResponse_clashGroup(Parsable):
    # The unique identifier of the clash test associated with the assigned clash group.
    clash_test_id: Optional[UUID] = None
    # The clashes included in the assigned clash group. Min items: 1 Max items: 1000.
    clashes: Optional[list[int]] = None
    # The unique identifier of the user who created the assigned clash group.
    created_by: Optional[str] = None
    # The date and time that the assigned clash group was created.
    created_on: Optional[datetime.datetime] = None
    # The unique identifier of the assigned clash group.
    id: Optional[UUID] = None
    # The unique identifier of the issue associated with the assigned clash group.
    issue_id: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ViewcontextPostResponse_clashGroup:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ViewcontextPostResponse_clashGroup
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ViewcontextPostResponse_clashGroup()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "clashTestId": lambda n : setattr(self, 'clash_test_id', n.get_uuid_value()),
            "clashes": lambda n : setattr(self, 'clashes', n.get_collection_of_primitive_values(int)),
            "createdBy": lambda n : setattr(self, 'created_by', n.get_str_value()),
            "createdOn": lambda n : setattr(self, 'created_on', n.get_datetime_value()),
            "id": lambda n : setattr(self, 'id', n.get_uuid_value()),
            "issueId": lambda n : setattr(self, 'issue_id', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_uuid_value("clashTestId", self.clash_test_id)
        writer.write_collection_of_primitive_values("clashes", self.clashes)
        writer.write_str_value("createdBy", self.created_by)
        writer.write_datetime_value("createdOn", self.created_on)
        writer.write_uuid_value("id", self.id)
        writer.write_str_value("issueId", self.issue_id)
    

