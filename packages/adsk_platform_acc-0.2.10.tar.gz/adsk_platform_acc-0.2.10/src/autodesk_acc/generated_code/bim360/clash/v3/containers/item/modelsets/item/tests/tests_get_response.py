from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .tests_get_response_page import TestsGetResponse_page
    from .tests_get_response_tests import TestsGetResponse_tests

@dataclass
class TestsGetResponse(Parsable):
    # Paging information associated with a paging response.
    page: Optional[TestsGetResponse_page] = None
    # A list of clash tests.
    tests: Optional[list[TestsGetResponse_tests]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> TestsGetResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: TestsGetResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return TestsGetResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .tests_get_response_page import TestsGetResponse_page
        from .tests_get_response_tests import TestsGetResponse_tests

        from .tests_get_response_page import TestsGetResponse_page
        from .tests_get_response_tests import TestsGetResponse_tests

        fields: dict[str, Callable[[Any], None]] = {
            "page": lambda n : setattr(self, 'page', n.get_object_value(TestsGetResponse_page)),
            "tests": lambda n : setattr(self, 'tests', n.get_collection_of_object_values(TestsGetResponse_tests)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_object_value("page", self.page)
        writer.write_collection_of_object_values("tests", self.tests)
    

