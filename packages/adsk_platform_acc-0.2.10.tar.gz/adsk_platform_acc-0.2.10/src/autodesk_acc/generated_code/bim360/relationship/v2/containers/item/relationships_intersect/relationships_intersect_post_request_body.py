from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .relationships_intersect_post_request_body_entities import RelationshipsIntersectPostRequestBody_entities
    from .relationships_intersect_post_request_body_with_entities import RelationshipsIntersectPostRequestBody_withEntities

@dataclass
class RelationshipsIntersectPostRequestBody(Parsable):
    # The list of entities to return relationships for.Min items: 1 Max items: 20
    entities: Optional[list[RelationshipsIntersectPostRequestBody_entities]] = None
    # The optional list of entities to filter returned relationships by.Min items: 1 Max items: 20
    with_entities: Optional[list[RelationshipsIntersectPostRequestBody_withEntities]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> RelationshipsIntersectPostRequestBody:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: RelationshipsIntersectPostRequestBody
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return RelationshipsIntersectPostRequestBody()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .relationships_intersect_post_request_body_entities import RelationshipsIntersectPostRequestBody_entities
        from .relationships_intersect_post_request_body_with_entities import RelationshipsIntersectPostRequestBody_withEntities

        from .relationships_intersect_post_request_body_entities import RelationshipsIntersectPostRequestBody_entities
        from .relationships_intersect_post_request_body_with_entities import RelationshipsIntersectPostRequestBody_withEntities

        fields: dict[str, Callable[[Any], None]] = {
            "entities": lambda n : setattr(self, 'entities', n.get_collection_of_object_values(RelationshipsIntersectPostRequestBody_entities)),
            "withEntities": lambda n : setattr(self, 'with_entities', n.get_collection_of_object_values(RelationshipsIntersectPostRequestBody_withEntities)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_object_values("entities", self.entities)
        writer.write_collection_of_object_values("withEntities", self.with_entities)
    

