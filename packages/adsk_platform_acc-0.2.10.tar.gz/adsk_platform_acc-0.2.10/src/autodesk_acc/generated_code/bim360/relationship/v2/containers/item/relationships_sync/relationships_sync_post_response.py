from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .relationships_sync_post_response_current import RelationshipsSyncPostResponse_current
    from .relationships_sync_post_response_deleted import RelationshipsSyncPostResponse_deleted

@dataclass
class RelationshipsSyncPostResponse(Parsable):
    # A set of current data.
    current: Optional[list[RelationshipsSyncPostResponse_current]] = None
    # A set of deleted data.
    deleted: Optional[list[RelationshipsSyncPostResponse_deleted]] = None
    # If set to true, data is available for synchronization using the supplied synchronization token.
    more_data: Optional[bool] = None
    # The token that can be used to obtain data via the synchronization endpoint. If moreData is set to false, you can use this token to resume synchronization at a later point in time.
    next_sync_token: Optional[str] = None
    # If set to true, the data returned by the synchronization endpoint can be used to overwrite local copies.
    overwrite: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> RelationshipsSyncPostResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: RelationshipsSyncPostResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return RelationshipsSyncPostResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .relationships_sync_post_response_current import RelationshipsSyncPostResponse_current
        from .relationships_sync_post_response_deleted import RelationshipsSyncPostResponse_deleted

        from .relationships_sync_post_response_current import RelationshipsSyncPostResponse_current
        from .relationships_sync_post_response_deleted import RelationshipsSyncPostResponse_deleted

        fields: dict[str, Callable[[Any], None]] = {
            "current": lambda n : setattr(self, 'current', n.get_collection_of_object_values(RelationshipsSyncPostResponse_current)),
            "deleted": lambda n : setattr(self, 'deleted', n.get_collection_of_object_values(RelationshipsSyncPostResponse_deleted)),
            "moreData": lambda n : setattr(self, 'more_data', n.get_bool_value()),
            "nextSyncToken": lambda n : setattr(self, 'next_sync_token', n.get_str_value()),
            "overwrite": lambda n : setattr(self, 'overwrite', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_object_values("current", self.current)
        writer.write_collection_of_object_values("deleted", self.deleted)
        writer.write_bool_value("moreData", self.more_data)
        writer.write_str_value("nextSyncToken", self.next_sync_token)
        writer.write_bool_value("overwrite", self.overwrite)
    

