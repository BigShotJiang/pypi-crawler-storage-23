from __future__ import annotations
from collections.abc import Callable
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.request_adapter import RequestAdapter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .relationships.relationships_request_builder import RelationshipsRequestBuilder
    from .relationships_batch.relationships_batch_request_builder import RelationshipsBatchRequestBuilder
    from .relationships_delete.relationships_delete_request_builder import RelationshipsDeleteRequestBuilder
    from .relationships_intersect.relationships_intersect_request_builder import RelationshipsIntersectRequestBuilder
    from .relationships_search.relationships_search_request_builder import RelationshipsSearchRequestBuilder
    from .relationships_sync.relationships_sync_request_builder import RelationshipsSyncRequestBuilder
    from .relationships_sync_status.relationships_sync_status_request_builder import RelationshipsSyncStatusRequestBuilder

class WithContainerItemRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /bim360/relationship/v2/containers/{containerId}
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new WithContainerItemRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/bim360/relationship/v2/containers/{containerId}", path_parameters)
    
    @property
    def relationships(self) -> RelationshipsRequestBuilder:
        """
        The relationships property
        """
        from .relationships.relationships_request_builder import RelationshipsRequestBuilder

        return RelationshipsRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def relationships_batch(self) -> RelationshipsBatchRequestBuilder:
        """
        The relationshipsBatch property
        """
        from .relationships_batch.relationships_batch_request_builder import RelationshipsBatchRequestBuilder

        return RelationshipsBatchRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def relationships_delete(self) -> RelationshipsDeleteRequestBuilder:
        """
        The relationshipsDelete property
        """
        from .relationships_delete.relationships_delete_request_builder import RelationshipsDeleteRequestBuilder

        return RelationshipsDeleteRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def relationships_intersect(self) -> RelationshipsIntersectRequestBuilder:
        """
        The relationshipsIntersect property
        """
        from .relationships_intersect.relationships_intersect_request_builder import RelationshipsIntersectRequestBuilder

        return RelationshipsIntersectRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def relationships_search(self) -> RelationshipsSearchRequestBuilder:
        """
        The relationshipsSearch property
        """
        from .relationships_search.relationships_search_request_builder import RelationshipsSearchRequestBuilder

        return RelationshipsSearchRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def relationships_sync(self) -> RelationshipsSyncRequestBuilder:
        """
        The relationshipsSync property
        """
        from .relationships_sync.relationships_sync_request_builder import RelationshipsSyncRequestBuilder

        return RelationshipsSyncRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def relationships_sync_status(self) -> RelationshipsSyncStatusRequestBuilder:
        """
        The relationshipsSyncStatus property
        """
        from .relationships_sync_status.relationships_sync_status_request_builder import RelationshipsSyncStatusRequestBuilder

        return RelationshipsSyncStatusRequestBuilder(self.request_adapter, self.path_parameters)
    

