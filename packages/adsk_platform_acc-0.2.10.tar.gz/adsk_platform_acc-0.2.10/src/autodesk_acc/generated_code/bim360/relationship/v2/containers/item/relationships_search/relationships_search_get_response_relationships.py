from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

if TYPE_CHECKING:
    from .relationships_search_get_response_relationships_entities import RelationshipsSearchGetResponse_relationships_entities

@dataclass
class RelationshipsSearchGetResponse_relationships(Parsable):
    # The date and time the relationship was created.
    created_on: Optional[datetime.datetime] = None
    # The date and time the relationship was deleted.
    deleted_on: Optional[datetime.datetime] = None
    # The entities contained in the relationship.Min items: 2 Max items: 2
    entities: Optional[list[RelationshipsSearchGetResponse_relationships_entities]] = None
    # The UUID that uniquely identifies the relationship.
    id: Optional[UUID] = None
    # ``true`` if this relationship is deleted.``false`` if this relationship is not deleted.
    is_deleted: Optional[bool] = None
    # ``true`` if this relationship is read only for the current caller.``false`` if this relationship is not read only for the current caller.
    is_read_only: Optional[bool] = None
    # ``true`` if this relationship was created by a service.``false`` if this relationship was not created by a service.
    is_service: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> RelationshipsSearchGetResponse_relationships:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: RelationshipsSearchGetResponse_relationships
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return RelationshipsSearchGetResponse_relationships()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .relationships_search_get_response_relationships_entities import RelationshipsSearchGetResponse_relationships_entities

        from .relationships_search_get_response_relationships_entities import RelationshipsSearchGetResponse_relationships_entities

        fields: dict[str, Callable[[Any], None]] = {
            "createdOn": lambda n : setattr(self, 'created_on', n.get_datetime_value()),
            "deletedOn": lambda n : setattr(self, 'deleted_on', n.get_datetime_value()),
            "entities": lambda n : setattr(self, 'entities', n.get_collection_of_object_values(RelationshipsSearchGetResponse_relationships_entities)),
            "id": lambda n : setattr(self, 'id', n.get_uuid_value()),
            "isDeleted": lambda n : setattr(self, 'is_deleted', n.get_bool_value()),
            "isReadOnly": lambda n : setattr(self, 'is_read_only', n.get_bool_value()),
            "isService": lambda n : setattr(self, 'is_service', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_datetime_value("createdOn", self.created_on)
        writer.write_datetime_value("deletedOn", self.deleted_on)
        writer.write_collection_of_object_values("entities", self.entities)
        writer.write_uuid_value("id", self.id)
        writer.write_bool_value("isDeleted", self.is_deleted)
        writer.write_bool_value("isReadOnly", self.is_read_only)
        writer.write_bool_value("isService", self.is_service)
    

