from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .relationships_sync_status_post_response_errors_errors import RelationshipsSyncStatusPostResponse_errors_errors

@dataclass
class RelationshipsSyncStatusPostResponse_errors(Parsable):
    # A more detailed, human readable description of the error, assuming that this message is not localized and is therefore EN-US. UI consumers can use the error.type value to provide a localized version of this error for presentation.
    detail: Optional[str] = None
    # A set of specific validation errors that need to be fixed.
    errors: Optional[list[RelationshipsSyncStatusPostResponse_errors_errors]] = None
    # An optional reference passed by the caller and returned by the service.
    reference_id: Optional[str] = None
    # The token that can be used to obtain data via the synchronization endpoint.
    sync_token: Optional[str] = None
    # A short title for the error.
    title: Optional[str] = None
    # The error code.
    type: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> RelationshipsSyncStatusPostResponse_errors:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: RelationshipsSyncStatusPostResponse_errors
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return RelationshipsSyncStatusPostResponse_errors()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .relationships_sync_status_post_response_errors_errors import RelationshipsSyncStatusPostResponse_errors_errors

        from .relationships_sync_status_post_response_errors_errors import RelationshipsSyncStatusPostResponse_errors_errors

        fields: dict[str, Callable[[Any], None]] = {
            "detail": lambda n : setattr(self, 'detail', n.get_str_value()),
            "errors": lambda n : setattr(self, 'errors', n.get_collection_of_object_values(RelationshipsSyncStatusPostResponse_errors_errors)),
            "referenceId": lambda n : setattr(self, 'reference_id', n.get_str_value()),
            "syncToken": lambda n : setattr(self, 'sync_token', n.get_str_value()),
            "title": lambda n : setattr(self, 'title', n.get_str_value()),
            "type": lambda n : setattr(self, 'type', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("detail", self.detail)
        writer.write_collection_of_object_values("errors", self.errors)
        writer.write_str_value("referenceId", self.reference_id)
        writer.write_str_value("syncToken", self.sync_token)
        writer.write_str_value("title", self.title)
        writer.write_str_value("type", self.type)
    

