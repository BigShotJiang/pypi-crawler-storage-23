from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class RelationshipsSearchGetResponse_relationships_entities(Parsable):
    # The date and time the entity was created.
    created_on: Optional[datetime.datetime] = None
    # The domain to which the entity belongs.To learn more about domains and entities, see the `Relationship Service Field Guide </en/docs/bim360/v1/overview/field-guide/relationships>`_.Max length: 128
    domain: Optional[str] = None
    # The unique identifier of the entity.Max length: 512
    id: Optional[str] = None
    # The type of entity.Max length: 128
    type: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> RelationshipsSearchGetResponse_relationships_entities:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: RelationshipsSearchGetResponse_relationships_entities
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return RelationshipsSearchGetResponse_relationships_entities()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "createdOn": lambda n : setattr(self, 'created_on', n.get_datetime_value()),
            "domain": lambda n : setattr(self, 'domain', n.get_str_value()),
            "id": lambda n : setattr(self, 'id', n.get_str_value()),
            "type": lambda n : setattr(self, 'type', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_datetime_value("createdOn", self.created_on)
        writer.write_str_value("domain", self.domain)
        writer.write_str_value("id", self.id)
        writer.write_str_value("type", self.type)
    

