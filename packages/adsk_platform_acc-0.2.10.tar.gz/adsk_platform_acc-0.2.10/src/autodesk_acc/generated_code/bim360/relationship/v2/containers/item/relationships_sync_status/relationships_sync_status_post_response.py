from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .relationships_sync_status_post_response_errors import RelationshipsSyncStatusPostResponse_errors
    from .relationships_sync_status_post_response_results import RelationshipsSyncStatusPostResponse_results

@dataclass
class RelationshipsSyncStatusPostResponse(Parsable):
    # The array of errors associated with the request for sync tokens.
    errors: Optional[list[RelationshipsSyncStatusPostResponse_errors]] = None
    # The array of sync tokens.
    results: Optional[list[RelationshipsSyncStatusPostResponse_results]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> RelationshipsSyncStatusPostResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: RelationshipsSyncStatusPostResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return RelationshipsSyncStatusPostResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .relationships_sync_status_post_response_errors import RelationshipsSyncStatusPostResponse_errors
        from .relationships_sync_status_post_response_results import RelationshipsSyncStatusPostResponse_results

        from .relationships_sync_status_post_response_errors import RelationshipsSyncStatusPostResponse_errors
        from .relationships_sync_status_post_response_results import RelationshipsSyncStatusPostResponse_results

        fields: dict[str, Callable[[Any], None]] = {
            "errors": lambda n : setattr(self, 'errors', n.get_collection_of_object_values(RelationshipsSyncStatusPostResponse_errors)),
            "results": lambda n : setattr(self, 'results', n.get_collection_of_object_values(RelationshipsSyncStatusPostResponse_results)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_object_values("errors", self.errors)
        writer.write_collection_of_object_values("results", self.results)
    

