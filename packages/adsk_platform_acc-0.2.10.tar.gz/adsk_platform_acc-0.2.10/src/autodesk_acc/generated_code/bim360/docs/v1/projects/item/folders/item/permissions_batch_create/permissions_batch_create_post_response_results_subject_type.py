from enum import Enum

class PermissionsBatchCreatePostResponse_results_subjectType(str, Enum):
    USER = "USER",
    COMPANY = "COMPANY",
    ROLE = "ROLE",

