from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .versions_batch_get_post_response_results_approval_status_value import VersionsBatchGetPostResponse_results_approvalStatus_value

@dataclass
class VersionsBatchGetPostResponse_results_approvalStatus(Parsable):
    """
    The approval status of the version. Only available when the review has been approved or rejected. For more information about the approval workflow, see the `Approval Workflows and Document Review <http://help.autodesk.com/view/BIM360D/ENU/?guid=GUID-2CC9A86E-2F4F-48EB-8EFA-FAA5FBECC20E>`_ documentation.
    """
    # The customized label of the approval status.Max length: 255
    label: Optional[str] = None
    # The value of the approval status.Possible values: ``approved``, ``rejected``
    value: Optional[VersionsBatchGetPostResponse_results_approvalStatus_value] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> VersionsBatchGetPostResponse_results_approvalStatus:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: VersionsBatchGetPostResponse_results_approvalStatus
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return VersionsBatchGetPostResponse_results_approvalStatus()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .versions_batch_get_post_response_results_approval_status_value import VersionsBatchGetPostResponse_results_approvalStatus_value

        from .versions_batch_get_post_response_results_approval_status_value import VersionsBatchGetPostResponse_results_approvalStatus_value

        fields: dict[str, Callable[[Any], None]] = {
            "label": lambda n : setattr(self, 'label', n.get_str_value()),
            "value": lambda n : setattr(self, 'value', n.get_enum_value(VersionsBatchGetPostResponse_results_approvalStatus_value)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("label", self.label)
        writer.write_enum_value("value", self.value)
    

