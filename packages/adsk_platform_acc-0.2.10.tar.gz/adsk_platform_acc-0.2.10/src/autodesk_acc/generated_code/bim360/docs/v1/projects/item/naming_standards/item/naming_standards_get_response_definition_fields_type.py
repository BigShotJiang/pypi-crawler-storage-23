from enum import Enum

class NamingStandardsGetResponse_definition_fields_type(str, Enum):
    ALPHANUMERIC = "ALPHANUMERIC",
    NONNUMERIC_TEXT = "NONNUMERIC_TEXT",
    NUMERIC = "NUMERIC",
    ARRAY = "ARRAY",

