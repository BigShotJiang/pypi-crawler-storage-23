from __future__ import annotations
from collections.abc import Callable
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.request_adapter import RequestAdapter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .item.with_folder_item_request_builder import WithFolder_ItemRequestBuilder

class FoldersRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /bim360/docs/v1/projects/{project-id}/folders
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new FoldersRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/bim360/docs/v1/projects/{project%2Did}/folders", path_parameters)
    
    def by_folder_id(self,folder_id: str) -> WithFolder_ItemRequestBuilder:
        """
        Gets an item from the Autodesk.ACC.bim360.docs.v1.projects.item.folders.item collection
        param folder_id: The ID (URN) of the folder.For details about how to find the URN, follow the initial steps (1-3) in the `Download Files </en/docs/bim360/v1/tutorials/document-management/download-document-s3/>`_ tutorial.
        Returns: WithFolder_ItemRequestBuilder
        """
        if folder_id is None:
            raise TypeError("folder_id cannot be null.")
        from .item.with_folder_item_request_builder import WithFolder_ItemRequestBuilder

        url_tpl_params = get_path_parameters(self.path_parameters)
        url_tpl_params["folder_id"] = folder_id
        return WithFolder_ItemRequestBuilder(self.request_adapter, url_tpl_params)
    

