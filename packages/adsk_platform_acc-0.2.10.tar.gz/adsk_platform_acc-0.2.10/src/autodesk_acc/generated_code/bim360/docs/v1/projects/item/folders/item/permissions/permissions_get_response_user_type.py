from enum import Enum

class PermissionsGetResponse_userType(str, Enum):
    PROJECT_ADMIN = "PROJECT_ADMIN",
    PROJECT_MEMBER = "PROJECT_MEMBER",

