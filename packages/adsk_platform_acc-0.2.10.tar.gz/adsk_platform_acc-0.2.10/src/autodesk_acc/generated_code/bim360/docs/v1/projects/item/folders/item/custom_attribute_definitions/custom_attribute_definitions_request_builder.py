from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from warnings import warn

if TYPE_CHECKING:
    from .custom_attribute_definitions_get_response import CustomAttributeDefinitionsGetResponse
    from .custom_attribute_definitions_post_request_body import CustomAttributeDefinitionsPostRequestBody
    from .custom_attribute_definitions_post_response import CustomAttributeDefinitionsPostResponse

class CustomAttributeDefinitionsRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /bim360/docs/v1/projects/{project-id}/folders/{folder_id}/custom-attribute-definitions
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new CustomAttributeDefinitionsRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/bim360/docs/v1/projects/{project%2Did}/folders/{folder_id}/custom-attribute-definitions{?limit*,offset*}", path_parameters)
    
    async def get(self,request_configuration: Optional[RequestConfiguration[CustomAttributeDefinitionsRequestBuilderGetQueryParameters]] = None) -> Optional[CustomAttributeDefinitionsGetResponse]:
        """
        To retrieve the values that were assigned to a document's custom attributes, call `POST versions:batch-get </en/docs/bim360/v1/reference/http/document-management-versionsbatch-get-POST/>`_.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[CustomAttributeDefinitionsGetResponse]
        """
        request_info = self.to_get_request_information(
            request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from .custom_attribute_definitions_get_response import CustomAttributeDefinitionsGetResponse

        return await self.request_adapter.send_async(request_info, CustomAttributeDefinitionsGetResponse, None)
    
    async def post(self,body: CustomAttributeDefinitionsPostRequestBody, request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> Optional[CustomAttributeDefinitionsPostResponse]:
        """
        Adds a custom attribute to a folder.
        param body: The request body
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[CustomAttributeDefinitionsPostResponse]
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = self.to_post_request_information(
            body, request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from .custom_attribute_definitions_post_response import CustomAttributeDefinitionsPostResponse

        return await self.request_adapter.send_async(request_info, CustomAttributeDefinitionsPostResponse, None)
    
    def to_get_request_information(self,request_configuration: Optional[RequestConfiguration[CustomAttributeDefinitionsRequestBuilderGetQueryParameters]] = None) -> RequestInformation:
        """
        To retrieve the values that were assigned to a document's custom attributes, call `POST versions:batch-get </en/docs/bim360/v1/reference/http/document-management-versionsbatch-get-POST/>`_.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        request_info = RequestInformation(Method.GET, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        return request_info
    
    def to_post_request_information(self,body: CustomAttributeDefinitionsPostRequestBody, request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> RequestInformation:
        """
        Adds a custom attribute to a folder.
        param body: The request body
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = RequestInformation(Method.POST, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        request_info.set_content_from_parsable(self.request_adapter, "application/json", body)
        return request_info
    
    def with_url(self,raw_url: str) -> CustomAttributeDefinitionsRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: CustomAttributeDefinitionsRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return CustomAttributeDefinitionsRequestBuilder(self.request_adapter, raw_url)
    
    @dataclass
    class CustomAttributeDefinitionsRequestBuilderGetQueryParameters():
        """
        To retrieve the values that were assigned to a document's custom attributes, call `POST versions:batch-get </en/docs/bim360/v1/reference/http/document-management-versionsbatch-get-POST/>`_.
        """
        # The number of results to return in the response. Acceptable values: 1-200. Default value: 10. For example, to limit the response to two custom attributes per page, use ``limit=2``.
        limit: Optional[int] = None

        # The item number that you want to begin results from. Default value: 0. For example, to begin the results from item three, use ``offset=3``.
        offset: Optional[int] = None

    
    @dataclass
    class CustomAttributeDefinitionsRequestBuilderGetRequestConfiguration(RequestConfiguration[CustomAttributeDefinitionsRequestBuilderGetQueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    
    @dataclass
    class CustomAttributeDefinitionsRequestBuilderPostRequestConfiguration(RequestConfiguration[QueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

