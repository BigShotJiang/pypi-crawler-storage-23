from __future__ import annotations
from collections.abc import Callable
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.request_adapter import RequestAdapter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .folders.folders_request_builder import FoldersRequestBuilder
    from .naming_standards.naming_standards_request_builder import NamingStandardsRequestBuilder
    from .versions.versions_request_builder import VersionsRequestBuilder
    from .versions_batch_get.versions_batch_get_request_builder import VersionsBatchGetRequestBuilder

class ProjectItemRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /bim360/docs/v1/projects/{project-id}
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new ProjectItemRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/bim360/docs/v1/projects/{project%2Did}", path_parameters)
    
    @property
    def folders(self) -> FoldersRequestBuilder:
        """
        The folders property
        """
        from .folders.folders_request_builder import FoldersRequestBuilder

        return FoldersRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def naming_standards(self) -> NamingStandardsRequestBuilder:
        """
        The namingStandards property
        """
        from .naming_standards.naming_standards_request_builder import NamingStandardsRequestBuilder

        return NamingStandardsRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def versions(self) -> VersionsRequestBuilder:
        """
        The versions property
        """
        from .versions.versions_request_builder import VersionsRequestBuilder

        return VersionsRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def versions_batch_get(self) -> VersionsBatchGetRequestBuilder:
        """
        The versionsBatchGet property
        """
        from .versions_batch_get.versions_batch_get_request_builder import VersionsBatchGetRequestBuilder

        return VersionsBatchGetRequestBuilder(self.request_adapter, self.path_parameters)
    

