from enum import Enum

class PermissionsBatchCreatePostRequestBody_subjectType(str, Enum):
    USER = "USER",
    COMPANY = "COMPANY",
    ROLE = "ROLE",

