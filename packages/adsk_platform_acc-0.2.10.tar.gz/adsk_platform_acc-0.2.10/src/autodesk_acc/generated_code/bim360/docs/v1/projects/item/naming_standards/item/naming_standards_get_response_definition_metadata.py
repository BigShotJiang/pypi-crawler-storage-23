from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .naming_standards_get_response_definition_metadata_options import NamingStandardsGetResponse_definition_metadata_options
    from .naming_standards_get_response_definition_metadata_type import NamingStandardsGetResponse_definition_metadata_type

@dataclass
class NamingStandardsGetResponse_definition_metadata(Parsable):
    # The ID of the related attribute.
    attribute_id: Optional[float] = None
    # The default value of the related attribute.
    default_value: Optional[str] = None
    # A description of the related attribute.Max length: 255
    description: Optional[str] = None
    # The maximum length of the related attribute.Max number of characters: 10
    max_length: Optional[float] = None
    # The minimum length of the related attribute.Min number of characters: 1
    min_length: Optional[float] = None
    # The name of the related attribute.Max length: 32
    name: Optional[str] = None
    # ``true``: this related attribute is required.``false``: this related attribute is not required.
    optional: Optional[bool] = None
    # A drop-down list of possible values for the related attribute.Only relevant for a related attribute of type ``ARRAY`` (drop-down list).
    options: Optional[list[NamingStandardsGetResponse_definition_metadata_options]] = None
    # The related attribute type.Possible values:- ``ALPHANUMERIC``: Accepts all characters.- ``NONNUMERIC_TEXT``: Accepts all characters, excluding ``0-9``.- ``NUMERIC``: Includes ``0-9``, comma ``','``, plus ``'+'``, minus ``'-'``, percent ``'%'``, period ``'.'``, underscore ``'_'``.- ``ARRAY``: A drop-down list.- ``CLASSIFICATION``: Only relevant for a classification attribute.Note that the ``minLength`` and ``maxLength`` properties are not included in the response for the ``ARRAY`` type.
    type: Optional[NamingStandardsGetResponse_definition_metadata_type] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> NamingStandardsGetResponse_definition_metadata:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: NamingStandardsGetResponse_definition_metadata
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return NamingStandardsGetResponse_definition_metadata()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .naming_standards_get_response_definition_metadata_options import NamingStandardsGetResponse_definition_metadata_options
        from .naming_standards_get_response_definition_metadata_type import NamingStandardsGetResponse_definition_metadata_type

        from .naming_standards_get_response_definition_metadata_options import NamingStandardsGetResponse_definition_metadata_options
        from .naming_standards_get_response_definition_metadata_type import NamingStandardsGetResponse_definition_metadata_type

        fields: dict[str, Callable[[Any], None]] = {
            "attributeId": lambda n : setattr(self, 'attribute_id', n.get_float_value()),
            "defaultValue": lambda n : setattr(self, 'default_value', n.get_str_value()),
            "description": lambda n : setattr(self, 'description', n.get_str_value()),
            "maxLength": lambda n : setattr(self, 'max_length', n.get_float_value()),
            "minLength": lambda n : setattr(self, 'min_length', n.get_float_value()),
            "name": lambda n : setattr(self, 'name', n.get_str_value()),
            "optional": lambda n : setattr(self, 'optional', n.get_bool_value()),
            "options": lambda n : setattr(self, 'options', n.get_collection_of_object_values(NamingStandardsGetResponse_definition_metadata_options)),
            "type": lambda n : setattr(self, 'type', n.get_enum_value(NamingStandardsGetResponse_definition_metadata_type)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_float_value("attributeId", self.attribute_id)
        writer.write_str_value("defaultValue", self.default_value)
        writer.write_str_value("description", self.description)
        writer.write_float_value("maxLength", self.max_length)
        writer.write_float_value("minLength", self.min_length)
        writer.write_str_value("name", self.name)
        writer.write_bool_value("optional", self.optional)
        writer.write_collection_of_object_values("options", self.options)
        writer.write_enum_value("type", self.type)
    

