from enum import Enum

class CustomAttributeDefinitionsPostRequestBody_type(str, Enum):
    String = "string",
    Date = "date",
    Array = "array",

