from __future__ import annotations
from collections.abc import Callable
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.request_adapter import RequestAdapter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

if TYPE_CHECKING:
    from .item.naming_standards_item_request_builder import NamingStandardsItemRequestBuilder

class NamingStandardsRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /bim360/docs/v1/projects/{project-id}/naming-standards
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new NamingStandardsRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/bim360/docs/v1/projects/{project%2Did}/naming-standards", path_parameters)
    
    def by_id(self,id: UUID) -> NamingStandardsItemRequestBuilder:
        """
        Gets an item from the Autodesk.ACC.bim360.docs.v1.projects.item.namingStandards.item collection
        param id: The ID of the file naming standard.The file naming standard is applied to the project files folder or its subfolders. To find the ID:- For the project files folder, call `GET hubs/:hub_id/projects/:project_id/topFolders </en/docs/data/v2/reference/http/hubs-hub_id-projects-project_id-topFolders-GET/>`_.- For subfolders, call `GET projects/:project_id/folders/:folder_id/contents </en/docs/data/v2/reference/http/projects-project_id-folders-folder_id-contents-GET/>`_.- For a specific folder, call `GET projects/:project_id/folders/:folder_id </en/docs/data/v2/reference/http/projects-project_id-folders-folder_id-GET/>`_.The ID is under ``data.attributes.extension.data.namingStandardIds``.
        Returns: NamingStandardsItemRequestBuilder
        """
        if id is None:
            raise TypeError("id cannot be null.")
        from .item.naming_standards_item_request_builder import NamingStandardsItemRequestBuilder

        url_tpl_params = get_path_parameters(self.path_parameters)
        url_tpl_params["id"] = id
        return NamingStandardsItemRequestBuilder(self.request_adapter, url_tpl_params)
    

