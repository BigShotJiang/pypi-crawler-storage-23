from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .custom_attribute_definitions_get_response_results_type import CustomAttributeDefinitionsGetResponse_results_type

@dataclass
class CustomAttributeDefinitionsGetResponse_results(Parsable):
    # A list of possible values for the attribute. Only relevant for drop-list attributes.
    array_values: Optional[list[str]] = None
    # The ID of the attribute.
    id: Optional[int] = None
    # The name of the attribute.
    name: Optional[str] = None
    # The type of attribute. Possible values: ``string`` (text field), ``date``, ``array`` (drop-list).
    type: Optional[CustomAttributeDefinitionsGetResponse_results_type] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> CustomAttributeDefinitionsGetResponse_results:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: CustomAttributeDefinitionsGetResponse_results
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return CustomAttributeDefinitionsGetResponse_results()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .custom_attribute_definitions_get_response_results_type import CustomAttributeDefinitionsGetResponse_results_type

        from .custom_attribute_definitions_get_response_results_type import CustomAttributeDefinitionsGetResponse_results_type

        fields: dict[str, Callable[[Any], None]] = {
            "arrayValues": lambda n : setattr(self, 'array_values', n.get_collection_of_primitive_values(str)),
            "id": lambda n : setattr(self, 'id', n.get_int_value()),
            "name": lambda n : setattr(self, 'name', n.get_str_value()),
            "type": lambda n : setattr(self, 'type', n.get_enum_value(CustomAttributeDefinitionsGetResponse_results_type)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_primitive_values("arrayValues", self.array_values)
        writer.write_int_value("id", self.id)
        writer.write_str_value("name", self.name)
        writer.write_enum_value("type", self.type)
    

