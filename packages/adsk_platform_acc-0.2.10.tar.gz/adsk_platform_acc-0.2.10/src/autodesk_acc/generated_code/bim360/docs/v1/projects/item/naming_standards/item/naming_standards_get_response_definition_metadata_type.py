from enum import Enum

class NamingStandardsGetResponse_definition_metadata_type(str, Enum):
    ALPHANUMERIC = "ALPHANUMERIC",
    NONNUMERIC_TEXT = "NONNUMERIC_TEXT",
    NUMERIC = "NUMERIC",
    ARRAY = "ARRAY",
    CLASSIFICATION = "CLASSIFICATION",

