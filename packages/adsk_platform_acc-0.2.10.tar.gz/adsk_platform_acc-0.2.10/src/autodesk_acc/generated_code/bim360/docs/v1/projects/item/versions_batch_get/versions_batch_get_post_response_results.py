from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .versions_batch_get_post_response_results_approval_status import VersionsBatchGetPostResponse_results_approvalStatus
    from .versions_batch_get_post_response_results_custom_attributes import VersionsBatchGetPostResponse_results_customAttributes
    from .versions_batch_get_post_response_results_entity_type import VersionsBatchGetPostResponse_results_entityType
    from .versions_batch_get_post_response_results_process_state import VersionsBatchGetPostResponse_results_processState

@dataclass
class VersionsBatchGetPostResponse_results(Parsable):
    # The approval status of the version. Only available when the review has been approved or rejected. For more information about the approval workflow, see the `Approval Workflows and Document Review <http://help.autodesk.com/view/BIM360D/ENU/?guid=GUID-2CC9A86E-2F4F-48EB-8EFA-FAA5FBECC20E>`_ documentation.
    approval_status: Optional[VersionsBatchGetPostResponse_results_approvalStatus] = None
    # The time and date the version was created.
    create_time: Optional[str] = None
    # The ID of the user who created the version.
    create_user_id: Optional[str] = None
    # The name of the user who created the version.
    create_user_name: Optional[str] = None
    # The list of custom attributes for each document. For more information about custom attributes, see the `Customize Documents with Attributes <http://help.autodesk.com/view/BIM360D/ENU/?guid=GUID-244FAB32-8E3B-4D1B-A1EB-C982DB93ABB3>`_ documentation.
    custom_attributes: Optional[list[VersionsBatchGetPostResponse_results_customAttributes]] = None
    # The type of version. Possible values:- ``SEED_FILE``: Documents that were not split into sheets when they were uploaded to BIM 360 Document Management.- ``DOCUMENT``: Documents that were split into sheets when they were uploaded to BIM 360 Document Management.
    entity_type: Optional[VersionsBatchGetPostResponse_results_entityType] = None
    # The ID of the related item.
    item_urn: Optional[str] = None
    # The time and date the version was last modified.
    last_modified_time: Optional[str] = None
    # The ID of the user who last modified the version.
    last_modified_user_id: Optional[str] = None
    # The name of the user who last modified the version.
    last_modified_user_name: Optional[str] = None
    # The name of the version. This corresponds to the file name in BIM 360 Document Management.
    name: Optional[str] = None
    # The sheet number. This is only relevant for documents uploaded to the Plans folder that were split into sheets.
    number: Optional[str] = None
    # The process state of the version.Possible values: ``NEEDS_PROCESSING``, ``PROCESSING``, ``PREVIOUS_SEED_PENDING``, ``EXTRACTION_PENDING``, ``SPLITTING``, ``PREVIOUS_DOC_PENDING``, ``PROCESSING_ABORTING``, ``PROCESSING_ABORTED``, ``PROCESSING_COMPLETE``, ``PROCESSING_PROMOTION``, ``PROCESSING_COPY``, ``PROCESSING_PROMOTING``, ``PROCESSING_COPYING``, ``PROCESSING_SUSPEND``
    process_state: Optional[VersionsBatchGetPostResponse_results_processState] = None
    # The revision number of the version. The revision number increases when you completely replace the version. For example when you reupload a document and overwrite the current document. Note that this is not the same as the version number, which increases when you update the document. For example, when you save the document. The revision number corresponds to the version in BIM 360 Document Management.
    revision_number: Optional[int] = None
    # The file size of the version's storage object, in bytes. This is only relevant for documents that were not split into sheets when they were uploaded to BIM 360 Document Management.
    storage_size: Optional[int] = None
    # The ID of the version's storage object. This is only relevant for documents that were not split into sheets when they were uploaded to BIM 360 Document Management.
    storage_urn: Optional[str] = None
    # The title of the version.
    title: Optional[str] = None
    # The ID of the version.
    urn: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> VersionsBatchGetPostResponse_results:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: VersionsBatchGetPostResponse_results
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return VersionsBatchGetPostResponse_results()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .versions_batch_get_post_response_results_approval_status import VersionsBatchGetPostResponse_results_approvalStatus
        from .versions_batch_get_post_response_results_custom_attributes import VersionsBatchGetPostResponse_results_customAttributes
        from .versions_batch_get_post_response_results_entity_type import VersionsBatchGetPostResponse_results_entityType
        from .versions_batch_get_post_response_results_process_state import VersionsBatchGetPostResponse_results_processState

        from .versions_batch_get_post_response_results_approval_status import VersionsBatchGetPostResponse_results_approvalStatus
        from .versions_batch_get_post_response_results_custom_attributes import VersionsBatchGetPostResponse_results_customAttributes
        from .versions_batch_get_post_response_results_entity_type import VersionsBatchGetPostResponse_results_entityType
        from .versions_batch_get_post_response_results_process_state import VersionsBatchGetPostResponse_results_processState

        fields: dict[str, Callable[[Any], None]] = {
            "approvalStatus": lambda n : setattr(self, 'approval_status', n.get_object_value(VersionsBatchGetPostResponse_results_approvalStatus)),
            "createTime": lambda n : setattr(self, 'create_time', n.get_str_value()),
            "createUserId": lambda n : setattr(self, 'create_user_id', n.get_str_value()),
            "createUserName": lambda n : setattr(self, 'create_user_name', n.get_str_value()),
            "customAttributes": lambda n : setattr(self, 'custom_attributes', n.get_collection_of_object_values(VersionsBatchGetPostResponse_results_customAttributes)),
            "entityType": lambda n : setattr(self, 'entity_type', n.get_enum_value(VersionsBatchGetPostResponse_results_entityType)),
            "itemUrn": lambda n : setattr(self, 'item_urn', n.get_str_value()),
            "lastModifiedTime": lambda n : setattr(self, 'last_modified_time', n.get_str_value()),
            "lastModifiedUserId": lambda n : setattr(self, 'last_modified_user_id', n.get_str_value()),
            "lastModifiedUserName": lambda n : setattr(self, 'last_modified_user_name', n.get_str_value()),
            "name": lambda n : setattr(self, 'name', n.get_str_value()),
            "number": lambda n : setattr(self, 'number', n.get_str_value()),
            "processState": lambda n : setattr(self, 'process_state', n.get_enum_value(VersionsBatchGetPostResponse_results_processState)),
            "revisionNumber": lambda n : setattr(self, 'revision_number', n.get_int_value()),
            "storageSize": lambda n : setattr(self, 'storage_size', n.get_int_value()),
            "storageUrn": lambda n : setattr(self, 'storage_urn', n.get_str_value()),
            "title": lambda n : setattr(self, 'title', n.get_str_value()),
            "urn": lambda n : setattr(self, 'urn', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_object_value("approvalStatus", self.approval_status)
        writer.write_str_value("createTime", self.create_time)
        writer.write_str_value("createUserId", self.create_user_id)
        writer.write_str_value("createUserName", self.create_user_name)
        writer.write_collection_of_object_values("customAttributes", self.custom_attributes)
        writer.write_enum_value("entityType", self.entity_type)
        writer.write_str_value("itemUrn", self.item_urn)
        writer.write_str_value("lastModifiedTime", self.last_modified_time)
        writer.write_str_value("lastModifiedUserId", self.last_modified_user_id)
        writer.write_str_value("lastModifiedUserName", self.last_modified_user_name)
        writer.write_str_value("name", self.name)
        writer.write_str_value("number", self.number)
        writer.write_enum_value("processState", self.process_state)
        writer.write_int_value("revisionNumber", self.revision_number)
        writer.write_int_value("storageSize", self.storage_size)
        writer.write_str_value("storageUrn", self.storage_urn)
        writer.write_str_value("title", self.title)
        writer.write_str_value("urn", self.urn)
    

