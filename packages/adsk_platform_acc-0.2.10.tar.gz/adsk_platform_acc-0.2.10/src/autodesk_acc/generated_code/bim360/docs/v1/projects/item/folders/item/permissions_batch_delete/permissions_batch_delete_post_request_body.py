from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

if TYPE_CHECKING:
    from .permissions_batch_delete_post_request_body_subject_type import PermissionsBatchDeletePostRequestBody_subjectType

@dataclass
class PermissionsBatchDeletePostRequestBody(Parsable):
    # The Autodesk ID of the user, role or company.
    autodesk_id: Optional[str] = None
    # The ID of the user, role, or company. To verify the subjectId of the user, role, or company, use `GET permissions </en/docs/bim360/v1/reference/http/document-management-projects-project_id-folders-folder_id-permissions-GET>`_.
    subject_id: Optional[UUID] = None
    # The type of subject.Possible values: ``USER``, ``COMPANY``, ``ROLE``
    subject_type: Optional[PermissionsBatchDeletePostRequestBody_subjectType] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> PermissionsBatchDeletePostRequestBody:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: PermissionsBatchDeletePostRequestBody
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return PermissionsBatchDeletePostRequestBody()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .permissions_batch_delete_post_request_body_subject_type import PermissionsBatchDeletePostRequestBody_subjectType

        from .permissions_batch_delete_post_request_body_subject_type import PermissionsBatchDeletePostRequestBody_subjectType

        fields: dict[str, Callable[[Any], None]] = {
            "autodeskId": lambda n : setattr(self, 'autodesk_id', n.get_str_value()),
            "subjectId": lambda n : setattr(self, 'subject_id', n.get_uuid_value()),
            "subjectType": lambda n : setattr(self, 'subject_type', n.get_enum_value(PermissionsBatchDeletePostRequestBody_subjectType)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("autodeskId", self.autodesk_id)
        writer.write_uuid_value("subjectId", self.subject_id)
        writer.write_enum_value("subjectType", self.subject_type)
    

