from enum import Enum

class PermissionsBatchDeletePostRequestBody_subjectType(str, Enum):
    USER = "USER",
    COMPANY = "COMPANY",
    ROLE = "ROLE",

