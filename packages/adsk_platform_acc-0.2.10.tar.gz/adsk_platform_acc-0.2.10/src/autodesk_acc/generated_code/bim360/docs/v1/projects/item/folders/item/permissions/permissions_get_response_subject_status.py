from enum import Enum

class PermissionsGetResponse_subjectStatus(str, Enum):
    INACTIVE = "INACTIVE",
    ACTIVE = "ACTIVE",
    PENDING = "PENDING",
    DISABLED = "DISABLED",

