from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

if TYPE_CHECKING:
    from .permissions_get_response_subject_status import PermissionsGetResponse_subjectStatus
    from .permissions_get_response_subject_type import PermissionsGetResponse_subjectType
    from .permissions_get_response_user_type import PermissionsGetResponse_userType

@dataclass
class PermissionsGetResponse(Parsable):
    # Permitted actions for the user, role, or company.The permission action group is different in BIM 360 Document Management and ACC Files.- The six permission levels in BIM 360 Document Management correspond to one or more actions:- View Only: ``VIEW``, ``COLLABORATE``- View/Download: ``VIEW``, ``DOWNLOAD``, ``COLLABORATE``- Upload Only: ``PUBLISH``- View/Download+Upload: ``PUBLISH``, ``VIEW``, ``DOWNLOAD``, ``COLLABORATE``- View/Download+Upload+Edit: ``PUBLISH``, ``VIEW``, ``DOWNLOAD``, ``COLLABORATE``, ``EDIT``- Full controller: ``PUBLISH``, ``VIEW``, ``DOWNLOAD``, ``COLLABORATE``, ``EDIT``, ``CONTROL``- The six permission levels in ACC correspond to one or more actions:- View Only: ``VIEW``, ``COLLABORATE``- View/Download: ``VIEW``, ``DOWNLOAD``, ``COLLABORATE``- View/Download+PublishMarkups: ``VIEW``, ``DOWNLOAD``, ``COLLABORATE``, ``PUBLISH_MARKUP``- View/Download+PublishMarkups+Upload: ``PUBLISH``, ``VIEW``, ``DOWNLOAD``, ``COLLABORATE``, ``PUBLISH_MARKUP``- View/Download+PublishMarkups+Upload+Edit: ``PUBLISH``, ``VIEW``, ``DOWNLOAD``, ``COLLABORATE``, ``PUBLISH_MARKUP``, ``EDIT``- Full controller: ``PUBLISH``, ``VIEW``, ``DOWNLOAD``, ``COLLABORATE``, ``PUBLISH_MARKUP``, ``EDIT``, ``CONTROL``See the `BIM 360 Help documentation <http://help.autodesk.com/view/BIM360D/ENU/?guid=GUID-2643FEEF-B48A-45A1-B354-797DAD628C37>`_ or the `ACC Files Help documentation <https://help.autodesk.com/view/BUILD/ENU/?guid=Folder_Permissions>`_ for more details about each permission group.Note that the full set of permissions assigned to the user, role, or company is a combination of ``actions`` and ``inheritActions``.
    actions: Optional[list[str]] = None
    # The Autodesk ID of the user, role or company.
    autodesk_id: Optional[str] = None
    # The user's email. Only relevant if the subject is a user.
    email: Optional[str] = None
    # Permissions inherited by the user, role, or company from a higher level folder.The permission action group is different in BIM 360 Document Management and ACC Files.- The six permission levels in BIM 360 Document Management correspond to one or more actions:- View Only: ``VIEW``, ``COLLABORATE``- View/Download: ``VIEW``, ``DOWNLOAD``, ``COLLABORATE``- Upload Only: ``PUBLISH``- View/Download+Upload: ``PUBLISH``, ``VIEW``, ``DOWNLOAD``, ``COLLABORATE``- View/Download+Upload+Edit: ``PUBLISH``, ``VIEW``, ``DOWNLOAD``, ``COLLABORATE``, ``EDIT``- Full controller: ``PUBLISH``, ``VIEW``, ``DOWNLOAD``, ``COLLABORATE``, ``EDIT``, ``CONTROL``- The six permission levels in ACC correspond to one or more actions:- View Only: ``VIEW``, ``COLLABORATE``- View/Download: ``VIEW``, ``DOWNLOAD``, ``COLLABORATE``- View/Download+PublishMarkups: ``VIEW``, ``DOWNLOAD``, ``COLLABORATE``, ``PUBLISH_MARKUP``- View/Download+PublishMarkups+Upload: ``PUBLISH``, ``VIEW``, ``DOWNLOAD``, ``COLLABORATE``, ``PUBLISH_MARKUP``- View/Download+PublishMarkups+Upload+Edit: ``PUBLISH``, ``VIEW``, ``DOWNLOAD``, ``COLLABORATE``, ``PUBLISH_MARKUP``, ``EDIT``- Full controller: ``PUBLISH``, ``VIEW``, ``DOWNLOAD``, ``COLLABORATE``, ``PUBLISH_MARKUP``, ``EDIT``, ``CONTROL``See the `BIM 360 Help documentation <http://help.autodesk.com/view/BIM360D/ENU/?guid=GUID-2643FEEF-B48A-45A1-B354-797DAD628C37>`_ or the `ACC Files Help documentation <https://help.autodesk.com/view/BUILD/ENU/?guid=Folder_Permissions>`_ for more details about each permission group.Note that the full set of permissions assigned to the user, role, or company is a combination of ``actions`` and ``inheritActions``.Note that project administrators' permissions are non-inherited actions for the root folder, and inherited actions for all other folders.
    inherit_actions: Optional[list[str]] = None
    # The name of the user, role, or company.
    name: Optional[str] = None
    # The ID of the user, role, or company. For example, this corresponds to the ``id``, ``roleId``, or ``companyId`` in the response for `GET /users/user_id </en/docs/bim360/v1/reference/http/admin-v1-projects-projectId-users-userId-GET/>`_.
    subject_id: Optional[UUID] = None
    # The status of the user, role, or company.Possible values:- For a user: ``INACTIVE``, ``ACTIVE``, ``PENDING``, ``DISABLED``- For a role: ``INACTIVE``, ``ACTIVE``- For a company: ``ACTIVE``
    subject_status: Optional[PermissionsGetResponse_subjectStatus] = None
    # The type of subject.Possible values: ``USER``, ``COMPANY``, ``ROLE``
    subject_type: Optional[PermissionsGetResponse_subjectType] = None
    # The type of project user. Possible values: ``PROJECT_ADMIN`` or ``PROJECT_MEMBER``. Only relevant if the subject is a user.
    user_type: Optional[PermissionsGetResponse_userType] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> PermissionsGetResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: PermissionsGetResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return PermissionsGetResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .permissions_get_response_subject_status import PermissionsGetResponse_subjectStatus
        from .permissions_get_response_subject_type import PermissionsGetResponse_subjectType
        from .permissions_get_response_user_type import PermissionsGetResponse_userType

        from .permissions_get_response_subject_status import PermissionsGetResponse_subjectStatus
        from .permissions_get_response_subject_type import PermissionsGetResponse_subjectType
        from .permissions_get_response_user_type import PermissionsGetResponse_userType

        fields: dict[str, Callable[[Any], None]] = {
            "actions": lambda n : setattr(self, 'actions', n.get_collection_of_primitive_values(str)),
            "autodeskId": lambda n : setattr(self, 'autodesk_id', n.get_str_value()),
            "email": lambda n : setattr(self, 'email', n.get_str_value()),
            "inheritActions": lambda n : setattr(self, 'inherit_actions', n.get_collection_of_primitive_values(str)),
            "name": lambda n : setattr(self, 'name', n.get_str_value()),
            "subjectId": lambda n : setattr(self, 'subject_id', n.get_uuid_value()),
            "subjectStatus": lambda n : setattr(self, 'subject_status', n.get_enum_value(PermissionsGetResponse_subjectStatus)),
            "subjectType": lambda n : setattr(self, 'subject_type', n.get_enum_value(PermissionsGetResponse_subjectType)),
            "userType": lambda n : setattr(self, 'user_type', n.get_enum_value(PermissionsGetResponse_userType)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_primitive_values("actions", self.actions)
        writer.write_str_value("autodeskId", self.autodesk_id)
        writer.write_str_value("email", self.email)
        writer.write_collection_of_primitive_values("inheritActions", self.inherit_actions)
        writer.write_str_value("name", self.name)
        writer.write_uuid_value("subjectId", self.subject_id)
        writer.write_enum_value("subjectStatus", self.subject_status)
        writer.write_enum_value("subjectType", self.subject_type)
        writer.write_enum_value("userType", self.user_type)
    

