from enum import Enum

class VersionsBatchGetPostResponse_results_approvalStatus_value(str, Enum):
    Approved = "approved",
    Rejected = "rejected",

