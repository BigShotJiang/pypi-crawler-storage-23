from enum import Enum

class VersionsBatchGetPostResponse_results_customAttributes_type(str, Enum):
    String = "string",
    Date = "date",
    Array = "array",

