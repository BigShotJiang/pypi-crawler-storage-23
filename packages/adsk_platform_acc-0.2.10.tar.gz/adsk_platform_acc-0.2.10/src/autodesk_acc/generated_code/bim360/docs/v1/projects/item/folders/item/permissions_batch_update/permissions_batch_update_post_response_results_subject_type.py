from enum import Enum

class PermissionsBatchUpdatePostResponse_results_subjectType(str, Enum):
    USER = "USER",
    COMPANY = "COMPANY",
    ROLE = "ROLE",

