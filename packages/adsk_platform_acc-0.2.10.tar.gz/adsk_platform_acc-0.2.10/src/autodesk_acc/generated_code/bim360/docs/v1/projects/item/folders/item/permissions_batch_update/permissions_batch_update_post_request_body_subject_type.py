from enum import Enum

class PermissionsBatchUpdatePostRequestBody_subjectType(str, Enum):
    USER = "USER",
    COMPANY = "COMPANY",
    ROLE = "ROLE",

