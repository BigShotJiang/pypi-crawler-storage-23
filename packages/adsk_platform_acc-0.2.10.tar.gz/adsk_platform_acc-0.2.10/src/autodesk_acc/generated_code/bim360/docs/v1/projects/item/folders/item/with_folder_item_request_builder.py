from __future__ import annotations
from collections.abc import Callable
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.request_adapter import RequestAdapter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .custom_attribute_definitions.custom_attribute_definitions_request_builder import CustomAttributeDefinitionsRequestBuilder
    from .permissions.permissions_request_builder import PermissionsRequestBuilder
    from .permissions_batch_create.permissions_batch_create_request_builder import PermissionsBatchCreateRequestBuilder
    from .permissions_batch_delete.permissions_batch_delete_request_builder import PermissionsBatchDeleteRequestBuilder
    from .permissions_batch_update.permissions_batch_update_request_builder import PermissionsBatchUpdateRequestBuilder

class WithFolder_ItemRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /bim360/docs/v1/projects/{project-id}/folders/{folder_id}
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new WithFolder_ItemRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/bim360/docs/v1/projects/{project%2Did}/folders/{folder_id}", path_parameters)
    
    @property
    def custom_attribute_definitions(self) -> CustomAttributeDefinitionsRequestBuilder:
        """
        The customAttributeDefinitions property
        """
        from .custom_attribute_definitions.custom_attribute_definitions_request_builder import CustomAttributeDefinitionsRequestBuilder

        return CustomAttributeDefinitionsRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def permissions(self) -> PermissionsRequestBuilder:
        """
        The permissions property
        """
        from .permissions.permissions_request_builder import PermissionsRequestBuilder

        return PermissionsRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def permissions_batch_create(self) -> PermissionsBatchCreateRequestBuilder:
        """
        The permissionsBatchCreate property
        """
        from .permissions_batch_create.permissions_batch_create_request_builder import PermissionsBatchCreateRequestBuilder

        return PermissionsBatchCreateRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def permissions_batch_delete(self) -> PermissionsBatchDeleteRequestBuilder:
        """
        The permissionsBatchDelete property
        """
        from .permissions_batch_delete.permissions_batch_delete_request_builder import PermissionsBatchDeleteRequestBuilder

        return PermissionsBatchDeleteRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def permissions_batch_update(self) -> PermissionsBatchUpdateRequestBuilder:
        """
        The permissionsBatchUpdate property
        """
        from .permissions_batch_update.permissions_batch_update_request_builder import PermissionsBatchUpdateRequestBuilder

        return PermissionsBatchUpdateRequestBuilder(self.request_adapter, self.path_parameters)
    

