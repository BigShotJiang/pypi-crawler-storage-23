from enum import Enum

class CustomAttributeDefinitionsGetResponse_results_type(str, Enum):
    String = "string",
    Date = "date",
    Array = "array",

