from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .custom_attribute_definitions_post_request_body_type import CustomAttributeDefinitionsPostRequestBody_type

@dataclass
class CustomAttributeDefinitionsPostRequestBody(Parsable):
    # A list of possible values for the attribute. Only relevant for drop-list attributes.
    array_values: Optional[list[str]] = None
    # The name of the attribute. It needs to be unique within the folder.
    name: Optional[str] = None
    # The type of attribute. Possible values: ``string`` (text field), ``date``, ``array`` (drop-list).
    type: Optional[CustomAttributeDefinitionsPostRequestBody_type] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> CustomAttributeDefinitionsPostRequestBody:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: CustomAttributeDefinitionsPostRequestBody
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return CustomAttributeDefinitionsPostRequestBody()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .custom_attribute_definitions_post_request_body_type import CustomAttributeDefinitionsPostRequestBody_type

        from .custom_attribute_definitions_post_request_body_type import CustomAttributeDefinitionsPostRequestBody_type

        fields: dict[str, Callable[[Any], None]] = {
            "arrayValues": lambda n : setattr(self, 'array_values', n.get_collection_of_primitive_values(str)),
            "name": lambda n : setattr(self, 'name', n.get_str_value()),
            "type": lambda n : setattr(self, 'type', n.get_enum_value(CustomAttributeDefinitionsPostRequestBody_type)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_primitive_values("arrayValues", self.array_values)
        writer.write_str_value("name", self.name)
        writer.write_enum_value("type", self.type)
    

