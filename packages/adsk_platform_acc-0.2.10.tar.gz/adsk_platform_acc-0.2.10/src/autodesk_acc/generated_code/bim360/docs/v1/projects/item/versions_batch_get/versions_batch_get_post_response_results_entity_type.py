from enum import Enum

class VersionsBatchGetPostResponse_results_entityType(str, Enum):
    SEED_FILE = "SEED_FILE",
    DOCUMENT = "DOCUMENT",

