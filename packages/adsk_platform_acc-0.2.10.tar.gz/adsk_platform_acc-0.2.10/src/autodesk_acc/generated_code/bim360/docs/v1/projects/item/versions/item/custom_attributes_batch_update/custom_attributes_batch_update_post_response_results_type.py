from enum import Enum

class CustomAttributesBatchUpdatePostResponse_results_type(str, Enum):
    String = "string",
    Date = "date",
    Array = "array",

