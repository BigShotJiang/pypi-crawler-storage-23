from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

if TYPE_CHECKING:
    from .permissions_batch_create_post_request_body_subject_type import PermissionsBatchCreatePostRequestBody_subjectType

@dataclass
class PermissionsBatchCreatePostRequestBody(Parsable):
    # Permitted actions for the user, role, or company.The permission action group is different in BIM 360 Document Management and ACC Build Files.- The six permission levels in BIM 360 Document Management correspond to one or more actions:- View Only: ``VIEW``, ``COLLABORATE``- View/Download: ``VIEW``, ``DOWNLOAD``, ``COLLABORATE``- Upload Only: ``PUBLISH``- View/Download+Upload: ``PUBLISH``, ``VIEW``, ``DOWNLOAD``, ``COLLABORATE``- View/Download+Upload+Edit: ``PUBLISH``, ``VIEW``, ``DOWNLOAD``, ``COLLABORATE``, ``EDIT``- Full controller: ``PUBLISH``, ``VIEW``, ``DOWNLOAD``, ``COLLABORATE``, ``EDIT``, ``CONTROL``- The six permission levels in Autodesk Construction Cloud correspond to one or more actions:- View Only: ``VIEW``, ``COLLABORATE``- View/Download: ``VIEW``, ``DOWNLOAD``, ``COLLABORATE``- View/Download+PublishMarkups: ``VIEW``, ``DOWNLOAD``, ``COLLABORATE``, ``PUBLISH_MARKUP``- View/Download+PublishMarkups+Upload: ``PUBLISH``, ``VIEW``, ``DOWNLOAD``, ``COLLABORATE``, ``PUBLISH_MARKUP``- View/Download+PublishMarkups+Upload+Edit: ``PUBLISH``, ``VIEW``, ``DOWNLOAD``, ``COLLABORATE``, ``PUBLISH_MARKUP``, ``EDIT``- Full controller: ``PUBLISH``, ``VIEW``, ``DOWNLOAD``, ``COLLABORATE``, ``PUBLISH_MARKUP``, ``EDIT``, ``CONTROL``See the `BIM 360 Help documentation <http://help.autodesk.com/view/BIM360D/ENU/?guid=GUID-2643FEEF-B48A-45A1-B354-797DAD628C37>`_ or the `ACC Files Help documentation <https://help.autodesk.com/view/BUILD/ENU/?guid=Folder_Permissions>`_ for more details about each permission level.Note that the full set of permissions assigned to the user, role, or company is a combination of ``actions`` and ``inheritActions``.
    actions: Optional[list[str]] = None
    # The Autodesk ID of the user, role or company.
    autodesk_id: Optional[str] = None
    # The ID of the user, role, or company. To verify the subjectId:- For a user, use `GET users </en/docs/bim360/v1/reference/http/admin-v1-projects-projectId-users-GET>`_.- For a role, use `GET roles </en/docs/bim360/v1/reference/http/projects-project_id-industry_roles-GET>`_- For a company, use `GET companies </en/docs/bim360/v1/reference/http/projects-:project_id-companies-GET>`_
    subject_id: Optional[UUID] = None
    # The type of subject.Possible values: ``USER``, ``COMPANY``, ``ROLE``
    subject_type: Optional[PermissionsBatchCreatePostRequestBody_subjectType] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> PermissionsBatchCreatePostRequestBody:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: PermissionsBatchCreatePostRequestBody
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return PermissionsBatchCreatePostRequestBody()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .permissions_batch_create_post_request_body_subject_type import PermissionsBatchCreatePostRequestBody_subjectType

        from .permissions_batch_create_post_request_body_subject_type import PermissionsBatchCreatePostRequestBody_subjectType

        fields: dict[str, Callable[[Any], None]] = {
            "actions": lambda n : setattr(self, 'actions', n.get_collection_of_primitive_values(str)),
            "autodeskId": lambda n : setattr(self, 'autodesk_id', n.get_str_value()),
            "subjectId": lambda n : setattr(self, 'subject_id', n.get_uuid_value()),
            "subjectType": lambda n : setattr(self, 'subject_type', n.get_enum_value(PermissionsBatchCreatePostRequestBody_subjectType)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_primitive_values("actions", self.actions)
        writer.write_str_value("autodeskId", self.autodesk_id)
        writer.write_uuid_value("subjectId", self.subject_id)
        writer.write_enum_value("subjectType", self.subject_type)
    

