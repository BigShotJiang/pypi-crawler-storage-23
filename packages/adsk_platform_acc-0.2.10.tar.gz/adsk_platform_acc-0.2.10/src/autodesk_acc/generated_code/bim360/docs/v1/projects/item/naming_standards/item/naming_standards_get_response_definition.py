from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .naming_standards_get_response_definition_fields import NamingStandardsGetResponse_definition_fields
    from .naming_standards_get_response_definition_metadata import NamingStandardsGetResponse_definition_metadata

@dataclass
class NamingStandardsGetResponse_definition(Parsable):
    # A specified character, separating between multiple fields of a file name.Possible values:- ``-``: Hyphen.- ``_``: Underscore.- ``.``: Point.Note that you cannot use the delimiter within a field name.
    delimiter: Optional[str] = None
    # A list of objects defining a file's field names.Note that the order of the objects that the endpoint returns in the response corresponds to the order of the fields that you set for the naming standard in the UI.
    fields: Optional[list[NamingStandardsGetResponse_definition_fields]] = None
    # A list of objects defining a file's related attributes. These attributes do not appear in the file name.
    metadata: Optional[list[NamingStandardsGetResponse_definition_metadata]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> NamingStandardsGetResponse_definition:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: NamingStandardsGetResponse_definition
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return NamingStandardsGetResponse_definition()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .naming_standards_get_response_definition_fields import NamingStandardsGetResponse_definition_fields
        from .naming_standards_get_response_definition_metadata import NamingStandardsGetResponse_definition_metadata

        from .naming_standards_get_response_definition_fields import NamingStandardsGetResponse_definition_fields
        from .naming_standards_get_response_definition_metadata import NamingStandardsGetResponse_definition_metadata

        fields: dict[str, Callable[[Any], None]] = {
            "delimiter": lambda n : setattr(self, 'delimiter', n.get_str_value()),
            "fields": lambda n : setattr(self, 'fields', n.get_collection_of_object_values(NamingStandardsGetResponse_definition_fields)),
            "metadata": lambda n : setattr(self, 'metadata', n.get_collection_of_object_values(NamingStandardsGetResponse_definition_metadata)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("delimiter", self.delimiter)
        writer.write_collection_of_object_values("fields", self.fields)
        writer.write_collection_of_object_values("metadata", self.metadata)
    

