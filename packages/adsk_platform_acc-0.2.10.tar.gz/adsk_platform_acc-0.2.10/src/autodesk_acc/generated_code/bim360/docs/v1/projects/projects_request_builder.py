from __future__ import annotations
from collections.abc import Callable
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.request_adapter import RequestAdapter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

if TYPE_CHECKING:
    from .item.project_item_request_builder import ProjectItemRequestBuilder

class ProjectsRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /bim360/docs/v1/projects
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new ProjectsRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/bim360/docs/v1/projects", path_parameters)
    
    def by_project_id(self,project_id: UUID) -> ProjectItemRequestBuilder:
        """
        Gets an item from the Autodesk.ACC.bim360.docs.v1.projects.item collection
        param project_id: The ID of the project.This corresponds to project ID in the `Data Management API </en/docs/data/v2/>`_. To convert a project ID in the Data Management API into a project ID in the BIM 360 API you need to remove the ``**b.**`` prefix. For example, a project ID of **b.**a4be0c34a-4ab7 translates to a project ID of a4be0c34a-4ab7.To learn how to find the project ID, see the `Retrieve BIM 360 Account and Project ID </en/docs/bim360/v1/tutorials/getting-started/retrieve-account-and-project-id/>`_ tutorial.
        Returns: ProjectItemRequestBuilder
        """
        if project_id is None:
            raise TypeError("project_id cannot be null.")
        from .item.project_item_request_builder import ProjectItemRequestBuilder

        url_tpl_params = get_path_parameters(self.path_parameters)
        url_tpl_params["project%2Did"] = project_id
        return ProjectItemRequestBuilder(self.request_adapter, url_tpl_params)
    

