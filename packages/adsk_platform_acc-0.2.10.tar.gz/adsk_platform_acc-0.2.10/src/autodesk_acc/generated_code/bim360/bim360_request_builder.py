from __future__ import annotations
from collections.abc import Callable
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.request_adapter import RequestAdapter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .clash.clash_request_builder import ClashRequestBuilder
    from .docs.docs_request_builder import DocsRequestBuilder
    from .modelset.modelset_request_builder import ModelsetRequestBuilder
    from .relationship.relationship_request_builder import RelationshipRequestBuilder

class Bim360RequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /bim360
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new Bim360RequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/bim360", path_parameters)
    
    @property
    def clash(self) -> ClashRequestBuilder:
        """
        The clash property
        """
        from .clash.clash_request_builder import ClashRequestBuilder

        return ClashRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def docs(self) -> DocsRequestBuilder:
        """
        The docs property
        """
        from .docs.docs_request_builder import DocsRequestBuilder

        return DocsRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def modelset(self) -> ModelsetRequestBuilder:
        """
        The modelset property
        """
        from .modelset.modelset_request_builder import ModelsetRequestBuilder

        return ModelsetRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def relationship(self) -> RelationshipRequestBuilder:
        """
        The relationship property
        """
        from .relationship.relationship_request_builder import RelationshipRequestBuilder

        return RelationshipRequestBuilder(self.request_adapter, self.path_parameters)
    

