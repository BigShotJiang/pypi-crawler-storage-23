"""ACC (Autodesk Construction Cloud) client module."""
from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Optional, TYPE_CHECKING

import httpx
from autodesk_common_httpclient import HttpClientFactory

from autodesk_acc.generated_code.base_a_c_cclient import BaseACCclient

if TYPE_CHECKING:
    from autodesk_acc.generated_code.bim360.clash.v3.v3_request_builder import (
        V3RequestBuilder as ClashV3RequestBuilder,
    )
    from autodesk_acc.generated_code.bim360.docs.v1.v1_request_builder import (
        V1RequestBuilder as DocsV1RequestBuilder,
    )
    from autodesk_acc.generated_code.bim360.modelset.v3.v3_request_builder import (
        V3RequestBuilder as ModelSetV3RequestBuilder,
    )
    from autodesk_acc.generated_code.bim360.relationship.v2.v2_request_builder import (
        V2RequestBuilder as RelationshipV2RequestBuilder,
    )
    from autodesk_acc.generated_code.construction.admin.v1.v1_request_builder import (
        V1RequestBuilder as AdminV1RequestBuilder,
    )
    from autodesk_acc.generated_code.construction.assets.assets_request_builder import (
        AssetsRequestBuilder,
    )
    from autodesk_acc.generated_code.construction.autospecs.v1.v1_request_builder import (
        V1RequestBuilder as AutoSpecsV1RequestBuilder,
    )
    from autodesk_acc.generated_code.construction.files.v1.v1_request_builder import (
        V1RequestBuilder as FilesV1RequestBuilder,
    )
    from autodesk_acc.generated_code.construction.forms.v1.v1_request_builder import (
        V1RequestBuilder as FormsV1RequestBuilder,
    )
    from autodesk_acc.generated_code.construction.index.v2.v2_request_builder import (
        V2RequestBuilder as IndexV2RequestBuilder,
    )
    from autodesk_acc.generated_code.construction.issues.v1.v1_request_builder import (
        V1RequestBuilder as IssuesV1RequestBuilder,
    )
    from autodesk_acc.generated_code.construction.locations.v2.v2_request_builder import (
        V2RequestBuilder as LocationsV2RequestBuilder,
    )
    from autodesk_acc.generated_code.construction.packages.v1.v1_request_builder import (
        V1RequestBuilder as PackagesV1RequestBuilder,
    )
    from autodesk_acc.generated_code.construction.photos.v1.v1_request_builder import (
        V1RequestBuilder as PhotosV1RequestBuilder,
    )
    from autodesk_acc.generated_code.construction.rcm.v1.v1_request_builder import (
        V1RequestBuilder as RcmV1RequestBuilder,
    )
    from autodesk_acc.generated_code.construction.reviews.v1.v1_request_builder import (
        V1RequestBuilder as ReviewsV1RequestBuilder,
    )
    from autodesk_acc.generated_code.construction.rfis.v3.v3_request_builder import (
        V3RequestBuilder as RfisV3RequestBuilder,
    )
    from autodesk_acc.generated_code.construction.sheets.v1.v1_request_builder import (
        V1RequestBuilder as SheetsV1RequestBuilder,
    )
    from autodesk_acc.generated_code.construction.submittals.v2.v2_request_builder import (
        V2RequestBuilder as SubmittalsV2RequestBuilder,
    )
    from autodesk_acc.generated_code.construction.takeoff.v1.v1_request_builder import (
        V1RequestBuilder as TakeoffV1RequestBuilder,
    )
    from autodesk_acc.generated_code.construction.transmittals.v1.v1_request_builder import (
        V1RequestBuilder as TransmittalsV1RequestBuilder,
    )
    from autodesk_acc.generated_code.cost.v1.v1_request_builder import (
        V1RequestBuilder as CostV1RequestBuilder,
    )
    from autodesk_acc.generated_code.data_connector.v1.v1_request_builder import (
        V1RequestBuilder as DataConnectorV1RequestBuilder,
    )
    from autodesk_acc.generated_code.hq.v1.accounts.accounts_request_builder import (
        AccountsRequestBuilder,
    )


class ACCClient:
    """High-level Autodesk Construction Cloud client.

    Provides convenient shortcut properties for all ACC API endpoint groups.

    Args:
        get_access_token: Async function that returns a valid access token.
        http_client: Optional httpx.AsyncClient to override the default HTTP client.
    """

    def __init__(
        self,
        get_access_token: Callable[[], Awaitable[str]],
        http_client: Optional[httpx.AsyncClient] = None,
    ) -> None:
        adapter = HttpClientFactory.create_adapter(get_access_token, http_client)
        self._api = BaseACCclient(adapter)

    @property
    def api(self) -> BaseACCclient:
        """The full generated ACC API client (base path https://developer.api.autodesk.com)."""
        return self._api

    # ── Account Admin shortcuts ──────────────────────────────────────────

    @property
    def accounts(self) -> AccountsRequestBuilder:
        """Shortcut to https://developer.api.autodesk.com/hq/v1/accounts/*"""
        return self._api.hq.v1.accounts

    @property
    def admin(self) -> AdminV1RequestBuilder:
        """Shortcut to https://developer.api.autodesk.com/construction/admin/v1/*"""
        return self._api.construction.admin.v1

    # ── Construction shortcuts ───────────────────────────────────────────

    @property
    def assets(self) -> AssetsRequestBuilder:
        """Shortcut to https://developer.api.autodesk.com/construction/assets/*"""
        return self._api.construction.assets

    @property
    def auto_specs(self) -> AutoSpecsV1RequestBuilder:
        """Shortcut to https://developer.api.autodesk.com/construction/autospecs/v1/*"""
        return self._api.construction.autospecs.v1

    @property
    def files(self) -> FilesV1RequestBuilder:
        """Shortcut to https://developer.api.autodesk.com/construction/files/v1/*"""
        return self._api.construction.files.v1

    @property
    def forms(self) -> FormsV1RequestBuilder:
        """Shortcut to https://developer.api.autodesk.com/construction/forms/v1/*"""
        return self._api.construction.forms.v1

    @property
    def index(self) -> IndexV2RequestBuilder:
        """Shortcut to https://developer.api.autodesk.com/construction/index/v2/*"""
        return self._api.construction.index.v2

    @property
    def issues(self) -> IssuesV1RequestBuilder:
        """Shortcut to https://developer.api.autodesk.com/construction/issues/v1/*"""
        return self._api.construction.issues.v1

    @property
    def locations(self) -> LocationsV2RequestBuilder:
        """Shortcut to https://developer.api.autodesk.com/construction/locations/v2/*"""
        return self._api.construction.locations.v2

    @property
    def packages(self) -> PackagesV1RequestBuilder:
        """Shortcut to https://developer.api.autodesk.com/construction/packages/v1/*"""
        return self._api.construction.packages.v1

    @property
    def photos(self) -> PhotosV1RequestBuilder:
        """Shortcut to https://developer.api.autodesk.com/construction/photos/v1/*"""
        return self._api.construction.photos.v1

    @property
    def rcm(self) -> RcmV1RequestBuilder:
        """Shortcut to https://developer.api.autodesk.com/construction/rcm/v1/*"""
        return self._api.construction.rcm.v1

    @property
    def reviews(self) -> ReviewsV1RequestBuilder:
        """Shortcut to https://developer.api.autodesk.com/construction/reviews/v1/*"""
        return self._api.construction.reviews.v1

    @property
    def rfis(self) -> RfisV3RequestBuilder:
        """Shortcut to https://developer.api.autodesk.com/construction/rfis/v3/*"""
        return self._api.construction.rfis.v3

    @property
    def sheets(self) -> SheetsV1RequestBuilder:
        """Shortcut to https://developer.api.autodesk.com/construction/sheets/v1/*"""
        return self._api.construction.sheets.v1

    @property
    def submittals(self) -> SubmittalsV2RequestBuilder:
        """Shortcut to https://developer.api.autodesk.com/construction/submittals/v2/*"""
        return self._api.construction.submittals.v2

    @property
    def takeoff(self) -> TakeoffV1RequestBuilder:
        """Shortcut to https://developer.api.autodesk.com/construction/takeoff/v1/*"""
        return self._api.construction.takeoff.v1

    @property
    def transmittals(self) -> TransmittalsV1RequestBuilder:
        """Shortcut to https://developer.api.autodesk.com/construction/transmittals/v1/*"""
        return self._api.construction.transmittals.v1

    # ── BIM 360 shortcuts ────────────────────────────────────────────────

    @property
    def clash(self) -> ClashV3RequestBuilder:
        """Shortcut to https://developer.api.autodesk.com/bim360/clash/v3/*"""
        return self._api.bim360.clash.v3

    @property
    def docs(self) -> DocsV1RequestBuilder:
        """Shortcut to https://developer.api.autodesk.com/bim360/docs/v1/*"""
        return self._api.bim360.docs.v1

    @property
    def model_set(self) -> ModelSetV3RequestBuilder:
        """Shortcut to https://developer.api.autodesk.com/bim360/modelset/v3/*"""
        return self._api.bim360.modelset.v3

    @property
    def projects(self) -> RelationshipV2RequestBuilder:
        """Shortcut to https://developer.api.autodesk.com/bim360/relationship/v2/*"""
        return self._api.bim360.relationship.v2

    @property
    def relationships(self) -> RelationshipV2RequestBuilder:
        """Shortcut to https://developer.api.autodesk.com/bim360/relationship/v2/*"""
        return self._api.bim360.relationship.v2

    # ── Cost shortcuts ───────────────────────────────────────────────────

    @property
    def cost(self) -> CostV1RequestBuilder:
        """Shortcut to https://developer.api.autodesk.com/cost/v1/*"""
        return self._api.cost.v1

    # ── Data Connector shortcuts ─────────────────────────────────────────

    @property
    def data_connector(self) -> DataConnectorV1RequestBuilder:
        """Shortcut to https://developer.api.autodesk.com/dataconnector/v1/*"""
        return self._api.data_connector.v1
