"""Cython optimized Faust features."""
