from django.apps import AppConfig


class FaustappConfig(AppConfig):
    name = 'faustapp'
