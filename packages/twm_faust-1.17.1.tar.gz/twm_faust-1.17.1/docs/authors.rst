.. _authors:

===============================
  Authors
===============================

.. contents::
    :local:

.. include:: ../AUTHORS.rst
