.. _history:

=========
 History
=========

This section contains historical change histories, for the latest
version please visit :ref:`changelog`.

:Release: |version|
:Date: |today|

.. toctree::
    :maxdepth: 2

    changelog-1.9
    changelog-1.8
    changelog-1.7
    changelog-1.6
    changelog-1.5
    changelog-1.4
    changelog-1.3
    changelog-1.2
    changelog-1.1
    changelog-1.0
    changelog-0.9
