=====================================================
 ``faust.serializers.schemas``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.serializers.schemas

.. automodule:: faust.serializers.schemas
    :members:
    :undoc-members:
