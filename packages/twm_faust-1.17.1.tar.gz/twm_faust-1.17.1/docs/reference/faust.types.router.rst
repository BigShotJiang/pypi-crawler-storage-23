=====================================================
 ``faust.types.router``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.types.router

.. automodule:: faust.types.router
    :members:
    :undoc-members:
