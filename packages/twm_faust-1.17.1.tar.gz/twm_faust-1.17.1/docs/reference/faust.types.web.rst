=====================================================
 ``faust.types.web``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.types.web

.. automodule:: faust.types.web
    :members:
    :undoc-members:
