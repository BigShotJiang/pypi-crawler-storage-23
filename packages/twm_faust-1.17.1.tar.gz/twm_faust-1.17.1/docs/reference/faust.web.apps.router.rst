=====================================================
 ``faust.web.apps.router``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.web.apps.router

.. automodule:: faust.web.apps.router
    :members:
    :undoc-members:
