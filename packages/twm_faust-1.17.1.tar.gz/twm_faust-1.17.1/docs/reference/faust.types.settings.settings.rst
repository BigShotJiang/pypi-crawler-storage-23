=====================================================
 ``faust.types.settings.settings``
=====================================================

.. contents::
    :local:

.. currentmodule:: faust.types.settings.settings

.. automodule:: faust.types.settings.settings
    :members:
    :undoc-members:
