=====================================================
 ``faust.livecheck.case``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.livecheck.case

.. automodule:: faust.livecheck.case
    :members:
    :undoc-members:
