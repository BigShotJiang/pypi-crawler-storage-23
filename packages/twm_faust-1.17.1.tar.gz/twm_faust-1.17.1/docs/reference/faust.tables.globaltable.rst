=====================================================
 ``faust.tables.globaltable``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.tables.globaltable

.. automodule:: faust.tables.globaltable
    :members:
    :undoc-members:
