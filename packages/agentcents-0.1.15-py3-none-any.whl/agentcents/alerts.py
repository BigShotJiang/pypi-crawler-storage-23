"""
agentcents alerts.py — Phase 5
Budget threshold checking. Called after every proxied call.
Alerts are stored in SQLite and surfaced in the dashboard + CLI.
"""

import time
import logging
import sqlite3
from pathlib import Path
from typing import Optional

from agentcents.config import load as load_config

logger = logging.getLogger("agentcents.alerts")

DB_PATH = Path(__file__).parent / "data" / "ledger.db"


# ---------------------------------------------------------------------------
# Alert storage
# ---------------------------------------------------------------------------

def _conn():
    DB_PATH.parent.mkdir(exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_alerts_table():
    with _conn() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS alerts (
                id        INTEGER PRIMARY KEY AUTOINCREMENT,
                ts        REAL    NOT NULL,
                level     TEXT    NOT NULL,   -- 'warn' | 'critical'
                scope     TEXT    NOT NULL,   -- 'hourly' | 'daily' | 'monthly' | 'tag:name'
                spent     REAL    NOT NULL,
                budget    REAL    NOT NULL,
                message   TEXT    NOT NULL,
                seen      INTEGER DEFAULT 0
            )
        """)
        conn.commit()


def _record_alert(level: str, scope: str, spent: float, budget: float, message: str):
    init_alerts_table()
    with _conn() as conn:
        # Avoid duplicate alerts within the same hour for same scope
        recent = conn.execute("""
            SELECT id FROM alerts
            WHERE scope = ? AND ts > ?
            ORDER BY ts DESC LIMIT 1
        """, (scope, time.time() - 3600)).fetchone()
        if recent:
            return  # already alerted this hour for this scope

        conn.execute("""
            INSERT INTO alerts (ts, level, scope, spent, budget, message)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (time.time(), level, scope, spent, budget, message))
        conn.commit()

    # Also log to proxy output so it's visible immediately
    color = "\033[33m" if level == "warn" else "\033[31m"
    reset = "\033[0m"
    logger.warning(f"{color}⚠ BUDGET ALERT [{scope}] {message}{reset}")


def get_recent_alerts(n: int = 20):
    init_alerts_table()
    with _conn() as conn:
        rows = conn.execute("""
            SELECT * FROM alerts ORDER BY ts DESC LIMIT ?
        """, (n,)).fetchall()
    return [dict(r) for r in rows]


def get_unseen_alerts():
    init_alerts_table()
    with _conn() as conn:
        rows = conn.execute("""
            SELECT * FROM alerts WHERE seen = 0 ORDER BY ts DESC
        """).fetchall()
        conn.execute("UPDATE alerts SET seen = 1 WHERE seen = 0")
        conn.commit()
    return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# Budget checking
# ---------------------------------------------------------------------------

def _get_spend(hours: float, tag: Optional[str] = None) -> float:
    """Sum cost_usd from ledger for the last N hours."""
    since = time.time() - hours * 3600
    with _conn() as conn:
        q = "SELECT SUM(cost_usd) FROM calls WHERE ts >= ? AND cost_usd IS NOT NULL"
        params = [since]
        if tag:
            q += " AND tag = ?"
            params.append(tag)
        row = conn.execute(q, params).fetchone()
    return row[0] or 0.0


def check_budgets(tag: Optional[str] = None):
    """
    Check all budget thresholds. Call this after every proxied request.
    """
    cfg = load_config()
    budgets = cfg.get("budgets", {})

    windows = [
        ("hourly",  1,    budgets.get("hourly")),
        ("daily",   24,   budgets.get("daily")),
        ("monthly", 720,  budgets.get("monthly")),
    ]

    for scope_name, hours, limit in windows:
        if limit is None:
            continue
        spent = _get_spend(hours)
        if spent >= limit:
            pct = (spent / limit) * 100
            level = "critical" if pct >= 100 else "warn"
            msg = f"${spent:.4f} spent of ${limit:.2f} {scope_name} budget ({pct:.0f}%)"
            _record_alert(level, scope_name, spent, limit, msg)

    # Per-tag budgets
    tag_budgets = budgets.get("tags", {})
    check_tag = tag or "default"
    if check_tag in tag_budgets:
        tag_limit = tag_budgets[check_tag].get("daily")
        if tag_limit:
            spent = _get_spend(24, tag=check_tag)
            if spent >= tag_limit * 0.8:  # warn at 80%
                pct = (spent / tag_limit) * 100
                level = "critical" if pct >= 100 else "warn"
                msg = f"[{check_tag}] ${spent:.4f} of ${tag_limit:.2f} daily budget ({pct:.0f}%)"
                _record_alert(level, f"tag:{check_tag}", spent, tag_limit, msg)
