"""
agentcents features.py — Phase 5
Central registry of free vs premium features.

Free tier:
  - Proxy core (all providers)
  - Pricing catalog
  - Cost logging + ledger
  - Exact-match cache (Phase 7)
  - Basic CLI (usage, recent, models, sync)
  - Budget alerts (local only)
  - Dashboard

Premium (Pro) tier:
  - Semantic similarity cache (Phase 9)
  - XGBoost cost predictor (Phase 11)
  - Model swap advisor (Phase 8)
  - Rolling 30-day budgets (Phase 6)
  - Multi-agent tracking (Phase 6)
  - Auto-routing to cheapest model (Phase 8)
  - Telemetry-trained predictor model (Phase 11)
"""

from agentcents.license import is_premium, require_premium


# ---------------------------------------------------------------------------
# Feature definitions
# ---------------------------------------------------------------------------

FEATURES = {
    # Free
    "proxy":           {"tier": "free",    "name": "Proxy core"},
    "catalog":         {"tier": "free",    "name": "Pricing catalog"},
    "ledger":          {"tier": "free",    "name": "Cost logging"},
    "exact_cache":     {"tier": "free",    "name": "Exact-match cache"},
    "budget_alerts":   {"tier": "free",    "name": "Budget alerts"},
    "dashboard":       {"tier": "free",    "name": "Dashboard"},
    "cli_basic":       {"tier": "free",    "name": "Basic CLI"},

    # Premium
    "semantic_cache":  {"tier": "pro",     "name": "Semantic similarity cache"},
    "predictor":       {"tier": "pro",     "name": "XGBoost cost predictor"},
    "advisor":         {"tier": "pro",     "name": "Model swap advisor"},
    "rolling_budgets": {"tier": "pro",     "name": "Rolling 30-day budgets"},
    "multi_agent":     {"tier": "pro",     "name": "Multi-agent tracking"},
    "auto_routing":    {"tier": "pro",     "name": "Auto-routing to cheapest model"},
}


def check(feature_key: str) -> bool:
    """Returns True if the feature is available for the current tier."""
    feature = FEATURES.get(feature_key)
    if not feature:
        return True  # unknown features default to available
    if feature["tier"] == "free":
        return True
    return is_premium()


def gate(feature_key: str):
    """
    Gate access to a premium feature.
    Raises PermissionError with upgrade message if not premium.

    Usage:
        from agentcents.features import gate
        gate("semantic_cache")
        # ... premium code below
    """
    feature = FEATURES.get(feature_key, {})
    if feature.get("tier") == "free":
        return
    name = feature.get("name", feature_key)
    require_premium(name)


def print_feature_table():
    """Print a table of all features and their availability."""
    premium = is_premium()
    tier_label = "Pro ✓" if premium else "Free"

    print(f"\nagentcents features  [{tier_label}]\n")
    print(f"  {'FEATURE':<35} {'TIER':<8} {'STATUS'}")
    print("  " + "-" * 60)

    for key, info in FEATURES.items():
        is_free    = info["tier"] == "free"
        available  = is_free or premium
        status     = "✓ available" if available else "✗ Pro only"
        tier_str   = "free" if is_free else "Pro"
        color      = "\033[32m" if available else "\033[90m"
        reset      = "\033[0m"
        print(f"  {color}{info['name']:<35} {tier_str:<8} {status}{reset}")

    if not premium:
        print(f"\n  Upgrade: https://labham.gumroad.com/l/agentcents-pro")
        print(f"  Activate: agentcents activate <your-key>")
    print()
