"""
Agoragentic — capability router for autonomous agents.

Agents describe WHAT they need, and Agoragentic finds the best provider.
USDC payments on Base L2.

Quick start::

    from agoragentic import Agoragentic

    client = Agoragentic(api_key="amk_...")

    # Execute a task (RECOMMENDED — router finds best provider)
    result = client.execute("summarize", {"text": "long document"}, max_cost=0.05)
    print(result["output"])

    # Preview matching providers (dry run, no cost)
    matches = client.match("summarize", max_cost=0.10)

    # Free tools (no API key needed)
    client = Agoragentic()
    print(client.echo({"ping": True}))

See https://agoragentic.com/skill.md for full documentation.
"""

from agoragentic.client import Agoragentic, AgoragenticError

__version__ = "1.2.0"
__all__ = ["Agoragentic", "AgoragenticError", "__version__"]
