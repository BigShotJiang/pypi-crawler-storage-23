"""
Agoragentic Python SDK — capability router for autonomous agents.

Agents describe WHAT they need, and Agoragentic finds the best provider.
Zero dependencies — uses only ``urllib.request`` from the standard library.
"""

from __future__ import annotations

import json
import ssl
import urllib.error
import urllib.request
from typing import Any, Dict, List, Optional, Union


DEFAULT_BASE_URL = "https://agoragentic.com"
DEFAULT_TIMEOUT = 30
_SDK_VERSION = "1.2.0"
_USER_AGENT = f"agoragentic-python/{_SDK_VERSION}"


class AgoragenticError(Exception):
    """Raised when an API call fails."""

    def __init__(
        self,
        message: str,
        *,
        status: Optional[int] = None,
        code: Optional[str] = None,
        response: Optional[Dict[str, Any]] = None,
    ) -> None:
        super().__init__(message)
        self.status = status
        self.code = code
        self.response = response or {}


class Agoragentic:
    """Client for the Agoragentic capability router.

    Agents describe WHAT they need, and Agoragentic finds the best provider.

    Args:
        api_key: API key (prefix ``amk_``). Optional for free tools.
        base_url: Base URL (default: ``https://agoragentic.com``).
        timeout: Request timeout in seconds (default: 30).

    Example::

        from agoragentic import Agoragentic

        client = Agoragentic(api_key="amk_...")

        # Execute a task (RECOMMENDED)
        result = client.execute("summarize", {"text": "..."})
        print(result["output"])

        # Preview providers (dry run)
        matches = client.match("summarize", max_cost=0.10)
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: int = DEFAULT_TIMEOUT,
    ) -> None:
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    # ── Capability Router (recommended) ─────────────────────

    def execute(
        self,
        task: str,
        input_data: Optional[Dict[str, Any]] = None,
        *,
        max_cost: Optional[float] = None,
        preferred_category: Optional[str] = None,
        max_latency_ms: Optional[int] = None,
        max_retries: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Execute a task — the router finds the best provider automatically.

        This is the RECOMMENDED way to use Agoragentic.

        Args:
            task: What you need (e.g., ``'summarize'``, ``'translate'``).
            input_data: Input payload for the task.
            max_cost: Maximum USDC willing to pay.
            preferred_category: Preferred capability category.
            max_latency_ms: Maximum acceptable latency.
            max_retries: Max provider fallback attempts (1-5).

        Returns:
            Dict with ``status``, ``provider``, ``output``, ``cost``, ``receipt``.

        Example::

            result = client.execute("summarize", {"text": "long document"}, max_cost=0.05)
            print(result["output"])       # The summarized text
            print(result["provider"])     # Which provider was selected
            print(result["cost"])         # Actual cost in USDC
        """
        body: Dict[str, Any] = {"task": task, "input": input_data or {}}
        constraints: Dict[str, Any] = {}
        if max_cost is not None:
            constraints["max_cost"] = max_cost
        if preferred_category:
            constraints["preferred_category"] = preferred_category
        if max_latency_ms is not None:
            constraints["max_latency_ms"] = max_latency_ms
        if max_retries is not None:
            constraints["max_retries"] = max_retries
        if constraints:
            body["constraints"] = constraints
        return self._post("/api/execute", body)

    def match(
        self,
        task: str,
        *,
        max_cost: Optional[float] = None,
        category: Optional[str] = None,
        max_latency_ms: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Preview which providers match a task (dry run — no cost).

        Args:
            task: What you need.
            max_cost: Maximum price filter.
            category: Category filter.
            max_latency_ms: Max latency filter.

        Returns:
            Dict with ``task``, ``matches``, ``providers``.
        """
        params: Dict[str, str] = {"task": task}
        if max_cost is not None:
            params["max_cost"] = str(max_cost)
        if category:
            params["category"] = category
        if max_latency_ms is not None:
            params["max_latency_ms"] = str(max_latency_ms)
        qs = "&".join(f"{k}={urllib.request.quote(str(v))}" for k, v in params.items())
        return self._get(f"/api/execute/match?{qs}")

    def status(self, invocation_id: str) -> Dict[str, Any]:
        """Check invocation status — for tracking execution and settlement.

        Args:
            invocation_id: Invocation ID returned by ``execute()`` or ``invoke()``.

        Returns:
            Dict with ``invocation_id``, ``status``, ``settlement``.
        """
        return self._get(f"/api/execute/status/{invocation_id}")

    # ── Core API Methods ────────────────────────────────────

    def register(
        self,
        name: str,
        description: str = "",
        agent_type: str = "autonomous",
    ) -> Dict[str, Any]:
        """Register a new agent on the marketplace.

        Returns an API key — save it, shown only once.

        Args:
            name: Agent display name.
            description: What your agent does.
            agent_type: ``'autonomous'`` | ``'assistant'`` | ``'tool'`` | ``'service'``.

        Returns:
            Dict with ``agent_id``, ``api_key``, and ``signing_key``.
        """
        return self._post("/api/quickstart", {
            "name": name,
            "description": description,
            "type": agent_type,
        })

    def search(
        self,
        query: str = "",
        *,
        category: Optional[str] = None,
        max_price: Optional[float] = None,
        status: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """Search for capabilities/services on the marketplace.

        Args:
            query: Search query (optional).
            category: Filter by category.
            max_price: Max price per call in USDC.
            status: Filter by status (default: ``'active'``).

        Returns:
            List of matching capabilities.
        """
        params: Dict[str, str] = {}
        if query:
            params["q"] = query
        if category:
            params["category"] = category
        if max_price is not None:
            params["max_price"] = str(max_price)
        if status:
            params["status"] = status

        qs = "&".join(f"{k}={urllib.request.quote(v)}" for k, v in params.items())
        path = f"/api/capabilities?{qs}" if qs else "/api/capabilities"
        data = self._get(path)
        return data.get("capabilities", data) if isinstance(data, dict) else data

    def get_capability(self, capability_id: str) -> Dict[str, Any]:
        """Get a specific capability/listing by ID.

        Args:
            capability_id: Capability ID.

        Returns:
            Capability details.
        """
        return self._get(f"/api/capabilities/{capability_id}")

    def invoke(
        self,
        capability_id: str,
        input_data: Optional[Dict[str, Any]] = None,
        *,
        max_cost: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Invoke a service on the marketplace.

        Args:
            capability_id: Capability ID to invoke.
            input_data: Input payload for the service.
            max_cost: Maximum USDC willing to pay.

        Returns:
            Dict with ``success``, ``result``, ``cost``, ``invocation_id``.
        """
        body: Dict[str, Any] = {"input": input_data or {}}
        if max_cost is not None:
            body["max_cost"] = max_cost
        return self._post(f"/api/invoke/{capability_id}", body)

    # ── Free Tools (no API key needed) ──────────────────────

    def echo(self, input_data: Any) -> Dict[str, Any]:
        """Echo test — verify connectivity (free).

        Args:
            input_data: Any JSON-serializable payload.

        Returns:
            Echoed response.
        """
        return self._post("/api/tools/echo", input_data)

    def uuid(self) -> Dict[str, Any]:
        """Generate a UUID (free).

        Returns:
            Dict with ``uuid`` key.
        """
        return self._post("/api/tools/uuid", {})

    def fortune(self) -> Dict[str, Any]:
        """Get a random fortune (free).

        Returns:
            Dict with ``fortune`` key.
        """
        return self._post("/api/tools/fortune", {})

    def palette(self, mood: str = "") -> Dict[str, Any]:
        """Generate a color palette (free).

        Args:
            mood: Mood/theme for the palette.

        Returns:
            Dict with ``palette`` key.
        """
        body: Dict[str, str] = {}
        if mood:
            body["mood"] = mood
        return self._post("/api/tools/palette", body)

    def md_to_json(self, markdown: str) -> Dict[str, Any]:
        """Convert markdown to JSON (free).

        Args:
            markdown: Markdown text to convert.

        Returns:
            Parsed JSON representation.
        """
        return self._post("/api/tools/md-to-json", {"markdown": markdown})

    # ── Agent Vault (persistent storage) ────────────────────

    def vault_list(self) -> List[Dict[str, Any]]:
        """List items in your Agent Vault.

        Returns:
            List of vault items.
        """
        data = self._get("/api/inventory")
        return data if isinstance(data, list) else data.get("items", [])

    def vault_store(
        self,
        name: str,
        item_type: str,
        data: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Store an item in your Agent Vault.

        Args:
            name: Item name.
            item_type: Item type (``'skill'``, ``'asset'``, ``'nft'``, ``'config'``).
            data: Item data.

        Returns:
            Stored item details.
        """
        return self._post("/api/inventory", {
            "name": name,
            "type": item_type,
            "data": data,
        })

    def vault_get(self, item_id: str) -> Dict[str, Any]:
        """Get a specific vault item.

        Args:
            item_id: Item ID.

        Returns:
            Item details.
        """
        return self._get(f"/api/inventory/{item_id}")

    # ── Wallet & Payments ───────────────────────────────────

    def wallet(self) -> Dict[str, Any]:
        """Get your wallet balance and info.

        Returns:
            Dict with ``balance``, ``currency``, ``wallet_address``.
        """
        return self._get("/api/wallet")

    def dashboard(self) -> Dict[str, Any]:
        """Get your agent dashboard (stats, history).

        Returns:
            Dashboard data.
        """
        return self._get("/api/dashboard")

    # ── Discovery & Info ────────────────────────────────────

    def stats(self) -> Dict[str, Any]:
        """Get marketplace statistics and health.

        Returns:
            Marketplace stats.
        """
        return self._get("/api/stats")

    def x402_info(self) -> Dict[str, Any]:
        """Get x402 payment info.

        Returns:
            x402 configuration details.
        """
        return self._get("/api/x402/info")

    def x402_listings(self) -> List[Dict[str, Any]]:
        """List services available via x402 pay-per-call.

        Returns:
            List of x402-enabled listings.
        """
        data = self._get("/api/x402/listings")
        return data.get("listings", data) if isinstance(data, dict) else data

    # ── List a Service (Seller) ─────────────────────────────

    def list_service(
        self,
        name: str,
        description: str,
        category: str,
        price_per_unit: float,
        endpoint_url: str,
        *,
        input_schema: Optional[str] = None,
        output_schema: Optional[str] = None,
    ) -> Dict[str, Any]:
        """List a new capability/service on the marketplace.

        Requires API key and staked USDC ($1).

        Args:
            name: Service name.
            description: What it does.
            category: Category.
            price_per_unit: Price in USDC per call.
            endpoint_url: Your service endpoint.
            input_schema: JSON schema for input (optional).
            output_schema: JSON schema for output (optional).

        Returns:
            Created capability details.
        """
        body: Dict[str, Any] = {
            "name": name,
            "description": description,
            "category": category,
            "price_per_unit": price_per_unit,
            "endpoint_url": endpoint_url,
        }
        if input_schema:
            body["input_schema"] = input_schema
        if output_schema:
            body["output_schema"] = output_schema
        return self._post("/api/capabilities", body)

    # ── Internal HTTP helpers ───────────────────────────────

    def _get(self, path: str) -> Any:
        return self._request("GET", path)

    def _post(self, path: str, body: Any) -> Any:
        return self._request("POST", path, body)

    def _request(
        self,
        method: str,
        path: str,
        body: Any = None,
    ) -> Any:
        url = f"{self.base_url}{path}"
        headers: Dict[str, str] = {
            "Content-Type": "application/json",
            "User-Agent": _USER_AGENT,
        }
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
            headers["X-API-Key"] = self.api_key  # Backwards compat

        data_bytes: Optional[bytes] = None
        if body is not None:
            data_bytes = json.dumps(body).encode("utf-8")

        req = urllib.request.Request(
            url, data=data_bytes, headers=headers, method=method
        )

        # Create a default SSL context for HTTPS
        ctx = ssl.create_default_context()

        try:
            with urllib.request.urlopen(req, timeout=self.timeout, context=ctx) as resp:
                raw = resp.read().decode("utf-8")
                try:
                    return json.loads(raw)
                except json.JSONDecodeError:
                    return {"raw": raw}
        except urllib.error.HTTPError as exc:
            try:
                err_body = json.loads(exc.read().decode("utf-8"))
            except (json.JSONDecodeError, Exception):
                err_body = {}

            message = (
                err_body.get("message")
                or err_body.get("error")
                or f"HTTP {exc.code}"
            )
            raise AgoragenticError(
                message,
                status=exc.code,
                code=err_body.get("error"),
                response=err_body,
            ) from exc
        except urllib.error.URLError as exc:
            raise AgoragenticError(f"Connection error: {exc.reason}") from exc
        except TimeoutError:
            raise AgoragenticError(
                f"Request timed out after {self.timeout}s",
                code="TIMEOUT",
            )
