"""
HTTP Client for Recursor MCP Server.
Full-featured client matching SDK capabilities for developers using coding assistants.
Refactored to use mixins for modularity.
"""

from .clients.base import RecursorClientBase
from .clients.auth import AuthClientMixin
from .clients.projects import ProjectsClientMixin
from .clients.billing import BillingClientMixin
from .clients.notifications import NotificationsClientMixin
from .clients.settings import SettingsClientMixin
from .clients.activity import ActivityClientMixin
from .clients.synchronization import SynchronizationClientMixin
from .clients.corrections import CorrectionsClientMixin
from .clients.intelligence import CodeIntelligenceClientMixin
from .clients.memory import MemoryClientMixin
from .clients.gateway import GatewayClientMixin
from .clients.websocket import WebSocketClientMixin

class RecursorClient(
    RecursorClientBase,
    AuthClientMixin,
    ProjectsClientMixin,
    BillingClientMixin,
    NotificationsClientMixin,
    SettingsClientMixin,
    ActivityClientMixin,
    SynchronizationClientMixin,
    CorrectionsClientMixin,
    CodeIntelligenceClientMixin,
    MemoryClientMixin,
    GatewayClientMixin,
    WebSocketClientMixin
):
    """
    Main Recursor Client combining all functional mixins.
    Inherits initialization and base HTTP methods from RecursorClientBase.
    """
    pass
