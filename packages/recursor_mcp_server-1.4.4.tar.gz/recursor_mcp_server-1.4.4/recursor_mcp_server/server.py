import os
import sys

from dotenv import load_dotenv
from mcp.server.fastmcp import FastMCP

# Load environment variables
load_dotenv()

from recursor_mcp_server.client import RecursorClient

# Initialize the MCP server
mcp = FastMCP("Recursor")

# Initialize API Client (lazy load to allow env vars to be set)
_client = None

def get_client() -> RecursorClient:
    global _client
    if not _client:
        _client = RecursorClient()
    return _client

def main():
    """Run the MCP server using stdio transport"""
    print("✅ System Management Interface (SMI): Linked", file=sys.stderr)
    print("✅ Codebase Watcher: Active", file=sys.stderr)
    mcp.run()

