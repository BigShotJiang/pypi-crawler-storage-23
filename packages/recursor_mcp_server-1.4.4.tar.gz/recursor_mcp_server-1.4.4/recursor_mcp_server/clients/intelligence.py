"""
Code Intelligence Client Mixin
"""
from typing import Any, Dict, List, Optional

class CodeIntelligenceClientMixin:
    """Code Intelligence related methods"""
    
    async def detect_intent(
        self,
        user_request: str,
        current_file: Optional[str] = None,
        user_id: Optional[str] = None,
        project_id: Optional[str] = None,
        tags: Optional[List[str]] = None,
        similar_limit: int = 5
    ) -> Dict[str, Any]:
        """Detect user intent"""
        payload = {
            "user_request": user_request[:4000],
            "current_file": current_file,
            "user_id": user_id,
            "project_id": project_id,
            "tags": tags or [],
            "similar_limit": similar_limit
        }
        return await self._post("/client/code_intelligence/detect-intent", payload)
    
    async def get_intent_history(self, limit: int = 50, project_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get intent history"""
        params = {"limit": limit}
        if project_id:
            params["project_id"] = project_id
        data = await self._get("/client/code_intelligence/intent-history", params)
        return data if isinstance(data, list) else []
    
    async def correct_code(
        self,
        code: str,
        language: str,
        project_profile: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Correct code"""
        payload = {
            "code": code,
            "language": language,
            "project_profile": project_profile or {}
        }
        return await self._post("/client/code_intelligence/correct/code", payload)
    
    async def correct_config(self, config: str, config_type: str) -> Dict[str, Any]:
        """Correct config"""
        payload = {"config": config, "config_type": config_type}
        return await self._post("/client/code_intelligence/correct/config", payload)
    
    async def correct_documentation(self, markdown: str, doc_type: str = "README") -> Dict[str, Any]:
        """Correct documentation"""
        payload = {"markdown": markdown, "doc_type": doc_type}
        return await self._post("/client/code_intelligence/correct/documentation", payload)
    
    async def get_patterns(self, user_id: Optional[str] = None, project_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get patterns"""
        params = {}
        if user_id:
            params["user_id"] = user_id
        if project_id:
            params["project_id"] = project_id
            
        data = await self._get("/client/code_intelligence/patterns", params if params else None)
        return data if isinstance(data, list) else []
    
    async def get_analytics_dashboard(
        self,
        user_id: str,
        period: str = "30d",
        project_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """Get analytics dashboard"""
        params = {"user_id": user_id, "period": period}
        if project_id:
            params["project_id"] = project_id
        return await self._get("/client/code_intelligence/analytics/dashboard", params)

    async def get_time_saved(self, user_id: str, period: str = "30d", project_id: Optional[str] = None) -> Dict[str, Any]:
        """Get time saved metrics"""
        params = {"user_id": user_id, "period": period}
        if project_id:
            params["project_id"] = project_id
        return await self._get("/client/code_intelligence/analytics/time-saved", params)
    
    async def get_quality_metrics(self, user_id: str, period: str = "30d", project_id: Optional[str] = None) -> Dict[str, Any]:
        """Get quality metrics"""
        params = {"user_id": user_id, "period": period}
        if project_id:
            params["project_id"] = project_id
        return await self._get("/client/code_intelligence/analytics/quality", params)
    
    async def get_ai_agent_metrics(self, user_id: str, project_id: Optional[str] = None) -> Dict[str, Any]:
        """Get AI agent metrics"""
        params = {"user_id": user_id}
        if project_id:
            params["project_id"] = project_id
        return await self._get("/client/code_intelligence/analytics/ai-agent", params)
    
    async def apply_auto_corrections(self, user_id: str, model_name: str, corrections: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Apply auto corrections"""
        payload = {
            "user_id": user_id,
            "model_name": model_name,
            "corrections": corrections
        }
        return await self._post("/client/code_intelligence/auto-correct", payload)
    
    async def get_trust_score(self, user_id: str, model_name: str) -> float:
        """Get trust score"""
        params = {"user_id": user_id, "model_name": model_name}
        data = await self._get("/client/code_intelligence/trust-score", params)
        try:
            return float(data.get("trust_score", 0))
        except Exception:
            return 0.0
    
    async def submit_feedback(self, prediction_id: str, accepted: bool) -> Dict[str, Any]:
        """Submit feedback"""
        payload = {"prediction_id": prediction_id, "accepted": bool(accepted)}
        return await self._post("/client/code_intelligence/feedback", payload)
    
    async def get_auto_correct_stats(self, user_id: str) -> Dict[str, Any]:
        """Get auto correction stats"""
        params = {"user_id": user_id}
        return await self._get("/client/code_intelligence/stats", params)
