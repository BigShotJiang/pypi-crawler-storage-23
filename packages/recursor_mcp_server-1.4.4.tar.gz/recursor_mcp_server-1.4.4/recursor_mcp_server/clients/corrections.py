"""
Corrections Client Mixin
"""
from typing import Any, Dict, List, Optional

class CorrectionsClientMixin:
    """Correction related methods"""
    
    async def search_corrections(self, query: str, limit: int = 5, project_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Search corrections via API"""
        params = {"query": query, "limit": limit}
        if project_id:
            params["project_id"] = project_id
        data = await self._get("/client/corrections/search", params)
        return data.get("corrections", []) if isinstance(data, dict) else data if isinstance(data, list) else []

    async def add_correction(
        self, 
        input_text: str, 
        output_text: str, 
        explanation: str,
        expected_output: Optional[str] = None,
        correction_type: Optional[str] = None,
        project_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """Add a correction via API"""
        payload = {
            "input_text": input_text,
            "output_text": output_text,
            "expected_output": expected_output or output_text,
            "correction_type": correction_type or "mcp_learned",
            "context": {"explanation": explanation, "source": "mcp"}
        }
        path = "/client/corrections/"
        if project_id:
            path = f"/client/corrections/?project_id={project_id}"
        return await self._post(path, payload)
    
    async def list_corrections(
        self,
        page: int = 1,
        page_size: int = 50,
        include_inactive: bool = False,
        project_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """List corrections"""
        params = {"page": page, "page_size": page_size, "include_inactive": include_inactive}
        if project_id:
            params["project_id"] = project_id
        return await self._get("/client/corrections/", params)
    
    async def get_correction(self, correction_id: str) -> Dict[str, Any]:
        """Get correction by ID"""
        return await self._get(f"/client/corrections/{correction_id}")
    
    async def update_correction(self, correction_id: str, updates: Dict[str, Any]) -> Dict[str, Any]:
        """Update correction"""
        return await self._put(f"/client/corrections/{correction_id}", updates)
    
    async def get_correction_stats(self) -> Dict[str, Any]:
        """Get correction statistics"""
        return await self._get("/client/corrections/stats")
