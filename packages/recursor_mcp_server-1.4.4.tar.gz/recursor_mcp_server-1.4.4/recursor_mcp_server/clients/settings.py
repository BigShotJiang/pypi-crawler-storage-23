"""
Settings Client Mixin
"""
from typing import Any, Dict, List, Optional

class SettingsClientMixin:
    """Settings related methods"""
    
    async def get_settings(self) -> Dict[str, Any]:
        """Get user settings"""
        return await self._get("/client/settings")
    
    async def update_account(self, full_name: Optional[str] = None, email: Optional[str] = None) -> Dict[str, Any]:
        """Update account information"""
        payload = {}
        if full_name is not None:
            payload["full_name"] = full_name
        if email is not None:
            payload["email"] = email
        return await self._put("/client/settings/account", payload)
    
    async def update_preferences(self, preferences: Dict[str, Any]) -> Dict[str, Any]:
        """Update user preferences"""
        return await self._put("/client/settings/preferences", preferences)
    
    async def get_guidelines(self) -> Dict[str, Any]:
        """Get coding guidelines"""
        return await self._get("/client/settings/guidelines")
    
    async def change_password_via_settings(self, current_password: str, new_password: str) -> None:
        """Change password via settings"""
        await self._put("/client/settings/password", {
            "current_password": current_password,
            "new_password": new_password
        })
    
    async def delete_account(self) -> None:
        """Delete user account"""
        await self._delete("/client/settings/account")
