"""
Activity Logs Client Mixin
"""
from typing import Any, Dict, List, Optional
import aiohttp

class ActivityClientMixin:
    """Activity Logs related methods"""
    
    async def list_activity_logs(self, page: int = 1, page_size: int = 50) -> Dict[str, Any]:
        """List activity logs"""
        params = {"page": page, "page_size": page_size}
        return await self._get("/client/activity", params)
    
    async def export_activity_logs(self) -> bytes:
        """Export activity logs as CSV"""
        url = self._get_full_url("/client/activity/export")
        async with aiohttp.ClientSession() as session:
            async with session.get(url, headers=self.headers) as resp:
                if resp.status >= 400:
                    raise Exception(f"API error {resp.status}: {await resp.text()}")
                return await resp.read()
