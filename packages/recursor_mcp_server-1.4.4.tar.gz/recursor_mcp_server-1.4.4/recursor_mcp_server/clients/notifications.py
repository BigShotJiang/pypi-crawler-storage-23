"""
Notifications Client Mixin
"""
from typing import Any, Dict, List, Optional

class NotificationsClientMixin:
    """Notifications related methods"""
    
    async def list_notifications(self) -> List[Dict[str, Any]]:
        """List notifications"""
        data = await self._get("/client/notifications")
        return data.get("notifications", []) if isinstance(data, dict) else []
    
    async def mark_notification_as_read(self, notification_id: str) -> Dict[str, Any]:
        """Mark notification as read"""
        return await self._post(f"/client/notifications/{notification_id}/read", {})
    
    async def mark_all_notifications_as_read(self) -> None:
        """Mark all notifications as read"""
        await self._post("/client/notifications/read-all", {})
    
    async def delete_notification(self, notification_id: str) -> None:
        """Delete notification"""
        await self._delete(f"/client/notifications/{notification_id}")
