"""
WebSocket Client Mixin
"""
from typing import Any, Optional

class WebSocketClientMixin:
    """WebSocket related methods"""
    
    def create_websocket(self) -> str:
        """Create WebSocket connection for real-time updates"""
        if not self.access_token:
            raise ValueError(
                "Access token required for WebSocket connection. Use login() first or set_access_token()"
            )
        
        try:
            from websockets.client import connect as ws_connect
        except ImportError:
            raise ImportError("websockets package is required. Install with: pip install websockets")
        
        # Convert http/https to ws/wss
        ws_url = self.api_url.replace("http://", "ws://").replace("https://", "wss://")
        ws_url = f"{ws_url}/client/ws?token={self.access_token}"
        
        return ws_url  # Return URL for connection
    
    async def connect_websocket(self) -> Any:
        """Connect WebSocket and return client (stores internally)"""
        if not self.access_token:
            raise ValueError("Access token required for WebSocket connection. Use login() first or set_access_token()")
        
        try:
            import websockets
        except ImportError:
            raise ImportError("websockets package is required. Install with: pip install websockets")
        
        ws_url = self.create_websocket()
        self._ws_client = await websockets.connect(ws_url)
        return self._ws_client
    
    async def disconnect_websocket(self) -> None:
        """Disconnect WebSocket"""
        if self._ws_client:
            await self._ws_client.close()
            self._ws_client = None
