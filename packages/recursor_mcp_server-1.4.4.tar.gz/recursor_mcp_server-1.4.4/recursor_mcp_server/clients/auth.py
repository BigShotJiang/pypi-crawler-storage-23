"""
Authentication Client Mixin
"""
from typing import Any, Dict, Optional

class AuthClientMixin:
    """Authentication related methods"""
    
    async def register(
        self,
        email: str,
        password: str,
        username: str,
        full_name: Optional[str] = None
    ) -> Dict[str, Any]:
        """Register a new user"""
        payload = {
            "email": email,
            "password": password,
            "username": username,
            "full_name": full_name
        }
        return await self._post("/client/auth/register", payload)
    
    async def login(self, email: str, password: str) -> Dict[str, Any]:
        """Login and get access token"""
        payload = {"email": email, "password": password}
        response = await self._post("/client/auth/login", payload)
        if "access_token" in response:
            self.access_token = response["access_token"]
            self.headers["Authorization"] = f"Bearer {self.access_token}"
            if "X-API-Key" in self.headers:
                del self.headers["X-API-Key"]
        return response
    
    async def logout(self) -> None:
        """Logout current user"""
        await self._post("/client/auth/logout", {})
        
    async def get_profile(self) -> Dict[str, Any]:
        """Get current user profile"""
        return await self._get("/client/auth/me")
    
    async def update_profile(self, full_name: Optional[str] = None, username: Optional[str] = None) -> Dict[str, Any]:
        """Update user profile"""
        payload = {}
        if full_name is not None:
            payload["full_name"] = full_name
        if username is not None:
            payload["username"] = username
        return await self._put("/client/auth/me", payload)
        
    async def refresh_token(self, refresh_token: str) -> Dict[str, Any]:
        """Refresh access token"""
        response = await self._post("/client/auth/refresh", {"refresh_token": refresh_token})
        if "access_token" in response:
            self.access_token = response["access_token"]
            self.headers["Authorization"] = f"Bearer {self.access_token}"
            if "X-API-Key" in self.headers:
                del self.headers["X-API-Key"]
        return response
    
    async def change_password(self, current_password: str, new_password: str) -> None:
        """Change user password"""
        await self._post("/client/auth/change-password", {
            "current_password": current_password,
            "new_password": new_password
        })
    
    async def generate_api_key(self) -> Dict[str, Any]:
        """Generate API key for current user"""
        return await self._post("/client/auth/api-key", {})
    
    async def revoke_api_key(self) -> None:
        """Revoke current user's API key"""
        await self._delete("/client/auth/api-key")
    
    async def get_password_requirements(self) -> Dict[str, Any]:
        """Get password requirements"""
        return await self._get("/client/auth/password-requirements")
