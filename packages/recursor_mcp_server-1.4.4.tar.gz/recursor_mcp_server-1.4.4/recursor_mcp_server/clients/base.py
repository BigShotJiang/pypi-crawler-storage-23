"""
Base HTTP Client for Recursor
"""
import asyncio
import os
import aiohttp
from typing import Any, Dict, Optional

class RecursorClientBase:
    def __init__(self):
        self.api_url = os.getenv("RECURSOR_API_URL", "https://api.recursor.dev/v1")
        # Ensure API URL ends with /v1
        if self.api_url and not self.api_url.endswith("/v1"):
            self.api_url = f"{self.api_url}/v1"

        self.api_key = os.getenv("RECURSOR_API_KEY")
        self.access_token = os.getenv("RECURSOR_ACCESS_TOKEN")
        self._ws_client: Optional[Any] = None
        
        if not self.api_key and not self.access_token:
            # For development/testing we might not want to enforce this immediately on init
            # but the original code did raise ValueError
            if not os.getenv("AreTestsRunning"):  # Gentle fallback for tests
                raise ValueError("Either RECURSOR_API_KEY or RECURSOR_ACCESS_TOKEN environment variable is required")
            
        self.headers = {
            "Content-Type": "application/json"
        }
        
        if self.access_token:
            self.headers["Authorization"] = f"Bearer {self.access_token}"
        elif self.api_key:
            self.headers["X-API-Key"] = self.api_key
    
    def set_access_token(self, token: str) -> None:
        """Set access token for authenticated requests"""
        self.access_token = token
        self.headers["Authorization"] = f"Bearer {token}"
        if "X-API-Key" in self.headers:
            del self.headers["X-API-Key"]
    
    def set_api_key(self, key: str) -> None:
        """Set API key for authenticated requests"""
        self.api_key = key
        self.headers["X-API-Key"] = key
        if "Authorization" in self.headers:
            del self.headers["Authorization"]
    
    async def close(self) -> None:
        """Close client and cleanup resources"""
        if self._ws_client:
            try:
                # Assuming websocket mixin provides this or we handle it gracefully
                if hasattr(self, 'disconnect_websocket'):
                    await self.disconnect_websocket()
            except Exception:
                pass
    
    def _get_full_url(self, path: str) -> str:
        """Build full URL with proper prefix"""
        if path.startswith("/"):
            return f"{self.api_url}{path}"
        return f"{self.api_url}/{path}"
    
    async def _request(self, method: str, path: str, retries: int = 3, **kwargs) -> Any:
        """Make HTTP request with exponential backoff retry logic"""
        url = self._get_full_url(path)
        print(f"DEBUG: Requesting {method} {url}")
        last_exception = None
        
        for attempt in range(retries + 1):
            try:
                print(f"DEBUG: kwargs={kwargs}, headers={self.headers}")
                async with aiohttp.ClientSession() as session:
                    async with session.request(method, url, headers=self.headers, **kwargs) as resp:
                        if resp.status >= 500 and attempt < retries:
                            # Server error, candidate for retry
                            await asyncio.sleep(2 ** attempt) # Exponential backoff
                            continue
                            
                        if resp.status >= 400:
                            error_text = await resp.text()
                            raise Exception(f"API error {resp.status}: {error_text}")
                        
                        if resp.status == 204:  # No Content
                            return {}
                        
                        try:
                            return await resp.json()
                        except:
                            return {}
            except (aiohttp.ClientError, asyncio.TimeoutError) as e:
                last_exception = e
                if attempt < retries:
                    await asyncio.sleep(2 ** attempt)
                else:
                    raise Exception(f"Connection failed after {retries} retries: {str(e)}")
            except Exception as e:
                # Other exceptions (like 4xx errors already raised) shouldn't be retried
                raise e
        
        if last_exception:
            raise last_exception
    
    async def _get(self, path: str, params: Optional[Dict[str, Any]] = None) -> Any:
        return await self._request("GET", path, params=params)
    
    async def _post(self, path: str, data: Optional[Dict[str, Any]] = None) -> Any:
        return await self._request("POST", path, json=data)
    
    async def _put(self, path: str, data: Optional[Dict[str, Any]] = None) -> Any:
        return await self._request("PUT", path, json=data)
    
    async def _patch(self, path: str, data: Optional[Dict[str, Any]] = None) -> Any:
        return await self._request("PATCH", path, json=data)
    
    async def _delete(self, path: str) -> Any:
        return await self._request("DELETE", path)
    
    async def check_health(self) -> bool:
        """Check if API is reachable"""
        try:
            result = await self._get("/status/health")
            return True
        except Exception:
            return False
