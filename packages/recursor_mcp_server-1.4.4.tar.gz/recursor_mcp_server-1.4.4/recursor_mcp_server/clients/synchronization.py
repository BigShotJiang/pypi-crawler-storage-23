"""
Synchronization Client Mixin
"""
from typing import Any, Dict, List, Optional

class SynchronizationClientMixin:
    """File synchronization related methods"""
    
    async def sync_file(self, file_metadata: Dict[str, Any]) -> Dict[str, Any]:
        """Sync a single file's metadata to the cloud"""
        return await self._post("/codebase/sync-file", data=file_metadata)
        
    async def sync_batch(self, files: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Sync multiple files' metadata in a single batch"""
        return await self._post("/codebase/sync-batch", data={"files": files})
        
    async def sync_delete(self, path: str) -> Dict[str, Any]:
        """Sync a file deletion to the cloud"""
        return await self._post("/codebase/sync-delete", data={"path": path})
