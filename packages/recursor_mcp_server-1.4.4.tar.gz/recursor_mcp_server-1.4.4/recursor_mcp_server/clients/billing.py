"""
Billing Client Mixin
"""
from typing import Any, Dict, List, Optional

class BillingClientMixin:
    """Billing related methods"""
    
    async def get_usage(self) -> Dict[str, Any]:
        """Get current usage statistics"""
        return await self._get("/client/billing/usage")
    
    async def get_usage_history(self, days: int = 30, resource_type: Optional[str] = None) -> Dict[str, Any]:
        """Get usage history"""
        params = {"days": days}
        if resource_type:
            params["resource_type"] = resource_type
        return await self._get("/client/billing/usage/history", params)
    
    async def list_billing_plans(self) -> List[Dict[str, Any]]:
        """List available billing plans"""
        data = await self._get("/client/billing/plans")
        return data.get("plans", []) if isinstance(data, dict) else []
    
    async def get_subscription(self) -> Dict[str, Any]:
        """Get current subscription"""
        return await self._get("/client/billing/subscription")
