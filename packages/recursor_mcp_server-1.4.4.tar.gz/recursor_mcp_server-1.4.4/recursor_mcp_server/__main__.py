"""
Entry point for running MCP server or HTTP bridge
"""
from recursor_mcp_server.cli import main

if __name__ == "__main__":
    main()

