"""
Recursor MCP Server - Model Context Protocol server for AI assistants
"""

__version__ = "1.4.3"

# Import tools and resources to register them with the MCP server
from recursor_mcp_server import resources, tools
from recursor_mcp_server.client import RecursorClient
from recursor_mcp_server.server import get_client, mcp

__all__ = ["mcp", "get_client", "RecursorClient", "__version__"]

