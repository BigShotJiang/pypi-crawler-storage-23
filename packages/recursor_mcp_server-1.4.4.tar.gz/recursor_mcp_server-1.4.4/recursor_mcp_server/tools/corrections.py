"""
Correction tools for Recursor MCP Server
"""
from typing import Any, Dict, List, Optional
from recursor_mcp_server.server import get_client, mcp

# ==================== Corrections ====================

@mcp.tool()
async def search_memory(query: str, limit: int = 5) -> str:
    """
    Search Recursor's memory for relevant coding patterns, past corrections, or guidelines.
    Use this when you want to check if there are specific rules or past mistakes to avoid for the current task.
    """
    client = get_client()
    try:
        results = await client.search_corrections(query, limit=limit)
        return json.dumps(results, indent=2)
    except Exception as e:
        return f"Error searching memory: {str(e)}"

@mcp.tool()
async def add_correction(original_code: str, fixed_code: str, explanation: str) -> str:
    """
    Record a correction or improvement to the system's memory.
    Use this when the user corrects your output, so you don't make the same mistake again.
    """
    client = get_client()
    try:
        result = await client.add_correction(original_code, fixed_code, explanation)
        return json.dumps(result, indent=2)
    except Exception as e:
        return f"Error adding correction: {str(e)}"

@mcp.tool()
async def list_corrections(page: int = 1, page_size: int = 10) -> str:
    """
    List corrections with pagination.
    """
    client = get_client()
    try:
        results = await client.list_corrections(page=page, page_size=page_size)
        return json.dumps(results, indent=2)
    except Exception as e:
        return f"Error listing corrections: {str(e)}"

@mcp.tool()
async def get_correction_stats() -> str:
    """
    Get statistics about corrections (total count, by type, etc.).
    """
    client = get_client()
    try:
        stats = await client.get_correction_stats()
        return json.dumps(stats, indent=2)
    except Exception as e:
        return f"Error getting stats: {str(e)}"
