"""
Safety tools for Recursor MCP Server
"""
import json
from typing import Any, Dict, List, Optional
from recursor_mcp_server.server import get_client, mcp

# ==================== Safety ====================

@mcp.tool()
async def check_safety(code_snippet: str) -> str:
    """
    Validate a code snippet against safety guardrails.
    """
    client = get_client()
    try:
        result = await client.check_safety(code_snippet)
        return json.dumps(result, indent=2)
    except Exception as e:
        return f"Error checking safety: {str(e)}"
