"""
Authentication tools for Recursor MCP Server
"""
import json
from typing import Any, Dict, List, Optional
from recursor_mcp_server.server import get_client, mcp

# ==================== Authentication ====================

@mcp.tool()
async def login(email: str, password: str) -> str:
    """
    Login to Recursor and get an access token. This will be used for subsequent requests.
    """
    client = get_client()
    try:
        result = await client.login(email, password)
        return json.dumps(result, indent=2)
    except Exception as e:
        return f"Error logging in: {str(e)}"

@mcp.tool()
async def get_profile() -> str:
    """
    Get the current user's profile information.
    """
    client = get_client()
    try:
        profile = await client.get_profile()
        return json.dumps(profile, indent=2)
    except Exception as e:
        return f"Error getting profile: {str(e)}"

@mcp.tool()
async def update_profile(full_name: Optional[str] = None, username: Optional[str] = None) -> str:
    """
    Update user profile information.
    """
    client = get_client()
    try:
        result = await client.update_profile(full_name=full_name, username=username)
        return json.dumps(result, indent=2)
    except Exception as e:
        return f"Error updating profile: {str(e)}"
