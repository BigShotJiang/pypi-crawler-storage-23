"""
Project tools for Recursor MCP Server
"""
import json
from typing import Any, Dict, List, Optional
from recursor_mcp_server.server import get_client, mcp

# ==================== Projects ====================

@mcp.tool()
async def create_project(name: str, description: Optional[str] = None) -> str:
    """
    Create a new project in Recursor.
    """
    client = get_client()
    try:
        result = await client.create_project(name, description)
        return json.dumps(result, indent=2)
    except Exception as e:
        return f"Error creating project: {str(e)}"

@mcp.tool()
async def list_projects() -> str:
    """
    List all projects for the current user.
    """
    client = get_client()
    try:
        projects = await client.list_projects()
        return json.dumps(projects, indent=2)
    except Exception as e:
        return f"Error listing projects: {str(e)}"

@mcp.tool()
async def get_project(project_id: str) -> str:
    """
    Get project details by ID.
    """
    client = get_client()
    try:
        project = await client.get_project(project_id)
        return json.dumps(project, indent=2)
    except Exception as e:
        return f"Error getting project: {str(e)}"

@mcp.tool()
async def get_mcp_config(project_id: str) -> str:
    """
    Get MCP server configuration for a project. Use this to set up Claude Desktop or Cursor.
    """
    client = get_client()
    try:
        config = await client.get_mcp_config(project_id)
        return json.dumps(config, indent=2)
    except Exception as e:
        return f"Error getting MCP config: {str(e)}"
