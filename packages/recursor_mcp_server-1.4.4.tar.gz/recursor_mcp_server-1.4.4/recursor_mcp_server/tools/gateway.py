"""
Gateway tools for Recursor MCP Server
"""
import json
from typing import Any, Dict, List, Optional
from recursor_mcp_server.server import get_client, mcp

# ==================== Gateway ====================

@mcp.tool()
async def gateway_chat(
    messages: str,
    provider: str = "gradient",
    model: Optional[str] = None
) -> str:
    """
    Send messages through the Recursor LLM gateway. This applies corrections and memory injection automatically.
    The messages parameter should be a JSON string array of message objects with 'role' and 'content' fields.
    """
    client = get_client()
    try:
        # Check if messages is a string, if so parse it
        if isinstance(messages, str):
            try:
                parsed_messages = json.loads(messages)
            except json.JSONDecodeError:
                return "Error: messages parameter must be a valid JSON string"
        else:
            parsed_messages = messages
            
        result = await client.gateway_chat(parsed_messages, provider=provider, model=model)
        return json.dumps(result, indent=2)
    except Exception as e:
        return f"Error calling gateway: {str(e)}"
