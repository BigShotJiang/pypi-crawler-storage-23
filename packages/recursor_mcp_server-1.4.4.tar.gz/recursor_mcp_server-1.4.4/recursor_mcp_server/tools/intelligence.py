"""
Code Intelligence tools for Recursor MCP Server
"""
import json
from typing import Any, Dict, List, Optional
from recursor_mcp_server.server import get_client, mcp

# ==================== Code Intelligence ====================

@mcp.tool()
async def detect_intent(user_request: str, current_file: Optional[str] = None) -> str:
    """
    Detect the user's intent from their request. Returns action, scope, constraints, and similar past requests.
    Use this to understand what the user wants before implementing.
    """
    client = get_client()
    try:
        result = await client.detect_intent(user_request, current_file=current_file)
        return json.dumps(result, indent=2)
    except Exception as e:
        return f"Error detecting intent: {str(e)}"

@mcp.tool()
async def correct_code(code: str, language: str) -> str:
    """
    Get AI-suggested corrections for code based on learned patterns.
    """
    client = get_client()
    try:
        result = await client.correct_code(code, language)
        return json.dumps(result, indent=2)
    except Exception as e:
        return f"Error correcting code: {str(e)}"

@mcp.tool()
async def get_coding_patterns(project_id: Optional[str] = None) -> str:
    """
    Get learned coding patterns from the system.
    """
    client = get_client()
    try:
        patterns = await client.get_patterns(project_id=project_id)
        return json.dumps(patterns, indent=2)
    except Exception as e:
        return f"Error getting patterns: {str(e)}"

@mcp.tool()
async def get_analytics(user_id: str, period: str = "30d") -> str:
    """
    Get analytics dashboard with time saved, quality metrics, and AI agent performance.
    """
    client = get_client()
    try:
        analytics = await client.get_analytics_dashboard(user_id=user_id, period=period)
        return json.dumps(analytics, indent=2)
    except Exception as e:
        return f"Error getting analytics: {str(e)}"
