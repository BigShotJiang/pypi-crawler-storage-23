"""
MCP Tools - Type hints and re-exports for backward compatibility.
Refactored into `tools/` directory.
"""
from typing import Optional

# Re-export all tools from the split modules
from .corrections import (
    search_memory,
    add_correction,
    list_corrections,
    get_correction_stats
)
from .intelligence import (
    detect_intent,
    correct_code,
    get_coding_patterns,
    get_analytics
)
from .projects import (
    create_project,
    list_projects,
    get_project,
    get_mcp_config
)
from .auth import (
    login,
    get_profile,
    update_profile
)
from .memory import (
    query_rotatable_memory,
    get_memory_stats,
    get_conversation_summaries,
    get_architectural_changes
)
from .gateway import gateway_chat
from .safety import check_safety

__all__ = [
    # Corrections
    "search_memory",
    "add_correction",
    "list_corrections",
    "get_correction_stats",
    # Intelligence
    "detect_intent",
    "correct_code",
    "get_coding_patterns",
    "get_analytics",
    # Projects
    "create_project",
    "list_projects",
    "get_project",
    "get_mcp_config",
    # Auth
    "login",
    "get_profile",
    "update_profile",
    # Memory
    "query_rotatable_memory",
    "get_memory_stats",
    "get_conversation_summaries",
    "get_architectural_changes",
    # Gateway
    "gateway_chat",
    # Safety
    "check_safety"
]
