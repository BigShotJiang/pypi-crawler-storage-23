"""
Memory tools for Recursor MCP Server
"""
import json
from typing import Any, Dict, List, Optional
from recursor_mcp_server.server import get_client, mcp

# ==================== Memory ====================

@mcp.tool()
async def query_rotatable_memory(
    domain: Optional[str] = None,
    pattern_type: Optional[str] = None,
    limit: int = 20
) -> str:
    """
    Query rotatable memory for learned patterns. This is the system's long-term memory of corrections and patterns.
    """
    client = get_client()
    try:
        results = await client.query_rotatable_memory(domain=domain, pattern_type=pattern_type, limit=limit)
        return json.dumps(results, indent=2)
    except Exception as e:
        return f"Error querying rotatable memory: {str(e)}"

@mcp.tool()
async def get_memory_stats() -> str:
    """
    Get statistics about the rotatable memory system.
    """
    client = get_client()
    try:
        stats = await client.get_memory_stats()
        return json.dumps(stats, indent=2)
    except Exception as e:
        return f"Error getting memory stats: {str(e)}"

@mcp.tool()
async def get_conversation_summaries(limit: int = 5) -> str:
    """
    Get recent conversation summaries. These help maintain context across long conversations.
    """
    client = get_client()
    try:
        summaries = await client.get_conversation_summaries(limit=limit)
        return json.dumps(summaries, indent=2)
    except Exception as e:
        return f"Error getting conversation summaries: {str(e)}"

@mcp.tool()
async def get_architectural_changes(limit: int = 10) -> str:
    """
    Get recent architectural changes to the codebase. These track structural changes over time.
    """
    client = get_client()
    try:
        changes = await client.get_architectural_changes(limit=limit)
        return json.dumps(changes, indent=2)
    except Exception as e:
        return f"Error getting architectural changes: {str(e)}"
