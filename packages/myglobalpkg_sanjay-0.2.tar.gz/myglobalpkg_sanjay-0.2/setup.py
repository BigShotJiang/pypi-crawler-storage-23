from setuptools import setup

setup(
    name="myglobalpkg_sanjay",   # make unique name
    version="0.2",
    description="Simple global package",
    author="hacker",
    packages=["myglobalpkg"],
)