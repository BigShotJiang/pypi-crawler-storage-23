def san():
    print("""
(insert)
#include <stdio.h>
#include <stdlib.h>
void displayArray(int *arr, int count) {
    if (count == 0) {
        printf("Array is empty.\n");
        return;
    }
    printf("Array elements: ");
    for (int i = 0; i < count; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
}
int* insertElement(int *arr, int *count, int element, int position) {
    if (position < 0 || position > *count) {
        printf("Invalid position for insertion.\n");
        return arr;
    }
    *count = *count + 1;
    arr = (int*)realloc(arr, (*count) * sizeof(int));
    if (arr == NULL) {
        printf("Memory re-allocation failed during insertion.\n");
        exit(EXIT_FAILURE);
    }
    for (int i = *count - 1; i > position; i--) {
        arr[i] = arr[i - 1];
    }

    arr[position] = element;
    printf("Element %d inserted at position %d.\n", element, position);
    return arr;
}
int* deleteElement(int *arr, int *count, int position) {
    if (*count == 0) {
        printf("Array is empty, cannot delete.\n");
        return arr;
    }
    if (position < 0 || position >= *count) {
        printf("Invalid position for deletion.\n");
        return arr;
    }
    printf("Element %d deleted from position %d.\n", arr[position], position);
    for (int i = position; i < *count - 1; i++) {
        arr[i] = arr[i + 1];
    }
    *count = *count - 1;
    if (*count == 0) {
        free(arr); 
        return NULL;
    } else {
        arr = (int*)realloc(arr, (*count) * sizeof(int));
        if (arr == NULL) {
            printf("Memory re-allocation failed after deletion.\n");
            exit(EXIT_FAILURE);
        }
    }
    return arr;
}

int main() {
    int *arr = NULL; 
    int count = 0;   
    int choice, element, position;
    do {
        printf("\n--- Array Operations Menu ---\n");
        printf("1. Insert Element\n");
        printf("2. Delete Element\n");
        printf("3. Display Array\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        switch (choice) {
            case 1:
                printf("Enter element to insert: ");
                scanf("%d", &element);
                printf("Enter position to insert (0 to %d): ", count);
                scanf("%d", &position);
                arr = insertElement(arr, &count, element, position);
                break;
            case 2:
                printf("Enter position to delete (0 to %d): ", count - 1);
                scanf("%d", &position);
                arr = deleteElement(arr, &count, position);
                break;
            case 3:
                displayArray(arr, count);
                break;
            case 4:
                printf("Exiting program.\n");
                break;
            default:
                printf("Invalid choice. Please try again.\n");
        }
    } while (choice != 4);
    if (arr != NULL) {
        free(arr);
    }
    return 0;
}
(push)
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#define MAX_SIZE 5
int stack[MAX_SIZE],top=-1;
bool isEmpty() {
    return top == -1;
}
void push(int item) {
    if (top == MAX_SIZE - 1) {
        printf("Stack Overflow\n");
    } else {
        stack[++top] = item;
    }
}
int pop() {
    if (isEmpty()) {
        printf("Stack Underflow\n");
        return -1; // Indicating underflow
    } else {
        return stack[top--];
    }
}
int peek() {
    if (isEmpty()) {
        printf("Stack is Empty\n");
        return -1; // Indicating empty stack
    } else {
        return stack[top];
    }
}
void show()
{
    int i;
    if (isEmpty()) 
        printf("Stack is Empty\n");
    else{
    for(i=top;i>-1;i--)
        printf("%d\n",stack[i]);
    }
}
int main() {
    int ch,data;
    do{
        printf("\n1. Push\n2. Pop\n3. Peek\n4. Show\n5. Exit");
        printf("\nEnter your choice:   ");
        scanf("%d",&ch);
        switch(ch)
        {
            case 1: printf("Enter data to push:  ");
                    scanf("%d",&data);
                    push(data);
                    break;
            case 2: printf("Popped: %d\n", pop());
                    break;
            case 3: printf("Top element: %d\n", peek());
                    break;
            case 4: show();
                    break;
            case 5: break;
            default: printf("Enter valid choice");
        }
    }while(ch!=5);
    return 0;
}


""")