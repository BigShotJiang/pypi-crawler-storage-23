INDEX_MD = """# {pkg_name}

Description of the project.

## Installation

```bash
pip install {pkg_name}
```

## Table of contents

```{{toctree}}
:maxdepth: 1

notebooks/userguide
advanceduse
apireference
```

## Links

- Source repository:
  [{source_repo}]({source_repo})
- PyPI:
  [{pypi_project}]({pypi_project})
- Documentation:
  [{documentation_page}]({documentation_page})
"""
