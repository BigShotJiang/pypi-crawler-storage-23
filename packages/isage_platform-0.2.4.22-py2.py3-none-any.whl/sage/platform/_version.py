"""Version information for sage-platform."""

__version__ = "0.2.4.22"
__author__ = "IntelliStream Team"
__email__ = "shuhao_zhang@hust.edu.cn"
