def main():
    print("Hello from td-parser-pro!")


if __name__ == "__main__":
    main()
