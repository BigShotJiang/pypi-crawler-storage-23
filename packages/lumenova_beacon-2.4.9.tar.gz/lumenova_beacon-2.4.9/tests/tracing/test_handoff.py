"""Tests for agent handoff trace separation."""

import pytest
from uuid import uuid4
from unittest.mock import MagicMock, patch

from lumenova_beacon import BeaconClient
from lumenova_beacon.tracing.span import Span, SpanLink
from lumenova_beacon.types import SpanType, StatusCode


def _make_handler(**kwargs):
    """Create a BeaconCallbackHandler with a mock client."""
    from lumenova_beacon.tracing.integrations.langchain import BeaconCallbackHandler

    with patch("lumenova_beacon.tracing.integrations.langchain.get_client") as mock_get:
        mock_client = MagicMock()
        mock_client.config.session_id = None
        mock_client.config.environment = None
        mock_client._timestamp_override = None
        mock_get.return_value = mock_client
        return BeaconCallbackHandler(**kwargs)


@pytest.fixture
def client():
    """Create a BeaconClient with OTEL disabled for unit tests."""
    return BeaconClient(
        endpoint="https://api.test.com",
        api_key="test-key",
        auto_instrument_opentelemetry=False,
    )


class TestSpanLink:
    """Tests for the SpanLink dataclass."""

    def test_span_link_creation(self):
        link = SpanLink(trace_id="aabb", span_id="ccdd")
        assert link.trace_id == "aabb"
        assert link.span_id == "ccdd"
        assert link.attributes == {}

    def test_span_link_with_attributes(self):
        link = SpanLink(
            trace_id="aabb",
            span_id="ccdd",
            attributes={"link.type": "child_trace"},
        )
        assert link.attributes == {"link.type": "child_trace"}


class TestSpanAddLink:
    """Tests for Span.add_link()."""

    def test_add_link(self):
        span = Span(name="test")
        span.add_link("trace-aaa", "span-bbb")
        assert len(span.links) == 1
        assert span.links[0].trace_id == "trace-aaa"
        assert span.links[0].span_id == "span-bbb"
        assert span.links[0].attributes == {}

    def test_add_link_with_attributes(self):
        span = Span(name="test")
        span.add_link("trace-aaa", "span-bbb", {"link.type": "child_trace"})
        assert span.links[0].attributes == {"link.type": "child_trace"}

    def test_add_link_returns_self(self):
        span = Span(name="test")
        result = span.add_link("trace-aaa", "span-bbb")
        assert result is span

    def test_add_multiple_links(self):
        span = Span(name="test")
        span.add_link("trace-1", "span-1")
        span.add_link("trace-2", "span-2")
        assert len(span.links) == 2

    def test_links_empty_by_default(self):
        span = Span(name="test")
        assert span.links == []


class TestSpanToDict:
    """Tests for Span.to_dict() with links."""

    def test_to_dict_without_links(self):
        span = Span(name="test")
        span.start()
        span.end()
        d = span.to_dict()
        assert "links" not in d

    def test_to_dict_with_links(self):
        span = Span(name="test")
        span.add_link("trace-aaa", "span-bbb", {"link.type": "child_trace"})
        span.start()
        span.end()
        d = span.to_dict()
        assert "links" in d
        assert len(d["links"]) == 1
        assert d["links"][0] == {
            "context": {"trace_id": "trace-aaa", "span_id": "span-bbb"},
            "attributes": {"link.type": "child_trace"},
        }


class TestSpanToOtelSpanLinks:
    """Tests for Span.to_otel_span() with links."""

    def test_otel_span_empty_links(self):
        span = Span(
            name="test",
            trace_id="a" * 32,
            span_id="b" * 16,
        )
        span.start()
        span.end()
        otel_span = span.to_otel_span()
        assert otel_span.links == ()

    def test_otel_span_with_links(self):
        span = Span(
            name="test",
            trace_id="a" * 32,
            span_id="b" * 16,
        )
        span.add_link("c" * 32, "d" * 16, {"link.type": "child_trace"})
        span.start()
        span.end()
        otel_span = span.to_otel_span()
        assert len(otel_span.links) == 1

        link = otel_span.links[0]
        assert link.context.trace_id == int("c" * 32, 16)
        assert link.context.span_id == int("d" * 16, 16)
        assert link.context.is_remote is True
        assert link.attributes == {"link.type": "child_trace"}


class TestHandlerHandoffContext:
    """Tests for BeaconCallbackHandler.handoff_context() state swap."""

    @pytest.fixture
    def handler(self):
        """Create a BeaconCallbackHandler for testing."""
        return _make_handler(agent_name="Orchestrator")

    def test_handoff_span_in_parent_trace(self, handler):
        """HANDOFF span should use the handler's current trace_id."""
        # Simulate handler having an active trace
        handler._current_trace_id = "parent_trace_aaa"
        handler._root_span_id = "root_span_bbb"

        with handler.handoff_context("Math Agent") as ctx:
            assert ctx.handoff_span.trace_id == "parent_trace_aaa"
            assert ctx.handoff_span.span_type == SpanType.HANDOFF
            assert ctx.handoff_span.name == "handoff:Math Agent"

    def test_handoff_span_parented_under_active_tool(self, handler):
        """HANDOFF span parent_id should be the active tool span."""
        handler._current_trace_id = "parent_trace"
        # Simulate an active tool span
        tool_span = Span(name="handoff_to_math_agent", trace_id="parent_trace")
        handler._runs = {"tool-run-1": {"span": tool_span}}
        handler._active_tool_run_ids = ["tool-run-1"]

        with handler.handoff_context("Math Agent") as ctx:
            assert ctx.handoff_span.parent_id == tool_span.span_id

    def test_state_swapped_for_child(self, handler):
        """After entering, handler state should be set for child trace."""
        handler._current_trace_id = "parent_trace"
        handler._root_span_id = "parent_root"
        handler._runs = {"run-1": {"span": Span(name="test")}}
        handler._active_tool_run_ids = ["run-1"]

        with handler.handoff_context("Math Agent") as ctx:
            assert handler._current_trace_id == ctx.trace_id
            assert handler._root_span_id == ctx.root_span_id
            assert handler._runs == {}
            assert handler._active_tool_run_ids == []

    def test_backlink_params_set_for_child(self, handler):
        """Handler's back-link params should point to parent handoff span."""
        handler._current_trace_id = "parent_trace"
        handler._parent_handoff_trace_id = None
        handler._parent_handoff_span_id = None

        with handler.handoff_context("Math Agent") as ctx:
            assert handler._parent_handoff_trace_id == "parent_trace"
            assert handler._parent_handoff_span_id == ctx.handoff_span.span_id

    def test_restores_state_on_exit(self, handler):
        """All parent state should be restored after the block."""
        handler._current_trace_id = "parent_trace"
        handler._root_span_id = "parent_root"
        original_runs = {"run-1": {"span": Span(name="test")}}
        handler._runs = original_runs
        handler._active_tool_run_ids = ["run-1"]
        handler._agent_name = "Orchestrator"

        with handler.handoff_context("Math Agent"):
            pass

        assert handler._current_trace_id == "parent_trace"
        assert handler._root_span_id == "parent_root"
        assert handler._runs is original_runs
        assert handler._active_tool_run_ids == ["run-1"]
        assert handler._agent_name == "Orchestrator"

    def test_restores_state_on_exception(self, handler):
        """Parent state should be restored even on exception."""
        handler._current_trace_id = "parent_trace"
        handler._root_span_id = "parent_root"

        try:
            with handler.handoff_context("Math Agent"):
                raise ValueError("child failed")
        except ValueError:
            pass

        assert handler._current_trace_id == "parent_trace"
        assert handler._root_span_id == "parent_root"

    def test_handoff_span_has_child_trace_link(self, handler):
        """HANDOFF span should have OTEL link to the child root span."""
        handler._current_trace_id = "parent_trace"

        with handler.handoff_context("Math Agent") as ctx:
            assert len(ctx.handoff_span.links) == 1
            link = ctx.handoff_span.links[0]
            assert link.trace_id == ctx.trace_id
            assert link.span_id == ctx.root_span_id
            assert link.attributes == {"link.type": "child_trace"}

    def test_handoff_span_attributes(self, handler):
        """HANDOFF span should carry target info in attributes."""
        handler._current_trace_id = "parent_trace"

        with handler.handoff_context("Math Agent") as ctx:
            attrs = ctx.handoff_span.attributes
            assert attrs["handoff.target_agent"] == "Math Agent"
            assert attrs["handoff.target_trace_id"] == ctx.trace_id
            assert attrs["handoff.target_root_span_id"] == ctx.root_span_id

    def test_handoff_span_exported(self, handler):
        """HANDOFF span should be exported on exit."""
        handler._current_trace_id = "parent_trace"

        with patch.object(handler.client, "export_span") as mock_export:
            with handler.handoff_context("Math Agent") as ctx:
                pass
            mock_export.assert_called_once_with(ctx.handoff_span)

    def test_handoff_span_records_exception(self, handler):
        """HANDOFF span should record child exceptions."""
        handler._current_trace_id = "parent_trace"

        try:
            with handler.handoff_context("Math Agent") as ctx:
                raise RuntimeError("child crashed")
        except RuntimeError:
            pass

        assert ctx.handoff_span.status_code == StatusCode.ERROR

    def test_agent_name_set_to_target(self, handler):
        """target_agent should set handler._agent_name during handoff."""
        handler._current_trace_id = "parent_trace"
        handler._agent_name = "Orchestrator"

        with handler.handoff_context("Math Agent"):
            assert handler._agent_name == "Math Agent"

        assert handler._agent_name == "Orchestrator"

    def test_handoff_with_explicit_parent_tool_run_id(self, handler):
        """parent_tool_run_id should determine the handoff span's parent."""
        handler._current_trace_id = "parent_trace"
        handler._root_span_id = "root_span"

        # Two active tool spans
        tool_a_span = Span(name="tool_a", trace_id="parent_trace")
        tool_b_span = Span(name="tool_b", trace_id="parent_trace")
        handler._runs = {
            "tool-run-a": {"span": tool_a_span},
            "tool-run-b": {"span": tool_b_span},
        }
        handler._active_tool_run_ids = ["tool-run-a", "tool-run-b"]

        # Handoff specifying tool A as parent (tool B is most recent)
        with handler.handoff_context("Sub Agent", parent_tool_run_id="tool-run-a") as ctx:
            assert ctx.handoff_span.parent_id == tool_a_span.span_id

    def test_sequential_handoffs(self, handler):
        """Multiple sequential handoffs should each work independently."""
        handler._current_trace_id = "parent_trace"
        handler._root_span_id = "parent_root"

        with handler.handoff_context("Agent A") as ctx_a:
            trace_a = ctx_a.trace_id

        with handler.handoff_context("Agent B") as ctx_b:
            trace_b = ctx_b.trace_id

        assert trace_a != trace_b
        assert handler._current_trace_id == "parent_trace"

    @pytest.mark.asyncio
    async def test_async_handoff_context(self, handler):
        """Async handoff_context should work identically."""
        handler._current_trace_id = "parent_trace"
        handler._root_span_id = "parent_root"

        async with handler.handoff_context("Math Agent") as ctx:
            assert handler._current_trace_id == ctx.trace_id
            assert ctx.handoff_span.trace_id == "parent_trace"

        assert handler._current_trace_id == "parent_trace"


class TestGetBeaconHandler:
    """Tests for get_beacon_handler() utility."""

    def test_from_list(self):
        from lumenova_beacon.tracing.integrations.langchain import (
            BeaconCallbackHandler,
            get_beacon_handler,
        )
        handler = BeaconCallbackHandler(agent_name="Test")
        config = {"callbacks": [handler]}
        assert get_beacon_handler(config) is handler

    def test_from_callback_manager(self):
        from lumenova_beacon.tracing.integrations.langchain import (
            BeaconCallbackHandler,
            get_beacon_handler,
        )
        handler = BeaconCallbackHandler(agent_name="Test")
        # Simulate a CallbackManager with .handlers attribute
        manager = MagicMock()
        manager.handlers = [handler]
        config = {"callbacks": manager}
        assert get_beacon_handler(config) is handler

    def test_returns_none_when_absent(self):
        from lumenova_beacon.tracing.integrations.langchain import get_beacon_handler
        config = {"callbacks": [MagicMock()]}
        assert get_beacon_handler(config) is None

    def test_returns_none_when_callbacks_none(self):
        from lumenova_beacon.tracing.integrations.langchain import get_beacon_handler
        config = {"callbacks": None}
        assert get_beacon_handler(config) is None

    def test_returns_none_when_no_callbacks_key(self):
        from lumenova_beacon.tracing.integrations.langchain import get_beacon_handler
        config = {}
        assert get_beacon_handler(config) is None


class TestHandoffSpanType:
    """Tests for the HANDOFF SpanType."""

    def test_handoff_enum_value(self):
        assert SpanType.HANDOFF == "handoff"
        assert SpanType.HANDOFF.value == "handoff"

    def test_create_span_with_handoff_type(self, client):
        span = client.create_span("test", span_type=SpanType.HANDOFF)
        assert span.span_type == SpanType.HANDOFF
        assert span.attributes["span.type"] == "handoff"


class TestAutoDetectSubagentHandoff:
    """Tests for auto-detecting subagent handoffs from nested graph invocations."""

    @pytest.fixture
    def handler(self):
        """Create a BeaconCallbackHandler with auto-detect enabled."""
        return _make_handler(agent_name="Orchestrator", autodetect_handoffs=True)

    @pytest.fixture
    def handler_disabled(self):
        """Create a BeaconCallbackHandler with auto-detect disabled (default)."""
        return _make_handler(agent_name="Orchestrator")

    def _setup_active_tool(self, handler, trace_id="parent_trace_aaa"):
        """Set up handler with an active tool span."""
        handler._current_trace_id = trace_id
        handler._root_span_id = "root_span_bbb"
        tool_run_id = uuid4()
        tool_span = Span(name="task", trace_id=trace_id)
        tool_span.start()
        handler._runs = {str(tool_run_id): {"span": tool_span, "parent_run_id": None}}
        handler._active_tool_run_ids = [str(tool_run_id)]
        return tool_run_id

    def _start_subgraph(self, handler, tool_run_id, name="research-assistant", run_id=None):
        """Fire on_chain_start for a subgraph root.

        In real LangGraph, parent_run_id points to the active tool because
        LangGraph propagates the callback context via contextvars.
        """
        run_id = run_id or uuid4()
        handler.on_chain_start(
            serialized={"name": name},
            inputs={"messages": []},
            run_id=run_id,
            parent_run_id=tool_run_id,
            metadata={"langgraph_node": "agent", "langgraph_checkpoint_ns": name},
            tags=["graph:step:1"],
        )
        return run_id

    def test_creates_separate_trace(self, handler):
        """Subgraph root with parent_run_id pointing to active tool should create a new trace."""
        tool_run_id = self._setup_active_tool(handler)
        sub_run_id = self._start_subgraph(handler, tool_run_id)

        assert handler._current_trace_id != "parent_trace_aaa"
        assert str(sub_run_id) in handler._auto_handoff_contexts

    def test_handoff_span_in_parent_trace(self, handler):
        """HANDOFF span should live in the parent trace."""
        tool_run_id = self._setup_active_tool(handler)
        sub_run_id = self._start_subgraph(handler, tool_run_id)

        ctx = handler._auto_handoff_contexts[str(sub_run_id)]
        assert ctx.handoff_span is not None
        assert ctx.handoff_span.trace_id == "parent_trace_aaa"
        assert ctx.handoff_span.span_type == SpanType.HANDOFF

    def test_handoff_span_attributes_and_link(self, handler):
        """HANDOFF span should have target agent info and OTEL link."""
        tool_run_id = self._setup_active_tool(handler)
        sub_run_id = self._start_subgraph(handler, tool_run_id, name="research-agent")

        ctx = handler._auto_handoff_contexts[str(sub_run_id)]
        assert ctx.handoff_span.attributes["handoff.target_agent"] == "research-agent"
        assert ctx.handoff_span.attributes["handoff.target_trace_id"] == ctx.trace_id
        assert len(ctx.handoff_span.links) == 1
        assert ctx.handoff_span.links[0].attributes == {"link.type": "child_trace"}

    def test_subgraph_root_gets_agent_type(self, handler):
        """First span after auto-handoff should be SpanType.AGENT."""
        tool_run_id = self._setup_active_tool(handler)
        sub_run_id = self._start_subgraph(handler, tool_run_id)

        sub_span = handler._runs[str(sub_run_id)]["span"]
        assert sub_span.span_type == SpanType.AGENT

    def test_restores_state_on_chain_end(self, handler):
        """on_chain_end for subgraph root should restore parent state."""
        tool_run_id = self._setup_active_tool(handler)
        sub_run_id = self._start_subgraph(handler, tool_run_id)

        child_trace = handler._current_trace_id
        assert child_trace != "parent_trace_aaa"

        handler.on_chain_end(outputs={"result": "done"}, run_id=sub_run_id)

        assert handler._current_trace_id == "parent_trace_aaa"
        assert handler._root_span_id == "root_span_bbb"
        assert str(sub_run_id) not in handler._auto_handoff_contexts
        # Tool span should be restored
        assert str(tool_run_id) in handler._runs

    def test_restores_state_on_chain_error(self, handler):
        """on_chain_error for subgraph root should restore parent state."""
        tool_run_id = self._setup_active_tool(handler)
        sub_run_id = self._start_subgraph(handler, tool_run_id)

        handler.on_chain_error(
            error=RuntimeError("subgraph crashed"),
            run_id=sub_run_id,
        )

        assert handler._current_trace_id == "parent_trace_aaa"
        assert str(sub_run_id) not in handler._auto_handoff_contexts

    def test_disabled_by_default(self, handler_disabled):
        """Without autodetect_handoffs=True, no handoff is created but span type is AGENT."""
        handler = handler_disabled
        tool_run_id = self._setup_active_tool(handler)
        sub_run_id = self._start_subgraph(handler, tool_run_id)

        # Should stay in same trace (parented under tool, no handoff)
        assert handler._current_trace_id == "parent_trace_aaa"
        assert not handler._auto_handoff_contexts
        # Subagent root should still get AGENT type even without full handoff
        span = handler._runs[str(sub_run_id)]["span"]
        assert span.span_type == SpanType.AGENT

    def test_no_handoff_without_langgraph_metadata(self, handler):
        """Without LangGraph metadata, no handoff even with parent pointing to tool."""
        tool_run_id = self._setup_active_tool(handler)
        sub_run_id = uuid4()

        handler.on_chain_start(
            serialized={"name": "plain-chain"},
            inputs={},
            run_id=sub_run_id,
            parent_run_id=tool_run_id,
            metadata={},
            tags=[],
        )

        assert handler._current_trace_id == "parent_trace_aaa"
        assert not handler._auto_handoff_contexts
        # Without LG metadata, span stays as CHAIN
        span = handler._runs[str(sub_run_id)]["span"]
        assert span.span_type == SpanType.CHAIN

    def test_no_handoff_when_parent_is_not_tool(self, handler):
        """Chain whose parent is NOT an active tool should not trigger handoff."""
        self._setup_active_tool(handler)
        non_tool_parent = uuid4()
        sub_run_id = uuid4()

        handler.on_chain_start(
            serialized={"name": "inner-chain"},
            inputs={},
            run_id=sub_run_id,
            parent_run_id=non_tool_parent,
            metadata={"langgraph_node": "agent"},
            tags=["graph:step:1"],
        )

        assert handler._current_trace_id == "parent_trace_aaa"
        assert not handler._auto_handoff_contexts

    def test_handoff_span_exported_on_exit(self, handler):
        """HANDOFF span should be exported when subgraph root ends."""
        tool_run_id = self._setup_active_tool(handler)
        sub_run_id = self._start_subgraph(handler, tool_run_id)

        with patch.object(handler.client, "export_span") as mock_export:
            handler.on_chain_end(outputs={}, run_id=sub_run_id)

        exported_types = [call.args[0].span_type for call in mock_export.call_args_list]
        assert SpanType.HANDOFF in exported_types

    def test_nested_auto_handoffs(self, handler):
        """Subagent A invokes Subagent B — both should auto-handoff correctly."""
        tool_a_run = self._setup_active_tool(handler)
        original_trace = handler._current_trace_id

        # Subagent A enters (parent_run_id = tool_a)
        sub_a_run = self._start_subgraph(handler, tool_a_run, name="agent-a")
        trace_a = handler._current_trace_id
        assert trace_a != original_trace

        # Tool inside agent-a that will invoke subagent B
        tool_b_run = uuid4()
        handler.on_tool_start(
            serialized={"name": "task"},
            input_str="",
            run_id=tool_b_run,
            parent_run_id=sub_a_run,
        )

        # Subagent B enters (parent_run_id = tool_b)
        sub_b_run = self._start_subgraph(handler, tool_b_run, name="agent-b")
        trace_b = handler._current_trace_id
        assert trace_b != trace_a
        assert trace_b != original_trace

        # End agent-b
        handler.on_chain_end(outputs={}, run_id=sub_b_run)
        assert handler._current_trace_id == trace_a

        # End tool_b
        handler.on_tool_end(output="done", run_id=tool_b_run)

        # End agent-a
        handler.on_chain_end(outputs={}, run_id=sub_a_run)
        assert handler._current_trace_id == original_trace

    def test_agent_name_set_during_handoff(self, handler):
        """agent_name should be the subagent name during auto-handoff."""
        tool_run_id = self._setup_active_tool(handler)
        assert handler._agent_name == "Orchestrator"

        sub_run_id = self._start_subgraph(handler, tool_run_id, name="research-assistant")
        assert handler._agent_name == "research-assistant"

        handler.on_chain_end(outputs={}, run_id=sub_run_id)
        assert handler._agent_name == "Orchestrator"

    def test_handoff_parented_under_triggering_tool(self, handler):
        """With two active tools, handoff span parent_id should match the triggering tool."""
        handler._current_trace_id = "parent_trace"
        handler._root_span_id = "root_span"

        # Set up two parallel active tool spans
        tool_a_run_id = uuid4()
        tool_a_span = Span(name="tool_a", trace_id="parent_trace")
        tool_a_span.start()
        tool_b_run_id = uuid4()
        tool_b_span = Span(name="tool_b", trace_id="parent_trace")
        tool_b_span.start()

        handler._runs = {
            str(tool_a_run_id): {"span": tool_a_span, "parent_run_id": None},
            str(tool_b_run_id): {"span": tool_b_span, "parent_run_id": None},
        }
        handler._active_tool_run_ids = [str(tool_a_run_id), str(tool_b_run_id)]

        # Tool A triggers the subgraph — parent_run_id = tool_a_run_id
        sub_run_id = uuid4()
        handler.on_chain_start(
            serialized={"name": "sub-agent"},
            inputs={"messages": []},
            run_id=sub_run_id,
            parent_run_id=tool_a_run_id,
            metadata={"langgraph_node": "agent"},
            tags=["graph:step:1"],
        )

        ctx = handler._auto_handoff_contexts[str(sub_run_id)]
        # The handoff span should be parented under tool A, NOT tool B
        assert ctx.handoff_span.parent_id == tool_a_span.span_id

        # Clean up
        handler.on_chain_end(outputs={}, run_id=sub_run_id)


class TestTraceInterruptIdsCache:
    """Tests for bounded _trace_interrupt_ids cache."""

    @pytest.fixture(autouse=True)
    def clear_cache(self):
        """Clear the class-level cache before and after each test."""
        from lumenova_beacon.tracing.integrations.langchain import BeaconCallbackHandler
        BeaconCallbackHandler._trace_interrupt_ids.clear()
        yield
        BeaconCallbackHandler._trace_interrupt_ids.clear()

    @pytest.fixture
    def handler(self):
        return _make_handler(agent_name="TestAgent")

    def test_bounded_cache_evicts_oldest(self):
        """Adding more than max entries should evict oldest."""
        from lumenova_beacon.tracing.integrations.langchain import BeaconCallbackHandler

        max_size = BeaconCallbackHandler._TRACE_INTERRUPT_IDS_MAX_SIZE

        # Fill beyond capacity
        for i in range(max_size + 50):
            BeaconCallbackHandler._set_trace_interrupt_id(f"trace_{i}", f"int_{i}")

        assert len(BeaconCallbackHandler._trace_interrupt_ids) == max_size
        # Oldest 50 entries should be evicted
        assert "trace_0" not in BeaconCallbackHandler._trace_interrupt_ids
        assert "trace_49" not in BeaconCallbackHandler._trace_interrupt_ids
        # Newest entries should still be present
        assert BeaconCallbackHandler._trace_interrupt_ids[f"trace_{max_size + 49}"] == f"int_{max_size + 49}"
        assert f"trace_{max_size}" in BeaconCallbackHandler._trace_interrupt_ids

    def test_cleanup_on_normal_root_end(self, handler):
        """Root span ending without interrupt should remove the trace from cache."""
        from lumenova_beacon.tracing.integrations.langchain import BeaconCallbackHandler

        trace_id = "trace_normal"
        handler._current_trace_id = trace_id
        BeaconCallbackHandler._set_trace_interrupt_id(trace_id, "some_int")
        assert trace_id in BeaconCallbackHandler._trace_interrupt_ids

        # Simulate a root span start + end without interrupt
        root_run_id = uuid4()
        handler.on_chain_start(
            serialized={"name": "agent"},
            inputs={"messages": []},
            run_id=root_run_id,
            parent_run_id=None,
            metadata={},
            tags=[],
        )
        handler.on_chain_end(outputs={"result": "done"}, run_id=root_run_id)

        assert trace_id not in BeaconCallbackHandler._trace_interrupt_ids

    def test_no_cleanup_on_interrupt_root_end(self, handler):
        """Root span ending with interrupt should NOT remove the cache entry."""
        from lumenova_beacon.tracing.integrations.langchain import BeaconCallbackHandler

        trace_id = "trace_interrupt"
        handler._current_trace_id = trace_id

        # Simulate a root span start
        root_run_id = uuid4()
        handler.on_chain_start(
            serialized={"name": "agent"},
            inputs={"messages": []},
            run_id=root_run_id,
            parent_run_id=None,
            metadata={},
            tags=[],
        )

        # Simulate interrupt detection (child span detected interrupt)
        handler._interrupt_detected = True
        handler._interrupt_info = {"value": "need input", "id": "int_123"}
        BeaconCallbackHandler._set_trace_interrupt_id(trace_id, "int_123")

        handler.on_chain_end(outputs={}, run_id=root_run_id)

        # Cache entry should still be present for resume to pick up
        assert trace_id in BeaconCallbackHandler._trace_interrupt_ids
        assert BeaconCallbackHandler._trace_interrupt_ids[trace_id] == "int_123"
