- After creating a new database or installing `queue_job` on an existing
  database, Odoo must be restarted for the runner to detect it.
