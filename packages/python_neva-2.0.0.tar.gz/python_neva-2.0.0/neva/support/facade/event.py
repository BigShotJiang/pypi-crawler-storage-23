"""Event facade."""

from typing import override

from neva.arch import Facade
from neva.events import EventDispatcher


class Event(Facade):
    """Event system facade."""

    @classmethod
    @override
    def get_facade_accessor(cls) -> type:
        return EventDispatcher
