"""Database facade."""

from typing import override

from neva.arch import Facade
from neva.database.manager import DatabaseManager


class DB(Facade):
    """Database facade."""

    @classmethod
    @override
    def get_facade_accessor(cls) -> type:
        """Return the service class."""
        return DatabaseManager
