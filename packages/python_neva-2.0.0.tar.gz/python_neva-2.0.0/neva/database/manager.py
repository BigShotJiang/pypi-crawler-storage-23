"""Database manager."""

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import final

from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, async_sessionmaker

from neva import Nothing, Option, Some
from neva.database.connection import ConnectionManager, TransactionContext
from neva.database.transaction import BoundTransaction, Transaction
from neva.obs import LogManager


@final
class DatabaseManager:
    """Database manager."""

    def __init__(self, tx_context: TransactionContext, logger: LogManager) -> None:
        self._tx_context = tx_context
        self._logger = logger
        self._connections: dict[str, ConnectionManager] = {}
        self._engines: dict[str, AsyncEngine] = {}
        self._session_factories: dict[str, async_sessionmaker[AsyncSession]] = {}

    def register_engine(self, name: str, engine: AsyncEngine) -> None:
        """Register an engine and create a session factory for a connection.

        Args:
            name: The connection name.
            engine: The async engine.
        """
        self._engines[name] = engine
        self._session_factories[name] = async_sessionmaker(
            bind=engine,
            expire_on_commit=False,
        )
        _ = self._connections.pop(name, None)

    def connection(self, name: str) -> ConnectionManager:
        """Returns a connection manager for the given name."""
        return self._connections.setdefault(
            name,
            ConnectionManager(
                name,
                self._tx_context,
                self._logger,
                self._session_factories.get(name),
            ),
        )

    def current(self, connection: str | None = None) -> Option[Transaction]:
        """Returns the current transaction.

        If no connection is specified, this will return the most recent transaction on
        any connection. This is something to keep in mind.
        """
        return self._tx_context.current(connection)

    def session(self, connection: str | None = None) -> Option[AsyncSession]:
        """Returns the current session for a connection.

        Args:
            connection: The connection name. Defaults to "default".

        Returns:
            The current session, if any. Returns Nothing if there is no active
            bound transaction on the given connection.
        """
        match self.current(connection):
            case Some(tx) if isinstance(tx, BoundTransaction):
                return Some(tx.session)
            case _:
                return Nothing()

    @asynccontextmanager
    async def transaction(self, name: str = "default") -> AsyncIterator[Transaction]:
        """Open an unbound transaction on the named connection.

        Intended for unit tests that exercise transaction lifecycle and callbacks
        without a real database engine.

        Yields:
            Transaction: An unbound transaction with no associated session.
        """
        async with self.connection(name).transaction() as tx:
            yield tx

    @asynccontextmanager
    async def begin(self, name: str = "default") -> AsyncIterator[BoundTransaction]:
        """Open a bound transaction on the named connection.

        Args:
            name: The connection name.

        Raises:
            RuntimeError: If no engine has been registered for the connection.

        Yields:
            BoundTransaction: A transaction with a guaranteed non-null session.
        """  # noqa: DOC502 explicit documentation of the possible exception raised by 'begin'
        async with self.connection(name).begin() as tx:
            yield tx

    async def close(self) -> None:
        """Dispose all engines and clear caches."""
        for engine in self._engines.values():
            await engine.dispose()
        self._engines.clear()
        self._session_factories.clear()
        self._connections.clear()
