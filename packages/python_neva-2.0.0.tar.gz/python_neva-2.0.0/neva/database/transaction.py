"""Transaction management systems."""

from collections.abc import Awaitable
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Callable, Self

from sqlalchemy.ext.asyncio import AsyncSession

from neva import Err, Nothing, Option, Result, Some


type TransactionCallback = Callable[[], Awaitable[Result[None, str]]]


class TransactionState(Enum):
    """Represents the state of a transaction."""

    ACTIVE = auto()
    COMMITTED = auto()
    ROLLED_BACK = auto()


@dataclass
class Transaction:
    """Represents a database transaction with callback support."""

    conn_name: str
    state: TransactionState = field(default=TransactionState.ACTIVE, init=False)
    _on_commit: list[TransactionCallback] = field(default_factory=list, init=False)
    _on_rollback: list[TransactionCallback] = field(default_factory=list, init=False)
    parent: Option["Transaction"] = field(default_factory=Nothing, init=False)

    @property
    def is_active(self) -> bool:
        """Determine if the transaction is active."""
        return self.state == TransactionState.ACTIVE

    @property
    def is_root(self) -> bool:
        """Determine if the transaction is the root transaction."""
        return self.parent.is_nothing

    def on_commit(self, callback: TransactionCallback) -> Self:
        """Register a callback to be called when the root transaction is committed.

        Returns:
            Self: The current transaction, for chaining purposes.
        """
        match self.parent:
            case Some(parent):
                _ = parent.on_commit(callback)
            case Nothing():
                self._on_commit.append(callback)
        return self

    def on_rollback(self, callback: TransactionCallback) -> Self:
        """Register a callback to be called when the root transaction is rolled back.

        Returns:
            Self: The current transaction, for chaining purposes.
        """
        match self.parent:
            case Some(parent):
                _ = parent.on_rollback(callback)
            case Nothing():
                self._on_rollback.append(callback)
        return self

    async def execute_on_commit_callbacks(self) -> list[Result[None, str]]:
        """Execute all registered commit callbacks.

        Returns:
            A list of results from each callback.
        """
        results: list[Result[None, str]] = []
        for callback in self._on_commit:
            try:
                results.append(await callback())
            except Exception as e:
                results.append(Err(f"Callback raised: {e}"))
        self._on_commit.clear()
        return results

    async def execute_on_rollback_callbacks(self) -> list[Result[None, str]]:
        """Execute all registered rollback callbacks.

        Returns:
            A list of results from each callback.
        """
        results: list[Result[None, str]] = []
        for callback in self._on_rollback:
            try:
                results.append(await callback())
            except Exception as e:
                results.append(Err(f"Callback raised: {e}"))
        self._on_rollback.clear()
        return results

    def begin(self, session: "AsyncSession") -> "BoundTransaction":
        """Bind this transaction to a session, returning a BoundTransaction.

        Transfers the parent relationship and all pending callbacks to the
        returned BoundTransaction. The original transaction should not be
        used after calling this method.

        Args:
            session: The SQLAlchemy async session to bind to.

        Returns:
            BoundTransaction: A new transaction with the session attached and
                all state transferred from this transaction.
        """
        bound = BoundTransaction(self.conn_name, session=session)
        bound.parent = self.parent
        bound._on_commit = self._on_commit
        bound._on_rollback = self._on_rollback
        return bound


@dataclass
class BoundTransaction(Transaction):
    """Transaction bound to an SQLAlchemy session."""

    session: AsyncSession
