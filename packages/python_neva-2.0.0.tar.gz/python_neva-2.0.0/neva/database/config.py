"""Database configs."""

from typing import NotRequired, TypedDict


class ConnectionConfig(TypedDict):
    """Configuration for a single database connection."""

    url: str
    pool_size: NotRequired[int]
    max_overflow: NotRequired[int]
    pool_recycle: NotRequired[int]
    pool_pre_ping: NotRequired[bool]
    echo: NotRequired[bool]


class DatabaseConfig(TypedDict):
    """Database config."""

    connections: dict[str, ConnectionConfig]
