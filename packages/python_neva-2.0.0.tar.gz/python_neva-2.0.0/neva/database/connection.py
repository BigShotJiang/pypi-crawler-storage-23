"""Connection manager."""

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from contextvars import ContextVar
from dataclasses import dataclass, field
from typing import final

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from neva import Nothing, Option, Some, from_optional
from neva.database.transaction import BoundTransaction, Transaction, TransactionState
from neva.obs import LogManager


@dataclass
class TransactionRegistry:
    """A registry of ongoing transactions."""

    by_connection: dict[str, Transaction] = field(default_factory=dict)
    stack: list[Transaction] = field(default_factory=list)

    def extend(self, transaction: Transaction) -> "TransactionRegistry":
        """Adds a new transaction to the registry.

        Returns:
            A new registry with the new transaction added.
        """
        return TransactionRegistry(
            by_connection={**self.by_connection, transaction.conn_name: transaction},
            stack=[*self.stack, transaction],
        )


_tx_registry: ContextVar[TransactionRegistry | None] = ContextVar(
    "_tx_registry",
    default=None,
)


class TransactionContext:
    """Transaction context."""

    def __init__(self) -> None:
        if _tx_registry.get() is None:
            _ = _tx_registry.set(TransactionRegistry())

    def current(self, connection: str | None = None) -> Option[Transaction]:
        """Get the current transaction.

        Returns:
            The current transaction, if any.
        """
        registry = _tx_registry.get()
        if registry is None:
            return Nothing()

        if connection is not None:
            tx = registry.by_connection.get(connection)
            return from_optional(tx)

        if registry.stack:
            return Some(registry.stack[-1])
        return Nothing()


@final
class ConnectionManager:
    """Connection manager."""

    def __init__(
        self,
        name: str,
        tx_context: TransactionContext,
        logger: LogManager | None,
        session_factory: async_sessionmaker[AsyncSession] | None = None,
    ) -> None:
        self.name = name
        self.tx_context = tx_context
        self.logger = logger
        self.session_factory = session_factory

    @asynccontextmanager
    async def _scoped(self, tx: Transaction) -> AsyncIterator[None]:
        """Manage registry, state transitions, and callbacks for a transaction.

        Yields:
            None
        """
        old_registry = _tx_registry.get()
        token = (
            _tx_registry.set(old_registry.extend(tx))
            if old_registry is not None
            else _tx_registry.set(TransactionRegistry())
        )
        try:
            yield
            tx.state = TransactionState.COMMITTED
            if tx.is_root:
                for result in await tx.execute_on_commit_callbacks():
                    if result.is_err and self.logger is not None:
                        self.logger.error(
                            "commit callback failed",
                            error=result.err().unwrap(),
                            connection=self.name,
                        )
        except BaseException:
            tx.state = TransactionState.ROLLED_BACK
            if tx.is_root:
                for result in await tx.execute_on_rollback_callbacks():
                    if result.is_err and self.logger is not None:
                        self.logger.error(
                            "rollback callback failed",
                            error=result.err().unwrap(),
                            connection=self.name,
                        )
            raise
        finally:
            _tx_registry.reset(token)

    @asynccontextmanager
    async def transaction(self) -> AsyncIterator[Transaction]:
        """Open a new unbound transaction (no database session).

        Intended for use in unit tests where transaction lifecycle, callbacks,
        and context isolation need to be exercised without a real database.

        Yields:
            Transaction: An unbound transaction with no associated session.
        """
        parent = self.tx_context.current(self.name)
        tx = Transaction(self.name)
        tx.parent = parent
        async with self._scoped(tx):
            yield tx

    @asynccontextmanager
    async def begin(self) -> AsyncIterator[BoundTransaction]:
        """Open a new bound transaction with an active database session.

        For nested calls on the same connection, reuses the parent session
        and begins a savepoint instead of a full transaction.

        Raises:
            RuntimeError: If no engine has been registered for this connection.

        Yields:
            BoundTransaction: A transaction with a guaranteed non-null session.
        """
        if self.session_factory is None:
            raise RuntimeError(
                f"No engine registered for connection '{self.name}'. "
                + "Call register_engine() before calling begin()."
            )

        parent = self.tx_context.current(self.name)

        match parent:
            case Some(parent_tx) if isinstance(parent_tx, BoundTransaction):
                tx = Transaction(self.name)
                tx.parent = parent
                bound = tx.begin(parent_tx.session)
                async with self._scoped(bound), parent_tx.session.begin_nested():
                    yield bound
            case _:
                tx = Transaction(self.name)
                tx.parent = Nothing()
                async with self.session_factory() as session, session.begin():
                    bound = tx.begin(session)
                    async with self._scoped(bound):
                        yield bound
