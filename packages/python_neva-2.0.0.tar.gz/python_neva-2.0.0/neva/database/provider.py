"""Database service provider."""

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Self, override

from sqlalchemy.ext.asyncio import create_async_engine

from neva import Err, Ok, Result
from neva.arch import ServiceProvider
from neva.config.repository import ConfigRepository
from neva.database.connection import TransactionContext
from neva.database.manager import DatabaseManager
from neva.obs import LogManager


class DatabaseServiceProvider(ServiceProvider):
    """Database service provider."""

    @override
    def register(self) -> Result[Self, str]:
        self.app.bind(TransactionContext)
        self.app.bind(DatabaseManager)
        return Ok(self)

    @asynccontextmanager
    async def lifespan(self) -> AsyncIterator[None]:
        """Initialize and cleanup database connections."""
        logger: LogManager = self.app.make(LogManager).unwrap()
        db: DatabaseManager = self.app.make(DatabaseManager).unwrap()
        logger.info("Beginning SQLAlchemy initialization...")
        match self.app.make(ConfigRepository).unwrap().get("database"):
            case Ok(config):
                connections: dict = config.get("connections", {})
                for name, conn_config in connections.items():
                    url = conn_config.pop("url")
                    engine = create_async_engine(url, **conn_config)
                    db.register_engine(name, engine)
                    logger.info(f"Registered engine for connection '{name}'.")
                logger.info("SQLAlchemy initialization complete.")
                yield
                await db.close()
            case Err(err):
                logger.error(f"Failed to load database configuration: {err}")
                yield
