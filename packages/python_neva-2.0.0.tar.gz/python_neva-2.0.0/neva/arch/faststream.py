"""FastStream wrapper for Neva."""

from collections.abc import AsyncGenerator, AsyncIterator
from contextlib import asynccontextmanager
from typing import Any, Callable

import dishka
import faststream
from faststream._internal.broker import BrokerUsecase
from faststream._internal.configs import BrokerConfig
from starlette.types import StatelessLifespan

from neva import Result
from neva.arch import Application, ServiceProvider


class FastStream(faststream.FastStream):
    """FastStream wrapper for Neva."""

    def __init__(
        self,
        broker: BrokerUsecase[Any, Any, BrokerConfig],
        config_path: str | None = None,
    ) -> None:
        """Initialize the FastStream wrapper."""
        self.application: Application = Application(config_path=config_path)
        super().__init__(broker, lifespan=self._create_lifespan())

    def register(
        self,
        provider: type[ServiceProvider],
    ) -> Result[ServiceProvider, str]:
        """Registers a service provider with the application.

        Returns:
            Result containing the registered provider instance or an error message.
        """
        return self.application.register(provider=provider)

    def bind(
        self,
        source: type | Callable[..., Any],
        *,
        interface: type | None = None,
        scope: dishka.BaseScope | None = None,
    ) -> None:
        """Binds a source to the container."""
        self.application.bind(
            source=source,
            interface=interface,
            scope=scope,
        )

    def make[T](self, interface: type[T]) -> Result[T, str]:
        """Resolve and instanciate a type from the container.

        Returns:
            Result containing the resolved type instance or an error message.
        """
        return self.application.make(interface=interface)

    @asynccontextmanager
    async def lifespan(self) -> AsyncGenerator[None, None]:
        """Async context manager for the application lifespan."""
        async with self.application.lifespan():
            yield

    def _create_lifespan(
        self,
    ) -> StatelessLifespan["FastStream"]:
        @asynccontextmanager
        async def composed_lifespan(app: faststream.FastStream) -> AsyncIterator[None]:
            async with self.lifespan():
                yield

        return composed_lifespan
