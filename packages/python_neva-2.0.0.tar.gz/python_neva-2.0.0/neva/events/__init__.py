"""Defines the events system.

This module defines the event system, which is used to dispatch events to listener.
Three components are of particular interest:
- The base Event class, which is used to define events.
- The @listener decorator, which is used to define listeners from handler functions.
- The EventDispatcher class, which is used to registers listeners and dispatch events.
"""

from neva.events.dispatcher import EventDispatcher
from neva.events.event import Event
from neva.events.listener import EventListener, HandlingPolicy, listener
from neva.events.provider import EventServiceProvider


__all__ = [
    "Event",
    "EventDispatcher",
    "EventListener",
    "EventServiceProvider",
    "HandlingPolicy",
    "listener",
]
