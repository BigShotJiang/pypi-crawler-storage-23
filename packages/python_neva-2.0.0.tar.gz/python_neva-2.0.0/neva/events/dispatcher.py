"""Base implementation of the event dispatcher."""

from typing import final

from neva import Err, Nothing, Result, Some
from neva.arch.application import Application
from neva.database.manager import DatabaseManager
from neva.database.transaction import TransactionCallback
from neva.events.event import Event
from neva.events.event_registry import EventRegistry
from neva.events.listener import EventListener


@final
class EventDispatcher:
    """Event dispatcher implementation."""

    def __init__(self, app: Application, db: DatabaseManager) -> None:
        self._registry = EventRegistry()
        self._app = app
        self._db = db

    async def dispatch(self, event: Event) -> list[Result[None, str]]:
        """Dispatch an event to all registered listeners.

        Listeners are resolved from the DI container when available,
        falling back to direct instantiation otherwise.

        Args:
            event: The event to dispatch.

        Returns:
            A list of results, one per listener invocation.
        """
        results: list[Result[None, str]] = []
        listeners = self._registry.get_listeners(event)

        to_execute = listeners.immediate.copy()

        match self._db.current():
            case Some(tx):
                for listener_cls in listeners.deferred:
                    _ = tx.on_commit(self._build_callback(event, listener_cls))
            case Nothing():
                to_execute += listeners.deferred

        for listener_cls in to_execute:
            listener = self._resolve_listener(listener_cls)
            try:
                results.append(await listener.handle(event))
            except Exception as e:
                results.append(Err(f"Listener raised: {e}"))

        return results

    def listen[T: Event](
        self,
        event_cls: type[T],
        listener_cls: type[EventListener[T]],
    ) -> None:
        """Register a listener for an event."""
        self._registry.register(event_cls, listener_cls)

    def _resolve_listener[T: Event](
        self, listener_cls: type[EventListener[T]]
    ) -> EventListener[T]:
        """Resolve a listener from the container.

        Listeners are resolved from the DI container when available,
        falling back to direct instantiation otherwise.

        Returns:
            EventListener[Any]: The resolved listener.
        """
        result = self._app.make(listener_cls)
        if result.is_ok:
            return result.unwrap()
        return listener_cls()

    def _build_callback[T: Event](
        self,
        event: T,
        listener_cls: type[EventListener[T]],
    ) -> TransactionCallback:
        async def callback() -> Result[None, str]:
            listener = self._resolve_listener(listener_cls)
            return await listener.handle(event)

        return callback
