"""Event/listener registry."""

from typing import Any

from neva.events.event import Event
from neva.events.listener import EventListener, HandlingPolicy


class EventListenerRegistry[T: Event]:
    """Event listener registry for a given event."""

    def __init__(self) -> None:
        self.immediate: list[type[EventListener[T]]] = []
        self.deferred: list[type[EventListener[T]]] = []

    def add_listener(self, listener_cls: type[EventListener[T]]) -> None:
        """Add a listener to the correct category in the registry."""
        match listener_cls.policy:
            case HandlingPolicy.IMMEDIATE:
                self.immediate.append(listener_cls)
            case HandlingPolicy.DEFERRED:
                self.deferred.append(listener_cls)


class EventRegistry:
    """Event/listener registry."""

    __listeners: dict[type[Any], EventListenerRegistry[Any]]

    def __init__(self) -> None:
        """Initialize the registry."""
        self.__listeners = {}

    def register[T: Event](
        self, event_cls: type[T], listener_cls: type[EventListener[T]]
    ) -> None:
        """Register a listener for an event."""
        self.__listeners.setdefault(event_cls, EventListenerRegistry()).add_listener(
            listener_cls
        )

    def get_listeners[T: Event](self, event: T) -> EventListenerRegistry[T]:
        """Return all listeners registered for an event type."""
        return self.__listeners.get(type(event), EventListenerRegistry[T]())
