"""Base event class."""

import datetime as dt

import pydantic

from neva.support import time


class Event[T](pydantic.BaseModel):
    """Base event class."""

    event_id: T
    timestamp: dt.datetime = pydantic.Field(default_factory=time.utcnow)
