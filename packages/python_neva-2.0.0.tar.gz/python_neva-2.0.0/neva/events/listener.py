"""Event listener protocol."""

import abc
from enum import StrEnum
from types import new_class
from typing import Callable, Protocol

from neva import Result
from neva.events.event import Event
from neva.support.strconv import snake2pascal


class HandlingPolicy(StrEnum):
    """Event dispatch policy."""

    IMMEDIATE = "immediate"
    DEFERRED = "deferred"


class EventListener[T: Event](abc.ABC):
    """Event listener protocol."""

    policy: HandlingPolicy = HandlingPolicy.IMMEDIATE

    @abc.abstractmethod
    async def handle(self, event: T) -> Result[None, str]:
        """Handle an event.

        Returns:
            A result indicating whether the event was handled successfully.
        """


class EventHandler[T: Event](Protocol):
    """Define a valid function for event handling."""

    __name__: str

    async def __call__(self, event: T) -> Result[None, str]:
        """Handle an event."""
        ...


def listener[T: Event](
    policy: HandlingPolicy = HandlingPolicy.IMMEDIATE,
) -> Callable[[EventHandler[T]], type[EventListener[T]]]:
    """Create a listener from a function.

    Returns:
        type[EventListener[T]]: The created listener class.
    """

    def decorator(
        func: EventHandler[T],
    ) -> type[EventListener[T]]:
        async def handle(_: EventListener[T], event: T) -> Result[None, str]:
            return await func(event)

        def exec_body(namespace: dict[str, object]) -> None:
            namespace["handle"] = handle
            namespace["policy"] = policy

        # Ty struggles with infering type here, hence the type: ignore
        return new_class(
            snake2pascal(func.__name__) + "Listener",
            (EventListener[T],),
            exec_body=exec_body,
        )  # type: ignore[invalid-return-type]

    return decorator
