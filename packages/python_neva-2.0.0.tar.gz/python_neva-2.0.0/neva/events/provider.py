"""Event service provider."""

from typing import Self, override

from neva import Ok, Result
from neva.arch.service_provider import ServiceProvider


class EventServiceProvider(ServiceProvider):
    """Bootstraps the event dispatcher into the container.

    Include this provider to enable the event system.  Event-listener
    mappings can then be declared on any ``ServiceProvider`` via the
    ``listen`` class variable.
    """

    @override
    def register(self) -> Result[Self, str]:
        """Bind the event dispatcher into the container.

        Returns:
            Result[Self, str]: The result of the registration.
        """
        from neva.events.dispatcher import EventDispatcher

        self.app.bind(EventDispatcher)
        return Ok(self)
