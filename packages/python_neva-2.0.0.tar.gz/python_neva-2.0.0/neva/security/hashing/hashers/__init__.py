"""Hasher protocol and built-in hashers."""
