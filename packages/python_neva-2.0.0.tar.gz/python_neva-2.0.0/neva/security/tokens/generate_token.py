"""Token generation function."""

import secrets


def generate_token(length: int = 32) -> str:
    """Generate a secure random token.

    Args:
        length (int, optional): The length of the token. Defaults to 32.

    Returns:
        str: The generated token.
    """
    token = secrets.token_urlsafe(length)
    return token
