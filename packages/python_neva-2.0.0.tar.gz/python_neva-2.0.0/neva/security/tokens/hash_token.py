"""Token hashing function."""

import hashlib


def hash_token(token: str | bytes) -> str:
    """Hash a secure random token for storage.

    Args:
        token: The token to hash.

    Returns:
        Hex-encoded hash of the token.
    """
    data = token.encode() if isinstance(token, str) else token
    return hashlib.sha256(data).hexdigest()
