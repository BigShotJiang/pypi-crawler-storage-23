"""Verify a token against a given hash."""

import hmac

from neva.security.tokens.hash_token import hash_token


def verify_token(token: str | bytes, hashed: str) -> bool:
    """Verify a token against its stored hash.

    Args:
        token: The plaintext token to verify.
        hashed: The stored hash to verify against.

    Returns:
        True if the token matches, False otherwise.
    """
    return hmac.compare_digest(hash_token(token), hashed)
