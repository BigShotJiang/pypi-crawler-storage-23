"""ConfigRepository tests."""

from neva.config.repository import ConfigRepository


class TestGet:
    def test_get_top_level_key(self) -> None:
        repo = ConfigRepository()
        _ = repo.set("name", "Neva")

        assert repo.get("name").unwrap() == "Neva"

    def test_get_nested_key(self) -> None:
        repo = ConfigRepository()
        _ = repo.set("database.host", "localhost")

        assert repo.get("database.host").unwrap() == "localhost"

    def test_get_deeply_nested_key(self) -> None:
        repo = ConfigRepository()
        _ = repo.set("a.b.c.d", "deep")

        assert repo.get("a.b.c.d").unwrap() == "deep"

    def test_get_returns_default_when_key_missing(self) -> None:
        repo = ConfigRepository()

        assert repo.get("missing", "fallback").unwrap() == "fallback"

    def test_get_returns_err_when_key_missing_and_no_default(self) -> None:
        repo = ConfigRepository()

        result = repo.get("missing")
        assert result.is_err

    def test_get_returns_default_when_traversing_non_dict(self) -> None:
        repo = ConfigRepository()
        _ = repo.set("key", "string_value")

        assert repo.get("key.nested", "fallback").unwrap() == "fallback"

    def test_get_returns_err_when_traversing_non_dict_without_default(self) -> None:
        repo = ConfigRepository()
        _ = repo.set("key", "string_value")

        result = repo.get("key.nested")
        assert result.is_err

    def test_get_returns_entire_subtree(self) -> None:
        repo = ConfigRepository()
        _ = repo.set("database.host", "localhost")
        _ = repo.set("database.port", 5432)

        subtree = repo.get("database").unwrap()
        assert subtree == {"host": "localhost", "port": 5432}


class TestSet:
    def test_set_creates_intermediate_dicts(self) -> None:
        repo = ConfigRepository()

        result = repo.set("a.b.c", "value")
        assert result.is_ok
        assert repo.get("a.b.c").unwrap() == "value"

    def test_set_errors_when_frozen(self) -> None:
        repo = ConfigRepository()
        repo.freeze()

        result = repo.set("key", "value")
        assert result.is_err
        assert "frozen" in result.unwrap_err()

    def test_set_errors_when_path_conflicts_with_non_dict(self) -> None:
        repo = ConfigRepository()
        _ = repo.set("key", "string_value")

        result = repo.set("key.nested", "value")
        assert result.is_err
        assert "not a dictionary" in result.unwrap_err()

    def test_set_overwrites_existing_value(self) -> None:
        repo = ConfigRepository()
        _ = repo.set("key", "old")
        _ = repo.set("key", "new")

        assert repo.get("key").unwrap() == "new"


class TestHas:
    def test_has_returns_true_for_existing_key(self) -> None:
        repo = ConfigRepository()
        _ = repo.set("key", "value")

        assert repo.has("key")

    def test_has_returns_false_for_missing_key(self) -> None:
        repo = ConfigRepository()

        assert not repo.has("missing")

    def test_has_works_with_nested_keys(self) -> None:
        repo = ConfigRepository()
        _ = repo.set("database.host", "localhost")

        assert repo.has("database.host")
        assert repo.has("database")
        assert not repo.has("database.port")


class TestFreeze:
    def test_freeze_prevents_set(self) -> None:
        repo = ConfigRepository()
        repo.freeze()

        assert repo.set("key", "value").is_err

    def test_freeze_prevents_merge(self) -> None:
        repo = ConfigRepository()
        repo.freeze()

        assert repo.merge("ns", {"key": "value"}).is_err

    def test_is_frozen_reflects_state(self) -> None:
        repo = ConfigRepository()

        assert not repo.is_frozen()
        repo.freeze()
        assert repo.is_frozen()

    def test_get_works_after_freeze(self) -> None:
        repo = ConfigRepository()
        _ = repo.set("key", "value")
        repo.freeze()

        assert repo.get("key").unwrap() == "value"


class TestMerge:
    def test_merge_into_new_namespace(self) -> None:
        repo = ConfigRepository()

        result = repo.merge("database", {"host": "localhost", "port": 5432})
        assert result.is_ok
        assert repo.get("database.host").unwrap() == "localhost"
        assert repo.get("database.port").unwrap() == 5432

    def test_merge_updates_existing_namespace(self) -> None:
        repo = ConfigRepository()
        _ = repo.merge("database", {"host": "localhost"})
        _ = repo.merge("database", {"port": 5432})

        assert repo.get("database.host").unwrap() == "localhost"
        assert repo.get("database.port").unwrap() == 5432

    def test_merge_overwrites_existing_keys(self) -> None:
        repo = ConfigRepository()
        _ = repo.merge("database", {"host": "localhost"})
        _ = repo.merge("database", {"host": "remotehost"})

        assert repo.get("database.host").unwrap() == "remotehost"

    def test_merge_errors_when_target_is_not_dict(self) -> None:
        repo = ConfigRepository()
        _ = repo.set("key", "string_value")

        result = repo.merge("key", {"nested": "value"})
        assert result.is_err
        assert "not dict" in result.unwrap_err()

    def test_merge_errors_when_frozen(self) -> None:
        repo = ConfigRepository()
        repo.freeze()

        result = repo.merge("ns", {"key": "value"})
        assert result.is_err
        assert "frozen" in result.unwrap_err()


class TestAll:
    def test_all_returns_copy(self) -> None:
        repo = ConfigRepository()
        _ = repo.set("key", "value")

        items = repo.all()
        items["key"] = "modified"

        assert repo.get("key").unwrap() == "value"

    def test_all_returns_empty_dict_when_empty(self) -> None:
        repo = ConfigRepository()

        assert repo.all() == {}
