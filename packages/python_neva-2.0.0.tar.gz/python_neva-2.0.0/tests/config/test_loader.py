"""ConfigLoader tests."""

from pathlib import Path

from neva.config.loader import ConfigLoader


class TestLoadAll:
    def test_loads_config_from_python_file(self, tmp_path: Path) -> None:
        _ = (tmp_path / "database.py").write_text(
            'config = {"host": "localhost", "port": 5432}'
        )

        loader = ConfigLoader(tmp_path)
        result = loader.load_all()

        assert result.is_ok
        configs = result.unwrap()
        assert "database" in configs
        assert configs["database"]["host"] == "localhost"
        assert configs["database"]["port"] == 5432

    def test_loads_multiple_config_files(self, tmp_path: Path) -> None:
        _ = (tmp_path / "app.py").write_text('config = {"name": "Neva"}')
        _ = (tmp_path / "database.py").write_text('config = {"host": "localhost"}')

        loader = ConfigLoader(tmp_path)
        configs = loader.load_all().unwrap()

        assert "app" in configs
        assert "database" in configs

    def test_ignores_init_file(self, tmp_path: Path) -> None:
        _ = (tmp_path / "__init__.py").write_text('config = {"ignored": True}')
        _ = (tmp_path / "app.py").write_text('config = {"name": "Neva"}')

        loader = ConfigLoader(tmp_path)
        configs = loader.load_all().unwrap()

        assert "__init__" not in configs
        assert "app" in configs

    def test_skips_file_without_config_attribute(self, tmp_path: Path) -> None:
        _ = (tmp_path / "helpers.py").write_text("x = 42")

        loader = ConfigLoader(tmp_path)
        configs = loader.load_all().unwrap()

        assert "helpers" not in configs

    def test_skips_file_with_non_dict_config(self, tmp_path: Path) -> None:
        _ = (tmp_path / "bad.py").write_text('config = "not a dict"')

        loader = ConfigLoader(tmp_path)
        configs = loader.load_all().unwrap()

        assert "bad" not in configs

    def test_returns_err_when_directory_missing(self, tmp_path: Path) -> None:
        loader = ConfigLoader(tmp_path / "nonexistent")
        result = loader.load_all()

        assert result.is_err
        assert "does not exist" in result.unwrap_err()

    def test_returns_err_when_path_is_file(self, tmp_path: Path) -> None:
        file_path = tmp_path / "file.txt"
        file_path.touch()

        loader = ConfigLoader(file_path)
        result = loader.load_all()

        assert result.is_err
        assert "not a directory" in result.unwrap_err()

    def test_returns_err_on_syntax_error(self, tmp_path: Path) -> None:
        _ = (tmp_path / "broken.py").write_text("config = {{{")

        loader = ConfigLoader(tmp_path)
        result = loader.load_all()

        assert result.is_err
        assert "Syntax error" in result.unwrap_err()

    def test_returns_empty_dict_for_empty_directory(self, tmp_path: Path) -> None:
        loader = ConfigLoader(tmp_path)
        configs = loader.load_all().unwrap()

        assert configs == {}

    def test_accepts_string_path(self, tmp_path: Path) -> None:
        _ = (tmp_path / "app.py").write_text('config = {"name": "Neva"}')

        loader = ConfigLoader(str(tmp_path))
        configs = loader.load_all().unwrap()

        assert "app" in configs
