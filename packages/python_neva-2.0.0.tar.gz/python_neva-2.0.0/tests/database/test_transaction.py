"""Transaction unit tests."""

from neva import Ok, Result, Some
from neva.database.transaction import Transaction, TransactionState


class TestTransaction:
    def test_is_root_true_for_first_transaction(self) -> None:
        tx = Transaction("default")

        assert tx.is_root

    def test_is_root_false_when_has_parent(self) -> None:
        root = Transaction("default")
        child = Transaction("default")
        child.parent = Some(root)

        assert not child.is_root

    def test_is_active_true_when_state_is_active(self) -> None:
        tx = Transaction("default")

        assert tx.is_active

    def test_is_active_false_after_commit(self) -> None:
        tx = Transaction("default")
        tx.state = TransactionState.COMMITTED

        assert not tx.is_active

    def test_is_active_false_after_rollback(self) -> None:
        tx = Transaction("default")
        tx.state = TransactionState.ROLLED_BACK

        assert not tx.is_active

    async def test_on_commit_callback_executes_after_commit(self) -> None:
        tx = Transaction("default")
        called = False

        async def callback() -> Result[None, str]:
            nonlocal called
            called = True
            return Ok(None)

        tx.on_commit(callback)
        await tx.execute_on_commit_callbacks()

        assert called

    async def test_on_commit_callback_not_executed_on_rollback(self) -> None:
        tx = Transaction("default")
        called = False

        async def callback() -> Result[None, str]:
            nonlocal called
            called = True
            return Ok(None)

        tx.on_commit(callback)
        await tx.execute_on_rollback_callbacks()

        assert not called

    async def test_on_rollback_callback_executes_after_rollback(self) -> None:
        tx = Transaction("default")
        called = False

        async def callback() -> Result[None, str]:
            nonlocal called
            called = True
            return Ok(None)

        tx.on_rollback(callback)
        await tx.execute_on_rollback_callbacks()

        assert called

    async def test_on_rollback_callback_not_executed_on_commit(self) -> None:
        tx = Transaction("default")
        called = False

        async def callback() -> Result[None, str]:
            nonlocal called
            called = True
            return Ok(None)

        tx.on_rollback(callback)
        await tx.execute_on_commit_callbacks()

        assert not called

    async def test_on_commit_callbacks_execute_in_registration_order(self) -> None:
        tx = Transaction("default")
        results: list[int] = []

        for i in range(3):

            async def callback(n: int = i) -> Result[None, str]:
                results.append(n)
                return Ok(None)

            tx.on_commit(callback)

        await tx.execute_on_commit_callbacks()

        assert results == [0, 1, 2]

    async def test_on_rollback_callbacks_execute_in_registration_order(self) -> None:
        tx = Transaction("default")
        results: list[int] = []

        for i in range(3):

            async def callback(n: int = i) -> Result[None, str]:
                results.append(n)
                return Ok(None)

            tx.on_rollback(callback)

        await tx.execute_on_rollback_callbacks()

        assert results == [0, 1, 2]

    def test_on_commit_bubbles_to_root(self) -> None:
        root = Transaction("default")
        child = Transaction("default")
        child.parent = Some(root)

        async def callback() -> Result[None, str]:
            return Ok(None)

        child.on_commit(callback)

        assert callback in root._on_commit
        assert callback not in child._on_commit

    def test_on_rollback_bubbles_to_root(self) -> None:
        root = Transaction("default")
        child = Transaction("default")
        child.parent = Some(root)

        async def callback() -> Result[None, str]:
            return Ok(None)

        child.on_rollback(callback)

        assert callback in root._on_rollback
        assert callback not in child._on_rollback

    def test_on_commit_returns_self_for_chaining(self) -> None:
        tx = Transaction("default")

        async def callback() -> Result[None, str]:
            return Ok(None)

        result = tx.on_commit(callback)

        assert result is tx

    def test_on_rollback_returns_self_for_chaining(self) -> None:
        tx = Transaction("default")

        async def callback() -> Result[None, str]:
            return Ok(None)

        result = tx.on_rollback(callback)

        assert result is tx
