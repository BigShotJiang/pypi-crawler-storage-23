"""Connection manager tests."""

import pytest

from neva.database.connection import ConnectionManager, TransactionContext
from neva.database.transaction import BoundTransaction, TransactionState
from neva.obs import LogManager


@pytest.fixture
def manager(tx_context: TransactionContext) -> ConnectionManager:
    return ConnectionManager("default", tx_context, LogManager())


class TestConnectionManager:
    async def test_transaction_yields_active_transaction(
        self, manager: ConnectionManager
    ) -> None:
        async with manager.transaction() as tx:
            assert tx.is_active
            assert tx.state == TransactionState.ACTIVE

    async def test_transaction_state_committed_after_success(
        self, manager: ConnectionManager
    ) -> None:
        async with manager.transaction() as tx:
            pass
        assert tx.state == TransactionState.COMMITTED

    async def test_transaction_state_rolled_back_after_exception(
        self, manager: ConnectionManager
    ) -> None:
        with pytest.raises(RuntimeError):
            async with manager.transaction() as tx:
                msg = "intentional"
                raise RuntimeError(msg)
        assert tx.state == TransactionState.ROLLED_BACK

    async def test_exception_propagates_after_rollback(
        self, manager: ConnectionManager
    ) -> None:
        with pytest.raises(RuntimeError, match="intentional"):
            async with manager.transaction():
                msg = "intentional"
                raise RuntimeError(msg)

    async def test_nested_transaction_same_connection_has_parent(
        self, manager: ConnectionManager
    ) -> None:
        async with manager.transaction() as outer, manager.transaction() as inner:
            assert inner.parent.is_some
            assert inner.parent.unwrap() is outer

    async def test_nested_transaction_different_connection_no_parent(
        self, tx_context: TransactionContext
    ) -> None:
        manager_a = ConnectionManager("conn_a", tx_context, LogManager())
        manager_b = ConnectionManager("conn_b", tx_context, LogManager())

        async with manager_a.transaction(), manager_b.transaction() as inner:
            assert inner.parent.is_nothing

    async def test_context_restored_after_transaction_ends(
        self, manager: ConnectionManager, tx_context: TransactionContext
    ) -> None:
        assert tx_context.current().is_nothing

        async with manager.transaction():
            assert tx_context.current().is_some

        assert tx_context.current().is_nothing

    async def test_context_restored_after_transaction_fails(
        self, manager: ConnectionManager, tx_context: TransactionContext
    ) -> None:
        assert tx_context.current().is_nothing

        with pytest.raises(RuntimeError):
            async with manager.transaction():
                assert tx_context.current().is_some
                msg = "intentional"
                raise RuntimeError(msg)

        assert tx_context.current().is_nothing

    async def test_transaction_yields_unbound_transaction(
        self, manager: ConnectionManager
    ) -> None:
        async with manager.transaction() as tx:
            assert not isinstance(tx, BoundTransaction)

    async def test_begin_raises_without_engine(
        self, manager: ConnectionManager
    ) -> None:
        with pytest.raises(RuntimeError, match="No engine registered"):
            async with manager.begin():
                pass
