"""Multi-connection transaction tests."""

import pytest

from neva import Ok, Result
from neva.database.connection import ConnectionManager, TransactionContext
from neva.database.transaction import TransactionState
from neva.obs import LogManager


@pytest.fixture
def manager_a(tx_context: TransactionContext) -> ConnectionManager:
    return ConnectionManager("conn_a", tx_context, LogManager())


@pytest.fixture
def manager_b(tx_context: TransactionContext) -> ConnectionManager:
    return ConnectionManager("conn_b", tx_context, LogManager())


class TestMultiConnectionTransactions:
    async def test_independent_transactions_on_different_connections(
        self, manager_a: ConnectionManager, manager_b: ConnectionManager
    ) -> None:
        async with manager_a.transaction() as tx_a, manager_b.transaction() as tx_b:
            assert tx_a.conn_name == "conn_a"
            assert tx_b.conn_name == "conn_b"
            assert tx_a is not tx_b

    async def test_current_returns_correct_connection_transaction(
        self,
        tx_context: TransactionContext,
        manager_a: ConnectionManager,
        manager_b: ConnectionManager,
    ) -> None:
        async with manager_a.transaction() as tx_a, manager_b.transaction() as tx_b:
            assert tx_context.current("conn_a").unwrap() is tx_a
            assert tx_context.current("conn_b").unwrap() is tx_b

    async def test_innermost_is_last_opened_regardless_of_connection(
        self,
        tx_context: TransactionContext,
        manager_a: ConnectionManager,
        manager_b: ConnectionManager,
    ) -> None:
        async with manager_a.transaction() as tx_a:
            assert tx_context.current().unwrap() is tx_a

            async with manager_b.transaction() as tx_b:
                assert tx_context.current().unwrap() is tx_b

    async def test_commit_callbacks_fire_per_connection(
        self, manager_a: ConnectionManager, manager_b: ConnectionManager
    ) -> None:
        results: list[str] = []

        async def cb_a() -> Result[None, str]:
            results.append("a")
            return Ok(None)

        async def cb_b() -> Result[None, str]:
            results.append("b")
            return Ok(None)

        async with manager_a.transaction() as tx_a:
            tx_a.on_commit(cb_a)

        async with manager_b.transaction() as tx_b:
            tx_b.on_commit(cb_b)

        assert results == ["a", "b"]

    async def test_nested_different_connections_callbacks_independent(
        self, manager_a: ConnectionManager, manager_b: ConnectionManager
    ) -> None:
        results: list[str] = []

        async def cb_a() -> Result[None, str]:
            results.append("a")
            return Ok(None)

        async def cb_b() -> Result[None, str]:
            results.append("b")
            return Ok(None)

        async with manager_a.transaction() as tx_a:
            tx_a.on_commit(cb_a)

            async with manager_b.transaction() as tx_b:
                tx_b.on_commit(cb_b)

        assert results == ["b", "a"]

    async def test_outer_connection_rollback_doesnt_affect_inner_committed(
        self, manager_a: ConnectionManager, manager_b: ConnectionManager
    ) -> None:
        results: list[str] = []

        async def cb_b() -> Result[None, str]:
            results.append("b_committed")
            return Ok(None)

        with pytest.raises(RuntimeError):
            async with manager_a.transaction() as tx_a:
                async with manager_b.transaction() as tx_b:
                    tx_b.on_commit(cb_b)
                msg = "intentional"
                raise RuntimeError(msg)

        assert tx_a.state == TransactionState.ROLLED_BACK
        assert tx_b.state == TransactionState.COMMITTED
        assert results == ["b_committed"]

    async def test_same_connection_nested_callbacks_bubble_to_root(
        self, manager_a: ConnectionManager
    ) -> None:
        results: list[str] = []

        async def cb_outer() -> Result[None, str]:
            results.append("outer")
            return Ok(None)

        async def cb_inner() -> Result[None, str]:
            results.append("inner")
            return Ok(None)

        async with manager_a.transaction() as outer:
            outer.on_commit(cb_outer)

            async with manager_a.transaction() as inner:
                inner.on_commit(cb_inner)

        assert results == ["outer", "inner"]
