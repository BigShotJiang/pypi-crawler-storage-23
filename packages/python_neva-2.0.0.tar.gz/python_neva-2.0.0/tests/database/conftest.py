"""Shared fixtures for database tests."""

import pytest

from neva.database.connection import TransactionContext


@pytest.fixture
def tx_context() -> TransactionContext:
    return TransactionContext()
