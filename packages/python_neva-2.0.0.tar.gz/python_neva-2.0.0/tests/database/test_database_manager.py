"""Database manager tests."""

import pytest
from sqlalchemy.ext.asyncio import create_async_engine

from neva.database.connection import ConnectionManager, TransactionContext
from neva.database.manager import DatabaseManager
from neva.obs import LogManager


@pytest.fixture
def db(tx_context: TransactionContext) -> DatabaseManager:
    return DatabaseManager(tx_context, LogManager())


class TestDatabaseManager:
    async def test_transaction_uses_default_connection(
        self, db: DatabaseManager
    ) -> None:
        async with db.transaction() as tx:
            assert tx.conn_name == "default"

    async def test_transaction_uses_specified_connection(
        self, db: DatabaseManager
    ) -> None:
        async with db.transaction("analytics") as tx:
            assert tx.conn_name == "analytics"

    async def test_current_delegates_to_transaction_context(
        self, db: DatabaseManager
    ) -> None:
        assert db.current().is_nothing

        async with db.transaction():
            assert db.current().is_some

    async def test_current_with_connection_delegates_correctly(
        self, db: DatabaseManager
    ) -> None:
        async with db.transaction("analytics"):
            assert db.current("analytics").is_some
            assert db.current("default").is_nothing

    def test_connection_returns_cached_connection_manager(
        self, db: DatabaseManager
    ) -> None:
        first = db.connection("default")
        second = db.connection("default")

        assert first is second

    def test_connection_creates_new_manager_for_new_name(
        self, db: DatabaseManager
    ) -> None:
        default = db.connection("default")
        analytics = db.connection("analytics")

        assert default is not analytics
        assert isinstance(default, ConnectionManager)
        assert isinstance(analytics, ConnectionManager)

    async def test_session_returns_nothing_outside_transaction(
        self, db: DatabaseManager
    ) -> None:
        assert db.session().is_nothing

    async def test_session_returns_nothing_in_unbound_transaction(
        self, db: DatabaseManager
    ) -> None:
        async with db.transaction():
            assert db.session().is_nothing

    async def test_session_with_connection_name_returns_nothing_when_no_match(
        self, db: DatabaseManager
    ) -> None:
        async with db.transaction("default"):
            assert db.session("other").is_nothing

    async def test_begin_raises_without_engine(self, db: DatabaseManager) -> None:
        with pytest.raises(RuntimeError, match="No engine registered"):
            async with db.begin():
                pass


class TestRegisterEngineCache:
    def test_register_engine_invalidates_stale_connection_manager(self) -> None:
        engine = create_async_engine("sqlite+aiosqlite:///:memory:")
        tx_context = TransactionContext()
        db = DatabaseManager(tx_context, LogManager())

        stale = db.connection("default")
        assert stale.session_factory is None

        db.register_engine("default", engine)

        fresh = db.connection("default")
        assert fresh is not stale
        assert fresh.session_factory is not None
