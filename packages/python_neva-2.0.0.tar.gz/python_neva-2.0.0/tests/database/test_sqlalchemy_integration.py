"""SQLAlchemy integration tests with real in-memory SQLite."""

from collections.abc import AsyncIterator
from typing import final

import pytest
from sqlalchemy import Column, Integer, String, select
from sqlalchemy.ext.asyncio import create_async_engine
from sqlalchemy.orm import DeclarativeBase

from neva import Ok, Result
from neva.database.connection import TransactionContext
from neva.database.manager import DatabaseManager
from neva.database.transaction import BoundTransaction
from neva.obs import LogManager


def _make_db() -> DatabaseManager:
    engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    tx_context = TransactionContext()
    db = DatabaseManager(tx_context, LogManager())
    db.register_engine("default", engine)
    return db


class Base(DeclarativeBase):
    pass


@final
class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)


@pytest.fixture
async def db() -> AsyncIterator[DatabaseManager]:
    engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    tx_context = TransactionContext()
    manager = DatabaseManager(tx_context, LogManager())
    manager.register_engine("default", engine)

    yield manager

    await manager.close()


class TestSessionAccess:
    async def test_session_available_inside_begin(self, db: DatabaseManager) -> None:
        async with db.begin() as tx:
            assert isinstance(tx, BoundTransaction)
            session = db.session()
            assert session.is_some
            assert session.unwrap() is tx.session

    async def test_session_not_available_outside_transaction(
        self, db: DatabaseManager
    ) -> None:
        assert db.session().is_nothing


class TestCommitAndRollback:
    async def test_committed_data_persists(self, db: DatabaseManager) -> None:
        async with db.begin() as tx:
            tx.session.add(User(id=1, name="Alice"))

        async with db.begin() as tx:
            result = await tx.session.execute(select(User).where(User.id == 1))
            user = result.scalar_one()
            assert user.name == "Alice"

    async def test_rolled_back_data_does_not_persist(self, db: DatabaseManager) -> None:
        with pytest.raises(RuntimeError):
            async with db.begin() as tx:
                tx.session.add(User(id=2, name="Bob"))
                await tx.session.flush()
                msg = "force rollback"
                raise RuntimeError(msg)

        async with db.begin() as tx:
            result = await tx.session.execute(select(User).where(User.id == 2))
            user = result.scalar_one_or_none()
            assert user is None


class TestNestedSavepoints:
    async def test_inner_rollback_outer_commit(self, db: DatabaseManager) -> None:
        async with db.begin() as outer:
            outer.session.add(User(id=10, name="Outer"))
            await outer.session.flush()

            with pytest.raises(RuntimeError):
                async with db.connection("default").begin() as inner:
                    assert inner.session is outer.session
                    inner.session.add(User(id=11, name="Inner"))
                    await inner.session.flush()
                    msg = "rollback inner"
                    raise RuntimeError(msg)

        async with db.begin() as tx:
            outer_row = await tx.session.execute(select(User).where(User.id == 10))
            assert outer_row.scalar_one().name == "Outer"

            inner_row = await tx.session.execute(select(User).where(User.id == 11))
            assert inner_row.scalar_one_or_none() is None


class TestOnCommitCallbacks:
    async def test_on_commit_fires_after_begin(self, db: DatabaseManager) -> None:
        results: list[str] = []

        async with db.begin() as tx:
            tx.session.add(User(id=20, name="Callback"))

            async def on_commit() -> Result[None, str]:
                results.append("committed")
                return Ok(None)

            _ = tx.on_commit(on_commit)

        assert results == ["committed"]

    async def test_on_rollback_fires_on_error(self, db: DatabaseManager) -> None:
        results: list[str] = []

        with pytest.raises(RuntimeError):
            async with db.begin() as tx:

                async def on_rollback() -> Result[None, str]:
                    results.append("rolled_back")
                    return Ok(None)

                _ = tx.on_rollback(on_rollback)
                msg = "force error"
                raise RuntimeError(msg)

        assert results == ["rolled_back"]


class TestBoundTransaction:
    async def test_tx_is_bound_inside_begin(self, db: DatabaseManager) -> None:
        async with db.begin() as tx:
            assert isinstance(tx, BoundTransaction)

    async def test_nested_begin_shares_session(self, db: DatabaseManager) -> None:
        async with db.begin() as outer, db.connection("default").begin() as inner:
            assert inner.session is outer.session

    async def test_nested_begin_has_parent(self, db: DatabaseManager) -> None:
        async with db.begin() as outer, db.connection("default").begin() as inner:
            assert inner.parent.is_some
            assert inner.parent.unwrap() is outer


class TestDatabaseManagerClose:
    async def test_close_makes_subsequent_begin_raise(self) -> None:
        db = _make_db()

        async with db.begin() as tx:
            assert isinstance(tx, BoundTransaction)

        await db.close()

        with pytest.raises(RuntimeError, match="No engine registered"):
            async with db.begin():
                pass

    async def test_close_clears_connection_cache(self) -> None:
        db = _make_db()
        manager_before = db.connection("default")

        await db.close()

        manager_after = db.connection("default")
        assert manager_before is not manager_after
