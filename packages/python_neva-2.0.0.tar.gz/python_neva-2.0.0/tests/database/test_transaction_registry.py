"""Transaction registry tests."""

from neva.database.connection import TransactionRegistry
from neva.database.transaction import Transaction


class TestTransactionRegistry:
    def test_extend_adds_to_by_connection(self) -> None:
        registry = TransactionRegistry()
        tx = Transaction("default")

        extended = registry.extend(tx)

        assert extended.by_connection["default"] is tx

    def test_extend_adds_to_stack(self) -> None:
        registry = TransactionRegistry()
        tx = Transaction("default")

        extended = registry.extend(tx)

        assert extended.stack == [tx]

    def test_extend_returns_new_registry(self) -> None:
        registry = TransactionRegistry()
        tx = Transaction("default")

        extended = registry.extend(tx)

        assert extended is not registry
        assert registry.by_connection == {}
        assert registry.stack == []

    def test_extend_overwrites_same_connection(self) -> None:
        registry = TransactionRegistry()
        tx_first = Transaction("default")
        tx_second = Transaction("default")

        extended = registry.extend(tx_first).extend(tx_second)

        assert extended.by_connection["default"] is tx_second
        assert extended.stack == [tx_first, tx_second]
