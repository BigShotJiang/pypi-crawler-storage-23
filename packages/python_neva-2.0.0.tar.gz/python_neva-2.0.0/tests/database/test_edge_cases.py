"""Transaction edge case tests."""

from neva import Err, Ok, Result, Some
from neva.database.transaction import Transaction


class TestTransactionEdgeCases:
    async def test_callback_exception_doesnt_prevent_other_callbacks(self) -> None:
        tx = Transaction("default")
        results: list[int] = []

        async def failing() -> Result[None, str]:
            return Err("callback error")

        async def succeeding() -> Result[None, str]:
            results.append(1)
            return Ok(None)

        tx.on_commit(failing)
        tx.on_commit(succeeding)

        callback_results = await tx.execute_on_commit_callbacks()

        assert results == [1]
        assert callback_results[0].is_err
        assert callback_results[1].is_ok

    async def test_deeply_nested_same_connection_callbacks_reach_root(self) -> None:
        root = Transaction("default")
        child = Transaction("default")
        child.parent = Some(root)
        grandchild = Transaction("default")
        grandchild.parent = Some(child)

        results: list[str] = []

        async def callback() -> Result[None, str]:
            results.append("reached_root")
            return Ok(None)

        grandchild.on_commit(callback)

        assert callback in root._on_commit
        await root.execute_on_commit_callbacks()
        assert results == ["reached_root"]

    async def test_deeply_nested_rollback_callbacks_reach_root(self) -> None:
        root = Transaction("default")
        child = Transaction("default")
        child.parent = Some(root)
        grandchild = Transaction("default")
        grandchild.parent = Some(child)

        results: list[str] = []

        async def callback() -> Result[None, str]:
            results.append("reached_root")
            return Ok(None)

        grandchild.on_rollback(callback)

        assert callback in root._on_rollback
        await root.execute_on_rollback_callbacks()
        assert results == ["reached_root"]

    async def test_empty_transaction_no_callbacks(self) -> None:
        tx = Transaction("default")

        commit_results = await tx.execute_on_commit_callbacks()
        rollback_results = await tx.execute_on_rollback_callbacks()

        assert commit_results == []
        assert rollback_results == []

    async def test_callback_registered_during_callback_execution(self) -> None:
        tx = Transaction("default")
        results: list[str] = []

        async def registering_callback() -> Result[None, str]:
            async def inner() -> Result[None, str]:
                results.append("inner")
                return Ok(None)

            tx.on_commit(inner)
            results.append("outer")
            return Ok(None)

        tx.on_commit(registering_callback)
        await tx.execute_on_commit_callbacks()

        assert results == ["outer", "inner"]

    async def test_raising_callback_captured_as_err(self) -> None:
        tx = Transaction("default")

        async def raising() -> Result[None, str]:
            msg = "unexpected"
            raise RuntimeError(msg)

        tx.on_commit(raising)

        callback_results = await tx.execute_on_commit_callbacks()

        assert len(callback_results) == 1
        assert callback_results[0].is_err
        assert "unexpected" in callback_results[0].err().unwrap()
