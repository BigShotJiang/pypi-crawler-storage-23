"""Architecture test suite."""
