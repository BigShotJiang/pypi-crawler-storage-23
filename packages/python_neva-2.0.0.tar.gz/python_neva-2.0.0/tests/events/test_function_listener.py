"""Function-based listener tests."""

from typing import override

from neva import Ok, Result
from neva.database.manager import DatabaseManager
from neva.events import EventDispatcher, EventListener, HandlingPolicy
from neva.events.listener import listener
from tests.events.conftest import OrderPlaced, UserCreated


class TestFunctionListener:
    async def test_decorated_function_is_called_on_dispatch(
        self, dispatcher: EventDispatcher
    ) -> None:
        called = False

        @listener()
        async def on_order_placed(event: OrderPlaced) -> Result[None, str]:
            nonlocal called
            called = True
            return Ok(None)

        dispatcher.listen(OrderPlaced, on_order_placed)
        _ = await dispatcher.dispatch(OrderPlaced(event_id=1, order_id=1))

        assert called

    async def test_decorated_function_receives_the_event(
        self, dispatcher: EventDispatcher
    ) -> None:
        received: OrderPlaced | None = None

        @listener()
        async def on_order_placed(event: OrderPlaced) -> Result[None, str]:
            nonlocal received
            received = event
            return Ok(None)

        dispatcher.listen(OrderPlaced, on_order_placed)
        event = OrderPlaced(event_id=2, order_id=42)
        _ = await dispatcher.dispatch(event)

        assert received is event

    def test_default_policy_is_immediate(self) -> None:
        @listener()
        async def on_order_placed(event: OrderPlaced) -> Result[None, str]: ...  # type: ignore[invalid-return-type]

        assert on_order_placed.policy == HandlingPolicy.IMMEDIATE

    def test_policy_can_be_set_to_deferred(self) -> None:
        @listener(policy=HandlingPolicy.DEFERRED)
        async def on_order_placed(event: OrderPlaced) -> Result[None, str]: ...  # type: ignore[invalid-return-type]

        assert on_order_placed.policy == HandlingPolicy.DEFERRED

    async def test_deferred_function_listener_deferred_until_commit(
        self, dispatcher: EventDispatcher, db: DatabaseManager
    ) -> None:
        called = False

        @listener(policy=HandlingPolicy.DEFERRED)
        async def on_user_created(event: UserCreated) -> Result[None, str]:
            nonlocal called
            called = True
            return Ok(None)

        dispatcher.listen(UserCreated, on_user_created)

        async with db.transaction():
            _ = await dispatcher.dispatch(UserCreated(event_id=1, user_id=1))
            assert not called

        assert called

    async def test_exception_in_function_listener_captured_as_err(
        self, dispatcher: EventDispatcher
    ) -> None:
        @listener()
        async def on_order_placed(event: OrderPlaced) -> Result[None, str]:
            msg = "boom"
            raise RuntimeError(msg)

        dispatcher.listen(OrderPlaced, on_order_placed)
        results = await dispatcher.dispatch(OrderPlaced(event_id=1, order_id=1))

        assert len(results) == 1
        assert results[0].is_err

    async def test_function_and_class_listeners_coexist(
        self, dispatcher: EventDispatcher
    ) -> None:
        order: list[str] = []

        class ClassListener(EventListener[OrderPlaced]):
            @override
            async def handle(self, event: OrderPlaced) -> Result[None, str]:
                order.append("class")
                return Ok(None)

        @listener()
        async def on_order_placed(event: OrderPlaced) -> Result[None, str]:
            order.append("function")
            return Ok(None)

        dispatcher.listen(OrderPlaced, ClassListener)
        dispatcher.listen(OrderPlaced, on_order_placed)
        _ = await dispatcher.dispatch(OrderPlaced(event_id=1, order_id=1))

        assert order == ["class", "function"]

    def test_decorated_function_is_event_listener_subclass(self) -> None:
        @listener()
        async def on_order_placed(event: OrderPlaced) -> Result[None, str]: ...  # type: ignore[invalid-return-type]

        assert issubclass(on_order_placed, EventListener)
