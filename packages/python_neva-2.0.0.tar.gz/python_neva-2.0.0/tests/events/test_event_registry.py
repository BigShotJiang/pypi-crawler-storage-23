"""Event registry unit tests."""

from neva import Ok, Result
from neva.events.event_registry import EventListenerRegistry, EventRegistry
from neva.events.listener import EventListener, HandlingPolicy
from tests.events.conftest import OrderPlaced, UserCreated


class TestEventListenerRegistry:
    def test_immediate_listener_added_to_immediate_bucket(self) -> None:
        class ImmediateListener(EventListener[OrderPlaced]):
            async def handle(self, event: OrderPlaced) -> Result[None, str]:
                return Ok(None)

        registry = EventListenerRegistry()
        registry.add_listener(ImmediateListener)

        assert ImmediateListener in registry.immediate
        assert ImmediateListener not in registry.deferred

    def test_deferred_listener_added_to_deferred_bucket(self) -> None:
        class DeferredListener(EventListener[OrderPlaced]):
            policy = HandlingPolicy.DEFERRED

            async def handle(self, event: OrderPlaced) -> Result[None, str]:
                return Ok(None)

        registry = EventListenerRegistry()
        registry.add_listener(DeferredListener)

        assert DeferredListener in registry.deferred
        assert DeferredListener not in registry.immediate

    def test_registering_same_listener_twice_adds_it_twice(self) -> None:
        class SomeListener(EventListener[OrderPlaced]):
            async def handle(self, event: OrderPlaced) -> Result[None, str]:
                return Ok(None)

        registry = EventListenerRegistry()
        registry.add_listener(SomeListener)
        registry.add_listener(SomeListener)

        assert registry.immediate.count(SomeListener) == 2


class TestEventRegistry:
    def test_get_listeners_returns_empty_for_unregistered_event(self) -> None:
        registry = EventRegistry()
        result = registry.get_listeners(OrderPlaced(event_id=1, order_id=1))

        assert result.immediate == []
        assert result.deferred == []

    def test_registered_immediate_listener_appears_in_immediate(self) -> None:
        class ImmediateListener(EventListener[OrderPlaced]):
            async def handle(self, event: OrderPlaced) -> Result[None, str]:
                return Ok(None)

        registry = EventRegistry()
        registry.register(OrderPlaced, ImmediateListener)
        result = registry.get_listeners(OrderPlaced(event_id=1, order_id=1))

        assert ImmediateListener in result.immediate
        assert result.deferred == []

    def test_registered_deferred_listener_appears_in_deferred(self) -> None:
        class DeferredListener(EventListener[OrderPlaced]):
            policy = HandlingPolicy.DEFERRED

            async def handle(self, event: OrderPlaced) -> Result[None, str]:
                return Ok(None)

        registry = EventRegistry()
        registry.register(OrderPlaced, DeferredListener)
        result = registry.get_listeners(OrderPlaced(event_id=1, order_id=1))

        assert DeferredListener in result.deferred
        assert result.immediate == []

    def test_different_event_types_have_independent_listener_sets(self) -> None:
        class OrderListener(EventListener[OrderPlaced]):
            async def handle(self, event: OrderPlaced) -> Result[None, str]:
                return Ok(None)

        registry = EventRegistry()
        registry.register(OrderPlaced, OrderListener)

        user_listeners = registry.get_listeners(UserCreated(event_id=1, user_id=1))

        assert OrderListener not in user_listeners.immediate
        assert OrderListener not in user_listeners.deferred
