"""Immediate dispatch policy tests."""

from typing import override

from neva import Ok, Result
from neva.database.manager import DatabaseManager
from neva.events import EventDispatcher, EventListener
from tests.events.conftest import OrderPlaced


class TestImmediatePolicy:
    async def test_immediate_event_fires_without_transaction(
        self, dispatcher: EventDispatcher
    ) -> None:
        called = False

        class OrderPlacedListener(EventListener[OrderPlaced]):
            @override
            async def handle(self, event: OrderPlaced) -> Result[None, str]:
                nonlocal called
                called = True
                return Ok(None)

        dispatcher.listen(OrderPlaced, OrderPlacedListener)
        _ = await dispatcher.dispatch(OrderPlaced(event_id=1, order_id=1))

        assert called

    async def test_immediate_event_fires_during_transaction(
        self, dispatcher: EventDispatcher, db: DatabaseManager
    ) -> None:
        called = False

        class OrderPlacedListener(EventListener[OrderPlaced]):
            @override
            async def handle(self, event: OrderPlaced) -> Result[None, str]:
                nonlocal called
                called = True
                return Ok(None)

        dispatcher.listen(OrderPlaced, OrderPlacedListener)

        async with db.transaction():
            _ = await dispatcher.dispatch(OrderPlaced(event_id=1, order_id=1))
            assert called
