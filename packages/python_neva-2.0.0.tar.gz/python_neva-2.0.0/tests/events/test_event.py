"""Event base class tests."""

import datetime as dt

from neva.events.event import Event


class ConcreteEvent(Event[int]):
    """Minimal concrete event for testing the base class."""


class TestEvent:
    def test_event_id_is_stored(self) -> None:
        event = ConcreteEvent(event_id=42)

        assert event.event_id == 42

    def test_timestamp_is_set_automatically(self) -> None:
        event = ConcreteEvent(event_id=1)

        assert event.timestamp is not None
        assert isinstance(event.timestamp, dt.datetime)

    def test_timestamp_is_utc_aware(self) -> None:
        event = ConcreteEvent(event_id=1)

        assert event.timestamp.tzinfo == dt.UTC

    def test_timestamp_can_be_overridden(self) -> None:
        custom_time = dt.datetime(2024, 1, 1, tzinfo=dt.UTC)
        event = ConcreteEvent(event_id=1, timestamp=custom_time)

        assert event.timestamp == custom_time

    def test_timestamp_is_close_to_now(self) -> None:
        before = dt.datetime.now(dt.UTC)
        event = ConcreteEvent(event_id=1)
        after = dt.datetime.now(dt.UTC)

        assert before <= event.timestamp <= after
