"""Deferred dispatch policy tests."""

from typing import override

import pytest

from neva import Ok, Result
from neva.database.manager import DatabaseManager
from neva.events import EventDispatcher, EventListener, HandlingPolicy
from tests.events.conftest import UserCreated


class TestDeferredPolicy:
    async def test_deferred_event_fires_immediately_without_transaction(
        self, dispatcher: EventDispatcher
    ) -> None:
        called = False

        class UserCreatedListener(EventListener[UserCreated]):
            policy = HandlingPolicy.DEFERRED

            @override
            async def handle(self, event: UserCreated) -> Result[None, str]:
                nonlocal called
                called = True
                return Ok(None)

        dispatcher.listen(UserCreated, UserCreatedListener)
        _ = await dispatcher.dispatch(UserCreated(event_id=1, user_id=1))

        assert called

    async def test_deferred_event_deferred_until_commit(
        self, dispatcher: EventDispatcher, db: DatabaseManager
    ) -> None:
        called = False

        class UserCreatedListener(EventListener[UserCreated]):
            policy = HandlingPolicy.DEFERRED

            @override
            async def handle(self, event: UserCreated) -> Result[None, str]:
                nonlocal called
                called = True
                return Ok(None)

        dispatcher.listen(UserCreated, UserCreatedListener)

        async with db.transaction():
            _ = await dispatcher.dispatch(UserCreated(event_id=1, user_id=1))
            assert not called

        assert called

    async def test_deferred_event_discarded_on_rollback(
        self, dispatcher: EventDispatcher, db: DatabaseManager
    ) -> None:
        called = False

        class UserCreatedListener(EventListener[UserCreated]):
            policy = HandlingPolicy.DEFERRED

            @override
            async def handle(self, event: UserCreated) -> Result[None, str]:
                nonlocal called
                called = True
                return Ok(None)

        dispatcher.listen(UserCreated, UserCreatedListener)

        with pytest.raises(RuntimeError):
            async with db.transaction():
                _ = await dispatcher.dispatch(UserCreated(event_id=1, user_id=1))
                msg = "rollback"
                raise RuntimeError(msg)

        assert not called

    async def test_deferred_dispatch_returns_empty_results_inside_transaction(
        self, dispatcher: EventDispatcher, db: DatabaseManager
    ) -> None:
        class UserCreatedListener(EventListener[UserCreated]):
            policy = HandlingPolicy.DEFERRED

            @override
            async def handle(self, event: UserCreated) -> Result[None, str]:
                return Ok(None)

        dispatcher.listen(UserCreated, UserCreatedListener)

        async with db.transaction():
            results = await dispatcher.dispatch(UserCreated(event_id=1, user_id=1))
            assert results == []

    async def test_multiple_deferred_events_all_fire_at_commit(
        self, dispatcher: EventDispatcher, db: DatabaseManager
    ) -> None:
        call_count = 0

        class UserCreatedListener(EventListener[UserCreated]):
            policy = HandlingPolicy.DEFERRED

            @override
            async def handle(self, event: UserCreated) -> Result[None, str]:
                nonlocal call_count
                call_count += 1
                return Ok(None)

        dispatcher.listen(UserCreated, UserCreatedListener)

        async with db.transaction():
            _ = await dispatcher.dispatch(UserCreated(event_id=1, user_id=1))
            _ = await dispatcher.dispatch(UserCreated(event_id=2, user_id=2))
            _ = await dispatcher.dispatch(UserCreated(event_id=3, user_id=3))
            assert call_count == 0

        assert call_count == 3

    async def test_deferred_listener_inside_nested_transaction_fires_at_root_commit(
        self, dispatcher: EventDispatcher, db: DatabaseManager
    ) -> None:
        called_at: list[str] = []

        class UserCreatedListener(EventListener[UserCreated]):
            policy = HandlingPolicy.DEFERRED

            @override
            async def handle(self, event: UserCreated) -> Result[None, str]:
                called_at.append("fired")
                return Ok(None)

        dispatcher.listen(UserCreated, UserCreatedListener)

        async with db.transaction():
            async with db.connection("default").transaction():
                _ = await dispatcher.dispatch(UserCreated(event_id=1, user_id=1))
                assert called_at == []

            # Inner (savepoint) has committed — callback is on root, not yet fired
            assert called_at == []

        # Root committed — now fires
        assert called_at == ["fired"]

    async def test_deferred_listener_resolved_at_commit_time(
        self, dispatcher: EventDispatcher, db: DatabaseManager
    ) -> None:
        resolution_phase: str | None = None

        class UserCreatedListener(EventListener[UserCreated]):
            policy = HandlingPolicy.DEFERRED

            def __init__(self) -> None:
                nonlocal resolution_phase
                resolution_phase = phase

            @override
            async def handle(self, event: UserCreated) -> Result[None, str]:
                return Ok(None)

        dispatcher.listen(UserCreated, UserCreatedListener)

        phase = "dispatch"
        async with db.transaction():
            _ = await dispatcher.dispatch(UserCreated(event_id=1, user_id=1))
            assert resolution_phase is None, (
                "Listener should not be instantiated at dispatch time"
            )
            phase = "commit"

        assert resolution_phase == "commit"
