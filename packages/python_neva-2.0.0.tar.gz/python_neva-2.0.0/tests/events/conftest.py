"""Shared fixtures for event tests."""

from random import randint

import pydantic
import pytest

from neva.arch import Application
from neva.database.connection import TransactionContext
from neva.database.manager import DatabaseManager
from neva.events import Event, EventDispatcher
from neva.obs import LogManager


class OrderPlaced(Event[int]):
    """An immediate event used across test modules."""

    id: int = pydantic.Field(default=randint(0, 200))  # noqa: S311
    order_id: int


class UserCreated(Event[int]):
    """A deferred event used across test modules."""

    user_id: int


@pytest.fixture
def tx_context() -> TransactionContext:
    return TransactionContext()


@pytest.fixture
def db(tx_context: TransactionContext) -> DatabaseManager:
    return DatabaseManager(tx_context, LogManager())


@pytest.fixture
def dispatcher(application: Application, db: DatabaseManager) -> EventDispatcher:
    return EventDispatcher(app=application, db=db)
