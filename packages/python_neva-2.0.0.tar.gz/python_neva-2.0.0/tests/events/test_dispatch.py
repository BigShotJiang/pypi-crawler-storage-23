"""Core event dispatch tests."""

from typing import override

import dishka

from neva import Err, Ok, Result
from neva.arch import Application
from neva.database.manager import DatabaseManager
from neva.events import EventDispatcher, EventListener
from tests.events.conftest import OrderPlaced


class TestEventDispatch:
    async def test_dispatching_calls_registered_listener(
        self, dispatcher: EventDispatcher
    ) -> None:
        called = False

        class OrderPlacedListener(EventListener[OrderPlaced]):
            @override
            async def handle(self, event: OrderPlaced) -> Result[None, str]:
                nonlocal called
                called = True
                return Ok(None)

        dispatcher.listen(OrderPlaced, OrderPlacedListener)
        _ = await dispatcher.dispatch(OrderPlaced(event_id=1, order_id=1))

        assert called

    async def test_listener_receives_the_dispatched_event(
        self, dispatcher: EventDispatcher
    ) -> None:
        received: OrderPlaced | None = None

        class OrderPlacedListener(EventListener[OrderPlaced]):
            @override
            async def handle(self, event: OrderPlaced) -> Result[None, str]:
                nonlocal received
                received = event
                return Ok(None)

        dispatcher.listen(OrderPlaced, OrderPlacedListener)
        event = OrderPlaced(event_id=2, order_id=42)
        _ = await dispatcher.dispatch(event)

        assert received is event

    async def test_multiple_listeners_called_in_registration_order(
        self, dispatcher: EventDispatcher
    ) -> None:
        order: list[str] = []

        class FirstListener(EventListener[OrderPlaced]):
            @override
            async def handle(self, event: OrderPlaced) -> Result[None, str]:
                order.append("first")
                return Ok(None)

        class SecondListener(EventListener[OrderPlaced]):
            @override
            async def handle(self, event: OrderPlaced) -> Result[None, str]:
                order.append("second")
                return Ok(None)

        dispatcher.listen(OrderPlaced, FirstListener)
        dispatcher.listen(OrderPlaced, SecondListener)
        _ = await dispatcher.dispatch(OrderPlaced(event_id=1, order_id=1))

        assert order == ["first", "second"]

    async def test_dispatch_collects_listener_results(
        self, dispatcher: EventDispatcher
    ) -> None:
        class FailingListener(EventListener[OrderPlaced]):
            @override
            async def handle(self, event: OrderPlaced) -> Result[None, str]:
                return Err("failed")

        class SucceedingListener(EventListener[OrderPlaced]):
            @override
            async def handle(self, event: OrderPlaced) -> Result[None, str]:
                return Ok(None)

        dispatcher.listen(OrderPlaced, FailingListener)
        dispatcher.listen(OrderPlaced, SucceedingListener)
        results = await dispatcher.dispatch(OrderPlaced(event_id=1, order_id=1))

        assert len(results) == 2
        assert results[0].is_err
        assert results[1].is_ok

    async def test_dispatch_with_no_listeners_returns_empty(
        self, dispatcher: EventDispatcher
    ) -> None:
        results = await dispatcher.dispatch(OrderPlaced(event_id=1, order_id=1))

        assert results == []

    async def test_same_listener_registered_twice_is_called_twice(
        self, dispatcher: EventDispatcher
    ) -> None:
        call_count = 0

        class CountingListener(EventListener[OrderPlaced]):
            @override
            async def handle(self, event: OrderPlaced) -> Result[None, str]:
                nonlocal call_count
                call_count += 1
                return Ok(None)

        dispatcher.listen(OrderPlaced, CountingListener)
        dispatcher.listen(OrderPlaced, CountingListener)
        _ = await dispatcher.dispatch(OrderPlaced(event_id=1, order_id=1))

        assert call_count == 2


class TestDIResolution:
    async def test_listener_resolved_from_di_container(
        self, application: Application, db: DatabaseManager
    ) -> None:
        handled_by_ids: list[int] = []

        class TrackedListener(EventListener[OrderPlaced]):
            @override
            async def handle(self, event: OrderPlaced) -> Result[None, str]:
                handled_by_ids.append(id(self))
                return Ok(None)

        application.bind(TrackedListener)
        application.container = dishka.make_container(application.di_provider)

        di_instance_id = id(application.make(TrackedListener).unwrap())

        dispatcher = EventDispatcher(app=application, db=db)
        dispatcher.listen(OrderPlaced, TrackedListener)
        _ = await dispatcher.dispatch(OrderPlaced(event_id=1, order_id=1))

        assert handled_by_ids == [di_instance_id]

    async def test_listener_falls_back_to_direct_instantiation(
        self, application: Application, db: DatabaseManager
    ) -> None:
        init_count = [0]

        class UnboundListener(EventListener[OrderPlaced]):
            def __init__(self) -> None:
                init_count[0] += 1

            @override
            async def handle(self, event: OrderPlaced) -> Result[None, str]:
                return Ok(None)

        dispatcher = EventDispatcher(app=application, db=db)
        dispatcher.listen(OrderPlaced, UnboundListener)
        _ = await dispatcher.dispatch(OrderPlaced(event_id=1, order_id=1))

        assert init_count[0] == 1
