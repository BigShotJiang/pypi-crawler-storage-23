"""ProfilerMiddleware tests."""

from pathlib import Path

from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import PlainTextResponse
from starlette.routing import Route
from starlette.testclient import TestClient
from starlette.types import Receive, Scope, Send

from neva.obs.middleware.profiler import ProfilerMiddleware


def _make_app(tmp_path: Path, **kwargs: object) -> TestClient:
    async def index(request: Request) -> PlainTextResponse:
        return PlainTextResponse("ok")

    app = Starlette(routes=[Route("/", index)])
    middleware = ProfilerMiddleware(app=app, path=str(tmp_path), **kwargs)  # type: ignore[arg-type]
    return TestClient(middleware)


class TestProfilerMiddleware:
    def test_generates_profile_html_file(self, tmp_path: Path) -> None:
        client = _make_app(tmp_path)
        response = client.get("/")

        assert response.status_code == 200

        html_files = list(tmp_path.glob("profile_*.html"))
        assert len(html_files) == 1

    def test_profile_uses_correlation_id_in_filename(self, tmp_path: Path) -> None:
        async def index(request: Request) -> PlainTextResponse:
            return PlainTextResponse("ok")

        app = Starlette(routes=[Route("/", index)])

        from neva.obs.middleware.correlation import CorrelationMiddleware

        # Profiler must be inner so correlation ID is set before profiler reads it
        profiler = ProfilerMiddleware(app=app, path=str(tmp_path))
        correlation = CorrelationMiddleware(app=profiler)
        client = TestClient(correlation)

        response = client.get("/")
        assert response.status_code == 200

        correlation_id = response.headers["X-Request-ID"]
        expected_file = tmp_path / f"profile_{correlation_id}.html"
        assert expected_file.exists()

    def test_profile_uses_timestamp_without_correlation_id(
        self, tmp_path: Path
    ) -> None:
        client = _make_app(tmp_path)
        _ = client.get("/")

        html_files = list(tmp_path.glob("profile_*.html"))
        assert len(html_files) == 1
        # Filename should contain a float timestamp, not a UUID
        name = html_files[0].stem.removeprefix("profile_")
        _ = float(name)  # Raises ValueError if not a timestamp

    def test_passes_through_non_http_scopes(self) -> None:
        called = False

        async def raw_app(scope: Scope, receive: Receive, send: Send) -> None:
            nonlocal called
            called = True

        middleware = ProfilerMiddleware(app=raw_app)
        import asyncio

        asyncio.get_event_loop().run_until_complete(
            middleware({"type": "lifespan", "state": {}}, None, None),  # type: ignore[arg-type]
        )
        assert called

    def test_response_is_not_altered(self, tmp_path: Path) -> None:
        client = _make_app(tmp_path)
        response = client.get("/")

        assert response.status_code == 200
        assert response.text == "ok"
