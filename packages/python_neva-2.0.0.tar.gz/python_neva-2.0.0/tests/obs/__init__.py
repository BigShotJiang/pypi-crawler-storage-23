"""Observability module test suite."""
