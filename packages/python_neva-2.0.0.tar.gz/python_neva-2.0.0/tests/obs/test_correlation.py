"""CorrelationMiddleware tests."""

import uuid

from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Route
from starlette.testclient import TestClient
from starlette.types import Receive, Scope, Send

from neva.obs.middleware.correlation import CorrelationMiddleware, is_valid_uuid


def _make_app(
    middleware: CorrelationMiddleware | None = None,
) -> TestClient:
    async def index(request: Request) -> JSONResponse:
        correlation_id = request.state.correlation_id
        return JSONResponse({"correlation_id": correlation_id})

    app = Starlette(routes=[Route("/", index)])

    if middleware is not None:
        middleware.app = app
        return TestClient(middleware)

    return TestClient(CorrelationMiddleware(app=app))


class TestIsValidUuid:
    def test_valid_uuid4(self) -> None:
        assert is_valid_uuid(uuid.uuid4().hex)

    def test_invalid_uuid(self) -> None:
        assert not is_valid_uuid("not-a-uuid")

    def test_wrong_version(self) -> None:
        v1 = str(uuid.uuid1())
        assert not is_valid_uuid(v1, version=4)

    def test_correct_version(self) -> None:
        v1 = str(uuid.uuid1())
        assert is_valid_uuid(v1, version=1)


class TestCorrelationMiddleware:
    def test_generates_correlation_id_when_absent(self) -> None:
        client = _make_app()
        response = client.get("/")

        assert response.status_code == 200
        body = response.json()
        assert is_valid_uuid(body["correlation_id"])

    def test_uses_existing_x_request_id(self) -> None:
        client = _make_app()
        request_id = uuid.uuid4().hex
        response = client.get("/", headers={"X-Request-ID": request_id})

        assert response.json()["correlation_id"] == request_id

    def test_uses_existing_x_correlation_id(self) -> None:
        client = _make_app()
        correlation_id = uuid.uuid4().hex
        response = client.get("/", headers={"X-Correlation-ID": correlation_id})

        assert response.json()["correlation_id"] == correlation_id

    def test_generates_new_id_when_header_invalid(self) -> None:
        client = _make_app()
        response = client.get("/", headers={"X-Request-ID": "not-a-uuid"})

        body = response.json()
        assert body["correlation_id"] != "not-a-uuid"
        assert is_valid_uuid(body["correlation_id"])

    def test_adds_correlation_id_to_response_headers(self) -> None:
        client = _make_app()
        response = client.get("/")

        assert "X-Request-ID" in response.headers
        assert is_valid_uuid(response.headers["X-Request-ID"])

    def test_response_header_matches_request_state(self) -> None:
        client = _make_app()
        response = client.get("/")

        body = response.json()
        assert response.headers["X-Request-ID"] == body["correlation_id"]

    def test_custom_header_name(self) -> None:
        middleware = CorrelationMiddleware(
            app=None,  # type: ignore[arg-type]
            header_name="X-Correlation-ID",
        )
        client = _make_app(middleware)
        response = client.get("/")

        assert "X-Correlation-ID" in response.headers

    def test_custom_generator(self) -> None:
        middleware = CorrelationMiddleware(
            app=None,  # type: ignore[arg-type]
            generator=lambda: "custom-id",
            validator=lambda _: False,
        )
        client = _make_app(middleware)
        response = client.get("/")

        assert response.json()["correlation_id"] == "custom-id"

    def test_passes_through_non_http_scopes(self) -> None:
        async def raw_app(scope: Scope, receive: Receive, send: Send) -> None:
            pass

        middleware = CorrelationMiddleware(app=raw_app)
        # lifespan scope should pass through without error
        import asyncio

        asyncio.get_event_loop().run_until_complete(
            middleware({"type": "lifespan", "state": {}}, None, None),  # type: ignore[arg-type]
        )
