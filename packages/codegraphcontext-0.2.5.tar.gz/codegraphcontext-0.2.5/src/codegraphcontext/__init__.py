# src/codegraphcontext/__init__.py
# This makes 'codegraphcontext' a package.