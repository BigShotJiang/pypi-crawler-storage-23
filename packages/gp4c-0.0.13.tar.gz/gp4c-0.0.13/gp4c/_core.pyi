"""Type stubs for gp4c._core module.

This file provides type hints and documentation for IDE support.
"""

from typing import Optional
import numpy as np
from numpy.typing import NDArray
from .types import SamplingSpec, MeanSpec, GPSamples, Observations, PosteriorSamples

def sample_prior(
    spec: SamplingSpec,
    sigma2: float = 1.0,
    ell: float = 1.0,
    kernel: str = "rbf",
    n_samples: int = 1,
    seed: int = 42,
) -> GPSamples:
    """Sample from GP with any combination of f, g=integral(f), h=f'.

    This is the flexible API that allows sampling any subset of:
    - f(x): the base GP function
    - g(x) = integral of f from 0 to x
    - h(x) = f'(x), the derivative

    Args:
        spec: Specification of which functions to sample and at which points.
            At least one of x_f, x_g, or x_h must be provided.
        sigma2: Kernel variance parameter. Defaults to 1.0.
        ell: Kernel length scale parameter. Defaults to 1.0.
        kernel: Kernel type: 'rbf', 'matern52', or 'matern32'.
            Note: 'matern32' doesn't support h. Defaults to 'rbf'.
        n_samples: Number of joint samples to draw. Defaults to 1.
        seed: Random seed for reproducibility. Defaults to 42.

    Returns:
        GPSamples: Named tuple with fields:
            - f: ndarray (n_samples, n_f) or None
            - g: ndarray (n_samples, n_g) or None
            - h: ndarray (n_samples, n_h) or None

    Raises:
        TypeError: If spec is not a SamplingSpec instance.
        ValueError: If parameters are invalid or kernel doesn't support requested operations.

    Example:
        Sample only f:

        >>> spec = SamplingSpec(x_f=np.linspace(0, 5, 100))
        >>> result = sample_gp(spec, n_samples=10)
        >>> result.f.shape  # (10, 100)
        >>> result.g  # None

        Sample f and derivative h with Matérn 5/2:

        >>> spec = SamplingSpec(x_f=x, x_h=x)
        >>> result = sample_gp(spec, ell=0.5, kernel='matern52', n_samples=10)
        >>> result.f.shape  # (10, 100)
        >>> result.h.shape  # (10, 100)

        Sample all three on different grids:

        >>> spec = SamplingSpec(
        ...     x_f=np.linspace(0, 5, 100),
        ...     x_g=np.linspace(0, 5, 50),
        ...     x_h=np.linspace(0.1, 4.9, 80)
        ... )
        >>> result = sample_gp(spec, sigma2=1.0, ell=0.5, n_samples=5, seed=42)

    Note:
        - Derivative kernels have O(1/ell^2) variance, which can cause
          numerical issues for small length scales. Uses higher jitter (1e-6).
        - The cross-covariance K_fh is anti-symmetric: K_hf = -K_fh^T
        - Matérn 5/2 is twice differentiable, so h=f' is well-defined.
    """
    ...

def sample_posterior(
    obs: Observations,
    spec: SamplingSpec,
    sigma2: float = 1.0,
    ell: float = 1.0,
    kernel: str = "rbf",
    n_samples: int = 1,
    seed: int = 42,
) -> PosteriorSamples:
    """Sample from GP posterior conditioned on observations.

    Given observations of f, g, and/or h at specific points, sample the
    posterior distribution at new points specified in spec.

    Args:
        obs: Observed data (f_obs, g_obs, h_obs at their respective points).
        spec: Specification of prediction points for f, g, and/or h.
        sigma2: Kernel variance parameter. Defaults to 1.0.
        ell: Kernel length scale parameter. Defaults to 1.0.
        kernel: Kernel type: 'rbf', 'matern52', or 'matern32'. Defaults to 'rbf'.
        n_samples: Number of posterior samples to draw. Defaults to 1.
        seed: Random seed for reproducibility. Defaults to 42.

    Returns:
        PosteriorSamples: Named tuple with:
            - f: ndarray (n_samples, n_f) or None
            - g: ndarray (n_samples, n_g) or None
            - h: ndarray (n_samples, n_h) or None
            - f_mean: ndarray (n_f,) or None - posterior mean
            - g_mean: ndarray (n_g,) or None - posterior mean
            - h_mean: ndarray (n_h,) or None - posterior mean
            - f_std: ndarray (n_f,) or None - posterior std dev
            - g_std: ndarray (n_g,) or None - posterior std dev
            - h_std: ndarray (n_h,) or None - posterior std dev

    Example:
        >>> # Observe f at some points
        >>> obs = Observations(
        ...     x_f=np.array([0.0, 1.0, 2.0]),
        ...     y_f=np.array([0.5, 0.3, -0.2])
        ... )
        >>> # Predict at new points
        >>> spec = SamplingSpec(x_f=np.linspace(0, 5, 100))
        >>> result = sample_posterior(obs, spec, sigma2=1.0, ell=0.5, n_samples=100)
        >>> result.f.shape  # (100, 100)
        >>> result.f_mean.shape  # (100,)
        >>> result.f_std.shape  # (100,)
    """
    ...
