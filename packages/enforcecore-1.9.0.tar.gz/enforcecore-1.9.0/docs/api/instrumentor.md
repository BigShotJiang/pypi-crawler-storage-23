# Instrumentor

::: enforcecore.telemetry.instrumentor.EnforceCoreInstrumentor
