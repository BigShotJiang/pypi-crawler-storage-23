"""Regulatory report generation."""

from .generator import ReportGenerator

__all__ = ["ReportGenerator"]
