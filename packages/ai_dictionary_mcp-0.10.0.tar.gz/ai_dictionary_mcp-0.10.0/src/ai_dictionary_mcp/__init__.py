"""AI Dictionary MCP Server — look up, search, and cite AI phenomenology terms."""

__version__ = "0.10.0"
