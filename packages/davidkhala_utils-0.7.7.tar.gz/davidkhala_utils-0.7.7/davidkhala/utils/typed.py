from typing import TypedDict


class IDDict(TypedDict):
    id: str
