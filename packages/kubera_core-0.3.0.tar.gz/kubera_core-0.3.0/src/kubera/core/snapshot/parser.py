"""Banksalad Excel export parser.

Structure-aware parser that discovers column mappings from header rows
rather than assuming fixed positions. Fails fast when the format is
unrecognized so users know to update kubera-core.
"""

from __future__ import annotations

import re
import tempfile
import zipfile
from dataclasses import dataclass, field
from datetime import date, datetime, time
from decimal import Decimal, InvalidOperation
from pathlib import Path

from openpyxl import load_workbook
from openpyxl.worksheet.worksheet import Worksheet


class ParseError(ValueError):
    """Raised when the Banksalad Excel format is unrecognized."""
    pass


@dataclass
class ParsedSnapshot:
    snapshot_date: datetime
    source: str
    credit_score: int | None
    total_assets: Decimal
    total_liabilities: Decimal
    net_worth: Decimal
    asset_entries: list[dict] = field(default_factory=list)
    investment_entries: list[dict] = field(default_factory=list)
    loan_entries: list[dict] = field(default_factory=list)
    insurance_entries: list[dict] = field(default_factory=list)
    ledger_entries: list[dict] = field(default_factory=list)
    filename_stem: str = ""


# Filename pattern: ...YYYY-MM-DD~YYYY-MM-DD... (use end date)
_DATE_PATTERN = re.compile(r"\d{4}-\d{2}-\d{2}~(\d{4}-\d{2}-\d{2})")

# Section markers (matched by startswith on any cell)
_SECTION_CUSTOMER = "1.고객정보"
_SECTION_FINANCE = "3.재무현황"
_SECTION_INSURANCE = "4.보험현황"
_SECTION_INVESTMENT = "5.투자현황"
_SECTION_LOAN = "6.대출현황"

_ALL_SECTIONS = [_SECTION_CUSTOMER, _SECTION_FINANCE, _SECTION_INSURANCE,
                 _SECTION_INVESTMENT, _SECTION_LOAN]
_REQUIRED_SECTIONS = {_SECTION_CUSTOMER, _SECTION_FINANCE}

_UPDATE_MSG = "Banksalad format may have changed — please update kubera-core."


# ---------------------------------------------------------------------------
# Cell value converters
# ---------------------------------------------------------------------------

def _extract_datetime(filename: str) -> datetime:
    """Extract end date from filename and combine with current time for intraday granularity."""
    m = _DATE_PATTERN.search(filename)
    if not m:
        raise ValueError(f"Cannot extract date from filename: {filename}")
    d = date.fromisoformat(m.group(1))
    return datetime.combine(d, datetime.now().time())


def _to_decimal(value) -> Decimal:
    if value is None:
        return Decimal("0")
    try:
        return Decimal(str(value).replace(",", ""))
    except (InvalidOperation, ValueError):
        return Decimal("0")


def _to_int(value) -> int | None:
    if value is None:
        return None
    try:
        return int(float(str(value).replace(",", "")))
    except (ValueError, TypeError):
        return None


def _to_date(value) -> date | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    try:
        return date.fromisoformat(str(value)[:10])
    except (ValueError, TypeError):
        return None


def _to_time(value) -> time | None:
    if value is None:
        return None
    if isinstance(value, time):
        return value
    if isinstance(value, datetime):
        return value.time()
    try:
        return time.fromisoformat(str(value).strip())
    except (ValueError, TypeError):
        return None


def _str(value) -> str:
    if value is None:
        return ""
    return str(value).strip()


def _cell(ws: Worksheet, row: int, col: int):
    """Get cell value (1-indexed row & col)."""
    return ws.cell(row=row, column=col).value


def _is_empty_row(ws: Worksheet, row: int, max_col: int) -> bool:
    return all(ws.cell(row=row, column=c).value is None for c in range(1, max_col + 1))


def _is_summary_label(text: str) -> bool:
    """Check if a cell label is a summary/total row marker."""
    return any(k in text for k in ("합계", "총자산", "총부채", "순자산"))


# ---------------------------------------------------------------------------
# Structure discovery
# ---------------------------------------------------------------------------

def _find_sections(ws: Worksheet) -> dict[str, int]:
    """Scan every cell for section markers. Returns {marker: 1-indexed row}."""
    sections: dict[str, int] = {}
    for row in ws.iter_rows():
        for cell in row:
            if cell.value is not None:
                val = str(cell.value).strip()
                for marker in _ALL_SECTIONS:
                    if val.startswith(marker):
                        sections[marker] = cell.row
    for marker in _REQUIRED_SECTIONS:
        if marker not in sections:
            raise ParseError(f"Required section '{marker}' not found. {_UPDATE_MSG}")
    return sections


def _section_end(sections: dict[str, int], current: str, max_row: int) -> int:
    """End row for a section = start of next section, or max_row + 1."""
    cur = sections[current]
    nxt = max_row + 1
    for marker, row in sections.items():
        if row > cur:
            nxt = min(nxt, row)
    return nxt


def _find_header(
    ws: Worksheet, start: int, end: int, keywords: set[str], min_match: int = 2
) -> tuple[int, dict[str, int]]:
    """Find the first row in [start, end) containing >= min_match keywords.

    Returns (row, {keyword: 1-indexed col}).
    Raises ParseError if no row matches.
    """
    for row_num in range(start, end):
        col_map: dict[str, int] = {}
        for cell in ws[row_num]:
            if cell.value is not None:
                val = str(cell.value).strip()
                for kw in keywords:
                    if kw in val and kw not in col_map:
                        col_map[kw] = cell.column
        if len(col_map) >= min_match:
            return row_num, col_map
    raise ParseError(
        f"Expected headers {keywords} not found (rows {start}-{end}). {_UPDATE_MSG}"
    )


def _scan_header_cols(ws: Worksheet, row: int, keyword_map: dict[str, str]) -> dict[str, int]:
    """Scan a single row and map Korean keywords → logical field names.

    keyword_map: {Korean keyword: field_name}, e.g. {"보험사": "insurer"}.
    Returns {field_name: 1-indexed col}.
    """
    result: dict[str, int] = {}
    for cell in ws[row]:
        if cell.value is not None:
            val = str(cell.value).strip()
            for kw, field in keyword_map.items():
                if kw in val and field not in result:
                    result[field] = cell.column
    return result


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------

class BanksaladParser:
    """Parse Banksalad Excel export files."""

    def parse(self, file_path: Path, password: str | None = None) -> ParsedSnapshot:
        file_path = Path(file_path)
        if file_path.suffix.lower() == ".zip":
            return self._parse_zip(file_path, password)
        return self._parse_xlsx(file_path)

    def _parse_zip(self, zip_path: Path, password: str | None) -> ParsedSnapshot:
        pwd = password.encode() if password else None
        with zipfile.ZipFile(zip_path, "r") as zf:
            xlsx_names = [n for n in zf.namelist() if n.endswith(".xlsx")]
            if not xlsx_names:
                raise ValueError(f"No .xlsx file found in {zip_path}")
            with tempfile.TemporaryDirectory() as tmpdir:
                zf.extract(xlsx_names[0], tmpdir, pwd=pwd)
                extracted = Path(tmpdir) / xlsx_names[0]
                return self._parse_xlsx(extracted, original_filename=zip_path.stem)

    def _parse_xlsx(self, xlsx_path: Path, original_filename: str | None = None) -> ParsedSnapshot:
        filename = original_filename or xlsx_path.stem
        snapshot_date = _extract_datetime(filename)

        wb = load_workbook(xlsx_path, data_only=True)
        ws = wb.active
        max_row = ws.max_row

        sections = _find_sections(ws)

        credit_score = self._parse_credit_score(ws, sections, max_row)
        finance = self._parse_finance(ws, sections, max_row)
        insurance = self._parse_insurance(ws, sections, max_row)
        investment = self._parse_investment(ws, sections, max_row)
        loan = self._parse_loan(ws, sections, max_row)
        ledger = self._parse_ledger_sheet(wb)

        wb.close()

        return ParsedSnapshot(
            snapshot_date=snapshot_date,
            source="banksalad",
            credit_score=credit_score,
            total_assets=finance["total_assets"],
            total_liabilities=finance["total_liabilities"],
            net_worth=finance["net_worth"],
            asset_entries=finance["asset_entries"],
            investment_entries=investment,
            loan_entries=loan,
            insurance_entries=insurance,
            ledger_entries=ledger,
            filename_stem=filename,
        )

    # ------ 1. Customer info ------

    def _parse_credit_score(self, ws: Worksheet, sections: dict, max_row: int) -> int | None:
        start = sections[_SECTION_CUSTOMER]
        end = _section_end(sections, _SECTION_CUSTOMER, max_row)

        # Find cell containing "신용점수" — the value is in the next row, same column
        for row_num in range(start + 1, end):
            for cell in ws[row_num]:
                if cell.value is not None and "신용점수" in str(cell.value):
                    data_row = row_num + 1
                    if data_row < end:
                        return _to_int(_cell(ws, data_row, cell.column))
        return None

    # ------ 3. Finance ------

    def _parse_finance(self, ws: Worksheet, sections: dict, max_row: int) -> dict:
        start = sections[_SECTION_FINANCE]
        end = _section_end(sections, _SECTION_FINANCE, max_row)

        # Find column header row with "항목", "상품명", "금액"
        header_row, col_map = _find_header(
            ws, start + 1, end, {"항목", "상품명", "금액"}, min_match=2
        )

        cat_col = col_map.get("항목")
        prod_col = col_map.get("상품명")
        amt_col = col_map.get("금액")

        # Also discover liability "금액" column (second occurrence, right of asset 금액)
        liab_amt_col: int | None = None
        if amt_col:
            for cell in ws[header_row]:
                if cell.value is not None and "금액" in str(cell.value) and cell.column > amt_col:
                    liab_amt_col = cell.column
                    break

        asset_entries: list[dict] = []
        current_category = ""
        total_assets_row = Decimal("0")
        total_liab_row = Decimal("0")

        for row_num in range(header_row + 1, end):
            if _is_empty_row(ws, row_num, ws.max_column):
                continue

            cat_val = _str(_cell(ws, row_num, cat_col)) if cat_col else ""
            prod_val = _str(_cell(ws, row_num, prod_col)) if prod_col else ""
            amt_val = _to_decimal(_cell(ws, row_num, amt_col)) if amt_col else Decimal("0")

            # Check for total/summary rows
            if "총자산" in cat_val:
                total_assets_row = amt_val
                # Check liability total in same row
                if liab_amt_col:
                    total_liab_row = _to_decimal(_cell(ws, row_num, liab_amt_col))
                continue
            if _is_summary_label(cat_val):
                continue

            # Track category (appears only on first row of each group)
            if cat_val:
                current_category = cat_val

            # Add entry if it has a product name
            if prod_val:
                asset_entries.append({
                    "category": current_category,
                    "product_name": prod_val,
                    "amount": amt_val,
                })

        # Calculate totals — prefer row values if non-zero, else sum entries
        asset_sum = sum(e["amount"] for e in asset_entries)
        total_assets = total_assets_row if total_assets_row else asset_sum
        total_liabilities = total_liab_row
        net_worth = total_assets - total_liabilities

        return {
            "total_assets": total_assets,
            "total_liabilities": total_liabilities,
            "net_worth": net_worth,
            "asset_entries": asset_entries,
        }

    # ------ 4. Insurance ------

    def _parse_insurance(self, ws: Worksheet, sections: dict, max_row: int) -> list[dict]:
        if _SECTION_INSURANCE not in sections:
            return []
        start = sections[_SECTION_INSURANCE]
        end = _section_end(sections, _SECTION_INSURANCE, max_row)

        header_row, _ = _find_header(
            ws, start + 1, end, {"금융사", "보험명"}, min_match=2
        )
        cols = _scan_header_cols(ws, header_row, {
            "금융사": "insurer", "보험명": "product_name",
            "상태": "status", "계약상태": "status",
            "납입금": "total_paid",
            "계약일": "start_date", "만기일": "end_date",
        })

        entries: list[dict] = []
        for row_num in range(header_row + 1, end):
            if _is_empty_row(ws, row_num, ws.max_column):
                continue
            insurer = _str(_cell(ws, row_num, cols["insurer"])) if "insurer" in cols else ""
            if not insurer or "합계" in insurer or "총" in insurer:
                break
            entries.append({
                "insurer": insurer,
                "product_name": _str(_cell(ws, row_num, cols["product_name"])) if "product_name" in cols else "",
                "status": _str(_cell(ws, row_num, cols["status"])) if "status" in cols else "",
                "total_paid": _to_decimal(_cell(ws, row_num, cols["total_paid"])) if "total_paid" in cols else Decimal("0"),
                "start_date": _to_date(_cell(ws, row_num, cols["start_date"])) if "start_date" in cols else None,
                "end_date": _to_date(_cell(ws, row_num, cols["end_date"])) if "end_date" in cols else None,
            })
        return entries

    # ------ 5. Investment ------

    def _parse_investment(self, ws: Worksheet, sections: dict, max_row: int) -> list[dict]:
        if _SECTION_INVESTMENT not in sections:
            return []
        start = sections[_SECTION_INVESTMENT]
        end = _section_end(sections, _SECTION_INVESTMENT, max_row)

        header_row, _ = _find_header(
            ws, start + 1, end, {"금융사", "상품명"}, min_match=2
        )
        cols = _scan_header_cols(ws, header_row, {
            "금융사": "broker", "상품명": "product_name",
            "투자원금": "invested_amount", "투자금액": "invested_amount",
            "평가금액": "current_value", "현재가치": "current_value",
            "수익률": "return_rate",
        })

        entries: list[dict] = []
        for row_num in range(header_row + 1, end):
            if _is_empty_row(ws, row_num, ws.max_column):
                continue

            # Check first non-None cell for summary label
            first = ""
            for cell in ws[row_num]:
                if cell.value is not None:
                    first = _str(cell.value)
                    break
            if "합계" in first or "총" in first:
                break

            product = _str(_cell(ws, row_num, cols["product_name"])) if "product_name" in cols else ""
            if not product:
                continue

            entries.append({
                "broker": _str(_cell(ws, row_num, cols["broker"])) if "broker" in cols else "",
                "product_name": product,
                "invested_amount": _to_decimal(_cell(ws, row_num, cols["invested_amount"])) if "invested_amount" in cols else Decimal("0"),
                "current_value": _to_decimal(_cell(ws, row_num, cols["current_value"])) if "current_value" in cols else Decimal("0"),
                "return_rate": _to_decimal(_cell(ws, row_num, cols["return_rate"])) if "return_rate" in cols else None,
            })
        return entries

    # ------ 6. Loan ------

    def _parse_loan(self, ws: Worksheet, sections: dict, max_row: int) -> list[dict]:
        if _SECTION_LOAN not in sections:
            return []
        start = sections[_SECTION_LOAN]
        end = _section_end(sections, _SECTION_LOAN, max_row)

        header_row, _ = _find_header(
            ws, start + 1, end, {"금융사", "상품명"}, min_match=2
        )
        cols = _scan_header_cols(ws, header_row, {
            "금융사": "lender", "상품명": "product_name",
            "대출원금": "principal", "원금": "principal",
            "잔액": "balance", "대출잔액": "balance",
            "금리": "interest_rate",
            "신규": "start_date", "대출신규": "start_date",
            "만기": "end_date",
        })

        entries: list[dict] = []
        for row_num in range(header_row + 1, end):
            if _is_empty_row(ws, row_num, ws.max_column):
                continue
            lender = _str(_cell(ws, row_num, cols["lender"])) if "lender" in cols else ""
            if not lender or "합계" in lender or "총" in lender:
                break

            entries.append({
                "lender": lender,
                "product_name": _str(_cell(ws, row_num, cols["product_name"])) if "product_name" in cols else "",
                "principal": _to_decimal(_cell(ws, row_num, cols["principal"])) if "principal" in cols else Decimal("0"),
                "balance": _to_decimal(_cell(ws, row_num, cols["balance"])) if "balance" in cols else Decimal("0"),
                "interest_rate": _to_decimal(_cell(ws, row_num, cols["interest_rate"])) if "interest_rate" in cols else None,
                "start_date": _to_date(_cell(ws, row_num, cols["start_date"])) if "start_date" in cols else None,
                "end_date": _to_date(_cell(ws, row_num, cols["end_date"])) if "end_date" in cols else None,
            })
        return entries

    # ------ Sheet 2: Ledger (가계부 내역) ------

    _LEDGER_KEYWORDS = {"날짜", "타입", "대분류", "금액"}
    _LEDGER_COL_MAP = {
        "날짜": "entry_date",
        "시간": "entry_time",
        "타입": "entry_type",
        "대분류": "major_category",
        "소분류": "minor_category",
        "내용": "description",
        "금액": "amount",
        "화폐": "currency",
        "결제수단": "payment_method",
        "메모": "memo",
    }
    _ALLOWED_TYPES = {"수입", "지출"}

    def _parse_ledger_sheet(self, wb) -> list[dict]:
        if len(wb.sheetnames) < 2:
            return []
        ws = wb[wb.sheetnames[1]]

        # Verify header row (row 1)
        cols = _scan_header_cols(ws, 1, self._LEDGER_COL_MAP)
        found_keywords = {kw for kw in self._LEDGER_KEYWORDS
                         if self._LEDGER_COL_MAP[kw] in cols}
        if len(found_keywords) < 3:
            return []

        entries: list[dict] = []
        for row_num in range(2, ws.max_row + 1):
            if _is_empty_row(ws, row_num, ws.max_column):
                continue

            entry_type = _str(_cell(ws, row_num, cols["entry_type"])) if "entry_type" in cols else ""
            if entry_type not in self._ALLOWED_TYPES:
                continue

            entry_date = _to_date(_cell(ws, row_num, cols["entry_date"])) if "entry_date" in cols else None
            if not entry_date:
                continue

            entries.append({
                "entry_date": entry_date,
                "entry_time": _to_time(_cell(ws, row_num, cols["entry_time"])) if "entry_time" in cols else None,
                "entry_type": entry_type,
                "major_category": _str(_cell(ws, row_num, cols["major_category"])) if "major_category" in cols else "",
                "minor_category": _str(_cell(ws, row_num, cols["minor_category"])) if "minor_category" in cols else None,
                "description": _str(_cell(ws, row_num, cols["description"])) if "description" in cols else None,
                "amount": _to_decimal(_cell(ws, row_num, cols["amount"])) if "amount" in cols else Decimal("0"),
                "currency": _str(_cell(ws, row_num, cols["currency"])) if "currency" in cols else "KRW",
                "payment_method": _str(_cell(ws, row_num, cols["payment_method"])) if "payment_method" in cols else None,
                "memo": _str(_cell(ws, row_num, cols["memo"])) if "memo" in cols else None,
            })
        return entries
