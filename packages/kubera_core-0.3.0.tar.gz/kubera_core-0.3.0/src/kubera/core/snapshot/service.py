"""Snapshot service: import, list, get, delete."""

from __future__ import annotations

import tempfile
import datetime as _dt
from datetime import date, datetime, time, timedelta
from pathlib import Path

from sqlalchemy import func, select
from sqlalchemy.orm import Session, joinedload

from kubera.api.errors import KuberaError
from kubera.core.snapshot.models import (
    AssetEntry,
    InsuranceEntry,
    InvestmentEntry,
    LedgerEntry,
    LoanEntry,
    Snapshot,
)
from kubera.core.snapshot.parser import BanksaladParser


class SnapshotService:
    def __init__(self, db: Session):
        self.db = db

    def import_from_file(
        self, file_path: str | Path, password: str | None = None, user_id: str = "default",
        force: bool = False,
    ) -> Snapshot:
        parser = BanksaladParser()
        parsed = parser.parse(Path(file_path), password=password)

        # Duplicate check by filename_stem + source
        existing = self.db.scalar(
            select(Snapshot).where(
                Snapshot.user_id == user_id,
                Snapshot.filename_stem == parsed.filename_stem,
                Snapshot.source == parsed.source,
            )
        ) if parsed.filename_stem else None
        if existing:
            if not force:
                raise KuberaError(
                    "Snapshot already exists for this file and source",
                    code="SNAPSHOT_DUPLICATE",
                    status=409,
                )
            self.db.delete(existing)
            self.db.flush()

        # Incremental ledger import: only entries after the previous snapshot date
        ledger = parsed.ledger_entries
        prev = self.db.scalar(
            select(Snapshot)
            .where(
                Snapshot.user_id == user_id,
                Snapshot.source == parsed.source,
            )
            .order_by(Snapshot.snapshot_date.desc())
        )
        if prev:
            prev_date = prev.snapshot_date.date() if isinstance(prev.snapshot_date, datetime) else prev.snapshot_date
            ledger = [e for e in ledger if e["entry_date"] > prev_date]

        snapshot = Snapshot(
            user_id=user_id,
            snapshot_date=parsed.snapshot_date,
            source=parsed.source,
            filename_stem=parsed.filename_stem or None,
            credit_score=parsed.credit_score,
            total_assets=parsed.total_assets,
            total_liabilities=parsed.total_liabilities,
            net_worth=parsed.net_worth,
            asset_entries=[AssetEntry(**e) for e in parsed.asset_entries],
            investment_entries=[InvestmentEntry(**e) for e in parsed.investment_entries],
            loan_entries=[LoanEntry(**e) for e in parsed.loan_entries],
            insurance_entries=[InsuranceEntry(**e) for e in parsed.insurance_entries],
            ledger_entries=[LedgerEntry(**e) for e in ledger],
        )
        self.db.add(snapshot)
        self.db.commit()
        self.db.refresh(snapshot)
        return snapshot

    def import_from_bytes(
        self,
        file_bytes: bytes,
        filename: str,
        password: str | None = None,
        user_id: str = "default",
        force: bool = False,
    ) -> Snapshot:
        # Preserve original filename so parser can extract date from it
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir) / filename
            tmp_path.write_bytes(file_bytes)
            return self.import_from_file(tmp_path, password=password, user_id=user_id, force=force)

    def list_snapshots(
        self,
        user_id: str = "default",
        start: date | None = None,
        end: date | None = None,
        offset: int = 0,
        limit: int = 20,
    ) -> tuple[list[Snapshot], int]:
        base = select(Snapshot).where(Snapshot.user_id == user_id)
        if start:
            base = base.where(Snapshot.snapshot_date >= datetime.combine(start, time.min))
        if end:
            base = base.where(Snapshot.snapshot_date < datetime.combine(end + timedelta(days=1), time.min))

        total = self.db.scalar(select(func.count()).select_from(base.subquery()))
        items = list(
            self.db.scalars(
                base.offset(offset).limit(limit).order_by(Snapshot.snapshot_date.desc())
            )
        )
        return items, total or 0

    def get_snapshot(self, snapshot_id: int, user_id: str = "default") -> Snapshot | None:
        return self.db.scalar(
            select(Snapshot)
            .where(Snapshot.id == snapshot_id, Snapshot.user_id == user_id)
            .options(
                joinedload(Snapshot.asset_entries),
                joinedload(Snapshot.investment_entries),
                joinedload(Snapshot.loan_entries),
                joinedload(Snapshot.insurance_entries),
                joinedload(Snapshot.ledger_entries),
            )
        )

    def delete_snapshot(self, snapshot_id: int, user_id: str = "default") -> bool:
        snapshot = self.db.scalar(
            select(Snapshot).where(
                Snapshot.id == snapshot_id, Snapshot.user_id == user_id
            )
        )
        if not snapshot:
            return False
        self.db.delete(snapshot)
        self.db.commit()
        return True

    def get_ledger_entries(
        self,
        snapshot_id: int,
        user_id: str = "default",
        offset: int = 0,
        limit: int = 50,
    ) -> tuple[list[LedgerEntry], int]:
        snapshot = self.db.scalar(
            select(Snapshot).where(
                Snapshot.id == snapshot_id, Snapshot.user_id == user_id
            )
        )
        if not snapshot:
            return [], 0
        base = select(LedgerEntry).where(LedgerEntry.snapshot_id == snapshot_id)
        total = self.db.scalar(select(func.count()).select_from(base.subquery()))
        items = list(
            self.db.scalars(
                base.order_by(LedgerEntry.entry_date.desc(), LedgerEntry.id.desc())
                .offset(offset)
                .limit(limit)
            )
        )
        return items, total or 0

    def get_trend(
        self,
        user_id: str = "default",
        start: date | None = None,
        end: date | None = None,
    ) -> list[dict]:
        base = select(Snapshot).where(Snapshot.user_id == user_id)
        if start:
            base = base.where(Snapshot.snapshot_date >= datetime.combine(start, time.min))
        if end:
            base = base.where(Snapshot.snapshot_date < datetime.combine(end + timedelta(days=1), time.min))
        base = base.order_by(Snapshot.snapshot_date.asc())

        snapshots = list(self.db.scalars(base))
        return [
            {
                "snapshot_date": s.snapshot_date,
                "credit_score": s.credit_score,
                "total_assets": s.total_assets,
                "total_liabilities": s.total_liabilities,
                "net_worth": s.net_worth,
            }
            for s in snapshots
        ]

    def add_asset_entry(self, snapshot_id: int, data: dict, user_id: str = "default") -> AssetEntry:
        snapshot = self.db.scalar(
            select(Snapshot).where(Snapshot.id == snapshot_id, Snapshot.user_id == user_id)
        )
        if not snapshot:
            raise KuberaError("Snapshot not found", code="SNAPSHOT_NOT_FOUND", status=404)
        entry = AssetEntry(snapshot_id=snapshot_id, **data)
        self.db.add(entry)
        self.db.commit()
        self.db.refresh(entry)
        return entry

    def delete_asset_entry(self, snapshot_id: int, entry_id: int, user_id: str = "default") -> bool:
        entry = self.db.scalar(
            select(AssetEntry).join(Snapshot).where(
                AssetEntry.id == entry_id,
                AssetEntry.snapshot_id == snapshot_id,
                Snapshot.user_id == user_id,
            )
        )
        if not entry:
            return False
        self.db.delete(entry)
        self.db.commit()
        return True

    def compare_snapshots(
        self,
        from_date: date,
        to_date: date,
        user_id: str = "default",
    ) -> dict:
        from_snap = self.db.scalar(
            select(Snapshot).where(
                Snapshot.user_id == user_id,
                Snapshot.snapshot_date >= datetime.combine(from_date, time.min),
                Snapshot.snapshot_date < datetime.combine(from_date + timedelta(days=1), time.min),
            ).order_by(Snapshot.snapshot_date.desc())
        )
        to_snap = self.db.scalar(
            select(Snapshot).where(
                Snapshot.user_id == user_id,
                Snapshot.snapshot_date >= datetime.combine(to_date, time.min),
                Snapshot.snapshot_date < datetime.combine(to_date + timedelta(days=1), time.min),
            ).order_by(Snapshot.snapshot_date.desc())
        )
        if not from_snap or not to_snap:
            raise KuberaError(
                "Snapshot not found for the specified date",
                code="SNAPSHOT_NOT_FOUND",
                status=404,
            )
        return {
            "from_date": from_snap.snapshot_date,
            "to_date": to_snap.snapshot_date,
            "diff": {
                "credit_score": (to_snap.credit_score or 0) - (from_snap.credit_score or 0),
                "total_assets": to_snap.total_assets - from_snap.total_assets,
                "total_liabilities": to_snap.total_liabilities - from_snap.total_liabilities,
                "net_worth": to_snap.net_worth - from_snap.net_worth,
            },
        }
