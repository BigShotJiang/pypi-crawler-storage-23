"""SQLAlchemy base, mixins, and engine/session factory."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from sqlalchemy import event, func, create_engine
from sqlalchemy.orm import (
    DeclarativeBase,
    Mapped,
    Session,
    mapped_column,
    sessionmaker,
)


class Base(DeclarativeBase):
    pass


class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(default=func.now())
    updated_at: Mapped[datetime] = mapped_column(default=func.now(), onupdate=func.now())
    deleted_at: Mapped[datetime | None] = mapped_column(default=None)


def _set_sqlite_wal(dbapi_conn: Any, connection_record: Any) -> None:
    cursor = dbapi_conn.cursor()
    cursor.execute("PRAGMA journal_mode=WAL")
    cursor.close()


def get_engine(database_url: str = "sqlite:///.kubera/kubera.db"):
    engine = create_engine(database_url, echo=False)
    if database_url.startswith("sqlite"):
        event.listen(engine, "connect", _set_sqlite_wal)
    return engine


def get_session(engine) -> Session:
    session_factory = sessionmaker(bind=engine)
    return session_factory()
