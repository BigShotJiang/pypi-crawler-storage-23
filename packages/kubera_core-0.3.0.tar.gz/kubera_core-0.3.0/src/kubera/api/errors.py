"""Error handling for the API."""

from __future__ import annotations

from fastapi import Request
from fastapi.responses import JSONResponse


class KuberaError(Exception):
    def __init__(self, detail: str, code: str, status: int = 400):
        self.detail = detail
        self.code = code
        self.status = status


async def kubera_error_handler(request: Request, exc: KuberaError) -> JSONResponse:
    return JSONResponse(
        status_code=exc.status,
        content={"detail": exc.detail, "code": exc.code, "status": exc.status},
    )
