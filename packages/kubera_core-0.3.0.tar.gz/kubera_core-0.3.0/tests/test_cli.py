"""Tests for CLI entry point."""

import argparse
import sys


def test_cli_help(capsys):
    from kubera.cli import main

    original = sys.argv
    sys.argv = ["kubera-core", "--help"]
    try:
        main()
    except SystemExit:
        pass
    sys.argv = original
    captured = capsys.readouterr()
    assert "kubera" in captured.out.lower()
    assert "start" in captured.out
    assert "token" in captured.out


def test_cli_token(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)

    from kubera.cli.commands import cmd_token

    args = argparse.Namespace(refresh=False)
    cmd_token(args)
    env_file = tmp_path / ".kubera" / ".env"
    assert env_file.exists()
    content = env_file.read_text()
    assert "KUBERA_SECRET_TOKEN=" in content


def test_cli_token_refresh(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)

    from kubera.cli.commands import cmd_token

    args = argparse.Namespace(refresh=True)
    cmd_token(args)
    env_file = tmp_path / ".kubera" / ".env"
    content = env_file.read_text()
    assert "KUBERA_SECRET_TOKEN=" in content
    # Token should be a long urlsafe string
    token = content.split("=", 1)[1].strip()
    assert len(token) > 20


def test_cli_no_command(capsys):
    from kubera.cli import main

    original = sys.argv
    sys.argv = ["kubera-core"]
    main()
    sys.argv = original
    captured = capsys.readouterr()
    assert "usage" in captured.out.lower() or "kubera" in captured.out.lower()
