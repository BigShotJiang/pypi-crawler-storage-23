"""Tests for CORS middleware configuration."""

from fastapi.testclient import TestClient

from kubera.api.main import create_app
from kubera.core.config import Settings


def _make_client(cors_origins: list[str]) -> TestClient:
    settings = Settings(
        _env_file=None,
        database_url="sqlite:///:memory:",
        cors_origins=cors_origins,
    )
    return TestClient(create_app(settings))


def test_cors_allows_configured_origin():
    client = _make_client(["http://localhost:3000"])
    resp = client.options(
        "/api/v1/health",
        headers={
            "Origin": "http://localhost:3000",
            "Access-Control-Request-Method": "GET",
        },
    )
    assert resp.headers["access-control-allow-origin"] == "http://localhost:3000"
    assert "GET" in resp.headers["access-control-allow-methods"]


def test_cors_rejects_unconfigured_origin():
    client = _make_client(["http://localhost:3000"])
    resp = client.options(
        "/api/v1/health",
        headers={
            "Origin": "http://evil.com",
            "Access-Control-Request-Method": "GET",
        },
    )
    assert "access-control-allow-origin" not in resp.headers


def test_cors_wildcard_allows_any_origin():
    client = _make_client(["*"])
    resp = client.options(
        "/api/v1/health",
        headers={
            "Origin": "http://any-domain.com",
            "Access-Control-Request-Method": "GET",
        },
    )
    # With allow_credentials=True, Starlette echoes the request origin instead of "*"
    assert resp.headers["access-control-allow-origin"] == "http://any-domain.com"


def test_cors_allows_credentials():
    client = _make_client(["http://localhost:3000"])
    resp = client.options(
        "/api/v1/health",
        headers={
            "Origin": "http://localhost:3000",
            "Access-Control-Request-Method": "GET",
        },
    )
    assert resp.headers.get("access-control-allow-credentials") == "true"


def test_cors_default_is_wildcard():
    settings = Settings(_env_file=None, database_url="sqlite:///:memory:")
    assert settings.cors_origins == ["*"]
