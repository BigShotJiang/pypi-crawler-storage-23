"""Smoke test: verify kubera package imports."""


def test_import_kubera():
    import kubera

    assert kubera.__version__ == "0.1.0"


def test_import_subpackages():
    import kubera.core
    import kubera.api
    import kubera.cli
