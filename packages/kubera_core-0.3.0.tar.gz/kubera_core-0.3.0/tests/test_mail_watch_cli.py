"""Tests for mail-watch CLI integration (issue #25)."""

from __future__ import annotations

import argparse
import sys
from unittest.mock import MagicMock, patch

import pytest


# Patch targets: source modules because cmd_start/cmd_mail_watch use lazy imports
_WATCHER = "kubera.core.snapshot.mail_watcher.MailWatcher"
_GET_ENGINE = "kubera.core.models.get_engine"
_GET_SESSION = "kubera.core.models.get_session"
_RUN_MIGRATIONS = "kubera.cli.commands._run_migrations"


class TestMailWatchSubcommand:
    def test_help_shows_mail_watch(self, capsys):
        from kubera.cli import main

        original = sys.argv
        sys.argv = ["kubera-core", "--help"]
        try:
            main()
        except SystemExit:
            pass
        sys.argv = original
        captured = capsys.readouterr()
        assert "mail-watch" in captured.out

    def test_start_help_shows_no_mail_watch_flag(self, capsys):
        from kubera.cli import main

        original = sys.argv
        sys.argv = ["kubera-core", "start", "--help"]
        try:
            main()
        except SystemExit:
            pass
        sys.argv = original
        captured = capsys.readouterr()
        assert "--no-mail-watch" in captured.out


class TestCmdMailWatch:
    def test_no_credential_exits_with_error(self, tmp_path, monkeypatch, capsys):
        monkeypatch.chdir(tmp_path)
        from kubera.cli.commands import cmd_mail_watch

        args = argparse.Namespace()
        with pytest.raises(SystemExit) as exc_info:
            cmd_mail_watch(args)

        assert exc_info.value.code == 1
        captured = capsys.readouterr()
        assert "no mail credential" in captured.out.lower()
        assert "credential add mail" in captured.out

    def test_with_credential_starts_watcher(self, tmp_path, monkeypatch, capsys):
        monkeypatch.chdir(tmp_path)
        import json

        (tmp_path / ".kubera").mkdir()
        cred_path = tmp_path / ".kubera" / "credentials.json"
        cred_path.write_text(json.dumps([{
            "provider": "mail",
            "imap_host": "imap.test.com",
            "email": "test@test.com",
            "password": "secret",
        }]))

        from kubera.cli.commands import cmd_mail_watch

        mock_watcher = MagicMock()
        mock_watcher.start.side_effect = KeyboardInterrupt

        with patch(_WATCHER, return_value=mock_watcher) as MockWatcher, \
             patch(_GET_ENGINE), \
             patch(_GET_SESSION):
            args = argparse.Namespace()
            cmd_mail_watch(args)

        MockWatcher.assert_called_once()
        call_kwargs = MockWatcher.call_args.kwargs
        assert call_kwargs["imap_config"]["imap_host"] == "imap.test.com"
        mock_watcher.start.assert_called_once()
        mock_watcher.stop.assert_called_once()


class TestStartWithMailWatch:
    def test_auto_starts_when_credential_exists(self, tmp_path, monkeypatch, capsys):
        monkeypatch.chdir(tmp_path)
        import json

        (tmp_path / ".kubera").mkdir()
        cred_path = tmp_path / ".kubera" / "credentials.json"
        cred_path.write_text(json.dumps([{
            "provider": "mail",
            "imap_host": "imap.test.com",
            "email": "test@test.com",
            "password": "secret",
        }]))

        from kubera.cli.commands import cmd_start

        args = argparse.Namespace(host=None, port=None, no_mail_watch=False)

        mock_thread = MagicMock()

        with patch(_RUN_MIGRATIONS), \
             patch(_WATCHER) as MockWatcher, \
             patch(_GET_ENGINE), \
             patch(_GET_SESSION), \
             patch("threading.Thread", return_value=mock_thread), \
             patch("uvicorn.run"), \
             patch("kubera.api.main.create_app"):
            cmd_start(args)

        MockWatcher.assert_called_once()
        mock_thread.start.assert_called_once()
        captured = capsys.readouterr()
        assert "mail watcher enabled" in captured.out.lower()

    def test_skips_when_no_credential(self, tmp_path, monkeypatch, capsys):
        monkeypatch.chdir(tmp_path)
        from kubera.cli.commands import cmd_start

        args = argparse.Namespace(host=None, port=None, no_mail_watch=False)

        with patch(_RUN_MIGRATIONS), \
             patch("uvicorn.run"), \
             patch("kubera.api.main.create_app"):
            cmd_start(args)

        captured = capsys.readouterr()
        assert "mail watcher" not in captured.out.lower()

    def test_no_mail_watch_flag_disables(self, tmp_path, monkeypatch, capsys):
        monkeypatch.chdir(tmp_path)
        import json

        (tmp_path / ".kubera").mkdir()
        cred_path = tmp_path / ".kubera" / "credentials.json"
        cred_path.write_text(json.dumps([{
            "provider": "mail",
            "imap_host": "imap.test.com",
            "email": "test@test.com",
            "password": "secret",
        }]))

        from kubera.cli.commands import cmd_start

        args = argparse.Namespace(host=None, port=None, no_mail_watch=True)

        with patch(_RUN_MIGRATIONS), \
             patch("uvicorn.run"), \
             patch("kubera.api.main.create_app"):
            cmd_start(args)

        captured = capsys.readouterr()
        assert "mail watcher" not in captured.out.lower()


class TestCredentialAddMail:
    """Tests for mail credential add (Gmail only)."""

    _SAVE = "kubera.core.credentials.save_credential"

    _IMAP = "imaplib.IMAP4_SSL"

    def _mock_imap(self):
        mock = MagicMock()
        mock.login.return_value = ("OK", [])
        mock.logout.return_value = ("BYE", [])
        return mock

    def test_gmail_auto_fills_host(self, tmp_path, monkeypatch, capsys):
        monkeypatch.chdir(tmp_path)
        from kubera.cli.commands import _cmd_credential_add

        monkeypatch.setattr("builtins.input", lambda _: "user@gmail.com")
        monkeypatch.setattr("getpass.getpass", lambda _: "app-pass-16chars")

        saved = {}
        with patch(self._SAVE, side_effect=lambda c: saved.update(c)), \
             patch(self._IMAP, return_value=self._mock_imap()):
            args = argparse.Namespace(provider="mail")
            _cmd_credential_add(args)

        assert saved["imap_host"] == "imap.gmail.com"
        assert saved["imap_port"] == "993"
        assert saved["sender_filter"] == "banksalad"
        assert saved["email"] == "user@gmail.com"
        assert saved["password"] == "app-pass-16chars"

    def test_non_gmail_rejected(self, tmp_path, monkeypatch, capsys):
        monkeypatch.chdir(tmp_path)
        from kubera.cli.commands import _cmd_credential_add

        monkeypatch.setattr("builtins.input", lambda _: "user@naver.com")

        with pytest.raises(SystemExit) as exc_info:
            args = argparse.Namespace(provider="mail")
            _cmd_credential_add(args)

        assert exc_info.value.code == 1
        captured = capsys.readouterr()
        assert "gmail" in captured.out.lower()

    def test_secret_input_shows_char_count(self, tmp_path, monkeypatch, capsys):
        monkeypatch.chdir(tmp_path)
        from kubera.cli.commands import _cmd_credential_add

        monkeypatch.setattr("builtins.input", lambda _: "user@gmail.com")
        monkeypatch.setattr("getpass.getpass", lambda _: "abcd1234efgh5678")

        with patch(self._SAVE), \
             patch(self._IMAP, return_value=self._mock_imap()):
            args = argparse.Namespace(provider="mail")
            _cmd_credential_add(args)

        captured = capsys.readouterr()
        assert "16 chars" in captured.out

    def test_connection_failure_does_not_save(self, tmp_path, monkeypatch, capsys):
        monkeypatch.chdir(tmp_path)
        from kubera.cli.commands import _cmd_credential_add

        monkeypatch.setattr("builtins.input", lambda _: "user@gmail.com")
        monkeypatch.setattr("getpass.getpass", lambda _: "wrong-password")

        mock_imap = MagicMock()
        mock_imap.login.side_effect = Exception("AUTHENTICATIONFAILED")

        with patch(self._SAVE) as mock_save, \
             patch(self._IMAP, return_value=mock_imap):
            args = argparse.Namespace(provider="mail")
            with pytest.raises(SystemExit) as exc_info:
                _cmd_credential_add(args)

        assert exc_info.value.code == 1
        mock_save.assert_not_called()
        captured = capsys.readouterr()
        assert "FAILED" in captured.out


class TestGetMailConfig:
    def test_returns_none_when_no_credentials(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        from kubera.core.credentials import get_credential

        assert get_credential("mail") is None

    def test_returns_mail_config(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        import json

        (tmp_path / ".kubera").mkdir()
        cred_path = tmp_path / ".kubera" / "credentials.json"
        cred_path.write_text(json.dumps([{
            "provider": "mail",
            "imap_host": "imap.example.com",
            "email": "user@example.com",
            "password": "pass",
        }]))

        from kubera.core.credentials import get_credential

        config = get_credential("mail")
        assert config is not None
        assert config["imap_host"] == "imap.example.com"

    def test_ignores_non_mail_providers(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        import json

        (tmp_path / ".kubera").mkdir()
        cred_path = tmp_path / ".kubera" / "credentials.json"
        cred_path.write_text(json.dumps([{
            "provider": "other",
            "host": "example.com",
        }]))

        from kubera.core.credentials import get_credential

        assert get_credential("mail") is None
