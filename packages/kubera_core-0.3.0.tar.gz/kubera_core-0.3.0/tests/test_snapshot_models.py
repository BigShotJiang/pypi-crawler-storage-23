"""Tests for snapshot models: CRUD, unique constraint, cascade delete, relationships."""

from datetime import date, datetime
from decimal import Decimal

import pytest
from sqlalchemy.exc import IntegrityError

from kubera.core.snapshot.models import (
    AssetEntry,
    InsuranceEntry,
    InvestmentEntry,
    LedgerEntry,
    LoanEntry,
    Snapshot,
)


def _make_snapshot(db, snapshot_date=None, source="banksalad", user_id="default", filename_stem=None):
    snapshot = Snapshot(
        user_id=user_id,
        snapshot_date=snapshot_date or datetime(2025, 1, 15),
        source=source,
        credit_score=850,
        total_assets=Decimal("100000000.0000"),
        total_liabilities=Decimal("20000000.0000"),
        net_worth=Decimal("80000000.0000"),
        filename_stem=filename_stem,
    )
    db.add(snapshot)
    db.commit()
    db.refresh(snapshot)
    return snapshot


class TestSnapshot:
    def test_create_and_read(self, db):
        snapshot = _make_snapshot(db)

        loaded = db.get(Snapshot, snapshot.id)
        assert loaded is not None
        assert loaded.snapshot_date == datetime(2025, 1, 15)
        assert loaded.source == "banksalad"
        assert loaded.credit_score == 850
        assert loaded.total_assets == Decimal("100000000.0000")
        assert loaded.total_liabilities == Decimal("20000000.0000")
        assert loaded.net_worth == Decimal("80000000.0000")
        assert loaded.user_id == "default"

    def test_timestamps_auto_set(self, db):
        snapshot = _make_snapshot(db)
        assert snapshot.created_at is not None
        assert snapshot.updated_at is not None

    def test_unique_constraint_same_filename_and_source(self, db):
        _make_snapshot(db, snapshot_date=datetime(2025, 3, 1, 12, 0), source="banksalad", filename_stem="2025-02-15~2025-03-01")
        db.begin_nested()
        with pytest.raises(IntegrityError):
            _make_snapshot(db, snapshot_date=datetime(2025, 3, 1, 13, 0), source="banksalad", filename_stem="2025-02-15~2025-03-01")

    def test_unique_constraint_different_source_ok(self, db):
        _make_snapshot(db, snapshot_date=datetime(2025, 3, 1, 12, 0), source="banksalad", filename_stem="2025-02-15~2025-03-01")
        s2 = _make_snapshot(db, snapshot_date=datetime(2025, 3, 1, 12, 0), source="manual", filename_stem="2025-02-15~2025-03-01")
        assert s2.id is not None

    def test_unique_constraint_different_filename_ok(self, db):
        _make_snapshot(db, snapshot_date=datetime(2025, 3, 1, 12, 0), source="banksalad", filename_stem="2025-02-01~2025-02-15")
        s2 = _make_snapshot(db, snapshot_date=datetime(2025, 3, 1, 13, 0), source="banksalad", filename_stem="2025-02-15~2025-03-01")
        assert s2.id is not None

    def test_null_filename_stem_no_constraint(self, db):
        """Snapshots without filename_stem should not trigger unique constraint."""
        _make_snapshot(db, snapshot_date=datetime(2025, 3, 1, 12, 0), source="banksalad")
        s2 = _make_snapshot(db, snapshot_date=datetime(2025, 3, 1, 13, 0), source="banksalad")
        assert s2.id is not None

    def test_nullable_credit_score(self, db):
        snapshot = Snapshot(
            snapshot_date=datetime(2025, 2, 1),
            source="banksalad",
            total_assets=Decimal("0"),
            total_liabilities=Decimal("0"),
            net_worth=Decimal("0"),
        )
        db.add(snapshot)
        db.commit()
        db.refresh(snapshot)
        assert snapshot.credit_score is None


class TestAssetEntry:
    def test_create_with_relationship(self, db):
        snapshot = _make_snapshot(db)
        entry = AssetEntry(
            snapshot_id=snapshot.id,
            category="deposit",
            product_name="Shinhan Savings",
            amount=Decimal("50000000.0000"),
        )
        db.add(entry)
        db.commit()

        loaded = db.get(AssetEntry, entry.id)
        assert loaded.snapshot_id == snapshot.id
        assert loaded.category == "deposit"
        assert loaded.product_name == "Shinhan Savings"
        assert loaded.amount == Decimal("50000000.0000")
        assert loaded.snapshot.id == snapshot.id


class TestInvestmentEntry:
    def test_create_with_relationship(self, db):
        snapshot = _make_snapshot(db)
        entry = InvestmentEntry(
            snapshot_id=snapshot.id,
            broker="Samsung Securities",
            product_name="KODEX 200",
            invested_amount=Decimal("10000000.0000"),
            current_value=Decimal("11000000.0000"),
            return_rate=Decimal("10.0000"),
        )
        db.add(entry)
        db.commit()

        loaded = db.get(InvestmentEntry, entry.id)
        assert loaded.broker == "Samsung Securities"
        assert loaded.return_rate == Decimal("10.0000")
        assert loaded.snapshot.id == snapshot.id


class TestLoanEntry:
    def test_create_with_relationship(self, db):
        snapshot = _make_snapshot(db)
        entry = LoanEntry(
            snapshot_id=snapshot.id,
            lender="Woori Bank",
            product_name="Home Mortgage",
            principal=Decimal("200000000.0000"),
            balance=Decimal("180000000.0000"),
            interest_rate=Decimal("3.5000"),
            start_date=date(2023, 1, 1),
            end_date=date(2053, 1, 1),
        )
        db.add(entry)
        db.commit()

        loaded = db.get(LoanEntry, entry.id)
        assert loaded.lender == "Woori Bank"
        assert loaded.balance == Decimal("180000000.0000")
        assert loaded.interest_rate == Decimal("3.5000")
        assert loaded.start_date == date(2023, 1, 1)
        assert loaded.snapshot.id == snapshot.id


class TestInsuranceEntry:
    def test_create_with_relationship(self, db):
        snapshot = _make_snapshot(db)
        entry = InsuranceEntry(
            snapshot_id=snapshot.id,
            insurer="Samsung Life",
            product_name="Term Life Insurance",
            status="active",
            total_paid=Decimal("5000000.0000"),
            start_date=date(2020, 6, 1),
            end_date=date(2040, 6, 1),
        )
        db.add(entry)
        db.commit()

        loaded = db.get(InsuranceEntry, entry.id)
        assert loaded.insurer == "Samsung Life"
        assert loaded.status == "active"
        assert loaded.total_paid == Decimal("5000000.0000")
        assert loaded.snapshot.id == snapshot.id


class TestLedgerEntry:
    def test_create_with_relationship(self, db):
        snapshot = _make_snapshot(db)
        entry = LedgerEntry(
            snapshot_id=snapshot.id,
            entry_date=date(2025, 1, 10),
            entry_time=None,
            entry_type="지출",
            major_category="식비",
            minor_category="외식",
            description="점심",
            amount=Decimal("-15000.0000"),
            currency="KRW",
            payment_method="신한카드",
            memo=None,
        )
        db.add(entry)
        db.commit()

        loaded = db.get(LedgerEntry, entry.id)
        assert loaded.snapshot_id == snapshot.id
        assert loaded.entry_date == date(2025, 1, 10)
        assert loaded.entry_type == "지출"
        assert loaded.major_category == "식비"
        assert loaded.amount == Decimal("-15000.0000")
        assert loaded.snapshot.id == snapshot.id

    def test_nullable_fields(self, db):
        snapshot = _make_snapshot(db)
        entry = LedgerEntry(
            snapshot_id=snapshot.id,
            entry_date=date(2025, 1, 5),
            entry_type="수입",
            major_category="급여",
            amount=Decimal("3000000.0000"),
        )
        db.add(entry)
        db.commit()

        loaded = db.get(LedgerEntry, entry.id)
        assert loaded.entry_time is None
        assert loaded.minor_category is None
        assert loaded.description is None
        assert loaded.payment_method is None
        assert loaded.memo is None
        assert loaded.currency == "KRW"


class TestCascadeDelete:
    def test_deleting_snapshot_removes_all_entries(self, db):
        snapshot = _make_snapshot(db)
        sid = snapshot.id

        db.add(AssetEntry(snapshot_id=sid, category="deposit", product_name="A", amount=Decimal("1000")))
        db.add(InvestmentEntry(snapshot_id=sid, broker="B", product_name="C", invested_amount=Decimal("1000"), current_value=Decimal("1100")))
        db.add(LoanEntry(snapshot_id=sid, lender="D", product_name="E", principal=Decimal("5000"), balance=Decimal("4000")))
        db.add(InsuranceEntry(snapshot_id=sid, insurer="F", product_name="G", status="active", total_paid=Decimal("500")))
        db.add(LedgerEntry(snapshot_id=sid, entry_date=date(2025, 1, 10), entry_type="지출", major_category="식비", amount=Decimal("-10000")))
        db.commit()

        assert len(snapshot.asset_entries) == 1
        assert len(snapshot.investment_entries) == 1
        assert len(snapshot.loan_entries) == 1
        assert len(snapshot.insurance_entries) == 1
        assert len(snapshot.ledger_entries) == 1

        db.delete(snapshot)
        db.commit()

        assert db.get(Snapshot, sid) is None
        assert db.get(AssetEntry, 1) is None
        assert db.get(InvestmentEntry, 1) is None
        assert db.get(LoanEntry, 1) is None
        assert db.get(InsuranceEntry, 1) is None
        assert db.get(LedgerEntry, 1) is None


class TestRelationshipBackPopulates:
    def test_add_entries_via_relationship(self, db):
        snapshot = Snapshot(
            snapshot_date=datetime(2025, 5, 1),
            source="banksalad",
            total_assets=Decimal("10000"),
            total_liabilities=Decimal("0"),
            net_worth=Decimal("10000"),
            asset_entries=[
                AssetEntry(category="deposit", product_name="Account A", amount=Decimal("5000")),
                AssetEntry(category="fund", product_name="Account B", amount=Decimal("5000")),
            ],
        )
        db.add(snapshot)
        db.commit()
        db.refresh(snapshot)

        assert len(snapshot.asset_entries) == 2
        assert snapshot.asset_entries[0].snapshot_id == snapshot.id
        assert snapshot.asset_entries[1].snapshot_id == snapshot.id
