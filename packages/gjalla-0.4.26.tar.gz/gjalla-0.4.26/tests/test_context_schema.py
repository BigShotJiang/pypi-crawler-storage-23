import importlib

import pytest


context = importlib.import_module("gjalla_precommit.config.context")


def test_context_schema_version_current(sample_context: dict):
    assert context.is_schema_current(sample_context)


def test_context_schema_version_old(sample_context: dict):
    old = dict(sample_context)
    old["schema_version"] = context.get_expected_schema_version() - 1
    assert context.should_refresh_context(old)


def test_context_schema_migration(sample_context: dict):
    old = dict(sample_context)
    old["schema_version"] = context.get_expected_schema_version() - 1
    migrated = context.migrate_context(old)
    assert migrated["schema_version"] == context.get_expected_schema_version()


def test_context_schema_future_version(sample_context: dict):
    future = dict(sample_context)
    future["schema_version"] = context.get_expected_schema_version() + 1
    assert context.is_schema_future(future)
