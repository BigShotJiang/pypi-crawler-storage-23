# ---------- tgapi ----------
log_bot_path = "storage/logs/bot.csv"
bot_folder = "bot"
config_path = "config.txt"
config_dev_path = "config_dev.txt"
