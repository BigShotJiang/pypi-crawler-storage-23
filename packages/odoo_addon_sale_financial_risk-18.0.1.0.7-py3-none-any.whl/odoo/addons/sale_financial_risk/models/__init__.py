from . import payment
from . import res_company
from . import res_partner
from . import sale
from . import res_config_settings
