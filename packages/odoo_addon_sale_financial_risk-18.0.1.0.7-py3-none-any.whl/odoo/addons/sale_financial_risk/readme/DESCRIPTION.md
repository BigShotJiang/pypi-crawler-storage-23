Extends Partner Financial Risk to manage sales orders.

Adds a new risk amount field in sale order line to compute risk based on
the difference between ordered quantity (or delivered in some cases) and
invoiced quantity.

If any limit is exceed the partner gets forbidden to confirm sale
orders.
