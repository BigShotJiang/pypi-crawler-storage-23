from . import test_partner_sale_risk
from . import test_payment_financial_risk
