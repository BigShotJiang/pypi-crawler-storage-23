Installation
============

Install from `PyPI <https://pypi.org/project/mixinv2/>`_:

.. code-block:: bash

   pip install mixinv2
