import pytest

import diffweave


def test_tree():
    diffweave.run_cmd("tree")
