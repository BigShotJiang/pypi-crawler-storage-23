from leid.client import SearchResult, WordEntry, Example, ParadigmTable, FormMatch
from leid.formatters import format_search, format_lookup, format_paradigm, format_identify, MORPH_LABELS
from leid.config import OutputFormat


SEARCH_RESULTS = [
    SearchResult(word_id=199880, word="maja", homonym_nr=1, datasets=["eki", "ety"]),
    SearchResult(word_id=199881, word="maja", homonym_nr=2, datasets=["eki"]),
]

WORD_ENTRY = WordEntry(
    word_id=199880, lemma="maja", homonym_nr=1, pos="s",
    grammar_notes=["17. tüüp"],
    definitions=["hoone inimestele elamiseks, töötamiseks jne"],
    examples=[Example(text="Kivimaja.", translation=None)]
)

PARADIGM = ParadigmTable(
    word_class="noomen", inflection_type="17u",
    forms={"SgN": "maja", "SgG": "maja", "SgP": "maja", "SgAdt": "majja", "SgIn": "majas"}
)

FORM_MATCHES = [
    FormMatch(word_id=199880, lemma="maja", homonym_nr=1, morph_codes=["SgIn"])
]


def test_format_search_markdown_contains_word_ids():
    output = format_search(SEARCH_RESULTS, OutputFormat.MARKDOWN, query="maja")
    assert "199880" in output
    assert "199881" in output
    assert "maja" in output


def test_format_search_markdown_contains_table():
    output = format_search(SEARCH_RESULTS, OutputFormat.MARKDOWN, query="maja")
    assert "|" in output  # markdown table


def test_format_lookup_markdown_contains_definition():
    output = format_lookup(WORD_ENTRY, OutputFormat.MARKDOWN)
    assert "hoone" in output
    assert "199880" in output
    assert "maja" in output


def test_format_lookup_markdown_contains_example():
    output = format_lookup(WORD_ENTRY, OutputFormat.MARKDOWN)
    assert "Kivimaja" in output


def test_format_paradigm_markdown_contains_forms():
    output = format_paradigm(PARADIGM, OutputFormat.MARKDOWN, lemma="maja")
    assert "maja" in output
    assert "majja" in output
    assert "majas" in output
    assert "17u" in output


def test_format_identify_markdown_contains_lemma():
    output = format_identify(FORM_MATCHES, OutputFormat.MARKDOWN, form="majas")
    assert "maja" in output
    assert "199880" in output


def test_format_identify_markdown_contains_lemma_and_morph():
    output = format_identify(FORM_MATCHES, OutputFormat.MARKDOWN, form="majas")
    assert "maja" in output
    assert "199880" in output
    assert "SgIn" in output
    assert "Inessive" in output  # label from MORPH_LABELS


def test_inf_is_da_infinitive():
    assert MORPH_LABELS["Inf"] == "da-infinitive"


def test_sup_is_ma_infinitive():
    assert MORPH_LABELS["Sup"] == "ma-infinitive"


def test_verb_codes_present():
    for code in ["Ger", "SupIn", "SupEl", "SupAb", "SupTr",
                 "IndIpfSg1", "IndIpfSg3", "IndIpfIps",
                 "ImpPrSg2", "KndPrPs", "KvtPrPs", "PtsPrPs",
                 "PtsPtIps", "PtsPtIpsNeg"]:
        assert code in MORPH_LABELS, f"Missing label for {code}"


def test_format_search_pretty_returns_string():
    output = format_search(SEARCH_RESULTS, OutputFormat.PRETTY, query="maja")
    assert isinstance(output, str)
    assert len(output) > 0
