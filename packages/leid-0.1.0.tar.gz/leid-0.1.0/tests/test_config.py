import os
import pytest
import tomllib
from unittest.mock import patch, MagicMock, mock_open
from leid.config import resolve_config, OutputFormat


def test_default_format_is_markdown():
    mock_cfg = MagicMock()
    mock_cfg.exists.return_value = False
    with patch.dict(os.environ, {"LEID_API_KEY": "test-key"}, clear=True):
        with patch("leid.config.CONFIG_FILE", mock_cfg):
            cfg = resolve_config(cli_format=None)
    assert cfg.format == OutputFormat.MARKDOWN


def test_cli_format_overrides_env():
    mock_cfg = MagicMock()
    mock_cfg.exists.return_value = False
    with patch.dict(os.environ, {"LEID_FORMAT": "pretty", "LEID_API_KEY": "test-key"}):
        with patch("leid.config.CONFIG_FILE", mock_cfg):
            cfg = resolve_config(cli_format=OutputFormat.MARKDOWN)
    assert cfg.format == OutputFormat.MARKDOWN


def test_env_var_overrides_config_file():
    parsed = {"output": {"format": "pretty"}, "api": {"key": "file-key"}}
    mock_cfg = MagicMock()
    mock_cfg.exists.return_value = True
    with patch.dict(os.environ, {"LEID_FORMAT": "markdown", "LEID_API_KEY": "env-key"}, clear=True):
        with patch("leid.config.CONFIG_FILE", mock_cfg):
            with patch("builtins.open", mock_open()):
                with patch("leid.config.tomllib.load", return_value=parsed):
                    cfg = resolve_config(cli_format=None)
    assert cfg.format == OutputFormat.MARKDOWN
    assert cfg.api_key == "env-key"


def test_config_file_used_when_no_env():
    parsed = {
        "output": {"format": "pretty"},
        "api": {"key": "file-key", "base_url": "https://example.com", "dataset": "eki"}
    }
    mock_cfg = MagicMock()
    mock_cfg.exists.return_value = True
    with patch.dict(os.environ, {}, clear=True):
        with patch("leid.config.CONFIG_FILE", mock_cfg):
            with patch("builtins.open", mock_open()):
                with patch("leid.config.tomllib.load", return_value=parsed):
                    cfg = resolve_config(cli_format=None)
    assert cfg.format == OutputFormat.PRETTY
    assert cfg.api_key == "file-key"
    assert cfg.base_url == "https://example.com"
    assert cfg.dataset == "eki"


def test_missing_api_key_raises():
    mock_cfg = MagicMock()
    mock_cfg.exists.return_value = False
    with patch.dict(os.environ, {}, clear=True):
        with patch("leid.config.CONFIG_FILE", mock_cfg):
            with pytest.raises(SystemExit):
                resolve_config(cli_format=None)
