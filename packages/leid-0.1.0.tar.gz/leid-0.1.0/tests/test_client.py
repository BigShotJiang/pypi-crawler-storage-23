import pytest
import respx
import httpx
from leid.client import EkilexClient, SearchResult, WordEntry, ParadigmTable, FormMatch


@pytest.fixture
def client():
    return EkilexClient(api_key="test-key", base_url="https://ekilex.ee", dataset="eki")


SEARCH_RESPONSE = {
    "totalCount": 2,
    "words": [
        {"wordId": 199880, "wordValue": "maja", "homonymNr": 1, "lang": "est",
         "datasetCodes": ["eki", "ety"]},
        {"wordId": 199881, "wordValue": "maja", "homonymNr": 2, "lang": "est",
         "datasetCodes": ["eki"]},
    ]
}

DETAILS_RESPONSE = {
    "word": {"wordId": 199880, "wordValue": "maja", "homonymNr": 1, "lang": "est"},
    "lexemes": [
        {
            "lexemeId": 5001, "datasetCode": "eki",
            "pos": [{"code": "s", "value": "nimisõna, substantiiv"}],
            "grammars": [{"value": "17. tüüp"}],
            "usages": [{"value": "Kivimaja.", "translations": None}],
            "meaning": {
                "definitions": [
                    {"value": "hoone inimestele elamiseks, töötamiseks jne", "lang": "est"}
                ]
            }
        }
    ]
}

PARADIGM_RESPONSE = [
    {
        "wordClass": "noomen", "inflectionType": "17u",
        "paradigmForms": [
            {"value": "maja", "morphCode": "SgN"},
            {"value": "maja", "morphCode": "SgG"},
            {"value": "maja", "morphCode": "SgP"},
            {"value": "majja", "morphCode": "SgAdt"},
            {"value": "majas", "morphCode": "SgIn"},
        ]
    }
]

FORM_RESPONSE = [
    {"wordId": 199880, "wordValue": "maja", "homonymNr": 1, "lang": "est"}
]


@respx.mock
def test_search_returns_results(client):
    respx.get("https://ekilex.ee/api/word/search/maja").mock(
        return_value=httpx.Response(200, json=SEARCH_RESPONSE)
    )
    results = client.search("maja")
    assert len(results) == 2
    assert results[0].word_id == 199880
    assert results[0].word == "maja"
    assert results[0].homonym_nr == 1
    assert "eki" in results[0].datasets


@respx.mock
def test_lookup_returns_word_entry(client):
    respx.get("https://ekilex.ee/api/word/details/199880").mock(
        return_value=httpx.Response(200, json=DETAILS_RESPONSE)
    )
    entry = client.lookup(199880)
    assert entry.word_id == 199880
    assert entry.lemma == "maja"
    assert entry.pos == "s"
    assert len(entry.definitions) == 1
    assert "hoone" in entry.definitions[0]
    assert len(entry.examples) == 1
    assert entry.examples[0].text == "Kivimaja."


@respx.mock
def test_paradigm_returns_table(client):
    respx.get("https://ekilex.ee/api/paradigm/details/199880").mock(
        return_value=httpx.Response(200, json=PARADIGM_RESPONSE)
    )
    table = client.paradigm(199880)
    assert table.word_class == "noomen"
    assert table.inflection_type == "17u"
    assert table.forms["SgN"] == "maja"
    assert table.forms["SgAdt"] == "majja"
    assert table.forms["SgIn"] == "majas"


PARADIGM_RESPONSE_MAJA = [
    {
        "wordClass": "noomen", "inflectionType": "17u",
        "paradigmForms": [
            {"value": "maja", "morphCode": "SgN"},
            {"value": "maja", "morphCode": "SgG"},
            {"value": "maja", "morphCode": "SgP"},
            {"value": "majja", "morphCode": "SgAdt"},
            {"value": "majas", "morphCode": "SgIn"},
        ]
    }
]

VERB_FORM_RESPONSE = [
    {"wordId": 173981, "wordValue": "jooksma", "homonymNr": 1, "lang": "est"}
]
VERB_PARADIGM_RESPONSE = [
    {
        "wordClass": "tegusõna", "inflectionType": "56",
        "paradigmForms": [
            {"value": "jooksid", "morphCode": "IndIpfSg2"},
            {"value": "jooksid", "morphCode": "IndIpfPl3"},
            {"value": "jooksin", "morphCode": "IndIpfSg1"},
        ]
    }
]


@respx.mock
def test_identify_returns_form_match(client):
    respx.get("https://ekilex.ee/api/form/search/majas").mock(
        return_value=httpx.Response(200, json=FORM_RESPONSE)
    )
    respx.get("https://ekilex.ee/api/paradigm/details/199880").mock(
        return_value=httpx.Response(200, json=PARADIGM_RESPONSE_MAJA)
    )
    matches = client.identify("majas")
    assert len(matches) == 1
    assert matches[0].word_id == 199880
    assert matches[0].lemma == "maja"
    assert matches[0].homonym_nr == 1
    assert matches[0].morph_codes == ["SgIn"]


@respx.mock
def test_identify_returns_multiple_morph_codes_for_ambiguous_form(client):
    respx.get("https://ekilex.ee/api/form/search/jooksid").mock(
        return_value=httpx.Response(200, json=VERB_FORM_RESPONSE)
    )
    respx.get("https://ekilex.ee/api/paradigm/details/173981").mock(
        return_value=httpx.Response(200, json=VERB_PARADIGM_RESPONSE)
    )
    matches = client.identify("jooksid")
    assert len(matches) == 1
    assert set(matches[0].morph_codes) == {"IndIpfSg2", "IndIpfPl3"}


MULTI_PARADIGM_RESPONSE = [
    {
        "wordClass": "noomen", "inflectionType": "15",
        "paradigmForms": [
            {"value": "käsi", "morphCode": "SgN"},
            {"value": "käe", "morphCode": "SgG"},
        ]
    },
    {
        "wordClass": None, "inflectionType": None,
        "paradigmForms": [{"value": "kätt", "morphCode": "SgP"}]
    },
    {
        "wordClass": None, "inflectionType": None,
        "paradigmForms": [{"value": "kätte", "morphCode": "SgIll"}]
    },
]


@respx.mock
def test_paradigm_skips_entries_without_inflection_type(client):
    respx.get("https://ekilex.ee/api/paradigm/details/190275").mock(
        return_value=httpx.Response(200, json=MULTI_PARADIGM_RESPONSE)
    )
    table = client.paradigm(190275)
    assert table.inflection_type == "15"
    assert table.word_class == "noomen"
    assert "SgN" in table.forms
    assert "SgG" in table.forms
    assert len(table.forms) == 2


@respx.mock
def test_search_sends_api_key_header(client):
    route = respx.get("https://ekilex.ee/api/word/search/maja").mock(
        return_value=httpx.Response(200, json={"totalCount": 0, "words": []})
    )
    client.search("maja")
    assert route.calls[0].request.headers["ekilex-api-key"] == "test-key"
