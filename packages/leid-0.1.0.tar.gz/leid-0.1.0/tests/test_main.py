import respx
import httpx
import pytest
from typer.testing import CliRunner
from leid.main import app

runner = CliRunner()

SEARCH_RESPONSE = {
    "totalCount": 1,
    "words": [{"wordId": 199880, "wordValue": "maja", "homonymNr": 1, "lang": "est",
               "datasetCodes": ["eki"]}]
}
DETAILS_RESPONSE = {
    "word": {"wordId": 199880, "wordValue": "maja", "homonymNr": 1},
    "lexemes": [
        {
            "lexemeId": 5001, "datasetCode": "eki",
            "pos": [{"code": "s", "value": "noun"}],
            "grammars": [],
            "usages": [],
            "meaning": {"definitions": [{"value": "Elamu.", "lang": "est"}]}
        }
    ]
}
PARADIGM_RESPONSE = [
    {"wordClass": "noomen", "inflectionType": "17u",
     "paradigmForms": [
         {"value": "maja", "morphCode": "SgN"},
         {"value": "majas", "morphCode": "SgIn"},
     ]}
]
FORM_RESPONSE = [
    {"wordId": 199880, "wordValue": "maja", "homonymNr": 1, "lang": "est"}
]


@pytest.fixture(autouse=True)
def mock_config(monkeypatch):
    monkeypatch.setenv("LEID_API_KEY", "test-key")
    monkeypatch.setenv("SONA_BASE_URL", "https://ekilex.ee")
    monkeypatch.setenv("SONA_DATASET", "eki")


@respx.mock
def test_search_command_outputs_word_id():
    respx.get("https://ekilex.ee/api/word/search/maja").mock(
        return_value=httpx.Response(200, json=SEARCH_RESPONSE)
    )
    result = runner.invoke(app, ["search", "maja"])
    assert result.exit_code == 0
    assert "199880" in result.output


@respx.mock
def test_lookup_command_outputs_definition():
    respx.get("https://ekilex.ee/api/word/details/199880").mock(
        return_value=httpx.Response(200, json=DETAILS_RESPONSE)
    )
    result = runner.invoke(app, ["lookup", "199880"])
    assert result.exit_code == 0
    assert "Elamu" in result.output


@respx.mock
def test_paradigm_command_outputs_forms():
    respx.get("https://ekilex.ee/api/paradigm/details/199880").mock(
        return_value=httpx.Response(200, json=PARADIGM_RESPONSE)
    )
    result = runner.invoke(app, ["paradigm", "199880"])
    assert result.exit_code == 0
    assert "majas" in result.output


@respx.mock
def test_identify_command_outputs_lemma():
    respx.get("https://ekilex.ee/api/form/search/majas").mock(
        return_value=httpx.Response(200, json=FORM_RESPONSE)
    )
    respx.get("https://ekilex.ee/api/paradigm/details/199880").mock(
        return_value=httpx.Response(200, json=PARADIGM_RESPONSE)
    )
    result = runner.invoke(app, ["identify", "majas"])
    assert result.exit_code == 0
    assert "maja" in result.output
    assert "SgIn" in result.output


@respx.mock
def test_format_flag_overrides_default():
    respx.get("https://ekilex.ee/api/word/search/maja").mock(
        return_value=httpx.Response(200, json=SEARCH_RESPONSE)
    )
    result = runner.invoke(app, ["--format", "pretty", "search", "maja"])
    assert result.exit_code == 0
    assert "maja" in result.output
