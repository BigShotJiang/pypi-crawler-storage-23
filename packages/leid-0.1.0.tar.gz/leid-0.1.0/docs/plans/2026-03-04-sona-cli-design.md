# sona-cli Design

**Date:** 2026-03-04
**Status:** Approved

## Overview

A CLI tool that wraps the public [sonaveeb.ee](https://sonaveeb.ee) (ekilex) API for Estonian language lookup, designed primarily as a tool for AI-driven Estonian language teaching. Ships with a Claude Code skill so the AI can call the CLI to verify word details, declension/conjugation paradigms, and identify inflected forms — rather than relying on its own memory.

---

## Project

- **Name:** `sona-cli`
- **Location:** `/home/adam/projects/sona-cli`
- **Language:** Python 3.11+
- **Package manager:** uv
- **Key dependencies:** Typer, Rich, httpx

---

## Commands

Four commands, all accepting a `--format` flag:

| Command | Input | Description |
|---|---|---|
| `sona search <word>` | surface form | Disambiguation list: wordId, homonym nr, POS, brief gloss |
| `sona lookup <wordId>` | wordId | Full definition, examples, grammar notes |
| `sona paradigm <wordId>` | wordId | Full inflection table (declension or conjugation) |
| `sona identify <form>` | inflected form | Base lemma + wordId + case/form label |

Every response always includes `wordId` so the AI can chain calls without re-searching.

### Workflow for AI

1. `sona search <word>` → pick correct homonym by context → note `wordId`
2. `sona lookup <wordId>` for definitions/examples
3. `sona paradigm <wordId>` for inflection tables (never recite from memory)
4. `sona identify <form>` when a student produces an inflected form to parse

---

## Output Formats

**Markdown (default):** Clean text with headings, tables, and code blocks. Designed for AI consumption — minimal tokens, structured.

**Pretty:** Rich panels, colored tables, borders. For humans reading in a terminal.

### Example outputs

**`sona search tee` (markdown):**
```markdown
# Search results: "tee"

| wordId | Word | # | POS  | Gloss                      |
|--------|------|---|------|----------------------------|
| 10234  | tee  | 1 | noun | road, path                 |
| 10235  | tee  | 2 | noun | tea (drink)                |
| 10236  | tee  | 3 | verb | to do, to make (imperative)|
```

**`sona paradigm 10234` (markdown):**
```markdown
# maja — declension (type 22)

| Case        | Singular | Plural      |
|-------------|----------|-------------|
| Nominative  | maja     | majad       |
| Genitive    | maja     | majade      |
| Partitive   | maja     | maju        |
| Illative    | majja    | majadesse   |
| Inessive    | majas    | majades     |
| Elative     | majast   | majadest    |
| Allative    | majale   | majadele    |
| Adessive    | majal    | majadel     |
| Ablative    | majalt   | majadelt    |
| Translative | majaks   | majadeks    |
| Terminative | majani   | majadeni    |
| Essive      | majana   | majadena    |
| Abessive    | majata   | majadeta    |
| Comitative  | majaga   | majadega    |
```

**`sona identify majas` (markdown):**
```markdown
# majas → maja (wordId: 10234)
**Case:** Inessive singular — *"in the house"*
```

---

## Configuration

Priority (highest → lowest): CLI flag → env var → config file → default

**Default:** `markdown`

**Config file:** `~/.config/sona-cli/config.toml`
```toml
[output]
format = "markdown"   # or "pretty"

[api]
key = "your-api-key-here"
base_url = "https://api.sonaveeb.ee"
dataset = "sss"
```

**Env vars:**
```bash
SONA_FORMAT=pretty
SONA_API_KEY=abc123
SONA_BASE_URL=https://api.sonaveeb.ee
SONA_DATASET=sss
```

**CLI flag (all commands):**
```bash
sona --format pretty search tee
sona --format markdown paradigm 10234
```

API key is required — the tool exits with a clear error if not found in any source.

---

## Project Layout

```
sona-cli/
├── sona/
│   ├── __init__.py
│   ├── main.py          # Typer app, 4 commands
│   ├── client.py        # ekilex API calls + response filtering
│   ├── formatters.py    # markdown vs pretty renderers
│   └── config.py        # config resolution (CLI > env > file > default)
├── skill.md             # Claude Code skill — copy to ~/.claude/skills/sona.md
├── pyproject.toml       # entry point: `sona` command
└── README.md            # setup instructions including skill installation
```

---

## Claude Code Skill (`skill.md`)

Ships in the repo so the whole setup is self-contained and publishable to GitHub.

**Skill behavior:**
- Triggers when: student asks about a word, AI needs to show a paradigm, AI needs to identify an inflected form, AI needs to verify grammar before teaching
- Always `search` first, resolve homonym by context, then `lookup` or `paradigm` by `wordId`
- Use `paradigm` for all inflection tables — never recite from memory
- Use `identify` to parse any inflected form the student produces
- Cache `wordId`s within the session — don't re-search already-resolved words
- Output is markdown by default — no `--format` flag needed in normal use

**README setup steps:**
1. `uv tool install .` (or `pip install .`)
2. Set `SONA_API_KEY` or add key to `~/.config/sona-cli/config.toml`
3. `cp skill.md ~/.claude/skills/sona.md`
4. Optional: `install-skill.sh` one-liner script for step 3

---

## API Endpoints Used

| Command | Endpoints called |
|---|---|
| `search` | `GET /api/word/search/{word}` |
| `lookup` | `GET /api/word/details/{wordId}` |
| `paradigm` | `GET /api/paradigm/details/{wordId}` |
| `identify` | `GET /api/form/search/{form}` |

Fields stripped from raw API responses: collocations, relation graphs, synonym hierarchies, forums, learner comments, media, etymology, source links, timestamps, admin/status flags.
