# sona-cli Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Build a 4-command Python CLI tool wrapping the sonaveeb.ee ekilex API for Estonian word lookup, designed primarily for AI-driven language teaching.

**Architecture:** Typer CLI with 4 commands (`search`, `lookup`, `paradigm`, `identify`), each calling filtered ekilex API endpoints and rendering output as markdown (default) or Rich terminal pretty output. Config resolved in priority: CLI flag → env var → config file → default (markdown).

**Tech Stack:** Python 3.11+, uv, Typer, Rich, httpx, pytest, respx

---

## Reference

**API base URL (default):** `https://api.sonaveeb.ee`
**API key header:** `ekilex-api-key`
**Default dataset:** `sss`

**Endpoints used:**
| Command | Endpoint |
|---|---|
| `search` | `GET /api/word/search/{word}` |
| `lookup` | `GET /api/word/details/{wordId}` |
| `paradigm` | `GET /api/paradigm/details/{wordId}` |
| `identify` | `GET /api/form/search/{form}` |

**Key JSON shapes (camelCase from Jackson):**

`/api/word/search/{word}` returns:
```json
{
  "words": [
    { "wordId": 10234, "wordValue": "tee", "homonymNr": 1, "lang": "et",
      "displayMorphCode": "s", "genderCode": null }
  ]
}
```

`/api/word/details/{wordId}` returns:
```json
{
  "word": { "wordId": 10234, "wordValue": "maja", "homonymNr": 1,
            "displayMorphCode": "s", "genderCode": null, "aspectCode": null },
  "lexemes": [
    {
      "lexemeId": 5001, "datasetCode": "sss",
      "pos": [{ "code": "s", "value": "noun" }],
      "registers": [],
      "grammars": [{ "value": "type 22" }],
      "usages": [
        { "value": "Maja on suur.", "lang": "et",
          "translations": [{ "value": "The house is big.", "lang": "en" }] }
      ],
      "meanings": [
        { "meaningId": 8001,
          "definitions": [{ "value": "Elamu, korterelamu.", "lang": "et" }] }
      ]
    }
  ],
  "firstDefinitionValue": "Elamu, korterelamu."
}
```

`/api/paradigm/details/{wordId}` returns:
```json
[
  {
    "wordClass": "noomen", "inflectionType": "22", "inflectionTypeNr": "22",
    "paradigmForms": [
      { "value": "maja", "morphCode": "sg n", "morphGroup1": "sg", "morphGroup2": "n" },
      { "value": "majja", "morphCode": "sg ill", "morphGroup1": "sg", "morphGroup2": "ill" }
    ]
  }
]
```

`/api/form/search/{form}` returns:
```json
[
  { "wordId": 10234, "wordValue": "maja", "homonymNr": 1,
    "wordClass": "noomen", "morphCode": "sg in" }
]
```

---

## Task 1: Project Scaffolding

**Files:**
- Create: `pyproject.toml`
- Create: `sona/__init__.py`
- Create: `sona/main.py`
- Create: `sona/client.py`
- Create: `sona/config.py`
- Create: `sona/formatters.py`
- Create: `tests/__init__.py`

**Step 1: Initialize uv project**

```bash
cd /home/adam/projects/sona-cli
uv init --name sona-cli --python 3.11
```

**Step 2: Replace generated pyproject.toml**

Delete the generated `pyproject.toml` and write:

```toml
[project]
name = "sona-cli"
version = "0.1.0"
description = "Estonian word lookup CLI for AI-driven language teaching"
readme = "README.md"
requires-python = ">=3.11"
dependencies = [
    "typer>=0.12.0",
    "rich>=13.0.0",
    "httpx>=0.27.0",
]

[project.scripts]
sona = "sona.main:app"

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[dependency-groups]
dev = [
    "pytest>=8.0.0",
    "respx>=0.21.0",
]
```

**Step 3: Create package skeleton**

```bash
mkdir -p sona tests
touch sona/__init__.py sona/main.py sona/client.py sona/config.py sona/formatters.py
touch tests/__init__.py
```

**Step 4: Install dependencies**

```bash
uv sync
```

Expected: resolves and installs all deps, creates `.venv/`.

**Step 5: Verify entry point wires up**

Add to `sona/main.py`:
```python
import typer
app = typer.Typer()

if __name__ == "__main__":
    app()
```

Run:
```bash
uv run sona --help
```
Expected: shows Typer help with no commands yet.

**Step 6: Commit**

```bash
git add pyproject.toml sona/ tests/
git commit -m "feat: scaffold sona-cli project"
```

---

## Task 2: Config Module

**Files:**
- Create: `sona/config.py`
- Create: `tests/test_config.py`

**Step 1: Write failing tests**

```python
# tests/test_config.py
import os
import pytest
from pathlib import Path
from unittest.mock import patch, mock_open
from sona.config import resolve_config, OutputFormat


def test_default_format_is_markdown():
    with patch.dict(os.environ, {}, clear=True):
        with patch("sona.config.CONFIG_FILE.exists", return_value=False):
            cfg = resolve_config(cli_format=None)
    assert cfg.format == OutputFormat.MARKDOWN


def test_cli_format_overrides_env():
    with patch.dict(os.environ, {"SONA_FORMAT": "pretty"}):
        cfg = resolve_config(cli_format=OutputFormat.MARKDOWN)
    assert cfg.format == OutputFormat.MARKDOWN


def test_env_var_overrides_config_file():
    toml_content = '[output]\nformat = "pretty"\n[api]\nkey = "file-key"'
    with patch.dict(os.environ, {"SONA_FORMAT": "markdown", "SONA_API_KEY": "env-key"}):
        with patch("sona.config.CONFIG_FILE.exists", return_value=True):
            with patch("builtins.open", mock_open(read_data=toml_content)):
                cfg = resolve_config(cli_format=None)
    assert cfg.format == OutputFormat.MARKDOWN
    assert cfg.api_key == "env-key"


def test_config_file_used_when_no_env():
    toml_content = '[output]\nformat = "pretty"\n[api]\nkey = "file-key"\nbase_url = "https://example.com"\ndataset = "eki"'
    with patch.dict(os.environ, {}, clear=True):
        with patch("sona.config.CONFIG_FILE.exists", return_value=True):
            with patch("builtins.open", mock_open(read_data=toml_content)):
                cfg = resolve_config(cli_format=None)
    assert cfg.format == OutputFormat.PRETTY
    assert cfg.api_key == "file-key"
    assert cfg.base_url == "https://example.com"
    assert cfg.dataset == "eki"


def test_missing_api_key_raises():
    with patch.dict(os.environ, {}, clear=True):
        with patch("sona.config.CONFIG_FILE.exists", return_value=False):
            with pytest.raises(SystemExit):
                resolve_config(cli_format=None)
```

**Step 2: Run tests to verify they fail**

```bash
uv run pytest tests/test_config.py -v
```
Expected: FAIL — `cannot import name 'resolve_config'`

**Step 3: Implement config.py**

```python
# sona/config.py
import os
import sys
import tomllib
from dataclasses import dataclass
from enum import Enum
from pathlib import Path

CONFIG_FILE = Path.home() / ".config" / "sona-cli" / "config.toml"


class OutputFormat(str, Enum):
    MARKDOWN = "markdown"
    PRETTY = "pretty"


@dataclass
class Config:
    format: OutputFormat
    api_key: str
    base_url: str
    dataset: str


def resolve_config(cli_format: OutputFormat | None) -> Config:
    file_cfg: dict = {}
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE, "rb") as f:
            file_cfg = tomllib.load(f)

    def _get(env_var: str, file_section: str, file_key: str, default: str) -> str:
        if env_value := os.environ.get(env_var):
            return env_value
        if file_section in file_cfg and file_key in file_cfg[file_section]:
            return file_cfg[file_section][file_key]
        return default

    raw_format = _get("SONA_FORMAT", "output", "format", "markdown")
    resolved_format = cli_format if cli_format is not None else OutputFormat(raw_format)

    api_key = _get("SONA_API_KEY", "api", "key", "")
    if not api_key:
        print("Error: API key not found. Set SONA_API_KEY env var or add to ~/.config/sona-cli/config.toml", file=sys.stderr)
        sys.exit(1)

    base_url = _get("SONA_BASE_URL", "api", "base_url", "https://api.sonaveeb.ee")
    dataset = _get("SONA_DATASET", "api", "dataset", "sss")

    return Config(format=resolved_format, api_key=api_key, base_url=base_url, dataset=dataset)
```

**Step 4: Run tests to verify they pass**

```bash
uv run pytest tests/test_config.py -v
```
Expected: 5 passed.

**Step 5: Commit**

```bash
git add sona/config.py tests/test_config.py
git commit -m "feat: add config resolution (CLI > env > file > default)"
```

---

## Task 3: API Client

**Files:**
- Create: `sona/client.py`
- Create: `tests/test_client.py`

**Step 1: Write failing tests**

```python
# tests/test_client.py
import pytest
import respx
import httpx
from sona.client import EkilexClient, SearchResult, WordEntry, ParadigmTable, FormMatch


@pytest.fixture
def client():
    return EkilexClient(api_key="test-key", base_url="https://api.sonaveeb.ee", dataset="sss")


SEARCH_RESPONSE = {
    "words": [
        {"wordId": 10234, "wordValue": "tee", "homonymNr": 1, "lang": "et", "displayMorphCode": "s"},
        {"wordId": 10235, "wordValue": "tee", "homonymNr": 2, "lang": "et", "displayMorphCode": "s"},
        {"wordId": 10236, "wordValue": "tee", "homonymNr": 3, "lang": "et", "displayMorphCode": "v"},
    ]
}

DETAILS_RESPONSE = {
    "word": {"wordId": 10234, "wordValue": "maja", "homonymNr": 1, "displayMorphCode": "s", "genderCode": None},
    "lexemes": [
        {
            "lexemeId": 5001, "datasetCode": "sss",
            "pos": [{"code": "s", "value": "substantiiv"}],
            "grammars": [{"value": "22. tüüp"}],
            "usages": [
                {"value": "Maja on suur.", "lang": "et",
                 "translations": [{"value": "The house is big.", "lang": "en"}]}
            ],
            "meanings": [
                {"meaningId": 8001,
                 "definitions": [{"value": "Elamu, korterelamu.", "lang": "et"}]}
            ]
        }
    ],
    "firstDefinitionValue": "Elamu, korterelamu."
}

PARADIGM_RESPONSE = [
    {
        "wordClass": "noomen", "inflectionType": "22",
        "paradigmForms": [
            {"value": "maja", "morphCode": "sg n", "morphGroup1": "sg", "morphGroup2": "n"},
            {"value": "maja", "morphCode": "sg g", "morphGroup1": "sg", "morphGroup2": "g"},
            {"value": "maja", "morphCode": "sg p", "morphGroup1": "sg", "morphGroup2": "p"},
            {"value": "majja", "morphCode": "sg ill", "morphGroup1": "sg", "morphGroup2": "ill"},
            {"value": "majas", "morphCode": "sg in", "morphGroup1": "sg", "morphGroup2": "in"},
        ]
    }
]

FORM_RESPONSE = [
    {"wordId": 10234, "wordValue": "maja", "homonymNr": 1, "wordClass": "noomen", "morphCode": "sg in"}
]


@respx.mock
def test_search_returns_results(client):
    respx.get("https://api.sonaveeb.ee/api/word/search/tee").mock(
        return_value=httpx.Response(200, json=SEARCH_RESPONSE)
    )
    results = client.search("tee")
    assert len(results) == 3
    assert results[0].word_id == 10234
    assert results[0].word == "tee"
    assert results[0].homonym_nr == 1
    assert results[0].pos == "s"


@respx.mock
def test_lookup_returns_word_entry(client):
    respx.get("https://api.sonaveeb.ee/api/word/details/10234").mock(
        return_value=httpx.Response(200, json=DETAILS_RESPONSE)
    )
    entry = client.lookup(10234)
    assert entry.word_id == 10234
    assert entry.lemma == "maja"
    assert len(entry.definitions) == 1
    assert entry.definitions[0] == "Elamu, korterelamu."
    assert len(entry.examples) == 1
    assert entry.examples[0].text == "Maja on suur."
    assert entry.examples[0].translation == "The house is big."


@respx.mock
def test_paradigm_returns_table(client):
    respx.get("https://api.sonaveeb.ee/api/paradigm/details/10234").mock(
        return_value=httpx.Response(200, json=PARADIGM_RESPONSE)
    )
    table = client.paradigm(10234)
    assert table.word_class == "noomen"
    assert table.inflection_type == "22"
    assert table.forms["sg n"] == "maja"
    assert table.forms["sg ill"] == "majja"
    assert table.forms["sg in"] == "majas"


@respx.mock
def test_identify_returns_form_match(client):
    respx.get("https://api.sonaveeb.ee/api/form/search/majas").mock(
        return_value=httpx.Response(200, json=FORM_RESPONSE)
    )
    matches = client.identify("majas")
    assert len(matches) == 1
    assert matches[0].word_id == 10234
    assert matches[0].lemma == "maja"
    assert matches[0].morph_code == "sg in"


@respx.mock
def test_search_sends_api_key_header(client):
    route = respx.get("https://api.sonaveeb.ee/api/word/search/maja").mock(
        return_value=httpx.Response(200, json={"words": []})
    )
    client.search("maja")
    assert route.calls[0].request.headers["ekilex-api-key"] == "test-key"
```

**Step 2: Run tests to verify they fail**

```bash
uv run pytest tests/test_client.py -v
```
Expected: FAIL — `cannot import name 'EkilexClient'`

**Step 3: Implement client.py**

```python
# sona/client.py
from dataclasses import dataclass
import httpx


@dataclass
class SearchResult:
    word_id: int
    word: str
    homonym_nr: int
    pos: str


@dataclass
class Example:
    text: str
    translation: str | None


@dataclass
class WordEntry:
    word_id: int
    lemma: str
    homonym_nr: int
    pos: str
    grammar_notes: list[str]
    definitions: list[str]
    examples: list[Example]


@dataclass
class ParadigmTable:
    word_class: str
    inflection_type: str
    forms: dict[str, str]  # morphCode -> form value


@dataclass
class FormMatch:
    word_id: int
    lemma: str
    homonym_nr: int
    word_class: str
    morph_code: str


class EkilexClient:
    def __init__(self, api_key: str, base_url: str, dataset: str):
        self._base = base_url.rstrip("/")
        self._dataset = dataset
        self._headers = {"ekilex-api-key": api_key}

    def _get(self, path: str) -> dict | list:
        with httpx.Client() as http:
            response = http.get(f"{self._base}{path}", headers=self._headers, timeout=10.0)
            response.raise_for_status()
            return response.json()

    def search(self, word: str) -> list[SearchResult]:
        data = self._get(f"/api/word/search/{word}")
        words = data.get("words", [])
        return [
            SearchResult(
                word_id=w["wordId"],
                word=w["wordValue"],
                homonym_nr=w.get("homonymNr", 1),
                pos=w.get("displayMorphCode", ""),
            )
            for w in words
        ]

    def lookup(self, word_id: int) -> WordEntry:
        data = self._get(f"/api/word/details/{word_id}")
        word = data["word"]

        definitions: list[str] = []
        examples: list[Example] = []
        grammar_notes: list[str] = []
        pos = ""

        for lexeme in data.get("lexemes", []):
            if lexeme.get("datasetCode") != self._dataset:
                continue
            if not pos and lexeme.get("pos"):
                pos = lexeme["pos"][0].get("code", "")
            for g in lexeme.get("grammars", []):
                if v := g.get("value"):
                    grammar_notes.append(v)
            for meaning in lexeme.get("meanings", []):
                for defn in meaning.get("definitions", []):
                    if v := defn.get("value"):
                        definitions.append(v)
            for usage in lexeme.get("usages", []):
                text = usage.get("value", "")
                translation = None
                if usage.get("translations"):
                    translation = usage["translations"][0].get("value")
                if text:
                    examples.append(Example(text=text, translation=translation))

        # fallback: if dataset filter left us empty, take first lexeme
        if not definitions and data.get("firstDefinitionValue"):
            definitions = [data["firstDefinitionValue"]]

        return WordEntry(
            word_id=word["wordId"],
            lemma=word["wordValue"],
            homonym_nr=word.get("homonymNr", 1),
            pos=pos,
            grammar_notes=grammar_notes,
            definitions=definitions,
            examples=examples,
        )

    def paradigm(self, word_id: int) -> ParadigmTable:
        data = self._get(f"/api/paradigm/details/{word_id}")
        if not data:
            return ParadigmTable(word_class="", inflection_type="", forms={})
        entry = data[0]
        forms = {
            f["morphCode"]: f["value"]
            for f in entry.get("paradigmForms", [])
            if f.get("value")
        }
        return ParadigmTable(
            word_class=entry.get("wordClass", ""),
            inflection_type=entry.get("inflectionType", ""),
            forms=forms,
        )

    def identify(self, form: str) -> list[FormMatch]:
        data = self._get(f"/api/form/search/{form}")
        return [
            FormMatch(
                word_id=f["wordId"],
                lemma=f["wordValue"],
                homonym_nr=f.get("homonymNr", 1),
                word_class=f.get("wordClass", ""),
                morph_code=f.get("morphCode", ""),
            )
            for f in data
        ]
```

**Step 4: Run tests to verify they pass**

```bash
uv run pytest tests/test_client.py -v
```
Expected: 5 passed.

**Step 5: Commit**

```bash
git add sona/client.py tests/test_client.py
git commit -m "feat: add ekilex API client with response filtering"
```

---

## Task 4: Formatters

**Files:**
- Create: `sona/formatters.py`
- Create: `tests/test_formatters.py`

### Morphological code label map

The ekilex `morphCode` values use abbreviated Estonian grammar codes. The formatter needs a label map:

```python
MORPH_LABELS = {
    "sg n": "Nominative sg", "pl n": "Nominative pl",
    "sg g": "Genitive sg",   "pl g": "Genitive pl",
    "sg p": "Partitive sg",  "pl p": "Partitive pl",
    "sg ill": "Illative sg", "pl ill": "Illative pl",
    "sg in": "Inessive sg",  "pl in": "Inessive pl",
    "sg el": "Elative sg",   "pl el": "Elative pl",
    "sg all": "Allative sg", "pl all": "Allative pl",
    "sg ad": "Adessive sg",  "pl ad": "Adessive pl",
    "sg abl": "Ablative sg", "pl abl": "Ablative pl",
    "sg tr": "Translative sg","pl tr": "Translative pl",
    "sg ter": "Terminative sg","pl ter": "Terminative pl",
    "sg es": "Essive sg",    "pl es": "Essive pl",
    "sg ab": "Abessive sg",  "pl ab": "Abessive pl",
    "sg kom": "Comitative sg","pl kom": "Comitative pl",
    # Verbs
    "ma": "ma-infinitive", "da": "da-infinitive",
    "b": "3sg present", "vad": "3pl present",
    "sin": "1sg present", "sid": "2sg present",
    "me": "1pl present", "te": "2pl present",
    "s": "3sg imperfect", "id": "2sg imperfect",
    "ks": "conditional", "takse": "passive present",
    "ti": "passive imperfect", "tud": "past passive participle",
    "nud": "past active participle", "v": "present participle",
}
```

**Step 1: Write failing tests**

```python
# tests/test_formatters.py
from sona.client import SearchResult, WordEntry, Example, ParadigmTable, FormMatch
from sona.formatters import format_search, format_lookup, format_paradigm, format_identify
from sona.config import OutputFormat


SEARCH_RESULTS = [
    SearchResult(word_id=10234, word="tee", homonym_nr=1, pos="s"),
    SearchResult(word_id=10235, word="tee", homonym_nr=2, pos="s"),
    SearchResult(word_id=10236, word="tee", homonym_nr=3, pos="v"),
]

WORD_ENTRY = WordEntry(
    word_id=10234, lemma="maja", homonym_nr=1, pos="s",
    grammar_notes=["22. tüüp"],
    definitions=["Elamu, korterelamu."],
    examples=[Example(text="Maja on suur.", translation="The house is big.")]
)

PARADIGM = ParadigmTable(
    word_class="noomen", inflection_type="22",
    forms={"sg n": "maja", "sg g": "maja", "sg p": "maja", "sg ill": "majja", "sg in": "majas"}
)

FORM_MATCHES = [
    FormMatch(word_id=10234, lemma="maja", homonym_nr=1, word_class="noomen", morph_code="sg in")
]


def test_format_search_markdown_contains_word_ids():
    output = format_search(SEARCH_RESULTS, OutputFormat.MARKDOWN, query="tee")
    assert "10234" in output
    assert "10235" in output
    assert "10236" in output
    assert "tee" in output


def test_format_search_markdown_contains_table():
    output = format_search(SEARCH_RESULTS, OutputFormat.MARKDOWN, query="tee")
    assert "|" in output  # markdown table


def test_format_lookup_markdown_contains_definition():
    output = format_lookup(WORD_ENTRY, OutputFormat.MARKDOWN)
    assert "Elamu, korterelamu." in output
    assert "10234" in output
    assert "maja" in output


def test_format_lookup_markdown_contains_example():
    output = format_lookup(WORD_ENTRY, OutputFormat.MARKDOWN)
    assert "Maja on suur." in output
    assert "The house is big." in output


def test_format_paradigm_markdown_contains_forms():
    output = format_paradigm(PARADIGM, OutputFormat.MARKDOWN, lemma="maja")
    assert "maja" in output
    assert "majja" in output
    assert "majas" in output
    assert "22" in output


def test_format_identify_markdown_contains_lemma_and_morph():
    output = format_identify(FORM_MATCHES, OutputFormat.MARKDOWN, form="majas")
    assert "maja" in output
    assert "10234" in output
    assert "sg in" in output or "Inessive" in output


def test_format_search_pretty_returns_string():
    # pretty mode uses Rich — just verify it returns a non-empty string
    output = format_search(SEARCH_RESULTS, OutputFormat.PRETTY, query="tee")
    assert isinstance(output, str)
    assert len(output) > 0
```

**Step 2: Run tests to verify they fail**

```bash
uv run pytest tests/test_formatters.py -v
```
Expected: FAIL — `cannot import name 'format_search'`

**Step 3: Implement formatters.py**

```python
# sona/formatters.py
import io
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich import box

from sona.client import SearchResult, WordEntry, ParadigmTable, FormMatch
from sona.config import OutputFormat

MORPH_LABELS: dict[str, str] = {
    "sg n": "Nominative sg",   "pl n": "Nominative pl",
    "sg g": "Genitive sg",     "pl g": "Genitive pl",
    "sg p": "Partitive sg",    "pl p": "Partitive pl",
    "sg ill": "Illative sg",   "pl ill": "Illative pl",
    "sg in": "Inessive sg",    "pl in": "Inessive pl",
    "sg el": "Elative sg",     "pl el": "Elative pl",
    "sg all": "Allative sg",   "pl all": "Allative pl",
    "sg ad": "Adessive sg",    "pl ad": "Adessive pl",
    "sg abl": "Ablative sg",   "pl abl": "Ablative pl",
    "sg tr": "Translative sg", "pl tr": "Translative pl",
    "sg ter": "Terminative sg","pl ter": "Terminative pl",
    "sg es": "Essive sg",      "pl es": "Essive pl",
    "sg ab": "Abessive sg",    "pl ab": "Abessive pl",
    "sg kom": "Comitative sg", "pl kom": "Comitative pl",
    "ma": "ma-infinitive",     "da": "da-infinitive",
    "b": "3sg present",        "vad": "3pl present",
    "sin": "1sg present",      "sid": "2sg present",
    "me": "1pl present",       "te": "2pl present",
    "s": "3sg imperfect",      "id": "2sg imperfect",
    "ks": "conditional",       "takse": "passive present",
    "ti": "passive imperfect", "tud": "past passive participle",
    "nud": "past active participle", "v": "present participle",
}


def _rich_to_str(renderable) -> str:
    buf = io.StringIO()
    console = Console(file=buf, highlight=False, markup=True)
    console.print(renderable)
    return buf.getvalue()


# --- Search ---

def format_search(results: list[SearchResult], fmt: OutputFormat, query: str) -> str:
    if fmt == OutputFormat.MARKDOWN:
        return _search_markdown(results, query)
    return _search_pretty(results, query)


def _search_markdown(results: list[SearchResult], query: str) -> str:
    if not results:
        return f"# No results for \"{query}\"\n"
    lines = [f'# Search results: "{query}"\n',
             "| wordId | Word | # | POS | Gloss |",
             "|--------|------|---|-----|-------|"]
    for r in results:
        lines.append(f"| {r.word_id} | {r.word} | {r.homonym_nr} | {r.pos} | — |")
    lines.append(f"\n*Use `sona lookup <wordId>` for full details.*\n")
    return "\n".join(lines)


def _search_pretty(results: list[SearchResult], query: str) -> str:
    if not results:
        return _rich_to_str(Panel(f'No results for "{query}"', border_style="red"))
    table = Table(title=f'Search: "{query}"', box=box.ROUNDED, show_header=True, header_style="bold cyan")
    table.add_column("wordId", style="dim")
    table.add_column("Word", style="bold")
    table.add_column("#", justify="center")
    table.add_column("POS")
    for r in results:
        table.add_row(str(r.word_id), r.word, str(r.homonym_nr), r.pos)
    return _rich_to_str(table)


# --- Lookup ---

def format_lookup(entry: WordEntry, fmt: OutputFormat) -> str:
    if fmt == OutputFormat.MARKDOWN:
        return _lookup_markdown(entry)
    return _lookup_pretty(entry)


def _lookup_markdown(entry: WordEntry) -> str:
    lines = [f"# {entry.lemma} *(wordId: {entry.word_id}, #{entry.homonym_nr})*\n"]
    if entry.pos:
        lines.append(f"**POS:** {entry.pos}")
    if entry.grammar_notes:
        lines.append(f"**Grammar:** {'; '.join(entry.grammar_notes)}")
    if entry.definitions:
        lines.append("\n## Definitions")
        for i, d in enumerate(entry.definitions, 1):
            lines.append(f"{i}. {d}")
    if entry.examples:
        lines.append("\n## Examples")
        for ex in entry.examples:
            line = f"- *{ex.text}*"
            if ex.translation:
                line += f" — {ex.translation}"
            lines.append(line)
    lines.append(f"\n*Use `sona paradigm {entry.word_id}` for the inflection table.*\n")
    return "\n".join(lines)


def _lookup_pretty(entry: WordEntry) -> str:
    content_lines = []
    if entry.pos:
        content_lines.append(f"[bold]POS:[/bold] {entry.pos}")
    if entry.grammar_notes:
        content_lines.append(f"[bold]Grammar:[/bold] {'; '.join(entry.grammar_notes)}")
    if entry.definitions:
        content_lines.append("\n[bold cyan]Definitions:[/bold cyan]")
        for i, d in enumerate(entry.definitions, 1):
            content_lines.append(f"  {i}. {d}")
    if entry.examples:
        content_lines.append("\n[bold cyan]Examples:[/bold cyan]")
        for ex in entry.examples:
            line = f"  [italic]{ex.text}[/italic]"
            if ex.translation:
                line += f" — {ex.translation}"
            content_lines.append(line)
    title = f"[bold]{entry.lemma}[/bold] [dim](wordId: {entry.word_id}, #{entry.homonym_nr})[/dim]"
    return _rich_to_str(Panel("\n".join(content_lines), title=title, border_style="blue"))


# --- Paradigm ---

def format_paradigm(table: ParadigmTable, fmt: OutputFormat, lemma: str = "") -> str:
    if fmt == OutputFormat.MARKDOWN:
        return _paradigm_markdown(table, lemma)
    return _paradigm_pretty(table, lemma)


def _paradigm_markdown(table: ParadigmTable, lemma: str) -> str:
    header = lemma or "word"
    lines = [f"# {header} — {table.word_class} (inflection type {table.inflection_type})\n",
             "| Form | Value |",
             "|------|-------|"]
    for code, value in table.forms.items():
        label = MORPH_LABELS.get(code, code)
        lines.append(f"| {label} | **{value}** |")
    return "\n".join(lines) + "\n"


def _paradigm_pretty(table: ParadigmTable, lemma: str) -> str:
    header = lemma or "word"
    t = Table(
        title=f"{header} — {table.word_class} (type {table.inflection_type})",
        box=box.SIMPLE_HEAD, show_header=True, header_style="bold magenta"
    )
    t.add_column("Form", style="cyan")
    t.add_column("Value", style="bold")
    for code, value in table.forms.items():
        label = MORPH_LABELS.get(code, code)
        t.add_row(label, value)
    return _rich_to_str(t)


# --- Identify ---

def format_identify(matches: list[FormMatch], fmt: OutputFormat, form: str) -> str:
    if fmt == OutputFormat.MARKDOWN:
        return _identify_markdown(matches, form)
    return _identify_pretty(matches, form)


def _identify_markdown(matches: list[FormMatch], form: str) -> str:
    if not matches:
        return f"# No matches for form \"{form}\"\n"
    lines = [f'# Form: "{form}"\n']
    for m in matches:
        label = MORPH_LABELS.get(m.morph_code, m.morph_code)
        lines.append(f"- **{m.lemma}** (wordId: {m.word_id}, #{m.homonym_nr}) — {m.word_class}")
        lines.append(f"  Form: `{m.morph_code}` ({label})")
    return "\n".join(lines) + "\n"


def _identify_pretty(matches: list[FormMatch], form: str) -> str:
    if not matches:
        return _rich_to_str(Panel(f'No matches for "{form}"', border_style="red"))
    lines = []
    for m in matches:
        label = MORPH_LABELS.get(m.morph_code, m.morph_code)
        lines.append(
            f"[bold]{m.lemma}[/bold] [dim](wordId: {m.word_id}, #{m.homonym_nr})[/dim] "
            f"[cyan]{m.word_class}[/cyan] — [yellow]{m.morph_code}[/yellow] ({label})"
        )
    return _rich_to_str(Panel("\n".join(lines), title=f'Form: "{form}"', border_style="green"))
```

**Step 4: Run tests to verify they pass**

```bash
uv run pytest tests/test_formatters.py -v
```
Expected: 7 passed.

**Step 5: Commit**

```bash
git add sona/formatters.py tests/test_formatters.py
git commit -m "feat: add markdown and pretty formatters for all 4 commands"
```

---

## Task 5: CLI Commands (main.py)

**Files:**
- Modify: `sona/main.py`
- Create: `tests/test_main.py`

**Step 1: Write failing tests**

```python
# tests/test_main.py
import respx
import httpx
import pytest
from typer.testing import CliRunner
from unittest.mock import patch
from sona.main import app

runner = CliRunner()

SEARCH_RESPONSE = {
    "words": [{"wordId": 10234, "wordValue": "maja", "homonymNr": 1, "lang": "et", "displayMorphCode": "s"}]
}
DETAILS_RESPONSE = {
    "word": {"wordId": 10234, "wordValue": "maja", "homonymNr": 1, "displayMorphCode": "s"},
    "lexemes": [
        {
            "lexemeId": 5001, "datasetCode": "sss",
            "pos": [{"code": "s", "value": "noun"}],
            "grammars": [],
            "usages": [],
            "meanings": [{"meaningId": 8001, "definitions": [{"value": "Elamu.", "lang": "et"}]}]
        }
    ],
    "firstDefinitionValue": "Elamu."
}
PARADIGM_RESPONSE = [
    {"wordClass": "noomen", "inflectionType": "22",
     "paradigmForms": [{"value": "maja", "morphCode": "sg n"}, {"value": "majja", "morphCode": "sg ill"}]}
]
FORM_RESPONSE = [
    {"wordId": 10234, "wordValue": "maja", "homonymNr": 1, "wordClass": "noomen", "morphCode": "sg in"}
]


@pytest.fixture(autouse=True)
def mock_config(monkeypatch):
    monkeypatch.setenv("SONA_API_KEY", "test-key")
    monkeypatch.setenv("SONA_BASE_URL", "https://api.sonaveeb.ee")
    monkeypatch.setenv("SONA_DATASET", "sss")


@respx.mock
def test_search_command_outputs_word_id():
    respx.get("https://api.sonaveeb.ee/api/word/search/maja").mock(
        return_value=httpx.Response(200, json=SEARCH_RESPONSE)
    )
    result = runner.invoke(app, ["search", "maja"])
    assert result.exit_code == 0
    assert "10234" in result.output


@respx.mock
def test_lookup_command_outputs_definition():
    respx.get("https://api.sonaveeb.ee/api/word/details/10234").mock(
        return_value=httpx.Response(200, json=DETAILS_RESPONSE)
    )
    result = runner.invoke(app, ["lookup", "10234"])
    assert result.exit_code == 0
    assert "Elamu" in result.output


@respx.mock
def test_paradigm_command_outputs_forms():
    respx.get("https://api.sonaveeb.ee/api/paradigm/details/10234").mock(
        return_value=httpx.Response(200, json=PARADIGM_RESPONSE)
    )
    result = runner.invoke(app, ["paradigm", "10234"])
    assert result.exit_code == 0
    assert "majja" in result.output


@respx.mock
def test_identify_command_outputs_lemma():
    respx.get("https://api.sonaveeb.ee/api/form/search/majas").mock(
        return_value=httpx.Response(200, json=FORM_RESPONSE)
    )
    result = runner.invoke(app, ["identify", "majas"])
    assert result.exit_code == 0
    assert "maja" in result.output


@respx.mock
def test_format_flag_overrides_default():
    respx.get("https://api.sonaveeb.ee/api/word/search/maja").mock(
        return_value=httpx.Response(200, json=SEARCH_RESPONSE)
    )
    # pretty mode should still output maja
    result = runner.invoke(app, ["--format", "pretty", "search", "maja"])
    assert result.exit_code == 0
    assert "maja" in result.output
```

**Step 2: Run tests to verify they fail**

```bash
uv run pytest tests/test_main.py -v
```
Expected: FAIL — commands not yet defined.

**Step 3: Implement main.py**

```python
# sona/main.py
from typing import Optional
import typer
import sys

from sona.config import resolve_config, OutputFormat
from sona.client import EkilexClient
from sona.formatters import format_search, format_lookup, format_paradigm, format_identify

app = typer.Typer(
    name="sona",
    help="Estonian word lookup CLI. Wraps the sonaveeb.ee ekilex API.",
    rich_markup_mode="markdown",
    no_args_is_help=True,
)

FormatOption = Optional[OutputFormat]


def _client_and_format(fmt: FormatOption) -> tuple[EkilexClient, OutputFormat]:
    cfg = resolve_config(cli_format=fmt)
    client = EkilexClient(api_key=cfg.api_key, base_url=cfg.base_url, dataset=cfg.dataset)
    return client, cfg.format


@app.command()
def search(
    word: str = typer.Argument(..., help="Estonian word to search for"),
    format: FormatOption = typer.Option(None, "--format", "-f", help="Output format: markdown or pretty"),
):
    """Search for a word and list all homonyms with their wordIds."""
    client, fmt = _client_and_format(format)
    results = client.search(word)
    typer.echo(format_search(results, fmt, query=word), nl=False)


@app.command()
def lookup(
    word_id: int = typer.Argument(..., help="wordId from `sona search`"),
    format: FormatOption = typer.Option(None, "--format", "-f", help="Output format: markdown or pretty"),
):
    """Get full definition, examples, and grammar notes for a word by wordId."""
    client, fmt = _client_and_format(format)
    entry = client.lookup(word_id)
    typer.echo(format_lookup(entry, fmt), nl=False)


@app.command()
def paradigm(
    word_id: int = typer.Argument(..., help="wordId from `sona search`"),
    format: FormatOption = typer.Option(None, "--format", "-f", help="Output format: markdown or pretty"),
):
    """Show the full declension or conjugation table for a word by wordId."""
    client, fmt = _client_and_format(format)
    entry = client.lookup(word_id)  # need lemma for table header
    table = client.paradigm(word_id)
    typer.echo(format_paradigm(table, fmt, lemma=entry.lemma), nl=False)
```

Wait — `paradigm` calls `lookup` to get the lemma for the table header, which costs an extra API call. To avoid this, accept an optional `--lemma` flag:

```python
@app.command()
def paradigm(
    word_id: int = typer.Argument(..., help="wordId from `sona search`"),
    lemma: str = typer.Option("", "--lemma", "-l", help="Word lemma for display (optional)"),
    format: FormatOption = typer.Option(None, "--format", "-f", help="Output format: markdown or pretty"),
):
    """Show the full declension or conjugation table for a word by wordId."""
    client, fmt = _client_and_format(format)
    table = client.paradigm(word_id)
    typer.echo(format_paradigm(table, fmt, lemma=lemma), nl=False)


@app.command()
def identify(
    form: str = typer.Argument(..., help="Inflected form to identify (e.g. 'majas')"),
    format: FormatOption = typer.Option(None, "--format", "-f", help="Output format: markdown or pretty"),
):
    """Identify an inflected form — returns base lemma, wordId, and case/form label."""
    client, fmt = _client_and_format(format)
    matches = client.identify(form)
    typer.echo(format_identify(matches, fmt, form=form), nl=False)


if __name__ == "__main__":
    app()
```

Update `test_main.py` — the `paradigm` test no longer needs a details mock (remove `DETAILS_RESPONSE` usage from that test).

**Step 4: Run tests to verify they pass**

```bash
uv run pytest tests/test_main.py -v
```
Expected: 5 passed.

**Step 5: Run full test suite**

```bash
uv run pytest -v
```
Expected: all tests pass.

**Step 6: Smoke test manually**

```bash
SONA_API_KEY=your_key uv run sona --help
SONA_API_KEY=your_key uv run sona search tee
```

**Step 7: Commit**

```bash
git add sona/main.py tests/test_main.py
git commit -m "feat: add all 4 CLI commands (search, lookup, paradigm, identify)"
```

---

## Task 6: Claude Code Skill

**Files:**
- Create: `skill.md`

No tests — this is documentation.

**Step 1: Write skill.md**

```markdown
---
name: sona
description: >
  Look up Estonian words using the sonaveeb.ee dictionary. Use when teaching
  Estonian vocabulary, grammar, or when a student produces a word form you need
  to verify or identify. NEVER recite Estonian inflection paradigms from memory
  — always call sona paradigm to verify.
---

## When to use

- Student asks what a word means → `sona search` then `sona lookup`
- You need to show a declension table or conjugation table → `sona paradigm`
- Student produces an inflected form you need to parse → `sona identify`
- You need to verify case forms before teaching them → `sona paradigm`

## Workflow

### Looking up a word

Always two steps — never assume there is only one match:

```bash
sona search <word>
```

This returns a table of all homonyms with their `wordId`. Pick the correct one
based on context (student's sentence, topic, prior conversation). Then:

```bash
sona lookup <wordId>
```

### Getting the inflection table

```bash
sona paradigm <wordId>
```

Use this for nouns (all 14 cases × singular/plural), verbs (all conjugated
forms), and adjectives. Never present a paradigm from memory — always call this.

### Identifying an inflected form

When the student writes a form like *majas*, *jooksid*, or *tehtud*:

```bash
sona identify <form>
```

This returns the base lemma, wordId, and the morphological label so you can
explain exactly what form it is.

## Caching wordIds

Within a session, cache `wordId`s you have already resolved. If you looked up
*maja* and got `wordId: 10234`, use `sona paradigm 10234` directly — do not
re-run `sona search maja`.

## Output format

Default output is markdown. You do not need to pass `--format` in normal use.
For human-readable terminal output, use `--format pretty`.

## Error handling

If `sona search` returns no results, try:
1. The base/dictionary form (infinitive for verbs, nominative singular for nouns)
2. `sona identify <form>` to find the base form first

## Setup (for users)

1. Install: `uv tool install .` (from this repo) or `pip install .`
2. Configure API key (one of):
   - `export SONA_API_KEY=your_key`
   - Add to `~/.config/sona-cli/config.toml` under `[api] key = "..."`
3. Copy this skill: `cp skill.md ~/.claude/skills/sona.md`
```

**Step 2: Commit**

```bash
git add skill.md
git commit -m "docs: add Claude Code skill for Estonian language teaching"
```

---

## Task 7: README and install script

**Files:**
- Create: `README.md`
- Create: `install-skill.sh`

**Step 1: Write README.md**

````markdown
# sona-cli

Estonian word lookup CLI for AI-driven language teaching. Wraps the
[sonaveeb.ee](https://sonaveeb.ee) (ekilex) dictionary API.

Ships with a Claude Code skill so your AI language tutor can look up words,
paradigms, and identify inflected forms — without relying on its own memory.

## Commands

| Command | Description |
|---|---|
| `sona search <word>` | Find all homonyms with wordIds |
| `sona lookup <wordId>` | Full definition and examples |
| `sona paradigm <wordId>` | Complete declension/conjugation table |
| `sona identify <form>` | Identify an inflected form |

## Install

Requires Python 3.11+ and [uv](https://docs.astral.sh/uv/).

```bash
git clone https://github.com/yourname/sona-cli
cd sona-cli
uv tool install .
```

Or with pip:
```bash
pip install .
```

## Configure

Get an API key from [sonaveeb.ee](https://sonaveeb.ee).

**Option 1 — env var (recommended for development):**
```bash
export SONA_API_KEY=your_key_here
```

**Option 2 — config file:**
```bash
mkdir -p ~/.config/sona-cli
cat > ~/.config/sona-cli/config.toml << EOF
[api]
key = "your_key_here"

[output]
format = "markdown"   # or "pretty"
EOF
```

## Claude Code skill

Copy the included skill file to activate AI-assisted Estonian teaching:
```bash
cp skill.md ~/.claude/skills/sona.md
# or:
./install-skill.sh
```

The skill teaches Claude Code when and how to call `sona` during language
lessons — always verifying paradigms from the dictionary rather than memory.

## Output format

Default is `markdown` (optimised for AI context). Use `--format pretty` or
`SONA_FORMAT=pretty` for human-readable terminal output.

```bash
sona --format pretty search tee
sona search tee          # markdown (default)
```

## Examples

```bash
sona search tee
# → table of all "tee" homonyms with wordIds

sona lookup 10234
# → definition, examples, grammar notes

sona paradigm 10234
# → full 14-case declension table

sona identify majas
# → maja (sg in — Inessive singular)
```
````

**Step 2: Write install-skill.sh**

```bash
#!/usr/bin/env bash
set -e
SKILL_DIR="$HOME/.claude/skills"
mkdir -p "$SKILL_DIR"
cp "$(dirname "$0")/skill.md" "$SKILL_DIR/sona.md"
echo "Skill installed to $SKILL_DIR/sona.md"
```

```bash
chmod +x install-skill.sh
```

**Step 3: Commit**

```bash
git add README.md install-skill.sh
git commit -m "docs: add README and install-skill.sh"
```

---

## Task 8: Final verification

**Step 1: Run full test suite**

```bash
uv run pytest -v
```
Expected: all tests pass, no warnings.

**Step 2: Verify CLI help**

```bash
uv run sona --help
uv run sona search --help
uv run sona lookup --help
uv run sona paradigm --help
uv run sona identify --help
```

**Step 3: Live smoke test** (requires real API key)

```bash
export SONA_API_KEY=your_real_key
sona search tee
sona lookup <first_wordId_from_above>
sona paradigm <wordId>
sona identify majas
sona --format pretty search maja
```

**Step 4: Tag v0.1.0**

```bash
git tag v0.1.0
```
