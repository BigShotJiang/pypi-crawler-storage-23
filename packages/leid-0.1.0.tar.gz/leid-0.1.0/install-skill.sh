#!/usr/bin/env bash
set -e
SKILL_DIR="$HOME/.claude/skills"
mkdir -p "$SKILL_DIR"
cp "$(dirname "$0")/skill.md" "$SKILL_DIR/sona.md"
echo "Skill installed to $SKILL_DIR/sona.md"
