import io
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich import box

from leid.client import SearchResult, WordEntry, ParadigmTable, FormMatch
from leid.config import OutputFormat

# Actual ekilex morphCode values (CamelCase)
MORPH_LABELS: dict[str, str] = {
    # Nouns — singular
    "SgN": "Nominative sg",       "SgG": "Genitive sg",
    "SgP": "Partitive sg",        "SgAdt": "Short illative sg",
    "SgIll": "Illative sg",       "SgIn": "Inessive sg",
    "SgEl": "Elative sg",         "SgAll": "Allative sg",
    "SgAd": "Adessive sg",        "SgAbl": "Ablative sg",
    "SgTr": "Translative sg",     "SgTer": "Terminative sg",
    "SgEs": "Essive sg",          "SgAb": "Abessive sg",
    "SgKom": "Comitative sg",
    # Nouns — plural
    "PlN": "Nominative pl",       "PlG": "Genitive pl",
    "PlP": "Partitive pl",        "PlIll": "Illative pl",
    "PlIn": "Inessive pl",        "PlEl": "Elative pl",
    "PlAll": "Allative pl",       "PlAd": "Adessive pl",
    "PlAbl": "Ablative pl",       "PlTr": "Translative pl",
    "PlTer": "Terminative pl",    "PlEs": "Essive pl",
    "PlAb": "Abessive pl",        "PlKom": "Comitative pl",
    # Verb — infinitives & verbal nouns
    "Sup": "ma-infinitive",       "Inf": "da-infinitive",
    "SupIps": "passive ma-infinitive",
    "SupIn": "ma-inessive",       "SupEl": "ma-elative",
    "SupAb": "ma-abessive",       "SupTr": "ma-translative",
    "Ger": "des-form (gerund)",
    # Verb — indicative present
    "IndPrSg1": "1sg present",    "IndPrSg2": "2sg present",
    "IndPrSg3": "3sg present",    "IndPrPl1": "1pl present",
    "IndPrPl2": "2pl present",    "IndPrPl3": "3pl present",
    "IndPrPs_": "present neg. stem",
    "IndPrIps": "impersonal present",
    "IndPrIps_": "impersonal present neg.",
    # Verb — indicative past
    "IndIpfSg1": "1sg past",      "IndIpfSg2": "2sg past",
    "IndIpfSg3": "3sg past",      "IndIpfPl1": "1pl past",
    "IndIpfPl2": "2pl past",      "IndIpfPl3": "3pl past",
    "IndIpfIps": "impersonal past",
    # Verb — imperative
    "ImpPrSg2": "2sg imperative", "ImpPrPl1": "1pl imperative",
    "ImpPrPl2": "2pl imperative", "ImpPrPs": "personal imperative",
    "ImpPrIps": "impersonal imperative",
    # Verb — conditional present
    "KndPrSg1": "1sg conditional",  "KndPrSg2": "2sg conditional",
    "KndPrPl1": "1pl conditional",  "KndPrPl2": "2pl conditional",
    "KndPrPl3": "3pl conditional",  "KndPrPs": "conditional personal",
    "KndPrIps": "conditional impersonal",
    # Verb — conditional past
    "KndPtSg1": "1sg past cond.",   "KndPtSg2": "2sg past cond.",
    "KndPtPl1": "1pl past cond.",   "KndPtPl2": "2pl past cond.",
    "KndPtPl3": "3pl past cond.",   "KndPtPs": "past cond. personal",
    "KndPtIps": "past cond. impersonal",
    # Verb — quotative
    "KvtPrPs": "quotative pres. active",  "KvtPrIps": "quotative pres. passive",
    "KvtPtPs": "quotative past active",   "KvtPtIps": "quotative past passive",
    # Verb — participles
    "PtsPrPs": "present active participle",
    "PtsPrIps": "present passive participle",
    "PtsPtPs": "past active participle",
    "PtsPtPsNeg": "past active participle (neg.)",
    "PtsPtIps": "past passive participle",
    "PtsPtIpsNeg": "past passive participle (neg.)",
}


def _rich_to_str(renderable) -> str:
    buf = io.StringIO()
    console = Console(file=buf, highlight=False, markup=True)
    console.print(renderable)
    return buf.getvalue()


# --- Search ---

def format_search(results: list[SearchResult], fmt: OutputFormat, query: str) -> str:
    if fmt == OutputFormat.MARKDOWN:
        return _search_markdown(results, query)
    return _search_pretty(results, query)


def _search_markdown(results: list[SearchResult], query: str) -> str:
    if not results:
        return f'# No results for "{query}"\n'
    lines = [f'# Search results: "{query}"\n',
             "| wordId | Word | # | Datasets |",
             "|--------|------|---|----------|"]
    for r in results:
        datasets = ", ".join(r.datasets)
        lines.append(f"| {r.word_id} | {r.word} | {r.homonym_nr} | {datasets} |")
    lines.append(f"\n*Use `leid lookup <wordId>` for full details.*\n")
    return "\n".join(lines)


def _search_pretty(results: list[SearchResult], query: str) -> str:
    if not results:
        return _rich_to_str(Panel(f'No results for "{query}"', border_style="red"))
    table = Table(title=f'Search: "{query}"', box=box.ROUNDED, show_header=True, header_style="bold cyan")
    table.add_column("wordId", style="dim")
    table.add_column("Word", style="bold")
    table.add_column("#", justify="center")
    table.add_column("Datasets", style="dim")
    for r in results:
        table.add_row(str(r.word_id), r.word, str(r.homonym_nr), ", ".join(r.datasets))
    return _rich_to_str(table)


# --- Lookup ---

def format_lookup(entry: WordEntry, fmt: OutputFormat) -> str:
    if fmt == OutputFormat.MARKDOWN:
        return _lookup_markdown(entry)
    return _lookup_pretty(entry)


def _lookup_markdown(entry: WordEntry) -> str:
    lines = [f"# {entry.lemma} *(wordId: {entry.word_id}, #{entry.homonym_nr})*\n"]
    if entry.pos:
        lines.append(f"**POS:** {entry.pos}")
    if entry.grammar_notes:
        lines.append(f"**Grammar:** {'; '.join(entry.grammar_notes)}")
    if entry.definitions:
        lines.append("\n## Definitions")
        for i, d in enumerate(entry.definitions, 1):
            lines.append(f"{i}. {d}")
    if entry.examples:
        lines.append("\n## Examples")
        for ex in entry.examples:
            line = f"- *{ex.text}*"
            if ex.translation:
                line += f" — {ex.translation}"
            lines.append(line)
    lines.append(f"\n*Use `leid paradigm {entry.word_id}` for the inflection table.*\n")
    return "\n".join(lines)


def _lookup_pretty(entry: WordEntry) -> str:
    content_lines = []
    if entry.pos:
        content_lines.append(f"[bold]POS:[/bold] {entry.pos}")
    if entry.grammar_notes:
        content_lines.append(f"[bold]Grammar:[/bold] {'; '.join(entry.grammar_notes)}")
    if entry.definitions:
        content_lines.append("\n[bold cyan]Definitions:[/bold cyan]")
        for i, d in enumerate(entry.definitions, 1):
            content_lines.append(f"  {i}. {d}")
    if entry.examples:
        content_lines.append("\n[bold cyan]Examples:[/bold cyan]")
        for ex in entry.examples:
            line = f"  [italic]{ex.text}[/italic]"
            if ex.translation:
                line += f" — {ex.translation}"
            content_lines.append(line)
    title = f"[bold]{entry.lemma}[/bold] [dim](wordId: {entry.word_id}, #{entry.homonym_nr})[/dim]"
    return _rich_to_str(Panel("\n".join(content_lines), title=title, border_style="blue"))


# --- Paradigm ---

def format_paradigm(table: ParadigmTable, fmt: OutputFormat, lemma: str = "") -> str:
    if fmt == OutputFormat.MARKDOWN:
        return _paradigm_markdown(table, lemma)
    return _paradigm_pretty(table, lemma)


def _paradigm_markdown(table: ParadigmTable, lemma: str) -> str:
    header = lemma or "word"
    lines = [f"# {header} — {table.word_class} (inflection type {table.inflection_type})\n",
             "| Form | Value |",
             "|------|-------|"]
    for code, value in table.forms.items():
        label = MORPH_LABELS.get(code, code)
        lines.append(f"| {label} | **{value}** |")
    return "\n".join(lines) + "\n"


def _paradigm_pretty(table: ParadigmTable, lemma: str) -> str:
    header = lemma or "word"
    t = Table(
        title=f"{header} — {table.word_class} (type {table.inflection_type})",
        box=box.SIMPLE_HEAD, show_header=True, header_style="bold magenta"
    )
    t.add_column("Form", style="cyan")
    t.add_column("Value", style="bold")
    for code, value in table.forms.items():
        label = MORPH_LABELS.get(code, code)
        t.add_row(label, value)
    return _rich_to_str(t)


# --- Identify ---

def format_identify(matches: list[FormMatch], fmt: OutputFormat, form: str) -> str:
    if fmt == OutputFormat.MARKDOWN:
        return _identify_markdown(matches, form)
    return _identify_pretty(matches, form)


def _identify_markdown(matches: list[FormMatch], form: str) -> str:
    if not matches:
        return f'# No matches for form "{form}"\n'
    lines = [f'# Form: "{form}"\n']
    for m in matches:
        if m.morph_codes:
            labels = ", ".join(
                f"`{c}` ({MORPH_LABELS.get(c, c)})" for c in m.morph_codes
            )
        else:
            labels = "—"
        lines.append(f"- **{m.lemma}** (wordId: {m.word_id}, #{m.homonym_nr}) — {labels}")
    return "\n".join(lines) + "\n"


def _identify_pretty(matches: list[FormMatch], form: str) -> str:
    if not matches:
        return _rich_to_str(Panel(f'No matches for "{form}"', border_style="red"))
    lines = []
    for m in matches:
        if m.morph_codes:
            labels = ", ".join(
                f"[yellow]{c}[/yellow] ({MORPH_LABELS.get(c, c)})" for c in m.morph_codes
            )
        else:
            labels = "—"
        lines.append(
            f"[bold]{m.lemma}[/bold] [dim](wordId: {m.word_id}, #{m.homonym_nr})[/dim] — {labels}"
        )
    return _rich_to_str(Panel("\n".join(lines), title=f'Form: "{form}"', border_style="green"))
