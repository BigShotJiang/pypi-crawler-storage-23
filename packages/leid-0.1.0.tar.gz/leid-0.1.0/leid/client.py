from dataclasses import dataclass
import httpx


@dataclass
class SearchResult:
    word_id: int
    word: str
    homonym_nr: int
    datasets: list[str]


@dataclass
class Example:
    text: str
    translation: str | None


@dataclass
class WordEntry:
    word_id: int
    lemma: str
    homonym_nr: int
    pos: str
    grammar_notes: list[str]
    definitions: list[str]
    examples: list[Example]


@dataclass
class ParadigmTable:
    word_class: str
    inflection_type: str
    forms: dict[str, str]  # morphCode -> form value


@dataclass
class FormMatch:
    word_id: int
    lemma: str
    homonym_nr: int
    morph_codes: list[str]  # all paradigm codes whose form value equals the input


class EkilexClient:
    def __init__(self, api_key: str, base_url: str, dataset: str):
        self._base = base_url.rstrip("/")
        self._dataset = dataset
        self._headers = {"ekilex-api-key": api_key}

    def _get(self, path: str) -> dict | list:
        with httpx.Client() as http:
            response = http.get(f"{self._base}{path}", headers=self._headers, timeout=10.0)
            response.raise_for_status()
            return response.json()

    def search(self, word: str) -> list[SearchResult]:
        data = self._get(f"/api/word/search/{word}")
        words = data.get("words", [])
        return [
            SearchResult(
                word_id=w["wordId"],
                word=w["wordValue"],
                homonym_nr=w.get("homonymNr", 1),
                datasets=w.get("datasetCodes", []),
            )
            for w in words
        ]

    def lookup(self, word_id: int) -> WordEntry:
        data = self._get(f"/api/word/details/{word_id}")
        word = data["word"]

        definitions: list[str] = []
        examples: list[Example] = []
        grammar_notes: list[str] = []
        pos = ""

        for lexeme in data.get("lexemes", []):
            if lexeme.get("datasetCode") != self._dataset:
                continue
            if not pos and lexeme.get("pos"):
                pos = lexeme["pos"][0].get("code", "")
            for g in lexeme.get("grammars", []):
                if v := g.get("value"):
                    grammar_notes.append(v)
            # definitions live on lexeme.meaning.definitions
            meaning = lexeme.get("meaning") or {}
            for defn in meaning.get("definitions", []):
                if (v := defn.get("value")) and v not in definitions:
                    definitions.append(v)
            for usage in lexeme.get("usages", []):
                text = usage.get("value", "")
                translation = None
                if usage.get("translations"):
                    translation = usage["translations"][0].get("value")
                if text:
                    examples.append(Example(text=text, translation=translation))

        return WordEntry(
            word_id=word["wordId"],
            lemma=word["wordValue"],
            homonym_nr=word.get("homonymNr", 1),
            pos=pos,
            grammar_notes=grammar_notes,
            definitions=definitions,
            examples=examples,
        )

    def paradigm(self, word_id: int) -> ParadigmTable:
        data = self._get(f"/api/paradigm/details/{word_id}")
        real = [p for p in data if p.get("inflectionType")]
        if not real:
            return ParadigmTable(word_class="", inflection_type="", forms={})
        entry = real[0]
        forms = {
            f["morphCode"]: f["value"]
            for f in entry.get("paradigmForms", [])
            if f.get("value")
        }
        return ParadigmTable(
            word_class=entry.get("wordClass", ""),
            inflection_type=entry.get("inflectionType", ""),
            forms=forms,
        )

    def identify(self, form: str) -> list[FormMatch]:
        data = self._get(f"/api/form/search/{form}")
        results = []
        for f in data:
            word_id = f["wordId"]
            paradigm = self.paradigm(word_id)
            morph_codes = [code for code, value in paradigm.forms.items() if value == form]
            results.append(FormMatch(
                word_id=word_id,
                lemma=f["wordValue"],
                homonym_nr=f.get("homonymNr", 1),
                morph_codes=morph_codes,
            ))
        return results
