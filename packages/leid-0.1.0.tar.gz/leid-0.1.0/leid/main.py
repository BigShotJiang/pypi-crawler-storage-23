from typing import Optional
import typer

from leid.config import resolve_config, OutputFormat
from leid.client import EkilexClient
from leid.formatters import format_search, format_lookup, format_paradigm, format_identify

app = typer.Typer(
    name="leid",
    help="Estonian word lookup CLI. Wraps the sonaveeb.ee ekilex API.",
    rich_markup_mode="markdown",
    no_args_is_help=True,
)

FormatOption = Optional[OutputFormat]


@app.callback()
def callback(
    ctx: typer.Context,
    format: FormatOption = typer.Option(None, "--format", "-f", help="Output format: markdown or pretty"),
):
    ctx.ensure_object(dict)
    ctx.obj["format"] = format


def _client_and_format(ctx: typer.Context) -> tuple[EkilexClient, OutputFormat]:
    fmt = (ctx.obj or {}).get("format")
    cfg = resolve_config(cli_format=fmt)
    client = EkilexClient(api_key=cfg.api_key, base_url=cfg.base_url, dataset=cfg.dataset)
    return client, cfg.format


@app.command()
def search(
    ctx: typer.Context,
    word: str = typer.Argument(..., help="Estonian word to search for"),
):
    """Search for a word and list all homonyms with their wordIds."""
    client, fmt = _client_and_format(ctx)
    results = client.search(word)
    typer.echo(format_search(results, fmt, query=word), nl=False)


@app.command()
def lookup(
    ctx: typer.Context,
    word_id: int = typer.Argument(..., help="wordId from `leid search`"),
):
    """Get full definition, examples, and grammar notes for a word by wordId."""
    client, fmt = _client_and_format(ctx)
    entry = client.lookup(word_id)
    typer.echo(format_lookup(entry, fmt), nl=False)


@app.command()
def paradigm(
    ctx: typer.Context,
    word_id: int = typer.Argument(..., help="wordId from `leid search`"),
    lemma: str = typer.Option("", "--lemma", "-l", help="Word lemma for display (optional)"),
):
    """Show the full declension or conjugation table for a word by wordId."""
    client, fmt = _client_and_format(ctx)
    table = client.paradigm(word_id)
    typer.echo(format_paradigm(table, fmt, lemma=lemma), nl=False)


@app.command()
def identify(
    ctx: typer.Context,
    form: str = typer.Argument(..., help="Inflected form to identify (e.g. 'majas')"),
):
    """Identify an inflected form — returns base lemma, wordId, and case/form label."""
    client, fmt = _client_and_format(ctx)
    matches = client.identify(form)
    typer.echo(format_identify(matches, fmt, form=form), nl=False)


if __name__ == "__main__":
    app()
