import os
import sys
import tomllib
from dataclasses import dataclass
from enum import Enum
from pathlib import Path

CONFIG_FILE = Path.home() / ".config" / "leid" / "config.toml"


class OutputFormat(str, Enum):
    MARKDOWN = "markdown"
    PRETTY = "pretty"


@dataclass
class Config:
    format: OutputFormat
    api_key: str
    base_url: str
    dataset: str


def resolve_config(cli_format: OutputFormat | None) -> Config:
    file_cfg: dict = {}
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE, "rb") as f:
            file_cfg = tomllib.load(f)

    def _get(env_var: str, file_section: str, file_key: str, default: str) -> str:
        if env_value := os.environ.get(env_var):
            return env_value
        if file_section in file_cfg and file_key in file_cfg[file_section]:
            return file_cfg[file_section][file_key]
        return default

    raw_format = _get("LEID_FORMAT", "output", "format", "markdown")
    resolved_format = cli_format if cli_format is not None else OutputFormat(raw_format)

    api_key = _get("LEID_API_KEY", "api", "key", "")
    if not api_key:
        print("Error: API key not found. Set LEID_API_KEY env var or add to ~/.config/leid/config.toml", file=sys.stderr)
        sys.exit(1)

    base_url = _get("LEID_BASE_URL", "api", "base_url", "https://ekilex.ee")
    dataset = _get("LEID_DATASET", "api", "dataset", "eki")

    return Config(format=resolved_format, api_key=api_key, base_url=base_url, dataset=dataset)
