---
name: leid
description: >
  Use when teaching Estonian vocabulary, grammar, or when a student produces a
  word form you need to verify or identify. NEVER recite Estonian inflection
  paradigms from memory — always call leid paradigm to verify.
---

## When to use

- Student asks what a word means → `leid search` then `leid lookup`
- You need to show a declension or conjugation table → `leid paradigm`
- Student produces an inflected form you need to parse → `leid identify`

## Workflow

### Looking up a word

Always two steps — never assume there is only one match:

```bash
leid search <word>
```

This returns a table of all homonyms with their `wordId`. Pick the correct one
based on context (student's sentence, topic, prior conversation). Then:

```bash
leid lookup <wordId>
```

### Getting the inflection table

```bash
leid paradigm <wordId>
```

Use this for nouns (all 14 cases × singular/plural), verbs (all conjugated
forms), and adjectives. Never present a paradigm from memory — always call this.

### Identifying an inflected form

When the student writes a form like *majas*, *jooksid*, or *tehtud*:

```bash
leid identify <form>
```

This returns the base lemma, wordId, and the morphological label so you can
explain exactly what form it is.

## Caching wordIds

Within a session, cache `wordId`s you have already resolved. If you looked up
*maja* and got `wordId: 10234`, use `leid paradigm 10234` directly — do not
re-run `leid search maja`.

## Output format

Default output is markdown. You do not need to pass `--format` in normal use.
For human-readable terminal output, use `--format pretty`.

## Error handling

If `leid search` returns no results, try:
1. The base/dictionary form (infinitive for verbs, nominative singular for nouns)
2. `leid identify <form>` to find the base form first
