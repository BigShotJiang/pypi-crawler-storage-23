# leid

Estonian word lookup CLI. Wraps the [ekilex.ee](https://ekilex.ee) dictionary API.

Ships with a Claude Code skill so your AI language tutor can look up words, paradigms, and identify inflected forms — without guessing from memory.

## Install

Requires Python 3.11+ and [uv](https://docs.astral.sh/uv/).

```bash
uv tool install git+https://github.com/yourusername/leid
```

Or from PyPI:

```bash
uv tool install leid
```

## Configure

Get an API key from [ekilex.ee](https://ekilex.ee).

```bash
export LEID_API_KEY=your_key_here
```

Or persist it in `~/.config/leid/config.toml`:

```toml
[api]
key = "your_key_here"

[output]
format = "markdown"   # or "pretty"
```

## Usage

```bash
leid search tee          # all "tee" homonyms with wordIds
leid lookup 10234        # definition, examples, grammar notes
leid paradigm 10234      # full 14-case declension table
leid identify majas      # → maja · sg in (Inessive singular)
```

Default output is `markdown` (for AI context). For terminal use:

```bash
leid --format pretty paradigm 10234
```

## Claude Code skill

```bash
cp skill.md ~/.claude/skills/leid.md
# or:
./install-skill.sh
```

Teaches Claude when and how to call `leid` during Estonian lessons — always verifying paradigms from the dictionary rather than memory.
