"""Create command for generating new realms with demo data and deployment scripts."""

import json
import os
import re
import shutil
import subprocess
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, Optional

import typer
from rich.console import Console

from ..constants import REALM_FOLDER
from ..utils import get_scripts_path, is_repo_mode

# Dynamically import RealmGenerator based on mode
def _get_realm_generator():
    """Get RealmGenerator class - always use bundled generator with ggg.entities."""
    # Always use bundled generator which uses ggg.entities (no kybra dependency)
    # The scripts/realm_generator.py has import issues with backend's ggg module
    from ..generator import RealmGenerator
    return RealmGenerator
from .deploy import _deploy_realm_internal

console = Console()


def _replace_timestamp_placeholders(extensions_dir: Path) -> None:
    """Replace timestamp placeholders in extension data JSON files.
    
    Placeholders:
    - __REALM_CREATION_TIME__: Current timestamp in format "YYYY-MM-DD HH:MM:SS.000"
    - __VOTING_DEADLINE_24H__: 24 hours from now in ISO format
    """
    now = datetime.utcnow()
    creation_time = now.strftime("%Y-%m-%d %H:%M:%S.000")
    voting_deadline = (now + timedelta(hours=24)).strftime("%Y-%m-%dT%H:%M:%SZ")
    
    # Find all JSON files in extensions/*/data/ directories
    for data_dir in extensions_dir.glob("*/data"):
        if data_dir.is_dir():
            for json_file in data_dir.glob("*.json"):
                try:
                    content = json_file.read_text(encoding="utf-8")
                    
                    # Check if file contains any placeholders
                    if "__REALM_CREATION_TIME__" in content or "__VOTING_DEADLINE_24H__" in content:
                        content = content.replace("__REALM_CREATION_TIME__", creation_time)
                        content = content.replace("__VOTING_DEADLINE_24H__", voting_deadline)
                        json_file.write_text(content, encoding="utf-8")
                except Exception as e:
                    console.print(f"   ⚠️  Warning: Could not process {json_file}: {e}")


def _generate_single_realm(
    realm_name: str,
    realm_folder: str,
    output_path: Path,
    repo_root: Path,
    random: bool,
    members: int,
    organizations: int,
    transactions: int,
    disputes: int,
    seed: Optional[int],
) -> None:
    """Generate a single realm with its data and configuration."""
    console.print(f"\n[bold cyan]  📦 Generating {realm_name}...[/bold cyan]")
    
    # Create realm output directory
    realm_output = output_path / realm_folder
    realm_output.mkdir(parents=True, exist_ok=True)
    
    # Copy manifest from examples/demo/{realm_folder}/
    demo_realm_dir = repo_root / "examples" / "demo" / realm_folder
    demo_manifest = demo_realm_dir / "manifest.json"
    
    if demo_manifest.exists():
        # Copy manifest
        with open(demo_manifest, 'r') as f:
            manifest_data = json.load(f)
        
        # Optionally override name if different
        if "name" not in manifest_data or manifest_data["name"] != realm_name:
            manifest_data["name"] = realm_name
        
        manifest_path = realm_output / "manifest.json"
        with open(manifest_path, "w") as f:
            json.dump(manifest_data, f, indent=2)
            f.write("\n")
        console.print(f"     ✅ Copied manifest from {demo_realm_dir}")
        
        # Copy logo file if specified in manifest
        logo_filename = manifest_data.get("logo", "")
        if logo_filename:
            logo_source = demo_realm_dir / logo_filename
            if logo_source.exists():
                shutil.copy2(logo_source, realm_output / logo_filename)
                console.print(f"     ✅ Copied logo: {logo_filename}")
            else:
                console.print(f"     ⚠️  Warning: Logo file not found: {logo_source}")
        
        # Copy welcome image file if it exists
        for welcome_ext in ["jpg", "jpeg", "png", "webp"]:
            welcome_source = demo_realm_dir / f"welcome.{welcome_ext}"
            if welcome_source.exists():
                shutil.copy2(welcome_source, realm_output / f"welcome.{welcome_ext}")
                console.print(f"     ✅ Copied welcome image: welcome.{welcome_ext}")
                break
    else:
        console.print(f"     ⚠️  Warning: No manifest found in {demo_realm_dir}")
    
    if random:
        # Generate random data for this realm using bundled generator
        try:
            RealmGenerator = _get_realm_generator()
            generator = RealmGenerator(seed, quiet=True) if seed else RealmGenerator(quiet=True)
            
            realm_data = generator.generate_realm_data(
                members=members,
                organizations=organizations,
                transactions=transactions,
                disputes=disputes,
                realm_name=realm_name
            )
            
            # Save realm data JSON
            json_file = realm_output / "realm_data.json"
            realm_data_serialized = [obj.serialize() for obj in realm_data]
            with open(json_file, 'w') as f:
                json.dump(realm_data_serialized, f, indent=2)
            
            # Generate codex files
            generator.generate_codex_files(realm_output)
            
            console.print(f"[green]     ✅ Generated random data for {realm_name}[/green]")
        
        except Exception as e:
            console.print(f"[red]     ❌ Error: {e}[/red]")
            raise typer.Exit(1)


def create_command(
    output_dir: str,
    realm_name: str,
    manifest: Optional[str],
    random: bool,
    members: Optional[int],
    organizations: Optional[int],
    transactions: Optional[int],
    disputes: Optional[int],
    seed: Optional[int],
    network: str,
    deploy: bool,
    identity: Optional[str] = None,
    mode: str = "auto",
    bare: bool = False,
    plain_logs: bool = False,
    registry: Optional[str] = None,
) -> None:
    """Create a new single realm. Flags override manifest values.
    
    Args:
        bare: If True, skip data generation and only deploy canisters (no extensions/data)
        plain_logs: If True, show full verbose output instead of progress UI during deployment
    """
    from ..utils import generate_output_dir_name
    
    # Suppress verbose output when deploying with progress display
    quiet = deploy and not plain_logs
    
    console.print(f"[bold blue]🏛️  Creating Realm: {realm_name}[/bold blue]")

    # Generate timestamped directory name
    dir_name = generate_output_dir_name("realm", realm_name)
    base_dir = Path(output_dir)
    output_path = base_dir / dir_name
    
    console.print()
    
    # Create base directory if it doesn't exist
    base_dir.mkdir(parents=True, exist_ok=True)
    
    # Check if generated directory already exists (unlikely with timestamps, but check anyway)
    if output_path.exists() and any(output_path.iterdir()):
        console.print(f"[red]❌ Error: Generated directory already exists and is not empty:[/red]")
        console.print(f"[red]   {output_path.absolute()}[/red]")
        raise typer.Exit(1)
    
    # Create output directory
    output_path.mkdir(exist_ok=True)
    if not quiet:
        console.print(f"📁 Realm directory: {output_path}\n")

    scripts_path = get_scripts_path()
    
    # Check if we're in repo mode or pip-installed mode
    in_repo_mode = is_repo_mode()
    if not in_repo_mode:
        # In pip-installed mode - use bundled files from package
        # The package includes src, extensions, scripts via symlinks at realms/ level
        # dfx.template.json and requirements.txt are in cli/ directory
        package_root = Path(__file__).parent.parent.parent  # cli/commands -> cli -> realms
        repo_root = package_root
        if not quiet:
            console.print("[dim]Running in pip-installed mode (using bundled files)...[/dim]")
    else:
        repo_root = scripts_path.parent
        if not repo_root.exists() or not (repo_root / "scripts" / "realm_generator.py").exists():
            # In repo mode but scripts missing - error
            console.print("[red]❌ Error: Cannot locate realm_generator.py[/red]")
            console.print("[yellow]Repository structure is incomplete.[/yellow]")
            raise typer.Exit(1)
    
    # Determine if we should use manifest or flags
    has_flags = any([members is not None, organizations is not None, transactions is not None, disputes is not None, seed is not None])
    
    # Load manifest for defaults (if exists)
    realm_options = {}
    realm_manifest = None  # Initialize to ensure it's always defined
    if not has_flags or manifest is not None:
        if manifest is None:
            manifest_path = repo_root / "examples" / "demo" / "realm1" / "manifest.json"
        else:
            manifest_path = Path(manifest)
        
        if manifest_path.exists():
            with open(manifest_path, 'r') as f:
                realm_manifest = json.load(f)
            realm_options = realm_manifest.get("options", {}).get("random", {})
            
            # Copy manifest to output directory
            dest_manifest = output_path / "manifest.json"
            with open(dest_manifest, 'w') as f:
                realm_manifest["name"] = realm_name  # Update name
                json.dump(realm_manifest, f, indent=2)
            if not quiet:
                console.print(f"✅ Copied manifest from {manifest_path.parent}")
            
            # Copy logo file if specified in manifest
            logo_filename = realm_manifest.get("logo", "")
            if logo_filename:
                logo_source = manifest_path.parent / logo_filename
                if logo_source.exists():
                    shutil.copy2(logo_source, output_path / logo_filename)
                    if not quiet:
                        console.print(f"✅ Copied logo: {logo_filename}")
                else:
                    if not quiet:
                        console.print(f"[yellow]⚠️  Logo file not found: {logo_source}[/yellow]")
            
            # Copy welcome/background image file if specified in manifest or found by convention
            welcome_filename = realm_manifest.get("welcome_image", "")
            welcome_copied = False
            if welcome_filename:
                welcome_source = manifest_path.parent / welcome_filename
                if welcome_source.exists():
                    shutil.copy2(welcome_source, output_path / welcome_filename)
                    welcome_copied = True
                    if not quiet:
                        console.print(f"✅ Copied welcome image: {welcome_filename}")
            if not welcome_copied:
                # Fallback: search for welcome.* or background.* in manifest directory
                for img_name in ["welcome.png", "welcome.jpg", "welcome.webp", "background.png", "background.jpg"]:
                    img_source = manifest_path.parent / img_name
                    if img_source.exists():
                        shutil.copy2(img_source, output_path / img_name)
                        if not quiet:
                            console.print(f"✅ Copied welcome image: {img_name}")
                        break
    
    # Get RealmGenerator (from scripts/ in repo mode, bundled in pip mode)
    try:
        RealmGenerator = _get_realm_generator()
        
        # Determine parameters from flags or manifest
        gen_members = members if members is not None else realm_options.get("members", 50)
        gen_organizations = organizations if organizations is not None else realm_options.get("organizations", 5)
        gen_transactions = transactions if transactions is not None else realm_options.get("transactions", 100)
        gen_disputes = disputes if disputes is not None else realm_options.get("disputes", 10)
        gen_seed = seed if seed is not None else realm_options.get("seed")
        
        # Create generator (quiet mode when deploying with progress display)
        generator = RealmGenerator(gen_seed, quiet=quiet) if gen_seed else RealmGenerator(quiet=quiet)
        
        # Generate realm data
        if not quiet:
            console.print("[dim]Generating realm data...[/dim]")
        realm_data = generator.generate_realm_data(
            members=gen_members,
            organizations=gen_organizations,
            transactions=gen_transactions,
            disputes=gen_disputes,
            realm_name=realm_name
        )
        
        # Save realm data JSON
        json_file = output_path / "realm_data.json"
        realm_data_serialized = [obj.serialize() for obj in realm_data]
        with open(json_file, 'w') as f:
            json.dump(realm_data_serialized, f, indent=2)
        if not quiet:
            console.print(f"[dim]Generated realm data saved to: {json_file}[/dim]")
        
        # Generate codex files - get codex name from manifest if available
        # Support both old format ("codex": "name") and new format ("codex": {"package": {"name": "...", "version": "..."}})
        codex_config = realm_manifest.get("codex") if realm_manifest else None
        if isinstance(codex_config, dict):
            codex_name = codex_config.get("package", {}).get("name")
        else:
            codex_name = codex_config  # Old format: string directly
        codex_result = generator.generate_codex_files(output_path, codex_name=codex_name)
        codex_files = codex_result.get("codex_files", [])
        codex_extensions = codex_result.get("extensions", [])
        codex_overrides = codex_result.get("entity_method_overrides", [])
        if not quiet:
            console.print(f"[dim]Generated {len(codex_files)} codex files[/dim]")
        
        # If codex provided entity_method_overrides, merge them into the realm manifest
        if codex_overrides and (output_path / "manifest.json").exists():
            with open(output_path / "manifest.json", 'r') as f:
                output_manifest = json.load(f)
            output_manifest["entity_method_overrides"] = codex_overrides
            if codex_extensions:
                output_manifest["extensions"] = codex_extensions
            with open(output_path / "manifest.json", 'w') as f:
                json.dump(output_manifest, f, indent=2)
            if not quiet:
                console.print(f"[dim]Updated manifest with {len(codex_overrides)} method overrides from codex[/dim]")
        
        if not quiet:
            console.print(f"[dim]Seed used: {generator.seed}[/dim]")
        
    except Exception as e:
        console.print(f"[red]❌ Error creating realm: {e}[/red]")
        import traceback
        console.print(f"[red]{traceback.format_exc()}[/red]")
        raise typer.Exit(1)
    
    # Copy canister_ids.json from manifest's directory if a manifest was specified
    if manifest is not None:
        manifest_path = Path(manifest)
        if manifest_path.exists():
            canister_ids_source = manifest_path.parent / "canister_ids.json"
            if canister_ids_source.exists():
                canister_ids_dest = output_path / "canister_ids.json"
                shutil.copy2(canister_ids_source, canister_ids_dest)
                if not quiet:
                    console.print(f"\n✅ Copied canister_ids.json from {canister_ids_source.parent}")
    
    # Generate deployment scripts after data generation
    # Check if we can generate scripts - look in cli directory first (pip-installed), then repo root
    cli_dir = Path(__file__).parent.parent  # cli/commands -> cli
    can_generate_scripts = (cli_dir / "dfx.template.json").exists() or (repo_root / "dfx.template.json").exists()
    
    if can_generate_scripts:
        _generate_deployment_scripts(output_path, network, realm_name, random, repo_root, deploy, identity, mode, bare, plain_logs, in_repo_mode=in_repo_mode, realm_manifest=realm_manifest, registry=registry)
    else:
        console.print(f"\n[yellow]⚠️  Deployment scripts not generated (bundled files not found)[/yellow]")
        console.print(f"[dim]Searched: {cli_dir / 'dfx.template.json'}, {repo_root / 'dfx.template.json'}[/dim]")
    
    if not quiet:
        console.print(f"\n[green]✅ Realm created successfully at: {output_path.absolute()}[/green]")


def _generate_deployment_scripts(
    output_path: Path,
    network: str,
    realm_name: str,
    has_random_data: bool,
    repo_root: Path,
    deploy: bool,
    identity: Optional[str],
    mode: str,
    bare: bool,
    plain_logs: bool = False,
    in_repo_mode: bool = True,
    realm_manifest: Optional[Dict[str, Any]] = None,
    registry: Optional[str] = None,
):
    """Generate deployment scripts and dfx.json for independent realm.
    
    Args:
        bare: If True, skip extensions and data upload during deployment
        plain_logs: If True, show full verbose output instead of progress UI
    """
    # Suppress verbose output when deploying with progress display
    quiet = deploy and not plain_logs
    
    if not quiet:
        console.print("\n🔧 Generating deployment configuration...")

    # 1. Generate dfx.json for this independent realm
    if not quiet:
        console.print("\n📝 Creating dfx.json...")
    
    # Load template dfx.json - check cli directory first (pip-installed), then repo root
    cli_dir = Path(__file__).parent.parent  # cli/commands -> cli
    template_dfx = cli_dir / "dfx.template.json"
    if not template_dfx.exists():
        template_dfx = repo_root / "dfx.template.json"
    if not template_dfx.exists():
        console.print(f"[red]❌ Template dfx.template.json not found[/red]")
        console.print(f"[dim]Searched: {cli_dir / 'dfx.template.json'}, {repo_root / 'dfx.template.json'}[/dim]")
        raise typer.Exit(1)
    
    with open(template_dfx, 'r') as f:
        dfx_config = json.load(f)
    
    # Create realm-only dfx.json (realm_backend, realm_frontend, and optional local-only canisters)
    # Check if canister_ids.json exists - if so, use standard names to match existing canisters
    # Otherwise, use unique names to avoid conflicts in mundus deployments
    canister_ids_file = output_path / "canister_ids.json"
    
    if canister_ids_file.exists():
        # canister_ids.json exists (from manifest) - use standard names to match existing canisters
        backend_name = "realm_backend"
        frontend_name = "realm_frontend"
        if not quiet:
            console.print(f"   ✅ Using standard canister names from canister_ids.json")
    else:
        # No canister_ids.json - generate unique names for local/mundus deployments
        sanitized_realm_name = realm_name.lower().replace(" ", "_").replace("-", "_")
        backend_name = f"{sanitized_realm_name}_backend"
        frontend_name = f"{sanitized_realm_name}_frontend"
        if not quiet:
            console.print(f"   ✅ Using unique canister names: {backend_name}, {frontend_name}")
    
    # Deep copy and update canister configs to avoid reference issues
    # Strip remote block - it's only for CLI commands, not for realm deployments
    import copy
    backend_config = copy.deepcopy(dfx_config["canisters"]["realm_backend"])
    backend_config.pop("remote", None)
    frontend_config = copy.deepcopy(dfx_config["canisters"]["realm_frontend"])
    frontend_config.pop("remote", None)
    
    # IMPORTANT: Keep workspace as "realm_frontend" (not unique name)
    # because src/ directories are copied with standard names
    # The workspace field tells dfx where to find package.json, which is at src/realm_frontend/
    
    realm_canisters = {
        backend_name: backend_config,
        frontend_name: frontend_config,
    }
    
    # For local networks, include additional canisters (Internet Identity, ckBTC, etc.)
    is_local_network = network.startswith("local")
    
    # Get the deploying user's principal for local ledger initialization
    deployer_principal = None
    if is_local_network:
        try:
            result = subprocess.run(
                ["dfx", "identity", "get-principal"],
                capture_output=True, text=True, check=True
            )
            deployer_principal = result.stdout.strip()
            if not quiet:
                console.print(f"   ✅ Deployer principal: {deployer_principal}")
        except Exception as e:
            if not quiet:
                console.print(f"   ⚠️  Could not get deployer principal: {e}")
    
    if is_local_network:
        # Include Internet Identity for local development (shared across realms)
        if "internet_identity" in dfx_config["canisters"]:
            realm_canisters["internet_identity"] = dfx_config["canisters"]["internet_identity"]
        
        # Include any ICRC-1 ledger canisters if they exist
        for canister_name, canister_config in dfx_config["canisters"].items():
            if any(keyword in canister_name.lower() for keyword in ["icrc1", "ledger", "indexer", "token_backend", "nft_backend", "token_frontend", "nft_frontend"]) and canister_name not in realm_canisters:
                # Use standard name if canister_ids exists, otherwise unique name
                if canister_ids_file.exists():
                    ledger_name = canister_name
                else:
                    sanitized_realm_name = realm_name.lower().replace(" ", "_").replace("-", "_")
                    ledger_name = f"{sanitized_realm_name}_{canister_name}"
                
                # Deep copy the config to avoid modifying the template
                ledger_config = copy.deepcopy(canister_config)
                
                # Update init_arg for ckbtc_ledger to include initial balance for deployer
                if "ckbtc" in canister_name.lower() and "ledger" in canister_name.lower() and deployer_principal:
                    if "init_arg" in ledger_config:
                        # Replace minting_account and initial_balances in existing init_arg
                        init_arg = ledger_config["init_arg"]
                        init_arg = init_arg.replace('principal "aaaaa-aa"', f'principal "{deployer_principal}"')
                        init_arg = init_arg.replace('initial_balances = vec {}', f'initial_balances = vec {{ record {{ record {{ owner = principal "{deployer_principal}"; subaccount = null }}; 100_000_000_000 }} }}')
                        ledger_config["init_arg"] = init_arg
                        if not quiet:
                            console.print(f"   ✅ Configured {ledger_name} with 1000 ckBTC initial balance for deployer")
                
                # Update init_arg for token_backend with realm-specific name and symbol
                if canister_name == "token_backend" and "init_arg" in ledger_config:
                    # Get token config from realm manifest if available
                    token_config = realm_manifest.get("token", {}) if realm_manifest else {}
                    token_name = token_config.get("name", f"{realm_name} Token")
                    token_symbol = token_config.get("symbol", realm_name[:3].upper())
                    
                    # Update the init_arg with realm-specific token name and symbol
                    init_arg = ledger_config["init_arg"]
                    # Replace name = "Simple Token" with realm-specific name
                    init_arg = re.sub(r'name = "[^"]*"', f'name = "{token_name}"', init_arg)
                    init_arg = re.sub(r'symbol = "[^"]*"', f'symbol = "{token_symbol}"', init_arg)
                    ledger_config["init_arg"] = init_arg
                    if not quiet:
                        console.print(f"   ✅ Configured {ledger_name} as '{token_name}' ({token_symbol})")
                
                # Update init_arg for nft_backend with realm-specific land_token config
                if canister_name == "nft_backend" and "init_arg" in ledger_config:
                    # Get land_token config from realm manifest if available
                    land_token_config = realm_manifest.get("land_token", {}) if realm_manifest else {}
                    if land_token_config:
                        nft_name = land_token_config.get("name", f"{realm_name} Land")
                        nft_symbol = land_token_config.get("symbol", f"{realm_name[:1]}LAND")
                        nft_description = land_token_config.get("description", f"Land ownership NFT for {realm_name}")
                        nft_supply_cap = land_token_config.get("supply_cap", 10000)
                        
                        # Update the init_arg with realm-specific NFT config
                        init_arg = ledger_config["init_arg"]
                        init_arg = re.sub(r'name = "[^"]*"', f'name = "{nft_name}"', init_arg)
                        init_arg = re.sub(r'symbol = "[^"]*"', f'symbol = "{nft_symbol}"', init_arg)
                        init_arg = re.sub(r'description = opt "[^"]*"', f'description = opt "{nft_description}"', init_arg)
                        init_arg = re.sub(r'supply_cap = opt \d+', f'supply_cap = opt {nft_supply_cap}', init_arg)
                        ledger_config["init_arg"] = init_arg
                        console.print(f"   ✅ Configured {ledger_name} as '{nft_name}' ({nft_symbol}) - Land NFT")
                    else:
                        console.print(f"   ⚠️  No land_token config in manifest, using defaults for {ledger_name}")
                
                realm_canisters[ledger_name] = ledger_config
                if not quiet:
                    console.print(f"   ✅ Including {ledger_name} for local development")
    
    realm_dfx = {
        "canisters": realm_canisters,
        "defaults": dfx_config.get("defaults", {}),
        "networks": dfx_config.get("networks", {}),
        "output_env_file": ".env",
        "version": dfx_config.get("version", 1)
    }
    
    # Write dfx.json
    dfx_json_path = output_path / "dfx.json"
    with open(dfx_json_path, 'w') as f:
        json.dump(realm_dfx, f, indent=2)
    if not quiet:
        console.print(f"   ✅ dfx.json created")

    # Copy src directories so the realm is fully self-contained and portable
    # This is crucial: deploy_canisters.sh cd's into the realm directory and expects src/ there
    src_dest = output_path / "src"
    if not src_dest.exists():
        src_source = repo_root / "src"
        if src_source.exists():
            # Define patterns to ignore during copy (build artifacts, caches, etc.)
            # Also exclude monitor route which depends on task_monitor extension
            ignore_patterns = shutil.ignore_patterns(
                'node_modules', '__pycache__', '.kybra', '*.pyc', '.svelte-kit',
                'build', 'dist', '.env', '.env.*', '*.log', 'monitor'
            )
            shutil.copytree(src_source, src_dest, ignore=ignore_patterns)
            if not quiet:
                console.print(f"   ✅ Copied src/ directory")
        else:
            if not quiet:
                console.print(f"   ⚠️  Warning: Could not find src directory at {src_source}")
    
    # Copy requirements.txt for venv creation during deployment
    # Check cli directory first (pip-installed), then repo root
    requirements_source = cli_dir / "requirements.txt"
    if not requirements_source.exists():
        requirements_source = repo_root / "requirements.txt"
    requirements_dest = output_path / "requirements.txt"
    if requirements_source.exists() and not requirements_dest.exists():
        shutil.copy2(requirements_source, requirements_dest)
        if not quiet:
            console.print(f"   ✅ Copied requirements.txt")
    
    # Copy extensions/ directory for extension data files (voting_data.json, etc.)
    # Flatten the nested submodule structure for standalone deployments:
    # - Repo structure: extensions/extensions/{ext_id}/ (git submodule)
    # - Deployment structure: extensions/{ext_id}/ (flat, for standalone use)
    extensions_dest = output_path / "extensions"
    extensions_source = repo_root / "extensions"
    if extensions_source.exists():
        # Check if extensions directory is empty (likely uninitialized submodule)
        extensions_contents = list(extensions_source.iterdir())
        if not extensions_contents or (len(extensions_contents) == 1 and extensions_contents[0].name == '.git'):
            if not quiet:
                console.print(f"   [yellow]⚠️  Warning: extensions/ directory is empty![/yellow]")
                console.print(f"   [yellow]   This is likely because the git submodule is not initialized.[/yellow]")
                console.print(f"   [yellow]   Run: git submodule update --init --recursive[/yellow]")
        elif not extensions_dest.exists():
            extensions_dest.mkdir(parents=True, exist_ok=True)
            ignore_patterns = shutil.ignore_patterns(
                '__pycache__', '*.pyc', 'venv', '.venv', 'node_modules', '.git', '.github'
            )
            
            # Check for nested structure (extensions/extensions/) and flatten it
            nested_extensions = extensions_source / "extensions"
            if nested_extensions.exists() and nested_extensions.is_dir():
                # Copy contents of nested extensions directory directly to deployment
                for item in nested_extensions.iterdir():
                    if item.is_dir() and not item.name.startswith('.'):
                        dest_item = extensions_dest / item.name
                        shutil.copytree(item, dest_item, ignore=ignore_patterns)
                if not quiet:
                    console.print(f"   ✅ Copied extensions/ directory (flattened from submodule)")
                
                # Also copy marketplace if it exists at the extensions/ level
                marketplace_source = extensions_source / "marketplace"
                if marketplace_source.exists() and marketplace_source.is_dir():
                    marketplace_dest = extensions_dest / "marketplace"
                    shutil.copytree(marketplace_source, marketplace_dest, ignore=ignore_patterns)
                    if not quiet:
                        console.print(f"   ✅ Copied marketplace extension")
            else:
                # Already flat structure or different layout, copy as-is
                shutil.copytree(extensions_source, extensions_dest, ignore=ignore_patterns, dirs_exist_ok=True)
                if not quiet:
                    console.print(f"   ✅ Copied extensions/ directory")
        
        # Always replace timestamp placeholders in extension data files
        if extensions_dest.exists():
            _replace_timestamp_placeholders(extensions_dest)
            if not quiet:
                console.print(f"   ✅ Replaced timestamp placeholders in extension data")
    else:
        if not quiet:
            console.print(f"   [yellow]⚠️  Warning: Could not find extensions directory at {extensions_source}[/yellow]")
            console.print(f"   [yellow]   Run: git submodule update --init --recursive[/yellow]")
    
    # 2. Create scripts subdirectory
    if not quiet:
        console.print("\n🔧 Generating deployment scripts...")
    scripts_dir = output_path / "scripts"
    scripts_dir.mkdir(exist_ok=True)

    # Get scripts path (auto-detects repo vs image mode)
    scripts_path = get_scripts_path()

    # 1. Create install_extensions.sh script
    target_install = scripts_dir / "1-install-extensions.sh"
    source_install = scripts_path / "install_extensions.sh"
    if source_install.exists():
        shutil.copy2(source_install, target_install)
        target_install.chmod(0o755)
        if not quiet:
            console.print(f"   ✅ {target_install.name}")
    else:
        console.print(f"   ❌ Source file not found: {source_install}")

    # 2. Copy deploy_canisters.sh script
    target_deploy = scripts_dir / "2-deploy-canisters.sh"
    source_deploy = scripts_path / "deploy_canisters.sh"
    if source_deploy.exists():
        shutil.copy2(source_deploy, target_deploy)
        target_deploy.chmod(0o755)
        if not quiet:
            console.print(f"   ✅ {target_deploy.name}")
    else:
        console.print(f"   ❌ Source file not found: {source_deploy}")

    # 3. Copy upload_data.sh script
    target_upload = scripts_dir / "3-upload-data.sh"
    source_upload = scripts_path / "upload_data.sh"
    if source_upload.exists():
        shutil.copy2(source_upload, target_upload)
        target_upload.chmod(0o755)
        if not quiet:
            console.print(f"   ✅ {target_upload.name}")
    else:
        console.print(f"   ❌ Source file not found: {source_upload}")

    # 4. Copy post_deploy.py script
    target_post_deploy = scripts_dir / "4-post-deploy.py"
    source_post_deploy = scripts_path / "post_deploy.py"
    if source_post_deploy.exists():
        shutil.copy2(source_post_deploy, target_post_deploy)
        target_post_deploy.chmod(0o755)
        if not quiet:
            console.print(f"   ✅ {target_post_deploy.name}")
    else:
        console.print(f"   ❌ Source file not found: {source_post_deploy}")
    
    # 5. Copy additional required scripts for deployment
    additional_scripts = [
        "download_wasms.sh",
        "set_canister_config.py",
        "clean_dfx.sh",
    ]
    for script_name in additional_scripts:
        source_script = scripts_path / script_name
        target_script = scripts_dir / script_name
        if source_script.exists():
            shutil.copy2(source_script, target_script)
            target_script.chmod(0o755)
            if not quiet:
                console.print(f"   ✅ {script_name}")
    
    # Copy utils directory if it exists (needed by some scripts)
    utils_source = scripts_path / "utils"
    utils_dest = scripts_dir / "utils"
    if utils_source.exists() and not utils_dest.exists():
        shutil.copytree(utils_source, utils_dest)
        if not quiet:
            console.print(f"   ✅ utils/")

    if not quiet:
        console.print(f"\n[green]🎉 Realm '{realm_name}' created successfully![/green]")
    
    if deploy:
        if not quiet:
            console.print("\n[yellow]🚀 Auto-deployment requested...[/yellow]")
        try:
            # Deploy the single realm using the internal deploy function
            _deploy_realm_internal(
                config_file=None, 
                folder=str(output_path),  # Use the generated realm directory
                network=network, 
                clean=False, 
                identity=identity, 
                mode=mode,
                bare=bare,
                plain_logs=plain_logs,
                registry=registry,
            )
        except typer.Exit as e:
            console.print(
                f"[red]❌ Auto-deployment failed with exit code: {e.exit_code}[/red]"
            )
            raise
        except Exception as e:
            import traceback
            console.print(f"[red]❌ Auto-deployment failed: {e}[/red]")
            console.print(f"[red]{traceback.format_exc()}[/red]")
            raise typer.Exit(1)
    else:
        console.print("\n[yellow]📝 Next steps:[/yellow]")
        console.print(f"   1. Deploy: realms realm deploy --folder {output_path}")
        console.print(f"   2. Or run: cd {output_path} && bash scripts/2-deploy-canisters.sh")
