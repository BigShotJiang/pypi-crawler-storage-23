"""Internal HTTP client for the TasksMind SDK."""

from __future__ import annotations

from typing import Any, Dict, Optional

import httpx

from .exceptions import APIError, AuthError, NotFoundError, RateLimitError

_DEFAULT_BASE_URL = "https://api.tasksmind.com"
_DEFAULT_TIMEOUT = 60.0


class HTTPClient:
    """Thin wrapper around ``httpx.Client`` that handles auth and error mapping."""

    def __init__(self, api_key: str, base_url: str, timeout: float) -> None:
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._client = httpx.Client(timeout=timeout)

    def _headers(self) -> Dict[str, str]:
        return {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    def _raise_for_status(self, resp: httpx.Response) -> None:
        if resp.is_success:
            return
        body = resp.text[:2000]
        code = resp.status_code
        if code in (401, 403):
            raise AuthError(f"Authentication failed (HTTP {code})", status_code=code, body=body)
        if code == 404:
            raise NotFoundError(f"Resource not found (HTTP 404)", status_code=code, body=body)
        if code == 429:
            raise RateLimitError(f"Rate limit exceeded (HTTP 429)", status_code=code, body=body)
        raise APIError(f"API error (HTTP {code}): {body}", status_code=code, body=body)

    def get(self, path: str, params: Optional[Dict[str, Any]] = None) -> Any:
        url = self._base_url + path
        resp = self._client.get(url, headers=self._headers(), params=params)
        self._raise_for_status(resp)
        return resp.json() if resp.text else {}

    def post(self, path: str, body: Any = None) -> Any:
        url = self._base_url + path
        resp = self._client.post(url, headers=self._headers(), json=body)
        self._raise_for_status(resp)
        return resp.json() if resp.text else {}

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> "HTTPClient":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()
