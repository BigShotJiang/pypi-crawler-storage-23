"""TasksMind SDK exceptions."""

from __future__ import annotations


class TasksMindError(Exception):
    """Base exception for all TasksMind SDK errors."""

    def __init__(self, message: str, status_code: int = 0, body: str = "") -> None:
        super().__init__(message)
        self.status_code = status_code
        self.body = body

    def __repr__(self) -> str:
        return f"{type(self).__name__}({self!s}, status_code={self.status_code})"


class AuthError(TasksMindError):
    """Raised when the API key is missing, invalid, or expired (HTTP 401/403)."""


class NotFoundError(TasksMindError):
    """Raised when the requested resource does not exist (HTTP 404)."""


class RateLimitError(TasksMindError):
    """Raised when the API rate limit is exceeded (HTTP 429)."""


class APIError(TasksMindError):
    """Raised for all other API-level errors (HTTP 4xx/5xx)."""


class TimeoutError(TasksMindError):
    """Raised when a polling call (e.g. runs.wait) exceeds its timeout."""
