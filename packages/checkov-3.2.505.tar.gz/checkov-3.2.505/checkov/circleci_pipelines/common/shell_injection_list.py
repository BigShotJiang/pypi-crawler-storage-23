# flake8: noqa
terms = [
    r"\$*CIRCLE_PR_REPONAME*",
    r"\$*CIRCLE_PR_USERNAME*",
    r"\$*CIRCLE_PULL_REQUESTS*",
    r"\$*CIRCLE_TAG*",
    r"\$*CIRCLE_BRANCH*"
]
