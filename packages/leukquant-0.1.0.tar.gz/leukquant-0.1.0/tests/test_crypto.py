"""
Tests for the PQ-Crypto Vault and KeyManager.
"""
import os
import sys
import tempfile
import pytest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.crypto.key_manager import KeyManager
from src.crypto.pq_encrypt import PQCryptoVault


# ─── key manager ─────────────────────────────────────────────────────────────

@pytest.fixture
def keys_dir(tmp_path):
    return str(tmp_path / "keys")


@pytest.fixture
def km(keys_dir):
    return KeyManager(keys_dir=keys_dir)


def test_generate_kem_keypair_returns_bytes(km):
    pub, priv = km.generate_kem_keypair()
    assert isinstance(pub, bytes) and len(pub) > 0
    assert isinstance(priv, bytes) and len(priv) > 0


def test_generate_sig_keypair_returns_bytes(km):
    pub, priv = km.generate_sig_keypair()
    assert isinstance(pub, bytes) and len(pub) > 0
    assert isinstance(priv, bytes) and len(priv) > 0


def test_save_and_load_keypair(km):
    pub, priv = km.generate_kem_keypair()
    km.save_keypair("test-kem", pub, priv)
    loaded_pub = km.load_key("test-kem", "pub")
    loaded_priv = km.load_key("test-kem", "priv")
    assert loaded_pub == pub
    assert loaded_priv == priv


def test_private_key_permissions(km, keys_dir):
    pub, priv = km.generate_kem_keypair()
    km.save_keypair("perm-test", pub, priv)
    priv_path = os.path.join(keys_dir, "perm-test.priv")
    mode = oct(os.stat(priv_path).st_mode)[-3:]
    assert mode == "600", f"Expected 600, got {mode}"


def test_list_keys(km):
    km.save_keypair("alpha", b"pub_a", b"priv_a")
    km.save_keypair("beta", b"pub_b", b"priv_b")
    keys = km.list_keys()
    assert "alpha" in keys
    assert "beta" in keys


def test_load_nonexistent_key_returns_none(km):
    assert km.load_key("does-not-exist", "pub") is None


def test_sign_and_verify_roundtrip(km):
    sig_pub, sig_priv = km.generate_sig_keypair()
    data = b"leukquant test payload"
    signature = km.sign(data, sig_priv)
    assert km.verify(data, signature, sig_pub)


def test_verify_tampered_data_fails(km):
    sig_pub, sig_priv = km.generate_sig_keypair()
    data = b"original data"
    signature = km.sign(data, sig_priv)
    assert not km.verify(b"tampered data", signature, sig_pub)


# ─── encrypt / decrypt ───────────────────────────────────────────────────────

@pytest.fixture
def vault_with_keys(tmp_path):
    keys_dir = str(tmp_path / "keys")
    km = KeyManager(keys_dir=keys_dir)
    kem_pub, kem_priv = km.generate_kem_keypair()
    km.save_keypair("kem", kem_pub, kem_priv)
    sig_pub, sig_priv = km.generate_sig_keypair()
    km.save_keypair("sig", sig_pub, sig_priv)
    return PQCryptoVault(keys_dir=keys_dir), tmp_path


def test_encrypt_produces_sqe_file(vault_with_keys, tmp_path):
    vault, base = vault_with_keys
    plaintext = b"top secret data 1234"
    src = base / "secret.txt"
    src.write_bytes(plaintext)
    ok = vault.encrypt_file(str(src))
    assert ok
    enc_path = str(src) + ".sqe"
    assert os.path.exists(enc_path)


def test_encrypt_sqe_magic_bytes(vault_with_keys, tmp_path):
    vault, base = vault_with_keys
    src = base / "magic_test.txt"
    src.write_bytes(b"check magic")
    vault.encrypt_file(str(src))
    enc_path = str(src) + ".sqe"
    with open(enc_path, "rb") as f:
        magic = f.read(4)
    assert magic == b"SQE1"


def test_encrypt_decrypt_roundtrip(vault_with_keys, tmp_path):
    vault, base = vault_with_keys
    plaintext = b"round trip test payload 12345!"
    src = base / "rt.txt"
    src.write_bytes(plaintext)

    enc_path = str(src) + ".sqe"
    dec_path = str(src) + ".dec"

    ok_enc = vault.encrypt_file(str(src), output_path=enc_path)
    assert ok_enc

    ok_dec = vault.decrypt_file(enc_path, output_path=dec_path)
    assert ok_dec

    with open(dec_path, "rb") as f:
        result = f.read()
    assert result == plaintext


def test_encrypt_nonexistent_file(vault_with_keys):
    vault, _ = vault_with_keys
    ok = vault.encrypt_file("/nonexistent/file.bin")
    assert not ok


def test_decrypt_invalid_file(vault_with_keys, tmp_path):
    vault, base = vault_with_keys
    bad = base / "bad.sqe"
    bad.write_bytes(b"not a valid sqe file")
    ok = vault.decrypt_file(str(bad))
    assert not ok
