"""
Tests for QuarantineManager and offline signature sync.
"""
import os
import sys
import tempfile
import pytest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.quarantine.manager import QuarantineManager
from src.db.database import DatabaseManager
from src.offline.sync import OfflineSync


# ─── quarantine manager ──────────────────────────────────────────────────────

@pytest.fixture
def qm(tmp_path):
    q = QuarantineManager(quarantine_dir=str(tmp_path / "quarantine"))
    q.db = DatabaseManager(db_dir=str(tmp_path / "db"))
    return q, tmp_path


def test_quarantine_moves_file(qm):
    manager, base = qm
    victim = base / "malware.exe"
    victim.write_bytes(b"evil_bytes_1234")

    qid = manager.quarantine_file(str(victim), reason="Test quarantine")

    assert not victim.exists(), "Original file should have been moved"
    entries = manager.list_quarantined()
    assert any(e["id"] == qid for e in entries)


def test_quarantine_records_metadata(qm):
    manager, base = qm
    f = base / "test_meta.bin"
    f.write_bytes(b"metadata test")

    qid = manager.quarantine_file(str(f), reason="Unit test")
    entry = manager.get_entry(qid)

    assert entry is not None
    assert entry["reason"] == "Unit test"
    assert entry["original_path"] == str(f)
    assert len(entry["file_hash"]) == 64  # SHA-256 hex


def test_restore_file_returns_to_original(qm):
    manager, base = qm
    f = base / "restore_me.txt"
    f.write_bytes(b"restore test data")
    original_path = str(f)

    qid = manager.quarantine_file(original_path)
    assert not f.exists()

    ok = manager.restore_file(qid)
    assert ok
    assert f.exists()
    assert f.read_bytes() == b"restore test data"


def test_restore_nonexistent_id(qm):
    manager, _ = qm
    assert not manager.restore_file("00000000-0000-0000-0000-000000000000")


def test_delete_permanently_removes_file(qm):
    manager, base = qm
    f = base / "delete_me.bin"
    f.write_bytes(b"delete me forever")

    qid = manager.quarantine_file(str(f))
    ok = manager.delete_permanently(qid)
    assert ok

    # File should be gone and DB entry removed
    assert manager.get_entry(qid) is None


def test_list_quarantined_empty(qm):
    manager, _ = qm
    assert manager.list_quarantined() == []


def test_quarantine_nonexistent_file(qm):
    manager, _ = qm
    with pytest.raises(FileNotFoundError):
        manager.quarantine_file("/nonexistent/evil.bin")


# ─── offline sync ────────────────────────────────────────────────────────────

@pytest.fixture
def sync_pair(tmp_path):
    db1 = DatabaseManager(db_dir=str(tmp_path / "db1"))
    db1.add_threat_signature("a" * 64, severity=7, source="test")
    db1.add_threat_signature("b" * 64, severity=3, source="test")

    s_export = OfflineSync(keys_dir=str(tmp_path / "keys"))
    s_export.db = db1

    db2 = DatabaseManager(db_dir=str(tmp_path / "db2"))
    s_import = OfflineSync(keys_dir=str(tmp_path / "keys"))
    s_import.db = db2

    export_path = str(tmp_path / "export.lqsig")
    return s_export, s_import, export_path


def test_export_creates_file(sync_pair, tmp_path):
    s_export, _, export_path = sync_pair
    ok = s_export.export_signatures(export_path)
    assert ok
    assert os.path.exists(export_path)


def test_export_has_correct_magic(sync_pair):
    s_export, _, export_path = sync_pair
    s_export.export_signatures(export_path)
    with open(export_path, "rb") as f:
        magic = f.read(4)
    assert magic == b"LQSG"


def test_import_restores_signatures(sync_pair):
    s_export, s_import, export_path = sync_pair
    s_export.export_signatures(export_path)
    ok = s_import.import_signatures(export_path, verify=True)
    assert ok
    sigs = s_import.db.get_all_signatures()
    hashes = {s["file_hash"] for s in sigs}
    assert "a" * 64 in hashes
    assert "b" * 64 in hashes


def test_import_fails_on_tampered_file(sync_pair, tmp_path):
    s_export, s_import, export_path = sync_pair
    s_export.export_signatures(export_path)

    # Tamper with a byte in the entries section
    with open(export_path, "r+b") as f:
        f.seek(-1, 2)
        f.write(b"\xff")

    ok = s_import.import_signatures(export_path, verify=True)
    assert not ok


def test_import_no_verify_flag(sync_pair):
    """--no-verify should import even without a matching HMAC key."""
    s_export, s_import, export_path = sync_pair
    s_export.export_signatures(export_path)
    ok = s_import.import_signatures(export_path, verify=False)
    assert ok
