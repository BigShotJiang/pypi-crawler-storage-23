"""
Tests for the Behavior Profiler and SystemMonitor.
"""
import os
import sys
import time
import tempfile
import pytest
import numpy as np

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.behavior.profiler import BehaviorProfiler, MIN_BASELINE_SAMPLES
from src.db.database import DatabaseManager


# ─── profiler helpers ────────────────────────────────────────────────────────

@pytest.fixture
def tmp_db(tmp_path):
    """Return a DatabaseManager using a temp directory."""
    return DatabaseManager(db_dir=str(tmp_path / "db"))


@pytest.fixture
def profiler(tmp_db):
    p = BehaviorProfiler()
    p.db = tmp_db
    return p


def _fill_baseline(db: DatabaseManager, n: int = 15, seed: int = 42):
    """Insert *n* synthetic baseline rows."""
    rng = np.random.default_rng(seed)
    for _ in range(n):
        db.insert_metrics({
            "process_spawn_rate": rng.normal(200, 20),
            "file_write_rate": rng.normal(5.0, 1.0),
            "network_socket_count": rng.normal(30, 5),
            "memory_alloc_spikes": rng.normal(45, 5),
        })


# ─── anomaly scoring ─────────────────────────────────────────────────────────

def test_anomaly_score_zero_without_enough_data(profiler):
    """No baseline data → score must be 0 (learning phase)."""
    metrics = {
        "process_spawn_rate": 200,
        "file_write_rate": 5.0,
        "network_socket_count": 30,
        "memory_alloc_spikes": 45,
    }
    assert profiler.calculate_anomaly_score(metrics) == 0.0


def test_anomaly_score_low_for_normal_metrics(profiler):
    """Metrics close to the baseline mean → score near zero."""
    _fill_baseline(profiler.db)
    metrics = {
        "process_spawn_rate": 200,
        "file_write_rate": 5.0,
        "network_socket_count": 30,
        "memory_alloc_spikes": 45,
    }
    score = profiler.calculate_anomaly_score(metrics)
    assert score < 1.0


def test_anomaly_score_high_for_spike(profiler):
    """Extreme deviation from baseline → score well above alert_threshold."""
    _fill_baseline(profiler.db)
    spike_metrics = {
        "process_spawn_rate": 5000,   # 200× normal
        "file_write_rate": 500.0,
        "network_socket_count": 900,
        "memory_alloc_spikes": 99.9,
    }
    score = profiler.calculate_anomaly_score(spike_metrics)
    assert score > profiler.alert_threshold


def test_anomaly_score_returns_float(profiler):
    _fill_baseline(profiler.db)
    metrics = {"process_spawn_rate": 200, "file_write_rate": 5, "network_socket_count": 30, "memory_alloc_spikes": 45}
    result = profiler.calculate_anomaly_score(metrics)
    assert isinstance(result, float)


# ─── database integration ────────────────────────────────────────────────────

def test_metrics_stored_and_retrieved(tmp_db):
    row = {
        "process_spawn_rate": 100,
        "file_write_rate": 2.5,
        "network_socket_count": 10,
        "memory_alloc_spikes": 30,
    }
    tmp_db.insert_metrics(row)
    assert tmp_db.metrics_count() == 1

    baseline = tmp_db.get_baseline_metrics(days=1)
    assert len(baseline) == 1
    assert baseline[0][0] == 100  # process_spawn_rate


def test_anomaly_log_roundtrip(tmp_db):
    tmp_db.log_anomaly(4.2, "test anomaly")
    entries = tmp_db.get_recent_anomalies(limit=5)
    assert len(entries) == 1
    assert abs(entries[0]["anomaly_score"] - 4.2) < 1e-6
    assert entries[0]["details"] == "test anomaly"
