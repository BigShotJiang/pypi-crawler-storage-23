"""
Tests for the Local AI Scanner.
Uses a real trained ONNX model if available; otherwise tests feature extraction
and hash-based signature lookup.
"""
import os
import sys
import tempfile
import hashlib
import pytest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.scanner.extract import extract_features
from src.scanner.scan import LocalScanner
from src.db.database import DatabaseManager


# ─── feature extraction ──────────────────────────────────────────────────────

def test_extract_features_vector_length():
    """Feature vector must always be 258 elements."""
    with tempfile.NamedTemporaryFile(delete=False, suffix=".bin") as f:
        f.write(os.urandom(4096))
        f.flush()
        features = extract_features(f.name)
    os.unlink(f.name)
    assert len(features) == 258


def test_extract_features_empty_file():
    with tempfile.NamedTemporaryFile(delete=False) as f:
        pass  # empty file
    features = extract_features(f.name)
    os.unlink(f.name)
    assert len(features) == 258
    assert features[0] == 0.0  # size == 0


def test_extract_features_missing_file():
    features = extract_features("/nonexistent/path/file.exe")
    assert len(features) == 258
    assert all(v == 0.0 for v in features)


def test_extract_features_histogram_sums_to_one():
    """Byte histogram (indices 2-257) should be a probability distribution."""
    with tempfile.NamedTemporaryFile(delete=False) as f:
        f.write(b"A" * 1000)
    features = extract_features(f.name)
    os.unlink(f.name)
    histogram_sum = sum(features[2:258])
    assert abs(histogram_sum - 1.0) < 1e-5


# ─── scanner ─────────────────────────────────────────────────────────────────

def test_scan_file_missing_file():
    scanner = LocalScanner(model_path="nonexistent.onnx")
    result = scanner.scan_file("/nonexistent/file.bin")
    assert "error" in result


def test_scan_returns_hash():
    with tempfile.NamedTemporaryFile(delete=False) as f:
        f.write(b"hello world")
    scanner = LocalScanner(model_path="nonexistent.onnx")
    result = scanner.scan_file(f.name)
    os.unlink(f.name)
    # Even without a model, the hash should be computed (or error returned cleanly)
    assert "file" in result


def test_signature_match_returns_malicious(tmp_path):
    """Files whose SHA-256 hash is in the DB should always return MALICIOUS."""
    sample = tmp_path / "evil.bin"
    sample.write_bytes(b"malware_payload_data")

    file_hash = hashlib.sha256(b"malware_payload_data").hexdigest()
    db = DatabaseManager(db_dir=str(tmp_path / "db"))
    db.add_threat_signature(file_hash, severity=9)

    scanner = LocalScanner(model_path="nonexistent.onnx")
    scanner.db = db  # inject test DB
    result = scanner.scan_file(str(sample))

    assert result["verdict"] == "MALICIOUS"
    assert result["method"] == "signature"
    assert result["malware_probability"] == 1.0


def test_hash_file_consistency(tmp_path):
    data = b"consistency_test_data"
    f = tmp_path / "test.bin"
    f.write_bytes(data)
    expected = hashlib.sha256(data).hexdigest()
    assert LocalScanner.hash_file(str(f)) == expected
