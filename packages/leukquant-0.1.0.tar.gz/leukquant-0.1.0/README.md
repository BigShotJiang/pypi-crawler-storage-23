# Leukquant — Fully Local, Decentralized Threat Defense

> **Zero cloud. Zero trust in corporations. Zero single point of failure.**

## Overview

Leukquant is a fully local, decentralized threat defense system. It uses on-device AI for malware classification, a behavior profiler for anomaly detection, and post-quantum cryptography for file encryption.

*Note: The blockchain threat ledger is currently disabled in this version. We use datasets like EMBER, VirusShare, and Kaggle Malware datasets for local AI scanning.*

## Features

1. **Local AI Scanning**: On-device malware classification using ONNX models. No telemetry. No cloud calls.
2. **Behavior Profiler**: Learns normal patterns over a 14-day baseline and flags deviations.
3. **Post-Quantum Crypto Vault**: Encrypts files with NIST PQC standards (ML-KEM, ML-DSA, SLH-DSA).
4. **Offline Mode**: Built for machines that never touch the internet.

## Installation

```bash
pip install -r requirements.txt
```

## Usage

### 1. Local AI Scanning

Scan a file using the local AI model:

```bash
python src/cli/main.py scan --file /path/to/file
```

### 2. Behavior Profiler

Start monitoring system behavior:

```bash
python src/cli/main.py monitor
```

### 3. Post-Quantum File Encryption

Encrypt a file:

```bash
python src/cli/main.py encrypt --file secret.pdf --algo ml-kem-1024 --sign ml-dsa-87
```

Decrypt a file:

```bash
python src/cli/main.py decrypt --file secret.pdf.sqe --key ~/.Leukquant/private.key
```

## File Structure

- `models/`: Contains the ONNX/GGML models for malware detection.
- `db/`: Local SQLite databases for threat signatures and behavior baselines.
- `keys/`: Post-quantum cryptographic keys.
- `config/`: Configuration files (e.g., `Leukquant.yml`).
- `src/`: Source code for the scanner, behavior profiler, crypto vault, and CLI.
- `logs/`: Local logs for anomalies.

## Datasets for Training

To train the local AI model, you can use the following datasets:
- **EMBER**: Open PE malware dataset.
- **VirusShare**: Repository of malware samples.
- **Kaggle Malware Datasets**: Various datasets available on Kaggle.

*Note: The pre-trained model should be placed in `models/malware_detector.onnx`.*
