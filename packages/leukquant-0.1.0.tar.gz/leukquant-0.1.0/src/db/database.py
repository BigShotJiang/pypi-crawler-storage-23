import sqlite3
import os
import logging
from datetime import datetime
from contextlib import contextmanager
from typing import Optional
from src.paths import app_path

logger = logging.getLogger(__name__)

# Register explicit adapters so Python datetime → ISO string in SQLite (Python 3.12+)
sqlite3.register_adapter(datetime, lambda d: d.isoformat())
sqlite3.register_converter("DATETIME", lambda b: datetime.fromisoformat(b.decode()))


class DatabaseManager:
    """Central SQLite persistence layer for threats, behavior metrics, quarantine, and anomaly logs."""

    def __init__(self, db_dir: str = None):
        db_dir = db_dir or app_path("db")
        self.db_dir = db_dir
        os.makedirs(self.db_dir, exist_ok=True)
        self.threats_db = os.path.join(self.db_dir, "threats.db")
        self.behavior_db = os.path.join(self.db_dir, "behavior_baseline.db")
        self._init_dbs()

    # ─── connection helper ───────────────────────────────────────────────────

    @contextmanager
    def _connect(self, db_path: str):
        conn = sqlite3.connect(db_path, detect_types=sqlite3.PARSE_DECLTYPES)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    # ─── schema ─────────────────────────────────────────────────────────────

    def _init_dbs(self):
        with self._connect(self.threats_db) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS signatures (
                    file_hash      TEXT PRIMARY KEY,
                    yara_rule_hash TEXT,
                    severity       INTEGER DEFAULT 5,
                    source         TEXT DEFAULT 'local',
                    label          TEXT DEFAULT 'malware',
                    timestamp      DATETIME
                )
            """)
            # Migration: add label column to existing DBs that pre-date this version
            try:
                conn.execute("ALTER TABLE signatures ADD COLUMN label TEXT DEFAULT 'malware'")
            except Exception:
                pass  # column already exists
            conn.execute("""
                CREATE TABLE IF NOT EXISTS quarantine (
                    id             TEXT PRIMARY KEY,
                    original_path  TEXT NOT NULL,
                    quarantine_path TEXT NOT NULL,
                    file_hash      TEXT,
                    reason         TEXT,
                    timestamp      DATETIME
                )
            """)

        with self._connect(self.behavior_db) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS metrics (
                    timestamp            DATETIME,
                    process_spawn_rate   REAL,
                    file_write_rate      REAL,
                    network_socket_count REAL,
                    memory_alloc_spikes  REAL
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS anomaly_log (
                    timestamp     DATETIME,
                    anomaly_score REAL,
                    details       TEXT
                )
            """)

    # ─── threat signatures ───────────────────────────────────────────────────

    def add_threat_signature(
        self,
        file_hash: str,
        yara_rule_hash: str = "",
        severity: int = 5,
        source: str = "local",
        label: str = "malware",
    ):
        with self._connect(self.threats_db) as conn:
            conn.execute(
                """INSERT OR REPLACE INTO signatures
                   (file_hash, yara_rule_hash, severity, source, label, timestamp)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (file_hash, yara_rule_hash, severity, source, label, datetime.now()),
            )

    def add_threat_signatures_bulk(self, entries: list) -> int:
        """
        Bulk-insert threat signatures using INSERT OR IGNORE (skips duplicates).
        Much faster than individual inserts for large datasets like VirusShare.

        entries: list of dicts with keys: hash, severity, source, label

        Returns the number of *new* rows inserted.
        """
        BATCH = 50_000
        now = datetime.now().isoformat()
        data = [
            (
                e["hash"],
                "",                         # yara_rule_hash
                int(e.get("severity", 5)),
                str(e.get("source", "local")),
                str(e.get("label", "malware")),
                now,
            )
            for e in entries
        ]
        with self._connect(self.threats_db) as conn:
            before = conn.execute("SELECT COUNT(*) FROM signatures").fetchone()[0]
            for i in range(0, len(data), BATCH):
                conn.executemany(
                    """INSERT OR IGNORE INTO signatures
                       (file_hash, yara_rule_hash, severity, source, label, timestamp)
                       VALUES (?, ?, ?, ?, ?, ?)""",
                    data[i : i + BATCH],
                )
                logger.info(
                    f"  Bulk insert: {min(i + BATCH, len(data))}/{len(data)} entries processed"
                )
            after = conn.execute("SELECT COUNT(*) FROM signatures").fetchone()[0]
        return after - before

    def get_threat_signature(self, file_hash: str) -> Optional[dict]:
        with self._connect(self.threats_db) as conn:
            row = conn.execute(
                "SELECT * FROM signatures WHERE file_hash = ?", (file_hash,)
            ).fetchone()
        return dict(row) if row else None

    def get_all_signatures(self) -> list[dict]:
        with self._connect(self.threats_db) as conn:
            rows = conn.execute("SELECT * FROM signatures ORDER BY timestamp DESC").fetchall()
        return [dict(r) for r in rows]

    def signature_count(self) -> int:
        with self._connect(self.threats_db) as conn:
            return conn.execute("SELECT COUNT(*) FROM signatures").fetchone()[0]

    # ─── behavior metrics ────────────────────────────────────────────────────

    def insert_metrics(self, metrics: dict):
        with self._connect(self.behavior_db) as conn:
            conn.execute(
                """INSERT INTO metrics
                   (timestamp, process_spawn_rate, file_write_rate,
                    network_socket_count, memory_alloc_spikes)
                   VALUES (?, ?, ?, ?, ?)""",
                (
                    metrics.get("timestamp", datetime.now()),
                    metrics.get("process_spawn_rate", 0),
                    metrics.get("file_write_rate", 0),
                    metrics.get("network_socket_count", 0),
                    metrics.get("memory_alloc_spikes", 0),
                ),
            )

    def get_baseline_metrics(self, days: int = 14) -> list[tuple]:
        with self._connect(self.behavior_db) as conn:
            rows = conn.execute(
                """SELECT process_spawn_rate, file_write_rate,
                          network_socket_count, memory_alloc_spikes
                   FROM metrics
                   WHERE timestamp > datetime('now', ?)""",
                (f"-{days} days",),
            ).fetchall()
        return [tuple(r) for r in rows]

    def metrics_count(self) -> int:
        with self._connect(self.behavior_db) as conn:
            return conn.execute("SELECT COUNT(*) FROM metrics").fetchone()[0]

    # ─── anomaly log ─────────────────────────────────────────────────────────

    def log_anomaly(self, score: float, details: str = ""):
        with self._connect(self.behavior_db) as conn:
            conn.execute(
                "INSERT INTO anomaly_log (timestamp, anomaly_score, details) VALUES (?, ?, ?)",
                (datetime.now(), score, details),
            )

    def get_recent_anomalies(self, limit: int = 20) -> list[dict]:
        with self._connect(self.behavior_db) as conn:
            rows = conn.execute(
                "SELECT * FROM anomaly_log ORDER BY timestamp DESC LIMIT ?", (limit,)
            ).fetchall()
        return [dict(r) for r in rows]

    # ─── quarantine ──────────────────────────────────────────────────────────

    def add_quarantine_entry(
        self,
        quarantine_id: str,
        original_path: str,
        quarantine_path: str,
        file_hash: str,
        reason: str,
    ):
        with self._connect(self.threats_db) as conn:
            conn.execute(
                """INSERT OR REPLACE INTO quarantine
                   (id, original_path, quarantine_path, file_hash, reason, timestamp)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (quarantine_id, original_path, quarantine_path, file_hash, reason, datetime.now()),
            )

    def get_quarantine_entry(self, quarantine_id: str) -> Optional[dict]:
        with self._connect(self.threats_db) as conn:
            row = conn.execute(
                "SELECT * FROM quarantine WHERE id = ?", (quarantine_id,)
            ).fetchone()
        return dict(row) if row else None

    def remove_quarantine_entry(self, quarantine_id: str):
        with self._connect(self.threats_db) as conn:
            conn.execute("DELETE FROM quarantine WHERE id = ?", (quarantine_id,))

    def list_quarantine_entries(self) -> list[dict]:
        with self._connect(self.threats_db) as conn:
            rows = conn.execute(
                "SELECT * FROM quarantine ORDER BY timestamp DESC"
            ).fetchall()
        return [dict(r) for r in rows]

    def quarantine_count(self) -> int:
        with self._connect(self.threats_db) as conn:
            return conn.execute("SELECT COUNT(*) FROM quarantine").fetchone()[0]
