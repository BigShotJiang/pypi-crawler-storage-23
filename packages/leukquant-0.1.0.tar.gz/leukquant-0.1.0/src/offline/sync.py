"""
Offline Signature Sync
======================
Binary wire format (.lqsig):

  [ MAGIC  4B  ] b'LQSG'
  [ VERSION 2B ]  0x0001
  [ COUNT   4B ]  number of entries
  [ HMAC   32B ]  HMAC-SHA256 over all entries bytes (key = sig.priv or random)
  [ ENTRIES     ]  COUNT × packed entry:
      sha256_hash  32B (binary)
      severity      1B
      source_len    1B
      source        source_len bytes
      ts_len        1B
      timestamp     ts_len bytes (ISO string)

Import verifies the HMAC before touching the database.
"""

import os
import struct
import hmac
import hashlib
import logging
from datetime import datetime

from src.db.database import DatabaseManager
from src.paths import app_path

logger = logging.getLogger(__name__)

MAGIC = b"LQSG"
VERSION = 1


def _derive_hmac_key(keys_dir: str = None) -> bytes:
    """Use the local signing private key as HMAC key, or a static fallback."""
    keys_dir = keys_dir or app_path("keys")
    priv_path = os.path.join(keys_dir, "sig.priv")
    if os.path.exists(priv_path):
        with open(priv_path, "rb") as f:
            raw = f.read()
        # Derive a fixed-length key via SHA-256
        return hashlib.sha256(raw).digest()
    # No key present yet — use a well-known constant (integrity only, not auth)
    return hashlib.sha256(b"leukquant-offline-sync-v1").digest()


def _pack_entry(sig: dict) -> bytes:
    """Pack one signature dict into binary form."""
    file_hash_bytes = bytes.fromhex(sig["file_hash"]) if len(sig["file_hash"]) == 64 else sig["file_hash"].encode()
    file_hash_bytes = file_hash_bytes[:32].ljust(32, b"\x00")
    severity = int(sig.get("severity", 5)) & 0xFF
    source = (sig.get("source") or "local").encode()[:255]
    # timestamp may be a datetime object or a string
    ts_raw = sig.get("timestamp") or datetime.now()
    ts = (ts_raw.isoformat() if hasattr(ts_raw, "isoformat") else str(ts_raw)).encode()[:255]

    return (
        file_hash_bytes
        + struct.pack("B", severity)
        + struct.pack("B", len(source))
        + source
        + struct.pack("B", len(ts))
        + ts
    )


def _unpack_entry(data: bytes, offset: int) -> tuple[dict, int]:
    """Unpack one entry starting at *offset*; returns (entry_dict, new_offset)."""
    file_hash = data[offset : offset + 32].hex()
    offset += 32
    severity = struct.unpack_from("B", data, offset)[0]
    offset += 1
    src_len = struct.unpack_from("B", data, offset)[0]
    offset += 1
    source = data[offset : offset + src_len].decode()
    offset += src_len
    ts_len = struct.unpack_from("B", data, offset)[0]
    offset += 1
    timestamp = data[offset : offset + ts_len].decode()
    offset += ts_len
    return {"file_hash": file_hash, "severity": severity, "source": source, "timestamp": timestamp}, offset


class OfflineSync:
    """Export and import threat signatures in a tamper-evident binary format."""

    def __init__(self, keys_dir: str = None):
        self.db = DatabaseManager()
        self.keys_dir = keys_dir or app_path("keys")

    # ─── export ──────────────────────────────────────────────────────────────

    def export_signatures(self, output_path: str) -> bool:
        try:
            sigs = self.db.get_all_signatures()
            if not sigs:
                logger.warning("No signatures to export.")

            entries_bytes = b"".join(_pack_entry(s) for s in sigs)
            mac = hmac.new(_derive_hmac_key(self.keys_dir), entries_bytes, hashlib.sha256).digest()

            os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
            with open(output_path, "wb") as f:
                f.write(MAGIC)
                f.write(struct.pack(">H", VERSION))
                f.write(struct.pack(">I", len(sigs)))
                f.write(mac)
                f.write(entries_bytes)

            logger.info(f"Exported {len(sigs)} signatures → {output_path}")
            return True
        except Exception as e:
            logger.error(f"Export failed: {e}")
            return False

    # ─── import ──────────────────────────────────────────────────────────────

    def import_signatures(self, input_path: str, verify: bool = True) -> bool:
        if not os.path.exists(input_path):
            logger.error(f"File not found: {input_path}")
            return False
        try:
            with open(input_path, "rb") as f:
                data = f.read()

            # Parse header
            if data[:4] != MAGIC:
                raise ValueError("Invalid file format (bad magic bytes)")
            version = struct.unpack_from(">H", data, 4)[0]
            if version != VERSION:
                raise ValueError(f"Unsupported version: {version}")
            count = struct.unpack_from(">I", data, 6)[0]
            stored_mac = data[10:42]
            entries_bytes = data[42:]

            # Verify HMAC
            if verify:
                expected_mac = hmac.new(
                    _derive_hmac_key(self.keys_dir), entries_bytes, hashlib.sha256
                ).digest()
                if not hmac.compare_digest(stored_mac, expected_mac):
                    logger.error("HMAC verification failed — file may be tampered!")
                    return False
                logger.info("HMAC integrity check passed.")

            # Unpack and insert
            offset = 0
            imported = 0
            for _ in range(count):
                entry, offset = _unpack_entry(entries_bytes, offset)
                self.db.add_threat_signature(
                    file_hash=entry["file_hash"],
                    severity=entry["severity"],
                    source=entry.get("source", "offline-import"),
                )
                imported += 1

            logger.info(f"Imported {imported} signatures from {input_path}")
            return True
        except Exception as e:
            logger.error(f"Import failed: {e}")
            return False
