import os
import shutil
import uuid
import hashlib
import logging
from datetime import datetime
from typing import Optional
from src.paths import app_path

logger = logging.getLogger(__name__)


class QuarantineManager:
    """
    Moves suspicious files to an isolated quarantine directory.
    Metadata (original path, hash, reason, timestamp) is stored in SQLite
    via DatabaseManager. Files can be restored, listed, or permanently deleted.
    """

    def __init__(self, quarantine_dir: str = None):
        # Import here to avoid circular dependency at module level
        from src.db.database import DatabaseManager

        self.quarantine_dir = quarantine_dir or app_path("quarantine")
        os.makedirs(self.quarantine_dir, exist_ok=True)
        self.db = DatabaseManager()

    # ─── internal helpers ────────────────────────────────────────────────────

    @staticmethod
    def _sha256(path: str) -> str:
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
        return h.hexdigest()

    # ─── public API ──────────────────────────────────────────────────────────

    def quarantine_file(self, file_path: str, reason: str = "Malware detected") -> str:
        """
        Move *file_path* into the quarantine directory.
        Returns the quarantine UUID that can be used to restore/delete later.
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")

        qid = str(uuid.uuid4())
        dest = os.path.join(self.quarantine_dir, qid)
        file_hash = self._sha256(file_path)
        original_abs = os.path.abspath(file_path)

        shutil.move(file_path, dest)

        self.db.add_quarantine_entry(
            quarantine_id=qid,
            original_path=original_abs,
            quarantine_path=dest,
            file_hash=file_hash,
            reason=reason,
        )

        logger.warning(
            f"[QUARANTINE] {original_abs} → {dest}  (id={qid}, reason={reason})"
        )
        return qid

    def restore_file(self, quarantine_id: str) -> bool:
        """Move the quarantined file back to its original location."""
        entry = self.db.get_quarantine_entry(quarantine_id)
        if not entry:
            logger.error(f"No quarantine entry: {quarantine_id}")
            return False

        dest = entry["original_path"]
        src = entry["quarantine_path"]

        if not os.path.exists(src):
            logger.error(f"Quarantined file missing from disk: {src}")
            return False

        os.makedirs(os.path.dirname(dest), exist_ok=True)
        shutil.move(src, dest)
        self.db.remove_quarantine_entry(quarantine_id)
        logger.info(f"[RESTORE] {src} → {dest}")
        return True

    def delete_permanently(self, quarantine_id: str) -> bool:
        """Securely delete a quarantined file and remove its DB record."""
        entry = self.db.get_quarantine_entry(quarantine_id)
        if not entry:
            logger.error(f"No quarantine entry: {quarantine_id}")
            return False

        path = entry["quarantine_path"]
        if os.path.exists(path):
            # Overwrite before deletion to reduce forensic recovery
            size = os.path.getsize(path)
            with open(path, "r+b") as f:
                f.write(os.urandom(size))
            os.remove(path)

        self.db.remove_quarantine_entry(quarantine_id)
        logger.info(f"[DELETE] Permanently removed quarantine id={quarantine_id}")
        return True

    def list_quarantined(self) -> list[dict]:
        return self.db.list_quarantine_entries()

    def get_entry(self, quarantine_id: str) -> Optional[dict]:
        return self.db.get_quarantine_entry(quarantine_id)
