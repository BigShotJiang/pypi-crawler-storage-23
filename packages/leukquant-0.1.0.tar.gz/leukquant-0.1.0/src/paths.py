r"""
Leukquant — Platform-Aware Application Paths
=============================================
All runtime data (models, keys, DBs, quarantine, logs) is stored in a
single, platform-appropriate hidden directory:

  Linux / macOS  ->  ~/.leukquant/
                     (respects XDG_DATA_HOME if set)
  Windows        ->  %APPDATA%\Leukquant\
                     (C:\Users\<user>\AppData\Roaming\Leukquant)

Override everything by setting LEUKQUANT_HOME:
    LEUKQUANT_HOME=/srv/leukquant leukquant scan --file ...

Sub-directory layout
--------------------
  <APP_DIR>/
    config/Leukquant.yml    -- runtime configuration
    models/                 -- ONNX model + .meta.json
    db/                     -- threats.db, behavior_baseline.db
    keys/                   -- kem.pub/priv, sig.pub/priv
    logs/                   -- monitor.pid, application logs
    quarantine/             -- isolated malicious files
    exports/                -- .lqsig signature bundles
    data/                   -- optional dataset downloads (kaggle, etc.)
"""

import os
import platform


def _compute_app_dir() -> str:
    # Explicit override — useful in containers, CI, or multi-user installs
    override = os.environ.get("LEUKQUANT_HOME", "").strip()
    if override:
        return os.path.abspath(os.path.expanduser(override))

    system = platform.system()

    if system == "Windows":
        # %APPDATA% → C:\Users\<user>\AppData\Roaming
        appdata = os.environ.get("APPDATA") or os.path.expanduser("~")
        return os.path.join(appdata, "Leukquant")

    # Linux / macOS / other POSIX
    # Honour XDG Base Directory spec on Linux if set
    xdg = os.environ.get("XDG_DATA_HOME", "").strip()
    if xdg:
        return os.path.join(os.path.expanduser(xdg), "leukquant")

    # Default: hidden dot-directory in the user's home
    return os.path.join(os.path.expanduser("~"), ".leukquant")


#: Absolute path to the application data directory (computed once at import).
APP_DIR: str = _compute_app_dir()


def app_path(*parts: str) -> str:
    """
    Join *parts* under APP_DIR and return an absolute path.

    Examples
    --------
    >>> app_path("models", "malware_detector.onnx")
    '/home/alice/.leukquant/models/malware_detector.onnx'
    >>> app_path("keys")
    '/home/alice/.leukquant/keys'
    """
    return os.path.join(APP_DIR, *parts)
