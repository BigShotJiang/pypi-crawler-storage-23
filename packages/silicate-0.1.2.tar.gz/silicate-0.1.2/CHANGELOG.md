# Changelog

## [0.1.2](https://github.com/alltuner/silicate/compare/v0.1.1...v0.1.2) (2026-02-25)


### Bug Fixes

* CI wheel builds and docs sidebar ([#3](https://github.com/alltuner/silicate/issues/3)) ([c7d34ec](https://github.com/alltuner/silicate/commit/c7d34ec28b21e5a8475361217ed4ab1dd358b407))

## [0.1.1](https://github.com/alltuner/silicate/compare/v0.1.0...v0.1.1) (2026-02-25)


### Features

* initial release of Silicate ([c72d77a](https://github.com/alltuner/silicate/commit/c72d77ab9b05fa4a98f2024f2213fe3841619a0d))


### Miscellaneous Chores

* add *.so and *.pyd to gitignore ([#2](https://github.com/alltuner/silicate/issues/2)) ([6ae4ad9](https://github.com/alltuner/silicate/commit/6ae4ad917b1c5dc21759d2049a3e3344ddf45df4))

## Changelog
