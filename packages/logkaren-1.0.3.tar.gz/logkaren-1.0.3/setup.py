from setuptools import setup, find_packages

setup(
    name="logkaren",
    version="1.0.1",
    description="A beautiful, colorful Python logging library by karenhoyoshi",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="karenhoyoshi",
    url="https://github.com/karenhoyoshi/logkaren",
    packages=find_packages(),
    python_requires=">=3.10",
    install_requires=[
        "colorama>=0.4.6",
        "pyfiglet>=0.8.post1",
    ],
    extras_require={
        "dev": ["build", "twine", "pytest"],
    },
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Topic :: System :: Logging",
        "Environment :: Console",
    ],
    keywords="logging logger colorful terminal cli console",
    license="MIT",
)
