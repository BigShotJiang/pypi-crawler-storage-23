"""
logkaren — A beautiful Python logging library.

Quick start:
    from logkaren import Logger, Loader, Home, LogLevel

    log = Logger()
    log.info("Hello, world!")
    log.success("Task completed", start=0, end=1.23)
    log.warning("Be careful!")
    log.error("Something went wrong")
    log.debug("Debug info here")

    with Loader(desc="Processing"):
        import time; time.sleep(2)

    Home(title="MYAPP", subtitle="My cool tool").display()
"""

from .enums import LogLevel
from .logger import Logger, ColorLogger, SimpleLogger
from .loader import Loader
from .home import Home

__all__ = [
    "Logger",
    "ColorLogger",
    "SimpleLogger",
    "Loader",
    "Home",
    "LogLevel",
]

__version__ = "1.0.0"
__author__ = "karenhoyoshi"
__email__ = ""
__url__ = "https://github.com/karenhoyoshi/logkaren"
