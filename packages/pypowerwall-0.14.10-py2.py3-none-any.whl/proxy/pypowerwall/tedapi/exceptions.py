class PyPowerwallTEDAPINoTeslaAuthFile(Exception):
    pass


class PyPowerwallTEDAPITeslaNotConnected(Exception):
    pass


class PyPowerwallTEDAPINotImplemented(Exception):
    pass


class PyPowerwallTEDAPIInvalidPayload(Exception):
    pass
