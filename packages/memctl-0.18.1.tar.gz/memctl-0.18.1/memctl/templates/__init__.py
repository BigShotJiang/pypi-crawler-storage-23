"""Bundled templates for eco mode and Claude Code hook installers."""
