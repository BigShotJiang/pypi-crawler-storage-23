# Fermion-Qubit Encoding

```{eval-rst}
.. automodule:: ferrmion.encode
   :members:
   :undoc-members:
   :show-inheritance:
```
