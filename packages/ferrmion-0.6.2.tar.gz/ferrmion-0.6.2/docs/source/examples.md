# Examples
(Examples)=

## Hamiltonians
```{base-gallery}
:caption: Hamiltonian Examples
:tooltip:

notebooks/encoding_hamiltonians
```

## Encodings
```{base-gallery}
:caption: Encoding Examples
:tooltip:

notebooks/growing_trees
notebooks/bonsai
```

## Optimization
```{base-gallery}
:caption: Optimization Examples
:tooltip:

notebooks/pauli_weight
notebooks/topp_hatt
notebooks/rett
notebooks/huffman
notebooks/hatt
```
