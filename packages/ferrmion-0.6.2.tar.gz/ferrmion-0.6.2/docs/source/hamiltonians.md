# Fermionic Hamiltonians

```{eval-rst}
.. automodule:: ferrmion.hamiltonians
   :members:
   :undoc-members:
   :show-inheritance:
```
