"""Monique: MONitor Integrated QUick Editor for Hyprland and Sway."""
