from __future__ import annotations
from typing import Callable, Type, Optional, Union, List, TYPE_CHECKING, Any
from uuid import UUID
from dataclasses import dataclass

from weaviate.classes.config import DataType, Property as weaviateProperty, Tokenization, ReferenceProperty as weaviateReferenceProperty
from weaviate.collections import Collection
from weaviate.util import _WeaviateUUIDInt
if TYPE_CHECKING:
    from .weaviate_base import Base_Model


@dataclass
class Polymorphic_Config:
    """
    Configuration for polymorphic references, allowing explicit control over
    which subclasses are allowed in a reference field.
    
    Instead of auto-detecting polymorphism by passing a base class, you can
    explicitly define allowed subclasses by name. The reference will accept instances
    of the superclass OR any of the allowed subclasses, storing both the UUID
    and the concrete type for proper deserialization.
    
    The superclass does NOT need to have a corresponding Weaviate collection.
    
    Attributes:
        superclass_name (str): The name of the superclass (can be abstract).
        allowed_subclasses (List[str]): List of allowed subclass names (as strings).
                                        Each must have its own collection.
    
    Example:
        >>> class Result(Base_Model):
        ...     title = Property(str)
        ...     _abstract = True
        ...
        >>> class Publication(Result):
        ...     __collection_name__ = "Publication"
        ...
        >>> class Artifact(Result):
        ...     __collection_name__ = "Artifact"
        ...
        >>> class Paper(Base_Model):
        ...     result = Reference(
        ...         polymorphic_config=Polymorphic_Config(
        ...             superclass_name="Result",
        ...             allowed_subclasses=["Publication", "Artifact"]
        ...         ),
        ...         description="Can reference Publication or Artifact"
        ...     )
    """
    superclass_name: str
    allowed_subclasses: List[str]


class Reference_Type:
    
    """
    Enum of the possible reference types.

    Attributes:
        SINGLE: A single reference.
        MULTIPLE: A list of references.
    """

    ONEWAY = "oneway"
    TWOWAY = "twoway"

    SINGLE = "single"
    LIST = "list"


class Reference:

    """
    Declares a reference field to another Weaviate class/collection.

    Attributes:
        target_collection (Base_Model): The target Weaviate collection.
        description (str): A human-readable description of the reference field.
        required (bool): Whether the reference field is required.
        auto_loading (bool): Whether to automatically load the referenced entity when accessed.
    """

    def __init__(
        self,
        target_collection_name: str,
        description: str = "",
        way_type: str = Reference_Type.ONEWAY,
        reference_type = Reference_Type.SINGLE,
        required: bool = False,
        auto_loading: bool = False,
        skip_validation: bool = False,
        inherited: bool = False,
        polymorphic_config: Optional[Polymorphic_Config] = None
    ):
        """
        Initialize the reference field descriptor.

        Args:
            target_collection_name (str): 
                Name of the target collection. 
                For polymorphic references when using polymorphic_config, 
                this should match the superclass_name in the config.
            description (str): A human-readable description of the reference field.
            way_type (str, optional): The way type of the reference. Defaults to Reference_Type.ONEWAY.
            reference_type (str, optional): The type of the reference. Defaults to Reference_Type.SINGLE. 
                Can be Reference_Type.SINGLE or Reference_Type.LIST.
            required (bool, optional): Whether the reference field is required. Defaults to False.
            auto_loading (bool, optional): Whether to automatically load the referenced entity when accessed. 
                Defaults to False. If false, the field will return the UUID of the referenced entity.
            skip_validation (bool, optional): Whether to skip validation of the reference field. Defaults to False.
            inherited (bool, optional): Whether the reference is inherited from a parent class. Defaults to False.
            polymorphic_config (Optional[Polymorphic_Config]): Explicit polymorphic configuration. 
                If provided, the reference is polymorphic.
        """

        self._is_polymorphic = False
        self._subclass_names: List[str] = []
        self._allowed_subclass_names: List[str] = []
        self.polymorphic_config = polymorphic_config
        self.target_collection_name = target_collection_name
        
        # Handle explicit Polymorphic_Config
        if polymorphic_config is not None:
            self._is_polymorphic = True
            self._allowed_subclass_names = polymorphic_config.allowed_subclasses
            self._subclass_names = polymorphic_config.allowed_subclasses.copy()

        self.description = description
        self.required = required
        self.auto_loading = auto_loading
        self.way_type = way_type
        self.reference_type = reference_type
        self.skip_validation = skip_validation
        self.inherited = inherited
        self.name: Optional[str] = None  # Assigned by __set_name__

    def __set_name__(self, owner, name):
        """
        Called automatically when the descriptor is assigned to a class attribute.
        """
        self.name = name
        self._owner = owner

    def __get__(self, instance, owner):

        """
        Access the value stored on the instance. If accessed from the class (instance is None)

        Args:
            instance: The instance of the class.
            owner: The class itself.

        Returns:
            Union[Base_Model, UUID]: The referenced entity or its UUID.

        Raises:
            ValueError: If the reference field is required but not set.
        """

        # Get handle_required_strict from the owner class, default to True if not set
        owner = getattr(self, "_owner", None)
        handle_required_strict = True
        if owner and hasattr(owner, "_handle_required_strict"):
            handle_required_strict = getattr(owner, "_handle_required_strict")

        # If accessed on the class itself, return the descriptor instance
        if instance is None:
            return self
        
        val = instance.__dict__.get(self.name)

        # If not set
        if val is None:
            if self.required and handle_required_strict:
                raise ValueError(f"Reference field '{self.name}' is required but not set.")
            return None
        
        # For polymorphic references, val is a tuple (uuid, type_name) or list of tuples
        # For monomorphic, val is uuid or list of uuids
        # Handle the value (auto-loading, list handling, etc.)
        value = self._handling_lists(instance, val)

        return value

    def __set__(self, instance, value):
        """
        Handle writing to the reference field: optional validation and loading the referenced entity.
        For polymorphic references, extracts and stores the type discriminator.

        Args:
            instance: The instance of the class.
            value: The value to set.

        Raises:
            ValueError: If the field is set with an invalid value.
        """

        value = self._handling_lists(instance, value)
        
        # Validate the value
        if not self._validate(value):
            raise ValueError(f"Invalid value ({value}) for reference field '{self.name}'")

        # For polymorphic references, wrap uuid with type discriminator
        if self._is_polymorphic:
            value = self._wrap_polymorphic_value(value)
            
            # CRITICAL: Also update the hidden properties so they get saved to Weaviate
            # The hidden properties must contain UUIDs and type strings, not objects
            uuid_prop_name = f"{self.name}_uuid"
            type_prop_name = f"{self.name}_type"
            
            if value is None:
                # Clear the hidden properties
                instance.__dict__[uuid_prop_name] = None
                instance.__dict__[type_prop_name] = None
            elif isinstance(value, list):
                # List of polymorphic references: extract UUIDs and types
                uuids = []
                types = []
                for v in value:
                    if v is not None:
                        obj_or_uuid, type_name = v
                        # Extract UUID from object if needed
                        if isinstance(obj_or_uuid, (UUID, _WeaviateUUIDInt)):
                            uuid_val = obj_or_uuid
                        else:
                            # It's an object instance - get its UUID
                            uuid_val = obj_or_uuid.get_uuid()
                        uuids.append(uuid_val)
                        types.append(type_name)
                instance.__dict__[uuid_prop_name] = uuids if uuids else None
                instance.__dict__[type_prop_name] = types if types else None
            else:
                # Single polymorphic reference: value is (obj_or_uuid, type_name)
                obj_or_uuid, type_name = value
                # Extract UUID from object if needed
                if isinstance(obj_or_uuid, (UUID, _WeaviateUUIDInt)):
                    uuid_val = obj_or_uuid
                else:
                    # It's an object instance - get its UUID
                    uuid_val = obj_or_uuid.get_uuid()
                instance.__dict__[uuid_prop_name] = uuid_val
                instance.__dict__[type_prop_name] = type_name

        # Store the final value in the instance
        instance.__dict__[self.name] = value

    def _get_target_collection(self, owner) -> Collection:
        """
        Get the target collection from weaviate.

        Args:
            owner: The class that owns the reference field.

        Returns:
            Collection: The target collection.
        """

        collection = None

        with owner._engine.client as client:
            collection = client.collections.get(self.target_collection_name)

        return collection
    
    def _wrap_polymorphic_value(self, value: Union[UUID, Any, List]) -> Union[tuple, List]:
        """
        Wrap values with their type discriminator for polymorphic references.
        Stores (Object | UUID, TypeString) to allow returning in-memory objects directly.
        
        Args:
            value: UUID, object instance, or list thereof
            
        Returns:
            For single refs: (object_or_uuid, type_name) tuple
            For list refs: list of (object_or_uuid, type_name) tuples
        """
        if value is None:
            return None
        
        def wrap_single(v):
            if isinstance(v, UUID):
                # UUID alone - shouldn't happen, but handle gracefully
                return (v, "Unknown")
            elif isinstance(v, tuple) and len(v) == 2 and isinstance(v[1], str):
                # Already wrapped as (value, type_name) - just return it
                return v
            else:
                # Must be an object instance - store the object itself, not just UUID
                type_name = v.__class__.__name__
                # Store the object directly so we can return it without auto-loading
                return (v, type_name)
        
        if self.reference_type == Reference_Type.LIST and isinstance(value, list):
            return [wrap_single(v) for v in value]
        else:
            return wrap_single(value)
    
    def _unwrap_polymorphic_value(self, value: Union[tuple, List]) -> Union[UUID, List[UUID]]:
        """
        Unwrap type discriminator from polymorphic values, returning just the UUID(s).
        
        Args:
            value: (uuid, type_name) tuple or list thereof
            
        Returns:
            UUID or list of UUIDs
        """
        if value is None:
            return None
        
        def unwrap_single(v):
            # Only unwrap if it's a proper (UUID, type_string) tuple
            if isinstance(v, tuple) and len(v) == 2 and isinstance(v[1], str):
                return v[0]  # Return just the UUID
            else:
                return v  # Already unwrapped or not a valid polymorphic tuple
        
        if self.reference_type == Reference_Type.LIST and isinstance(value, list):
            return [unwrap_single(v) for v in value]
        else:
            return unwrap_single(value)
    def _get_target_class(self, collection_name: Optional[str] = None) -> Type['Base_Model']:
        """
        Get the target class from the engine's model registry.
        Works for both polymorphic and monomorphic references.

        Args:
            collection_name (Optional[str]): Specific collection name to look up.
                If None, uses self.target_collection_name for monomorphic
                or self.target_collection_name for polymorphic.

        Returns:
            Type['Base_Model']: The target model class.

        Raises:
            ValueError: If the target class is not found in the engine.
        """

        owner = getattr(self, "_owner", None)
        if not owner or not hasattr(owner, "_engine"):
            raise ValueError("Cannot determine target class without engine.")

        target_name = collection_name or self.target_collection_name
        collection_classes = {model.__name__: model for model in owner._engine._models}

        if target_name in collection_classes:
            return collection_classes[target_name]
        
        raise ValueError(f"Target class '{target_name}' not found in the engine. Do you have a model for it?")

    def _validate(self, value) -> bool:
        """
        Validate the value of the reference field. If not required, None is allowed.
        For polymorphic references, accepts any subclass instance or UUID.

        Args:
            value: The value to validate.

        Returns:
            bool: True if the value is valid, False otherwise

        Raises:
            ValueError: If the value is invalid.
        """

        if self.skip_validation:
            return True

        # None is okay if not required
        if value is None:
            if self.required:
                raise ValueError(f"Reference field '{self.name}' is required, but got None.")
            
            return True
        
        # For polymorphic references, validate against allowed subclass names
        if self._is_polymorphic:
            # Get the engine's models registry to validate against
            owner = getattr(self, "_owner", None)
            if owner and hasattr(owner, "_engine"):
                engine = owner._engine
                allowed_classes = tuple(
                    model for model in engine._models 
                    if model.__name__ in self._allowed_subclass_names
                )
            else:
                # Fallback: can't strictly validate without engine, accept UUIDs
                allowed_classes = (UUID,)
            
            if self.reference_type == Reference_Type.SINGLE:
                if not (isinstance(value, UUID) or isinstance(value, allowed_classes)):
                    return False
            elif self.reference_type == Reference_Type.LIST:
                if not isinstance(value, list):
                    return False
                if not all(isinstance(v, (UUID, *allowed_classes)) for v in value):
                    return False
            
            # Check if objects are valid (UUIDs are always valid)
            if isinstance(value, allowed_classes) and hasattr(value, 'is_valid') and not value.is_valid:
                return False
            elif isinstance(value, list):
                for v in value:
                    if isinstance(v, allowed_classes) and hasattr(v, 'is_valid') and not v.is_valid:
                        return False
            
            return True
        
        # For monomorphic references, use the exact target class
        target_class = self._get_target_class()

        # Otherwise, must be either a UUID or a target_collection instance
        if self.reference_type == Reference_Type.SINGLE and (not (isinstance(value, UUID) or isinstance(value, target_class))):
            return False
        elif self.reference_type == Reference_Type.LIST and (not isinstance(value, list) or not all(isinstance(v, (UUID, target_class)) for v in value)):
            return False

        # If it's a target_collection instance, ensure it's valid (UUIDs are always considered valid)
        if isinstance(value, UUID):
            return True
        elif isinstance(value, list) and all(isinstance(v, (UUID, target_class)) for v in value):
            if all(not hasattr(v, 'is_valid') or v.is_valid for v in value):
                return True
        elif isinstance(value, target_class) and (not hasattr(value, 'is_valid') or value.is_valid):
            return True
        
        return False
        
    def _get_weaviate_reference(self) -> weaviateReferenceProperty:

        """
        Get the Weaviate reference property configuration.

        Returns:
            weaviateReferenceProperty: The Weaviate reference property configuration.

        Raises:
            ValueError: If the reference field name is not set.
        """

        if self.name is None:
            raise ValueError("Reference field name is not set; cannot create Weaviate reference property from not assigned reference field")
        
        ref = weaviateReferenceProperty(
            name=self.name,
            description=self.description,
            target_collection=self.target_collection_name,
        )

        return ref

    def _handle_weaviate_uuid(self, input_value) -> Union[UUID, Any]:
        """
        Handle the Weaviate UUID type. Convert it to a UUID object.
        For polymorphic refs, input_value may be (object_or_uuid, type_name) tuple,
        in which case we extract and convert the first element if needed.

        Args:
            input_value: A value, possibly wrapped as (value, type_name) tuple.

        Returns:
            Union[UUID, Any]: The handled value (UUID or object), or None.
        """
        # If it's a tuple (object_or_uuid, type_name), extract the first element
        if isinstance(input_value, tuple) and len(input_value) == 2 and isinstance(input_value[1], str):
            actual_value = input_value[0]
        else:
            actual_value = input_value
        
        # Convert Weaviate UUID to standard UUID
        if isinstance(actual_value, _WeaviateUUIDInt):
            actual_value = UUID(str(actual_value.hex))
        
        return actual_value

    def _handle_auto_loading(self, input_value, target_class=None) -> Union[UUID, Any]:
        """
        Handle the auto_loading of the reference field.
        For polymorphic references, uses the type discriminator to load from the correct collection.
        For monomorphic references, loads from the configured target collection.

        Args:
            input_value: The value to handle. For polymorphic: (object_or_uuid, type_name) tuple. For monomorphic: UUID or object.
            target_class (Optional): The target class to load the reference from. 
                If not provided, will be looked up from the engine.

        Returns:
            Union[UUID, Any]: The handled value. Object instance if auto_loading or if value is already an object, otherwise the UUID.        
        """

        # Handle Weaviate UUID conversion and polymorphic wrapping
        # For polymorphic references: only treat as (object_or_uuid, type_name) tuple if second element is a string (type name)
        if isinstance(input_value, tuple) and len(input_value) == 2 and isinstance(input_value[1], str):
            # Polymorphic reference: (object_or_uuid, type_name)
            value, type_name = input_value
            
            # If it's already an object instance, return it directly
            if not isinstance(value, (UUID, _WeaviateUUIDInt)):
                return value
            
            # Convert Weaviate UUID if needed
            value = self._handle_weaviate_uuid(value)
            
            if self.auto_loading:
                # Get the concrete class using type_name from engine
                try:
                    concrete_class = self._get_target_class(collection_name=type_name)
                    loaded = concrete_class.get(value)
                    # If auto-loading fails (object not in database yet), return the UUID
                    return loaded if loaded is not None else value
                except ValueError:
                    raise ValueError(f"Type '{type_name}' not found in engine models. Cannot auto-load.")
            else:
                return value
        else:
            # Monomorphic reference: just UUID or object
            value = self._handle_weaviate_uuid(input_value)

            # If it's already an object instance, return it directly
            if not isinstance(value, (UUID, _WeaviateUUIDInt)):
                return value

            if self.auto_loading:
                # Get target_class if not provided
                if target_class is None:
                    target_class = self._get_target_class()
                
                loaded = target_class.get(value)
                # If auto-loading fails (object not in database yet), return the UUID
                return loaded if loaded is not None else value

            return value

    def _handling_lists(self, instance, input_value):
        """
        Handle the input value for the reference field. Processes both monomorphic (UUID) 
        and polymorphic ((uuid, type) tuples) values.
        
        Ensures correct reference type (SINGLE vs LIST), handles auto-loading, and 
        unwraps polymorphic values to return UUIDs when appropriate.

        Args:
            instance: The instance of the class.
            input_value: The value to handle (UUID, object, or tuple for polymorphic).

        Raises:
            ValueError: If the reference field is a single reference but multiple values are provided.
        """

        if isinstance(input_value, list) and self.reference_type == Reference_Type.SINGLE:
            if len(input_value) > 1:
                raise ValueError(f"Reference field '{self.name}' is a single reference but got multiple values: {input_value}")
            elif len(input_value) == 1 and input_value[0] is not None:
                value = input_value[0]
            elif len(input_value) == 1 and input_value[0] is None:
                value = None
            elif len(input_value) == 0:
                value = None
        else:
            value = input_value

        # Provide target_class for auto_loading (only used in monomorphic mode)
        target_class = None
        if self.auto_loading and not self._is_polymorphic:
            target_class = self._get_target_class()

        if value == [] or value is None:
            value = None

        elif isinstance(value, list):
            # Handle the list of references
            for i, v in enumerate(value):
                # Handle UUID, auto_loading, and polymorphic unwrapping
                value[i] = self._handle_auto_loading(v, target_class=target_class)
        else:
            # Handle single reference
            value = self._handle_auto_loading(value, target_class=target_class)

        # For non-polymorphic reads, unwrap any tuples (shouldn't happen, but defensive)
        if not self._is_polymorphic:
            value = self._unwrap_polymorphic_value(value)

        return value
    
