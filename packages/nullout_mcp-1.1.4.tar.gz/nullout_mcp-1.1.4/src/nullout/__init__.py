"""NullOut — MCP server for removing undeletable files on Windows."""

__version__ = "1.1.4"
