# sage_setup: distribution = sagemath-m4ri-m4rie

from sage.all__sagemath_m4ri_m4rie import *
