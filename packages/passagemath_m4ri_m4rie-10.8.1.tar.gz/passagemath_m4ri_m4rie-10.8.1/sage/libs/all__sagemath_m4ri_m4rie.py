# sage_setup: distribution = sagemath-m4ri-m4rie
