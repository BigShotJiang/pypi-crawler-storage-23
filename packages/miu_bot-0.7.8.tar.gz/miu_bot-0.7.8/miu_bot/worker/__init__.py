"""Hatchet worker module for distributed message processing."""
