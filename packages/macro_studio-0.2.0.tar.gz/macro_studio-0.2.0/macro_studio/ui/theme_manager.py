import os
import sys
from string import Template


class ThemeManager:
    # Define palettes as Python dictionaries
    DARK_THEME = {
        # --- Core UI ---
        "bg_primary": "#1e1e1e",  # Main window background
        "bg_secondary": "#252526",  # Tables/Input fields
        "text_primary": "#e0e0e0",  # Main text
        "text_light": "#ffffff",  # Bright text (Buttons/Headers)
        "border_color": "#333333",  # Generic borders

        # --- Generic Buttons ---
        "btn_bg": "#3b3b3b",
        "btn_hover": "#454545",
        "btn_press": "#2a2a2a",
        "btn_border": "#555555",
        "btn_border_h": "#666666",  # Hover border

        # -- Generic Stuff ---
        "selection_color": "#394873",
        "selected_color": "#1158c7",
        "selected_hover": "#007FF4",

        # --- Functional Buttons (Start/Stop/Etc) ---
        "btn_pick_bg": "#264f78",  # Navy
        "btn_pick_hover": "#3a6ea5",

        # --- Table Widget ---
        "header_bg": "#242633",
        "header_text": "#cccccc",

        # --- Console ---
        "alt_bg": "#101010",  # Slightly darker than main bg
        "console_text": "#f0f0f0",
    }

    LIGHT_THEME = {
        # --- Core UI ---
        "bg_primary": "#f3f3f3",  # Light gray window background
        "bg_secondary": "#ffffff",  # Pure white for tables/inputs
        "text_primary": "#333333",  # Dark gray text
        "text_light": "#000000",  # Black text (for buttons)
        "border_color": "#d0d0d0",  # Light borders

        # --- Generic Buttons ---
        "btn_bg": "#ffffff",  # White buttons
        "btn_hover": "#e6e6e6",  # Light gray hover
        "btn_press": "#d0d0d0",
        "btn_border": "#cccccc",
        "btn_border_h": "#a0a0a0",

        # -- Generic Labels ---
        "selection_color": "#cce8ff",
        "selected_color": "#1158c7",
        "selected_hover": "#007FF4",

        # --- Functional Buttons ---
        "btn_pick_bg": "#d0e8ff",  # Very Light Blue (so black text is readable)
        "btn_pick_hover": "#b3d7ff",

        # --- Table Widget ---
        "header_bg": "#e1e1e1",
        "header_text": "#000000",

        # --- Console ---
        "alt_bg": "#fafafa",  # Almost white
        "console_text": "#24292f"
    }

    @staticmethod
    def applyTheme(app, palette_name="DARK"):
        palette_dict = ThemeManager.DARK_THEME if palette_name == "DARK" else ThemeManager.LIGHT_THEME

        current_dir = os.path.dirname(os.path.abspath(__file__))
        template_path = os.path.join(current_dir, "templates", "style_template.qss")

        if hasattr(sys, '_MEIPASS'):
            template_path = os.path.join(sys._MEIPASS, "ui", "templates", "style_template.qss")

        try:
            with open(template_path, "r", encoding="utf-8") as f:
                content = f.read()
        except FileNotFoundError:
            print(f"CRITICAL ERROR: Could not find style at {template_path}")
            content = ""

        src = Template(content)
        final_style = src.safe_substitute(**palette_dict)

        app.setStyleSheet(final_style)