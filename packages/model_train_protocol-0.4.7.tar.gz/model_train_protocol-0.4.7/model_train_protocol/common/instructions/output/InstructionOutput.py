from typing import List, Union

from .BaseOutput import BaseOutput
from ...tokens.FinalNumToken import FinalNumToken
from ...tokens.FinalToken import FinalToken
from ...tokens.TokenSet import TokenSet, Snippet
from model_train_protocol.errors import OutputError, OutputTypeError


class InstructionOutput(BaseOutput):
    """Defines the output of Instructions."""

    def __init__(self, tokenset: TokenSet, final: FinalToken | List[FinalToken] | None = None):
        """
        Initializes a Response instance.

        :param tokenset: The TokenSet associated with the model's response. Not used in
        :param final: A FinalToken or list of FinalToken designating the allowed final action by the model.
        """
        super().__init__(tokenset=tokenset, final=final)

    def validate_sample(self, snippet: Snippet, value: Union[int, float, None],
                        final: FinalToken | None):
        """
        Validates the snippet against the response definition.

        :param snippet: The snippet to validate.
        :param value: The value of the Snippet to validate if Snippet has a NumToken.
        :param final: The FinalToken to validate.
        """
        if not isinstance(snippet, Snippet):
            raise OutputTypeError(f"Snippet must be an instance of Snippet. Got: {type(snippet)}")

        if not final in self.final:
            raise OutputError(
                f"FinalToken {final} is not added to the Response final tokens. Allowed finals: {self.final}")

        if not isinstance(final, FinalToken):
            raise OutputTypeError(f"Final must be an instance of FinalToken. Got: {type(final)}")

        if isinstance(final, FinalNumToken):
            if value is None:
                raise OutputError(f"FinalToken {final} requires a numeric value, but none was provided.")

            if not isinstance(value, Union[int, float]):
                raise OutputTypeError(f"Value must be an int or float. Got: {type(value)}")

            final.validate_number(number=value)
