# Changelog

All notable changes to the official BIGHUB Python SDK are documented in this file.

The format is based on Keep a Changelog and this project uses Semantic Versioning.

## [Unreleased]

- No unreleased entries at this time.

## [0.2.1] - 2026-02-28

### Changed

- Updated `README.md` to improve first-run developer experience:
  - moved Sync/Async quickstarts near the top (right after install)
  - added direct PyPI links for `bighub` and `bighub-openai`
  - consolidated Provider Adapter guidance to a single clear runtime integration reference.
- Updated documentation examples to align with the current adapter release:
  - replaced stale `bighub-openai@0.1.0` references with `bighub-openai@0.2.0`
  - kept recommendation preview/apply examples aligned with optimistic locking usage.

## [0.2.0] - 2026-02-27

### Added

- Future Memory client coverage for production feedback loops:
  - `actions.ingest_memory(...)`
  - `actions.memory_context(...)`
  - `actions.refresh_memory_aggregates(...)`
  - `actions.memory_recommendations(...)`
- Policy recommendation compatibility fields documented and supported end-to-end:
  - `recommendation_id`, `scope`, `time_window_hours`
  - `target_rule_id` or `rule_selector`
  - `suggested_policy_patch` (JSON Patch envelope)
  - `apply_endpoint` for one-click UX.
- Optimistic concurrency workflow support for rules patching:
  - `RuleResponse.version` typing
  - preview/apply flow with version token usage.
- Expanded webhook/event interoperability in docs and typed surfaces:
  - `rule.patch_previewed`
  - `rule.patch_applied`
  - `decision_event.created`
  - approval lifecycle events.
- Documentation refresh aligned with control-plane positioning:
  - Architecture section
  - Policy Intelligence section
  - Provider Adapters section
  - preview-first safe apply examples.

### Changed

- Migration note: `rules.version` is required server-side for atomic optimistic locking
  (introduced via backend rules-version migration).
  If your backend is older, `apply_patch` optimistic locking may return `409`
  conflicts unexpectedly or be unavailable.
- `rules.apply_patch(...)` (sync + async) now accepts either:
  - raw JSON Patch ops list, or
  - wrapped payload `{ "format": "json_patch", "ops": [...] }`.
- `rules.apply_patch(...)` now supports optimistic locking inputs:
  - `if_match_version`
  - `if_match` (If-Match header passthrough).
- Recommended patch flow updated to explicit two-step safety:
  - `preview=True`
  - then `preview=False` with returned version token.

### Removed

- `if_match_updated_at` support in `rules.apply_patch(...)` has been removed in favor of version/ETag-based concurrency.

## [0.1.0] - 2026-02-26

### Added

- First institutional-grade SDK baseline (sync + async clients).
- Public clients: `BighubClient`, `AsyncBighubClient`.
- Resources:
  - `actions`: submit, submit_v2, dry_run, verify_validation, observer_stats, dashboard_summary, status
  - `auth`: signup, login, refresh, logout
  - `rules`: create, list, get, update, delete, pause, resume, dry_run, validate, validate_dry_run, domains, versions, purge_idempotency
  - `kill_switch`: status, activate, deactivate
  - `events`: list, stats
  - `approvals`: list, resolve
  - `api_keys`: create, list, delete/revoke, rotate, validate, scopes
  - `webhooks`: create, list, get, update, delete, deliveries, test, list_events, verify_signature, replay_failed_delivery
- Retry/backoff transport, auth headers, typed exceptions.
- Webhook signature verification helper.
- Reliability: timeout configuration, transient retry (429/5xx/network), Idempotency-Key forwarding.
- DX baseline for 0.1.0: stronger `TypedDict` coverage, ergonomic dataclass payload models, and overloaded method signatures (dict or model), including partial update models for rules/webhooks.
- Basic test suite for sync/async paths.

