import os


cli_root_path = os.path.dirname(__file__)
