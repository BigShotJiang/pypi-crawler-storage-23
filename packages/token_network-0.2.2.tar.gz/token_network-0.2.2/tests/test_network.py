"""Tests for token_network package."""

import pytest
from token_network import network, TokenNetworkError


def test_network_bitcoin_returns_config():
    cfg = network.bitcoin.config
    assert cfg["network_type"] == "UTXO"
    assert cfg["base_token"] == "BTC"
    assert cfg["base_token_decimal"] == 8


def test_network_bitcoin_tokens():
    tokens = network.bitcoin.tokens
    assert len(tokens) >= 1
    btc = next(t for t in tokens if t.token.get("symbol") == "BTC")
    assert btc.native is True
    assert btc.decimal == 8
    assert btc.token["symbol"] == "BTC"
    assert btc["token_info"]["symbol"] == "BTC"


def test_network_bitcoin_to_dict():
    data = network.bitcoin.to_dict()
    assert "config" in data
    assert "tokens" in data
    assert data["config"]["base_token"] == "BTC"


def test_network_bsc_usdt():
    data = network.bsc.usdt
    assert data["network"]["network_type"] == "EVM"
    assert data["token"]["symbol"] == "USDT"
    assert data["contract_address"] == "0x55d398326f99059fF775485246999027B3197955"
    assert data["decimal"] == 18
    assert data["native"] is False


def test_unknown_network_raises():
    with pytest.raises(TokenNetworkError) as exc_info:
        _ = network.nonexistent_chain
    assert "Unknown network" in str(exc_info.value)
    assert "nonexistent_chain" in str(exc_info.value)


def test_unknown_token_on_network_raises():
    with pytest.raises(TokenNetworkError) as exc_info:
        _ = network.bsc.nonexistent_token
    assert "not defined on network" in str(exc_info.value)
    assert "bsc" in str(exc_info.value)


def test_case_insensitive_network():
    assert network.BSC.config == network.bsc.config
    assert network.Bitcoin.config == network.bitcoin.config


def test_case_insensitive_token():
    assert network.bsc.USDT.contract_address == network.bsc.usdt.contract_address
    assert network.ethereum.Usdt["token"]["symbol"] == "USDT"


def test_network_callable():
    """network('bitcoin') returns same as network.bitcoin."""
    bitcoin = network("bitcoin")
    assert bitcoin.decimal == 8
    assert bitcoin.confirmation_number == 2
    assert "config" in bitcoin.__dict__()
    assert bitcoin.config == network.bitcoin.config


def test_network_tokens_are_objects():
    """ethereum.tokens is list of TokenOnNetwork objects with contract_address, __dict__."""
    from token_network import TokenOnNetwork

    ethereum = network("ethereum")
    assert isinstance(ethereum.tokens, list)
    assert all(isinstance(t, TokenOnNetwork) for t in ethereum.tokens)
    usdt = next(t for t in ethereum.tokens if t.token.get("symbol") == "USDT")
    assert usdt.contract_address == "0xdAC17F958D2ee523a2206206994597C13D831ec7"
    assert "contract_address" in usdt.__dict__()


def test_get_token_on_network():
    """get_token_on_network(network=..., token_abbr=...) returns TokenOnNetwork."""
    from token_network import get_token_on_network, TokenOnNetwork

    ton = get_token_on_network(network="ethereum", token_abbr="USDT")
    assert isinstance(ton, TokenOnNetwork)
    assert ton.contract_address == "0xdAC17F958D2ee523a2206206994597C13D831ec7"
    assert ton.__dict__()["contract_address"] == ton.contract_address
