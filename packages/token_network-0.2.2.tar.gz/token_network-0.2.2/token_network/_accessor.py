"""Attribute-based access to network and token config: network.bitcoin, network.bsc.usdt."""

from __future__ import annotations

from typing import Any

from ._loader import load_all


class TokenNetworkError(Exception):
    """Raised when a network or token is unknown or invalid."""


class TokenOnNetwork:
    """
    Represents a token on a specific network (e.g. USDT on Ethereum).
    Use get_token_on_network(network="ethereum", token_abbr="USDT") or network.ethereum.tokens.
    """

    __slots__ = ("_data",)

    def __init__(self, data: dict[str, Any]) -> None:
        self._data = dict(data)

    @property
    def contract_address(self) -> str | None:
        """Contract address for this token on the network (None for native coins)."""
        return self._data.get("contract_address")

    @property
    def decimal(self) -> int:
        """Decimals for this token on this network."""
        return self._data.get("decimal") or self._data.get("decimals", 0)

    @property
    def decimals(self) -> int:
        """Alias for decimal."""
        return self.decimal

    @property
    def native(self) -> bool:
        """True if this is the native coin of the network."""
        return bool(self._data.get("native", False))

    @property
    def network(self) -> dict[str, Any]:
        """Network config dict."""
        return dict(self._data.get("network") or {})

    @property
    def token(self) -> dict[str, Any]:
        """Token info dict (symbol, slug, name, etc.)."""
        return dict(self._data.get("token") or {})

    @property
    def type(self) -> str:
        """'COIN' or 'TOKEN'."""
        return str(self._data.get("type", "TOKEN"))

    def __dict__(self) -> dict[str, Any]:
        """Return all token-on-network data as a dict."""
        return dict(self._data)

    def to_dict(self) -> dict[str, Any]:
        """Return all token-on-network data as a dict (same as __dict__())."""
        return self.__dict__()

    def __getitem__(self, key: str) -> Any:
        """Dict-like access for backward compatibility (e.g. obj['contract_address'])."""
        if key == "token_info":
            return self._data.get("token") or {}
        return self._data[key]


class _NetworkNode:
    """
    Represents one network. Supports .config, .tokens (list of TokenOnNetwork),
    .decimal, .confirmation_number, .__dict__(), and .<token_symbol> (e.g. .usdt).
    """

    __slots__ = ("_net_key", "_network_tokens", "_token_on_network")

    def __init__(
        self,
        net_key: str,
        network_tokens: dict[str, dict[str, Any]],
        token_on_network: dict[tuple[str, str], dict[str, Any]],
    ) -> None:
        self._net_key = net_key
        self._network_tokens = network_tokens
        self._token_on_network = token_on_network

    def _ensure_network(self) -> dict[str, Any]:
        if self._net_key not in self._network_tokens:
            raise TokenNetworkError(f"Unknown network: {self._net_key!r}")
        return self._network_tokens[self._net_key]

    @property
    def config(self) -> dict[str, Any]:
        """Network config for this network."""
        return dict(self._ensure_network()["config"])

    @property
    def decimal(self) -> int:
        """Base token decimal for this network (e.g. 8 for Bitcoin, 18 for Ethereum)."""
        cfg = self.config
        return int(cfg.get("base_token_decimal") or cfg.get("decimal", 0))

    @property
    def confirmation_number(self) -> int:
        """Required number of confirmations for this network."""
        return int(self.config.get("confirmation_number", 0))

    @property
    def tokens(self) -> list[TokenOnNetwork]:
        """List of token objects on this network (TokenOnNetwork with contract_address, etc.)."""
        data = self._ensure_network()
        return [
            TokenOnNetwork(self._token_on_network[(self._net_key, t["token"])])
            for t in data["tokens"]
            if (self._net_key, t["token"]) in self._token_on_network
        ]

    def _tokens_raw(self) -> list[dict[str, Any]]:
        """Raw list of token bindings (dicts). Used for to_dict and backward compatibility."""
        return list(self._ensure_network()["tokens"])

    def __getattr__(self, name: str) -> Any:
        if name.startswith("_"):
            raise AttributeError(name)
        token_sym = name.upper()
        key = (self._net_key, token_sym)
        if key not in self._token_on_network:
            raise TokenNetworkError(
                f"Token {token_sym!r} is not defined on network {self._net_key!r}. "
                f"Available tokens: {[t['token'] for t in self._tokens_raw()]}"
            )
        return TokenOnNetwork(self._token_on_network[key])

    def __dict__(self) -> dict[str, Any]:
        """Return all network data: config plus tokens (each as full dict)."""
        return {
            "config": self.config,
            "tokens": [TokenOnNetwork(self._token_on_network[(self._net_key, t["token"])]).__dict__() for t in self._tokens_raw() if (self._net_key, t["token"]) in self._token_on_network],
        }

    def to_dict(self) -> dict[str, Any]:
        """Return full network data: config and tokens (same as __dict__() for compatibility)."""
        return {"config": self.config, "tokens": self._tokens_raw()}


class NetworkAccessor:
    """
    Attribute-based access to token network config.
    - network.bitcoin  -> network node (use .config, .tokens, or .to_dict() for full config)
    - network.bsc.usdt -> dict with network config, token info, contract_address, decimal, native
    """

    __slots__ = ("_network_tokens", "_token_on_network", "_tokens")

    def __init__(self, testnet: bool = False) -> None:
        self._network_tokens, self._token_on_network, _, self._tokens = load_all(testnet=testnet)

    def get_networks(self) -> list[str]:
        """Return list of all network ids (e.g. ['bitcoin', 'bsc', 'ethereum', ...])."""
        return sorted(self._network_tokens.keys())

    def get_tokens(self) -> list[str]:
        """Return list of all token symbols (e.g. ['AAVE', 'BNB', 'BTC', ...])."""
        return sorted(self._tokens.keys())

    def get_token(self, identifier: str) -> dict[str, Any]:
        """
        Get token object by symbol, slug, or name (case-insensitive).
        Returns the token info dict (slug, symbol, standard_symbol, name, precision, factor).
        Raises TokenNetworkError if not found.
        """
        raw = (identifier or "").strip()
        if not raw:
            raise TokenNetworkError("Token identifier cannot be empty")
        key_upper = raw.upper()
        key_lower = raw.lower()
        if key_upper in self._tokens:
            return dict(self._tokens[key_upper])
        for sym, info in self._tokens.items():
            if (info.get("slug") or "").strip().lower() == key_lower:
                return dict(info)
            if (info.get("name") or "").strip().lower() == key_lower:
                return dict(info)
        raise TokenNetworkError(
            f"Unknown token: {identifier!r}. Known tokens: {self.get_tokens()}"
        )

    def get_network(self, identifier: str) -> dict[str, Any]:
        """
        Get network object by network name/id (case-insensitive).
        Returns dict with "config" (network config) and "tokens" (token bindings on this network).
        Raises TokenNetworkError if not found.
        """
        raw = (identifier or "").strip()
        if not raw:
            raise TokenNetworkError("Network identifier cannot be empty")
        net_key = raw.lower()
        if net_key not in self._network_tokens:
            raise TokenNetworkError(
                f"Unknown network: {identifier!r}. Known networks: {self.get_networks()}"
            )
        data = self._network_tokens[net_key]
        return {"config": dict(data["config"]), "tokens": list(data["tokens"])}

    def get_token_network(self, token_identifier: str, network_identifier: str) -> dict[str, Any]:
        """
        Get token_network config by token (symbol/slug/name) and network name (case-insensitive).
        Returns dict with network config, token info, contract_address, decimal, native.
        Same data as network.bsc.usdt. Raises TokenNetworkError if not found or token not on network.
        """
        token_info = self.get_token(token_identifier)
        symbol = (token_info.get("symbol") or "").strip().upper()
        if not symbol:
            raise TokenNetworkError("Token has no symbol")
        raw_net = (network_identifier or "").strip()
        if not raw_net:
            raise TokenNetworkError("Network identifier cannot be empty")
        net_key = raw_net.lower()
        if net_key not in self._network_tokens:
            raise TokenNetworkError(
                f"Unknown network: {network_identifier!r}. Known networks: {self.get_networks()}"
            )
        key = (net_key, symbol)
        if key not in self._token_on_network:
            tokens_on_net = [t["token"] for t in self._network_tokens[net_key]["tokens"]]
            raise TokenNetworkError(
                f"Token {symbol!r} is not on network {net_key!r}. "
                f"Available on this network: {tokens_on_net}"
            )
        return dict(self._token_on_network[key])

    def __call__(self, name: str) -> _NetworkNode:
        """Return network object by name: bitcoin = network('bitcoin')."""
        raw = (name or "").strip()
        if not raw:
            raise TokenNetworkError("Network name cannot be empty")
        net_key = raw.lower()
        if net_key not in self._network_tokens:
            raise TokenNetworkError(
                f"Unknown network: {name!r}. Known networks: {self.get_networks()}"
            )
        return _NetworkNode(
            net_key,
            self._network_tokens,
            self._token_on_network,
        )

    def __getattr__(self, name: str) -> _NetworkNode:
        if name.startswith("_"):
            raise AttributeError(name)
        net_key = name.lower()
        if net_key not in self._network_tokens:
            known = ", ".join(self.get_networks())
            raise TokenNetworkError(
                f"Unknown network: {name!r}. Known networks: {known}"
            )
        return _NetworkNode(
            net_key,
            self._network_tokens,
            self._token_on_network,
        )

    def get_token_on_network(self, *, network: str, token_abbr: str) -> TokenOnNetwork:
        """
        Get token-on-network object by network and token symbol/slug (e.g. USDT).
        Returns TokenOnNetwork with .contract_address, .__dict__(), etc.
        """
        data = self.get_token_network(token_abbr, network)
        return TokenOnNetwork(data)


# Singleton used as `network`
network = NetworkAccessor()
