# Changelog

## 0.0.4 (2026-02-22)

Full Changelog: [v0.0.3...v0.0.4](https://github.com/machinepulse-ai/karpo-persona-python-sdk/compare/v0.0.3...v0.0.4)

### Chores

* update SDK settings ([bc22516](https://github.com/machinepulse-ai/karpo-persona-python-sdk/commit/bc22516ddea5ac0b08ae05ffcd384311fef07ff7))
* update SDK settings ([91f184c](https://github.com/machinepulse-ai/karpo-persona-python-sdk/commit/91f184c5fdc17ab991efca40d8a5661bc5620344))
* update SDK settings ([20611fc](https://github.com/machinepulse-ai/karpo-persona-python-sdk/commit/20611fc77f3ed4515b246dd9cb85c9aecb8cc44f))

## 0.0.3 (2026-02-22)

Full Changelog: [v0.0.2...v0.0.3](https://github.com/machinepulse-ai/karpo-persona-python-sdk/compare/v0.0.2...v0.0.3)

### Chores

* update SDK settings ([84ac3a0](https://github.com/machinepulse-ai/karpo-persona-python-sdk/commit/84ac3a0bd8a26ea2a7f8fa482bef30682bf871a0))
* update SDK settings ([abb8cca](https://github.com/machinepulse-ai/karpo-persona-python-sdk/commit/abb8ccadae022e3d4aed79a5fcc6aa2f9b11886e))

## 0.0.2 (2026-02-22)

Full Changelog: [v0.0.1...v0.0.2](https://github.com/machinepulse-ai/karpo-persona-python-sdk/compare/v0.0.1...v0.0.2)

### Chores

* configure new SDK language ([1b503a1](https://github.com/machinepulse-ai/karpo-persona-python-sdk/commit/1b503a125c65a6d316f24a887b2382ddf22b5ab7))
* **internal:** remove mock server code ([cfaee1b](https://github.com/machinepulse-ai/karpo-persona-python-sdk/commit/cfaee1b9a8767aa83a9c08dc461604e4509eedb9))
* update mock server docs ([9e865d4](https://github.com/machinepulse-ai/karpo-persona-python-sdk/commit/9e865d4f43503e6e9f41ad91fc69b572f687db5f))
* update SDK settings ([a1a4e97](https://github.com/machinepulse-ai/karpo-persona-python-sdk/commit/a1a4e972236bb640cf71c0fcc8929068d857912f))
* update SDK settings ([fef5671](https://github.com/machinepulse-ai/karpo-persona-python-sdk/commit/fef567136e3033e114c07bd992a21199e2bd72dc))
* update SDK settings ([3adf53a](https://github.com/machinepulse-ai/karpo-persona-python-sdk/commit/3adf53ac590bf64c1f00e85c25a806b98921720a))
