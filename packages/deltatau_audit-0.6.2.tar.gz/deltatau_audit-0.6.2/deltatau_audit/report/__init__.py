from .generator import generate_report as generate_report
