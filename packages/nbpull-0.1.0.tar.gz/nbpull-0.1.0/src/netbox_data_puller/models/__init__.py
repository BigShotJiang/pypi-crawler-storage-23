"""📦 Pydantic models for NetBox IPAM resources."""
