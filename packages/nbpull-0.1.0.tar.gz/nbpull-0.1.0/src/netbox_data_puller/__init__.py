"""🔍 NetBox Data Puller — Read-only CLI for querying NetBox IPAM data."""

__version__ = "0.1.0"
