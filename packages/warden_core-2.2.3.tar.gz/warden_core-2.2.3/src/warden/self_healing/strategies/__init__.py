"""Strategy package — individual strategy modules register themselves on import."""
