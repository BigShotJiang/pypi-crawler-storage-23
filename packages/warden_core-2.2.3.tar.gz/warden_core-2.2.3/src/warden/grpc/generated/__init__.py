"""Generated gRPC code for Warden."""

from .warden_pb2 import *
from .warden_pb2_grpc import *
