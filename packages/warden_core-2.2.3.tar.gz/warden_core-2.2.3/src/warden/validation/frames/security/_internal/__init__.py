"""Internal implementation details for SecurityFrame.

These check classes are implementation details and should not be imported directly.
Use SecurityFrame instead.
"""
