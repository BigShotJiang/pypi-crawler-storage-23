"""Fortification infrastructure module."""
