"""Allow running Zimi as a module: python -m zimi serve --port 8899"""

from zimi.server import main

main()
