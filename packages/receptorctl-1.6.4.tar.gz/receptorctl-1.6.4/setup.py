# This file is only used by our downstream RPM builds.
# Remove this once that tooling has been updated to work with setup.cfg.

import setuptools

if __name__ == "__main__":
    setuptools.setup()
