
# E2E API Optimization Test Report

**Date:** 2026-03-06T14:55:53.610540+00:00
**Config:** `ci/e2e-ci-config.yaml`
**Waldur:** http://docker:8080/api/
**Backend:** SLURM emulator
**Offering:** e2ef0000000000000000000000000001
**Components:** cpu (factor=60000.0), ram (factor=61440.0)


## Benchmark: CREATE order processing

API calls: **26**
Order state: `done`

## Benchmark: UPDATE order processing

API calls: **10**
Order state: `done`

## Benchmark: TERMINATE order processing

API calls: **10**
Order state: `done`

## Benchmark: Membership sync

API calls: **10**

## Benchmark: Usage reporting

API calls: **13**

## Multi-resource benchmark: setup (5 resources)

Submitted **5** orders in 0.8s
Processed in **1** cycles, 28.1s
Created **5** / 5 resources successfully.

## Multi-resource benchmark: membership sync (5 resources)

Resources: **5**
API calls: **28** (per resource: 5.6)
Response bytes: **10353** (per resource: 2071)
Duration: **20.0s**

## Multi-resource benchmark: reporting (5 resources)

Resources: **5**
API calls: **33** (per resource: 6.6)
Response bytes: **59398** (per resource: 11880)
Duration: **7.5s**

## Multi-resource benchmark: cleanup

Terminated **5** / 5 resources.

## API Call Summary

| Test | API Calls | Response Size |
|------|-----------|---------------|
| TestBenchmarkOrderProcessing::test_01_create | 30 | 68.4 KB |
| TestBenchmarkOrderProcessing::test_02_update | 11 | 24.9 KB |
| TestBenchmarkOrderProcessing::test_03_terminate | 11 | 23.6 KB |
| TestBenchmarkMembershipSync::test_01_sync | 13 | 13.1 KB |
| TestBenchmarkReporting::test_01_setup_resource | 25 | 50.6 KB |
| TestBenchmarkReporting::test_02_report | 16 | 29.3 KB |
| TestMultiResourceBenchmark::test_01_create_resources | 93 | 188.8 KB |
| TestMultiResourceBenchmark::test_02_membership_sync | 31 | 16.1 KB |
| TestMultiResourceBenchmark::test_03_reporting | 36 | 64.0 KB |
| TestMultiResourceBenchmark::test_04_cleanup | 35 | 80.5 KB |
| **TOTAL** | **301** | **559.3 KB** |
