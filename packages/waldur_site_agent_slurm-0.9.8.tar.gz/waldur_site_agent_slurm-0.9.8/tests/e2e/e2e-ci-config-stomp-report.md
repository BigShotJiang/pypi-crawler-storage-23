
# E2E STOMP Test Report

**Date:** 2026-03-06T14:57:43.797895+00:00
**Config:** `ci/e2e-ci-config-stomp.yaml`
**Waldur:** http://docker:8080/api/
**Backend:** SLURM emulator
**Offering:** e2ef0000000000000000000000000001


## API Call Summary

| Test | API Calls | Response Size |
|------|-----------|---------------|
| **TOTAL** | **0** | **0 B** |
