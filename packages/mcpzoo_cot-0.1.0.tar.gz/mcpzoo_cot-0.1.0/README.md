# mcpzoo-cot

> 思维链 — 生成思维链推理的提示词模板

## Installation

```bash
uvx mcpzoo-cot
```

## uvx JSON

```json
{
  "mcpServers": {
    "cot": {
      "args": ["mcpzoo-cot"],
      "command": "uvx"
    }
  }
}
```
