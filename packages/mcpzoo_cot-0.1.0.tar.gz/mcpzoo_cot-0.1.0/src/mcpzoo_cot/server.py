from mcp.server.fastmcp import FastMCP

mcp = FastMCP("cot")

@mcp.tool()
def gen_cot(question: str) -> str:
    """生成思维链（Chain of Thought）推理的提示词模板。"""
    prompt = f"问题：\n{question}\n\n"
    prompt += "解决这个问题的要求：\n"
    prompt += "1. 请不要直接给出最终答案。\n"
    prompt += "2. 请一步一步地写下你的思考过程。\n"
    prompt += "3. 对每一步的推理进行说明。\n"
    prompt += "4. 最后在思考结束时，给出明确的最终结论。\n\n"
    prompt += "请开始你的思考："
    return prompt

def main():
    mcp.run()

if __name__ == "__main__":
    main()
