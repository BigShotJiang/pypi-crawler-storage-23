import json
import os
import random
from name_generator.definitions.enums import DefaultValue, DefaultType


class NameGenerator:
    def __init__(self):
        self._data = None
        self._load_data()

    def _load_data(self):
        base_dir = os.path.dirname(os.path.abspath(__file__))
        json_dir = os.path.join(base_dir, "statics", "proper_words.json")

        try:
            with open(json_dir, "r", encoding="utf-8") as f:
                self._data = json.load(f)
        except FileNotFoundError:
            raise FileNotFoundError(f"File not found:{json_dir}")

    def get_words(self, type: str) -> list:
        if not self._data:
            self._load_data()

        if type == DefaultType.ADJECTIVE.value:
            default_value = [DefaultValue.ADJECTIVE.value]
        elif type == DefaultType.NOUN.value:
            default_value = [DefaultValue.NOUN.value]
        else:
            default_value = []

        return self._data.get(type, default_value)

    def filter_words_by_length(self, type: str, length: int) -> list:
        return [word for word in self.get_words(type) if len(word) <= length]


_generator = NameGenerator()


def get_random_name() -> str:
    adjectives = _generator.filter_words_by_length(DefaultType.ADJECTIVE.value, 9)
    nouns = _generator.filter_words_by_length(DefaultType.NOUN.value, 10)

    first_name = random.choice(adjectives + nouns)
    last_name = random.choice(nouns)

    return f"{first_name} {last_name}"


def get_random_word(type: DefaultType) -> str:
    word_list = _generator.get_words(type.value)

    return random.choice(word_list)


if __name__ == "__main__":
    for _ in range(10):
        print(get_random_word(DefaultType.NOUN))
