from enum import Enum


class DefaultValue(Enum):
    ADJECTIVE = "Amazing"
    NOUN = "Koconut"


class DefaultType(Enum):
    ADJECTIVE = "adjectives"
    NOUN = "nouns"
