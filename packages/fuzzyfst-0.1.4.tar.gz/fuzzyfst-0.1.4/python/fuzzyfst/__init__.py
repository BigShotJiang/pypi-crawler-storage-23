"""FuzzyFST: Fast fuzzy string search using finite state transducers."""

from fuzzyfst._fuzzyfst import Fst, build

__all__ = ["Fst", "build"]
