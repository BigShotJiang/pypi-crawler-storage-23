"""plane-cli: A command-line interface for Plane.so project management."""

__version__ = "0.1.0"
