/**
 * 通用工具函数
 * 存放不依赖其他业务逻辑的纯工具函数，避免循环引用
 */

/**
 * 获取Cookie值
 * @param {string} name - Cookie名称
 * @returns {string|null} Cookie值，如果不存在则返回null
 */
export function getCookie(name) {
  const cookies = document.cookie.split(";");
  for (let cookie of cookies) {
    const trimmedCookie = cookie.trim();
    const equalIndex = trimmedCookie.indexOf("=");
    if (equalIndex === -1) continue;
    const key = trimmedCookie.substring(0, equalIndex);
    const value = trimmedCookie.substring(equalIndex + 1);
    if (key === name) {
      return value;
    }
  }
  return null;
}
