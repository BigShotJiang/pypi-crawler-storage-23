import { app } from "../../scripts/app.js";
import { ensureConfigLoaded } from "./hookLoad/configLoader.js";

const loadNodeList = [
  "LoadImage",
  "LoadImageMask",
  "LoadAudio",
  "LoadVideo",
  "Load3D",
  "VHS_LoadVideo",
  "VHS_LoadAudioUpload",
];
const extMap = {
  LoadImage: ".png,.jpg,.jpeg,.webp,.gif,.svg,.ico,.bmp,.tiff,.tif,.heic,.heif",
  LoadImageMask:
    ".png,.jpg,.jpeg,.webp,.gif,.svg,.ico,.bmp,.tiff,.tif,.heic,.heif",
  LoadAudio: ".mp3,.wav,.ogg,.m4a,.aac,.flac,.wma,.m4r",
  LoadVideo: ".mp4,.mov,.avi,.mkv,.webm,.flv,.wmv,.m4v",
  Load3D: ".glb,.gltf,.fbx,.obj,.dae,.ply,.stl",
  VHS_LoadAudioUpload: ".mp3,.wav,.ogg,.m4a,.aac,.flac,.wma,.m4r",
  VHS_LoadVideo: ".mp4,.mov,.avi,.mkv,.webm,.flv,.wmv,.m4v",
};

export const hideWidget = (node, widget_name) => {
  const widget = node.widgets.find((widget) => widget.name === widget_name);
  if (!widget) {
    return;
  }
  const originalComputeSize = widget.computeSize;
  const originalType = widget.type;

  widget.computeSize = () => [0, -4];
  widget.type = "hidden";
  widget.hidden = true;
  widget.options = widget.options || {};
  widget.show = () => {
    widget.computeSize = originalComputeSize;
    widget.type = originalType;
    widget.height = undefined;
  };
};
export const computeIsLoadNode = (nodeName) => {
  return loadNodeList.includes(nodeName);
};
export const computeExt = (nodeName) => {
  return extMap[nodeName] || "";
};
/**
 * 判断节点名是否为模型加载类（不包含 bizyair）
 * @param {string} nodeName
 * @returns {boolean}
 */
function isModelLoaderType(nodeName) {
  // 1) 触发AI模型节点配置加载并检查缓存
  if (ensureConfigLoaded("aiModel", nodeName)) {
    return false;
  }

  // 2) 触发模型节点配置加载并检查缓存
  if (ensureConfigLoaded("node", nodeName)) {
    return true;
  }

  // 3) 正则补充：如 XxxLoader => Xxx（立即返回，不等待API）
  const regex = /^(\w+).*Loader.*/i;
  return regex.test(nodeName);
}

/**
 * 处理 graphData.output
 * @param {Object} output - graphData.output 对象
 * @returns {Object} 处理后的新对象
 */
export function processGraphOutput(output) {
  const newOutput = JSON.parse(JSON.stringify(output));
  for (const key in newOutput) {
    const node = newOutput[key];
    // 1. 如果 class_type 在 loadNodeList 里，删除 inputs.image_name
    if (
      loadNodeList.includes(node.class_type) &&
      node.inputs &&
      node.inputs.image_name !== undefined
    ) {
      delete node.inputs.image_name;
    }
    if (isModelLoaderType(node.class_type) && !node.is_load_field) {
      delete newOutput[key];
    }
  }
  return newOutput;
}

/**
 * 检测节点是否包含model输入（计费节点判断）
 * @param {Object} node - 节点对象
 * @returns {boolean} 如果节点包含model输入则返回true，否则返回false
 */
export function hasModelInput(node) {
  if (node._bizyairHiddenOutput) {
    return node._bizyairHiddenOutput;
  }
  const localized_name = "bizyair_model_name";
  if (!node.outputs || node.outputs.length === 0) {
    return null;
  }
  return node.outputs.find((item) => item.name === localized_name);
}

/**
 * 通用的节点meta处理函数
 * 遍历所有运行时节点，对每个节点的_meta对象执行处理函数
 * @param {Function} processor - 处理函数，接收(runtimeNode, meta)参数
 * @param {Object} graph - 可选的graph对象，如果不传则内部获取
 * @returns {Promise<Object>} 返回处理后的graph.output对象
 */
export async function processNodeMeta(processor, graph = null) {
  // 如果没有传入graph，则获取graph对象
  if (!graph) {
    graph = await app.graphToPrompt();
  }

  // 从运行时graph获取所有节点
  if (
    !app ||
    !app.graph ||
    !app.graph._nodes ||
    typeof processor !== "function"
  ) {
    return graph.output;
  }

  // 遍历所有运行时节点
  app.graph._nodes.forEach((runtimeNode) => {
    const nodeId = String(runtimeNode.id);
    // 确保output中存在该节点
    if (graph.output[nodeId]) {
      // 确保_meta对象存在
      if (!graph.output[nodeId]._meta) {
        graph.output[nodeId]._meta = {};
      }

      // 执行处理函数
      processor(runtimeNode, graph.output[nodeId]._meta);
    }
  });

  return graph.output;
}
