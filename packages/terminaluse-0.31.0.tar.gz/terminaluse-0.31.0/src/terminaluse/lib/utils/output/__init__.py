"""Composable output processing utilities for CLI display.

This module provides:
- Filter system for removing unwanted content (metadata, system prompts, etc.)
- Text extractors for polymorphic outputs
- Formatters for tool requests and responses

Example:
    from terminaluse.lib.utils.output import ToolRequestFormatter, ToolOutputFormatter

    request_fmt = ToolRequestFormatter(verbose=False)
    response_fmt = ToolOutputFormatter(verbose=False)

    formatted_request = request_fmt.format("read_file", '{"path": "/foo/bar.txt"}')
    formatted_response = response_fmt.format(tool_output)

For custom filtering:
    from terminaluse.lib.utils.output import FilterPipeline, RegexRemoveFilter

    custom_pipeline = FilterPipeline([
        RegexRemoveFilter(my_pattern),
    ])
    formatter = ToolOutputFormatter(filter_pipeline=custom_pipeline)
"""

from .defaults import (
    CLI_TOOL_RESPONSE_FILTERS,
    METADATA_HINTS,
    METADATA_LINE_PREFIXES,
    is_not_metadata_hint,
    is_not_metadata_line,
)
from .extractors import extract_text
from .filters import (
    BlockRemoveFilter,
    FilterPipeline,
    LineFilter,
    LinePrefixStripFilter,
    OutputFilter,
    RegexRemoveFilter,
    RegexSubstituteFilter,
)
from .formatters import ToolOutputFormatter, ToolRequestFormatter, clean_lines
from .handlers import (
    DefaultOutputHandler,
    OutputHandler,
    RequestHandler,
    TaskOutputHandler,
    TaskRequestHandler,
    default_output_handlers,
    default_request_handlers,
)

__all__ = [
    # Filters
    "OutputFilter",
    "RegexRemoveFilter",
    "RegexSubstituteFilter",
    "LineFilter",
    "LinePrefixStripFilter",
    "BlockRemoveFilter",
    "FilterPipeline",
    # Defaults
    "CLI_TOOL_RESPONSE_FILTERS",
    "METADATA_LINE_PREFIXES",
    "METADATA_HINTS",
    "is_not_metadata_line",
    "is_not_metadata_hint",
    # Extractors
    "extract_text",
    # Formatters
    "ToolRequestFormatter",
    "ToolOutputFormatter",
    "clean_lines",
    # Handlers
    "RequestHandler",
    "OutputHandler",
    "TaskRequestHandler",
    "TaskOutputHandler",
    "DefaultOutputHandler",
    "default_request_handlers",
    "default_output_handlers",
]
