import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Optional

from kopipasta.file import read_file_contents


def read_env_file() -> Dict[str, str]:
    """Reads .env file from the current directory."""
    env_vars = {}
    if os.path.exists(".env"):
        try:
            with open(".env", "r", encoding="utf-8") as env_file:
                for line in env_file:
                    line = line.strip()
                    if line and not line.startswith("#"):
                        if "=" in line:
                            key, value = line.split("=", 1)
                            key = key.strip()
                            value = value.strip()
                            if value:
                                env_vars[key] = value
        except Exception as e:
            print(f"Warning: Could not read .env file: {e}")
    return env_vars


def read_gitignore() -> List[str]:
    """Reads .gitignore and returns a list of patterns."""
    default_ignore_patterns = [
        ".git",
        "node_modules",
        "venv",
        ".venv",
        "dist",
        ".idea",
        "__pycache__",
        "*.pyc",
        ".ruff_cache",
        ".mypy_cache",
        ".pytest_cache",
        ".vscode",
        ".vite",
        ".terraform",
        "output",
        "poetry.lock",
        "package-lock.json",
        ".env",
        "*.log",
        "*.bak",
        "*.swp",
        "*.swo",
        "*.tmp",
        "tmp",
        "temp",
        "logs",
        "build",
        "target",
        ".DS_Store",
        "Thumbs.db",
    ]
    gitignore_patterns = default_ignore_patterns.copy()

    if os.path.exists(".gitignore"):
        print(".gitignore detected.")
        try:
            with open(".gitignore", "r", encoding="utf-8") as file:
                for line in file:
                    line = line.strip()
                    if line and not line.startswith("#"):
                        gitignore_patterns.append(line)
        except Exception as e:
            print(f"Warning: Could not read .gitignore: {e}")

    return gitignore_patterns


def get_global_profile_path() -> Path:
    """Returns the path to the global user profile (AI Identity)."""
    config_home = os.environ.get("XDG_CONFIG_HOME")
    if config_home:
        return Path(config_home) / "kopipasta" / "ai_profile.md"
    else:
        return Path.home() / ".config" / "kopipasta" / "ai_profile.md"


def read_global_profile() -> Optional[str]:
    """Reads the global profile content."""
    config_path = get_global_profile_path()
    if config_path.exists():
        result: Optional[str] = read_file_contents(str(config_path))
        return result
    return None


def get_active_project_pointer_path() -> Path:
    """Returns the path to the active project pointer file."""
    config_home = os.environ.get("XDG_CONFIG_HOME")
    if config_home:
        path = Path(config_home) / "kopipasta"
    else:
        path = Path.home() / ".config" / "kopipasta"

    path.mkdir(parents=True, exist_ok=True)
    return path / "active_project"


def set_active_project(project_path: Path) -> None:
    """Writes the active project path to the pointer file."""
    pointer = get_active_project_pointer_path()
    try:
        pointer.write_text(str(project_path.resolve()), encoding="utf-8")
    except Exception as e:
        print(f"Warning: Could not write active project pointer: {e}")


def get_active_project() -> Optional[Path]:
    """Reads the active project path from the pointer file."""
    pointer = get_active_project_pointer_path()
    if pointer.exists():
        try:
            content = pointer.read_text(encoding="utf-8").strip()
            if content:
                return Path(content)
        except Exception:
            pass
    return None


def open_profile_in_editor():
    """Opens the global profile in the default editor, creating it if needed."""
    config_path = get_global_profile_path()

    if not config_path.exists():
        config_path.parent.mkdir(parents=True, exist_ok=True)
        default_content = (
            "# Global AI Profile\n"
            "This file is injected into the top of every prompt.\n"
            "Use it for your identity and global preferences.\n\n"
            "- I am a Senior Python Developer.\n"
            "- I prefer functional programming patterns where possible.\n"
            "- I use VS Code on MacOS.\n"
            "- Always type annotate Python code.\n"
        )
        try:
            with open(config_path, "w", encoding="utf-8") as f:
                f.write(default_content)
            print(f"Created new profile at: {config_path}")
        except IOError as e:
            print(f"Error creating profile: {e}")
            return

    editor = os.environ.get("EDITOR", "code" if shutil.which("code") else "vim")

    if sys.platform == "win32":
        os.startfile(config_path)
    elif sys.platform == "darwin":
        subprocess.call(("open", config_path))
    else:
        subprocess.call((editor, config_path))


def read_project_context(project_root: str) -> Optional[str]:
    """Reads AI_CONTEXT.md from project root."""
    path = os.path.join(project_root, "AI_CONTEXT.md")
    if os.path.exists(path):
        result: Optional[str] = read_file_contents(path)
        return result
    return None


def read_session_state(project_root: str) -> Optional[str]:
    """Reads AI_SESSION.md from project root."""
    path = os.path.join(project_root, "AI_SESSION.md")
    if os.path.exists(path):
        result: Optional[str] = read_file_contents(path)
        return result
    return None
