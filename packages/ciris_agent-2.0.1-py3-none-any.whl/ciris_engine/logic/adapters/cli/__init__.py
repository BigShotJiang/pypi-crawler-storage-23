from .adapter import CliPlatform

Adapter = CliPlatform
