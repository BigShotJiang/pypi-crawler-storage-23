from .adapter import DiscordPlatform

Adapter = DiscordPlatform
