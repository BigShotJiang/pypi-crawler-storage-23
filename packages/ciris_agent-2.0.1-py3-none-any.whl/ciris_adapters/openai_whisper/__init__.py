"""
OpenaiWhisper Adapter - Converted from CIRIS adapter: openai-whisper

Local speech-to-text with the Whisper CLI (no API key).

Original source: /home/emoore/clawdbot_lessons/clawdbot/skills/openai-whisper/SKILL.md
"""

from .adapter import OpenaiWhisperAdapter
from .service import OpenaiWhisperToolService

# Export as Adapter for load_adapter() compatibility
Adapter = OpenaiWhisperAdapter

__all__ = [
    "Adapter",
    "OpenaiWhisperAdapter",
    "OpenaiWhisperToolService",
]
