"""
Sag Adapter - Converted from CIRIS adapter: sag

ElevenLabs text-to-speech with mac-style say UX.

Original source: /home/emoore/clawdbot_lessons/clawdbot/skills/sag/SKILL.md
"""

from .adapter import SagAdapter
from .service import SagToolService

# Export as Adapter for load_adapter() compatibility
Adapter = SagAdapter

__all__ = [
    "Adapter",
    "SagAdapter",
    "SagToolService",
]
