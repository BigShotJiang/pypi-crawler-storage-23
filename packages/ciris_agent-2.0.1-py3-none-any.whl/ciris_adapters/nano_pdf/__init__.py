"""
NanoPdf Adapter - Converted from CIRIS adapter: nano-pdf

Edit PDFs with natural-language instructions using the nano-pdf CLI.

Original source: /home/emoore/clawdbot_lessons/clawdbot/skills/nano-pdf/SKILL.md
"""

from .adapter import NanoPdfAdapter
from .service import NanoPdfToolService

# Export as Adapter for load_adapter() compatibility
Adapter = NanoPdfAdapter

__all__ = [
    "Adapter",
    "NanoPdfAdapter",
    "NanoPdfToolService",
]
