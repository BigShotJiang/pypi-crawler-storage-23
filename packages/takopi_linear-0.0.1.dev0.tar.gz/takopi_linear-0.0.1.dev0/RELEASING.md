# Releasing `takopi-linear`

Publishing is automated via GitHub Actions: `.github/workflows/release.yml` runs on pushed tags that match `v*`.

## One-time setup (first PyPI release)

1. Create a PyPI account.
2. Create a PyPI API token.
3. Add the token to GitHub as `PYPI_API_TOKEN` (repo Settings → Secrets and variables → Actions).

After the first release creates the project on PyPI, you can optionally switch to PyPI **Trusted Publishing** (OIDC)
and remove the token secret.

## Release checklist

1. Pick a version (for early “name-claim” releases, consider `0.0.x`, a dev release like `0.0.1.dev0`, or a pre-release like `0.1.0a1`).
2. Update versions in:
   - `pyproject.toml`
   - `src/takopi_linear/__init__.py`
3. Validate locally:
   - `uv run --extra test pytest`
   - `uv build`
   - `uvx twine check dist/*`
4. Tag and push (must match the version in `pyproject.toml`):
   - `git tag v<version>`
   - `git push origin v<version>`
5. Confirm the GitHub Actions “Release” workflow published on PyPI and created a GitHub Release.

## Notes

- PyPI does not allow overwriting an existing version; if you need to fix something, bump the version and re-release.
- If you want to discourage installs while keeping the name, you can “yank” a release in the PyPI UI.
