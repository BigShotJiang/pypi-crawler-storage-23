"""Lazy text content reader for map mode."""

from __future__ import annotations

from .lazy_proxy import LazyProxy


class LazyText(LazyProxy):
    """Lazily reads file content on first access."""

    __slots__ = ("_fd", "_text")

    def __init__(self, fd):
        self._fd = fd
        self._text = None

    def _ensure_loaded(self):
        if self._text is None:
            self._text = self._fd.read()
        return self._text

    def _proxy_target(self):
        return self._ensure_loaded()

    def __str__(self):
        return self._proxy_target()

    def __repr__(self):
        return repr(str(self))

    def __eq__(self, other):
        if isinstance(other, LazyText):
            return str(self) == str(other)
        return str(self) == other

    def __hash__(self):
        return hash(str(self))

    def __len__(self):
        return len(str(self))

    def __contains__(self, item):
        return item in str(self)

    def __add__(self, other):
        return str(self) + other

    def __radd__(self, other):
        return other + str(self)

    def __snail_print__(self):
        print(str(self))
