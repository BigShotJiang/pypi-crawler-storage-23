#!/usr/bin/env bash
set -eu
SCRIPT_DIR=""
bash $(dirname "$(realpath "$0")")/update-env-core.ps1
