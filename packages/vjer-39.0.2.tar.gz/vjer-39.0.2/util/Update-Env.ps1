$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
& $PSScriptRoot\update-env-core.ps1
