# Vjer Python Module

A command line tool for automating CI/CD tasks.
