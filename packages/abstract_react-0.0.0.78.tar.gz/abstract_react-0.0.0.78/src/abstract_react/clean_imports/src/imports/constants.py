from .init_imports import *
SOLCATCHER_DIR = get_abs_path('solcatcher')
