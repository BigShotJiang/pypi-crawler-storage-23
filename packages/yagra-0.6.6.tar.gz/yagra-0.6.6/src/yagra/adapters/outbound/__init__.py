"""Exposes the outbound adapter implementations for Yagra."""

from yagra.adapters.outbound.in_memory_node_registry import InMemoryNodeRegistry

__all__ = ["InMemoryNodeRegistry"]
