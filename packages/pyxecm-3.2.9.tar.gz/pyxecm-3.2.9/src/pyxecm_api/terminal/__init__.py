"""WebSocket Terminal Server defintion."""
