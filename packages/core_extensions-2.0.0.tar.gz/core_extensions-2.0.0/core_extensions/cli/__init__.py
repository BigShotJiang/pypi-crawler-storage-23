# -*- coding: utf-8 -*-

"""CLI extensions for core-extensions."""

from .aliased_group import AliasedGroup


__all__ = [
    "AliasedGroup"
]
