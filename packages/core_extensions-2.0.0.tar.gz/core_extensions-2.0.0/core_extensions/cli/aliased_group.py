# -*- coding: utf-8 -*-

"""
Click group extension that supports command and subgroup
aliases.
"""

from __future__ import annotations

import typing as t

import click


class AliasedGroup(click.Group):
    """
    A Click Group subclass that supports aliases for
    commands and subgroups.
    """

    def __init__(self, *args: t.Any, **kwargs: t.Any) -> None:
        super().__init__(*args, **kwargs)
        self.aliases: dict[str, str] = {}

    @t.overload
    def command(self, __func: t.Callable[..., t.Any]) -> click.Command: ...

    @t.overload
    def command(
        self, *args: t.Any, **kwargs: t.Any
    ) -> t.Callable[[t.Callable[..., t.Any]], click.Command]: ...

    def command(
        self, *args: t.Any, **kwargs: t.Any
    ) -> t.Callable[[t.Callable[..., t.Any]], click.Command] | click.Command:
        aliases = kwargs.pop("aliases", [])

        # Handle direct decorator usage without parentheses (@group.command)
        func: t.Callable[..., t.Any] | None = None
        cmd_args: tuple[t.Any, ...] = args

        if args:
            first = args[0]
            if callable(first):
                if len(args) > 1:
                    raise TypeError(
                        "Use 'group.command(**kwargs)(callable)' to pass arguments."
                    )

                func = first
                cmd_args = ()

        decorator = super().command(*cmd_args, **kwargs)

        def _decorator(f: t.Callable[..., t.Any]) -> click.Command:
            cmd = decorator(f)  # pylint: disable=not-callable
            if aliases and cmd.name:
                for alias in aliases:
                    if alias in self.aliases:
                        raise ValueError(
                            f"Alias '{alias}' is already registered "
                            f"to command '{self.aliases[alias]}'."
                        )

                    self.aliases[alias] = cmd.name

            return cmd

        # If func was provided (direct usage), apply decorator immediately
        if func is not None:
            return _decorator(func)

        return _decorator

    @t.overload
    def group(self, __func: t.Callable[..., t.Any]) -> click.Group: ...

    @t.overload
    def group(
        self, *args: t.Any, **kwargs: t.Any
    ) -> t.Callable[[t.Callable[..., t.Any]], click.Group]: ...

    def group(
        self, *args: t.Any, **kwargs: t.Any
    ) -> t.Callable[[t.Callable[..., t.Any]], click.Group] | click.Group:
        aliases = kwargs.pop("aliases", [])

        # Handle direct decorator usage without parentheses (@group.group)
        func: t.Callable[..., t.Any] | None = None
        cmd_args: tuple[t.Any, ...] = args

        if args:
            first = args[0]
            if callable(first):
                if len(args) > 1:
                    raise TypeError(
                        "Use 'group.group(**kwargs)(callable)' to pass arguments."
                    )

                func = first
                cmd_args = ()

        decorator = super().group(*cmd_args, **kwargs)

        def _decorator(f: t.Callable[..., t.Any]) -> click.Group:
            cmd = decorator(f)  # pylint: disable=not-callable
            if aliases and cmd.name:
                for alias in aliases:
                    if alias in self.aliases:
                        raise ValueError(
                            f"Alias '{alias}' is already registered "
                            f"to command '{self.aliases[alias]}'."
                        )

                    self.aliases[alias] = cmd.name

            return cmd

        if func is not None:
            return _decorator(func)

        return _decorator

    def add_command(
        self,
        cmd: click.Command,
        name: t.Optional[str] = None,
        aliases: t.Optional[t.List[str]] = None,
    ) -> None:
        super().add_command(cmd, name)

        if aliases:
            cmd_name = name or cmd.name
            if cmd_name:
                for alias in aliases:
                    if alias in self.aliases:
                        raise ValueError(
                            f"Alias '{alias}' is already registered "
                            f"to command '{self.aliases[alias]}'."
                        )

                    self.aliases[alias] = cmd_name

    def format_commands(
        self, ctx: click.Context, formatter: click.HelpFormatter
    ) -> None:
        # Build reverse map: command name -> ordered list of its aliases
        cmd_aliases: dict[str, list[str]] = {}
        for alias, cmd_name in self.aliases.items():
            cmd_aliases.setdefault(cmd_name, []).append(alias)

        commands = []
        for subcommand in self.list_commands(ctx):
            cmd = self.get_command(ctx, subcommand)
            if cmd is None or cmd.hidden:
                continue
            commands.append((subcommand, cmd))

        if not commands:
            return

        limit = formatter.width - 6 - max(len(sub) for sub, _ in commands)

        rows = []
        for subcommand, cmd in commands:
            help_str = cmd.get_short_help_str(limit)
            if subcommand in cmd_aliases:
                alias_str = ", ".join(cmd_aliases[subcommand])
                suffix = f"(aliases: {alias_str})"
                help_str = f"{help_str}  {suffix}" if help_str else suffix

            rows.append((subcommand, help_str))

        with formatter.section("Commands"):
            formatter.write_dl(rows)

    def get_command(
        self, ctx: click.Context, cmd_name: str
    ) -> click.Command | None:
        return super().get_command(ctx, self.aliases.get(cmd_name, cmd_name))
