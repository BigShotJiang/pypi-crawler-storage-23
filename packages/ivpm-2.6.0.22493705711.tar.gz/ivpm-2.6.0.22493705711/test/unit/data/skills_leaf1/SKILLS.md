---
name: skill-leaf1
description: Provides leaf1 capability for testing IVPM skill aggregation.
license: Apache-2.0
---

# Skill Leaf 1

Instructions for skill-leaf1.
