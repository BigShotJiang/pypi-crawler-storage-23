---
name: skill-both-dot
description: This is the SKILL.md version and should NOT be selected.
---

# Skill Both (SKILL.md)
