---
name: skill-both
description: Package with both SKILLS.md and SKILL.md for preference testing.
---

# Skill Both (SKILLS.md)

This is the SKILLS.md version.
