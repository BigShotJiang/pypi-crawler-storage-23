---
name: skill-leaf2
description: Provides leaf2 capability. Use when working with leaf2 tasks.
compatibility: Requires Python 3.8+
---

# Skill Leaf 2

Instructions for skill-leaf2.
