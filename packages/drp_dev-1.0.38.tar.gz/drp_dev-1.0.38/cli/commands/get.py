"""get — Download a file to disk."""

from . import Arg, Command, register

cmd = register(Command(
    name="get",
    description="Download a file to disk.",
    args=(
        Arg("key",
            "Bare key (xK9mZ2) or full URL.",
            required=True),
        Arg("-n/--name",
            "Save with a different filename instead of the original."),
        Arg("--fork",
            "Fork the file into your own account instead of downloading.",
            type="bool"),
        Arg("--encryption-key",
            "Passphrase for client-side encrypted content. Decrypts after download.",
            type="passphrase"),
        Arg("--stdout",
            "Write content to stdout instead of a file. Enables piping.",
            type="bool"),
    ),
))


def run(shell, args_str):
    """Download a file to disk."""
    import os
    import requests
    from cli.session import api_get, check_auth

    if not check_auth(shell):
        return

    args = args_str.strip().split() if args_str.strip() else []
    if not args:
        shell.poutput("usage: get <key> [-n NAME] [--stdout]")
        return

    key = args[0]
    # Strip URL prefix if given
    if "/" in key:
        key = key.rstrip("/").rsplit("/", 1)[-1]

    save_name = None
    stdout_mode = False
    i = 1
    while i < len(args):
        if args[i] in ("-n", "--name") and i + 1 < len(args):
            save_name = args[i + 1]; i += 2
        elif args[i] == "--stdout":
            stdout_mode = True; i += 1
        else:
            i += 1

    resp = api_get(f"/api/v1/keys/{key}/")
    if resp.status_code != 200:
        shell.poutput(f"error: {resp.json().get('error', resp.status_code)}")
        return

    data = resp.json()
    download_url = data.get("download_url")
    filename = save_name or data.get("filename", key)

    if not download_url:
        shell.poutput("error: no download URL available")
        return

    r = requests.get(download_url, stream=True)
    if r.status_code != 200:
        shell.poutput(f"error: download failed ({r.status_code})")
        return

    if stdout_mode:
        import sys
        for chunk in r.iter_content(8192):
            sys.stdout.buffer.write(chunk)
        return

    dest = os.path.join(shell.local_cwd, filename)
    with open(dest, "wb") as f:
        for chunk in r.iter_content(8192):
            f.write(chunk)

    size = os.path.getsize(dest)
    shell.poutput(f"  saved: {dest} ({size} bytes)")
