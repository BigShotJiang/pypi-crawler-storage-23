"""token — Manage account-level API tokens."""

from . import Arg, Command, register

cmd = register(Command(
    name="token",
    description="Manage account-level API tokens for scripts and integrations.",
    args=(
        Arg("action",
            "Subcommand: create, list, or revoke.",
            required=True, choices=("create", "list", "revoke")),
        Arg("target",
            "Token ID (for revoke)."),
        Arg("--label",
            "Human-readable label for a new token."),
    ),
))


def run(shell, args_str):
    """Manage API tokens."""
    from cli.session import api_get, api_post, api_delete, check_auth

    if not check_auth(shell):
        return

    args = args_str.strip().split() if args_str.strip() else []
    if not args:
        shell.poutput("usage: token <create|list|revoke> [--label LABEL] [TOKEN_ID]")
        return

    action = args[0]

    if action == "list":
        resp = api_get("/api/v1/tokens/")
        if resp.status_code != 200:
            shell.poutput(f"error: {resp.json().get('error', resp.status_code)}")
            return
        tokens = resp.json().get("tokens", [])
        if not tokens:
            shell.poutput("  no tokens")
            return
        for t in tokens:
            label = t.get("label", "") or "(no label)"
            created = str(t.get("created_at", ""))[:10]
            shell.poutput(f"  #{t['id']}  {label:<20s}  created: {created}")

    elif action == "create":
        label = ""
        for i, a in enumerate(args):
            if a == "--label" and i + 1 < len(args):
                label = args[i + 1]
        resp = api_post("/api/v1/tokens/", json={"label": label})
        if resp.status_code in (200, 201):
            d = resp.json()
            shell.poutput(f"  token: {d['token']}")
            shell.poutput(f"  id:    {d['id']}")
            shell.poutput("  (save this — it won't be shown again)")
        else:
            shell.poutput(f"error: {resp.json().get('error', resp.status_code)}")

    elif action == "revoke":
        if len(args) < 2:
            shell.poutput("usage: token revoke <TOKEN_ID>")
            return
        token_id = args[1]
        resp = api_delete(f"/api/v1/tokens/{token_id}/")
        if resp.status_code == 200:
            shell.poutput(f"  revoked token #{token_id}")
        else:
            shell.poutput(f"error: {resp.json().get('error', resp.status_code)}")

    else:
        shell.poutput(f"unknown action: {action} (use create, list, or revoke)")
