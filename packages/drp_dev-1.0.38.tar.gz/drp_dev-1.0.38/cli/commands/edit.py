"""edit — Open a drive file in $EDITOR and re-upload if changed."""

from . import Arg, Command, register

cmd = register(Command(
    name="edit",
    description="Fetch a drive file, open in $EDITOR, re-upload if changed.",
    shell_only=True,
    args=(
        Arg("filename",
            "Filename in the current drive folder.",
            required=True),
        Arg("--editor",
            "Override $EDITOR, e.g. --editor nano."),
        Arg("--encryption-key",
            "Passphrase for client-side encrypted content. Decrypts for editing, re-encrypts on save.",
            type="passphrase"),
    ),
))


def run(shell, args_str):
    """Open a drive file in $EDITOR and re-upload if changed."""
    import hashlib
    import os
    import subprocess
    import tempfile
    import requests
    from cli.session import api_get, api_post, api_delete, check_auth

    if not check_auth(shell):
        return

    args = args_str.strip().split() if args_str.strip() else []
    if not args:
        shell.poutput("usage: edit <filename> [--editor EDITOR]")
        return

    filename = args[0]
    editor = os.environ.get("EDITOR", "nano")
    for i, a in enumerate(args):
        if a == "--editor" and i + 1 < len(args):
            editor = args[i + 1]

    # Resolve filename to key
    path = shell.cwd.strip("/")
    params = {"path": path} if path else {}
    resp = api_get("/api/v1/folders/", params=params)
    key = None
    if resp.status_code == 200:
        for f in resp.json().get("files", []):
            if f.get("filename") == filename:
                key = f.get("key")
                break

    if not key:
        shell.poutput(f"  not found: {filename}")
        return

    # Download content
    raw = api_get(f"/api/v1/keys/{key}/raw/")
    if raw.status_code != 200:
        shell.poutput(f"  error: {raw.json().get('error', raw.status_code)}")
        return

    data = raw.json()
    content = data.get("content")
    if content is None:
        shell.poutput("  binary files cannot be edited in terminal")
        return

    # Write to temp file, open editor
    suffix = os.path.splitext(filename)[1] or ".txt"
    with tempfile.NamedTemporaryFile(mode="w", suffix=suffix, delete=False) as tmp:
        tmp.write(content)
        tmp_path = tmp.name

    before = hashlib.sha256(content.encode()).hexdigest()

    try:
        subprocess.run([editor, tmp_path], check=True)
    except (subprocess.CalledProcessError, FileNotFoundError) as e:
        shell.poutput(f"  editor error: {e}")
        os.unlink(tmp_path)
        return

    with open(tmp_path, "r") as f:
        new_content = f.read()
    os.unlink(tmp_path)

    after = hashlib.sha256(new_content.encode()).hexdigest()
    if before == after:
        shell.poutput("  no changes")
        return

    # Re-upload
    folder = shell.cwd.strip("/")
    resp2 = api_post("/api/v1/keys/", json={
        "text": new_content, "filename": filename,
        "folder": folder, "key": key,
    })
    # If key conflict (same key), delete old and retry
    if resp2.status_code == 409:
        api_delete(f"/api/v1/keys/{key}/")
        resp2 = api_post("/api/v1/keys/", json={
            "text": new_content, "filename": filename,
            "folder": folder, "key": key,
        })

    if resp2.status_code in (200, 201):
        shell.poutput(f"  saved: {resp2.json().get('url', key)}")
    else:
        shell.poutput(f"  error: {resp2.json().get('error', resp2.status_code)}")
