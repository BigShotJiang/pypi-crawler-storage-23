"""mkdir — Create a folder at the current drive location."""

from . import Arg, Command, register

cmd = register(Command(
    name="mkdir",
    description="Create a folder at the current drive location.",
    shell_only=True,
    args=(
        Arg("name",
            "Name for the new folder.",
            required=True),
    ),
))


def run(shell, args_str):
    """Create a folder at the current drive location."""
    from cli.session import api_post, check_auth

    if not check_auth(shell):
        return

    name = args_str.strip()
    if not name:
        shell.poutput("usage: mkdir <name>")
        return

    parent = shell.cwd.strip("/")
    payload = {"name": name}
    if parent:
        payload["parent"] = parent

    resp = api_post("/api/v1/folders/", json=payload)
    if resp.status_code in (200, 201):
        d = resp.json()
        shell.poutput(f"  created: {d.get('path', name)}")
    else:
        shell.poutput(f"  error: {resp.json().get('error', resp.status_code)}")
