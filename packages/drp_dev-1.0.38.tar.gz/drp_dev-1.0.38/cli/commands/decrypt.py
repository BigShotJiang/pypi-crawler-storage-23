"""decrypt — Permanently remove client-side encryption from a file."""

from . import Arg, Command, register

cmd = register(Command(
    name="decrypt",
    description="Permanently decrypt a file. Downloads, decrypts, and re-uploads without encryption.",
    args=(
        Arg("ref",
            "Key (xK9mZ2) or filename in the current drive folder (shell only).",
            required=True),
        Arg("encryption_key",
            "The passphrase used to encrypt the file.",
            required=True, type="passphrase"),
    ),
))


def run(shell, args_str):
    """Permanently decrypt a file."""
    shell.poutput("  decrypt requires the Web Crypto API (browser-side AES-256-GCM).")
    shell.poutput("  Client-side decryption is handled in the browser at /<key>/decrypt/.")
    shell.poutput("  CLI decryption is not yet supported — use the web interface.")
