from tenzir._bin._common import exec_binary


def main() -> None:
    exec_binary("tenzir")
