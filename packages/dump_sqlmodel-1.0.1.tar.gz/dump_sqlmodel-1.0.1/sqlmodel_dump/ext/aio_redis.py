import json
from inspect import isawaitable
from typing import Any, Callable

from redis.asyncio import Redis

from sqlmodel_dump.deserializer import Deserializer
from sqlmodel_dump.serializer import Serializer


class SQLModelDump:
    _class: dict[str, type[Any]] = {}

    _max_depth: int
    _self_ref: bool

    _key_factory: Callable[[Any], str]
    _ref_alternative: Callable[[str], Any] | None

    _redis: Redis
    _store_obj_to_redis: bool
    _set_kwargs: dict[str, Any]
    _get_kwargs: dict[str, Any]

    def __init__(
        self,
        redis: Redis,
        max_depth: int = 3,
        self_ref: bool = False,
        key_factory: Callable[[Any], str] = lambda x: (
            f"{x.__class__.__name__}:{getattr(x, 'id', 'None')}"
        ),
        ref_alternative: Callable[[str], Any] | None = None,
        store_obj_to_redis: bool = False,
        set_kwargs: dict[str, Any] = {},
        get_kwargs: dict[str, Any] = {},
    ) -> None:
        """
        SQLModel dumping manager

        ## What is self_ref mode?

        With self_ref set to `False`, the Relationship reference will be stored in `SQLModelDump._ref` dict.
        This is the default mode and need a garbage collector in order not to raise the memory leak error..

        **Example:**
        Return object:
        ```
        {
            "__type": "model",
            "__class": "Enrollment",
            "id": "f2915205-831c-4941-b116-7c76b27ebd2f",
            "classroom": {
                "__type": "relationship",
                "__class": "Class",
                "__ref": "Class:b607a4a3-4a10-453b-aed4-cd575ebb6c36" # An address to the reference in `_ref` object
            },
            ...
        }
        ```
        `_ref` object
        ```
        {
            "Class:b607a4a3-4a10-453b-aed4-cd575ebb6c36": { # The relationship value
                "__type": "model",
                "__class": "Class",
                "id": "b607a4a3-4a10-453b-aed4-cd575ebb6c36",
                "name": "Test Class",
                "subject": "Test",
                "teacher_id": "3135756c-be25-41a5-a6a8-be2c6f667c99",
                "teacher": {
                    "__type": "relationship",
                    "__class": "Teacher",
                    "__ref": "Teacher:3135756c-be25-41a5-a6a8-be2c6f667c99" # Reference to another object
                }
            },
            ...
        }
        ```

        With self_ref set to `True`, the reference will be stored in the result object itself.
        This can help eliminate the garbage collector but the result object size will be significantly increased

        **Example:**
        ```
        {
            "__type": "model",
            "__class": "Enrollment",
            "id": "ae4efb62-cd94-47bf-a6e7-3f9c93703c00",
            "class_id": "bdd2df1c-5b33-467b-9c0b-a1e69f4324b2",
            "classroom": {
                "__type": "relationship",
                "__class": "Class",
                "__ref": "Class:bdd2df1c-5b33-467b-9c0b-a1e69f4324b2",
                "__val": { # The relationship will be store in itself
                    "__type": "model",
                    "__class": "Class",
                    "id": "bdd2df1c-5b33-467b-9c0b-a1e69f4324b2",
                    "created_at": {
                        "__type": "datetime",
                        "__val": 1772292084.449564
                    },
                    "updated_at": {
                        "__type": "datetime",
                        "__val": 1772292084.449624
                    },
                    "name": "Test Class",
                    "subject": "Test",
                    ...
                }
            },
            ...
        }
        ```

        :param Redis redis: Redis client
        :param int max_depth: control how deep the serializer and deserializer will go
        :param bool self_ref: Use self_ref mode
        :param Callable key_factory: A custom function to produce the key for reference, should accept only one args is the reference object
        :prarm Callable ref_alternative: A function to call when a reference is missing, could be an async function
        :param bool store_obj_to_redis: Will the result object be stored in the Redis before returning
        :param dict set_kwargs: kwargs for Redis set function
        :param dict get_kwargs: kwargs for Redis get function
        """
        self._redis = redis
        self._max_depth = max_depth
        self._self_ref = self_ref
        self._key_factory = key_factory
        self._ref_alternative = ref_alternative
        self._set_kwargs = set_kwargs
        self._get_kwargs = get_kwargs
        self._store_obj_to_redis = store_obj_to_redis

    async def dumps(self, obj: Any) -> tuple[dict[str, Any], str | None]:
        """
        Dump the SQLModel into dict
        
        :param SQLModel obj: Obj to dump
        :return tuple[dict[str, Any], str | None]: The dumped object and the redis key if the `store_obj_to_redis` is set to true
        """
        serializer = Serializer(
            self_ref=self._self_ref,
            max_depth=self._max_depth,
            key_factory=self._key_factory,
        )
        dumps = serializer.serialize(obj)
        self._class |= serializer.base_class
        for key, val in serializer.ref.items():
            await self._redis.set(key, json.dumps(val), **self._set_kwargs)
        redis_key = None
        if self._store_obj_to_redis:
            redis_key = self._key_factory(obj)
            await self._redis.set(redis_key, dumps)
        return dumps, redis_key

    async def _redis_ref_alternative(self, key: str) -> Any:
        data = await self._redis.get(key)
        if data:
            return json.loads(data)
        if self._ref_alternative:
            obj = self._ref_alternative(key)
            if isawaitable(obj):
                return await obj
            else:
                return obj
        return None

    async def loads_from_redis(self, key: str) -> Any:
        """
        Loads the object from Redis

        :param str key: The Redis key
        :return: The loaded object 
        """
        obj = self._redis.get(key)
        if obj is not None:
            return await self.loads(obj)
        return None

    async def loads(self, obj: Any) -> Any:
        """
        Loads the object

        :param Any obj: The object to load
        :return: The loaded object 
        """
        deserializer = Deserializer(
            get_class=self._class.get,
            get_ref=lambda x: None,
            self_ref=self._self_ref,
            max_depth=self._max_depth,
            ref_alternative=self._redis_ref_alternative,
            running_loop=None,
        )
        return await deserializer.async_deserialize(obj)
