from typing import Literal


class Invalid(BaseException):
    def __init__(self, obj: str, expect: str, got: str) -> None:
        super().__init__(obj, expect, got)
        self.obj = obj
        self.expect = expect
        self.got = got

    def __str__(self) -> str:
        return f"{self.obj} is invalid, expect '{self.expect}', got '{self.got}'"


class LostRef(BaseException):
    def __init__(self, ref: str) -> None:
        super().__init__(ref)
        self.ref = ref

    def __str__(self) -> str:
        return f"ref {self.ref} is lost, maybe the GC or you has deleted"


class InvalidOption(Exception): ...


class DeserializerObjMissing(BaseException):
    def __init__(self, obj_type: str, field: str) -> None:
        super().__init__(obj_type, field)
        self.obj_type = obj_type
        self.field = field

    def __str__(self) -> str:
        return f"obj is {self.obj_type} but missing '{self.field}' field"


class DeserializerMissing(BaseException):
    def __init__(self, obj_type: Literal["ref", "class"], field: str) -> None:
        super().__init__(obj_type, field)
        self.obj_type = obj_type
        self.field = field

    def __str__(self) -> str:
        return f"missing {self.obj_type} '{self.field}'"


class WhereIsMyRef(BaseException):
    def __init__(self, ref: str) -> None:
        super().__init__(ref)
        self.ref = ref

    def __str__(self) -> str:
        return f"can't ref '{self.ref}'"
