"""SWE-Bench and other benchmark harnesses for howler-agents."""
