"""LLM role definitions - re-exported from config for convenience."""

from howler_agents.config import LLMRole, RoleModelConfig

__all__ = ["LLMRole", "RoleModelConfig"]
