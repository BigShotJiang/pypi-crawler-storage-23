"""Compatibility shim for launcher path utilities.

Canonical implementation: `adscan_core.path_utils`.
"""

from __future__ import annotations

from adscan_core.path_utils import *  # noqa: F403
