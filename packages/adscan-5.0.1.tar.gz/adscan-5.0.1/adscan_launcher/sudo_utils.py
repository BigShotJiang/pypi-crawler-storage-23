"""Compatibility shim for launcher sudo utilities.

Canonical implementation: `adscan_core.sudo_utils`.
"""

from __future__ import annotations

from adscan_core.sudo_utils import *  # noqa: F403
