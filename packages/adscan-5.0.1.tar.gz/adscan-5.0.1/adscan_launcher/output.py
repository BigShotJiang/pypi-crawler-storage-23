"""Compatibility shim for launcher Rich output helpers.

Canonical implementation: `adscan_core.rich_output`.
"""

from __future__ import annotations

from adscan_core.rich_output import *  # noqa: F403
