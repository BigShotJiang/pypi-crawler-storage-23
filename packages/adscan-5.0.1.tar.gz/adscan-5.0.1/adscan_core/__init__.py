"""Shared, dependency-light primitives used by both launcher and runtime.

This package is intentionally small and stable. It contains code that is safe
to distribute with the open-source PyPI launcher, while still being reusable
by the full in-container runtime.
"""

from __future__ import annotations

__all__ = []
