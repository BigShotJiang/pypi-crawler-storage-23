#!/usr/bin/env python3
"""OmenDB Performance Benchmark

Uses real SIFT embeddings for all benchmarks. Skips scales with no dataset.

Usage:
    python benchmark.py              # SIFT-100K benchmark (100K, 128D)
    python benchmark.py --publish    # 5 runs, median ± IQR (publishable numbers)
    python benchmark.py --vectors 1000000  # SIFT-1M benchmark
    python benchmark.py --full       # Multi-dimension (random vectors)
    python benchmark.py --scale      # Scale tests (SIFT data only, skips missing sizes)
    python benchmark.py --append history.json  # Append results to history file
"""

import argparse
import json
import platform
import subprocess
import tempfile
import time
from datetime import datetime
from pathlib import Path

import numpy as np

import omendb

SIFT_DATA_DIR = Path(__file__).parent.parent / "benchmarks" / "data"

# Map vector count → dataset filename. Add sift-100k.npz / sift-1m.npz when available.
SIFT_DATASETS: dict[int, str] = {
    10_000: "sift-10k.npz",
    100_000: "sift-100k.npz",
    1_000_000: "sift-1m.npz",
}


def load_sift(n_vectors: int) -> tuple[np.ndarray, np.ndarray, np.ndarray] | None:
    """Load SIFT dataset for given size. Returns (vectors, queries, ground_truth) or None."""
    filename = SIFT_DATASETS.get(n_vectors)
    if filename is None:
        return None
    path = SIFT_DATA_DIR / filename
    if not path.exists():
        return None
    data = np.load(path)
    return data["vectors"], data["queries"], data["ground_truth"]


def get_benchmark_metadata() -> dict:
    """Get system and version info for reproducible benchmarks."""
    # Git commit
    try:
        commit = subprocess.check_output(
            ["git", "rev-parse", "--short", "HEAD"],
            stderr=subprocess.DEVNULL,
            text=True,
        ).strip()
    except Exception:
        commit = "unknown"

    return {
        "timestamp": datetime.now().isoformat(),
        "commit": commit,
        "omendb_version": getattr(omendb, "__version__", "unknown"),
        "python": platform.python_version(),
        "platform": platform.platform(),
        "cpu": platform.processor() or platform.machine(),
    }


def print_metadata(metadata: dict):
    """Print benchmark metadata header."""
    print(f"Commit:   {metadata['commit']}")
    print(f"Version:  {metadata['omendb_version']}")
    print(f"Python:   {metadata['python']}")
    print(f"Platform: {metadata['platform']}")
    print(f"CPU:      {metadata['cpu']}")
    print(f"Time:     {metadata['timestamp']}")


def generate_vectors(n: int, dim: int, seed: int = 42) -> np.ndarray:
    """Generate random vectors."""
    np.random.seed(seed)
    return np.random.randn(n, dim).astype(np.float32)


def generate_text_corpus(n: int, seed: int = 42) -> list[str]:
    """Generate random text documents for hybrid search benchmarks."""
    words = [
        "database",
        "vector",
        "search",
        "query",
        "index",
        "storage",
        "memory",
        "performance",
        "fast",
        "efficient",
        "scalable",
        "distributed",
        "embedded",
        "machine",
        "learning",
        "neural",
        "network",
        "model",
        "training",
        "inference",
        "algorithm",
        "optimization",
        "parallel",
        "concurrent",
        "async",
        "thread",
        "rust",
        "python",
        "javascript",
        "typescript",
        "server",
        "client",
    ]
    np.random.seed(seed)
    texts = []
    for _ in range(n):
        n_words = np.random.randint(5, 15)
        doc = " ".join(np.random.choice(words, n_words))
        texts.append(doc)
    return texts


def benchmark_build(
    db_path: str,
    vectors: np.ndarray,
    with_metadata: bool = True,
    quantize_bits: int = 0,
) -> dict:
    """Benchmark index build throughput."""
    n, dim = vectors.shape
    if quantize_bits > 0:
        db = omendb.open(db_path, dimensions=dim, quantization="sq8")
    else:
        db = omendb.open(db_path, dimensions=dim)

    if with_metadata:
        batch = [
            {
                "id": f"d{i}",
                "vector": vectors[i].tolist(),
                "metadata": {"cat": i % 10},
            }
            for i in range(n)
        ]
    else:
        batch = [{"id": f"d{i}", "vector": vectors[i].tolist()} for i in range(n)]

    start = time.time()
    db.set(batch)
    elapsed = time.time() - start

    return {
        "vectors": n,
        "time_s": elapsed,
        "vec_per_s": n / elapsed,
        "db": db,
    }


def benchmark_search(db, queries: np.ndarray, k: int = 10, warmup: int = 10) -> dict:
    """Benchmark search QPS and latency."""
    n_queries = len(queries)

    # Warmup
    for q in queries[:warmup]:
        db.search(q.tolist(), k=k)

    # Benchmark
    latencies = []
    start = time.time()
    for q in queries:
        t0 = time.time()
        db.search(q.tolist(), k=k)
        latencies.append((time.time() - t0) * 1000)
    total = time.time() - start

    latencies.sort()
    return {
        "queries": n_queries,
        "time_s": total,
        "qps": n_queries / total,
        "latency_avg_ms": sum(latencies) / len(latencies),
        "latency_p50_ms": latencies[len(latencies) // 2],
        "latency_p99_ms": latencies[int(len(latencies) * 0.99)],
    }


def benchmark_filtered_search(
    db, queries: np.ndarray, filter_dict: dict, k: int = 10, warmup: int = 10
) -> dict:
    """Benchmark filtered search performance."""
    n_queries = len(queries)

    # Warmup
    for q in queries[:warmup]:
        db.search(q.tolist(), k=k, filter=filter_dict)

    # Benchmark
    start = time.time()
    for q in queries:
        db.search(q.tolist(), k=k, filter=filter_dict)
    total = time.time() - start

    return {
        "queries": n_queries,
        "time_s": total,
        "qps": n_queries / total,
        "latency_ms": (total / n_queries) * 1000,
    }


def benchmark_batch_search(db, queries: np.ndarray, k: int = 10) -> dict:
    """Benchmark batch search performance."""
    queries_list = [q.tolist() for q in queries]

    start = time.time()
    db.search_batch(queries_list, k=k)
    total = time.time() - start

    return {
        "queries": len(queries),
        "time_s": total,
        "qps": len(queries) / total,
        "latency_ms": (total / len(queries)) * 1000,
    }


def benchmark_text_search(db, query_texts: list[str], k: int = 10, warmup: int = 5) -> dict:
    """Benchmark text-only (BM25) search performance."""
    n_queries = len(query_texts)

    # Warmup
    for q in query_texts[:warmup]:
        db.search_text(q, k=k)

    # Benchmark
    latencies = []
    start = time.time()
    for q in query_texts:
        t0 = time.time()
        db.search_text(q, k=k)
        latencies.append((time.time() - t0) * 1000)
    total = time.time() - start

    latencies.sort()
    return {
        "queries": n_queries,
        "time_s": total,
        "qps": n_queries / total,
        "latency_avg_ms": sum(latencies) / len(latencies),
        "latency_p99_ms": latencies[int(len(latencies) * 0.99)] if latencies else 0,
    }


def benchmark_hybrid_search(
    db,
    query_vectors: np.ndarray,
    query_texts: list[str],
    k: int = 10,
    alpha: float | None = None,
    warmup: int = 5,
) -> dict:
    """Benchmark hybrid (vector + text) search performance."""
    n_queries = len(query_vectors)

    # Warmup
    for i in range(min(warmup, n_queries)):
        db.search_hybrid(
            query_vectors[i].tolist(), query_texts[i % len(query_texts)], k=k, alpha=alpha
        )

    # Benchmark
    latencies = []
    start = time.time()
    for i in range(n_queries):
        t0 = time.time()
        db.search_hybrid(
            query_vectors[i].tolist(), query_texts[i % len(query_texts)], k=k, alpha=alpha
        )
        latencies.append((time.time() - t0) * 1000)
    total = time.time() - start

    latencies.sort()
    return {
        "queries": n_queries,
        "time_s": total,
        "qps": n_queries / total,
        "latency_avg_ms": sum(latencies) / len(latencies),
        "latency_p99_ms": latencies[int(len(latencies) * 0.99)] if latencies else 0,
    }


def compute_ground_truth(vectors: np.ndarray, queries: np.ndarray, k: int = 10) -> np.ndarray:
    """Compute ground truth neighbors using brute-force L2 search."""
    n_queries = len(queries)
    ground_truth = np.zeros((n_queries, k), dtype=np.int32)

    for i, q in enumerate(queries):
        # L2 distance to all vectors
        distances = np.sum((vectors - q) ** 2, axis=1)
        # Get k nearest indices
        ground_truth[i] = np.argpartition(distances, k)[:k]

    return ground_truth


def benchmark_recall(
    db,
    vectors: np.ndarray,
    queries: np.ndarray,
    k: int = 10,
    ground_truth: np.ndarray | None = None,
) -> dict:
    """Measure recall@k against ground truth (pre-computed or brute-force)."""
    n_queries = min(100, len(queries))
    queries_subset = queries[:n_queries]
    if ground_truth is None:
        ground_truth = compute_ground_truth(vectors, queries_subset, k)
    else:
        ground_truth = ground_truth[:n_queries]

    total_recall = 0.0
    for i, q in enumerate(queries_subset):
        results = db.search(q.tolist(), k=k)
        returned_ids = {int(r["id"][1:]) for r in results}  # "d123" -> 123
        true_ids = set(ground_truth[i][:k].tolist())
        recall = len(returned_ids & true_ids) / k
        total_recall += recall

    avg_recall = total_recall / n_queries
    return {"recall_at_k": avg_recall, "k": k, "n_queries": n_queries}


def run_benchmark(
    n_vectors: int,
    dim: int,
    n_queries: int = 1000,
    quantize_bits: int = 0,
    sift_data: tuple[np.ndarray, np.ndarray, np.ndarray] | None = None,
    verbose: bool = True,
):
    """Run full benchmark suite for given parameters."""
    mode = f"SQ{quantize_bits}" if quantize_bits > 0 else "f32"
    dataset = "SIFT" if sift_data else "random"
    if verbose:
        print(f"\n{'=' * 60}")
        print(f"OmenDB Benchmark: {n_vectors:,} vectors, {dim}D ({mode}, {dataset})")
        print(f"{'=' * 60}")

    if sift_data:
        vectors, queries, ground_truth = sift_data
        n_queries = len(queries)
    else:
        vectors = generate_vectors(n_vectors, dim)
        queries = generate_vectors(n_queries, dim, seed=999)
        ground_truth = None

    with tempfile.TemporaryDirectory() as tmpdir:
        # Build
        build = benchmark_build(f"{tmpdir}/db", vectors, quantize_bits=quantize_bits)
        if verbose:
            print(f"\nBuild:    {build['vec_per_s']:>10,.0f} vec/s  ({build['time_s']:.2f}s)")

        db = build["db"]

        # Search
        search = benchmark_search(db, queries)
        if verbose:
            print(
                f"Search:   {search['qps']:>10,.0f} QPS    ({search['latency_avg_ms']:.2f}ms avg, {search['latency_p99_ms']:.2f}ms p99)"
            )

        # Recall measurement (graph quality indicator)
        recall = benchmark_recall(db, vectors, queries, ground_truth=ground_truth)
        if verbose:
            print(f"Recall:   {recall['recall_at_k']:>10.1%} @{recall['k']}")

        # Filtered search (10% selectivity)
        filtered = benchmark_filtered_search(db, queries, {"cat": 5})
        if verbose:
            print(
                f"Filtered: {filtered['qps']:>10,.0f} QPS    ({filtered['latency_ms']:.2f}ms, 10% selectivity)"
            )

        # Batch search
        batch = benchmark_batch_search(db, queries)
        if verbose:
            print(
                f"Batch:    {batch['qps']:>10,.0f} QPS    ({batch['latency_ms']:.3f}ms per query)"
            )

    # Return serializable results (no db object)
    return {
        "config": {
            "n_vectors": n_vectors,
            "dimensions": dim,
            "n_queries": n_queries,
            "quantize_bits": quantize_bits,
        },
        "build": {k: v for k, v in build.items() if k != "db"},
        "search": search,
        "recall": recall,
        "filtered": filtered,
        "batch": batch,
    }


def run_hybrid_benchmark(n_vectors: int, dim: int, n_queries: int = 100):
    """Run hybrid search benchmark suite."""
    print(f"\n{'=' * 60}")
    print(f"OmenDB Hybrid Benchmark: {n_vectors:,} vectors, {dim}D")
    print(f"{'=' * 60}")

    vectors = generate_vectors(n_vectors, dim)
    texts = generate_text_corpus(n_vectors, seed=42)
    query_vectors = generate_vectors(n_queries, dim, seed=999)
    query_texts = ["vector database", "machine learning", "rust performance", "search query"]

    with tempfile.TemporaryDirectory() as tmpdir:
        db = omendb.open(f"{tmpdir}/db", dimensions=dim)
        db.enable_text_search()

        # Build with text
        batch = [
            {
                "id": f"d{i}",
                "vector": vectors[i].tolist(),
                "text": texts[i],
                "metadata": {"cat": i % 10},
            }
            for i in range(n_vectors)
        ]
        start = time.time()
        db.set(batch)
        build_time = time.time() - start
        print(f"\nBuild:    {n_vectors / build_time:>10,.0f} vec/s  ({build_time:.2f}s)")

        # Text search (BM25 only)
        text_result = benchmark_text_search(db, query_texts * (n_queries // 4))
        print(
            f"Text:     {text_result['qps']:>10,.0f} QPS    ({text_result['latency_avg_ms']:.2f}ms avg)"
        )

        # Hybrid search (balanced alpha=0.5)
        hybrid_result = benchmark_hybrid_search(db, query_vectors, query_texts, alpha=0.5)
        print(
            f"Hybrid:   {hybrid_result['qps']:>10,.0f} QPS    ({hybrid_result['latency_avg_ms']:.2f}ms avg)"
        )

        # Hybrid text-only (alpha=0.0)
        text_only = benchmark_hybrid_search(db, query_vectors, query_texts, alpha=0.0)
        print(
            f"α=0.0:    {text_only['qps']:>10,.0f} QPS    ({text_only['latency_avg_ms']:.2f}ms avg)"
        )

        # Hybrid vector-only (alpha=1.0)
        vec_only = benchmark_hybrid_search(db, query_vectors, query_texts, alpha=1.0)
        print(
            f"α=1.0:    {vec_only['qps']:>10,.0f} QPS    ({vec_only['latency_avg_ms']:.2f}ms avg)"
        )

    return {
        "config": {"n_vectors": n_vectors, "dimensions": dim, "n_queries": n_queries},
        "build_time_s": build_time,
        "text_search": text_result,
        "hybrid_balanced": hybrid_result,
        "hybrid_text_only": text_only,
        "hybrid_vector_only": vec_only,
    }


def append_to_history(metadata: dict, results: list, history_path: Path):
    """Append results to the given history file."""
    history_path.parent.mkdir(parents=True, exist_ok=True)

    # Load existing history or create new
    if history_path.exists():
        with open(history_path) as f:
            history = json.load(f)
    else:
        history = []

    # Append new entry
    entry = {
        "metadata": metadata,
        "results": results,
    }
    history.append(entry)

    # Keep last 100 entries to avoid unbounded growth
    history = history[-100:]

    with open(history_path, "w") as f:
        json.dump(history, f, indent=2)

    print(f"History updated: {history_path} ({len(history)} entries)")


def check_regressions(results: list, history_path: Path) -> bool:
    """Compare results to previous runs and warn about regressions.

    Returns True if regressions detected.
    """
    if not history_path.exists():
        return False

    with open(history_path) as f:
        history = json.load(f)

    if len(history) < 2:
        return False

    # Get previous entry (before the one we just added)
    prev = history[-2]

    # Build lookup of previous results by config
    prev_by_config = {}
    for r in prev.get("results", []):
        cfg = r.get("config", {})
        key = (cfg.get("n_vectors"), cfg.get("dimensions"))
        prev_by_config[key] = r

    regressions = []
    for r in results:
        cfg = r.get("config", {})
        key = (cfg.get("n_vectors"), cfg.get("dimensions"))

        prev_r = prev_by_config.get(key)
        if not prev_r:
            continue

        # Check recall regression (>5% drop is significant)
        recall = r.get("recall", {})
        prev_recall = prev_r.get("recall", {})
        if recall and prev_recall:
            cur = recall.get("recall_at_k", 0)
            pre = prev_recall.get("recall_at_k", 0)
            if pre > 0 and cur < pre * 0.95:
                regressions.append(
                    f"  Recall@10 regression at {key[0]:,}/{key[1]}D: {pre:.1%} → {cur:.1%} ({(cur - pre) / pre:+.1%})"
                )

        # Check search QPS regression (>20% drop is significant)
        search = r.get("search", {})
        prev_search = prev_r.get("search", {})
        if search and prev_search:
            cur_qps = search.get("qps", 0)
            pre_qps = prev_search.get("qps", 0)
            if pre_qps > 0 and cur_qps < pre_qps * 0.80:
                regressions.append(
                    f"  Search QPS regression at {key[0]:,}/{key[1]}D: {pre_qps:,.0f} → {cur_qps:,.0f} ({(cur_qps - pre_qps) / pre_qps:+.0%})"
                )

        # Check build throughput regression (>20% drop is significant)
        build = r.get("build", {})
        prev_build = prev_r.get("build", {})
        if build and prev_build:
            cur_vps = build.get("vec_per_s", 0)
            pre_vps = prev_build.get("vec_per_s", 0)
            if pre_vps > 0 and cur_vps < pre_vps * 0.80:
                regressions.append(
                    f"  Build regression at {key[0]:,}/{key[1]}D: {pre_vps:,.0f} → {cur_vps:,.0f} ({(cur_vps - pre_vps) / pre_vps:+.0%})"
                )

    if regressions:
        print("\n" + "!" * 60)
        print("WARNING: Performance regressions detected!")
        print("!" * 60)
        for r in regressions:
            print(r)
        print("!" * 60)
        return True

    return False


def _percentile(values: list[float], p: float) -> float:
    """Return percentile p (0-100) of values using linear interpolation."""
    sorted_vals = sorted(values)
    n = len(sorted_vals)
    if n == 1:
        return sorted_vals[0]
    idx = (p / 100) * (n - 1)
    lo, hi = int(idx), min(int(idx) + 1, n - 1)
    frac = idx - lo
    return sorted_vals[lo] + frac * (sorted_vals[hi] - sorted_vals[lo])


def _print_publish_summary(runs_results: list[dict], n_runs: int):
    """Print median ± IQR summary for publish mode."""
    print(f"\n{'=' * 70}")
    print(f"OmenDB Publish Results (median of {n_runs}, 128D, M=16, ef_c=100, k=10)")
    print(f"{'=' * 70}")

    builds = [r["build"]["vec_per_s"] for r in runs_results]
    searches = [r["search"]["qps"] for r in runs_results]
    batches = [r["batch"]["qps"] for r in runs_results]
    recalls = [r["recall"]["recall_at_k"] for r in runs_results]

    for label, values, unit in [
        ("Build", builds, "vec/s"),
        ("Search", searches, "QPS"),
        ("Batch", batches, "QPS"),
    ]:
        med = _percentile(values, 50)
        q1 = _percentile(values, 25)
        q3 = _percentile(values, 75)
        print(f"{label}: {med:,.0f} {unit} (median of {n_runs}, IQR: {q1:,.0f}–{q3:,.0f})")

    med_recall = _percentile(recalls, 50)
    print(f"Recall@10: {med_recall:.1%}")
    print()


def _median_result(runs_results: list[dict]) -> dict:
    """Return a result dict with median values from multiple runs."""
    import copy

    base = copy.deepcopy(runs_results[0])

    builds = [r["build"]["vec_per_s"] for r in runs_results]
    searches = [r["search"]["qps"] for r in runs_results]
    batches = [r["batch"]["qps"] for r in runs_results]
    recalls = [r["recall"]["recall_at_k"] for r in runs_results]

    base["build"]["vec_per_s"] = round(_percentile(builds, 50))
    base["search"]["qps"] = round(_percentile(searches, 50))
    base["batch"]["qps"] = round(_percentile(batches, 50))
    base["recall"]["recall_at_k"] = round(_percentile(recalls, 50), 4)

    return base


def main():
    parser = argparse.ArgumentParser(description="OmenDB Performance Benchmark")
    parser.add_argument("--full", action="store_true", help="Run full benchmark suite")
    parser.add_argument(
        "--scale", action="store_true", help="Run scale tests (10K, 50K, 100K at 128D)"
    )
    parser.add_argument("--hybrid", action="store_true", help="Run hybrid search benchmarks")
    parser.add_argument("--dimension", type=int, default=128, help="Vector dimension")
    parser.add_argument("--vectors", type=int, default=100000, help="Number of vectors")
    parser.add_argument("--queries", type=int, default=1000, help="Number of queries")
    parser.add_argument(
        "--quantize",
        type=int,
        choices=[0, 2, 4, 8],
        default=0,
        help="Quantization bits (0=none, 2/4/8=quantized)",
    )
    parser.add_argument(
        "--append", type=str, metavar="FILE", help="Append results to history file (JSON)"
    )
    parser.add_argument(
        "--publish",
        action="store_true",
        help="Publishable mode: 5 runs, report median ± IQR",
    )
    parser.add_argument(
        "--runs",
        type=int,
        default=1,
        help="Number of full benchmark runs (default: 1, --publish sets to 5)",
    )
    args = parser.parse_args()

    if args.publish:
        args.runs = max(args.runs, 5)

    print("=" * 60)
    print("OmenDB Performance Benchmark")
    print("=" * 60)

    metadata = get_benchmark_metadata()
    print_metadata(metadata)

    all_results = []

    if args.hybrid:
        # Hybrid search benchmarks
        result = run_hybrid_benchmark(args.vectors, args.dimension)
        all_results.append(result)
    elif args.scale:
        # Scale tests at 128D using real SIFT embeddings
        print("\n" + "=" * 60)
        print("Scale Test (128D, SIFT)")
        print("=" * 60)
        for n in [10_000, 100_000, 1_000_000]:
            sift_data = load_sift(n)
            if sift_data is None:
                filename = SIFT_DATASETS.get(n, f"sift-{n // 1000}k.npz")
                print(
                    f"\nSkipping {n:,} vectors — no SIFT dataset found (add benchmarks/data/{filename})"
                )
                continue
            result = run_benchmark(n, 128, sift_data=sift_data)
            all_results.append(result)
    elif args.full:
        # Multiple dimensions
        for dim in [128, 384, 768, 1536]:
            result = run_benchmark(10000, dim)
            all_results.append(result)

        # Multiple scales at 768D
        print("\n" + "=" * 60)
        print("Scale Test (768D)")
        print("=" * 60)
        for n in [10000, 50000, 100000]:
            result = run_benchmark(n, 768)
            all_results.append(result)

        # Hybrid search at 384D (common embedding dim)
        print("\n" + "=" * 60)
        print("Hybrid Search Test")
        print("=" * 60)
        result = run_hybrid_benchmark(10000, 384)
        all_results.append(result)
    else:
        sift_data = None
        if args.dimension == 128:
            sift_data = load_sift(args.vectors)

        if args.runs > 1:
            # Multi-run mode: run silently, report median
            print(f"\nRunning {args.runs} benchmark runs...", flush=True)
            runs_results = []
            for i in range(args.runs):
                print(f"  Run {i + 1}/{args.runs}...", flush=True)
                r = run_benchmark(
                    args.vectors,
                    args.dimension,
                    n_queries=args.queries,
                    quantize_bits=args.quantize,
                    sift_data=sift_data,
                    verbose=False,
                )
                runs_results.append(r)

            _print_publish_summary(runs_results, args.runs)

            # Use median result for history
            result = _median_result(runs_results)
            all_results.append(result)

            if args.publish:
                metadata["runs"] = args.runs
                metadata["methodology"] = "median"
        else:
            result = run_benchmark(
                args.vectors,
                args.dimension,
                n_queries=args.queries,
                quantize_bits=args.quantize,
                sift_data=sift_data,
            )
            all_results.append(result)

    print("\n" + "=" * 60)
    print("Benchmark complete")
    print("=" * 60)

    if args.append:
        history_path = Path(args.append)
        append_to_history(metadata, all_results, history_path)
        check_regressions(all_results, history_path)


if __name__ == "__main__":
    main()
