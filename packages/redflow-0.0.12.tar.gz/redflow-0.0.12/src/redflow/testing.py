"""Testing utilities -- run workflows without a full Redis-backed worker.

``run_inline`` executes a workflow handler in-process with a minimal step API
that records step results in memory.  This is useful for unit tests that want
to verify handler logic without standing up Redis.

For integration tests that need the full Lua-script-backed lifecycle, use a
real ``start_worker`` with a local Redis instance.
"""

from __future__ import annotations

import asyncio
import builtins
import inspect
from collections.abc import Callable, Coroutine
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from ._json import safe_json_dumps
from .errors import CanceledError, InputValidationError, OutputSerializationError, RedflowError, TimeoutError
from .registry import WorkflowDefinition, WorkflowHandlerContext, _RunInfo


@dataclass(slots=True)
class InlineStepResult:
    name: str
    status: str
    output: Any = None
    error: Any = None


@dataclass(slots=True)
class InlineRunResult:
    output: Any = None
    error: BaseException | None = None
    steps: list[InlineStepResult] = field(default_factory=list)

    @property
    def succeeded(self) -> bool:
        return self.error is None


async def run_inline(
    definition: WorkflowDefinition,
    input: Any = None,
    *,
    run_id: str = "test-run-1",
    attempt: int = 1,
    max_attempts: int = 3,
    timeout_s: float | None = 30.0,
    step_overrides: dict[str, Any] | None = None,
) -> InlineRunResult:
    """Execute a workflow handler in-process for testing.

    Parameters
    ----------
    definition:
        The workflow definition (from ``define_workflow`` or ``@workflow``).
    input:
        Workflow input data.
    run_id:
        Fake run ID for the test context.
    attempt:
        Current attempt number.
    max_attempts:
        Maximum attempts before permanent failure.
    timeout_s:
        Overall timeout for the handler.  ``None`` = no timeout.
    step_overrides:
        Dict of ``{step_name: return_value}`` -- if a step name matches,
        the override value is returned instead of calling the step function.
    """
    overrides = step_overrides or {}
    steps: list[InlineStepResult] = []
    cancel_event = asyncio.Event()
    used_step_names: set[str] = set()

    def _check_duplicate(name: str) -> None:
        if name in used_step_names:
            raise RedflowError(f"Duplicate step name '{name}' in workflow '{definition.options.name}'")
        used_step_names.add(name)

    async def run_step(
        name: str,
        fn: Callable[..., Coroutine[Any, Any, Any]],
        *fn_args: Any,
        timeout_ms: int | None = None,
        **fn_kwargs: Any,
    ) -> Any:
        if cancel_event.is_set():
            raise CanceledError()

        _check_duplicate(name)

        if name in overrides:
            value = overrides[name]
            steps.append(InlineStepResult(name=name, status="succeeded", output=value))
            return value

        def _call_step_fn() -> Coroutine[Any, Any, Any]:
            call_kwargs = dict(fn_kwargs)
            if "signal" not in call_kwargs:
                try:
                    signature = inspect.signature(fn)
                except (TypeError, ValueError):
                    signature = None
                if signature is not None:
                    accepts_signal = "signal" in signature.parameters
                    accepts_kwargs = any(
                        param.kind == inspect.Parameter.VAR_KEYWORD for param in signature.parameters.values()
                    )
                    if accepts_signal or accepts_kwargs:
                        call_kwargs["signal"] = cancel_event
            return fn(*fn_args, **call_kwargs)

        try:
            if timeout_ms and timeout_ms > 0:
                value = await asyncio.wait_for(_call_step_fn(), timeout=timeout_ms / 1000)
            else:
                value = await _call_step_fn()

            try:
                safe_json_dumps(value)
            except Exception as ser_err:
                raise OutputSerializationError(f"Step output is not JSON-serializable: {name}", ser_err) from ser_err

            steps.append(InlineStepResult(name=name, status="succeeded", output=value))
            return value

        except builtins.TimeoutError:
            err = TimeoutError(f"Step timed out: {name}")
            steps.append(InlineStepResult(name=name, status="failed", error=err))
            raise err from None

        except Exception as err:
            steps.append(InlineStepResult(name=name, status="failed", error=err))
            raise

    async def emit_workflow_step(
        name: str,
        target_workflow: Any,
        workflow_input: Any,
        *,
        timeout_ms: int | None = None,
        run_at: datetime | None = None,
        queue_override: str | None = None,
        idempotency_key: str | None = None,
        idempotency_ttl: int | None = None,
    ) -> str:
        if cancel_event.is_set():
            raise CanceledError()

        _check_duplicate(name)

        if name in overrides:
            value = overrides[name]
            if not isinstance(value, str):
                raise RedflowError(f"emit_workflow override for step '{name}' must be a string run id")
            steps.append(InlineStepResult(name=name, status="succeeded", output=value))
            return value

        target_workflow_name = (
            target_workflow if isinstance(target_workflow, str) else getattr(target_workflow, "name", "")
        )
        fake_id = f"test-child-{target_workflow_name}-{name}"
        steps.append(InlineStepResult(name=name, status="succeeded", output=fake_id))
        return fake_id

    async def run_workflow_step(
        name: str,
        target_workflow: Any,
        workflow_input: Any,
        *,
        timeout_ms: int | None = None,
        run_at: datetime | None = None,
        queue_override: str | None = None,
        idempotency_key: str | None = None,
        idempotency_ttl: int | None = None,
    ) -> Any:
        if cancel_event.is_set():
            raise CanceledError()

        _check_duplicate(name)

        if name in overrides:
            value = overrides[name]
            steps.append(InlineStepResult(name=name, status="succeeded", output=value))
            return value

        target_workflow_name = (
            target_workflow if isinstance(target_workflow, str) else getattr(target_workflow, "name", "")
        )
        raise RedflowError(
            f"run_workflow step '{name}' for '{target_workflow_name}' requires a step_override in run_inline (no Redis)"
        )

    step_api = _InlineStepApi(run=run_step, emit_workflow=emit_workflow_step, run_workflow=run_workflow_step)

    run_info = _RunInfo(
        id=run_id,
        workflow=definition.options.name,
        queue=definition.options.queue,
        attempt=attempt,
        max_attempts=max_attempts,
    )
    validated_input = input
    schema = definition.options.input_schema
    if schema is not None:
        try:
            validated_input = schema.model_validate(input)
        except Exception as exc:
            return InlineRunResult(error=InputValidationError(str(exc)), steps=steps)

    ctx = WorkflowHandlerContext(input=validated_input, run=run_info, step=step_api, signal=cancel_event)

    result = InlineRunResult(steps=steps)

    try:
        if timeout_s is not None:
            output = await asyncio.wait_for(definition.handler(ctx), timeout=timeout_s)
        else:
            output = await definition.handler(ctx)
        try:
            safe_json_dumps(output)
        except Exception as ser_err:
            raise OutputSerializationError("Workflow output is not JSON-serializable", ser_err) from ser_err
        result.output = output
    except Exception as err:
        result.error = err

    return result


@dataclass(slots=True)
class _InlineStepApi:
    run: Callable[..., Coroutine[Any, Any, Any]]
    emit_workflow: Callable[..., Coroutine[Any, Any, str]]
    run_workflow: Callable[..., Coroutine[Any, Any, Any]]
