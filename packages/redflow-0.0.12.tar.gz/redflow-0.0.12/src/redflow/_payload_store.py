"""Helpers for storing large JSON payloads in per-run blob hashes."""

from __future__ import annotations

import base64
import hashlib
from typing import Any

from redis.asyncio import Redis

from . import _keys as K

_BLOB_REF_PREFIX = "@blob:"
_INLINE_JSON_MAX_BYTES = 1024


def _decode(value: Any) -> str:
    if isinstance(value, bytes):
        return value.decode()
    if value is None:
        return ""
    return str(value)


def _blob_field_for_json(json_string: str) -> str:
    digest = hashlib.sha1(json_string.encode("utf-8")).digest()
    digest_b64 = base64.urlsafe_b64encode(digest).decode("ascii").rstrip("=")
    return f"v1:{digest_b64}"


def _blob_field_from_ref(stored_value: str) -> str | None:
    if not stored_value.startswith(_BLOB_REF_PREFIX):
        return None
    field = stored_value[len(_BLOB_REF_PREFIX) :]
    return field or None


async def store_json_string_for_run(
    *,
    redis: Redis[Any],
    prefix: str,
    run_id: str,
    json_string: str,
) -> str:
    """Store oversized JSON in ``run:{id}:blobs`` and return inline string or ``@blob:...`` ref."""
    if _blob_field_from_ref(json_string):
        return json_string

    if len(json_string.encode("utf-8")) <= _INLINE_JSON_MAX_BYTES:
        return json_string

    field = _blob_field_for_json(json_string)
    await redis.hset(K.run_blobs(prefix, run_id), mapping={field: json_string})
    return f"{_BLOB_REF_PREFIX}{field}"


async def resolve_json_string_for_run(
    *,
    redis: Redis[Any],
    prefix: str,
    run_id: str,
    stored_value: str | None,
) -> str | None:
    """Resolve a ``@blob:...`` reference back to stored JSON, fallback to original value."""
    if not stored_value:
        return None

    field = _blob_field_from_ref(stored_value)
    if not field:
        return stored_value

    resolved = await redis.hget(K.run_blobs(prefix, run_id), field)
    if resolved is None:
        return stored_value
    return _decode(resolved)
