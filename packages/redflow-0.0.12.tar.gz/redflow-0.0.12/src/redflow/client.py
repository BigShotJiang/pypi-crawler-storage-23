"""RedflowClient — the main entry point for interacting with redflow runs.

Provides run creation (with idempotency), cancellation, listing, status
transitions, and registry sync.  All Redis mutations that touch multiple
keys use Lua scripts via EVALSHA for atomicity.
"""

from __future__ import annotations

import asyncio
import contextlib
import hashlib
import math
import os
import random
import uuid
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Protocol, cast

from redis.asyncio import Redis

from . import _keys as K
from ._json import UNDEFINED_TOKEN, safe_json_dumps, safe_json_loads, safe_json_try_loads
from ._lua_scripts import (
    ENQUEUE_RUN,
    FINALIZE_TERMINAL_RUN,
    PROMOTE_SCHEDULED_RUN,
    REQUEST_CANCELLATION,
    SCHEDULE_RETRY,
    TRANSITION_IF_CURRENT_STATUS,
    TRANSITION_QUEUED_TO_RUNNING,
    TRANSITION_RUN_STATUS,
)
from ._payload_store import resolve_json_string_for_run, store_json_string_for_run
from ._time import now_ms
from .default import get_default_client as _get_default_client_impl
from .default import set_default_client as _set_default_client_impl
from .errors import (
    CanceledError,
    InputValidationError,
    NonRetriableError,
    OutputSerializationError,
    RedflowError,
    UnknownWorkflowError,
    serialize_error,
)
from .errors import (
    TimeoutError as RedflowTimeoutError,
)
from .registry import WorkflowRegistry
from .types import (
    ALL_STATUSES,
    DEFAULT_MAX_ATTEMPTS,
    IDEMPOTENCY_TTL_SEC,
    AttemptTrace,
    CronTrigger,
    ListedRun,
    ListRunsParams,
    RunState,
    RunStats,
    RunStatus,
    StepState,
    StepTrace,
    WorkflowCronMeta,
    WorkflowMeta,
)

_POLL_MS = 250
_STALE_WORKFLOW_GRACE_MS = 30_000
_RUN_HISTORY_RETENTION_DAYS = 30
_RUN_HISTORY_CLEANUP_BATCH = 100
_DAY_MS = 24 * 60 * 60 * 1000


class _RedisExecCommandProto(Protocol):
    async def execute_command(self, *args: Any) -> Any: ...


def default_prefix() -> str:
    return os.environ.get("REDFLOW_PREFIX") or "redflow:v1"


def _default_run_history_retention_ms() -> int:
    raw = (os.environ.get("REDFLOW_RUN_RETENTION_DAYS") or "").strip()
    if not raw:
        return _RUN_HISTORY_RETENTION_DAYS * _DAY_MS

    try:
        parsed = float(raw)
    except (TypeError, ValueError):
        return _RUN_HISTORY_RETENTION_DAYS * _DAY_MS

    if not math.isfinite(parsed) or parsed <= 0:
        return _RUN_HISTORY_RETENTION_DAYS * _DAY_MS

    return math.floor(parsed * _DAY_MS)


# ---------- helpers ----------


def _normalize_max_concurrency(value: Any) -> int:
    """Clamp a raw Redis/config value to ``>= 1``."""
    try:
        v = int(value)
    except (TypeError, ValueError):
        return 1
    return max(1, v)


def _parse_redis_int(value: Any) -> int:
    """Parse a Redis string to a non-negative int, defaulting to ``0``."""
    if value is None:
        return 0
    try:
        return max(0, int(value))
    except (TypeError, ValueError):
        return 0


def _redis_result_is_one(value: Any) -> bool:
    """Return ``True`` for Redis integer-script results equal to 1."""
    if isinstance(value, bytes):
        return value == b"1"
    if isinstance(value, str):
        return value == "1"
    if isinstance(value, int):
        return value == 1
    return False


def _is_valid_datetime(dt: datetime | None) -> bool:
    return isinstance(dt, datetime) and math.isfinite(dt.timestamp())


def _normalize_queue_name(queue: str | None) -> str:
    normalized = (queue or "").strip()
    return normalized or "default"


def _scope_queue_name(app: str | None, queue: str | None) -> str:
    normalized_queue = _normalize_queue_name(queue)
    normalized_app = (app or "").strip()
    if not normalized_app or normalized_app == "unknown":
        return normalized_queue

    app_prefix = f"{normalized_app}:"
    if normalized_queue.startswith(app_prefix):
        return normalized_queue

    return f"{app_prefix}{normalized_queue}"


def _infer_input_json_schema(schema: Any) -> dict[str, Any] | None:
    """Extract JSON Schema from a Pydantic model class, if available."""
    if schema is None:
        return None
    model_json_schema = getattr(schema, "model_json_schema", None)
    if callable(model_json_schema):
        try:
            value = model_json_schema()
            if isinstance(value, dict):
                return cast(dict[str, Any], value)
            return None
        except Exception:
            return None
    return None


def _cron_to_dict(c: CronTrigger) -> dict[str, Any]:
    """Serialize a CronTrigger omitting None values (matches JS ``JSON.stringify`` behavior)."""
    d: dict[str, Any] = {"expression": c.expression}
    if c.timezone is not None:
        d["timezone"] = c.timezone
    if c.input is not None:
        d["input"] = c.input
    if c.id is not None:
        d["id"] = c.id
    return d


def _parse_enqueue_result(value: Any) -> tuple[str, str] | None:
    """Parse ``["created"|"existing", runId]`` from Lua script."""
    if isinstance(value, (list, tuple)):
        if len(value) == 1 and isinstance(value[0], (list, tuple)):
            return _parse_enqueue_result(value[0])
        if len(value) >= 2:
            kind_raw = value[0]
            run_id_raw = value[1]
            kind = kind_raw.decode() if isinstance(kind_raw, bytes) else str(kind_raw)
            run_id = run_id_raw.decode() if isinstance(run_id_raw, bytes) else str(run_id_raw)
            if kind in ("created", "existing") and run_id:
                return (kind, run_id)
    return None


def _decode(value: Any) -> str:
    """Decode bytes to str, pass through str, return empty string for None."""
    if isinstance(value, bytes):
        return value.decode()
    return str(value) if value is not None else ""


def _decode_optional_json_field(mapping: dict[str, Any], field: str) -> tuple[bool, Any | None]:
    """Decode optional ``*Json`` field while preserving explicit JSON ``null``.

    Returns ``(present, value)`` where ``present`` is ``True`` only when a valid
    serialized value exists (including ``"null"`` / undefined sentinel).
    """
    if field not in mapping:
        return (False, None)

    raw = mapping.get(field)
    if not isinstance(raw, str):
        return (False, None)

    parsed = safe_json_try_loads(raw)
    if parsed is not None:
        return (True, parsed)
    if raw in ("null", UNDEFINED_TOKEN):
        return (True, None)
    return (False, None)


def _decode_optional_json_string(raw: str | None) -> tuple[bool, Any | None]:
    """Decode an optional JSON string while preserving explicit JSON ``null``."""
    if raw is None:
        return (False, None)

    parsed = safe_json_try_loads(raw)
    if parsed is not None:
        return (True, parsed)
    if raw in ("null", UNDEFINED_TOKEN):
        return (True, None)
    return (False, None)


def is_retryable_error(err: BaseException) -> bool:
    return not isinstance(
        err, (InputValidationError, UnknownWorkflowError, OutputSerializationError, CanceledError, NonRetriableError)
    )


def is_terminal_status(status: RunStatus) -> bool:
    return status in ("succeeded", "failed", "canceled")


def compute_retry_delay_ms(attempt: int) -> int:
    """Exponential backoff with jitter, matching the TS client."""
    base = 250
    max_delay = 30_000
    exp: int = min(max_delay, base * (2 ** max(0, attempt - 1)))
    jitter = random.randint(0, 99)
    return int(exp + jitter)


def make_error_json(err: BaseException | Any) -> str:
    try:
        return safe_json_dumps(serialize_error(err))
    except Exception:
        return '{"name":"Error","message":"Failed to serialize original error","kind":"error"}'


async def validate_input_with_schema(schema: Any, input: Any) -> Any:
    try:
        model_validate = getattr(schema, "model_validate", None)
        if callable(model_validate):
            return model_validate(input)

        raise TypeError("Unsupported schema type for validate_input_with_schema")
    except InputValidationError:
        raise
    except Exception as err:
        raise InputValidationError("Workflow input validation failed", err) from err


# ---------- RunHandle ----------


@dataclass(slots=True)
class ConcreteRunHandle:
    """Concrete implementation of the RunHandle protocol."""

    id: str
    _client: RedflowClient

    async def get_state(self) -> RunState | None:
        return await self._client.get_run(self.id)

    async def result(self, *, timeout_ms: int = 30_000) -> Any:
        return await self._client.wait_for_result(self.id, timeout_ms=timeout_ms)


# ---------- RedflowClient ----------


class RedflowClient:
    """High-level client for creating and managing redflow workflow runs."""

    __slots__ = ("app", "prefix", "redis", "run_history_retention_ms")

    def __init__(
        self,
        redis: Redis[Any],
        prefix: str,
        app: str | None = None,
        run_history_retention_ms: int | None = None,
    ) -> None:
        self.redis = redis
        self.prefix = prefix
        normalized_app = (app or "").strip()
        self.app: str | None = normalized_app if normalized_app else None
        if (
            not isinstance(run_history_retention_ms, bool)
            and isinstance(run_history_retention_ms, (int, float))
            and math.isfinite(run_history_retention_ms)
            and run_history_retention_ms > 0
        ):
            self.run_history_retention_ms = math.floor(run_history_retention_ms)
        else:
            self.run_history_retention_ms = _default_run_history_retention_ms()

    async def close(self) -> None:
        await self.redis.aclose()

    # ---------- state management ----------

    async def reset_state(self) -> dict[str, int]:
        """Delete all redflow keys (testing/dev only)."""
        normalized = self.prefix.rstrip(":")
        pattern = f"{normalized}:*"
        deleted = 0
        cursor: int | str = 0

        while True:
            cursor, found_keys = await self.redis.scan(cursor=int(cursor), match=pattern, count=500)
            if found_keys:
                deleted += await self.redis.unlink(*found_keys)
            if cursor == 0:
                break

        with contextlib.suppress(Exception):
            deleted += await self.redis.unlink(normalized)

        return {"deleted": deleted}

    # ---------- workflow metadata ----------

    async def list_workflows(self) -> list[str]:
        members = await self.redis.smembers(K.workflows(self.prefix))
        return [_decode(m) for m in members]

    async def get_workflow_meta(self, name: str) -> WorkflowMeta | None:
        data = await self.redis.hgetall(K.workflow(self.prefix, name))
        if not data:
            return None

        decoded: dict[str, str] = {_decode(k): _decode(v) for k, v in data.items()}

        parsed_cron = safe_json_try_loads(decoded.get("cronJson"))
        cron_ids = safe_json_try_loads(decoded.get("cronIdsJson")) or []
        cron_list = parsed_cron if isinstance(parsed_cron, list) else []

        cron_with_next: list[WorkflowCronMeta] = []
        if cron_list:
            resolved_ids: list[str] = []
            for i, trigger in enumerate(cron_list):
                resolved_ids.append(
                    cron_ids[i]
                    if i < len(cron_ids)
                    else self._compute_cron_id(
                        name,
                        trigger.get("id"),
                        trigger.get("expression", ""),
                        trigger.get("timezone"),
                        trigger.get("input"),
                    )
                )
            cron_next_key = K.cron_next(self.prefix)
            pipe = self.redis.pipeline(transaction=False)
            for cid in resolved_ids:
                pipe.zscore(cron_next_key, cid)
            scores = await pipe.execute()

            for trigger, raw_next in zip(cron_list, scores, strict=True):
                entry = dict(trigger)
                if raw_next and _parse_redis_int(raw_next) > 0:
                    entry["next_run_at"] = int(raw_next)
                cron_with_next.append(entry)

        result: WorkflowMeta = {
            "name": name,
            "app": (decoded.get("app") or "unknown").strip() or "unknown",
            "queue": _normalize_queue_name(decoded.get("queue")),
            "max_concurrency": _normalize_max_concurrency(decoded.get("maxConcurrency", "1")),
            "updated_at": int(decoded.get("updatedAt", "0")),
        }
        max_attempts_raw = decoded.get("maxAttempts")
        if max_attempts_raw:
            result["max_attempts"] = int(max_attempts_raw)
        if cron_with_next:
            result["cron"] = cron_with_next

        input_schema_json = safe_json_try_loads(decoded.get("inputSchemaJson"))
        if isinstance(input_schema_json, dict):
            result["input_json_schema"] = input_schema_json

        return result

    async def list_workflows_meta(self) -> list[WorkflowMeta]:
        names = await self.list_workflows()
        metas = await asyncio.gather(*(self.get_workflow_meta(n) for n in names))
        return [m for m in metas if m is not None]

    async def get_stats(self) -> RunStats:
        pipe = self.redis.pipeline(transaction=False)
        for status in ALL_STATUSES:
            pipe.zcard(K.runs_status(self.prefix, status))
        results = await pipe.execute()

        by_status: dict[RunStatus, int] = {}
        total = 0
        for status, count_raw in zip(ALL_STATUSES, results, strict=True):
            count = _parse_redis_int(count_raw)
            by_status[status] = count
            total += count
        return {"total": total, "by_status": by_status}

    # ---------- run lifecycle ----------

    async def emit_workflow(
        self,
        workflow_name: str,
        input: Any,
        *,
        idempotency_key: str | None = None,
        idempotency_ttl: int | None = None,
        run_at: datetime | None = None,
    ) -> ConcreteRunHandle:
        return await self.run_by_name(
            workflow_name,
            input,
            idempotency_key=idempotency_key,
            idempotency_ttl=idempotency_ttl,
            run_at=run_at,
        )

    async def run_by_name(
        self,
        workflow_name: str,
        input: Any,
        *,
        idempotency_key: str | None = None,
        idempotency_ttl: int | None = None,
        run_at: datetime | None = None,
        queue_override: str | None = None,
        max_attempts_override: int | None = None,
    ) -> ConcreteRunHandle:
        if run_at is not None and not _is_valid_datetime(run_at):
            raise ValueError("Invalid runAt date")

        queue_from_registry, workflow_app = await asyncio.gather(
            self._get_queue_for_workflow(workflow_name),
            self._get_app_for_workflow(workflow_name),
        )
        queue_candidate = queue_override if queue_override is not None else queue_from_registry
        if not queue_candidate:
            raise UnknownWorkflowError(workflow_name)
        queue = _scope_queue_name(workflow_app or self.app, queue_candidate)

        normalized_max_attempts_override: int | None = None
        if (
            not isinstance(max_attempts_override, bool)
            and isinstance(max_attempts_override, (int, float))
            and math.isfinite(max_attempts_override)
            and max_attempts_override > 0
        ):
            normalized_max_attempts_override = math.floor(max_attempts_override)

        max_attempts = (
            normalized_max_attempts_override
            or await self._get_max_attempts_for_workflow(workflow_name)
            or DEFAULT_MAX_ATTEMPTS
        )

        return await self._enqueue_run(
            workflow_name=workflow_name,
            queue=queue,
            input=input,
            available_at=run_at,
            idempotency_key=idempotency_key,
            idempotency_ttl=idempotency_ttl,
            max_attempts=max_attempts,
        )

    async def cancel_run(self, run_id: str, *, reason: str = "") -> bool:
        run_key = K.run(self.prefix, run_id)
        ts = now_ms()

        requested_from = await self._request_cancellation(run_id, ts, reason)
        if requested_from == "__missing__":
            return False
        if requested_from in ("succeeded", "failed", "canceled"):
            return False
        if requested_from == "running":
            return True

        queue = _normalize_queue_name(_decode(await self.redis.hget(run_key, "queue")))

        canceled_now = await self.transition_run_status_if_current(run_id, requested_from, "canceled", ts)
        if canceled_now:
            await self._finalize_canceled_run_immediately(run_id, queue, ts)
            return True

        latest_status = _decode(await self.redis.hget(run_key, "status"))
        if latest_status in ("queued", "scheduled"):
            canceled_latest = await self.transition_run_status_if_current(run_id, latest_status, "canceled", ts)
            if canceled_latest:
                await self._finalize_canceled_run_immediately(run_id, queue, ts)
                return True

        final_status = _decode(await self.redis.hget(run_key, "status"))
        return final_status in ("running", "queued", "scheduled", "canceled")

    async def get_run(self, run_id: str) -> RunState | None:
        run_key = K.run(self.prefix, run_id)
        raw = await self.redis.hgetall(run_key)
        if not raw:
            return None

        data: dict[str, str] = {_decode(k): _decode(v) for k, v in raw.items()}
        input_json, output_json, error_json = await asyncio.gather(
            resolve_json_string_for_run(
                redis=self.redis,
                prefix=self.prefix,
                run_id=run_id,
                stored_value=data.get("inputJson") or "null",
            ),
            resolve_json_string_for_run(
                redis=self.redis,
                prefix=self.prefix,
                run_id=run_id,
                stored_value=data.get("outputJson"),
            ),
            resolve_json_string_for_run(
                redis=self.redis,
                prefix=self.prefix,
                run_id=run_id,
                stored_value=data.get("errorJson"),
            ),
        )

        input_val = safe_json_loads(input_json or "null")
        has_output, output_val = _decode_optional_json_string(output_json if "outputJson" in data else None)
        has_error, error_val = _decode_optional_json_string(error_json if "errorJson" in data else None)

        result: RunState = {
            "id": run_id,
            "workflow": data.get("workflow", ""),
            "queue": _normalize_queue_name(data.get("queue")),
            "status": data.get("status", "queued"),  # type: ignore[typeddict-item]
            "input": input_val,
            "attempt": int(data.get("attempt", "0")),
            "max_attempts": int(data.get("maxAttempts", str(DEFAULT_MAX_ATTEMPTS))),
            "created_at": int(data.get("createdAt", "0")),
        }
        if has_output:
            result["output"] = output_val
        if has_error:
            result["error"] = error_val
        if data.get("availableAt"):
            result["available_at"] = int(data["availableAt"])
        if data.get("startedAt"):
            result["started_at"] = int(data["startedAt"])
        if data.get("finishedAt"):
            result["finished_at"] = int(data["finishedAt"])
        if data.get("cancelRequestedAt"):
            result["cancel_requested_at"] = int(data["cancelRequestedAt"])
        if data.get("cancelReason"):
            result["cancel_reason"] = data["cancelReason"]

        return result

    async def get_run_steps(self, run_id: str) -> list[StepState]:
        steps_key = K.run_steps(self.prefix, run_id)
        raw = await self.redis.hgetall(steps_key)

        entries: list[tuple[int, StepState]] = []
        for name_raw, value_raw in raw.items():
            name = _decode(name_raw)
            parsed = safe_json_loads(_decode(value_raw))
            if not isinstance(parsed, dict):
                raise ValueError(f"Invalid step entry JSON for '{name}': expected object")

            order = parsed.get("seq", parsed.get("startedAt", 0))

            step: StepState = {"name": name, "status": parsed.get("status", "running")}
            if "startedAt" in parsed:
                step["started_at"] = parsed["startedAt"]
            if "finishedAt" in parsed:
                step["finished_at"] = parsed["finishedAt"]

            output_json, error_json = await asyncio.gather(
                resolve_json_string_for_run(
                    redis=self.redis,
                    prefix=self.prefix,
                    run_id=run_id,
                    stored_value=parsed.get("outputJson") if isinstance(parsed.get("outputJson"), str) else None,
                ),
                resolve_json_string_for_run(
                    redis=self.redis,
                    prefix=self.prefix,
                    run_id=run_id,
                    stored_value=parsed.get("errorJson") if isinstance(parsed.get("errorJson"), str) else None,
                ),
            )

            has_out, out = _decode_optional_json_string(output_json)
            has_err, err = _decode_optional_json_string(error_json)
            if has_out:
                step["output"] = out
            if has_err:
                step["error"] = err

            entries.append((order, step))

        entries.sort(key=lambda e: e[0])
        return [s for _, s in entries]

    async def get_run_attempts(self, run_id: str) -> list[AttemptTrace]:
        attempt_event_ids_raw, step_event_ids_raw = await asyncio.gather(
            self.redis.smembers(K.run_attempt_events(self.prefix, run_id)),
            self.redis.smembers(K.run_step_events(self.prefix, run_id)),
        )
        attempt_event_ids = [_decode(v) for v in attempt_event_ids_raw if _decode(v)]
        step_event_ids = [_decode(v) for v in step_event_ids_raw if _decode(v)]
        if not attempt_event_ids:
            return []

        attempt_raws, step_raws = await asyncio.gather(
            self.redis.hmget(K.trace_attempts_data(self.prefix), attempt_event_ids),
            self.redis.hmget(K.trace_steps_data(self.prefix), step_event_ids)
            if step_event_ids
            else asyncio.sleep(0, result=[]),
        )

        steps_by_attempt: dict[int, list[StepTrace]] = {}
        for raw_step in step_raws:
            if raw_step is None:
                continue
            parsed = safe_json_try_loads(_decode(raw_step))
            if not isinstance(parsed, dict) or parsed.get("type") != "step":
                continue

            attempt_num = _parse_redis_int(parsed.get("attempt"))
            step_trace: StepTrace = {
                "name": str(parsed.get("step", "")),
                "seq": _parse_redis_int(parsed.get("seq")),
                "status": str(parsed.get("status", "unknown")),
                "attempt": attempt_num,
                "started_at": _parse_redis_int(parsed.get("startedAt")),
                "finished_at": _parse_redis_int(parsed.get("finishedAt")),
            }

            if isinstance(parsed.get("outputJson"), str):
                step_trace["output"] = safe_json_try_loads(parsed["outputJson"])
            if isinstance(parsed.get("errorJson"), str):
                step_trace["error"] = safe_json_try_loads(parsed["errorJson"])

            steps_by_attempt.setdefault(attempt_num, []).append(step_trace)

        for steps in steps_by_attempt.values():
            steps.sort(key=lambda item: item.get("seq", 0))

        attempts: list[AttemptTrace] = []
        for raw_attempt in attempt_raws:
            if raw_attempt is None:
                continue
            parsed = safe_json_try_loads(_decode(raw_attempt))
            if not isinstance(parsed, dict) or parsed.get("type") != "attempt":
                continue

            attempt_num = _parse_redis_int(parsed.get("attempt"))
            attempt_trace: AttemptTrace = {
                "attempt": attempt_num,
                "status": str(parsed.get("status", "unknown")),
                "started_at": _parse_redis_int(parsed.get("startedAt")),
                "finished_at": _parse_redis_int(parsed.get("finishedAt")),
                "steps": steps_by_attempt.get(attempt_num, []),
            }

            if isinstance(parsed.get("outputJson"), str):
                attempt_trace["output"] = safe_json_try_loads(parsed["outputJson"])
            if isinstance(parsed.get("errorJson"), str):
                attempt_trace["error"] = safe_json_try_loads(parsed["errorJson"])

            attempts.append(attempt_trace)

        attempts.sort(key=lambda item: item.get("attempt", 0))
        return attempts

    async def list_runs(self, params: ListRunsParams | None = None) -> list[ListedRun]:
        p = params or ListRunsParams()
        limit = max(1, p.limit)
        offset = max(0, p.offset)

        if p.status and p.workflow:
            workflow_index_key = K.workflow_runs(self.prefix, p.workflow)
            result: list[ListedRun] = []
            cursor = 0
            skipped = 0
            batch_size = max(100, limit * 2)

            while len(result) < limit:
                run_ids_raw = await self.redis.zrevrange(workflow_index_key, cursor, cursor + batch_size - 1)
                if not run_ids_raw:
                    break
                cursor += len(run_ids_raw)

                run_ids = [_decode(rid_raw) for rid_raw in run_ids_raw]
                run_states = await self._get_runs_by_ids(run_ids)

                for run_state in run_states:
                    if not run_state or run_state.get("status") != p.status:
                        continue
                    if skipped < offset:
                        skipped += 1
                        continue
                    result.append(self._to_listed_run(run_state))
                    if len(result) >= limit:
                        break

            return result

        if p.status:
            index_key = K.runs_status(self.prefix, p.status)
        elif p.workflow:
            index_key = K.workflow_runs(self.prefix, p.workflow)
        else:
            index_key = K.runs_created(self.prefix)

        run_ids_raw = await self.redis.zrevrange(index_key, offset, offset + limit - 1)
        run_ids = [_decode(rid_raw) for rid_raw in run_ids_raw]
        run_states = await self._get_runs_by_ids(run_ids)
        return [self._to_listed_run(run_state) for run_state in run_states if run_state]

    def make_run_handle(self, run_id: str) -> ConcreteRunHandle:
        return ConcreteRunHandle(id=run_id, _client=self)

    async def wait_for_result(self, run_id: str, *, timeout_ms: int = 30_000) -> Any:
        deadline = now_ms() + timeout_ms
        missing_grace_ms = max(250, min(2000, _POLL_MS * 4))
        missing_since: int | None = None
        seen_state = False

        while True:
            state = await self.get_run(run_id)
            if not state:
                t = now_ms()
                if missing_since is None:
                    missing_since = t
                if t - missing_since >= missing_grace_ms:
                    if seen_state:
                        raise RedflowError(f"Run state unavailable: {run_id}")
                    raise RedflowError(f"Run not found: {run_id}")
                if t > deadline:
                    raise RedflowTimeoutError(f"Timed out waiting for run result ({run_id})")
                await asyncio.sleep(_POLL_MS / 1000)
                continue

            seen_state = True
            missing_since = None

            status = state.get("status")
            if status == "succeeded":
                return state.get("output")
            if status == "failed":
                raise RedflowError(f"Run failed: {safe_json_dumps(state.get('error'))}")
            if status == "canceled":
                cancel_reason = state.get("cancel_reason")
                raise CanceledError(f"Run canceled: {cancel_reason}" if cancel_reason else "Run canceled")

            if now_ms() > deadline:
                raise RedflowTimeoutError(f"Timed out waiting for run result ({run_id})")
            await asyncio.sleep(_POLL_MS / 1000)

    # ---------- registry sync ----------

    async def sync_registry(self, registry: WorkflowRegistry, *, app: str) -> None:
        app = app.strip()
        if not app:
            raise ValueError("sync_registry requires a non-empty app")

        defs = registry.list()
        sync_started_at = now_ms()
        registered_names = {d.options.name for d in defs}

        await self._cleanup_stale_workflows(registered_names, sync_started_at, app)

        for defn in defs:
            opts = defn.options
            name = opts.name
            queue = _scope_queue_name(app, opts.queue)
            max_concurrency = _normalize_max_concurrency(opts.max_concurrency)
            cron = opts.cron
            max_attempts = opts.max_attempts
            updated_at = now_ms()

            custom_cron_ids: set[str] = set()
            for c in cron:
                if c.id:
                    if c.id in custom_cron_ids:
                        raise ValueError(f"Duplicate cron trigger id '{c.id}' in workflow '{name}'")
                    custom_cron_ids.add(c.id)

            workflow_key = K.workflow(self.prefix, name)
            cron_def_key = K.cron_def(self.prefix)
            cron_next_key = K.cron_next(self.prefix)

            pipe = self.redis.pipeline(transaction=False)
            pipe.sadd(K.workflows(self.prefix), name)
            pipe.hget(workflow_key, "cronIdsJson")
            _, prev_cron_ids_raw = await pipe.execute()
            prev_cron_ids = safe_json_try_loads(_decode(prev_cron_ids_raw)) or []
            next_cron_ids = [self._compute_cron_id(name, c.id, c.expression, c.timezone, c.input) for c in cron]

            next_cron_id_set: set[str] = set()
            for cron_id in next_cron_ids:
                if cron_id in next_cron_id_set:
                    raise ValueError(
                        f"Duplicate cron trigger definition in workflow '{name}'. "
                        "Add explicit unique ids for identical cron entries."
                    )
                next_cron_id_set.add(cron_id)

            stale_cron_ids = [old_id for old_id in prev_cron_ids if old_id not in next_cron_id_set]
            if stale_cron_ids:
                pipe = self.redis.pipeline(transaction=False)
                pipe.hdel(cron_def_key, *stale_cron_ids)
                pipe.zrem(cron_next_key, *stale_cron_ids)
                await pipe.execute()

            cron_pipe = self.redis.pipeline(transaction=False)
            for i, c in enumerate(cron):
                cron_id = next_cron_ids[i]
                cron_input = c.input if c.input is not None else {}

                cron_def_data = {
                    "id": cron_id,
                    "workflow": name,
                    "queue": queue,
                    "maxConcurrency": max_concurrency,
                    "expression": c.expression,
                    "timezone": c.timezone,
                    "inputJson": safe_json_dumps(cron_input),
                }
                cron_pipe.hset(cron_def_key, cron_id, safe_json_dumps(cron_def_data))

                next_at = self._compute_next_cron_at_ms(c.expression, c.timezone)
                if next_at is not None:
                    cron_pipe.zadd(cron_next_key, {cron_id: next_at})
                else:
                    cron_pipe.zrem(cron_next_key, cron_id)

            if cron:
                await cron_pipe.execute()

            input_json_schema = _infer_input_json_schema(opts.input_schema)

            meta: dict[str, str] = {
                "name": name,
                "queue": queue,
                "maxConcurrency": str(max_concurrency),
                "app": app,
                "updatedAt": str(updated_at),
                "cronJson": safe_json_dumps([_cron_to_dict(c) for c in cron]),
                "cronIdsJson": safe_json_dumps(next_cron_ids),
            }
            if max_attempts is not None:
                meta["maxAttempts"] = str(max_attempts)
            if input_json_schema is not None:
                meta["inputSchemaJson"] = safe_json_dumps(input_json_schema)

            stale_fields: list[str] = []
            if max_attempts is None:
                stale_fields.append("maxAttempts")
            if input_json_schema is None:
                stale_fields.append("inputSchemaJson")

            pipe = self.redis.pipeline(transaction=False)
            pipe.hset(workflow_key, mapping=meta)
            if stale_fields:
                pipe.hdel(workflow_key, *stale_fields)
            await pipe.execute()

    # ---------- status transitions (used by worker) ----------

    async def transition_run_status(self, run_id: str, next_status: RunStatus, updated_at: int) -> None:
        status_index_prefix = K.runs_status(self.prefix, "")
        running_count_key = await self._resolve_workflow_running_key(run_id) or K.workflow_running(
            self.prefix, "__unknown__"
        )
        result = await TRANSITION_RUN_STATUS.execute(
            self.redis,
            keys=[K.run(self.prefix, run_id), K.runs_status(self.prefix, next_status), running_count_key],
            args=[run_id, next_status, str(updated_at), status_index_prefix],
        )
        if _decode(result) == "__missing__":
            raise RedflowError(f"Run not found: {run_id}")

    async def schedule_retry(
        self,
        run_id: str,
        *,
        queue: str,
        next_at: int,
        error_json: str,
        updated_at: int,
        workflow_name: str | None = None,
    ) -> None:
        """Atomically schedules a retry or raises if the run does not exist."""
        run_key = K.run(self.prefix, run_id)
        stored_error_json = await store_json_string_for_run(
            redis=self.redis,
            prefix=self.prefix,
            run_id=run_id,
            json_string=error_json,
        )
        wf_name = workflow_name or _decode(await self.redis.hget(run_key, "workflow")) or ""
        running_count_key = K.workflow_running(self.prefix, wf_name or "__unknown__")
        status_index_prefix = K.runs_status(self.prefix, "")
        result = await SCHEDULE_RETRY.execute(
            self.redis,
            keys=[
                run_key,
                K.runs_status(self.prefix, "scheduled"),
                K.queue_scheduled(self.prefix, queue),
                K.runs_status(self.prefix, "canceled"),
                running_count_key,
            ],
            args=[run_id, str(updated_at), str(next_at), stored_error_json, status_index_prefix],
        )
        decoded_result = _decode(result)
        if decoded_result == "__missing__":
            raise RedflowError(f"Run not found: {run_id}")
        if decoded_result == "canceled":
            await self._schedule_run_history_expiry(run_id, updated_at, run_key=run_key)

    async def transition_run_status_if_current(
        self,
        run_id: str,
        expected_status: str,
        next_status: RunStatus,
        updated_at: int,
    ) -> bool:
        running_count_key = K.workflow_running(self.prefix, "__unused__")
        if expected_status == "running" or next_status == "running":
            running_count_key = await self._resolve_workflow_running_key(run_id) or K.workflow_running(
                self.prefix, "__unknown__"
            )

        changed = await TRANSITION_IF_CURRENT_STATUS.execute(
            self.redis,
            keys=[
                K.run(self.prefix, run_id),
                K.runs_status(self.prefix, expected_status),
                K.runs_status(self.prefix, next_status),
                running_count_key,
            ],
            args=[run_id, expected_status, next_status, str(updated_at)],
        )
        return _redis_result_is_one(changed)

    async def finalize_run(
        self,
        run_id: str,
        *,
        status: RunStatus,
        output_json: str | None = None,
        error_json: str | None = None,
        finished_at: int,
        workflow_name: str | None = None,
    ) -> None:
        run_key = K.run(self.prefix, run_id)
        stored_output_json = (
            await store_json_string_for_run(
                redis=self.redis,
                prefix=self.prefix,
                run_id=run_id,
                json_string=output_json,
            )
            if output_json is not None
            else None
        )
        stored_error_json = (
            await store_json_string_for_run(
                redis=self.redis,
                prefix=self.prefix,
                run_id=run_id,
                json_string=error_json,
            )
            if error_json is not None
            else None
        )
        wf_name = workflow_name or _decode(await self.redis.hget(run_key, "workflow")) or ""
        running_count_key = K.workflow_running(self.prefix, wf_name or "__unknown__")

        result = await FINALIZE_TERMINAL_RUN.execute(
            self.redis,
            keys=[
                run_key,
                K.runs_status(self.prefix, "scheduled"),
                K.runs_status(self.prefix, "queued"),
                K.runs_status(self.prefix, "running"),
                K.runs_status(self.prefix, "succeeded"),
                K.runs_status(self.prefix, "failed"),
                K.runs_status(self.prefix, "canceled"),
                running_count_key,
            ],
            args=[
                run_id,
                status,
                str(finished_at),
                stored_output_json or "",
                stored_error_json or "",
                "1" if stored_output_json is not None else "0",
                "1" if stored_error_json is not None else "0",
            ],
        )
        decoded_result = _decode(result)
        if decoded_result == "__missing__":
            raise RedflowError(f"Run not found: {run_id}")
        await self._schedule_run_history_expiry(run_id, finished_at, run_key=run_key)

    async def promote_scheduled_run_if_due(
        self,
        run_id: str,
        *,
        queue: str,
        due_at: int,
        updated_at: int,
    ) -> str:
        """Returns ``"promoted"``, ``"not_due"``, ``"missing"``, or ``"stale"``."""
        result = await PROMOTE_SCHEDULED_RUN.execute(
            self.redis,
            keys=[
                K.run(self.prefix, run_id),
                K.queue_scheduled(self.prefix, queue),
                K.runs_status(self.prefix, "scheduled"),
                K.runs_status(self.prefix, "queued"),
                K.queue_ready(self.prefix, queue),
            ],
            args=[run_id, str(updated_at), str(due_at)],
        )
        decoded = _decode(result)
        if decoded in ("promoted", "not_due", "missing", "stale"):
            return decoded
        return "missing"

    async def transition_queued_to_running(
        self,
        run_id: str,
        *,
        workflow_name: str,
        max_concurrency: int,
        updated_at: int,
    ) -> int:
        """Returns 2 (moved), 1 (concurrency limit), or 0 (not queued/missing)."""
        result = await TRANSITION_QUEUED_TO_RUNNING.execute(
            self.redis,
            keys=[
                K.run(self.prefix, run_id),
                K.runs_status(self.prefix, "queued"),
                K.runs_status(self.prefix, "running"),
                K.workflow_running(self.prefix, workflow_name),
            ],
            args=[
                run_id,
                str(updated_at),
                workflow_name,
                str(max_concurrency),
                K.run(self.prefix, ""),
            ],
        )
        try:
            return int(result)
        except (TypeError, ValueError):
            return 0

    # ---------- internal ----------

    async def _resolve_workflow_running_key(self, run_id: str) -> str | None:
        workflow_name = _decode(await self.redis.hget(K.run(self.prefix, run_id), "workflow"))
        if not workflow_name:
            return None
        return K.workflow_running(self.prefix, workflow_name)

    async def _get_queue_for_workflow(self, workflow_name: str) -> str | None:
        raw = await self.redis.hget(K.workflow(self.prefix, workflow_name), "queue")
        return _normalize_queue_name(_decode(raw)) if raw else None

    async def _get_app_for_workflow(self, workflow_name: str) -> str | None:
        raw = await self.redis.hget(K.workflow(self.prefix, workflow_name), "app")
        app = _decode(raw).strip()
        return app or None

    async def _get_max_attempts_for_workflow(self, workflow_name: str) -> int | None:
        raw = await self.redis.hget(K.workflow(self.prefix, workflow_name), "maxAttempts")
        if not raw:
            return None
        try:
            v = int(raw)
            return v if v > 0 else None
        except (TypeError, ValueError):
            return None

    def _compute_cron_id(
        self,
        workflow_name: str,
        user_id: str | None,
        expression: str,
        timezone: str | None,
        input: Any,
    ) -> str:
        """Deterministic cron trigger ID from its defining properties (SHA-256 truncated to 24 hex chars)."""
        if user_id:
            stable = safe_json_dumps({"workflowName": workflow_name, "userId": user_id})
            h = hashlib.sha256(stable.encode()).hexdigest()[:24]
            return f"cron_user_{h}"

        obj: dict[str, Any] = {
            "workflowName": workflow_name,
            "expression": expression,
            "timezone": timezone,
            "input": input,
        }
        stable = safe_json_dumps(obj)
        h = hashlib.sha256(stable.encode()).hexdigest()[:24]
        return f"cron_auto_{h}"

    def _compute_next_cron_at_ms(self, expression: str, timezone: str | None) -> int | None:
        try:
            from cronsim import CronSim

            if timezone:
                from zoneinfo import ZoneInfo

                start = datetime.now(ZoneInfo(timezone))
            else:
                start = datetime.now()
            next_dt = next(CronSim(expression, start))
            return int(next_dt.timestamp() * 1000)
        except Exception:
            return None

    async def _cleanup_stale_workflows(
        self,
        registered_names: set[str],
        sync_started_at: int,
        app: str,
    ) -> None:
        existing_names = await self.list_workflows()
        for name in existing_names:
            if name in registered_names:
                continue
            wf_key = K.workflow(self.prefix, name)
            pipe = self.redis.pipeline(transaction=False)
            pipe.hget(wf_key, "app")
            pipe.hget(wf_key, "updatedAt")
            wf_app_raw, updated_at_raw = await pipe.execute()
            wf_app = (_decode(wf_app_raw)).strip()
            is_legacy_unscoped = wf_app == "" or wf_app == "unknown"
            if not is_legacy_unscoped and wf_app != app:
                continue
            updated_at = int(_decode(updated_at_raw) or "0")
            if updated_at > 0 and sync_started_at - updated_at < _STALE_WORKFLOW_GRACE_MS:
                continue
            await self._delete_workflow_metadata(name)

    async def cleanup_expired_runs_now(
        self,
        *,
        reference_time_ms: int | None = None,
        limit: int | None = None,
    ) -> int:
        effective_reference_time_ms = reference_time_ms if reference_time_ms is not None else now_ms()
        if not isinstance(limit, bool) and isinstance(limit, (int, float)) and math.isfinite(limit):
            effective_limit = max(1, math.floor(limit))
        else:
            effective_limit = _RUN_HISTORY_CLEANUP_BATCH

        stale_run_ids_raw = await self.redis.zrangebyscore(
            K.runs_expires_at(self.prefix),
            "-inf",
            str(effective_reference_time_ms),
            start=0,
            num=effective_limit,
        )
        stale_run_ids: list[str] = []
        for raw in stale_run_ids_raw:
            run_id = _decode(raw)
            if run_id:
                stale_run_ids.append(run_id)

        for stale_run_id in stale_run_ids:
            await self._purge_run_history(stale_run_id)

        return len(stale_run_ids)

    async def _purge_run_history(self, run_id: str) -> None:
        run_key = K.run(self.prefix, run_id)
        run_attempt_events_key = K.run_attempt_events(self.prefix, run_id)
        run_step_events_key = K.run_step_events(self.prefix, run_id)
        raw, attempt_trace_ids_raw, step_trace_ids_raw = await asyncio.gather(
            self.redis.hgetall(run_key),
            self.redis.smembers(run_attempt_events_key),
            self.redis.smembers(run_step_events_key),
        )
        data: dict[str, str] = {_decode(k): _decode(v) for k, v in raw.items()}
        workflow_name = (data.get("workflow") or "").strip()
        queue = (data.get("queue") or "").strip()
        attempt_trace_ids = [_decode(v) for v in attempt_trace_ids_raw if _decode(v)]
        step_trace_ids = [_decode(v) for v in step_trace_ids_raw if _decode(v)]

        pipe = self.redis.pipeline(transaction=False)
        pipe.zrem(K.runs_expires_at(self.prefix), run_id)
        pipe.zrem(K.runs_created(self.prefix), run_id)
        for status in ALL_STATUSES:
            pipe.zrem(K.runs_status(self.prefix, status), run_id)

        if workflow_name:
            pipe.zrem(K.workflow_runs(self.prefix, workflow_name), run_id)

        if queue:
            pipe.zrem(K.queue_scheduled(self.prefix, queue), run_id)
            pipe.lrem(K.queue_ready(self.prefix, queue), 0, run_id)
            pipe.lrem(K.queue_processing(self.prefix, queue), 0, run_id)

        if attempt_trace_ids:
            pipe.zrem(K.trace_attempts_index(self.prefix), *attempt_trace_ids)
            pipe.hdel(K.trace_attempts_data(self.prefix), *attempt_trace_ids)

        if step_trace_ids:
            pipe.zrem(K.trace_steps_index(self.prefix), *step_trace_ids)
            pipe.hdel(K.trace_steps_data(self.prefix), *step_trace_ids)

        pipe.delete(run_key)
        pipe.delete(K.run_steps(self.prefix, run_id))
        pipe.delete(K.run_blobs(self.prefix, run_id))
        pipe.delete(K.run_lease(self.prefix, run_id))
        pipe.delete(run_attempt_events_key)
        pipe.delete(run_step_events_key)
        await pipe.execute()

    async def _schedule_run_history_expiry(
        self,
        run_id: str,
        finished_at: int,
        *,
        run_key: str | None = None,
    ) -> None:
        expires_at = finished_at + self.run_history_retention_ms
        effective_run_key = run_key if run_key is not None else K.run(self.prefix, run_id)
        pipe = self.redis.pipeline(transaction=False)
        pipe.hset(effective_run_key, mapping={"expiresAt": str(expires_at)})
        pipe.zadd(K.runs_expires_at(self.prefix), {run_id: expires_at})
        await pipe.execute()

    async def _delete_workflow_metadata(self, workflow_name: str) -> None:
        wf_key = K.workflow(self.prefix, workflow_name)
        prev_cron_ids = safe_json_try_loads(_decode(await self.redis.hget(wf_key, "cronIdsJson"))) or []
        pipe = self.redis.pipeline(transaction=False)
        if prev_cron_ids:
            pipe.hdel(K.cron_def(self.prefix), *prev_cron_ids)
            pipe.zrem(K.cron_next(self.prefix), *prev_cron_ids)
        pipe.delete(wf_key)
        pipe.srem(K.workflows(self.prefix), workflow_name)
        await pipe.execute()

    async def _request_cancellation(self, run_id: str, requested_at: int, reason: str) -> str:
        result = await REQUEST_CANCELLATION.execute(
            self.redis,
            keys=[K.run(self.prefix, run_id)],
            args=[str(requested_at), reason],
        )
        decoded = _decode(result)
        return decoded if decoded else "__missing__"

    async def _finalize_canceled_run_immediately(self, run_id: str, queue: str, finished_at: int) -> None:
        run_key = K.run(self.prefix, run_id)
        expires_at = finished_at + self.run_history_retention_ms

        pipe = self.redis.pipeline(transaction=False)
        pipe.zrem(K.queue_scheduled(self.prefix, queue), run_id)
        pipe.lrem(K.queue_ready(self.prefix, queue), 0, run_id)
        pipe.lrem(K.queue_processing(self.prefix, queue), 0, run_id)
        pipe.hdel(run_key, "availableAt")
        pipe.hdel(run_key, "outputJson")
        pipe.hdel(run_key, "errorJson")
        pipe.hset(run_key, mapping={"finishedAt": str(finished_at), "expiresAt": str(expires_at)})
        pipe.zadd(K.runs_expires_at(self.prefix), {run_id: expires_at})
        await pipe.execute()

    async def _enqueue_run(
        self,
        *,
        workflow_name: str,
        queue: str,
        input: Any,
        available_at: datetime | None = None,
        idempotency_key: str | None = None,
        idempotency_ttl: int | None = None,
        max_attempts: int,
    ) -> ConcreteRunHandle:
        if available_at is not None and not _is_valid_datetime(available_at):
            raise ValueError("Invalid availableAt date")

        queue = _normalize_queue_name(queue)
        created_at = now_ms()
        available_at_ms: int | None = None
        if available_at is not None:
            available_at_ms = int(available_at.timestamp() * 1000)

        should_schedule = available_at_ms is not None and available_at_ms > created_at
        run_id = f"run_{uuid.uuid4()}"
        status: RunStatus = "scheduled" if should_schedule else "queued"
        run_key = K.run(self.prefix, run_id)
        stored_input_json = await store_json_string_for_run(
            redis=self.redis,
            prefix=self.prefix,
            run_id=run_id,
            json_string=safe_json_dumps(input),
        )

        idempotency_redis_key = (
            K.idempotency(self.prefix, workflow_name, idempotency_key)
            if idempotency_key
            else K.idempotency(self.prefix, "__unused__", run_id)
        )

        result = await ENQUEUE_RUN.execute(
            self.redis,
            keys=[
                run_key,
                K.runs_created(self.prefix),
                K.runs_status(self.prefix, status),
                K.workflow_runs(self.prefix, workflow_name),
                K.queue_ready(self.prefix, queue),
                K.queue_scheduled(self.prefix, queue),
                idempotency_redis_key,
            ],
            args=[
                run_id,
                workflow_name,
                queue,
                status,
                stored_input_json,
                str(created_at),
                str(available_at_ms) if should_schedule else "",
                str(max_attempts),
                "1" if idempotency_key else "0",
                str(idempotency_ttl if idempotency_ttl is not None else IDEMPOTENCY_TTL_SEC),
                K.run(self.prefix, ""),
            ],
        )

        parsed = _parse_enqueue_result(result)
        if not parsed:
            raise RedflowError(f"Failed to enqueue run '{workflow_name}': unexpected Redis response")

        kind, actual_run_id = parsed
        if kind == "existing":
            await self._repair_existing_run_placement(actual_run_id)

        return self.make_run_handle(actual_run_id)

    async def _repair_existing_run_placement(self, run_id: str) -> None:
        run_key = K.run(self.prefix, run_id)
        raw = await self.redis.hgetall(run_key)
        if not raw:
            return

        data: dict[str, str] = {_decode(k): _decode(v) for k, v in raw.items()}
        status = data.get("status")
        queue = _normalize_queue_name(data.get("queue"))
        workflow_name = data.get("workflow", "")
        created_at_raw = data.get("createdAt", "0")
        created_at = int(created_at_raw) if created_at_raw.isdigit() and int(created_at_raw) > 0 else now_ms()

        pipe = self.redis.pipeline(transaction=False)
        pipe.zadd(K.runs_created(self.prefix), {run_id: created_at})
        if status:
            pipe.zadd(K.runs_status(self.prefix, status), {run_id: created_at})
        if workflow_name:
            pipe.zadd(K.workflow_runs(self.prefix, workflow_name), {run_id: created_at})
        await pipe.execute()

        if status == "queued":
            ready_key = K.queue_ready(self.prefix, queue)
            processing_key = K.queue_processing(self.prefix, queue)
            in_ready, in_processing = await asyncio.gather(
                self._list_contains(ready_key, run_id),
                self._list_contains(processing_key, run_id),
            )
            if not (in_ready or in_processing):
                await self.redis.lpush(ready_key, run_id)

        elif status == "scheduled":
            scheduled_key = K.queue_scheduled(self.prefix, queue)
            score = await self.redis.zscore(scheduled_key, run_id)
            if score is None:
                available_at_raw = data.get("availableAt", "0")
                available_at = (
                    int(available_at_raw) if available_at_raw.isdigit() and int(available_at_raw) > 0 else now_ms()
                )
                await self.redis.zadd(scheduled_key, {run_id: available_at})

    async def _list_contains(self, list_key: str, value: str) -> bool:
        try:
            # redis>=6.0 supports LPOS and avoids transferring full queue contents.
            redis_exec = cast(_RedisExecCommandProto, self.redis)
            position = await redis_exec.execute_command("LPOS", list_key, value)
            return position is not None
        except Exception:
            # Fallback for older Redis versions.
            items = await self.redis.lrange(list_key, 0, -1)
            return any(_decode(item) == value for item in items)

    @staticmethod
    def _run_state_from_hash(run_id: str, raw: Any) -> RunState | None:
        if not raw:
            return None

        data: dict[str, str] = {_decode(k): _decode(v) for k, v in raw.items()}

        input_val = safe_json_loads(data.get("inputJson") or "null")
        has_output, output_val = _decode_optional_json_field(data, "outputJson")
        has_error, error_val = _decode_optional_json_field(data, "errorJson")

        result: RunState = {
            "id": run_id,
            "workflow": data.get("workflow", ""),
            "queue": _normalize_queue_name(data.get("queue")),
            "status": data.get("status", "queued"),  # type: ignore[typeddict-item]
            "input": input_val,
            "attempt": int(data.get("attempt", "0")),
            "max_attempts": int(data.get("maxAttempts", str(DEFAULT_MAX_ATTEMPTS))),
            "created_at": int(data.get("createdAt", "0")),
        }
        if has_output:
            result["output"] = output_val
        if has_error:
            result["error"] = error_val
        if data.get("availableAt"):
            result["available_at"] = int(data["availableAt"])
        if data.get("startedAt"):
            result["started_at"] = int(data["startedAt"])
        if data.get("finishedAt"):
            result["finished_at"] = int(data["finishedAt"])
        if data.get("cancelRequestedAt"):
            result["cancel_requested_at"] = int(data["cancelRequestedAt"])
        if data.get("cancelReason"):
            result["cancel_reason"] = data["cancelReason"]

        return result

    async def _get_runs_by_ids(self, run_ids: list[str]) -> list[RunState | None]:
        if not run_ids:
            return []
        return await asyncio.gather(*(self.get_run(run_id) for run_id in run_ids))

    @staticmethod
    def _to_listed_run(run: RunState) -> ListedRun:
        result: ListedRun = {
            "id": run["id"],
            "workflow": run["workflow"],
            "queue": run["queue"],
            "status": run["status"],
            "created_at": run["created_at"],
            "attempt": run["attempt"],
            "max_attempts": run["max_attempts"],
        }
        if "error" in run:
            result["error"] = run["error"]
        if "available_at" in run:
            result["available_at"] = run["available_at"]
        if "started_at" in run:
            result["started_at"] = run["started_at"]
        if "finished_at" in run:
            result["finished_at"] = run["finished_at"]
        return result


# ---------- factory ----------


def create_client(
    *,
    app: str | None = None,
    redis: Redis[Any] | None = None,
    url: str | None = None,
    prefix: str | None = None,
) -> RedflowClient:
    """Create a :class:`RedflowClient` with sensible defaults."""
    pfx = prefix if prefix is not None else default_prefix()
    # Resolve app: explicit arg > REDFLOW_APP env var > None
    resolved_app = (app or "").strip() or os.environ.get("REDFLOW_APP", "").strip() or None
    if redis is not None:
        return RedflowClient(redis, pfx, resolved_app)
    if url:
        return RedflowClient(Redis.from_url(url), pfx, resolved_app)
    return RedflowClient(Redis.from_url(os.environ.get("REDIS_URL", "redis://localhost:6379")), pfx, resolved_app)


def get_default_client() -> RedflowClient:
    return _get_default_client_impl()


def set_default_client(client: RedflowClient | None) -> None:
    _set_default_client_impl(client)
