"""Core data types — wire-compatible with the TypeScript ``types.ts``."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal, Protocol, TypedDict, runtime_checkable

RunStatus = Literal["scheduled", "queued", "running", "succeeded", "failed", "canceled"]
StepStatus = Literal["running", "succeeded", "failed"]

ALL_STATUSES: tuple[RunStatus, ...] = ("scheduled", "queued", "running", "succeeded", "failed", "canceled")
TERMINAL_STATUSES: frozenset[RunStatus] = frozenset({"succeeded", "failed", "canceled"})
DEFAULT_MAX_ATTEMPTS = 3
IDEMPOTENCY_TTL_SEC = 60 * 60 * 24 * 7  # 7 days


# ---------- Cron ----------


@dataclass(frozen=True, slots=True)
class CronTrigger:
    expression: str
    timezone: str | None = None
    input: Any = None
    id: str | None = None


# ---------- Workflow options ----------


@dataclass(slots=True)
class OnFailureContext:
    error: Any
    input: Any
    run: RunContext


@dataclass(frozen=True, slots=True)
class RunContext:
    id: str
    workflow: str
    queue: str
    attempt: int
    max_attempts: int


@dataclass(slots=True)
class DefineWorkflowOptions:
    name: str
    queue: str = "default"
    max_concurrency: int = 1
    max_attempts: int | None = None
    cron: list[CronTrigger] = field(default_factory=list)
    on_failure: Any | None = None  # Callable[[OnFailureContext], Awaitable[None] | None]
    input_schema: Any | None = None  # Pydantic BaseModel subclass for input validation


# ---------- Step options ----------


@dataclass(frozen=True, slots=True)
class StepRunOptions:
    name: str
    timeout_ms: int | None = None


# ---------- Run state ----------


class RunState(TypedDict, total=False):
    id: str
    workflow: str
    queue: str
    status: RunStatus
    input: Any
    output: Any
    error: Any
    attempt: int
    max_attempts: int
    created_at: int
    available_at: int
    started_at: int
    finished_at: int
    cancel_requested_at: int
    cancel_reason: str


class StepState(TypedDict, total=False):
    name: str
    status: StepStatus
    started_at: int
    finished_at: int
    output: Any
    error: Any


class StepTrace(TypedDict, total=False):
    attempt: int
    error: Any
    finished_at: int
    name: str
    output: Any
    seq: int
    started_at: int
    status: str


class AttemptTrace(TypedDict, total=False):
    attempt: int
    error: Any
    finished_at: int
    output: Any
    started_at: int
    status: str
    steps: list[StepTrace]


# ---------- Listing ----------


class ListedRun(TypedDict, total=False):
    id: str
    workflow: str
    queue: str
    status: RunStatus
    error: Any
    created_at: int
    available_at: int
    started_at: int
    finished_at: int
    attempt: int
    max_attempts: int


@dataclass(frozen=True, slots=True)
class ListRunsParams:
    status: RunStatus | None = None
    workflow: str | None = None
    offset: int = 0
    limit: int = 50


class RunStats(TypedDict):
    total: int
    by_status: dict[RunStatus, int]


# ---------- Workflow metadata ----------


class WorkflowCronMeta(TypedDict, total=False):
    expression: str
    timezone: str
    input: Any
    id: str
    next_run_at: int


class WorkflowMeta(TypedDict, total=False):
    name: str
    app: str
    queue: str
    max_concurrency: int
    max_attempts: int
    cron: list[WorkflowCronMeta]
    input_json_schema: dict[str, Any]
    updated_at: int


# ---------- Run handle ----------


@runtime_checkable
class RunHandle(Protocol):
    @property
    def id(self) -> str: ...
    async def get_state(self) -> RunState | None: ...
    async def result(self, *, timeout_ms: int = 30_000) -> Any: ...


# ---------- Workflow protocol ----------


@runtime_checkable
class WorkflowLike(Protocol):
    @property
    def name(self) -> str: ...
    async def run(self, input: Any, **kwargs: Any) -> RunHandle: ...
