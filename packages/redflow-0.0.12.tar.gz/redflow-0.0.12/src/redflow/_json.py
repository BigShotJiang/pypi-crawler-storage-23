"""JSON helpers that stay wire-compatible with the TypeScript client.

The TS client uses a sentinel string to represent ``undefined`` values
(JavaScript has both ``null`` and ``undefined``; Python only has ``None``).
We map Python ``None`` to JSON ``null`` and reserve the sentinel for
explicit ``undefined`` round-trips.
"""

from __future__ import annotations

import json
import math
from typing import Any, overload

UNDEFINED_TOKEN = "__redflow_undefined_raw__:v1"


def safe_json_dumps(value: Any) -> str:
    """Serialize *value* to a JSON string.

    ``None`` becomes ``"null"`` (standard JSON).
    If the value is not serializable a ``TypeError`` propagates.
    """
    if value is None:
        return "null"

    normalized = _normalize_for_json_stringify(value)
    return json.dumps(normalized, separators=(",", ":"), ensure_ascii=False, allow_nan=False)


def safe_json_loads(raw: str | None) -> Any:
    """Deserialize a JSON string produced by either the TS or Python client.

    Raises ``ValueError`` when *raw* is ``None`` (missing data).
    """
    if raw is None:
        raise ValueError("Expected JSON string, got None")

    if raw == UNDEFINED_TOKEN:
        return None

    return json.loads(raw)


@overload
def safe_json_try_loads(raw: str) -> Any: ...


@overload
def safe_json_try_loads(raw: None) -> None: ...


def safe_json_try_loads(raw: str | None) -> Any | None:
    """Like :func:`safe_json_loads` but returns ``None`` on failure."""
    if raw is None:
        return None
    try:
        return safe_json_loads(raw)
    except (ValueError, json.JSONDecodeError):
        return None


def _normalize_for_json_stringify(value: Any) -> Any:
    """Approximate JS ``JSON.stringify`` semantics for Python values.

    In particular, non-finite floats (NaN/Infinity) become ``null`` in JS.
    Python's ``json.dumps`` would emit ``NaN``/``Infinity`` by default, which
    breaks TS ``JSON.parse`` compatibility.
    """
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, list):
        return [_normalize_for_json_stringify(item) for item in value]
    if isinstance(value, tuple):
        return [_normalize_for_json_stringify(item) for item in value]
    if isinstance(value, dict):
        return {k: _normalize_for_json_stringify(v) for k, v in value.items()}
    return value
