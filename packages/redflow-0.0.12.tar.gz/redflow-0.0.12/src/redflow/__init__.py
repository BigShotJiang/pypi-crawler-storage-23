"""redflow — Durable workflow engine backed by Redis.

Public API
----------

Client
~~~~~~
.. autoclass:: RedflowClient
.. autofunction:: create_client

Workflow definition
~~~~~~~~~~~~~~~~~~~
.. autofunction:: define_workflow
.. autodecorator:: workflow
.. autoclass:: WorkflowRegistry
.. autoclass:: WorkflowHandlerContext
.. autoclass:: WorkflowDefinition

Worker
~~~~~~
.. autofunction:: start_worker
.. autoclass:: StartWorkerOptions
.. autoclass:: WorkerHandle

Testing
~~~~~~~
.. autofunction:: run_inline
.. autoclass:: InlineRunResult
.. autoclass:: InlineStepResult

Types
~~~~~
.. autoclass:: RunState
.. autoclass:: StepState
.. autoclass:: RunStats
.. autoclass:: CronTrigger
.. autoclass:: DefineWorkflowOptions

Errors
~~~~~~
.. autoclass:: RedflowError
.. autoclass:: CanceledError
.. autoclass:: NonRetriableError
.. autoclass:: TimeoutError
"""

from .client import (
    ConcreteRunHandle as RunHandle,
)
from .client import (
    RedflowClient,
    create_client,
    default_prefix,
    is_terminal_status,
    validate_input_with_schema,
)
from .default import get_default_client, set_default_client
from .errors import (
    CanceledError,
    InputValidationError,
    NonRetriableError,
    OutputSerializationError,
    RedflowError,
    TimeoutError,
    UnknownWorkflowError,
)
from .registry import (
    WorkflowDefinition,
    WorkflowHandlerContext,
    WorkflowRegistry,
    __unstable_reset_default_registry_for_tests,
    define_workflow,
    get_default_registry,
    workflow,
)
from .testing import InlineRunResult, InlineStepResult, run_inline
from .types import (
    AttemptTrace,
    CronTrigger,
    DefineWorkflowOptions,
    ListedRun,
    ListRunsParams,
    OnFailureContext,
    RunState,
    RunStats,
    RunStatus,
    StepState,
    StepTrace,
    WorkflowMeta,
)
from .worker import StartWorkerOptions, WorkerHandle, start_worker

__all__ = [
    "AttemptTrace",
    "CanceledError",
    "CronTrigger",
    "DefineWorkflowOptions",
    "InlineRunResult",
    "InlineStepResult",
    "InputValidationError",
    "ListRunsParams",
    "ListedRun",
    "NonRetriableError",
    "OnFailureContext",
    "OutputSerializationError",
    "RedflowClient",
    "RedflowError",
    "RunHandle",
    "RunState",
    "RunStats",
    "RunStatus",
    "StartWorkerOptions",
    "StepState",
    "StepTrace",
    "TimeoutError",
    "UnknownWorkflowError",
    "WorkerHandle",
    "WorkflowDefinition",
    "WorkflowHandlerContext",
    "WorkflowMeta",
    "WorkflowRegistry",
    "__unstable_reset_default_registry_for_tests",
    "create_client",
    "default_prefix",
    "define_workflow",
    "get_default_client",
    "get_default_registry",
    "is_terminal_status",
    "run_inline",
    "set_default_client",
    "start_worker",
    "validate_input_with_schema",
    "workflow",
]
