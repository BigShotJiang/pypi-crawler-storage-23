"""Default client registry (mirrors TS ``default.ts`` structure).

This module owns the process-global default client instance. ``client.py`` keeps
wrapper functions for backward compatibility, but the state lives here so
workflow helpers can depend on a small, focused module.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .client import RedflowClient

_default_client: RedflowClient | None = None


def get_default_client() -> RedflowClient:
    global _default_client
    if _default_client is None:
        from .client import create_client

        _default_client = create_client()
    return _default_client


def set_default_client(client: RedflowClient | None) -> None:
    global _default_client
    _default_client = client

