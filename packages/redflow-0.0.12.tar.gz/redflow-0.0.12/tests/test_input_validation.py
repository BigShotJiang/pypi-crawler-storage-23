"""Tests for Pydantic input schema validation in the worker."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import pytest

from redflow.errors import InputValidationError
from redflow.registry import WorkflowHandlerContext, define_workflow
from redflow.testing import run_inline

pydantic = pytest.importorskip("pydantic")
BaseModel = pydantic.BaseModel


class UserInput(BaseModel):
    name: str
    age: int


@dataclass
class _FakeOpts:
    input_schema: Any


@dataclass
class _FakeDefn:
    options: _FakeOpts


class TestValidateInput:
    def test_no_schema_passthrough(self) -> None:
        from redflow.worker import _validate_input

        defn = _FakeDefn(options=_FakeOpts(input_schema=None))
        raw = {"name": "Alice", "age": 30}
        assert _validate_input(defn, raw) == raw

    def test_valid_pydantic(self) -> None:
        from redflow.worker import _validate_input

        defn = _FakeDefn(options=_FakeOpts(input_schema=UserInput))
        result = _validate_input(defn, {"name": "Bob", "age": 25})
        assert isinstance(result, UserInput)
        assert result.name == "Bob"
        assert result.age == 25

    def test_invalid_pydantic(self) -> None:
        from redflow.worker import _validate_input

        defn = _FakeDefn(options=_FakeOpts(input_schema=UserInput))
        with pytest.raises(InputValidationError, match="Workflow input validation failed") as exc_info:
            _validate_input(defn, {"name": "Charlie"})  # missing required 'age'
        assert exc_info.value.issues is not None

    def test_wrong_type(self) -> None:
        from redflow.worker import _validate_input

        defn = _FakeDefn(options=_FakeOpts(input_schema=UserInput))
        with pytest.raises(InputValidationError):
            _validate_input(defn, {"name": 123, "age": "not_an_int"})


class TestInputValidationInline:
    """Test input_schema through run_inline end-to-end."""

    async def test_valid_input_passes(self) -> None:
        wf = define_workflow(
            "test-valid-input",
            handler=_echo_handler,
            input_schema=UserInput,
        )
        result = await run_inline(wf, input={"name": "Alice", "age": 30})
        assert result.succeeded
        assert result.output["name"] == "Alice"

    async def test_invalid_input_fails(self) -> None:
        wf = define_workflow(
            "test-invalid-input",
            handler=_echo_handler,
            input_schema=UserInput,
        )
        result = await run_inline(wf, input={"name": "Bob"})  # missing age
        assert not result.succeeded


async def _echo_handler(ctx: WorkflowHandlerContext[Any]) -> dict[str, Any]:
    inp = ctx.input
    if isinstance(inp, BaseModel):
        return inp.model_dump()
    return dict(inp) if isinstance(inp, dict) else {"value": inp}
