"""Test workflow registry and define_workflow."""

import pytest

import redflow.default as redflow_default_module
from redflow.errors import InputValidationError
from redflow.registry import (
    WorkflowDefinition,
    WorkflowHandlerContext,
    WorkflowRegistry,
    define_workflow,
    workflow,
)


async def _noop_handler(ctx: WorkflowHandlerContext) -> dict:
    return {"done": True}


def test_register_and_get() -> None:
    reg = WorkflowRegistry()
    defn = define_workflow("test-wf", handler=_noop_handler, registry=reg)
    assert reg.get("test-wf") is defn
    assert reg.get("nonexistent") is None


def test_list() -> None:
    reg = WorkflowRegistry()
    define_workflow("wf-1", handler=_noop_handler, registry=reg)
    define_workflow("wf-2", handler=_noop_handler, registry=reg)
    names = [d.options.name for d in reg.list()]
    assert "wf-1" in names
    assert "wf-2" in names


def test_last_registration_wins() -> None:
    reg = WorkflowRegistry()

    async def handler_a(ctx: WorkflowHandlerContext) -> str:
        return "a"

    async def handler_b(ctx: WorkflowHandlerContext) -> str:
        return "b"

    define_workflow("same-name", handler=handler_a, registry=reg)
    define_workflow("same-name", handler=handler_b, registry=reg)
    assert reg.get("same-name") is not None
    assert reg.get("same-name").handler is handler_b  # type: ignore[union-attr]


def test_clear() -> None:
    reg = WorkflowRegistry()
    define_workflow("wf", handler=_noop_handler, registry=reg)
    reg.clear()
    assert reg.list() == []


def test_decorator_api() -> None:
    reg = WorkflowRegistry()

    @workflow("decorated-wf", queue="fast", registry=reg)
    async def my_handler(ctx: WorkflowHandlerContext) -> dict:
        return {"ok": True}

    assert isinstance(my_handler, WorkflowDefinition)
    assert my_handler.options.name == "decorated-wf"
    assert my_handler.options.queue == "fast"
    assert reg.get("decorated-wf") is my_handler


def test_default_options() -> None:
    reg = WorkflowRegistry()
    defn = define_workflow("defaults", handler=_noop_handler, registry=reg)
    assert defn.options.queue == "default"
    assert defn.options.max_concurrency == 1
    assert defn.options.max_attempts is None
    assert defn.options.cron == []


async def test_workflow_definition_run_uses_default_client_and_definition_defaults(monkeypatch) -> None:
    calls: dict[str, object] = {}

    class _FakeClient:
        async def run_by_name(self, workflow_name: str, input: object, **kwargs: object) -> dict[str, bool]:
            calls["workflow_name"] = workflow_name
            calls["input"] = input
            calls.update(kwargs)
            return {"ok": True}

    monkeypatch.setattr(redflow_default_module, "_default_client", _FakeClient())

    reg = WorkflowRegistry()
    defn = define_workflow("wf-run", handler=_noop_handler, queue="fast", max_attempts=4, registry=reg)

    result = await defn.run({"x": 1})

    assert result == {"ok": True}
    assert calls["workflow_name"] == "wf-run"
    assert calls["input"] == {"x": 1}
    assert calls["queue_override"] == "fast"
    assert calls["max_attempts_override"] == 4


async def test_workflow_definition_run_validates_input_before_client_call(monkeypatch) -> None:
    called = False

    class _FakeClient:
        async def run_by_name(self, workflow_name: str, input: object, **kwargs: object) -> dict[str, bool]:
            nonlocal called
            called = True
            return {"ok": True}

    class _Schema:
        @staticmethod
        def model_validate(value: object) -> object:
            raise ValueError("bad")

    monkeypatch.setattr(redflow_default_module, "_default_client", _FakeClient())

    reg = WorkflowRegistry()
    defn = define_workflow("wf-schema", handler=_noop_handler, input_schema=_Schema, registry=reg)

    with pytest.raises(InputValidationError, match="Workflow input validation failed"):
        await defn.run({"x": 1})

    assert called is False


async def test_workflow_definition_run_normalizes_max_attempts_like_ts(monkeypatch) -> None:
    calls: list[dict[str, object]] = []

    class _FakeClient:
        async def run_by_name(self, workflow_name: str, input: object, **kwargs: object) -> dict[str, bool]:
            calls.append({"workflow_name": workflow_name, "input": input, **kwargs})
            return {"ok": True}

    monkeypatch.setattr(redflow_default_module, "_default_client", _FakeClient())

    reg = WorkflowRegistry()
    defn_bool = define_workflow("wf-bool", handler=_noop_handler, max_attempts=True, registry=reg)  # type: ignore[arg-type]
    defn_float = define_workflow("wf-float", handler=_noop_handler, max_attempts=4.9, registry=reg)  # type: ignore[arg-type]

    await defn_bool.run({"x": 1})
    await defn_float.run({"x": 2})

    assert calls[0]["workflow_name"] == "wf-bool"
    assert calls[0]["max_attempts_override"] is None

    assert calls[1]["workflow_name"] == "wf-float"
    assert calls[1]["max_attempts_override"] == 4
