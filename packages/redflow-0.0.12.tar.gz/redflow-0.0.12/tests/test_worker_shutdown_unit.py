"""Unit tests for worker shutdown and cancellation helpers."""

from __future__ import annotations

import asyncio
import contextlib
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest

import redflow.worker as worker_module
from redflow.worker import WorkerHandle, _accepts_signal_kwarg, _cancel_task_and_drain, _normalize_blmove_timeout_sec


class _FakeRedis:
    def __init__(self) -> None:
        self.aclose = AsyncMock()


def test_normalize_blmove_timeout_sec_clamps_zero_and_invalid() -> None:
    assert _normalize_blmove_timeout_sec(0) == 1
    assert _normalize_blmove_timeout_sec(-10) == 1
    assert _normalize_blmove_timeout_sec("bad") == 1
    assert _normalize_blmove_timeout_sec(5) == 5


def test_accepts_signal_kwarg_matches_callable_signatures() -> None:
    async def _with_signal(*, signal: asyncio.Event) -> None:
        _ = signal

    async def _with_kwargs(**kwargs: object) -> None:
        _ = kwargs

    async def _without_signal() -> None:
        return None

    assert _accepts_signal_kwarg(_with_signal) is True
    assert _accepts_signal_kwarg(_with_kwargs) is True
    assert _accepts_signal_kwarg(_without_signal) is False


def test_accepts_signal_kwarg_handles_non_weakrefable_callables() -> None:
    assert _accepts_signal_kwarg(len) is False


@pytest.mark.asyncio
async def test_cancel_task_and_drain_returns_true_for_cooperative_cancellation() -> None:
    started = asyncio.Event()

    async def _cooperative() -> None:
        started.set()
        await asyncio.Event().wait()

    task = asyncio.create_task(_cooperative(), name="cooperative")
    await started.wait()

    drained = await _cancel_task_and_drain(task, timeout_s=0.05, label="test-cooperative")

    assert drained is True
    assert task.cancelled()


@pytest.mark.asyncio
async def test_cancel_task_and_drain_times_out_when_task_suppresses_cancel() -> None:
    started = asyncio.Event()
    allow_exit = asyncio.Event()

    async def _stubborn() -> None:
        started.set()
        while True:
            try:
                await asyncio.Event().wait()
            except asyncio.CancelledError:
                if allow_exit.is_set():
                    raise
                # Suppress cancellation (bad user code) and keep running.
                continue

    task = asyncio.create_task(_stubborn(), name="stubborn")
    await started.wait()

    drained = await _cancel_task_and_drain(task, timeout_s=0.01, label="test-stubborn")

    assert drained is False
    assert not task.done()

    allow_exit.set()
    task.cancel()
    with contextlib.suppress(asyncio.CancelledError, Exception):
        await asyncio.wait_for(task, timeout=1)


@pytest.mark.asyncio
async def test_worker_handle_stop_cancels_slot_tasks_and_closes_owned_redis() -> None:
    stop_event = asyncio.Event()
    slot_started = asyncio.Event()

    async def _slot_loop() -> None:
        slot_started.set()
        await asyncio.Event().wait()

    slot_task = asyncio.create_task(_slot_loop(), name="slot-1")
    await slot_started.wait()

    fake_redis = _FakeRedis()
    handle = WorkerHandle(
        stop_event=stop_event,
        tasks=[],
        owned_redis=[fake_redis],  # type: ignore[list-item]
        slots=[SimpleNamespace(task=slot_task)],
    )

    await asyncio.wait_for(handle.stop(), timeout=1)

    assert stop_event.is_set()
    assert slot_task.cancelled()
    fake_redis.aclose.assert_awaited_once()


@pytest.mark.asyncio
async def test_worker_handle_stop_does_not_hang_on_stubborn_slot_task(monkeypatch) -> None:
    stop_event = asyncio.Event()
    slot_started = asyncio.Event()
    allow_exit = asyncio.Event()

    async def _stubborn_slot() -> None:
        slot_started.set()
        while True:
            try:
                await asyncio.Event().wait()
            except asyncio.CancelledError:
                if allow_exit.is_set():
                    raise
                continue

    slot_task = asyncio.create_task(_stubborn_slot(), name="slot-stubborn")
    await slot_started.wait()

    monkeypatch.setattr(worker_module, "_STOP_SLOT_CANCEL_DRAIN_TIMEOUT_S", 0.01)

    fake_redis = _FakeRedis()
    handle = WorkerHandle(
        stop_event=stop_event,
        tasks=[],
        owned_redis=[fake_redis],  # type: ignore[list-item]
        slots=[SimpleNamespace(task=slot_task)],
    )

    await asyncio.wait_for(handle.stop(), timeout=1)

    assert stop_event.is_set()
    assert not slot_task.done()
    fake_redis.aclose.assert_awaited_once()

    allow_exit.set()
    slot_task.cancel()
    with contextlib.suppress(asyncio.CancelledError, Exception):
        await asyncio.wait_for(slot_task, timeout=1)
