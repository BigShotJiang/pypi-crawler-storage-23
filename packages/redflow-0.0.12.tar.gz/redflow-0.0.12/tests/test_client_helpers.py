"""Tests for client.py helper functions that don't require Redis."""

from __future__ import annotations

import pytest

from redflow.client import (
    RedflowClient,
    _decode,
    _default_run_history_retention_ms,
    _normalize_max_concurrency,
    _parse_enqueue_result,
    _parse_redis_int,
    compute_retry_delay_ms,
    create_client,
    default_prefix,
    get_default_client,
    is_retryable_error,
    is_terminal_status,
    make_error_json,
    set_default_client,
    validate_input_with_schema,
)
from redflow.errors import (
    CanceledError,
    InputValidationError,
    NonRetriableError,
    OutputSerializationError,
    UnknownWorkflowError,
)


class TestNormalizeMaxConcurrency:
    def test_positive_int(self) -> None:
        assert _normalize_max_concurrency(5) == 5

    def test_zero_clamps_to_one(self) -> None:
        assert _normalize_max_concurrency(0) == 1

    def test_negative_clamps_to_one(self) -> None:
        assert _normalize_max_concurrency(-3) == 1

    def test_string_number(self) -> None:
        assert _normalize_max_concurrency("10") == 10

    def test_none_returns_one(self) -> None:
        assert _normalize_max_concurrency(None) == 1

    def test_invalid_string_returns_one(self) -> None:
        assert _normalize_max_concurrency("abc") == 1


class TestParseRedisInt:
    def test_none(self) -> None:
        assert _parse_redis_int(None) == 0

    def test_positive(self) -> None:
        assert _parse_redis_int(42) == 42

    def test_negative_clamps(self) -> None:
        assert _parse_redis_int(-5) == 0

    def test_string(self) -> None:
        assert _parse_redis_int("123") == 123

    def test_invalid(self) -> None:
        assert _parse_redis_int("not_a_number") == 0

    def test_bytes(self) -> None:
        assert _parse_redis_int(b"7") == 7


class TestDecode:
    def test_bytes(self) -> None:
        assert _decode(b"hello") == "hello"

    def test_str(self) -> None:
        assert _decode("world") == "world"

    def test_none(self) -> None:
        assert _decode(None) == ""

    def test_int(self) -> None:
        assert _decode(42) == "42"


class TestParseEnqueueResult:
    def test_created(self) -> None:
        result = _parse_enqueue_result(["created", "run-123"])
        assert result == ("created", "run-123")

    def test_existing(self) -> None:
        result = _parse_enqueue_result(["existing", "run-456"])
        assert result == ("existing", "run-456")

    def test_bytes(self) -> None:
        result = _parse_enqueue_result([b"created", b"run-789"])
        assert result == ("created", "run-789")

    def test_nested(self) -> None:
        result = _parse_enqueue_result([["created", "run-nested"]])
        assert result == ("created", "run-nested")

    def test_invalid_kind(self) -> None:
        assert _parse_enqueue_result(["unknown", "run-1"]) is None

    def test_empty_run_id(self) -> None:
        assert _parse_enqueue_result(["created", ""]) is None

    def test_not_list(self) -> None:
        assert _parse_enqueue_result("not a list") is None

    def test_none(self) -> None:
        assert _parse_enqueue_result(None) is None

    def test_empty_list(self) -> None:
        assert _parse_enqueue_result([]) is None


class TestComputeRetryDelayMs:
    def test_first_attempt(self) -> None:
        delay = compute_retry_delay_ms(1)
        assert 250 <= delay < 350  # base 250 + jitter 0-99

    def test_second_attempt(self) -> None:
        delay = compute_retry_delay_ms(2)
        assert 500 <= delay < 600

    def test_third_attempt(self) -> None:
        delay = compute_retry_delay_ms(3)
        assert 1000 <= delay < 1100

    def test_high_attempt_capped(self) -> None:
        delay = compute_retry_delay_ms(100)
        assert delay <= 30_100  # max_delay 30000 + jitter 99

    def test_zero_attempt(self) -> None:
        delay = compute_retry_delay_ms(0)
        assert 250 <= delay < 350


class TestIsRetryableError:
    def test_generic_exception(self) -> None:
        assert is_retryable_error(RuntimeError("oops")) is True

    def test_canceled(self) -> None:
        assert is_retryable_error(CanceledError("canceled")) is False

    def test_non_retriable(self) -> None:
        assert is_retryable_error(NonRetriableError("permanent")) is False

    def test_input_validation(self) -> None:
        assert is_retryable_error(InputValidationError("bad input")) is False

    def test_unknown_workflow(self) -> None:
        assert is_retryable_error(UnknownWorkflowError("missing")) is False

    def test_output_serialization(self) -> None:
        assert is_retryable_error(OutputSerializationError("bad output")) is False


class TestIsTerminalStatus:
    def test_terminal_statuses(self) -> None:
        assert is_terminal_status("succeeded") is True
        assert is_terminal_status("failed") is True
        assert is_terminal_status("canceled") is True

    def test_non_terminal_statuses(self) -> None:
        assert is_terminal_status("queued") is False
        assert is_terminal_status("running") is False
        assert is_terminal_status("scheduled") is False


class TestRunByNameParity:
    @staticmethod
    def _make_stub_client() -> tuple[RedflowClient, dict[str, object]]:
        class _StubClient(RedflowClient):
            __slots__ = ("_captured",)

            def __init__(self) -> None:
                self.app = "worker-app"
                self.prefix = "redflow:v1"
                self.redis = None  # type: ignore[assignment]
                self.run_history_retention_ms = 30 * 24 * 60 * 60 * 1000
                self._captured: dict[str, object] = {}

            async def _get_queue_for_workflow(self, workflow_name: str) -> str | None:
                return "registry-q"

            async def _get_app_for_workflow(self, workflow_name: str) -> str | None:
                return None

            async def _get_max_attempts_for_workflow(self, workflow_name: str) -> int | None:
                return 7

            async def _enqueue_run(self, **kwargs: object) -> object:
                self._captured.update(kwargs)
                return {"ok": True}

        client = _StubClient()
        return client, client._captured

    async def test_invalid_run_at_raises(self) -> None:
        client = RedflowClient.__new__(RedflowClient)
        client.app = None
        client.prefix = "redflow:v1"
        client.redis = None  # type: ignore[assignment]
        client.run_history_retention_ms = 30 * 24 * 60 * 60 * 1000

        with pytest.raises(ValueError, match="Invalid runAt date"):
            await client.run_by_name("wf", {}, run_at="not-a-datetime")  # type: ignore[arg-type]

    async def test_queue_override_empty_string_is_explicit_and_rejected_like_ts(self) -> None:
        client, _captured = self._make_stub_client()

        with pytest.raises(UnknownWorkflowError):
            await client.run_by_name(
                "wf",
                {"x": 1},
                queue_override="",
            )

    async def test_invalid_max_attempts_override_is_ignored(self) -> None:
        client, captured = self._make_stub_client()

        result = await client.run_by_name(
            "wf",
            {"x": 1},
            max_attempts_override=-5,
        )

        assert result == {"ok": True}
        assert captured["queue"] == "worker-app:registry-q"
        assert captured["max_attempts"] == 7

    async def test_idempotency_ttl_zero_is_preserved(self) -> None:
        client, captured = self._make_stub_client()

        result = await client.run_by_name(
            "wf",
            {"x": 1},
            idempotency_ttl=0,
        )

        assert result == {"ok": True}
        assert captured["idempotency_ttl"] == 0

    async def test_bool_max_attempts_override_is_ignored_like_ts(self) -> None:
        client, captured = self._make_stub_client()

        result = await client.run_by_name(
            "wf",
            {"x": 1},
            max_attempts_override=True,  # bool is not a JS number; TS ignores this.
        )

        assert result == {"ok": True}
        assert captured["max_attempts"] == 7


class TestDefaultClientHelpers:
    def test_get_default_client_memoizes_and_set_default_client_overrides(self, monkeypatch) -> None:
        import redflow.client as client_module
        import redflow.default as default_module

        created: list[object] = []

        class _SentinelClient:
            pass

        def _fake_create_client() -> object:
            inst = _SentinelClient()
            created.append(inst)
            return inst

        monkeypatch.setattr(default_module, "_default_client", None)
        monkeypatch.setattr(client_module, "create_client", _fake_create_client)

        first = get_default_client()
        second = get_default_client()
        assert first is second
        assert len(created) == 1

        override = _SentinelClient()
        set_default_client(override)  # type: ignore[arg-type]
        assert get_default_client() is override

        set_default_client(None)


class TestCreateClientHelpers:
    def test_default_prefix_uses_env(self, monkeypatch) -> None:
        monkeypatch.setenv("REDFLOW_PREFIX", "rf:test")
        assert default_prefix() == "rf:test"

    def test_default_prefix_empty_env_falls_back_like_ts(self, monkeypatch) -> None:
        monkeypatch.setenv("REDFLOW_PREFIX", "")
        assert default_prefix() == "redflow:v1"

    def test_create_client_explicit_app_overrides_env(self, monkeypatch) -> None:
        import redflow.client as client_module

        monkeypatch.setenv("REDFLOW_APP", "from-env")

        captured: dict[str, object] = {}

        class _FakeRedisFactory:
            @staticmethod
            def from_url(url: str) -> object:
                captured["url"] = url
                return object()

        monkeypatch.setattr(client_module, "Redis", _FakeRedisFactory)

        client = create_client(app="from-arg", url="redis://example", prefix="pfx")
        assert isinstance(client, RedflowClient)
        assert client.app == "from-arg"
        assert client.prefix == "pfx"
        assert captured["url"] == "redis://example"

    def test_create_client_uses_env_app_when_arg_empty(self, monkeypatch) -> None:
        import redflow.client as client_module

        monkeypatch.setenv("REDFLOW_APP", "from-env")

        class _FakeRedisFactory:
            @staticmethod
            def from_url(url: str) -> object:
                return object()

        monkeypatch.setattr(client_module, "Redis", _FakeRedisFactory)

        client = create_client(app="   ", url="redis://example", prefix="pfx")
        assert client.app == "from-env"

    def test_create_client_with_explicit_redis_bypasses_from_url(self, monkeypatch) -> None:
        import redflow.client as client_module

        explicit_redis = object()

        class _FakeRedisFactory:
            @staticmethod
            def from_url(url: str) -> object:
                raise AssertionError("Redis.from_url should not be called when redis= is provided")

        monkeypatch.setattr(client_module, "Redis", _FakeRedisFactory)

        client = create_client(redis=explicit_redis, prefix="pfx")
        assert client.redis is explicit_redis
        assert client.prefix == "pfx"

    def test_create_client_preserves_explicit_empty_prefix_like_ts_nullish(self, monkeypatch) -> None:
        import redflow.client as client_module

        class _FakeRedisFactory:
            @staticmethod
            def from_url(url: str) -> object:
                return object()

        monkeypatch.setattr(client_module, "Redis", _FakeRedisFactory)
        monkeypatch.setenv("REDFLOW_PREFIX", "env-prefix")

        client = create_client(url="redis://example", prefix="")
        assert client.prefix == ""


class TestRunHistoryRetentionEnv:
    def test_default_when_env_missing(self, monkeypatch) -> None:
        monkeypatch.delenv("REDFLOW_RUN_RETENTION_DAYS", raising=False)
        assert _default_run_history_retention_ms() == 30 * 24 * 60 * 60 * 1000

    def test_default_when_env_invalid(self, monkeypatch) -> None:
        monkeypatch.setenv("REDFLOW_RUN_RETENTION_DAYS", "abc")
        assert _default_run_history_retention_ms() == 30 * 24 * 60 * 60 * 1000

    def test_default_when_env_non_positive(self, monkeypatch) -> None:
        monkeypatch.setenv("REDFLOW_RUN_RETENTION_DAYS", "0")
        assert _default_run_history_retention_ms() == 30 * 24 * 60 * 60 * 1000

    def test_parses_fractional_days(self, monkeypatch) -> None:
        monkeypatch.setenv("REDFLOW_RUN_RETENTION_DAYS", "1.5")
        assert _default_run_history_retention_ms() == 129600000


class TestValidateInputWithSchema:
    async def test_success(self) -> None:
        class _Schema:
            @staticmethod
            def model_validate(value: object) -> dict[str, object]:
                return {"wrapped": value}

        result = await validate_input_with_schema(_Schema, {"a": 1})
        assert result == {"wrapped": {"a": 1}}

    async def test_wraps_validation_error(self) -> None:
        class _Schema:
            @staticmethod
            def model_validate(value: object) -> object:
                raise ValueError("bad input")

        with pytest.raises(InputValidationError, match="Workflow input validation failed"):
            await validate_input_with_schema(_Schema, {"a": 1})

    async def test_unsupported_schema_type_raises_input_validation_error(self) -> None:
        with pytest.raises(InputValidationError, match="Workflow input validation failed"):
            await validate_input_with_schema(object(), {"a": 1})


class TestMakeErrorJson:
    def test_basic_error(self) -> None:
        result = make_error_json(RuntimeError("test error"))
        assert "test error" in result
        assert "RuntimeError" in result

    def test_non_exception(self) -> None:
        result = make_error_json("string error")
        assert isinstance(result, str)


class TestRunStateNullPreservation:
    def test_run_state_from_hash_preserves_explicit_json_null_output_and_error(self) -> None:
        state = RedflowClient._run_state_from_hash(
            "run-1",
            {
                b"workflow": b"wf",
                b"queue": b"default",
                b"status": b"succeeded",
                b"inputJson": b"{}",
                b"attempt": b"1",
                b"maxAttempts": b"3",
                b"createdAt": b"123",
                b"outputJson": b"null",
                b"errorJson": b"null",
            },
        )

        assert state is not None
        assert "output" in state and state["output"] is None
        assert "error" in state and state["error"] is None

    async def test_get_run_steps_preserves_explicit_json_null_output_and_error(self) -> None:
        class _FakeRedis:
            async def hgetall(self, key: str) -> dict[bytes, bytes]:
                return {
                    b"step-a": (
                        b'{"status":"succeeded","seq":1,"startedAt":1,"finishedAt":2,'
                        b'"outputJson":"null","errorJson":"null"}'
                    )
                }

        client = RedflowClient(redis=_FakeRedis(), prefix="redflow:test")  # type: ignore[arg-type]
        steps = await client.get_run_steps("run-1")

        assert len(steps) == 1
        step = steps[0]
        assert "output" in step and step["output"] is None
        assert "error" in step and step["error"] is None

    async def test_get_run_steps_raises_on_malformed_outer_step_json_to_match_ts(self) -> None:
        class _FakeRedis:
            async def hgetall(self, key: str) -> dict[bytes, bytes]:
                return {
                    b"good-step": (
                        b'{"status":"succeeded","seq":1,"startedAt":1,"finishedAt":2,"outputJson":"{\\"x\\":1}"}'
                    ),
                    b"bad-step": b"NOT VALID JSON AT ALL",
                }

        client = RedflowClient(redis=_FakeRedis(), prefix="redflow:test")  # type: ignore[arg-type]

        with pytest.raises(ValueError):
            await client.get_run_steps("run-1")
