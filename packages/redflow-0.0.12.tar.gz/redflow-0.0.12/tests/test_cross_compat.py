"""Cross-language compatibility tests.

These tests verify that the Python client produces the exact same Redis keys,
JSON serialization, and error format as the TypeScript client.  If any of these
fail, the two clients are out of sync.
"""

import hashlib
import json

from redflow._json import UNDEFINED_TOKEN, safe_json_dumps, safe_json_loads
from redflow._keys import (
    cron_def,
    cron_next,
    idempotency,
    lock_cron,
    queue_processing,
    queue_ready,
    queue_scheduled,
    run,
    run_lease,
    run_steps,
    runs_created,
    runs_expires_at,
    runs_status,
    workflow,
    workflow_running,
    workflow_runs,
    workflows,
)
from redflow._lua_scripts import (
    ALL_SCRIPTS,
    CLAIM_QUEUED_RUN_FOR_INLINE,
    ENQUEUE_RUN,
    FINALIZE_TERMINAL_RUN,
    PROMOTE_SCHEDULED_RUN,
    RENEW_LEASE,
    REQUEST_CANCELLATION,
    REQUEUE_DUE_TO_CONCURRENCY,
    SCHEDULE_RETRY,
    TRANSITION_IF_CURRENT_STATUS,
    TRANSITION_QUEUED_TO_RUNNING,
    TRANSITION_RUN_STATUS,
    UNLOCK,
)
from redflow.errors import (
    CanceledError,
    InputValidationError,
    NonRetriableError,
    OutputSerializationError,
    TimeoutError,
    UnknownWorkflowError,
    serialize_error,
)

PREFIX = "redflow:v1"


class TestKeyParity:
    """Every Python key function must produce the same string as the TS ``keys.ts``."""

    def test_workflows(self) -> None:
        assert workflows(PREFIX) == "redflow:v1:workflows"

    def test_workflow(self) -> None:
        assert workflow(PREFIX, "sync-docs") == "redflow:v1:workflow:sync-docs"

    def test_workflow_runs(self) -> None:
        assert workflow_runs(PREFIX, "sync-docs") == "redflow:v1:workflow-runs:sync-docs"

    def test_workflow_running(self) -> None:
        assert workflow_running(PREFIX, "sync-docs") == "redflow:v1:workflow-running:sync-docs"

    def test_runs_created(self) -> None:
        assert runs_created(PREFIX) == "redflow:v1:runs:created"

    def test_runs_expires_at(self) -> None:
        assert runs_expires_at(PREFIX) == "redflow:v1:runs:expires-at"

    def test_runs_status(self) -> None:
        for status in ("scheduled", "queued", "running", "succeeded", "failed", "canceled"):
            assert runs_status(PREFIX, status) == f"redflow:v1:runs:status:{status}"

    def test_run(self) -> None:
        assert run(PREFIX, "run_abc") == "redflow:v1:run:run_abc"

    def test_run_steps(self) -> None:
        assert run_steps(PREFIX, "run_abc") == "redflow:v1:run:run_abc:steps"

    def test_run_lease(self) -> None:
        assert run_lease(PREFIX, "run_abc") == "redflow:v1:run:run_abc:lease"

    def test_queue_ready(self) -> None:
        assert queue_ready(PREFIX, "default") == "redflow:v1:q:default:ready"

    def test_queue_processing(self) -> None:
        assert queue_processing(PREFIX, "critical") == "redflow:v1:q:critical:processing"

    def test_queue_scheduled(self) -> None:
        assert queue_scheduled(PREFIX, "default") == "redflow:v1:q:default:scheduled"

    def test_cron_def(self) -> None:
        assert cron_def(PREFIX) == "redflow:v1:cron:def"

    def test_cron_next(self) -> None:
        assert cron_next(PREFIX) == "redflow:v1:cron:next"

    def test_lock_cron(self) -> None:
        assert lock_cron(PREFIX) == "redflow:v1:lock:cron"

    def test_idempotency_composite_encoding(self) -> None:
        result = idempotency(PREFIX, "my-workflow", "user-123")
        assert result == "redflow:v1:idempo:11:my-workflow:8:user-123"

    def test_prefix_normalization(self) -> None:
        assert workflows("redflow:v1:") == workflows("redflow:v1")


class TestJsonParity:
    """JSON serialization must be compact and match ``safeJsonStringify`` from TS."""

    def test_compact_output(self) -> None:
        result = safe_json_dumps({"a": 1, "b": [2, 3]})
        assert " " not in result
        parsed = json.loads(result)
        assert parsed == {"a": 1, "b": [2, 3]}

    def test_none_to_null(self) -> None:
        assert safe_json_dumps(None) == "null"

    def test_undefined_token_roundtrip(self) -> None:
        assert UNDEFINED_TOKEN == "__redflow_undefined_raw__:v1"
        assert safe_json_loads(UNDEFINED_TOKEN) is None

    def test_unicode_preserved(self) -> None:
        result = safe_json_dumps({"city": "Белград"})
        assert "Белград" in result

    def test_non_finite_numbers_match_js_json_stringify(self) -> None:
        result = safe_json_dumps({"nan": float("nan"), "inf": float("inf"), "items": [1, float("-inf")]})
        assert result == '{"nan":null,"inf":null,"items":[1,null]}'


class TestLuaScriptIntegrity:
    """Verify Lua scripts are loaded and SHA hashes are consistent."""

    def test_all_scripts_tuple(self) -> None:
        assert len(ALL_SCRIPTS) == 12

    def test_sha_matches_source(self) -> None:
        for script in ALL_SCRIPTS:
            expected = hashlib.sha1(script.source.encode()).hexdigest()
            assert script.sha == expected, f"SHA mismatch for script (sha={script.sha[:8]}...)"

    def test_named_scripts_exist(self) -> None:
        assert ENQUEUE_RUN.source.startswith("--")
        assert FINALIZE_TERMINAL_RUN.source.startswith("--")
        assert PROMOTE_SCHEDULED_RUN.source.startswith("--")
        assert RENEW_LEASE.source.startswith("--")
        assert REQUEST_CANCELLATION.source.startswith("--")
        assert SCHEDULE_RETRY.source.startswith("--")
        assert TRANSITION_RUN_STATUS.source.startswith("--")
        assert TRANSITION_IF_CURRENT_STATUS.source.startswith("--")
        assert TRANSITION_QUEUED_TO_RUNNING.source.startswith("--")
        assert REQUEUE_DUE_TO_CONCURRENCY.source.startswith("--")
        assert UNLOCK.source.startswith("--")
        assert CLAIM_QUEUED_RUN_FOR_INLINE.source.startswith("--")

    def test_lua_sources_contain_redis_calls(self) -> None:
        for script in ALL_SCRIPTS:
            assert "redis.call" in script.source


class TestErrorSerializationParity:
    """Error kind tags must match the TS ``serializeError`` output."""

    def test_canceled_kind(self) -> None:
        assert serialize_error(CanceledError())["kind"] == "canceled"

    def test_timeout_kind(self) -> None:
        assert serialize_error(TimeoutError())["kind"] == "timeout"

    def test_validation_kind(self) -> None:
        assert serialize_error(InputValidationError())["kind"] == "validation"

    def test_unknown_workflow_kind(self) -> None:
        assert serialize_error(UnknownWorkflowError("x"))["kind"] == "unknown_workflow"

    def test_serialization_kind(self) -> None:
        assert serialize_error(OutputSerializationError())["kind"] == "serialization"

    def test_non_retriable_kind(self) -> None:
        assert serialize_error(NonRetriableError("no"))["kind"] == "non_retriable"

    def test_generic_error_kind(self) -> None:
        assert serialize_error(RuntimeError("oops"))["kind"] == "error"

    def test_serialized_has_name_and_message(self) -> None:
        result = serialize_error(CanceledError("stopped"))
        assert result["name"] == "CanceledError"
        assert result["message"] == "stopped"

    def test_serialized_has_stack(self) -> None:
        try:
            raise ValueError("test traceback")
        except ValueError as e:
            result = serialize_error(e)
            assert "stack" in result
            assert "test traceback" in result["stack"]


class TestCronIdParity:
    """Cron ID computation must match the TS ``computeCronId`` exactly."""

    def test_auto_cron_id_without_input(self) -> None:
        """When input is None, it must still appear as null in JSON to match TS."""
        import hashlib

        from redflow._json import safe_json_dumps
        from redflow.client import RedflowClient

        client = RedflowClient.__new__(RedflowClient)
        result = client._compute_cron_id("sync-docs", None, "0 */5 * * *", None, None)

        obj: dict[str, object] = {
            "workflowName": "sync-docs",
            "expression": "0 */5 * * *",
            "timezone": None,
            "input": None,
        }
        stable = safe_json_dumps(obj)
        expected = f"cron_auto_{hashlib.sha256(stable.encode()).hexdigest()[:24]}"
        assert result == expected

    def test_auto_cron_id_with_input(self) -> None:
        """When input is provided, the JSON must include the key."""
        import hashlib

        from redflow._json import safe_json_dumps

        obj: dict[str, object] = {
            "workflowName": "sync-docs",
            "expression": "0 */5 * * *",
            "timezone": None,
            "input": {"source": "serbia"},
        }
        stable = safe_json_dumps(obj)
        assert '"input"' in stable
        h = hashlib.sha256(stable.encode()).hexdigest()[:24]
        cron_id = f"cron_auto_{h}"
        assert cron_id.startswith("cron_auto_")

    def test_user_cron_id(self) -> None:
        """User-provided cron IDs use a different prefix and key layout."""
        import hashlib

        from redflow._json import safe_json_dumps
        from redflow.client import RedflowClient

        client = RedflowClient.__new__(RedflowClient)
        result = client._compute_cron_id("sync-docs", "daily", "0 * * * *", None, None)

        stable = safe_json_dumps({"workflowName": "sync-docs", "userId": "daily"})
        expected = f"cron_user_{hashlib.sha256(stable.encode()).hexdigest()[:24]}"
        assert result == expected


class TestRetryDelayParity:
    """Retry delay must use the same formula as the TS client."""

    def test_first_attempt(self) -> None:
        from redflow.client import compute_retry_delay_ms

        delay = compute_retry_delay_ms(1)
        assert 250 <= delay <= 349  # 250 base + [0,99] jitter

    def test_second_attempt(self) -> None:
        from redflow.client import compute_retry_delay_ms

        delay = compute_retry_delay_ms(2)
        assert 500 <= delay <= 599  # 500 base + [0,99] jitter

    def test_max_cap(self) -> None:
        from redflow.client import compute_retry_delay_ms

        delay = compute_retry_delay_ms(100)
        assert 30_000 <= delay <= 30_099  # capped at 30000 + jitter
