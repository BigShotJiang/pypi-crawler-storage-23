"""Unit tests for worker watchdog decision logic."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Any

import pytest

from redflow.registry import WorkflowRegistry
from redflow.worker import _poller_watchdog_loop, _WorkerHealth, _WorkerSlot


@dataclass
class _FakeRedis:
    ready: int
    processing: int

    async def llen(self, key: str) -> int:
        if key.endswith(":ready"):
            return self.ready
        if key.endswith(":processing"):
            return self.processing
        return 0


def _make_slot(index: int, *, stale: bool, now: int) -> _WorkerSlot:
    health = _WorkerHealth(index=index)
    if stale:
        health.last_progress_at = now - 10_000
        health.in_flight_since = now - 10_000
        health.in_flight_command = "blmove"
        health.in_flight_queue = "q"
    else:
        health.last_progress_at = now
        health.in_flight_since = None
        health.in_flight_command = None
        health.in_flight_queue = None

    return _WorkerSlot(
        index=index,
        redis=None,  # type: ignore[arg-type]
        client=None,  # type: ignore[arg-type]
        health=health,
        cancel_scope=asyncio.Event(),
    )


@pytest.mark.asyncio
async def test_watchdog_skips_when_processing_queue_not_empty(monkeypatch) -> None:
    import redflow.worker as worker_module

    now = 50_000
    monkeypatch.setattr(worker_module, "now_ms", lambda: now)

    restart_calls: list[int] = []

    async def _fake_restart_worker_slot(**kwargs: Any) -> None:
        restart_calls.append(kwargs["slot"].index)

    monkeypatch.setattr(worker_module, "_restart_worker_slot", _fake_restart_worker_slot)

    stop_event = asyncio.Event()
    task = asyncio.create_task(
        _poller_watchdog_loop(
            redis=_FakeRedis(ready=3, processing=1),  # processing > 0 => skip recovery (TS parity)
            prefix="redflow:test",
            queues=["q"],
            slots=[_make_slot(1, stale=True, now=now), _make_slot(2, stale=True, now=now)],
            check_interval_ms=1,
            stalled_for_ms=1000,
            stop_event=stop_event,
            base_redis=None,  # type: ignore[arg-type]
            owned_redis=[],
            registry=WorkflowRegistry(),
            lease_ms=500,
            blmove_timeout_sec=1,
        )
    )

    await asyncio.sleep(0.01)
    stop_event.set()
    await asyncio.wait_for(task, timeout=1)

    assert restart_calls == []


@pytest.mark.asyncio
async def test_watchdog_skips_when_only_subset_of_slots_are_stale(monkeypatch) -> None:
    import redflow.worker as worker_module

    now = 60_000
    monkeypatch.setattr(worker_module, "now_ms", lambda: now)

    restart_calls: list[int] = []

    async def _fake_restart_worker_slot(**kwargs: Any) -> None:
        restart_calls.append(kwargs["slot"].index)

    monkeypatch.setattr(worker_module, "_restart_worker_slot", _fake_restart_worker_slot)

    stop_event = asyncio.Event()
    task = asyncio.create_task(
        _poller_watchdog_loop(
            redis=_FakeRedis(ready=2, processing=0),
            prefix="redflow:test",
            queues=["q"],
            slots=[_make_slot(1, stale=True, now=now), _make_slot(2, stale=False, now=now)],
            check_interval_ms=1,
            stalled_for_ms=1000,
            stop_event=stop_event,
            base_redis=None,  # type: ignore[arg-type]
            owned_redis=[],
            registry=WorkflowRegistry(),
            lease_ms=500,
            blmove_timeout_sec=1,
        )
    )

    await asyncio.sleep(0.01)
    stop_event.set()
    await asyncio.wait_for(task, timeout=1)

    assert restart_calls == []


@pytest.mark.asyncio
async def test_watchdog_restarts_all_slots_when_all_stale_and_ready_backlog(monkeypatch) -> None:
    import redflow.worker as worker_module

    now = 70_000
    monkeypatch.setattr(worker_module, "now_ms", lambda: now)

    restart_calls: list[int] = []
    stop_event = asyncio.Event()

    async def _fake_restart_worker_slot(**kwargs: Any) -> None:
        restart_calls.append(kwargs["slot"].index)
        if len(restart_calls) >= 2:
            stop_event.set()

    monkeypatch.setattr(worker_module, "_restart_worker_slot", _fake_restart_worker_slot)

    task = asyncio.create_task(
        _poller_watchdog_loop(
            redis=_FakeRedis(ready=5, processing=0),
            prefix="redflow:test",
            queues=["q"],
            slots=[_make_slot(1, stale=True, now=now), _make_slot(2, stale=True, now=now)],
            check_interval_ms=1,
            stalled_for_ms=1000,
            stop_event=stop_event,
            base_redis=None,  # type: ignore[arg-type]
            owned_redis=[],
            registry=WorkflowRegistry(),
            lease_ms=500,
            blmove_timeout_sec=1,
        )
    )

    await asyncio.wait_for(task, timeout=1)

    assert sorted(restart_calls) == [1, 2]
