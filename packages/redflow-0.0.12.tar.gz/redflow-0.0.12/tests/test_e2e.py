"""End-to-end tests against a real Redis instance.

These tests mirror the TypeScript e2e suite — they spin up a real worker,
emit workflows, and assert on the final state stored in Redis.

Requires: ``REDIS_URL`` env or a local ``redis-server`` binary.
"""

from __future__ import annotations

import asyncio
import time
from typing import Any

import pytest
import redis.asyncio as aioredis

from redflow import (
    NonRetriableError,
    RedflowClient,
    StartWorkerOptions,
    WorkflowHandlerContext,
    create_client,
    define_workflow,
    start_worker,
)
from redflow import _keys as K
from redflow._json import safe_json_dumps, safe_json_loads
from redflow.registry import WorkflowRegistry, __unstable_reset_default_registry_for_tests

pytestmark = [pytest.mark.asyncio, pytest.mark.e2e]


@pytest.fixture(autouse=True)
def _reset_registry():
    __unstable_reset_default_registry_for_tests()
    yield
    __unstable_reset_default_registry_for_tests()


async def _wait_for(
    fn,
    *,
    timeout_s: float = 5.0,
    interval_s: float = 0.05,
    label: str = "",
) -> None:
    deadline = asyncio.get_event_loop().time() + timeout_s
    while asyncio.get_event_loop().time() < deadline:
        if await fn():
            return
        await asyncio.sleep(interval_s)
    raise TimeoutError(f"wait_for timeout: {label}" if label else "wait_for timeout")


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestBasicWorkflow:
    async def test_manual_run_succeeds_and_records_steps(self, redis_url: str, test_prefix: str) -> None:
        registry = WorkflowRegistry()
        r = aioredis.from_url(redis_url)
        client = create_client(redis=r, prefix=test_prefix)

        define_workflow(
            "manual-success",
            handler=self._handler,
            queue="q1",
            registry=registry,
        )

        worker = await start_worker(
            StartWorkerOptions(
                app="test",
                redis=r,
                prefix=test_prefix,
                queues=["q1"],
                lease_ms=500,
                registry=registry,
            )
        )

        handle = await client.emit_workflow("manual-success", {"n": 1})
        result = await handle.result(timeout_ms=5000)

        assert result == {"ok": True, "b": 3}

        steps = await client.get_run_steps(handle.id)
        assert [s["name"] for s in steps] == ["a", "b"]
        assert all(s["status"] == "succeeded" for s in steps)

        await worker.stop()
        await r.aclose()

    @staticmethod
    async def _handler(ctx: WorkflowHandlerContext) -> dict:
        a = await ctx.step.run("a", _make_adder(ctx.input["n"], 1))
        b = await ctx.step.run("b", _make_adder(a, 1))
        return {"ok": True, "b": b}


class TestTracesAndPayloadStore:
    async def test_worker_writes_attempt_and_step_traces(self, redis_url: str, test_prefix: str) -> None:
        registry = WorkflowRegistry()
        r = aioredis.from_url(redis_url)
        client = create_client(redis=r, prefix=test_prefix)

        async def handler(ctx: WorkflowHandlerContext) -> dict[str, Any]:
            await ctx.step.run("work", _trace_work(ctx))
            return {"done": ctx.input["value"]}

        define_workflow(
            "trace-payloads",
            handler=handler,
            queue="q_trace_payloads",
            max_attempts=2,
            registry=registry,
        )

        worker = await start_worker(
            StartWorkerOptions(
                app="test",
                redis=r,
                prefix=test_prefix,
                queues=["q_trace_payloads"],
                lease_ms=500,
                registry=registry,
            )
        )

        run_input = {"value": 7}
        handle = await client.emit_workflow("trace-payloads", run_input)
        output = await handle.result(timeout_ms=10_000)
        assert output == {"done": 7}

        attempt_ids_raw = await r.smembers(K.run_attempt_events(test_prefix, handle.id))
        attempt_ids = [id_raw.decode() if isinstance(id_raw, bytes) else str(id_raw) for id_raw in attempt_ids_raw]
        assert len(attempt_ids) == 2

        attempt_traces: list[dict[str, Any]] = []
        for trace_id in attempt_ids:
            raw = await r.hget(K.trace_attempts_data(test_prefix), trace_id)
            assert isinstance(raw, (bytes, str))
            assert await r.zscore(K.trace_attempts_index(test_prefix), trace_id) is not None
            trace = safe_json_loads(raw.decode() if isinstance(raw, bytes) else raw)
            assert isinstance(trace, dict)
            attempt_traces.append(trace)
        attempt_traces.sort(key=lambda item: int(item.get("attempt", 0)))

        for trace in attempt_traces:
            started_at = int(trace.get("startedAt", 0))
            finished_at = int(trace.get("finishedAt", 0))
            assert started_at > 0
            assert finished_at >= started_at
            assert trace.get("inputJson") == safe_json_dumps(run_input)

        assert attempt_traces[0].get("status") == "failed"
        assert "trace step failure" in str(attempt_traces[0].get("errorJson", ""))
        assert attempt_traces[1].get("status") == "succeeded"

        step_ids_raw = await r.smembers(K.run_step_events(test_prefix, handle.id))
        step_ids = [id_raw.decode() if isinstance(id_raw, bytes) else str(id_raw) for id_raw in step_ids_raw]
        assert len(step_ids) == 2

        step_traces: list[dict[str, Any]] = []
        for trace_id in step_ids:
            raw = await r.hget(K.trace_steps_data(test_prefix), trace_id)
            assert isinstance(raw, (bytes, str))
            assert await r.zscore(K.trace_steps_index(test_prefix), trace_id) is not None
            trace = safe_json_loads(raw.decode() if isinstance(raw, bytes) else raw)
            assert isinstance(trace, dict)
            step_traces.append(trace)
        step_traces.sort(key=lambda item: int(item.get("attempt", 0)))

        for trace in step_traces:
            started_at = int(trace.get("startedAt", 0))
            finished_at = int(trace.get("finishedAt", 0))
            assert started_at > 0
            assert finished_at >= started_at
            assert trace.get("step") == "work"

        assert step_traces[0].get("status") == "failed"
        assert "trace step failure" in str(step_traces[0].get("errorJson", ""))
        assert step_traces[1].get("status") == "succeeded"

        attempts = await client.get_run_attempts(handle.id)
        assert [item["attempt"] for item in attempts] == [1, 2]
        assert attempts[0]["status"] == "failed"
        assert attempts[0]["steps"][0]["status"] == "failed"
        assert attempts[1]["status"] == "succeeded"
        assert attempts[1]["steps"][0]["status"] == "succeeded"

        await worker.stop()
        await r.aclose()

    async def test_large_payloads_are_externalized(self, redis_url: str, test_prefix: str) -> None:
        registry = WorkflowRegistry()
        r = aioredis.from_url(redis_url)
        client = create_client(redis=r, prefix=test_prefix)

        async def handler(ctx: WorkflowHandlerContext) -> dict[str, str]:
            value = await ctx.step.run("work", _mirror_payload(ctx.input["payload"]))
            return value

        define_workflow(
            "trace-large-payloads",
            handler=handler,
            queue="q_trace_large",
            max_attempts=1,
            registry=registry,
        )

        worker = await start_worker(
            StartWorkerOptions(
                app="test",
                redis=r,
                prefix=test_prefix,
                queues=["q_trace_large"],
                lease_ms=500,
                registry=registry,
            )
        )

        run_input = {"payload": "x" * 6000}
        handle = await client.emit_workflow("trace-large-payloads", run_input)
        output = await handle.result(timeout_ms=10_000)
        assert output == {"mirrored": run_input["payload"]}

        run_state = await client.get_run(handle.id)
        assert run_state is not None
        assert run_state["input"] == run_input
        assert run_state["output"] == output

        steps = await client.get_run_steps(handle.id)
        assert len(steps) == 1
        assert steps[0]["output"] == output

        run_raw = await r.hgetall(K.run(test_prefix, handle.id))
        run_raw_decoded = {
            (k.decode() if isinstance(k, bytes) else str(k)): (v.decode() if isinstance(v, bytes) else str(v))
            for k, v in run_raw.items()
        }
        assert run_raw_decoded["inputJson"].startswith("@blob:")
        assert run_raw_decoded["outputJson"].startswith("@blob:")

        blobs = await r.hgetall(K.run_blobs(test_prefix, handle.id))
        assert len(blobs) >= 2

        attempt_ids_raw = await r.smembers(K.run_attempt_events(test_prefix, handle.id))
        attempt_ids = [id_raw.decode() if isinstance(id_raw, bytes) else str(id_raw) for id_raw in attempt_ids_raw]
        assert len(attempt_ids) == 1
        attempt_trace_raw = await r.hget(K.trace_attempts_data(test_prefix), attempt_ids[0])
        assert isinstance(attempt_trace_raw, (bytes, str))
        attempt_trace = safe_json_loads(
            attempt_trace_raw.decode() if isinstance(attempt_trace_raw, bytes) else attempt_trace_raw
        )
        assert isinstance(attempt_trace, dict)
        assert str(attempt_trace.get("inputJson", "")).startswith("@blob:")
        assert attempt_trace.get("outputJson") == run_raw_decoded["outputJson"]

        step_ids_raw = await r.smembers(K.run_step_events(test_prefix, handle.id))
        step_ids = [id_raw.decode() if isinstance(id_raw, bytes) else str(id_raw) for id_raw in step_ids_raw]
        assert len(step_ids) == 1
        step_trace_raw = await r.hget(K.trace_steps_data(test_prefix), step_ids[0])
        assert isinstance(step_trace_raw, (bytes, str))
        step_trace = safe_json_loads(step_trace_raw.decode() if isinstance(step_trace_raw, bytes) else step_trace_raw)
        assert isinstance(step_trace, dict)
        assert step_trace.get("outputJson") == run_raw_decoded["outputJson"]

        await worker.stop()
        await r.aclose()


class TestScheduledRun:
    async def test_run_at_scheduled_then_executed(self, redis_url: str, test_prefix: str) -> None:
        from datetime import datetime, timedelta

        registry = WorkflowRegistry()
        r = aioredis.from_url(redis_url)
        client = create_client(redis=r, prefix=test_prefix)

        define_workflow(
            "delayed",
            handler=_ok_handler,
            queue="q2",
            registry=registry,
        )

        worker = await start_worker(
            StartWorkerOptions(
                app="test",
                redis=r,
                prefix=test_prefix,
                queues=["q2"],
                lease_ms=500,
                registry=registry,
            )
        )

        run_at = datetime.now() + timedelta(seconds=1.2)
        handle = await client.emit_workflow("delayed", {}, run_at=run_at)

        state1 = await client.get_run(handle.id)
        assert state1 is not None
        assert state1["status"] == "scheduled"

        result = await handle.result(timeout_ms=6000)
        assert result == {"ok": True}

        state2 = await client.get_run(handle.id)
        assert state2 is not None
        assert state2["status"] == "succeeded"

        await worker.stop()
        await r.aclose()


class TestRetries:
    async def test_retry_exhaustion_fails(self, redis_url: str, test_prefix: str) -> None:
        registry = WorkflowRegistry()
        r = aioredis.from_url(redis_url)
        client = create_client(redis=r, prefix=test_prefix)

        define_workflow(
            "always-fail",
            handler=_always_fail_handler,
            queue="q3",
            max_attempts=2,
            registry=registry,
        )

        worker = await start_worker(
            StartWorkerOptions(
                app="test",
                redis=r,
                prefix=test_prefix,
                queues=["q3"],
                lease_ms=500,
                registry=registry,
            )
        )

        handle = await client.emit_workflow("always-fail", {})

        with pytest.raises(Exception, match="Run failed"):
            await handle.result(timeout_ms=15000)

        state = await client.get_run(handle.id)
        assert state is not None
        assert state["status"] == "failed"
        assert state["attempt"] == 2

        await worker.stop()
        await r.aclose()

    async def test_non_retriable_error_fails_immediately(self, redis_url: str, test_prefix: str) -> None:
        registry = WorkflowRegistry()
        r = aioredis.from_url(redis_url)
        client = create_client(redis=r, prefix=test_prefix)

        async def handler(ctx: WorkflowHandlerContext) -> None:
            raise NonRetriableError("permanent failure")

        define_workflow(
            "non-retriable",
            handler=handler,
            queue="q_nr",
            max_attempts=5,
            registry=registry,
        )

        worker = await start_worker(
            StartWorkerOptions(
                app="test",
                redis=r,
                prefix=test_prefix,
                queues=["q_nr"],
                lease_ms=500,
                registry=registry,
            )
        )

        handle = await client.emit_workflow("non-retriable", {})
        with pytest.raises(Exception, match="Run failed"):
            await handle.result(timeout_ms=5000)

        state = await client.get_run(handle.id)
        assert state is not None
        assert state["status"] == "failed"
        assert state["attempt"] == 1

        error = state.get("error")
        assert isinstance(error, dict)
        assert error.get("kind") == "non_retriable"
        assert error.get("message") == "permanent failure"

        await worker.stop()
        await r.aclose()


class TestCancel:
    async def test_cancel_running_workflow(self, redis_url: str, test_prefix: str) -> None:
        registry = WorkflowRegistry()
        r = aioredis.from_url(redis_url)
        client = create_client(redis=r, prefix=test_prefix)

        started = asyncio.Event()

        async def handler(ctx: WorkflowHandlerContext) -> dict:
            started.set()
            while not ctx.signal.is_set():
                await asyncio.sleep(0.05)
            return {"ok": True}

        define_workflow("cancellable", handler=handler, queue="q_cancel", registry=registry)

        worker = await start_worker(
            StartWorkerOptions(
                app="test",
                redis=r,
                prefix=test_prefix,
                queues=["q_cancel"],
                lease_ms=500,
                registry=registry,
            )
        )

        handle = await client.emit_workflow("cancellable", {})

        await _wait_for(
            lambda: _check_status(client, handle.id, "running"),
            timeout_s=5,
            label="run starts",
        )

        await client.cancel_run(handle.id)

        await _wait_for(
            lambda: _check_status(client, handle.id, "canceled"),
            timeout_s=5,
            label="run canceled",
        )

        state = await client.get_run(handle.id)
        assert state is not None
        assert state["status"] == "canceled"

        await worker.stop()
        await r.aclose()

    async def test_cancel_running_workflow_marks_active_step_failed(self, redis_url: str, test_prefix: str) -> None:
        registry = WorkflowRegistry()
        r = aioredis.from_url(redis_url)
        client = create_client(redis=r, prefix=test_prefix)

        async def handler(ctx: WorkflowHandlerContext) -> dict:
            async def hold(*, signal) -> None:
                while not signal.is_set():
                    await asyncio.sleep(0.05)

            await ctx.step.run("hold", hold)
            return {"ok": True}

        define_workflow("cancellable-step", handler=handler, queue="q_cancel_step", registry=registry)

        worker = await start_worker(
            StartWorkerOptions(
                app="test",
                redis=r,
                prefix=test_prefix,
                queues=["q_cancel_step"],
                lease_ms=500,
                registry=registry,
            )
        )

        handle = await client.emit_workflow("cancellable-step", {})

        await _wait_for(
            lambda: _check_status(client, handle.id, "running"),
            timeout_s=5,
            label="run starts",
        )

        assert await client.cancel_run(handle.id) is True

        await _wait_for(
            lambda: _check_status(client, handle.id, "canceled"),
            timeout_s=5,
            label="run canceled",
        )

        steps = await client.get_run_steps(handle.id)
        assert len(steps) == 1
        assert steps[0]["name"] == "hold"
        assert steps[0]["status"] == "failed"
        assert isinstance(steps[0].get("error"), dict)
        assert steps[0]["error"].get("kind") == "canceled"

        await worker.stop()
        await r.aclose()

    async def test_cancel_queued_workflow(self, redis_url: str, test_prefix: str) -> None:
        registry = WorkflowRegistry()
        r = aioredis.from_url(redis_url)
        client = create_client(redis=r, prefix=test_prefix)

        define_workflow("cancel-queued", handler=_ok_handler, queue="q_cancel_q", registry=registry)

        worker = await start_worker(
            StartWorkerOptions(
                app="test",
                redis=r,
                prefix=test_prefix,
                queues=[],  # no queues -> run stays queued
                lease_ms=500,
                registry=registry,
            )
        )

        handle = await client.emit_workflow("cancel-queued", {})

        state1 = await client.get_run(handle.id)
        assert state1 is not None
        assert state1["status"] == "queued"

        result = await client.cancel_run(handle.id)
        assert result is True

        state2 = await client.get_run(handle.id)
        assert state2 is not None
        assert state2["status"] == "canceled"

        await worker.stop()
        await r.aclose()


class TestOnFailure:
    async def test_on_failure_called_after_retry_exhaustion(self, redis_url: str, test_prefix: str) -> None:
        registry = WorkflowRegistry()
        r = aioredis.from_url(redis_url)
        client = create_client(redis=r, prefix=test_prefix)

        failure_ctx_holder: list[Any] = []

        def on_failure(ctx):
            failure_ctx_holder.append(ctx)

        async def handler(ctx: WorkflowHandlerContext) -> None:
            raise RuntimeError("always fails")

        define_workflow(
            "on-failure-wf",
            handler=handler,
            queue="q_of",
            max_attempts=2,
            on_failure=on_failure,
            registry=registry,
        )

        worker = await start_worker(
            StartWorkerOptions(
                app="test",
                redis=r,
                prefix=test_prefix,
                queues=["q_of"],
                lease_ms=500,
                registry=registry,
            )
        )

        handle = await client.emit_workflow("on-failure-wf", {"some": "data"})

        with pytest.raises(Exception, match="Run failed"):
            await handle.result(timeout_ms=15000)

        assert len(failure_ctx_holder) == 1
        fctx = failure_ctx_holder[0]
        assert fctx.error is not None
        assert fctx.input == {"some": "data"}
        assert fctx.run.id == handle.id
        assert fctx.run.workflow == "on-failure-wf"
        assert fctx.run.attempt == 2
        assert fctx.run.max_attempts == 2

        await worker.stop()
        await r.aclose()

    async def test_on_failure_not_called_on_cancel(self, redis_url: str, test_prefix: str) -> None:
        registry = WorkflowRegistry()
        r = aioredis.from_url(redis_url)
        client = create_client(redis=r, prefix=test_prefix)

        on_failure_called = False

        def on_failure(ctx):
            nonlocal on_failure_called
            on_failure_called = True

        async def handler(ctx: WorkflowHandlerContext) -> dict:
            while not ctx.signal.is_set():
                await asyncio.sleep(0.05)
            return {}

        define_workflow(
            "on-failure-not-cancel",
            handler=handler,
            queue="q_of_cancel",
            on_failure=on_failure,
            registry=registry,
        )

        worker = await start_worker(
            StartWorkerOptions(
                app="test",
                redis=r,
                prefix=test_prefix,
                queues=["q_of_cancel"],
                lease_ms=500,
                registry=registry,
            )
        )

        handle = await client.emit_workflow("on-failure-not-cancel", {})

        await _wait_for(
            lambda: _check_status(client, handle.id, "running"),
            timeout_s=5,
            label="run starts",
        )

        await client.cancel_run(handle.id)

        await _wait_for(
            lambda: _check_status(client, handle.id, "canceled"),
            timeout_s=5,
            label="run canceled",
        )

        await asyncio.sleep(0.3)
        assert on_failure_called is False

        await worker.stop()
        await r.aclose()


class TestIdempotency:
    async def test_same_idempotency_key_returns_same_run(self, redis_url: str, test_prefix: str) -> None:
        registry = WorkflowRegistry()
        r = aioredis.from_url(redis_url)
        client = create_client(redis=r, prefix=test_prefix)

        define_workflow("idem-wf", handler=_ok_handler, queue="q_idem", registry=registry)

        worker = await start_worker(
            StartWorkerOptions(
                app="test",
                redis=r,
                prefix=test_prefix,
                queues=["q_idem"],
                lease_ms=500,
                registry=registry,
            )
        )

        h1 = await client.emit_workflow("idem-wf", {"a": 1}, idempotency_key="same-key")
        h2 = await client.emit_workflow("idem-wf", {"a": 2}, idempotency_key="same-key")

        assert h1.id == h2.id

        result = await h1.result(timeout_ms=5000)
        assert result == {"ok": True}

        await worker.stop()
        await r.aclose()


class TestStepCaching:
    async def test_step_results_are_cached_across_retries(self, redis_url: str, test_prefix: str) -> None:
        registry = WorkflowRegistry()
        r = aioredis.from_url(redis_url)
        client = create_client(redis=r, prefix=test_prefix)

        counter_key = f"{test_prefix}:t:step-cache-count"

        attempt_tracker: list[int] = []

        async def handler(ctx: WorkflowHandlerContext) -> dict:
            attempt_tracker.append(ctx.run.attempt)

            async def counted_step():
                await r.incr(counter_key)
                return 42

            val = await ctx.step.run("counted", counted_step)

            if ctx.run.attempt < 2:
                raise RuntimeError("fail first attempt")

            return {"val": val}

        define_workflow(
            "step-cache-wf",
            handler=handler,
            queue="q_sc",
            max_attempts=3,
            registry=registry,
        )

        worker = await start_worker(
            StartWorkerOptions(
                app="test",
                redis=r,
                prefix=test_prefix,
                queues=["q_sc"],
                lease_ms=500,
                registry=registry,
            )
        )

        handle = await client.emit_workflow("step-cache-wf", {})
        result = await handle.result(timeout_ms=15000)

        assert result == {"val": 42}

        count = await r.get(counter_key)
        assert int(count or 0) == 1

        await worker.stop()
        await r.aclose()


class TestChildWorkflows:
    async def test_emit_workflow_from_step(self, redis_url: str, test_prefix: str) -> None:
        registry = WorkflowRegistry()
        r = aioredis.from_url(redis_url)
        client = create_client(redis=r, prefix=test_prefix)

        async def child_handler(ctx: WorkflowHandlerContext) -> dict:
            return {"child": True, "n": ctx.input.get("n", 0) + 10}

        define_workflow("child-emit", handler=child_handler, queue="q_child", registry=registry)

        async def parent_handler(ctx: WorkflowHandlerContext) -> dict:
            child_run_id = await ctx.step.emit_workflow("emit-child", "child-emit", {"n": 5})
            return {"child_run_id": child_run_id}

        define_workflow("parent-emit", handler=parent_handler, queue="q_parent", registry=registry)

        worker = await start_worker(
            StartWorkerOptions(
                app="test",
                redis=r,
                prefix=test_prefix,
                queues=["q_parent", "q_child"],
                concurrency=2,
                lease_ms=500,
                registry=registry,
            )
        )

        handle = await client.emit_workflow("parent-emit", {})
        result = await handle.result(timeout_ms=8000)

        assert "child_run_id" in result
        child_id = result["child_run_id"]

        await _wait_for(
            lambda: _check_status(client, child_id, "succeeded"),
            timeout_s=5,
            label="child completes",
        )

        child_state = await client.get_run(child_id)
        assert child_state is not None
        assert child_state["output"] == {"child": True, "n": 15}

        await worker.stop()
        await r.aclose()

    async def test_emit_workflow_from_step_accepts_workflow_object(self, redis_url: str, test_prefix: str) -> None:
        registry = WorkflowRegistry()
        r = aioredis.from_url(redis_url)
        client = create_client(redis=r, prefix=test_prefix)

        async def child_handler(ctx: WorkflowHandlerContext) -> dict:
            return {"child": True, "n": ctx.input.get("n", 0) + 20}

        child_workflow = define_workflow(
            "child-emit-obj", handler=child_handler, queue="q_child_obj", registry=registry
        )

        async def parent_handler(ctx: WorkflowHandlerContext) -> dict:
            child_run_id = await ctx.step.emit_workflow("emit-child", child_workflow, {"n": 5})
            return {"child_run_id": child_run_id}

        define_workflow("parent-emit-obj", handler=parent_handler, queue="q_parent_obj", registry=registry)

        worker = await start_worker(
            StartWorkerOptions(
                app="test",
                redis=r,
                prefix=test_prefix,
                queues=["q_parent_obj", "q_child_obj"],
                concurrency=2,
                lease_ms=500,
                registry=registry,
            )
        )

        handle = await client.emit_workflow("parent-emit-obj", {})
        result = await handle.result(timeout_ms=8000)
        child_id = result["child_run_id"]

        await _wait_for(
            lambda: _check_status(client, child_id, "succeeded"),
            timeout_s=5,
            label="child completes",
        )

        child_state = await client.get_run(child_id)
        assert child_state is not None
        assert child_state["output"] == {"child": True, "n": 25}

        await worker.stop()
        await r.aclose()

    async def test_run_workflow_waits_for_child(self, redis_url: str, test_prefix: str) -> None:
        registry = WorkflowRegistry()
        r = aioredis.from_url(redis_url)
        client = create_client(redis=r, prefix=test_prefix)

        async def child_handler(ctx: WorkflowHandlerContext) -> dict:
            val = await ctx.step.run("compute", _make_adder(ctx.input.get("n", 0), 100))
            return {"result": val}

        define_workflow("child-invoke", handler=child_handler, queue="q_invoke_child", registry=registry)

        async def parent_handler(ctx: WorkflowHandlerContext) -> dict:
            child_result = await ctx.step.run_workflow("invoke-child", "child-invoke", {"n": 5})
            return {"from_child": child_result}

        define_workflow("parent-invoke", handler=parent_handler, queue="q_invoke_parent", registry=registry)

        worker = await start_worker(
            StartWorkerOptions(
                app="test",
                redis=r,
                prefix=test_prefix,
                queues=["q_invoke_parent", "q_invoke_child"],
                concurrency=2,
                lease_ms=500,
                registry=registry,
            )
        )

        handle = await client.emit_workflow("parent-invoke", {})
        result = await handle.result(timeout_ms=10000)

        assert result == {"from_child": {"result": 105}}

        await worker.stop()
        await r.aclose()

    async def test_run_workflow_accepts_workflow_object(self, redis_url: str, test_prefix: str) -> None:
        registry = WorkflowRegistry()
        r = aioredis.from_url(redis_url)
        client = create_client(redis=r, prefix=test_prefix)

        async def child_handler(ctx: WorkflowHandlerContext) -> dict:
            val = await ctx.step.run("compute", _make_adder(ctx.input.get("n", 0), 200))
            return {"result": val}

        child_workflow = define_workflow(
            "child-invoke-obj", handler=child_handler, queue="q_invoke_child_obj", registry=registry
        )

        async def parent_handler(ctx: WorkflowHandlerContext) -> dict:
            child_result = await ctx.step.run_workflow("invoke-child", child_workflow, {"n": 5})
            return {"from_child": child_result}

        define_workflow("parent-invoke-obj", handler=parent_handler, queue="q_invoke_parent_obj", registry=registry)

        worker = await start_worker(
            StartWorkerOptions(
                app="test",
                redis=r,
                prefix=test_prefix,
                queues=["q_invoke_parent_obj", "q_invoke_child_obj"],
                concurrency=2,
                lease_ms=500,
                registry=registry,
            )
        )

        handle = await client.emit_workflow("parent-invoke-obj", {})
        result = await handle.result(timeout_ms=10000)

        assert result == {"from_child": {"result": 205}}

        await worker.stop()
        await r.aclose()

    async def test_parent_run_workflow_cancel_cancels_started_children(self, redis_url: str, test_prefix: str) -> None:
        from redflow.types import ListRunsParams

        registry = WorkflowRegistry()
        r = aioredis.from_url(redis_url)
        client = create_client(redis=r, prefix=test_prefix)

        parent_queue = "q_rw_cancel_parent"
        child_queue = "q_rw_cancel_child"
        child_workflow = "child-rw-cancel-batch"
        batch1_started_key = f"{test_prefix}:t:rw-cancel-batch1-started"
        batch2_started_key = f"{test_prefix}:t:rw-cancel-batch2-started"

        async def child_handler(ctx: WorkflowHandlerContext) -> dict[str, Any]:
            payload = ctx.input

            async def hold() -> bool:
                key = batch1_started_key if payload.get("batch") == 1 else batch2_started_key
                await r.incr(key)
                await asyncio.sleep(4.0)
                return True

            await ctx.step.run("hold", hold)
            return {"ok": True, "batch": payload.get("batch"), "child": payload.get("child")}

        define_workflow(
            child_workflow,
            handler=child_handler,
            queue=child_queue,
            max_attempts=1,
            max_concurrency=5,
            registry=registry,
        )

        async def parent_handler(ctx: WorkflowHandlerContext) -> dict[str, bool]:
            async def run_batch(batch: int) -> None:
                await asyncio.gather(
                    *[
                        ctx.step.run_workflow(
                            f"batch-{batch}-child-{i + 1}",
                            child_workflow,
                            {"batch": batch, "child": i + 1},
                        )
                        for i in range(5)
                    ]
                )

            await run_batch(1)
            await run_batch(2)
            return {"ok": True}

        define_workflow(
            "parent-rw-cancel-batch",
            handler=parent_handler,
            queue=parent_queue,
            max_attempts=1,
            registry=registry,
        )

        worker = await start_worker(
            StartWorkerOptions(
                app="test",
                redis=r,
                prefix=test_prefix,
                queues=[parent_queue, child_queue],
                concurrency=6,
                lease_ms=500,
                registry=registry,
            )
        )

        try:
            parent_handle = await client.emit_workflow("parent-rw-cancel-batch", {})

            async def _batch1_started() -> bool:
                raw = await r.get(batch1_started_key)
                return int(raw or 0) == 5

            await _wait_for(_batch1_started, timeout_s=8, label="first child batch started")

            canceled = await client.cancel_run(parent_handle.id, reason="test-parent-cancel")
            assert canceled is True

            await _wait_for(
                lambda: _check_status(client, parent_handle.id, "canceled"),
                timeout_s=8,
                label="parent canceled",
            )

            async def _children_canceled() -> bool:
                child_runs = await client.list_runs(ListRunsParams(workflow=child_workflow, limit=20))
                return len(child_runs) == 5 and all(run["status"] == "canceled" for run in child_runs)

            await _wait_for(_children_canceled, timeout_s=10, label="first child batch canceled")
            await asyncio.sleep(0.3)

            child_runs = await client.list_runs(ListRunsParams(workflow=child_workflow, limit=20))
            assert len(child_runs) == 5
            assert all(run["status"] == "canceled" for run in child_runs)

            batch2_started = int((await r.get(batch2_started_key)) or 0)
            assert batch2_started == 0
        finally:
            await worker.stop()
            await r.aclose()


class TestMetadataAndStats:
    async def test_sync_registry_and_workflow_meta(self, redis_url: str, test_prefix: str) -> None:
        registry = WorkflowRegistry()
        r = aioredis.from_url(redis_url)
        client = create_client(redis=r, prefix=test_prefix)

        define_workflow("meta-wf", handler=_ok_handler, queue="q_meta", max_attempts=5, registry=registry)

        await client.sync_registry(registry, app="test-app")

        meta = await client.get_workflow_meta("meta-wf")
        assert meta is not None
        assert meta["name"] == "meta-wf"
        assert meta["queue"] == "test-app:q_meta"
        assert meta["app"] == "test-app"
        assert meta.get("max_attempts") == 5

        all_meta = await client.list_workflows_meta()
        names = [m["name"] for m in all_meta]
        assert "meta-wf" in names

        await r.aclose()

    async def test_stats_reflect_run_statuses(self, redis_url: str, test_prefix: str) -> None:
        registry = WorkflowRegistry()
        r = aioredis.from_url(redis_url)
        client = create_client(redis=r, prefix=test_prefix)

        define_workflow("stats-wf", handler=_ok_handler, queue="q_stats", registry=registry)

        worker = await start_worker(
            StartWorkerOptions(
                app="test",
                redis=r,
                prefix=test_prefix,
                queues=["q_stats"],
                lease_ms=500,
                registry=registry,
            )
        )

        h1 = await client.emit_workflow("stats-wf", {})
        h2 = await client.emit_workflow("stats-wf", {})
        await h1.result(timeout_ms=5000)
        await h2.result(timeout_ms=5000)

        stats = await client.get_stats()
        assert stats["by_status"]["succeeded"] >= 2
        assert stats["total"] >= 2

        await worker.stop()
        await r.aclose()


class TestListRuns:
    async def test_list_runs_by_workflow(self, redis_url: str, test_prefix: str) -> None:
        registry = WorkflowRegistry()
        r = aioredis.from_url(redis_url)
        client = create_client(redis=r, prefix=test_prefix)

        define_workflow("list-wf-a", handler=_ok_handler, queue="q_list", registry=registry)
        define_workflow("list-wf-b", handler=_ok_handler, queue="q_list", registry=registry)

        worker = await start_worker(
            StartWorkerOptions(
                app="test",
                redis=r,
                prefix=test_prefix,
                queues=["q_list"],
                lease_ms=500,
                registry=registry,
            )
        )

        await client.emit_workflow("list-wf-a", {})
        await client.emit_workflow("list-wf-a", {})
        await client.emit_workflow("list-wf-b", {})

        await asyncio.sleep(1)

        from redflow.types import ListRunsParams

        runs_a = await client.list_runs(ListRunsParams(workflow="list-wf-a"))
        assert len(runs_a) == 2
        assert all(r["workflow"] == "list-wf-a" for r in runs_a)

        runs_b = await client.list_runs(ListRunsParams(workflow="list-wf-b"))
        assert len(runs_b) == 1

        await worker.stop()
        await r.aclose()

    async def test_list_runs_by_status(self, redis_url: str, test_prefix: str) -> None:
        registry = WorkflowRegistry()
        r = aioredis.from_url(redis_url)
        client = create_client(redis=r, prefix=test_prefix)

        define_workflow("list-status-wf", handler=_ok_handler, queue="q_ls", registry=registry)

        worker = await start_worker(
            StartWorkerOptions(
                app="test",
                redis=r,
                prefix=test_prefix,
                queues=["q_ls"],
                lease_ms=500,
                registry=registry,
            )
        )

        h = await client.emit_workflow("list-status-wf", {})
        await h.result(timeout_ms=5000)

        from redflow.types import ListRunsParams

        succeeded = await client.list_runs(ListRunsParams(status="succeeded"))
        assert any(r["id"] == h.id for r in succeeded)

        await worker.stop()
        await r.aclose()


class TestInputValidation:
    async def test_pydantic_schema_rejects_invalid_input(self, redis_url: str, test_prefix: str) -> None:
        from pydantic import BaseModel

        class MyInput(BaseModel):
            name: str
            age: int

        registry = WorkflowRegistry()
        r = aioredis.from_url(redis_url)
        client = create_client(redis=r, prefix=test_prefix)

        async def handler(ctx: WorkflowHandlerContext) -> dict:
            return {"name": ctx.input.name}

        define_workflow(
            "validated-wf",
            handler=handler,
            queue="q_val",
            input_schema=MyInput,
            registry=registry,
        )

        worker = await start_worker(
            StartWorkerOptions(
                app="test",
                redis=r,
                prefix=test_prefix,
                queues=["q_val"],
                lease_ms=500,
                registry=registry,
            )
        )

        h_bad = await client.emit_workflow("validated-wf", {"name": 123, "age": "not_int"})
        with pytest.raises(Exception, match="Run failed"):
            await h_bad.result(timeout_ms=5000)

        state = await client.get_run(h_bad.id)
        assert state is not None
        assert state["status"] == "failed"

        h_good = await client.emit_workflow("validated-wf", {"name": "Alice", "age": 30})
        result = await h_good.result(timeout_ms=5000)
        assert result == {"name": "Alice"}

        await worker.stop()
        await r.aclose()


class TestResetState:
    async def test_reset_state_clears_all_keys(self, redis_url: str, test_prefix: str) -> None:
        registry = WorkflowRegistry()
        r = aioredis.from_url(redis_url)
        client = create_client(redis=r, prefix=test_prefix)

        define_workflow("reset-wf", handler=_ok_handler, queue="q_reset", registry=registry)

        worker = await start_worker(
            StartWorkerOptions(
                app="test",
                redis=r,
                prefix=test_prefix,
                queues=["q_reset"],
                lease_ms=500,
                registry=registry,
            )
        )

        h = await client.emit_workflow("reset-wf", {})
        await h.result(timeout_ms=5000)

        stats_before = await client.get_stats()
        assert stats_before["total"] >= 1

        await worker.stop()

        result = await client.reset_state()
        assert result["deleted"] >= 1

        stats_after = await client.get_stats()
        assert stats_after["total"] == 0

        await r.aclose()

    async def test_worker_registry_recovery_restores_workflow_metadata_after_reset_state(
        self,
        redis_url: str,
        test_prefix: str,
    ) -> None:
        registry = WorkflowRegistry()
        r = aioredis.from_url(redis_url)
        client = create_client(redis=r, prefix=test_prefix)

        workflow_name = "registry-recovery-wf"
        queue = "q_registry_recovery"

        async def handler(ctx: WorkflowHandlerContext) -> dict:
            return {"ok": True, "input": ctx.input}

        define_workflow(workflow_name, handler=handler, queue=queue, registry=registry)

        worker = await start_worker(
            StartWorkerOptions(
                app="test-app",
                redis=r,
                prefix=test_prefix,
                queues=[queue],
                lease_ms=500,
                registry=registry,
                registry_recovery_interval_ms=100,
            )
        )

        try:
            await _wait_for(
                lambda: _workflow_meta_exists(client, workflow_name),
                timeout_s=5,
                label="initial workflow metadata",
            )

            reset_result = await client.reset_state()
            assert reset_result["deleted"] > 0

            await _wait_for(
                lambda: _workflow_meta_exists(client, workflow_name),
                timeout_s=8,
                label="restored workflow metadata",
            )

            handle = await client.run_by_name(workflow_name, {"n": 7})
            out = await handle.result(timeout_ms=8000)
            assert out == {"ok": True, "input": {"n": 7}}
        finally:
            await worker.stop()
            await r.aclose()


class TestRunHistoryRetention:
    async def test_run_history_retention_env_controls_cleanup_window(
        self,
        redis_url: str,
        test_prefix: str,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("REDFLOW_RUN_RETENTION_DAYS", "1")

        registry = WorkflowRegistry()
        r = aioredis.from_url(redis_url)
        client = create_client(redis=r, prefix=test_prefix)

        workflow_name = "run-history-retention-env"
        queue = "q_history_retention_env"

        define_workflow(workflow_name, handler=_ok_handler, queue=queue, registry=registry)
        await client.sync_registry(registry, app="test-app")

        now = int(time.time() * 1000)
        old_finished_at = now - 2 * 24 * 60 * 60 * 1000

        old_run = await client.emit_workflow(workflow_name, {})
        moved_old = await client.transition_run_status_if_current(
            old_run.id,
            "queued",
            "running",
            old_finished_at - 1,
        )
        assert moved_old is True
        await client.finalize_run(
            old_run.id,
            status="succeeded",
            finished_at=old_finished_at,
            workflow_name=workflow_name,
        )

        fresh_run = await client.emit_workflow(workflow_name, {})
        moved_fresh = await client.transition_run_status_if_current(
            fresh_run.id,
            "queued",
            "running",
            now,
        )
        assert moved_fresh is True
        await client.finalize_run(
            fresh_run.id,
            status="succeeded",
            finished_at=now,
            workflow_name=workflow_name,
        )

        worker = await start_worker(
            StartWorkerOptions(
                app="test-app",
                redis=r,
                prefix=test_prefix,
                queues=[queue],
                lease_ms=500,
                registry=registry,
                run_history_cleanup_interval_ms=50,
            )
        )

        try:
            await _wait_for(
                lambda: _run_missing(client, old_run.id),
                timeout_s=8,
                label="expired run history cleanup",
            )

            assert await client.get_run(old_run.id) is None
            assert await r.zscore(K.runs_created(test_prefix), old_run.id) is None
            assert await r.zscore(K.runs_status(test_prefix, "succeeded"), old_run.id) is None
            assert await r.zscore(K.workflow_runs(test_prefix, workflow_name), old_run.id) is None

            fresh_state = await client.get_run(fresh_run.id)
            assert fresh_state is not None
            assert fresh_state["status"] == "succeeded"
        finally:
            await worker.stop()
            await r.aclose()


class TestConcurrency:
    async def test_max_concurrency_limits_parallel_runs(self, redis_url: str, test_prefix: str) -> None:
        registry = WorkflowRegistry()
        r = aioredis.from_url(redis_url)
        client = create_client(redis=r, prefix=test_prefix)

        max_running_key = f"{test_prefix}:t:max-running"
        current_running_key = f"{test_prefix}:t:current-running"

        async def handler(ctx: WorkflowHandlerContext) -> dict:
            cur = await r.incr(current_running_key)
            while True:
                max_val = int(await r.get(max_running_key) or 0)
                if cur > max_val:
                    await r.set(max_running_key, str(cur))
                break
            await asyncio.sleep(0.3)
            await r.decr(current_running_key)
            return {"ok": True}

        define_workflow(
            "conc-wf",
            handler=handler,
            queue="q_conc",
            max_concurrency=1,
            registry=registry,
        )

        worker = await start_worker(
            StartWorkerOptions(
                app="test",
                redis=r,
                prefix=test_prefix,
                queues=["q_conc"],
                concurrency=3,
                lease_ms=500,
                registry=registry,
            )
        )

        handles = []
        for _ in range(4):
            h = await client.emit_workflow("conc-wf", {})
            handles.append(h)

        for h in handles:
            await h.result(timeout_ms=15000)

        max_running = int(await r.get(max_running_key) or 0)
        assert max_running == 1, f"Expected max 1 concurrent, got {max_running}"

        await worker.stop()
        await r.aclose()


class TestMultipleSteps:
    async def test_workflow_with_many_steps(self, redis_url: str, test_prefix: str) -> None:
        registry = WorkflowRegistry()
        r = aioredis.from_url(redis_url)
        client = create_client(redis=r, prefix=test_prefix)

        async def handler(ctx: WorkflowHandlerContext) -> dict:
            results = []
            for i in range(5):
                val = await ctx.step.run(f"step-{i}", _make_adder(i, 10))
                results.append(val)
            return {"results": results}

        define_workflow("multi-step", handler=handler, queue="q_ms", registry=registry)

        worker = await start_worker(
            StartWorkerOptions(
                app="test",
                redis=r,
                prefix=test_prefix,
                queues=["q_ms"],
                lease_ms=500,
                registry=registry,
            )
        )

        handle = await client.emit_workflow("multi-step", {})
        result = await handle.result(timeout_ms=5000)

        assert result == {"results": [10, 11, 12, 13, 14]}

        steps = await client.get_run_steps(handle.id)
        assert len(steps) == 5
        assert all(s["status"] == "succeeded" for s in steps)

        await worker.stop()
        await r.aclose()


class TestStepTimeout:
    async def test_step_timeout_fails_the_step(self, redis_url: str, test_prefix: str) -> None:
        registry = WorkflowRegistry()
        r = aioredis.from_url(redis_url)
        client = create_client(redis=r, prefix=test_prefix)

        async def handler(ctx: WorkflowHandlerContext) -> dict:
            async def slow():
                await asyncio.sleep(60)
                return "never"

            val = await ctx.step.run("slow-step", slow, timeout_ms=200)
            return {"val": val}

        define_workflow(
            "timeout-step-wf",
            handler=handler,
            queue="q_timeout",
            max_attempts=1,
            registry=registry,
        )

        worker = await start_worker(
            StartWorkerOptions(
                app="test",
                redis=r,
                prefix=test_prefix,
                queues=["q_timeout"],
                lease_ms=500,
                registry=registry,
            )
        )

        handle = await client.emit_workflow("timeout-step-wf", {})

        with pytest.raises(Exception, match="Run failed"):
            await handle.result(timeout_ms=5000)

        state = await client.get_run(handle.id)
        assert state is not None
        assert state["status"] == "failed"
        steps = await client.get_run_steps(handle.id)
        assert len(steps) == 1
        assert steps[0]["name"] == "slow-step"
        assert steps[0]["status"] == "failed"

        await worker.stop()
        await r.aclose()


class TestGetRunSteps:
    async def test_step_output_is_stored(self, redis_url: str, test_prefix: str) -> None:
        registry = WorkflowRegistry()
        r = aioredis.from_url(redis_url)
        client = create_client(redis=r, prefix=test_prefix)

        async def handler(ctx: WorkflowHandlerContext) -> dict:
            a = await ctx.step.run("compute", _make_adder(10, 20))
            return {"a": a}

        define_workflow("step-output-wf", handler=handler, queue="q_so", registry=registry)

        worker = await start_worker(
            StartWorkerOptions(
                app="test",
                redis=r,
                prefix=test_prefix,
                queues=["q_so"],
                lease_ms=500,
                registry=registry,
            )
        )

        handle = await client.emit_workflow("step-output-wf", {})
        await handle.result(timeout_ms=5000)

        steps = await client.get_run_steps(handle.id)
        assert len(steps) == 1
        assert steps[0]["name"] == "compute"
        assert steps[0]["output"] == 30
        assert "started_at" in steps[0]
        assert "finished_at" in steps[0]

        await worker.stop()
        await r.aclose()


# ---------------------------------------------------------------------------
# Shared handler helpers
# ---------------------------------------------------------------------------


def _make_adder(a: int, b: int):
    async def _add():
        return a + b

    return _add


def _trace_work(ctx: WorkflowHandlerContext):
    async def _work() -> dict[str, int]:
        if ctx.run.attempt == 1:
            raise RuntimeError("trace step failure")
        return {"stepOk": int(ctx.input["value"])}

    return _work


def _mirror_payload(payload: str):
    async def _work() -> dict[str, str]:
        return {"mirrored": payload}

    return _work


async def _ok_handler(ctx: WorkflowHandlerContext) -> dict:
    await ctx.step.run("do", _make_adder(0, 0))
    return {"ok": True}


async def _always_fail_handler(ctx: WorkflowHandlerContext) -> None:
    raise RuntimeError("boom")


async def _check_status(client: RedflowClient, run_id: str, expected: str) -> bool:
    state = await client.get_run(run_id)
    return state is not None and state.get("status") == expected


async def _workflow_meta_exists(client: RedflowClient, workflow_name: str) -> bool:
    return await client.get_workflow_meta(workflow_name) is not None


async def _run_missing(client: RedflowClient, run_id: str) -> bool:
    return await client.get_run(run_id) is None
