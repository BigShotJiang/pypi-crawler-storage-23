"""Verify key layout matches the TypeScript client."""

from redflow._keys import (
    cron_def,
    cron_next,
    idempotency,
    lock_cron,
    queue_processing,
    queue_ready,
    queue_scheduled,
    run,
    run_attempt_events,
    run_blobs,
    run_lease,
    run_step_events,
    run_steps,
    runs_created,
    runs_expires_at,
    runs_status,
    trace_attempts_data,
    trace_attempts_index,
    trace_steps_data,
    trace_steps_index,
    workflow,
    workflow_running,
    workflow_runs,
    workflows,
)

PREFIX = "redflow:v1"


def test_workflows() -> None:
    assert workflows(PREFIX) == "redflow:v1:workflows"


def test_workflow() -> None:
    assert workflow(PREFIX, "my-wf") == "redflow:v1:workflow:my-wf"


def test_workflow_runs() -> None:
    assert workflow_runs(PREFIX, "my-wf") == "redflow:v1:workflow-runs:my-wf"


def test_workflow_running() -> None:
    assert workflow_running(PREFIX, "my-wf") == "redflow:v1:workflow-running:my-wf"


def test_runs_created() -> None:
    assert runs_created(PREFIX) == "redflow:v1:runs:created"


def test_runs_expires_at() -> None:
    assert runs_expires_at(PREFIX) == "redflow:v1:runs:expires-at"


def test_runs_status() -> None:
    assert runs_status(PREFIX, "running") == "redflow:v1:runs:status:running"


def test_run() -> None:
    assert run(PREFIX, "run_123") == "redflow:v1:run:run_123"


def test_run_steps() -> None:
    assert run_steps(PREFIX, "run_123") == "redflow:v1:run:run_123:steps"


def test_run_blobs() -> None:
    assert run_blobs(PREFIX, "run_123") == "redflow:v1:run:run_123:blobs"


def test_run_lease() -> None:
    assert run_lease(PREFIX, "run_123") == "redflow:v1:run:run_123:lease"


def test_trace_attempts_index() -> None:
    assert trace_attempts_index(PREFIX) == "redflow:v1:trace:attempts:index"


def test_trace_attempts_data() -> None:
    assert trace_attempts_data(PREFIX) == "redflow:v1:trace:attempts:data"


def test_trace_steps_index() -> None:
    assert trace_steps_index(PREFIX) == "redflow:v1:trace:steps:index"


def test_trace_steps_data() -> None:
    assert trace_steps_data(PREFIX) == "redflow:v1:trace:steps:data"


def test_run_attempt_events() -> None:
    assert run_attempt_events(PREFIX, "run_123") == "redflow:v1:run:run_123:attempt-events"


def test_run_step_events() -> None:
    assert run_step_events(PREFIX, "run_123") == "redflow:v1:run:run_123:step-events"


def test_queue_ready() -> None:
    assert queue_ready(PREFIX, "default") == "redflow:v1:q:default:ready"


def test_queue_processing() -> None:
    assert queue_processing(PREFIX, "default") == "redflow:v1:q:default:processing"


def test_queue_scheduled() -> None:
    assert queue_scheduled(PREFIX, "default") == "redflow:v1:q:default:scheduled"


def test_cron_def() -> None:
    assert cron_def(PREFIX) == "redflow:v1:cron:def"


def test_cron_next() -> None:
    assert cron_next(PREFIX) == "redflow:v1:cron:next"


def test_lock_cron() -> None:
    assert lock_cron(PREFIX) == "redflow:v1:lock:cron"


def test_idempotency() -> None:
    result = idempotency(PREFIX, "my-wf", "key-1")
    assert result == "redflow:v1:idempo:5:my-wf:5:key-1"


def test_idempotency_encoding() -> None:
    result = idempotency(PREFIX, "a", "longer-key")
    assert result == "redflow:v1:idempo:1:a:10:longer-key"


def test_prefix_trailing_colon() -> None:
    assert workflows("redflow:v1:") == "redflow:v1:workflows"


def test_prefix_no_colon() -> None:
    assert workflows("redflow:v1") == "redflow:v1:workflows"
