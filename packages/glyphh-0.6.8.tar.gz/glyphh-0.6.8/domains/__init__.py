"""Domain modules - business logic organized by domain"""
