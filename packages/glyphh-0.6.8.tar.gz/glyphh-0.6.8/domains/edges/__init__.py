"""
Edge Generation Domain.

Handles edge generation and caching for glyphs using the SDK's EdgeGenerator.
"""

from domains.edges.generator_service import EdgeGeneratorService

__all__ = ["EdgeGeneratorService"]
