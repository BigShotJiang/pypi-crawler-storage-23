"""Infrastructure layer - database, config, external services"""
