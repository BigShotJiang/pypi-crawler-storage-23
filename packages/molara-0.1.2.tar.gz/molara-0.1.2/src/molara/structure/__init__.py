"""Init file for structure package."""

from __future__ import annotations

__copyright__ = "Copyright 2024, Molara"
