"""Contain the glsl shader source code for the rendering."""
