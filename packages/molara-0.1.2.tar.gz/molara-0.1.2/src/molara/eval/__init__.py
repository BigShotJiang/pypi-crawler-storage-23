"""Initialize the eval module."""

from __future__ import annotations

__copyright__ = "Copyright 2024, Molara"
