"""Module containing the layout classes for the GUI.

They can be generated using QT creator and are then converted to python code using the pyside6-uic tool.
"""
