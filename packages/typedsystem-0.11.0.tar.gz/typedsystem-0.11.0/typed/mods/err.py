class TypedErr(Exception): pass
