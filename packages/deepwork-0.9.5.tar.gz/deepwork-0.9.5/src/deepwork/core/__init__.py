"""Core components for DeepWork."""
