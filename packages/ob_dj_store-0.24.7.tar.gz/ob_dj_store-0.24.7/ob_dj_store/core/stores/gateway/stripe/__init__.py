# Stripe Payment Gateway
default_app_config = "ob_dj_store.core.stores.gateway.stripe.apps.StripeConfig"
