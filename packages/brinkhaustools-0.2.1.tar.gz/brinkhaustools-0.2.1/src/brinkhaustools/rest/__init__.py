"""brinkhaustools.rest – REST API server (Flask + Waitress)."""

from brinkhaustools.rest.server import RestServer

__all__ = ["RestServer"]
