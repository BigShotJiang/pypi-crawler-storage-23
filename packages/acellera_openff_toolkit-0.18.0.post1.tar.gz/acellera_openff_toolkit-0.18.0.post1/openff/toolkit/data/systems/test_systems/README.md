### Simulation ready systems

- `T4_lysozyme_water_ions.pdb`: T4 Lysozyme solved in TIP3P water molecules and 50mM of Na+ and Cl- ions with `openmm.app.Modeller` starting from `data/proteins/T4-protein.pdb`.
