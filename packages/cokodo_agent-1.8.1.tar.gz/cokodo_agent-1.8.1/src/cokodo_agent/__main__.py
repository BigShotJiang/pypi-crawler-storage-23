"""Entry point for python -m cokodo_agent."""

from cokodo_agent.cli import main

if __name__ == "__main__":
    main()
