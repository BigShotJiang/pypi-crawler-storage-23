"""
instaharvest_v2 Models
===============
Pydantic data models for structured Instagram API responses.

Usage:
    from instaharvest_v2.models import User, Media, Comment, Story

    # Parse raw API dict into model:
    user = User.from_web_profile(raw_data)
    media = Media.from_api(raw_data)

    # Dict-like access (backward compat):
    print(user["username"])
    print(user.get("followers", 0))

    # Convert back to dict:
    data = user.to_dict()
"""

# Base
from .base import InstaModel

# Common
from .common import ImageVersion, Pagination

# Core models
from .user import User, UserShort, Contact, BioParsed
from .media import Media, Caption
from .comment import Comment
from .story import Story, StorySticker, Highlight
from .direct import DirectThread, DirectMessage
from .location import Location
from .hashtag import HashtagSearchResult
from .public_data import (
    PublicProfile,
    PublicPost,
    HashtagPost,
    ProfileSnapshot,
    PublicDataReport,
)
from .notification import (
    Notification, NotifCounts, NotifInbox,
    NotifUserInfo, NotifFriendship, NotifInlineFollow,
    NotifMedia, NotifLink,
)

__all__ = [
    # Base
    "InstaModel",
    # Common
    "ImageVersion",
    "Pagination",
    # User
    "User",
    "UserShort",
    "Contact",
    "BioParsed",
    # Media
    "Media",
    "Caption",
    # Comment
    "Comment",
    # Story
    "Story",
    "StorySticker",
    "Highlight",
    # Direct
    "DirectThread",
    "DirectMessage",
    # Location
    "Location",
    # Hashtag
    "HashtagSearchResult",
    # Public Data
    "PublicProfile",
    "PublicPost",
    "HashtagPost",
    "ProfileSnapshot",
    "PublicDataReport",
    # Notification
    "Notification",
    "NotifCounts",
    "NotifInbox",
    "NotifUserInfo",
    "NotifFriendship",
    "NotifInlineFollow",
    "NotifMedia",
    "NotifLink",
]

