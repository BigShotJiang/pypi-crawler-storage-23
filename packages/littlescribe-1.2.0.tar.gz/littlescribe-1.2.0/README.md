# AI Little Scribe

<p align="center">
  <img src="logo.png" alt="AI Little Scribe Logo" width="200">
</p>

AI Little Scribe is a real-time audio transcription tool for macOS. It captures what's being said on your computer — system audio, your microphone, or both — and transcribes it live using Amazon Transcribe. When you're done, it can generate an AI-powered summary of the conversation using Amazon Bedrock (Nova Pro).

It's built for meetings, calls, interviews, or any situation where you want a written trace of what was said without taking notes yourself.

## What it does

- Transcribes audio in real time (system audio, microphone, or both simultaneously)
- Supports multiple languages (any language code supported by Amazon Transcribe, e.g. `en-US`, `fr-FR`, `es-ES`)
- Identifies different speakers in the conversation
- Lets you type comments during the recording — they get inserted inline in the transcript for context or corrections
- Generates an AI summary at the end using Amazon Bedrock Nova Pro, formatted as structured meeting notes
- Outputs both a raw transcription file and an optional summary file

## Prerequisites

- macOS 14.2 or later
- Python 3.7+
- [uv](https://docs.astral.sh/uv/getting-started/installation/) installed (to run via `uvx`)
- AWS credentials configured (`aws configure`, or environment variables, or any method supported by boto3)
  - Access to Amazon Transcribe (us-east-1)
  - Access to Amazon Bedrock with the Nova Pro model enabled (us-east-1)
- AudioTee installed (required for system audio capture)
- ffmpeg installed (required only for microphone or both mode)

### Install AudioTee

```bash
git clone https://github.com/makeusabrew/audiotee.git
cd audiotee
make
sudo cp audiotee /usr/local/bin/
```

### Install ffmpeg (only needed for `--microphone` or `--both`)

```bash
brew install ffmpeg
```

## Usage

No installation needed. Just run it with `uvx`:

```bash
# Transcribe system audio (default)
uvx littlescribe

# Transcribe microphone only
uvx littlescribe --microphone

# Transcribe both system audio and microphone
uvx littlescribe --both

# French transcription with custom output files
uvx littlescribe --language fr-FR --output meeting.txt --summary meeting_summary.txt
```

Press `Ctrl+C` to stop recording. You'll be asked if you want to generate an AI summary.

During recording, you can type directly in the terminal to add inline comments (press Enter to submit). These comments appear in the transcript as `[COMMENT]` entries and help the AI produce a better summary.

## Command-line options

| Option | Short | Default | Description |
|---|---|---|---|
| `--language` | `-l` | `en-US` | Language code for transcription (e.g. `fr-FR`, `es-ES`, `de-DE`) |
| `--output` | `-o` | `transcription_output.txt` | Path for the raw transcription output file |
| `--summary` | `-s` | *(auto-generated)* | Path for the summary output file. If omitted and you choose to generate a summary, it defaults to `<output>-summary.txt` |
| `--microphone` | `-m` | off | Record from the microphone instead of system audio. Requires ffmpeg |
| `--both` | `-b` | off | Record both system audio and microphone simultaneously. Requires ffmpeg |

## AWS costs

This tool uses AWS services that may incur charges on your account:

- [Amazon Transcribe pricing](https://aws.amazon.com/transcribe/pricing/)
- [Amazon Bedrock pricing](https://aws.amazon.com/bedrock/pricing/)

You are responsible for any AWS charges incurred while using this tool.
