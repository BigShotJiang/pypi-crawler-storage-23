import random

import numpy as np
import pytest

from dkist_processing_common.parsers.cs_step import CSStep
from dkist_processing_common.parsers.cs_step import CSStepModstate


def test_equality_correct(
    grouped_cal_sequence_fits_objs, max_cs_step_time_sec, cs_step_angle_round_ndigits
):
    """
    Given: A set of PolCal headers
    When: Converting them to CSStep objects and comparing them
    Then: All headers belonging to the same step produce CSStep objects that are equal and are not equal to CSStep objects
          from other steps
    """
    num_steps = len(grouped_cal_sequence_fits_objs)
    for step in range(num_steps):
        for i in range(num_steps):
            objs_equal = CSStep(
                grouped_cal_sequence_fits_objs[step][0], max_cs_step_time_sec
            ) == CSStep(grouped_cal_sequence_fits_objs[i][0], max_cs_step_time_sec)
            assert objs_equal == (step == i)


def test_csstepmodstate_equality_correct(
    grouped_cal_sequence_modstate_fits_objs,
    num_modstates,
    max_cs_step_time_sec,
    cs_step_angle_round_ndigits,
):
    """
    Given: A set of PolCal headers
    When: Converting them to CSStepModstate objects and comparing them
    Then: All headers belonging to the same step and modstate produce CSStepModstate objects that are equal and that are
          not equal to CSStepModstate objects from other steps and modstates
    """
    num_steps = len(grouped_cal_sequence_modstate_fits_objs)
    for step, modstate_dict in grouped_cal_sequence_modstate_fits_objs.items():
        for modstate in range(num_modstates):
            for ss in range(num_steps):
                for mm in range(num_modstates):
                    objs_equal = CSStepModstate(
                        grouped_cal_sequence_modstate_fits_objs[step][modstate][0],
                        max_cs_step_time_sec,
                    ) == CSStepModstate(
                        grouped_cal_sequence_modstate_fits_objs[ss][mm][0],
                        max_cs_step_time_sec,
                    )
                    assert objs_equal == (ss == step and mm == modstate)


@pytest.mark.parametrize(
    "step_class",
    [pytest.param(CSStep, id="CSStep"), pytest.param(CSStepModstate, id="CSStepModstate")],
)
def test_not_equal_non_CS_Step_type(
    grouped_cal_sequence_fits_objs, step_class, max_cs_step_time_sec
):
    """
    Given: A PolCal header and resulting CSStep[Modstate] object
    When: Testing equality with a non CSStep object
    Then: An error is raised
    """
    cs_step = step_class(grouped_cal_sequence_fits_objs[0][0], max_cs_step_time_sec)
    with pytest.raises(
        TypeError,
        match=f"Cannot compare <class 'dkist_processing_common.parsers.cs_step.{step_class.__name__}'> with <class 'int'>",
    ):
        _ = cs_step == 1


@pytest.mark.parametrize(
    "step_class",
    [pytest.param(CSStep, id="CSStep"), pytest.param(CSStepModstate, id="CSStepModstate")],
)
def test_order_correct(grouped_cal_sequence_fits_objs, step_class, max_cs_step_time_sec):
    """
    Given: A set of PolCal headers
    When: Converting them to CSStep[Modstate] objects and ordering them
    Then: The step objects are correctly ordered by observe time
    """
    cs_step_list = [
        step_class(header, max_cs_step_time_sec)
        for header in sum(grouped_cal_sequence_fits_objs.values(), [])
    ]
    random.shuffle(cs_step_list)  # Just to mix it up a bit
    time_list = [c.obs_time for c in cs_step_list]
    cs_sort_idx = np.argsort(cs_step_list)
    time_sort_idx = np.argsort(time_list)
    assert np.array_equal(cs_sort_idx, time_sort_idx)


@pytest.mark.parametrize(
    "step_class",
    [pytest.param(CSStep, id="CSStep"), pytest.param(CSStepModstate, id="CSStepModstate")],
)
def test_repr(grouped_cal_sequence_fits_objs, step_class):
    """
    Given: An `L0FitsAccess` object
    When: Using that object to instantiate `CSStep[Modstate]`
    Then: The repr of the instance is correct
    """
    fits_obj = grouped_cal_sequence_fits_objs[0][0]
    cs_step_obj = step_class(fits_obj, max_cs_time_sec=10, angle_round_ndigits=5)
    assert (
        repr(cs_step_obj)
        == f"{step_class.__name__}({fits_obj!r}, max_cs_time_sec=10, angle_round_ndigits=5)"
    )
