"""Encoders and decoders for writing and reading FITS files."""

import warnings
from io import BytesIO
from pathlib import Path
from typing import Type

import numpy as np
from astropy.io import fits
from astropy.io.fits import Header
from astropy.utils.exceptions import AstropyUserWarning

from dkist_processing_common.codecs.iobase import iobase_encoder
from dkist_processing_common.models.fits_access import FitsAccessBase


def fits_array_encoder(data: np.ndarray, header: Header | dict | None = None) -> bytes:
    """Convert an array to raw bytes representing a fits `~astropy.io.fits.HDUList`."""
    if not isinstance(data, np.ndarray):
        raise ValueError(f"Input type {type(data)} is not np.ndarray")
    if isinstance(header, dict):
        header = Header(header)
    hdu_list = fits.HDUList([fits.PrimaryHDU(data=data, header=header)])
    return fits_hdulist_encoder(hdu_list)


def fits_hdulist_encoder(hdu_list: fits.HDUList) -> bytes:
    """Convert an `~astropy.io.fits.HDUList` to raw bytes for writing to a file."""
    if not isinstance(hdu_list, fits.HDUList):
        raise ValueError(f"Input type {type(hdu_list)} is not fits.HDUList")
    file_obj = BytesIO()
    hdu_list.writeto(file_obj, checksum=True)
    return iobase_encoder(file_obj)


def fits_hdu_decoder(
    path: Path,
    hdu: int | None = None,
    checksum: bool = True,
    disable_image_compression: bool = False,
    memmap: bool | None = False,
) -> fits.PrimaryHDU | fits.CompImageHDU:
    """
    Read a Path with `~astropy.io.fits` and return the HDU that contains data.

    If ``hdu`` is specified then return that index of the opened HDUList, otherwise return the first HDU that has
    non-`None` data.

    Under the hood, this function opens the specified file, constructs a new HDU with the file's data and header, and
    then closes the original file. This ensures the file descriptor to the original file is freed. If ``memmap=True``
    and no decompression is needed then this function will generate a single additional file descriptor for the memmapping.
    If ``memmap=False`` and no decompression is needed then no extra file descriptors will be opened as a result of this
    function; the returned HDU will live entirely in memory.
    """
    with warnings.catch_warnings():
        # If the checksum is invalid then raise an error instead of warning
        warnings.filterwarnings(
            "error", category=AstropyUserWarning, message="Checksum verification failed for HDU"
        )
        hdu_list = fits.open(
            path,
            checksum=checksum,
            disable_image_compression=disable_image_compression,
            memmap=memmap,
        )
    data_hdu = _extract_hdu(hdu_list, hdu)

    # Create a new HDU that has the same type as the on-disk `data_hdu`. This catches the distinction between
    # un-decompressed (BinTableHDU) and decompressed (CompImageHDU) HDUs of compressed files.
    # We don't use `data_hdu.copy()` because that pulls the data into memory regardless of the `memmap` kwarg.
    # Mostly this line exists as a good way to call `data_hdu.data`, which will load the data (either memmapped or not),
    # which we need to do prior to closing the HDUList.
    new_hdu = type(data_hdu)(data=data_hdu.data, header=data_hdu.header)
    hdu_list.close()

    return new_hdu


def fits_header_decoder(
    path: Path,
    hdu: int | None = None,
) -> fits.Header:
    """
    Read a Path with `~astropy.io.fits` and return a copy of the ``.header`` property.

    This decoder explicitly closes the original file after copying the header.

    This function does NOT decompress `~astropy.io.fits.CompImageHDU` objects. In this case the returned header will
    have the full set of compression keys.

    To speed up reading, the checksum (if present) is not verified.
    """
    hdu_list = fits.open(path, checksum=False, disable_image_compression=True)
    hdu = _extract_hdu(hdu_list, hdu)
    copied_header = hdu.header.copy()
    hdu_list.close()
    return copied_header


def fits_array_decoder(
    path: Path,
    hdu: int | None = None,
    auto_squeeze: bool = True,
    checksum: bool = True,
    disable_image_compression: bool = False,
    memmap: bool | None = False,
) -> np.ndarray:
    """Read a Path with `~astropy.io.fits` and return the ``.data`` property.

    The underlying `~astropy.io.fits.HDUList` is closed prior to returning the data, regardless of the value of ``memmap``.
    This is safe in both cases and merely closes the file link to the `~astropy.io.fits.HDUList` object. If ``memmap = True``
    then an additional file link will persist until the data object is deleted.
    """
    data_hdu = fits_hdu_decoder(
        path,
        hdu=hdu,
        checksum=checksum,
        disable_image_compression=disable_image_compression,
        memmap=memmap,
    )
    data = data_hdu.data

    # This conditional is explicitly to catch summit data with a dummy first axis for WCS
    # purposes
    if auto_squeeze and len(data.shape) == 3 and data.shape[0] == 1:
        return np.squeeze(data)
    return data


def fits_access_decoder(
    path: Path,
    fits_access_class: Type[FitsAccessBase],
    hdu: int | None = None,
    checksum: bool = True,
    disable_image_compression: bool = False,
    memmap: bool | None = False,
    **fits_access_kwargs,
) -> FitsAccessBase:
    """Read a Path with `~astropy.io.fits` and ingest into a `~dkist_processing_common.models.fits_access.FitsAccessBase`-type object."""
    data_hdu = fits_hdu_decoder(
        path,
        hdu=hdu,
        checksum=checksum,
        disable_image_compression=disable_image_compression,
        memmap=memmap,
    )
    return fits_access_class(hdu=data_hdu, name=str(path), **fits_access_kwargs)


def fits_access_header_decoder(
    path: Path,
    fits_access_class: Type[FitsAccessBase],
    hdu: int | None = None,
    **from_header_kwargs,
) -> FitsAccessBase:
    """
    Read a header from a Path with `~astropy.io.fits` and ingest into a `~dkist_processing_common.models.fits_access.FitsAccessBase`-type object.

    Unlike `fits_access_decoder`, this function results in an object with no `.data` property. Furthermore, due to how
    `fits_header_decoder` works, this function guarantees the underlying file is closed after reading.
    """
    header = fits_header_decoder(
        path,
        hdu=hdu,
    )
    return fits_access_class.from_header(header=header, name=str(path), **from_header_kwargs)


def _extract_hdu(hdul: fits.HDUList, hdu: int | None = None) -> fits.PrimaryHDU | fits.CompImageHDU:
    """
    Return the fits hdu associated with the data in the hdu list.

    Only search down the hdu index for the data if the hdu index is not explicitly provided.
    """
    if hdu is not None:
        return hdul[hdu]
    if hdul[0].data is not None:
        return hdul[0]
    return hdul[1]
