"""Classes supporting Calibration Sequence steps."""

from __future__ import annotations

import logging
from collections import Counter
from collections import defaultdict
from datetime import datetime
from datetime import timezone
from enum import StrEnum
from typing import Type

from dkist_processing_common.models.constants import BudName
from dkist_processing_common.models.flower_pot import ListStem
from dkist_processing_common.models.flower_pot import SetStem
from dkist_processing_common.models.flower_pot import SpilledDirt
from dkist_processing_common.models.flower_pot import Stem
from dkist_processing_common.models.tags import StemName
from dkist_processing_common.parsers.l0_fits_access import L0FitsAccess

logger = logging.getLogger(__name__)


class CSStep:
    """
    Compare fits access objects to see if they are from the same CS step.

    This class allows for an easy way to quickly compare fits access objects to determine if they come from the
    same Calibration Sequence (CS) step. Each step in a CS is defined by the configuration of the GOS, namely the
    status of the polarizer and retarder (in or out) and the angle of each. Because some CS schemes call for some
    GOS configurations to repeat, a check is also made against the observation time for each object; the value of
    ``max_cs_time_sec`` defines a maximum difference in time where two exposures are considered different CS steps
    regardless of GOS configuration.

    This class can also be sorted. In this case, only the observation time is taken into account.

    Finally, this class is hashable for use in dictionaries. The hash is only based on the GOS configuration so that
    all objects from the same CS step result in the same hash. Python also checks that dictionary keys are equal so any
    conflicts with repeated CS steps are avoided.

    Parameters
    ----------
    fits_obj
        The FitsAccess object to ingest

    max_cs_time_sec
        Any objects taken more than this amount of time apart are considered in separate steps, regardless of GOS
        configuration.
    """

    def __init__(
        self, fits_obj: L0FitsAccess, max_cs_time_sec: float, angle_round_ndigits: int = 1
    ):
        """Initialize and read the GOS configuration and time from a SPEC-0122 FITS header."""
        self.pol_in = fits_obj.gos_polarizer_status not in ["undefined", "clear"]
        self.pol_theta = round(fits_obj.gos_polarizer_angle, angle_round_ndigits) % 360
        self.ret_in = fits_obj.gos_retarder_status not in ["undefined", "clear"]
        self.ret_theta = round(fits_obj.gos_retarder_angle, angle_round_ndigits) % 360
        self.dark_in = fits_obj.gos_level0_status == "DarkShutter"
        self.obs_time = datetime.fromisoformat(fits_obj.time_obs).replace(tzinfo=timezone.utc)
        self.max_cs_time_sec = max_cs_time_sec

        self.fits_obj_repr = repr(fits_obj)
        self.angle_round_ndigits = angle_round_ndigits

    def __repr__(self):
        return f"{self.__class__.__name__}({self.fits_obj_repr}, max_cs_time_sec={self.max_cs_time_sec!r}, angle_round_ndigits={self.angle_round_ndigits})"

    def __str__(self):
        return "CS step with Pol = {}:{}, Ret = {}:{}, Dark = {}. Taken at {}".format(
            self.pol_in,
            self.pol_theta,
            self.ret_in,
            self.ret_theta,
            self.dark_in,
            self.obs_time.isoformat(),
        )

    def __eq__(self, other: object) -> bool:
        """Two steps are equal if they have the same GOS configuration and are taken within some package-defined time of each other."""
        if not isinstance(other, type(self)):
            raise TypeError(f"Cannot compare {type(self)} with {type(other)}")

        for item in ["pol_in", "pol_theta", "ret_in", "ret_theta", "dark_in"]:
            if getattr(self, item) != getattr(other, item):
                return False

        tdelt = abs(self.obs_time - other.obs_time)
        if tdelt.total_seconds() > self.max_cs_time_sec:
            return False

        return True

    def __lt__(self, other: CSStep) -> bool:
        """Only based on time."""
        return self.obs_time < other.obs_time

    def __hash__(self) -> int:
        """Only based on GSO configuration so that all objects from the same CS step hash the same."""
        return hash((self.pol_in, self.pol_theta, self.ret_in, self.ret_theta, self.dark_in))


class CSStepModstate(CSStep):
    """
    Subclass of `CSStep` that is also aware of the modulation state associated with a given fits object.

    This is used for grouping files based on CS step and modstate, which is useful when determining the number of frames
    in a given CS step.

    The equality and hash functionality of `CSStep` is extended to modulation state, and sorting remains only based on
    observe time.
    """

    def __init__(
        self,
        fits_obj: L0FitsAccess,
        max_cs_time_sec: float,
        angle_round_ndigits: int = 1,
    ):
        super().__init__(
            fits_obj=fits_obj,
            max_cs_time_sec=max_cs_time_sec,
            angle_round_ndigits=angle_round_ndigits,
        )
        self.modstate = fits_obj.modulator_state

    def __repr__(self):
        return f"{self.__class__.__name__}({self.fits_obj_repr}, max_cs_time_sec={self.max_cs_time_sec!r}, angle_round_ndigits={self.angle_round_ndigits})"

    def __str__(self):
        return (
            "CS step with Pol = {}:{}, Ret = {}:{}, Dark = {}. Modstate = {}. Taken at {}".format(
                self.pol_in,
                self.pol_theta,
                self.ret_in,
                self.ret_theta,
                self.dark_in,
                self.modstate,
                self.obs_time.isoformat(),
            )
        )

    def __eq__(self, other: object) -> bool:
        return super().__eq__(other) and self.modstate == other.modstate

    def __hash__(self) -> int:
        return hash(
            (self.pol_in, self.pol_theta, self.ret_in, self.ret_theta, self.dark_in, self.modstate)
        )


class CSStepFlower(Stem):
    """
    Identify which CS Step a header belongs to.

    Parameters
    ----------
    max_cs_step_time_sec
        The maximum cs step time in seconds
    """

    def __init__(self, max_cs_step_time_sec: float):
        super().__init__(stem_name=StemName.cs_step)
        self.max_cs_step_time_sec = max_cs_step_time_sec
        self.CS_step_set = set()

    def setter(self, fits_obj: L0FitsAccess) -> CSStep | Type[SpilledDirt]:
        """
        Set the CS Step for this fits object.

        Parameters
        ----------
        fits_obj
            The input fits object

        Returns
        -------
        The cs step for this fits object
        """
        if fits_obj.ip_task_type != "polcal":
            return SpilledDirt

        cs_step = CSStep(fits_obj, max_cs_time_sec=self.max_cs_step_time_sec)
        self.CS_step_set.add(cs_step)
        return cs_step

    def getter(self, key) -> int:
        """
        Get the CS Step associated with the given key.

        Parameters
        ----------
        key
            The input key

        Returns
        -------
        The cs step for the given key
        """
        unique_steps = sorted(self.CS_step_set)
        return unique_steps.index(self.key_to_petal_dict[key])


class CSStepFrameFlower(Stem):
    """
    Identify the ordered frame in a single CS Step a file belongs to.

    The order of files in a CS Step is set by their observe time.

    Parameters
    ----------
    max_cs_step_time_sec
        The maximum cs step time in seconds
    """

    def __init__(self, max_cs_step_time_sec: float):
        super().__init__(stem_name=StemName.cs_step_frame)
        self.max_cs_step_time_sec = max_cs_step_time_sec
        self.CS_step_dict = defaultdict(list)

    def setter(self, fits_obj: L0FitsAccess) -> CSStepModstate | Type[SpilledDirt]:
        """
        Set the CS Step for this fits object.

        Parameters
        ----------
        fits_obj
            The input fits object

        Returns
        -------
        The cs step for this fits object
        """
        if fits_obj.ip_task_type != "polcal":
            return SpilledDirt

        cs_step = CSStepModstate(
            fits_obj,
            max_cs_time_sec=self.max_cs_step_time_sec,
        )
        self.CS_step_dict[cs_step].append(cs_step)
        return cs_step

    def getter(self, key) -> int:
        """
        Get the index in a sorted list of frames associated with the same CS Step as the given key.

        In other words, which "frame in the CS Step" does this key correspond to?

        Parameters
        ----------
        key
            The input key

        Returns
        -------
        The frame index in the CS Step associated with the given key
        """
        cs_step_for_key = self.key_to_petal_dict[key]

        # Use sorted's `key` here to guarantee we never hit `CSStepModstate.__eq__`, which would consider all of these
        # frames equal because they come from the same CS Step.
        frames_in_cs_step_list = sorted(
            self.CS_step_dict[cs_step_for_key], key=lambda cs: cs.obs_time
        )

        for i, cs_step_i in enumerate(frames_in_cs_step_list):
            if cs_step_i.obs_time == cs_step_for_key.obs_time:
                return i

        raise ValueError(
            f"Could not identify frame in CS step for {cs_step_for_key}. This is impossible. List of siblings is {frames_in_cs_step_list}."
        )


class NumCSStepBud(SetStem):
    """
    The total number of CS Steps present in a dataset.

    Parameters
    ----------
    max_cs_step_time_sec
        The maximum cs step time in seconds
    """

    def __init__(self, max_cs_step_time_sec: float):
        super().__init__(stem_name=BudName.num_cs_steps)
        self.max_cs_step_time_sec = max_cs_step_time_sec

    def setter(self, fits_obj: L0FitsAccess) -> CSStep | Type[SpilledDirt]:
        """
        Return the CS Step for this fits object.

        Parameters
        ----------
        fits_obj
            The input fits object

        Returns
        -------
        The cs step for this fits object
        """
        if fits_obj.ip_task_type != "polcal":
            return SpilledDirt
        return CSStep(fits_obj, max_cs_time_sec=self.max_cs_step_time_sec)

    def getter(self) -> int:
        """
        Return the number of CS Steps present.

        Returns
        -------
        The number of cs steps associated with the key
        """
        return len(self.value_set)


class NumFramesPerCSStepBud(ListStem):
    """
    The number of frames per CS Step present in a dataset.

    Parameters
    ----------
    max_cs_step_time_sec
        The maximum cs step time in seconds
    """

    def __init__(self, max_cs_step_time_sec: float):
        super().__init__(stem_name=BudName.num_frames_per_cs_step)
        self.max_cs_step_time_sec = max_cs_step_time_sec

    def setter(self, fits_obj: L0FitsAccess) -> CSStepModstate | Type[SpilledDirt]:
        """
        Return the CS Step for this fits object.

        Parameters
        ----------
        fits_obj
            The input fits object

        Returns
        -------
        The cs step for this fits object
        """
        if fits_obj.ip_task_type != "polcal":
            return SpilledDirt
        return CSStepModstate(
            fits_obj,
            max_cs_time_sec=self.max_cs_step_time_sec,
        )

    def getter(self) -> int:
        """
        Return number of frames per CS step.

        We assume that each copy of the same `CSStepModstate` object represents a single frame.

        Returns
        -------
        The number of frames per CS step.
        """
        counter = Counter(self.value_list)
        num_frames = set(counter.values())
        if len(num_frames) != 1:
            logger.info(
                "WARNING: CS Steps have a varying number of frames. Very strange. We'll choose the smallest one."
            )

        return sorted(num_frames)[0]
