"""
Platform-specific HTML builders for different publishing platforms.
"""
from __future__ import annotations

from .base import MIME_TO_EXT, PlatformBuilder
from .substack import SubstackBuilder
from .x import XArticlesBuilder
from .medium import MediumBuilder


_BUILDERS: dict[str, type[PlatformBuilder]] = {
    "substack": SubstackBuilder,
    "x": XArticlesBuilder,
    "medium": MediumBuilder,
}


def get_builder(platform: str) -> PlatformBuilder:
    """Get the appropriate HTML builder for the specified platform."""
    if platform not in _BUILDERS:
        raise ValueError(
            f"Unknown platform: {platform}. Supported: {list(_BUILDERS.keys())}"
        )
    return _BUILDERS[platform]()


def list_platforms() -> list[str]:
    """Return list of supported platform names."""
    return list(_BUILDERS.keys())


__all__ = ["MIME_TO_EXT", "PlatformBuilder", "get_builder", "list_platforms"]
