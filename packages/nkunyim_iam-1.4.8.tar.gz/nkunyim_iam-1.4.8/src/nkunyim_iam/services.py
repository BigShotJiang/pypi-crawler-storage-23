import random
import requests
import string

from datetime import datetime, timedelta, timezone
from typing import Optional
from uuid import UUID, uuid4

from django.contrib import auth
from django.http import HttpRequest

from nkunyim_iam.commands import UserCommand
from nkunyim_iam.data import (
    AccessTokenData,
    SessionData,
    TokenData,
    AuthConfigData,
    UserinfoData,
)
from nkunyim_iam.encryption import Hashing, JWTEncryption
from nkunyim_iam.handlers import UserHandler, LoggingHandler
from nkunyim_iam.models import User
from nkunyim_iam.signals import token_data_updated, userinfo_data_updated, user_data_updated



class SessionService:
    def __init__(self, req: HttpRequest) -> None:
        self.req = req
    
    @property
    def key(self) -> str:
        parts = self.req.get_host().lower().split(".")
        if len(parts) < 2:
            key = "www.localhost"
        else:
            domain = ".".join(parts[-2:])
            subdomain = parts[-3] if len(parts) > 2 else "www"
            key = f"{subdomain}.{domain}"
        return f"auth.{key}"
    
    def set(self, data: SessionData) -> None:
        self.req.session[self.key] = data.model_dump()
        self.req.session.modified = True
    
    def get(self) -> Optional[SessionData]:
        if bool(self.key in self.req.session and self.req.session[self.key]):
            session = self.req.session[self.key]
            return SessionData(**session)
        return None
    
    def rmv(self) -> None:
        self.req.session.clear()
        self.req.session.flush()
        auth.logout(self.req)
        
    
class AuthService:
    # PyJWT [https://pyjwt.readthedocs.io/en/stable/index.html]

    def __init__(self, config: AuthConfigData, req: HttpRequest) -> None:
        self.req = req
        self.config = config
        self.headers = {
            "Accept": "application/json",
            "Content-Type": "application/x-www-form-urlencoded",
            "Cache-Control": "no-cache",
        }
        self.session = SessionService(req=req)


    def _log_exception(self, message: str, ex: Exception) -> None:
        LoggingHandler.danger(
            message=message,
            context={"exception": str(ex)},
        )

    def _post(self, path: str, data: Optional[dict] = None) -> Optional[requests.Response]:
        token = self.get_access_token()
        if token:
            self.headers["Authorization"] = "Bearer " + token
        
        response = requests.post(
            url=self.config.back_url + path,
            data=data,
            headers=self.headers,
        )
        if not response.ok:
            LoggingHandler.danger(
                message="Failed to retrieve data from API at " + self.config.back_url + path,
                context={
                    "status_code": response.status_code,
                    "response": response.text,
                    "reason": response.reason,
                    "method": "POST",
                    "headers": str(self.headers),
                    "data": str(data),
                },
            )
            return None
        return response
    
    def _get(self, path: str) -> Optional[requests.Response]:
        token = self.get_access_token()
        if token:
            self.headers["Authorization"] = "Bearer " + token
        
        response = requests.get(
            url=self.config.back_url + path,
            headers=self.headers,
        )
        if not response.ok:
            LoggingHandler.danger(
                message="Failed to retrieve data from API at " + self.config.back_url + path,
                context={
                    "status_code": response.status_code,
                    "response": response.text,
                    "reason": response.reason,
                    "method": "GET",
                    "headers": str(self.headers),
                },
            )
            return None
        return response



    def get_authorization_url(self) -> str:
        state = str(uuid4())
        nonce = uuid4().hex
        next = self.req.GET.get("next", "/home/")
        code_verifier = "".join(
            random.choice(string.ascii_uppercase + string.digits)
            for _ in range(random.randint(43, 128))
        )
        session_data = SessionData(
            next=next,
            state=state,
            nonce=nonce,
            code="",
            verifier=code_verifier,
            token=None,
        )
        self.session.set(data=session_data)

        code_challenge = Hashing(input_string=code_verifier).make(
            algo=self.config.hash_algo
        )

        authorize_url = (
            f"{self.config.front_url}{self.config.authorize_path}?"
            + f"response_type={self.config.response_type}&"
            + f"client_id={self.config.client_id}&"
            + f"redirect_uri={self.config.redirect_uri}&"
            + f"scope={self.config.client_scope}&"
            + f"state={state}&"
            + f"nonce={nonce}&"
            + f"code_challenge={code_challenge}&"
            + f"code_challenge_method={self.config.hash_algo}"
        )

        return authorize_url


    def process_token(self, token_data: dict) -> Optional[TokenData]:
        try:
            session_data = self.session.get()
            if not session_data:
                return None

            # Calculate token expiration time
            expires_in = int(token_data.get("expires_in", 300))
            expires_at = datetime.now(timezone.utc) + timedelta(seconds=expires_in)
            token_data["expires_at"] = expires_at
            
            token_model = TokenData(**token_data)

            session_data.token = token_model
            self.session.set(data=session_data)

            # Inform interested parties
            token_data_updated.send(sender=TokenData, instance=token_model)

            return token_model
        except Exception as ex:
            self._log_exception("Failed to process token data from API.", ex)
            return None


    def authorize_access_token(self) -> Optional[TokenData]:
        try:
            session_data = self.session.get()
            if not session_data:
                return None

            code = self.req.GET.get("code", "")
            state = self.req.GET.get("state", None)

            if not bool(state and session_data.state == state):
                LoggingHandler.danger(
                    message="OAuth2 state mismatch.",
                )
                return None

            error = self.req.GET.get("error", None)
            error_description = self.req.GET.get("error_description", None)
            if bool(error):
                LoggingHandler.danger(
                    message="OAuth2 authorization failed.",
                    context={"error": error, "error_description": error_description},
                )
                return None

            session_data.code = code
            self.session.set(data=session_data)

            data = {
                "client_id": self.config.client_id,
                "client_secret": self.config.client_secret,
                "redirect_uri": self.config.redirect_uri,
                "grant_type": self.config.grant_type,
                "code": code,
                "code_verifier": session_data.verifier,
            }

            response = self._post(path=self.config.token_path, data=data)
            if not response:
                return None

            return self.process_token(token_data=response.json())
        except Exception as ex:
            self._log_exception("Failed to retrieve token data from API.", ex)
            return None


    def refresh_access_token(self) -> Optional[TokenData]:
        try:
            session_data = self.session.get()
            if not (session_data and session_data.token):
                LoggingHandler.danger(
                    message="No refresh token available.",
                )
                return None

            data = {
                "client_id": self.config.client_id,
                "client_secret": self.config.client_secret,
                "grant_type": "refresh_token",
                "refresh_token": session_data.token.refresh_token,
            }
            response = self._post(path=self.config.token_path, data=data)
            if not response:
                return None

            return self.process_token(token_data=response.json())
        except Exception as ex:
            self._log_exception("Failed to refresh token data from API.", ex)
            return None


    def get_userinfo(self, access_token: str) -> Optional[UserinfoData]:
        try:
            self.headers["Authorization"] = "Bearer " + access_token
            response = self._get(path=self.config.userinfo_path)
            if not response:
                return None

            json_data = response.json()
            userinfo_data = UserinfoData(**json_data)

            # Inform interested parties
            userinfo_data_updated.send(sender=UserinfoData, instance=userinfo_data)
            return userinfo_data
        except Exception as ex:
            self._log_exception("Failed to retrieve userinfo data from API.", ex)
            return None

    def jwt_userinfo(self, access_token: str) -> Optional[UserinfoData]:
        try:
            decoded = JWTEncryption.decode(token=access_token)
            access_token_data = AccessTokenData(**decoded)
            if access_token_data.exp <= int(datetime.now(timezone.utc).timestamp()):
                return None
            
            if self.config.client_name.lower() not in  access_token_data.access.roles:
                return None
                
            userinfo = access_token_data.access.user
            userinfo_data = userinfo.model_dump()
            return UserinfoData(**userinfo_data)
        except Exception as ex:
            self._log_exception("Failed to decode userinfo data from JWT.", ex)
            return None
    

    def get_access_token(self) -> Optional[str]:
        session_data = self.session.get()
        if session_data and session_data.token:
            if session_data.token.expires_at <= datetime.now(timezone.utc):
                LoggingHandler.warning(
                    message="Access token has expired. Calling refresh token endpoint.",
                    context=session_data.token.model_dump()
                )
                token_data = self.refresh_access_token()
                if token_data:
                    session_data.token = token_data
                    self.session.set(data=session_data)

            return session_data.token.access_token

        return None


    def authenticate(self, token: str) -> Optional[User]:
        # -- API Use --
        try:
            userinfo_data = self.jwt_userinfo(access_token=token)
            if not userinfo_data:
                return None

            userinfo = userinfo_data.model_dump()
            user_command = UserCommand(**userinfo)
            user_model = UserHandler.handle(command=user_command)
            
            return user_model
        except Exception as ex:
            self._log_exception("Failed to retrieve user data from API.", ex)
            return None


    def authorize(self) -> Optional[User]:
        # -- APP Use --
        try:
            token_data = self.authorize_access_token()
            if not token_data:
                return None

            userinfo_data = self.get_userinfo(access_token=token_data.access_token)
            if not userinfo_data:
                return None

            userinfo = userinfo_data.model_dump()
            user_command = UserCommand(**userinfo)
            user_model = UserHandler.handle(command=user_command)
            
            # Inform interested parties
            user_data_updated.send(sender=User, instance=user_model)

            # Log the user in
            auth.login(self.req, user_model)

            return user_model
        except Exception as ex:
            self._log_exception("Failed to retrieve user data from API.", ex)
            return None


class UserService:
    def __init__(self, req: HttpRequest) -> None:
        self.req = req
        
    def _log_exception(self, message: str, ex: Exception) -> None:
        LoggingHandler.danger(
            message=message,
            context={"exception": str(ex)},
        )


    def get_current_user(self) -> Optional[User]:
        try:
            if not self.is_authenticated:
                return None
            
            user_id = self.req.user.id
            if not user_id:
                return None
            
            user = UserHandler.find(id=user_id)
            return user
        except Exception as ex:
            self._log_exception("Failed to retrieve user data from database.", ex)
            return None
        
        
    def find_by_email(self, email_address: str) -> Optional[User]:
        try:
            user = User.objects.filter(email_address=email_address).first()
            return user
        except Exception as ex:
            self._log_exception("Failed to retrieve user data from database.", ex)
            return None
        
        
    def find_by_phone(self, phone_number: str) -> Optional[User]:
        try:
            user = User.objects.filter(phone_number=phone_number).first()
            return user
        except Exception as ex:
            self._log_exception("Failed to retrieve user data from database.", ex)
            return None
        
    
    def find_by_username(self, username: str) -> Optional[User]:
        try:
            user = User.objects.filter(username=username).first()
            return user
        except Exception as ex:
            self._log_exception("Failed to retrieve user data from database.", ex)
            return None
        
        
    def delete_user(self, id:UUID) -> bool:
        try:
            delete = User.objects.get(pk=id).delete()
            return len(delete) > 0
        except Exception as ex:
            self._log_exception("Failed to delete user data from database.", ex)
            return False
    
    
    def is_authenticated(self) -> bool:
        return self.req.user.is_authenticated
    

    def logout(self) -> None:
        self.req.session.clear()
        self.req.session.flush()
        auth.logout(self.req)
