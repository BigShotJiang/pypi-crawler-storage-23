import requests


class Http:
    
    def __init__(self, domain: str):
        self.domain = domain
        self.httppkg = requests

    def _call(self,*, endpoint, method, headers, payload, **kwargs):
        url = self.domain + endpoint
        responseobj = self.httppkg.request(method=method, url=url, headers=headers, json=payload, **kwargs)
        info = {
            "url": url,
            "method": method,
            "headers": headers,
            "payload": payload
        }
        try:
            info['response'] = responseobj.json()
        except:
            info['response'] = responseobj.text
        finally:
            return info