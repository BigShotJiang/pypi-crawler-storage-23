from signalflow.detector.adapter.pandas_detector import PandasSignalDetector

__all__ = [
    "PandasSignalDetector",
]
