from __future__ import annotations

import builtins
import dataclasses
import importlib
import pkgutil
import sys
from dataclasses import dataclass, field
from importlib.metadata import entry_points
from typing import Any, ClassVar

from loguru import logger

from .enums import SfComponentType

_BUILTIN_RAW_DATA_TYPES: dict[str, set[str]] = {
    "spot": {"pair", "timestamp", "open", "high", "low", "close", "volume"},
    "futures": {"pair", "timestamp", "open", "high", "low", "close", "volume", "open_interest"},
    "perpetual": {"pair", "timestamp", "open", "high", "low", "close", "volume", "funding_rate", "open_interest"},
}


@dataclass
class ComponentInfo:
    """Metadata about a registered component.

    Stores the class reference along with extracted documentation
    for UI display and introspection.

    Attributes:
        cls: The registered component class.
        docstring: Full class docstring (or empty string if none).
        summary: First line of docstring (short description).
        module: Module path where the class is defined.
    """

    cls: type[Any]
    docstring: str = ""
    summary: str = ""
    module: str = ""

    @classmethod
    def from_class(cls, component_cls: type[Any]) -> ComponentInfo:
        """Create ComponentInfo by extracting metadata from a class."""
        docstring = (component_cls.__doc__ or "").strip()
        lines = docstring.split("\n")
        summary = lines[0] if lines else ""
        module = getattr(component_cls, "__module__", "")
        return cls(
            cls=component_cls,
            docstring=docstring,
            summary=summary,
            module=module,
        )


@dataclass
class SignalFlowRegistry:
    """Component registry for dynamic component discovery and instantiation.

    Provides centralized registration and lookup for SignalFlow components.
    Components are organized by type (DETECTOR, EXTRACTOR, etc.) and
    accessed by case-insensitive names.

    Also manages extensible raw data type definitions - each data type maps
    to a set of required columns. Built-in types (SPOT, FUTURES, PERPETUAL)
    are pre-registered; users can add custom types via ``register_raw_data_type()``.

    Registry structure:
        component_type -> name -> ComponentInfo (class + metadata)

    Supported component types:
        - DETECTOR: Signal detection classes
        - EXTRACTOR: Feature extraction classes
        - LABELER: Signal labeling classes
        - ENTRY_RULE: Position entry rules
        - EXIT_RULE: Position exit rules
        - METRIC: Strategy metrics
        - EXECUTOR: Order execution engines

    Attributes:
        _items (dict[SfComponentType, dict[str, ComponentInfo]]):
            Internal storage mapping component types to name-ComponentInfo pairs.
        _raw_data_types (dict[str, set[str]]):
            Mapping of raw data type names to their required column sets.

    Example:
        ```python
        from signalflow.core.registry import SignalFlowRegistry, default_registry

        # Register custom raw data type
        default_registry.register_raw_data_type(
            name="lob",
            columns=["pair", "timestamp", "bid", "ask", "bid_size", "ask_size"],
        )

        # Get component info with docstring for UI
        info = default_registry.get_info(SfComponentType.DETECTOR, "sma_cross")
        print(info.summary)    # "Detects SMA crossover signals."
        print(info.docstring)  # Full docstring with Args, Example, etc.

        # Get columns for any type
        cols = default_registry.get_raw_data_columns("spot")
        custom_cols = default_registry.get_raw_data_columns("lob")

        # List all registered raw data types
        print(default_registry.list_raw_data_types())
        ```

    Note:
        Component names are stored and looked up in lowercase.
        Use default_registry singleton for application-wide registration.

    See Also:
        Semantic decorators (@sf.detector, @sf.feature, etc.) for automatic registration.
    """

    _items: dict[SfComponentType, dict[str, ComponentInfo]] = field(default_factory=dict)
    _raw_data_types: dict[str, set[str]] = field(
        default_factory=lambda: {k: v.copy() for k, v in _BUILTIN_RAW_DATA_TYPES.items()}
    )
    _discovered: bool = field(default=False, repr=False)

    def _ensure(self, component_type: SfComponentType) -> None:
        """Ensure component type exists in registry.

        Initializes empty dict for component_type if not present.

        Args:
            component_type (SfComponentType): Component type to ensure.
        """
        self._items.setdefault(component_type, {})

    # ── Autodiscovery ─────────────────────────────────────────────────

    def _discover_if_needed(self) -> None:
        """Trigger autodiscovery on first read access (lazy loading)."""
        if not self._discovered:
            self.autodiscover()

    def autodiscover(self) -> None:
        """Scan ``signalflow.*`` packages and entry-points for components.

        Walks all sub-modules of the ``signalflow`` package using
        :func:`pkgutil.walk_packages` and imports them.  Because
        semantic decorators register classes at import time, importing
        a module is sufficient to populate the registry.

        External packages can expose components via the
        ``signalflow.components`` entry-point group.  Each entry-point
        should reference a module (not a callable); importing it triggers
        registration through semantic decorators.

        This method is idempotent - subsequent calls are no-ops once
        ``_discovered`` is ``True``.

        Example:
            ```python
            from signalflow.core.registry import default_registry

            # Explicit discovery (normally automatic on first get/list)
            default_registry.autodiscover()

            # All decorated classes are now registered
            print(default_registry.snapshot())
            ```
        """
        if self._discovered:
            return
        self._discovered = True

        self._discover_internal_packages()
        self._discover_entry_points()

    def _discover_internal_packages(self) -> None:
        """Import all ``signalflow.*`` sub-modules to trigger registration."""
        try:
            import signalflow as _sf_root
        except ImportError:  # pragma: no cover
            logger.warning("signalflow package not importable - skipping internal autodiscovery")
            return

        pkg_path = getattr(_sf_root, "__path__", None)
        if pkg_path is None:  # pragma: no cover
            return

        for _importer, modname, _ispkg in pkgutil.walk_packages(pkg_path, prefix="signalflow."):
            if modname in sys.modules:
                continue
            try:
                importlib.import_module(modname)
            except Exception:
                logger.debug(f"autodiscover: failed to import {modname}")

    def _discover_entry_points(self) -> None:
        """Load external plugins registered under ``signalflow.components``."""
        eps = entry_points()

        # Python 3.12+: entry_points() returns SelectableGroups
        if hasattr(eps, "select"):
            group = eps.select(group="signalflow.components")
        else:  # pragma: no cover
            group = getattr(eps, "get", lambda k, d: d)("signalflow.components", [])

        for ep in group:
            try:
                ep.load()
            except Exception:
                logger.warning(f"autodiscover: failed to load entry-point {ep.name!r}")

    def register(self, component_type: SfComponentType, name: str, cls: type[Any], *, override: bool = False) -> None:
        """Register a class under (component_type, name).

        Stores class with metadata (docstring, module) in registry for later
        lookup, instantiation, and UI display.
        Names are normalized to lowercase for case-insensitive lookup.

        Args:
            component_type (SfComponentType): Type of component (DETECTOR, EXTRACTOR, etc.).
            name (str): Registry name (case-insensitive, will be lowercased).
            cls (Type[Any]): Class to register.
            override (bool): Allow overriding existing registration. Default: False.

        Raises:
            ValueError: If name is empty or already registered (when override=False).

        Example:
            ```python
            # Register new component
            registry.register(
                SfComponentType.DETECTOR,
                name="my_detector",
                cls=MyDetector
            )

            # Override existing component
            registry.register(
                SfComponentType.DETECTOR,
                name="my_detector",
                cls=ImprovedDetector,
                override=True  # Logs warning
            )

            # Register multiple types
            registry.register(SfComponentType.EXTRACTOR, "rsi", RsiExtractor)
            registry.register(SfComponentType.LABELER, "fixed", FixedHorizonLabeler)
            ```
        """
        if not isinstance(name, str) or not name.strip():
            raise ValueError("name must be a non-empty string")

        key = name.strip().lower()
        self._ensure(component_type)

        if key in self._items[component_type] and not override:
            raise ValueError(f"{component_type.value}:{key} already registered")

        if key in self._items[component_type] and override:
            logger.warning(f"Overriding {component_type.value}:{key} with {cls.__name__}")

        # Store class with extracted metadata
        self._items[component_type][key] = ComponentInfo.from_class(cls)

    def get(self, component_type: SfComponentType, name: str) -> type[Any]:
        """Get a registered class by key.

        Lookup is case-insensitive. Raises helpful error with available
        components if key not found.

        Args:
            component_type (SfComponentType): Type of component to lookup.
            name (str): Component name (case-insensitive).

        Returns:
            Type[Any]: Registered class.

        Raises:
            KeyError: If component not found. Error message includes available components.

        Example:
            ```python
            # Get component class
            detector_cls = registry.get(SfComponentType.DETECTOR, "sma_cross")

            # Case-insensitive
            detector_cls = registry.get(SfComponentType.DETECTOR, "SMA_Cross")

            # Instantiate manually
            detector = detector_cls(fast_window=10, slow_window=20)

            # Handle missing component
            try:
                cls = registry.get(SfComponentType.DETECTOR, "unknown")
            except KeyError as e:
                print(f"Component not found: {e}")
                # Shows: "Component not found: DETECTOR:unknown. Available: [sma_cross, ...]"
            ```
        """
        self._discover_if_needed()
        self._ensure(component_type)
        key = name.lower()
        try:
            return self._items[component_type][key].cls
        except KeyError as e:
            available = ", ".join(sorted(self._items[component_type]))
            raise KeyError(f"Component not found: {component_type.value}:{key}. Available: [{available}]") from e

    def get_info(self, component_type: SfComponentType, name: str) -> ComponentInfo:
        """Get full component info including docstring.

        Use this method when you need metadata for UI display or
        documentation generation.

        Args:
            component_type (SfComponentType): Type of component to lookup.
            name (str): Component name (case-insensitive).

        Returns:
            ComponentInfo: Full metadata including class, docstring, summary, module.

        Raises:
            KeyError: If component not found.

        Example:
            ```python
            # Get info for UI tooltip
            info = registry.get_info(SfComponentType.DETECTOR, "sma_cross")
            print(info.summary)     # "Detects SMA crossover signals."
            print(info.docstring)   # Full docstring
            print(info.module)      # "signalflow.detector.sma_cross"

            # Use in sf-ui component browser
            for name in registry.list(SfComponentType.FEATURE):
                info = registry.get_info(SfComponentType.FEATURE, name)
                display_component_card(name, info.summary, info.docstring)
            ```
        """
        self._discover_if_needed()
        self._ensure(component_type)
        key = name.lower()
        try:
            return self._items[component_type][key]
        except KeyError as e:
            available = ", ".join(sorted(self._items[component_type]))
            raise KeyError(f"Component not found: {component_type.value}:{key}. Available: [{available}]") from e

    def create(self, component_type: SfComponentType, name: str, **kwargs: Any) -> Any:
        """Instantiate a component by registry key.

        Convenient method that combines get() and instantiation.

        Args:
            component_type (SfComponentType): Type of component to create.
            name (str): Component name (case-insensitive).
            **kwargs: Arguments to pass to component constructor.

        Returns:
            Any: Instantiated component.

        Raises:
            KeyError: If component not found.
            TypeError: If kwargs don't match component constructor.

        Example:
            ```python
            # Create detector with params
            detector = registry.create(
                SfComponentType.DETECTOR,
                "sma_cross",
                fast_window=10,
                slow_window=20
            )

            # Create extractor
            extractor = registry.create(
                SfComponentType.EXTRACTOR,
                "rsi",
                window=14
            )

            # Create with config dict
            config = {"window": 20, "threshold": 0.7}
            labeler = registry.create(
                SfComponentType.LABELER,
                "fixed",
                **config
            )
            ```
        """
        cls = self.get(component_type, name)
        return cls(**kwargs)

    def list(self, component_type: SfComponentType) -> list[str]:
        """List registered components for a type.

        Returns sorted list of component names for given type.

        Args:
            component_type (SfComponentType): Type of components to list.

        Returns:
            list[str]: Sorted list of registered component names.

        Example:
            ```python
            # List all detectors
            detectors = registry.list(SfComponentType.DETECTOR)
            print(f"Available detectors: {detectors}")
            # Output: ['ema_cross', 'macd', 'rsi_threshold', 'sma_cross']

            # Check if component exists
            if "sma_cross" in registry.list(SfComponentType.DETECTOR):
                detector = registry.create(SfComponentType.DETECTOR, "sma_cross")

            # List all component types
            from signalflow.core.enums import SfComponentType
            for component_type in SfComponentType:
                components = registry.list(component_type)
                print(f"{component_type.value}: {components}")
            ```
        """
        self._discover_if_needed()
        self._ensure(component_type)
        return sorted(self._items[component_type])

    # ── Raw data type registry ─────────────────────────────────────────

    def register_raw_data_type(
        self,
        name: str,
        columns: builtins.list[str] | set[str],
        *,
        override: bool = False,
    ) -> None:
        """Register a custom raw data type with its required columns.

        Args:
            name: Data type identifier (case-insensitive, stored lowercase).
            columns: Required column names for this data type.
            override: Allow overriding an existing registration.

        Raises:
            ValueError: If name is empty, columns are empty, or name already
                registered (when override=False).

        Example:
            ```python
            default_registry.register_raw_data_type(
                name="lob",
                columns=["pair", "timestamp", "bid", "ask", "bid_size", "ask_size"],
            )
            ```
        """
        if not isinstance(name, str) or not name.strip():
            raise ValueError("name must be a non-empty string")

        cols = set(columns)
        if not cols:
            raise ValueError("columns must be a non-empty collection")

        key = name.strip().lower()

        if key in self._raw_data_types and not override:
            raise ValueError(f"Raw data type '{key}' already registered")

        if key in self._raw_data_types and override:
            logger.warning(f"Overriding raw data type '{key}'")

        self._raw_data_types[key] = cols

    def get_raw_data_columns(self, name: str) -> set[str]:
        """Get required columns for a raw data type.

        Args:
            name: Data type identifier (case-insensitive). Accepts both
                ``RawDataType`` enum members and plain strings.

        Returns:
            Copy of the column set for the requested type.

        Raises:
            KeyError: If data type is not registered.

        Example:
            ```python
            cols = default_registry.get_raw_data_columns("spot")
            # {'pair', 'timestamp', 'open', 'high', 'low', 'close', 'volume'}

            cols = default_registry.get_raw_data_columns("lob")
            # {'pair', 'timestamp', 'bid', 'ask', ...}
            ```
        """
        raw = getattr(name, "value", name)
        key = str(raw).strip().lower()
        try:
            return self._raw_data_types[key].copy()
        except KeyError:
            available = ", ".join(sorted(self._raw_data_types))
            raise KeyError(f"Raw data type '{key}' not registered. Available: [{available}]") from None

    def list_raw_data_types(self) -> builtins.list[str]:
        """List all registered raw data type names.

        Returns:
            Sorted list of registered data type names.
        """
        return sorted(self._raw_data_types)

    # ── Schema introspection ──────────────────────────────────────────

    # Fields from base classes that are internal infrastructure, not user-facing params
    _BASE_FIELDS: ClassVar[frozenset[str]] = frozenset(
        {
            "component_type",
            # SignalDetector base
            "pair_col",
            "ts_col",
            "group_col",
            "raw_data_type",
            "features",
            "require_probability",
            "keep_only_latest_per_pair",
            "allowed_signal_types",
            "signal_category",
            # Feature base
            "normalized",
            "norm_period",
            # Runner internal
            "broker",
            "entry_rules",
            "exit_rules",
            "metrics",
            "strategy_id",
            "initial_capital",
            "price_col",
            "data_key",
            "show_progress",
        }
    )

    def get_schema(self, component_type: SfComponentType, name: str) -> dict[str, Any]:
        """Get JSON-serializable parameter schema for a registered component.

        Uses ``dataclasses.fields()`` to introspect ``@dataclass``-decorated
        components and extract field names, types, and defaults.

        Args:
            component_type: Type of component.
            name: Component registry name (case-insensitive).

        Returns:
            Schema dict with keys: ``name``, ``class_name``, ``component_type``,
            ``description``, ``docstring``, ``module``, ``parameters``,
            ``requires``, ``outputs``.

        Raises:
            KeyError: If component not found.

        Example:
            >>> schema = registry.get_schema(SfComponentType.DETECTOR, "example/sma_cross")
            >>> print(schema["description"])  # Short summary
            >>> print(schema["docstring"])    # Full docstring for UI
            >>> for p in schema["parameters"]:
            ...     print(f"{p['name']}: {p['type']} = {p['default']}")
        """
        info = self.get_info(component_type, name)
        cls = info.cls

        parameters: list[dict[str, Any]] = []
        if dataclasses.is_dataclass(cls):
            for f in dataclasses.fields(cls):
                if f.name.startswith("_") or f.name in self._BASE_FIELDS:
                    continue
                # Skip ClassVar fields (they show up as strings containing "ClassVar")
                type_str = self._type_to_str(f.type)
                if "ClassVar" in type_str:
                    continue

                has_default = f.default is not dataclasses.MISSING
                has_default_factory = f.default_factory is not dataclasses.MISSING  # type: ignore[misc]

                parameters.append(
                    {
                        "name": f.name,
                        "type": type_str,
                        "default": f.default if has_default else None,
                        "required": not has_default and not has_default_factory,
                    }
                )

        # Extract ClassVar metadata
        requires = getattr(cls, "requires", [])
        outputs = getattr(cls, "outputs", [])

        return {
            "name": name,
            "class_name": cls.__name__,
            "component_type": component_type.value,
            "description": info.summary,
            "docstring": info.docstring,
            "module": info.module,
            "parameters": parameters,
            "requires": list(requires) if requires else [],
            "outputs": list(outputs) if outputs else [],
        }

    def export_schemas(self) -> dict[str, builtins.list[dict[str, Any]]]:
        """Export schemas for all registered components, grouped by type.

        Useful for bulk loading into UI component browsers without N+1 calls.

        Returns:
            Dict mapping component type names to lists of component schemas.

        Example:
            >>> all_schemas = registry.export_schemas()
            >>> for det in all_schemas.get("DETECTOR", []):
            ...     print(det["name"], len(det["parameters"]), "params")
        """
        self._discover_if_needed()
        result: dict[str, list[dict[str, Any]]] = {}
        for comp_type, names_dict in self._items.items():
            schemas = []
            for name in sorted(names_dict):
                try:
                    schemas.append(self.get_schema(comp_type, name))
                except Exception:
                    logger.debug(f"export_schemas: failed to get schema for {comp_type.value}:{name}")
            if schemas:
                result[comp_type.value] = schemas
        return result

    @staticmethod
    def _type_to_str(type_annotation: Any) -> str:
        """Convert a type annotation to a readable string."""
        s = str(type_annotation)
        # Clean up common patterns
        for prefix in ("typing.", "signalflow.core.enums.", "signalflow."):
            s = s.replace(prefix, "")
        # Remove <class '...'> wrapper
        if s.startswith("<class '") and s.endswith("'>"):
            s = s[8:-2]
        return s

    # ── Snapshot ────────────────────────────────────────────────────────

    def snapshot(self) -> dict[str, builtins.list[str]]:
        """Snapshot of registry for debugging.

        Returns complete registry state organized by component type.

        Returns:
            dict[str, list[str]]: Dictionary mapping component type names
                to sorted lists of registered component names.

        Example:
            ```python
            # Get full registry snapshot
            snapshot = registry.snapshot()
            print(snapshot)
            # Output:
            # {
            #     'DETECTOR': ['ema_cross', 'sma_cross'],
            #     'EXTRACTOR': ['rsi', 'sma'],
            #     'LABELER': ['fixed', 'triple_barrier'],
            #     'ENTRY_RULE': ['fixed_size'],
            #     'EXIT_RULE': ['take_profit', 'time_based']
            # }

            # Use for debugging
            import json
            print(json.dumps(registry.snapshot(), indent=2))

            # Check registration status
            snapshot = registry.snapshot()
            if 'DETECTOR' in snapshot and 'sma_cross' in snapshot['DETECTOR']:
                print("SMA detector is registered")
            ```
        """
        self._discover_if_needed()
        return {t.value: sorted(v.keys()) for t, v in self._items.items()}


default_registry = SignalFlowRegistry()
"""Global default registry instance.

Use this singleton for application-wide component registration.

Example:
    ```python
    from signalflow.core.registry import default_registry
    from signalflow.core.enums import SfComponentType

    # Register to default registry
    default_registry.register(
        SfComponentType.DETECTOR,
        "my_detector",
        MyDetector
    )

    # Access from anywhere
    detector = default_registry.create(
        SfComponentType.DETECTOR,
        "my_detector"
    )
    ```
"""


def get_component(type: SfComponentType, name: str) -> type[Any]:
    """Get a registered component by type and name."""
    return default_registry.get(type, name)


def get_component_info(type: SfComponentType, name: str) -> ComponentInfo:
    """Get component info including docstring for UI display."""
    return default_registry.get_info(type, name)
