from dataclasses import dataclass, field
from typing import Any, ClassVar

import polars as pl

from signalflow.core import RawDataType, RawDataView
from signalflow.core.registry import default_registry
from signalflow.feature.base import Feature, GlobalFeature


@dataclass
class FeaturePipeline(Feature):
    """Orchestrates multiple features with optimized execution.

    Groups consecutive per-pair features into batches for single group_by.

    Args:
        features: List of features to compute.
        raw_data_type: Type of raw data (defines available columns).

    Example:
        >>> pipeline = FeaturePipeline(
        ...     features=[
        ...         RsiFeature(period=14),
        ...         SmaFeature(period=20),
        ...         GlobalFeature(base=RsiFeature(period=14), reference_pair="BTCUSDT"),
        ...     ],
        ...     raw_data_type=RawDataType.SPOT,
        ... )
        >>> df = pipeline.run(raw_data_view)
    """

    features: list[Feature] = field(default_factory=list)
    raw_data_type: RawDataType | str = RawDataType.SPOT

    requires: ClassVar[list[str]] = []

    def __post_init__(self) -> None:
        if not self.features:
            raise ValueError("FeaturePipeline requires at least one feature")
        self._validate()

    @property
    def outputs(self) -> list[str]:  # type: ignore[override]
        """Aggregated outputs from all features."""
        result: list[str] = []
        for f in self.features:
            result.extend(f.output_cols())
        return result

    def output_cols(self, prefix: str = "") -> list[str]:
        return [f"{prefix}{col}" for col in self.outputs]

    def _validate(self) -> None:
        """Validate all dependencies are satisfied."""
        available = default_registry.get_raw_data_columns(self.raw_data_type)

        for f in self.features:
            required = set(f.required_cols())
            missing = required - available

            if missing:
                raise ValueError(f"{f.__class__.__name__} requires {missing}, available: {sorted(available)}")

            available.update(f.output_cols())

    def _group_into_batches(self) -> list[list[Feature]]:
        """Group features: consecutive per-pair → batch, global → separate."""
        batches = []
        current_batch: list[Feature] = []

        for f in self.features:
            is_global = isinstance(f, (GlobalFeature, FeaturePipeline)) or getattr(f, "_is_global", False)

            if is_global:
                if current_batch:
                    batches.append(current_batch)
                    current_batch = []
                batches.append([f])
            else:
                current_batch.append(f)

        if current_batch:
            batches.append(current_batch)

        return batches

    def _is_per_pair_batch(self, batch: list[Feature]) -> bool:
        """Check if batch contains only per-pair features."""
        return not any(
            isinstance(f, (GlobalFeature, FeaturePipeline)) or getattr(f, "_is_global", False) for f in batch
        )

    def compute(self, df: pl.DataFrame, context: dict[str, Any] | None = None) -> pl.DataFrame:
        """Compute all features with optimized batching."""
        df = df.sort([self.group_col, self.ts_col])

        batches = self._group_into_batches()

        for batch in batches:
            if self._is_per_pair_batch(batch):

                def apply_batch(pair_df: pl.DataFrame, features: list[Feature] = batch) -> pl.DataFrame:
                    for f in features:
                        pair_df = f.compute_pair(pair_df)
                    return pair_df

                df = df.group_by(self.group_col, maintain_order=True).map_groups(apply_batch)
            else:
                for f in batch:
                    df = f.compute(df, context=context)

        return df

    def run(self, raw_data_view: RawDataView, context: dict[str, Any] | None = None) -> pl.DataFrame:
        """Entry point: load from RawDataView and compute."""
        key = getattr(self.raw_data_type, "value", self.raw_data_type)
        df = raw_data_view.to_polars(key)
        return self.compute(df)

    def to_mermaid(self) -> str:
        """Generate Mermaid diagram of feature dependencies."""
        lines = ["graph LR"]
        lines.append("    subgraph Input")
        for col in sorted(default_registry.get_raw_data_columns(self.raw_data_type)):
            lines.append(f"        {col}[{col}]")
        lines.append("    end")

        for f in self.features:
            name = f.__class__.__name__
            if hasattr(f, "period"):
                name = f"{name}_{f.period}"

            for req in f.required_cols():
                lines.append(f"    {req} --> {name}")
            for out in f.output_cols():
                lines.append(f"    {name} --> {out}[{out}]")

        return "\n".join(lines)
