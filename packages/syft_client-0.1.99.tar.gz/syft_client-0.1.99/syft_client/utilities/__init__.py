"""
Utility functions for syft-client diagnostics and debugging.
"""

from syft_client.utilities.bug_report import bug_report

__all__ = ["bug_report"]
