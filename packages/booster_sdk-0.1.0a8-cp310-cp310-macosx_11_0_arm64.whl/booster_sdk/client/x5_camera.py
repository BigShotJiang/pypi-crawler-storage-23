"""X5 camera client bindings."""

from __future__ import annotations

import booster_sdk_bindings as bindings

X5CameraClient = bindings.X5CameraClient

__all__ = ["X5CameraClient"]
