"""Version information for dawg-baas SDK."""

__version__ = "0.1.1"
