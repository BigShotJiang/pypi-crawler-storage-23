"""
File Manager - SDK-level file & image upload/download operations.

Provides org.files.* API and object-level .attach() / .detach() convenience.

Architecture:
    File service stores binary → returns FileReference → CRUD saves reference to entity.
    FileManager wraps BOTH steps so callers never deal with raw HTTP multipart.

Usage:
    org = Supero.login(domain_name="my-app", email="...", password="...")

    # ── Upload standalone (Step 1 only — returns FileReference) ──
    ref = org.files.upload("photo.jpg")
    refs = org.files.upload_batch(["a.jpg", "b.jpg", "c.jpg"])

    # ── Attach to object (Step 1 + Step 2 in one call) ──
    org.files.attach(project_uuid, "real_estate_project", "project_photos", "render.jpg")
    org.files.attach(project_uuid, "real_estate_project", "brochure", open("brochure.pdf", "rb"))

    # ── Fluent object-level (injected by core.py) ──
    project.attach("project_photos", file="render.jpg")
    project.attach("brochure", file=open("brochure.pdf", "rb"))
    project.detach("project_photos", file_id="img_a7bX9kLmNp3q")

    # ── Download ──
    content, filename, mime = org.files.download("img_a7bX9kLmNp3q")
    org.files.download_to("img_a7bX9kLmNp3q", "/tmp/photo.jpg")

    # ── Replace (same file_id, same URL) ──
    org.files.replace("img_a7bX9kLmNp3q", "new-render.jpg")

    # ── Delete (binary + optionally remove from entity) ──
    org.files.delete("img_a7bX9kLmNp3q")
    org.files.detach(project_uuid, "real_estate_project", "project_photos", "img_a7bX9kLmNp3q")

    # ── Signed URL (S3 backends, 1hr expiry) ──
    url = org.files.signed_url("img_a7bX9kLmNp3q")

    # ── Thumbnail URL ──
    url = org.files.thumbnail_url("img_a7bX9kLmNp3q")
"""

from __future__ import annotations

import io
import logging
import mimetypes
import os
from pathlib import Path
from typing import Any, BinaryIO, Dict, List, Optional, Tuple, Union

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Type alias
# ---------------------------------------------------------------------------
FileLike = Union[str, Path, BinaryIO, bytes]
"""Accepted file input: path string, Path object, open binary file, or raw bytes."""


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _resolve_file(file: FileLike) -> Tuple[str, BinaryIO, Optional[str]]:
    """
    Normalize any accepted file input into (filename, file_obj, mime_type).

    Returns:
        (filename, readable binary IO, guessed MIME type or None)
    """
    if isinstance(file, (str, Path)):
        path = Path(file)
        if not path.exists():
            raise FileNotFoundError(f"File not found: {path}")
        mime, _ = mimetypes.guess_type(str(path))
        return path.name, open(path, "rb"), mime

    if isinstance(file, bytes):
        return "upload", io.BytesIO(file), None

    # Assume file-like object (has .read)
    if hasattr(file, "read"):
        name = getattr(file, "name", "upload")
        if isinstance(name, (str, Path)):
            name = Path(name).name
        mime, _ = mimetypes.guess_type(str(name))
        return str(name), file, mime

    raise TypeError(
        f"Unsupported file type: {type(file).__name__}. "
        f"Pass a file path (str/Path), open binary file, or bytes."
    )


# ---------------------------------------------------------------------------
# FileReference (thin wrapper for the JSON the service returns)
# ---------------------------------------------------------------------------

class FileReference(dict):
    """
    Dict subclass wrapping the JSON returned by the file service.

    Attributes accessible as properties:
        ref.file_id, ref.filename, ref.url, ref.thumbnail_url,
        ref.mime_type, ref.size_bytes, ref.width, ref.height,
        ref.uploaded_at

    Also behaves as a plain dict so it can be saved directly into
    CRUD payloads without conversion.
    """

    @property
    def file_id(self) -> str:
        return self.get("file_id", "")

    @property
    def filename(self) -> str:
        return self.get("filename", "")

    @property
    def url(self) -> str:
        return self.get("url", "")

    @property
    def thumbnail_url(self) -> Optional[str]:
        return self.get("thumbnail_url")

    @property
    def mime_type(self) -> str:
        return self.get("mime_type", "")

    @property
    def size_bytes(self) -> int:
        return self.get("size_bytes", 0)

    @property
    def width(self) -> Optional[int]:
        return self.get("width")

    @property
    def height(self) -> Optional[int]:
        return self.get("height")

    @property
    def uploaded_at(self) -> Optional[str]:
        return self.get("uploaded_at")

    @property
    def is_image(self) -> bool:
        return self.file_id.startswith("img_")

    @property
    def size_display(self) -> str:
        """Human-readable size string."""
        b = self.size_bytes
        if b < 1024:
            return f"{b} B"
        elif b < 1024 * 1024:
            return f"{b / 1024:.1f} KB"
        else:
            return f"{b / (1024 * 1024):.1f} MB"

    def __repr__(self) -> str:
        return (
            f"FileReference(file_id={self.file_id!r}, "
            f"filename={self.filename!r}, "
            f"size={self.size_display})"
        )


# ---------------------------------------------------------------------------
# BatchUploadResult
# ---------------------------------------------------------------------------

class BatchUploadResult:
    """Result of a batch upload operation."""

    def __init__(self, data: Dict[str, Any]):
        self.files: List[FileReference] = [
            FileReference(f) for f in data.get("files", [])
        ]
        self.failed: List[Dict[str, Any]] = data.get("failed", [])

    @property
    def succeeded(self) -> int:
        return len(self.files)

    @property
    def failed_count(self) -> int:
        return len(self.failed)

    @property
    def all_succeeded(self) -> bool:
        return self.failed_count == 0

    def __repr__(self) -> str:
        return (
            f"BatchUploadResult(succeeded={self.succeeded}, "
            f"failed={self.failed_count})"
        )


# ---------------------------------------------------------------------------
# FileManager
# ---------------------------------------------------------------------------

class FileManager:
    """
    SDK-level file & image management.

    Wraps /api/v1/files/{domain}/* endpoints and provides
    convenience methods that combine upload + CRUD in one call.
    """

    # Max sizes enforced client-side (server also validates)
    # Source: Image.json → ui_hints.max_size_mb = 10
    #         File.json  → ui_hints.max_size_mb = 25
    MAX_IMAGE_SIZE = 10 * 1024 * 1024   # 10 MB
    MAX_FILE_SIZE  = 25 * 1024 * 1024   # 25 MB
    MAX_BATCH_SIZE = 10                  # max files per batch

    # Image type accepted MIMEs — must match Image.json ui_hints.accept exactly.
    # Files with these MIMEs get the 10 MB limit and Image-type treatment (width, height, thumbnail).
    # All other files are treated as File type (25 MB limit, no dimensions).
    IMAGE_MIMES = {
        "image/jpeg",
        "image/png",
        "image/webp",
        "image/gif",
        "image/svg+xml",
        "image/bmp",
        "image/tiff",
    }

    # Thumbnail-capable subset — file service generates 200×200 thumbs for raster formats only.
    # SVG is vector, so thumbnail_url will be null for SVG.
    THUMBNAIL_MIMES = IMAGE_MIMES - {"image/svg+xml"}

    def __init__(self, supero: 'Supero'):
        """
        Initialize FileManager.

        Args:
            supero: Parent Supero instance (provides domain, auth, HTTP)
        """
        self._org = supero
        self.logger = supero.logger

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @property
    def _domain(self) -> str:
        return self._org.domain_name

    def _file_endpoint(self, *parts) -> str:
        """Build /api/v1/files/{domain}/... path."""
        base = f"/api/v1/files/{self._domain}"
        if parts:
            base += "/" + "/".join(str(p) for p in parts)
        return base

    def _crud_endpoint(self, obj_type: str, uuid: str) -> str:
        """Build /crud/{domain}/{obj_type}/{uuid} path (matches CrudManager convention)."""
        return f"/crud/{self._domain}/{obj_type}/{uuid}"

    def _auth_headers(self, api_key: Optional[str] = None) -> Dict[str, str]:
        """Build auth headers. Does NOT set Content-Type (browser handles multipart boundary)."""
        headers: Dict[str, str] = {}
        if api_key:
            headers["X-API-Key"] = api_key
        elif self._org.jwt_token:
            headers["Authorization"] = f"Bearer {self._org.jwt_token}"
        return headers

    def _validate_file_size(self, file_obj: BinaryIO, mime: Optional[str]) -> int:
        """
        Validate file size against limits. Returns size in bytes.

        Raises:
            ValueError: If file exceeds size limit
        """
        # Read current position, seek to end, measure, seek back
        pos = file_obj.tell()
        file_obj.seek(0, 2)
        size = file_obj.tell()
        file_obj.seek(pos)

        is_image = mime in self.IMAGE_MIMES if mime else False
        limit = self.MAX_IMAGE_SIZE if is_image else self.MAX_FILE_SIZE
        limit_label = "10 MB (image)" if is_image else "25 MB"

        if size > limit:
            raise ValueError(
                f"File size {size / (1024*1024):.1f} MB exceeds {limit_label} limit"
            )
        return size

    # ------------------------------------------------------------------
    # Upload
    # ------------------------------------------------------------------

    def upload(
        self,
        file: FileLike,
        *,
        filename: Optional[str] = None,
        api_key: Optional[str] = None,
    ) -> FileReference:
        """
        Upload a single file to the file service.

        This is Step 1 only — returns a FileReference that you can then
        save into an entity attribute via CRUD.  For a combined flow,
        use ``attach()``.

        Args:
            file: File path (str/Path), open binary file, or raw bytes.
            filename: Override filename (optional).
            api_key: Optional API key for RBAC.

        Returns:
            FileReference with file_id, url, thumbnail_url, etc.

        Raises:
            FileNotFoundError: If path doesn't exist.
            ValueError: If file exceeds size limit.

        Example:
            >>> ref = org.files.upload("photos/front-view.jpg")
            >>> print(ref.file_id)   # 'img_a7bX9kLmNp3q'
            >>> print(ref.url)       # '/api/v1/files/acme-corp/img_a7bX9kLmNp3q'
        """
        name, file_obj, mime = _resolve_file(file)
        if filename:
            name = filename

        try:
            self._validate_file_size(file_obj, mime)

            # PlatformClient.post_multipart() or raw requests
            data = self._org._platform_client.post_multipart(
                self._file_endpoint("upload"),
                file_field="file",
                file_name=name,
                file_obj=file_obj,
                file_mime=mime,
                extra_headers=self._auth_headers(api_key),
            )
            ref = FileReference(data)
            self.logger.debug(f"Uploaded: {ref}")
            return ref

        finally:
            # Close file if we opened it
            if isinstance(file, (str, Path)):
                file_obj.close()

    def upload_batch(
        self,
        files: List[FileLike],
        *,
        api_key: Optional[str] = None,
    ) -> BatchUploadResult:
        """
        Upload multiple files in one request (max 10).

        Args:
            files: List of file paths, open files, or bytes.
            api_key: Optional API key for RBAC.

        Returns:
            BatchUploadResult with .files (succeeded) and .failed lists.

        Raises:
            ValueError: If more than 10 files provided.

        Example:
            >>> result = org.files.upload_batch(["a.jpg", "b.jpg", "c.jpg"])
            >>> print(f"Uploaded {result.succeeded}, failed {result.failed_count}")
            >>> for ref in result.files:
            ...     print(ref.file_id, ref.url)
        """
        if len(files) > self.MAX_BATCH_SIZE:
            raise ValueError(
                f"Batch upload limited to {self.MAX_BATCH_SIZE} files, "
                f"got {len(files)}"
            )

        opened_files = []
        file_tuples = []  # [(field_name, (filename, file_obj, mime)), ...]

        try:
            for f in files:
                name, file_obj, mime = _resolve_file(f)
                self._validate_file_size(file_obj, mime)
                file_tuples.append((name, file_obj, mime))
                if isinstance(f, (str, Path)):
                    opened_files.append(file_obj)

            data = self._org._platform_client.post_multipart_batch(
                self._file_endpoint("upload", "batch"),
                file_field="files[]",
                files=file_tuples,
                extra_headers=self._auth_headers(api_key),
            )
            result = BatchUploadResult(data)
            self.logger.debug(f"Batch upload: {result}")
            return result

        finally:
            for f in opened_files:
                f.close()

    # ------------------------------------------------------------------
    # Download
    # ------------------------------------------------------------------

    def download(
        self,
        file_id: str,
        *,
        api_key: Optional[str] = None,
    ) -> Tuple[bytes, str, str]:
        """
        Download file content.

        Args:
            file_id: File ID (e.g. 'img_a7bX9kLmNp3q' or 'file_xYz123456')
            api_key: Optional API key for RBAC.

        Returns:
            (content_bytes, filename, mime_type)

        Example:
            >>> content, filename, mime = org.files.download("img_a7bX9kLmNp3q")
            >>> with open(filename, "wb") as f:
            ...     f.write(content)
        """
        data = self._org._platform_client.get_binary(
            self._file_endpoint(file_id),
            extra_headers=self._auth_headers(api_key),
        )
        return data["content"], data["filename"], data["mime_type"]

    def download_to(
        self,
        file_id: str,
        output_path: str,
        *,
        api_key: Optional[str] = None,
    ) -> str:
        """
        Download file and save to disk.

        Args:
            file_id: File ID.
            output_path: Destination path. If a directory, uses original filename.
            api_key: Optional API key for RBAC.

        Returns:
            Actual path written.

        Example:
            >>> path = org.files.download_to("img_a7bX9kLmNp3q", "/tmp/")
            >>> print(f"Saved to: {path}")
        """
        content, filename, _ = self.download(file_id, api_key=api_key)

        out = Path(output_path)
        if out.is_dir():
            out = out / filename

        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(content)

        self.logger.debug(f"Downloaded {file_id} → {out}")
        return str(out)

    # ------------------------------------------------------------------
    # Replace
    # ------------------------------------------------------------------

    def replace(
        self,
        file_id: str,
        file: FileLike,
        *,
        filename: Optional[str] = None,
        api_key: Optional[str] = None,
    ) -> FileReference:
        """
        Replace file binary (same file_id, same URL).

        Useful for updating an image without changing references.

        Args:
            file_id: Existing file ID.
            file: New file content.
            filename: Override filename (optional).
            api_key: Optional API key for RBAC.

        Returns:
            Updated FileReference (size/dimensions may change).

        Example:
            >>> updated = org.files.replace("img_a7bX9kLmNp3q", "new-render.jpg")
            >>> print(updated.size_bytes)
        """
        name, file_obj, mime = _resolve_file(file)
        if filename:
            name = filename

        try:
            self._validate_file_size(file_obj, mime)

            data = self._org._platform_client.put_multipart(
                self._file_endpoint(file_id),
                file_field="file",
                file_name=name,
                file_obj=file_obj,
                file_mime=mime,
                extra_headers=self._auth_headers(api_key),
            )
            ref = FileReference(data)
            self.logger.debug(f"Replaced: {ref}")
            return ref

        finally:
            if isinstance(file, (str, Path)):
                file_obj.close()

    # ------------------------------------------------------------------
    # Delete
    # ------------------------------------------------------------------

    def delete(
        self,
        file_id: str,
        *,
        api_key: Optional[str] = None,
    ) -> bool:
        """
        Delete file binary from storage.

        NOTE: This removes the binary only. If the FileReference is saved
        in an entity attribute, use ``detach()`` to also remove the reference.

        Args:
            file_id: File ID to delete.
            api_key: Optional API key for RBAC.

        Returns:
            True if deleted.

        Example:
            >>> org.files.delete("img_a7bX9kLmNp3q")
        """
        self._org._platform_client.delete(
            self._file_endpoint(file_id),
            extra_headers=self._auth_headers(api_key),
        )
        self.logger.debug(f"Deleted file: {file_id}")
        return True

    # ------------------------------------------------------------------
    # URLs
    # ------------------------------------------------------------------

    def url(self, file_id: str) -> str:
        """
        Get direct download URL for a file.

        Args:
            file_id: File ID.

        Returns:
            URL string (relative).

        Example:
            >>> org.files.url("img_a7bX9kLmNp3q")
            '/api/v1/files/acme-corp/img_a7bX9kLmNp3q'
        """
        return self._file_endpoint(file_id)

    def thumbnail_url(self, file_id: str) -> str:
        """
        Get thumbnail URL for an image (200×200 JPEG).

        Args:
            file_id: File ID (must be an image).

        Returns:
            Thumbnail URL string (relative).

        Example:
            >>> org.files.thumbnail_url("img_a7bX9kLmNp3q")
            '/api/v1/files/acme-corp/img_a7bX9kLmNp3q/thumb'
        """
        return self._file_endpoint(file_id, "thumb")

    def signed_url(
        self,
        file_id: str,
        *,
        api_key: Optional[str] = None,
    ) -> str:
        """
        Get a signed URL with 1-hour expiry (S3 backends only).

        Args:
            file_id: File ID.
            api_key: Optional API key for RBAC.

        Returns:
            Signed URL string.

        Example:
            >>> url = org.files.signed_url("img_a7bX9kLmNp3q")
        """
        data = self._org._platform_client.get(
            self._file_endpoint(file_id),
            params={"signed": "true"},
            extra_headers=self._auth_headers(api_key),
        )
        return data.get("signed_url", data.get("url", ""))

    # ==================================================================
    # ATTACH / DETACH  (combined upload + CRUD in one call)
    # ==================================================================

    def attach(
        self,
        obj_uuid: str,
        obj_type: str,
        attribute: str,
        file: FileLike,
        *,
        filename: Optional[str] = None,
        append: bool = True,
        is_list: Optional[bool] = None,
        api_key: Optional[str] = None,
    ) -> FileReference:
        """
        Upload file AND save reference into an entity attribute (two-step in one call).

        For ``list`` attributes (galleries), appends by default.
        For single-value attributes, replaces the current value.

        Args:
            obj_uuid: UUID of the target entity.
            obj_type: Schema type name (e.g. "real_estate_project").
            attribute: Attribute name on the schema (e.g. "project_photos").
            file: File to upload (path, open file, or bytes).
            filename: Override filename (optional).
            append: For list attributes, append (True) or replace entire list (False).
            is_list: Force list mode (True) for list attributes on new/empty entities.
                     If None, auto-detects from current value in DB.
            api_key: Optional API key for RBAC.

        Returns:
            The FileReference that was saved.

        Example:
            >>> # Single image attribute
            >>> ref = org.files.attach(partner_uuid, "channel_partner", "logo", "logo.png")

            >>> # Gallery (list) attribute — appends by default
            >>> ref = org.files.attach(proj_uuid, "real_estate_project", "project_photos", "render.jpg")

            >>> # First image on a new entity with empty list — pass is_list=True
            >>> ref = org.files.attach(proj_uuid, "real_estate_project", "project_photos",
            ...                        "render.jpg", is_list=True)

            >>> # Document
            >>> ref = org.files.attach(proj_uuid, "real_estate_project", "brochure", "brochure.pdf")
        """
        # Step 1: Upload → FileReference
        ref = self.upload(file, filename=filename, api_key=api_key)

        # Step 2: Save reference into entity via CRUD
        try:
            self._save_ref_to_entity(
                obj_uuid, obj_type, attribute, ref,
                append=append, is_list=is_list, api_key=api_key,
            )
        except Exception as e:
            # If CRUD fails, clean up the uploaded file
            self.logger.warning(
                f"CRUD update failed after upload, cleaning up file {ref.file_id}: {e}"
            )
            try:
                self.delete(ref.file_id, api_key=api_key)
            except Exception:
                pass
            raise

        self.logger.info(
            f"Attached {ref.filename} → {obj_type}/{obj_uuid}.{attribute}"
        )
        return ref

    def attach_batch(
        self,
        obj_uuid: str,
        obj_type: str,
        attribute: str,
        files: List[FileLike],
        *,
        append: bool = True,
        api_key: Optional[str] = None,
    ) -> BatchUploadResult:
        """
        Upload multiple files AND save all references into a list attribute.

        Args:
            obj_uuid: UUID of the target entity.
            obj_type: Schema type name.
            attribute: List attribute name (must have ``list: true``).
            files: List of files to upload.
            append: Append to existing list (True) or replace (False).
            api_key: Optional API key for RBAC.

        Returns:
            BatchUploadResult with all FileReferences.

        Example:
            >>> result = org.files.attach_batch(
            ...     proj_uuid, "real_estate_project", "project_photos",
            ...     ["render1.jpg", "render2.jpg", "render3.jpg"]
            ... )
            >>> print(f"Attached {result.succeeded} photos")
        """
        # Step 1: Batch upload
        result = self.upload_batch(files, api_key=api_key)

        if not result.files:
            return result

        # Step 2: Save all references into entity
        try:
            self._save_refs_to_entity(
                obj_uuid, obj_type, attribute, result.files,
                append=append, api_key=api_key,
            )
        except Exception as e:
            self.logger.warning(
                f"CRUD update failed after batch upload: {e}. "
                f"Files uploaded but not linked to entity."
            )
            raise

        self.logger.info(
            f"Attached {result.succeeded} files → {obj_type}/{obj_uuid}.{attribute}"
        )
        return result

    def detach(
        self,
        obj_uuid: str,
        obj_type: str,
        attribute: str,
        file_id: str,
        *,
        delete_binary: bool = True,
        api_key: Optional[str] = None,
    ) -> bool:
        """
        Remove a file from an entity AND optionally delete the binary.

        Follows Appendix F.4 ordering:
          Step 1: Delete binary from file storage
          Step 2: Remove FileReference from entity via CRUD

        Args:
            obj_uuid: UUID of the entity.
            obj_type: Schema type name.
            attribute: Attribute name.
            file_id: File ID to remove.
            delete_binary: Also delete from file storage (default True).
            api_key: Optional API key for RBAC.

        Returns:
            True if succeeded.

        Example:
            >>> org.files.detach(proj_uuid, "real_estate_project", "project_photos", "img_a7bX9kLmNp3q")
        """
        # Step 1: Delete binary from storage (Appendix F.4 ordering)
        if delete_binary:
            try:
                self.delete(file_id, api_key=api_key)
            except Exception as e:
                self.logger.warning(
                    f"Binary delete failed for {file_id}: {e}. "
                    f"Proceeding to remove reference anyway."
                )

        # Step 2: Remove reference from entity
        self._remove_ref_from_entity(
            obj_uuid, obj_type, attribute, file_id, api_key=api_key,
        )

        self.logger.info(
            f"Detached {file_id} from {obj_type}/{obj_uuid}.{attribute}"
        )
        return True

    def replace_attached(
        self,
        obj_uuid: str,
        obj_type: str,
        attribute: str,
        file_id: str,
        new_file: FileLike,
        *,
        filename: Optional[str] = None,
        api_key: Optional[str] = None,
    ) -> FileReference:
        """
        Replace a file binary AND update the entity reference in one call.

        Same file_id and URL — but size/dimensions/filename may change.

        Args:
            obj_uuid: UUID of the entity.
            obj_type: Schema type name.
            attribute: Attribute name.
            file_id: File ID to replace.
            new_file: New file content.
            filename: Override filename (optional).
            api_key: Optional API key for RBAC.

        Returns:
            Updated FileReference.

        Example:
            >>> updated = org.files.replace_attached(
            ...     proj_uuid, "real_estate_project", "project_photos",
            ...     "img_a7bX9kLmNp3q", "better-render.jpg"
            ... )
        """
        # Step 1: Replace binary
        updated_ref = self.replace(file_id, new_file, filename=filename, api_key=api_key)

        # Step 2: Update reference in entity (metadata may have changed)
        try:
            self._update_ref_in_entity(
                obj_uuid, obj_type, attribute, updated_ref, api_key=api_key,
            )
        except Exception as e:
            self.logger.warning(
                f"Binary replaced but entity update failed for {file_id}: {e}"
            )
            raise

        self.logger.info(
            f"Replaced {file_id} on {obj_type}/{obj_uuid}.{attribute}"
        )
        return updated_ref

    # ==================================================================
    # Internal: CRUD operations on entity attributes
    # ==================================================================

    def _get_entity(
        self, obj_uuid: str, obj_type: str, api_key: Optional[str] = None
    ) -> Dict[str, Any]:
        """Fetch entity via CRUD."""
        endpoint = self._crud_endpoint(obj_type, obj_uuid)
        return self._org._platform_client.get(
            endpoint,
            extra_headers=self._auth_headers(api_key),
        )

    def _update_entity(
        self,
        obj_uuid: str,
        obj_type: str,
        patch: Dict[str, Any],
        api_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Patch entity via CRUD PUT."""
        endpoint = self._crud_endpoint(obj_type, obj_uuid)
        return self._org._platform_client.put(
            endpoint,
            json=patch,
            extra_headers=self._auth_headers(api_key),
        )

    def _save_ref_to_entity(
        self,
        obj_uuid: str,
        obj_type: str,
        attribute: str,
        ref: FileReference,
        *,
        append: bool = True,
        is_list: Optional[bool] = None,
        api_key: Optional[str] = None,
    ):
        """
        Save a single FileReference into an entity attribute.

        Args:
            is_list: Force list mode. If None, auto-detects from current value.
                     Pass True for ``list: true`` attributes when the entity
                     is new and the current value is None/missing.
        """
        entity = self._get_entity(obj_uuid, obj_type, api_key=api_key)
        current = entity.get(attribute)

        # Determine if this is a list attribute:
        #   1. Explicit caller hint (most reliable)
        #   2. Current value is already a list
        #   3. Current value is None but caller said append → treat as list
        treat_as_list = is_list if is_list is not None else isinstance(current, list)

        if treat_as_list:
            existing = current if isinstance(current, list) else []
            if append:
                new_value = existing + [dict(ref)]
            else:
                new_value = [dict(ref)]
        else:
            # Single-value attribute
            new_value = dict(ref)

        self._update_entity(obj_uuid, obj_type, {attribute: new_value}, api_key=api_key)

    def _save_refs_to_entity(
        self,
        obj_uuid: str,
        obj_type: str,
        attribute: str,
        refs: List[FileReference],
        *,
        append: bool = True,
        api_key: Optional[str] = None,
    ):
        """Save multiple FileReferences into a list attribute."""
        entity = self._get_entity(obj_uuid, obj_type, api_key=api_key)
        current = entity.get(attribute) or []

        if not isinstance(current, list):
            current = [current] if current else []

        if append:
            new_value = current + [dict(r) for r in refs]
        else:
            new_value = [dict(r) for r in refs]

        self._update_entity(obj_uuid, obj_type, {attribute: new_value}, api_key=api_key)

    def _remove_ref_from_entity(
        self,
        obj_uuid: str,
        obj_type: str,
        attribute: str,
        file_id: str,
        *,
        api_key: Optional[str] = None,
    ):
        """Remove a FileReference from an entity attribute by file_id."""
        entity = self._get_entity(obj_uuid, obj_type, api_key=api_key)
        current = entity.get(attribute)

        if isinstance(current, list):
            # Filter out the matching file_id
            new_value = [
                item for item in current
                if item.get("file_id") != file_id
            ]
        elif isinstance(current, dict) and current.get("file_id") == file_id:
            # Single attribute — set to None
            new_value = None
        else:
            self.logger.warning(
                f"file_id {file_id} not found in {obj_type}/{obj_uuid}.{attribute}"
            )
            return

        self._update_entity(obj_uuid, obj_type, {attribute: new_value}, api_key=api_key)

    def _update_ref_in_entity(
        self,
        obj_uuid: str,
        obj_type: str,
        attribute: str,
        updated_ref: FileReference,
        *,
        api_key: Optional[str] = None,
    ):
        """Update an existing FileReference in an entity (after replace)."""
        entity = self._get_entity(obj_uuid, obj_type, api_key=api_key)
        current = entity.get(attribute)

        if isinstance(current, list):
            # Replace the matching entry in the list
            new_value = [
                dict(updated_ref) if item.get("file_id") == updated_ref.file_id else item
                for item in current
            ]
        elif isinstance(current, dict):
            # Single attribute
            new_value = dict(updated_ref)
        else:
            new_value = dict(updated_ref)

        self._update_entity(obj_uuid, obj_type, {attribute: new_value}, api_key=api_key)


# ---------------------------------------------------------------------------
# Object-level mixin methods (injected by core.py onto schema instances)
# ---------------------------------------------------------------------------

def _make_attach_method(supero: 'Supero', instance: Any):
    """
    Create a bound .attach() method for a schema instance.

    Injected by core.py's _inject_child_methods_auto() or similar.
    """
    def attach(
        attribute: str,
        file: FileLike,
        *,
        filename: Optional[str] = None,
        append: bool = True,
        is_list: Optional[bool] = None,
        api_key: Optional[str] = None,
    ) -> FileReference:
        """
        Upload and attach a file to this object.

        Args:
            attribute: Attribute name (e.g. "project_photos", "logo", "brochure")
            file: File path, open file, or bytes
            filename: Override filename (optional)
            append: For list attributes, append (True) or replace (False)
            is_list: Force list mode for empty list attributes on new entities
            api_key: Optional API key for RBAC

        Returns:
            FileReference of the uploaded file

        Example:
            >>> project.attach("project_photos", "render.jpg")
            >>> project.attach("brochure", open("brochure.pdf", "rb"))
            >>> project.attach("logo", "new-logo.png")
        """
        obj_uuid = getattr(instance, "uuid", None)
        obj_type = getattr(instance, "obj_type", None)
        if not obj_uuid or not obj_type:
            raise ValueError("Object must have uuid and obj_type to attach files")

        return supero.files.attach(
            obj_uuid, obj_type, attribute, file,
            filename=filename, append=append, is_list=is_list, api_key=api_key,
        )

    return attach


def _make_detach_method(supero: 'Supero', instance: Any):
    """Create a bound .detach() method for a schema instance."""
    def detach(
        attribute: str,
        file_id: str,
        *,
        delete_binary: bool = True,
        api_key: Optional[str] = None,
    ) -> bool:
        """
        Remove a file from this object (and optionally delete the binary).

        Args:
            attribute: Attribute name
            file_id: File ID to remove
            delete_binary: Also delete from storage (default True)
            api_key: Optional API key for RBAC

        Returns:
            True if succeeded

        Example:
            >>> project.detach("project_photos", "img_a7bX9kLmNp3q")
        """
        obj_uuid = getattr(instance, "uuid", None)
        obj_type = getattr(instance, "obj_type", None)
        if not obj_uuid or not obj_type:
            raise ValueError("Object must have uuid and obj_type to detach files")

        return supero.files.detach(
            obj_uuid, obj_type, attribute, file_id,
            delete_binary=delete_binary, api_key=api_key,
        )

    return detach


def _make_replace_file_method(supero: 'Supero', instance: Any):
    """Create a bound .replace_file() method for a schema instance."""
    def replace_file(
        attribute: str,
        file_id: str,
        new_file: FileLike,
        *,
        filename: Optional[str] = None,
        api_key: Optional[str] = None,
    ) -> FileReference:
        """
        Replace a file's binary and update the reference on this object.

        Args:
            attribute: Attribute name
            file_id: File ID to replace
            new_file: New file content
            filename: Override filename (optional)
            api_key: Optional API key for RBAC

        Returns:
            Updated FileReference

        Example:
            >>> project.replace_file("logo", "img_abc123", "better-logo.png")
        """
        obj_uuid = getattr(instance, "uuid", None)
        obj_type = getattr(instance, "obj_type", None)
        if not obj_uuid or not obj_type:
            raise ValueError("Object must have uuid and obj_type to replace files")

        return supero.files.replace_attached(
            obj_uuid, obj_type, attribute, file_id, new_file,
            filename=filename, api_key=api_key,
        )

    return replace_file


def _make_attach_batch_method(supero: 'Supero', instance: Any):
    """Create a bound .attach_batch() method for a schema instance."""
    def attach_batch(
        attribute: str,
        files: List[FileLike],
        *,
        append: bool = True,
        api_key: Optional[str] = None,
    ) -> 'BatchUploadResult':
        """
        Upload multiple files and attach all to a list attribute.

        Args:
            attribute: List attribute name (e.g. "project_photos")
            files: List of file paths, open files, or bytes
            append: Append to existing list (True) or replace (False)
            api_key: Optional API key for RBAC

        Returns:
            BatchUploadResult with .files and .failed

        Example:
            >>> result = project.attach_batch("project_photos", ["a.jpg", "b.jpg", "c.jpg"])
            >>> print(f"Attached {result.succeeded} photos")
        """
        obj_uuid = getattr(instance, "uuid", None)
        obj_type = getattr(instance, "obj_type", None)
        if not obj_uuid or not obj_type:
            raise ValueError("Object must have uuid and obj_type to attach files")

        return supero.files.attach_batch(
            obj_uuid, obj_type, attribute, files,
            append=append, api_key=api_key,
        )

    return attach_batch


def _make_list_files_method(instance: Any):
    """Create a bound .list_files() method for a schema instance."""
    def list_files(attribute: str) -> List[FileReference]:
        """
        Get all FileReferences for an attribute on this object.

        Args:
            attribute: Attribute name (e.g. "project_photos", "logo")

        Returns:
            List of FileReference dicts (empty list if None/missing).
            For single-value attributes, wraps in a list for uniform handling.

        Example:
            >>> photos = project.list_files("project_photos")
            >>> for photo in photos:
            ...     print(photo.file_id, photo.filename)
        """
        value = getattr(instance, attribute, None)
        if value is None:
            return []
        if isinstance(value, list):
            return [FileReference(v) if not isinstance(v, FileReference) else v for v in value]
        if isinstance(value, dict):
            return [FileReference(value)]
        return []

    return list_files


def inject_file_methods(supero: 'Supero', instance: Any):
    """
    Inject .attach(), .detach(), .replace_file(), .attach_batch(), .list_files()
    onto a schema instance.

    Called from core.py's _inject_child_methods_auto() for any instance
    that has a UUID (i.e., is a saved object).

    Args:
        supero: Parent Supero context
        instance: Schema object instance
    """
    if not hasattr(instance, "uuid") or not getattr(instance, "uuid", None):
        return  # Only inject on saved objects

    if not hasattr(instance, "attach"):
        setattr(instance, "attach", _make_attach_method(supero, instance))

    if not hasattr(instance, "detach"):
        setattr(instance, "detach", _make_detach_method(supero, instance))

    if not hasattr(instance, "replace_file"):
        setattr(instance, "replace_file", _make_replace_file_method(supero, instance))

    if not hasattr(instance, "attach_batch"):
        setattr(instance, "attach_batch", _make_attach_batch_method(supero, instance))

    if not hasattr(instance, "list_files"):
        setattr(instance, "list_files", _make_list_files_method(instance))
