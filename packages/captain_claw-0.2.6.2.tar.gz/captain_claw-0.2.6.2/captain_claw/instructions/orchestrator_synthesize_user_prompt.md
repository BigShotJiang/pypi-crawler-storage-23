Original user request:
{user_input}

Task results:
{task_results}

Synthesis instruction:
{synthesis_instruction}

Based on the task results above, provide a final comprehensive answer to the user's original request. If some tasks failed, note what succeeded and what did not. Be concise but thorough.