Planning mode is ON. Follow this task pipeline and execute step-by-step:
