User request:
{user_input}

Reusable sessions:
{available_sessions}

{workspace_tree}

Decompose into parallel tasks. JSON only.