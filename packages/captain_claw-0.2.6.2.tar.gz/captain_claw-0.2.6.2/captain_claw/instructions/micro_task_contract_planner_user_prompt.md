Create a task contract.

User request:
{user_input}

Recent source URLs:
{recent_source_urls}

Must cover all sources: {require_all_sources}

Extracted list members:
{extracted_list_members}

If must-cover=true, include all URLs in prefetch_urls with coverage requirements.
If list members present, require coverage of each member.

Plan for complete execution. Use nested children for phases. JSON only.