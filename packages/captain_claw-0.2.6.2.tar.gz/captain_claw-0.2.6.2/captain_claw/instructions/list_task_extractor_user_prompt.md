Extract list members and per-member action from this request and context.

User request:
{user_input}

Relevant recent context/content:
{context_excerpt}

Return JSON only.
