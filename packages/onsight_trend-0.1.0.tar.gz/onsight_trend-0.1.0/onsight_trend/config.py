"""
Configuration and default values for onsight_trend.
"""

# Default magnitude categories: {name: (min, max)}
# Values are in units of your parameter (e.g. psi, bar, stb/d, °C).
# Categories are checked in order; first match wins. Use float('inf') for unbounded upper.
DEFAULT_MAGNITUDE_CATEGORIES = {
    "negligible": (0, 10),
    "small": (10, 50),
    "moderate": (50, 150),
    "large": (150, 300),
    "very_large": (300, float("inf")),
}
