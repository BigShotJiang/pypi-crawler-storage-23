"""
onsight_trend - Time-series trend analysis for any parameter.
"""

from .core import analyze_trend, TrendResult
from .config import DEFAULT_MAGNITUDE_CATEGORIES

__version__ = "0.1.0"
__all__ = ["analyze_trend", "TrendResult", "DEFAULT_MAGNITUDE_CATEGORIES"]
