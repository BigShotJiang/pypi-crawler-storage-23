"""Aetherence brigde Module"""
__version__ = "0.1.0"
