"""
Basilisk — LLM/AI Application Red Teaming Framework
The serpent whose gaze breaks minds.

Built by Rot Hackers | Architected by Regaan
https://basilisk.rothackers.com
"""

__version__ = "1.0.5"
__author__ = "Regaan"
__email__ = "support@rothackers.com"
__url__ = "https://github.com/noobforanonymous/basilisk"

BANNER = r"""
  ██████╗  █████╗ ███████╗██╗██╗     ██╗███████╗██╗  ██╗
  ██╔══██╗██╔══██╗██╔════╝██║██║     ██║██╔════╝██║ ██╔╝
  ██████╔╝███████║███████╗██║██║     ██║███████╗█████╔╝
  ██╔══██╗██╔══██║╚════██║██║██║     ██║╚════██║██╔═██╗
  ██████╔╝██║  ██║███████║██║███████╗██║███████║██║  ██╗
  ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝╚══════╝╚═╝╚══════╝╚═╝  ╚═╝
          AI Red Teaming Framework v{}
          Rot Hackers | rothackers.com
""".format(__version__)
