
import { CodeBlock } from "@/components/code-block";
import Link from "next/link";


export default function VersioningPage() {
    return (
        <article className="prose prose-invert max-w-none">
            <div className="not-prose mb-12">
                <h1 className="text-4xl font-bold tracking-tight text-foreground">
                    API Versioning
                </h1>
                <p className="mt-4 text-xl text-muted-foreground leading-relaxed">
                    Enforces semantic versioning on endpoints based on the <code>X-API-Version</code> header using the <code>@version</code> decorator.
                </p>
            </div>

            <section className="mb-12">
                <h2 className="text-2xl font-semibold text-foreground mb-4">Constraint Syntax</h2>
                <p className="text-muted-foreground leading-relaxed mb-4">
                    Supports standard comparison operators: <code>{`>=, <=, >, <, ==, !=`}</code>.
                </p>

                <CodeBlock
                    filename="routes/api.py"
                    language="python"
                    code={`from jec_api.decorators import version

class Api(Route):
    # Available for version 1.0.0 and above
    @version(">=1.0.0")
    async def get(self):
        return {"v": 1}
        
    # Replaced in version 2.0.0
    @version("<2.0.0")
    async def post(self):
        return "Legacy Endpoint"`}
                />

                <div className="mt-8 p-4 rounded-lg bg-card border border-border">
                    <p className="text-muted-foreground">
                        Need strict version enforcement, deprecation headers, or sunset dates? Check the <Link href="/docs/decorators/versioning/advanced" className="text-accent-blue hover:text-accent-blue/80 transition-colors">Advanced Usage</Link> guide.
                    </p>
                </div>
            </section>
        </article>
    );
}
