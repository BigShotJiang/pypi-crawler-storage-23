import os
import json
from PyQt6.QtCore import QObject, pyqtSlot
from Orange.widgets import widget
from Orange.widgets.widget import Input, Output
from Orange.widgets.settings import Setting
from Orange.data import Table
from .web_utils import WebEngineMixin
from .auxiliary_functions import _o2d, _d2o, _bcj, _bfm


class _Br(QObject):
    def __init__(self, _v, _pw):
        super().__init__()
        self._v = _v
        self._pw = _pw
        self._pj = []
        self._ld = False
        self._v.loadFinished.connect(self._ol)

    def _ol(self, ok):
        if ok:
            self._ld = True
            for _j in self._pj:
                self._v.page().runJavaScript(_j)
            self._pj.clear()

    def _rj(self, _j):
        if self._ld:
            self._v.page().runJavaScript(_j)
        else:
            self._pj.append(_j)

    def _sc(self, _d):
        self._rj(f"window.updateColumnDefinitions&&updateColumnDefinitions({_d});")

    def _rs(self, _s):
        self._rj(f"window.restoreFilterState&&restoreFilterState({_s});")

    def _sn(self):
        self._rj("window.showNoDataMessage&&showNoDataMessage();")

    @pyqtSlot(str)
    def filterChanged(self, _s):
        try:
            _st = json.loads(_s)
            if _st.get("_action") == "react_ready":
                if self._pw._id is not None:
                    self._sc(self._pw._cj())
                    self._rs(self._pw.filter_state)
                else:
                    self._sn()
                return
            self._pw._ofc(_s)
        except Exception:
            import traceback

            traceback.print_exc()


class OWAdvancedFilter(WebEngineMixin, widget.OWWidget):
    name = "Filter Builder"
    description = "Advanced AND/OR filtering with full type preservation"
    category = "Altera Data Suite"
    icon = "icons/filter.svg"
    priority = 20

    class Inputs:
        data = Input("Input Table", Table)

    class Outputs:
        filtered_data = Output("Filtered Data", Table)

    filter_state = Setting('{"groups":[]}')
    want_main_area = True
    want_control_area = False
    resizing_enabled = True

    class Error(widget.OWWidget.Error):
        invalid_columns = widget.Msg("Invalid columns in filter: {}")
        license_error = widget.Msg("License error: {}")

    def __init__(self):
        super().__init__()
        self._id = None
        self._od = None
        self._df = None
        self._ic = []
        _h = os.path.join(os.path.dirname(__file__), "UI", "filter_ui", "index.html")
        self.setup_webengine_lazy(_h, _Br, zoom_factor=0.9)

    def on_webengine_ready(self):
        if self._id is not None:
            self.bridge._sc(self._cj())
            self._rfs()
        else:
            self.bridge._sn()

    def on_webengine_show(self):
        pass

    @Inputs.data
    def set_data(self, data):
        self.Error.clear()
        if data is None:
            self._id = None
            self._df = None
            self._od = None
            self.Outputs.filtered_data.send(None)
            if self.web_loaded and self.bridge:
                self.bridge._sn()
            return
        self._id = data
        self._od = data.domain
        self._df = _o2d(data)
        self._af()
        if self.web_loaded and self.bridge:
            self.bridge._sc(self._cj())
            self._rfs()

    def _cj(self):
        return _bcj(self._od, self._df)

    def _rfs(self):
        try:
            _st = json.loads(self.filter_state)
            _cs = set(self._df.columns)
            self._ic = [
                c["column"]
                for g in _st.get("groups", [])
                for c in g.get("conditions", [])
                if c.get("column") not in _cs
            ]
            if self._ic:
                self.Error.invalid_columns(", ".join(self._ic))
            else:
                self.Error.clear()
            self.bridge._rs(self.filter_state)
        except Exception:
            self.filter_state = '{"groups":[]}'

    @pyqtSlot(str)
    def _ofc(self, _s):
        self.filter_state = _s
        self._af()

    def _af(self):
        if self._df is None:
            self.Outputs.filtered_data.send(None)
            return
        try:
            _st = json.loads(self.filter_state)
            if not _st.get("groups"):
                self.Error.clear()
                self.Outputs.filtered_data.send(self._id)
                return
            _mk = _bfm(self._df, self.filter_state, self._ic, self._od)
            self.Error.clear()
            self.Outputs.filtered_data.send(_d2o(self._df[_mk], self._od))
        except RuntimeError as _e:
            self.Error.license_error(str(_e))
            self.Outputs.filtered_data.send(None)
        except Exception as _e:
            print("Filter apply error:", _e)
            self.Outputs.filtered_data.send(None)
