import os
import base64
import tempfile
import json
from PyQt6.QtCore import QUrl, QObject, QThread, pyqtSignal, Qt, pyqtSlot
from PyQt6.QtWebChannel import QWebChannel
from PyQt6.QtWidgets import QLabel, QVBoxLayout
from PyQt6.QtWebEngineWidgets import QWebEngineView
from Orange.widgets.gui import ProgressBar
from Orange.widgets.widget import OWWidget, Output, Msg
from Orange.widgets.settings import Setting
from Orange.data import Table
from .auxiliary_functions import _f0, _f1, _f2, _f3, _f4


class _OW(QObject):
    finished = pyqtSignal(str)
    error = pyqtSignal(str)
    progress = pyqtSignal(int)

    def __init__(self, pdf_path, opacity, zoom):
        super().__init__()
        self.pdf_path = pdf_path
        self.opacity = opacity
        self.zoom = zoom

    def run(self):
        try:
            _op = os.path.join(tempfile.gettempdir(), "pdf_ink_overlay.png")
            _f0(
                self.pdf_path,
                _op,
                zoom=self.zoom,
                opacity=self.opacity,
                white_threshold=150,
                ink_color=(0, 0, 0),
                progress_cb=lambda c, t: self.progress.emit(int((c / t) * 100)),
            )
            with open(_op, "rb") as f:
                _d = base64.b64encode(f.read()).decode("utf-8")
            self.finished.emit(f"data:image/png;base64,{_d}")
        except Exception as e:
            self.error.emit(str(e))


class _CW(QObject):
    progress = pyqtSignal(int)
    message = pyqtSignal(str)
    finished = pyqtSignal(object)
    error = pyqtSignal(str)

    def __init__(self, file_path, tables_info, total_pages, dpi):
        super().__init__()
        self.file_path = file_path
        self.tables_info = tables_info
        self.total_pages = total_pages
        self.dpi = dpi

    def run(self):
        try:

            def _pcb(c, t):
                self.progress.emit(int((c / t) * 100))
                self.message.emit(f"Processing page {c} / {t}")

            self.finished.emit(
                _f1(self.file_path, self.tables_info, self.total_pages, self.dpi, _pcb)
            )
        except Exception as e:
            self.error.emit(str(e))


class _Br(QObject):
    def __init__(self, view, parent_widget):
        super().__init__()
        self.view = view
        self.parent_widget = parent_widget
        self.dpi = 150

    @pyqtSlot(str, str)
    def receivePdfData(self, filename, base64_data):
        try:
            _pb = base64.b64decode(base64_data)
            _sf = "".join(c for c in filename if c.isalnum() or c in ("_", "-", "."))
            _tp = os.path.join(tempfile.gettempdir(), f"pdf_converter_{_sf}")
            with open(_tp, "wb") as f:
                f.write(_pb)
            self.parent_widget.file_path = _tp
            self.parent_widget.steps = _f4(_tp)
        except Exception:
            pass

    @pyqtSlot(str)
    def setPdfPath(self, pdf_path):
        self.parent_widget.file_path = pdf_path
        self.parent_widget.steps = _f4(pdf_path)

    @pyqtSlot(str)
    def saveHtmlState(self, html_delimiters):
        try:
            self.parent_widget.ui_state = json.loads(html_delimiters)
        except Exception:
            self.parent_widget.ui_state = {"rectangles": [], "guides": []}

    @pyqtSlot(str, int)
    def getCoordinatesFromJs(self, data, breaklines=1):
        if not self.parent_widget.file_path:
            self.view.page().runJavaScript(
                "alert('Error: No PDF loaded. Please load a PDF first.')"
            )
            return
        if not os.path.exists(self.parent_widget.file_path):
            self.view.page().runJavaScript("alert('Error: PDF file not found.')")
            return
        try:
            _ti = json.loads(data)
        except Exception as e:
            self.view.page().runJavaScript(
                f"alert('Error parsing coordinates: {str(e)}')"
            )
            return
        self.parent_widget.tables_info_ui = _ti
        self.parent_widget.break_lines = breaklines
        self.closeWidget()
        self.parent_widget.process_tables(_ti)

    @pyqtSlot()
    def closeWidget(self):
        self.parent_widget.close()

    @pyqtSlot()
    def openFileDialog(self):
        from PyQt6.QtWidgets import QFileDialog

        _fp, _ = QFileDialog.getOpenFileName(
            self.view, "Open PDF File", "", "PDF Files (*.pdf)"
        )
        if _fp:
            self.parent_widget.file_path = _fp
            self.parent_widget.steps = _f4(_fp)
            _sp = _fp.replace("\\", "\\\\").replace("'", "\\'")
            self.view.page().runJavaScript(
                f"if(window.loadPdfFromPath){{window.loadPdfFromPath('{_sp}');}}"
            )

    @pyqtSlot(str, float, float)
    def generateInkOverlay(self, pdf_path, opacity=0.3, zoom=2.0):
        self.overlay_thread = QThread()
        self.overlay_worker = _OW(pdf_path, opacity, zoom)
        self.overlay_worker.moveToThread(self.overlay_thread)
        self.overlay_thread.started.connect(self.overlay_worker.run)

        def _of(d):
            self.view.page().runJavaScript(
                f"if(window.setInkOverlay){{window.setInkOverlay('{d}');}}"
            )
            self.overlay_thread.quit()
            self.overlay_thread.wait()

        def _oe(msg):
            self.view.page().runJavaScript(
                "if(window.setInkOverlayError){window.setInkOverlayError();}"
            )
            self.view.page().runJavaScript(
                f"alert('Failed to generate overlay: {msg}');"
            )
            self.overlay_thread.quit()
            self.overlay_thread.wait()

        def _op(pct):
            self.view.page().runJavaScript(
                f"if(window.setOverlayProgress){{window.setOverlayProgress({pct});}}"
            )

        self.overlay_worker.finished.connect(_of)
        self.overlay_worker.progress.connect(_op)
        self.overlay_worker.error.connect(_oe)
        self.overlay_worker.finished.connect(self.overlay_worker.deleteLater)
        self.overlay_worker.error.connect(self.overlay_worker.deleteLater)
        self.overlay_thread.finished.connect(self.overlay_thread.deleteLater)
        self.overlay_thread.start()


class PdfConverter(OWWidget):
    name = "PDF Converter"
    description = "Interactively extract tables from PDF documents by visually selecting table areas and column delimiters."
    category = "Altera Data Suite"
    icon = "icons/pdf_converter.svg"
    want_main_area = True
    want_control_area = False
    priority = 1

    class Outputs:
        data = Output("Data", Table)

    file_path: str = Setting("", schema_only=True)
    break_lines: int = Setting(1, schema_only=True)
    ui_state: dict = Setting({"rectangles": [], "guides": []}, schema_only=True)
    tables_info_ui: list = Setting([], schema_only=True)

    class Error(OWWidget.Error):
        invalid_path = Msg("File path is invalid, File was not found.")
        processing_failed = Msg("Processing failed: {}")
        path_is_not_file = Msg("File path is not a PDF file.")

    class Warning(OWWidget.Warning):
        empty_input = Msg("No input data")
        partial_data = Msg("Some data is missing")

    class Information(OWWidget.Information):
        data_loaded = Msg("Data successfully loaded")
        processing_complete = Msg("Processing complete")

    def __init__(self):
        super().__init__()
        self.extracted_tables = []
        self.steps = 0
        self.pb = None
        self.counter = 0
        self._iu()

    def _iu(self):
        _l = QVBoxLayout()
        self.status_label = QLabel("Ready")
        _l.addWidget(self.status_label)
        self._swe()
        self.mainArea.layout().addWidget(self.view)

    def _swe(self):
        self.view = QWebEngineView()
        self.view.setContextMenuPolicy(Qt.ContextMenuPolicy.NoContextMenu)
        self.channel = QWebChannel()
        self.bridge = _Br(self.view, self)
        self.channel.registerObject("bridge", self.bridge)
        self.view.page().setWebChannel(self.channel)
        _hp = os.path.join(
            os.path.dirname(__file__), "UI", "pdf_converter_gui", "index.html"
        )
        if os.path.exists(_hp):
            self.view.setUrl(QUrl.fromLocalFile(_hp))
        self.view.loadFinished.connect(self._opl)

    def _opl(self, ok):
        if not ok:
            return
        if self.file_path and os.path.exists(self.file_path):
            self.steps = _f4(self.file_path)
            _sp = self.file_path.replace("\\", "\\\\").replace("'", "\\'")
            self.view.page().runJavaScript(
                f"if(window.loadPdfFromPath){{window.loadPdfFromPath('{_sp}').then(()=>{{{self._grjs()}}}).catch(()=>{{}});}}"
            )
        else:
            if self.ui_state and (
                self.ui_state.get("rectangles") or self.ui_state.get("guides")
            ):
                self.view.page().runJavaScript(self._grjs())

    def _grjs(self):
        if not self.ui_state or (
            not self.ui_state.get("rectangles") and not self.ui_state.get("guides")
        ):
            return ""
        return f"if(window.restoreAnnotations){{window.restoreAnnotations({json.dumps(self.ui_state)});}}"

    def process_tables(self, tables_info):
        from .auxiliary_functions import verify_license

        if not verify_license():
            self.Error.processing_failed(
                "Invalid or expired license. Please contact support to renew."
            )
            return
        self.setBlocking(True)
        if not self.file_path or not os.path.exists(self.file_path) or not tables_info:
            self.setBlocking(False)
            return
        self.pb = ProgressBar(self, iterations=self.steps)
        self.counter = 0
        self.thread = QThread()
        self.worker = _CW(self.file_path, tables_info, self.steps, self.bridge.dpi)
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)

        def _op(pct):
            if self.counter < self.steps:
                self.pb.advance()
                self.counter += 1

        def _of(df):
            self.pb.finish()
            self.setBlocking(False)
            self.view.page().runJavaScript(
                "if(window.showLoaderHandler){window.showLoaderHandler(0);}"
            )
            if df is None:
                return
            self.Outputs.data.send(_f2(df))
            self.Error.clear()
            self.status_label.setText(_f3(self.file_path))

        def _oe(msg):
            self.Error.processing_failed(msg)
            self.setBlocking(False)
            if self.pb:
                self.pb.finish()

        self.worker.progress.connect(_op)
        self.worker.finished.connect(_of)
        self.worker.error.connect(_oe)
        self.worker.finished.connect(self.thread.quit)
        self.worker.finished.connect(self.worker.deleteLater)
        self.worker.error.connect(self.thread.quit)
        self.worker.error.connect(self.worker.deleteLater)
        self.thread.finished.connect(self.thread.deleteLater)
        self.thread.start()

    def onDeleteWidget(self):
        if hasattr(self, "file_path") and self.file_path:
            if "pdf_converter_" in self.file_path and os.path.exists(self.file_path):
                try:
                    os.remove(self.file_path)
                except Exception:
                    pass
        super().onDeleteWidget()
