import traceback
from PyQt6.QtWidgets import QCheckBox
from Orange.data import Table
from Orange.data.pandas_compat import table_to_frame
from Orange.widgets import gui
from Orange.widgets.settings import Setting
from Orange.widgets.widget import Input, Output, OWWidget, Msg
from .auxiliary_functions import _d2os


class OWHStack(OWWidget):
    name = "Horizontal Stack"
    description = (
        "Horizontally stack multiple tables (concatenate columns side-by-side)."
    )
    icon = "icons/hstack.svg"
    category = "Altera Data Suite"
    priority = 10

    class Inputs:
        data = Input("Multiple Tables", Table, multiple=True)

    class Outputs:
        data = Output("Horizontally Stacked Tables", Table)

    class Error(OWWidget.Error):
        row_mismatch = Msg(
            "Input tables have different number of rows. Enable padding to continue."
        )
        processing_error = Msg("Error processing tables: {}")
        license_error = Msg("License error: {}")

    class Warning(OWWidget.Warning):
        padding_applied = Msg(
            "Tables have different row counts. Missing values padded with NaN."
        )

    allow_padding: bool = Setting(True)
    auto_commit: bool = Setting(True)
    want_main_area = False
    resizing_enabled = True

    def __init__(self):
        super().__init__()
        self._itd = {}
        self._it = []
        self.resize(340, 280)
        self._su()

    def _su(self):
        _ob = gui.widgetBox(self.controlArea, "Stacking Options", spacing=12)
        self._pc = QCheckBox("Allow padding for mismatched rows")
        self._pc.setChecked(self.allow_padding)
        self._pc.stateChanged.connect(self._opc)
        _ob.layout().addWidget(self._pc)
        self._ac = QCheckBox("Auto-apply changes")
        self._ac.setChecked(self.auto_commit)
        self._ac.stateChanged.connect(self._oac)
        _ob.layout().addWidget(self._ac)
        self._ab = gui.button(
            _ob,
            self,
            "Apply Stacking",
            callback=self._p,
            autoDefault=True,
            default=True,
        )
        self._ab.setMinimumHeight(35)
        _sb = gui.widgetBox(self.controlArea, "Status", spacing=8)
        self._il = gui.widgetLabel(_sb, "No tables loaded")
        self._il.setWordWrap(True)
        self._dl = gui.widgetLabel(_sb, "")
        self._dl.setWordWrap(True)
        self._uabv()

    def _uabv(self):
        self._ab.setEnabled(not self.auto_commit)

    def _opc(self, state):
        from PyQt6.QtCore import Qt

        self.allow_padding = state == Qt.CheckState.Checked.value
        if self.auto_commit:
            self._p()

    def _oac(self, state):
        from PyQt6.QtCore import Qt

        self.auto_commit = state == Qt.CheckState.Checked.value
        self._uabv()
        if self.auto_commit:
            self._p()

    @Inputs.data
    def set_data(self, data: Table, id=None):
        if data is not None:
            self._itd[id] = data
        else:
            self._itd.pop(id, None)
        self._it = [t for t in self._itd.values() if t is not None]
        self._ui()
        self.clear_messages()
        if len(self._it) >= 2:
            if self.auto_commit:
                self._p()
        else:
            self.Outputs.data.send(None)

    def _ui(self):
        _n = len(self._it)
        if _n == 0:
            self._il.setText("No tables loaded")
            self._dl.setText("")
        elif _n == 1:
            self._il.setText("⚠ Need at least 2 tables")
            _t = self._it[0]
            self._dl.setText(
                f"Loaded: 1 table\n{len(_t)} rows × {len(_t.domain.attributes) + len(_t.domain.metas)} columns"
            )
        else:
            self._il.setText(f"{_n} tables loaded")
            _rc = [len(t) for t in self._it]
            _cc = [len(t.domain.attributes) + len(t.domain.metas) for t in self._it]
            _dt = (
                f"Rows: {', '.join(map(str, _rc))}\nColumns: {', '.join(map(str, _cc))}"
            )
            if len(set(_rc)) > 1:
                _dt += f"\n⚠ Row count mismatch (max: {max(_rc)})"
            self._dl.setText(_dt)

    def _p(self):
        import pandas as pd

        self.clear_messages()
        if len(self._it) < 2:
            self.Outputs.data.send(None)
            return
        try:
            _dfs = [table_to_frame(t, include_metas=True) for t in self._it]
            _rc = [len(d) for d in _dfs]
            if len(set(_rc)) != 1:
                if not self.allow_padding:
                    self.Error.row_mismatch()
                    self.Outputs.data.send(None)
                    return
                self.Warning.padding_applied()
            _cd = pd.concat(_dfs, axis=1, ignore_index=False)
            _rt = _d2os(_cd)
            self.Outputs.data.send(_rt)
            _nr = len(_rt)
            _nc = len(_rt.domain.attributes) + len(_rt.domain.metas)
            self._il.setText(
                f"✔ Stacked {len(self._it)} tables → {_nr} rows × {_nc} cols"
            )
            self._dl.setText(
                f"Input tables:\nRows: {', '.join(map(str, _rc))}\nColumns: {', '.join(map(str, [len(t.domain.attributes) + len(t.domain.metas) for t in self._it]))}"
            )
        except RuntimeError as _e:
            self.Error.license_error(str(_e))
            self.Outputs.data.send(None)
        except Exception as _e:
            traceback.print_exc()
            self.Error.processing_error(str(_e))
            self.Outputs.data.send(None)

    def send_report(self):
        self.report_items(
            [
                ("Number of input tables", len(self._it)),
                ("Allow padding", "Yes" if self.allow_padding else "No"),
                ("Auto-apply", "Yes" if self.auto_commit else "No"),
            ]
        )
