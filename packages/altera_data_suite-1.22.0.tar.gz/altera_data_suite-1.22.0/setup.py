import os
import shutil
from setuptools import setup, find_namespace_packages
from setuptools.dist import Distribution


# Delete all __pycache__ dirs before discovery so setuptools never sees them
for root, dirs, files in os.walk("."):
    for d in dirs:
        if d == "__pycache__":
            shutil.rmtree(os.path.join(root, d))


class BinaryDistribution(Distribution):
    def has_ext_modules(self):
        return True


setup(
    name="altera-data-suite",
    version="1.22.0",
    author="Mehdi Benrabiaa",
    packages=find_namespace_packages(include=["orangecontrib", "orangecontrib.*"]),
    distclass=BinaryDistribution,
    package_data={
        "orangecontrib.custom.widgets": [
            "icons/*.svg",
            "icons/*.png",
            "UI/*",
            "UI/*/*",
            "UI/*/*/*",
            "web_UI/*",
            "web_UI/*/*",
            "web_UI/*/*/*",
            "*.pyd",
        ]
    },
    include_package_data=True,
    install_requires=[
        "orange3",
        "PyQt6>=6.0,<6.9",
        "PyQt6-WebEngine>=6.0,<6.9",
        "pandas",
        "numpy",
        "keyring",
        "requests",
        "pymupdf",
        "camelot-py",
        "pypdfium2",
        "Pillow",
    ],
    entry_points={
        "orange3.addon": ("altera_data_suite = orangecontrib.custom",),
        "orange.widgets": ("Altera Data Suite = orangecontrib.custom.widgets",),
    },
    python_requires=">=3.10",
)
