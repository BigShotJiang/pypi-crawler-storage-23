from snaptrade_client.paths.market_data_options_quotes.get import ApiForget


class MarketDataOptionsQuotes(
    ApiForget,
):
    pass
