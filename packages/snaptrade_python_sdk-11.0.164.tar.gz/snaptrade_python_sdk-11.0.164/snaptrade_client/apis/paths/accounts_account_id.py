from snaptrade_client.paths.accounts_account_id.get import ApiForget
from snaptrade_client.paths.accounts_account_id.put import ApiForput


class AccountsAccountId(
    ApiForget,
    ApiForput,
):
    pass
