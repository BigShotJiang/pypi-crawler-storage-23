from snaptrade_client.paths.brokerages.get import ApiForget


class Brokerages(
    ApiForget,
):
    pass
