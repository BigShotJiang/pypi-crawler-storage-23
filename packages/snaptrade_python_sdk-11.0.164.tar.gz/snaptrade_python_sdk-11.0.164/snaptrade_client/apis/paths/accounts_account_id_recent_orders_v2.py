from snaptrade_client.paths.accounts_account_id_recent_orders_v2.get import ApiForget


class AccountsAccountIdRecentOrdersV2(
    ApiForget,
):
    pass
