from snaptrade_client.paths.accounts_account_id_options.get import ApiForget


class AccountsAccountIdOptions(
    ApiForget,
):
    pass
