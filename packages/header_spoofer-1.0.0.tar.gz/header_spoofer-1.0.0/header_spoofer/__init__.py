from .spoofer import HeaderSpoofer, BrowserProfile, HeaderSpoofer

__all__ = ["HeaderSpoofer", "BrowserProfile"]