# header-spoofer

Discord browser fingerprint and header spoofing library.

## Install
pip install header-spoofer

## Usage
from header_spoofer import HeaderSpoofer

spoofer = HeaderSpoofer("your_token_here")
headers = spoofer.get_headers()