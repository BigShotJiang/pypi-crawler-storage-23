def plotHoughCircles(img,detected_circles):
    """
    Affiche les cercles détectés par transformée de Hough
    sur l'image correspondante.

    Parameters
    ----------
    IMG : numpy.ndarray
        Image 2D.

    DETECTED_CIRCLES : numpy.ndarray
        Sortie de la fonction cv2.HoughCircles.

    Returns
    -------
    fig : plotly.graph_objects.Figure
        Figure contenant l'image et les cercles détectés.
"""
    import numpy as np
    from plotly import express as px
     
    if detected_circles is not None: 
        print("# circles detected:", detected_circles.shape[1])
        
        theta = np.append(np.arange(0,2*np.pi,2*np.pi/100).reshape(1,-1) , [np.nan])
        cx, cy, r = detected_circles[:,:,0], detected_circles[:,:,1], detected_circles[:,:,2] 
            
        x = r.T * np.cos(theta) + cx.T
        x = x.reshape(x.size)

        y = r.T * np.sin(theta) + cy.T
        y = y.reshape(y.size)

        # plot circles on top of the image
        fig = px.imshow(img, binary_string=True)
        fig.add_trace(px.line(x=x,y=y).data[0])
        
    else:
        print ('no circle detected')
        
        # plot image
        fig = px.imshow(img, binary_string=True)
    
    return fig
