import numpy as np
import torch
from skimage.metrics import structural_similarity

def mse(I,ref):
    """ Calcule la MSE

    Parameters
    ----------
    I : (numpy.ndarray)               
        signal 1D OU image NON vectorisée 2D dégradé(e)
    
    ref : (numpy.ndarray)               
        vérité terrain (signal 1D OU image NON vectorisée 2D)

    
    Returns
    -------
    : (float)
        Valeur de MSE
    """

    return np.round(np.sum((I-ref)**2)/I.size,5)

def snr(I,ref):
    """ Calcule le SNR

    Parameters
    ----------
    I : (numpy.ndarray)               
        signal 1D OU image NON vectorisée 2D dégradé(e)
    
    ref : (numpy.ndarray)               
        vérité terrain (signal 1D OU image NON vectorisée 2D)

    
    Returns
    -------
    : (float)
        Valeur de SNR
    """
    return np.round(10* np.log10(np.sum(ref**2)/np.sum((I-ref)**2)),2)

def ssim(I,ref):
    """ Calcule le SSIM

    Parameters
    ----------
    I : (numpy.ndarray)               
        signal 1D OU image NON vectorisée 2D dégradé(e)
    
    ref : (numpy.ndarray)               
        vérité terrain (signal 1D OU image NON vectorisée 2D)

    
    Returns
    -------
    : (float)
        Valeur de SSIM
    """

    return np.round(structural_similarity(ref, I, data_range=ref.max() - ref.min()),3)

