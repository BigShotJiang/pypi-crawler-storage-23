"""Configuration for the standalone healthcheck agent."""

from __future__ import annotations

import os


# Anthropic API
ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
MODEL = os.environ.get("HEALTHCHECK_MODEL", "claude-sonnet-4-5-20250929")
MAX_TOKENS = 4096

# Agent behavior
MAX_TURNS = 50  # Maximum agent loop iterations
INTERACTIVE_MODE = True  # Whether to prompt user for manual questions
OUTPUT_DIR = os.environ.get("HEALTHCHECK_OUTPUT_DIR", "./output")

# Qualys (inherited from environment)
QUALYS_USERNAME = os.environ.get("QUALYS_USERNAME", "")
QUALYS_PASSWORD = os.environ.get("QUALYS_PASSWORD", "")
QUALYS_BASE_URL = os.environ.get("QUALYS_BASE_URL", "")
QUALYS_GATEWAY_URL = os.environ.get("QUALYS_GATEWAY_URL", "")
