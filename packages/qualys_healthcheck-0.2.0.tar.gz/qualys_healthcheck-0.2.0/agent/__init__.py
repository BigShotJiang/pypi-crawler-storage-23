"""Standalone agent for Qualys VMDR healthcheck."""
