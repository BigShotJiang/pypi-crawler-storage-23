"""Standalone agent orchestrator using the Anthropic Claude API.

Runs a tool-use loop that conducts the healthcheck interactively,
collecting data, asking manual questions, and generating reports.

Usage:
    python -m agent.orchestrator [--customer "Customer Name"] [--non-interactive]
"""

from __future__ import annotations

import argparse
import json
import sys

try:
    import anthropic
except ImportError:
    print("Error: anthropic package required. Install with: pip install 'qualys-healthcheck[agent]'")
    sys.exit(1)

from . import config, prompts
from healthcheck.evaluator import HealthcheckEvaluator
from healthcheck.scoring import compute_overall_score, format_score_summary
from healthcheck.interactive import get_pending_questions
from healthcheck.models import Score
from healthcheck.questions import QUESTIONS


# Shared evaluator
_evaluator = HealthcheckEvaluator()


def _tool_evaluate_all(customer_name: str = "") -> str:
    """Tool implementation: run full evaluation."""
    global _evaluator
    _evaluator = HealthcheckEvaluator()
    if customer_name:
        _evaluator.state.customer_name = customer_name

    _evaluator.evaluate_all()
    overall = compute_overall_score(_evaluator.state.results)
    summary = format_score_summary(overall)
    pending = get_pending_questions(_evaluator.state.results)

    result = {
        "overall_score": overall.overall_percentage,
        "overall_grade": overall.overall_grade.value,
        "evaluated": overall.evaluated_count,
        "total": overall.total_questions,
        "passed": overall.passed_count,
        "failed": overall.failed_count,
        "pending_manual": len(pending),
        "pending_questions": [
            {"id": p["id"], "question": p["question"]} for p in pending
        ],
        "summary": summary,
    }
    return json.dumps(result, indent=2)


def _tool_submit_manual(question_id: str, compliant: bool, notes: str = "") -> str:
    """Tool implementation: submit manual answer."""
    if question_id not in QUESTIONS:
        return json.dumps({"error": f"Unknown question: {question_id}"})

    _evaluator.submit_manual_answer(question_id, compliant, notes)
    overall = compute_overall_score(_evaluator.state.results)
    pending = get_pending_questions(_evaluator.state.results)

    return json.dumps({
        "recorded": question_id,
        "compliant": compliant,
        "overall_score": overall.overall_percentage,
        "overall_grade": overall.overall_grade.value,
        "remaining_manual": len(pending),
    })


def _tool_generate_report(
    format: str = "both", output_dir: str = "./output", customer_name: str = ""
) -> str:
    """Tool implementation: generate reports."""
    if customer_name:
        _evaluator.state.customer_name = customer_name

    if not _evaluator.state.results:
        return json.dumps({"error": "No results. Run evaluate_all first."})

    overall = compute_overall_score(_evaluator.state.results)
    files = {}

    if format in ("pptx", "both"):
        try:
            from reports.pptx_report import generate_pptx
            files["pptx"] = generate_pptx(_evaluator.state, overall, output_dir)
        except Exception as e:
            files["pptx_error"] = str(e)

    if format in ("html", "both"):
        try:
            from reports.html_report import generate_html
            files["html"] = generate_html(_evaluator.state, overall, output_dir)
        except Exception as e:
            files["html_error"] = str(e)

    return json.dumps({
        "files": files,
        "overall_score": overall.overall_percentage,
        "overall_grade": overall.overall_grade.value,
    })


# Tool definitions for Claude API
TOOLS = [
    {
        "name": "evaluate_all",
        "description": (
            "Run the complete 44-question VMDR healthcheck assessment. "
            "Collects API data, auto-scores questions, flags manual ones."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "customer_name": {
                    "type": "string",
                    "description": "Customer name for the report.",
                }
            },
        },
    },
    {
        "name": "submit_manual_answer",
        "description": "Record a manual answer for a healthcheck question.",
        "input_schema": {
            "type": "object",
            "properties": {
                "question_id": {
                    "type": "string",
                    "description": "Question ID (e.g. AUTH-07, TRURISK-02).",
                },
                "compliant": {
                    "type": "boolean",
                    "description": "True if compliant, False if not.",
                },
                "notes": {
                    "type": "string",
                    "description": "Optional notes about the answer.",
                },
            },
            "required": ["question_id", "compliant"],
        },
    },
    {
        "name": "generate_report",
        "description": "Generate PPTX and/or HTML healthcheck report.",
        "input_schema": {
            "type": "object",
            "properties": {
                "format": {
                    "type": "string",
                    "enum": ["pptx", "html", "both"],
                    "description": "Report format(s) to generate.",
                },
                "output_dir": {
                    "type": "string",
                    "description": "Output directory path.",
                },
                "customer_name": {
                    "type": "string",
                    "description": "Customer name (optional override).",
                },
            },
        },
    },
]

TOOL_DISPATCH = {
    "evaluate_all": lambda args: _tool_evaluate_all(**args),
    "submit_manual_answer": lambda args: _tool_submit_manual(**args),
    "generate_report": lambda args: _tool_generate_report(**args),
}


def run_agent(customer_name: str = "", interactive: bool = True):
    """Run the agent loop."""
    client = anthropic.Anthropic(api_key=config.ANTHROPIC_API_KEY)

    messages = []

    # Initial user message
    if customer_name:
        messages.append({
            "role": "user",
            "content": f"Run a VMDR healthcheck for customer: {customer_name}",
        })
    else:
        messages.append({"role": "user", "content": "Start a VMDR healthcheck assessment."})

    print(prompts.USER_GREETING)

    for turn in range(config.MAX_TURNS):
        response = client.messages.create(
            model=config.MODEL,
            max_tokens=config.MAX_TOKENS,
            system=prompts.SYSTEM_PROMPT,
            tools=TOOLS,
            messages=messages,
        )

        # Process response
        assistant_content = response.content
        messages.append({"role": "assistant", "content": assistant_content})

        # Check for tool use
        tool_uses = [b for b in assistant_content if b.type == "tool_use"]

        if not tool_uses:
            # Text-only response - print and check if done
            for block in assistant_content:
                if hasattr(block, "text"):
                    print(f"\n{block.text}")

            if response.stop_reason == "end_turn":
                if interactive:
                    user_input = input("\n> ").strip()
                    if user_input.lower() in ("quit", "exit", "done"):
                        break
                    messages.append({"role": "user", "content": user_input})
                else:
                    break
            continue

        # Process tool calls
        tool_results = []
        for tool_use in tool_uses:
            # Print any text before tool use
            for block in assistant_content:
                if hasattr(block, "text") and block.text:
                    print(f"\n{block.text}")
                    break

            print(f"\n[Running {tool_use.name}...]")
            handler = TOOL_DISPATCH.get(tool_use.name)
            if handler:
                result = handler(tool_use.input)
            else:
                result = json.dumps({"error": f"Unknown tool: {tool_use.name}"})

            tool_results.append({
                "type": "tool_result",
                "tool_use_id": tool_use.id,
                "content": result,
            })

        messages.append({"role": "user", "content": tool_results})

    print("\n--- Healthcheck session complete ---")


def main():
    parser = argparse.ArgumentParser(description="Qualys VMDR Healthcheck Agent")
    parser.add_argument("--customer", default="", help="Customer name")
    parser.add_argument(
        "--non-interactive",
        action="store_true",
        help="Run without interactive prompts",
    )
    args = parser.parse_args()

    if not config.ANTHROPIC_API_KEY:
        print("Error: ANTHROPIC_API_KEY not set. Export it or add to .env")
        sys.exit(1)

    run_agent(customer_name=args.customer, interactive=not args.non_interactive)


if __name__ == "__main__":
    main()
