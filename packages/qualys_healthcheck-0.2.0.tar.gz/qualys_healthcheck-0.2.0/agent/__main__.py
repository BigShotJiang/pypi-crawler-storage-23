"""Allow running as: python -m agent"""
from .orchestrator import main

main()
