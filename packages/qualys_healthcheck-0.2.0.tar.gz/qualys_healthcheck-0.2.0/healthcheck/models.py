"""Data models for the healthcheck evaluation engine."""

from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class QuestionMode(Enum):
    """How a question gets answered."""
    AUTO = "auto"           # Fully automated via API
    HYBRID = "hybrid"       # API data + manual confirmation
    MANUAL = "manual"       # Requires human input


class HealthArea(Enum):
    """Top-level health check areas (maps to xlsx template)."""
    SCANNING_HYGIENE = "Scanning Hygiene"
    ASSET_SETUP_HYGIENE = "Asset Setup Hygiene"
    TAGGING_HYGIENE = "Tagging Hygiene"
    REPORTING_AND_PURGING = "Reporting and Purging"
    TRURISK = "TruRisk"


class Section(Enum):
    """Evaluation sections within health areas."""
    AUTH = "AUTH"
    SCAN = "SCAN"
    AGENT_HEALTH = "AGENT HEALTH"
    TAG = "TAG"
    PURGING = "PURGING"
    REPORTING = "REPORTING"
    TRURISK = "TRURISK"


# Map sections to their parent health area
SECTION_TO_AREA: dict[Section, HealthArea] = {
    Section.AUTH: HealthArea.SCANNING_HYGIENE,
    Section.SCAN: HealthArea.SCANNING_HYGIENE,
    Section.AGENT_HEALTH: HealthArea.ASSET_SETUP_HYGIENE,
    Section.TAG: HealthArea.TAGGING_HYGIENE,
    Section.PURGING: HealthArea.REPORTING_AND_PURGING,
    Section.REPORTING: HealthArea.REPORTING_AND_PURGING,
    Section.TRURISK: HealthArea.TRURISK,
}


class Score(Enum):
    """Possible scores for a question."""
    PASS = 1.0
    PARTIAL = 0.5
    FAIL = 0.0
    NOT_ANSWERED = -1       # Manual question not yet answered
    NOT_APPLICABLE = -2     # API unavailable or question doesn't apply


class Grade(Enum):
    """Letter grade for section/overall scores."""
    A = "A"
    B = "B"
    C = "C"
    D = "D"
    F = "F"


def score_to_grade(pct: float) -> Grade:
    """Convert percentage score to letter grade."""
    if pct >= 90:
        return Grade.A
    elif pct >= 75:
        return Grade.B
    elif pct >= 60:
        return Grade.C
    elif pct >= 40:
        return Grade.D
    else:
        return Grade.F


@dataclass
class Question:
    """Definition of a single healthcheck question."""
    id: str                              # e.g. "AUTH-01"
    section: Section
    question: str                        # Full question text
    navigation: str                      # UI navigation hint from template
    recommendation: str                  # Recommendation if non-compliant
    mode: QuestionMode = QuestionMode.AUTO
    eval_function: str = ""              # Name of evaluator method
    xlsx_row: int = 0                    # Row in original template

    @property
    def area(self) -> HealthArea:
        return SECTION_TO_AREA[self.section]


@dataclass
class QuestionResult:
    """Result of evaluating a single question."""
    question_id: str
    score: Score
    evidence: str = ""                   # What data led to this score
    details: dict = field(default_factory=dict)  # Structured evidence
    notes: str = ""                      # Manual notes / user input
    api_error: bool = False              # True if API call failed

    @property
    def passed(self) -> bool:
        return self.score == Score.PASS

    @property
    def numeric_score(self) -> float:
        """Return numeric score, or -1 for unanswered/N/A."""
        return self.score.value


@dataclass
class SectionScore:
    """Aggregated score for a section."""
    section: Section
    total_questions: int
    evaluated_count: int
    passed_count: int
    partial_count: int
    failed_count: int
    unanswered_count: int
    not_applicable_count: int
    raw_score: float                     # Sum of numeric scores
    max_score: float                     # evaluated_count (max possible)
    percentage: float                    # 0-100
    grade: Grade


@dataclass
class AreaScore:
    """Aggregated score for a health area."""
    area: HealthArea
    sections: list[SectionScore]
    percentage: float
    grade: Grade


@dataclass
class OverallScore:
    """Complete healthcheck scoring summary."""
    area_scores: list[AreaScore]
    overall_percentage: float
    overall_grade: Grade
    total_questions: int
    evaluated_count: int
    passed_count: int
    partial_count: int
    failed_count: int
    unanswered_count: int
    not_applicable_count: int


@dataclass
class HealthcheckState:
    """Full state of a healthcheck evaluation session."""
    customer_name: str = ""
    results: dict[str, QuestionResult] = field(default_factory=dict)
    api_data: dict = field(default_factory=dict)   # Cached API responses
    started_at: str = ""
    completed_at: str = ""

    @property
    def is_complete(self) -> bool:
        """True if all manual questions have been answered."""
        from .questions import QUESTIONS
        for q in QUESTIONS.values():
            if q.mode in (QuestionMode.MANUAL, QuestionMode.HYBRID):
                result = self.results.get(q.id)
                if not result or result.score == Score.NOT_ANSWERED:
                    return False
        return True

    @property
    def pending_manual_questions(self) -> list[str]:
        """Return IDs of manual/hybrid questions not yet answered."""
        from .questions import QUESTIONS
        pending = []
        for q in QUESTIONS.values():
            if q.mode in (QuestionMode.MANUAL, QuestionMode.HYBRID):
                result = self.results.get(q.id)
                if not result or result.score == Score.NOT_ANSWERED:
                    pending.append(q.id)
        return pending
