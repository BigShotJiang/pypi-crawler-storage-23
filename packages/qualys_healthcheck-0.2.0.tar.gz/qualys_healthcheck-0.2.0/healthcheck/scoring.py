"""Scoring calculations for the VMDR healthcheck.

Computes per-section scores, per-area scores, and overall scores
following the xlsx template's formula: sum(scores) / evaluated_count * 100.
"""

from __future__ import annotations

from .models import (
    AreaScore,
    Grade,
    HealthArea,
    OverallScore,
    QuestionResult,
    Score,
    Section,
    SectionScore,
    SECTION_TO_AREA,
    score_to_grade,
)
from .questions import QUESTIONS, QUESTIONS_BY_SECTION


def compute_section_score(
    section: Section, results: dict[str, QuestionResult]
) -> SectionScore:
    """Compute aggregated score for a single section."""
    questions = QUESTIONS_BY_SECTION.get(section, [])
    total = len(questions)

    passed = 0
    partial = 0
    failed = 0
    unanswered = 0
    not_applicable = 0
    raw_score = 0.0

    for q in questions:
        result = results.get(q.id)
        if not result:
            unanswered += 1
            continue

        if result.score == Score.PASS:
            passed += 1
            raw_score += 1.0
        elif result.score == Score.PARTIAL:
            partial += 1
            raw_score += 0.5
        elif result.score == Score.FAIL:
            failed += 1
        elif result.score == Score.NOT_ANSWERED:
            unanswered += 1
        elif result.score == Score.NOT_APPLICABLE:
            not_applicable += 1

    # Evaluated = total minus unanswered and N/A
    evaluated = total - unanswered - not_applicable
    max_score = float(evaluated)
    percentage = (raw_score / max_score * 100) if max_score > 0 else 0.0
    grade = score_to_grade(percentage) if evaluated > 0 else Grade.F

    return SectionScore(
        section=section,
        total_questions=total,
        evaluated_count=evaluated,
        passed_count=passed,
        partial_count=partial,
        failed_count=failed,
        unanswered_count=unanswered,
        not_applicable_count=not_applicable,
        raw_score=raw_score,
        max_score=max_score,
        percentage=round(percentage, 1),
        grade=grade,
    )


def compute_area_score(
    area: HealthArea, results: dict[str, QuestionResult]
) -> AreaScore:
    """Compute aggregated score for a health area (may contain multiple sections)."""
    sections = [s for s, a in SECTION_TO_AREA.items() if a == area]
    section_scores = [compute_section_score(s, results) for s in sections]

    # Area percentage = weighted average of section scores
    total_evaluated = sum(ss.evaluated_count for ss in section_scores)
    total_raw = sum(ss.raw_score for ss in section_scores)

    if total_evaluated > 0:
        percentage = total_raw / total_evaluated * 100
    else:
        percentage = 0.0

    return AreaScore(
        area=area,
        sections=section_scores,
        percentage=round(percentage, 1),
        grade=score_to_grade(percentage) if total_evaluated > 0 else Grade.F,
    )


def compute_overall_score(results: dict[str, QuestionResult]) -> OverallScore:
    """Compute the full healthcheck score across all areas."""
    area_scores = [compute_area_score(area, results) for area in HealthArea]

    total_questions = len(QUESTIONS)
    passed = sum(
        1 for r in results.values() if r.score == Score.PASS
    )
    partial = sum(
        1 for r in results.values() if r.score == Score.PARTIAL
    )
    failed = sum(
        1 for r in results.values() if r.score == Score.FAIL
    )
    unanswered = sum(
        1 for r in results.values() if r.score == Score.NOT_ANSWERED
    )
    not_applicable = sum(
        1 for r in results.values() if r.score == Score.NOT_APPLICABLE
    )
    # Count questions with no result at all
    missing = total_questions - len(results)
    unanswered += missing

    evaluated = total_questions - unanswered - not_applicable
    raw_score = passed + (partial * 0.5)

    if evaluated > 0:
        overall_pct = raw_score / evaluated * 100
    else:
        overall_pct = 0.0

    return OverallScore(
        area_scores=area_scores,
        overall_percentage=round(overall_pct, 1),
        overall_grade=score_to_grade(overall_pct) if evaluated > 0 else Grade.F,
        total_questions=total_questions,
        evaluated_count=evaluated,
        passed_count=passed,
        partial_count=partial,
        failed_count=failed,
        unanswered_count=unanswered,
        not_applicable_count=not_applicable,
    )


def format_score_summary(overall: OverallScore) -> str:
    """Format a text summary of the overall score."""
    lines = [
        f"Overall Score: {overall.overall_percentage}% (Grade: {overall.overall_grade.value})",
        f"Questions: {overall.evaluated_count}/{overall.total_questions} evaluated "
        f"({overall.unanswered_count} unanswered, {overall.not_applicable_count} N/A)",
        f"Results: {overall.passed_count} passed, {overall.partial_count} partial, "
        f"{overall.failed_count} failed",
        "",
        "Section Breakdown:",
    ]

    for area_score in overall.area_scores:
        lines.append(f"\n  {area_score.area.value}: {area_score.percentage}% ({area_score.grade.value})")
        for ss in area_score.sections:
            status = "pass" if ss.grade in (Grade.A, Grade.B) else "warn" if ss.grade == Grade.C else "fail"
            lines.append(
                f"    [{status}] {ss.section.value}: "
                f"{ss.percentage}% ({ss.passed_count}/{ss.evaluated_count} passed)"
            )

    return "\n".join(lines)
