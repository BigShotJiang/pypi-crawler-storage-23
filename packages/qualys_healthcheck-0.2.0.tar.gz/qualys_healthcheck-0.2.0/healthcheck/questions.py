"""All 42 healthcheck question definitions mapped from the VMDR HealthCheck Template.

Questions are numbered per-section: AUTH-01..07, SCAN-01..11, AGHLTH-01..10,
TAG-01..05, PURGE-01..05, RPT-01..02, TRURISK-01..04.
Total: 7 + 11 + 10 + 5 + 5 + 2 + 4 = 44 questions (scored out of 42 per template).
"""

from .models import Question, QuestionMode, Section

# ─── AUTH Section (7 questions, xlsx rows 2-8) ────────────────────────────────

AUTH_QUESTIONS = [
    Question(
        id="AUTH-01",
        section=Section.AUTH,
        question="Does the customer use Authenticated scans in their option profiles?",
        navigation="Option Profile--Scan--Authentication",
        recommendation=(
            "Authenticated scanning is important to make sure that we can detect as many "
            "vulnerabilities as possible on the asset, also by using authenticated scanning "
            "and other features provided by Qualys will minimize the number of false positives, "
            "false negatives, and duplicates within the subscription."
        ),
        mode=QuestionMode.AUTO,
        eval_function="eval_auth_01",
        xlsx_row=2,
    ),
    Question(
        id="AUTH-02",
        section=Section.AUTH,
        question="Is their authentication failure rate less than 10%?",
        navigation="Check on dashboard for both windows and Linux",
        recommendation=(
            "Qualys recommends that authentication records within the subscription get updated "
            "as part of your organization's password rotation as to minimize the risk of using "
            "compromised or outdated credentials. This also ensures proper authenticated scans "
            "are taking place with minimal failures."
        ),
        mode=QuestionMode.HYBRID,
        eval_function="eval_auth_02",
        xlsx_row=3,
    ),
    Question(
        id="AUTH-03",
        section=Section.AUTH,
        question="Is the percentage of authentication records not in use less than 20% of the total?",
        navigation="Scans--Auth-- check all and used and calculate percentage",
        recommendation=(
            "For general subscription hygiene Qualys recommends removing any authentication "
            "records that are not in use. This eliminates the chances of authentication failure "
            "rates as well as ensures capturing the most accurate vulnerability data."
        ),
        mode=QuestionMode.AUTO,
        eval_function="eval_auth_03",
        xlsx_row=4,
    ),
    Question(
        id="AUTH-04",
        section=Section.AUTH,
        question="Are the customer windows authentication records using domain records?",
        navigation="Ask question",
        recommendation=(
            "Ensure that local windows authentication is not being used and if possible your "
            "organization is using Windows domain records for ease of management. Additionally "
            "this provides better control over access permissions."
        ),
        mode=QuestionMode.AUTO,
        eval_function="eval_auth_04",
        xlsx_row=5,
    ),
    Question(
        id="AUTH-05",
        section=Section.AUTH,
        question=(
            "For Linux records is the customer using tag based authentication, "
            "is it turned on for the customer?"
        ),
        navigation="Scan-Auth-Auth record-Asset",
        recommendation=(
            "Qualys recommends utilizing tag-based authentication for Linux systems to simplify "
            "management and ensure that the correct credentials are used for each scan. "
            "https://docs.qualys.com/en/vm/latest/authentication/tag_support.htm"
        ),
        mode=QuestionMode.AUTO,
        eval_function="eval_auth_05",
        xlsx_row=6,
    ),
    Question(
        id="AUTH-06",
        section=Section.AUTH,
        question="Does the customer use an authentication vault?",
        navigation="Ask question or Scan--Authentication--In Vault count",
        recommendation=(
            "While not mandatory for a healthy Qualys subscription, using an AUTH Vault "
            "(Thycotic, CyberArk, HashiCorp, etc) is easier to ensure passwords are "
            "synchronized and offer even more robust security. Static passwords should not be "
            "used long term. Rotating passwords should be used with scanner service accounts "
            "and are best implemented with password vault technologies."
        ),
        mode=QuestionMode.AUTO,
        eval_function="eval_auth_06",
        xlsx_row=7,
    ),
    Question(
        id="AUTH-07",
        section=Section.AUTH,
        question="Does the customer only use non Authenticated scans for external and PCI scans?",
        navigation="Ask question",
        recommendation=(
            "It is not recommended to perform authenticated external scans as the goal is to "
            "get an external attacker's perspective of the environment. Additionally for PCI "
            "external only scans are not required to be authenticated."
        ),
        mode=QuestionMode.AUTO,
        eval_function="eval_auth_07",
        xlsx_row=8,
    ),
]


# ─── SCAN Section (11 questions, xlsx rows 9-19) ─────────────────────────────

SCAN_QUESTIONS = [
    Question(
        id="SCAN-01",
        section=Section.SCAN,
        question=(
            "Are they doing scans by tags/Asset groups (compliant), "
            "or by IP (non-compliant)?"
        ),
        navigation="Scan-Auth-Auth record-Asset",
        recommendation=(
            "Qualys recommends performing scans using logical groupings, such as asset groups "
            "or tags, and scanning full address ranges for optimal coverage. This approach "
            "ensures that any changes to these ranges need to be updated only once, reducing "
            "the risk of manually inputting IPs and potentially missing assets."
        ),
        mode=QuestionMode.AUTO,
        eval_function="eval_scan_01",
        xlsx_row=9,
    ),
    Question(
        id="SCAN-02",
        section=Section.SCAN,
        question="Has the customer setup lightweight authenticated discovery scans?",
        navigation="Ask question",
        recommendation=(
            "Authenticated discovery scans enable customers to retrieve detailed information "
            "such as software inventory and local certificates. Additionally, when configured "
            "correctly, they facilitate the proper merging of assets, resulting in a much "
            "smoother operation."
        ),
        mode=QuestionMode.AUTO,
        eval_function="eval_scan_02",
        xlsx_row=10,
    ),
    Question(
        id="SCAN-03",
        section=Section.SCAN,
        question="Does the customer run a perimeter scan every 24h and/or use Qualys EASM?",
        navigation="Ask question",
        recommendation=(
            "Qualys recommends performing perimeter scans every 24 hours as a best practice to "
            "ensure timely identification and remediation of vulnerabilities. Alternatively, you "
            "can use Qualys External Attack Surface Management (EASM) to continuously monitor "
            "and manage your external digital footprint."
        ),
        mode=QuestionMode.AUTO,
        eval_function="eval_scan_03",
        xlsx_row=11,
    ),
    Question(
        id="SCAN-04",
        section=Section.SCAN,
        question="Does the customer run all scans at least weekly?",
        navigation="Ask question",
        recommendation=(
            "Ensuring that all your Qualys scans are run and completed at least weekly is "
            "essential for maintaining a proper security posture. This practice reduces the "
            "window of time your systems are exposed to potential exploits."
        ),
        mode=QuestionMode.AUTO,
        eval_function="eval_scan_04",
        xlsx_row=12,
    ),
    Question(
        id="SCAN-05",
        section=Section.SCAN,
        question=(
            "Does the customer have an emergency scan process, for singular QIDs/Zero days?"
        ),
        navigation="Ask question",
        recommendation=(
            "Qualys recommends creating dedicated option profiles for identifying specific "
            "vulnerabilities in one-off scans, such as singular QIDs and zero-day "
            "vulnerabilities. By narrowing down the profile to focus on a specific QID search "
            "list, the scanning and detection process becomes faster."
        ),
        mode=QuestionMode.MANUAL,
        eval_function="eval_scan_05",
        xlsx_row=13,
    ),
    Question(
        id="SCAN-06",
        section=Section.SCAN,
        question="Do all scans complete in less than 24h from time of start?",
        navigation="scan--schedules and check duration",
        recommendation=(
            "Longer running scans may suggest underlying scanning issues such as slow or "
            "unresponsive systems. If scans take more than 24 to 48 hours to complete, it may "
            "be beneficial to consider adding additional scanner appliances or dividing the scan "
            "jobs into smaller sections for improved efficiency."
        ),
        mode=QuestionMode.AUTO,
        eval_function="eval_scan_06",
        xlsx_row=14,
    ),
    Question(
        id="SCAN-07",
        section=Section.SCAN,
        question="Do all scans complete in less than 48h from time of start?",
        navigation="scan--schedules and check duration",
        recommendation=(
            "Longer running scans may suggest underlying scanning issues such as slow or "
            "unresponsive systems. If scans take more than 24 to 48 hours to complete, it may "
            "be beneficial to consider adding additional scanner appliances or dividing the scan "
            "jobs into smaller sections for improved efficiency."
        ),
        mode=QuestionMode.AUTO,
        eval_function="eval_scan_07",
        xlsx_row=15,
    ),
    Question(
        id="SCAN-08",
        section=Section.SCAN,
        question=(
            "Do all of their option profiles use standard or full port scans "
            "configured for both TCP and UDP?"
        ),
        navigation="Scans--Option Profile--scans",
        recommendation=(
            "By performing full or standard port scans for TCP and UDP we can be sure to "
            "perform checks against the largest portion of QIDs. Recommend only using specific "
            "port scan option profiles for scans on sensitive assets."
        ),
        mode=QuestionMode.AUTO,
        eval_function="eval_scan_08",
        xlsx_row=16,
    ),
    Question(
        id="SCAN-09",
        section=Section.SCAN,
        question=(
            "Do all option profiles use at least normal and parallel scaling "
            "performance settings?"
        ),
        navigation="Scans--Option Profile--scans--performance",
        recommendation=(
            "Adjusting parallel scanning settings in the option profile is crucial for "
            "balancing scan efficiency and network performance. Increasing the number of "
            "parallel scans can significantly reduce the time it takes to complete scans."
        ),
        mode=QuestionMode.AUTO,
        eval_function="eval_scan_09",
        xlsx_row=17,
    ),
    Question(
        id="SCAN-10",
        section=Section.SCAN,
        question=(
            "In the scan option profiles in use, has the option to ignore firewall "
            "generated TCP/RST packets been turned on?"
        ),
        navigation="Scans--Option Profile--Additional--packet Options",
        recommendation=(
            "Firewalls often generate TCP Reset (RST) packets as a defensive measure. If these "
            "RST packets are not ignored, the scanner might incorrectly interpret them as "
            "indications that the scanned ports are closed or unreachable. This can lead to "
            "false negatives, where open ports or potential vulnerabilities are missed."
        ),
        mode=QuestionMode.AUTO,
        eval_function="eval_scan_10",
        xlsx_row=18,
    ),
    Question(
        id="SCAN-11",
        section=Section.SCAN,
        question=(
            'From the hygiene dashboard, do they have less than 10% of their license '
            'shown as "ghost" hosts? (Less = Compliant)'
        ),
        navigation="No of ghost vs total number of assets from dashboard",
        recommendation=(
            'Qualys recommends minimizing "Ghost Hosts" within the environment to ensure an '
            "accurate and up-to-date asset inventory. Ghost Hosts, which are obsolete or "
            "inactive assets, can clutter the system, leading to inaccurate security assessments "
            "and inefficient resource allocation."
        ),
        mode=QuestionMode.AUTO,
        eval_function="eval_scan_11",
        xlsx_row=19,
    ),
]


# ─── AGENT HEALTH Section (10 questions, xlsx rows 20-29) ────────────────────

AGENT_HEALTH_QUESTIONS = [
    Question(
        id="AGHLTH-01",
        section=Section.AGENT_HEALTH,
        question="Has the customer turned on Agentless tracking?",
        navigation="Asset-Setup--Agentless tracking",
        recommendation=(
            "Turning on Agentless Tracking in Qualys enhances asset management by using unique "
            "identifiers, ensuring accurate identification and tracking even in dynamic "
            "environments. This reduces the risk of duplicate or misidentified assets."
        ),
        mode=QuestionMode.AUTO,
        eval_function="eval_aghlth_01",
        xlsx_row=20,
    ),
    Question(
        id="AGHLTH-02",
        section=Section.AGENT_HEALTH,
        question='For Asset Merging have they set the option to "Unified View"?',
        navigation="Assets--Setup--Asset Tracking & Data merging--Asset Merging",
        recommendation=(
            'Using "Unified View" consolidates information from various Qualys modules, offering '
            "a holistic view of the organization's security posture. This streamlined visibility "
            "enhances decision-making."
        ),
        mode=QuestionMode.AUTO,
        eval_function="eval_aghlth_02",
        xlsx_row=21,
    ),
    Question(
        id="AGHLTH-03",
        section=Section.AGENT_HEALTH,
        question=(
            "Has the customer setup non authenticated agent scan merging, "
            "is it both accepted in VMDR and turned on for the configuration profile?"
        ),
        navigation="Cloud Agent-->Configuration Profile---Agent scan Merge",
        recommendation=(
            "Qualys recommends setting up non-authenticated agent scan merging to enhance asset "
            "tracking and vulnerability detection. By merging data from authenticated and "
            "non-authenticated scans, it ensures a comprehensive view of each asset's security "
            "posture."
        ),
        mode=QuestionMode.AUTO,
        eval_function="eval_aghlth_03",
        xlsx_row=22,
    ),
    Question(
        id="AGHLTH-04",
        section=Section.AGENT_HEALTH,
        question=(
            "Does the customer have Cloud Agents deployed to 50% or more of their "
            "assets capable of agent deployment?"
        ),
        navigation="IN GAV - Default dashboard - Agents vs total count",
        recommendation=(
            "Deploying Qualys Cloud Agents provides continuous, real-time visibility into the "
            "security and compliance status of your IT assets. These lightweight agents offer "
            "constant monitoring and immediate detection of vulnerabilities, even on devices "
            "that are off-network."
        ),
        mode=QuestionMode.AUTO,
        eval_function="eval_aghlth_04",
        xlsx_row=23,
    ),
    Question(
        id="AGHLTH-05",
        section=Section.AGENT_HEALTH,
        question=(
            "Does the customer have Cloud Agents deployed to 75% or more of their "
            "assets capable of agent deployment?"
        ),
        navigation="IN GAV - Default dashboard - Agents vs total count",
        recommendation=(
            "Deploying Qualys Cloud Agents provides continuous, real-time visibility into the "
            "security and compliance status of your IT assets."
        ),
        mode=QuestionMode.AUTO,
        eval_function="eval_aghlth_05",
        xlsx_row=24,
    ),
    Question(
        id="AGHLTH-06",
        section=Section.AGENT_HEALTH,
        question=(
            "Does the customer have Cloud Agents deployed to 90% or more of their "
            "assets capable of agent deployment?"
        ),
        navigation="IN GAV - Default dashboard - Agents vs total count",
        recommendation=(
            "Deploying Qualys Cloud Agents provides continuous, real-time visibility into the "
            "security and compliance status of your IT assets."
        ),
        mode=QuestionMode.AUTO,
        eval_function="eval_aghlth_06",
        xlsx_row=25,
    ),
    Question(
        id="AGHLTH-07",
        section=Section.AGENT_HEALTH,
        question=(
            'Does the customer have more than the "initial options" cloud agent '
            "configuration profile?"
        ),
        navigation="Cloud Agent --Configuration Profiles",
        recommendation=(
            'Creating a Qualys Cloud Agent configuration profile instead of using the "initial '
            'options" allows for customized and fine-tuned settings tailored to your specific '
            "environment and security needs."
        ),
        mode=QuestionMode.AUTO,
        eval_function="eval_aghlth_07",
        xlsx_row=26,
    ),
    Question(
        id="AGHLTH-08",
        section=Section.AGENT_HEALTH,
        question=(
            "Do they have cloud agent configuration profiles setup to allow auto "
            "update of version?"
        ),
        navigation="Cloud Agent --Configuration Profiles--General--Prevent auto updating",
        recommendation=(
            "Allowing the Qualys agent to auto-update ensures that your security tools are "
            "always equipped with the latest features, improvements, and vulnerability "
            "signatures. This automatic updating process reduces the administrative burden."
        ),
        mode=QuestionMode.AUTO,
        eval_function="eval_aghlth_08",
        xlsx_row=27,
    ),
    Question(
        id="AGHLTH-09",
        section=Section.AGENT_HEALTH,
        question=(
            "Do 5% or less of their agents show an older version than what is "
            "currently available on the platform?"
        ),
        navigation="Cloud Agent --Agents -- Note what version of agents",
        recommendation=(
            "Keeping the Qualys agent updated and avoiding older versions ensures that the "
            "agent has the latest security features, bug fixes, and vulnerability signatures. "
            "It also ensures compatibility with new operating systems and applications."
        ),
        mode=QuestionMode.AUTO,
        eval_function="eval_aghlth_09",
        xlsx_row=28,
    ),
    Question(
        id="AGHLTH-10",
        section=Section.AGENT_HEALTH,
        question=(
            "Do 5% or less of their agents show activated for inventory only?"
        ),
        navigation="Cloud Agent--Agent management and Activation keys",
        recommendation=(
            'Avoiding "Inventory Only" activation for Qualys agents ensures comprehensive '
            "security monitoring, vulnerability detection, and compliance management. Full "
            "activation enables the agents to perform real-time vulnerability assessments."
        ),
        mode=QuestionMode.AUTO,
        eval_function="eval_aghlth_10",
        xlsx_row=29,
    ),
]


# ─── TAG Section (5 questions, xlsx rows 30-34) ──────────────────────────────

TAG_QUESTIONS = [
    Question(
        id="TAG-01",
        section=Section.TAG,
        question=(
            "Do they have tagging setup with grouping (compliant), or is everything "
            "just off the top level tags (non-compliant)?"
        ),
        navigation="CSAM--Tags--check the tags",
        recommendation=(
            "Qualys recommends tagging with a layered structure over top-level tags to improve "
            "granularity and organization in asset management. This hierarchical approach allows "
            "for more precise and flexible categorization."
        ),
        mode=QuestionMode.AUTO,
        eval_function="eval_tag_01",
        xlsx_row=30,
    ),
    Question(
        id="TAG-02",
        section=Section.TAG,
        question=(
            "Are asset criticality scores setup on 90% of their tags "
            "(making sure everything isn't just a 3 or 4 or 5)?"
        ),
        navigation="CSAM--Tags--check the criticality scores",
        recommendation=(
            "Setting up asset criticality scores on asset groups and asset tags helps prioritize "
            "security efforts based on the importance of assets. This approach enables more "
            "efficient vulnerability management."
        ),
        mode=QuestionMode.AUTO,
        eval_function="eval_tag_02",
        xlsx_row=31,
    ),
    Question(
        id="TAG-03",
        section=Section.TAG,
        question=(
            "Are asset criticality scores setup on 90% of their asset groups "
            "(making sure everything isn't just a 3 or 4 or 5)?"
        ),
        navigation="CSAM--Tags--check the criticality scores",
        recommendation=(
            "Setting up asset criticality scores on asset groups and asset tags helps prioritize "
            "security efforts based on the importance of assets."
        ),
        mode=QuestionMode.AUTO,
        eval_function="eval_tag_03",
        xlsx_row=32,
    ),
    Question(
        id="TAG-04",
        section=Section.TAG,
        question="Do they have a reasonable number of tags relative to the account size?",
        navigation="CSAM--Tags--No of Tags",
        recommendation=(
            "Having a proper tagging hierarchy is important for reporting because it ensures "
            "organized, detailed, and accurate categorization of assets. This structured approach "
            "allows for more granular and meaningful insights."
        ),
        mode=QuestionMode.AUTO,
        eval_function="eval_tag_04",
        xlsx_row=33,
    ),
    Question(
        id="TAG-05",
        section=Section.TAG,
        question="Do they use dynamic inventory based tags?",
        navigation="CSAM--Tags--check the criticality scores",
        recommendation=(
            "Using dynamic inventory-based tags ensures that asset categorization is always "
            "up-to-date and reflects the current state of the IT environment. "
            "https://success.qualys.com/discussions/s/article/000005817"
        ),
        mode=QuestionMode.AUTO,
        eval_function="eval_tag_05",
        xlsx_row=34,
    ),
]


# ─── PURGING Section (5 questions, xlsx rows 35-39) ──────────────────────────

PURGE_QUESTIONS = [
    Question(
        id="PURGE-01",
        section=Section.PURGING,
        question="Does the customer subscription have purge rules enabled?",
        navigation="CSAM--Rules--Asset Purge Rules--check the items",
        recommendation=(
            "Enabling automatic purge rules ensures that outdated and irrelevant data is "
            "regularly removed from the system, maintaining a clean and accurate asset inventory."
        ),
        mode=QuestionMode.AUTO,
        eval_function="eval_purge_01",
        xlsx_row=35,
    ),
    Question(
        id="PURGE-02",
        section=Section.PURGING,
        question="Does the customer subscription have purge rules configured?",
        navigation="CSAM--Rules--Asset Purge Rules--check the items",
        recommendation=(
            "Enabling automatic purge rules ensures that outdated and irrelevant data is "
            "regularly removed from the system, maintaining a clean and accurate asset inventory."
        ),
        mode=QuestionMode.AUTO,
        eval_function="eval_purge_02",
        xlsx_row=36,
    ),
    Question(
        id="PURGE-03",
        section=Section.PURGING,
        question=(
            "Does the customer subscription have purge rules set to purge all "
            "terminated instances?"
        ),
        navigation="CSAM--Rules--Asset Purge Rules--check the items",
        recommendation=(
            "This prevents clutter from obsolete instances, enhances system performance, and "
            "ensures that security assessments and compliance reports reflect the current state "
            "of the cloud environment."
        ),
        mode=QuestionMode.AUTO,
        eval_function="eval_purge_03",
        xlsx_row=37,
    ),
    Question(
        id="PURGE-04",
        section=Section.PURGING,
        question=(
            "Does the customer subscription have a purge rule to remove IP/DNS tracked "
            "hosts not scanned in at least the last 90 days?"
        ),
        navigation="CSAM--Rules--Asset Purge Rules--check the items",
        recommendation=(
            "Implementing purge rules to remove IP/DNS tracked hosts not scanned within the "
            "last 90 days helps maintain a current and accurate asset inventory."
        ),
        mode=QuestionMode.AUTO,
        eval_function="eval_purge_04",
        xlsx_row=38,
    ),
    Question(
        id="PURGE-05",
        section=Section.PURGING,
        question=(
            "Does the customer subscription have a purge rule to remove IP/DNS tracked "
            "hosts not scanned in at least the last 30 days?"
        ),
        navigation="CSAM--Rules--Asset Purge Rules--check the items",
        recommendation=(
            "Implementing purge rules to remove IP/DNS tracked hosts not scanned within the "
            "last 30 days helps maintain a current and accurate asset inventory."
        ),
        mode=QuestionMode.AUTO,
        eval_function="eval_purge_05",
        xlsx_row=39,
    ),
]


# ─── REPORTING Section (2 questions, xlsx rows 40-41) ────────────────────────

REPORTING_QUESTIONS = [
    Question(
        id="RPT-01",
        section=Section.REPORTING,
        question=(
            "Does the customer use custom dashboards, or have more than 3 dashboards "
            "imported?"
        ),
        navigation="Check dashboard",
        recommendation=(
            "Custom dashboards provide focused, real-time insights into key metrics and trends "
            "relevant to your organization, enhancing decision-making and operational efficiency."
        ),
        mode=QuestionMode.MANUAL,
        eval_function="eval_rpt_01",
        xlsx_row=40,
    ),
    Question(
        id="RPT-02",
        section=Section.REPORTING,
        question="Does the customer have our Hygiene dashboard imported?",
        navigation="Ask question",
        recommendation=(
            "Importing the Qualys hygiene dashboard into your subscription provides easy access "
            "to key metrics like activated agents, ghost hosts, and authentication failure rates."
        ),
        mode=QuestionMode.MANUAL,
        eval_function="eval_rpt_02",
        xlsx_row=41,
    ),
]


# ─── TRURISK Section (4 questions, xlsx rows 42-45) ──────────────────────────

TRURISK_QUESTIONS = [
    Question(
        id="TRURISK-01",
        section=Section.TRURISK,
        question="Does the customer use our TruRisk Dashboard?",
        navigation="Ask question",
        recommendation=(
            "The Qualys TruRisk dashboard provides a comprehensive overview of your "
            "organization's risk posture by integrating and analyzing vulnerability data, "
            "asset criticality, and threat intelligence."
        ),
        mode=QuestionMode.MANUAL,
        eval_function="eval_trurisk_01",
        xlsx_row=42,
    ),
    Question(
        id="TRURISK-02",
        section=Section.TRURISK,
        question="Is the customer using TruRisk to drive patching jobs?",
        navigation="Ask question",
        recommendation=(
            "Qualys recommends using TruRisk to drive patching operations because it "
            "prioritizes vulnerabilities based on their risk impact, helping to focus efforts "
            "on the most critical issues."
        ),
        mode=QuestionMode.MANUAL,
        eval_function="eval_trurisk_02",
        xlsx_row=43,
    ),
    Question(
        id="TRURISK-03",
        section=Section.TRURISK,
        question=(
            "Has the customer integrated our data with a ticketing system to drive "
            "patching? (SNOW, BMC, JIRA)"
        ),
        navigation="Ask question",
        recommendation=(
            "Qualys recommends integrating your data with a ticketing system like SNOW, BMC, "
            "or JIRA to streamline the patching process by automating the creation and tracking "
            "of remediation tasks."
        ),
        mode=QuestionMode.MANUAL,
        eval_function="eval_trurisk_03",
        xlsx_row=44,
    ),
    Question(
        id="TRURISK-04",
        section=Section.TRURISK,
        question="Does the customer use our integrated Patching?",
        navigation="Ask question",
        recommendation=(
            "Qualys recommends integrated patching because it streamlines the patch management "
            "process by combining vulnerability detection and remediation in a single platform."
        ),
        mode=QuestionMode.MANUAL,
        eval_function="eval_trurisk_04",
        xlsx_row=45,
    ),
]


# ─── Master question registry ────────────────────────────────────────────────

ALL_QUESTION_LISTS = [
    AUTH_QUESTIONS,
    SCAN_QUESTIONS,
    AGENT_HEALTH_QUESTIONS,
    TAG_QUESTIONS,
    PURGE_QUESTIONS,
    REPORTING_QUESTIONS,
    TRURISK_QUESTIONS,
]

QUESTIONS: dict[str, Question] = {}
for _qlist in ALL_QUESTION_LISTS:
    for _q in _qlist:
        QUESTIONS[_q.id] = _q

QUESTIONS_BY_SECTION: dict[Section, list[Question]] = {}
for _q in QUESTIONS.values():
    QUESTIONS_BY_SECTION.setdefault(_q.section, []).append(_q)

# Ordered list for iteration
QUESTION_ORDER: list[str] = [q.id for ql in ALL_QUESTION_LISTS for q in ql]

TOTAL_QUESTIONS = len(QUESTIONS)  # Should be 44
SCORED_TOTAL = 42  # Per template formula (scored out of 42)
