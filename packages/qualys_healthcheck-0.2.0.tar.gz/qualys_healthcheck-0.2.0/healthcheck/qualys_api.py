"""Qualys API functions for healthcheck data collection.

Follows the same patterns as qualys-mcp: Basic Auth for classic APIs,
Bearer Token for Gateway APIs, XML/JSON parsing, caching, error handling.
"""

from __future__ import annotations

import os
import re
import sys
import json
import ssl
import base64
from urllib.request import Request, urlopen
from urllib.parse import urlencode
from urllib.error import HTTPError, URLError
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from concurrent.futures import ThreadPoolExecutor, as_completed
from threading import Lock


# ─── Configuration (same env vars as qualys-mcp) ─────────────────────────────

USERNAME = os.environ.get("QUALYS_USERNAME", "")
PASSWORD = os.environ.get("QUALYS_PASSWORD", "")


def normalize_url(url: str) -> str:
    url = url.strip().rstrip("/")
    if url and not url.startswith("http"):
        url = f"https://{url}"
    return url


BASE_URL = normalize_url(os.environ.get("QUALYS_BASE_URL", ""))
GATEWAY_URL = normalize_url(os.environ.get("QUALYS_GATEWAY_URL", ""))
BASIC_AUTH = base64.b64encode(f"{USERNAME}:{PASSWORD}".encode()).decode()

# Bearer token state (thread-safe)
BEARER_TOKEN: str | None = None
BEARER_TOKEN_TIME: datetime | None = None
AUTH_LOCK = Lock()

# SSL context
SSL_CTX = None
if os.environ.get("QUALYS_SSL_VERIFY", "").lower() in ("0", "false", "no"):
    SSL_CTX = ssl.create_default_context()
    SSL_CTX.check_hostname = False
    SSL_CTX.verify_mode = ssl.CERT_NONE

# Module-level caches
_CACHE: dict[str, tuple[datetime, object]] = {}
CACHE_TTL = 300  # 5 minutes


def _open(req, timeout=30):
    """urlopen wrapper for SSL context."""
    return urlopen(req, timeout=timeout, context=SSL_CTX)


def _log(msg: str):
    """Log to stderr (visible in MCP server logs)."""
    print(f"[qualys-healthcheck] {msg}", file=sys.stderr)


def _cache_get(key: str):
    """Return cached value if still valid, else None."""
    if key in _CACHE:
        ts, val = _CACHE[key]
        if (datetime.now(timezone.utc) - ts).total_seconds() < CACHE_TTL:
            return val
    return None


def _cache_set(key: str, val):
    _CACHE[key] = (datetime.now(timezone.utc), val)


def get_bearer_token() -> str | None:
    """Get bearer token, refreshing if expired. Thread-safe."""
    global BEARER_TOKEN, BEARER_TOKEN_TIME
    if BEARER_TOKEN and BEARER_TOKEN_TIME:
        age = (datetime.now(timezone.utc) - BEARER_TOKEN_TIME).total_seconds()
        if age < 12600:  # 3.5 hours
            return BEARER_TOKEN
    with AUTH_LOCK:
        if BEARER_TOKEN and BEARER_TOKEN_TIME:
            age = (datetime.now(timezone.utc) - BEARER_TOKEN_TIME).total_seconds()
            if age < 12600:
                return BEARER_TOKEN
        _log("Refreshing bearer token...")
        try:
            auth_data = urlencode(
                {"username": USERNAME, "password": PASSWORD, "token": "true"}
            ).encode()
            req = Request(f"{GATEWAY_URL}/auth", data=auth_data, method="POST")
            req.add_header("Content-Type", "application/x-www-form-urlencoded")
            with _open(req, timeout=30) as resp:
                BEARER_TOKEN = resp.read().decode().strip()
                BEARER_TOKEN_TIME = datetime.now(timezone.utc)
                return BEARER_TOKEN
        except Exception as e:
            _log(f"Auth error: {e}")
            return None


def api_get(url: str, gateway: bool = False, timeout: int = 60) -> bytes | None:
    """Make authenticated GET request. Returns raw bytes or None on error."""
    req = Request(url)
    if gateway:
        token = get_bearer_token()
        req.add_header(
            "Authorization", f"Bearer {token}" if token else f"Basic {BASIC_AUTH}"
        )
    else:
        req.add_header("Authorization", f"Basic {BASIC_AUTH}")
    req.add_header("X-Requested-With", "qualys-healthcheck")
    try:
        with _open(req, timeout=timeout) as resp:
            return resp.read()
    except HTTPError as e:
        _log(f"API error {e.code}: {url.split('?')[0]}")
        return None
    except URLError as e:
        _log(f"Connection error: {e.reason}")
        return None
    except Exception as e:
        _log(f"Request failed: {e}")
        return None


def api_post(
    url: str,
    data: dict | None = None,
    body: str | bytes | None = None,
    gateway: bool = False,
    content_type: str = "application/x-www-form-urlencoded",
    timeout: int = 60,
) -> bytes | None:
    """Make authenticated POST request. Returns raw bytes or None on error."""
    if data and not body:
        encoded = urlencode(data).encode()
    elif body:
        encoded = body.encode() if isinstance(body, str) else body
    else:
        encoded = b""
    req = Request(url, data=encoded, method="POST")
    if gateway:
        token = get_bearer_token()
        req.add_header(
            "Authorization", f"Bearer {token}" if token else f"Basic {BASIC_AUTH}"
        )
        req.add_header("Accept", "application/json")
    else:
        req.add_header("Authorization", f"Basic {BASIC_AUTH}")
    req.add_header("Content-Type", content_type)
    req.add_header("X-Requested-With", "qualys-healthcheck")
    try:
        with _open(req, timeout=timeout) as resp:
            return resp.read()
    except HTTPError as e:
        _log(f"API POST error {e.code}: {url.split('?')[0]}")
        return None
    except URLError as e:
        _log(f"Connection error: {e.reason}")
        return None
    except Exception as e:
        _log(f"POST request failed: {e}")
        return None


def _run_concurrent(**tasks) -> dict:
    """Run named tasks concurrently. Returns dict of {name: result}."""
    results = {}
    with ThreadPoolExecutor(max_workers=min(len(tasks), 8)) as executor:
        futures = {executor.submit(fn): name for name, fn in tasks.items()}
        for future in as_completed(futures):
            name = futures[future]
            try:
                results[name] = future.result()
            except Exception as e:
                _log(f"Concurrent task '{name}' failed: {e}")
                results[name] = None
    return results


# ─── Data Collection Functions ────────────────────────────────────────────────


def get_option_profiles() -> list[dict]:
    """Fetch option profiles with auth, port, performance, and firewall settings.

    API: /api/6.0/fo/subscription/option_profile/?action=export
    (v2.0 is EOS; v6.0 uses action=export with different XML structure)
    """
    cached = _cache_get("option_profiles")
    if cached is not None:
        return cached

    url = f"{BASE_URL}/api/6.0/fo/subscription/option_profile/?action=export"
    data = api_get(url, timeout=120)
    if not data:
        return []

    profiles = []
    try:
        root = ET.fromstring(data)
        for op in root.findall(".//OPTION_PROFILE"):
            bi = op.find("BASIC_INFO")
            profile = {
                "id": bi.findtext("ID", "") if bi is not None else "",
                "title": bi.findtext("GROUP_NAME", "") if bi is not None else "",
                "is_default": False,
                "is_global": (bi.findtext("IS_GLOBAL", "0") == "1") if bi is not None else False,
            }

            # Authentication settings
            scan_el = op.find("SCAN")
            if scan_el is not None:
                auth_el = scan_el.find("AUTHENTICATION")
                if auth_el is not None:
                    profile["auth_enabled"] = True
                    profile["windows_auth"] = auth_el.find("WINDOWS") is not None
                    profile["unix_auth"] = auth_el.find("UNIX") is not None
                else:
                    profile["auth_enabled"] = False

                # Port settings (v6 uses TCP_PORTS, UDP_PORTS, TARGETED_SCAN)
                ports_el = scan_el.find("PORTS")
                if ports_el is not None:
                    tcp_text = ports_el.findtext("TCP_PORTS", "").strip()
                    udp_text = ports_el.findtext("UDP_PORTS", "").strip()
                    targeted = ports_el.findtext("TARGETED_SCAN", "0")
                    profile["tcp_ports"] = tcp_text
                    profile["udp_ports"] = udp_text
                    tcp_lower = tcp_text.lower()
                    profile["full_tcp"] = tcp_lower in ("full", "standard", "1-65535")
                    profile["has_udp"] = bool(udp_text)
                    profile["targeted_scan"] = targeted == "1"

                # Performance settings
                perf_el = scan_el.find("PERFORMANCE")
                if perf_el is not None:
                    profile["parallel_scaling"] = perf_el.findtext(
                        "PARALLEL_SCALING", ""
                    )
                    profile["overall_performance"] = perf_el.findtext(
                        "OVERALL_PERFORMANCE", ""
                    )

            # Additional settings (firewall RST)
            addl_el = op.find("ADDITIONAL")
            if addl_el is not None:
                profile["ignore_firewall_rst"] = (
                    addl_el.findtext("HOST_ALIVE_TESTING/IGNORE_FIREWALL_TCP_RST", "0")
                    == "1"
                )
            else:
                profile["ignore_firewall_rst"] = False

            profiles.append(profile)
    except ET.ParseError as e:
        _log(f"XML parse error in option profiles: {e}")

    _cache_set("option_profiles", profiles)
    return profiles


def get_auth_records() -> dict:
    """Fetch authentication records (Windows + Unix).

    APIs: /api/2.0/fo/auth/windows/?action=list
          /api/2.0/fo/auth/unix/?action=list
    """
    cached = _cache_get("auth_records")
    if cached is not None:
        return cached

    result = {"windows": [], "unix": [], "total": 0, "in_use": 0, "vault_count": 0}

    def fetch_windows():
        url = f"{BASE_URL}/api/2.0/fo/auth/windows/?action=list&details=All"
        data = api_get(url, timeout=90)
        if not data:
            return []
        records = []
        try:
            root = ET.fromstring(data)
            for rec in root.findall(".//AUTH_WINDOWS"):
                record = {
                    "id": rec.findtext("ID", ""),
                    "title": rec.findtext("TITLE", ""),
                    "type": "windows",
                    "is_domain": False,
                    "is_vault": False,
                    "in_use": False,
                }
                # Check domain vs local (DOMAIN element or domain in USERNAME)
                domain_el = rec.find("DOMAIN")
                if domain_el is not None and domain_el.text:
                    record["is_domain"] = True
                # Check vault usage
                vault_el = rec.find("VAULT")
                if vault_el is not None:
                    record["is_vault"] = True
                # Usage info - check IP_SET, TAGS
                ip_set = rec.find("IP_SET")
                tags = rec.find("TAGS")
                if (ip_set is not None and len(ip_set) > 0) or tags is not None:
                    record["in_use"] = True
                records.append(record)
        except ET.ParseError as e:
            _log(f"XML parse error in windows auth: {e}")
        return records

    def fetch_unix():
        url = f"{BASE_URL}/api/2.0/fo/auth/unix/?action=list&details=All"
        data = api_get(url, timeout=90)
        if not data:
            return []
        records = []
        try:
            root = ET.fromstring(data)
            for rec in root.findall(".//AUTH_UNIX"):
                record = {
                    "id": rec.findtext("ID", ""),
                    "title": rec.findtext("TITLE", ""),
                    "type": "unix",
                    "tag_based": False,
                    "is_vault": False,
                    "in_use": False,
                }
                # Tag-based auth
                tags = rec.find("TAGS")
                if tags is not None:
                    record["tag_based"] = True
                    record["in_use"] = True
                # Vault
                vault_el = rec.find("VAULT")
                if vault_el is not None:
                    record["is_vault"] = True
                # Usage - check IP_SET
                ip_set = rec.find("IP_SET")
                if ip_set is not None and len(ip_set) > 0:
                    record["in_use"] = True
                records.append(record)
        except ET.ParseError as e:
            _log(f"XML parse error in unix auth: {e}")
        return records

    concurrent = _run_concurrent(windows=fetch_windows, unix=fetch_unix)
    win_records = concurrent.get("windows") or []
    unix_records = concurrent.get("unix") or []

    result["windows"] = win_records
    result["unix"] = unix_records
    all_records = win_records + unix_records
    result["total"] = len(all_records)
    result["in_use"] = sum(1 for r in all_records if r.get("in_use"))
    result["vault_count"] = sum(1 for r in all_records if r.get("is_vault"))
    result["domain_windows"] = sum(
        1 for r in win_records if r.get("is_domain")
    )
    result["local_windows"] = sum(
        1 for r in win_records if not r.get("is_domain")
    )
    result["tag_based_unix"] = sum(
        1 for r in unix_records if r.get("tag_based")
    )

    _cache_set("auth_records", result)
    return result


def get_scan_schedules() -> dict:
    """Fetch scan schedules and recent scan results for frequency/duration analysis.

    APIs: /api/2.0/fo/schedule/scan/?action=list
          /api/2.0/fo/scan/?action=list (recent scans)
    """
    cached = _cache_get("scan_schedules")
    if cached is not None:
        return cached

    result = {
        "schedules": [],
        "recent_scans": [],
        "all_weekly_or_better": False,
        "all_under_24h": False,
        "all_under_48h": False,
        "uses_tags": False,
        "uses_ips_only": False,
    }

    def fetch_schedules():
        url = f"{BASE_URL}/api/2.0/fo/schedule/scan/?action=list"
        data = api_get(url, timeout=120)
        if not data:
            return []
        schedules = []
        try:
            root = ET.fromstring(data)
            for sched in root.findall(".//SCAN"):
                s = {
                    "id": sched.findtext("ID", ""),
                    "title": sched.findtext("TITLE", ""),
                    "active": sched.findtext("ACTIVE", "0") == "1",
                    "frequency": sched.findtext("SCHEDULE/FREQUENCY_TYPE", ""),
                    "target": sched.findtext("TARGET", ""),
                    "asset_group_title": sched.findtext("ASSET_GROUP_TITLE", ""),
                    "tag_set_include": sched.findtext("TAG_SET_INCLUDE", ""),
                    "option_profile": sched.findtext("OPTION_PROFILE/TITLE", ""),
                }
                # Determine target type
                if s["tag_set_include"] or s["asset_group_title"]:
                    s["target_type"] = "tags_or_groups"
                else:
                    s["target_type"] = "ip"
                schedules.append(s)
        except ET.ParseError as e:
            _log(f"XML parse error in schedules: {e}")
        return schedules

    def fetch_recent_scans():
        after = (datetime.now(timezone.utc) - timedelta(days=30)).strftime("%Y-%m-%d")
        url = (
            f"{BASE_URL}/api/2.0/fo/scan/?action=list"
            f"&launched_after_datetime={after}"
            "&show_status=1"
        )
        data = api_get(url, timeout=120)
        if not data:
            return []
        scans = []
        try:
            root = ET.fromstring(data)
            for scan in root.findall(".//SCAN"):
                s = {
                    "ref": scan.findtext("REF", ""),
                    "title": scan.findtext("TITLE", ""),
                    "status": scan.findtext("STATUS/STATE", ""),
                    "launch_datetime": scan.findtext("LAUNCH_DATETIME", ""),
                    "end_datetime": scan.findtext("END_DATETIME", ""),
                    "type": scan.findtext("TYPE", ""),
                    "target": scan.findtext("TARGET", ""),
                    "duration_hours": None,
                }
                # Calculate duration
                if s["launch_datetime"] and s["end_datetime"]:
                    try:
                        fmt = "%Y-%m-%dT%H:%M:%SZ"
                        start = datetime.strptime(s["launch_datetime"], fmt)
                        end = datetime.strptime(s["end_datetime"], fmt)
                        s["duration_hours"] = (end - start).total_seconds() / 3600
                    except (ValueError, TypeError):
                        pass
                scans.append(s)
        except ET.ParseError as e:
            _log(f"XML parse error in recent scans: {e}")
        return scans

    concurrent = _run_concurrent(
        schedules=fetch_schedules, recent_scans=fetch_recent_scans
    )
    schedules = concurrent.get("schedules") or []
    recent_scans = concurrent.get("recent_scans") or []

    result["schedules"] = schedules
    result["recent_scans"] = recent_scans

    # Analyze schedules
    active_schedules = [s for s in schedules if s.get("active")]
    if active_schedules:
        weekly_freqs = {"daily", "weekly"}
        result["all_weekly_or_better"] = all(
            s.get("frequency", "").lower() in weekly_freqs for s in active_schedules
        )
        result["uses_tags"] = any(
            s.get("target_type") == "tags_or_groups" for s in active_schedules
        )
        result["uses_ips_only"] = all(
            s.get("target_type") == "ip" for s in active_schedules
        )

    # Analyze durations from completed scans
    completed = [s for s in recent_scans if s.get("duration_hours") is not None]
    if completed:
        result["all_under_24h"] = all(s["duration_hours"] < 24 for s in completed)
        result["all_under_48h"] = all(s["duration_hours"] < 48 for s in completed)
        result["max_duration_hours"] = max(s["duration_hours"] for s in completed)
        result["avg_duration_hours"] = sum(
            s["duration_hours"] for s in completed
        ) / len(completed)

    _cache_set("scan_schedules", result)
    return result


def get_cloud_agents_status() -> dict:
    """Fetch Cloud Agent counts, versions, config profiles, and activation status.

    APIs: Gateway /rest/2.0/count/am/asset (total + agent counts via trackingMethod)
          Gateway /rest/2.0/search/am/asset (agent details via CSAM)
    """
    cached = _cache_get("cloud_agents")
    if cached is not None:
        return cached

    result = {
        "total_assets": 0,
        "agent_count": 0,
        "agent_percentage": 0.0,
        "latest_version": "",
        "outdated_agents": 0,
        "outdated_percentage": 0.0,
        "inventory_only_count": 0,
        "inventory_only_percentage": 0.0,
        "config_profiles": [],
        "auto_update_enabled": False,
        "has_custom_profiles": False,
    }

    def fetch_asset_counts():
        """Get total asset and agent counts from CSAM."""
        counts = {"total": 0, "agents": 0}
        count_url = f"{GATEWAY_URL}/rest/2.0/count/am/asset"
        # Total assets
        data = api_post(
            count_url,
            body="{}",
            gateway=True,
            content_type="application/json",
            timeout=60,
        )
        if data:
            try:
                j = json.loads(data)
                counts["total"] = j.get("count", 0)
            except (json.JSONDecodeError, KeyError):
                pass
        # Agent assets (trackingMethod=QAGENT)
        filter_body = json.dumps(
            {"filters": [{"field": "asset.trackingMethod", "operator": "EQUALS", "value": "QAGENT"}]}
        )
        data = api_post(
            count_url,
            body=filter_body,
            gateway=True,
            content_type="application/json",
            timeout=60,
        )
        if data:
            try:
                j = json.loads(data)
                counts["agents"] = j.get("count", 0)
            except (json.JSONDecodeError, KeyError):
                pass
        return counts

    def fetch_agent_details():
        """Get agent version and activation details from CSAM search."""
        details = {"agents": [], "versions": {}, "inventory_only": 0}
        url = (
            f"{GATEWAY_URL}/rest/2.0/search/am/asset"
            "?pageSize=100&includeFields=agentInfo"
        )
        filter_body = json.dumps(
            {"filters": [{"field": "asset.trackingMethod", "operator": "EQUALS", "value": "QAGENT"}]}
        )
        data = api_post(
            url,
            body=filter_body,
            gateway=True,
            content_type="application/json",
            timeout=180,
        )
        if not data:
            return details
        try:
            j = json.loads(data)
            assets = j.get("assetListData", {}).get("asset", [])
            for asset in assets:
                agent_info = asset.get("agent") or asset.get("agentInfo") or {}
                a = {
                    "id": str(asset.get("assetId", "")),
                    "name": asset.get("assetName") or asset.get("dnsName") or "",
                    "version": agent_info.get("version", "") if isinstance(agent_info, dict) else "",
                    "status": agent_info.get("status", "") if isinstance(agent_info, dict) else "",
                    "activated_for": agent_info.get("activatedModule", "") if isinstance(agent_info, dict) else "",
                }
                details["agents"].append(a)
                v = a["version"]
                if v:
                    details["versions"][v] = details["versions"].get(v, 0) + 1
                activated = (a.get("activated_for") or "").lower()
                if activated and "vm" not in activated and "vuln" not in activated:
                    details["inventory_only"] += 1
        except (json.JSONDecodeError, KeyError) as e:
            _log(f"JSON parse error in agent details: {e}")
        return details

    concurrent = _run_concurrent(
        counts=fetch_asset_counts,
        details=fetch_agent_details,
    )

    counts = concurrent.get("counts") or {"total": 0, "agents": 0}
    details = concurrent.get("details") or {"agents": [], "versions": {}, "inventory_only": 0}

    result["total_assets"] = counts.get("total", 0)
    result["agent_count"] = counts.get("agents", 0)
    if result["total_assets"] > 0:
        result["agent_percentage"] = (
            result["agent_count"] / result["total_assets"]
        ) * 100

    # Version analysis
    versions = details.get("versions", {})
    if versions:
        latest = max(versions.keys(), key=lambda v: [int(x) for x in v.split(".") if x.isdigit()] if v else [0])
        result["latest_version"] = latest
        total_agents = sum(versions.values())
        outdated = total_agents - versions.get(latest, 0)
        result["outdated_agents"] = outdated
        result["outdated_percentage"] = (outdated / total_agents * 100) if total_agents > 0 else 0

    # Inventory only
    agent_list = details.get("agents", [])
    result["inventory_only_count"] = details.get("inventory_only", 0)
    if agent_list:
        result["inventory_only_percentage"] = (
            result["inventory_only_count"] / len(agent_list) * 100
        )

    _cache_set("cloud_agents", result)
    return result


def get_tags_and_groups() -> dict:
    """Fetch tag hierarchy and asset groups with criticality info.

    APIs: Gateway /rest/2.0/search/am/tag
          /api/2.0/fo/asset/group/?action=list
    """
    cached = _cache_get("tags_and_groups")
    if cached is not None:
        return cached

    result = {
        "tags": [],
        "tag_count": 0,
        "has_hierarchy": False,
        "dynamic_tags": 0,
        "tags_with_criticality": 0,
        "tags_criticality_percentage": 0.0,
        "asset_groups": [],
        "groups_with_criticality": 0,
        "groups_criticality_percentage": 0.0,
    }

    def fetch_tags():
        """Get tags via QPS XML API (Basic Auth)."""
        all_tags = []
        last_id = 0
        while True:
            criteria = ""
            if last_id:
                criteria = f'<Criteria field="id" operator="GREATER">{last_id}</Criteria>'
            body = (
                "<ServiceRequest>"
                f"<filters>{criteria}</filters>"
                "<preferences><limitResults>500</limitResults></preferences>"
                "</ServiceRequest>"
            )
            url = f"{BASE_URL}/qps/rest/2.0/search/am/tag"
            data = api_post(
                url,
                body=body,
                content_type="text/xml",
                timeout=120,
            )
            if not data:
                break
            try:
                root = ET.fromstring(data)
                if root.findtext("responseCode") != "SUCCESS":
                    break
                tag_elements = root.findall(".//Tag")
                if not tag_elements:
                    break
                for t in tag_elements:
                    tag = {
                        "id": t.findtext("id", ""),
                        "name": t.findtext("name", ""),
                        "parent_id": t.findtext("parentTagId", ""),
                        "criticality_score": None,
                        "rule_type": t.findtext("ruleType", ""),
                        "color": t.findtext("color", ""),
                    }
                    crit = t.findtext("criticalityScore")
                    if crit is not None:
                        try:
                            tag["criticality_score"] = int(crit)
                        except ValueError:
                            pass
                    # Check for children (hierarchy indicator)
                    children = t.find("children")
                    tag["has_children"] = children is not None and len(children) > 0
                    all_tags.append(tag)
                has_more = root.findtext("hasMoreRecords", "false")
                new_last_id = root.findtext("lastId", "")
                if has_more.lower() != "true" or not new_last_id:
                    break
                last_id = new_last_id
            except ET.ParseError as e:
                _log(f"XML parse error in tags: {e}")
                break
        return all_tags

    def fetch_asset_groups():
        """Get asset groups with criticality."""
        url = f"{BASE_URL}/api/2.0/fo/asset/group/?action=list&truncation_limit=1000"
        data = api_get(url, timeout=90)
        if not data:
            return []
        groups = []
        try:
            root = ET.fromstring(data)
            for grp in root.findall(".//ASSET_GROUP"):
                g = {
                    "id": grp.findtext("ID", ""),
                    "title": grp.findtext("TITLE", ""),
                    "criticality": grp.findtext("CVSS_ENVIRO_CDP", ""),
                    "business_impact": grp.findtext("BUSINESS_IMPACT", ""),
                }
                groups.append(g)
        except ET.ParseError as e:
            _log(f"XML parse error in asset groups: {e}")
        return groups

    concurrent = _run_concurrent(tags=fetch_tags, groups=fetch_asset_groups)
    tags = concurrent.get("tags") or []
    groups = concurrent.get("groups") or []

    result["tags"] = tags
    result["tag_count"] = len(tags)

    # Hierarchy analysis
    parent_ids = {t["parent_id"] for t in tags if t.get("parent_id")}
    result["has_hierarchy"] = len(parent_ids) > 1  # More than just root

    # Dynamic tags
    result["dynamic_tags"] = sum(
        1 for t in tags
        if t.get("rule_type", "").lower() in ("dynamic", "groovy", "cloud_inventory")
    )

    # Criticality coverage for tags
    tags_with_crit = sum(
        1 for t in tags
        if t.get("criticality_score") is not None and t["criticality_score"] != 3
    )
    result["tags_with_criticality"] = tags_with_crit
    if tags:
        result["tags_criticality_percentage"] = tags_with_crit / len(tags) * 100

    # Asset groups
    result["asset_groups"] = groups
    groups_with_crit = sum(
        1 for g in groups
        if g.get("criticality") or g.get("business_impact")
    )
    result["groups_with_criticality"] = groups_with_crit
    if groups:
        result["groups_criticality_percentage"] = groups_with_crit / len(groups) * 100

    _cache_set("tags_and_groups", result)
    return result


def get_asset_tracking_config() -> dict:
    """Fetch asset tracking configuration: agentless tracking, merging, purge rules.

    APIs: /api/2.0/fo/asset/host/?action=list (tracking config)
          CSAM purge rules API
    """
    cached = _cache_get("asset_tracking")
    if cached is not None:
        return cached

    result = {
        "agentless_tracking": False,
        "unified_view": False,
        "purge_rules": [],
        "purge_enabled": False,
        "purge_terminated_instances": False,
        "purge_90_day_unscanned": False,
        "purge_30_day_unscanned": False,
        "ghost_host_count": 0,
        "ghost_host_percentage": 0.0,
    }

    def fetch_tracking_config():
        """Infer asset tracking settings from auth records."""
        config = {"agentless_tracking": False, "unified_view": False}
        # Check auth records for agentless tracking indicators
        # The USE_AGENTLESS_TRACKING field in auth records tells us
        for auth_type in ["windows", "unix"]:
            url = f"{BASE_URL}/api/2.0/fo/auth/{auth_type}/?action=list&details=All"
            data = api_get(url, timeout=60)
            if data:
                try:
                    root = ET.fromstring(data)
                    for rec in root.findall(f".//AUTH_{auth_type.upper()}"):
                        agentless = rec.findtext("USE_AGENTLESS_TRACKING", "0")
                        if agentless == "1":
                            config["agentless_tracking"] = True
                            break
                except ET.ParseError:
                    pass
            if config["agentless_tracking"]:
                break
        return config

    def fetch_ghost_hosts():
        """Count ghost/stale hosts using CSAM total and host list API."""
        counts = {"ghost": 0, "total": 0, "ip_tracked": 0}
        count_url = f"{GATEWAY_URL}/rest/2.0/count/am/asset"
        # Get total hosts
        data = api_post(
            count_url,
            body="{}",
            gateway=True,
            content_type="application/json",
            timeout=60,
        )
        if data:
            try:
                counts["total"] = json.loads(data).get("count", 0)
            except (json.JSONDecodeError, KeyError):
                pass
        # Get IP-tracked count (these are the ones that can become ghosts)
        filter_body = json.dumps(
            {"filters": [{"field": "asset.trackingMethod", "operator": "EQUALS", "value": "IP"}]}
        )
        data = api_post(
            count_url,
            body=filter_body,
            gateway=True,
            content_type="application/json",
            timeout=60,
        )
        if data:
            try:
                j = json.loads(data)
                if j.get("responseCode") == "SUCCESS":
                    counts["ip_tracked"] = j.get("count", 0)
            except (json.JSONDecodeError, KeyError):
                pass
        # Use classic host list to count stale hosts (not scanned in 30 days)
        stale_date = (datetime.now(timezone.utc) - timedelta(days=30)).strftime(
            "%Y-%m-%dT00:00:00Z"
        )
        host_url = (
            f"{BASE_URL}/api/2.0/fo/asset/host/"
            f"?action=list&details=Basic&no_vm_scan_since={stale_date}"
            "&truncation_limit=1"
        )
        data = api_get(host_url, timeout=60)
        if data:
            try:
                root = ET.fromstring(data)
                # Check for WARNING with truncation info for count
                warning = root.findtext(".//WARNING/TEXT", "")
                if "truncation" in warning.lower():
                    # Parse count from truncation warning
                    import re
                    m = re.search(r"(\d+)\s+record", warning)
                    if m:
                        counts["ghost"] = int(m.group(1))
                else:
                    # Count HOST elements directly
                    counts["ghost"] = len(root.findall(".//HOST"))
            except ET.ParseError:
                pass
        return counts

    concurrent = _run_concurrent(
        tracking=fetch_tracking_config,
        ghost=fetch_ghost_hosts,
    )

    tracking = concurrent.get("tracking") or {}
    ghost = concurrent.get("ghost") or {"ghost": 0, "total": 0}

    result["agentless_tracking"] = tracking.get("agentless_tracking", False)
    result["unified_view"] = tracking.get("unified_view", False)
    result["purge_rules"] = []
    result["purge_enabled"] = False

    # Ghost hosts
    result["ghost_host_count"] = ghost.get("ghost", 0)
    total = ghost.get("total", 0)
    if total > 0:
        result["ghost_host_percentage"] = result["ghost_host_count"] / total * 100

    _cache_set("asset_tracking", result)
    return result


def get_dashboard_info() -> dict:
    """Dashboard information for reporting questions.

    Note: Qualys does not expose a dashboard listing API. Dashboard/reporting
    questions are treated as MANUAL or HYBRID and answered by the TAM/user.
    This function returns a placeholder structure.
    """
    cached = _cache_get("dashboards")
    if cached is not None:
        return cached

    result = {
        "dashboards": [],
        "dashboard_count": 0,
        "custom_dashboard_count": 0,
        "has_hygiene_dashboard": False,
        "has_trurisk_dashboard": False,
        "api_available": False,
        "note": "Dashboard configuration is not available via API. These questions require manual verification by the TAM.",
    }

    _cache_set("dashboards", result)
    return result


def collect_all_data() -> dict:
    """Collect all healthcheck data concurrently. Returns dict keyed by data source."""
    _log("Collecting all healthcheck data...")
    data = _run_concurrent(
        option_profiles=get_option_profiles,
        auth_records=get_auth_records,
        scan_schedules=get_scan_schedules,
        cloud_agents=get_cloud_agents_status,
        tags_and_groups=get_tags_and_groups,
        asset_tracking=get_asset_tracking_config,
        dashboards=get_dashboard_info,
    )
    _log(f"Data collection complete. Got data for: {list(data.keys())}")
    return data
