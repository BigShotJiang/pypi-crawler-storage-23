"""Interactive Q&A handler for manual and hybrid healthcheck questions.

Manages the flow of asking the human/TAM for answers to questions
that can't be fully automated via API.
"""

from __future__ import annotations

from .models import QuestionMode, QuestionResult, Score
from .questions import QUESTIONS


def get_pending_questions(results: dict[str, QuestionResult]) -> list[dict]:
    """Return list of questions that still need manual input.

    Returns dicts with id, question, section, mode, and current evidence/hints.
    """
    pending = []
    for qid, q in QUESTIONS.items():
        if q.mode == QuestionMode.AUTO:
            continue

        result = results.get(qid)
        needs_answer = (
            result is None
            or result.score == Score.NOT_ANSWERED
        )
        if needs_answer:
            pending.append({
                "id": q.id,
                "question": q.question,
                "section": q.section.value,
                "area": q.area.value,
                "mode": q.mode.value,
                "navigation_hint": q.navigation,
                "current_evidence": result.evidence if result else "",
                "recommendation_if_fail": q.recommendation,
            })

    return pending


def format_pending_for_agent(results: dict[str, QuestionResult]) -> str:
    """Format pending questions as a prompt for the AI agent to ask."""
    pending = get_pending_questions(results)
    if not pending:
        return "All questions have been answered. No manual input needed."

    lines = [
        f"There are {len(pending)} questions that need manual input from the customer/TAM:",
        "",
    ]

    for i, pq in enumerate(pending, 1):
        lines.append(f"### {i}. [{pq['id']}] {pq['question']}")
        lines.append(f"   Section: {pq['section']} ({pq['area']})")
        if pq["current_evidence"]:
            lines.append(f"   Hint: {pq['current_evidence']}")
        lines.append(f"   Answer: Yes (compliant=1) or No (non-compliant=0)")
        lines.append("")

    lines.append(
        "For each question, provide the question ID, whether it's compliant (yes/no), "
        "and any notes."
    )
    return "\n".join(lines)


def parse_manual_answers(answer_text: str) -> list[dict]:
    """Parse a block of manual answers into structured form.

    Accepts formats like:
    - AUTH-07: yes
    - SCAN-05: no, customer doesn't have this process
    - TRURISK-02: 1
    - TRURISK-03: 0, they use ServiceNow
    """
    answers = []
    for line in answer_text.strip().split("\n"):
        line = line.strip()
        if not line or line.startswith("#"):
            continue

        # Try to parse "ID: answer [, notes]"
        if ":" in line:
            parts = line.split(":", 1)
            qid = parts[0].strip().upper()
            rest = parts[1].strip()

            # Check if question ID is valid
            if qid not in QUESTIONS:
                continue

            # Parse answer and optional notes
            if "," in rest:
                answer_part, notes = rest.split(",", 1)
                notes = notes.strip()
            else:
                answer_part = rest
                notes = ""

            answer_part = answer_part.strip().lower()
            compliant = answer_part in ("yes", "1", "true", "pass", "compliant", "y")

            answers.append({
                "question_id": qid,
                "compliant": compliant,
                "notes": notes,
            })

    return answers
