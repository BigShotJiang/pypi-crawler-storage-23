"""Evaluation engine for the 44-question VMDR healthcheck.

Each question has a corresponding eval_* method that examines API data
and returns a QuestionResult with score, evidence, and details.
"""

from __future__ import annotations

from datetime import datetime, timezone

from .models import (
    HealthcheckState,
    Question,
    QuestionMode,
    QuestionResult,
    Score,
)
from .questions import QUESTIONS, QUESTION_ORDER
from . import heuristics
from . import qualys_api


class HealthcheckEvaluator:
    """Runs all 44 healthcheck evaluations against collected API data."""

    def __init__(self, state: HealthcheckState | None = None):
        self.state = state or HealthcheckState()

    def collect_data(self) -> dict:
        """Collect all API data and cache in state."""
        self.state.api_data = qualys_api.collect_all_data()
        self.state.started_at = datetime.now(timezone.utc).isoformat()
        return self.state.api_data

    def evaluate_all(self) -> dict[str, QuestionResult]:
        """Run all evaluations. Collects data first if not already cached."""
        if not self.state.api_data:
            self.collect_data()

        for qid in QUESTION_ORDER:
            q = QUESTIONS[qid]
            if q.mode == QuestionMode.MANUAL:
                # Manual questions start as NOT_ANSWERED
                if qid not in self.state.results:
                    self.state.results[qid] = QuestionResult(
                        question_id=qid,
                        score=Score.NOT_ANSWERED,
                        evidence="Requires manual input from customer/TAM.",
                    )
                continue

            # Run the evaluation function
            eval_fn = getattr(self, q.eval_function, None)
            if eval_fn:
                try:
                    result = eval_fn(self.state.api_data)
                    self.state.results[qid] = result
                except Exception as e:
                    self.state.results[qid] = QuestionResult(
                        question_id=qid,
                        score=Score.NOT_APPLICABLE,
                        evidence=f"Evaluation error: {e}",
                        api_error=True,
                    )
            else:
                self.state.results[qid] = QuestionResult(
                    question_id=qid,
                    score=Score.NOT_APPLICABLE,
                    evidence=f"No evaluation function: {q.eval_function}",
                )

        return self.state.results

    def submit_manual_answer(
        self, question_id: str, compliant: bool, notes: str = ""
    ) -> QuestionResult:
        """Record a manual answer for a manual/hybrid question."""
        result = QuestionResult(
            question_id=question_id,
            score=Score.PASS if compliant else Score.FAIL,
            evidence=f"Manual assessment: {'Compliant' if compliant else 'Non-compliant'}",
            notes=notes,
        )
        self.state.results[question_id] = result
        return result

    # ─── AUTH evaluations ─────────────────────────────────────────────────

    def eval_auth_01(self, data: dict) -> QuestionResult:
        """AUTH-01: Authenticated scans in option profiles?"""
        profiles = data.get("option_profiles") or []
        if not profiles:
            return QuestionResult(
                question_id="AUTH-01",
                score=Score.NOT_APPLICABLE,
                evidence="No option profiles found.",
                api_error=True,
            )
        auth_profiles = [p for p in profiles if p.get("auth_enabled")]
        total = len(profiles)
        auth_count = len(auth_profiles)

        if auth_count == total:
            score = Score.PASS
            evidence = f"All {total} option profiles have authentication enabled."
        elif auth_count > 0:
            score = Score.PARTIAL
            evidence = f"{auth_count}/{total} option profiles have authentication enabled."
        else:
            score = Score.FAIL
            evidence = "No option profiles have authentication enabled."

        return QuestionResult(
            question_id="AUTH-01",
            score=score,
            evidence=evidence,
            details={"total": total, "auth_enabled": auth_count},
        )

    def eval_auth_02(self, data: dict) -> QuestionResult:
        """AUTH-02: Auth failure rate < 10%? (Hybrid - may need dashboard data)"""
        # This is a hybrid question - we can check auth records for indicators
        # but the actual failure rate typically comes from dashboard/scan results
        auth = data.get("auth_records") or {}
        total = auth.get("total", 0)
        in_use = auth.get("in_use", 0)

        if total == 0:
            return QuestionResult(
                question_id="AUTH-02",
                score=Score.NOT_ANSWERED,
                evidence=(
                    "No auth records found. Please check the dashboard for "
                    "authentication failure rates and provide manual input."
                ),
            )

        # We can't directly calculate failure rate from auth records alone
        # Mark as hybrid - needs manual confirmation
        return QuestionResult(
            question_id="AUTH-02",
            score=Score.NOT_ANSWERED,
            evidence=(
                f"Found {total} auth records ({in_use} in use). "
                "Authentication failure rate must be verified from dashboard. "
                "Please check dashboard for both Windows and Linux failure rates."
            ),
            details={"total": total, "in_use": in_use},
        )

    def eval_auth_03(self, data: dict) -> QuestionResult:
        """AUTH-03: Unused auth records < 20%?"""
        auth = data.get("auth_records") or {}
        total = auth.get("total", 0)
        in_use = auth.get("in_use", 0)

        if total == 0:
            return QuestionResult(
                question_id="AUTH-03",
                score=Score.NOT_APPLICABLE,
                evidence="No auth records found.",
            )

        unused = total - in_use
        unused_pct = (unused / total) * 100
        ok = heuristics.unused_auth_records_ok(total, in_use)

        return QuestionResult(
            question_id="AUTH-03",
            score=Score.PASS if ok else Score.FAIL,
            evidence=f"{unused}/{total} auth records unused ({unused_pct:.1f}%). "
            + ("Under 20% threshold." if ok else "Exceeds 20% threshold."),
            details={"total": total, "in_use": in_use, "unused": unused, "unused_pct": unused_pct},
        )

    def eval_auth_04(self, data: dict) -> QuestionResult:
        """AUTH-04: Windows using domain (not local) auth?
        Auto-scorable: we can check DOMAIN element and IP_SET in auth records.
        """
        auth = data.get("auth_records") or {}
        win = auth.get("windows", [])

        if not win:
            return QuestionResult(
                question_id="AUTH-04",
                score=Score.NOT_APPLICABLE,
                evidence="No Windows auth records found.",
            )

        domain_count = auth.get("domain_windows", 0)
        local_count = auth.get("local_windows", 0)
        total_win = len(win)

        if domain_count == total_win:
            score = Score.PASS
            evidence = f"All {total_win} Windows auth records use domain authentication."
        elif domain_count > local_count:
            score = Score.PARTIAL
            evidence = f"{domain_count}/{total_win} Windows auth records use domain auth, {local_count} use local."
        else:
            score = Score.FAIL
            evidence = f"Only {domain_count}/{total_win} Windows auth records use domain auth. {local_count} use local auth."

        return QuestionResult(
            question_id="AUTH-04",
            score=score,
            evidence=evidence,
            details={"total_windows": total_win, "domain": domain_count, "local": local_count},
        )

    def eval_auth_05(self, data: dict) -> QuestionResult:
        """AUTH-05: Linux tag-based auth enabled?"""
        auth = data.get("auth_records") or {}
        unix = auth.get("unix", [])

        if not unix:
            return QuestionResult(
                question_id="AUTH-05",
                score=Score.NOT_APPLICABLE,
                evidence="No Unix/Linux auth records found.",
            )

        tag_based = auth.get("tag_based_unix", 0)
        total_unix = len(unix)

        if tag_based > 0:
            score = Score.PASS if tag_based == total_unix else Score.PARTIAL
            evidence = f"{tag_based}/{total_unix} Unix auth records use tag-based authentication."
        else:
            score = Score.FAIL
            evidence = "No Unix auth records use tag-based authentication."

        return QuestionResult(
            question_id="AUTH-05",
            score=score,
            evidence=evidence,
            details={"total_unix": total_unix, "tag_based": tag_based},
        )

    def eval_auth_06(self, data: dict) -> QuestionResult:
        """AUTH-06: Auth vault in use?
        Auto-scorable: VAULT element presence in auth record XML.
        """
        auth = data.get("auth_records") or {}
        vault_count = auth.get("vault_count", 0)
        total = auth.get("total", 0)

        if total == 0:
            return QuestionResult(
                question_id="AUTH-06",
                score=Score.NOT_APPLICABLE,
                evidence="No auth records found.",
            )

        if vault_count > 0:
            score = Score.PASS
            evidence = f"{vault_count}/{total} auth records use vault integration."
        else:
            score = Score.FAIL
            evidence = "No auth records use vault integration. Static passwords detected."

        return QuestionResult(
            question_id="AUTH-06",
            score=score,
            evidence=evidence,
            details={"vault_count": vault_count, "total": total},
        )

    def eval_auth_07(self, data: dict) -> QuestionResult:
        """AUTH-07: Non-auth scans only for external/PCI?
        Auto-check: look for external/PCI scans and verify their option profiles
        don't have auth enabled.
        """
        scans = data.get("scan_schedules") or {}
        schedules = scans.get("schedules", [])
        profiles = data.get("option_profiles") or []

        # Build profile lookup by title
        profile_map = {p.get("title", "").lower(): p for p in profiles}

        external_scans = [
            s for s in schedules
            if s.get("active") and any(
                kw in (s.get("title") or "").lower()
                for kw in ("external", "pci", "perimeter", "outside")
            )
        ]

        if not external_scans:
            return QuestionResult(
                question_id="AUTH-07",
                score=Score.NOT_ANSWERED,
                evidence="No external/PCI scans detected in schedules. Confirm with customer.",
            )

        # Check if their option profiles have auth disabled
        auth_external = []
        noauth_external = []
        for s in external_scans:
            op_title = (s.get("option_profile") or "").lower()
            profile = profile_map.get(op_title, {})
            if profile.get("auth_enabled"):
                auth_external.append(s["title"])
            else:
                noauth_external.append(s["title"])

        if not auth_external:
            score = Score.PASS
            evidence = (
                f"Found {len(external_scans)} external/PCI scan(s), "
                "all using non-authenticated option profiles."
            )
        else:
            score = Score.FAIL
            evidence = (
                f"{len(auth_external)} external/PCI scan(s) use authenticated profiles: "
                + ", ".join(auth_external[:5])
            )

        return QuestionResult(
            question_id="AUTH-07",
            score=score,
            evidence=evidence,
            details={
                "external_scans": len(external_scans),
                "auth_enabled": auth_external,
                "no_auth": noauth_external,
            },
        )

    # ─── SCAN evaluations ────────────────────────────────────────────────

    def eval_scan_01(self, data: dict) -> QuestionResult:
        """SCAN-01: Scans by tags/groups (not raw IPs)?"""
        scans = data.get("scan_schedules") or {}
        schedules = scans.get("schedules", [])
        active = [s for s in schedules if s.get("active")]

        if not active:
            return QuestionResult(
                question_id="SCAN-01",
                score=Score.NOT_APPLICABLE,
                evidence="No active scan schedules found.",
                api_error=True,
            )

        tag_group = sum(1 for s in active if s.get("target_type") == "tags_or_groups")
        ip_only = sum(1 for s in active if s.get("target_type") == "ip")
        total = len(active)

        if tag_group == total:
            score = Score.PASS
            evidence = f"All {total} active scans use tags or asset groups for targeting."
        elif tag_group > ip_only:
            score = Score.PARTIAL
            evidence = f"{tag_group}/{total} scans use tags/groups, {ip_only} use raw IPs."
        else:
            score = Score.FAIL
            evidence = f"Only {tag_group}/{total} scans use tags/groups. {ip_only} use raw IPs."

        return QuestionResult(
            question_id="SCAN-01",
            score=score,
            evidence=evidence,
            details={"total": total, "tags_groups": tag_group, "ip_only": ip_only},
        )

    def eval_scan_02(self, data: dict) -> QuestionResult:
        """SCAN-02: Lightweight authenticated discovery scans?
        Auto-check: look for discovery/map profiles in option profiles and scan schedules.
        """
        profiles = data.get("option_profiles") or []
        scans = data.get("scan_schedules") or {}
        schedules = scans.get("schedules", [])

        # Look for discovery-type profiles by name
        discovery_keywords = ("discovery", "lightweight", "map", "inventory", "host discovery")
        discovery_profiles = [
            p for p in profiles
            if any(kw in (p.get("title") or "").lower() for kw in discovery_keywords)
        ]

        # Also check scan schedule titles for discovery scans
        discovery_scans = [
            s for s in schedules
            if s.get("active") and any(
                kw in (s.get("title") or "").lower() for kw in discovery_keywords
            )
        ]

        if discovery_profiles or discovery_scans:
            items = [p["title"] for p in discovery_profiles] + [s["title"] for s in discovery_scans]
            return QuestionResult(
                question_id="SCAN-02",
                score=Score.PASS,
                evidence=f"Found discovery scan configuration: " + ", ".join(set(items)),
                details={"profiles": [p["title"] for p in discovery_profiles],
                         "scans": [s["title"] for s in discovery_scans]},
            )

        return QuestionResult(
            question_id="SCAN-02",
            score=Score.FAIL,
            evidence="No discovery scan profiles or scheduled discovery scans found.",
        )

    def eval_scan_03(self, data: dict) -> QuestionResult:
        """SCAN-03: Perimeter scan every 24h / EASM? (Hybrid)"""
        scans = data.get("scan_schedules") or {}
        schedules = scans.get("schedules", [])

        # Look for perimeter/external scans with daily frequency
        perimeter = [
            s for s in schedules
            if s.get("active") and (
                "perimeter" in (s.get("title") or "").lower()
                or "external" in (s.get("title") or "").lower()
                or "easm" in (s.get("title") or "").lower()
            )
        ]

        daily_perimeter = [
            s for s in perimeter
            if s.get("frequency", "").lower() in ("daily", "every_day")
        ]

        if daily_perimeter:
            return QuestionResult(
                question_id="SCAN-03",
                score=Score.PASS,
                evidence=f"Found {len(daily_perimeter)} daily perimeter/external scan(s).",
                details={"perimeter_scans": [s["title"] for s in daily_perimeter]},
            )

        if perimeter:
            return QuestionResult(
                question_id="SCAN-03",
                score=Score.PARTIAL,
                evidence=f"Found {len(perimeter)} perimeter scan(s) but not all run daily.",
            )

        return QuestionResult(
            question_id="SCAN-03",
            score=Score.FAIL,
            evidence="No perimeter/external scans detected in scan schedules.",
        )

    def eval_scan_04(self, data: dict) -> QuestionResult:
        """SCAN-04: All scans at least weekly?"""
        scans = data.get("scan_schedules") or {}
        schedules = scans.get("schedules", [])
        active = [s for s in schedules if s.get("active")]

        if not active:
            return QuestionResult(
                question_id="SCAN-04",
                score=Score.NOT_APPLICABLE,
                evidence="No active scan schedules found.",
                api_error=True,
            )

        weekly_ok = []
        not_weekly = []
        for s in active:
            freq = (s.get("frequency") or "").lower()
            if heuristics.scan_frequency_weekly_or_better(freq):
                weekly_ok.append(s)
            else:
                not_weekly.append(s)

        if not not_weekly:
            score = Score.PASS
            evidence = f"All {len(active)} active scans run weekly or more frequently."
        elif len(weekly_ok) > len(not_weekly):
            score = Score.PARTIAL
            evidence = (
                f"{len(weekly_ok)}/{len(active)} scans run weekly+. "
                f"{len(not_weekly)} run less frequently: "
                + ", ".join(f"{s['title']} ({s['frequency']})" for s in not_weekly[:5])
            )
        else:
            score = Score.FAIL
            evidence = f"Only {len(weekly_ok)}/{len(active)} scans run at least weekly."

        return QuestionResult(
            question_id="SCAN-04",
            score=score,
            evidence=evidence,
            details={"total": len(active), "weekly_ok": len(weekly_ok), "not_weekly": len(not_weekly)},
        )

    def eval_scan_05(self, data: dict) -> QuestionResult:
        """SCAN-05: Emergency zero-day scan process? (Manual)"""
        return QuestionResult(
            question_id="SCAN-05",
            score=Score.NOT_ANSWERED,
            evidence="Ask customer: Do they have a process for emergency scans targeting specific QIDs/zero-days?",
        )

    def eval_scan_06(self, data: dict) -> QuestionResult:
        """SCAN-06: All scans complete < 24h?"""
        scans = data.get("scan_schedules") or {}
        recent = scans.get("recent_scans", [])
        completed = [s for s in recent if s.get("duration_hours") is not None]

        if not completed:
            return QuestionResult(
                question_id="SCAN-06",
                score=Score.NOT_APPLICABLE,
                evidence="No completed scans with duration data found.",
                api_error=True,
            )

        over_24h = [s for s in completed if s["duration_hours"] >= 24]
        all_ok = scans.get("all_under_24h", False)

        if all_ok:
            max_h = max(s["duration_hours"] for s in completed)
            score = Score.PASS
            evidence = f"All {len(completed)} recent scans completed under 24h (max: {max_h:.1f}h)."
        elif len(over_24h) <= len(completed) * 0.1:
            score = Score.PARTIAL
            evidence = f"{len(over_24h)}/{len(completed)} scans exceeded 24h."
        else:
            score = Score.FAIL
            evidence = f"{len(over_24h)}/{len(completed)} scans exceeded 24h."

        return QuestionResult(
            question_id="SCAN-06",
            score=score,
            evidence=evidence,
            details={
                "total_completed": len(completed),
                "over_24h": len(over_24h),
                "max_hours": max(s["duration_hours"] for s in completed) if completed else 0,
            },
        )

    def eval_scan_07(self, data: dict) -> QuestionResult:
        """SCAN-07: All scans complete < 48h?"""
        scans = data.get("scan_schedules") or {}
        recent = scans.get("recent_scans", [])
        completed = [s for s in recent if s.get("duration_hours") is not None]

        if not completed:
            return QuestionResult(
                question_id="SCAN-07",
                score=Score.NOT_APPLICABLE,
                evidence="No completed scans with duration data found.",
                api_error=True,
            )

        over_48h = [s for s in completed if s["duration_hours"] >= 48]
        all_ok = scans.get("all_under_48h", False)

        if all_ok:
            score = Score.PASS
            evidence = f"All {len(completed)} recent scans completed under 48h."
        else:
            score = Score.FAIL
            evidence = f"{len(over_48h)}/{len(completed)} scans exceeded 48h."

        return QuestionResult(
            question_id="SCAN-07",
            score=score,
            evidence=evidence,
            details={"total_completed": len(completed), "over_48h": len(over_48h)},
        )

    def eval_scan_08(self, data: dict) -> QuestionResult:
        """SCAN-08: Full port scans TCP+UDP in profiles?"""
        profiles = data.get("option_profiles") or []
        if not profiles:
            return QuestionResult(
                question_id="SCAN-08",
                score=Score.NOT_APPLICABLE,
                evidence="No option profiles found.",
                api_error=True,
            )

        adequate = []
        inadequate = []
        for p in profiles:
            tcp = p.get("tcp_ports", "")
            udp = p.get("udp_ports", "")
            if heuristics.port_scan_adequate(tcp, udp):
                adequate.append(p)
            else:
                inadequate.append(p)

        total = len(profiles)
        if not inadequate:
            score = Score.PASS
            evidence = f"All {total} option profiles use standard/full TCP+UDP port scans."
        elif len(adequate) > len(inadequate):
            score = Score.PARTIAL
            evidence = (
                f"{len(adequate)}/{total} profiles have adequate port scanning. "
                f"Profiles needing update: "
                + ", ".join(p["title"] for p in inadequate[:5])
            )
        else:
            score = Score.FAIL
            evidence = f"Only {len(adequate)}/{total} profiles have adequate TCP+UDP port scanning."

        return QuestionResult(
            question_id="SCAN-08",
            score=score,
            evidence=evidence,
            details={"total": total, "adequate": len(adequate), "inadequate": len(inadequate)},
        )

    def eval_scan_09(self, data: dict) -> QuestionResult:
        """SCAN-09: Normal+ parallel scaling in profiles?"""
        profiles = data.get("option_profiles") or []
        if not profiles:
            return QuestionResult(
                question_id="SCAN-09",
                score=Score.NOT_APPLICABLE,
                evidence="No option profiles found.",
                api_error=True,
            )

        adequate = []
        inadequate = []
        for p in profiles:
            scaling = p.get("parallel_scaling", "")
            if heuristics.parallel_scaling_adequate(scaling):
                adequate.append(p)
            else:
                inadequate.append(p)

        total = len(profiles)
        if not inadequate:
            score = Score.PASS
            evidence = f"All {total} profiles use normal or better parallel scaling."
        elif len(adequate) > len(inadequate):
            score = Score.PARTIAL
            evidence = f"{len(adequate)}/{total} profiles have adequate parallel scaling."
        else:
            score = Score.FAIL
            evidence = f"Only {len(adequate)}/{total} profiles have adequate parallel scaling."

        return QuestionResult(
            question_id="SCAN-09",
            score=score,
            evidence=evidence,
            details={"total": total, "adequate": len(adequate)},
        )

    def eval_scan_10(self, data: dict) -> QuestionResult:
        """SCAN-10: Ignore firewall TCP/RST in profiles?"""
        profiles = data.get("option_profiles") or []
        if not profiles:
            return QuestionResult(
                question_id="SCAN-10",
                score=Score.NOT_APPLICABLE,
                evidence="No option profiles found.",
                api_error=True,
            )

        enabled = [p for p in profiles if p.get("ignore_firewall_rst")]
        total = len(profiles)

        if len(enabled) == total:
            score = Score.PASS
            evidence = f"All {total} profiles ignore firewall TCP/RST packets."
        elif enabled:
            score = Score.PARTIAL
            evidence = f"{len(enabled)}/{total} profiles ignore firewall TCP/RST packets."
        else:
            score = Score.FAIL
            evidence = "No profiles configured to ignore firewall TCP/RST packets."

        return QuestionResult(
            question_id="SCAN-10",
            score=score,
            evidence=evidence,
            details={"total": total, "rst_ignored": len(enabled)},
        )

    def eval_scan_11(self, data: dict) -> QuestionResult:
        """SCAN-11: Ghost hosts < 10%?"""
        tracking = data.get("asset_tracking") or {}
        ghost_pct = tracking.get("ghost_host_percentage", 0)
        ghost_count = tracking.get("ghost_host_count", 0)

        ok = heuristics.ghost_hosts_ok(ghost_pct)

        return QuestionResult(
            question_id="SCAN-11",
            score=Score.PASS if ok else Score.FAIL,
            evidence=(
                f"Ghost hosts: {ghost_count} ({ghost_pct:.1f}% of total). "
                + ("Under 10% threshold." if ok else "Exceeds 10% threshold.")
            ),
            details={"ghost_count": ghost_count, "ghost_percentage": ghost_pct},
        )

    # ─── AGENT HEALTH evaluations ────────────────────────────────────────

    def eval_aghlth_01(self, data: dict) -> QuestionResult:
        """AGHLTH-01: Agentless tracking enabled?"""
        tracking = data.get("asset_tracking") or {}
        enabled = tracking.get("agentless_tracking", False)

        return QuestionResult(
            question_id="AGHLTH-01",
            score=Score.PASS if enabled else Score.FAIL,
            evidence="Agentless tracking is " + ("enabled." if enabled else "not enabled."),
        )

    def eval_aghlth_02(self, data: dict) -> QuestionResult:
        """AGHLTH-02: Asset Merging = Unified View?"""
        tracking = data.get("asset_tracking") or {}
        unified = tracking.get("unified_view", False)

        return QuestionResult(
            question_id="AGHLTH-02",
            score=Score.PASS if unified else Score.FAIL,
            evidence="Asset merging is " + ("set to Unified View." if unified else "not set to Unified View."),
        )

    def eval_aghlth_03(self, data: dict) -> QuestionResult:
        """AGHLTH-03: Agent scan merging enabled?"""
        agents = data.get("cloud_agents") or {}
        merge = agents.get("scan_merge_enabled", False)

        return QuestionResult(
            question_id="AGHLTH-03",
            score=Score.PASS if merge else Score.FAIL,
            evidence="Agent scan merging is " + ("enabled." if merge else "not enabled."),
        )

    def eval_aghlth_04(self, data: dict) -> QuestionResult:
        """AGHLTH-04: Cloud Agents on 50%+ of assets?"""
        agents = data.get("cloud_agents") or {}
        pct = agents.get("agent_percentage", 0)
        count = agents.get("agent_count", 0)
        total = agents.get("total_assets", 0)

        ok = heuristics.agent_coverage_met(pct, 50)
        return QuestionResult(
            question_id="AGHLTH-04",
            score=Score.PASS if ok else Score.FAIL,
            evidence=f"Agent coverage: {count}/{total} assets ({pct:.1f}%). "
            + ("Meets 50% threshold." if ok else "Below 50% threshold."),
            details={"agent_count": count, "total_assets": total, "percentage": pct},
        )

    def eval_aghlth_05(self, data: dict) -> QuestionResult:
        """AGHLTH-05: Cloud Agents on 75%+ of assets?"""
        agents = data.get("cloud_agents") or {}
        pct = agents.get("agent_percentage", 0)

        ok = heuristics.agent_coverage_met(pct, 75)
        return QuestionResult(
            question_id="AGHLTH-05",
            score=Score.PASS if ok else Score.FAIL,
            evidence=f"Agent coverage: {pct:.1f}%. "
            + ("Meets 75% threshold." if ok else "Below 75% threshold."),
            details={"percentage": pct},
        )

    def eval_aghlth_06(self, data: dict) -> QuestionResult:
        """AGHLTH-06: Cloud Agents on 90%+ of assets?"""
        agents = data.get("cloud_agents") or {}
        pct = agents.get("agent_percentage", 0)

        ok = heuristics.agent_coverage_met(pct, 90)
        return QuestionResult(
            question_id="AGHLTH-06",
            score=Score.PASS if ok else Score.FAIL,
            evidence=f"Agent coverage: {pct:.1f}%. "
            + ("Meets 90% threshold." if ok else "Below 90% threshold."),
            details={"percentage": pct},
        )

    def eval_aghlth_07(self, data: dict) -> QuestionResult:
        """AGHLTH-07: More than initial CA config profile?"""
        agents = data.get("cloud_agents") or {}
        has_custom = agents.get("has_custom_profiles", False)
        profiles = agents.get("config_profiles", [])

        if has_custom:
            custom = [p for p in profiles if not p.get("is_default")]
            score = Score.PASS
            evidence = f"Found {len(custom)} custom configuration profile(s) beyond initial."
        else:
            score = Score.FAIL
            evidence = "Only the initial/default configuration profile exists."

        return QuestionResult(
            question_id="AGHLTH-07",
            score=score,
            evidence=evidence,
            details={"profiles": [p.get("name") for p in profiles]},
        )

    def eval_aghlth_08(self, data: dict) -> QuestionResult:
        """AGHLTH-08: CA auto-update enabled?"""
        agents = data.get("cloud_agents") or {}
        auto = agents.get("auto_update_enabled", False)

        return QuestionResult(
            question_id="AGHLTH-08",
            score=Score.PASS if auto else Score.FAIL,
            evidence="Agent auto-update is " + ("enabled." if auto else "not enabled."),
        )

    def eval_aghlth_09(self, data: dict) -> QuestionResult:
        """AGHLTH-09: <=5% agents on old version?"""
        agents = data.get("cloud_agents") or {}
        outdated_pct = agents.get("outdated_percentage", 0)
        outdated = agents.get("outdated_agents", 0)
        latest = agents.get("latest_version", "unknown")

        ok = heuristics.outdated_agents_ok(outdated_pct)
        return QuestionResult(
            question_id="AGHLTH-09",
            score=Score.PASS if ok else Score.FAIL,
            evidence=(
                f"Outdated agents: {outdated} ({outdated_pct:.1f}%). "
                f"Latest version: {latest}. "
                + ("Within 5% threshold." if ok else "Exceeds 5% threshold.")
            ),
            details={"outdated": outdated, "outdated_pct": outdated_pct, "latest": latest},
        )

    def eval_aghlth_10(self, data: dict) -> QuestionResult:
        """AGHLTH-10: <=5% agents inventory-only?"""
        agents = data.get("cloud_agents") or {}
        inv_pct = agents.get("inventory_only_percentage", 0)
        inv_count = agents.get("inventory_only_count", 0)

        ok = heuristics.inventory_only_ok(inv_pct)
        return QuestionResult(
            question_id="AGHLTH-10",
            score=Score.PASS if ok else Score.FAIL,
            evidence=(
                f"Inventory-only agents: {inv_count} ({inv_pct:.1f}%). "
                + ("Within 5% threshold." if ok else "Exceeds 5% threshold.")
            ),
            details={"inventory_only": inv_count, "percentage": inv_pct},
        )

    # ─── TAG evaluations ─────────────────────────────────────────────────

    def eval_tag_01(self, data: dict) -> QuestionResult:
        """TAG-01: Tags have hierarchy (not flat)?"""
        tags_data = data.get("tags_and_groups") or {}
        tags = tags_data.get("tags", [])
        has_hierarchy = tags_data.get("has_hierarchy", False)

        if not tags:
            return QuestionResult(
                question_id="TAG-01",
                score=Score.NOT_APPLICABLE,
                evidence="No tags found.",
                api_error=True,
            )

        return QuestionResult(
            question_id="TAG-01",
            score=Score.PASS if has_hierarchy else Score.FAIL,
            evidence=(
                f"Found {len(tags)} tags. "
                + ("Tags have hierarchical grouping." if has_hierarchy else "Tags are flat (top-level only).")
            ),
            details={"tag_count": len(tags), "has_hierarchy": has_hierarchy},
        )

    def eval_tag_02(self, data: dict) -> QuestionResult:
        """TAG-02: Criticality on 90% of tags?"""
        tags_data = data.get("tags_and_groups") or {}
        pct = tags_data.get("tags_criticality_percentage", 0)
        count = tags_data.get("tags_with_criticality", 0)
        total = tags_data.get("tag_count", 0)

        ok = heuristics.criticality_coverage_ok(pct)
        return QuestionResult(
            question_id="TAG-02",
            score=Score.PASS if ok else Score.FAIL,
            evidence=(
                f"Tags with non-default criticality: {count}/{total} ({pct:.1f}%). "
                + ("Meets 90% threshold." if ok else "Below 90% threshold.")
            ),
            details={"with_criticality": count, "total": total, "percentage": pct},
        )

    def eval_tag_03(self, data: dict) -> QuestionResult:
        """TAG-03: Criticality on 90% of asset groups?"""
        tags_data = data.get("tags_and_groups") or {}
        groups = tags_data.get("asset_groups", [])
        pct = tags_data.get("groups_criticality_percentage", 0)
        count = tags_data.get("groups_with_criticality", 0)

        if not groups:
            return QuestionResult(
                question_id="TAG-03",
                score=Score.NOT_APPLICABLE,
                evidence="No asset groups found.",
            )

        ok = heuristics.criticality_coverage_ok(pct)
        return QuestionResult(
            question_id="TAG-03",
            score=Score.PASS if ok else Score.FAIL,
            evidence=(
                f"Asset groups with criticality: {count}/{len(groups)} ({pct:.1f}%). "
                + ("Meets 90% threshold." if ok else "Below 90% threshold.")
            ),
            details={"with_criticality": count, "total": len(groups), "percentage": pct},
        )

    def eval_tag_04(self, data: dict) -> QuestionResult:
        """TAG-04: Reasonable tag count for account?"""
        tags_data = data.get("tags_and_groups") or {}
        tag_count = tags_data.get("tag_count", 0)
        agents = data.get("cloud_agents") or {}
        asset_count = agents.get("total_assets", 0)

        ok, reason = heuristics.reasonable_tag_count(tag_count, asset_count)
        return QuestionResult(
            question_id="TAG-04",
            score=Score.PASS if ok else Score.FAIL,
            evidence=reason,
            details={"tag_count": tag_count, "asset_count": asset_count},
        )

    def eval_tag_05(self, data: dict) -> QuestionResult:
        """TAG-05: Dynamic inventory tags in use?"""
        tags_data = data.get("tags_and_groups") or {}
        dynamic = tags_data.get("dynamic_tags", 0)
        total = tags_data.get("tag_count", 0)

        if dynamic > 0:
            score = Score.PASS
            evidence = f"{dynamic}/{total} tags are dynamic/inventory-based."
        else:
            score = Score.FAIL
            evidence = "No dynamic inventory-based tags found."

        return QuestionResult(
            question_id="TAG-05",
            score=score,
            evidence=evidence,
            details={"dynamic_tags": dynamic, "total_tags": total},
        )

    # ─── PURGE evaluations ───────────────────────────────────────────────

    def eval_purge_01(self, data: dict) -> QuestionResult:
        """PURGE-01: Purge rules enabled?"""
        tracking = data.get("asset_tracking") or {}
        enabled = tracking.get("purge_enabled", False)
        rules = tracking.get("purge_rules", [])

        if enabled:
            active = sum(1 for r in rules if r.get("enabled"))
            score = Score.PASS
            evidence = f"Purge rules are enabled ({active} active rule(s))."
        else:
            score = Score.FAIL
            evidence = "No purge rules are enabled."

        return QuestionResult(
            question_id="PURGE-01",
            score=score,
            evidence=evidence,
            details={"rules": len(rules), "active": sum(1 for r in rules if r.get("enabled"))},
        )

    def eval_purge_02(self, data: dict) -> QuestionResult:
        """PURGE-02: Purge rules configured?"""
        tracking = data.get("asset_tracking") or {}
        rules = tracking.get("purge_rules", [])

        if rules:
            score = Score.PASS
            evidence = f"Found {len(rules)} configured purge rule(s)."
        else:
            score = Score.FAIL
            evidence = "No purge rules configured."

        return QuestionResult(
            question_id="PURGE-02",
            score=score,
            evidence=evidence,
            details={"rule_count": len(rules)},
        )

    def eval_purge_03(self, data: dict) -> QuestionResult:
        """PURGE-03: Purge terminated instances?"""
        tracking = data.get("asset_tracking") or {}
        has_rule = tracking.get("purge_terminated_instances", False)

        return QuestionResult(
            question_id="PURGE-03",
            score=Score.PASS if has_rule else Score.FAIL,
            evidence=(
                "Purge rule for terminated instances is configured."
                if has_rule
                else "No purge rule for terminated instances found."
            ),
        )

    def eval_purge_04(self, data: dict) -> QuestionResult:
        """PURGE-04: Purge 90-day unscanned?"""
        tracking = data.get("asset_tracking") or {}
        has_rule = tracking.get("purge_90_day_unscanned", False)

        return QuestionResult(
            question_id="PURGE-04",
            score=Score.PASS if has_rule else Score.FAIL,
            evidence=(
                "Purge rule for hosts not scanned in 90 days is configured."
                if has_rule
                else "No purge rule for 90-day unscanned hosts found."
            ),
        )

    def eval_purge_05(self, data: dict) -> QuestionResult:
        """PURGE-05: Purge 30-day unscanned?"""
        tracking = data.get("asset_tracking") or {}
        has_rule = tracking.get("purge_30_day_unscanned", False)

        return QuestionResult(
            question_id="PURGE-05",
            score=Score.PASS if has_rule else Score.FAIL,
            evidence=(
                "Purge rule for hosts not scanned in 30 days is configured."
                if has_rule
                else "No purge rule for 30-day unscanned hosts found."
            ),
        )

    # ─── REPORTING evaluations ───────────────────────────────────────────

    def eval_rpt_01(self, data: dict) -> QuestionResult:
        """RPT-01: 3+ custom dashboards imported?
        Dashboard listing is not available via API — requires manual check.
        """
        return QuestionResult(
            question_id="RPT-01",
            score=Score.NOT_ANSWERED,
            evidence=(
                "Dashboard configuration is not accessible via API. "
                "Verify with customer: do they have custom dashboards or 3+ imported dashboards?"
            ),
        )

    def eval_rpt_02(self, data: dict) -> QuestionResult:
        """RPT-02: Hygiene dashboard imported? (Hybrid)"""
        dash = data.get("dashboards") or {}
        has_hygiene = dash.get("has_hygiene_dashboard", False)

        if has_hygiene:
            return QuestionResult(
                question_id="RPT-02",
                score=Score.PASS,
                evidence="Hygiene dashboard is imported.",
            )

        return QuestionResult(
            question_id="RPT-02",
            score=Score.NOT_ANSWERED,
            evidence=(
                "Hygiene dashboard not detected automatically. "
                "Ask customer if they have imported the Qualys Hygiene dashboard."
            ),
        )

    # ─── TRURISK evaluations ─────────────────────────────────────────────

    def eval_trurisk_01(self, data: dict) -> QuestionResult:
        """TRURISK-01: TruRisk Dashboard in use? (Hybrid)"""
        dash = data.get("dashboards") or {}
        has_trurisk = dash.get("has_trurisk_dashboard", False)

        if has_trurisk:
            return QuestionResult(
                question_id="TRURISK-01",
                score=Score.PASS,
                evidence="TruRisk dashboard detected.",
            )

        return QuestionResult(
            question_id="TRURISK-01",
            score=Score.NOT_ANSWERED,
            evidence=(
                "TruRisk dashboard not detected automatically. "
                "Ask customer if they use the TruRisk dashboard."
            ),
        )

    def eval_trurisk_02(self, data: dict) -> QuestionResult:
        """TRURISK-02: TruRisk driving patching? (Manual)"""
        return QuestionResult(
            question_id="TRURISK-02",
            score=Score.NOT_ANSWERED,
            evidence="Ask customer: Is TruRisk being used to prioritize/drive patching jobs?",
        )

    def eval_trurisk_03(self, data: dict) -> QuestionResult:
        """TRURISK-03: Ticketing integration? (Manual)"""
        return QuestionResult(
            question_id="TRURISK-03",
            score=Score.NOT_ANSWERED,
            evidence="Ask customer: Have they integrated Qualys data with SNOW, BMC, JIRA, or other ticketing?",
        )

    def eval_trurisk_04(self, data: dict) -> QuestionResult:
        """TRURISK-04: Integrated patching? (Manual)"""
        return QuestionResult(
            question_id="TRURISK-04",
            score=Score.NOT_ANSWERED,
            evidence="Ask customer: Do they use Qualys integrated patching?",
        )
