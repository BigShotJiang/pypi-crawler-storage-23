"""Threshold logic and heuristic helpers for qualitative healthcheck checks."""

from __future__ import annotations


def auth_failure_rate_ok(failure_rate: float) -> bool:
    """AUTH-02: Authentication failure rate < 10%."""
    return failure_rate < 10.0


def unused_auth_records_ok(total: int, in_use: int) -> bool:
    """AUTH-03: Unused auth records < 20% of total."""
    if total == 0:
        return True
    unused_pct = ((total - in_use) / total) * 100
    return unused_pct < 20.0


def ghost_hosts_ok(ghost_pct: float) -> bool:
    """SCAN-11: Ghost hosts < 10% of total."""
    return ghost_pct < 10.0


def agent_coverage_met(agent_pct: float, threshold: float) -> bool:
    """AGHLTH-04/05/06: Agent coverage meets threshold percentage."""
    return agent_pct >= threshold


def outdated_agents_ok(outdated_pct: float) -> bool:
    """AGHLTH-09: <=5% agents on old version."""
    return outdated_pct <= 5.0


def inventory_only_ok(inventory_only_pct: float) -> bool:
    """AGHLTH-10: <=5% agents inventory-only."""
    return inventory_only_pct <= 5.0


def tag_hierarchy_ok(tags: list[dict]) -> bool:
    """TAG-01: Tags have hierarchy (not all top-level)."""
    if not tags:
        return False
    parent_ids = {t.get("parent_id") for t in tags if t.get("parent_id")}
    # More than one unique parent = hierarchy exists
    return len(parent_ids) > 1


def criticality_coverage_ok(pct: float, threshold: float = 90.0) -> bool:
    """TAG-02/03: Criticality scores on >= threshold% of items."""
    return pct >= threshold


def reasonable_tag_count(tag_count: int, asset_count: int) -> tuple[bool, str]:
    """TAG-04: Reasonable number of tags relative to account size.

    Heuristic: at least 5 tags, and ratio of tags to assets
    should be between 1:10 and 10:1 approximately.
    """
    if tag_count < 5:
        return False, f"Only {tag_count} tags - too few for proper organization"
    if asset_count > 0:
        ratio = tag_count / asset_count
        if ratio > 10:
            return False, f"Tag-to-asset ratio {ratio:.1f}:1 is very high - possible tag sprawl"
    return True, f"{tag_count} tags for {asset_count} assets"


def scan_frequency_weekly_or_better(frequency: str) -> bool:
    """Check if a scan frequency is weekly or more frequent."""
    freq = frequency.lower()
    return freq in ("daily", "weekly", "every_day", "every_week")


def scan_duration_ok(hours: float, threshold: float) -> bool:
    """Check if scan completed within threshold hours."""
    return hours < threshold


def port_scan_adequate(tcp_ports: str, udp_ports: str) -> bool:
    """SCAN-08: Check if port scan covers standard/full TCP + UDP."""
    tcp = tcp_ports.lower().strip()
    tcp_ok = tcp in ("full", "standard", "1-65535") or len(tcp) > 20  # long range = broad
    udp_ok = bool(udp_ports.strip())
    return tcp_ok and udp_ok


def parallel_scaling_adequate(scaling: str) -> bool:
    """SCAN-09: At least 'normal' parallel scaling."""
    s = scaling.lower()
    # Acceptable values: normal, aggressive, custom (with high values)
    return s in ("normal", "aggressive", "custom_aggressive", "high")
