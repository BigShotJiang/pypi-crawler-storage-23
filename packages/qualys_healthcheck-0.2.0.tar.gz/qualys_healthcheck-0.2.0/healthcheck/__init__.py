"""Qualys VMDR Healthcheck - automated 42-question assessment engine."""
