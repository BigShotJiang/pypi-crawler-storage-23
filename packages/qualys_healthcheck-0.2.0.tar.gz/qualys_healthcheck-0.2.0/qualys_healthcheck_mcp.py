#!/usr/bin/env python3
"""Qualys VMDR Healthcheck MCP Server - 10 tools for automated assessment.

Tools:
  Data Collection (7): get_option_profiles, get_auth_records, get_scan_schedules,
                        get_cloud_agents_status, get_tags_and_groups,
                        get_asset_tracking_config, get_dashboard_info
  Evaluation (2):      evaluate_all, submit_manual_answer
  Reporting (1):       generate_report
"""

import json
from fastmcp import FastMCP

from healthcheck.qualys_api import (
    get_option_profiles as _get_option_profiles,
    get_auth_records as _get_auth_records,
    get_scan_schedules as _get_scan_schedules,
    get_cloud_agents_status as _get_cloud_agents_status,
    get_tags_and_groups as _get_tags_and_groups,
    get_asset_tracking_config as _get_asset_tracking_config,
    get_dashboard_info as _get_dashboard_info,
)
from healthcheck.evaluator import HealthcheckEvaluator
from healthcheck.scoring import compute_overall_score, format_score_summary
from healthcheck.interactive import (
    format_pending_for_agent,
    get_pending_questions,
)
from healthcheck.models import Score
from healthcheck.questions import QUESTIONS

mcp = FastMCP("qualys-healthcheck")

# Shared evaluator state across tool calls within a session
_evaluator = HealthcheckEvaluator()


# ─── Data Collection Tools (7) ───────────────────────────────────────────────


@mcp.tool()
def get_option_profiles() -> dict:
    """Fetch Qualys option profiles with authentication, port, performance, and firewall settings. Use this to evaluate scanning configuration (AUTH-01, SCAN-08, SCAN-09, SCAN-10)."""
    profiles = _get_option_profiles()
    return {
        "count": len(profiles),
        "profiles": profiles,
        "summary": f"Found {len(profiles)} option profiles. "
        + (
            f"{sum(1 for p in profiles if p.get('auth_enabled'))} have auth enabled."
            if profiles
            else "No profiles found."
        ),
    }


@mcp.tool()
def get_auth_records() -> dict:
    """Fetch authentication records (Windows + Unix) with vault and domain info. Use this to evaluate auth hygiene (AUTH-02 through AUTH-06)."""
    records = _get_auth_records()
    return {
        "total": records.get("total", 0),
        "in_use": records.get("in_use", 0),
        "vault_count": records.get("vault_count", 0),
        "domain_windows": records.get("domain_windows", 0),
        "local_windows": records.get("local_windows", 0),
        "tag_based_unix": records.get("tag_based_unix", 0),
        "windows_count": len(records.get("windows", [])),
        "unix_count": len(records.get("unix", [])),
        "summary": (
            f"Total: {records.get('total', 0)} auth records "
            f"({records.get('in_use', 0)} in use, "
            f"{records.get('vault_count', 0)} using vault)."
        ),
    }


@mcp.tool()
def get_scan_schedules() -> dict:
    """Fetch scan schedules and recent scan results for frequency/duration analysis. Use this to evaluate scan hygiene (SCAN-01, SCAN-04, SCAN-06, SCAN-07)."""
    data = _get_scan_schedules()
    active = [s for s in data.get("schedules", []) if s.get("active")]
    completed = [
        s for s in data.get("recent_scans", []) if s.get("duration_hours") is not None
    ]
    return {
        "total_schedules": len(data.get("schedules", [])),
        "active_schedules": len(active),
        "recent_scans": len(data.get("recent_scans", [])),
        "all_weekly_or_better": data.get("all_weekly_or_better", False),
        "all_under_24h": data.get("all_under_24h", False),
        "all_under_48h": data.get("all_under_48h", False),
        "uses_tags": data.get("uses_tags", False),
        "max_duration_hours": data.get("max_duration_hours"),
        "avg_duration_hours": data.get("avg_duration_hours"),
        "summary": (
            f"{len(active)} active schedules, {len(completed)} completed scans. "
            f"Weekly+: {data.get('all_weekly_or_better', False)}, "
            f"Under 24h: {data.get('all_under_24h', False)}."
        ),
    }


@mcp.tool()
def get_cloud_agents_status() -> dict:
    """Fetch Cloud Agent counts, versions, config profiles, and activation status. Use this to evaluate agent health (AGHLTH-04 through AGHLTH-10)."""
    data = _get_cloud_agents_status()
    return {
        "total_assets": data.get("total_assets", 0),
        "agent_count": data.get("agent_count", 0),
        "agent_percentage": round(data.get("agent_percentage", 0), 1),
        "latest_version": data.get("latest_version", ""),
        "outdated_percentage": round(data.get("outdated_percentage", 0), 1),
        "inventory_only_percentage": round(
            data.get("inventory_only_percentage", 0), 1
        ),
        "has_custom_profiles": data.get("has_custom_profiles", False),
        "auto_update_enabled": data.get("auto_update_enabled", False),
        "scan_merge_enabled": data.get("scan_merge_enabled", False),
        "config_profile_count": len(data.get("config_profiles", [])),
        "summary": (
            f"Agents: {data.get('agent_count', 0)}/{data.get('total_assets', 0)} "
            f"({data.get('agent_percentage', 0):.1f}%). "
            f"Outdated: {data.get('outdated_percentage', 0):.1f}%, "
            f"Inventory-only: {data.get('inventory_only_percentage', 0):.1f}%."
        ),
    }


@mcp.tool()
def get_tags_and_groups() -> dict:
    """Fetch tag hierarchy and asset groups with criticality info. Use this to evaluate tagging hygiene (TAG-01 through TAG-05)."""
    data = _get_tags_and_groups()
    return {
        "tag_count": data.get("tag_count", 0),
        "has_hierarchy": data.get("has_hierarchy", False),
        "dynamic_tags": data.get("dynamic_tags", 0),
        "tags_criticality_percentage": round(
            data.get("tags_criticality_percentage", 0), 1
        ),
        "asset_group_count": len(data.get("asset_groups", [])),
        "groups_criticality_percentage": round(
            data.get("groups_criticality_percentage", 0), 1
        ),
        "summary": (
            f"{data.get('tag_count', 0)} tags "
            f"({'hierarchical' if data.get('has_hierarchy') else 'flat'}), "
            f"{data.get('dynamic_tags', 0)} dynamic. "
            f"Criticality: {data.get('tags_criticality_percentage', 0):.0f}% of tags, "
            f"{data.get('groups_criticality_percentage', 0):.0f}% of groups."
        ),
    }


@mcp.tool()
def get_asset_tracking_config() -> dict:
    """Fetch asset tracking config: agentless tracking, merging, purge rules, ghost hosts. Use this to evaluate asset setup and purging (AGHLTH-01/02, SCAN-11, PURGE-01 through PURGE-05)."""
    data = _get_asset_tracking_config()
    return {
        "agentless_tracking": data.get("agentless_tracking", False),
        "unified_view": data.get("unified_view", False),
        "purge_enabled": data.get("purge_enabled", False),
        "purge_rule_count": len(data.get("purge_rules", [])),
        "purge_terminated_instances": data.get("purge_terminated_instances", False),
        "purge_90_day_unscanned": data.get("purge_90_day_unscanned", False),
        "purge_30_day_unscanned": data.get("purge_30_day_unscanned", False),
        "ghost_host_count": data.get("ghost_host_count", 0),
        "ghost_host_percentage": round(data.get("ghost_host_percentage", 0), 1),
        "summary": (
            f"Agentless tracking: {data.get('agentless_tracking', False)}, "
            f"Unified view: {data.get('unified_view', False)}, "
            f"Purge rules: {len(data.get('purge_rules', []))} "
            f"({'enabled' if data.get('purge_enabled') else 'disabled'}), "
            f"Ghost hosts: {data.get('ghost_host_percentage', 0):.1f}%."
        ),
    }


@mcp.tool()
def get_dashboard_info() -> dict:
    """Fetch dashboard information for reporting evaluation. Use this to evaluate reporting (RPT-01, RPT-02, TRURISK-01)."""
    data = _get_dashboard_info()
    return {
        "dashboard_count": data.get("dashboard_count", 0),
        "custom_dashboard_count": data.get("custom_dashboard_count", 0),
        "has_hygiene_dashboard": data.get("has_hygiene_dashboard", False),
        "has_trurisk_dashboard": data.get("has_trurisk_dashboard", False),
        "summary": (
            f"{data.get('dashboard_count', 0)} dashboards "
            f"({data.get('custom_dashboard_count', 0)} custom/imported). "
            f"Hygiene: {data.get('has_hygiene_dashboard', False)}, "
            f"TruRisk: {data.get('has_trurisk_dashboard', False)}."
        ),
    }


# ─── Evaluation Tools (2) ────────────────────────────────────────────────────


@mcp.tool()
def evaluate_all(customer_name: str = "") -> dict:
    """Run the complete 44-question VMDR healthcheck assessment. Collects API data, auto-scores API-answerable questions, and flags manual/hybrid questions for human input. Returns scores, results, and pending questions.

    Args:
        customer_name: Customer name for the report (optional).
    """
    global _evaluator
    _evaluator = HealthcheckEvaluator()
    if customer_name:
        _evaluator.state.customer_name = customer_name

    # Collect data and run all evaluations
    _evaluator.evaluate_all()

    # Compute scores
    overall = compute_overall_score(_evaluator.state.results)
    summary = format_score_summary(overall)

    # Get pending manual questions
    pending = get_pending_questions(_evaluator.state.results)

    # Build results summary
    results_summary = {}
    for qid, result in _evaluator.state.results.items():
        q = QUESTIONS.get(qid)
        results_summary[qid] = {
            "question": q.question if q else "",
            "score": result.score.name,
            "score_value": result.numeric_score,
            "evidence": result.evidence,
            "section": q.section.value if q else "",
        }

    return {
        "overall_score": overall.overall_percentage,
        "overall_grade": overall.overall_grade.value,
        "evaluated": overall.evaluated_count,
        "total_questions": overall.total_questions,
        "passed": overall.passed_count,
        "partial": overall.partial_count,
        "failed": overall.failed_count,
        "unanswered": overall.unanswered_count,
        "pending_manual_count": len(pending),
        "pending_manual_questions": pending,
        "score_summary": summary,
        "results": results_summary,
        "area_scores": {
            a.area.value: {"percentage": a.percentage, "grade": a.grade.value}
            for a in overall.area_scores
        },
    }


@mcp.tool()
def submit_manual_answer(question_id: str, compliant: bool, notes: str = "") -> dict:
    """Record a manual answer for a manual/hybrid healthcheck question.

    Args:
        question_id: The question ID (e.g. "AUTH-07", "TRURISK-02").
        compliant: True if compliant (score=1), False if non-compliant (score=0).
        notes: Optional notes about the answer.
    """
    global _evaluator

    if question_id not in QUESTIONS:
        return {"error": f"Unknown question ID: {question_id}"}

    result = _evaluator.submit_manual_answer(question_id, compliant, notes)

    # Recompute scores
    overall = compute_overall_score(_evaluator.state.results)
    pending = get_pending_questions(_evaluator.state.results)

    return {
        "question_id": question_id,
        "score": result.score.name,
        "evidence": result.evidence,
        "notes": notes,
        "overall_score": overall.overall_percentage,
        "overall_grade": overall.overall_grade.value,
        "remaining_manual": len(pending),
        "message": f"Recorded {'compliant' if compliant else 'non-compliant'} for {question_id}. "
        f"Score: {overall.overall_percentage}% ({overall.overall_grade.value}). "
        f"{len(pending)} questions remaining.",
    }


# ─── Report Generation Tool (1) ─────────────────────────────────────────────


@mcp.tool()
def generate_report(
    format: str = "both", output_dir: str = "./output", customer_name: str = ""
) -> dict:
    """Generate healthcheck report as PPTX and/or HTML.

    Args:
        format: "pptx", "html", or "both" (default).
        output_dir: Output directory for report files.
        customer_name: Customer name (uses previously set name if empty).

    Returns dict with file paths and summary.
    """
    global _evaluator

    if customer_name:
        _evaluator.state.customer_name = customer_name

    if not _evaluator.state.results:
        return {"error": "No evaluation results. Run evaluate_all() first."}

    overall = compute_overall_score(_evaluator.state.results)
    files = {}

    if format in ("pptx", "both"):
        try:
            from reports.pptx_report import generate_pptx

            path = generate_pptx(_evaluator.state, overall, output_dir)
            files["pptx"] = path
        except Exception as e:
            files["pptx_error"] = str(e)

    if format in ("html", "both"):
        try:
            from reports.html_report import generate_html

            path = generate_html(_evaluator.state, overall, output_dir)
            files["html"] = path
        except Exception as e:
            files["html_error"] = str(e)

    return {
        "files": files,
        "customer_name": _evaluator.state.customer_name,
        "overall_score": overall.overall_percentage,
        "overall_grade": overall.overall_grade.value,
        "message": f"Report generated for {_evaluator.state.customer_name or 'customer'}. "
        f"Score: {overall.overall_percentage}% ({overall.overall_grade.value}).",
    }


def main():
    mcp.run()


if __name__ == "__main__":
    main()
