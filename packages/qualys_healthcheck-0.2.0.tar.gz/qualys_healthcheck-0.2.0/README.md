# Qualys VMDR Healthcheck

Automated 44-question VMDR healthcheck assessment via MCP server and standalone agent.

## Quick Start

```bash
# Install
pip install -e .

# Set environment variables
export QUALYS_USERNAME=your_username
export QUALYS_PASSWORD=your_password
export QUALYS_BASE_URL=https://qualysapi.qualys.com
export QUALYS_GATEWAY_URL=https://gateway.qualys.com

# Run as MCP server
qualys-healthcheck

# Run standalone agent (requires anthropic package)
pip install -e ".[agent]"
export ANTHROPIC_API_KEY=sk-ant-...
python -m agent --customer "Customer Name"
```

## MCP Tools

- `get_option_profiles()` - Scan option profiles
- `get_auth_records()` - Authentication records
- `get_scan_schedules()` - Scan schedules and durations
- `get_cloud_agents_status()` - Agent deployment status
- `get_tags_and_groups()` - Tags and asset groups
- `get_asset_tracking_config()` - Tracking, merging, purge rules
- `get_dashboard_info()` - Dashboard configuration
- `evaluate_all(customer_name)` - Run full assessment
- `submit_manual_answer(question_id, compliant, notes)` - Record manual answers
- `generate_report(format, output_dir)` - Generate PPTX/HTML reports
