"""Recommendation engine for the VMDR healthcheck.

Generates prioritized recommendations based on evaluation results,
and suggests Qualys products to fill gaps.
"""

from __future__ import annotations

from healthcheck.models import HealthcheckState, OverallScore, Score
from healthcheck.questions import QUESTIONS


# Priority levels
CRITICAL = "Critical"
HIGH = "High"
MEDIUM = "Medium"
LOW = "Low"

# Question priority mapping (default is MEDIUM)
QUESTION_PRIORITY: dict[str, str] = {
    # Critical - security-impacting
    "AUTH-01": CRITICAL,  # No authenticated scans
    "AUTH-02": CRITICAL,  # High auth failure rate
    "PURGE-01": CRITICAL,  # No purge rules at all
    "SCAN-11": CRITICAL,  # Too many ghost hosts
    "AGHLTH-01": CRITICAL,  # No agentless tracking
    # High - best practice gaps
    "AUTH-03": HIGH,  # Too many unused auth records
    "AUTH-04": HIGH,  # Not using domain auth
    "SCAN-01": HIGH,  # Scanning by IP not tags
    "SCAN-04": HIGH,  # Not scanning weekly
    "SCAN-06": HIGH,  # Scans taking >24h
    "AGHLTH-02": HIGH,  # Not unified view
    "AGHLTH-04": HIGH,  # <50% agent coverage
    "TAG-01": HIGH,  # Flat tags
    "PURGE-03": HIGH,  # No terminated instance purge
    "TRURISK-01": HIGH,  # No TruRisk dashboard
    # Medium - optimization
    "AUTH-05": MEDIUM,
    "SCAN-08": MEDIUM,
    "SCAN-09": MEDIUM,
    "SCAN-10": MEDIUM,
    "AGHLTH-03": MEDIUM,
    "AGHLTH-07": MEDIUM,
    "AGHLTH-08": MEDIUM,
    "TAG-02": MEDIUM,
    "TAG-03": MEDIUM,
    "TAG-04": MEDIUM,
    "PURGE-04": MEDIUM,
    "RPT-01": MEDIUM,
    # Low - nice-to-haves
    "AUTH-06": LOW,
    "AUTH-07": LOW,
    "SCAN-02": LOW,
    "SCAN-03": LOW,
    "SCAN-05": LOW,
    "SCAN-07": LOW,
    "AGHLTH-05": LOW,
    "AGHLTH-06": LOW,
    "AGHLTH-09": LOW,
    "AGHLTH-10": LOW,
    "TAG-05": LOW,
    "PURGE-02": LOW,
    "PURGE-05": LOW,
    "RPT-02": LOW,
    "TRURISK-02": LOW,
    "TRURISK-03": LOW,
    "TRURISK-04": LOW,
}

PRIORITY_ORDER = {CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3}


# Qualys product recommendations tied to specific question failures
PRODUCT_RECOMMENDATIONS: dict[str, dict] = {
    "EASM": {
        "name": "Qualys External Attack Surface Management (EASM)",
        "description": (
            "Continuously discover and monitor your external digital footprint. "
            "EASM provides real-time visibility into internet-facing assets."
        ),
        "triggered_by": ["SCAN-03"],
    },
    "Patch Management": {
        "name": "Qualys Patch Management",
        "description": (
            "Automate patching operations with risk-based prioritization. "
            "Deploy patches directly from the Qualys platform."
        ),
        "triggered_by": ["TRURISK-02", "TRURISK-04"],
    },
    "Cloud Agent": {
        "name": "Qualys Cloud Agent Expansion",
        "description": (
            "Expand cloud agent deployment for continuous, real-time vulnerability "
            "assessment across all endpoints, including off-network devices."
        ),
        "triggered_by": ["AGHLTH-04", "AGHLTH-05", "AGHLTH-06"],
    },
    "TruRisk": {
        "name": "Qualys TruRisk",
        "description": (
            "Leverage risk-based prioritization combining vulnerability severity, "
            "asset criticality, and threat intelligence for focused remediation."
        ),
        "triggered_by": ["TRURISK-01", "TRURISK-02"],
    },
    "ITSM Integration": {
        "name": "Qualys ITSM Connector",
        "description": (
            "Integrate Qualys findings with ServiceNow, BMC, or JIRA to automate "
            "ticket creation and track remediation workflows."
        ),
        "triggered_by": ["TRURISK-03"],
    },
}


def get_recommendations(state: HealthcheckState) -> list[dict]:
    """Generate prioritized recommendations from evaluation results.

    Returns list of dicts: {priority, question_id, question, recommendation, evidence}
    sorted by priority (critical first).
    """
    recs = []
    for qid, result in state.results.items():
        if result.score in (Score.FAIL, Score.PARTIAL):
            q = QUESTIONS.get(qid)
            if not q:
                continue
            priority = QUESTION_PRIORITY.get(qid, MEDIUM)
            recs.append({
                "priority": priority,
                "priority_order": PRIORITY_ORDER.get(priority, 2),
                "question_id": qid,
                "question": q.question,
                "recommendation": q.recommendation,
                "evidence": result.evidence,
                "score": result.score.name,
                "section": q.section.value,
                "area": q.area.value,
            })

    recs.sort(key=lambda r: (r["priority_order"], r["question_id"]))
    return recs


def get_product_recommendations(state: HealthcheckState) -> list[dict]:
    """Suggest Qualys products based on failed questions."""
    products = []
    for key, prod in PRODUCT_RECOMMENDATIONS.items():
        triggered = False
        for qid in prod["triggered_by"]:
            result = state.results.get(qid)
            if result and result.score in (Score.FAIL, Score.PARTIAL):
                triggered = True
                break
        if triggered:
            products.append({
                "product": prod["name"],
                "description": prod["description"],
                "triggered_by": prod["triggered_by"],
            })
    return products


def get_top_recommendations(state: HealthcheckState, limit: int = 10) -> list[dict]:
    """Get the top N recommendations by priority."""
    return get_recommendations(state)[:limit]
