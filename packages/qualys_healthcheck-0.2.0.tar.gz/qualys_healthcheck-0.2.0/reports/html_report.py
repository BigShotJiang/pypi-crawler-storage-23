"""HTML report generation for the VMDR healthcheck.

Generates a self-contained HTML file with embedded CSS, collapsible sections,
and print-optimized layout for PDF export.
"""

from __future__ import annotations

import os
from datetime import datetime

from jinja2 import Environment, FileSystemLoader, select_autoescape

from healthcheck.models import (
    Grade,
    HealthcheckState,
    OverallScore,
    Score,
)
from healthcheck.questions import QUESTIONS, QUESTIONS_BY_SECTION
from .recommendations import (
    get_top_recommendations,
    get_product_recommendations,
)


TEMPLATE_DIR = os.path.join(os.path.dirname(__file__), "templates")


def _score_class(score: Score) -> str:
    """Return CSS class for a score."""
    return {
        Score.PASS: "pass",
        Score.PARTIAL: "partial",
        Score.FAIL: "fail",
        Score.NOT_ANSWERED: "pending",
        Score.NOT_APPLICABLE: "na",
    }.get(score, "na")


def _score_icon(score: Score) -> str:
    return {
        Score.PASS: "&#10004;",       # checkmark
        Score.PARTIAL: "&#9679;",      # circle
        Score.FAIL: "&#10008;",        # X
        Score.NOT_ANSWERED: "&#8230;", # ellipsis
        Score.NOT_APPLICABLE: "&#8212;",  # em dash
    }.get(score, "?")


def _grade_class(grade: Grade) -> str:
    if grade in (Grade.A, Grade.B):
        return "grade-good"
    elif grade == Grade.C:
        return "grade-warn"
    else:
        return "grade-fail"


def generate_html(
    state: HealthcheckState, overall: OverallScore, output_dir: str = "./output"
) -> str:
    """Generate the HTML report. Returns the file path."""
    os.makedirs(output_dir, exist_ok=True)

    # Build template context
    sections_data = []
    for area_score in overall.area_scores:
        for ss in area_score.sections:
            questions = QUESTIONS_BY_SECTION.get(ss.section, [])
            q_results = []
            for q in questions:
                result = state.results.get(q.id)
                q_results.append({
                    "id": q.id,
                    "question": q.question,
                    "score": result.score if result else Score.NOT_APPLICABLE,
                    "score_class": _score_class(result.score) if result else "na",
                    "score_icon": _score_icon(result.score) if result else "?",
                    "evidence": result.evidence if result else "",
                    "recommendation": q.recommendation if result and result.score in (Score.FAIL, Score.PARTIAL) else "",
                    "notes": result.notes if result else "",
                })
            sections_data.append({
                "name": ss.section.value,
                "area": area_score.area.value,
                "percentage": ss.percentage,
                "grade": ss.grade.value,
                "grade_class": _grade_class(ss.grade),
                "passed": ss.passed_count,
                "partial": ss.partial_count,
                "failed": ss.failed_count,
                "evaluated": ss.evaluated_count,
                "questions": q_results,
            })

    recs = get_top_recommendations(state, limit=10)
    products = get_product_recommendations(state)

    context = {
        "customer_name": state.customer_name or "Customer",
        "date": datetime.now().strftime("%B %d, %Y"),
        "overall_percentage": overall.overall_percentage,
        "overall_grade": overall.overall_grade.value,
        "overall_grade_class": _grade_class(overall.overall_grade),
        "total_questions": overall.total_questions,
        "evaluated": overall.evaluated_count,
        "passed": overall.passed_count,
        "partial": overall.partial_count,
        "failed": overall.failed_count,
        "unanswered": overall.unanswered_count,
        "area_scores": [
            {
                "name": a.area.value,
                "percentage": a.percentage,
                "grade": a.grade.value,
                "grade_class": _grade_class(a.grade),
            }
            for a in overall.area_scores
        ],
        "sections": sections_data,
        "recommendations": recs,
        "products": products,
    }

    # Try to load from template file, fall back to inline template
    try:
        env = Environment(
            loader=FileSystemLoader(TEMPLATE_DIR),
            autoescape=select_autoescape(["html"]),
        )
        template = env.get_template("report.html.j2")
    except Exception:
        # Inline fallback
        env = Environment(autoescape=select_autoescape(["html"]))
        template = env.from_string(_INLINE_TEMPLATE)

    html = template.render(**context)

    # Save
    customer_slug = (state.customer_name or "healthcheck").replace(" ", "_").lower()
    date_str = datetime.now().strftime("%Y%m%d")
    filename = f"vmdr_healthcheck_{customer_slug}_{date_str}.html"
    filepath = os.path.join(output_dir, filename)

    with open(filepath, "w", encoding="utf-8") as f:
        f.write(html)

    return filepath


_INLINE_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>VMDR Healthcheck - {{ customer_name }}</title>
<style>
{{ css }}
</style>
</head>
<body>
<h1>VMDR Healthcheck: {{ customer_name }}</h1>
<p>Generated: {{ date }}</p>
<p>Overall: {{ overall_percentage }}% ({{ overall_grade }})</p>
</body>
</html>
"""
