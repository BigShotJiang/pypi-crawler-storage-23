"""PowerPoint report generation for the VMDR healthcheck.

Generates a professional PPTX with:
- Title slide with customer name and date
- Executive summary with overall score and grade
- Section overview with traffic-light scoring
- Detail slides per section with question tables
- Top recommendations slide
- Product recommendations slide
- Next steps slide
"""

from __future__ import annotations

import os
from datetime import datetime

from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.chart import XL_CHART_TYPE
from pptx.chart.data import CategoryChartData

from healthcheck.models import (
    Grade,
    HealthArea,
    HealthcheckState,
    OverallScore,
    Score,
)
from healthcheck.questions import QUESTIONS, QUESTIONS_BY_SECTION
from .recommendations import (
    get_top_recommendations,
    get_product_recommendations,
)


# Color scheme
QUALYS_BLUE = RGBColor(0x00, 0x3D, 0x6B)
QUALYS_LIGHT_BLUE = RGBColor(0x00, 0x7B, 0xC0)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
DARK_GRAY = RGBColor(0x33, 0x33, 0x33)
LIGHT_GRAY = RGBColor(0xF5, 0xF5, 0xF5)
GREEN = RGBColor(0x27, 0xAE, 0x60)
YELLOW = RGBColor(0xF3, 0x9C, 0x12)
RED = RGBColor(0xE7, 0x4C, 0x3C)
ORANGE = RGBColor(0xE6, 0x7E, 0x22)


def grade_color(grade: Grade) -> RGBColor:
    if grade in (Grade.A, Grade.B):
        return GREEN
    elif grade == Grade.C:
        return YELLOW
    elif grade == Grade.D:
        return ORANGE
    else:
        return RED


def score_icon(score: Score) -> str:
    if score == Score.PASS:
        return "[PASS]"
    elif score == Score.PARTIAL:
        return "[PARTIAL]"
    elif score == Score.FAIL:
        return "[FAIL]"
    elif score == Score.NOT_ANSWERED:
        return "[PENDING]"
    else:
        return "[N/A]"


def score_color(score: Score) -> RGBColor:
    if score == Score.PASS:
        return GREEN
    elif score == Score.PARTIAL:
        return YELLOW
    elif score == Score.FAIL:
        return RED
    else:
        return DARK_GRAY


def _add_title_slide(prs: Presentation, customer_name: str):
    """Add title slide."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])  # Blank layout

    # Background
    bg = slide.background.fill
    bg.solid()
    bg.fore_color.rgb = QUALYS_BLUE

    # Title
    txBox = slide.shapes.add_textbox(Inches(1), Inches(2), Inches(8), Inches(1.5))
    tf = txBox.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.text = "VMDR Healthcheck Assessment"
    p.font.size = Pt(36)
    p.font.color.rgb = WHITE
    p.font.bold = True
    p.alignment = PP_ALIGN.CENTER

    # Customer name
    txBox2 = slide.shapes.add_textbox(Inches(1), Inches(3.5), Inches(8), Inches(0.8))
    tf2 = txBox2.text_frame
    p2 = tf2.paragraphs[0]
    p2.text = customer_name or "Customer Assessment"
    p2.font.size = Pt(24)
    p2.font.color.rgb = RGBColor(0xCC, 0xDD, 0xEE)
    p2.alignment = PP_ALIGN.CENTER

    # Date
    txBox3 = slide.shapes.add_textbox(Inches(1), Inches(4.5), Inches(8), Inches(0.5))
    tf3 = txBox3.text_frame
    p3 = tf3.paragraphs[0]
    p3.text = datetime.now().strftime("%B %d, %Y")
    p3.font.size = Pt(16)
    p3.font.color.rgb = RGBColor(0x99, 0xBB, 0xDD)
    p3.alignment = PP_ALIGN.CENTER


def _add_executive_summary(prs: Presentation, overall: OverallScore, customer_name: str):
    """Add executive summary slide with overall score."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])

    # Title
    txBox = slide.shapes.add_textbox(Inches(0.5), Inches(0.3), Inches(9), Inches(0.7))
    tf = txBox.text_frame
    p = tf.paragraphs[0]
    p.text = "Executive Summary"
    p.font.size = Pt(28)
    p.font.color.rgb = QUALYS_BLUE
    p.font.bold = True

    # Score display
    txBox2 = slide.shapes.add_textbox(Inches(0.5), Inches(1.2), Inches(4), Inches(2.5))
    tf2 = txBox2.text_frame
    tf2.word_wrap = True

    # Overall score
    p_score = tf2.paragraphs[0]
    p_score.text = f"Overall Score: {overall.overall_percentage}%"
    p_score.font.size = Pt(24)
    p_score.font.bold = True
    p_score.font.color.rgb = grade_color(overall.overall_grade)

    # Grade
    p_grade = tf2.add_paragraph()
    p_grade.text = f"Grade: {overall.overall_grade.value}"
    p_grade.font.size = Pt(20)
    p_grade.font.color.rgb = grade_color(overall.overall_grade)

    # Stats
    p_stats = tf2.add_paragraph()
    p_stats.space_before = Pt(12)
    p_stats.text = (
        f"Evaluated: {overall.evaluated_count}/{overall.total_questions} questions\n"
        f"Passed: {overall.passed_count}  |  Partial: {overall.partial_count}  |  "
        f"Failed: {overall.failed_count}"
    )
    p_stats.font.size = Pt(12)
    p_stats.font.color.rgb = DARK_GRAY

    if overall.unanswered_count > 0:
        p_pending = tf2.add_paragraph()
        p_pending.text = f"Pending: {overall.unanswered_count} questions awaiting input"
        p_pending.font.size = Pt(11)
        p_pending.font.color.rgb = ORANGE

    # Area breakdown on right side
    txBox3 = slide.shapes.add_textbox(Inches(5), Inches(1.2), Inches(4.5), Inches(3))
    tf3 = txBox3.text_frame
    tf3.word_wrap = True

    p_hdr = tf3.paragraphs[0]
    p_hdr.text = "Area Breakdown"
    p_hdr.font.size = Pt(16)
    p_hdr.font.bold = True
    p_hdr.font.color.rgb = QUALYS_BLUE

    for area_score in overall.area_scores:
        p_area = tf3.add_paragraph()
        p_area.space_before = Pt(6)
        p_area.text = f"{area_score.area.value}: {area_score.percentage}% ({area_score.grade.value})"
        p_area.font.size = Pt(13)
        p_area.font.color.rgb = grade_color(area_score.grade)


def _add_section_overview(prs: Presentation, overall: OverallScore):
    """Add section overview slide with all sections."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])

    # Title
    txBox = slide.shapes.add_textbox(Inches(0.5), Inches(0.3), Inches(9), Inches(0.7))
    tf = txBox.text_frame
    p = tf.paragraphs[0]
    p.text = "Section Overview"
    p.font.size = Pt(28)
    p.font.color.rgb = QUALYS_BLUE
    p.font.bold = True

    # Table with section scores
    rows = 1  # header
    for area_score in overall.area_scores:
        rows += len(area_score.sections)
    cols = 5

    table_shape = slide.shapes.add_table(
        rows, cols, Inches(0.5), Inches(1.2), Inches(9), Inches(0.4 * rows)
    )
    table = table_shape.table

    # Header
    headers = ["Section", "Score", "Grade", "Passed", "Status"]
    for i, h in enumerate(headers):
        cell = table.cell(0, i)
        cell.text = h
        for paragraph in cell.text_frame.paragraphs:
            paragraph.font.size = Pt(11)
            paragraph.font.bold = True
            paragraph.font.color.rgb = WHITE
        cell.fill.solid()
        cell.fill.fore_color.rgb = QUALYS_BLUE

    # Data rows
    row_idx = 1
    for area_score in overall.area_scores:
        for ss in area_score.sections:
            cells = [
                ss.section.value,
                f"{ss.percentage}%",
                ss.grade.value,
                f"{ss.passed_count}/{ss.evaluated_count}",
                "Pass" if ss.grade in (Grade.A, Grade.B) else "Needs Work" if ss.grade == Grade.C else "Fail",
            ]
            for col_idx, val in enumerate(cells):
                cell = table.cell(row_idx, col_idx)
                cell.text = val
                for paragraph in cell.text_frame.paragraphs:
                    paragraph.font.size = Pt(10)
                    paragraph.font.color.rgb = DARK_GRAY

            # Color the grade cell
            grade_cell = table.cell(row_idx, 2)
            for paragraph in grade_cell.text_frame.paragraphs:
                paragraph.font.color.rgb = grade_color(ss.grade)
                paragraph.font.bold = True

            # Alternate row colors
            if row_idx % 2 == 0:
                for col_idx in range(cols):
                    table.cell(row_idx, col_idx).fill.solid()
                    table.cell(row_idx, col_idx).fill.fore_color.rgb = LIGHT_GRAY

            row_idx += 1


def _add_section_detail(
    prs: Presentation, section_name: str, questions: list, results: dict
):
    """Add a detail slide for a single section."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])

    # Title
    txBox = slide.shapes.add_textbox(Inches(0.5), Inches(0.3), Inches(9), Inches(0.6))
    tf = txBox.text_frame
    p = tf.paragraphs[0]
    p.text = f"Section: {section_name}"
    p.font.size = Pt(24)
    p.font.color.rgb = QUALYS_BLUE
    p.font.bold = True

    # Questions table
    q_count = len(questions)
    rows = min(q_count + 1, 16)  # Cap at 15 questions per slide
    cols = 4

    table_shape = slide.shapes.add_table(
        rows, cols, Inches(0.3), Inches(1.0), Inches(9.4), Inches(0.35 * rows)
    )
    table = table_shape.table

    # Set column widths
    table.columns[0].width = Inches(0.8)   # ID
    table.columns[1].width = Inches(4.8)   # Question
    table.columns[2].width = Inches(0.8)   # Status
    table.columns[3].width = Inches(3.0)   # Evidence

    # Header
    for i, h in enumerate(["ID", "Question", "Status", "Evidence"]):
        cell = table.cell(0, i)
        cell.text = h
        for paragraph in cell.text_frame.paragraphs:
            paragraph.font.size = Pt(9)
            paragraph.font.bold = True
            paragraph.font.color.rgb = WHITE
        cell.fill.solid()
        cell.fill.fore_color.rgb = QUALYS_BLUE

    # Question rows
    for idx, q in enumerate(questions[:15]):  # Max 15 per slide
        result = results.get(q.id)
        row = idx + 1

        # ID
        table.cell(row, 0).text = q.id
        # Question (truncated)
        q_text = q.question[:80] + ("..." if len(q.question) > 80 else "")
        table.cell(row, 1).text = q_text
        # Status
        if result:
            status = score_icon(result.score)
            table.cell(row, 2).text = status
            for paragraph in table.cell(row, 2).text_frame.paragraphs:
                paragraph.font.color.rgb = score_color(result.score)
                paragraph.font.bold = True
            # Evidence (truncated)
            ev_text = (result.evidence or "")[:60] + ("..." if len(result.evidence or "") > 60 else "")
            table.cell(row, 3).text = ev_text
        else:
            table.cell(row, 2).text = "[N/A]"

        # Font sizes
        for col in range(cols):
            for paragraph in table.cell(row, col).text_frame.paragraphs:
                paragraph.font.size = Pt(8)

        # Alternate rows
        if row % 2 == 0:
            for col in range(cols):
                table.cell(row, col).fill.solid()
                table.cell(row, col).fill.fore_color.rgb = LIGHT_GRAY


def _add_recommendations_slide(prs: Presentation, state: HealthcheckState):
    """Add top recommendations slide."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])

    txBox = slide.shapes.add_textbox(Inches(0.5), Inches(0.3), Inches(9), Inches(0.6))
    tf = txBox.text_frame
    p = tf.paragraphs[0]
    p.text = "Top Recommendations"
    p.font.size = Pt(28)
    p.font.color.rgb = QUALYS_BLUE
    p.font.bold = True

    recs = get_top_recommendations(state, limit=8)

    txBox2 = slide.shapes.add_textbox(Inches(0.5), Inches(1.1), Inches(9), Inches(5.5))
    tf2 = txBox2.text_frame
    tf2.word_wrap = True

    for i, rec in enumerate(recs):
        p_rec = tf2.paragraphs[0] if i == 0 else tf2.add_paragraph()
        p_rec.space_before = Pt(8) if i > 0 else Pt(0)

        # Priority badge
        priority_colors = {
            "Critical": RED,
            "High": ORANGE,
            "Medium": YELLOW,
            "Low": DARK_GRAY,
        }
        run = p_rec.add_run()
        run.text = f"[{rec['priority']}] "
        run.font.size = Pt(10)
        run.font.bold = True
        run.font.color.rgb = priority_colors.get(rec["priority"], DARK_GRAY)

        run2 = p_rec.add_run()
        run2.text = f"{rec['question_id']}: "
        run2.font.size = Pt(10)
        run2.font.bold = True
        run2.font.color.rgb = DARK_GRAY

        run3 = p_rec.add_run()
        rec_text = rec["recommendation"][:150] + ("..." if len(rec["recommendation"]) > 150 else "")
        run3.text = rec_text
        run3.font.size = Pt(9)
        run3.font.color.rgb = DARK_GRAY


def _add_product_recommendations(prs: Presentation, state: HealthcheckState):
    """Add product recommendations slide."""
    products = get_product_recommendations(state)
    if not products:
        return

    slide = prs.slides.add_slide(prs.slide_layouts[6])

    txBox = slide.shapes.add_textbox(Inches(0.5), Inches(0.3), Inches(9), Inches(0.6))
    tf = txBox.text_frame
    p = tf.paragraphs[0]
    p.text = "Recommended Qualys Solutions"
    p.font.size = Pt(28)
    p.font.color.rgb = QUALYS_BLUE
    p.font.bold = True

    txBox2 = slide.shapes.add_textbox(Inches(0.5), Inches(1.1), Inches(9), Inches(5.5))
    tf2 = txBox2.text_frame
    tf2.word_wrap = True

    for i, prod in enumerate(products):
        p_prod = tf2.paragraphs[0] if i == 0 else tf2.add_paragraph()
        p_prod.space_before = Pt(12) if i > 0 else Pt(0)

        run = p_prod.add_run()
        run.text = prod["product"]
        run.font.size = Pt(14)
        run.font.bold = True
        run.font.color.rgb = QUALYS_LIGHT_BLUE

        p_desc = tf2.add_paragraph()
        p_desc.text = prod["description"]
        p_desc.font.size = Pt(10)
        p_desc.font.color.rgb = DARK_GRAY


def _add_next_steps(prs: Presentation, overall: OverallScore):
    """Add next steps slide."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])

    # Background
    bg = slide.background.fill
    bg.solid()
    bg.fore_color.rgb = QUALYS_BLUE

    txBox = slide.shapes.add_textbox(Inches(0.5), Inches(0.5), Inches(9), Inches(0.7))
    tf = txBox.text_frame
    p = tf.paragraphs[0]
    p.text = "Next Steps"
    p.font.size = Pt(28)
    p.font.color.rgb = WHITE
    p.font.bold = True

    steps = [
        "Review this report with your security team",
        "Prioritize Critical and High recommendations",
        "Schedule follow-up session to track progress",
        "Implement quick wins identified in this assessment",
        "Plan for product deployments (EASM, Patch Management, etc.)",
        "Re-assess in 90 days to measure improvement",
    ]

    txBox2 = slide.shapes.add_textbox(Inches(1), Inches(1.5), Inches(8), Inches(4.5))
    tf2 = txBox2.text_frame
    tf2.word_wrap = True

    for i, step in enumerate(steps):
        p_step = tf2.paragraphs[0] if i == 0 else tf2.add_paragraph()
        p_step.space_before = Pt(12) if i > 0 else Pt(0)
        p_step.text = f"{i + 1}. {step}"
        p_step.font.size = Pt(16)
        p_step.font.color.rgb = WHITE


def generate_pptx(
    state: HealthcheckState, overall: OverallScore, output_dir: str = "./output"
) -> str:
    """Generate the complete PPTX report. Returns the file path."""
    os.makedirs(output_dir, exist_ok=True)
    prs = Presentation()
    prs.slide_width = Inches(10)
    prs.slide_height = Inches(7.5)

    # Build slides
    _add_title_slide(prs, state.customer_name)
    _add_executive_summary(prs, overall, state.customer_name)
    _add_section_overview(prs, overall)

    # Section detail slides
    for area_score in overall.area_scores:
        for ss in area_score.sections:
            questions = QUESTIONS_BY_SECTION.get(ss.section, [])
            if questions:
                _add_section_detail(prs, ss.section.value, questions, state.results)

    _add_recommendations_slide(prs, state)
    _add_product_recommendations(prs, state)
    _add_next_steps(prs, overall)

    # Save
    customer_slug = (state.customer_name or "healthcheck").replace(" ", "_").lower()
    date_str = datetime.now().strftime("%Y%m%d")
    filename = f"vmdr_healthcheck_{customer_slug}_{date_str}.pptx"
    filepath = os.path.join(output_dir, filename)
    prs.save(filepath)

    return filepath
