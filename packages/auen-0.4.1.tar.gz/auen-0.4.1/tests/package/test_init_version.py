from __future__ import annotations

import importlib
import sys
from importlib.metadata import PackageNotFoundError

import pytest

import auen


def test_version_fallback_when_metadata_missing(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def _raise_version(_: str) -> str:
        raise PackageNotFoundError

    monkeypatch.setattr("importlib.metadata.version", _raise_version)
    sys.modules.pop("auen", None)
    reloaded = importlib.import_module("auen")
    assert reloaded.__version__ == "0.0.0"
    sys.modules["auen"] = auen
