"""Pagination configuration tests."""

from __future__ import annotations

from typing import Any, cast

import pytest
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient
from pydantic import ValidationError
from tests.conftest import Book, SessionFactory

from auen import (
    CrudRouterBuilder,
    FilterConfig,
    FilterFieldConfig,
    FilterOp,
    Operation,
    PaginationConfig,
)


async def test_unsupported_pagination_style() -> None:
    with pytest.raises(ValidationError):
        PaginationConfig(style=cast(Any, "cursor"))


async def test_page_pagination_with_filters(get_session: SessionFactory) -> None:
    app = FastAPI()
    app.include_router(
        CrudRouterBuilder.for_model(Book, get_session)
        .with_pagination(PaginationConfig(style="page", default_limit=10))
        .with_filters(
            FilterConfig(
                fields={"title": FilterFieldConfig(ops=frozenset({FilterOp.EQ}))},
            )
        )
        .with_operations({Operation.CREATE, Operation.LIST})
        .build()
    )
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        await c.post("/books/", json={"title": "T", "isbn": "I"})
        resp = await c.get("/books/", params={"title": "T"})
        assert resp.status_code == 200
