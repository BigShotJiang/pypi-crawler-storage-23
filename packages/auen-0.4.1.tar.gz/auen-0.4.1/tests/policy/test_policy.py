"""Policy tests: verify row-level authorization."""

from __future__ import annotations

from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient


async def test_list_filtered_by_policy(policy_app: FastAPI) -> None:
    """LIST only returns rows owned by the current user."""
    transport = ASGITransport(app=policy_app)

    # Create books as alice
    async with AsyncClient(
        transport=transport,
        base_url="http://test",
        headers={"X-User": "alice"},
    ) as alice:
        await alice.post(
            "/books/",
            json={
                "title": "Refactoring",
                "isbn": "978-0134757599",
                "owner_id": "alice",
            },
        )

    # Create books as bob
    async with AsyncClient(
        transport=transport,
        base_url="http://test",
        headers={"X-User": "bob"},
    ) as bob:
        await bob.post(
            "/books/",
            json={
                "title": "Introduction to Algorithms",
                "isbn": "978-0262046305",
                "owner_id": "bob",
            },
        )

    # Alice should only see her books
    async with AsyncClient(
        transport=transport,
        base_url="http://test",
        headers={"X-User": "alice"},
    ) as alice:
        resp = await alice.get("/books/")
        assert resp.status_code == 200
        books = resp.json()
        assert all(b["owner_id"] == "alice" for b in books)
        assert len(books) >= 1


async def test_read_forbidden_by_policy(policy_app: FastAPI) -> None:
    """READ on another user's object returns 403."""
    transport = ASGITransport(app=policy_app)

    # Create as bob
    async with AsyncClient(
        transport=transport,
        base_url="http://test",
        headers={"X-User": "bob"},
    ) as bob:
        resp = await bob.post(
            "/books/",
            json={
                "title": "Structure and Interpretation of Computer Programs",
                "isbn": "978-0262510875",
                "owner_id": "bob",
            },
        )
        book_id = resp.json()["id"]

    # Alice tries to read bob's book
    async with AsyncClient(
        transport=transport,
        base_url="http://test",
        headers={"X-User": "alice"},
    ) as alice:
        resp = await alice.get(f"/books/{book_id}")
        assert resp.status_code == 403


async def test_delete_forbidden_by_policy(policy_app: FastAPI) -> None:
    """DELETE on another user's object returns 403."""
    transport = ASGITransport(app=policy_app)

    # Create as bob
    async with AsyncClient(
        transport=transport,
        base_url="http://test",
        headers={"X-User": "bob"},
    ) as bob:
        resp = await bob.post(
            "/books/",
            json={
                "title": "Compilers: Principles, Techniques, and Tools",
                "isbn": "978-0321486813",
                "owner_id": "bob",
            },
        )
        book_id = resp.json()["id"]

    # Alice tries to delete bob's book
    async with AsyncClient(
        transport=transport,
        base_url="http://test",
        headers={"X-User": "alice"},
    ) as alice:
        resp = await alice.delete(f"/books/{book_id}")
        assert resp.status_code == 403
