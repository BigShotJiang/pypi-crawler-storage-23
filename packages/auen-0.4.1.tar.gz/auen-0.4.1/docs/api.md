# API Reference

## Main entrypoint

::: auen.CrudRouterBuilder

## Configuration

::: auen.config.Operation
::: auen.config.FilterOp
::: auen.config.SchemaConfig
::: auen.config.AuthConfig
::: auen.config.PaginationConfig
::: auen.config.FilterConfig
::: auen.config.FilterFieldConfig

## Policy

::: auen.policy.CrudPolicy
::: auen.policy.AllowAll

## Repository

::: auen.repository.AsyncCrudRepository
::: auen.repository.AsyncSqlModelRepository

## Schemas

::: auen.schemas.derive_schemas

## Exceptions

::: auen.exceptions.NotFoundError
::: auen.exceptions.ConflictError
::: auen.exceptions.ForbiddenError
