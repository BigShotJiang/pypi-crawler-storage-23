# Pagination & Filtering

Pagination, sorting, and filtering are boilerplate that every API implements identically — offset/limit handling, sort-field validation, operator mapping, query parameter parsing. auen generates all of it from a declaration.

## Pagination

All LIST endpoints support `offset` and `limit` query parameters.

```python
from auen import PaginationConfig

pagination = PaginationConfig(
    default_limit=20,   # default if client omits limit
    max_limit=100,      # 422 if client requests more
)
```

### Page-based pagination

```python
pagination = PaginationConfig(
    style="page",
    default_limit=20,
    max_limit=100,
)
```

## Sorting

Enable sorting on specific fields:

```python
from auen import FilterConfig

filters = FilterConfig(sort_fields=["name", "age"])
```

Clients sort with `?sort=name` (ascending) or `?sort=-name` (descending). Sorting on non-allowlisted fields returns 422.

## Field filtering

Allow filtering on specific fields with specific operations:

```python
from auen import FilterConfig, FilterFieldConfig, FilterOp

filters = FilterConfig(
    fields={
        "name": FilterFieldConfig(ops=frozenset({FilterOp.EQ})),
        "age": FilterFieldConfig(ops=frozenset({FilterOp.EQ, FilterOp.GTE, FilterOp.LTE})),
    },
    sort_fields=["name", "age"],
)
```
