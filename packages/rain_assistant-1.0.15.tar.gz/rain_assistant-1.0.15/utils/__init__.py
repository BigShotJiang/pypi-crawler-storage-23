"""Rain Assistant utility modules."""
