"""SFTP storage provider using paramiko.

Supports SSH/SFTP-based file transfer for remote storage connections.
"""

import asyncio
import logging
import os
from pathlib import Path, PurePosixPath
from typing import Optional

import paramiko

from .base_storage import BaseStorage

logger = logging.getLogger(__name__)


class SFTPStorage(BaseStorage):
    """SFTP storage provider using paramiko.

    Supports download, upload, and presigned URLs (not applicable for SFTP,
    returns the SFTP path as a fallback).

    Args:
        host: SFTP server hostname.
        port: SFTP server port (default: 22).
        username: SSH username.
        password: SSH password (optional if private_key is provided).
        private_key: Path to SSH private key file or key string (optional).
    """

    def __init__(
        self,
        host: str,
        port: int = 22,
        username: str = "",
        password: Optional[str] = None,
        private_key: Optional[str] = None,
    ):
        self._host = host
        self._port = port
        self._username = username
        self._password = password
        self._private_key = private_key
        self._transport: Optional[paramiko.Transport] = None
        self._sftp: Optional[paramiko.SFTPClient] = None

        logger.info(
            "SFTPStorage initialized",
            extra={"host": host, "port": port, "username": username},
        )

    def _connect(self) -> paramiko.SFTPClient:
        """Establish SFTP connection (lazy, reusable)."""
        if self._sftp is not None:
            try:
                self._sftp.stat(".")
                return self._sftp
            except Exception:
                logger.debug("SFTP connection stale, reconnecting")
                self._close()

        logger.debug("Opening SFTP connection", extra={"host": self._host})
        self._transport = paramiko.Transport((self._host, self._port))

        if self._private_key:
            # Try loading as file path first, then as key string
            pkey: Optional[paramiko.PKey] = None
            if os.path.isfile(self._private_key):
                pkey = paramiko.RSAKey.from_private_key_file(self._private_key)
            else:
                import io
                pkey = paramiko.RSAKey.from_private_key(io.StringIO(self._private_key))
            self._transport.connect(username=self._username, pkey=pkey)
        else:
            self._transport.connect(
                username=self._username,
                password=self._password or "",
            )

        self._sftp = paramiko.SFTPClient.from_transport(self._transport)
        return self._sftp

    def _close(self) -> None:
        """Close SFTP connection."""
        if self._sftp:
            try:
                self._sftp.close()
            except Exception:
                pass
            self._sftp = None
        if self._transport:
            try:
                self._transport.close()
            except Exception:
                pass
            self._transport = None

    def __del__(self) -> None:
        self._close()

    async def download(self, uri: str, destination: Path) -> None:
        """Download a file from SFTP to a local path.

        Args:
            uri: Remote file path on the SFTP server.
            destination: Local directory or file path.
        """
        remote_path = uri

        if destination.is_dir():
            dest_file = destination / PurePosixPath(remote_path).name
        else:
            dest_file = destination
            dest_file.parent.mkdir(parents=True, exist_ok=True)

        logger.info(
            "Downloading from SFTP",
            extra={"remote_path": remote_path, "destination": str(dest_file)},
        )

        loop = asyncio.get_event_loop()

        def _do_download() -> None:
            sftp = self._connect()
            sftp.get(remote_path, str(dest_file))

        try:
            await loop.run_in_executor(None, _do_download)
        except FileNotFoundError:
            logger.error("Remote file not found", extra={"remote_path": remote_path})
            raise
        except paramiko.SSHException as e:
            logger.error("SFTP download failed", extra={"error": str(e)})
            raise

        logger.info(
            "SFTP download complete",
            extra={"remote_path": remote_path, "size_bytes": dest_file.stat().st_size},
        )

    async def upload(self, source: Path, uri: str) -> None:
        """Upload a local file to SFTP.

        Args:
            source: Local file path.
            uri: Remote destination path on the SFTP server.
        """
        remote_path = uri

        logger.info(
            "Uploading to SFTP",
            extra={"source": str(source), "remote_path": remote_path},
        )

        loop = asyncio.get_event_loop()

        def _do_upload() -> None:
            sftp = self._connect()
            # Ensure remote directory exists
            remote_dir = str(PurePosixPath(remote_path).parent)
            try:
                sftp.stat(remote_dir)
            except FileNotFoundError:
                self._mkdir_p(sftp, remote_dir)
            sftp.put(str(source), remote_path)

        try:
            await loop.run_in_executor(None, _do_upload)
        except paramiko.SSHException as e:
            logger.error("SFTP upload failed", extra={"error": str(e)})
            raise

        logger.info("SFTP upload complete", extra={"remote_path": remote_path})

    async def get_presigned_url(self, uri: str, expiration: int = 3600) -> str:
        """SFTP does not support presigned URLs.

        Returns the SFTP URI as a fallback for internal use.

        Args:
            uri: Remote file path.
            expiration: Ignored for SFTP.

        Returns:
            An sftp:// URI string.
        """
        logger.debug("Presigned URLs not supported for SFTP, returning sftp:// URI")
        return f"sftp://{self._username}@{self._host}:{self._port}{uri}"

    @staticmethod
    def _mkdir_p(sftp: paramiko.SFTPClient, remote_dir: str) -> None:
        """Recursively create remote directories (like mkdir -p)."""
        dirs_to_create: list[str] = []
        current = remote_dir
        while current and current != "/":
            try:
                sftp.stat(current)
                break
            except FileNotFoundError:
                dirs_to_create.insert(0, current)
                current = str(PurePosixPath(current).parent)

        for d in dirs_to_create:
            sftp.mkdir(d)
