# worker-core-lib/src/core_lib/core_lib_bullmq/base_worker.py
import asyncio
import logging
import os
import signal
import time
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional

from bullmq import Worker, WaitingChildrenError

from ..core_lib_utils.hooks import WorkerHooks
from ..core_lib_logging import set_correlation_id, clear_correlation_id
from .queue_manager import QueueManager
from .worker_backend_factory import WorkerBackendFactory

logger = logging.getLogger(__name__)


class BaseWorker(ABC):
    """
    An abstract base class for creating BullMQ workers.
    It now uses a centralized QueueManager for consistent Redis connections
    and includes improved shutdown logic and internal state management.
    
    This class supports the adapter pattern through WorkerBackendFactory,
    allowing it to work with either BullMQ or external worker backend services.
    
    Analytics Integration:
    - Automatically emits analytics events on job completion
    - Set ANALYTICS_ENABLED=false to disable
    - Override `get_analytics_metrics()` to provide custom metrics
    """

    # Worker ID for analytics (override in subclass)
    WORKER_ID: str = "unknown-worker"
    
    # Analytics event type (override in subclass)
    ANALYTICS_EVENT_TYPE: str = "unknown_event"

    def __init__(
        self,
        queue_name: str,
        hooks: Optional[WorkerHooks] = None,
    ):
        """
        Initializes the BaseWorker.
        
        Args:
            queue_name: Name of the queue to process jobs from
            hooks: Optional WorkerHooks instance for lifecycle callbacks
        """
        self.queue_name = queue_name
        self.hooks = hooks
        self.redis_connection = QueueManager.get_redis_url()
        self._worker_instance: Optional[Worker] = None
        self._shutdown_event = asyncio.Event()
        # **CRITICAL FIX**: Add internal state to prevent re-running.
        self._is_running = False
        
        self._backend_adapter = WorkerBackendFactory.get_adapter()
        
        # Initialize analytics publisher
        self._analytics_enabled = os.getenv("ANALYTICS_ENABLED", "true").lower() == "true"
        self._analytics_publisher = None
        if self._analytics_enabled:
            try:
                from .analytics import AnalyticsPublisher
                worker_id = getattr(self, 'WORKER_ID', self.__class__.__name__)
                self._analytics_publisher = AnalyticsPublisher(worker_id=worker_id)
            except ImportError:
                logger.debug("Analytics module not available, analytics disabled")
                self._analytics_enabled = False
        
        logger.info(
            f"BaseWorker for queue '{self.queue_name}' initialized with adapter: "
            f"{self._backend_adapter.__class__.__name__}, analytics={self._analytics_enabled}"
        )

    @abstractmethod
    async def process(self, job: Any, job_token: str) -> Any:
        raise NotImplementedError

    def get_analytics_metrics(self, job: Any, result: Any, processing_ms: int) -> Optional[Dict[str, Any]]:
        """
        Override this method to provide worker-specific metrics.
        
        Args:
            job: The processed job
            result: The job result
            processing_ms: Processing time in milliseconds
            
        Returns:
            Dictionary of metrics or None
        """
        return None

    async def _emit_analytics(
        self,
        job: Any,
        result: Any,
        processing_ms: int,
        error: Optional[Exception] = None,
    ):
        """Emit analytics event for job completion."""
        if not self._analytics_enabled or not self._analytics_publisher:
            return
        
        try:
            from .analytics import AnalyticsEventType, AnalyticsStatus
            
            # Map event type string to enum
            event_type_str = getattr(self, 'ANALYTICS_EVENT_TYPE', 'unknown_event')
            try:
                event_type = AnalyticsEventType(event_type_str)
            except ValueError:
                # Unknown event type, skip analytics
                return
            
            # Extract context from job data
            job_data = job.data if hasattr(job, 'data') else {}
            user_id = job_data.get("ownerId") or job_data.get("userId")
            model_id = job_data.get("modelId")
            metamodel_id = job_data.get("metamodelId")
            storage_item_id = job_data.get("storageItemId")
            
            # Get worker-specific metrics
            metrics = self.get_analytics_metrics(job, result, processing_ms)
            
            if error:
                await self._analytics_publisher.emit_failure(
                    event_type=event_type,
                    job_id=str(job.id),
                    user_id=user_id,
                    model_id=model_id,
                    error_code=error.__class__.__name__,
                    error_message=str(error)[:500],
                    processing_ms=processing_ms,
                    metamodel_id=metamodel_id,
                    storage_item_id=storage_item_id,
                )
            else:
                await self._analytics_publisher.emit_success(
                    event_type=event_type,
                    job_id=str(job.id),
                    user_id=user_id,
                    model_id=model_id,
                    processing_ms=processing_ms,
                    metrics=metrics,
                    metamodel_id=metamodel_id,
                    storage_item_id=storage_item_id,
                )
        except Exception as e:
            # Analytics should never break main flow
            logger.debug(f"Failed to emit analytics: {e}")

    async def _keep_alive(self, job: Any, interval_s: int) -> None:
        """
        Periodically update job progress to prevent stalling on long-running jobs.
        
        BullMQ considers a job stalled if the lock isn't refreshed. While the
        Worker.extendLocks timer handles this, calling updateProgress provides
        an additional heartbeat signal and is harmless if lock renewal already works.
        
        Args:
            job: The BullMQ job instance
            interval_s: Seconds between heartbeats
        """
        tick = 0
        try:
            while True:
                await asyncio.sleep(interval_s)
                tick += 1
                try:
                    # updateProgress signals the job is still active.
                    # The BullMQ Python library's updateProgress() returns
                    # a coroutine/pipeline result that we need to await.
                    progress_result = job.updateProgress({"heartbeat": tick})
                    if asyncio.iscoroutine(progress_result) or asyncio.isfuture(progress_result):
                        await asyncio.wait_for(progress_result, timeout=5.0)
                    logger.debug(f"Job {job.id} keep-alive heartbeat #{tick}")
                except asyncio.TimeoutError:
                    logger.warning(f"Job {job.id} keep-alive timed out on heartbeat #{tick}")
                except Exception as e:
                    logger.warning(f"Job {job.id} keep-alive failed: {e}")
        except asyncio.CancelledError:
            pass

    async def _job_processor(self, job: Any, job_token: str) -> Any:
        # Extract and set correlation ID from job data (injected by backend)
        job_data = job.data if hasattr(job, 'data') else {}
        correlation_id = job_data.get("correlationId")
        if correlation_id:
            set_correlation_id(correlation_id)

        if self.hooks and hasattr(self.hooks, "on_request_received"):
            await self.hooks.on_request_received(job)
        
        start_time = time.time()
        error_occurred = None
        result = None
        
        # Start keep-alive heartbeat to prevent job stalling on long-running tasks.
        # Interval = lockDuration / 4 (default 30s with 120s lock) — well within
        # the stall detection window, so the lock stays alive even if the Worker's
        # built-in extendLocks timer misses a beat.
        keep_alive_interval = int(os.getenv("WORKER_KEEP_ALIVE_INTERVAL_S", "30"))
        keep_alive_task = asyncio.create_task(self._keep_alive(job, keep_alive_interval))
        
        try:
            result = await self.process(job, job_token)
            if self.hooks and hasattr(self.hooks, "on_request_completed"):
                await self.hooks.on_request_completed(job, result)
            return result
        except WaitingChildrenError:
            logger.info(f"Job {job.id} is waiting for children to complete.")
            raise
        except Exception as e:
            error_occurred = e
            logger.error(f"Error processing job {job.id} in queue {self.queue_name}: {e}", exc_info=True)
            if self.hooks and hasattr(self.hooks, "on_error_occurred"):
                await self.hooks.on_error_occurred(job, e)
            raise
        finally:
            # Cancel keep-alive heartbeat
            keep_alive_task.cancel()
            try:
                await keep_alive_task
            except asyncio.CancelledError:
                pass
            # Emit analytics (don't emit for WaitingChildrenError)
            if not isinstance(error_occurred, WaitingChildrenError):
                processing_ms = int((time.time() - start_time) * 1000)
                await self._emit_analytics(job, result, processing_ms, error_occurred)
            # Clear correlation ID after job completes
            clear_correlation_id()

    async def enqueue_child_job(self, parent_job_id: str, job_name: str, job_data: dict) -> Any:
        """
        Enqueues a child job, making the current job its parent.

        Args:
            parent_job_id: The ID of the parent job.
            job_name: The name of the child job to enqueue.
            job_data: The data for the child job.

        Returns:
            The newly created job object.
        """
        queue = QueueManager.get_queue(self.queue_name)
        logger.info(f"Enqueueing child job '{job_name}' for parent '{parent_job_id}' in queue '{self.queue_name}'.")
        job = await queue.add(name=job_name, data=job_data, opts={"parentId": parent_job_id})
        return job

    def _signal_handler(self):
        logger.info(f"Shutdown signal received for {self.queue_name}. Shutting down...")
        self._shutdown_event.set()

    def _start_health_server(self) -> None:
        """
        Start the health check HTTP server for Kubernetes probes.

        Auto-discovers available dependency checks from environment variables.
        Disable by setting HEALTH_PORT=0.
        """
        try:
            from ..core_lib_health import HealthServer
            health_port = int(os.getenv("HEALTH_PORT", "8080"))
            if health_port == 0:
                logger.info("Health server disabled (HEALTH_PORT=0)")
                return
            server = HealthServer.from_environment(port=health_port)
            server.start()
        except Exception as e:
            # Health server failure should never prevent the worker from starting
            logger.warning(f"Failed to start health server: {e}")

    async def run(self) -> None:
        # **CRITICAL FIX**: Prevent the run method from being entered more than once.
        if self._is_running:
            logger.warning(f"Worker for queue '{self.queue_name}' is already running. Ignoring redundant run call.")
            return
        self._is_running = True

        # Start health check server for Kubernetes probes
        self._start_health_server()

        logger.info(f"Worker starting for queue: {self.queue_name}")

        loop = asyncio.get_event_loop()
        loop.add_signal_handler(signal.SIGTERM, self._signal_handler)
        loop.add_signal_handler(signal.SIGINT, self._signal_handler)

        # Retry loop: reconnect on transient Redis/connection failures
        max_retries = int(os.getenv("WORKER_MAX_CONNECT_RETRIES", "0"))  # 0 = infinite
        retry_delay = int(os.getenv("WORKER_CONNECT_RETRY_DELAY_S", "5"))
        max_retry_delay = int(os.getenv("WORKER_CONNECT_MAX_RETRY_DELAY_S", "60"))
        attempt = 0

        while not self._shutdown_event.is_set():
            attempt += 1
            try:
                # Create worker using adapter pattern
                logger.info(
                    f"Creating worker via adapter: {self._backend_adapter.__class__.__name__} "
                    f"(attempt {attempt})"
                )
                self._worker_instance = await self._backend_adapter.create_worker(
                    self.queue_name,
                    self._job_processor,
                    {"connection": self.redis_connection}
                )

                worker_task = asyncio.create_task(self._worker_instance.run())

                # Wait for either shutdown signal or worker crash
                done, _ = await asyncio.wait(
                    [worker_task, asyncio.create_task(self._shutdown_event.wait())],
                    return_when=asyncio.FIRST_COMPLETED,
                )

                if self._shutdown_event.is_set():
                    logger.info(f"Gracefully shutting down worker {self.queue_name}...")
                    await self.close()
                    worker_task.cancel()
                    try:
                        await worker_task
                    except asyncio.CancelledError:
                        logger.info(f"Worker task for {self.queue_name} cancelled successfully.")
                    break

                # Worker task completed unexpectedly (crashed)
                for task in done:
                    if task.exception():
                        raise task.exception()

            except Exception as e:
                # Clean up current worker instance before retry
                if self._worker_instance and not self._worker_instance.closed:
                    try:
                        await self._backend_adapter.close_worker(self._worker_instance)
                    except Exception:
                        pass
                    self._worker_instance = None

                if self._shutdown_event.is_set():
                    break

                if max_retries > 0 and attempt >= max_retries:
                    logger.error(
                        f"Worker for queue {self.queue_name} failed after {attempt} attempts, giving up: {e}",
                        exc_info=True,
                    )
                    break

                # Exponential backoff with cap
                current_delay = min(retry_delay * (2 ** (attempt - 1)), max_retry_delay)
                logger.warning(
                    f"Worker for queue {self.queue_name} crashed (attempt {attempt}): {e}. "
                    f"Retrying in {current_delay}s...",
                )

                try:
                    await asyncio.wait_for(self._shutdown_event.wait(), timeout=current_delay)
                    # If we reach here, shutdown was requested during the delay
                    break
                except asyncio.TimeoutError:
                    # Timeout expired, retry
                    continue

        if self._worker_instance and not self._worker_instance.closed:
            await self._backend_adapter.close_worker(self._worker_instance)
        self._is_running = False
        logger.info(f"Worker {self.queue_name} shutdown complete.")

    async def close(self) -> None:
        if self._worker_instance and not self._worker_instance.closed:
            await self._backend_adapter.close_worker(self._worker_instance)
            self._worker_instance = None
            self._is_running = False # Reset state
            logger.info(f"Worker {self.queue_name} connections closed.")