from verdictswarm_mcp import main


main()
