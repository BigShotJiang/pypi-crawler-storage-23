"""SSE transport middleware for per-session provider API key injection.

Reads the X-Model-Keys HTTP header from incoming /messages/ requests,
parses the comma-separated provider=key format, and stores the result
in a ContextVar accessible from tool functions.

Header format: X-Model-Keys: openai=sk-...,anthropic=sk-ant-...
"""

import contextvars

from starlette.types import ASGIApp, Receive, Scope, Send

from src.analytics import sse_analytics_id

# Per-request provider keys from HTTP headers.
# Tools check this ContextVar and merge with the lifespan key registry.
sse_provider_keys: contextvars.ContextVar[dict[str, str]] = contextvars.ContextVar(
    "sse_provider_keys", default={}
)

_HEADER_NAME = b"x-model-keys"


def _parse_model_keys_header(raw_value: bytes) -> dict[str, str]:
    """Parse X-Model-Keys header value into a provider->key dict.

    Expected format: provider1=key1,provider2=key2
    Provider names are lowercased. Empty values are skipped.
    """
    keys: dict[str, str] = {}
    text = raw_value.decode("utf-8", errors="ignore").strip()
    if not text:
        return keys

    for pair in text.split(","):
        pair = pair.strip()
        if "=" not in pair:
            continue
        provider, _, value = pair.partition("=")
        provider = provider.strip().lower()
        value = value.strip()
        if provider and value:
            keys[provider] = value

    return keys


class SSEKeyMiddleware:
    """ASGI middleware that extracts provider keys from X-Model-Keys header.

    Only processes HTTP requests (the /messages/ POST endpoint where tool
    execution happens in SSE transport). Sets a ContextVar so tool functions
    can access per-session keys.
    """

    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        # Extract session_id from query string for analytics
        query_string = scope.get("query_string", b"").decode("utf-8", errors="ignore")
        session_id = ""
        for param in query_string.split("&"):
            if param.startswith("session_id="):
                session_id = param.split("=", 1)[1]
                break

        # Extract X-Model-Keys header
        headers = dict(scope.get("headers", []))
        raw_value = headers.get(_HEADER_NAME, b"")

        analytics_token = sse_analytics_id.set(session_id) if session_id else None
        try:
            if raw_value:
                parsed = _parse_model_keys_header(raw_value)
                token = sse_provider_keys.set(parsed)
                try:
                    await self.app(scope, receive, send)
                finally:
                    sse_provider_keys.reset(token)
            else:
                await self.app(scope, receive, send)
        finally:
            if analytics_token is not None:
                sse_analytics_id.reset(analytics_token)
