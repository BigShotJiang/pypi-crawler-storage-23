"""FastMCP server entry point for the Okareo MCP server.

Validates the API key at startup, registers all MCP tools, and runs the server.
Supports stdio (default) and SSE transports via the TRANSPORT environment variable.
"""

import os
import sys
from contextlib import asynccontextmanager

from mcp.server.fastmcp import FastMCP

from src.analytics import emit_tool_event, init_analytics, shutdown_analytics
from src.key_registry import scan_provider_keys
from src.okareo_client import create_okareo_client
from src.tools import docs, models, scenarios, simulations, tests

_server_ready = False
_analytics_client = None


@asynccontextmanager
async def lifespan(server: FastMCP):
    """Validate API key and initialize Okareo client at startup."""
    global _server_ready

    api_key = os.environ.get("OKAREO_API_KEY", "").strip()

    if not api_key:
        print(
            "OKAREO_API_KEY environment variable is not set. "
            "Get your API key from app.okareo.com and configure it "
            "in your MCP server settings.",
            file=sys.stderr,
        )
        raise SystemExit(1)

    base_url = os.environ.get("OKAREO_BASE_URL", "https://api.okareo.com/")
    print(
        f"Base URL for Connection {base_url}. ",
        file=sys.stderr,
    )

    # Redirect stdout to stderr during SDK init so any SDK prints
    # (e.g. validation errors) don't corrupt the MCP stdio protocol.
    _real_stdout = sys.stdout
    sys.stdout = sys.stderr
    try:
        okareo = create_okareo_client(api_key, base_url)
    except TypeError:
        print(
            "OKAREO_API_KEY is invalid. The Okareo API rejected the "
            "provided key. Verify your key at app.okareo.com.",
            file=sys.stderr,
        )
        raise SystemExit(1)
    except Exception as e:
        error_name = type(e).__name__
        if error_name in ("ConnectError", "TimeoutException", "ConnectTimeout"):
            target = base_url
            print(
                f"Cannot connect to the Okareo API at {target}. "
                "Check your network connection.",
                file=sys.stderr,
            )
            raise SystemExit(1)
        raise
    finally:
        sys.stdout = _real_stdout

    key_registry = scan_provider_keys()
    if key_registry:
        provider_names = ", ".join(sorted(key_registry.keys()))
        print(f"Provider keys loaded: {provider_names}", file=sys.stderr)
    else:
        print("No provider API keys configured.", file=sys.stderr)

    transport = os.environ.get("TRANSPORT", "stdio")
    port = os.environ.get("PORT", "8000")
    print(
        f"Okareo MCP server started successfully. "
        f"Transport: {transport}, Port: {port}",
        file=sys.stderr,
    )
    global _analytics_client
    _analytics_client = init_analytics()

    _server_ready = True
    try:
        yield {
            "okareo": okareo,
            "key_registry": key_registry,
            "analytics": _analytics_client,
        }
    finally:
        _server_ready = False
        await shutdown_analytics(_analytics_client)
        _analytics_client = None


mcp = FastMCP(
    "okareo-mcp",
    lifespan=lifespan,
    host=os.environ.get("FASTMCP_HOST", "127.0.0.1"),
    port=int(os.environ.get("FASTMCP_PORT", "8000")),
)

# Register all tools
tests.register_tools(mcp)
scenarios.register_tools(mcp)
models.register_tools(mcp)
simulations.register_tools(mcp)
docs.register_tools(mcp)

# Instrument tool calls with analytics
_original_call_tool = mcp.call_tool


async def _instrumented_call_tool(name, arguments):
    success = True
    try:
        result = await _original_call_tool(name, arguments)
        return result
    except Exception:
        success = False
        raise
    finally:
        try:
            if _analytics_client is not None:
                emit_tool_event(_analytics_client, tool_name=name, success=success)
        except Exception:
            pass


mcp.call_tool = _instrumented_call_tool


def main():
    """CLI entry point for okareo-mcp."""
    transport = os.environ.get("TRANSPORT", "stdio")

    if transport == "sse":
        from src.sse_middleware import SSEKeyMiddleware

        app = mcp.sse_app()
        app = SSEKeyMiddleware(app)
        import uvicorn

        host = os.environ.get("FASTMCP_HOST", "127.0.0.1")
        port = int(os.environ.get("FASTMCP_PORT", "8000"))
        uvicorn.run(app, host=host, port=port)
    else:
        mcp.run(transport=transport)


if __name__ == "__main__":
    main()
