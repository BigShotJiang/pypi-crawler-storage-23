# Code-Based Check Template

A Code Check is a Python function that programmatically evaluates a target's output. Use this when you need deterministic, rule-based evaluation that goes beyond what a prompt-based check can do.

## Function Signature

```python
def check(output: str, input: str, result: str) -> bool | int | float:
    """Evaluate the model output against the expected result.

    Args:
        output: The target's actual response (model output).
        input: The original user input from the scenario.
        result: The expected/reference result from the scenario.

    Returns:
        bool: True if the check passes, False otherwise.
        int/float: A numeric score for scored checks.
    """
    # Your evaluation logic here
    pass
```

## Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `output` | str | The target's actual response |
| `input` | str | The original scenario input |
| `result` | str | The expected result from the scenario |

## Return Types

- **bool**: Return `True`/`False` for pass/fail checks
- **int** or **float**: Return a numeric score for scored checks

## Example: Keyword Presence Check

```python
def check(output: str, input: str, result: str) -> bool:
    """Check that all required keywords from the expected result appear in the output."""
    keywords = [k.strip().lower() for k in result.split(",")]
    output_lower = output.lower()
    return all(k in output_lower for k in keywords)
```

## Example: Length Constraint Check

```python
def check(output: str, input: str, result: str) -> bool:
    """Verify the output is within an acceptable length range."""
    word_count = len(output.split())
    return 10 <= word_count <= 500
```

## Example: JSON Format Check

```python
def check(output: str, input: str, result: str) -> bool:
    """Verify the output is valid JSON."""
    import json
    try:
        json.loads(output)
        return True
    except (json.JSONDecodeError, TypeError):
        return False
```

## Usage in Okareo

Register the function as a Code Check in Okareo. The function will be called once per scenario row during evaluation. Results appear alongside prompt-based check results in your test run.
