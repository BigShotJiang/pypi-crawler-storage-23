"""Temporal-based dispatch for durable workflow orchestration."""
