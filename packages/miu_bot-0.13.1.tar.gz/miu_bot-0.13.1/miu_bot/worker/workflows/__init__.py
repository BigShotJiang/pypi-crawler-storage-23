"""Workflow definitions for message processing."""
