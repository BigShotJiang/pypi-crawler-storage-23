"""Unit tests for context module."""
