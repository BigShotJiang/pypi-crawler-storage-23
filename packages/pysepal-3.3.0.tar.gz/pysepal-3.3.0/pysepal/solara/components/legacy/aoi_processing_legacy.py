"""Pure processing functions for AOI selection.

This module provides stateless functions for AOI processing, separating
business logic from UI components. All functions are async-friendly and
return immutable dataclasses.

Both GEE and non-GEE workflows use GAUL 2024 administrative boundaries:
- Admin names: pygaul's local parquet file (instant, ~1ms lookups)
- GEE geometry: sat-io's GAUL 2024 Earth Engine asset
- Non-GEE geometry: FAO's GAUL 2024 WFS service
- Preview: FAO's GAUL 2024 WMS service
"""

import asyncio
import json
from dataclasses import dataclass, field
from datetime import datetime as dt
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import geopandas as gpd
import pandas as pd
import pygaul
import requests
from deprecated.sphinx import versionadded
from ipyleaflet import WMSLayer

from pysepal.message import ms
from pysepal.scripts import utils as su
from pysepal.scripts.gee_interface import GEEInterface

__all__ = [
    "AoiResult",
    "fetch_admin_items",
    "fetch_admin_bounds_async",
    "process_admin",
    "process_draw",
    "create_wms_preview_layer",
    "remove_wms_preview_layer",
    "WMS_PREVIEW_LAYER_NAME",
    "FAO_WMS_BASE_URL",
    "FAO_GAUL_LAYERS",
]

# Path to GAUL -> ISO-3 mapping file
GAUL_ISO_MAPPING: Path = Path(__file__).parents[3] / "data" / "gaul_iso.json"

# FAO GAUL WMS/WFS Configuration
# WMS: https://data.apps.fao.org/map/gsrv/gsrv1/gaul/wms?service=WMS&request=GetCapabilities
# WFS: https://data.apps.fao.org/map/gsrv/gsrv1/gaul/wfs?service=WFS&request=GetCapabilities
FAO_WMS_BASE_URL = "https://data.apps.fao.org/map/gsrv/gsrv1/gaul/wms"
FAO_WFS_BASE_URL = "https://data.apps.fao.org/map/gsrv/gsrv1/gaul/wfs"

# FAO GAUL WMS/WFS layers
# Note: g2024_2023_0 only has ~128 countries (disputed territories)
# gaul_2024_l0 has full 272 countries coverage
FAO_GAUL_LAYERS = {
    0: "gaul:gaul_2024_l0",  # Full coverage layer for countries
    1: "gaul:g2024_2023_1",
    2: "gaul:g2024_2023_2",
}
# Property naming convention in FAO WFS/WMS and pygaul: gaul{level}_name, gaul{level}_code
# Level 0 has: gaul0_name, gaul0_code, iso3_code, continent
# Level 1 has: gaul0_code, gaul0_name, gaul1_code, gaul1_name, iso3_code
# Level 2 has: gaul0_code, gaul0_name, gaul1_code, gaul1_name, gaul2_code, gaul2_name, iso3_code

# WMS preview layer name constant
WMS_PREVIEW_LAYER_NAME = "aoi_wms_preview"

# Simple in-process cache to avoid repeating admin lookups.
# Keyed by (level, parent_code) - same for both GEE and non-GEE since GAUL 2024 is used for both.
_ADMIN_ITEMS_CACHE: Dict[tuple, List[Dict[str, str]]] = {}

# Cache for WFS geometry results
_WFS_GEOMETRY_CACHE: Dict[str, gpd.GeoDataFrame] = {}

# Cache for WFS bounds results (lighter than full geometry)
_WFS_BOUNDS_CACHE: Dict[str, tuple] = {}


async def fetch_admin_bounds_async(level: int, admin_code: str) -> tuple:
    """Fetch bounding box for an admin boundary from FAO WFS asynchronously.

    This fetches only the bbox without the full geometry, making it faster
    for zoom operations. The bbox is cached for subsequent calls.

    Args:
        level: Administrative level (0, 1, or 2)
        admin_code: The admin code to fetch bounds for

    Returns:
        Tuple of (minx, miny, maxx, maxy) in EPSG:4326

    Example:
        ```python
        bounds = await fetch_admin_bounds_async(level=0, admin_code="301")
        map_.zoom_bounds(bounds)
        ```
    """
    cache_key = f"bounds_{level}_{admin_code}"
    if cache_key in _WFS_BOUNDS_CACHE:
        return _WFS_BOUNDS_CACHE[cache_key]

    # For level 0, query the full coverage layer
    layer = FAO_GAUL_LAYERS[level]
    params = {
        "service": "WFS",
        "version": "2.0.0",
        "request": "GetFeature",
        "typeName": layer,
        "outputFormat": "application/json",
        "srsName": "EPSG:4326",
        "CQL_FILTER": f"gaul{level}_code={admin_code}",
        # Request only non-geometry properties to reduce payload
        # The bbox is still included in the response metadata
        "propertyName": f"gaul{level}_code,gaul{level}_name",
    }

    response = requests.get(FAO_WFS_BASE_URL, params=params, timeout=30)
    response.raise_for_status()
    data = response.json()

    # bbox is at the response level: [minx, miny, maxx, maxy]
    if "bbox" in data:
        bounds = tuple(data["bbox"])
    # Fallback: check feature-level bbox
    elif data.get("features") and "bbox" in data["features"][0]:
        bounds = tuple(data["features"][0]["bbox"])
    else:
        raise ValueError(f"No bbox found for gaul{level}_code={admin_code}")

    _WFS_BOUNDS_CACHE[cache_key] = bounds
    return bounds


def create_wms_preview_layer(
    level: int,
    admin_code: str,
    name: str = WMS_PREVIEW_LAYER_NAME,
) -> Any:
    """Create an ipyleaflet WMSLayer for previewing an admin boundary.

    This creates a lightweight WMS layer that displays the admin boundary
    on the map without fetching the full geometry. Ideal for previewing
    selections before committing.

    Args:
        level: Administrative level (0, 1, or 2)
        admin_code: The admin code to highlight
        name: Layer name for identification (default: "aoi_wms_preview")

    Returns:
        ipyleaflet.WMSLayer configured to display the admin boundary

    Example:
        ```python
        from pysepal.solara.components.aoi import create_wms_preview_layer

        # Create preview layer for France
        layer = create_wms_preview_layer(level=0, admin_code="301")
        map_.add_layer(layer)
        ```
    """
    # Use the appropriate layer for the level
    wms_layer = FAO_GAUL_LAYERS[level]
    cql_filter = f"gaul{level}_code={admin_code}"

    # Build URL with CQL_FILTER
    url = f"{FAO_WMS_BASE_URL}?CQL_FILTER={cql_filter}"

    return WMSLayer(
        url=url,
        layers=wms_layer,
        format="image/png",
        transparent=True,
        name=name,
    )


def remove_wms_preview_layer(map_: Any, name: str = WMS_PREVIEW_LAYER_NAME) -> None:
    """Remove WMS preview layer from map if it exists.

    Args:
        map_: The ipyleaflet Map or SepalMap instance
        name: The layer name to remove (default: "aoi_wms_preview")
    """
    for layer in list(map_.layers):
        if hasattr(layer, "name") and layer.name == name:
            map_.remove_layer(layer)


def _fetch_admin_names_from_pygaul(level: int, parent_code: Optional[str] = None) -> pd.DataFrame:
    """Fetch administrative names from pygaul's local parquet file.

    This uses pygaul.Names which reads from a local ~1MB parquet file,
    providing instant lookups (~1ms) compared to WFS queries (~30s).

    Args:
        level: Administrative level (0, 1, or 2)
        parent_code: Parent admin code for filtering (e.g., "301" for France)

    Returns:
        DataFrame with columns [gaul{level}_name, gaul{level}_code]
    """
    # pygaul.Names returns a DataFrame subclass with the admin names
    # admin=None for level 0, parent_code for levels 1 and 2
    df = pygaul.Names(admin=parent_code if parent_code else None, content_level=level)
    return df.sort_values(by=[df.columns[0]]) if not df.empty else df


async def _fetch_wfs_geometry_async(level: int, admin_code: str) -> gpd.GeoDataFrame:
    """Fetch administrative geometry from FAO WFS asynchronously.

    Uses the appropriate GAUL 2024 WFS layer for each level:
    - Level 0: gaul:gaul_2024_l0 (272 countries)
    - Level 1: gaul:g2024_2023_1
    - Level 2: gaul:g2024_2023_2

    Args:
        level: Administrative level (0, 1, or 2)
        admin_code: The admin code to fetch

    Returns:
        GeoDataFrame with the geometry
    """
    cache_key = f"wfs_{level}_{admin_code}"
    if cache_key in _WFS_GEOMETRY_CACHE:
        return _WFS_GEOMETRY_CACHE[cache_key]

    # Query the appropriate layer directly
    layer = FAO_GAUL_LAYERS[level]
    params = {
        "service": "WFS",
        "version": "2.0.0",
        "request": "GetFeature",
        "typeName": layer,
        "outputFormat": "application/json",
        "srsName": "EPSG:4326",
        "CQL_FILTER": f"gaul{level}_code={admin_code}",
    }

    response = requests.get(FAO_WFS_BASE_URL, params=params, timeout=120)
    response.raise_for_status()
    data = response.json()

    if not data.get("features"):
        raise ValueError(f"No features found for gaul{level}_code={admin_code}")

    gdf = gpd.GeoDataFrame.from_features(data["features"], crs="EPSG:4326")

    _WFS_GEOMETRY_CACHE[cache_key] = gdf
    return gdf


@dataclass(frozen=True)
@versionadded(version="3.1", reason="Pure Solara AOI result dataclass")
class AoiResult:
    """Immutable result from AOI selection.

    This dataclass represents the output of any AOI selection method.
    It is designed to be immutable (frozen) for predictable state management.

    For admin boundaries, geometry (GDF) is NOT fetched automatically to keep
    selections fast. Use `get_gdf()` or `get_gdf_async()` to fetch the geometry
    when needed.

    Attributes:
        method: Selection method used (e.g., "ADMIN0", "ADMIN1", "ADMIN2", "DRAW")
        name: Human-readable name for the AOI (e.g., "FRA_Île-de-France")
        gdf: GeoDataFrame with the geometry (None for admin methods - use get_gdf())
        feature_collection: ee.FeatureCollection for GEE workflows (None otherwise)
        admin: Admin code for admin methods (None for other methods)
        gee: Whether this result was created with GEE binding

    Example:
        ```python
        result = await process_admin("ADMIN1", "3431", gee=False)
        print(f"Selected: {result.name}")

        # Fetch geometry when needed
        gdf = await result.get_gdf_async()
        ```
    """

    method: str
    name: str
    gdf: Optional[gpd.GeoDataFrame] = field(default=None, repr=False)
    feature_collection: Optional[Any] = field(default=None, repr=False)  # ee.FeatureCollection
    admin: Optional[str] = None
    gee: bool = False

    async def get_gdf_async(self) -> Optional[gpd.GeoDataFrame]:
        """Fetch the GeoDataFrame asynchronously.

        For admin boundaries (non-GEE), this fetches the geometry from FAO WFS.
        For GEE results, this returns None (use feature_collection instead).
        For DRAW results, this returns the already-available gdf.

        Returns:
            GeoDataFrame with the geometry, or None for GEE results.
        """
        # If we already have a GDF, return it
        if self.gdf is not None:
            return self.gdf

        # For GEE results, we don't fetch GDF (users should use feature_collection)
        if self.gee:
            return None

        # For admin methods, fetch from WFS
        if self.admin is not None and self.method in ["ADMIN0", "ADMIN1", "ADMIN2"]:
            level = int(self.method[-1])
            return await _fetch_wfs_geometry_async(level, self.admin)

        return None


async def fetch_admin_items(
    level: int,
    parent_code: str = "",
    gee: bool = True,
) -> List[Dict[str, str]]:
    """Fetch administrative region items for dropdown selection.

    Retrieves a list of administrative regions at the specified level,
    optionally filtered by a parent region code.

    Both GEE and non-GEE modes use pygaul's local GAUL 2024 parquet file
    for instant name lookups (~1ms). The gee parameter only affects
    geometry fetching in process_admin().

    Args:
        level: Administrative level (0, 1, or 2)
        parent_code: Parent admin code to filter results. Empty string for level 0.
        gee: Kept for API compatibility. Both modes use the same GAUL 2024 codes.

    Returns:
        List of dicts with 'text' (display name) and 'value' (admin code) keys.

    Example:
        ```python
        # Get all countries (instant from local parquet)
        countries = await fetch_admin_items(level=0)

        # Get regions within France (code 301 in GAUL 2024)
        regions = await fetch_admin_items(level=1, parent_code="301")
        ```
    """
    # Cache key doesn't include gee since both modes use same GAUL 2024 codes
    cache_key = (level, parent_code or "")
    cached = _ADMIN_ITEMS_CACHE.get(cache_key)
    if cached is not None:
        return cached

    # Use pygaul's local parquet for instant lookups (both GEE and non-GEE)
    df = _fetch_admin_names_from_pygaul(level, parent_code or None)

    # pygaul.Names returns DataFrame with columns: gaul{level}_name, gaul{level}_code
    name_col = df.columns[0]  # gaul{level}_name
    code_col = df.columns[1]  # gaul{level}_code

    item_list = []
    for _, r in df.iterrows():
        text = su.normalize_str(r[name_col], folder=False)
        item_list.append({"text": text, "value": str(r[code_col])})

    _ADMIN_ITEMS_CACHE[cache_key] = item_list
    return item_list


async def process_admin(
    method: str,
    admin_code: str,
    gee: bool = True,
    gee_interface: Optional[Any] = None,
) -> AoiResult:
    """Process administrative boundary selection.

    Fetches the geometry for the given administrative code using either
    Earth Engine (sat-io GAUL 2024 asset) or FAO GAUL 2024 WFS service.

    Both modes use the same GAUL 2024 codes from pygaul's local parquet.

    Args:
        method: The admin method ("ADMIN0", "ADMIN1", or "ADMIN2")
        admin_code: The administrative code to fetch (GAUL 2024 code)
        gee: If True, use Earth Engine with sat-io's GAUL 2024 asset.
             If False, use FAO GAUL 2024 WFS service.
        gee_interface: Optional GEEInterface for Earth Engine operations

    Returns:
        AoiResult with the administrative boundary data

    Raises:
        ValueError: If admin_code is empty or invalid

    Example:
        ```python
        # Select France (non-GEE, using FAO WFS)
        result = await process_admin("ADMIN0", "301", gee=False)

        # Select France (GEE, using sat-io asset)
        result = await process_admin("ADMIN0", "301", gee=True)
        ```
    """
    if not admin_code:
        raise ValueError(ms.aoi_sel.exception.no_admlyr)

    if method not in ["ADMIN0", "ADMIN1", "ADMIN2"]:
        raise ValueError(f"Invalid admin method: {method}")

    level = int(method[-1])  # Extract level from method name

    if gee:
        # Initialize Earth Engine
        su.init_ee()

        # Use provided interface or create a new one
        interface = gee_interface or GEEInterface()

        # Use pygaul.Items to get the feature collection (handles all the EE logic)
        feature_collection = pygaul.Items(admin=admin_code)

        # Get properties for naming (async call)
        feature = feature_collection.first()
        properties = await interface.get_info_async(feature.toDictionary(feature.propertyNames()))

        # Build name from ISO code and admin names
        # GAUL 2024 uses: iso3_code, gaul0_name, gaul1_name, gaul2_name
        iso = properties.get("iso3_code", "")
        if not iso or iso.startswith("x"):  # 'x' prefix means disputed/unknown
            iso_mapping = json.loads(GAUL_ISO_MAPPING.read_text())
            gaul0_code = str(properties.get("gaul0_code", ""))
            iso = iso_mapping.get(gaul0_code, "UNK")

        # Collect admin names from all levels up to current
        names = [iso]
        for lvl in range(1, level + 1):
            name_col = f"gaul{lvl}_name"
            if name_col in properties and properties.get(name_col):
                names.append(su.normalize_str(properties[name_col]))

        name = "_".join(names)

        return AoiResult(
            method=method,
            name=name,
            gdf=None,  # Lazy - users can use get_gdf() if needed
            feature_collection=feature_collection,
            admin=admin_code,
            gee=True,
        )

    else:
        # Non-GEE: Build name from pygaul's local parquet (instant, no WFS call)
        # GDF will be fetched lazily via AoiResult.get_gdf_async() when needed

        # Get admin info from pygaul's full parquet (includes iso3_code)
        full_df = pygaul._df()
        code_col = f"gaul{level}_code"
        admin_rows = full_df[full_df[code_col] == str(admin_code)]

        if admin_rows.empty:
            raise ValueError(f"Admin code {admin_code} not found in GAUL 2024")

        # Get first row for name building
        row = admin_rows.iloc[0]

        # Build name from ISO code and admin names
        iso = row.get("iso3_code", "")
        if not iso or (isinstance(iso, str) and iso.startswith("x")):
            # Fall back to mapping file
            iso_mapping = json.loads(GAUL_ISO_MAPPING.read_text())
            gaul0_code = str(row.get("gaul0_code", ""))
            iso = iso_mapping.get(gaul0_code, "UNK")

        # Collect admin names from all levels up to current
        names = [iso]
        for lvl in range(1, level + 1):
            name_col = f"gaul{lvl}_name"
            if name_col in full_df.columns and row.get(name_col):
                names.append(su.normalize_str(row[name_col]))

        name = "_".join(names)

        return AoiResult(
            method=method,
            name=name,
            gdf=None,  # Lazy - users can use get_gdf_async() when needed
            feature_collection=None,
            admin=admin_code,
            gee=False,
        )


def process_draw(
    geo_json: Dict,
    name: str = "",
    gee: bool = True,
    folder: Union[str, Path] = "",
) -> AoiResult:
    """Process a drawn geometry from map interaction.

    Converts a GeoJSON dict (from DrawControl) into an AoiResult.

    Args:
        geo_json: GeoJSON dict with 'features' key from DrawControl.get_data()
        name: Optional name for the AOI. If empty, generates timestamp-based name.
        gee: If True, create Earth Engine FeatureCollection
        folder: Folder for GEE asset export (only used if gee=True)

    Returns:
        AoiResult with the drawn geometry

    Raises:
        ValueError: If geo_json is empty or invalid

    Example:
        ```python
        # From DrawControl
        features = draw_control.get_data()
        result = process_draw(features, name="my_area", gee=False)
        ```
    """
    if not geo_json or not geo_json.get("features"):
        raise ValueError(ms.aoi_sel.exception.no_draw)

    # Clean style properties from features
    cleaned_features = []
    for feat in geo_json["features"]:
        cleaned_feat = feat.copy()
        if "properties" in cleaned_feat and "style" in cleaned_feat.get("properties", {}):
            cleaned_feat["properties"] = {
                k: v for k, v in cleaned_feat["properties"].items() if k != "style"
            }
        cleaned_features.append(cleaned_feat)

    cleaned_geojson = {"type": "FeatureCollection", "features": cleaned_features}

    # Create GeoDataFrame
    gdf = gpd.GeoDataFrame.from_features(cleaned_geojson).set_crs(epsg=4326)

    # Generate name if not provided
    if not name:
        name = f"drawn_{dt.now().strftime('%Y%m%d_%H%M%S')}"
    else:
        name = su.normalize_str(name)

    feature_collection = None
    if gee:

        su.init_ee()
        feature_collection = su.geojson_to_ee(gdf.__geo_interface__)

    return AoiResult(
        method="DRAW",
        name=name,
        gdf=gdf,
        feature_collection=feature_collection,
        admin=None,
        gee=gee,
    )
