"""Solara-native AOI (Area of Interest) selection component.

This module provides a pure Solara component for AOI selection following the modern
Solara patterns with value/on_value parameters instead of the legacy model-based approach.

Location: sepal_ui/solara/components/aoi_solara.py

Usage:
    from pysepal.solara.components.aoi import AoiView

    @solara.component
    def MyApp():
        aoi_data = solara.use_reactive(None)

        AoiView(
            value=aoi_data,
            methods="ALL",
            gee=True
        )

        # Access AOI data when available
        if aoi_data.value:
            area = aoi_data.value.get("area")
            gdf = aoi_data.value.get("gdf")
"""

from datetime import datetime as dt
from pathlib import Path
from typing import Callable, Dict, List, Optional, Union

import geopandas as gpd
import pygadm
import pygaul
import reacton.ipyvuetify as rv
import solara
from deprecated.sphinx import versionadded

from pysepal import mapping as sm
from pysepal.aoi.aoi_model import AoiModel
from pysepal.message import ms
from pysepal.scripts import utils as su

__all__ = ["AoiView", "MethodSelect", "AdminField"]

# Constants from AoiModel
CUSTOM = AoiModel.CUSTOM
ADMIN = AoiModel.ADMIN
ALL = "All"
select_methods = AoiModel.METHODS


# Simple in-process cache to avoid repeating expensive admin lookups across remounts.
# Keyed by (gee, level, filter_).
_ADMIN_ITEMS_CACHE: Dict[tuple, List[Dict[str, str]]] = {}


@solara.component
def MethodSelect(
    methods: Union[str, List[str]] = "ALL",
    gee: bool = True,
    map_: Optional[sm.SepalMap] = None,
    value: Union[str, solara.Reactive[str]] = "",
    on_value: Optional[Callable[[str], None]] = None,
):
    """A method selector for AOI selection.

    Lists available methods for AOI selection. 'ALL' will select all available methods (default).
    'ADMIN' only the admin methods, 'CUSTOM' only the custom methods.
    Individual methods can be added (e.g., ['ADMIN0', 'SHAPE']) or removed (e.g., ['-DRAW', '-ASSET']).

    Args:
        methods: A list of methods from the available list (ADMIN0, ADMIN1, ADMIN2, SHAPE, DRAW, POINTS, ASSET)
        gee: Whether to bind to Earth Engine or not
        map_: Link the aoi_view to a custom SepalMap to display the output, default to None
        value: Current selected method (can be reactive)
        on_value: Callback when method changes

    Returns:
        A Solara select component for method selection
    """
    # Normalize value to reactive
    reactive_value = solara.use_reactive(value, on_value)
    del value, on_value

    # Create the method list based on input
    if methods == "ALL":
        method_dict = select_methods
    elif methods == "ADMIN":
        method_dict = {k: v for k, v in select_methods.items() if v["type"] == ADMIN}
    elif methods == "CUSTOM":
        method_dict = {k: v for k, v in select_methods.items() if v["type"] == CUSTOM}
    elif isinstance(methods, list):
        if any(m[0] == "-" for m in methods) and not all(m[0] == "-" for m in methods):
            raise ValueError("Cannot mix adding and removing methods")

        if methods[0][0] == "-":
            to_remove = [method[1:] for method in methods]
            method_dict = {k: v for k, v in select_methods.items() if k not in to_remove}
        else:
            method_dict = {k: select_methods[k] for k in methods if k in select_methods}
    else:
        raise ValueError("Invalid methods parameter")

    # Clean the list from things we can't use
    if not gee:
        method_dict.pop("ASSET", None)
    if map_ is None:
        method_dict.pop("DRAW", None)

    # Build the item list with headers
    prev_type = None
    items = []
    for k, m in method_dict.items():
        current_type = m["type"]

        if prev_type != current_type:
            items.append({"header": current_type})
        prev_type = current_type

        items.append({"text": m["name"], "value": k})

    # Create the select component
    with rv.Select(
        label=ms.aoi_sel.method,
        items=items,
        v_model=reactive_value.value,
        dense=True,
        on_v_model=reactive_value.set,
    ):
        pass


@solara.component
def AdminField(
    level: int,
    parent_value: Optional[solara.Reactive[Optional[str]]] = None,
    gee: bool = True,
    value: Union[str, solara.Reactive[Optional[str]]] = None,
    on_value: Optional[Callable[[Optional[str]], None]] = None,
):
    """An administrative level selector.

    Bound to Earth Engine (GAUL 2015) or not (GADM). Allows selection of administrative
    codes taking into account the parent administrative level.

    Args:
        level: The administrative level of the field (0, 1, or 2)
        parent_value: The reactive value of the parent admin field to filter results
        gee: Whether to use Earth Engine or not (default to True)
        value: Current selected admin code (can be reactive)
        on_value: Callback when admin code changes

    Returns:
        A Solara select component for admin code selection
    """
    # Normalize value to reactive
    reactive_value = solara.use_reactive(value, on_value)
    del value, on_value

    # Component state
    items = solara.use_reactive([])
    is_visible = solara.use_reactive(False)

    def get_items(filter_: str = ""):
        """Update the item list based on the given filter."""
        cache_key = (gee, level, filter_ or "")
        cached = _ADMIN_ITEMS_CACHE.get(cache_key)
        if cached is not None:
            items.set(cached)
            return

        AdmNames = pygaul.Names if gee else pygadm.Names
        df = AdmNames(admin=filter_, content_level=level)
        df = df.sort_values(by=[df.columns[0]])

        # Format as item list for select component
        item_list = []
        for _, r in df.iterrows():
            text = su.normalize_str(r.iloc[0], folder=False)
            item_list.append({"text": text, "value": str(r.iloc[1])})

        _ADMIN_ITEMS_CACHE[cache_key] = item_list
        items.set(item_list)

    # Effect to update items when parent changes
    def update_items():
        if parent_value is not None and parent_value.value:
            reactive_value.set(None)  # Reset current value
            get_items(parent_value.value)
            is_visible.set(True)
        elif parent_value is None and level == 0:
            # Level 0 has no parent, load all items
            get_items()
            is_visible.set(True)
        else:
            items.set([])
            reactive_value.set(None)
            is_visible.set(False)

    # Run effect when parent changes or on mount
    parent_dep = parent_value.value if parent_value is not None else None
    solara.use_effect(update_items, [parent_dep])

    # Render only if visible
    if is_visible.value:
        with rv.Select(
            label=ms.aoi_sel.adm[level],
            items=items.value,
            v_model=reactive_value.value,
            clearable=True,
            on_v_model=reactive_value.set,
        ):
            pass


@solara.component
@versionadded(version="3.0", reason="Solara-native AOI selection component with value/on_value")
def AoiView(
    value: Union[Dict, solara.Reactive[Optional[Dict]]] = None,
    on_value: Optional[Callable[[Optional[Dict]], None]] = None,
    loading: Union[bool, solara.Reactive[bool]] = False,
    on_loading: Optional[Callable[[bool], None]] = None,
    methods: Union[str, List[str]] = "ALL",
    map_: Optional[sm.SepalMap] = None,
    gee: bool = True,
    folder: Union[str, Path] = "",
    map_style: Optional[dict] = None,
):
    """Solara-native component for AOI (Area of Interest) selection.

    Provides multiple selection methods including administrative boundaries (GADM/GAUL),
    vector files, drawn shapes, points, and Earth Engine assets. The component follows
    modern Solara patterns with value/on_value for reactive data flow.

    Args:
        value: Dictionary containing AOI data (gdf, method, admin, area, etc.). Can be reactive.
        on_value: Callback function called when AOI is selected/updated with AOI data dict
        methods: Methods to enable ('ALL', 'ADMIN', 'CUSTOM', or list of method names)
        map_: Link to a SepalMap instance for drawing and display
        gee: Whether to bind to Earth Engine
        folder: Folder name used in GEE components (for debugging)
        map_style: Custom style for AOI display on map

    Example:
        ```python
        @solara.component
        def MyApp():
            aoi_data = solara.use_reactive(None)
            my_map = sm.SepalMap()

            with solara.Column():
                AoiView(value=aoi_data, map_=my_map)

                # Display AOI info when available
                if aoi_data.value:
                    area = aoi_data.value.get("area")
                    solara.Info(f"Selected area: {area:.2f} ha")
        ```

    Returns:
        None. AOI data is passed through value/on_value parameters.

    Value Dictionary Structure:
        {
            "gdf": GeoDataFrame,      # The selected geometry
            "method": str,            # Selection method used (e.g., "ADMIN0")
            "admin": str,             # Admin code (for admin methods)
            "area": float,            # Area in hectares
            "bounds": tuple,          # (minx, miny, maxx, maxy)
            "name": str,              # Optional: AOI name
        }
    """
    # Normalize value/loading to reactive
    reactive_value = solara.use_reactive(value, on_value)
    reactive_loading = solara.use_reactive(loading, on_loading)
    del value, on_value, loading, on_loading

    # Validate GEE consistency between map and AoiView
    if map_ is not None and hasattr(map_, "gee"):
        if map_.gee != gee:
            raise ValueError(
                f"GEE setting mismatch: AoiView has gee={gee} but map has gee={map_.gee}. "
                f"Both must have the same GEE setting for proper functionality."
            )

    # Initialize Earth Engine once (avoid doing work on every render).
    def _ensure_ee():
        if gee:
            su.init_ee()
        return None

    solara.use_effect(_ensure_ee, [gee])  # noqa: SH101

    # Initialize DrawControl if map is provided
    aoi_dc = None
    if map_:
        aoi_dc = map_.dc

    # Internal model for processing (not exposed to user)
    model = solara.use_memo(lambda: AoiModel(gee=gee, folder=folder), [gee, folder])

    # State management - all hooks must be called unconditionally
    selected_method = solara.use_reactive("")
    admin_0_value = solara.use_reactive(None)
    admin_1_value = solara.use_reactive(None)
    admin_2_value = solara.use_reactive(None)
    vector_file = solara.use_reactive(None)
    points_file = solara.use_reactive(None)
    draw_name = solara.use_reactive(None)
    asset_name = solara.use_reactive(None)

    alert_message = solara.use_reactive("")
    alert_type = solara.use_reactive("info")

    def reset_inputs():
        """Reset all input values."""
        admin_0_value.set(None)
        admin_1_value.set(None)
        admin_2_value.set(None)
        vector_file.set(None)
        points_file.set(None)
        draw_name.set(None)
        asset_name.set(None)
        alert_message.set("")

    def create_aoi_dict() -> Optional[Dict]:
        """Create AOI data dictionary from model.

        Note: For GEE workflows, gdf is lazy-loaded. We don't access it here
        to avoid unnecessary computation. Users can access it later if needed.
        """
        if model.object_set == 0:
            return None

        try:
            # Build the AOI data dictionary without forcing gdf computation
            aoi_dict = {
                "model": model,  # Provide access to the model for lazy gdf access
                "method": model.method,
                "admin": model.admin if model.method in ["ADMIN0", "ADMIN1", "ADMIN2"] else None,
                "gee": gee,
            }

            # Add GEE feature collection for GEE workflows
            if gee and model.feature_collection:
                aoi_dict["feature_collection"] = model.feature_collection

            # Add computed properties that don't require gdf
            try:
                aoi_dict["area"] = model.get_area()
            except:
                aoi_dict["area"] = None

            try:
                aoi_dict["bounds"] = model.total_bounds()
            except:
                aoi_dict["bounds"] = None

            # Add name if available
            if hasattr(model, "name") and model.name:
                aoi_dict["name"] = model.name

            # For non-GEE or when _gdf is already loaded, include it
            if not gee or model._gdf is not None:
                aoi_dict["gdf"] = model._gdf

            return aoi_dict

        except Exception as e:
            print(f"Error creating AOI dict: {e}")
            return None

    async def process_aoi():
        """Process the selected AOI asynchronously.

        Returns:
            Success message
        """
        try:
            # Update model based on selected method
            method = selected_method.value

            if method in ["ADMIN0", "ADMIN1", "ADMIN2"]:
                # Get the appropriate admin value
                admin_value = None
                if method == "ADMIN0":
                    admin_value = admin_0_value.value
                elif method == "ADMIN1":
                    admin_value = admin_1_value.value
                elif method == "ADMIN2":
                    admin_value = admin_2_value.value

                if not admin_value:
                    raise ValueError(f"Please select a {method} region")

                # Set the admin attribute on the model, then call async_set_object
                model.admin = admin_value
                await model.async_set_object(method)

            elif method == "SHAPE" and vector_file.value:
                # TODO: Implement when VectorField component is available
                raise NotImplementedError("SHAPE method not yet implemented")

            elif method == "POINTS" and points_file.value:
                # TODO: Implement when LoadTableField component is available
                raise NotImplementedError("POINTS method not yet implemented")

            elif method == "DRAW":
                if aoi_dc is None:
                    raise ValueError("No DrawControl available")

                # Get the drawn features
                features = aoi_dc.get_data()
                if not features:
                    raise ValueError("No drawn features found. Please draw an area on the map.")

                # Set the geo_json attribute on the model, then call set_object
                model.geo_json = features
                model.set_object("DRAW")

            elif method == "ASSET" and asset_name.value:
                # TODO: Implement when AssetSelect component is available
                raise NotImplementedError("ASSET method not yet implemented")

            # Update the map if available
            if map_:
                # Clear existing AOI layers
                for layer in list(map_.layers):
                    if hasattr(layer, "name") and layer.name == "aoi":
                        map_.remove_layer(layer)

                # Add new AOI layer using appropriate method
                if gee:
                    await map_.add_ee_layer_async(
                        model.feature_collection, map_style or {}, "aoi", autocenter=True
                    )
                else:
                    map_.add_layer(model.get_ipygeojson(map_style), "aoi")

            # Create AOI data dictionary and update reactive value
            aoi_dict = create_aoi_dict()
            if aoi_dict:
                reactive_value.set(aoi_dict)

            return ms.aoi_sel.complete

        except Exception as e:
            # Clean up model state on error
            model.clear_output()
            reactive_value.set(None)
            raise e

    # Run AOI processing as async task (supports cancellation for async operations)
    result = solara.lab.use_task(  # noqa: SH101
        process_aoi,
        dependencies=None,
        raise_error=False,
    )

    # Update UI based on result state
    def handle_result_state():
        if result.pending:
            reactive_loading.set(True)
            alert_message.set("Processing AOI... This may take a moment for GADM data downloads.")
            alert_type.set("info")
        elif result.finished:
            reactive_loading.set(False)
            if result.value:
                alert_message.set(result.value)
                alert_type.set("success")
        elif result.error:
            reactive_loading.set(False)
            alert_message.set(f"Error: {str(result.exception)}")
            alert_type.set("error")
        elif result.cancelled:
            reactive_loading.set(False)
            alert_message.set("Process cancelled")
            alert_type.set("info")

    solara.use_effect(  # noqa: SH101
        handle_result_state, [result.pending, result.finished, result.error, result.cancelled]
    )

    def start_process():
        """Trigger the background process by calling the task."""
        alert_message.set("")
        reactive_loading.set(True)
        result()  # Call the task directly

    # Effect to reset inputs when method changes
    def on_method_change():
        if selected_method.value:
            # Changing the method invalidates the previously selected AOI.
            # Clear output early so parent UIs don't keep showing stale AOI data.
            reactive_value.set(None)
            model.clear_output()
            reset_inputs()

            # Clear any existing AOI layer from the map
            if map_:
                for layer in list(map_.layers):
                    if hasattr(layer, "name") and layer.name == "aoi":
                        map_.remove_layer(layer)

            # Handle DrawControl visibility and cleanup
            if aoi_dc:
                if selected_method.value == "DRAW":
                    aoi_dc.clear()
                    map_.add_control(aoi_dc)
                else:
                    # Remove DrawControl for non-DRAW methods
                    if aoi_dc in map_.controls:
                        map_.remove_control(aoi_dc)

    solara.use_effect(on_method_change, [selected_method.value])  # noqa: SH101

    # Render the component
    with solara.Column(classes="mx-0 px-0"):
        # Method selector
        MethodSelect(
            methods=methods,
            gee=gee,
            map_=map_,
            value=selected_method,
        )

        # Conditional rendering based on selected method
        if selected_method.value == "ADMIN0":
            AdminField(level=0, gee=gee, value=admin_0_value)

        elif selected_method.value == "ADMIN1":
            AdminField(level=0, gee=gee, value=admin_0_value)
            AdminField(level=1, parent_value=admin_0_value, gee=gee, value=admin_1_value)

        elif selected_method.value == "ADMIN2":
            AdminField(level=0, gee=gee, value=admin_0_value)
            AdminField(level=1, parent_value=admin_0_value, gee=gee, value=admin_1_value)
            AdminField(level=2, parent_value=admin_1_value, gee=gee, value=admin_2_value)

        elif selected_method.value == "SHAPE":
            # TODO: Add VectorField component when available
            solara.Warning("SHAPE method not yet implemented. Waiting for VectorField component.")

        elif selected_method.value == "POINTS":
            # TODO: Add LoadTableField component when available
            solara.Warning(
                "POINTS method not yet implemented. Waiting for LoadTableField component."
            )

        elif selected_method.value == "DRAW":
            if aoi_dc:
                solara.Info("Use the drawing tools on the map to create your AOI.")
                with rv.TextField(
                    label="AOI Name (optional)",
                    v_model=draw_name.value or "",
                    on_v_model=draw_name.set,
                    outlined=True,
                    dense=True,
                ):
                    pass
            else:
                solara.Error("DrawControl not available. Please provide a map with DrawControl.")

        elif selected_method.value == "ASSET" and gee:
            # TODO: Add AssetSelect component when available
            solara.Warning("ASSET method not yet implemented. Waiting for AssetSelect component.")

        # Action buttons - Process and Cancel
        if selected_method.value:
            ui_loading = reactive_loading.value or result.pending
            with solara.Column():
                solara.Button(
                    "Select AOI",
                    on_click=start_process,
                    disabled=ui_loading,
                    loading=ui_loading,
                    color="primary",
                    block=True,
                    small=True,
                )
                if ui_loading:
                    solara.Button(
                        "Cancel",
                        on_click=result.cancel,
                        color="error",
                        outlined=True,
                        block=True,
                        small=True,
                    )

        # Alert message display (optional; prefer global notifications in apps)
        if alert_message.value:
            if alert_type.value == "success":
                solara.Success(alert_message.value)
            elif alert_type.value == "error":
                solara.Error(alert_message.value)
            elif alert_type.value == "warning":
                solara.Warning(alert_message.value)
            else:
                solara.Info(alert_message.value)

    # Cleanup on unmount (and when the map instance changes)
    def _cleanup_effect():
        def _cleanup():
            # Stop any ongoing processing
            try:
                if result.pending:
                    result.cancel()
            except Exception:
                pass

            # Clear UI state
            reactive_loading.set(False)
            alert_message.set("")
            alert_type.set("info")

            # Clear model output
            try:
                model.clear_output()
            except Exception:
                pass

            # Remove AOI artifacts from the map
            if map_:
                try:
                    for layer in list(map_.layers):
                        if hasattr(layer, "name") and layer.name == "aoi":
                            map_.remove_layer(layer)
                except Exception:
                    pass

                if aoi_dc:
                    try:
                        aoi_dc.clear()
                    except Exception:
                        pass
                    try:
                        if aoi_dc in map_.controls:
                            map_.remove_control(aoi_dc)
                    except Exception:
                        pass

            return None

        return _cleanup

    solara.use_effect(_cleanup_effect, [id(map_) if map_ is not None else None])  # noqa: SH101


def _get_available_methods(
    methods: Union[str, List[str]],
    gee: bool,
    map_: Optional[sm.SepalMap],
) -> Dict[str, Dict[str, str]]:
    """Helper function to determine available methods based on configuration.

    Args:
        methods: Methods configuration
        gee: Whether Earth Engine is available
        map_: Map instance

    Returns:
        Dictionary of available methods
    """
    # Create the method list
    if methods == "ALL":
        method_dict = select_methods.copy()
    elif methods == "ADMIN":
        method_dict = {k: v for k, v in select_methods.items() if v["type"] == ADMIN}
    elif methods == "CUSTOM":
        method_dict = {k: v for k, v in select_methods.items() if v["type"] == CUSTOM}
    elif isinstance(methods, list):
        if any(m[0] == "-" for m in methods) and not all(m[0] == "-" for m in methods):
            raise ValueError("Cannot mix adding and removing methods")

        if methods[0][0] == "-":
            to_remove = [method[1:] for method in methods]
            method_dict = {k: v for k, v in select_methods.items() if k not in to_remove}
        else:
            method_dict = {k: select_methods[k] for k in methods if k in select_methods}
    else:
        method_dict = select_methods.copy()

    # Clean the list based on availability
    if not gee:
        method_dict.pop("ASSET", None)
    if map_ is None:
        method_dict.pop("DRAW", None)

    return method_dict
