"""Wrapper for ipyvuetify widgets to unify the display of voila dashboards in the SEPAL platform.

``pysepal`` is a lib designed to create elegant python based dashboard in the SEPAL environment. It is designed on top of the amazing ``ipyvuetify`` library and will help developer to easily create interface for their workflows. By using this libraries, you'll ensure a robust and unified interface for your scripts and a easy and complete integration into the SEPAL dashboard of application.
"""

from pysepal.conf import config as config
from pysepal.conf import config_file as config_file
from pysepal.frontend.styles import SepalColor
from pysepal.frontend.styles import get_theme as get_theme

__author__ = """Pierrick Rambaud"""
__email__ = "pierrick.rambaud49@gmail.com"
__version__ = "3.3.0"

color = SepalColor()
'color: the colors of sepal. members are in the following list: "main, darker, bg, primary, accent, secondary, success, info, warning, error, menu". They will render according to the selected theme.'
