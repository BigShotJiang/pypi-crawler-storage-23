# Changelog

All notable changes to `ffid-python-sdk` will be documented in this file.

This project follows [Semantic Versioning](https://semver.org/).

## [0.2.0] - 2026-02-28

### Added
- **Agency SDK** (`ffid_sdk.agency`) - Full agency management client (#654, #655)
  - `FFIDAgencyClient` with Bearer token authentication and httpx connection reuse
  - Agency CRUD, member management, organization linking
  - Sub-agency creation and hierarchy traversal
  - Branding settings (logo, favicon, colors) with asset upload
  - Custom domain setup, verification, and DNS record management
  - Email settings (fromName, fromEmail, replyTo)
  - Billing configuration, summary, invoices, and revenue

### Improved
- **Agency SDK type design** - Stricter ErrorCode types, removed redundant Partial usage, unified `_parse_model` pattern (#666, #667)
- **Agency SDK quality** - httpx connection reuse for performance, explicit interface, internal API methods made private (#657, #665)
- **Test coverage** - Added tests for custom logger injection, member management, organization linking, hierarchy, domain, email settings, billing, network errors, and multi-parameter validation (#656, #670)

## [0.1.0] - 2026-02-12

### Added
- Initial release
- `FFIDMiddleware` - FastAPI middleware for request authentication and session verification
- `FFIDContext` - User, organization, and subscription context
- `@require_subscription` - Subscription check decorator
- `FFIDClient` - Low-level API client with Service API Key authentication
- Token auto-refresh support (optional)
- **Legal client** (`ffid_sdk.legal`) - Terms of service consent management
- Logger injection support for custom logging
- Typed error hierarchy (`FFIDError`, `FFIDAuthError`, `FFIDAPIError`)
