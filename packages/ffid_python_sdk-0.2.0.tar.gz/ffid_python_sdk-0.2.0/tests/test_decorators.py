"""
Decorator Tests

@require_subscription デコレータのテスト。
TypeScript SDK の withSubscription テストに対応。
"""

from __future__ import annotations

import pytest

from ffid_sdk.decorators import require_subscription
from ffid_sdk.errors import FFIDAuthenticationError, FFIDSubscriptionError
from ffid_sdk.types import FFIDContext

from .conftest import (
    create_mock_context,
    create_mock_subscription,
)


# ---------------------------------------------------------------------------
# @require_subscription tests
# ---------------------------------------------------------------------------


class TestRequireSubscription:
    """@require_subscription デコレータテスト"""

    @pytest.mark.asyncio
    async def test_allows_active_subscription(self) -> None:
        """有効な契約がある場合に通過すること"""
        ctx = create_mock_context()

        @require_subscription()
        async def handler(ctx: FFIDContext = ctx) -> str:
            return "ok"

        result = await handler(ctx=ctx)
        assert result == "ok"

    @pytest.mark.asyncio
    async def test_allows_trialing_subscription(self) -> None:
        """トライアル中の契約がある場合に通過すること"""
        sub = create_mock_subscription(status="trialing")
        ctx = create_mock_context(subscriptions=[sub])

        @require_subscription()
        async def handler(ctx: FFIDContext = ctx) -> str:
            return "ok"

        result = await handler(ctx=ctx)
        assert result == "ok"

    @pytest.mark.asyncio
    async def test_rejects_canceled_subscription(self) -> None:
        """キャンセル済みの契約しかない場合にエラーを発生させること"""
        sub = create_mock_subscription(status="canceled")
        ctx = create_mock_context(subscriptions=[sub])

        @require_subscription()
        async def handler(ctx: FFIDContext = ctx) -> str:
            return "ok"

        with pytest.raises(FFIDSubscriptionError, match="有効な契約が必要"):
            await handler(ctx=ctx)

    @pytest.mark.asyncio
    async def test_rejects_no_subscriptions(self) -> None:
        """契約がない場合にエラーを発生させること"""
        ctx = create_mock_context(subscriptions=[])

        @require_subscription()
        async def handler(ctx: FFIDContext = ctx) -> str:
            return "ok"

        with pytest.raises(FFIDSubscriptionError, match="有効な契約が必要"):
            await handler(ctx=ctx)

    @pytest.mark.asyncio
    async def test_filters_by_plan(self) -> None:
        """指定プランでフィルタリングすること"""
        sub = create_mock_subscription(planCode="pro")
        ctx = create_mock_context(subscriptions=[sub])

        @require_subscription(plans=["pro", "enterprise"])
        async def handler(ctx: FFIDContext = ctx) -> str:
            return "ok"

        result = await handler(ctx=ctx)
        assert result == "ok"

    @pytest.mark.asyncio
    async def test_plan_alias_same_as_plans(self) -> None:
        """plan= は plans= のエイリアスであること（Issue #170 使用例互換）"""
        sub = create_mock_subscription(planCode="pro")
        ctx = create_mock_context(subscriptions=[sub])

        @require_subscription(plan=["basic", "pro", "enterprise"])
        async def handler(ctx: FFIDContext = ctx) -> str:
            return "ok"

        result = await handler(ctx=ctx)
        assert result == "ok"

    @pytest.mark.asyncio
    async def test_rejects_wrong_plan(self) -> None:
        """指定外のプランの場合にエラーを発生させること"""
        sub = create_mock_subscription(planCode="basic")
        ctx = create_mock_context(subscriptions=[sub])

        @require_subscription(plans=["pro", "enterprise"])
        async def handler(ctx: FFIDContext = ctx) -> str:
            return "ok"

        with pytest.raises(FFIDSubscriptionError, match="pro, enterprise"):
            await handler(ctx=ctx)

    @pytest.mark.asyncio
    async def test_filters_by_service_code(self) -> None:
        """サービスコードでフィルタリングすること"""
        sub = create_mock_subscription(serviceCode="analytics")
        ctx = create_mock_context(subscriptions=[sub])

        @require_subscription(service_code="analytics")
        async def handler(ctx: FFIDContext = ctx) -> str:
            return "ok"

        result = await handler(ctx=ctx)
        assert result == "ok"

    @pytest.mark.asyncio
    async def test_rejects_wrong_service_code(self) -> None:
        """異なるサービスコードの場合にエラーを発生させること"""
        sub = create_mock_subscription(serviceCode="chatbot")
        ctx = create_mock_context(subscriptions=[sub])

        @require_subscription(service_code="analytics")
        async def handler(ctx: FFIDContext = ctx) -> str:
            return "ok"

        with pytest.raises(FFIDSubscriptionError):
            await handler(ctx=ctx)

    @pytest.mark.asyncio
    async def test_raises_auth_error_without_context(self) -> None:
        """コンテキストがない場合に認証エラーを発生させること"""

        @require_subscription()
        async def handler() -> str:
            return "ok"

        with pytest.raises(FFIDAuthenticationError, match="認証が必要"):
            await handler()

    @pytest.mark.asyncio
    async def test_plan_and_service_code_combined(self) -> None:
        """プランとサービスコードの組み合わせフィルタ"""
        sub = create_mock_subscription(
            serviceCode="chatbot", planCode="enterprise"
        )
        ctx = create_mock_context(subscriptions=[sub])

        @require_subscription(plans=["enterprise"], service_code="chatbot")
        async def handler(ctx: FFIDContext = ctx) -> str:
            return "ok"

        result = await handler(ctx=ctx)
        assert result == "ok"

    @pytest.mark.asyncio
    async def test_error_details_include_required_plans(self) -> None:
        """エラー詳細に必要プランが含まれること"""
        ctx = create_mock_context(subscriptions=[])

        @require_subscription(plans=["pro"], service_code="chatbot")
        async def handler(ctx: FFIDContext = ctx) -> str:
            return "ok"

        with pytest.raises(FFIDSubscriptionError) as exc_info:
            await handler(ctx=ctx)

        assert exc_info.value.details is not None
        assert exc_info.value.details["required_plans"] == ["pro"]
        assert exc_info.value.details["service_code"] == "chatbot"
