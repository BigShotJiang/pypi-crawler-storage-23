"""
FFIDMiddleware Tests

FastAPI ミドルウェアのテスト。
"""

from __future__ import annotations

from typing import Any, Dict

import httpx
import pytest
import respx
from fastapi import FastAPI, Request
from fastapi.testclient import TestClient

from ffid_sdk.constants import SESSION_ENDPOINT
from ffid_sdk.middleware import FFIDMiddleware
from ffid_sdk.types import FFIDContext

from .conftest import (
    TEST_ACCESS_TOKEN,
    TEST_API_BASE_URL,
    TEST_SERVICE_CODE,
)


def _create_test_app(
    exclude_paths: list[str] | None = None,
    exclude_path_prefixes: list[str] | None = None,
) -> FastAPI:
    """テスト用FastAPIアプリを生成"""
    app = FastAPI()
    app.add_middleware(
        FFIDMiddleware,
        service_code=TEST_SERVICE_CODE,
        api_base_url=TEST_API_BASE_URL,
        exclude_paths=exclude_paths or ["/health"],
        exclude_path_prefixes=exclude_path_prefixes or ["/docs"],
    )

    @app.get("/health")
    async def health() -> Dict[str, str]:
        return {"status": "ok"}

    @app.get("/protected")
    async def protected(request: Request) -> Dict[str, Any]:
        ctx: FFIDContext = request.state.ffid_context
        return {
            "user_email": ctx.user.email,
            "org_count": len(ctx.organizations),
            "sub_count": len(ctx.subscriptions),
        }

    @app.get("/docs/openapi")
    async def docs() -> Dict[str, str]:
        return {"docs": "available"}

    return app


# ---------------------------------------------------------------------------
# Middleware tests
# ---------------------------------------------------------------------------


class TestFFIDMiddleware:
    """ミドルウェアテスト"""

    @respx.mock
    def test_allows_excluded_paths(self) -> None:
        """除外パスは認証をスキップすること"""
        app = _create_test_app()
        client = TestClient(app)

        response = client.get("/health")

        assert response.status_code == 200
        assert response.json() == {"status": "ok"}

    @respx.mock
    def test_allows_excluded_path_prefixes(self) -> None:
        """除外パスプレフィックスは認証をスキップすること"""
        app = _create_test_app()
        client = TestClient(app)

        response = client.get("/docs/openapi")

        assert response.status_code == 200
        assert response.json() == {"docs": "available"}

    @respx.mock
    def test_returns_401_without_token(self) -> None:
        """トークンなしで401を返すこと"""
        app = _create_test_app()
        client = TestClient(app)

        response = client.get("/protected")

        assert response.status_code == 401
        data = response.json()
        assert data["error"]["code"] == "AUTHENTICATION_ERROR"
        assert "トークンが見つかりません" in data["error"]["message"]

    @respx.mock
    def test_authenticates_with_bearer_token(
        self, mock_session_data: Dict[str, Any]
    ) -> None:
        """Bearer トークンで認証できること"""
        respx.get(f"{TEST_API_BASE_URL}{SESSION_ENDPOINT}").mock(
            return_value=httpx.Response(200, json={"data": mock_session_data})
        )

        app = _create_test_app()
        client = TestClient(app)

        response = client.get(
            "/protected",
            headers={"Authorization": f"Bearer {TEST_ACCESS_TOKEN}"},
        )

        assert response.status_code == 200
        data = response.json()
        assert data["user_email"] == "test@example.com"
        assert data["org_count"] == 1
        assert data["sub_count"] == 1

    @respx.mock
    def test_authenticates_with_cookie(
        self, mock_session_data: Dict[str, Any]
    ) -> None:
        """Cookie で認証できること"""
        respx.get(f"{TEST_API_BASE_URL}{SESSION_ENDPOINT}").mock(
            return_value=httpx.Response(200, json={"data": mock_session_data})
        )

        app = _create_test_app()
        client = TestClient(app)

        response = client.get(
            "/protected",
            cookies={"ffid_session": TEST_ACCESS_TOKEN},
        )

        assert response.status_code == 200
        data = response.json()
        assert data["user_email"] == "test@example.com"

    @respx.mock
    def test_returns_401_on_invalid_token(self) -> None:
        """無効なトークンで401を返すこと"""
        respx.get(f"{TEST_API_BASE_URL}{SESSION_ENDPOINT}").mock(
            return_value=httpx.Response(
                401,
                json={
                    "error": {
                        "code": "AUTHENTICATION_ERROR",
                        "message": "トークンが無効です",
                    }
                },
            )
        )

        app = _create_test_app()
        client = TestClient(app)

        response = client.get(
            "/protected",
            headers={"Authorization": "Bearer invalid-token"},
        )

        assert response.status_code == 401

    @respx.mock
    def test_bearer_token_takes_priority_over_cookie(
        self, mock_session_data: Dict[str, Any]
    ) -> None:
        """Bearer トークンが Cookie より優先されること"""
        route = respx.get(f"{TEST_API_BASE_URL}{SESSION_ENDPOINT}").mock(
            return_value=httpx.Response(200, json={"data": mock_session_data})
        )

        app = _create_test_app()
        client = TestClient(app)

        response = client.get(
            "/protected",
            headers={"Authorization": f"Bearer {TEST_ACCESS_TOKEN}"},
            cookies={"ffid_session": "cookie-token"},
        )

        assert response.status_code == 200
        # Bearer トークンが使われたことを確認
        assert route.called
        request = route.calls[0].request
        assert f"Bearer {TEST_ACCESS_TOKEN}" in request.headers.get("Authorization", "")

    @respx.mock
    def test_ignores_empty_bearer_token(self) -> None:
        """空のBearerトークンを無視すること"""
        app = _create_test_app()
        client = TestClient(app)

        response = client.get(
            "/protected",
            headers={"Authorization": "Bearer "},
        )

        assert response.status_code == 401

    @respx.mock
    def test_ignores_non_bearer_auth_header(self) -> None:
        """Bearer以外のAuthヘッダーを無視すること"""
        app = _create_test_app()
        client = TestClient(app)

        response = client.get(
            "/protected",
            headers={"Authorization": "Basic dXNlcjpwYXNz"},
        )

        assert response.status_code == 401

    def test_returns_500_on_unexpected_exception(self) -> None:
        """予期しない例外発生時に500を返すこと"""
        from unittest.mock import AsyncMock, patch

        app = _create_test_app()

        # FFIDClient.get_session をクラスレベルでパッチし、
        # ミドルウェアの except Exception ブロック（500レスポンス）をテスト
        with patch(
            "ffid_sdk.client.FFIDClient.get_session",
            new=AsyncMock(side_effect=RuntimeError("Unexpected internal error")),
        ):
            client = TestClient(app)
            response = client.get(
                "/protected",
                headers={"Authorization": f"Bearer {TEST_ACCESS_TOKEN}"},
            )

        assert response.status_code == 500
        data = response.json()
        assert data["error"]["code"] == "UNKNOWN_ERROR"
        assert "認証処理中にエラーが発生しました" in data["error"]["message"]

    @respx.mock
    def test_custom_auth_error_handler(
        self, mock_session_data: Dict[str, Any]
    ) -> None:
        """カスタムエラーハンドラーが呼び出されること"""
        from starlette.responses import JSONResponse

        from ffid_sdk.errors import FFIDAuthenticationError

        def custom_handler(request: Request, error: FFIDAuthenticationError) -> JSONResponse:
            return JSONResponse(
                status_code=403,
                content={"custom_error": error.message},
            )

        app = FastAPI()
        app.add_middleware(
            FFIDMiddleware,
            service_code=TEST_SERVICE_CODE,
            api_base_url=TEST_API_BASE_URL,
            exclude_paths=["/health"],
            on_auth_error=custom_handler,
        )

        @app.get("/protected")
        async def protected(request: Request) -> Dict[str, Any]:
            return {"ok": True}

        client = TestClient(app)

        # トークンなしでリクエスト → カスタムハンドラーが呼ばれる
        response = client.get("/protected")

        assert response.status_code == 403
        data = response.json()
        assert "custom_error" in data
        assert "トークンが見つかりません" in data["custom_error"]
