"""
Type Model Tests

Pydantic モデルのバリデーション・変換テスト。
camelCase → snake_case 変換が正しく動作するか確認。
"""

from __future__ import annotations

from datetime import datetime, timezone

import pytest

from ffid_sdk.types import (
    FFIDApiResponse,
    FFIDContext,
    FFIDError,
    FFIDOrganization,
    FFIDSessionResponse,
    FFIDSubscription,
    FFIDUser,
    MembershipStatus,
    OrganizationRole,
    SubscriptionStatus,
)

from .conftest import (
    create_mock_context,
    create_mock_organization,
    create_mock_subscription,
    create_mock_user,
)


class TestFFIDUser:
    """FFIDUser モデルテスト"""

    def test_parses_camelcase_json(self) -> None:
        """camelCase JSON を正しくパースすること"""
        data = {
            "id": "user-001",
            "email": "test@example.com",
            "displayName": "テストユーザー",
            "avatarUrl": "https://example.com/avatar.png",
            "locale": "ja",
            "timezone": "Asia/Tokyo",
            "createdAt": "2024-01-01T00:00:00Z",
        }
        user = FFIDUser.model_validate(data)

        assert user.id == "user-001"
        assert user.email == "test@example.com"
        assert user.display_name == "テストユーザー"
        assert user.avatar_url == "https://example.com/avatar.png"

    def test_allows_null_optional_fields(self) -> None:
        """オプショナルフィールドがnullでも受け入れること"""
        data = {
            "id": "user-001",
            "email": "test@example.com",
            "displayName": None,
            "avatarUrl": None,
            "locale": None,
            "timezone": None,
            "createdAt": "2024-01-01T00:00:00Z",
        }
        user = FFIDUser.model_validate(data)

        assert user.display_name is None
        assert user.avatar_url is None


class TestFFIDOrganization:
    """FFIDOrganization モデルテスト"""

    def test_parses_valid_roles(self) -> None:
        """全ロールを正しくパースすること"""
        for role in ["owner", "admin", "member"]:
            org = create_mock_organization(role=role)
            assert org.role == OrganizationRole(role)

    def test_parses_valid_statuses(self) -> None:
        """全ステータスを正しくパースすること"""
        for status in ["active", "invited", "suspended"]:
            org = create_mock_organization(status=status)
            assert org.status == MembershipStatus(status)


class TestFFIDSubscription:
    """FFIDSubscription モデルテスト"""

    def test_parses_camelcase_fields(self) -> None:
        """camelCase フィールドを正しくパースすること"""
        sub = create_mock_subscription()

        assert sub.service_code == "chatbot"
        assert sub.service_name == "AI チャットボット"
        assert sub.plan_code == "pro"
        assert sub.plan_name == "プロプラン"
        expected_period_end = datetime(2025, 12, 31, 23, 59, 59, tzinfo=timezone.utc)
        assert sub.current_period_end == expected_period_end

    def test_parses_all_subscription_statuses(self) -> None:
        """全契約ステータスを正しくパースすること"""
        for status in ["trialing", "active", "past_due", "canceled", "paused"]:
            sub = create_mock_subscription(status=status)
            assert sub.status == SubscriptionStatus(status)

    def test_allows_null_period_end(self) -> None:
        """current_period_end がnullでも受け入れること"""
        sub = create_mock_subscription(currentPeriodEnd=None)
        assert sub.current_period_end is None


class TestFFIDSessionResponse:
    """FFIDSessionResponse モデルテスト"""

    def test_parses_complete_session(self) -> None:
        """完全なセッションデータをパースすること"""
        data = {
            "user": {
                "id": "user-001",
                "email": "test@example.com",
                "displayName": "テスト",
                "avatarUrl": None,
                "locale": "ja",
                "timezone": "Asia/Tokyo",
                "createdAt": "2024-01-01T00:00:00Z",
            },
            "organizations": [
                {
                    "id": "org-001",
                    "name": "テスト組織",
                    "slug": "test-org",
                    "role": "owner",
                    "status": "active",
                }
            ],
            "subscriptions": [
                {
                    "id": "sub-001",
                    "serviceCode": "chatbot",
                    "serviceName": "チャットボット",
                    "planCode": "pro",
                    "planName": "プロプラン",
                    "status": "active",
                    "currentPeriodEnd": None,
                }
            ],
        }
        session = FFIDSessionResponse.model_validate(data)

        assert session.user.email == "test@example.com"
        assert len(session.organizations) == 1
        assert len(session.subscriptions) == 1

    def test_handles_empty_lists(self) -> None:
        """空リストを処理すること"""
        data = {
            "user": {
                "id": "user-001",
                "email": "test@example.com",
                "displayName": None,
                "avatarUrl": None,
                "locale": None,
                "timezone": None,
                "createdAt": "2024-01-01T00:00:00Z",
            },
            "organizations": [],
            "subscriptions": [],
        }
        session = FFIDSessionResponse.model_validate(data)

        assert len(session.organizations) == 0
        assert len(session.subscriptions) == 0


class TestFFIDApiResponse:
    """FFIDApiResponse モデルテスト"""

    def test_success_response(self) -> None:
        """成功レスポンスの is_success が True であること"""
        response = FFIDApiResponse[str](data="ok")
        assert response.is_success is True
        assert response.data == "ok"
        assert response.error is None

    def test_error_response(self) -> None:
        """エラーレスポンスの is_success が False であること"""
        error = FFIDError(code="TEST_ERROR", message="テストエラー")
        response = FFIDApiResponse[str](error=error)
        assert response.is_success is False
        assert response.data is None
        assert response.error is not None
        assert response.error.code == "TEST_ERROR"

    def test_empty_response_is_success_when_no_error(self) -> None:
        """error がないレスポンスは成功（sign_out等のdata=Noneケース対応）"""
        response = FFIDApiResponse[str]()
        assert response.is_success is True  # error is None → success

    def test_none_data_with_no_error_is_success(self) -> None:
        """data=None, error=None は成功（sign_outの成功レスポンスパターン）"""
        response = FFIDApiResponse[None](data=None)
        assert response.is_success is True

    def test_rejects_both_data_and_error(self) -> None:
        """data と error を同時に設定すると ValueError になること"""
        error = FFIDError(code="TEST_ERROR", message="テストエラー")
        with pytest.raises(ValueError, match="data と error は同時に設定できません"):
            FFIDApiResponse[str](data="ok", error=error)


class TestFFIDContext:
    """FFIDContext モデルテスト"""

    def test_active_subscription_prefers_active(self) -> None:
        """active_subscription は active を優先すること"""
        active_sub = create_mock_subscription(
            id="sub-active", status="active", planCode="pro"
        )
        trialing_sub = create_mock_subscription(
            id="sub-trial", status="trialing", planCode="basic"
        )
        ctx = create_mock_context(subscriptions=[trialing_sub, active_sub])

        assert ctx.active_subscription is not None
        assert ctx.active_subscription.plan_code == "pro"

    def test_active_subscription_fallback_to_trialing(self) -> None:
        """active がなければ trialing を返すこと"""
        trialing_sub = create_mock_subscription(
            id="sub-trial", status="trialing", planCode="basic"
        )
        ctx = create_mock_context(subscriptions=[trialing_sub])

        assert ctx.active_subscription is not None
        assert ctx.active_subscription.plan_code == "basic"

    def test_active_subscription_none_when_empty(self) -> None:
        """契約がない場合は None を返すこと"""
        ctx = create_mock_context(subscriptions=[])

        assert ctx.active_subscription is None

    def test_active_subscription_fallback_to_first_when_no_active_or_trialing(self) -> None:
        """active/trialing がなければ先頭の契約を返すこと"""
        canceled_sub = create_mock_subscription(
            id="sub-canceled", status="canceled", planCode="basic"
        )
        past_due_sub = create_mock_subscription(
            id="sub-past-due", status="past_due", planCode="pro"
        )
        ctx = create_mock_context(subscriptions=[canceled_sub, past_due_sub])

        assert ctx.active_subscription is not None
        assert ctx.active_subscription.id == "sub-canceled"

    def test_has_subscription(self) -> None:
        """has_subscription が正しく動作すること"""
        ctx = create_mock_context()

        assert ctx.has_subscription("chatbot") is True
        assert ctx.has_subscription("analytics") is False

    def test_has_plan(self) -> None:
        """has_plan が正しく動作すること"""
        ctx = create_mock_context()

        assert ctx.has_plan(["pro", "enterprise"]) is True
        assert ctx.has_plan(["basic"]) is False

    def test_has_plan_with_service_code(self) -> None:
        """has_plan がサービスコードでフィルタすること"""
        ctx = create_mock_context()

        assert ctx.has_plan(["pro"], service_code="chatbot") is True
        assert ctx.has_plan(["pro"], service_code="analytics") is False

    def test_context_is_frozen(self) -> None:
        """コンテキストがイミュータブルであること"""
        ctx = create_mock_context()

        with pytest.raises(Exception):
            ctx.user = create_mock_user(email="hacker@evil.com")  # type: ignore[misc]


class TestFFIDErrorSubclassDefaults:
    """エラーサブクラスのデフォルト値テスト"""

    def test_authentication_error_defaults(self) -> None:
        """FFIDAuthenticationError のデフォルト値が正しいこと"""
        from ffid_sdk.errors import FFIDAuthenticationError, FFIDErrorCode

        error = FFIDAuthenticationError()
        assert error.code == FFIDErrorCode.AUTHENTICATION_ERROR
        assert "認証に失敗しました" in error.message

    def test_authorization_error_defaults(self) -> None:
        """FFIDAuthorizationError のデフォルト値が正しいこと"""
        from ffid_sdk.errors import FFIDAuthorizationError, FFIDErrorCode

        error = FFIDAuthorizationError()
        assert error.code == FFIDErrorCode.AUTHORIZATION_ERROR
        assert "権限がありません" in error.message

    def test_subscription_error_defaults(self) -> None:
        """FFIDSubscriptionError のデフォルト値が正しいこと"""
        from ffid_sdk.errors import FFIDSubscriptionError, FFIDErrorCode

        error = FFIDSubscriptionError()
        assert error.code == FFIDErrorCode.SUBSCRIPTION_REQUIRED
        assert "契約が必要" in error.message

    def test_network_error_defaults(self) -> None:
        """FFIDNetworkError のデフォルト値が正しいこと"""
        from ffid_sdk.errors import FFIDNetworkError, FFIDErrorCode

        error = FFIDNetworkError()
        assert error.code == FFIDErrorCode.NETWORK_ERROR
        assert "ネットワークエラー" in error.message

    def test_validation_error_defaults(self) -> None:
        """FFIDValidationError のデフォルト値が正しいこと"""
        from ffid_sdk.errors import FFIDValidationError, FFIDErrorCode

        error = FFIDValidationError()
        assert error.code == FFIDErrorCode.VALIDATION_ERROR
        assert "入力内容に誤りがあります" in error.message


class TestFFIDSDKErrorToDict:
    """FFIDSDKError.to_dict() テスト"""

    def test_to_dict_without_details(self) -> None:
        """details なしの場合に code と message のみ返すこと"""
        from ffid_sdk.errors import FFIDSDKError, FFIDErrorCode

        error = FFIDSDKError(
            code=FFIDErrorCode.AUTHENTICATION_ERROR,
            message="認証に失敗しました",
        )
        result = error.to_dict()

        assert result == {
            "code": "AUTHENTICATION_ERROR",
            "message": "認証に失敗しました",
        }
        assert "details" not in result

    def test_to_dict_with_details(self) -> None:
        """details ありの場合に details も含めること"""
        from ffid_sdk.errors import FFIDSDKError, FFIDErrorCode

        error = FFIDSDKError(
            code=FFIDErrorCode.SUBSCRIPTION_REQUIRED,
            message="契約が必要です",
            details={"required_plans": ["pro", "enterprise"]},
        )
        result = error.to_dict()

        assert result == {
            "code": "SUBSCRIPTION_REQUIRED",
            "message": "契約が必要です",
            "details": {"required_plans": ["pro", "enterprise"]},
        }
