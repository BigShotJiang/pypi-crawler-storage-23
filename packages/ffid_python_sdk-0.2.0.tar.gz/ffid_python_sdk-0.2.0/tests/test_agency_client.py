"""
FFID Agency Client Tests

FFIDAgencyClient のテスト。respx で API をモック。
"""

from __future__ import annotations

from collections.abc import AsyncGenerator

import pytest
import respx

from ffid_sdk.agency import FFIDAgencyClient, FFIDAgencyClientConfig
from ffid_sdk.agency.errors import FFIDAgencyMissingTokenError, FFIDAgencyNetworkError

TEST_API_BASE = "https://agency-test.ffid.local"
TEST_TOKEN = "test_jwt_token_abc123"


@pytest.fixture
def agency_config() -> FFIDAgencyClientConfig:
    return FFIDAgencyClientConfig(
        access_token=TEST_TOKEN,
        api_base_url=TEST_API_BASE,
        debug=False,
    )


@pytest.fixture
async def agency_client(agency_config: FFIDAgencyClientConfig) -> AsyncGenerator[FFIDAgencyClient, None]:
    client = FFIDAgencyClient(agency_config)
    yield client
    await client.close()


class TestFFIDAgencyClientInit:
    """初期化テスト"""

    def test_raises_when_token_empty(self) -> None:
        with pytest.raises(FFIDAgencyMissingTokenError):
            FFIDAgencyClient(FFIDAgencyClientConfig(access_token=""))

    def test_raises_when_token_whitespace_only(self) -> None:
        with pytest.raises(FFIDAgencyMissingTokenError):
            FFIDAgencyClient(FFIDAgencyClientConfig(access_token="   "))

    def test_creates_client_with_valid_config(
        self, agency_config: FFIDAgencyClientConfig
    ) -> None:
        client = FFIDAgencyClient(agency_config)
        assert client._config.access_token == TEST_TOKEN
        assert client._base_url == TEST_API_BASE


class TestFFIDAgencyClientGetAgencies:
    """get_agencies テスト"""

    @pytest.mark.asyncio
    @respx.mock
    async def test_returns_agencies_on_success(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        respx.get(f"{TEST_API_BASE}/api/v1/agencies").mock(
            return_value=respx.MockResponse(
                200,
                json={
                    "success": True,
                    "data": {
                        "agencies": [
                            {"id": "agency-1", "name": "Test Agency"},
                        ],
                        "count": 1,
                    },
                },
            )
        )

        data, err = await agency_client.get_agencies()

        assert err is None
        assert data is not None
        assert data["agencies"][0]["name"] == "Test Agency"
        assert data["count"] == 1

    @pytest.mark.asyncio
    @respx.mock
    async def test_returns_error_on_unauthorized(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        respx.get(f"{TEST_API_BASE}/api/v1/agencies").mock(
            return_value=respx.MockResponse(
                401,
                json={
                    "success": False,
                    "error": {"code": "UNAUTHORIZED", "message": "Not authenticated"},
                },
            )
        )

        data, err = await agency_client.get_agencies()

        assert data is None
        assert err is not None
        assert err.code == "UNAUTHORIZED"


class TestFFIDAgencyClientGetAgency:
    """get_agency テスト"""

    @pytest.mark.asyncio
    @respx.mock
    async def test_returns_agency_details(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        respx.get(f"{TEST_API_BASE}/api/v1/agencies/agency-1").mock(
            return_value=respx.MockResponse(
                200,
                json={
                    "success": True,
                    "data": {
                        "agency": {
                            "id": "agency-1",
                            "name": "Test Agency",
                            "slug": "test-agency",
                            "isPlatformOwner": False,
                            "parentAgencyId": None,
                            "status": "active",
                            "settings": {},
                            "billingType": "direct",
                            "contactEmail": "test@agency.com",
                            "createdAt": "2025-01-01T00:00:00Z",
                            "updatedAt": "2025-01-01T00:00:00Z",
                        }
                    },
                },
            )
        )

        agency, err = await agency_client.get_agency("agency-1")

        assert err is None
        assert agency is not None
        assert agency.name == "Test Agency"
        assert agency.slug == "test-agency"
        assert agency.status == "active"

    @pytest.mark.asyncio
    @respx.mock
    async def test_returns_error_when_not_found(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        respx.get(f"{TEST_API_BASE}/api/v1/agencies/nonexistent").mock(
            return_value=respx.MockResponse(
                404,
                json={
                    "success": False,
                    "error": {"code": "NOT_FOUND", "message": "Agency not found"},
                },
            )
        )

        agency, err = await agency_client.get_agency("nonexistent")

        assert agency is None
        assert err is not None
        assert err.code == "NOT_FOUND"


class TestFFIDAgencyClientMembers:
    """メンバー管理テスト"""

    @pytest.mark.asyncio
    @respx.mock
    async def test_get_members_returns_list(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        respx.get(f"{TEST_API_BASE}/api/v1/agencies/agency-1/members").mock(
            return_value=respx.MockResponse(
                200,
                json={
                    "success": True,
                    "data": {
                        "members": [
                            {
                                "userId": "user-1",
                                "email": "admin@test.com",
                                "displayName": "Admin",
                                "avatarUrl": None,
                                "role": "admin",
                                "status": "active",
                                "joinedAt": "2025-01-01T00:00:00Z",
                                "invitedAt": None,
                            }
                        ],
                        "count": 1,
                    },
                },
            )
        )

        members, err = await agency_client.get_members("agency-1")

        assert err is None
        assert members is not None
        assert len(members) == 1
        assert members[0].email == "admin@test.com"
        assert members[0].role == "admin"


class TestFFIDAgencyClientBranding:
    """ブランディング管理テスト"""

    @pytest.mark.asyncio
    @respx.mock
    async def test_get_branding_returns_settings(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        respx.get(f"{TEST_API_BASE}/api/v1/agencies/agency-1/branding").mock(
            return_value=respx.MockResponse(
                200,
                json={
                    "success": True,
                    "data": {
                        "branding": {
                            "logoUrl": "https://example.com/logo.png",
                            "primaryColor": "#FF0000",
                            "companyName": "Partner Inc.",
                        }
                    },
                },
            )
        )

        branding, err = await agency_client.get_branding("agency-1")

        assert err is None
        assert branding is not None
        assert branding.logo_url == "https://example.com/logo.png"
        assert branding.primary_color == "#FF0000"
        assert branding.company_name == "Partner Inc."

    @pytest.mark.asyncio
    @respx.mock
    async def test_update_branding(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        respx.put(f"{TEST_API_BASE}/api/v1/agencies/agency-1/branding").mock(
            return_value=respx.MockResponse(
                200,
                json={
                    "success": True,
                    "data": {
                        "branding": {
                            "primaryColor": "#00FF00",
                        }
                    },
                },
            )
        )

        branding, err = await agency_client.update_branding(
            "agency-1", primary_color="#00FF00"
        )

        assert err is None
        assert branding is not None
        assert branding.primary_color == "#00FF00"


class TestFFIDAgencyClientDomain:
    """ドメイン管理テスト"""

    @pytest.mark.asyncio
    @respx.mock
    async def test_setup_domain(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        respx.post(f"{TEST_API_BASE}/api/v1/agencies/agency-1/domain").mock(
            return_value=respx.MockResponse(
                200,
                json={
                    "success": True,
                    "data": {
                        "domain": {
                            "customDomain": "id.partner.com",
                            "sslStatus": "pending",
                        }
                    },
                },
            )
        )

        domain, err = await agency_client.setup_domain(
            "agency-1", "id.partner.com"
        )

        assert err is None
        assert domain is not None
        assert domain.custom_domain == "id.partner.com"
        assert domain.ssl_status == "pending"


class TestFFIDAgencyClientBilling:
    """課金管理テスト"""

    @pytest.mark.asyncio
    @respx.mock
    async def test_get_billing(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        respx.get(f"{TEST_API_BASE}/api/v1/agencies/agency-1/billing").mock(
            return_value=respx.MockResponse(
                200,
                json={
                    "success": True,
                    "data": {
                        "billing": {
                            "billingType": "consolidated",
                            "stripeCustomerId": "cus_test",
                            "invoiceEmail": "billing@agency.com",
                            "paymentTerms": 30,
                            "defaultMarkupRate": None,
                            "defaultMarkupFixed": None,
                        }
                    },
                },
            )
        )

        billing, err = await agency_client.get_billing("agency-1")

        assert err is None
        assert billing is not None
        assert billing.billing_type == "consolidated"
        assert billing.invoice_email == "billing@agency.com"


class TestFFIDAgencyClientTopLevelModels:
    """トップレベルモデル（_parse_model key=None）テスト"""

    @pytest.mark.asyncio
    @respx.mock
    async def test_get_hierarchy_returns_hierarchy(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        respx.get(f"{TEST_API_BASE}/api/v1/agencies/agency-1/hierarchy").mock(
            return_value=respx.MockResponse(
                200,
                json={
                    "success": True,
                    "data": {
                        "root": {
                            "agency": {
                                "id": "agency-1",
                                "name": "Root Agency",
                                "slug": "root",
                                "isPlatformOwner": True,
                                "parentAgencyId": None,
                                "status": "active",
                                "settings": {},
                                "billingType": "direct",
                                "contactEmail": None,
                                "createdAt": "2025-01-01T00:00:00Z",
                                "updatedAt": "2025-01-01T00:00:00Z",
                            },
                            "children": [],
                            "level": 0,
                        },
                        "totalLevels": 1,
                        "totalAgencies": 1,
                    },
                },
            )
        )

        hierarchy, err = await agency_client.get_hierarchy("agency-1")

        assert err is None
        assert hierarchy is not None
        assert hierarchy.root.agency.name == "Root Agency"
        assert hierarchy.total_levels == 1
        assert hierarchy.total_agencies == 1

    @pytest.mark.asyncio
    @respx.mock
    async def test_get_billing_summary_returns_summary(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        respx.get(f"{TEST_API_BASE}/api/v1/agencies/agency-1/billing-summary").mock(
            return_value=respx.MockResponse(
                200,
                json={
                    "success": True,
                    "data": {
                        "agencyId": "agency-1",
                        "totalOrganizations": 5,
                        "totalRevenue": 12345.67,
                        "period": "2025-01",
                    },
                },
            )
        )

        summary, err = await agency_client.get_billing_summary("agency-1")

        assert err is None
        assert summary is not None
        assert summary.agency_id == "agency-1"
        assert summary.total_organizations == 5
        assert summary.total_revenue == 12345.67
        assert summary.period == "2025-01"

    @pytest.mark.asyncio
    @respx.mock
    async def test_get_revenue_returns_revenue(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        respx.get(f"{TEST_API_BASE}/api/v1/agencies/agency-1/revenue").mock(
            return_value=respx.MockResponse(
                200,
                json={
                    "success": True,
                    "data": {
                        "agencyId": "agency-1",
                        "totalRevenue": 98765.43,
                        "breakdown": {"chatbot": 50000.0, "flow-board": 48765.43},
                        "period": "2025-01",
                    },
                },
            )
        )

        revenue, err = await agency_client.get_revenue("agency-1")

        assert err is None
        assert revenue is not None
        assert revenue.agency_id == "agency-1"
        assert revenue.total_revenue == 98765.43
        assert revenue.breakdown == {"chatbot": 50000.0, "flow-board": 48765.43}


class TestFFIDAgencyClientNetworkErrors:
    """FFIDAgencyNetworkError パステスト"""

    @pytest.mark.asyncio
    @respx.mock
    async def test_timeout_exception_raises_network_error(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        import httpx as _httpx

        respx.get(f"{TEST_API_BASE}/api/v1/agencies").mock(
            side_effect=_httpx.TimeoutException("Connection timed out")
        )

        with pytest.raises(FFIDAgencyNetworkError, match="タイムアウト"):
            await agency_client.get_agencies()

    @pytest.mark.asyncio
    @respx.mock
    async def test_transport_error_raises_network_error(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        import httpx as _httpx

        respx.get(f"{TEST_API_BASE}/api/v1/agencies").mock(
            side_effect=_httpx.ConnectError("Connection refused")
        )

        with pytest.raises(FFIDAgencyNetworkError, match="ネットワークエラー"):
            await agency_client.get_agencies()

    @pytest.mark.asyncio
    @respx.mock
    async def test_network_error_contains_details(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        import httpx as _httpx

        respx.get(f"{TEST_API_BASE}/api/v1/agencies").mock(
            side_effect=_httpx.TimeoutException("timed out")
        )

        with pytest.raises(FFIDAgencyNetworkError) as exc_info:
            await agency_client.get_agencies()

        assert exc_info.value.code == "NETWORK_ERROR"
        assert "url" in exc_info.value.details
        assert "error" in exc_info.value.details

    @pytest.mark.asyncio
    @respx.mock
    async def test_timeout_on_specific_method(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        import httpx as _httpx

        respx.get(f"{TEST_API_BASE}/api/v1/agencies/agency-1").mock(
            side_effect=_httpx.TimeoutException("read timed out")
        )

        with pytest.raises(FFIDAgencyNetworkError, match="タイムアウト"):
            await agency_client.get_agency("agency-1")


class TestFFIDAgencyClientParseErrors:
    """FFIDAgencyParseError パステスト"""

    @pytest.mark.asyncio
    @respx.mock
    async def test_invalid_json_raises_parse_error(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        from ffid_sdk.agency.errors import FFIDAgencyParseError

        respx.get(f"{TEST_API_BASE}/api/v1/agencies").mock(
            return_value=respx.MockResponse(200, text="<html>Not JSON</html>")
        )

        with pytest.raises(FFIDAgencyParseError, match="不正なレスポンス"):
            await agency_client.get_agencies()

    @pytest.mark.asyncio
    @respx.mock
    async def test_parse_error_contains_status_code(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        from ffid_sdk.agency.errors import FFIDAgencyParseError

        respx.get(f"{TEST_API_BASE}/api/v1/agencies/agency-1").mock(
            return_value=respx.MockResponse(502, text="Bad Gateway")
        )

        with pytest.raises(FFIDAgencyParseError, match="502"):
            await agency_client.get_agency("agency-1")

    @pytest.mark.asyncio
    @respx.mock
    async def test_parse_error_code_is_set(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        from ffid_sdk.agency.errors import FFIDAgencyParseError

        respx.get(f"{TEST_API_BASE}/api/v1/agencies").mock(
            return_value=respx.MockResponse(200, text="not json")
        )

        with pytest.raises(FFIDAgencyParseError) as exc_info:
            await agency_client.get_agencies()

        assert exc_info.value.code == "PARSE_ERROR"

    @pytest.mark.asyncio
    @respx.mock
    async def test_model_validation_error_raises_parse_error(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        from ffid_sdk.agency.errors import FFIDAgencyParseError

        respx.get(f"{TEST_API_BASE}/api/v1/agencies/agency-1").mock(
            return_value=respx.MockResponse(
                200,
                json={
                    "success": True,
                    "data": {"agency": {"invalid_field_only": True}},
                },
            )
        )

        with pytest.raises(FFIDAgencyParseError, match="形式が不正"):
            await agency_client.get_agency("agency-1")


class TestFFIDAgencyClientDataMissingFallback:
    """data-missing fallback テスト"""

    @pytest.mark.asyncio
    @respx.mock
    async def test_success_true_but_no_data_returns_error(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        respx.get(f"{TEST_API_BASE}/api/v1/agencies").mock(
            return_value=respx.MockResponse(200, json={"success": True})
        )

        data, err = await agency_client.get_agencies()

        assert data is None
        assert err is not None
        assert err.message == "サーバーからデータが返されませんでした"

    @pytest.mark.asyncio
    @respx.mock
    async def test_success_true_data_null_returns_error(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        respx.get(f"{TEST_API_BASE}/api/v1/agencies").mock(
            return_value=respx.MockResponse(
                200, json={"success": True, "data": None}
            )
        )

        data, err = await agency_client.get_agencies()

        assert data is None
        assert err is not None
        assert err.message == "サーバーからデータが返されませんでした"

    @pytest.mark.asyncio
    @respx.mock
    async def test_data_missing_key_fallback_for_model(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        respx.get(f"{TEST_API_BASE}/api/v1/agencies/agency-1/branding").mock(
            return_value=respx.MockResponse(
                200,
                json={
                    "success": True,
                    "data": {
                        "logoUrl": "https://example.com/logo.png",
                        "primaryColor": "#FF0000",
                    },
                },
            )
        )

        branding, err = await agency_client.get_branding("agency-1")

        assert err is None
        assert branding is not None
        assert branding.logo_url == "https://example.com/logo.png"


class TestFFIDAgencyClientUpdateMember:
    """update_member テスト（マルチパラメータバリデーション）"""

    @pytest.mark.asyncio
    @respx.mock
    async def test_update_member_success(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        respx.put(
            f"{TEST_API_BASE}/api/v1/agencies/agency-1/members/user-1"
        ).mock(
            return_value=respx.MockResponse(
                200,
                json={
                    "success": True,
                    "data": {
                        "member": {
                            "userId": "user-1",
                            "email": "admin@test.com",
                            "displayName": "Admin",
                            "avatarUrl": None,
                            "role": "admin",
                            "status": "active",
                            "joinedAt": "2025-01-01T00:00:00Z",
                            "invitedAt": None,
                        }
                    },
                },
            )
        )

        member, err = await agency_client.update_member(
            "agency-1", "user-1", role="admin"
        )

        assert err is None
        assert member is not None
        assert member.role == "admin"

    @pytest.mark.asyncio
    @respx.mock
    async def test_update_member_sends_correct_payload(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        import json

        route = respx.put(
            f"{TEST_API_BASE}/api/v1/agencies/agency-1/members/user-1"
        ).mock(
            return_value=respx.MockResponse(
                200,
                json={
                    "success": True,
                    "data": {
                        "member": {
                            "userId": "user-1",
                            "email": "a@b.com",
                            "displayName": None,
                            "avatarUrl": None,
                            "role": "sales",
                            "status": "active",
                            "joinedAt": None,
                            "invitedAt": None,
                        }
                    },
                },
            )
        )

        await agency_client.update_member("agency-1", "user-1", role="sales")

        assert route.called
        body = json.loads(route.calls.last.request.content)
        assert body == {"role": "sales"}


class TestFFIDAgencyClientRemoveMember:
    """remove_member テスト（マルチパラメータバリデーション）"""

    @pytest.mark.asyncio
    @respx.mock
    async def test_remove_member_success(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        respx.delete(
            f"{TEST_API_BASE}/api/v1/agencies/agency-1/members/user-1"
        ).mock(
            return_value=respx.MockResponse(
                200,
                json={"success": True, "data": {"message": "Member removed"}},
            )
        )

        data, err = await agency_client.remove_member("agency-1", "user-1")

        assert err is None
        assert data is not None
        assert data["message"] == "Member removed"

    @pytest.mark.asyncio
    @respx.mock
    async def test_remove_member_not_found(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        respx.delete(
            f"{TEST_API_BASE}/api/v1/agencies/agency-1/members/nonexistent"
        ).mock(
            return_value=respx.MockResponse(
                404,
                json={
                    "success": False,
                    "error": {
                        "code": "NOT_FOUND",
                        "message": "Member not found",
                    },
                },
            )
        )

        data, err = await agency_client.remove_member("agency-1", "nonexistent")

        assert data is None
        assert err is not None
        assert err.code == "NOT_FOUND"


class TestFFIDAgencyClientAddMember:
    """add_member テスト"""

    @pytest.mark.asyncio
    @respx.mock
    async def test_add_member_success(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        respx.post(f"{TEST_API_BASE}/api/v1/agencies/agency-1/members").mock(
            return_value=respx.MockResponse(
                200,
                json={
                    "success": True,
                    "data": {
                        "member": {
                            "userId": "user-new",
                            "email": "new@test.com",
                            "displayName": None,
                            "avatarUrl": None,
                            "role": "support",
                            "status": "invited",
                            "joinedAt": None,
                            "invitedAt": "2025-06-01T00:00:00Z",
                        }
                    },
                },
            )
        )

        member, err = await agency_client.add_member(
            "agency-1", email="new@test.com"
        )

        assert err is None
        assert member is not None
        assert member.email == "new@test.com"
        assert member.status == "invited"

    @pytest.mark.asyncio
    @respx.mock
    async def test_add_member_with_role(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        import json

        route = respx.post(
            f"{TEST_API_BASE}/api/v1/agencies/agency-1/members"
        ).mock(
            return_value=respx.MockResponse(
                200,
                json={
                    "success": True,
                    "data": {
                        "member": {
                            "userId": "user-new",
                            "email": "admin@test.com",
                            "displayName": None,
                            "avatarUrl": None,
                            "role": "admin",
                            "status": "invited",
                            "joinedAt": None,
                            "invitedAt": "2025-06-01T00:00:00Z",
                        }
                    },
                },
            )
        )

        member, err = await agency_client.add_member(
            "agency-1", email="admin@test.com", role="admin"
        )

        assert err is None
        assert member is not None
        assert member.role == "admin"

        body = json.loads(route.calls.last.request.content)
        assert body["email"] == "admin@test.com"
        assert body["role"] == "admin"


class TestFFIDAgencyClientOrganizations:
    """組織管理テスト（追加）"""

    @pytest.mark.asyncio
    @respx.mock
    async def test_get_organizations_returns_list(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        respx.get(
            f"{TEST_API_BASE}/api/v1/agencies/agency-1/organizations"
        ).mock(
            return_value=respx.MockResponse(
                200,
                json={
                    "success": True,
                    "data": {
                        "organizations": [
                            {
                                "id": "link-1",
                                "agencyId": "agency-1",
                                "organizationId": "org-1",
                                "organizationName": "Org 1",
                                "organizationSlug": "org-1",
                                "billingOverride": "default",
                                "commissionRate": None,
                                "markupRate": None,
                                "markupFixed": None,
                                "notes": None,
                                "createdAt": "2025-01-01T00:00:00Z",
                            }
                        ],
                        "count": 1,
                    },
                },
            )
        )

        orgs, err = await agency_client.get_organizations("agency-1")

        assert err is None
        assert orgs is not None
        assert len(orgs) == 1
        assert orgs[0].organization_name == "Org 1"

    @pytest.mark.asyncio
    @respx.mock
    async def test_unlink_organization(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        respx.delete(
            f"{TEST_API_BASE}/api/v1/agencies/agency-1/organizations/org-1"
        ).mock(
            return_value=respx.MockResponse(
                200, json={"success": True, "data": {"message": "Unlinked"}}
            )
        )

        data, err = await agency_client.unlink_organization("agency-1", "org-1")

        assert err is None
        assert data is not None


class TestFFIDAgencyClientSubAgencies:
    """サブ代理店テスト"""

    @pytest.mark.asyncio
    @respx.mock
    async def test_get_sub_agencies(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        respx.get(
            f"{TEST_API_BASE}/api/v1/agencies/agency-1/sub-agencies"
        ).mock(
            return_value=respx.MockResponse(
                200,
                json={
                    "success": True,
                    "data": {
                        "agencies": [
                            {
                                "id": "sub-1",
                                "name": "Sub Agency",
                                "slug": "sub-agency",
                                "isPlatformOwner": False,
                                "parentAgencyId": "agency-1",
                                "status": "active",
                                "settings": {},
                                "billingType": "direct",
                                "contactEmail": None,
                                "createdAt": "2025-01-01T00:00:00Z",
                                "updatedAt": "2025-01-01T00:00:00Z",
                            }
                        ],
                        "count": 1,
                    },
                },
            )
        )

        subs, err = await agency_client.get_sub_agencies("agency-1")

        assert err is None
        assert subs is not None
        assert len(subs) == 1
        assert subs[0].name == "Sub Agency"

    @pytest.mark.asyncio
    @respx.mock
    async def test_create_sub_agency(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        import json

        route = respx.post(
            f"{TEST_API_BASE}/api/v1/agencies/agency-1/sub-agencies"
        ).mock(
            return_value=respx.MockResponse(
                200,
                json={
                    "success": True,
                    "data": {
                        "agency": {
                            "id": "sub-new",
                            "name": "New Sub",
                            "slug": "new-sub",
                            "isPlatformOwner": False,
                            "parentAgencyId": "agency-1",
                            "status": "active",
                            "settings": {},
                            "billingType": "direct",
                            "contactEmail": "c@sub.com",
                            "createdAt": "2025-06-01T00:00:00Z",
                            "updatedAt": "2025-06-01T00:00:00Z",
                        }
                    },
                },
            )
        )

        agency, err = await agency_client.create_sub_agency(
            "agency-1", name="New Sub", contact_email="c@sub.com"
        )

        assert err is None
        assert agency is not None
        assert agency.name == "New Sub"

        body = json.loads(route.calls.last.request.content)
        assert body["name"] == "New Sub"
        assert body["contactEmail"] == "c@sub.com"


class TestFFIDAgencyClientEmailSettings:
    """メール設定テスト"""

    @pytest.mark.asyncio
    @respx.mock
    async def test_get_email_settings(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        respx.get(
            f"{TEST_API_BASE}/api/v1/agencies/agency-1/email-settings"
        ).mock(
            return_value=respx.MockResponse(
                200,
                json={
                    "success": True,
                    "data": {
                        "emailSettings": {
                            "fromName": "Partner Inc.",
                            "fromEmail": "noreply@partner.com",
                            "replyTo": "support@partner.com",
                        }
                    },
                },
            )
        )

        settings, err = await agency_client.get_email_settings("agency-1")

        assert err is None
        assert settings is not None
        assert settings.from_name == "Partner Inc."
        assert settings.reply_to == "support@partner.com"

    @pytest.mark.asyncio
    @respx.mock
    async def test_update_email_settings(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        import json

        route = respx.put(
            f"{TEST_API_BASE}/api/v1/agencies/agency-1/email-settings"
        ).mock(
            return_value=respx.MockResponse(
                200,
                json={
                    "success": True,
                    "data": {
                        "emailSettings": {
                            "fromName": "Updated",
                            "fromEmail": "new@p.com",
                            "replyTo": None,
                        }
                    },
                },
            )
        )

        settings, err = await agency_client.update_email_settings(
            "agency-1", from_name="Updated", from_email="new@p.com"
        )

        assert err is None
        assert settings is not None
        assert settings.from_name == "Updated"

        body = json.loads(route.calls.last.request.content)
        assert body["fromName"] == "Updated"
        assert body["fromEmail"] == "new@p.com"


class TestFFIDAgencyClientUpdateBilling:
    """課金設定更新テスト"""

    @pytest.mark.asyncio
    @respx.mock
    async def test_update_billing(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        import json

        route = respx.put(
            f"{TEST_API_BASE}/api/v1/agencies/agency-1/billing"
        ).mock(
            return_value=respx.MockResponse(
                200,
                json={
                    "success": True,
                    "data": {
                        "billing": {
                            "billingType": "markup",
                            "stripeCustomerId": "cus_test",
                            "invoiceEmail": "billing@a.com",
                            "paymentTerms": 45,
                            "defaultMarkupRate": 0.1,
                            "defaultMarkupFixed": None,
                        }
                    },
                },
            )
        )

        billing, err = await agency_client.update_billing(
            "agency-1", billing_type="markup", payment_terms=45,
            default_markup_rate=0.1,
        )

        assert err is None
        assert billing is not None
        assert billing.billing_type == "markup"
        assert billing.payment_terms == 45

        body = json.loads(route.calls.last.request.content)
        assert body["billingType"] == "markup"


class TestFFIDAgencyClientInvoices:
    """請求書テスト"""

    @pytest.mark.asyncio
    @respx.mock
    async def test_get_invoices_returns_list(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        respx.get(f"{TEST_API_BASE}/api/v1/agencies/agency-1/invoices").mock(
            return_value=respx.MockResponse(
                200,
                json={
                    "success": True,
                    "data": {
                        "invoices": [
                            {
                                "id": "inv-1",
                                "amount": 10000,
                                "currency": "jpy",
                                "status": "paid",
                                "periodStart": "2025-01-01T00:00:00Z",
                                "periodEnd": "2025-01-31T23:59:59Z",
                                "createdAt": "2025-02-01T00:00:00Z",
                            }
                        ],
                        "count": 1,
                    },
                },
            )
        )

        invoices, err = await agency_client.get_invoices("agency-1")

        assert err is None
        assert invoices is not None
        assert len(invoices) == 1
        assert invoices[0].amount == 10000


class TestFFIDAgencyClientDomainExtended:
    """ドメイン管理テスト（追加）"""

    @pytest.mark.asyncio
    @respx.mock
    async def test_get_domain(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        respx.get(f"{TEST_API_BASE}/api/v1/agencies/agency-1/domain").mock(
            return_value=respx.MockResponse(
                200,
                json={
                    "success": True,
                    "data": {
                        "domain": {
                            "customDomain": "id.partner.com",
                            "sslStatus": "active",
                            "verifiedAt": "2025-01-01T00:00:00Z",
                        }
                    },
                },
            )
        )

        domain, err = await agency_client.get_domain("agency-1")

        assert err is None
        assert domain is not None
        assert domain.custom_domain == "id.partner.com"
        assert domain.ssl_status == "active"

    @pytest.mark.asyncio
    @respx.mock
    async def test_remove_domain(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        respx.delete(f"{TEST_API_BASE}/api/v1/agencies/agency-1/domain").mock(
            return_value=respx.MockResponse(
                200, json={"success": True, "data": {"message": "Removed"}}
            )
        )

        data, err = await agency_client.remove_domain("agency-1")

        assert err is None
        assert data is not None

    @pytest.mark.asyncio
    @respx.mock
    async def test_verify_domain(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        respx.post(
            f"{TEST_API_BASE}/api/v1/agencies/agency-1/domain/verify"
        ).mock(
            return_value=respx.MockResponse(
                200,
                json={
                    "success": True,
                    "data": {
                        "domain": {
                            "customDomain": "id.partner.com",
                            "sslStatus": "active",
                            "verifiedAt": "2025-06-01T00:00:00Z",
                        }
                    },
                },
            )
        )

        domain, err = await agency_client.verify_domain("agency-1")

        assert err is None
        assert domain is not None
        assert domain.ssl_status == "active"


class TestFFIDAgencyClientUpdateAgency:
    """代理店更新テスト"""

    @pytest.mark.asyncio
    @respx.mock
    async def test_update_agency_name(
        self, agency_client: FFIDAgencyClient
    ) -> None:
        import json

        route = respx.put(f"{TEST_API_BASE}/api/v1/agencies/agency-1").mock(
            return_value=respx.MockResponse(
                200,
                json={
                    "success": True,
                    "data": {
                        "agency": {
                            "id": "agency-1",
                            "name": "Updated Name",
                            "slug": "updated-name",
                            "isPlatformOwner": False,
                            "parentAgencyId": None,
                            "status": "active",
                            "settings": {},
                            "billingType": "direct",
                            "contactEmail": "c@a.com",
                            "createdAt": "2025-01-01T00:00:00Z",
                            "updatedAt": "2025-06-01T00:00:00Z",
                        }
                    },
                },
            )
        )

        agency, err = await agency_client.update_agency(
            "agency-1", name="Updated Name"
        )

        assert err is None
        assert agency is not None
        assert agency.name == "Updated Name"

        body = json.loads(route.calls.last.request.content)
        assert body == {"name": "Updated Name"}


class TestFFIDAgencyClientLifecycle:
    """クライアントライフサイクルテスト"""

    @pytest.mark.asyncio
    async def test_close_closes_http_client(
        self, agency_config: FFIDAgencyClientConfig
    ) -> None:
        client = FFIDAgencyClient(agency_config)
        assert not client._client.is_closed
        await client.close()
        assert client._client.is_closed

    @pytest.mark.asyncio
    async def test_async_context_manager(
        self, agency_config: FFIDAgencyClientConfig
    ) -> None:
        async with FFIDAgencyClient(agency_config) as client:
            assert not client._client.is_closed
        assert client._client.is_closed

    @pytest.mark.asyncio
    async def test_raises_on_request_after_close(
        self, agency_config: FFIDAgencyClientConfig
    ) -> None:
        client = FFIDAgencyClient(agency_config)
        await client.close()
        with pytest.raises(FFIDAgencyNetworkError, match="既に閉じられています"):
            await client.get_agencies()
