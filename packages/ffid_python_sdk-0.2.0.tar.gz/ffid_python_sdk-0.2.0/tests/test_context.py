"""
FFID Context Dependencies Tests

get_ffid_context と require_ffid_auth のテスト。
"""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from ffid_sdk.context import get_ffid_context, require_ffid_auth
from ffid_sdk.errors import FFIDAuthenticationError, FFIDErrorCode
from ffid_sdk.types import FFIDContext

from .conftest import create_mock_context


class TestGetFFIDContext:
    """get_ffid_context テスト"""

    def test_returns_context_when_set(self) -> None:
        """request.state にコンテキストがある場合に返すこと"""
        mock_context = create_mock_context()
        request = MagicMock()
        request.state.ffid_context = mock_context

        result = get_ffid_context(request)

        assert result is not None
        assert isinstance(result, FFIDContext)
        assert result.user.email == "test@example.com"

    def test_returns_none_when_not_set(self) -> None:
        """request.state にコンテキストがない場合に None を返すこと"""
        request = MagicMock(spec=[])
        request.state = MagicMock(spec=[])

        result = get_ffid_context(request)

        assert result is None

    def test_returns_none_for_excluded_paths(self) -> None:
        """除外パス（ミドルウェアがコンテキストを設定しない場合）に None を返すこと"""
        request = MagicMock()
        # ffid_context 属性が存在しない場合をシミュレート
        del request.state.ffid_context

        result = get_ffid_context(request)

        assert result is None


class TestRequireFFIDAuth:
    """require_ffid_auth テスト"""

    def test_returns_context_when_authenticated(self) -> None:
        """認証済みの場合にコンテキストを返すこと"""
        mock_context = create_mock_context()
        request = MagicMock()
        request.state.ffid_context = mock_context

        result = require_ffid_auth(request)

        assert isinstance(result, FFIDContext)
        assert result.user.email == "test@example.com"

    def test_raises_error_when_not_authenticated(self) -> None:
        """未認証の場合に FFIDAuthenticationError を送出すること"""
        request = MagicMock(spec=[])
        request.state = MagicMock(spec=[])

        with pytest.raises(FFIDAuthenticationError) as exc_info:
            require_ffid_auth(request)

        assert exc_info.value.code == FFIDErrorCode.AUTHENTICATION_ERROR
        assert "認証が必要です" in exc_info.value.message

    def test_raises_error_when_context_is_none(self) -> None:
        """コンテキストが明示的に None の場合にエラーを送出すること"""
        request = MagicMock()
        request.state.ffid_context = None

        with pytest.raises(FFIDAuthenticationError) as exc_info:
            require_ffid_auth(request)

        assert exc_info.value.code == FFIDErrorCode.AUTHENTICATION_ERROR
