"""
FFID SDK Test Fixtures

テスト全体で共有するフィクスチャとモックデータ。
TypeScript SDK の __tests__/test-utils.tsx に対応。
"""

from __future__ import annotations

from typing import Any, Dict

import pytest

from ffid_sdk.client import FFIDClient
from ffid_sdk.types import (
    FFIDConfig,
    FFIDContext,
    FFIDOrganization,
    FFIDSessionResponse,
    FFIDSubscription,
    FFIDUser,
)

# ---------------------------------------------------------------------------
# Test constants
# ---------------------------------------------------------------------------

TEST_API_BASE_URL = "https://test.ffid.local"
TEST_SERVICE_CODE = "chatbot"
TEST_ACCESS_TOKEN = "test-access-token-abc123"
TEST_USER_ID = "user-uuid-001"
TEST_ORG_ID = "org-uuid-001"
TEST_SUB_ID = "sub-uuid-001"


# ---------------------------------------------------------------------------
# Mock data factories (TypeScript SDK test-utils.tsx パターンに準拠)
# ---------------------------------------------------------------------------


def create_mock_user(**overrides: Any) -> FFIDUser:
    """モックユーザーを生成"""
    defaults: Dict[str, Any] = {
        "id": TEST_USER_ID,
        "email": "test@example.com",
        "displayName": "テストユーザー",
        "avatarUrl": "https://example.com/avatar.png",
        "locale": "ja",
        "timezone": "Asia/Tokyo",
        "createdAt": "2024-01-01T00:00:00Z",
    }
    defaults.update(overrides)
    return FFIDUser.model_validate(defaults)


def create_mock_organization(**overrides: Any) -> FFIDOrganization:
    """モック組織を生成"""
    defaults: Dict[str, Any] = {
        "id": TEST_ORG_ID,
        "name": "テスト組織",
        "slug": "test-org",
        "role": "owner",
        "status": "active",
    }
    defaults.update(overrides)
    return FFIDOrganization.model_validate(defaults)


def create_mock_subscription(**overrides: Any) -> FFIDSubscription:
    """モック契約を生成"""
    defaults: Dict[str, Any] = {
        "id": TEST_SUB_ID,
        "serviceCode": TEST_SERVICE_CODE,
        "serviceName": "AI チャットボット",
        "planCode": "pro",
        "planName": "プロプラン",
        "status": "active",
        "currentPeriodEnd": "2025-12-31T23:59:59Z",
    }
    defaults.update(overrides)
    return FFIDSubscription.model_validate(defaults)


def create_mock_session_response(**overrides: Any) -> FFIDSessionResponse:
    """モックセッションレスポンスを生成"""
    defaults: Dict[str, Any] = {
        "user": create_mock_user().model_dump(by_alias=True),
        "organizations": [create_mock_organization().model_dump(by_alias=True)],
        "subscriptions": [create_mock_subscription().model_dump(by_alias=True)],
    }
    defaults.update(overrides)
    return FFIDSessionResponse.model_validate(defaults)


def create_mock_context(**overrides: Any) -> FFIDContext:
    """モックコンテキストを生成"""
    session = create_mock_session_response()
    defaults: Dict[str, Any] = {
        "user": session.user,
        "organizations": session.organizations,
        "subscriptions": session.subscriptions,
        "access_token": TEST_ACCESS_TOKEN,
    }
    defaults.update(overrides)
    return FFIDContext(**defaults)


def create_mock_api_response(
    data: Any = None,
    error: Any = None,
) -> Dict[str, Any]:
    """モックAPIレスポンスJSONを生成（TypeScript版の discriminated union 相当）"""
    if error:
        return {"error": error}
    return {"data": data}


# ---------------------------------------------------------------------------
# Pytest fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def ffid_config() -> FFIDConfig:
    """テスト用SDK設定"""
    return FFIDConfig(
        service_code=TEST_SERVICE_CODE,
        api_base_url=TEST_API_BASE_URL,
        debug=True,
    )


@pytest.fixture
def ffid_client(ffid_config: FFIDConfig) -> FFIDClient:
    """テスト用FFIDClient"""
    return FFIDClient(ffid_config)


@pytest.fixture
def mock_user() -> FFIDUser:
    """テスト用モックユーザー"""
    return create_mock_user()


@pytest.fixture
def mock_organization() -> FFIDOrganization:
    """テスト用モック組織"""
    return create_mock_organization()


@pytest.fixture
def mock_subscription() -> FFIDSubscription:
    """テスト用モック契約"""
    return create_mock_subscription()


@pytest.fixture
def mock_context() -> FFIDContext:
    """テスト用モックコンテキスト"""
    return create_mock_context()


@pytest.fixture
def mock_session_data() -> Dict[str, Any]:
    """モックセッションAPIレスポンスデータ（JSON形式）"""
    return {
        "user": {
            "id": TEST_USER_ID,
            "email": "test@example.com",
            "displayName": "テストユーザー",
            "avatarUrl": "https://example.com/avatar.png",
            "locale": "ja",
            "timezone": "Asia/Tokyo",
            "createdAt": "2024-01-01T00:00:00Z",
        },
        "organizations": [
            {
                "id": TEST_ORG_ID,
                "name": "テスト組織",
                "slug": "test-org",
                "role": "owner",
                "status": "active",
            }
        ],
        "subscriptions": [
            {
                "id": TEST_SUB_ID,
                "serviceCode": TEST_SERVICE_CODE,
                "serviceName": "AI チャットボット",
                "planCode": "pro",
                "planName": "プロプラン",
                "status": "active",
                "currentPeriodEnd": "2025-12-31T23:59:59Z",
            }
        ],
    }
