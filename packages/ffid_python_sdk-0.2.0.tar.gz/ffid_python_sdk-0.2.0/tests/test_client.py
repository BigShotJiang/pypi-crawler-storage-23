"""
FFIDClient Tests

FFIDClient の全メソッドをテスト。
TypeScript SDK の ffid-client.test.ts に対応。
"""

from __future__ import annotations

from typing import Any, Dict

import httpx
import pytest
import respx

from ffid_sdk.client import FFIDClient, _sanitize_for_log
from ffid_sdk.constants import (
    NO_CONTENT_STATUS,
    REFRESH_ENDPOINT,
    SESSION_ENDPOINT,
    SIGNOUT_ENDPOINT,
    SUBSCRIPTIONS_CHECK_ENDPOINT,
)
from ffid_sdk.errors import FFIDErrorCode, FFIDValidationError
from ffid_sdk.types import FFIDConfig

from .conftest import (
    TEST_ACCESS_TOKEN,
    TEST_API_BASE_URL,
    TEST_SERVICE_CODE,
)


# ---------------------------------------------------------------------------
# _sanitize_for_log tests (debug log sensitive data masking)
# ---------------------------------------------------------------------------


class TestSanitizeForLog:
    """_sanitize_for_log のテスト（センシティブキーがマスクされること）"""

    def test_masks_sensitive_keys_snake_case(self) -> None:
        """snake_case のセンシティブキーがマスクされること"""
        data = {"access_token": "secret", "user_id": "u1"}
        result = _sanitize_for_log(data)
        assert result["access_token"] == "***"
        assert result["user_id"] == "u1"

    def test_masks_sensitive_keys_camel_case(self) -> None:
        """camelCase のセンシティブキーがマスクされること"""
        data = {"accessToken": "secret", "refreshToken": "rt"}
        result = _sanitize_for_log(data)
        assert result["accessToken"] == "***"
        assert result["refreshToken"] == "***"

    def test_masks_nested_sensitive_keys(self) -> None:
        """ネストしたオブジェクト内のセンシティブキーもマスクされること"""
        data = {"data": {"access_token": "secret", "expires_in": 3600}}
        result = _sanitize_for_log(data)
        assert result["data"]["access_token"] == "***"
        assert result["data"]["expires_in"] == 3600

    def test_masks_sensitive_keys_in_list_of_dicts(self) -> None:
        """辞書の値であるリスト内の辞書に含まれるセンシティブキーもマスクされること"""
        data = {"items": [{"refresh_token": "rt1"}, {"name": "foo"}]}
        result = _sanitize_for_log(data)
        assert result["items"][0]["refresh_token"] == "***"
        assert result["items"][1]["name"] == "foo"

    def test_returns_non_dict_unchanged(self) -> None:
        """dict 以外を渡した場合はそのまま返すこと（APIレスポンスは常にdict想定）"""
        assert _sanitize_for_log("string") == "string"  # type: ignore[arg-type]
        assert _sanitize_for_log(None) is None  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# Client initialization tests
# ---------------------------------------------------------------------------


class TestFFIDClientInit:
    """クライアント初期化テスト"""

    def test_creates_client_with_valid_config(self) -> None:
        """有効な設定でクライアントを生成できること"""
        config = FFIDConfig(
            service_code=TEST_SERVICE_CODE,
            api_base_url=TEST_API_BASE_URL,
        )
        client = FFIDClient(config)
        assert client.service_code == TEST_SERVICE_CODE
        assert client.base_url == TEST_API_BASE_URL

    def test_uses_default_base_url(self) -> None:
        """api_base_url 未指定時にデフォルトURLを使用すること"""
        config = FFIDConfig(service_code=TEST_SERVICE_CODE)
        client = FFIDClient(config)
        assert client.base_url == "https://id.feelflow.co.jp"

    def test_raises_error_for_empty_service_code(self) -> None:
        """service_code が空文字の場合にエラーを発生させること"""
        config = FFIDConfig(service_code="", api_base_url=TEST_API_BASE_URL)
        with pytest.raises(FFIDValidationError, match="service_code が未設定"):
            FFIDClient(config)

    def test_raises_error_for_whitespace_service_code(self) -> None:
        """service_code がホワイトスペースのみの場合にエラーを発生させること"""
        config = FFIDConfig(service_code="   ", api_base_url=TEST_API_BASE_URL)
        with pytest.raises(FFIDValidationError, match="service_code が未設定"):
            FFIDClient(config)


# ---------------------------------------------------------------------------
# get_session tests
# ---------------------------------------------------------------------------


class TestGetSession:
    """get_session メソッドテスト"""

    @respx.mock
    @pytest.mark.asyncio
    async def test_returns_session_on_success(
        self,
        ffid_client: FFIDClient,
        mock_session_data: Dict[str, Any],
    ) -> None:
        """正常時にセッション情報を返すこと"""
        respx.get(f"{TEST_API_BASE_URL}{SESSION_ENDPOINT}").mock(
            return_value=httpx.Response(200, json={"data": mock_session_data})
        )

        response = await ffid_client.get_session(TEST_ACCESS_TOKEN)

        assert response.is_success
        assert response.data is not None
        assert response.data.user.email == "test@example.com"
        assert response.data.user.display_name == "テストユーザー"
        assert len(response.data.organizations) == 1
        assert len(response.data.subscriptions) == 1

    @respx.mock
    @pytest.mark.asyncio
    async def test_returns_error_on_401(self, ffid_client: FFIDClient) -> None:
        """401レスポンス時にエラーを返すこと"""
        respx.get(f"{TEST_API_BASE_URL}{SESSION_ENDPOINT}").mock(
            return_value=httpx.Response(
                401,
                json={
                    "error": {
                        "code": "AUTHENTICATION_ERROR",
                        "message": "トークンが無効です",
                    }
                },
            )
        )

        response = await ffid_client.get_session(TEST_ACCESS_TOKEN)

        assert not response.is_success
        assert response.error is not None
        assert response.error.code == "AUTHENTICATION_ERROR"

    @respx.mock
    @pytest.mark.asyncio
    async def test_returns_error_on_network_failure(
        self, ffid_client: FFIDClient,
    ) -> None:
        """ネットワークエラー時にエラーを返すこと"""
        respx.get(f"{TEST_API_BASE_URL}{SESSION_ENDPOINT}").mock(
            side_effect=httpx.ConnectError("Connection refused")
        )

        response = await ffid_client.get_session(TEST_ACCESS_TOKEN)

        assert not response.is_success
        assert response.error is not None
        assert response.error.code == FFIDErrorCode.NETWORK_ERROR

    @respx.mock
    @pytest.mark.asyncio
    async def test_returns_error_on_invalid_json(
        self, ffid_client: FFIDClient,
    ) -> None:
        """不正なJSONレスポンス時にエラーを返すこと"""
        respx.get(f"{TEST_API_BASE_URL}{SESSION_ENDPOINT}").mock(
            return_value=httpx.Response(200, content=b"<html>Not JSON</html>")
        )

        response = await ffid_client.get_session(TEST_ACCESS_TOKEN)

        assert not response.is_success
        assert response.error is not None
        assert response.error.code == FFIDErrorCode.PARSE_ERROR

    @respx.mock
    @pytest.mark.asyncio
    async def test_handles_timeout(self, ffid_client: FFIDClient) -> None:
        """タイムアウト時にエラーを返すこと"""
        respx.get(f"{TEST_API_BASE_URL}{SESSION_ENDPOINT}").mock(
            side_effect=httpx.TimeoutException("Request timed out")
        )

        response = await ffid_client.get_session(TEST_ACCESS_TOKEN)

        assert not response.is_success
        assert response.error is not None
        assert response.error.code == FFIDErrorCode.NETWORK_ERROR


# ---------------------------------------------------------------------------
# sign_out tests
# ---------------------------------------------------------------------------


class TestSignOut:
    """sign_out メソッドテスト"""

    @respx.mock
    @pytest.mark.asyncio
    async def test_signs_out_successfully(self, ffid_client: FFIDClient) -> None:
        """正常にサインアウトできること"""
        respx.post(f"{TEST_API_BASE_URL}{SIGNOUT_ENDPOINT}").mock(
            return_value=httpx.Response(NO_CONTENT_STATUS)
        )

        response = await ffid_client.sign_out(TEST_ACCESS_TOKEN)

        assert response.is_success is True  # error=None なので成功
        assert response.error is None

    @respx.mock
    @pytest.mark.asyncio
    async def test_returns_error_on_failure(self, ffid_client: FFIDClient) -> None:
        """サインアウト失敗時にエラーを返すこと"""
        respx.post(f"{TEST_API_BASE_URL}{SIGNOUT_ENDPOINT}").mock(
            side_effect=httpx.ConnectError("Connection refused")
        )

        response = await ffid_client.sign_out(TEST_ACCESS_TOKEN)

        assert response.error is not None
        assert response.error.code == FFIDErrorCode.NETWORK_ERROR


# ---------------------------------------------------------------------------
# refresh_token tests
# ---------------------------------------------------------------------------


class TestRefreshToken:
    """refresh_token メソッドテスト"""

    @respx.mock
    @pytest.mark.asyncio
    async def test_refreshes_token_successfully(
        self, ffid_client: FFIDClient
    ) -> None:
        """正常にトークンをリフレッシュできること"""
        new_token_data = {"access_token": "new-token-xyz", "expires_in": 3600}
        respx.post(f"{TEST_API_BASE_URL}{REFRESH_ENDPOINT}").mock(
            return_value=httpx.Response(200, json={"data": new_token_data})
        )

        response = await ffid_client.refresh_token("old-refresh-token")

        assert response.is_success
        assert response.data is not None
        assert response.data.access_token == "new-token-xyz"

    @respx.mock
    @pytest.mark.asyncio
    async def test_returns_error_on_invalid_token(
        self, ffid_client: FFIDClient
    ) -> None:
        """無効なリフレッシュトークン時にエラーを返すこと"""
        respx.post(f"{TEST_API_BASE_URL}{REFRESH_ENDPOINT}").mock(
            return_value=httpx.Response(
                401,
                json={
                    "error": {
                        "code": "TOKEN_EXPIRED",
                        "message": "リフレッシュトークンの有効期限が切れています",
                    }
                },
            )
        )

        response = await ffid_client.refresh_token("expired-token")

        assert not response.is_success
        assert response.error is not None
        assert response.error.code == "TOKEN_EXPIRED"


# ---------------------------------------------------------------------------
# check_subscription tests
# ---------------------------------------------------------------------------


class TestRetryBehavior:
    """リトライ動作テスト"""

    @respx.mock
    @pytest.mark.asyncio
    async def test_retries_on_timeout_then_succeeds(
        self,
        ffid_client: FFIDClient,
        mock_session_data: Dict[str, Any],
    ) -> None:
        """タイムアウト後にリトライして成功すること"""
        route = respx.get(f"{TEST_API_BASE_URL}{SESSION_ENDPOINT}")

        # 1回目: タイムアウト、2回目: 成功
        route.side_effect = [
            httpx.TimeoutException("Request timed out"),
            httpx.Response(200, json={"data": mock_session_data}),
        ]

        response = await ffid_client.get_session(TEST_ACCESS_TOKEN)

        assert response.is_success
        assert response.data is not None
        assert response.data.user.email == "test@example.com"

    @respx.mock
    @pytest.mark.asyncio
    async def test_all_retries_fail_returns_network_error(
        self, ffid_client: FFIDClient,
    ) -> None:
        """全リトライ失敗後にネットワークエラーを返すこと"""
        respx.get(f"{TEST_API_BASE_URL}{SESSION_ENDPOINT}").mock(
            side_effect=httpx.ConnectError("Connection refused")
        )

        response = await ffid_client.get_session(TEST_ACCESS_TOKEN)

        assert not response.is_success
        assert response.error is not None
        assert response.error.code == FFIDErrorCode.NETWORK_ERROR


class TestRefreshTokenSecurity:
    """refresh_token セキュリティテスト"""

    @respx.mock
    @pytest.mark.asyncio
    async def test_does_not_send_authorization_header(
        self, ffid_client: FFIDClient,
    ) -> None:
        """refresh_token が Authorization ヘッダーを送信しないこと"""
        route = respx.post(f"{TEST_API_BASE_URL}{REFRESH_ENDPOINT}").mock(
            return_value=httpx.Response(
                200, json={"data": {"access_token": "new-token", "expires_in": 3600}}
            )
        )

        await ffid_client.refresh_token("test-refresh-token")

        assert route.called
        request = route.calls[0].request
        auth_header = request.headers.get("Authorization", "")
        # Authorization ヘッダーに Bearer トークンが含まれないこと
        assert not auth_header.startswith("Bearer ")

    @respx.mock
    @pytest.mark.asyncio
    async def test_sends_refresh_token_in_body_only(
        self, ffid_client: FFIDClient,
    ) -> None:
        """refresh_token をボディのみで送信すること"""
        route = respx.post(f"{TEST_API_BASE_URL}{REFRESH_ENDPOINT}").mock(
            return_value=httpx.Response(
                200, json={"data": {"access_token": "new-token", "expires_in": 3600}}
            )
        )

        await ffid_client.refresh_token("my-refresh-token")

        assert route.called
        request = route.calls[0].request
        import json
        body = json.loads(request.content)
        assert body["refresh_token"] == "my-refresh-token"


class TestCheckSubscription:
    """check_subscription メソッドテスト"""

    @respx.mock
    @pytest.mark.asyncio
    async def test_checks_subscription_successfully(
        self, ffid_client: FFIDClient
    ) -> None:
        """正常に契約状況をチェックできること"""
        sub_data = {
            "id": "sub-uuid-001",
            "serviceCode": TEST_SERVICE_CODE,
            "serviceName": "AI チャットボット",
            "planCode": "pro",
            "planName": "プロプラン",
            "status": "active",
            "currentPeriodEnd": "2025-12-31T23:59:59Z",
        }
        respx.get(f"{TEST_API_BASE_URL}{SUBSCRIPTIONS_CHECK_ENDPOINT}").mock(
            return_value=httpx.Response(200, json={"data": sub_data})
        )

        response = await ffid_client.check_subscription(TEST_ACCESS_TOKEN)

        assert response.is_success
        assert response.data is not None
        assert response.data.plan_code == "pro"
        assert response.data.service_code == TEST_SERVICE_CODE

    @respx.mock
    @pytest.mark.asyncio
    async def test_uses_custom_service_code(
        self, ffid_client: FFIDClient
    ) -> None:
        """カスタムサービスコードを指定できること"""
        sub_data = {
            "id": "sub-uuid-002",
            "serviceCode": "analytics",
            "serviceName": "アナリティクス",
            "planCode": "enterprise",
            "planName": "エンタープライズ",
            "status": "active",
            "currentPeriodEnd": None,
        }
        route = respx.get(f"{TEST_API_BASE_URL}{SUBSCRIPTIONS_CHECK_ENDPOINT}").mock(
            return_value=httpx.Response(200, json={"data": sub_data})
        )

        response = await ffid_client.check_subscription(
            TEST_ACCESS_TOKEN, service_code="analytics"
        )

        assert response.is_success
        # service_code パラメータが送信されたことを確認
        assert route.called
        request = route.calls[0].request
        assert "service_code=analytics" in str(request.url)

    @respx.mock
    @pytest.mark.asyncio
    async def test_returns_error_when_no_subscription(
        self, ffid_client: FFIDClient
    ) -> None:
        """契約なしの場合にエラーを返すこと"""
        respx.get(f"{TEST_API_BASE_URL}{SUBSCRIPTIONS_CHECK_ENDPOINT}").mock(
            return_value=httpx.Response(
                404,
                json={
                    "error": {
                        "code": "SUBSCRIPTION_NOT_FOUND",
                        "message": "契約が見つかりません",
                    }
                },
            )
        )

        response = await ffid_client.check_subscription(TEST_ACCESS_TOKEN)

        assert not response.is_success
        assert response.error is not None
        assert response.error.code == "SUBSCRIPTION_NOT_FOUND"
