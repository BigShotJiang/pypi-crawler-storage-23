"""
Webhook Handler Tests

WebhookHandler のデコレータ登録・ディスパッチ・FastAPIルーターテスト。
"""

from __future__ import annotations

import hashlib
import hmac
import json
import time
from typing import List

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from ffid_sdk.webhook_constants import FFID_WEBHOOK_SIGNATURE_HEADER
from ffid_sdk.webhook_handler import WebhookHandler
from ffid_sdk.webhook_types import FFIDWebhookEvent

# ---------------------------------------------------------------------------
# Test constants
# ---------------------------------------------------------------------------

TEST_SECRET = "whsec_handler_test_secret"
TEST_EVENT_PAYLOAD = {
    "id": "evt_handler_001",
    "type": "subscription.created",
    "createdAt": "2024-06-01T00:00:00Z",
    "data": {
        "subscriptionId": "sub_789",
        "plan": "enterprise",
    },
}
TEST_USER_EVENT_PAYLOAD = {
    "id": "evt_handler_002",
    "type": "user.created",
    "createdAt": "2024-06-01T00:00:00Z",
    "data": {
        "userId": "user_123",
        "email": "test@example.com",
    },
}


def _build_signature(secret: str, timestamp: int, body: str) -> str:
    """テスト用署名生成ヘルパー"""
    signed_content = f"{timestamp}.{body}"
    sig = hmac.new(
        secret.encode("utf-8"),
        signed_content.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()
    return f"t={timestamp},v1={sig}"


def _create_test_app(handler: WebhookHandler) -> FastAPI:
    """テスト用FastAPIアプリを生成"""
    app = FastAPI()
    app.include_router(handler.router, prefix="/webhooks/ffid")
    return app


# ---------------------------------------------------------------------------
# Decorator registration tests
# ---------------------------------------------------------------------------


class TestWebhookHandlerDecorator:
    """デコレータ登録テスト"""

    def test_on_registers_handler(self) -> None:
        """on() でハンドラーが登録されること"""
        handler = WebhookHandler(secret=TEST_SECRET)

        @handler.on("subscription.created")
        async def on_sub(event: FFIDWebhookEvent) -> None:
            pass

        assert "subscription.created" in handler._handlers
        assert on_sub in handler._handlers["subscription.created"]

    def test_on_all_registers_handler(self) -> None:
        """on_all() でハンドラーが登録されること"""
        handler = WebhookHandler(secret=TEST_SECRET)

        @handler.on_all()
        async def on_any(event: FFIDWebhookEvent) -> None:
            pass

        assert on_any in handler._all_handlers

    def test_multiple_handlers_for_same_event(self) -> None:
        """同一イベントタイプに複数ハンドラーを登録できること"""
        handler = WebhookHandler(secret=TEST_SECRET)

        @handler.on("user.created")
        async def handler_a(event: FFIDWebhookEvent) -> None:
            pass

        @handler.on("user.created")
        async def handler_b(event: FFIDWebhookEvent) -> None:
            pass

        assert len(handler._handlers["user.created"]) == 2

    def test_decorator_returns_original_function(self) -> None:
        """デコレータが元の関数を返すこと"""
        handler = WebhookHandler(secret=TEST_SECRET)

        @handler.on("test.ping")
        async def original_func(event: FFIDWebhookEvent) -> None:
            pass

        # デコレータが関数を変更しないことを確認
        assert original_func.__name__ == "original_func"


# ---------------------------------------------------------------------------
# handle_event & dispatch tests
# ---------------------------------------------------------------------------


class TestWebhookHandlerDispatch:
    """イベントディスパッチテスト"""

    @pytest.mark.asyncio
    async def test_handle_event_calls_specific_handler(self) -> None:
        """handle_event が特定イベントハンドラーを呼び出すこと"""
        handler = WebhookHandler(secret=TEST_SECRET)
        received_events: List[FFIDWebhookEvent] = []

        @handler.on("subscription.created")
        async def on_sub(event: FFIDWebhookEvent) -> None:
            received_events.append(event)

        body = json.dumps(TEST_EVENT_PAYLOAD)
        timestamp = int(time.time())
        signature = _build_signature(TEST_SECRET, timestamp, body)

        event = await handler.handle_event(body.encode("utf-8"), signature)

        assert len(received_events) == 1
        assert received_events[0].id == "evt_handler_001"
        assert event.type == "subscription.created"

    @pytest.mark.asyncio
    async def test_handle_event_calls_all_handler(self) -> None:
        """handle_event が on_all ハンドラーを呼び出すこと"""
        handler = WebhookHandler(secret=TEST_SECRET)
        received_events: List[FFIDWebhookEvent] = []

        @handler.on_all()
        async def on_any(event: FFIDWebhookEvent) -> None:
            received_events.append(event)

        body = json.dumps(TEST_EVENT_PAYLOAD)
        timestamp = int(time.time())
        signature = _build_signature(TEST_SECRET, timestamp, body)

        await handler.handle_event(body.encode("utf-8"), signature)

        assert len(received_events) == 1

    @pytest.mark.asyncio
    async def test_handle_event_calls_both_specific_and_all(self) -> None:
        """handle_event が特定ハンドラーと on_all の両方を呼び出すこと"""
        handler = WebhookHandler(secret=TEST_SECRET)
        specific_events: List[str] = []
        all_events: List[str] = []

        @handler.on("subscription.created")
        async def on_sub(event: FFIDWebhookEvent) -> None:
            specific_events.append(event.id)

        @handler.on_all()
        async def on_any(event: FFIDWebhookEvent) -> None:
            all_events.append(event.id)

        body = json.dumps(TEST_EVENT_PAYLOAD)
        timestamp = int(time.time())
        signature = _build_signature(TEST_SECRET, timestamp, body)

        await handler.handle_event(body.encode("utf-8"), signature)

        assert specific_events == ["evt_handler_001"]
        assert all_events == ["evt_handler_001"]

    @pytest.mark.asyncio
    async def test_unmatched_event_type_only_calls_all_handler(self) -> None:
        """登録されてないイベントタイプでは on_all のみ呼ばれること"""
        handler = WebhookHandler(secret=TEST_SECRET)
        specific_events: List[str] = []
        all_events: List[str] = []

        @handler.on("subscription.created")
        async def on_sub(event: FFIDWebhookEvent) -> None:
            specific_events.append(event.id)

        @handler.on_all()
        async def on_any(event: FFIDWebhookEvent) -> None:
            all_events.append(event.id)

        body = json.dumps(TEST_USER_EVENT_PAYLOAD)
        timestamp = int(time.time())
        signature = _build_signature(TEST_SECRET, timestamp, body)

        await handler.handle_event(body.encode("utf-8"), signature)

        assert specific_events == []
        assert all_events == ["evt_handler_002"]

    @pytest.mark.asyncio
    async def test_handler_error_does_not_stop_dispatch(self) -> None:
        """ハンドラーのエラーが他のハンドラーの実行を止めないこと"""
        handler = WebhookHandler(secret=TEST_SECRET)
        second_called = False

        @handler.on("subscription.created")
        async def failing_handler(event: FFIDWebhookEvent) -> None:
            raise ValueError("handler error")

        @handler.on_all()
        async def second_handler(event: FFIDWebhookEvent) -> None:
            nonlocal second_called
            second_called = True

        body = json.dumps(TEST_EVENT_PAYLOAD)
        timestamp = int(time.time())
        signature = _build_signature(TEST_SECRET, timestamp, body)

        # エラーが発生してもhandle_event自体は成功する
        event = await handler.handle_event(body.encode("utf-8"), signature)
        assert event.id == "evt_handler_001"
        assert second_called

    @pytest.mark.asyncio
    async def test_sync_handler_is_supported(self) -> None:
        """同期ハンドラーも動作すること"""
        handler = WebhookHandler(secret=TEST_SECRET)
        received: List[str] = []

        @handler.on("subscription.created")
        def sync_handler(event: FFIDWebhookEvent) -> None:
            received.append(event.id)

        body = json.dumps(TEST_EVENT_PAYLOAD)
        timestamp = int(time.time())
        signature = _build_signature(TEST_SECRET, timestamp, body)

        await handler.handle_event(body.encode("utf-8"), signature)
        assert received == ["evt_handler_001"]


# ---------------------------------------------------------------------------
# FastAPI Router integration tests
# ---------------------------------------------------------------------------


class TestWebhookHandlerRouter:
    """FastAPIルーター統合テスト"""

    def test_router_returns_200_on_valid_request(self) -> None:
        """正しいリクエストで200を返すこと"""
        handler = WebhookHandler(secret=TEST_SECRET)

        @handler.on("subscription.created")
        async def on_sub(event: FFIDWebhookEvent) -> None:
            pass

        app = _create_test_app(handler)
        client = TestClient(app)

        body = json.dumps(TEST_EVENT_PAYLOAD)
        timestamp = int(time.time())
        signature = _build_signature(TEST_SECRET, timestamp, body)

        response = client.post(
            "/webhooks/ffid/",
            content=body,
            headers={FFID_WEBHOOK_SIGNATURE_HEADER: signature},
        )

        assert response.status_code == 200
        data = response.json()
        assert data["received"] is True
        assert data["eventId"] == "evt_handler_001"

    def test_router_returns_400_on_missing_signature(self) -> None:
        """署名ヘッダーなしで400を返すこと"""
        handler = WebhookHandler(secret=TEST_SECRET)
        app = _create_test_app(handler)
        client = TestClient(app)

        body = json.dumps(TEST_EVENT_PAYLOAD)

        response = client.post(
            "/webhooks/ffid/",
            content=body,
        )

        assert response.status_code == 400
        data = response.json()
        assert data["error"]["code"] == "WEBHOOK_SIGNATURE_ERROR"

    def test_router_returns_400_on_invalid_signature(self) -> None:
        """不正な署名で400を返すこと"""
        handler = WebhookHandler(secret=TEST_SECRET)
        app = _create_test_app(handler)
        client = TestClient(app)

        body = json.dumps(TEST_EVENT_PAYLOAD)
        timestamp = int(time.time())

        response = client.post(
            "/webhooks/ffid/",
            content=body,
            headers={
                FFID_WEBHOOK_SIGNATURE_HEADER: f"t={timestamp},v1=invalid_signature_hex"
            },
        )

        assert response.status_code == 400
        data = response.json()
        assert data["error"]["code"] == "WEBHOOK_SIGNATURE_ERROR"

    def test_router_returns_400_on_expired_timestamp(self) -> None:
        """期限切れタイムスタンプで400を返すこと"""
        handler = WebhookHandler(secret=TEST_SECRET, tolerance_seconds=60)
        app = _create_test_app(handler)
        client = TestClient(app)

        body = json.dumps(TEST_EVENT_PAYLOAD)
        old_timestamp = int(time.time()) - 120  # 2分前
        signature = _build_signature(TEST_SECRET, old_timestamp, body)

        response = client.post(
            "/webhooks/ffid/",
            content=body,
            headers={FFID_WEBHOOK_SIGNATURE_HEADER: signature},
        )

        assert response.status_code == 400
        data = response.json()
        assert data["error"]["code"] == "WEBHOOK_TIMESTAMP_ERROR"

    def test_router_custom_path(self) -> None:
        """カスタムパスでルーターが動作すること"""
        handler = WebhookHandler(secret=TEST_SECRET, path="/receive")
        app = FastAPI()
        app.include_router(handler.router, prefix="/hooks")
        client = TestClient(app)

        body = json.dumps(TEST_EVENT_PAYLOAD)
        timestamp = int(time.time())
        signature = _build_signature(TEST_SECRET, timestamp, body)

        response = client.post(
            "/hooks/receive",
            content=body,
            headers={FFID_WEBHOOK_SIGNATURE_HEADER: signature},
        )

        assert response.status_code == 200

    def test_router_dispatches_to_handlers(self) -> None:
        """ルーター経由でハンドラーが呼ばれること"""
        handler = WebhookHandler(secret=TEST_SECRET)
        received: List[str] = []

        @handler.on("subscription.created")
        async def on_sub(event: FFIDWebhookEvent) -> None:
            received.append(event.id)

        app = _create_test_app(handler)
        client = TestClient(app)

        body = json.dumps(TEST_EVENT_PAYLOAD)
        timestamp = int(time.time())
        signature = _build_signature(TEST_SECRET, timestamp, body)

        client.post(
            "/webhooks/ffid/",
            content=body,
            headers={FFID_WEBHOOK_SIGNATURE_HEADER: signature},
        )

        assert received == ["evt_handler_001"]
