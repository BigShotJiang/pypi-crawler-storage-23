"""
Python SDK Integration Tests

Verifies SDK can connect to real FFID API.
Requires: FFID_API_BASE_URL (default: http://localhost:3000), server running

@see docs/07-quality/TESTING.md
"""

from __future__ import annotations

import os

import httpx
import pytest

from ffid_sdk.client import FFIDClient
from ffid_sdk.types import FFIDConfig

BASE_URL = os.environ.get("FFID_API_BASE_URL", "http://localhost:3000")

HTTP_OK = 200
HTTP_UNAUTHORIZED = 401


async def is_server_reachable() -> bool:
    """Check if FFID API server is reachable."""
    try:
        async with httpx.AsyncClient() as client:
            res = await client.get(f"{BASE_URL}/api/v1/auth/session")
            return res.status_code in (HTTP_OK, HTTP_UNAUTHORIZED)
    except Exception:
        return False


@pytest.fixture
def ffid_client() -> FFIDClient:
    """Create FFID client for integration tests."""
    return FFIDClient(FFIDConfig(service_code="chatbot", api_base_url=BASE_URL))


@pytest.mark.asyncio
async def test_connect_to_session_endpoint(ffid_client: FFIDClient) -> None:
    """SDK should connect to session endpoint and handle response."""
    if not await is_server_reachable():
        pytest.skip("Server not reachable")

    response = await ffid_client.get_session(token="invalid-token-for-test")

    if response.error:
        assert response.error.code is not None
    else:
        assert response.data is not None
        assert response.data.user is not None
