"""
FFID Legal Helpers Tests

check_pending_agreements_and_redirect_url のテスト。
"""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from ffid_sdk.constants import DEFAULT_API_BASE_URL
from ffid_sdk.legal import check_pending_agreements_and_redirect_url
from ffid_sdk.legal.client import FFIDLegalClient
from ffid_sdk.legal.types import (
    FFIDLegalClientConfig,
    FFIDLegalServerError,
    FFIDPendingAgreementsResponse,
)


@pytest.fixture
def legal_client() -> FFIDLegalClient:
    return FFIDLegalClient(FFIDLegalClientConfig(api_key="ffid_sk_test"))


@pytest.mark.asyncio
async def test_returns_no_pending_when_has_pending_false(
    legal_client: FFIDLegalClient,
) -> None:
    legal_client.get_pending_agreements = AsyncMock(
        return_value=(
            FFIDPendingAgreementsResponse(
                pending_documents=[],
                count=0,
                has_pending=False,
            ),
            None,
        )
    )
    has_pending, pending, redirect_url, error = (
        await check_pending_agreements_and_redirect_url(
            legal_client, "user-1"
        )
    )
    assert has_pending is False
    assert pending is not None
    assert pending.has_pending is False
    assert error is None
    assert DEFAULT_API_BASE_URL in redirect_url


@pytest.mark.asyncio
async def test_returns_pending_and_redirect_when_has_pending_true(
    legal_client: FFIDLegalClient,
) -> None:
    legal_client.get_pending_agreements = AsyncMock(
        return_value=(
            FFIDPendingAgreementsResponse(
                pending_documents=[],
                count=1,
                has_pending=True,
            ),
            None,
        )
    )
    has_pending, pending, redirect_url, error = (
        await check_pending_agreements_and_redirect_url(
            legal_client, "user-1"
        )
    )
    assert has_pending is True
    assert pending is not None
    assert error is None
    assert "portal/legal" in redirect_url


@pytest.mark.asyncio
async def test_redirect_uri_after_agree_appended_to_redirect_url(
    legal_client: FFIDLegalClient,
) -> None:
    legal_client.get_pending_agreements = AsyncMock(
        return_value=(
            FFIDPendingAgreementsResponse(
                pending_documents=[],
                count=1,
                has_pending=True,
            ),
            None,
        )
    )
    _, _, redirect_url, _ = await check_pending_agreements_and_redirect_url(
        legal_client,
        "user-1",
        redirect_uri_after_agree="https://app.example.com/callback",
    )
    assert "redirect_uri=" in redirect_url
    assert "https" in redirect_url


@pytest.mark.asyncio
async def test_returns_error_when_api_fails(
    legal_client: FFIDLegalClient,
) -> None:
    """API 失敗時は第4要素にエラーが入り、has_pending は False になること"""
    legal_client.get_pending_agreements = AsyncMock(
        return_value=(
            None,
            FFIDLegalServerError(
                code="NETWORK_ERROR",
                message="ネットワークエラーが発生しました。",
            ),
        )
    )
    has_pending, pending, redirect_url, error = (
        await check_pending_agreements_and_redirect_url(
            legal_client, "user-1"
        )
    )
    assert has_pending is False
    assert pending is None
    assert error is not None
    assert error.code == "NETWORK_ERROR"
    assert "ネットワーク" in error.message
