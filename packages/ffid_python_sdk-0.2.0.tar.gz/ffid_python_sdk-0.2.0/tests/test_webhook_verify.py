"""
Webhook Signature Verification Tests

署名検証の正常系・異常系テスト。
"""

from __future__ import annotations

import hashlib
import hmac
import json
import time

import pytest

from ffid_sdk.webhook_errors import (
    FFIDWebhookPayloadError,
    FFIDWebhookSignatureError,
    FFIDWebhookTimestampError,
)
from ffid_sdk.webhook_types import FFIDWebhookEvent
from ffid_sdk.webhook_verify import _parse_signature_header, verify_webhook_signature

# ---------------------------------------------------------------------------
# Test constants
# ---------------------------------------------------------------------------

TEST_SECRET = "whsec_test_secret_key_12345"
TEST_EVENT_PAYLOAD = {
    "id": "evt_001",
    "type": "subscription.created",
    "createdAt": "2024-06-01T00:00:00Z",
    "data": {
        "subscriptionId": "sub_123",
        "organizationId": "org_456",
        "plan": "pro",
        "status": "active",
    },
}


def _build_signature(secret: str, timestamp: int, body: str) -> str:
    """テスト用署名生成ヘルパー"""
    signed_content = f"{timestamp}.{body}"
    sig = hmac.new(
        secret.encode("utf-8"),
        signed_content.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()
    return f"t={timestamp},v1={sig}"


# ---------------------------------------------------------------------------
# _parse_signature_header tests
# ---------------------------------------------------------------------------


class TestParseSignatureHeader:
    """署名ヘッダーパーステスト"""

    def test_valid_header(self) -> None:
        """正常なヘッダーをパースできること"""
        timestamp, signature = _parse_signature_header("t=1234567890,v1=abcdef0123456789")
        assert timestamp == 1234567890
        assert signature == "abcdef0123456789"

    def test_missing_timestamp(self) -> None:
        """タイムスタンプがない場合にエラーを返すこと"""
        with pytest.raises(FFIDWebhookSignatureError):
            _parse_signature_header("v1=abcdef0123456789")

    def test_missing_signature(self) -> None:
        """署名がない場合にエラーを返すこと"""
        with pytest.raises(FFIDWebhookSignatureError):
            _parse_signature_header("t=1234567890")

    def test_invalid_timestamp(self) -> None:
        """タイムスタンプが数値でない場合にエラーを返すこと"""
        with pytest.raises(FFIDWebhookSignatureError):
            _parse_signature_header("t=not_a_number,v1=abcdef")

    def test_empty_header(self) -> None:
        """空のヘッダーでエラーを返すこと"""
        with pytest.raises(FFIDWebhookSignatureError):
            _parse_signature_header("")

    def test_completely_invalid_format(self) -> None:
        """不正なフォーマットでエラーを返すこと"""
        with pytest.raises(FFIDWebhookSignatureError):
            _parse_signature_header("garbage_data")


# ---------------------------------------------------------------------------
# verify_webhook_signature tests
# ---------------------------------------------------------------------------


class TestVerifyWebhookSignature:
    """署名検証テスト"""

    def test_verify_valid_signature(self) -> None:
        """正しい署名で検証が成功すること"""
        body = json.dumps(TEST_EVENT_PAYLOAD)
        timestamp = int(time.time())
        header = _build_signature(TEST_SECRET, timestamp, body)

        event = verify_webhook_signature(
            raw_body=body.encode("utf-8"),
            signature_header=header,
            secret=TEST_SECRET,
        )

        assert isinstance(event, FFIDWebhookEvent)
        assert event.id == "evt_001"
        assert event.type == "subscription.created"

    def test_verify_invalid_signature(self) -> None:
        """不正な署名でFFIDWebhookSignatureErrorが発生すること"""
        body = json.dumps(TEST_EVENT_PAYLOAD)
        timestamp = int(time.time())
        header = f"t={timestamp},v1=0000000000000000000000000000000000000000000000000000000000000000"

        with pytest.raises(FFIDWebhookSignatureError):
            verify_webhook_signature(
                raw_body=body.encode("utf-8"),
                signature_header=header,
                secret=TEST_SECRET,
            )

    def test_verify_wrong_secret(self) -> None:
        """異なるシークレットでFFIDWebhookSignatureErrorが発生すること"""
        body = json.dumps(TEST_EVENT_PAYLOAD)
        timestamp = int(time.time())
        header = _build_signature("wrong_secret", timestamp, body)

        with pytest.raises(FFIDWebhookSignatureError):
            verify_webhook_signature(
                raw_body=body.encode("utf-8"),
                signature_header=header,
                secret=TEST_SECRET,
            )

    def test_verify_expired_timestamp(self) -> None:
        """期限切れタイムスタンプでFFIDWebhookTimestampErrorが発生すること"""
        body = json.dumps(TEST_EVENT_PAYLOAD)
        old_timestamp = int(time.time()) - 600  # 10分前
        header = _build_signature(TEST_SECRET, old_timestamp, body)

        with pytest.raises(FFIDWebhookTimestampError):
            verify_webhook_signature(
                raw_body=body.encode("utf-8"),
                signature_header=header,
                secret=TEST_SECRET,
                tolerance_seconds=300,
            )

    def test_verify_custom_tolerance(self) -> None:
        """カスタム許容秒数で検証できること"""
        body = json.dumps(TEST_EVENT_PAYLOAD)
        old_timestamp = int(time.time()) - 400  # 6分40秒前
        header = _build_signature(TEST_SECRET, old_timestamp, body)

        # 5分の許容では失敗
        with pytest.raises(FFIDWebhookTimestampError):
            verify_webhook_signature(
                raw_body=body.encode("utf-8"),
                signature_header=header,
                secret=TEST_SECRET,
                tolerance_seconds=300,
            )

        # 10分の許容では成功
        event = verify_webhook_signature(
            raw_body=body.encode("utf-8"),
            signature_header=header,
            secret=TEST_SECRET,
            tolerance_seconds=600,
        )
        assert event.id == "evt_001"

    def test_verify_returns_event_with_correct_fields(self) -> None:
        """検証成功時に正しいフィールドを持つFFIDWebhookEventを返すこと"""
        body = json.dumps(TEST_EVENT_PAYLOAD)
        timestamp = int(time.time())
        header = _build_signature(TEST_SECRET, timestamp, body)

        event = verify_webhook_signature(
            raw_body=body.encode("utf-8"),
            signature_header=header,
            secret=TEST_SECRET,
        )

        assert event.id == "evt_001"
        assert event.type == "subscription.created"
        assert event.created_at == "2024-06-01T00:00:00Z"
        assert event.data["subscriptionId"] == "sub_123"
        assert event.data["organizationId"] == "org_456"

    def test_verify_invalid_json_body(self) -> None:
        """不正なJSONボディでFFIDWebhookPayloadErrorが発生すること"""
        body = "not valid json"
        timestamp = int(time.time())
        header = _build_signature(TEST_SECRET, timestamp, body)

        with pytest.raises(FFIDWebhookPayloadError):
            verify_webhook_signature(
                raw_body=body.encode("utf-8"),
                signature_header=header,
                secret=TEST_SECRET,
            )

    def test_verify_missing_required_fields(self) -> None:
        """必須フィールドが欠けたJSONでFFIDWebhookPayloadErrorが発生すること"""
        body = json.dumps({"foo": "bar"})
        timestamp = int(time.time())
        header = _build_signature(TEST_SECRET, timestamp, body)

        with pytest.raises(FFIDWebhookPayloadError):
            verify_webhook_signature(
                raw_body=body.encode("utf-8"),
                signature_header=header,
                secret=TEST_SECRET,
            )

    def test_verify_future_timestamp_within_tolerance(self) -> None:
        """未来のタイムスタンプでも許容範囲内なら成功すること"""
        body = json.dumps(TEST_EVENT_PAYLOAD)
        future_timestamp = int(time.time()) + 100  # 100秒後
        header = _build_signature(TEST_SECRET, future_timestamp, body)

        event = verify_webhook_signature(
            raw_body=body.encode("utf-8"),
            signature_header=header,
            secret=TEST_SECRET,
        )
        assert event.id == "evt_001"

    def test_verify_future_timestamp_outside_tolerance(self) -> None:
        """未来のタイムスタンプで許容範囲外なら失敗すること"""
        body = json.dumps(TEST_EVENT_PAYLOAD)
        future_timestamp = int(time.time()) + 600  # 10分後
        header = _build_signature(TEST_SECRET, future_timestamp, body)

        with pytest.raises(FFIDWebhookTimestampError):
            verify_webhook_signature(
                raw_body=body.encode("utf-8"),
                signature_header=header,
                secret=TEST_SECRET,
                tolerance_seconds=300,
            )
