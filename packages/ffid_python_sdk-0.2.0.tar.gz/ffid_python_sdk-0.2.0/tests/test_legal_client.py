"""
FFID Legal Client Tests

FFIDLegalClient のテスト。respx で API をモック。
"""

from __future__ import annotations

import pytest
import respx

from ffid_sdk.legal import FFIDLegalClient, FFIDLegalClientConfig
from ffid_sdk.legal.errors import FFIDLegalMissingApiKeyError
from ffid_sdk.legal.types import (
    FFIDRecordAgreementRequest,
)

TEST_API_BASE = "https://legal-test.ffid.local"
TEST_API_KEY = "ffid_sk_test_abc123"


@pytest.fixture
def legal_config() -> FFIDLegalClientConfig:
    return FFIDLegalClientConfig(
        api_key=TEST_API_KEY,
        api_base_url=TEST_API_BASE,
        debug=False,
    )


@pytest.fixture
def legal_client(legal_config: FFIDLegalClientConfig) -> FFIDLegalClient:
    return FFIDLegalClient(legal_config)


class TestFFIDLegalClientInit:
    """初期化テスト"""

    def test_raises_when_api_key_empty(self) -> None:
        with pytest.raises(FFIDLegalMissingApiKeyError):
            FFIDLegalClient(FFIDLegalClientConfig(api_key=""))

    def test_raises_when_api_key_whitespace_only(self) -> None:
        with pytest.raises(FFIDLegalMissingApiKeyError):
            FFIDLegalClient(FFIDLegalClientConfig(api_key="   "))

    def test_creates_client_with_valid_config(
        self, legal_config: FFIDLegalClientConfig
    ) -> None:
        client = FFIDLegalClient(legal_config)
        assert client._config.api_key == TEST_API_KEY
        assert client._base_url == TEST_API_BASE


class TestFFIDLegalClientGetDocuments:
    """get_documents テスト"""

    @pytest.mark.asyncio
    @respx.mock
    async def test_returns_documents_on_success(
        self, legal_client: FFIDLegalClient
    ) -> None:
        respx.get(f"{TEST_API_BASE}/api/v1/legal/ext/documents").mock(
            return_value=respx.MockResponse(
                200,
                json={
                    "success": True,
                    "data": {
                        "documents": [
                            {
                                "id": "doc-1",
                                "type": "terms_of_service",
                                "title": "利用規約",
                                "version": "1.0",
                            }
                        ],
                        "count": 1,
                    },
                },
            )
        )
        data, err = await legal_client.get_documents()
        assert err is None
        assert data is not None
        assert data["count"] == 1
        assert len(data["documents"]) == 1
        assert data["documents"][0]["title"] == "利用規約"

    @pytest.mark.asyncio
    @respx.mock
    async def test_returns_error_on_server_error(
        self, legal_client: FFIDLegalClient
    ) -> None:
        respx.get(f"{TEST_API_BASE}/api/v1/legal/ext/documents").mock(
            return_value=respx.MockResponse(
                401,
                json={
                    "success": False,
                    "error": {
                        "code": "INVALID_API_KEY",
                        "message": "APIキーが無効です。",
                    },
                },
            )
        )
        data, err = await legal_client.get_documents()
        assert data is None
        assert err is not None
        assert err.code == "INVALID_API_KEY"
        assert "無効" in err.message


class TestFFIDLegalClientGetPendingAgreements:
    """get_pending_agreements テスト"""

    @pytest.mark.asyncio
    @respx.mock
    async def test_returns_pending_on_success(
        self, legal_client: FFIDLegalClient
    ) -> None:
        respx.get(
            f"{TEST_API_BASE}/api/v1/legal/ext/agreements/pending",
            params={"externalUserId": "user-123"},
        ).mock(
            return_value=respx.MockResponse(
                200,
                json={
                    "success": True,
                    "data": {
                        "pendingDocuments": [],
                        "count": 0,
                        "hasPending": False,
                    },
                },
            )
        )
        result, err = await legal_client.get_pending_agreements("user-123")
        assert err is None
        assert result is not None
        assert result.has_pending is False
        assert result.count == 0

    @pytest.mark.asyncio
    async def test_returns_error_when_external_user_id_empty(
        self, legal_client: FFIDLegalClient
    ) -> None:
        result, err = await legal_client.get_pending_agreements("")
        assert result is None
        assert err is not None
        assert err.code == "VALIDATION_ERROR"
        assert "必須" in err.message


class TestFFIDLegalClientGetDocument:
    """get_document テスト"""

    @pytest.mark.asyncio
    @respx.mock
    async def test_returns_document_on_success(
        self, legal_client: FFIDLegalClient
    ) -> None:
        respx.get(
            f"{TEST_API_BASE}/api/v1/legal/ext/documents/doc-uuid-1"
        ).mock(
            return_value=respx.MockResponse(
                200,
                json={
                    "success": True,
                    "data": {
                        "document": {
                            "id": "doc-uuid-1",
                            "type": "terms_of_service",
                            "title": "利用規約",
                            "version": "1.0",
                            "content": "# 利用規約",
                        }
                    },
                },
            )
        )
        data, err = await legal_client.get_document("doc-uuid-1")
        assert err is None
        assert data is not None
        assert "document" in data
        assert data["document"]["title"] == "利用規約"

    @pytest.mark.asyncio
    @respx.mock
    async def test_returns_error_on_document_not_found(
        self, legal_client: FFIDLegalClient
    ) -> None:
        respx.get(
            f"{TEST_API_BASE}/api/v1/legal/ext/documents/nonexistent"
        ).mock(
            return_value=respx.MockResponse(
                404,
                json={
                    "success": False,
                    "error": {
                        "code": "DOCUMENT_NOT_FOUND",
                        "message": "文書が見つかりません。",
                    },
                },
            )
        )
        data, err = await legal_client.get_document("nonexistent")
        assert data is None
        assert err is not None
        assert err.code == "DOCUMENT_NOT_FOUND"

    @pytest.mark.asyncio
    async def test_returns_error_when_document_id_empty(
        self, legal_client: FFIDLegalClient
    ) -> None:
        data, err = await legal_client.get_document("")
        assert data is None
        assert err is not None
        assert err.code == "VALIDATION_ERROR"


class TestFFIDLegalClientCheckAgreement:
    """check_agreement テスト"""

    @pytest.mark.asyncio
    @respx.mock
    async def test_returns_has_agreed_true_on_success(
        self, legal_client: FFIDLegalClient
    ) -> None:
        respx.get(
            f"{TEST_API_BASE}/api/v1/legal/ext/agreements/check",
            params={"externalUserId": "user-1", "documentId": "doc-1"},
        ).mock(
            return_value=respx.MockResponse(
                200,
                json={
                    "success": True,
                    "data": {
                        "hasAgreed": True,
                        "agreement": {
                            "id": "agr-1",
                            "serviceId": "svc-1",
                            "externalUserId": "user-1",
                            "documentId": "doc-1",
                            "agreedAt": "2024-01-01T00:00:00Z",
                            "agreementMethod": "click_through",
                            "documentVersion": "1.0",
                            "documentTitle": "利用規約",
                            "documentHash": "abc",
                            "createdAt": "2024-01-01T00:00:00Z",
                        },
                    },
                },
            )
        )
        result, err = await legal_client.check_agreement("user-1", "doc-1")
        assert err is None
        assert result is not None
        assert result.has_agreed is True
        assert result.agreement is not None
        assert result.agreement.document_id == "doc-1"

    @pytest.mark.asyncio
    @respx.mock
    async def test_returns_has_agreed_false_when_not_agreed(
        self, legal_client: FFIDLegalClient
    ) -> None:
        respx.get(
            f"{TEST_API_BASE}/api/v1/legal/ext/agreements/check",
            params={"externalUserId": "user-2", "documentId": "doc-2"},
        ).mock(
            return_value=respx.MockResponse(
                200,
                json={
                    "success": True,
                    "data": {
                        "hasAgreed": False,
                        "agreement": None,
                    },
                },
            )
        )
        result, err = await legal_client.check_agreement("user-2", "doc-2")
        assert err is None
        assert result is not None
        assert result.has_agreed is False

    @pytest.mark.asyncio
    async def test_returns_error_when_params_empty(
        self, legal_client: FFIDLegalClient
    ) -> None:
        result, err = await legal_client.check_agreement("", "doc-1")
        assert result is None
        assert err is not None
        assert "必須" in err.message


class TestFFIDLegalClientRecordAgreement:
    """record_agreement バリデーションテスト"""

    @pytest.mark.asyncio
    async def test_returns_error_when_external_user_id_missing(
        self, legal_client: FFIDLegalClient
    ) -> None:
        req = FFIDRecordAgreementRequest(
            external_user_id="",
            document_id="doc-1",
        )
        result, err = await legal_client.record_agreement(req)
        assert result is None
        assert err is not None
        assert "必須" in err.message

    @pytest.mark.asyncio
    async def test_returns_error_when_document_id_missing(
        self, legal_client: FFIDLegalClient
    ) -> None:
        req = FFIDRecordAgreementRequest(
            external_user_id="user-1",
            document_id="",
        )
        result, err = await legal_client.record_agreement(req)
        assert result is None
        assert err is not None
