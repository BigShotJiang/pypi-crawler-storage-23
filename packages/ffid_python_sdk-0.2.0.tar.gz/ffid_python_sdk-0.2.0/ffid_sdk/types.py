"""
FFID SDK Type Definitions

Pydantic v2 モデル。TypeScript SDK の型定義に 1:1 対応。
snake_case ⇔ camelCase 変換は ``Field(alias=...)`` と ``populate_by_name=True`` で対応。
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Dict, Generic, List, Optional, TypeVar

from pydantic import BaseModel, ConfigDict, Field, model_validator

from ffid_sdk.constants import DEFAULT_API_BASE_URL, DEFAULT_MAX_RETRIES, DEFAULT_TIMEOUT_SECONDS


# ---------------------------------------------------------------------------
# Enum definitions
# ---------------------------------------------------------------------------


class OrganizationRole(str, Enum):
    """組織内ロール（TypeScript: 'owner' | 'admin' | 'member'）"""

    OWNER = "owner"
    ADMIN = "admin"
    MEMBER = "member"


class MembershipStatus(str, Enum):
    """メンバーシップステータス（TypeScript: 'active' | 'invited' | 'suspended'）"""

    ACTIVE = "active"
    INVITED = "invited"
    SUSPENDED = "suspended"


class SubscriptionStatus(str, Enum):
    """契約ステータス（TypeScript: 'trialing' | 'active' | ...）"""

    TRIALING = "trialing"
    ACTIVE = "active"
    PAST_DUE = "past_due"
    CANCELED = "canceled"
    PAUSED = "paused"


# ---------------------------------------------------------------------------
# Pydantic base config
# ---------------------------------------------------------------------------

_CAMEL_CASE_CONFIG = ConfigDict(
    # Accept both snake_case (field name) and camelCase (alias) from input
    populate_by_name=True,
    # Allow construction from ORM/dataclass attributes
    from_attributes=True,
)


# ---------------------------------------------------------------------------
# Core models (mirrors TypeScript SDK types)
# ---------------------------------------------------------------------------


class FFIDUser(BaseModel):
    """ユーザー情報（TypeScript: FFIDUser）"""

    model_config = _CAMEL_CASE_CONFIG

    id: str
    email: str
    display_name: Optional[str] = Field(default=None, alias="displayName")
    avatar_url: Optional[str] = Field(default=None, alias="avatarUrl")
    locale: Optional[str] = None
    timezone: Optional[str] = None
    created_at: datetime = Field(alias="createdAt")


class FFIDAgencyBranding(BaseModel):
    """代理店ブランディング情報（TypeScript: FFIDAgencyBranding）

    組織が代理店に紐づいている場合に含まれる。
    ホワイトラベルでのブランド適用に使用。
    """

    model_config = _CAMEL_CASE_CONFIG

    agency_id: str = Field(alias="agencyId")
    agency_name: str = Field(alias="agencyName")
    logo_url: Optional[str] = Field(default=None, alias="logoUrl")
    favicon_url: Optional[str] = Field(default=None, alias="faviconUrl")
    primary_color: Optional[str] = Field(default=None, alias="primaryColor")
    secondary_color: Optional[str] = Field(default=None, alias="secondaryColor")
    company_name: Optional[str] = Field(default=None, alias="companyName")


class FFIDOrganization(BaseModel):
    """組織情報（TypeScript: FFIDOrganization）"""

    model_config = _CAMEL_CASE_CONFIG

    id: str
    name: str
    slug: str
    role: OrganizationRole
    status: MembershipStatus
    agency_branding: Optional[FFIDAgencyBranding] = Field(
        default=None, alias="agencyBranding"
    )


class FFIDSubscription(BaseModel):
    """契約情報（TypeScript: FFIDSubscription）"""

    model_config = _CAMEL_CASE_CONFIG

    id: str
    service_code: str = Field(alias="serviceCode")
    service_name: str = Field(alias="serviceName")
    plan_code: str = Field(alias="planCode")
    plan_name: str = Field(alias="planName")
    status: SubscriptionStatus
    current_period_end: Optional[datetime] = Field(default=None, alias="currentPeriodEnd")


class FFIDSessionResponse(BaseModel):
    """セッション取得APIレスポンス（TypeScript: FFIDSessionResponse）"""

    model_config = _CAMEL_CASE_CONFIG

    user: FFIDUser
    organizations: List[FFIDOrganization]
    subscriptions: List[FFIDSubscription]


class FFIDError(BaseModel):
    """エラーオブジェクト（TypeScript: FFIDError）"""

    code: str
    message: str
    details: Optional[Dict[str, Any]] = None


class FFIDTokenResponse(BaseModel):
    """トークンリフレッシュAPIレスポンス（TypeScript: AuthSession のトークン部分）"""

    model_config = _CAMEL_CASE_CONFIG

    access_token: str = Field(alias="accessToken")
    expires_in: int = Field(alias="expiresIn")
    refresh_token: Optional[str] = Field(default=None, alias="refreshToken")
    expires_at: Optional[int] = Field(default=None, alias="expiresAt")


# ---------------------------------------------------------------------------
# API Response wrapper (discriminated union pattern)
# ---------------------------------------------------------------------------

T = TypeVar("T")


class FFIDApiResponse(BaseModel, Generic[T]):
    """API レスポンスラッパー（TypeScript: FFIDApiResponse<T>）

    成功時は ``data`` に値が設定され、失敗時は ``error`` に値が設定される。
    TypeScript版の discriminated union パターンに準拠。

    Example:
        ```python
        response = await client.get_session(token)
        if response.is_success:
            print(response.data.user.email)
        else:
            print(response.error.message)
        ```
    """

    data: Optional[T] = None
    error: Optional[FFIDError] = None

    @model_validator(mode="after")
    def _check_data_error_exclusive(self) -> FFIDApiResponse[T]:
        if self.data is not None and self.error is not None:
            raise ValueError("data と error は同時に設定できません")
        return self

    @property
    def is_success(self) -> bool:
        """レスポンスが成功かどうか

        エラーが存在しないことで判定。sign_out のような data=None の
        成功レスポンスにも対応。
        """
        return self.error is None


# ---------------------------------------------------------------------------
# SDK Configuration
# ---------------------------------------------------------------------------


class FFIDConfig(BaseModel):
    """SDK設定（TypeScript: FFIDConfig のサーバーサイド版）

    Attributes:
        service_code: サービス識別コード（例: 'chatbot'）
        api_base_url: FFID API のベースURL
        debug: デバッグログ有効化
        timeout_seconds: HTTPタイムアウト（秒）
        max_retries: リトライ回数
    """

    service_code: str
    api_base_url: str = DEFAULT_API_BASE_URL
    debug: bool = False
    timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS
    max_retries: int = DEFAULT_MAX_RETRIES


# ---------------------------------------------------------------------------
# FFID Context (request-scoped, set by middleware)
# ---------------------------------------------------------------------------


class FFIDContext(BaseModel):
    """リクエストスコープの認証コンテキスト

    ミドルウェアがリクエストごとに生成し、``request.state.ffid_context`` に格納。
    FastAPI の ``Depends()`` でエンドポイントに注入して使用。

    Attributes:
        user: 認証済みユーザー情報
        organizations: ユーザーの所属組織一覧
        subscriptions: ユーザーの契約一覧
        current_organization: 現在選択中の組織（未選択時はNone）
        access_token: アクセストークン（リフレッシュ等で利用）
    """

    model_config = ConfigDict(frozen=True)

    user: FFIDUser
    organizations: List[FFIDOrganization]
    subscriptions: List[FFIDSubscription]
    current_organization: Optional[FFIDOrganization] = None
    access_token: str

    @property
    def active_subscription(self) -> Optional[FFIDSubscription]:
        """有効な契約を取得（active > trialing > その他の優先順位）"""
        active = [s for s in self.subscriptions if s.status == SubscriptionStatus.ACTIVE]
        if active:
            return active[0]

        trialing = [s for s in self.subscriptions if s.status == SubscriptionStatus.TRIALING]
        if trialing:
            return trialing[0]

        return self.subscriptions[0] if self.subscriptions else None

    def has_subscription(self, service_code: str) -> bool:
        """指定サービスの有効な契約があるか"""
        return any(
            s.service_code == service_code
            and s.status in (SubscriptionStatus.ACTIVE, SubscriptionStatus.TRIALING)
            for s in self.subscriptions
        )

    def has_plan(self, plans: List[str], service_code: Optional[str] = None) -> bool:
        """指定プランのいずれかを持っているか"""
        for sub in self.subscriptions:
            if service_code and sub.service_code != service_code:
                continue
            if sub.status in (SubscriptionStatus.ACTIVE, SubscriptionStatus.TRIALING):
                if sub.plan_code in plans:
                    return True
        return False
