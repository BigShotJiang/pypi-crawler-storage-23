"""
FFID SDK Error Definitions

エラーコード定数と例外クラス階層。
TypeScript SDK の FFID_ERROR_CODES パターンに準拠。
"""

from __future__ import annotations

from enum import Enum
from typing import Any, Dict, Optional


class FFIDErrorCode(str, Enum):
    """FFID SDK エラーコード定数

    TypeScript SDK の ``FFID_ERROR_CODES`` に対応。
    """

    NETWORK_ERROR = "NETWORK_ERROR"
    """ネットワークリクエスト失敗（サーバー到達不可）"""

    PARSE_ERROR = "PARSE_ERROR"
    """サーバーレスポンスのJSONパース失敗"""

    UNKNOWN_ERROR = "UNKNOWN_ERROR"
    """不明なエラー"""

    AUTHENTICATION_ERROR = "AUTHENTICATION_ERROR"
    """認証エラー（トークン無効・未提供）"""

    AUTHORIZATION_ERROR = "AUTHORIZATION_ERROR"
    """認可エラー（権限不足）"""

    SUBSCRIPTION_REQUIRED = "SUBSCRIPTION_REQUIRED"
    """契約が必要"""

    VALIDATION_ERROR = "VALIDATION_ERROR"
    """入力バリデーションエラー"""

    TOKEN_EXPIRED = "TOKEN_EXPIRED"
    """トークン有効期限切れ"""

    SESSION_NOT_FOUND = "SESSION_NOT_FOUND"
    """セッションが見つからない"""


class FFIDSDKError(Exception):
    """FFID SDK 基底例外クラス

    全てのSDK固有例外はこのクラスを継承する。

    Attributes:
        code: エラーコード（FFIDErrorCode の値）
        message: ユーザー向けメッセージ（日本語）
        details: 追加のエラー情報
    """

    def __init__(
        self,
        code: str,
        message: str,
        details: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.code = code
        self.message = message
        self.details = details or {}
        super().__init__(message)

    def to_dict(self) -> Dict[str, Any]:
        """エラー情報を辞書に変換（APIレスポンス用）"""
        result: Dict[str, Any] = {
            "code": self.code,
            "message": self.message,
        }
        if self.details:
            result["details"] = self.details
        return result


class FFIDAuthenticationError(FFIDSDKError):
    """認証エラー（401相当）

    トークンが無効・未提供・期限切れの場合に発生。
    """

    def __init__(
        self,
        message: str = "認証に失敗しました。再度ログインしてください。",
        code: str = FFIDErrorCode.AUTHENTICATION_ERROR,
        details: Optional[Dict[str, Any]] = None,
    ) -> None:
        super().__init__(code=code, message=message, details=details)


class FFIDAuthorizationError(FFIDSDKError):
    """認可エラー（403相当）

    権限不足の場合に発生。
    """

    def __init__(
        self,
        message: str = "この操作を実行する権限がありません。",
        code: str = FFIDErrorCode.AUTHORIZATION_ERROR,
        details: Optional[Dict[str, Any]] = None,
    ) -> None:
        super().__init__(code=code, message=message, details=details)


class FFIDSubscriptionError(FFIDSDKError):
    """契約エラー

    有効な契約がない場合に発生。
    """

    def __init__(
        self,
        message: str = "この機能を利用するには有効な契約が必要です。",
        code: str = FFIDErrorCode.SUBSCRIPTION_REQUIRED,
        details: Optional[Dict[str, Any]] = None,
    ) -> None:
        super().__init__(code=code, message=message, details=details)


class FFIDNetworkError(FFIDSDKError):
    """ネットワークエラー

    FFID APIへの接続に失敗した場合に発生。
    """

    def __init__(
        self,
        message: str = "ネットワークエラーが発生しました。しばらく経ってから再度お試しください。",
        code: str = FFIDErrorCode.NETWORK_ERROR,
        details: Optional[Dict[str, Any]] = None,
    ) -> None:
        super().__init__(code=code, message=message, details=details)


class FFIDValidationError(FFIDSDKError):
    """バリデーションエラー

    入力パラメータが不正な場合に発生。
    """

    def __init__(
        self,
        message: str = "入力内容に誤りがあります。",
        code: str = FFIDErrorCode.VALIDATION_ERROR,
        details: Optional[Dict[str, Any]] = None,
    ) -> None:
        super().__init__(code=code, message=message, details=details)
