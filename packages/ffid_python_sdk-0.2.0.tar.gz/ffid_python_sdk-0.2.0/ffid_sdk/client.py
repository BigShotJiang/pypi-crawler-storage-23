"""
FFID API Client

FFID プラットフォームとの全API通信を担当するクライアント。
TypeScript SDK の ``createFFIDClient`` に対応するサーバーサイド版。

ブラウザの Cookie 認証ではなく、Bearer Token 認証を使用。

Example:
    ```python
    from ffid_sdk import FFIDClient, FFIDConfig

    client = FFIDClient(FFIDConfig(service_code="chatbot"))

    # セッション検証
    response = await client.get_session(token="eyJ...")
    if response.is_success:
        print(response.data.user.email)
    ```
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict, Optional

import httpx

from ffid_sdk.constants import (
    AUTHORIZATION_HEADER,
    BEARER_PREFIX,
    DEFAULT_API_BASE_URL,
    DEFAULT_MAX_RETRIES,
    DEFAULT_RETRY_BACKOFF_FACTOR,
    DEFAULT_TIMEOUT_SECONDS,
    NO_CONTENT_STATUS,
    REFRESH_ENDPOINT,
    SDK_LOGGER_NAME,
    SESSION_ENDPOINT,
    SIGNOUT_ENDPOINT,
    SUBSCRIPTIONS_CHECK_ENDPOINT,
)
from ffid_sdk.errors import FFIDErrorCode, FFIDNetworkError, FFIDSDKError
from ffid_sdk.types import (
    FFIDApiResponse,
    FFIDConfig,
    FFIDError,
    FFIDSessionResponse,
    FFIDSubscription,
    FFIDTokenResponse,
)

logger = logging.getLogger(SDK_LOGGER_NAME)

# デバッグログでマスクするセンシティブなキー（snake_case / camelCase）
_SENSITIVE_KEYS = frozenset({
    "access_token", "refresh_token", "accessToken", "refreshToken",
    "authorization",
})

# ログ用マスクプレースホルダー（センシティブ値を置換する文字列）
_MASK_PLACEHOLDER = "***"


def _sanitize_for_log(data: Dict[str, Any]) -> Dict[str, Any]:
    """ログ出力用にセンシティブデータをマスクした辞書を返す"""
    if not isinstance(data, dict):
        return data
    result: Dict[str, Any] = {}
    for key, value in data.items():
        if key in _SENSITIVE_KEYS:
            result[key] = _MASK_PLACEHOLDER
        elif isinstance(value, dict):
            result[key] = _sanitize_for_log(value)
        elif isinstance(value, list):
            result[key] = [
                _sanitize_for_log(item) if isinstance(item, dict) else item
                for item in value
            ]
        else:
            result[key] = value
    return result


class FFIDClient:
    """FFID API クライアント

    FFID プラットフォームのAPIを呼び出すための非同期HTTPクライアント。
    TypeScript SDK の ``createFFIDClient`` に対応。

    Args:
        config: SDK設定（``FFIDConfig`` インスタンス）

    Raises:
        FFIDValidationError: service_code が未設定の場合

    Example:
        ```python
        client = FFIDClient(FFIDConfig(service_code="chatbot"))
        response = await client.get_session(token)
        ```
    """

    def __init__(self, config: FFIDConfig) -> None:
        if not config.service_code or not config.service_code.strip():
            from ffid_sdk.errors import FFIDValidationError

            raise FFIDValidationError(
                message="service_code が未設定です",
                code=FFIDErrorCode.VALIDATION_ERROR,
            )

        self._config = config
        self._base_url = config.api_base_url if config.api_base_url is not None else DEFAULT_API_BASE_URL
        self._timeout = config.timeout_seconds if config.timeout_seconds is not None else DEFAULT_TIMEOUT_SECONDS
        self._max_retries = config.max_retries if config.max_retries is not None else DEFAULT_MAX_RETRIES
        self._backoff_factor = DEFAULT_RETRY_BACKOFF_FACTOR
        self._service_code = config.service_code

        if config.debug:
            logging.getLogger(SDK_LOGGER_NAME).setLevel(logging.DEBUG)

        logger.debug("FFIDClient initialized: base_url=%s, service_code=%s",
                      self._base_url, self._service_code)

    @property
    def base_url(self) -> str:
        """API ベースURL"""
        return self._base_url

    @property
    def service_code(self) -> str:
        """サービスコード"""
        return self._service_code

    # ------------------------------------------------------------------
    # Internal HTTP helpers
    # ------------------------------------------------------------------

    def _build_headers(self, token: str) -> Dict[str, str]:
        """認証ヘッダーを構築"""
        return {
            AUTHORIZATION_HEADER: f"{BEARER_PREFIX}{token}",
            "Content-Type": "application/json",
        }

    async def _request(
        self,
        method: str,
        endpoint: str,
        token: Optional[str] = None,
        *,
        json_body: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, str]] = None,
        headers_override: Optional[Dict[str, str]] = None,
    ) -> httpx.Response:
        """HTTP リクエストを実行（リトライ + 指数バックオフ付き）

        Args:
            method: HTTPメソッド（GET, POST等）
            endpoint: APIエンドポイントパス
            token: アクセストークン（headers_override未指定時に使用）
            json_body: リクエストボディ（JSON）
            params: クエリパラメータ
            headers_override: カスタムヘッダー（認証ヘッダー不要なリクエスト用）

        Raises:
            FFIDNetworkError: 全リトライ失敗時
        """
        url = f"{self._base_url}{endpoint}"
        headers = headers_override if headers_override is not None else self._build_headers(token or "")
        last_error: Optional[Exception] = None

        async with httpx.AsyncClient(timeout=self._timeout) as client:
            for attempt in range(self._max_retries):
                try:
                    logger.debug("Request [attempt %d/%d]: %s %s",
                                 attempt + 1, self._max_retries, method, url)

                    response = await client.request(
                        method=method,
                        url=url,
                        headers=headers,
                        json=json_body,
                        params=params,
                    )
                    return response

                except httpx.TimeoutException as exc:
                    last_error = exc
                    logger.warning("Request timeout [attempt %d/%d]: %s %s",
                                   attempt + 1, self._max_retries, method, url)
                except httpx.ConnectError as exc:
                    last_error = exc
                    logger.warning("Connection error [attempt %d/%d]: %s %s",
                                   attempt + 1, self._max_retries, method, url)

                # 指数バックオフ（最後の試行後は待機不要）
                if attempt < self._max_retries - 1:
                    backoff_seconds = self._backoff_factor * (2 ** attempt)
                    logger.debug("Retrying in %.1f seconds...", backoff_seconds)
                    await asyncio.sleep(backoff_seconds)

        raise FFIDNetworkError(
            message="ネットワークエラーが発生しました。しばらく経ってから再度お試しください。",
            details={"url": url, "error": str(last_error)},
        )

    async def _fetch_json(
        self,
        method: str,
        endpoint: str,
        token: Optional[str] = None,
        *,
        json_body: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, str]] = None,
        headers_override: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """JSON レスポンスを取得してパース

        Returns:
            パース済みJSONレスポンス

        Raises:
            FFIDNetworkError: ネットワークエラー
            FFIDSDKError: パースエラー
        """
        response = await self._request(
            method, endpoint, token,
            json_body=json_body, params=params,
            headers_override=headers_override,
        )

        if response.status_code == NO_CONTENT_STATUS:
            return {}

        try:
            data: Dict[str, Any] = response.json()
        except Exception as exc:
            logger.error("Parse error: status=%d, error=%s", response.status_code, exc)
            raise FFIDSDKError(
                code=FFIDErrorCode.PARSE_ERROR,
                message=f"サーバーから不正なレスポンスを受信しました (status: {response.status_code})",
            ) from exc

        logger.debug(
            "Response: status=%d, data=%s",
            response.status_code,
            _sanitize_for_log(data),
        )

        if response.status_code >= 400:
            error_data = data.get("error", {})
            raise FFIDSDKError(
                code=error_data.get("code", FFIDErrorCode.UNKNOWN_ERROR),
                message=error_data.get("message", "不明なエラーが発生しました"),
                details=error_data.get("details"),
            )

        return data

    # ------------------------------------------------------------------
    # Public API methods
    # ------------------------------------------------------------------

    async def get_session(self, token: str) -> FFIDApiResponse[FFIDSessionResponse]:
        """セッション情報を取得

        FFID API の ``GET /api/v1/auth/session`` を呼び出し、
        トークンに紐づくユーザー・組織・契約情報を取得する。

        Args:
            token: アクセストークン（Bearer Token）

        Returns:
            セッション情報を含むレスポンス
        """
        try:
            raw = await self._fetch_json("GET", SESSION_ENDPOINT, token)
            session_data = raw.get("data", raw)
            session = FFIDSessionResponse.model_validate(session_data)
            return FFIDApiResponse[FFIDSessionResponse](data=session)
        except FFIDSDKError as exc:
            return FFIDApiResponse[FFIDSessionResponse](
                error=FFIDError(code=exc.code, message=exc.message, details=exc.details)
            )
        except Exception as exc:
            logger.error("Unexpected error in get_session: %s", exc)
            return FFIDApiResponse[FFIDSessionResponse](
                error=FFIDError(
                    code=FFIDErrorCode.UNKNOWN_ERROR,
                    message="セッション情報の取得に失敗しました",
                )
            )

    async def refresh_token(self, refresh_token: str) -> FFIDApiResponse[FFIDTokenResponse]:
        """トークンをリフレッシュ

        リフレッシュトークンはリクエストボディのみに含める（セキュリティ対策）。
        Authorization ヘッダーには送信しない。

        Args:
            refresh_token: リフレッシュトークン

        Returns:
            新しいアクセストークンを含むレスポンス
        """
        try:
            raw = await self._fetch_json(
                "POST",
                REFRESH_ENDPOINT,
                None,
                json_body={"refresh_token": refresh_token},
                headers_override={"Content-Type": "application/json"},
            )
            data = raw.get("data", raw)
            token_response = FFIDTokenResponse.model_validate(data)
            return FFIDApiResponse[FFIDTokenResponse](data=token_response)
        except FFIDSDKError as exc:
            return FFIDApiResponse[FFIDTokenResponse](
                error=FFIDError(code=exc.code, message=exc.message, details=exc.details)
            )
        except Exception as exc:
            logger.error("Unexpected error in refresh_token: %s", exc)
            return FFIDApiResponse[FFIDTokenResponse](
                error=FFIDError(
                    code=FFIDErrorCode.UNKNOWN_ERROR,
                    message="トークンのリフレッシュに失敗しました",
                )
            )

    async def sign_out(self, token: str) -> FFIDApiResponse[None]:
        """サインアウト

        Args:
            token: アクセストークン

        Returns:
            成功時は data=None のレスポンス
        """
        try:
            await self._request("POST", SIGNOUT_ENDPOINT, token)
            return FFIDApiResponse[None](data=None)
        except FFIDSDKError as exc:
            return FFIDApiResponse[None](
                error=FFIDError(code=exc.code, message=exc.message, details=exc.details)
            )
        except Exception as exc:
            logger.error("Unexpected error in sign_out: %s", exc)
            return FFIDApiResponse[None](
                error=FFIDError(
                    code=FFIDErrorCode.UNKNOWN_ERROR,
                    message="サインアウトに失敗しました",
                )
            )

    async def check_subscription(
        self,
        token: str,
        service_code: Optional[str] = None,
    ) -> FFIDApiResponse[FFIDSubscription]:
        """契約状況をチェック

        Args:
            token: アクセストークン
            service_code: サービスコード（未指定時はクライアント設定値を使用）

        Returns:
            契約情報を含むレスポンス
        """
        svc = service_code or self._service_code
        try:
            raw = await self._fetch_json(
                "GET",
                SUBSCRIPTIONS_CHECK_ENDPOINT,
                token,
                params={"service_code": svc},
            )
            data = raw.get("data", raw)
            subscription = FFIDSubscription.model_validate(data)
            return FFIDApiResponse[FFIDSubscription](data=subscription)
        except FFIDSDKError as exc:
            return FFIDApiResponse[FFIDSubscription](
                error=FFIDError(code=exc.code, message=exc.message, details=exc.details)
            )
        except Exception as exc:
            logger.error("Unexpected error in check_subscription: %s", exc)
            return FFIDApiResponse[FFIDSubscription](
                error=FFIDError(
                    code=FFIDErrorCode.UNKNOWN_ERROR,
                    message="契約情報の取得に失敗しました",
                )
            )
