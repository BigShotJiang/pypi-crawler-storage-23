"""
FFID SDK Webhook Type Definitions

Pydantic v2 モデル。TypeScript SDK の webhook types に対応。
snake_case ⇔ camelCase 変換は ``Field(alias=...)`` と ``populate_by_name=True`` で対応。
"""

from __future__ import annotations

from enum import Enum
from typing import Any, Dict, Optional, Type

from pydantic import BaseModel, ConfigDict, Field


# ---------------------------------------------------------------------------
# Event type enum
# ---------------------------------------------------------------------------


class WebhookEventType(str, Enum):
    """Webhookイベントタイプ（TypeScript: WebhookEventType に対応）"""

    # Subscription events
    SUBSCRIPTION_CREATED = "subscription.created"
    SUBSCRIPTION_UPDATED = "subscription.updated"
    SUBSCRIPTION_CANCELED = "subscription.canceled"
    SUBSCRIPTION_TRIAL_ENDING = "subscription.trial_ending"
    SUBSCRIPTION_PAYMENT_FAILED = "subscription.payment_failed"

    # User events
    USER_CREATED = "user.created"
    USER_UPDATED = "user.updated"
    USER_DELETED = "user.deleted"
    USER_DELETION_REQUESTED = "user.deletion_requested"

    # Organization events
    ORGANIZATION_CREATED = "organization.created"
    ORGANIZATION_UPDATED = "organization.updated"
    ORGANIZATION_MEMBER_ADDED = "organization.member.added"
    ORGANIZATION_MEMBER_REMOVED = "organization.member.removed"
    ORGANIZATION_MEMBER_ROLE_CHANGED = "organization.member.role_changed"

    # Legal events
    LEGAL_DOCUMENT_UPDATED = "legal.document.updated"
    LEGAL_AGREEMENT_REQUIRED = "legal.agreement.required"

    # System events
    SYSTEM_MAINTENANCE_SCHEDULED = "system.maintenance.scheduled"
    SYSTEM_MAINTENANCE_STARTED = "system.maintenance.started"
    SYSTEM_MAINTENANCE_COMPLETED = "system.maintenance.completed"

    # Test events
    TEST_PING = "test.ping"


# ---------------------------------------------------------------------------
# Pydantic base config
# ---------------------------------------------------------------------------

_CAMEL_CASE_CONFIG = ConfigDict(
    populate_by_name=True,
    from_attributes=True,
)


# ---------------------------------------------------------------------------
# Event payload models
# ---------------------------------------------------------------------------


class FFIDSubscriptionPayload(BaseModel):
    """サブスクリプション系イベントペイロード"""

    model_config = _CAMEL_CASE_CONFIG

    subscription_id: str = Field(alias="subscriptionId")
    organization_id: Optional[str] = Field(default=None, alias="organizationId")
    plan: Optional[str] = None
    status: Optional[str] = None


class FFIDUserPayload(BaseModel):
    """ユーザー系イベントペイロード"""

    model_config = _CAMEL_CASE_CONFIG

    user_id: str = Field(alias="userId")
    email: Optional[str] = None
    display_name: Optional[str] = Field(default=None, alias="displayName")
    updated_fields: Optional[list[str]] = Field(default=None, alias="updatedFields")


class FFIDOrganizationPayload(BaseModel):
    """組織系イベントペイロード"""

    model_config = _CAMEL_CASE_CONFIG

    organization_id: str = Field(alias="organizationId")
    name: Optional[str] = None
    slug: Optional[str] = None
    updated_fields: Optional[list[str]] = Field(default=None, alias="updatedFields")


class FFIDOrganizationMemberPayload(BaseModel):
    """組織メンバー系イベントペイロード"""

    model_config = _CAMEL_CASE_CONFIG

    organization_id: str = Field(alias="organizationId")
    user_id: str = Field(alias="userId")
    role: Optional[str] = None
    previous_role: Optional[str] = Field(default=None, alias="previousRole")


class FFIDLegalDocumentPayload(BaseModel):
    """法的文書系イベントペイロード"""

    model_config = _CAMEL_CASE_CONFIG

    document_id: str = Field(alias="documentId")
    document_type: Optional[str] = Field(default=None, alias="documentType")
    version: Optional[str] = None


class FFIDMaintenancePayload(BaseModel):
    """システムメンテナンス系イベントペイロード"""

    model_config = _CAMEL_CASE_CONFIG

    maintenance_id: Optional[str] = Field(default=None, alias="maintenanceId")
    scheduled_at: Optional[str] = Field(default=None, alias="scheduledAt")
    estimated_duration: Optional[str] = Field(
        default=None, alias="estimatedDuration"
    )
    description: Optional[str] = None


class FFIDTestPingPayload(BaseModel):
    """テストPingイベントペイロード"""

    model_config = _CAMEL_CASE_CONFIG

    message: Optional[str] = None


# ---------------------------------------------------------------------------
# Event type → Payload class mapping
# ---------------------------------------------------------------------------

EVENT_TYPE_PAYLOAD_MAP: Dict[str, Type[BaseModel]] = {
    WebhookEventType.SUBSCRIPTION_CREATED: FFIDSubscriptionPayload,
    WebhookEventType.SUBSCRIPTION_UPDATED: FFIDSubscriptionPayload,
    WebhookEventType.SUBSCRIPTION_CANCELED: FFIDSubscriptionPayload,
    WebhookEventType.SUBSCRIPTION_TRIAL_ENDING: FFIDSubscriptionPayload,
    WebhookEventType.SUBSCRIPTION_PAYMENT_FAILED: FFIDSubscriptionPayload,
    WebhookEventType.USER_CREATED: FFIDUserPayload,
    WebhookEventType.USER_UPDATED: FFIDUserPayload,
    WebhookEventType.USER_DELETED: FFIDUserPayload,
    WebhookEventType.USER_DELETION_REQUESTED: FFIDUserPayload,
    WebhookEventType.ORGANIZATION_CREATED: FFIDOrganizationPayload,
    WebhookEventType.ORGANIZATION_UPDATED: FFIDOrganizationPayload,
    WebhookEventType.ORGANIZATION_MEMBER_ADDED: FFIDOrganizationMemberPayload,
    WebhookEventType.ORGANIZATION_MEMBER_REMOVED: FFIDOrganizationMemberPayload,
    WebhookEventType.ORGANIZATION_MEMBER_ROLE_CHANGED: FFIDOrganizationMemberPayload,
    WebhookEventType.LEGAL_DOCUMENT_UPDATED: FFIDLegalDocumentPayload,
    WebhookEventType.LEGAL_AGREEMENT_REQUIRED: FFIDLegalDocumentPayload,
    WebhookEventType.SYSTEM_MAINTENANCE_SCHEDULED: FFIDMaintenancePayload,
    WebhookEventType.SYSTEM_MAINTENANCE_STARTED: FFIDMaintenancePayload,
    WebhookEventType.SYSTEM_MAINTENANCE_COMPLETED: FFIDMaintenancePayload,
    WebhookEventType.TEST_PING: FFIDTestPingPayload,
}


# ---------------------------------------------------------------------------
# Webhook event envelope
# ---------------------------------------------------------------------------


class FFIDWebhookEvent(BaseModel):
    """Webhookイベントエンベロープ（TypeScript: WebhookEvent に対応）"""

    model_config = _CAMEL_CASE_CONFIG

    id: str
    type: str
    created_at: str = Field(alias="createdAt")
    data: Dict[str, Any] = Field(default_factory=dict)

    def get_typed_data(self, model_class: Type[BaseModel]) -> BaseModel:
        """ペイロードを型付きモデルに変換

        Example:
            ```python
            event = verify_webhook_signature(...)
            payload = event.get_typed_data(FFIDSubscriptionPayload)
            print(payload.subscription_id)
            ```
        """
        return model_class.model_validate(self.data)

    def get_auto_typed_data(self) -> Optional[BaseModel]:
        """イベントタイプに応じた型付きモデルに自動変換

        EVENT_TYPE_PAYLOAD_MAP に登録されたイベントタイプの場合、
        対応するモデルクラスで自動的にパースする。
        未登録のイベントタイプの場合は None を返す。
        """
        model_class = EVENT_TYPE_PAYLOAD_MAP.get(self.type)
        if model_class is None:
            return None
        return model_class.model_validate(self.data)
