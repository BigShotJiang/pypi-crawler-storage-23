"""
FFID Authentication Middleware for FastAPI

リクエストからアクセストークンを抽出し、FFID APIでセッションを検証して、
認証コンテキストを ``request.state.ffid_context`` に格納するミドルウェア。

Example:
    ```python
    from fastapi import FastAPI
    from ffid_sdk import FFIDMiddleware

    app = FastAPI()
    app.add_middleware(
        FFIDMiddleware,
        service_code="chatbot",
        # 認証不要パスを指定
        exclude_paths=["/health", "/docs", "/openapi.json"],
    )
    ```
"""

from __future__ import annotations

import logging
from collections.abc import Callable, Sequence

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.responses import JSONResponse
from starlette.status import HTTP_401_UNAUTHORIZED, HTTP_500_INTERNAL_SERVER_ERROR
from starlette.types import ASGIApp

from ffid_sdk.client import FFIDClient
from ffid_sdk.constants import (
    AUTHORIZATION_HEADER,
    BEARER_PREFIX,
    REFRESH_COOKIE_NAME,
    SDK_LOGGER_NAME,
    SESSION_COOKIE_NAME,
)
from ffid_sdk.errors import FFIDAuthenticationError, FFIDErrorCode
from ffid_sdk.types import FFIDConfig, FFIDContext

logger = logging.getLogger(SDK_LOGGER_NAME)


class FFIDMiddleware(BaseHTTPMiddleware):
    """FastAPI 認証ミドルウェア

    各リクエストに対して:
    1. Authorization ヘッダーまたは Cookie からトークンを抽出
    2. FFID API でセッションを検証
    3. ``request.state.ffid_context`` に ``FFIDContext`` を格納

    Args:
        app: FastAPI/Starlette アプリケーション
        service_code: サービス識別コード
        api_base_url: FFID API のベースURL（省略時はデフォルト）
        debug: デバッグモード
        exclude_paths: 認証をスキップするパスのリスト
        exclude_path_prefixes: 認証をスキップするパスプレフィックスのリスト
        on_auth_error: 認証エラー時のカスタムハンドラー
        auto_refresh: True の場合、セッション失敗時に refresh Cookie からリフレッシュして再試行
    """

    def __init__(
        self,
        app: ASGIApp,
        *,
        service_code: str,
        api_base_url: str | None = None,
        debug: bool = False,
        exclude_paths: Sequence[str] | None = None,
        exclude_path_prefixes: Sequence[str] | None = None,
        on_auth_error: Callable[[Request, FFIDAuthenticationError], Response] | None = None,
        auto_refresh: bool = False,
    ) -> None:
        config_kwargs = {"service_code": service_code, "debug": debug}
        if api_base_url is not None:
            config_kwargs["api_base_url"] = api_base_url

        self._client = FFIDClient(FFIDConfig(**config_kwargs))
        self._exclude_paths: list[str] = list(exclude_paths or [])
        self._exclude_path_prefixes: list[str] = list(exclude_path_prefixes or [])
        self._on_auth_error = on_auth_error
        self._auto_refresh = auto_refresh

        super().__init__(app)

    def _is_excluded(self, path: str) -> bool:
        """パスが認証除外対象かどうか"""
        if path in self._exclude_paths:
            return True
        return any(path.startswith(prefix) for prefix in self._exclude_path_prefixes)

    def _extract_token(self, request: Request) -> str | None:
        """リクエストからアクセストークンを抽出

        優先順位:
        1. Authorization: Bearer <token> ヘッダー
        2. ffid_session Cookie
        """
        # 1. Authorization header
        auth_header = request.headers.get(AUTHORIZATION_HEADER)
        if auth_header and auth_header.startswith(BEARER_PREFIX):
            token = auth_header[len(BEARER_PREFIX):]
            if token.strip():
                return token.strip()

        # 2. Session cookie
        cookie_token = request.cookies.get(SESSION_COOKIE_NAME)
        if cookie_token and cookie_token.strip():
            return cookie_token.strip()

        return None

    def _extract_refresh_token(self, request: Request) -> str | None:
        """リフレッシュトークンを Cookie から取得（auto_refresh 用）"""
        raw = request.cookies.get(REFRESH_COOKIE_NAME)
        if raw and raw.strip():
            return raw.strip()
        return None

    async def _try_refresh_and_set_context(
        self, request: Request, refresh_token: str
    ) -> bool:
        """リフレッシュトークンで再取得し、request.state.ffid_context を設定する。

        成功時は True、失敗時は False を返す。
        """
        refresh_response = await self._client.refresh_token(refresh_token)
        if not refresh_response.is_success or not refresh_response.data:
            return False
        new_token = refresh_response.data.access_token
        retry_response = await self._client.get_session(new_token)
        if not retry_response.is_success or not retry_response.data:
            return False
        session = retry_response.data
        request.state.ffid_context = FFIDContext(
            user=session.user,
            organizations=session.organizations,
            subscriptions=session.subscriptions,
            access_token=new_token,
        )
        logger.debug(
            "Authenticated after refresh: user=%s",
            session.user.email,
        )
        return True

    def _create_error_response(
        self,
        request: Request,
        error: FFIDAuthenticationError,
    ) -> Response:
        """認証エラーレスポンスを生成"""
        if self._on_auth_error:
            return self._on_auth_error(request, error)

        return JSONResponse(
            status_code=HTTP_401_UNAUTHORIZED,
            content={
                "error": {
                    "code": error.code,
                    "message": error.message,
                }
            },
        )

    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        """リクエストを処理"""
        # 除外パスはスキップ
        if self._is_excluded(request.url.path):
            return await call_next(request)

        # トークン抽出
        token = self._extract_token(request)
        if not token:
            logger.debug("No token found for path: %s", request.url.path)
            auth_error = FFIDAuthenticationError(
                message="認証トークンが見つかりません。ログインしてください。",
                code=FFIDErrorCode.AUTHENTICATION_ERROR,
            )
            return self._create_error_response(request, auth_error)

        # セッション検証（失敗時は auto_refresh でリフレッシュ試行）
        try:
            response = await self._client.get_session(token)

            if not response.is_success or response.data is None:
                if (
                    self._auto_refresh
                    and (refresh_token := self._extract_refresh_token(request))
                    and await self._try_refresh_and_set_context(request, refresh_token)
                ):
                    return await call_next(request)

                error_msg = "セッションの検証に失敗しました。"
                if response.error:
                    error_msg = response.error.message
                auth_error = FFIDAuthenticationError(
                    message=error_msg,
                    code=FFIDErrorCode.AUTHENTICATION_ERROR,
                )
                return self._create_error_response(request, auth_error)

            # コンテキストを構築して request.state に格納
            session = response.data
            context = FFIDContext(
                user=session.user,
                organizations=session.organizations,
                subscriptions=session.subscriptions,
                access_token=token,
            )
            request.state.ffid_context = context

            logger.debug(
                "Authenticated: user=%s, orgs=%d, subs=%d",
                session.user.email,
                len(session.organizations),
                len(session.subscriptions),
            )

        except FFIDAuthenticationError as exc:
            return self._create_error_response(request, exc)
        except Exception as exc:
            logger.error("Unexpected error during authentication: %s", exc)
            return JSONResponse(
                status_code=HTTP_500_INTERNAL_SERVER_ERROR,
                content={
                    "error": {
                        "code": FFIDErrorCode.UNKNOWN_ERROR,
                        "message": "認証処理中にエラーが発生しました。",
                    }
                },
            )

        return await call_next(request)
