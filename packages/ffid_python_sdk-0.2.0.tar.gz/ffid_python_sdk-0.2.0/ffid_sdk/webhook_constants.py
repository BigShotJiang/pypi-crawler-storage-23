"""
FFID SDK Webhook Constants

Webhook署名検証で使用される定数。TypeScript SDK の constants.ts に対応。
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# HTTP Headers
# ---------------------------------------------------------------------------

FFID_WEBHOOK_SIGNATURE_HEADER = "X-FFID-Signature"
"""Webhook署名ヘッダー名"""

FFID_WEBHOOK_TIMESTAMP_HEADER = "X-FFID-Timestamp"
"""Webhookタイムスタンプヘッダー名"""

FFID_WEBHOOK_EVENT_ID_HEADER = "X-FFID-Event-ID"
"""WebhookイベントIDヘッダー名"""

# ---------------------------------------------------------------------------
# Signature
# ---------------------------------------------------------------------------

FFID_WEBHOOK_SIGNATURE_VERSION = "v1"
"""署名バージョン"""

# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------

DEFAULT_TOLERANCE_SECONDS = 300
"""タイムスタンプ許容秒数（5分）"""
