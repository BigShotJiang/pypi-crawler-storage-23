"""
FFID SDK Webhook Signature Verification

HMAC-SHA256 署名検証。TypeScript SDK の verify.ts に対応。
署名フォーマット: ``t={timestamp},v1={hex_hmac}``
"""

from __future__ import annotations

import hashlib
import hmac
import json
import time
from typing import Optional, Tuple

from ffid_sdk.webhook_constants import DEFAULT_TOLERANCE_SECONDS
from ffid_sdk.webhook_errors import (
    FFIDWebhookPayloadError,
    FFIDWebhookSignatureError,
    FFIDWebhookTimestampError,
)
from ffid_sdk.webhook_types import FFIDWebhookEvent


def _parse_signature_header(header: str) -> Tuple[int, str]:
    """署名ヘッダーをパース

    Args:
        header: "t={timestamp},v1={hex_hmac}" 形式のヘッダー値

    Returns:
        (timestamp, signature) のタプル

    Raises:
        FFIDWebhookSignatureError: ヘッダーフォーマットが不正な場合
    """
    timestamp: Optional[int] = None
    signature: Optional[str] = None

    for part in header.split(","):
        key_value = part.split("=", 1)
        if len(key_value) != 2:
            continue
        key, value = key_value
        if key == "t" and value:
            try:
                timestamp = int(value)
            except ValueError:
                raise FFIDWebhookSignatureError(
                    message="署名ヘッダーのタイムスタンプが不正です",
                    details={"header": header},
                )
        elif key == "v1" and value:
            signature = value

    if timestamp is None or signature is None:
        raise FFIDWebhookSignatureError(
            message="署名ヘッダーのフォーマットが不正です（t=...,v1=... が必要）",
            details={"header": header},
        )

    return timestamp, signature


def verify_webhook_signature(
    raw_body: bytes,
    signature_header: str,
    secret: str,
    tolerance_seconds: Optional[int] = None,
) -> FFIDWebhookEvent:
    """Webhook署名を検証してイベントを返す

    TypeScript SDK の verifyWebhookSignature + isTimestampValid + parseSignatureHeader
    を1つの関数にまとめたもの。

    Args:
        raw_body: リクエストボディ（bytes）
        signature_header: X-FFID-Signature ヘッダー値
        secret: Webhookエンドポイントシークレット
        tolerance_seconds: タイムスタンプ許容秒数（デフォルト: 300秒 = 5分）

    Returns:
        検証済み FFIDWebhookEvent

    Raises:
        FFIDWebhookSignatureError: 署名が不正な場合
        FFIDWebhookTimestampError: タイムスタンプが期限切れの場合
        FFIDWebhookPayloadError: ボディのJSONパースに失敗した場合
    """
    if tolerance_seconds is None:
        tolerance_seconds = DEFAULT_TOLERANCE_SECONDS

    # 1. Parse signature header
    timestamp, signature = _parse_signature_header(signature_header)

    # 2. Verify timestamp tolerance
    now = int(time.time())
    if abs(now - timestamp) > tolerance_seconds:
        raise FFIDWebhookTimestampError(
            details={
                "timestamp": timestamp,
                "now": now,
                "tolerance_seconds": tolerance_seconds,
            },
        )

    # 3. Compute expected signature: HMAC-SHA256(secret, "{timestamp}.{body}")
    body_str = raw_body.decode("utf-8")
    signed_content = f"{timestamp}.{body_str}"
    expected = hmac.new(
        secret.encode("utf-8"),
        signed_content.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()

    # 4. Timing-safe comparison
    if not hmac.compare_digest(signature, expected):
        raise FFIDWebhookSignatureError(
            details={"timestamp": timestamp},
        )

    # 5. Parse body JSON into FFIDWebhookEvent
    try:
        payload = json.loads(body_str)
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise FFIDWebhookPayloadError(
            details={"error": str(exc)},
        ) from exc

    try:
        return FFIDWebhookEvent.model_validate(payload)
    except Exception as exc:
        raise FFIDWebhookPayloadError(
            message="Webhookイベントのバリデーションに失敗しました",
            details={"error": str(exc)},
        ) from exc
