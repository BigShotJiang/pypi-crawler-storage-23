"""
FFID SDK Webhook Handler

デコレータベースのWebhookハンドラー。FastAPI APIRouter との統合を提供。

Example:
    ```python
    from ffid_sdk import WebhookHandler

    handler = WebhookHandler(secret="whsec_xxx")

    @handler.on("subscription.created")
    async def on_sub_created(event):
        print(f"New subscription: {event.data}")

    @handler.on_all()
    async def on_any(event):
        print(f"Event received: {event.type}")

    # FastAPI integration
    app.include_router(handler.router, prefix="/webhooks/ffid")
    ```
"""

from __future__ import annotations

import asyncio
import inspect
import logging
from typing import Callable, Dict, Optional, Set

from fastapi import APIRouter, Request
from starlette.responses import JSONResponse

from ffid_sdk.webhook_constants import FFID_WEBHOOK_SIGNATURE_HEADER
from ffid_sdk.webhook_errors import FFIDWebhookError
from ffid_sdk.webhook_types import FFIDWebhookEvent
from ffid_sdk.webhook_verify import verify_webhook_signature

logger = logging.getLogger("ffid_sdk.webhook")


class WebhookHandler:
    """FFID Webhook ハンドラー

    イベントタイプごとにハンドラーを登録し、署名検証 → ディスパッチを行う。
    FastAPI APIRouter として組み込み可能。

    Args:
        secret: Webhookエンドポイントシークレット
        tolerance_seconds: タイムスタンプ許容秒数（None でデフォルト5分）
        path: ルーターのエンドポイントパス（デフォルト: "/"）
    """

    def __init__(
        self,
        secret: str,
        tolerance_seconds: Optional[int] = None,
        path: str = "/",
    ) -> None:
        self._secret = secret
        self._tolerance_seconds = tolerance_seconds
        self._handlers: Dict[str, Set[Callable]] = {}
        self._all_handlers: Set[Callable] = set()
        self._path = path
        self._router = self._create_router()

    def on(self, event_type: str) -> Callable:
        """特定イベントタイプのハンドラーを登録するデコレータ

        Args:
            event_type: 対象イベントタイプ（例: "subscription.created"）

        Example:
            ```python
            @handler.on("subscription.created")
            async def handle_sub(event: FFIDWebhookEvent):
                ...
            ```
        """

        def decorator(func: Callable) -> Callable:
            if event_type not in self._handlers:
                self._handlers[event_type] = set()
            self._handlers[event_type].add(func)
            return func

        return decorator

    def on_all(self) -> Callable:
        """全イベントのハンドラーを登録するデコレータ

        Example:
            ```python
            @handler.on_all()
            async def handle_all(event: FFIDWebhookEvent):
                ...
            ```
        """

        def decorator(func: Callable) -> Callable:
            self._all_handlers.add(func)
            return func

        return decorator

    @property
    def router(self) -> APIRouter:
        """FastAPI APIRouter を取得"""
        return self._router

    async def handle_event(
        self,
        raw_body: bytes,
        signature_header: str,
    ) -> FFIDWebhookEvent:
        """署名を検証してハンドラーにディスパッチ

        Args:
            raw_body: リクエストボディ（bytes）
            signature_header: X-FFID-Signature ヘッダー値

        Returns:
            検証済み FFIDWebhookEvent

        Raises:
            FFIDWebhookError: 署名検証やペイロードパースに失敗した場合
        """
        event = verify_webhook_signature(
            raw_body=raw_body,
            signature_header=signature_header,
            secret=self._secret,
            tolerance_seconds=self._tolerance_seconds,
        )

        await self._dispatch(event)
        return event

    async def _dispatch(self, event: FFIDWebhookEvent) -> None:
        """登録済みハンドラーにイベントをディスパッチ"""
        handlers: list[Callable] = []

        # イベントタイプ固有のハンドラー
        if event.type in self._handlers:
            handlers.extend(self._handlers[event.type])

        # 全イベントハンドラー
        handlers.extend(self._all_handlers)

        for handler_func in handlers:
            try:
                if inspect.iscoroutinefunction(handler_func):
                    await handler_func(event)
                else:
                    # 同期ハンドラーも対応
                    loop = asyncio.get_running_loop()
                    await loop.run_in_executor(None, handler_func, event)
            except Exception:
                logger.exception(
                    "Webhook handler error in %s for event %s",
                    handler_func.__name__,
                    event.type,
                )

    def _create_router(self) -> APIRouter:
        """FastAPI APIRouter を生成"""
        router = APIRouter()

        @router.post(self._path)
        async def webhook_endpoint(request: Request) -> JSONResponse:
            raw_body = await request.body()
            signature = request.headers.get(FFID_WEBHOOK_SIGNATURE_HEADER, "")

            if not signature:
                return JSONResponse(
                    status_code=400,
                    content={
                        "error": {
                            "code": "WEBHOOK_SIGNATURE_ERROR",
                            "message": "署名ヘッダーがありません",
                        }
                    },
                )

            try:
                event = await self.handle_event(raw_body, signature)
                return JSONResponse(
                    status_code=200,
                    content={"received": True, "eventId": event.id},
                )
            except FFIDWebhookError as exc:
                logger.warning(
                    "Webhook verification failed: %s (code=%s)",
                    exc.message,
                    exc.code,
                )
                return JSONResponse(
                    status_code=400,
                    content={"error": exc.to_dict()},
                )
            except Exception:
                logger.exception("Webhook handler error")
                return JSONResponse(
                    status_code=500,
                    content={
                        "error": {
                            "code": "WEBHOOK_HANDLER_ERROR",
                            "message": "Internal handler error",
                        }
                    },
                )

        return router
