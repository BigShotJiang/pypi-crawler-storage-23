"""
FFID SDK - FeelFlow ID Platform SDK for Python (FastAPI)

FastAPI アプリケーション向けの認証・認可・契約管理 SDK。

Quick Start:
    ```python
    from fastapi import FastAPI, Depends
    from ffid_sdk import FFIDMiddleware, FFIDContext, get_ffid_context, require_subscription

    app = FastAPI()
    app.add_middleware(FFIDMiddleware, service_code="chatbot")

    @app.get("/dashboard")
    async def dashboard(ctx: FFIDContext = Depends(get_ffid_context)):
        return {"user": ctx.user.email}

    @app.get("/premium")
    @require_subscription(plans=["pro", "enterprise"])
    async def premium(ctx: FFIDContext = Depends(get_ffid_context)):
        return {"plan": ctx.active_subscription.plan_code}
    ```
"""

from __future__ import annotations

# Client
from ffid_sdk.client import FFIDClient

# Constants
from ffid_sdk.constants import DEFAULT_API_BASE_URL

# Context & Dependencies
from ffid_sdk.context import get_ffid_context, require_ffid_auth

# Decorators
from ffid_sdk.decorators import require_subscription

# Errors
from ffid_sdk.errors import (
    FFIDAuthenticationError,
    FFIDAuthorizationError,
    FFIDErrorCode,
    FFIDNetworkError,
    FFIDSDKError,
    FFIDSubscriptionError,
    FFIDValidationError,
)

# Middleware
from ffid_sdk.middleware import FFIDMiddleware

# Types
from ffid_sdk.types import (
    FFIDAgencyBranding,
    FFIDApiResponse,
    FFIDConfig,
    FFIDContext,
    FFIDError,
    FFIDOrganization,
    FFIDSessionResponse,
    FFIDSubscription,
    FFIDTokenResponse,
    FFIDUser,
    MembershipStatus,
    OrganizationRole,
    SubscriptionStatus,
)

# Webhook - Constants
from ffid_sdk.webhook_constants import (
    DEFAULT_TOLERANCE_SECONDS,
    FFID_WEBHOOK_EVENT_ID_HEADER,
    FFID_WEBHOOK_SIGNATURE_HEADER,
    FFID_WEBHOOK_TIMESTAMP_HEADER,
)

# Webhook - Errors
from ffid_sdk.webhook_errors import (
    FFIDWebhookError,
    FFIDWebhookPayloadError,
    FFIDWebhookSignatureError,
    FFIDWebhookTimestampError,
)

# Webhook - Handler
from ffid_sdk.webhook_handler import WebhookHandler

# Webhook - Types
from ffid_sdk.webhook_types import (
    EVENT_TYPE_PAYLOAD_MAP,
    FFIDLegalDocumentPayload,
    FFIDMaintenancePayload,
    FFIDOrganizationMemberPayload,
    FFIDOrganizationPayload,
    FFIDSubscriptionPayload,
    FFIDTestPingPayload,
    FFIDUserPayload,
    FFIDWebhookEvent,
    WebhookEventType,
)

# Webhook - Verify
from ffid_sdk.webhook_verify import verify_webhook_signature

# Legal (Phase 2: 利用規約チェック・リダイレクト)
from ffid_sdk.legal import (
    FFIDLegalClient,
    FFIDLegalClientConfig,
    check_pending_agreements_and_redirect_url,
)

# Agency (代理店管理)
from ffid_sdk.agency import (
    FFIDAgencyClient,
    FFIDAgencyClientConfig,
)

__all__ = [
    # Client
    "FFIDClient",
    # Config & Constants
    "FFIDConfig",
    "DEFAULT_API_BASE_URL",
    # Context & Dependencies
    "FFIDContext",
    "get_ffid_context",
    "require_ffid_auth",
    # Decorators
    "require_subscription",
    # Errors
    "FFIDSDKError",
    "FFIDAuthenticationError",
    "FFIDAuthorizationError",
    "FFIDSubscriptionError",
    "FFIDNetworkError",
    "FFIDValidationError",
    "FFIDErrorCode",
    # Middleware
    "FFIDMiddleware",
    # Types
    "FFIDAgencyBranding",
    "FFIDUser",
    "FFIDOrganization",
    "FFIDSubscription",
    "FFIDSessionResponse",
    "FFIDTokenResponse",
    "FFIDError",
    "FFIDApiResponse",
    "OrganizationRole",
    "MembershipStatus",
    "SubscriptionStatus",
    # Webhook - Constants
    "FFID_WEBHOOK_SIGNATURE_HEADER",
    "FFID_WEBHOOK_TIMESTAMP_HEADER",
    "FFID_WEBHOOK_EVENT_ID_HEADER",
    "DEFAULT_TOLERANCE_SECONDS",
    # Webhook - Errors
    "FFIDWebhookError",
    "FFIDWebhookSignatureError",
    "FFIDWebhookTimestampError",
    "FFIDWebhookPayloadError",
    # Webhook - Handler
    "WebhookHandler",
    # Webhook - Types
    "FFIDWebhookEvent",
    "WebhookEventType",
    "FFIDSubscriptionPayload",
    "FFIDUserPayload",
    "FFIDOrganizationPayload",
    "FFIDOrganizationMemberPayload",
    "FFIDLegalDocumentPayload",
    "FFIDMaintenancePayload",
    "FFIDTestPingPayload",
    "EVENT_TYPE_PAYLOAD_MAP",
    # Webhook - Verify
    "verify_webhook_signature",
    # Legal
    "FFIDLegalClient",
    "FFIDLegalClientConfig",
    "check_pending_agreements_and_redirect_url",
    # Agency
    "FFIDAgencyClient",
    "FFIDAgencyClientConfig",
]

__version__ = "0.2.0"
