"""
FFID Agency API Client

代理店管理の API 通信。Bearer Token 認証。
TypeScript の createFFIDAgencyClient と同等の API を提供するが、
認証方式が異なる（TS: Cookie認証 / Python: Bearer Token認証）。
"""

from __future__ import annotations

import json
import logging
import urllib.parse
from typing import Any, TypeVar

import httpx
from pydantic import BaseModel, ValidationError

from ffid_sdk.constants import (
    AUTHORIZATION_HEADER,
    BEARER_PREFIX,
    DEFAULT_API_BASE_URL,
    DEFAULT_TIMEOUT_SECONDS,
    SDK_LOGGER_NAME,
)
from ffid_sdk.agency.errors import (
    FFIDAgencyMissingTokenError,
    FFIDAgencyNetworkError,
    FFIDAgencyParseError,
)
from ffid_sdk.agency.types import (
    FFIDAgency,
    FFIDAgencyBillingConfig,
    FFIDAgencyBillingOverride,
    FFIDAgencyBillingSummary,
    FFIDAgencyBrandingSettings,
    FFIDAgencyClientConfig,
    FFIDAgencyDomainSettings,
    FFIDAgencyEmailSettings,
    FFIDAgencyHierarchyResponse,
    FFIDAgencyInvoice,
    FFIDAgencyMember,
    FFIDAgencyMemberRole,
    FFIDAgencyOrganization,
    FFIDAgencyRevenue,
    FFIDAgencyServerError,
)

logger = logging.getLogger(SDK_LOGGER_NAME)

AGENCY_API_PREFIX = "/api/v1/agencies"

_T = TypeVar("_T", bound=BaseModel)


def _parse_agency_response(
    response: httpx.Response,
) -> tuple[dict[str, Any] | None, FFIDAgencyServerError | None]:
    """Agency API の success/data|error 形式をパースする"""
    try:
        body: dict[str, Any] = response.json()
    except (json.JSONDecodeError, ValueError) as exc:
        raise FFIDAgencyParseError(
            f"サーバーから不正なレスポンスを受信しました (status: {response.status_code})",
            details={"error": str(exc)},
        ) from exc
    success = body.get("success", False)
    if not response.is_success or not success:
        err = body.get("error", {})
        return None, FFIDAgencyServerError(
            code=err.get("code", "UNKNOWN_ERROR"),
            message=err.get("message", "不明なエラーが発生しました"),
            details=err.get("details"),
        )
    data = body.get("data")
    if data is None:
        return None, FFIDAgencyServerError(message="サーバーからデータが返されませんでした")
    return data, None


def _parse_model(
    model: type[_T],
    data: dict[str, Any] | None,
    key: str | None,
    error_message: str,
) -> _T:
    """レスポンスデータから Pydantic モデルをパースする共通ヘルパー

    key が None の場合は data 全体を model_validate に渡す（トップレベルモデル用）。
    key が指定された場合は data[key] を取得し、存在しなければ data 全体にフォールバックする。
    """
    try:
        raw = data.get(key, data) if data is not None and key is not None else data
        return model.model_validate(raw or {})
    except ValidationError as exc:
        raise FFIDAgencyParseError(
            error_message,
            details={"error": str(exc)},
        ) from exc


def _parse_model_list(
    model: type[_T],
    data: dict[str, Any] | None,
    key: str,
    error_message: str,
) -> list[_T]:
    """レスポンスデータから Pydantic モデルのリストをパースする共通ヘルパー"""
    try:
        items_raw = data.get(key, []) if data else []
        return [model.model_validate(item) for item in items_raw]
    except ValidationError as exc:
        raise FFIDAgencyParseError(
            error_message,
            details={"error": str(exc)},
        ) from exc


class FFIDAgencyClient:
    """FFID Agency API クライアント（Bearer Token 認証）"""

    def __init__(self, config: FFIDAgencyClientConfig) -> None:
        if not (config.access_token or "").strip():
            raise FFIDAgencyMissingTokenError()
        self._config = config
        self._base_url = (config.api_base_url or DEFAULT_API_BASE_URL).rstrip("/")
        self._timeout = DEFAULT_TIMEOUT_SECONDS
        self._prefix = AGENCY_API_PREFIX
        self._client = httpx.AsyncClient(timeout=self._timeout)
        if config.debug:
            logging.getLogger(SDK_LOGGER_NAME).setLevel(logging.DEBUG)
        logger.debug("FFIDAgencyClient initialized: base_url=%s", self._base_url)

    async def close(self) -> None:
        """HTTPクライアントを閉じる"""
        try:
            await self._client.aclose()
        except Exception:
            logger.warning("HTTPクライアントのクローズ中にエラーが発生しました", exc_info=True)

    async def __aenter__(self) -> FFIDAgencyClient:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    def _url(self, path: str) -> str:
        return f"{self._base_url}{self._prefix}{path}"

    def _headers(self) -> dict[str, str]:
        return {
            "Content-Type": "application/json",
            AUTHORIZATION_HEADER: f"{BEARER_PREFIX}{self._config.access_token}",
        }

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, str] | None = None,
        json_body: dict[str, Any] | None = None,
    ) -> tuple[dict[str, Any] | None, FFIDAgencyServerError | None]:
        if self._client.is_closed:
            raise FFIDAgencyNetworkError(
                "HTTPクライアントは既に閉じられています。新しいクライアントを作成してください。",
                details={"method": method, "path": path},
            )
        url = self._url(path)
        try:
            response = await self._client.request(
                method,
                url,
                headers=self._headers(),
                params=params,
                json=json_body,
            )
        except httpx.TimeoutException as exc:
            raise FFIDAgencyNetworkError(
                "リクエストがタイムアウトしました。しばらく経ってから再度お試しください。",
                details={"url": url, "error": str(exc)},
            ) from exc
        except httpx.TransportError as exc:
            raise FFIDAgencyNetworkError(
                "ネットワークエラーが発生しました。しばらく経ってから再度お試しください。",
                details={"url": url, "error": str(exc)},
            ) from exc
        return _parse_agency_response(response)

    @staticmethod
    def _encode(value: str) -> str:
        return urllib.parse.quote(value, safe="")

    # --- Agency CRUD ---

    async def get_agencies(
        self,
    ) -> tuple[dict[str, Any] | None, FFIDAgencyServerError | None]:
        """代理店一覧を取得"""
        return await self._request("GET", "")

    async def get_agency(
        self, agency_id: str
    ) -> tuple[FFIDAgency | None, FFIDAgencyServerError | None]:
        """代理店詳細を取得"""
        data, err = await self._request("GET", f"/{self._encode(agency_id)}")
        if err:
            return None, err
        return _parse_model(FFIDAgency, data, "agency", "代理店レスポンスの形式が不正です。"), None

    async def update_agency(
        self, agency_id: str, *, name: str | None = None, contact_email: str | None = None
    ) -> tuple[FFIDAgency | None, FFIDAgencyServerError | None]:
        """代理店情報を更新"""
        payload: dict[str, Any] = {}
        if name is not None:
            payload["name"] = name
        if contact_email is not None:
            payload["contactEmail"] = contact_email
        data, err = await self._request("PUT", f"/{self._encode(agency_id)}", json_body=payload)
        if err:
            return None, err
        return _parse_model(FFIDAgency, data, "agency", "代理店更新レスポンスの形式が不正です。"), None

    # --- Members ---

    async def get_members(
        self, agency_id: str
    ) -> tuple[list[FFIDAgencyMember] | None, FFIDAgencyServerError | None]:
        """メンバー一覧を取得"""
        data, err = await self._request("GET", f"/{self._encode(agency_id)}/members")
        if err:
            return None, err
        return _parse_model_list(FFIDAgencyMember, data, "members", "メンバー一覧レスポンスの形式が不正です。"), None

    async def add_member(
        self, agency_id: str, *, email: str, role: FFIDAgencyMemberRole | None = None
    ) -> tuple[FFIDAgencyMember | None, FFIDAgencyServerError | None]:
        """メンバーを追加"""
        payload: dict[str, Any] = {"email": email}
        if role is not None:
            payload["role"] = role
        data, err = await self._request("POST", f"/{self._encode(agency_id)}/members", json_body=payload)
        if err:
            return None, err
        return _parse_model(FFIDAgencyMember, data, "member", "メンバー追加レスポンスの形式が不正です。"), None

    async def update_member(
        self, agency_id: str, user_id: str, *, role: FFIDAgencyMemberRole
    ) -> tuple[FFIDAgencyMember | None, FFIDAgencyServerError | None]:
        """メンバーロールを更新"""
        data, err = await self._request(
            "PUT", f"/{self._encode(agency_id)}/members/{self._encode(user_id)}", json_body={"role": role}
        )
        if err:
            return None, err
        return _parse_model(FFIDAgencyMember, data, "member", "メンバー更新レスポンスの形式が不正です。"), None

    async def remove_member(
        self, agency_id: str, user_id: str
    ) -> tuple[dict[str, Any] | None, FFIDAgencyServerError | None]:
        """メンバーを削除"""
        return await self._request("DELETE", f"/{self._encode(agency_id)}/members/{self._encode(user_id)}")

    # --- Organizations ---

    async def get_organizations(
        self, agency_id: str
    ) -> tuple[list[FFIDAgencyOrganization] | None, FFIDAgencyServerError | None]:
        """紐づく組織一覧を取得"""
        data, err = await self._request("GET", f"/{self._encode(agency_id)}/organizations")
        if err:
            return None, err
        return _parse_model_list(FFIDAgencyOrganization, data, "organizations", "組織一覧レスポンスの形式が不正です。"), None

    async def link_organization(
        self,
        agency_id: str,
        *,
        organization_id: str,
        billing_override: FFIDAgencyBillingOverride | None = None,
        commission_rate: float | None = None,
        notes: str | None = None,
    ) -> tuple[FFIDAgencyOrganization | None, FFIDAgencyServerError | None]:
        """組織をリンク"""
        payload: dict[str, Any] = {"organizationId": organization_id}
        if billing_override is not None:
            payload["billingOverride"] = billing_override
        if commission_rate is not None:
            payload["commissionRate"] = commission_rate
        if notes is not None:
            payload["notes"] = notes
        data, err = await self._request("POST", f"/{self._encode(agency_id)}/organizations", json_body=payload)
        if err:
            return None, err
        return _parse_model(FFIDAgencyOrganization, data, "organization", "組織リンクレスポンスの形式が不正です。"), None

    async def unlink_organization(
        self, agency_id: str, org_id: str
    ) -> tuple[dict[str, Any] | None, FFIDAgencyServerError | None]:
        """組織リンクを解除"""
        return await self._request("DELETE", f"/{self._encode(agency_id)}/organizations/{self._encode(org_id)}")

    # --- Sub-Agencies ---

    async def get_sub_agencies(
        self, agency_id: str
    ) -> tuple[list[FFIDAgency] | None, FFIDAgencyServerError | None]:
        """サブ代理店一覧を取得"""
        data, err = await self._request("GET", f"/{self._encode(agency_id)}/sub-agencies")
        if err:
            return None, err
        return _parse_model_list(FFIDAgency, data, "agencies", "サブ代理店一覧レスポンスの形式が不正です。"), None

    async def create_sub_agency(
        self, agency_id: str, *, name: str, contact_email: str | None = None
    ) -> tuple[FFIDAgency | None, FFIDAgencyServerError | None]:
        """サブ代理店を作成"""
        payload: dict[str, Any] = {"name": name}
        if contact_email is not None:
            payload["contactEmail"] = contact_email
        data, err = await self._request("POST", f"/{self._encode(agency_id)}/sub-agencies", json_body=payload)
        if err:
            return None, err
        return _parse_model(FFIDAgency, data, "agency", "サブ代理店作成レスポンスの形式が不正です。"), None

    # --- Hierarchy ---

    async def get_hierarchy(
        self, agency_id: str
    ) -> tuple[FFIDAgencyHierarchyResponse | None, FFIDAgencyServerError | None]:
        """代理店階層を取得"""
        data, err = await self._request("GET", f"/{self._encode(agency_id)}/hierarchy")
        if err:
            return None, err
        return _parse_model(FFIDAgencyHierarchyResponse, data, None, "階層レスポンスの形式が不正です。"), None

    # --- Branding ---

    async def get_branding(
        self, agency_id: str
    ) -> tuple[FFIDAgencyBrandingSettings | None, FFIDAgencyServerError | None]:
        """ブランディング設定を取得"""
        data, err = await self._request("GET", f"/{self._encode(agency_id)}/branding")
        if err:
            return None, err
        return _parse_model(FFIDAgencyBrandingSettings, data, "branding", "ブランディングレスポンスの形式が不正です。"), None

    async def update_branding(
        self,
        agency_id: str,
        *,
        logo_url: str | None = None,
        favicon_url: str | None = None,
        primary_color: str | None = None,
        secondary_color: str | None = None,
        company_name: str | None = None,
    ) -> tuple[FFIDAgencyBrandingSettings | None, FFIDAgencyServerError | None]:
        """ブランディング設定を更新"""
        payload: dict[str, Any] = {}
        if logo_url is not None:
            payload["logoUrl"] = logo_url
        if favicon_url is not None:
            payload["faviconUrl"] = favicon_url
        if primary_color is not None:
            payload["primaryColor"] = primary_color
        if secondary_color is not None:
            payload["secondaryColor"] = secondary_color
        if company_name is not None:
            payload["companyName"] = company_name
        data, err = await self._request("PUT", f"/{self._encode(agency_id)}/branding", json_body=payload)
        if err:
            return None, err
        return _parse_model(FFIDAgencyBrandingSettings, data, "branding", "ブランディング更新レスポンスの形式が不正です。"), None

    # --- Domain ---

    async def get_domain(
        self, agency_id: str
    ) -> tuple[FFIDAgencyDomainSettings | None, FFIDAgencyServerError | None]:
        """ドメイン設定を取得"""
        data, err = await self._request("GET", f"/{self._encode(agency_id)}/domain")
        if err:
            return None, err
        return _parse_model(FFIDAgencyDomainSettings, data, "domain", "ドメインレスポンスの形式が不正です。"), None

    async def setup_domain(
        self, agency_id: str, custom_domain: str
    ) -> tuple[FFIDAgencyDomainSettings | None, FFIDAgencyServerError | None]:
        """ドメインをセットアップ"""
        data, err = await self._request(
            "POST", f"/{self._encode(agency_id)}/domain", json_body={"customDomain": custom_domain}
        )
        if err:
            return None, err
        return _parse_model(FFIDAgencyDomainSettings, data, "domain", "ドメインセットアップレスポンスの形式が不正です。"), None

    async def remove_domain(
        self, agency_id: str
    ) -> tuple[dict[str, Any] | None, FFIDAgencyServerError | None]:
        """ドメインを削除"""
        return await self._request("DELETE", f"/{self._encode(agency_id)}/domain")

    async def verify_domain(
        self, agency_id: str
    ) -> tuple[FFIDAgencyDomainSettings | None, FFIDAgencyServerError | None]:
        """ドメインを検証"""
        data, err = await self._request("POST", f"/{self._encode(agency_id)}/domain/verify")
        if err:
            return None, err
        return _parse_model(FFIDAgencyDomainSettings, data, "domain", "ドメイン検証レスポンスの形式が不正です。"), None

    # --- Email Settings ---

    async def get_email_settings(
        self, agency_id: str
    ) -> tuple[FFIDAgencyEmailSettings | None, FFIDAgencyServerError | None]:
        """メール設定を取得"""
        data, err = await self._request("GET", f"/{self._encode(agency_id)}/email-settings")
        if err:
            return None, err
        return _parse_model(FFIDAgencyEmailSettings, data, "emailSettings", "メール設定レスポンスの形式が不正です。"), None

    async def update_email_settings(
        self,
        agency_id: str,
        *,
        from_name: str | None = None,
        from_email: str | None = None,
        reply_to: str | None = None,
    ) -> tuple[FFIDAgencyEmailSettings | None, FFIDAgencyServerError | None]:
        """メール設定を更新"""
        payload: dict[str, Any] = {}
        if from_name is not None:
            payload["fromName"] = from_name
        if from_email is not None:
            payload["fromEmail"] = from_email
        if reply_to is not None:
            payload["replyTo"] = reply_to
        data, err = await self._request("PUT", f"/{self._encode(agency_id)}/email-settings", json_body=payload)
        if err:
            return None, err
        return _parse_model(FFIDAgencyEmailSettings, data, "emailSettings", "メール設定更新レスポンスの形式が不正です。"), None

    # --- Billing ---

    async def get_billing(
        self, agency_id: str
    ) -> tuple[FFIDAgencyBillingConfig | None, FFIDAgencyServerError | None]:
        """課金設定を取得"""
        data, err = await self._request("GET", f"/{self._encode(agency_id)}/billing")
        if err:
            return None, err
        return _parse_model(FFIDAgencyBillingConfig, data, "billing", "課金設定レスポンスの形式が不正です。"), None

    async def update_billing(
        self,
        agency_id: str,
        *,
        billing_type: str | None = None,
        invoice_email: str | None = None,
        payment_terms: int | None = None,
        default_markup_rate: float | None = None,
        default_markup_fixed: float | None = None,
    ) -> tuple[FFIDAgencyBillingConfig | None, FFIDAgencyServerError | None]:
        """課金設定を更新"""
        payload: dict[str, Any] = {}
        if billing_type is not None:
            payload["billingType"] = billing_type
        if invoice_email is not None:
            payload["invoiceEmail"] = invoice_email
        if payment_terms is not None:
            payload["paymentTerms"] = payment_terms
        if default_markup_rate is not None:
            payload["defaultMarkupRate"] = default_markup_rate
        if default_markup_fixed is not None:
            payload["defaultMarkupFixed"] = default_markup_fixed
        data, err = await self._request("PUT", f"/{self._encode(agency_id)}/billing", json_body=payload)
        if err:
            return None, err
        return _parse_model(FFIDAgencyBillingConfig, data, "billing", "課金設定更新レスポンスの形式が不正です。"), None

    async def get_billing_summary(
        self, agency_id: str
    ) -> tuple[FFIDAgencyBillingSummary | None, FFIDAgencyServerError | None]:
        """課金サマリーを取得"""
        data, err = await self._request("GET", f"/{self._encode(agency_id)}/billing-summary")
        if err:
            return None, err
        return _parse_model(FFIDAgencyBillingSummary, data, None, "課金サマリーレスポンスの形式が不正です。"), None

    async def get_invoices(
        self, agency_id: str
    ) -> tuple[list[FFIDAgencyInvoice] | None, FFIDAgencyServerError | None]:
        """請求書一覧を取得"""
        data, err = await self._request("GET", f"/{self._encode(agency_id)}/invoices")
        if err:
            return None, err
        return _parse_model_list(FFIDAgencyInvoice, data, "invoices", "請求書一覧レスポンスの形式が不正です。"), None

    async def get_revenue(
        self, agency_id: str
    ) -> tuple[FFIDAgencyRevenue | None, FFIDAgencyServerError | None]:
        """収益情報を取得"""
        data, err = await self._request("GET", f"/{self._encode(agency_id)}/revenue")
        if err:
            return None, err
        return _parse_model(FFIDAgencyRevenue, data, None, "収益情報レスポンスの形式が不正です。"), None
