"""
FFID Agency SDK Errors

代理店管理関連のエラー。日本語メッセージで統一。
"""

from __future__ import annotations

from typing import Any


class FFIDAgencySDKError(Exception):
    """Agency SDK の基底例外"""

    def __init__(
        self,
        message: str,
        code: str = "UNKNOWN_ERROR",
        details: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.code = code
        self.details = details or {}


class FFIDAgencyValidationError(FFIDAgencySDKError):
    """バリデーションエラー"""

    def __init__(self, message: str, details: dict[str, Any] | None = None) -> None:
        super().__init__(message, code="VALIDATION_ERROR", details=details)


class FFIDAgencyNetworkError(FFIDAgencySDKError):
    """ネットワークエラー"""

    def __init__(self, message: str, details: dict[str, Any] | None = None) -> None:
        super().__init__(message, code="NETWORK_ERROR", details=details)


class FFIDAgencyParseError(FFIDAgencySDKError):
    """レスポンスパースエラー"""

    def __init__(self, message: str, details: dict[str, Any] | None = None) -> None:
        super().__init__(message, code="PARSE_ERROR", details=details)


class FFIDAgencyMissingTokenError(FFIDAgencySDKError):
    """アクセストークン未設定"""

    def __init__(self) -> None:
        super().__init__(
            "Agency クライアント: access_token が未設定です。",
            code="MISSING_TOKEN",
        )
