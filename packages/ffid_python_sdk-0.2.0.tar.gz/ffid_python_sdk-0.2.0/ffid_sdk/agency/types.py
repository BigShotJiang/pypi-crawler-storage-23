"""
FFID Agency SDK Type Definitions

代理店管理用の型。TypeScript Agency SDK の型に準拠。
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

_CAMEL = ConfigDict(populate_by_name=True, from_attributes=True)

FFIDAgencyStatus = Literal["active", "suspended", "inactive"]
FFIDAgencyBillingType = Literal["direct", "consolidated", "markup"]
FFIDAgencyMemberRole = Literal["owner", "admin", "sales", "support"]
FFIDAgencyMemberStatus = Literal["active", "invited", "suspended"]
FFIDAgencyBillingOverride = Literal["default", "direct", "exempt"]
FFIDSslStatus = Literal["pending", "active", "failed"]
FFIDAgencyAssetType = Literal["logo", "favicon"]
FFIDAgencyInvoiceStatus = Literal[
    "draft", "open", "paid", "void", "uncollectible"
]


class FFIDAgencyClientConfig(BaseModel):
    """Agency クライアント設定（Bearer Token 認証）"""

    access_token: str
    api_base_url: str | None = None
    debug: bool = False


class FFIDAgencyBrandingSettings(BaseModel):
    """ブランディング設定"""

    model_config = _CAMEL

    logo_url: str | None = Field(default=None, alias="logoUrl")
    favicon_url: str | None = Field(default=None, alias="faviconUrl")
    primary_color: str | None = Field(default=None, alias="primaryColor")
    secondary_color: str | None = Field(default=None, alias="secondaryColor")
    company_name: str | None = Field(default=None, alias="companyName")


class FFIDAgencyDnsRecord(BaseModel):
    """DNS レコード"""

    type: str
    name: str
    value: str


class FFIDAgencyDomainSettings(BaseModel):
    """ドメイン設定"""

    model_config = _CAMEL

    custom_domain: str | None = Field(default=None, alias="customDomain")
    ssl_status: FFIDSslStatus | None = Field(default=None, alias="sslStatus")
    verified_at: str | None = Field(default=None, alias="verifiedAt")
    dns_records: list[FFIDAgencyDnsRecord] | None = Field(default=None, alias="dnsRecords")


class FFIDAgencyEmailSettings(BaseModel):
    """メール設定"""

    model_config = _CAMEL

    from_name: str | None = Field(default=None, alias="fromName")
    from_email: str | None = Field(default=None, alias="fromEmail")
    reply_to: str | None = Field(default=None, alias="replyTo")


class FFIDAgencySettings(BaseModel):
    """代理店設定"""

    branding: FFIDAgencyBrandingSettings | None = None
    domain: FFIDAgencyDomainSettings | None = None
    email: FFIDAgencyEmailSettings | None = None


class FFIDAgency(BaseModel):
    """代理店情報"""

    model_config = _CAMEL

    id: str
    name: str
    slug: str
    is_platform_owner: bool = Field(alias="isPlatformOwner")
    parent_agency_id: str | None = Field(default=None, alias="parentAgencyId")
    status: FFIDAgencyStatus
    settings: FFIDAgencySettings
    billing_type: FFIDAgencyBillingType = Field(alias="billingType")
    contact_email: str | None = Field(default=None, alias="contactEmail")
    created_at: str = Field(alias="createdAt")
    updated_at: str = Field(alias="updatedAt")


class FFIDAgencyMember(BaseModel):
    """代理店メンバー"""

    model_config = _CAMEL

    user_id: str = Field(alias="userId")
    email: str
    display_name: str | None = Field(default=None, alias="displayName")
    avatar_url: str | None = Field(default=None, alias="avatarUrl")
    role: FFIDAgencyMemberRole
    status: FFIDAgencyMemberStatus
    joined_at: str | None = Field(default=None, alias="joinedAt")
    invited_at: str | None = Field(default=None, alias="invitedAt")


class FFIDAgencyOrganization(BaseModel):
    """代理店-組織リンク"""

    model_config = _CAMEL

    id: str
    agency_id: str = Field(alias="agencyId")
    organization_id: str = Field(alias="organizationId")
    organization_name: str = Field(alias="organizationName")
    organization_slug: str = Field(alias="organizationSlug")
    billing_override: FFIDAgencyBillingOverride = Field(alias="billingOverride")
    commission_rate: float | None = Field(default=None, alias="commissionRate")
    markup_rate: float | None = Field(default=None, alias="markupRate")
    markup_fixed: float | None = Field(default=None, alias="markupFixed")
    notes: str | None = None
    created_at: str = Field(alias="createdAt")


class FFIDAgencyHierarchyNode(BaseModel):
    """代理店階層ノード"""

    agency: FFIDAgency
    children: list[FFIDAgencyHierarchyNode]
    level: int


class FFIDAgencyHierarchyResponse(BaseModel):
    """階層レスポンス"""

    model_config = _CAMEL

    root: FFIDAgencyHierarchyNode
    total_levels: int = Field(alias="totalLevels")
    total_agencies: int = Field(alias="totalAgencies")


class FFIDAgencyBillingConfig(BaseModel):
    """課金設定"""

    model_config = _CAMEL

    billing_type: FFIDAgencyBillingType = Field(alias="billingType")
    stripe_customer_id: str | None = Field(default=None, alias="stripeCustomerId")
    invoice_email: str | None = Field(default=None, alias="invoiceEmail")
    payment_terms: int | None = Field(default=None, alias="paymentTerms")
    default_markup_rate: float | None = Field(default=None, alias="defaultMarkupRate")
    default_markup_fixed: float | None = Field(default=None, alias="defaultMarkupFixed")


class FFIDAgencyBillingSummary(BaseModel):
    """課金サマリー"""

    model_config = _CAMEL

    agency_id: str = Field(alias="agencyId")
    total_organizations: int = Field(alias="totalOrganizations")
    total_revenue: float = Field(alias="totalRevenue")
    period: str


class FFIDAgencyInvoice(BaseModel):
    """請求書"""

    model_config = _CAMEL

    id: str
    amount: float
    currency: str
    status: FFIDAgencyInvoiceStatus
    period_start: str = Field(alias="periodStart")
    period_end: str = Field(alias="periodEnd")
    created_at: str = Field(alias="createdAt")


class FFIDAgencyRevenue(BaseModel):
    """収益情報"""

    model_config = _CAMEL

    agency_id: str = Field(alias="agencyId")
    total_revenue: float = Field(alias="totalRevenue")
    breakdown: dict[str, float]
    period: str


class FFIDAgencyServerError(BaseModel):
    """Agency API エラー"""

    code: str = ""
    message: str = ""
    details: dict[str, Any] | None = None
