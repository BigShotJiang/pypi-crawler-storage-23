"""
FFID Agency SDK

代理店管理（Bearer Token 認証）。
"""

from __future__ import annotations

from ffid_sdk.agency.client import FFIDAgencyClient
from ffid_sdk.agency.errors import (
    FFIDAgencyMissingTokenError,
    FFIDAgencyNetworkError,
    FFIDAgencyParseError,
    FFIDAgencySDKError,
    FFIDAgencyValidationError,
)
from ffid_sdk.agency.types import (
    FFIDAgency,
    FFIDAgencyAssetType,
    FFIDAgencyBillingConfig,
    FFIDAgencyBillingOverride,
    FFIDAgencyBillingSummary,
    FFIDAgencyBillingType,
    FFIDAgencyBrandingSettings,
    FFIDAgencyClientConfig,
    FFIDAgencyDnsRecord,
    FFIDAgencyDomainSettings,
    FFIDAgencyEmailSettings,
    FFIDAgencyHierarchyNode,
    FFIDAgencyHierarchyResponse,
    FFIDAgencyInvoice,
    FFIDAgencyMember,
    FFIDAgencyMemberRole,
    FFIDAgencyMemberStatus,
    FFIDAgencyOrganization,
    FFIDAgencyRevenue,
    FFIDAgencyServerError,
    FFIDAgencySettings,
    FFIDAgencyStatus,
    FFIDSslStatus,
)

__all__ = [
    "FFIDAgencyClient",
    "FFIDAgencyClientConfig",
    "FFIDAgency",
    "FFIDAgencySettings",
    "FFIDAgencyBrandingSettings",
    "FFIDAgencyDomainSettings",
    "FFIDAgencyDnsRecord",
    "FFIDAgencyEmailSettings",
    "FFIDAgencyMember",
    "FFIDAgencyOrganization",
    "FFIDAgencyHierarchyNode",
    "FFIDAgencyHierarchyResponse",
    "FFIDAgencyBillingConfig",
    "FFIDAgencyBillingSummary",
    "FFIDAgencyInvoice",
    "FFIDAgencyRevenue",
    "FFIDAgencyServerError",
    "FFIDAgencyStatus",
    "FFIDAgencyBillingType",
    "FFIDAgencyMemberRole",
    "FFIDAgencyMemberStatus",
    "FFIDAgencyBillingOverride",
    "FFIDSslStatus",
    "FFIDAgencyAssetType",
    "FFIDAgencySDKError",
    "FFIDAgencyValidationError",
    "FFIDAgencyNetworkError",
    "FFIDAgencyParseError",
    "FFIDAgencyMissingTokenError",
]
