"""
FFID SDK Webhook Error Definitions

Webhook処理で発生するエラーの例外クラス階層。
FFIDSDKError を継承し、署名検証・タイムスタンプ・ペイロードのエラーを提供。
"""

from __future__ import annotations

from typing import Any, Dict, Optional

from ffid_sdk.errors import FFIDSDKError


class FFIDWebhookError(FFIDSDKError):
    """Webhook基底エラー"""

    def __init__(
        self,
        message: str = "Webhookエラーが発生しました",
        code: str = "WEBHOOK_ERROR",
        details: Optional[Dict[str, Any]] = None,
    ) -> None:
        super().__init__(code=code, message=message, details=details)


class FFIDWebhookSignatureError(FFIDWebhookError):
    """署名検証エラー"""

    def __init__(
        self,
        message: str = "Webhook署名の検証に失敗しました",
        details: Optional[Dict[str, Any]] = None,
    ) -> None:
        super().__init__(
            code="WEBHOOK_SIGNATURE_ERROR", message=message, details=details
        )


class FFIDWebhookTimestampError(FFIDWebhookError):
    """タイムスタンプ検証エラー"""

    def __init__(
        self,
        message: str = "Webhookタイムスタンプが有効期限切れです",
        details: Optional[Dict[str, Any]] = None,
    ) -> None:
        super().__init__(
            code="WEBHOOK_TIMESTAMP_ERROR", message=message, details=details
        )


class FFIDWebhookPayloadError(FFIDWebhookError):
    """ペイロードパースエラー"""

    def __init__(
        self,
        message: str = "Webhookペイロードのパースに失敗しました",
        details: Optional[Dict[str, Any]] = None,
    ) -> None:
        super().__init__(
            code="WEBHOOK_PAYLOAD_ERROR", message=message, details=details
        )
