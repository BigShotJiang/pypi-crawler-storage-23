"""
FFID SDK Shared Constants

SDK全体で共有される定数。URL・エンドポイント・デフォルト設定値を一元管理。
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# API Base URL
# ---------------------------------------------------------------------------

DEFAULT_API_BASE_URL = "https://id.feelflow.co.jp"
"""FFID API のデフォルトベースURL（本番環境）"""

# ---------------------------------------------------------------------------
# API Endpoint Paths
# ---------------------------------------------------------------------------

SESSION_ENDPOINT = "/api/v1/auth/session"
"""セッション取得エンドポイント"""

REFRESH_ENDPOINT = "/api/v1/auth/refresh"
"""トークンリフレッシュエンドポイント"""

SIGNOUT_ENDPOINT = "/api/v1/auth/signout"
"""サインアウトエンドポイント"""

SUBSCRIPTIONS_CHECK_ENDPOINT = "/api/v1/subscriptions/check"
"""契約チェックエンドポイント"""

LEGAL_EXT_PREFIX = "/api/v1/legal/ext"
"""Legal 外部 API プレフィックス（Service API Key 認証）"""

# ---------------------------------------------------------------------------
# HTTP
# ---------------------------------------------------------------------------

SERVICE_API_KEY_HEADER = "X-Service-Api-Key"
"""Service API Key ヘッダー名（Legal 等のサーバー間通信）"""

NO_CONTENT_STATUS = 204
"""HTTP 204 No Content ステータスコード"""

AUTHORIZATION_HEADER = "Authorization"
"""認証ヘッダー名"""

BEARER_PREFIX = "Bearer "
"""Bearer トークンプレフィックス"""

SESSION_COOKIE_NAME = "ffid_session"
"""セッションCookie名"""

REFRESH_COOKIE_NAME = "ffid_refresh"
"""リフレッシュトークン用Cookie名（auto_refresh 有効時のみ参照）"""

# ---------------------------------------------------------------------------
# Timeouts & Retries
# ---------------------------------------------------------------------------

DEFAULT_TIMEOUT_SECONDS = 10.0
"""デフォルトHTTPタイムアウト（秒）"""

DEFAULT_MAX_RETRIES = 3
"""デフォルトリトライ回数"""

DEFAULT_RETRY_BACKOFF_FACTOR = 0.5
"""リトライ時のバックオフ係数"""

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

SDK_LOGGER_NAME = "ffid_sdk"
"""SDKロガー名"""
