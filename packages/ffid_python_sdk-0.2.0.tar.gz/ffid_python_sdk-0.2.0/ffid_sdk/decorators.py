"""
FFID SDK Decorators

FastAPI エンドポイント向けの契約チェックデコレータ。
TypeScript SDK の ``withSubscription`` HOC に対応。

Example:
    ```python
    from ffid_sdk import require_subscription, FFIDContext, get_ffid_context

    @app.get("/premium")
    @require_subscription(plans=["pro", "enterprise"])
    async def premium_feature(ctx: FFIDContext = Depends(get_ffid_context)):
        return {"plan": ctx.active_subscription.plan_code}

    @app.get("/basic")
    @require_subscription()  # 任意の有効な契約があればOK
    async def basic_feature(ctx: FFIDContext = Depends(get_ffid_context)):
        return {"message": "Welcome!"}
    ```
"""

from __future__ import annotations

import functools
import logging
from collections.abc import Callable
from typing import TypeVar

try:
    from typing import ParamSpec
except ImportError:
    from typing_extensions import ParamSpec

from ffid_sdk.constants import SDK_LOGGER_NAME
from ffid_sdk.errors import (
    FFIDAuthenticationError,
    FFIDErrorCode,
    FFIDSubscriptionError,
)
from ffid_sdk.types import FFIDContext, SubscriptionStatus

logger = logging.getLogger(SDK_LOGGER_NAME)

P = ParamSpec("P")
R = TypeVar("R")


def require_subscription(
    plans: list[str] | None = None,
    plan: list[str] | None = None,
    service_code: str | None = None,
) -> Callable[[Callable[P, R]], Callable[P, R]]:
    """契約チェックデコレータ

    エンドポイント関数をラップし、有効な契約があるかチェックする。
    TypeScript SDK の ``withSubscription`` HOC に対応。

    Args:
        plans: 許可するプランコードのリスト（省略時は任意のアクティブ契約でOK）
        plan: ``plans`` のエイリアス（Issue #170 の使用例と一致。plans より優先されない）
        service_code: サービスコード（省略時はコンテキストの全契約を対象）

    Returns:
        デコレータ関数

    Raises:
        FFIDAuthenticationError: 未認証の場合
        FFIDSubscriptionError: 有効な契約がない場合

    Example:
        ```python
        @require_subscription(plans=["pro", "enterprise"])
        async def premium_only(ctx: FFIDContext = Depends(get_ffid_context)):
            ...
        ```
    """
    # Issue #170: plan は plans のエイリアス（使用例 @require_subscription(plan=[...]) と一致）
    if plans is None and plan is not None:
        plans = plan

    def decorator(func: Callable[P, R]) -> Callable[P, R]:
        @functools.wraps(func)
        async def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
            # コンテキストを取得（args および kwargs から FFIDContext を探す）
            ctx: FFIDContext | None = next(
                (a for a in args if isinstance(a, FFIDContext)), None
            )
            if ctx is None:
                ctx = next(
                    (v for v in kwargs.values() if isinstance(v, FFIDContext)), None
                )

            if ctx is None:
                raise FFIDAuthenticationError(
                    message="認証が必要です。ログインしてください。",
                    code=FFIDErrorCode.AUTHENTICATION_ERROR,
                )

            # 契約チェック
            active_statuses = (SubscriptionStatus.ACTIVE, SubscriptionStatus.TRIALING)
            matching_subs = [
                s for s in ctx.subscriptions
                if s.status in active_statuses
            ]

            # サービスコードでフィルタ
            if service_code:
                matching_subs = [
                    s for s in matching_subs
                    if s.service_code == service_code
                ]

            # プランでフィルタ
            if plans:
                matching_subs = [
                    s for s in matching_subs
                    if s.plan_code in plans
                ]

            if not matching_subs:
                plan_info = ""
                if plans:
                    plan_info = f"（必要なプラン: {', '.join(plans)}）"
                logger.debug(
                    "Subscription check failed: user=%s, plans=%s, service=%s",
                    ctx.user.email, plans, service_code,
                )
                raise FFIDSubscriptionError(
                    message=f"この機能を利用するには有効な契約が必要です。{plan_info}",
                    code=FFIDErrorCode.SUBSCRIPTION_REQUIRED,
                    details={
                        "required_plans": plans or [],
                        "service_code": service_code,
                    },
                )

            logger.debug(
                "Subscription check passed: user=%s, plan=%s",
                ctx.user.email, matching_subs[0].plan_code,
            )

            return await func(*args, **kwargs)

        return wrapper  # type: ignore[return-value]

    return decorator
