"""
FFID Context Dependencies for FastAPI

FastAPI の ``Depends()`` で利用するコンテキスト取得関数。
ミドルウェアが設定した ``FFIDContext`` をエンドポイントに注入する。

Example:
    ```python
    from fastapi import Depends
    from ffid_sdk import FFIDContext, get_ffid_context, require_ffid_auth

    @app.get("/profile")
    async def profile(ctx: FFIDContext = Depends(get_ffid_context)):
        return {"email": ctx.user.email}

    @app.get("/admin")
    async def admin(ctx: FFIDContext = Depends(require_ffid_auth)):
        # 認証必須（未認証時は FFIDAuthenticationError を送出）
        return {"user": ctx.user.id}
    ```
"""

from __future__ import annotations

import logging
from typing import Optional

from fastapi import Request

from ffid_sdk.constants import SDK_LOGGER_NAME
from ffid_sdk.errors import FFIDAuthenticationError, FFIDErrorCode
from ffid_sdk.types import FFIDContext

logger = logging.getLogger(SDK_LOGGER_NAME)


def get_ffid_context(request: Request) -> Optional[FFIDContext]:
    """リクエストから FFID コンテキストを取得（認証任意）

    ミドルウェアが設定した ``FFIDContext`` を返す。
    未認証（除外パス等）の場合は ``None`` を返す。

    Args:
        request: FastAPI リクエストオブジェクト

    Returns:
        認証済みの場合は FFIDContext、未認証の場合は None
    """
    context: Optional[FFIDContext] = getattr(request.state, "ffid_context", None)
    return context


def require_ffid_auth(request: Request) -> FFIDContext:
    """リクエストから FFID コンテキストを取得（認証必須）

    ミドルウェアが設定した ``FFIDContext`` を返す。
    未認証の場合は ``FFIDAuthenticationError`` を発生させる。

    Args:
        request: FastAPI リクエストオブジェクト

    Returns:
        認証済みの FFIDContext

    Raises:
        FFIDAuthenticationError: 未認証の場合
    """
    context: Optional[FFIDContext] = getattr(request.state, "ffid_context", None)
    if context is None:
        logger.debug("require_ffid_auth: No context found on request.state")
        raise FFIDAuthenticationError(
            message="認証が必要です。ログインしてください。",
            code=FFIDErrorCode.AUTHENTICATION_ERROR,
        )
    return context
