"""
FFID Legal SDK Errors

利用規約・同意関連のエラー。日本語メッセージで統一。
"""

from __future__ import annotations

from typing import Any


class FFIDLegalSDKError(Exception):
    """Legal SDK の基底例外"""

    def __init__(
        self,
        message: str,
        code: str = "UNKNOWN_ERROR",
        details: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.code = code
        self.details = details or {}


class FFIDLegalValidationError(FFIDLegalSDKError):
    """バリデーションエラー（必須パラメータ未設定など）"""

    def __init__(self, message: str, details: dict[str, Any] | None = None) -> None:
        super().__init__(message, code="VALIDATION_ERROR", details=details)


class FFIDLegalNetworkError(FFIDLegalSDKError):
    """ネットワークエラー"""

    def __init__(self, message: str, details: dict[str, Any] | None = None) -> None:
        super().__init__(message, code="NETWORK_ERROR", details=details)


class FFIDLegalParseError(FFIDLegalSDKError):
    """レスポンスパースエラー"""

    def __init__(self, message: str, details: dict[str, Any] | None = None) -> None:
        super().__init__(message, code="PARSE_ERROR", details=details)


class FFIDLegalMissingApiKeyError(FFIDLegalSDKError):
    """API キー未設定"""

    def __init__(self) -> None:
        super().__init__(
            "Legal クライアント: apiKey が未設定です。",
            code="MISSING_API_KEY",
        )
