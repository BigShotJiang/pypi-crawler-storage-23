"""
FFID Legal SDK

法的文書・同意管理（Service API Key 認証）。
"""

from __future__ import annotations

from ffid_sdk.legal.client import FFIDLegalClient
from ffid_sdk.legal.errors import (
    FFIDLegalMissingApiKeyError,
    FFIDLegalNetworkError,
    FFIDLegalParseError,
    FFIDLegalSDKError,
    FFIDLegalValidationError,
)
from ffid_sdk.legal.helpers import (
    DEFAULT_AGREEMENT_PAGE_PATH,
    check_pending_agreements_and_redirect_url,
)
from ffid_sdk.legal.types import (
    FFIDAgreementCheckResult,
    FFIDAgreementMethod,
    FFIDLegalClientConfig,
    FFIDLegalDocument,
    FFIDLegalDocumentType,
    FFIDPendingAgreement,
    FFIDPendingAgreementsResponse,
    FFIDRecordAgreementRequest,
    FFIDRecordAgreementResponse,
    FFIDServiceUserAgreement,
)

__all__ = [
    "FFIDLegalClient",
    "FFIDLegalClientConfig",
    "FFIDLegalDocument",
    "FFIDLegalDocumentType",
    "FFIDAgreementMethod",
    "FFIDRecordAgreementRequest",
    "FFIDRecordAgreementResponse",
    "FFIDAgreementCheckResult",
    "FFIDServiceUserAgreement",
    "FFIDPendingAgreement",
    "FFIDPendingAgreementsResponse",
    "FFIDLegalSDKError",
    "FFIDLegalValidationError",
    "FFIDLegalNetworkError",
    "FFIDLegalParseError",
    "FFIDLegalMissingApiKeyError",
    "DEFAULT_AGREEMENT_PAGE_PATH",
    "check_pending_agreements_and_redirect_url",
]
