"""
FFID Legal SDK Type Definitions

法的文書・同意管理用の型。TypeScript Legal SDK の型に準拠。
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

_CAMEL = ConfigDict(populate_by_name=True, from_attributes=True)

FFIDLegalDocumentType = Literal[
    "terms_of_service",
    "privacy_policy",
    "cookie_policy",
    "acceptable_use_policy",
    "data_processing_agreement",
    "service_level_agreement",
    "other",
]

FFIDAgreementMethod = Literal[
    "explicit_checkbox",
    "click_through",
    "continued_use",
    "electronic_signature",
]


class FFIDLegalClientConfig(BaseModel):
    """Legal クライアント設定（Service API Key 認証）"""

    api_key: str
    api_base_url: str | None = None
    debug: bool = False


class FFIDLegalDocument(BaseModel):
    """法的文書"""

    model_config = _CAMEL

    id: str
    type: str  # FFIDLegalDocumentType
    title: str
    version: str
    content: str = ""
    summary: str | None = None
    effective_date: str = Field(alias="effectiveDate", default="")
    is_active: bool = Field(alias="isActive", default=True)
    service_scope: str = Field(alias="serviceScope", default="platform")
    requires_agreement: bool = Field(alias="requiresAgreement", default=False)
    content_hash: str = Field(alias="contentHash", default="")
    created_at: str = Field(alias="createdAt", default="")
    updated_at: str = Field(alias="updatedAt", default="")


class FFIDServiceUserAgreement(BaseModel):
    """同意記録"""

    model_config = _CAMEL

    id: str
    service_id: str = Field(alias="serviceId")
    external_user_id: str = Field(alias="externalUserId")
    external_user_email: str | None = Field(default=None, alias="externalUserEmail")
    document_id: str = Field(alias="documentId")
    agreed_at: str = Field(alias="agreedAt")
    agreement_method: str = Field(alias="agreementMethod")
    ip_address: str | None = Field(default=None, alias="ipAddress")
    user_agent: str | None = Field(default=None, alias="userAgent")
    document_version: str = Field(alias="documentVersion")
    document_title: str = Field(alias="documentTitle")
    document_hash: str = Field(alias="documentHash")
    metadata: dict[str, Any] = Field(default_factory=dict)
    created_at: str = Field(alias="createdAt")


class FFIDRecordAgreementRequest(BaseModel):
    """同意記録リクエスト"""

    model_config = _CAMEL

    external_user_id: str = Field(alias="externalUserId")
    external_user_email: str | None = Field(default=None, alias="externalUserEmail")
    document_id: str = Field(alias="documentId")
    agreement_method: str = Field(default="click_through", alias="agreementMethod")
    ip_address: str | None = Field(default=None, alias="ipAddress")
    user_agent: str | None = Field(default=None, alias="userAgent")
    metadata: dict[str, Any] | None = None


class FFIDRecordAgreementResponse(BaseModel):
    """同意記録レスポンス"""

    model_config = _CAMEL

    message: str = ""
    agreement_id: str = Field(alias="agreementId")
    document_id: str = Field(alias="documentId")
    external_user_id: str = Field(alias="externalUserId")


class FFIDAgreementCheckResult(BaseModel):
    """同意確認結果（hasAgreed が True のとき agreement が存在）"""

    model_config = _CAMEL

    has_agreed: bool = Field(alias="hasAgreed")
    agreement: FFIDServiceUserAgreement | None = None


class FFIDPendingAgreement(BaseModel):
    """未同意文書情報"""

    model_config = _CAMEL

    document_id: str = Field(alias="documentId")
    document_type: str = Field(alias="documentType")
    document_title: str = Field(alias="documentTitle")
    document_version: str = Field(alias="documentVersion")
    effective_date: str = Field(alias="effectiveDate")


class FFIDPendingAgreementsResponse(BaseModel):
    """未同意一覧レスポンス"""

    model_config = _CAMEL

    pending_documents: list[FFIDPendingAgreement] = Field(
        default_factory=list, alias="pendingDocuments"
    )
    count: int = 0
    has_pending: bool = Field(alias="hasPending", default=False)


class FFIDLegalServerError(BaseModel):
    """Legal API エラー"""

    code: str = ""
    message: str = ""
    details: dict[str, Any] | None = None
