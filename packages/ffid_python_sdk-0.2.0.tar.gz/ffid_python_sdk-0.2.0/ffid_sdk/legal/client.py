"""
FFID Legal API Client

法的文書・同意管理のサーバー間通信。X-Service-Api-Key で認証。
TypeScript の createFFIDLegalClient に対応。
"""

from __future__ import annotations

import logging
import urllib.parse
from typing import Any

import httpx

from ffid_sdk.constants import (
    DEFAULT_API_BASE_URL,
    DEFAULT_TIMEOUT_SECONDS,
    LEGAL_EXT_PREFIX,
    NO_CONTENT_STATUS,
    SDK_LOGGER_NAME,
    SERVICE_API_KEY_HEADER,
)
from ffid_sdk.legal.errors import (
    FFIDLegalMissingApiKeyError,
    FFIDLegalNetworkError,
    FFIDLegalParseError,
)
from ffid_sdk.legal.types import (
    FFIDAgreementCheckResult,
    FFIDLegalClientConfig,
    FFIDLegalServerError,
    FFIDPendingAgreementsResponse,
    FFIDRecordAgreementRequest,
    FFIDRecordAgreementResponse,
)

logger = logging.getLogger(SDK_LOGGER_NAME)


def _parse_legal_response(
    response: httpx.Response,
) -> tuple[dict[str, Any] | None, FFIDLegalServerError | None]:
    """Legal API の success/data|error 形式をパースする"""
    if response.status_code == NO_CONTENT_STATUS:
        return None, FFIDLegalServerError(
            message="予期しないレスポンス: サーバーからコンテンツが返されませんでした"
        )
    try:
        body: dict[str, Any] = response.json()
    except Exception as exc:
        raise FFIDLegalParseError(
            f"サーバーから不正なレスポンスを受信しました (status: {response.status_code})",
            details={"error": str(exc)},
        ) from exc
    success = body.get("success", False)
    if not response.is_success or not success:
        err = body.get("error", {})
        return None, FFIDLegalServerError(
            code=err.get("code", "UNKNOWN_ERROR"),
            message=err.get("message", "不明なエラーが発生しました"),
            details=err.get("details"),
        )
    data = body.get("data")
    if data is None:
        return None, FFIDLegalServerError(message="サーバーからデータが返されませんでした")
    return data, None


class FFIDLegalClient:
    """FFID Legal API クライアント（Service API Key 認証）"""

    def __init__(self, config: FFIDLegalClientConfig) -> None:
        if not (config.api_key or "").strip():
            raise FFIDLegalMissingApiKeyError()
        self._config = config
        self._base_url = (config.api_base_url or DEFAULT_API_BASE_URL).rstrip("/")
        self._timeout = DEFAULT_TIMEOUT_SECONDS
        self._prefix = LEGAL_EXT_PREFIX
        if config.debug:
            logging.getLogger(SDK_LOGGER_NAME).setLevel(logging.DEBUG)
        logger.debug(
            "FFIDLegalClient initialized: base_url=%s",
            self._base_url,
        )

    def _url(self, path: str) -> str:
        return f"{self._base_url}{self._prefix}{path}"

    def _headers(self) -> dict[str, str]:
        return {
            "Content-Type": "application/json",
            SERVICE_API_KEY_HEADER: self._config.api_key,
        }

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, str] | None = None,
        json_body: dict[str, Any] | None = None,
    ) -> tuple[dict[str, Any] | None, FFIDLegalServerError | None]:
        url = self._url(path)
        try:
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                response = await client.request(
                    method,
                    url,
                    headers=self._headers(),
                    params=params,
                    json=json_body,
                )
        except httpx.TimeoutException as exc:
            raise FFIDLegalNetworkError(
                "ネットワークエラーが発生しました。しばらく経ってから再度お試しください。",
                details={"url": url, "error": str(exc)},
            ) from exc
        except httpx.ConnectError as exc:
            raise FFIDLegalNetworkError(
                "ネットワークエラーが発生しました。しばらく経ってから再度お試しください。",
                details={"url": url, "error": str(exc)},
            ) from exc
        return _parse_legal_response(response)

    async def get_documents(
        self,
    ) -> tuple[dict[str, Any] | None, FFIDLegalServerError | None]:
        """法的文書一覧を取得"""
        data, err = await self._request("GET", "/documents")
        if err:
            return None, err
        return data, None

    async def get_document(
        self,
        document_id: str,
    ) -> tuple[dict[str, Any] | None, FFIDLegalServerError | None]:
        """指定IDの法的文書を取得"""
        if not (document_id or "").strip():
            return None, FFIDLegalServerError(
                code="VALIDATION_ERROR",
                message="documentId は必須です。",
            )
        path = f"/documents/{urllib.parse.quote(document_id, safe='')}"
        return await self._request("GET", path)

    async def record_agreement(
        self,
        request: FFIDRecordAgreementRequest,
    ) -> tuple[FFIDRecordAgreementResponse | None, FFIDLegalServerError | None]:
        """同意を記録"""
        if not (request.external_user_id or "").strip() or not (
            request.document_id or ""
        ).strip():
            return None, FFIDLegalServerError(
                code="VALIDATION_ERROR",
                message="externalUserId と documentId は必須です。",
            )
        payload = request.model_dump(by_alias=True, exclude_none=True)
        data, err = await self._request("POST", "/agreements", json_body=payload)
        if err:
            return None, err
        try:
            return FFIDRecordAgreementResponse.model_validate(data), None
        except Exception as exc:
            raise FFIDLegalParseError(
                "同意記録レスポンスの形式が不正です。",
                details={"error": str(exc)},
            ) from exc

    async def check_agreement(
        self,
        external_user_id: str,
        document_id: str,
    ) -> tuple[FFIDAgreementCheckResult | None, FFIDLegalServerError | None]:
        """指定ユーザー・文書の同意有無を確認"""
        if not (external_user_id or "").strip() or not (document_id or "").strip():
            return None, FFIDLegalServerError(
                code="VALIDATION_ERROR",
                message="externalUserId と documentId は必須です。",
            )
        data, err = await self._request(
            "GET",
            "/agreements/check",
            params={
                "externalUserId": external_user_id,
                "documentId": document_id,
            },
        )
        if err:
            return None, err
        try:
            return FFIDAgreementCheckResult.model_validate(data), None
        except Exception as exc:
            raise FFIDLegalParseError(
                "同意確認レスポンスの形式が不正です。",
                details={"error": str(exc)},
            ) from exc

    async def get_pending_agreements(
        self,
        external_user_id: str,
    ) -> tuple[FFIDPendingAgreementsResponse | None, FFIDLegalServerError | None]:
        """未同意の文書一覧を取得"""
        if not (external_user_id or "").strip():
            return None, FFIDLegalServerError(
                code="VALIDATION_ERROR",
                message="externalUserId は必須です。",
            )
        data, err = await self._request(
            "GET",
            "/agreements/pending",
            params={"externalUserId": external_user_id},
        )
        if err:
            return None, err
        try:
            return FFIDPendingAgreementsResponse.model_validate(data), None
        except Exception as exc:
            raise FFIDLegalParseError(
                "未同意一覧レスポンスの形式が不正です。",
                details={"error": str(exc)},
            ) from exc
