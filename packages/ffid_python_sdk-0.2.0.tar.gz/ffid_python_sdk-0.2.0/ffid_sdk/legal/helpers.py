"""
FFID Legal Helpers for FastAPI

利用規約チェック・未同意時のリダイレクトURL生成。
"""

from __future__ import annotations

from urllib.parse import quote

from ffid_sdk.constants import DEFAULT_API_BASE_URL
from ffid_sdk.legal.client import FFIDLegalClient
from ffid_sdk.legal.types import (
    FFIDLegalServerError,
    FFIDPendingAgreementsResponse,
)

# FFID の同意画面パス（未同意時にリダイレクトする先）
DEFAULT_AGREEMENT_PAGE_PATH = "/portal/legal"


async def check_pending_agreements_and_redirect_url(
    legal_client: FFIDLegalClient,
    external_user_id: str,
    *,
    base_url: str | None = None,
    redirect_uri_after_agree: str | None = None,
) -> tuple[bool, FFIDPendingAgreementsResponse | None, str, FFIDLegalServerError | None]:
    """未同意文書があるか確認し、未同意時用のリダイレクトURLを返す。

    FastAPI で利用規約チェックを行い、未同意ならリダイレクトする場合に使用。

    Args:
        legal_client: FFIDLegalClient インスタンス
        external_user_id: 外部サービス上のユーザーID（FFID の user.id など）
        base_url: FFID のベースURL（省略時は DEFAULT_API_BASE_URL）
        redirect_uri_after_agree: 同意後に戻るURL（クエリに付与）

    Returns:
        (has_pending, pending_response, redirect_url, error) のタプル。
        has_pending が True のとき redirect_url に同意画面URLが入る。
        API 失敗時は error に FFIDLegalServerError が入り、has_pending は False。
    """
    base = (base_url or DEFAULT_API_BASE_URL).rstrip("/")
    path = DEFAULT_AGREEMENT_PAGE_PATH
    redirect_url = f"{base}{path}"

    pending, err = await legal_client.get_pending_agreements(external_user_id)
    if err or pending is None:
        return False, None, redirect_url, err
    if not pending.has_pending:
        return False, pending, redirect_url, None
    if redirect_uri_after_agree:
        redirect_url = f"{redirect_url}?redirect_uri={quote(redirect_uri_after_agree, safe='')}"
    return True, pending, redirect_url, None
