"""
Empty setup.py for amplifier-module-loop-streaming
"""
from setuptools import setup

setup(
    name="amplifier-module-loop-streaming",
    version="0.0.0",
    description="Empty placeholder package - reserved name",
    author="Package Protector",
    author_email="protector@example.com",
    py_modules=[],
)
