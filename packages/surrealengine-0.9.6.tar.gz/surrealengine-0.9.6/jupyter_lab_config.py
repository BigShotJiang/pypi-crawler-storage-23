c = get_config()
c.ServerApp.ip = '0.0.0.0'
c.ServerApp.allow_origin = '*'
c.IdentityProvider.token = ''
c.ServerApp.password = ''
c.ServerApp.open_browser = False