import requests

class TrophaClient:
    def __init__(self, base_url: str = "https://tropha-api.onrender.com/api"):
        self.base_url = base_url.rstrip("/")
        self.session = requests.Session()

    def create_service(self, worker_address, title, description, base_price):
        url = f"{self.base_url}/services/create"
        payload = {
            "worker_address": worker_address,
            "title": title,
            "description": description,
            "base_price": base_price
        }
        response = self.session.post(url, json=payload)
        response.raise_for_status()
        return response.json()

    def get_services(self):
        url = f"{self.base_url}/services"
        response = self.session.get(url)
        response.raise_for_status()
        return response.json()

    def create_job(self, client_wallet, worker_address, amount_usdc, job_description, service_id, acceptance_criteria: dict, timeout_hours=24):
        url = f"{self.base_url}/jobs/create"
        payload = {
            "client_wallet": client_wallet,
            "worker_address": worker_address,
            "amount_usdc": amount_usdc,
            "job_description": job_description,
            "service_id": service_id,
            "acceptance_criteria": acceptance_criteria,
            "timeout_hours": timeout_hours
        }
        response = self.session.post(url, json=payload)
        response.raise_for_status()
        return response.json()

    def accept_job(self, job_id, worker_address):
        url = f"{self.base_url}/jobs/accept"
        payload = {
            "job_id": job_id,
            "worker_address": worker_address
        }
        response = self.session.post(url, json=payload)
        response.raise_for_status()
        return response.json()

    def reject_job(self, job_id, worker_address):
        url = f"{self.base_url}/jobs/reject"
        payload = {
            "job_id": job_id,
            "worker_address": worker_address
        }
        response = self.session.post(url, json=payload)
        response.raise_for_status()
        return response.json()

    def deliver_job(self, job_id, worker_address, delivery_payload):
        url = f"{self.base_url}/jobs/deliver"
        payload = {
            "job_id": job_id,
            "worker_address": worker_address,
            "delivery_payload": delivery_payload
        }
        response = self.session.post(url, json=payload)
        response.raise_for_status()
        return response.json()

    def release_job(self, job_id, client_wallet):
        url = f"{self.base_url}/jobs/release"
        payload = {
            "job_id": job_id,
            "client_wallet": client_wallet
        }
        response = self.session.post(url, json=payload)
        response.raise_for_status()
        return response.json()

    def dispute_job(self, job_id, client_wallet):
        url = f"{self.base_url}/jobs/dispute"
        payload = {
            "job_id": job_id,
            "client_wallet": client_wallet
        }
        response = self.session.post(url, json=payload)
        response.raise_for_status()
        return response.json()

    def timeout_job(self, job_id, client_wallet):
        url = f"{self.base_url}/jobs/timeout"
        payload = {
            "job_id": job_id,
            "client_wallet": client_wallet
        }
        response = self.session.post(url, json=payload)
        response.raise_for_status()
        return response.json()

    def get_worker_score(self, wallet_address):
        url = f"{self.base_url}/workers/{wallet_address}/score"
        response = self.session.get(url)
        response.raise_for_status()
        return response.json()
