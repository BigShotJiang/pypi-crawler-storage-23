
from django.dispatch import Signal


# Token signal
token_data_updated = Signal()


# UserInfo signal
userinfo_data_updated = Signal()

# User signal
user_data_updated = Signal()