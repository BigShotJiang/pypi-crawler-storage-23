from django.contrib import admin

class UserAdmin(admin.ModelAdmin):
    fields = [
        'username',
        'nickname',
        'first_name',
        'middle_name',
        'last_name',
        'email_address',
        'email_verified',
        'email_verified_at',
        'phone_number',
        'phone_verified',
        'phone_verified_at',
        'serial',
        'gender', 
        'birth_date', 
        'photo_url', 
        'photo_verified', 
        'photo_verified_at', 
        'profile',
        'is_pwd', 
        'is_active',
        'is_admin',
        'is_superuser',
        'is_verified',
    ]
    list_display = [
        'nickname', 
        'first_name', 
        'last_name', 
        'email_address',
        'phone_number',
        'gender',
        'is_active',
        'is_admin',
        'is_superuser',
        'is_verified'
    ]
    list_filter = ['email_verified', 'phone_verified', 'is_active', 'is_admin', 'is_superuser', 'is_verified']
    search_fields = ['username', 'nickname', 'first_name', 'last_name', 'email_address', 'phone_number']


class LoggingAdmin(admin.ModelAdmin):
    fields = [
        'level',
        'message',
        'context',
    ]
    list_display = ['created_at', 'level', 'message',]
    list_filter = ['level', 'created_at']
    search_fields = ['message', 'context']