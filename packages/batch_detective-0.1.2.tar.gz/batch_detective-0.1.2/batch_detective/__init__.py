"""batch-detective: Batch effect diagnosis tool for bulk RNA-seq count matrices."""

__version__ = "0.1.0"
__author__ = "batch-detective contributors"
__license__ = "MIT"
