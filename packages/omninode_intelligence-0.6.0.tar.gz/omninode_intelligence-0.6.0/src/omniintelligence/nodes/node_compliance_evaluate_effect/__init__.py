# SPDX-FileCopyrightText: 2025 OmniNode.ai Inc.
# SPDX-License-Identifier: MIT

# Copyright (c) 2025 OmniNode Team
"""Node Compliance Evaluate Effect.

Event-driven consumer of compliance-evaluate commands emitted by omniclaude.

Ticket: OMN-2339
"""
