﻿braindecode.preprocessing.create_windows_from_target_channels
=============================================================

.. currentmodule:: braindecode.preprocessing

.. autofunction:: create_windows_from_target_channels

.. include:: braindecode.preprocessing.create_windows_from_target_channels.examples

.. raw:: html

    <div style='clear:both'></div>