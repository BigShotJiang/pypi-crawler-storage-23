﻿braindecode.preprocessing.SetBipolarReference
=============================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: SetBipolarReference
   
   
   
   
      
   
      
   
      
   
      
         
      
   
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: fn

   
   
   

.. include:: braindecode.preprocessing.SetBipolarReference.examples

.. raw:: html

    <div style='clear:both'></div>