﻿braindecode.preprocessing.RemoveDrifts
======================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: RemoveDrifts
   
   
   
   
      
   
      
   
      
         
      
   
      
   
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: apply_eeg

   
   
   

.. include:: braindecode.preprocessing.RemoveDrifts.examples

.. raw:: html

    <div style='clear:both'></div>