﻿braindecode.preprocessing.create_fixed_length_windows
=====================================================

.. currentmodule:: braindecode.preprocessing

.. autofunction:: create_fixed_length_windows

.. include:: braindecode.preprocessing.create_fixed_length_windows.examples

.. raw:: html

    <div style='clear:both'></div>