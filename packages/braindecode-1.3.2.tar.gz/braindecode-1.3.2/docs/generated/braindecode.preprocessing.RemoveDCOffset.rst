﻿braindecode.preprocessing.RemoveDCOffset
========================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: RemoveDCOffset
   
   
   
   
      
   
      
   
      
         
      
   
      
   
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: apply_eeg

   
   
   

.. include:: braindecode.preprocessing.RemoveDCOffset.examples

.. raw:: html

    <div style='clear:both'></div>