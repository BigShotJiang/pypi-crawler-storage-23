﻿braindecode.preprocessing.ReinterpolateRemovedChannels
======================================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: ReinterpolateRemovedChannels
   
   
   
   
      
   
      
   
      
         
      
   
      
   
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: apply_eeg

   
   
   

.. include:: braindecode.preprocessing.ReinterpolateRemovedChannels.examples

.. raw:: html

    <div style='clear:both'></div>