﻿braindecode.preprocessing.AddChannels
=====================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: AddChannels
   
   
   
   
      
   
      
   
      
   
      
   
   

.. include:: braindecode.preprocessing.AddChannels.examples

.. raw:: html

    <div style='clear:both'></div>