﻿braindecode.augmentation.functional.frequency_shift
===================================================

.. currentmodule:: braindecode.augmentation.functional

.. autofunction:: frequency_shift

.. include:: braindecode.augmentation.functional.frequency_shift.examples

.. raw:: html

    <div style='clear:both'></div>