﻿braindecode.preprocessing.EqualizeChannels
==========================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: EqualizeChannels
   
   
   
   
      
   
      
   
      
   
      
         
      
   
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: fn

   
   
   

.. include:: braindecode.preprocessing.EqualizeChannels.examples

.. raw:: html

    <div style='clear:both'></div>