﻿braindecode.preprocessing.create_windows_from_events
====================================================

.. currentmodule:: braindecode.preprocessing

.. autofunction:: create_windows_from_events

.. include:: braindecode.preprocessing.create_windows_from_events.examples

.. raw:: html

    <div style='clear:both'></div>