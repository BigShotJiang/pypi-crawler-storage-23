﻿braindecode.datasets.BCICompetitionIVDataset4
=============================================

.. currentmodule:: braindecode.datasets

.. autoclass:: BCICompetitionIVDataset4
   
   
   
   
      
   
      
   
      
         
      
   
      
   
      
   
      
   
      
   
      
   
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: download

   
   
   

.. include:: braindecode.datasets.BCICompetitionIVDataset4.examples

.. raw:: html

    <div style='clear:both'></div>