﻿braindecode.functional.glorot_weight_zero_bias
==============================================

.. currentmodule:: braindecode.functional

.. autofunction:: glorot_weight_zero_bias

.. include:: braindecode.functional.glorot_weight_zero_bias.examples

.. raw:: html

    <div style='clear:both'></div>