﻿braindecode.datasets.bids.BIDSIterableDataset
=============================================

.. currentmodule:: braindecode.datasets.bids

.. autoclass:: BIDSIterableDataset
   
   
   
   
      
   
   

.. include:: braindecode.datasets.bids.BIDSIterableDataset.examples

.. raw:: html

    <div style='clear:both'></div>