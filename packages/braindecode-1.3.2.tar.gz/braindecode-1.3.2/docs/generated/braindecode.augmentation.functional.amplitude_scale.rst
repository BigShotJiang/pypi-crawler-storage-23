﻿braindecode.augmentation.functional.amplitude_scale
===================================================

.. currentmodule:: braindecode.augmentation.functional

.. autofunction:: amplitude_scale

.. include:: braindecode.augmentation.functional.amplitude_scale.examples

.. raw:: html

    <div style='clear:both'></div>