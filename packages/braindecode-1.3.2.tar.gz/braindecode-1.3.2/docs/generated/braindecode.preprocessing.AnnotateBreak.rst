﻿braindecode.preprocessing.AnnotateBreak
=======================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: AnnotateBreak
   
   
   
   
      
   
      
   
      
   
      
         
      
   
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: fn

   
   
   

.. include:: braindecode.preprocessing.AnnotateBreak.examples

.. raw:: html

    <div style='clear:both'></div>