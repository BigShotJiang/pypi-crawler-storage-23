﻿braindecode.preprocessing.OversampledTemporalProjection
=======================================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: OversampledTemporalProjection
   
   
   
   
      
   
      
   
      
   
      
         
      
   
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: fn

   
   
   

.. include:: braindecode.preprocessing.OversampledTemporalProjection.examples

.. raw:: html

    <div style='clear:both'></div>