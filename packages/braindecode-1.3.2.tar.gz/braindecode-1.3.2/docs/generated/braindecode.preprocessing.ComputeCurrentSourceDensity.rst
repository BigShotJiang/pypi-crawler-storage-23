﻿braindecode.preprocessing.ComputeCurrentSourceDensity
=====================================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: ComputeCurrentSourceDensity
   
   
   
   
      
   
      
   
      
   
      
         
      
   
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: fn

   
   
   

.. include:: braindecode.preprocessing.ComputeCurrentSourceDensity.examples

.. raw:: html

    <div style='clear:both'></div>