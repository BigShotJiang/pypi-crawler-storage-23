﻿braindecode.preprocessing.AnnotateMovement
==========================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: AnnotateMovement
   
   
   
   
      
   
      
   
      
   
      
         
      
   
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: fn

   
   
   

.. include:: braindecode.preprocessing.AnnotateMovement.examples

.. raw:: html

    <div style='clear:both'></div>