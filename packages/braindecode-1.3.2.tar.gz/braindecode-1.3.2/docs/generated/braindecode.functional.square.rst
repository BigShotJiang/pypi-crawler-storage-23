﻿braindecode.functional.square
=============================

.. currentmodule:: braindecode.functional

.. autofunction:: square

.. include:: braindecode.functional.square.examples

.. raw:: html

    <div style='clear:both'></div>