﻿braindecode.preprocessing.ComputeBridgedElectrodes
==================================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: ComputeBridgedElectrodes
   
   
   
   
      
   
      
   
      
   
      
         
      
   
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: fn

   
   
   

.. include:: braindecode.preprocessing.ComputeBridgedElectrodes.examples

.. raw:: html

    <div style='clear:both'></div>