﻿braindecode.augmentation.functional.gaussian_noise
==================================================

.. currentmodule:: braindecode.augmentation.functional

.. autofunction:: gaussian_noise

.. include:: braindecode.augmentation.functional.gaussian_noise.examples

.. raw:: html

    <div style='clear:both'></div>