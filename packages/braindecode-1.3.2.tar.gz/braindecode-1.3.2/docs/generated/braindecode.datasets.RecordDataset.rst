﻿braindecode.datasets.RecordDataset
==================================

.. currentmodule:: braindecode.datasets

.. autoclass:: RecordDataset
   
   
   
   
      
   
      
         
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: set_description

   
   
   

.. include:: braindecode.datasets.RecordDataset.examples

.. raw:: html

    <div style='clear:both'></div>