﻿braindecode.preprocessing.DelProj
=================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: DelProj
   
   
   
   
      
   
      
   
      
   
      
   
   

.. include:: braindecode.preprocessing.DelProj.examples

.. raw:: html

    <div style='clear:both'></div>