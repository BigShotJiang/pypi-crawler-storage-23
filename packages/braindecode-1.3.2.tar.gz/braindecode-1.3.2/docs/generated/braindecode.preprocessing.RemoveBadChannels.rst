﻿braindecode.preprocessing.RemoveBadChannels
===========================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: RemoveBadChannels
   
   
   
   
      
   
      
   
      
         
      
   
      
   
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: apply_eeg

   
   
   

.. include:: braindecode.preprocessing.RemoveBadChannels.examples

.. raw:: html

    <div style='clear:both'></div>