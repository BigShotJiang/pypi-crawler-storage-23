﻿braindecode.preprocessing.RemoveBadWindows
==========================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: RemoveBadWindows
   
   
   
   
      
   
      
   
      
         
      
   
      
   
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: apply_eeg

   
   
   

.. include:: braindecode.preprocessing.RemoveBadWindows.examples

.. raw:: html

    <div style='clear:both'></div>