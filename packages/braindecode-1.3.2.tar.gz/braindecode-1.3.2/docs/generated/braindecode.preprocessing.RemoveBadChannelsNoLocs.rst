﻿braindecode.preprocessing.RemoveBadChannelsNoLocs
=================================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: RemoveBadChannelsNoLocs
   
   
   
   
      
   
      
   
      
         
      
   
      
   
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: apply_eeg

   
   
   

.. include:: braindecode.preprocessing.RemoveBadChannelsNoLocs.examples

.. raw:: html

    <div style='clear:both'></div>