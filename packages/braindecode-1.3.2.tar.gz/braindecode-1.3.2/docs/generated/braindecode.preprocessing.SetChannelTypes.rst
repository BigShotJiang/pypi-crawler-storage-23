﻿braindecode.preprocessing.SetChannelTypes
=========================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: SetChannelTypes
   
   
   
   
      
   
      
   
      
   
      
   
   

.. include:: braindecode.preprocessing.SetChannelTypes.examples

.. raw:: html

    <div style='clear:both'></div>