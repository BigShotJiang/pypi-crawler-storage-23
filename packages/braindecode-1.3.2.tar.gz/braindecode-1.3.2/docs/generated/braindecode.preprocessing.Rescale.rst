﻿braindecode.preprocessing.Rescale
=================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: Rescale
   
   
   
   
      
   
      
   
      
   
      
   
   

.. include:: braindecode.preprocessing.Rescale.examples

.. raw:: html

    <div style='clear:both'></div>