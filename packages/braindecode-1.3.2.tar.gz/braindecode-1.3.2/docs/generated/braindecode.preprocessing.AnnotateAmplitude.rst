﻿braindecode.preprocessing.AnnotateAmplitude
===========================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: AnnotateAmplitude
   
   
   
   
      
   
      
   
      
   
      
         
      
   
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: fn

   
   
   

.. include:: braindecode.preprocessing.AnnotateAmplitude.examples

.. raw:: html

    <div style='clear:both'></div>