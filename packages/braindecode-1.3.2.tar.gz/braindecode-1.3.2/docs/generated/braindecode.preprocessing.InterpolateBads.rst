﻿braindecode.preprocessing.InterpolateBads
=========================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: InterpolateBads
   
   
   
   
      
   
      
   
      
   
      
   
   

.. include:: braindecode.preprocessing.InterpolateBads.examples

.. raw:: html

    <div style='clear:both'></div>