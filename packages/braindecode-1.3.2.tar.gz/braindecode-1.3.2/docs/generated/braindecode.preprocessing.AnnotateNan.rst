﻿braindecode.preprocessing.AnnotateNan
=====================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: AnnotateNan
   
   
   
   
      
   
      
   
      
   
      
         
      
   
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: fn

   
   
   

.. include:: braindecode.preprocessing.AnnotateNan.examples

.. raw:: html

    <div style='clear:both'></div>