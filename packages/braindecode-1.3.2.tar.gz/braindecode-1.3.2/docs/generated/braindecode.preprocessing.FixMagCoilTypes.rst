﻿braindecode.preprocessing.FixMagCoilTypes
=========================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: FixMagCoilTypes
   
   
   
   
      
   
      
   
      
   
      
   
   

.. include:: braindecode.preprocessing.FixMagCoilTypes.examples

.. raw:: html

    <div style='clear:both'></div>