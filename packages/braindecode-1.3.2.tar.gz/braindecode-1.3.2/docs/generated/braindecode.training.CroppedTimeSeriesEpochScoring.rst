﻿braindecode.training.CroppedTimeSeriesEpochScoring
==================================================

.. currentmodule:: braindecode.training

.. autoclass:: CroppedTimeSeriesEpochScoring
   
   
   
   
      
   
      
   
      
   
      
   
      
   
      
   
      
   
      
         
      
   
      
   
      
   
      
   
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: on_epoch_end

   
   
   

.. include:: braindecode.training.CroppedTimeSeriesEpochScoring.examples

.. raw:: html

    <div style='clear:both'></div>