﻿braindecode.preprocessing.Resampling
====================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: Resampling
   
   
   
   
      
   
      
   
      
         
      
   
      
   
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: apply_eeg

   
   
   

.. include:: braindecode.preprocessing.Resampling.examples

.. raw:: html

    <div style='clear:both'></div>