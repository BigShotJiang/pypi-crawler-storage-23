﻿braindecode.preprocessing.NotchFilter
=====================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: NotchFilter
   
   
   
   
      
   
      
   
      
   
      
   
   

.. include:: braindecode.preprocessing.NotchFilter.examples

.. raw:: html

    <div style='clear:both'></div>