﻿braindecode.preprocessing.RealignRaw
====================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: RealignRaw
   
   
   
   
      
   
      
   
      
   
      
         
      
   
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: fn

   
   
   

.. include:: braindecode.preprocessing.RealignRaw.examples

.. raw:: html

    <div style='clear:both'></div>