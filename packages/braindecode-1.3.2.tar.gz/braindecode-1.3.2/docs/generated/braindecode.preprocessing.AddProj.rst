﻿braindecode.preprocessing.AddProj
=================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: AddProj
   
   
   
   
      
   
      
   
      
   
      
   
   

.. include:: braindecode.preprocessing.AddProj.examples

.. raw:: html

    <div style='clear:both'></div>