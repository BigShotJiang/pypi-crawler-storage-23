﻿braindecode.modules.VarLayer
============================

.. currentmodule:: braindecode.modules

.. autodata:: VarLayer