﻿braindecode.modules.StdLayer
============================

.. currentmodule:: braindecode.modules

.. autodata:: StdLayer