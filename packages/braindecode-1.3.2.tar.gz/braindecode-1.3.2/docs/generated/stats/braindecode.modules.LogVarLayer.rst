﻿braindecode.modules.LogVarLayer
===============================

.. currentmodule:: braindecode.modules

.. autodata:: LogVarLayer