﻿braindecode.preprocessing.SetAnnotations
========================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: SetAnnotations
   
   
   
   
      
   
      
   
      
   
      
   
   

.. include:: braindecode.preprocessing.SetAnnotations.examples

.. raw:: html

    <div style='clear:both'></div>