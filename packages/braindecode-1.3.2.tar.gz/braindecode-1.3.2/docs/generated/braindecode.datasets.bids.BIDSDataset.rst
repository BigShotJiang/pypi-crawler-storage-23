﻿braindecode.datasets.bids.BIDSDataset
=====================================

.. currentmodule:: braindecode.datasets.bids

.. autoclass:: BIDSDataset
   
   
   
   
      
   
      
   
      
   
      
   
      
   
      
   
      
   
      
   
   

.. include:: braindecode.datasets.bids.BIDSDataset.examples

.. raw:: html

    <div style='clear:both'></div>