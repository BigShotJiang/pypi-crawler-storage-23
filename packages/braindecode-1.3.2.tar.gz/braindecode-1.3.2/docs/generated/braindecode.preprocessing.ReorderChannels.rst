﻿braindecode.preprocessing.ReorderChannels
=========================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: ReorderChannels
   
   
   
   
      
   
      
   
      
   
      
   
   

.. include:: braindecode.preprocessing.ReorderChannels.examples

.. raw:: html

    <div style='clear:both'></div>