﻿braindecode.preprocessing.SavgolFilter
======================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: SavgolFilter
   
   
   
   
      
   
      
   
      
   
      
   
   

.. include:: braindecode.preprocessing.SavgolFilter.examples

.. raw:: html

    <div style='clear:both'></div>