﻿braindecode.preprocessing.MaxwellFilter
=======================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: MaxwellFilter
   
   
   
   
      
   
      
   
      
   
      
         
      
   
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: fn

   
   
   

.. include:: braindecode.preprocessing.MaxwellFilter.examples

.. raw:: html

    <div style='clear:both'></div>