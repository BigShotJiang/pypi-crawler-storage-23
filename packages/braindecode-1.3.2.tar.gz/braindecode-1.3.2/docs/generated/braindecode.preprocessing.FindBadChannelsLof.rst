﻿braindecode.preprocessing.FindBadChannelsLof
============================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: FindBadChannelsLof
   
   
   
   
      
   
      
   
      
   
      
         
      
   
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: fn

   
   
   

.. include:: braindecode.preprocessing.FindBadChannelsLof.examples

.. raw:: html

    <div style='clear:both'></div>