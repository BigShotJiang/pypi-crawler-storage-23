﻿braindecode.preprocessing.AnnotateMuscleZscore
==============================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: AnnotateMuscleZscore
   
   
   
   
      
   
      
   
      
   
      
         
      
   
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: fn

   
   
   

.. include:: braindecode.preprocessing.AnnotateMuscleZscore.examples

.. raw:: html

    <div style='clear:both'></div>