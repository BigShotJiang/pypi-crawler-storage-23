﻿braindecode.preprocessing.AddEvents
===================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: AddEvents
   
   
   
   
      
   
      
   
      
   
      
   
   

.. include:: braindecode.preprocessing.AddEvents.examples

.. raw:: html

    <div style='clear:both'></div>