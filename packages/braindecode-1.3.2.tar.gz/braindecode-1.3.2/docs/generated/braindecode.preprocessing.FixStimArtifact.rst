﻿braindecode.preprocessing.FixStimArtifact
=========================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: FixStimArtifact
   
   
   
   
      
   
      
   
      
   
      
         
      
   
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: fn

   
   
   

.. include:: braindecode.preprocessing.FixStimArtifact.examples

.. raw:: html

    <div style='clear:both'></div>