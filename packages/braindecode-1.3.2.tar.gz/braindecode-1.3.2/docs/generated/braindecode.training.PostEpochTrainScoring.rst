﻿braindecode.training.PostEpochTrainScoring
==========================================

.. currentmodule:: braindecode.training

.. autoclass:: PostEpochTrainScoring
   
   
   
   
      
   
      
   
      
   
      
   
      
   
      
   
      
   
      
         
      
   
      
   
      
   
      
   
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: on_epoch_end

   
   
   

.. include:: braindecode.training.PostEpochTrainScoring.examples

.. raw:: html

    <div style='clear:both'></div>