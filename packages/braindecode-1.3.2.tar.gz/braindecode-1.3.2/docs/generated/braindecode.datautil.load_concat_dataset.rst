﻿braindecode.datautil.load_concat_dataset
========================================

.. currentmodule:: braindecode.datautil

.. autofunction:: load_concat_dataset

.. include:: braindecode.datautil.load_concat_dataset.examples

.. raw:: html

    <div style='clear:both'></div>