﻿braindecode.datasets.bids.HubDatasetMixin
=========================================

.. currentmodule:: braindecode.datasets.bids

.. autoclass:: HubDatasetMixin
   
   
   
   
      
   
      
         
      
   
      
         
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: pull_from_hub

   
   .. automethod:: push_to_hub

   
   
   

.. include:: braindecode.datasets.bids.HubDatasetMixin.examples

.. raw:: html

    <div style='clear:both'></div>