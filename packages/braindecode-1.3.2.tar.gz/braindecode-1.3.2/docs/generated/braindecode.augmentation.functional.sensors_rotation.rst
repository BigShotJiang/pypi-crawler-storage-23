﻿braindecode.augmentation.functional.sensors_rotation
====================================================

.. currentmodule:: braindecode.augmentation.functional

.. autofunction:: sensors_rotation

.. include:: braindecode.augmentation.functional.sensors_rotation.examples

.. raw:: html

    <div style='clear:both'></div>