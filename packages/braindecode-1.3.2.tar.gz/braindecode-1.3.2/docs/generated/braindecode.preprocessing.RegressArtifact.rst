﻿braindecode.preprocessing.RegressArtifact
=========================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: RegressArtifact
   
   
   
   
      
   
      
   
      
   
      
         
      
   
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: fn

   
   
   

.. include:: braindecode.preprocessing.RegressArtifact.examples

.. raw:: html

    <div style='clear:both'></div>