﻿braindecode.datasets.bids.BIDSEpochsDataset
===========================================

.. currentmodule:: braindecode.datasets.bids

.. autoclass:: BIDSEpochsDataset
   
   
   
   
      
   
      
   
      
   
      
   
      
   
      
   
      
   
      
   
   

.. include:: braindecode.datasets.bids.BIDSEpochsDataset.examples

.. raw:: html

    <div style='clear:both'></div>