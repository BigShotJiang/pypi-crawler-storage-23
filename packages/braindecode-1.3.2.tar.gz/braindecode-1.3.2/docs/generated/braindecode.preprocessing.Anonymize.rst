﻿braindecode.preprocessing.Anonymize
===================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: Anonymize
   
   
   
   
      
   
      
   
      
   
      
   
   

.. include:: braindecode.preprocessing.Anonymize.examples

.. raw:: html

    <div style='clear:both'></div>