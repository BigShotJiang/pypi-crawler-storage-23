﻿braindecode.samplers.RelativePositioningSampler
===============================================

.. currentmodule:: braindecode.samplers

.. autoclass:: RelativePositioningSampler
   
   
   
   
      
   
      
         
      
   
      
   
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: presample

   
   
   

.. include:: braindecode.samplers.RelativePositioningSampler.examples

.. raw:: html

    <div style='clear:both'></div>