﻿braindecode.augmentation.functional.bandstop_filter
===================================================

.. currentmodule:: braindecode.augmentation.functional

.. autofunction:: bandstop_filter

.. include:: braindecode.augmentation.functional.bandstop_filter.examples

.. raw:: html

    <div style='clear:both'></div>