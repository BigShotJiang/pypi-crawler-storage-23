﻿braindecode.preprocessing.RenameChannels
========================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: RenameChannels
   
   
   
   
      
   
      
   
      
   
      
   
   

.. include:: braindecode.preprocessing.RenameChannels.examples

.. raw:: html

    <div style='clear:both'></div>