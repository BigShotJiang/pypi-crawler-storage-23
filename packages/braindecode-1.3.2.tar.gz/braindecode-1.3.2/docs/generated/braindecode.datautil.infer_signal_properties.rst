﻿braindecode.datautil.infer_signal_properties
============================================

.. currentmodule:: braindecode.datautil

.. autofunction:: infer_signal_properties

.. include:: braindecode.datautil.infer_signal_properties.examples

.. raw:: html

    <div style='clear:both'></div>