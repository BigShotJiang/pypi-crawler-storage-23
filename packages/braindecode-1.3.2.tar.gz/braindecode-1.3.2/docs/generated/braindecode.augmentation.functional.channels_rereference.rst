﻿braindecode.augmentation.functional.channels_rereference
========================================================

.. currentmodule:: braindecode.augmentation.functional

.. autofunction:: channels_rereference

.. include:: braindecode.augmentation.functional.channels_rereference.examples

.. raw:: html

    <div style='clear:both'></div>