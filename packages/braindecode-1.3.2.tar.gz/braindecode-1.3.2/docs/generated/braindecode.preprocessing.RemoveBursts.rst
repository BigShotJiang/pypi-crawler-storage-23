﻿braindecode.preprocessing.RemoveBursts
======================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: RemoveBursts
   
   
   
   
      
   
      
   
      
         
      
   
      
   
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: apply_eeg

   
   
   

.. include:: braindecode.preprocessing.RemoveBursts.examples

.. raw:: html

    <div style='clear:both'></div>