﻿braindecode.preprocessing.EqualizeBads
======================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: EqualizeBads
   
   
   
   
      
   
      
   
      
   
      
         
      
   
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: fn

   
   
   

.. include:: braindecode.preprocessing.EqualizeBads.examples

.. raw:: html

    <div style='clear:both'></div>