﻿braindecode.preprocessing.CombineChannels
=========================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: CombineChannels
   
   
   
   
      
   
      
   
      
   
      
         
      
   
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: fn

   
   
   

.. include:: braindecode.preprocessing.CombineChannels.examples

.. raw:: html

    <div style='clear:both'></div>