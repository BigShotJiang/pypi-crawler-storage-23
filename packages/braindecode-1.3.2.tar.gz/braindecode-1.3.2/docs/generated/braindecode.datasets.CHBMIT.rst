﻿braindecode.datasets.CHBMIT
===========================

.. currentmodule:: braindecode.datasets

.. autoclass:: CHBMIT
   
   
   
   
      
   
      
   
      
   
      
   
      
   
      
   
      
   
      
   
   

.. include:: braindecode.datasets.CHBMIT.examples

.. raw:: html

    <div style='clear:both'></div>