﻿braindecode.preprocessing.FilterData
====================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: FilterData
   
   
   
   
      
   
      
   
      
   
      
         
      
   
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: fn

   
   
   

.. include:: braindecode.preprocessing.FilterData.examples

.. raw:: html

    <div style='clear:both'></div>