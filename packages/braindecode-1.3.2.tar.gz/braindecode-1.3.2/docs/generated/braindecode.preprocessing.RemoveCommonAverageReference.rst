﻿braindecode.preprocessing.RemoveCommonAverageReference
======================================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: RemoveCommonAverageReference
   
   
   
   
      
   
      
   
      
         
      
   
      
   
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: apply_eeg

   
   
   

.. include:: braindecode.preprocessing.RemoveCommonAverageReference.examples

.. raw:: html

    <div style='clear:both'></div>