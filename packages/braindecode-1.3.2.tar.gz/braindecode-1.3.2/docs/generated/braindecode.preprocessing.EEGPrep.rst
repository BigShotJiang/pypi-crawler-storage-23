﻿braindecode.preprocessing.EEGPrep
=================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: EEGPrep
   
   
   
   
      
   
      
   
      
         
      
   
      
   
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: apply_eeg

   
   
   

.. include:: braindecode.preprocessing.EEGPrep.examples

.. raw:: html

    <div style='clear:both'></div>