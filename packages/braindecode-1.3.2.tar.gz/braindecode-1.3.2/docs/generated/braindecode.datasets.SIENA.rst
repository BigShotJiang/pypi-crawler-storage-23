﻿braindecode.datasets.SIENA
==========================

.. currentmodule:: braindecode.datasets

.. autoclass:: SIENA
   
   
   
   
      
   
      
   
      
   
      
   
      
   
      
   
      
   
      
   
   

.. include:: braindecode.datasets.SIENA.examples

.. raw:: html

    <div style='clear:both'></div>