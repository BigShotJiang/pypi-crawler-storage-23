﻿braindecode.preprocessing.RemoveFlatChannels
============================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: RemoveFlatChannels
   
   
   
   
      
   
      
   
      
         
      
   
      
   
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: apply_eeg

   
   
   

.. include:: braindecode.preprocessing.RemoveFlatChannels.examples

.. raw:: html

    <div style='clear:both'></div>