﻿braindecode.preprocessing.AddReferenceChannels
==============================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: AddReferenceChannels
   
   
   
   
      
   
      
   
      
   
      
   
   

.. include:: braindecode.preprocessing.AddReferenceChannels.examples

.. raw:: html

    <div style='clear:both'></div>