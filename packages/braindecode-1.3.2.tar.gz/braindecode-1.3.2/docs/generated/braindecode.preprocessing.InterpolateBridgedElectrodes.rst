﻿braindecode.preprocessing.InterpolateBridgedElectrodes
======================================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: InterpolateBridgedElectrodes
   
   
   
   
      
   
      
   
      
   
      
         
      
   
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: fn

   
   
   

.. include:: braindecode.preprocessing.InterpolateBridgedElectrodes.examples

.. raw:: html

    <div style='clear:both'></div>