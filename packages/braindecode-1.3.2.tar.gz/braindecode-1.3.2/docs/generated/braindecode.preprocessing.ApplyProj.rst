﻿braindecode.preprocessing.ApplyProj
===================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: ApplyProj
   
   
   
   
      
   
      
   
      
   
      
   
   

.. include:: braindecode.preprocessing.ApplyProj.examples

.. raw:: html

    <div style='clear:both'></div>