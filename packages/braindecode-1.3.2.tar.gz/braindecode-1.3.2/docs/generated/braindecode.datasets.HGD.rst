﻿braindecode.datasets.HGD
========================

.. currentmodule:: braindecode.datasets

.. autoclass:: HGD
   
   
   
   
      
   
      
   
      
   
      
   
      
   
      
   
      
   
      
   
   

.. include:: braindecode.datasets.HGD.examples

.. raw:: html

    <div style='clear:both'></div>