﻿braindecode.preprocessing.SetMontage
====================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: SetMontage
   
   
   
   
      
   
      
   
      
   
      
   
   

.. include:: braindecode.preprocessing.SetMontage.examples

.. raw:: html

    <div style='clear:both'></div>