

.. _sphx_glr_auto_examples_advanced_training:


Advanced neural network training strategies
-------------------------------------------

Examples explaining more advanced topics in neural network training strategies.



.. raw:: html

    <div class="sphx-glr-thumbnails">

.. thumbnail-parent-div-open

.. raw:: html

    <div class="sphx-glr-thumbcontainer" tooltip="This tutorial shows you how to train and test deep learning models with Braindecode on ECoG BCI IV competition dataset 4 using cropped mode. For this dataset we will predict 5 regression targets corresponding to flexion of each finger. The targets were recorded as a time series (each 25 Hz), so this tutorial is an example of time series target prediction.">

.. only:: html

  .. image:: /auto_examples/advanced_training/images/thumb/sphx_glr_bcic_iv_4_ecog_cropped_thumb.png
    :alt:

  :doc:`/auto_examples/advanced_training/bcic_iv_4_ecog_cropped`

.. raw:: html

      <div class="sphx-glr-thumbnail-title">Fingers flexion cropped decoding on BCIC IV 4 ECoG Dataset</div>
    </div>


.. raw:: html

    <div class="sphx-glr-thumbcontainer" tooltip="This tutorial shows how to train EEG deep models with data augmentation. It follows the trial-wise decoding example and also illustrates the effect of a transform on the input signals.">

.. only:: html

  .. image:: /auto_examples/advanced_training/images/thumb/sphx_glr_plot_data_augmentation_thumb.png
    :alt:

  :doc:`/auto_examples/advanced_training/plot_data_augmentation`

.. raw:: html

      <div class="sphx-glr-thumbnail-title">Data Augmentation on BCIC IV 2a Dataset</div>
    </div>


.. raw:: html

    <div class="sphx-glr-thumbcontainer" tooltip="This tutorial shows how to search data augmentations using braindecode. Indeed, it is known that the best augmentation to use often dependent on the task or phenomenon studied. Here we follow the methodology proposed in [1]_ on the openly available BCI IV 2a Dataset.">

.. only:: html

  .. image:: /auto_examples/advanced_training/images/thumb/sphx_glr_plot_data_augmentation_search_thumb.png
    :alt:

  :doc:`/auto_examples/advanced_training/plot_data_augmentation_search`

.. raw:: html

      <div class="sphx-glr-thumbnail-title">Searching the best data augmentation on BCIC IV 2a Dataset</div>
    </div>


.. raw:: html

    <div class="sphx-glr-thumbcontainer" tooltip="This example shows how to use the pydantic and exca libraries to configure and run EEG experiments with Braindecode.">

.. only:: html

  .. image:: /auto_examples/advanced_training/images/thumb/sphx_glr_plot_exca_config_thumb.png
    :alt:

  :doc:`/auto_examples/advanced_training/plot_exca_config`

.. raw:: html

      <div class="sphx-glr-thumbnail-title">Experiment configuration with Pydantic and Exca</div>
    </div>


.. raw:: html

    <div class="sphx-glr-thumbcontainer" tooltip="Foundation models are large-scale pre-trained models that serve as a starting point for a wide range of downstream tasks, leveraging their generalization capabilities. Fine-tuning these models is necessary to adapt them to specific tasks or datasets, ensuring optimal performance in specialized applications.">

.. only:: html

  .. image:: /auto_examples/advanced_training/images/thumb/sphx_glr_plot_finetune_foundation_model_thumb.png
    :alt:

  :doc:`/auto_examples/advanced_training/plot_finetune_foundation_model`

.. raw:: html

      <div class="sphx-glr-thumbnail-title">Fine-tuning a Foundation Model (Signal-JEPA)</div>
    </div>


.. raw:: html

    <div class="sphx-glr-thumbcontainer" tooltip="Cross-session motor imagery with deep learning EEGNet v4 model">

.. only:: html

  .. image:: /auto_examples/advanced_training/images/thumb/sphx_glr_plot_moabb_benchmark_thumb.png
    :alt:

  :doc:`/auto_examples/advanced_training/plot_moabb_benchmark`

.. raw:: html

      <div class="sphx-glr-thumbnail-title">Cross-session motor imagery with deep learning EEGNet v4 model</div>
    </div>


.. raw:: html

    <div class="sphx-glr-thumbcontainer" tooltip="This example shows how to train a neural network with self-supervision on sleep EEG data. We follow the relative positioning approach of [1]_ on the openly accessible Sleep Physionet dataset [2]_ [3]_.">

.. only:: html

  .. image:: /auto_examples/advanced_training/images/thumb/sphx_glr_plot_relative_positioning_thumb.png
    :alt:

  :doc:`/auto_examples/advanced_training/plot_relative_positioning`

.. raw:: html

      <div class="sphx-glr-thumbnail-title">Self-supervised learning on EEG with relative positioning</div>
    </div>


.. raw:: html

    <div class="sphx-glr-thumbcontainer" tooltip="In this tutorial, we will show you how to use the Braindecode library to decode EEG data over time. The problem of decoding EEG data over time is formulated as fitting a multivariate predictive model on each time point of the signal and then evaluating the performance of the model at the same time point in new epoched data. Specifically, given a pair of features X and targets y, where X has more than 2 dimensions, we want to fit a model f to X and y and evaluate the performance of f on a new pair of features X&#x27; and targets y&#x27;. Typically, X is in the shape of n_{\text{epochs}} \times n_{\text{channels}} \times n_{\text{time}} and y is in the shape of n_{\text{epochs}} \times n_{\text{classes}}. This tutorial is based on the MNE tutorial: https://mne.tools/stable/auto_tutorials/machine-learning/50_decoding.html#temporal-decoding.">

.. only:: html

  .. image:: /auto_examples/advanced_training/images/thumb/sphx_glr_plot_temporal_generalization_thumb.png
    :alt:

  :doc:`/auto_examples/advanced_training/plot_temporal_generalization`

.. raw:: html

      <div class="sphx-glr-thumbnail-title">Temporal generalization with Braindecode</div>
    </div>


.. thumbnail-parent-div-close

.. raw:: html

    </div>


.. toctree::
   :hidden:

   /auto_examples/advanced_training/bcic_iv_4_ecog_cropped
   /auto_examples/advanced_training/plot_data_augmentation
   /auto_examples/advanced_training/plot_data_augmentation_search
   /auto_examples/advanced_training/plot_exca_config
   /auto_examples/advanced_training/plot_finetune_foundation_model
   /auto_examples/advanced_training/plot_moabb_benchmark
   /auto_examples/advanced_training/plot_relative_positioning
   /auto_examples/advanced_training/plot_temporal_generalization

