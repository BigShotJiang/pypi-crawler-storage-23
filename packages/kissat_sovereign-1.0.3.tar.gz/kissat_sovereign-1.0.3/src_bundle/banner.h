#ifndef _banner_h_INCLUDED
#define _banner_h_INCLUDED

#define LIGHT_BLUE  "\033[1;34m"
#define NORMAL      "\033[0m"

void kissat_banner (const char * name, const char * description);

#endif
