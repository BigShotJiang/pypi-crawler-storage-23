#ifndef _search_h_INCLUDED
#define _search_h_INCLUDED

struct kissat;

int kissat_search (struct kissat *);

#endif
