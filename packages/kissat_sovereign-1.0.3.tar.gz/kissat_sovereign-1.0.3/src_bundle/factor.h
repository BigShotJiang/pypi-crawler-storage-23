#ifndef _factor_h_INCLUDED
#define _factor_h_INCLUDED

#include <stdbool.h>

struct kissat;
void kissat_factor (struct kissat *);

#endif
