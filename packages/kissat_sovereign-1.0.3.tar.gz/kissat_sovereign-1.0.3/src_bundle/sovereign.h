#ifndef _sovereign_h_INCLUDED
#define _sovereign_h_INCLUDED

#include "internal.h"

void sovereign_launch_parallel (struct kissat *);
void *sovereign_logic_bridge (void *);

#endif
