# KernelBoost

**Gradient boosting with kernel-based local constant estimators**

![Python](https://img.shields.io/badge/python-%3E%3D3.9-blue)
![NumPy](https://img.shields.io/badge/NumPy-array%20backend-blue)
![C](https://img.shields.io/badge/C-language-blue)
![GPU](https://img.shields.io/badge/GPU-CUDA%20C%2FCuPy-orange)
![License](https://img.shields.io/badge/license-MIT-green)
![Version](https://img.shields.io/badge/version-0.2.0-blue)

KernelBoost is a gradient boosting algorithm that uses Nadaraya-Watson (local constant) kernel estimators as base learners instead of decision trees. It has:

- Support for regression, classification and quantile regression tasks.
- sklearn style API (`fit`, `predict`).
- CPU (via C) and GPU (via CuPy/CUDA) backends.

## Installation

```bash
# Basic installation
pip install kernelboost

# With GPU support (requires CUDA)
pip install cupy-cuda12x  # for CUDA 12
```

> **Dependencies**: NumPy only. CuPy optional for GPU acceleration.

## Quick Start

```python
from kernelboost import KernelBooster, MulticlassBooster
from kernelboost.objectives import MSEObjective, EntropyObjective

# Regression
booster = KernelBooster(objective=MSEObjective()).fit(X_train, y_train)
predictions = booster.predict(X_test)

# Binary classification
booster = KernelBooster(objective=EntropyObjective()).fit(X_train, y_train)
logits = booster.predict(X_test)
probabilities = booster.predict_proba(X_test)

# Multiclass classification (fits one booster per class)
booster = MulticlassBooster().fit(X_train, y_train)
class_labels = booster.predict(X_test)
```

## Documentation

For full documentation, benchmarks, architecture details, and API reference, see the [GitHub repository](https://github.com/tlaiho/kernelboost).

## License

MIT License
