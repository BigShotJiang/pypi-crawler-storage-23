from typing import TypedDict


class DirectV2ThreadsUnmuteResponse(TypedDict):
    pass
