from typing import TypedDict


class DirectV2ThreadsAddUserResponse(TypedDict):
    pass
