from typing import TypedDict


class DirectV2ThreadsDeleteItemsLocallyResponse(TypedDict):
    status: str
    status_code: str
