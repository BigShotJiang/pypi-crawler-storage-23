from typing import TypedDict


class DirectV2ThreadsApproveMultipleResponse(TypedDict):
    pass
