from typing import TypedDict


class DirectV2ThreadsDeclineAllResponse(TypedDict):
    pass
