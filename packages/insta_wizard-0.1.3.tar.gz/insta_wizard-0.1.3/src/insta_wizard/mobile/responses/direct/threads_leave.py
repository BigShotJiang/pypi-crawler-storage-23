from typing import TypedDict


class DirectV2ThreadsLeaveResponse(TypedDict):
    pass
