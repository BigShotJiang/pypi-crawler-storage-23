from typing import TypedDict


class DirectV2HasInteropUpgradedResponse(TypedDict):
    pass
