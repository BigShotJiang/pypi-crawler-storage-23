from typing import TypedDict


class DirectV2RankedRecipientsResponse(TypedDict):
    pass
