from typing import TypedDict


class DirectV2ThreadsItemsDeleteResponse(TypedDict):
    status: str
    status_code: str
