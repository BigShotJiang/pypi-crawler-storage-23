from typing import TypedDict


class ChallengeActionResponse(TypedDict):
    pass
