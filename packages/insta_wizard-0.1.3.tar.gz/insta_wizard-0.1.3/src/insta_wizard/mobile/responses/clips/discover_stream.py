from typing import TypedDict


class ClipsDiscoverStreamResponse(TypedDict):
    pass
