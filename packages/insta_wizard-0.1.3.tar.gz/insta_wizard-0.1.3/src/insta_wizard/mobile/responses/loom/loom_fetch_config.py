from typing import TypedDict


class LoomFetchConfigResponse(TypedDict):
    GATE_APP_VERSION: bool
    status: str
