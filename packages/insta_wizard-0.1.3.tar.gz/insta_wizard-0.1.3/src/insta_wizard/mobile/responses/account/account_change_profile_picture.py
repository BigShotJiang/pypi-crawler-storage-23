from typing import TypedDict


class AccountChangeProfilePictureResponse(TypedDict):
    pass
