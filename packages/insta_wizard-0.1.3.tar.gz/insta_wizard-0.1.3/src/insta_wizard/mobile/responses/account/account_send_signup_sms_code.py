from typing import TypedDict


class AccountSendSignupSmsCodeResponse(TypedDict):
    pass
