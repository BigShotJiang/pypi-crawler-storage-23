from typing import TypedDict


class AccountUsernameSuggestionsResponse(TypedDict):
    pass
