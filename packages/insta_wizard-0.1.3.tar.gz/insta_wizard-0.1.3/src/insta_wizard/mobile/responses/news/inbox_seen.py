class NewsInboxSeenResponse:
    pass
