from typing import TypedDict


class BloksProcessClientDataAndRedirectBApiResponse(TypedDict):
    pass
