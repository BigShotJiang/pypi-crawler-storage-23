from typing import TypedDict


class BloksPhoneNumberPrefillAsyncResponse(TypedDict):
    pass
