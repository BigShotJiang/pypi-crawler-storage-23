from typing import TypedDict


class BloksSendLoginRequestResponse(TypedDict):
    pass
