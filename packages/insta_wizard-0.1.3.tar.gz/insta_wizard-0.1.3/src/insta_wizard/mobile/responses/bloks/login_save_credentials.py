from typing import TypedDict


class BloksLoginSaveCredentialsBApiResponse(TypedDict):
    pass
