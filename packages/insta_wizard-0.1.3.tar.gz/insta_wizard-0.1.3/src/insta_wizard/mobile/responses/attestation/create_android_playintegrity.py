from typing import TypedDict


class AttestationCreateAndroidPlayIntegrityResponse(TypedDict):
    challenge_nonce: str
    status: str
