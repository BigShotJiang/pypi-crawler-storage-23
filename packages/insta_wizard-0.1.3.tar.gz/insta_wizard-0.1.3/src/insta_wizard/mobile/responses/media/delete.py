from typing import TypedDict


class MediaDeleteResponse(TypedDict):
    pass
