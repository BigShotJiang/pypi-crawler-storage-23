from typing import TypedDict


class MediaSaveResponse(TypedDict):
    status: str
