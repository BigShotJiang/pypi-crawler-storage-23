from typing import TypedDict


class MediaEditResponse(TypedDict):
    pass
