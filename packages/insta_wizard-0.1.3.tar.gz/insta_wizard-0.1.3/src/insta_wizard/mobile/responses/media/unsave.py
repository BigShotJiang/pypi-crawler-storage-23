from typing import TypedDict


class MediaUnsaveResponse(TypedDict):
    status: str
