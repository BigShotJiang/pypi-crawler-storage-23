from typing import TypedDict


class MediaCommentBulkDeleteResponse(TypedDict):
    pass
