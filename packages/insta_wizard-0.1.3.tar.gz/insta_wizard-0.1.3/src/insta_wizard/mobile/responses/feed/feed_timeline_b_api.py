from typing import TypedDict


class FeedTimelineBApiResponse(TypedDict):
    pass
