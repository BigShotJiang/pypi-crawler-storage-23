from typing import TypedDict


class FeedTimelineIApiResponse(TypedDict):
    pass
