from typing import TypedDict


class FeedGetReelsTrayResponse(TypedDict):
    pass
