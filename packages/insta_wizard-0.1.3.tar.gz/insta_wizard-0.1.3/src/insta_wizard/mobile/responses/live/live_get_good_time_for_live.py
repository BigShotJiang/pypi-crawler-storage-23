from typing import TypedDict


class LiveGetGoodTimeForLiveResponse(TypedDict):
    status: str
