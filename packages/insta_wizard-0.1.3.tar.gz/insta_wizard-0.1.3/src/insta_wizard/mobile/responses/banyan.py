from typing import TypedDict


class BanyanBanyanResponse(TypedDict):
    pass
