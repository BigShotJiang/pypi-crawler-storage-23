from typing import TypedDict


class FetchRmdResponse(TypedDict):
    pass
