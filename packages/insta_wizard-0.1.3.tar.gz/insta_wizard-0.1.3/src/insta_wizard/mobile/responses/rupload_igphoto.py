from typing import TypedDict


class RuploadIgphotoResponse(TypedDict):
    pass
