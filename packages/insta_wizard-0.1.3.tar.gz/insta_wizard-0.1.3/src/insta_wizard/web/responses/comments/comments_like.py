from typing import TypedDict


class CommentsLikeResponse(TypedDict):
    status: str
