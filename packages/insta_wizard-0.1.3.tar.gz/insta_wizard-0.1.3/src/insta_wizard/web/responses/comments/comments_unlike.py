from typing import TypedDict


class CommentsUnlikeResponse(TypedDict):
    status: str
