from typing import Any, TypeAlias

PolarisSearchBoxRefetchableQueryResponse: TypeAlias = dict[str, Any]
