from typing import Any, TypeAlias

ChallengeWebResponse: TypeAlias = dict[str, Any]
