from typing import Any, TypeAlias

UseAuthPlatformSendCodeAgainMutationResponse: TypeAlias = dict[str, Any]
