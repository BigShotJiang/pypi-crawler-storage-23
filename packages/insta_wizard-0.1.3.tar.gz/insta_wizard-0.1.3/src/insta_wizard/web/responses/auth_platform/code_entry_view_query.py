from typing import Any, TypeAlias

AuthPlatformCodeEntryViewQueryResponse: TypeAlias = dict[str, Any]
