from typing import Any, TypeAlias

UseAuthPlatformSubmitCodeMutationResponse: TypeAlias = dict[str, Any]
