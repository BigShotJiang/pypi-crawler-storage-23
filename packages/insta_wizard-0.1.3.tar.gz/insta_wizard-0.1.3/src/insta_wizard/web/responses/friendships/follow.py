from typing import Any, TypeAlias

FriendshipsFollowResponse: TypeAlias = dict[str, Any]
