from typing import TypeAlias

GetInstagramHomePageResponse: TypeAlias = str
