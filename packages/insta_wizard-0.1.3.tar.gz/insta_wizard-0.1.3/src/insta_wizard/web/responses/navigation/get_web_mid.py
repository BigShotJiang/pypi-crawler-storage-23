from typing import TypeAlias

GetWebMidResponse: TypeAlias = str
