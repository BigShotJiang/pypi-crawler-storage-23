from typing import TypeAlias

GetEmailSignupPageResponse: TypeAlias = str
