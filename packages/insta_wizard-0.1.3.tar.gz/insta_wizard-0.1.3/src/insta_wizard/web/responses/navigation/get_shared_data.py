from typing import Any, TypeAlias

GetSharedDataResponse: TypeAlias = dict[str, Any]
