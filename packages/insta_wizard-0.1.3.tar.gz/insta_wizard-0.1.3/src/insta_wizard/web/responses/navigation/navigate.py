from typing import TypeAlias

NavigateResponse: TypeAlias = str
