from typing import TypedDict


class LikesLikeResponse(TypedDict):
    status: str
