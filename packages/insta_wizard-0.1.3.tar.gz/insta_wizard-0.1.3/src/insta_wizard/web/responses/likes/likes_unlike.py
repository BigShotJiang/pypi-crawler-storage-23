from typing import TypedDict


class LikesUnlikeResponse(TypedDict):
    status: str
