from typing import Any, TypeAlias

WebCreateAjaxResponse: TypeAlias = dict[str, Any]
