from typing import TypedDict


class AccountsEditResponse(TypedDict):
    pass
