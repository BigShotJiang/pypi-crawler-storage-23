from typing import Any, TypeAlias

SendSignupSmsCodeAjaxResponse: TypeAlias = dict[str, Any]
