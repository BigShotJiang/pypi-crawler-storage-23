from typing import TypedDict


class AccountsLogoutAjaxResponse(TypedDict):
    pass
