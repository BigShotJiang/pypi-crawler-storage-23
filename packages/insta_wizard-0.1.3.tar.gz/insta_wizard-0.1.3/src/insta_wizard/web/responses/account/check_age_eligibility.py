from typing import Any, TypeAlias

CheckAgeEligibilityResponse: TypeAlias = dict[str, Any]
