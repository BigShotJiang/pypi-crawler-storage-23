from typing import Any, TypeAlias

WebCreateAjaxAttemptResponse: TypeAlias = dict[str, Any]
