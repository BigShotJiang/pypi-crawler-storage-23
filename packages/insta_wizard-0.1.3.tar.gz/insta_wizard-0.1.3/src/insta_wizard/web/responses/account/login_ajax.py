from typing import Any, TypeAlias

AccountsLoginAjaxResponse: TypeAlias = dict[str, Any]
