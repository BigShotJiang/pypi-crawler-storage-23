from typing import Any, TypeAlias

AccountRecoverySendAjaxResponse: TypeAlias = dict[str, Any]
