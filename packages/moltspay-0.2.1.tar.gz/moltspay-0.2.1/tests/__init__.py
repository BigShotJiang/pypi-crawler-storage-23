"""MoltsPay tests."""
