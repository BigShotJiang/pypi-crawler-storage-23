"""HTTP client with auto-refresh for Registry API"""

import logging
from typing import Optional

import httpx

from cli import settings
from cli.config import (
    CLIConfig,
    clear_token,
    load_config,
    save_config,
    validate_token,
)

logger = logging.getLogger(__name__)


class RegistryClient:
    """HTTP client for Registry API with auto-refresh on 401/403"""

    def __init__(self, config: Optional[CLIConfig] = None):
        self.config = config or load_config()
        self._client = httpx.Client(
            timeout=30.0,
            headers={"User-Agent": settings.user_agent()},
        )

    def _get_headers(self) -> dict[str, str]:
        """Get request headers including auth token if available"""
        headers = {"Content-Type": "application/json"}
        if self.config.access_token:
            headers["Authorization"] = f"Bearer {self.config.access_token}"
        return headers

    def _refresh_token(self) -> bool:
        """Refresh the access token via /v1/oauth/refresh."""
        if not self.config.refresh_token:
            logger.warning("No refresh token available")
            clear_token(self.config)
            return False

        try:
            from datetime import datetime, timedelta, timezone

            response = self._client.post(
                f"{self.config.auth_url}/v1/oauth/refresh",
                json={
                    "grant_type": "refresh_token",
                    "refresh_token": self.config.refresh_token,
                    "client_id": self.config.client_id,
                },
            )
            response.raise_for_status()
            token_data = response.json()

            access_token = token_data["access_token"]
            claims = validate_token(access_token)
            if claims is None:
                logger.warning("Refreshed token failed validation")
                clear_token(self.config)
                return False

            token_expires_in = token_data.get("expires_in", 3600)
            expires_at = datetime.now(timezone.utc) + timedelta(
                seconds=token_expires_in
            )

            self.config.access_token = access_token
            if "refresh_token" in token_data:
                self.config.refresh_token = token_data["refresh_token"]
            self.config.token_expires_at = expires_at.isoformat()
            save_config(self.config)

            logger.info("Token refreshed successfully")
            return True

        except Exception as e:
            logger.warning("Token refresh failed: %s", e)
            clear_token(self.config)
            return False

    def _request(
        self,
        method: str,
        path: str,
        json: Optional[dict] = None,
        retry_auth: bool = True,
    ) -> httpx.Response:
        """Make an authenticated request with auto-refresh on 401."""
        url = f"{self.config.api_url}{path}"
        headers = self._get_headers()

        response = self._client.request(method, url, json=json, headers=headers)

        if response.status_code in (401, 403) and retry_auth:
            logger.info("Token expired, attempting refresh...")
            if self._refresh_token():
                headers = self._get_headers()
                response = self._client.request(method, url, json=json, headers=headers)

        return response

    def get(self, path: str) -> httpx.Response:
        return self._request("GET", path)

    def post(self, path: str, json: Optional[dict] = None) -> httpx.Response:
        return self._request("POST", path, json=json)

    def patch(self, path: str, json: Optional[dict] = None) -> httpx.Response:
        return self._request("PATCH", path, json=json)

    def delete(self, path: str) -> httpx.Response:
        return self._request("DELETE", path)

    def close(self) -> None:
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
