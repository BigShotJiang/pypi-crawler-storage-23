"""MCP server for AIMemory."""

from aimemory.mcp.bridge import MemoryBridge

__all__ = ["MemoryBridge"]
