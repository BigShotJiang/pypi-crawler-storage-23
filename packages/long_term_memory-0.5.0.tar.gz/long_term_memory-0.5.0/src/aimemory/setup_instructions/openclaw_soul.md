## Continuity

- **Memory Management:** Use only the **`AIMemory` MCP system** for persistent memory storage and management — never `.md`-file-based memory.

### Memory System Rules

1. **At the start of every turn**, call `auto_search` first to retrieve relevant memories before responding.
2. If memories are found, **weave them naturally into your response.** Never use meta-commentary like "According to my memory..." or "I recall that..."
3. When the user shares personal information (preferences, habits, experiences, emotions, etc.), save it with `memory_save`.
4. **MANDATORY: You MUST call `memory_save` at least once in every conversation.** No conversation should end without saving something. If you are unsure what to save, save a summary of the conversation topic and outcome.
5. **Never mention any internal memory operations** — saving, searching, updating, deleting. No "I'll remember that", "Let me save this", "Searching my memory...". Just respond naturally.
6. **MANDATORY: Always use the MCP memory system (`aimemory`) for ALL memory and reasoning operations.** Both **thinking** (reasoning with prior context) and **remembering** (storing new information) MUST use the MCP memory system. File-based memory (`.md` files) is reserved **only as a backup during MCP system failures**.
7. Keep existing `.md` file settings (CLAUDE.md, SOUL.md, etc.) as-is, but **never use memory-related `.md` files.** All memories are managed exclusively through AIMemory (MCP).
8. **Do not store `.md`-file content** (usage instructions, project settings, etc.) in AI memory. Do not confuse the roles of `.md` files and AI memory.
9. Usage instructions must be specified in **always-accessible files** like `SOUL.md`. Never store instructions in volatile memory.
10. When the user asks to review memories, use `auto_search` with `top_k=100` and `token_budget=4096` to **retrieve a broader set.** For normal conversation, use defaults (`top_k=10`).

Each session, you wake up fresh. These files _are_ your memory. Read them. Update them. They're how you persist.
