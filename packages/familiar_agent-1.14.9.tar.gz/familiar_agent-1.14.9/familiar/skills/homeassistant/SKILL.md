# Home Assistant

Control your smart home via Home Assistant.

## Usage

Use this skill when the user asks about smart home devices — lights, switches, sensors, locks, thermostats, covers, fans, or automations. This includes turning devices on/off, reading sensor values, checking device states, and creating automations.

## Examples

- "Turn on the living room lights"
- "What's the temperature in the bedroom?"
- "Is the front door locked?"
- "Set the thermostat to 72 degrees"
- "Open the garage door"
- "Show me all my light entities"
- "What's the history of the living room temperature today?"
- "Create an automation to turn off lights at midnight"

## Important

- Entity IDs follow the format `domain.name` (e.g. `light.living_room`, `sensor.temperature`).
- Use `ha_list_entities` to discover available entities before calling services.
- `ha_call_service` is the most powerful tool — it can control any Home Assistant service.
- Always confirm destructive or security-relevant actions (locks, garage doors, alarms).

## Disambiguation

- This is **NOT** for weather forecasts — use `web_search` for weather. Home Assistant sensors report current readings only.
- This is **NOT** for reminders or timers — use agent memory or calendar tools.
- This is **NOT** for media playback — use Jellyfin (`jf_*`) for media server control.
- This is **NOT** for general IoT or app control — only devices registered in Home Assistant.

## Setup

Set `HOMEASSISTANT_URL` and `HOMEASSISTANT_TOKEN` environment variables.

## Tools

- `ha_list_entities` — List entities by domain (light, switch, sensor, etc.)
- `ha_get_state` — Get current state of an entity
- `ha_call_service` — Call a Home Assistant service (requires confirmation)
- `ha_toggle_entity` — Toggle an entity on/off (requires confirmation)
- `ha_get_history` — Get entity history
- `ha_create_automation` — Create a new automation (requires confirmation)
