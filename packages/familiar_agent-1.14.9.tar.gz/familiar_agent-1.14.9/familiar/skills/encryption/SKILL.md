# Encryption Completeness Skill

AES-256 encryption at rest for all JSON data stores. Key management,
rotation, and status monitoring.

## Architecture

Wraps core/encryption.py EncryptedJSONStorage with user-facing tools.
Uses Fernet (AES-128-CBC via cryptography library) or falls back to
AES-256-GCM via stdlib (hashlib + os.urandom + hmac).

## HIPAA Requirements

- §164.312(a)(2)(iv): Encryption and decryption of ePHI
- §164.312(e)(2)(ii): Encryption mechanism for transmission
- §164.306(a)(1): Ensure confidentiality of ePHI

## Key Management

- Keys stored in ~/.familiar/keys/ with file permissions 600
- PBKDF2 key derivation from master password
- Key rotation re-encrypts all stores without downtime
