# Voice / Transcription Skill

Lightweight audio transcription, voice notes, and dictation.
Complements the full voice skill with simple file-based workflows.

## Usage

- Transcribe audio files (WAV, MP3, M4A, OGG, FLAC)
- Quick voice notes: save transcription as knowledge base entry
- Dictation to text: transcribe and return as editable text
- View transcription history

## Backends (in order of preference)

1. faster-whisper (fast, local, GPU-accelerated)
2. openai-whisper (local, original)
3. OpenAI Whisper API (cloud, requires API key)

## Relationship to Existing Voice Skill

The existing skills/voice/ provides live transcription, TTS,
document reading, and meeting transcription with speaker diarization.
This skill focuses on:
- Simple file → text transcription
- Voice note workflow (transcribe + save to knowledge base)
- Dictation mode (transcribe + return for editing)
- Transcription history/search
