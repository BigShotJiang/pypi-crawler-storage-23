# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""
Familiar Constants

Centralized constants and enums used across the application.
Eliminates magic strings and provides type safety.

Usage:
    from familiar.core.constants import Role, Channel, Category

    if message.role == Role.USER:
        ...
"""

from enum import Enum


class Role(str, Enum):
    """Message roles in conversations."""

    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"
    TOOL = "tool"


class Channel(str, Enum):
    """Communication channels."""

    CLI = "cli"
    TELEGRAM = "telegram"
    DISCORD = "discord"
    IMESSAGE = "imessage"
    WHATSAPP = "whatsapp"
    SIGNAL = "signal"
    SMS = "sms"
    WEB = "web"
    INTERNAL = "internal"  # For scheduled tasks, etc.


class MemoryCategory(str, Enum):
    """Categories for stored memories."""

    USER_INFO = "user_info"
    PREFERENCE = "preference"
    FACT = "fact"
    TASK = "task"
    RELATIONSHIP = "relationship"
    SKILL = "skill"
    INTEREST = "interest"


class ToolCategory(str, Enum):
    """Categories for tools."""

    SYSTEM = "system"
    FILESYSTEM = "filesystem"
    NETWORK = "network"
    MEMORY = "memory"
    UTILITY = "utility"
    BROWSER = "browser"
    EMAIL = "email"
    CALENDAR = "calendar"
    TRIGGERS = "triggers"
    VOICE = "voice"
    KNOWLEDGE = "knowledge"


class Provider(str, Enum):
    """LLM providers."""

    ANTHROPIC = "anthropic"
    CLAUDE = "claude"  # Alias
    OPENAI = "openai"
    GPT = "gpt"  # Alias
    OLLAMA = "ollama"
    LLAMA = "llama"
    MISTRAL = "mistral"
    DEEPSEEK = "deepseek"
    QWEN = "qwen"


class StopReason(str, Enum):
    """Reasons for LLM response completion."""

    END_TURN = "end_turn"
    TOOL_USE = "tool_use"
    MAX_TOKENS = "max_tokens"
    STOP_SEQUENCE = "stop_sequence"


# Limits and defaults
class Limits:
    """Application limits and defaults."""

    MAX_CONVERSATION_HISTORY = 100
    MAX_TOTAL_CHATS = 500
    MAX_FILE_READ_SIZE = 50_000  # 50KB
    MAX_COMMAND_LENGTH = 10_000
    DEFAULT_SHELL_TIMEOUT = 60
    DEFAULT_HTTP_TIMEOUT = 30
    MAX_TOOL_ITERATIONS = 15
    EVENT_QUEUE_MAX_SIZE = 1000


# Version
VERSION = "1.10.0"
