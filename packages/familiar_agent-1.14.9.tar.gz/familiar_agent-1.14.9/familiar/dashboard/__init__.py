# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""
Familiar Web Dashboard

Run the dashboard:
    python -m familiar.dashboard
"""

from .app import app, run_dashboard

__all__ = ["run_dashboard", "app"]
