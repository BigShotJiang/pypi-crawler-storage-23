#!/usr/bin/env python3
# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""
Run the Familiar Web Dashboard

Usage:
    python -m familiar.dashboard [--port 5000] [--host 0.0.0.0]
"""

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def _load_dotenv():
    """Load .env from project dir or ~/.familiar/."""
    try:
        from dotenv import load_dotenv as _dotenv_load
    except ImportError:
        return
    for env_path in [
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".env"),
        os.path.expanduser("~/.familiar/.env"),
    ]:
        if os.path.exists(env_path):
            _dotenv_load(env_path, override=False)
            break


_load_dotenv()


def main():
    parser = argparse.ArgumentParser(description="Familiar Web Dashboard")

    parser.add_argument(
        "--port", "-p", type=int, default=5000, help="Port to run on (default: 5000)"
    )

    parser.add_argument(
        "--host",
        "-H",
        default="127.0.0.1",
        help="Host to bind to (default: 127.0.0.1, use 0.0.0.0 for network access)",
    )

    parser.add_argument("--debug", action="store_true", help="Enable debug mode")

    args = parser.parse_args()

    print(f"""
╔═══════════════════════════════════════╗
║      Familiar Web Dashboard           ║
╠═══════════════════════════════════════╣
║  🌐 http://{args.host}:{args.port:<5}              ║
║  📱 Open in browser to control agent  ║
╚═══════════════════════════════════════╝
    """)

    from familiar.core.agent import Agent
    from familiar.dashboard.app import run_dashboard

    agent = Agent()
    run_dashboard(agent, host=args.host, port=args.port, debug=args.debug)


if __name__ == "__main__":
    main()
