"""Familiar onboarding wizards."""

# Re-export run_onboard so existing imports keep working
# after the onboard/ subpackage was introduced in Phase 3.
import importlib.util as _ilu
import sys as _sys
from pathlib import Path as _Path

_onboard_py = _Path(__file__).parent.parent / "onboard.py"
if _onboard_py.exists():
    _spec = _ilu.spec_from_file_location("familiar._onboard_legacy", _onboard_py)
    _mod = _ilu.module_from_spec(_spec)
    _sys.modules["familiar._onboard_legacy"] = _mod
    _spec.loader.exec_module(_mod)
    run_onboard = _mod.run_onboard
else:

    def run_onboard(*args, **kwargs):
        raise ImportError("familiar/onboard.py not found")
