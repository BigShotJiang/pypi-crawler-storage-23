Python Mistral bindings class refrence
======================================

.. toctree::
   :maxdepth: 1

   api/modules
