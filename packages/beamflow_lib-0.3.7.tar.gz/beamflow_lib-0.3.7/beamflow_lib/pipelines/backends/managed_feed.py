"""
Managed Feed Backend — HTTP proxy to the Integrator Platform API.

Drop-in replacement for RecordsFeed's Redis-based publishing when
running in the managed deployment mode. No Redis or GCP SDK dependency.
"""
import logging
from datetime import datetime, UTC
from typing import Optional

import httpx

from beamflow_lib.pipelines.records_model import RecordData
from beamflow_lib.context import get_context
from beamflow_lib.observability.ingestion import enqueue_record_link
from beamflow_lib.observability.model import RecordLinkKind

logger = logging.getLogger(__name__)


class ManagedFeedBackend:
    """
    Feed backend that publishes records via the Integrator Platform API.

    The platform API handles deduplication using Firestore transactions.
    """

    def __init__(self, api_url: str, auth_token: str):
        """
        Args:
            api_url: Base URL of the platform API.
            auth_token: JWT token for authentication.
        """
        self.api_url = api_url.rstrip("/")
        self._client = httpx.AsyncClient(
            base_url=self.api_url,
            headers={
                "Authorization": f"Bearer {auth_token}",
                "Content-Type": "application/json",
            },
            timeout=30.0,
        )

    async def publish(self, feed_id: str, record: RecordData) -> str:
        """
        Publish a record to a feed via the Platform API.

        Args:
            feed_id: The feed identifier.
            record: The record to publish.

        Returns:
            "published" if the record was written, "deduped" if skipped.
        """
        ctx = get_context()
        integration = ctx.integration if ctx else "unknown"
        dedupe_key = record.get_dedupe_key(integration)

        # Use record timestamp or now
        effective_ts = record.timestamp or datetime.now(UTC)
        ts_val = effective_ts.timestamp()

        payload = {
            "dedupe_key": dedupe_key,
            "timestamp": ts_val,
            "data": record.data,
        }

        response = await self._client.post(
            f"/v1/feed/{feed_id}/publish",
            json=payload,
        )
        response.raise_for_status()
        result = response.json()
        status = result.get("status", "unknown")

        # Emit observability event
        if ctx:
            await enqueue_record_link(
                tenant_id=ctx.tenant_id,
                integration=integration,
                pipeline=ctx.integration_pipeline,
                run_id=ctx.run_id,
                trace_id=ctx.trace_id,
                span_id=ctx.span_id,
                record_key=dedupe_key,
                kind=RecordLinkKind.PUBLISHED,
                source=feed_id,
            )

        return status

    async def close(self):
        """Close the HTTP client."""
        await self._client.aclose()
