from enum import Enum
from typing import Optional
from pydantic import BaseModel, ConfigDict, Field

class DurabilityMode(str, Enum):
    IMMEDIATE = "immediate"
    EVENTUAL = "eventual"

class StoreType(str, Enum):
    GCP = "gcp"
    LOCAL = "local"

class LoggingConfig(BaseModel):
    enabled: bool = True
    min_level: str = "INFO"
    include_prefixes: list[str] = Field(default_factory=list, alias="includePrefixes")
    exclude_prefixes: list[str] = Field(default_factory=list, alias="excludePrefixes")
    filter_fn: Optional[str] = Field(None, alias="filterFn")

    model_config = ConfigDict(populate_by_name=True)

class ObservabilityConfig(BaseModel):
    durability: DurabilityMode = DurabilityMode.EVENTUAL
    store_type: StoreType = StoreType.LOCAL
    
    # Local settings
    local_store_path: str = Field("logs", alias="localStorePath")

    # GCP settings
    gcp_project_id: Optional[str] = Field(None, alias="gcpProjectId")
    gcp_dataset_id: Optional[str] = Field(None, alias="gcpDatasetId")
    gcp_bucket_name: Optional[str] = Field(None, alias="gcpBucketName")

    # Logging settings
    logging: LoggingConfig = Field(default_factory=LoggingConfig)

    model_config = ConfigDict(populate_by_name=True)
