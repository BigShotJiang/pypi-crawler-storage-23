"""
Search Replace Patch Module

提供三种文本替换策略：
1. 字符串替换 (StringReplacer) - 严格行级匹配
2. 补丁库替换 (PatchReplacer) - unified diff 格式
3. 文本相似度替换 (SimilarityReplacer) - 模糊匹配
"""

from .base import BaseReplacer, ReplaceResult, ReplaceStrategy
from .string_replacer import StringReplacer
from .patch_replacer import PatchReplacer
from .similarity_replacer import SimilarityReplacer
from .manager import SearchReplaceManager

__all__ = [
    "BaseReplacer",
    "ReplaceResult",
    "ReplaceStrategy",
    "StringReplacer",
    "PatchReplacer",
    "SimilarityReplacer",
    "SearchReplaceManager",
]
