"""Routing registry for Phase 3 view bridging."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

RouteHandler = Callable[[Any], Any]
_ROUTES: dict[str, RouteHandler] = {}


def _normalize_path(route: str) -> str:
    if not route:
        raise ValueError("route cannot be empty")

    normalized = route if route.startswith("/") else f"/{route}"

    if normalized != "/" and normalized.endswith("/"):
        normalized = normalized.rstrip("/")

    return normalized


def path(route: str, view: RouteHandler) -> tuple[str, RouteHandler]:
    if not callable(view):
        raise TypeError("view must be callable")

    normalized = _normalize_path(route)
    _ROUTES[normalized] = view
    return normalized, view


def get_route_registry() -> dict[str, RouteHandler]:
    return dict(_ROUTES)


def clear_routes() -> None:
    _ROUTES.clear()
