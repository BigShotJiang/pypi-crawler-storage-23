"""Ferrum app registry."""

from .registry import AppConfig, Apps, apps

__all__ = ["AppConfig", "Apps", "apps"]

