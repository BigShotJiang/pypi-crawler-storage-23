"""Create a new Ferrum app package and register it in settings.py."""

from __future__ import annotations

import argparse
from pathlib import Path

from ferrum.management.base import BaseCommand, CommandError
from ferrum.management.project import load_settings_module


class Command(BaseCommand):
    help = "Create a new app directory and add it to INSTALLED_APPS."

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        parser.add_argument(
            "app_name",
            help="Name of the app package to create",
        )

    def handle(self, *, app_name: str) -> None:
        project_dir = self.require_project_dir()
        if not app_name.isidentifier():
            raise CommandError(
                f"invalid app name '{app_name}'; use a valid Python identifier"
            )

        app_dir = project_dir / app_name
        if app_dir.exists() and not app_dir.is_dir():
            raise CommandError(
                f"cannot create app '{app_name}': {app_dir} exists and is not a directory"
            )

        created = not app_dir.exists()
        self._upsert_app_scaffold(app_name, app_dir)
        settings_path = self._ensure_settings_has_installed_app(project_dir, app_name)

        if created:
            print(f"Created app '{app_name}' at {app_dir}")
        else:
            print(f"Updated existing app scaffold '{app_name}' at {app_dir}")
        print(f"Added '{app_name}' to INSTALLED_APPS in {settings_path}")

    def _upsert_app_scaffold(self, app_name: str, app_dir: Path) -> None:
        app_dir.mkdir(parents=True, exist_ok=True)
        migrations_dir = app_dir / "migrations"

        migrations_dir.mkdir(parents=True, exist_ok=True)

        files: dict[Path, str] = {
            app_dir / "__init__.py": f'"""Ferrum app: {app_name}.\"\"\"\n',
            app_dir / "apps.py": (
                f'class {self._config_class_name(app_name)}:\n'
                f'    name = "{app_name}"\n'
                f'    label = "{app_name}"\n'
            ),
            app_dir / "models.py": (
                "from ferrum.db import models\n\n\n"
                "# Create your models here.\n"
            ),
            app_dir / "views.py": (
                "from ferrum.http import HttpResponse\n\n\n"
                "# Create your views here.\n"
            ),
            app_dir / "urls.py": (
                "from ferrum.urls import path\n\n\n"
                "urlpatterns = [\n"
                "    # path(\"\", some_view),\n"
                "]\n"
            ),
            migrations_dir / "__init__.py": '"""Migration package for this app."""\n',
        }

        for path, contents in files.items():
            if path.exists():
                continue
            path.write_text(contents, encoding="utf-8")

    def _ensure_settings_has_installed_app(self, project_dir: Path, app_name: str) -> Path:
        settings_path = self._resolve_settings_path(project_dir)
        if not settings_path.exists():
            root_urlconf = f"{project_dir.name}.urls" if project_dir.name else "urls"
            settings_path.write_text(
                (
                    "INSTALLED_APPS = [\n"
                    f'    "{app_name}",\n'
                    "]\n\n"
                    f'ROOT_URLCONF = "{root_urlconf}"\n\n'
                    "DATABASES = {\n"
                    '    "default": {\n'
                    '        "ENGINE": "ferrum.db.backends.sqlite3",\n'
                    '        "NAME": "ferrum.sqlite",\n'
                    "    }\n"
                    "}\n"
                ),
                encoding="utf-8",
            )
            return settings_path

        existing = settings_path.read_text(encoding="utf-8")
        if f'"{app_name}"' in existing or f"'{app_name}'" in existing:
            return settings_path

        if "INSTALLED_APPS" not in existing:
            updated = (
                existing.rstrip()
                + "\n\n"
                + "INSTALLED_APPS = [\n"
                + f'    "{app_name}",\n'
                + "]\n"
            )
            settings_path.write_text(updated + "\n", encoding="utf-8")
            return settings_path

        updated = (
            existing.rstrip()
            + "\n\n"
            + f'if "{app_name}" not in INSTALLED_APPS:\n'
            + f'    INSTALLED_APPS.append("{app_name}")\n'
        )
        settings_path.write_text(updated + "\n", encoding="utf-8")
        return settings_path

    def _config_class_name(self, app_name: str) -> str:
        return "".join(part.title() for part in app_name.split("_")) + "Config"

    def _resolve_settings_path(self, project_dir: Path) -> Path:
        settings_module = load_settings_module(project_dir, required=False)
        if settings_module is not None:
            module_file = getattr(settings_module, "__file__", None)
            if isinstance(module_file, str):
                return Path(module_file).resolve()

        nested = project_dir / project_dir.name / "settings.py"
        if nested.exists():
            return nested

        return project_dir / "settings.py"
