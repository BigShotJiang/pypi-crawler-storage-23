"""Built-in Ferrum management commands."""
