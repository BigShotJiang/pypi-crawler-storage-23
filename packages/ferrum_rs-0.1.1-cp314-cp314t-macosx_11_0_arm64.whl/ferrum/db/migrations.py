"""Migration framework for Ferrum.

Provides:
- file discovery/loading for migration modules
- apply/status helpers backed by the ferrum_migrations table
- migration generation (makemigrations) from current model state
"""

from __future__ import annotations

import importlib.util
import hashlib
import json
import re
from datetime import datetime, timezone
from dataclasses import dataclass
from heapq import heappop, heappush
from pathlib import Path
from types import ModuleType
from typing import Any, Callable, Mapping, Sequence

from ferrum._ferrum import ensure_model_table as _ensure_model_table
from ferrum._ferrum import execute_query as _execute_query
from ferrum._ferrum import execute_sql as _execute_sql
from ferrum._ferrum import save_model as _save_model

from .models import Model, configure_db

_MIGRATIONS_TABLE = "ferrum_migrations"
_MIGRATIONS_TABLE_SCHEMA = {
    "app": {
        "type": "text",
        "nullable": False,
        "db_index": True,
    },
    "name": {
        "type": "text",
        "nullable": False,
    }
}
_MIGRATION_META_TABLE = "ferrum_migration_meta"
_MIGRATION_META_TABLE_SCHEMA = {
    "app": {
        "type": "text",
        "nullable": False,
        "db_index": True,
    },
    "name": {
        "type": "text",
        "nullable": False,
        "db_index": True,
    },
    "checksum": {
        "type": "text",
        "nullable": False,
    },
    "applied_at": {
        "type": "text",
        "nullable": False,
    },
}
_MIGRATION_FILE_RE = re.compile(r"^\d{4}_[a-z0-9_]+\.py$")
_MIGRATION_NAME_RE = re.compile(r"^(\d{4})_(.+)$")
_IDENTIFIER_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")

ModelState = dict[str, dict[str, Any]]


@dataclass(frozen=True)
class MigrationContext:
    database_url: str

    def execute_sql(self, sql: str, *, unsafe_unchecked: bool = True) -> None:
        _execute_sql(sql, unsafe_unchecked=unsafe_unchecked)


class MigrationOperation:
    def apply(self, context: MigrationContext) -> None:
        raise NotImplementedError


@dataclass(frozen=True)
class CreateTable(MigrationOperation):
    table_name: str
    schema: dict[str, dict[str, object]]

    def apply(self, context: MigrationContext) -> None:
        _ = context
        _ensure_model_table(self.table_name, self.schema)


@dataclass(frozen=True)
class AddColumn(MigrationOperation):
    table_name: str
    column_name: str
    column_type: str
    nullable: bool = False
    unique: bool = False
    db_index: bool = False

    def apply(self, context: MigrationContext) -> None:
        table = _quoted_identifier(self.table_name)
        column = _quoted_identifier(self.column_name)
        sql_type = _column_type_to_sql(self.column_type)
        if self.unique:
            raise ValueError(
                "AddColumn does not support inline unique constraints; "
                f"use RawSQL for '{self.table_name}.{self.column_name}'"
            )
        nullability = "" if self.nullable else " NOT NULL"
        context.execute_sql(
            f"ALTER TABLE {table} ADD COLUMN {column} {sql_type}{nullability}"
        )
        if self.db_index and not self.unique:
            index_name = _quoted_identifier(f"idx_{self.table_name}_{self.column_name}")
            context.execute_sql(
                f"CREATE INDEX IF NOT EXISTS {index_name} ON {table} ({column})"
            )


@dataclass(frozen=True)
class CreateModel(MigrationOperation):
    model_cls: type[Model]

    def apply(self, context: MigrationContext) -> None:
        _ = context
        CreateTable(
            table_name=self.model_cls.table_name(),
            schema=self.model_cls.schema(),
        ).apply(context)


@dataclass(frozen=True)
class RawSQL(MigrationOperation):
    sql: str

    def apply(self, context: MigrationContext) -> None:
        context.execute_sql(self.sql)


class RawRQL(RawSQL):
    """Compatibility alias for projects using RawRQL naming."""


@dataclass(frozen=True)
class RunPython(MigrationOperation):
    callback: Callable[[MigrationContext], None]

    def apply(self, context: MigrationContext) -> None:
        self.callback(context)


@dataclass(frozen=True)
class RenameTable(MigrationOperation):
    old_name: str
    new_name: str

    def apply(self, context: MigrationContext) -> None:
        old = _quoted_identifier(self.old_name)
        new = _quoted_identifier(self.new_name)
        context.execute_sql(f"ALTER TABLE {old} RENAME TO {new}")


@dataclass(frozen=True)
class RenameColumn(MigrationOperation):
    table_name: str
    old_name: str
    new_name: str

    def apply(self, context: MigrationContext) -> None:
        table = _quoted_identifier(self.table_name)
        old = _quoted_identifier(self.old_name)
        new = _quoted_identifier(self.new_name)
        context.execute_sql(f"ALTER TABLE {table} RENAME COLUMN {old} TO {new}")


@dataclass(frozen=True)
class AlterColumn(MigrationOperation):
    table_name: str
    column_name: str
    column_type: str | None = None
    nullable: bool | None = None

    def apply(self, context: MigrationContext) -> None:
        _ = context
        # SQLite cannot fully ALTER COLUMN constraints/types without table rebuild.
        # Keep this as explicit scaffolding for forward compatibility.
        _quoted_identifier(self.table_name)
        _quoted_identifier(self.column_name)
        if self.column_type is not None:
            _column_type_to_sql(self.column_type)


@dataclass(frozen=True)
class DropColumn(MigrationOperation):
    table_name: str
    column_name: str

    def apply(self, context: MigrationContext) -> None:
        table = _quoted_identifier(self.table_name)
        column = _quoted_identifier(self.column_name)
        context.execute_sql(f"ALTER TABLE {table} DROP COLUMN {column}")


@dataclass(frozen=True)
class Migration:
    name: str
    operations: Sequence[MigrationOperation]
    dependencies: Sequence[tuple[str, str]] = ()
    state: ModelState | None = None


def ensure_migrations_package(migrations_dir: Path) -> None:
    migrations_dir.mkdir(parents=True, exist_ok=True)
    init_file = migrations_dir / "__init__.py"
    if not init_file.exists():
        init_file.write_text("\"\"\"Ferrum migrations package.\"\"\"\n", encoding="utf-8")


def discover_migrations(migrations_dir: Path) -> list[Migration]:
    if not migrations_dir.exists():
        return []

    files = sorted(
        path
        for path in migrations_dir.iterdir()
        if path.is_file() and _MIGRATION_FILE_RE.match(path.name)
    )

    migrations: list[Migration] = []
    seen_names: set[str] = set()

    for file_path in files:
        migration = _load_migration(file_path)
        if migration.name != file_path.stem:
            raise ValueError(
                f"migration name mismatch in {file_path.name}: "
                f"expected '{file_path.stem}', got '{migration.name}'"
            )

        if migration.name in seen_names:
            raise ValueError(f"duplicate migration name: {migration.name}")

        seen_names.add(migration.name)
        migrations.append(migration)

    return migrations


@dataclass(frozen=True)
class MigrationNode:
    app: str
    migration: Migration

    @property
    def key(self) -> tuple[str, str]:
        return self.app, self.migration.name


def plan_migrations_for_apps(
    migrations_by_app: Mapping[str, Sequence[Migration]],
    *,
    applied_by_app: Mapping[str, set[str]],
    targets: Mapping[str, str] | None = None,
) -> list[MigrationNode]:
    targets = dict(targets or {})

    migration_lookup: dict[tuple[str, str], Migration] = {}
    selected_names: dict[str, set[str]] = {}
    dependencies: dict[tuple[str, str], set[tuple[str, str]]] = {}

    for app_label, migrations in sorted(migrations_by_app.items()):
        _validate_app_label(app_label)
        names = [migration.name for migration in migrations]
        _validate_migration_sequence(app_label, names)

        target = targets.get(app_label)
        if target is not None and target != "zero" and target not in names:
            raise ValueError(
                f"unknown migration target '{app_label}.{target}'"
            )

        if target == "zero":
            selected = set()
        elif target is None:
            selected = set(names)
        else:
            cutoff = names.index(target)
            selected = set(names[: cutoff + 1])

        selected_names[app_label] = selected

        previous_name: str | None = None
        for migration in migrations:
            key = (app_label, migration.name)
            migration_lookup[key] = migration

            deps: set[tuple[str, str]] = set()
            if previous_name is not None:
                deps.add((app_label, previous_name))
            previous_name = migration.name

            for dependency in migration.dependencies:
                if (
                    not isinstance(dependency, tuple)
                    or len(dependency) != 2
                    or not isinstance(dependency[0], str)
                    or not isinstance(dependency[1], str)
                ):
                    raise ValueError(
                        f"invalid dependency in {app_label}.{migration.name}: {dependency!r}"
                    )
                dep_app, dep_name = dependency
                _validate_app_label(dep_app)
                deps.add((dep_app, dep_name))

            dependencies[key] = deps

    pending: set[tuple[str, str]] = set()
    for app_label, selected in selected_names.items():
        applied = applied_by_app.get(app_label, set())
        pending.update((app_label, name) for name in selected if name not in applied)

    adjacency: dict[tuple[str, str], set[tuple[str, str]]] = {key: set() for key in pending}
    indegree: dict[tuple[str, str], int] = {key: 0 for key in pending}

    for key in pending:
        for dependency in dependencies.get(key, set()):
            dep_app, dep_name = dependency
            dep_selected = selected_names.get(dep_app)
            dep_applied = applied_by_app.get(dep_app, set())
            dep_exists = (dep_app, dep_name) in migration_lookup

            if dep_selected is None:
                raise ValueError(
                    f"migration dependency '{dep_app}.{dep_name}' referenced by "
                    f"'{key[0]}.{key[1]}' targets unknown app '{dep_app}'"
                )

            if dep_name not in dep_selected and dep_name not in dep_applied:
                raise ValueError(
                    f"migration dependency '{dep_app}.{dep_name}' required by "
                    f"'{key[0]}.{key[1]}' is not selected for execution"
                )

            if not dep_exists and dep_name not in dep_applied:
                raise ValueError(
                    f"migration dependency '{dep_app}.{dep_name}' referenced by "
                    f"'{key[0]}.{key[1]}' does not exist"
                )

            if dependency in pending:
                adjacency[dependency].add(key)
                indegree[key] += 1

    queue: list[tuple[str, str]] = []
    for key, degree in indegree.items():
        if degree == 0:
            heappush(queue, key)

    ordered: list[MigrationNode] = []
    while queue:
        app_label, migration_name = heappop(queue)
        key = (app_label, migration_name)
        migration = migration_lookup[key]
        ordered.append(MigrationNode(app=app_label, migration=migration))

        for nxt in sorted(adjacency[key]):
            indegree[nxt] -= 1
            if indegree[nxt] == 0:
                heappush(queue, nxt)

    if len(ordered) != len(pending):
        unresolved = sorted(key for key, degree in indegree.items() if degree > 0)
        details = ", ".join(f"{app}.{name}" for app, name in unresolved)
        raise ValueError(f"migration dependency cycle detected: {details}")

    return ordered


def apply_migrations_for_apps(
    migrations_dirs: Mapping[str, Path],
    *,
    database_url: str,
    targets: Mapping[str, str] | None = None,
    fake: bool = False,
) -> list[tuple[str, str]]:
    configure_db(database_url)
    migrations_by_app = {
        app_label: discover_migrations(path)
        for app_label, path in migrations_dirs.items()
    }
    applied_by_app = {
        app_label: _applied_migration_names(app_label)
        for app_label in migrations_dirs
    }
    for app_label, migrations in migrations_by_app.items():
        _validate_applied_migration_metadata(
            app_label,
            migrations,
            applied_by_app.get(app_label, set()),
        )

    targets = dict(targets or {})
    _apply_fake_unapply_if_needed(
        migrations_by_app=migrations_by_app,
        applied_by_app=applied_by_app,
        targets=targets,
        fake=fake,
    )

    plan = plan_migrations_for_apps(
        migrations_by_app,
        applied_by_app=applied_by_app,
        targets=targets,
    )

    context = MigrationContext(database_url=database_url)
    applied_now: list[tuple[str, str]] = []
    for node in plan:
        if not fake:
            for operation in node.migration.operations:
                operation.apply(context)
        _record_migration(node.app, node.migration)
        applied_by_app.setdefault(node.app, set()).add(node.migration.name)
        applied_now.append((node.app, node.migration.name))

    return applied_now


def apply_migrations(
    migrations: Sequence[Migration],
    *,
    database_url: str,
    app_label: str = "default",
    target: str | None = None,
    fake: bool = False,
) -> list[str]:
    ordered = list(migrations)
    _validate_app_label(app_label)
    _validate_migration_sequence(app_label, [migration.name for migration in ordered])

    configure_db(database_url)
    context = MigrationContext(database_url=database_url)
    known_applied = _applied_migration_names(app_label)
    _validate_applied_migration_metadata(app_label, ordered, known_applied)
    selected_names = [migration.name for migration in ordered]
    if target and target != "zero":
        if target not in selected_names:
            raise ValueError(f"unknown migration target '{target}' for app '{app_label}'")
        selected_names = selected_names[: selected_names.index(target) + 1]
    if target == "zero":
        selected_names = []

    applied_now: list[str] = []
    for migration in ordered:
        if migration.name not in selected_names or migration.name in known_applied:
            continue
        if not fake:
            for operation in migration.operations:
                operation.apply(context)
        _record_migration(app_label, migration)
        known_applied.add(migration.name)
        applied_now.append(migration.name)
    return applied_now


def apply_migrations_from_directory(
    migrations_dir: Path,
    *,
    database_url: str,
    app_label: str = "default",
    target: str | None = None,
    fake: bool = False,
) -> list[str]:
    applied = apply_migrations_for_apps(
        {app_label: migrations_dir},
        database_url=database_url,
        targets={app_label: target} if target else None,
        fake=fake,
    )
    return [name for applied_app, name in applied if applied_app == app_label]


def get_migration_status(
    migrations_dir: Path,
    *,
    database_url: str,
    app_label: str = "default",
) -> tuple[list[tuple[str, bool]], list[str]]:
    _validate_app_label(app_label)
    configure_db(database_url)
    migrations = discover_migrations(migrations_dir)
    applied = _applied_migration_names(app_label)
    _validate_applied_migration_metadata(app_label, migrations, applied)

    discovered_names = [migration.name for migration in migrations]
    statuses = [(name, name in applied) for name in discovered_names]
    unknown_applied = sorted(applied - set(discovered_names))

    return statuses, unknown_applied


def capture_model_state(model_registry: Mapping[str, type[Model]]) -> ModelState:
    state: ModelState = {}

    for model_name, model_cls in sorted(model_registry.items()):
        fields: dict[str, dict[str, object]] = {}
        for field_name, field_spec in sorted(model_cls.schema().items()):
            serialized_field = {
                "type": str(field_spec["type"]),
                "nullable": bool(field_spec.get("nullable", False)),
                "unique": bool(field_spec.get("unique", False)),
                "db_index": bool(field_spec.get("db_index", False)),
            }
            relation_model = field_spec.get("relation_model")
            if isinstance(relation_model, str):
                serialized_field["relation_model"] = relation_model

            related_name = field_spec.get("related_name")
            if isinstance(related_name, str):
                serialized_field["related_name"] = related_name

            fields[field_name] = serialized_field

        state[model_name] = {
            "table_name": model_cls.table_name(),
            "fields": fields,
        }

    return state


def make_migration(
    migrations_dir: Path,
    model_registry: Mapping[str, type[Model]],
    *,
    name: str | None = None,
) -> tuple[Path | None, list[str]]:
    ensure_migrations_package(migrations_dir)
    migrations = discover_migrations(migrations_dir)
    current_state = capture_model_state(model_registry)
    has_state_snapshot = any(migration.state is not None for migration in migrations)
    previous_state = _latest_state(migrations)

    if migrations and not has_state_snapshot:
        return None, [
            "cannot diff state because existing migrations have no 'state' snapshot"
        ]

    operations, warnings = _plan_operations(previous_state, current_state)
    if not operations:
        return None, warnings

    migration_name = _next_migration_name(
        existing_names=[migration.name for migration in migrations],
        hint=name,
    )
    migration_file = migrations_dir / f"{migration_name}.py"

    migration_contents = _render_migration_file(
        migration_name=migration_name,
        operations=operations,
        state=current_state,
    )
    migration_file.write_text(migration_contents, encoding="utf-8")

    return migration_file, warnings


def _query_plan_all_for_app(app_label: str) -> str:
    return json.dumps(
        [
            {
                "op": "filter",
                "conditions": [
                    {"field": "app", "lookup": "exact", "value": app_label},
                ],
            },
            {"op": "all", "filters": {}},
        ],
        separators=(",", ":"),
        sort_keys=True,
    )


def _applied_migration_names(app_label: str) -> set[str]:
    _validate_app_label(app_label)
    _ensure_model_table(_MIGRATIONS_TABLE, _MIGRATIONS_TABLE_SCHEMA)
    result = _execute_query(
        _MIGRATIONS_TABLE,
        _query_plan_all_for_app(app_label),
        {"id": "integer", "app": "text", "name": "text"},
    )

    if result is None:
        return set()

    if not isinstance(result, list):
        raise RuntimeError("invalid migrations table payload")

    names: set[str] = set()
    for row in result:
        if not isinstance(row, dict):
            continue
        value = row.get("name")
        if isinstance(value, str):
            names.add(value)

    return names


def _migration_operation_signature(operation: MigrationOperation) -> dict[str, object]:
    if isinstance(operation, CreateTable):
        return {
            "op": "CreateTable",
            "table_name": operation.table_name,
            "schema": operation.schema,
        }
    if isinstance(operation, AddColumn):
        return {
            "op": "AddColumn",
            "table_name": operation.table_name,
            "column_name": operation.column_name,
            "column_type": operation.column_type,
            "nullable": operation.nullable,
            "unique": operation.unique,
            "db_index": operation.db_index,
        }
    if isinstance(operation, RenameTable):
        return {
            "op": "RenameTable",
            "old_name": operation.old_name,
            "new_name": operation.new_name,
        }
    if isinstance(operation, RenameColumn):
        return {
            "op": "RenameColumn",
            "table_name": operation.table_name,
            "old_name": operation.old_name,
            "new_name": operation.new_name,
        }
    if isinstance(operation, AlterColumn):
        return {
            "op": "AlterColumn",
            "table_name": operation.table_name,
            "column_name": operation.column_name,
            "column_type": operation.column_type,
            "nullable": operation.nullable,
        }
    if isinstance(operation, DropColumn):
        return {
            "op": "DropColumn",
            "table_name": operation.table_name,
            "column_name": operation.column_name,
        }
    if isinstance(operation, RawSQL):
        return {"op": "RawSQL", "sql": operation.sql}
    if isinstance(operation, RunPython):
        callback = operation.callback
        return {
            "op": "RunPython",
            "callback": callback.__qualname__,
        }
    if isinstance(operation, CreateModel):
        return {
            "op": "CreateModel",
            "model": operation.model_cls.__name__,
            "table_name": operation.model_cls.table_name(),
            "schema": operation.model_cls.schema(),
        }

    return {"op": type(operation).__name__, "repr": repr(operation)}


def _migration_checksum(migration: Migration) -> str:
    payload = {
        "name": migration.name,
        "dependencies": sorted(tuple(dep) for dep in migration.dependencies),
        "operations": [
            _migration_operation_signature(operation)
            for operation in migration.operations
        ],
        "state": migration.state,
    }
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _migration_meta_by_name(app_label: str) -> dict[str, dict[str, str]]:
    _validate_app_label(app_label)
    _ensure_model_table(_MIGRATION_META_TABLE, _MIGRATION_META_TABLE_SCHEMA)
    result = _execute_query(
        _MIGRATION_META_TABLE,
        _query_plan_all_for_app(app_label),
        {
            "id": "integer",
            "app": "text",
            "name": "text",
            "checksum": "text",
            "applied_at": "text",
        },
    )

    if result is None:
        return {}
    if not isinstance(result, list):
        raise RuntimeError("invalid migration metadata payload")

    metadata: dict[str, dict[str, str]] = {}
    for row in result:
        if not isinstance(row, dict):
            continue
        name = row.get("name")
        checksum = row.get("checksum")
        applied_at = row.get("applied_at")
        if not isinstance(name, str) or not isinstance(checksum, str):
            continue
        metadata[name] = {
            "checksum": checksum,
            "applied_at": applied_at if isinstance(applied_at, str) else "",
        }
    return metadata


def _record_migration_meta(app_label: str, name: str, checksum: str) -> None:
    _validate_app_label(app_label)
    _ensure_model_table(_MIGRATION_META_TABLE, _MIGRATION_META_TABLE_SCHEMA)
    _execute_query(
        _MIGRATION_META_TABLE,
        json.dumps(
            [
                {
                    "op": "filter",
                    "conditions": [
                        {"field": "app", "lookup": "exact", "value": app_label},
                        {"field": "name", "lookup": "exact", "value": name},
                    ],
                },
                {"op": "delete"},
            ],
            separators=(",", ":"),
            sort_keys=True,
        ),
        {
            "id": "integer",
            "app": "text",
            "name": "text",
            "checksum": "text",
            "applied_at": "text",
        },
    )

    _save_model(
        _MIGRATION_META_TABLE,
        _MIGRATION_META_TABLE_SCHEMA,
        {
            "app": app_label,
            "name": name,
            "checksum": checksum,
            "applied_at": datetime.now(timezone.utc).isoformat(),
        },
    )


def _validate_applied_migration_metadata(
    app_label: str,
    migrations: Sequence[Migration],
    applied_names: set[str],
) -> None:
    metadata = _migration_meta_by_name(app_label)

    for migration in migrations:
        if migration.name not in applied_names:
            continue

        expected_checksum = _migration_checksum(migration)
        current_meta = metadata.get(migration.name)
        if current_meta is None:
            _record_migration_meta(app_label, migration.name, expected_checksum)
            continue

        actual_checksum = current_meta.get("checksum", "")
        if actual_checksum != expected_checksum:
            raise ValueError(
                "migration checksum mismatch for "
                f"'{app_label}.{migration.name}': database has {actual_checksum}, "
                f"source has {expected_checksum}"
            )


def _record_migration(app_label: str, migration: Migration) -> None:
    _validate_app_label(app_label)
    _ensure_model_table(_MIGRATIONS_TABLE, _MIGRATIONS_TABLE_SCHEMA)
    _save_model(
        _MIGRATIONS_TABLE,
        _MIGRATIONS_TABLE_SCHEMA,
        {"app": app_label, "name": migration.name},
    )
    _record_migration_meta(app_label, migration.name, _migration_checksum(migration))


def _remove_migration_record(app_label: str, name: str) -> None:
    _validate_app_label(app_label)
    _ensure_model_table(_MIGRATIONS_TABLE, _MIGRATIONS_TABLE_SCHEMA)
    payload = json.dumps(
        [
            {
                "op": "filter",
                "conditions": [
                    {"field": "app", "lookup": "exact", "value": app_label},
                    {"field": "name", "lookup": "exact", "value": name},
                ],
            },
            {"op": "delete"},
        ],
        separators=(",", ":"),
        sort_keys=True,
    )
    _execute_query(
        _MIGRATIONS_TABLE,
        payload,
        {"id": "integer", "app": "text", "name": "text"},
    )
    _ensure_model_table(_MIGRATION_META_TABLE, _MIGRATION_META_TABLE_SCHEMA)
    _execute_query(
        _MIGRATION_META_TABLE,
        json.dumps(
            [
                {
                    "op": "filter",
                    "conditions": [
                        {"field": "app", "lookup": "exact", "value": app_label},
                        {"field": "name", "lookup": "exact", "value": name},
                    ],
                },
                {"op": "delete"},
            ],
            separators=(",", ":"),
            sort_keys=True,
        ),
        {
            "id": "integer",
            "app": "text",
            "name": "text",
            "checksum": "text",
            "applied_at": "text",
        },
    )


def _validate_app_label(app_label: str) -> None:
    if not app_label or not app_label.isidentifier():
        raise ValueError(f"invalid app label '{app_label}'")


def _validate_migration_sequence(app_label: str, names: Sequence[str]) -> None:
    seen: set[str] = set()
    for name in names:
        if name in seen:
            raise ValueError(f"duplicate migration '{app_label}.{name}'")
        seen.add(name)

    ordered = sorted(names)
    if list(names) != ordered:
        raise ValueError(
            f"migration files for '{app_label}' must be ordered by name"
        )


def _apply_fake_unapply_if_needed(
    *,
    migrations_by_app: Mapping[str, Sequence[Migration]],
    applied_by_app: dict[str, set[str]],
    targets: Mapping[str, str],
    fake: bool,
) -> None:
    if not targets:
        return

    for app_label, target in targets.items():
        names = [migration.name for migration in migrations_by_app.get(app_label, ())]
        applied = set(applied_by_app.get(app_label, set()))

        if target == "zero":
            desired: set[str] = set()
        else:
            if target not in names:
                raise ValueError(f"unknown migration target '{app_label}.{target}'")
            cutoff = names.index(target)
            desired = set(names[: cutoff + 1])

        rollback = sorted(applied - desired)
        if not rollback:
            continue
        if not fake:
            joined = ", ".join(f"{app_label}.{name}" for name in rollback)
            raise ValueError(
                f"backward migration requested ({joined}); re-run with --fake"
            )

        for migration_name in reversed(rollback):
            _remove_migration_record(app_label, migration_name)
            applied_by_app.setdefault(app_label, set()).discard(migration_name)


def _latest_state(migrations: Sequence[Migration]) -> ModelState:
    for migration in reversed(migrations):
        if migration.state is not None:
            return _normalize_state(migration.state)
    return {}


def _normalize_state(state: Mapping[str, Any]) -> ModelState:
    normalized: ModelState = {}

    for model_name, model_payload in sorted(state.items()):
        if not isinstance(model_payload, Mapping):
            raise ValueError(f"invalid state payload for model '{model_name}'")

        table_name_value = model_payload.get("table_name")
        fields_value = model_payload.get("fields")
        if not isinstance(table_name_value, str) or not isinstance(fields_value, Mapping):
            raise ValueError(f"invalid state structure for model '{model_name}'")

        normalized_fields: dict[str, dict[str, object]] = {}
        for field_name, field_payload in sorted(fields_value.items()):
            if not isinstance(field_payload, Mapping):
                raise ValueError(f"invalid field payload for '{model_name}.{field_name}'")

            field_type = field_payload.get("type")
            nullable = field_payload.get("nullable", False)
            unique = field_payload.get("unique", False)
            db_index = field_payload.get("db_index", False)
            relation_model = field_payload.get("relation_model")
            related_name = field_payload.get("related_name")
            if not isinstance(field_type, str):
                raise ValueError(f"invalid field type for '{model_name}.{field_name}'")

            normalized_field = {
                "type": field_type,
                "nullable": bool(nullable),
                "unique": bool(unique),
                "db_index": bool(db_index),
            }
            if isinstance(relation_model, str):
                normalized_field["relation_model"] = relation_model
            if isinstance(related_name, str):
                normalized_field["related_name"] = related_name

            normalized_fields[field_name] = normalized_field

        normalized[model_name] = {
            "table_name": table_name_value,
            "fields": normalized_fields,
        }

    return normalized


def _plan_operations(
    previous_state: ModelState,
    current_state: ModelState,
) -> tuple[list[MigrationOperation], list[str]]:
    operations: list[MigrationOperation] = []
    warnings: list[str] = []

    previous_models = set(previous_state)
    current_models = set(current_state)
    added_models = current_models - previous_models
    removed_models = previous_models - current_models

    inferred_model_renames: dict[str, str] = {}
    handled_removed_models: set[str] = set()
    for model_name in sorted(added_models):
        table_name = str(current_state[model_name]["table_name"])
        candidates = [
            previous_name
            for previous_name in sorted(removed_models - handled_removed_models)
            if str(previous_state[previous_name]["table_name"]) == table_name
        ]
        if len(candidates) == 1:
            previous_name = candidates[0]
            inferred_model_renames[model_name] = previous_name
            handled_removed_models.add(previous_name)
            warnings.append(
                "possible model rename detected: "
                f"'{previous_name}' -> '{model_name}' for table '{table_name}'. "
                "Create an explicit migration using RenameTable if the DB table name changed, "
                "or keep table_name stable and update state intentionally."
            )

    for model_name in sorted(added_models):
        if model_name in inferred_model_renames:
            continue
        model_state = current_state[model_name]
        operations.append(
            CreateTable(
                table_name=str(model_state["table_name"]),
                schema=dict(model_state["fields"]),
            )
        )

    for model_name in sorted(current_models & previous_models):
        previous_model = previous_state[model_name]
        current_model = current_state[model_name]

        previous_table = str(previous_model["table_name"])
        current_table = str(current_model["table_name"])
        if previous_table != current_table:
            warnings.append(
                "table rename is not auto-generated: "
                f"'{model_name}' changed table_name from '{previous_table}' to '{current_table}'. "
                "Add an explicit RenameTable(old_name=..., new_name=...) migration operation."
            )
            continue

        previous_fields = dict(previous_model["fields"])
        current_fields = dict(current_model["fields"])
        added_fields = sorted(set(current_fields) - set(previous_fields))
        removed_fields = sorted(set(previous_fields) - set(current_fields))

        inferred_field_renames: dict[str, str] = {}
        consumed_removed_fields: set[str] = set()
        for field_name in added_fields:
            field_state = current_fields[field_name]
            candidates = [
                previous_name
                for previous_name in removed_fields
                if previous_name not in consumed_removed_fields
                and previous_fields[previous_name] == field_state
            ]
            if len(candidates) == 1:
                previous_name = candidates[0]
                inferred_field_renames[field_name] = previous_name
                consumed_removed_fields.add(previous_name)
                warnings.append(
                    "possible field rename detected: "
                    f"'{model_name}.{previous_name}' -> '{model_name}.{field_name}'. "
                    "Add an explicit RenameColumn(table_name=..., old_name=..., new_name=...) "
                    "migration if this was intentional."
                )

        for field_name in added_fields:
            if field_name in inferred_field_renames:
                continue
            field_state = current_fields[field_name]
            field_unique = bool(field_state.get("unique", False))
            if field_unique:
                warnings.append(
                    "unique constraint for new field is not auto-generated: "
                    f"'{model_name}.{field_name}'. Add a follow-up migration with a unique "
                    "constraint or custom SQL."
                )
            operations.append(
                AddColumn(
                    table_name=current_table,
                    column_name=field_name,
                    column_type=str(field_state["type"]),
                    nullable=bool(field_state.get("nullable", False)),
                    unique=False,
                    db_index=bool(field_state.get("db_index", False)),
                )
            )

        for field_name in removed_fields:
            if field_name in consumed_removed_fields:
                continue
            warnings.append(
                "field removal is not auto-generated: "
                f"'{model_name}.{field_name}'. Add an explicit DropColumn or manual data "
                "migration before removal."
            )

        for field_name in sorted(set(previous_fields) & set(current_fields)):
            previous_field = previous_fields[field_name]
            current_field = current_fields[field_name]
            if previous_field != current_field:
                warnings.append(
                    "field alteration is not auto-generated: "
                    f"'{model_name}.{field_name}'. Add an explicit AlterColumn/RawSQL migration "
                    "with a safe rollout plan."
                )

    for model_name in sorted(removed_models):
        if model_name in handled_removed_models:
            continue
        warnings.append(
            "model removal is not auto-generated: "
            f"'{model_name}'. Add explicit teardown migration steps and data retention strategy."
        )

    return operations, warnings


def _next_migration_name(existing_names: Sequence[str], hint: str | None) -> str:
    latest = 0
    for name in existing_names:
        match = _MIGRATION_NAME_RE.match(name)
        if not match:
            continue
        latest = max(latest, int(match.group(1)))

    prefix = latest + 1
    slug = _slugify(hint or ("initial" if prefix == 1 else "auto"))
    return f"{prefix:04d}_{slug}"


def _slugify(name: str) -> str:
    slug = re.sub(r"[^a-z0-9_]+", "_", name.strip().lower())
    slug = slug.strip("_")
    return slug or "auto"


def _render_migration_file(
    *,
    migration_name: str,
    operations: Sequence[MigrationOperation],
    state: ModelState,
) -> str:
    imports = ["Migration"]
    if any(isinstance(operation, CreateTable) for operation in operations):
        imports.append("CreateTable")
    if any(isinstance(operation, AddColumn) for operation in operations):
        imports.append("AddColumn")

    import_line = ", ".join(sorted(imports))

    operation_lines = "\n".join(_operation_to_source(operation) for operation in operations)
    state_repr = repr(state)

    return (
        f"from ferrum.db.migrations import {import_line}\n\n\n"
        "MIGRATION = Migration(\n"
        f"    name={migration_name!r},\n"
        "    operations=[\n"
        f"{operation_lines}\n"
        "    ],\n"
        "    dependencies=[],\n"
        f"    state={state_repr},\n"
        ")\n"
    )


def _operation_to_source(operation: MigrationOperation) -> str:
    if isinstance(operation, CreateTable):
        return (
            "        CreateTable("
            f"table_name={operation.table_name!r}, schema={repr(operation.schema)}"
            "),"
        )

    if isinstance(operation, AddColumn):
        return (
            "        AddColumn("
            f"table_name={operation.table_name!r}, "
            f"column_name={operation.column_name!r}, "
            f"column_type={operation.column_type!r}, "
            f"nullable={operation.nullable!r}, "
            f"unique={operation.unique!r}, "
            f"db_index={operation.db_index!r}"
            "),"
        )

    raise TypeError(
        "makemigrations can only serialize CreateTable/AddColumn operations, "
        f"got {type(operation).__name__}"
    )


def _load_migration(path: Path) -> Migration:
    module_name = f"_ferrum_migration_{path.stem}_{abs(hash(path.resolve()))}"
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"failed to load migration module from {path}")

    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    migration = _extract_migration(module)
    if not isinstance(migration, Migration):
        raise TypeError(
            f"migration module {path.name} must expose MIGRATION: Migration"
        )
    return migration


def _extract_migration(module: ModuleType) -> Migration | None:
    for attr in ("MIGRATION", "migration"):
        value = getattr(module, attr, None)
        if isinstance(value, Migration):
            return value
    return None


def _column_type_to_sql(column_type: str) -> str:
    normalized = column_type.strip().lower()
    if normalized in {"text", "char", "string"}:
        return "TEXT"
    if normalized in {"integer", "int"}:
        return "INTEGER"
    if normalized in {"boolean", "bool"}:
        return "INTEGER"
    raise ValueError(f"unsupported column type '{column_type}'")


def _quoted_identifier(value: str) -> str:
    if not _IDENTIFIER_RE.match(value):
        raise ValueError(f"invalid SQL identifier '{value}'")
    return f'"{value}"'


__all__ = [
    "AddColumn",
    "AlterColumn",
    "CreateModel",
    "CreateTable",
    "DropColumn",
    "Migration",
    "MigrationContext",
    "MigrationNode",
    "RawRQL",
    "RawSQL",
    "RenameColumn",
    "RenameTable",
    "RunPython",
    "apply_migrations",
    "apply_migrations_from_directory",
    "apply_migrations_for_apps",
    "capture_model_state",
    "discover_migrations",
    "ensure_migrations_package",
    "get_migration_status",
    "make_migration",
    "plan_migrations_for_apps",
]
