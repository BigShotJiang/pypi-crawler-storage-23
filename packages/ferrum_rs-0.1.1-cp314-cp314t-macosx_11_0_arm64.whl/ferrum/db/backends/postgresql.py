"""PostgreSQL backend adapter (skeleton)."""

from __future__ import annotations

from pathlib import Path
from typing import Mapping

from ferrum._ferrum import configure_db as _configure_db

from .base import BackendAdapter


class PostgresqlBackendAdapter(BackendAdapter):
    def __init__(self) -> None:
        super().__init__(
            engine="ferrum.db.backends.postgresql",
            dialect="postgresql",
            param_style="numeric",
        )

    def resolve_database_url(
        self,
        database_settings: Mapping[str, object],
        *,
        base_dir: str | Path | None = None,
    ) -> str:
        _ = base_dir
        explicit_url = database_settings.get("URL")
        if not isinstance(explicit_url, str) or not explicit_url.strip():
            raise ValueError(
                "postgresql backend requires DATABASES['default']['URL']"
            )
        return explicit_url.strip()

    def configure_connection(self, database_url: str) -> None:
        _configure_db(str(database_url))
