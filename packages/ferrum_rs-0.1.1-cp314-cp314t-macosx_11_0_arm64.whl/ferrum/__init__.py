"""Ferrum Python package entrypoint."""

from __future__ import annotations

import importlib
import json
import os
import sys
import sysconfig
from typing import Any

from ._ferrum import (
    PyHttpRequest,
    ensure_model_table as _ensure_model_table,
    execute_query as _execute_query,
    execute_sql as _execute_sql,
    save_model as _save_model,
    start_server as _start_server,
)
from .apps import apps
from .conf import ENVIRONMENT_VARIABLE, ImproperlyConfigured, settings
from .http import HttpResponse, JsonResponse
from .urls import get_route_registry

__all__ = [
    "HttpResponse",
    "JsonResponse",
    "PyHttpRequest",
    "is_no_gil_active",
    "runtime_info",
    "setup",
    "start_server",
]

_MIN_PYTHON = (3, 14)
_SETUP_COMPLETE = False
_MIDDLEWARE_STACK: list[object] = []
_INSTALLED_APPS_TABLE = "ferrum_installed_apps"
_INSTALLED_APPS_SCHEMA = {
    "label": {
        "type": "text",
        "nullable": False,
        "unique": True,
    }
}
_MIGRATIONS_TABLE = "ferrum_migrations"
_MIGRATIONS_SCHEMA = {
    "app": {"type": "text", "nullable": False, "db_index": True},
    "name": {"type": "text", "nullable": False},
}


def setup(settings_module: str | None = None) -> None:
    global _SETUP_COMPLETE

    if settings_module:
        os.environ[ENVIRONMENT_VARIABLE] = settings_module
        settings.reset()

    if not settings.configured:
        _ = settings.INSTALLED_APPS

    apps.populate(getattr(settings, "INSTALLED_APPS", []))
    _validate_startup_sanity()

    resolved_database = _resolve_database_connection()
    if resolved_database:
        _, database_url = resolved_database
        from .db import models as db_models

        db_models.configure_db(database_url)
        _sync_installed_apps_table(apps.get_app_labels())

    _SETUP_COMPLETE = True


def start_server(port: int | None = None) -> None:
    if not _SETUP_COMPLETE:
        try:
            setup()
        except ImproperlyConfigured:
            # Backward-compatible fallback: allow bare ferrum.start_server()
            # when no project settings module is configured.
            pass

    selected_port = port
    if selected_port is None:
        if settings.configured:
            configured_port = getattr(settings, "PORT", 8000)
            selected_port = int(configured_port)
        else:
            selected_port = 8000

    _start_server(int(selected_port), _build_route_registry())


def runtime_info() -> dict[str, Any]:
    free_threaded_build = bool(sysconfig.get_config_var("Py_GIL_DISABLED") or False)
    gil_enabled = _read_gil_state()

    return {
        "python_version": sys.version.split()[0],
        "free_threaded_build": free_threaded_build,
        "gil_enabled": gil_enabled,
        "no_gil_active": free_threaded_build and gil_enabled is False,
    }


def is_no_gil_active() -> bool:
    return bool(runtime_info()["no_gil_active"])


def _resolve_database_connection() -> tuple[Any, str] | None:
    databases = getattr(settings, "DATABASES", None)
    if not isinstance(databases, dict):
        return None

    default_config = databases.get("default")
    if not isinstance(default_config, dict):
        return None

    from .db.backends import get_backend_adapter

    engine = default_config.get("ENGINE", "ferrum.db.backends.sqlite3")
    try:
        adapter = get_backend_adapter(str(engine))
    except ValueError as err:
        raise ImproperlyConfigured(str(err)) from err

    base_dir = getattr(settings, "BASE_DIR", None)
    try:
        database_url = adapter.resolve_database_url(default_config, base_dir=base_dir)
    except ValueError as err:
        raise ImproperlyConfigured(str(err)) from err

    return adapter, database_url


def _build_route_registry() -> dict[str, Any]:
    routes = get_route_registry()
    if not settings.configured or not _MIDDLEWARE_STACK:
        return routes

    from .middleware import build_middleware_chain

    wrapped: dict[str, Any] = {}
    for route_path, view in routes.items():
        wrapped[route_path] = build_middleware_chain(view, _MIDDLEWARE_STACK)
    return wrapped


def _read_gil_state() -> bool | None:
    checker = getattr(sys, "_is_gil_enabled", None)
    if checker is None:
        return None

    try:
        return bool(checker())
    except Exception:
        return None


def _enforce_runtime_requirements() -> None:
    if sys.version_info < _MIN_PYTHON:
        raise RuntimeError(
            "Ferrum requires Python 3.14+ free-threaded builds "
            "(CPython 3.14t or newer)."
        )

    info = runtime_info()
    if not info["free_threaded_build"]:
        raise RuntimeError(
            "Ferrum requires a free-threaded Python build (Py_GIL_DISABLED=1). "
            "Install and use CPython 3.14t or newer."
        )

    if info["gil_enabled"] is None:
        raise RuntimeError(
            "Ferrum requires a runtime that exposes sys._is_gil_enabled(). "
            "Use CPython 3.14t or newer."
        )

    if info["gil_enabled"]:
        raise RuntimeError(
            "Ferrum requires no-GIL runtime execution. Restart with PYTHON_GIL=0."
        )


def _sync_installed_apps_table(app_labels: list[str]) -> None:
    previous = _load_installed_app_labels()
    current = {label for label in app_labels}
    removed = sorted(previous - current)
    if removed:
        blocked = _apps_with_applied_migrations(set(removed))
        if blocked:
            joined = ", ".join(sorted(blocked))
            raise ImproperlyConfigured(
                "INSTALLED_APPS drift detected. Removed apps still have applied "
                f"migrations: {joined}. Re-add apps or run an explicit retirement plan."
            )

    _ensure_model_table(_INSTALLED_APPS_TABLE, _INSTALLED_APPS_SCHEMA)
    _execute_sql(f'DELETE FROM "{_INSTALLED_APPS_TABLE}"')

    for app_label in sorted(current):
        _save_model(
            _INSTALLED_APPS_TABLE,
            _INSTALLED_APPS_SCHEMA,
            {"label": app_label},
        )


def _load_installed_app_labels() -> set[str]:
    _ensure_model_table(_INSTALLED_APPS_TABLE, _INSTALLED_APPS_SCHEMA)
    payload = json.dumps(
        [{"op": "all", "filters": {}}],
        separators=(",", ":"),
        sort_keys=True,
    )
    rows = _execute_query(
        _INSTALLED_APPS_TABLE,
        payload,
        {"id": "integer", "label": "text"},
    )
    if not isinstance(rows, list):
        return set()

    labels: set[str] = set()
    for row in rows:
        if not isinstance(row, dict):
            continue
        label = row.get("label")
        if isinstance(label, str):
            labels.add(label)
    return labels


def _apps_with_applied_migrations(app_labels: set[str]) -> set[str]:
    if not app_labels:
        return set()

    _ensure_model_table(_MIGRATIONS_TABLE, _MIGRATIONS_SCHEMA)
    payload = json.dumps(
        [
            {
                "op": "filter",
                "conditions": [
                    {
                        "field": "app",
                        "lookup": "in",
                        "value": sorted(app_labels),
                    }
                ],
            },
            {"op": "all", "filters": {}},
        ],
        separators=(",", ":"),
        sort_keys=True,
    )
    rows = _execute_query(
        _MIGRATIONS_TABLE,
        payload,
        {"id": "integer", "app": "text", "name": "text"},
    )
    if not isinstance(rows, list):
        return set()

    blocked: set[str] = set()
    for row in rows:
        if not isinstance(row, dict):
            continue
        app = row.get("app")
        if isinstance(app, str):
            blocked.add(app)
    return blocked


def _validate_startup_sanity() -> None:
    global _MIDDLEWARE_STACK

    root_urlconf = getattr(settings, "ROOT_URLCONF", None)
    try:
        importlib.import_module(str(root_urlconf))
    except ModuleNotFoundError as err:
        if err.name == root_urlconf:
            raise ImproperlyConfigured(
                f"ROOT_URLCONF module '{root_urlconf}' could not be imported"
            ) from err
        raise ImproperlyConfigured(
            f"failed importing ROOT_URLCONF '{root_urlconf}': {err}"
        ) from err

    from .middleware import load_middleware

    middleware_paths = getattr(settings, "MIDDLEWARE", [])
    try:
        _MIDDLEWARE_STACK = load_middleware(middleware_paths)
    except RuntimeError as err:
        raise ImproperlyConfigured(str(err)) from err


_enforce_runtime_requirements()
