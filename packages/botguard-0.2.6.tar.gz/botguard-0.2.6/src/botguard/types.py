﻿"""Type definitions for BotGuard SDK."""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Union


@dataclass
class ShieldVerdict:
    """Result of BotGuard Shield analysis."""
    action: str  # "allowed", "blocked_input", "blocked_output"
    reason: Optional[str] = None
    confidence: Optional[float] = None
    analysis_path: Optional[str] = None
    matched_patterns: Optional[List[str]] = None
    pii_detections: Optional[List[Dict[str, Any]]] = None
    guardrail_violation: Optional[str] = None
    policy_violation: Optional[str] = None
    latency_ms: Optional[int] = None

    @property
    def blocked(self) -> bool:
        return self.action != "allowed"


@dataclass
class ShieldResult:
    """Wraps an OpenAI response with Shield analysis metadata."""
    response: Any
    shield: ShieldVerdict = field(default_factory=lambda: ShieldVerdict(action="allowed"))

    @property
    def blocked(self) -> bool:
        return self.shield.blocked

    @property
    def content(self) -> Optional[str]:
        try:
            if isinstance(self.response, dict):
                return self.response["choices"][0]["message"]["content"]
            return self.response.choices[0].message.content
        except (AttributeError, IndexError, KeyError, TypeError):
            return None


@dataclass
class McpScanResult:
    """Result of scanning an MCP tool response for indirect injection."""
    blocked: bool
    confidence: float
    safe_response: Optional[str]
    tool_name: Optional[str] = None
    reason: Optional[str] = None
    analysis_path: Optional[str] = None
    matched_patterns: Optional[List[str]] = None
    pii_detections: Optional[List[Dict[str, Any]]] = None


@dataclass
class RagChunkResult:
    """Scan result for a single RAG document chunk."""
    chunk: str
    blocked: bool
    confidence: float
    reason: Optional[str] = None
    analysis_path: Optional[str] = None
    matched_patterns: Optional[List[str]] = None
    pii_detections: Optional[List[Dict[str, Any]]] = None


@dataclass
class RagScanResult:
    """Result of scanning a batch of RAG document chunks."""
    results: List[RagChunkResult]
    clean_chunks: List[str]
    blocked_count: int
    total_count: int
