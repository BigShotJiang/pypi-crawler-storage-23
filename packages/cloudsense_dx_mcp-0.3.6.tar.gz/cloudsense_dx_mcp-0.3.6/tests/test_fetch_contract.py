"""Tests for the fetch_orchestration_templates tool contract."""

import asyncio
import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from cloudsense_dx_mcp.tools.fetch_templates import (
    _clamp_workers,
    _escape_soql_string,
    _sanitize_filename,
    _fetch_all_async,
    execute,
)


class TestFetchAllContract:
    """Verify fetch_all / template_names guardrails."""

    @pytest.mark.asyncio
    async def test_rejects_missing_both(self):
        result = json.loads(await execute({}))
        assert result["success"] is False
        assert "must provide" in result["error"].lower()

    @pytest.mark.asyncio
    async def test_rejects_empty_template_names_without_fetch_all(self):
        result = json.loads(await execute({"template_names": []}))
        assert result["success"] is False

    @pytest.mark.asyncio
    async def test_rejects_both_template_names_and_fetch_all(self):
        result = json.loads(await execute({
            "template_names": ["Foo"],
            "fetch_all": True,
        }))
        assert result["success"] is False
        assert "cannot specify both" in result["error"].lower()

    @pytest.mark.asyncio
    async def test_accepts_fetch_all_true(self):
        mock_org = {"org_alias": "test-org", "org_source": "session"}
        mock_records = {"records": [{"Name": "Template A"}]}
        fetch_result = [{"name": "Template A", "success": True, "file": "/tmp/a.json"}]

        with (
            patch("cloudsense_dx_mcp.tools.fetch_templates.resolve_org_async",
                  new_callable=AsyncMock, return_value=mock_org),
            patch("cloudsense_dx_mcp.tools.fetch_templates.run_soql_async",
                  new_callable=AsyncMock, return_value=mock_records),
            patch("cloudsense_dx_mcp.tools.fetch_templates._fetch_all_async",
                  new_callable=AsyncMock, return_value=fetch_result),
            patch("pathlib.Path.mkdir"),
        ):
            result = json.loads(await execute({"fetch_all": True}))
            assert result["success"] is True
            assert "elapsed_seconds" in result

    @pytest.mark.asyncio
    async def test_fetch_all_skips_validation(self):
        """When fetch_all=True, _validate_template_names should NOT be called."""
        mock_org = {"org_alias": "test-org", "org_source": "session"}
        mock_records = {"records": [{"Name": "A"}]}
        fetch_result = [{"name": "A", "success": True, "file": "/tmp/a.json"}]

        with (
            patch("cloudsense_dx_mcp.tools.fetch_templates.resolve_org_async",
                  new_callable=AsyncMock, return_value=mock_org),
            patch("cloudsense_dx_mcp.tools.fetch_templates.run_soql_async",
                  new_callable=AsyncMock, return_value=mock_records),
            patch("cloudsense_dx_mcp.tools.fetch_templates._validate_template_names",
                  new_callable=AsyncMock) as mock_validate,
            patch("cloudsense_dx_mcp.tools.fetch_templates._fetch_all_async",
                  new_callable=AsyncMock, return_value=fetch_result),
            patch("pathlib.Path.mkdir"),
        ):
            await execute({"fetch_all": True})
            mock_validate.assert_not_called()

    @pytest.mark.asyncio
    async def test_explicit_names_does_validate(self):
        """When template_names provided, _validate_template_names IS called."""
        mock_org = {"org_alias": "test-org", "org_source": "user"}
        mock_validate = {"found": ["Foo"], "not_found": [], "available": []}
        fetch_result = [{"name": "Foo", "success": True, "file": "/tmp/foo.json"}]

        with (
            patch("cloudsense_dx_mcp.tools.fetch_templates.resolve_org_async",
                  new_callable=AsyncMock, return_value=mock_org),
            patch("cloudsense_dx_mcp.tools.fetch_templates._validate_template_names",
                  new_callable=AsyncMock, return_value=mock_validate) as mock_val,
            patch("cloudsense_dx_mcp.tools.fetch_templates._fetch_all_async",
                  new_callable=AsyncMock, return_value=fetch_result),
            patch("pathlib.Path.mkdir"),
        ):
            result = json.loads(await execute({"template_names": ["Foo"]}))
            assert result["success"] is True
            mock_val.assert_called_once()


class TestProgressCallback:
    """Verify that progress_callback is invoked during async fetch."""

    @pytest.mark.asyncio
    async def test_callback_called_per_template(self):
        callback = AsyncMock()

        async def fake_fetch(name, org, out_dir, sem):
            return {"name": name, "success": True, "file": f"/tmp/{name}.json"}

        with patch(
            "cloudsense_dx_mcp.tools.fetch_templates._fetch_single_template_async",
            side_effect=fake_fetch,
        ):
            results = await _fetch_all_async(
                ["A", "B", "C"], "org", "/tmp", 8, progress_callback=callback
            )
            assert len(results) == 3
            assert callback.call_count == 3

    @pytest.mark.asyncio
    async def test_callback_failure_does_not_break_fetch(self):
        callback = AsyncMock(side_effect=Exception("notification failed"))

        async def fake_fetch(name, org, out_dir, sem):
            return {"name": name, "success": True, "file": f"/tmp/{name}.json"}

        with patch(
            "cloudsense_dx_mcp.tools.fetch_templates._fetch_single_template_async",
            side_effect=fake_fetch,
        ):
            results = await _fetch_all_async(
                ["A", "B"], "org", "/tmp", 8, progress_callback=callback
            )
            assert len(results) == 2
            assert all(r["success"] for r in results)


class TestClampWorkers:
    def test_default_on_none(self):
        assert _clamp_workers(None) == 8

    def test_default_on_string(self):
        assert _clamp_workers("abc") == 8

    def test_minimum_is_one(self):
        assert _clamp_workers(0) == 1
        assert _clamp_workers(-5) == 1

    def test_clamps_to_upper_bound(self):
        assert _clamp_workers(999) <= 8

    def test_normal_value(self):
        assert _clamp_workers(3) == 3


class TestSanitizeFilename:
    def test_replaces_spaces(self):
        assert _sanitize_filename("Hello World") == "Hello_World"

    def test_replaces_special_chars(self):
        assert _sanitize_filename('a<b>c:d"e') == "a_b_c_d_e"

    def test_strips_leading_dots(self):
        assert _sanitize_filename("...test") == "test"

    def test_handles_empty_after_strip(self):
        assert _sanitize_filename("___") == ""


class TestEscapeSoqlString:
    def test_escapes_single_quote(self):
        assert _escape_soql_string("it's") == "it\\'s"

    def test_escapes_backslash(self):
        assert _escape_soql_string("a\\b") == "a\\\\b"

    def test_escapes_both(self):
        assert _escape_soql_string("it\\'s") == "it\\\\\\'s"

    def test_no_change_for_safe_string(self):
        assert _escape_soql_string("Hello World") == "Hello World"
