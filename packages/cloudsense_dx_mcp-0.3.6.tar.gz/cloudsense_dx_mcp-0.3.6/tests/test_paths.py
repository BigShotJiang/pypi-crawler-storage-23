"""Tests for cross-platform path handling."""

import os
from pathlib import Path

from cloudsense_dx_mcp.tools.fetch_templates import _sanitize_filename


class TestOutputPathConstruction:
    def test_sanitized_folder_name(self):
        assert _sanitize_filename("my-org") == "my-org"
        assert _sanitize_filename("org with spaces") == "org_with_spaces"
        assert _sanitize_filename("org/with:special") == "org_with_special"

    def test_pathlib_join_is_cross_platform(self):
        base = Path("/tmp/exports")
        org = _sanitize_filename("test-org")
        result = base / "cloudsense-dx-exports" / "orchestration-templates" / org / "2025-01-01_00-00-00"
        assert "test-org" in str(result)
        assert isinstance(result, Path)

    def test_export_root_env_var_is_respected(self):
        custom_root = "/custom/export/root"
        original = os.environ.get("CLOUDSENSE_DX_EXPORT_ROOT")
        try:
            os.environ["CLOUDSENSE_DX_EXPORT_ROOT"] = custom_root
            root = Path(os.getenv("CLOUDSENSE_DX_EXPORT_ROOT", Path.cwd()))
            assert str(root) == custom_root
        finally:
            if original is None:
                os.environ.pop("CLOUDSENSE_DX_EXPORT_ROOT", None)
            else:
                os.environ["CLOUDSENSE_DX_EXPORT_ROOT"] = original
