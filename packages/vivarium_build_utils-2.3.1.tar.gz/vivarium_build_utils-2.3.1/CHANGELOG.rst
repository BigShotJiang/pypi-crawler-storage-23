**2.3.1 - 02/23/26**

  - Increase cleanup job timeout

**2.3.0 - 02/18/26**

  - Feature: Support python 3.13
  - Command: `make build-env` now defaults to python 3.13

**2.2.4 - 02/10/26**

  - Bugfix: fix timeout env variable in jenkinsfile
  - Bugfix: fix the cleanup depth for the shared directory
  - Bugfix: fix doc-only / changelog-only skipping behavior

**2.2.3 - 02/09/26**

  - Increase the cleanup Jenkins job timeout to 120 minutes
  - Message the slack channel when the cleanup job is aborted

**2.2.2 - 01/27/26**

  - Stop skipping any builds (temporary)

**2.2.1 - 01/27/26**

  - Stop skipping builds if CHANGELOG-only commit (temporary)

**2.2.0 - 01/26/26**

  - Feature: Add shared model environments nightly build

**2.1.2 - 01/15/26**

  - Bugfix: use PST timezone for CHANGELOG date validation

**2.1.1 - 01/06/26**

  - Fail deployment if CHANGELOG date does not match current date
  - Add CHANGELOG date validation for Jenkins pipeline

**2.1.0 - 12/16/2025**

  - Feature: Add model lineage analysis utility

**2.0.13 - 11/21/2025**

  - Bugfix: stop skipping scheduled builds if the last commit was CHANGELOG-only

**2.0.12 - 10/22/2025**

  - Skip Jenkins builds for CHANGELOG-only commits
  - Skip doc checks if there is no docs/ directory

**2.0.11 - 10/7/2025**

  - Stop cacheing secondary uv pip install

**2.0.10 - 10/2/2025**

  - Bugfix: Remove Make sources

**2.0.9 - 10/1/2025**

  - Bugfix: Change name of doc build directory

**2.0.8 - 9/24/2025**

  - Revert disabling dependent branch installs (v2.0.7)
  - Stop explicit folder deletion in cleanup

**2.0.7 - 9/23/2025**

  - Disable dependent branch installs

**2.0.6 - 8/20/2025**

  - Validate arguments passed to reusable_pipeline.groovy

**2.0.5 - 8/8/2025**

  - Create pipeline to clean up Jenkins build directories

**2.0.4 - 8/6/2025**

  - Revert v2.0.3

**2.0.3 - 8/5/2025**

  - Use Jenkins node /tmp/ dir (reversion from v2.0.2) until permissions get resolved

**2.0.2 - 8/4/2025**

  - Create all Jenkins build envs in shared team folder

**2.0.1 - 7/25/2025**

  - Bugfix: fix broken doc stages in Jenkins pipeline

**2.0.0 - 7/24/2025**

  - Clean up and better document Make files

**1.1.2 - 7/16/2025**

  - Bugfix: typo in extra-index-url

**1.1.1 - 7/16/2025**

  - Bugfix: fix broken pip install --dry-run call in get_vbu_version.py

**1.1.0 - 7/15/2025**

  - Allow for pinning in other repos

**1.0.0 - 7/8/2025**

  - Initial major release

**0.1.0 - 7/8/2025**

  - Initial rc release
