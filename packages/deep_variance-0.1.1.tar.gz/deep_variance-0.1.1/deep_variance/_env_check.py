"""
Environment checks for deep_variance: C++ compiler, PyTorch, and CUDA.

Supports HPC environments where CUDA is provided via `module load cuda`.
"""

from __future__ import annotations

import os
import platform
import shutil
import subprocess
import sys
from typing import Optional, Tuple


def _find_cxx() -> Optional[str]:
    """Find a suitable C++ compiler (CXX env, g++, clang++, etc.)."""
    cxx = os.environ.get("CXX")
    if cxx and shutil.which(cxx.split()[0]):
        return cxx
    for name in ("g++", "clang++", "c++", "gcc", "clang"):
        path = shutil.which(name)
        if path:
            # Prefer g++/clang++ for C++; gcc/clang can work with -x c++
            if "++" in name or name in ("gcc", "clang"):
                return path
    return None


def _try_module_load_cuda() -> Tuple[bool, str]:
    """
    Try to run `module load cuda` (or equivalent) if the environment
    supports modules. Returns (success, message).
    """
    modulecmd = shutil.which("modulecmd") or os.environ.get("MODULESHOME", "")
    if modulecmd and not modulecmd.endswith("modulecmd"):
        modulecmd = os.path.join(modulecmd, "bin", "modulecmd")
    if not modulecmd or not os.path.isfile(modulecmd):
        return False, "modulecmd not found (no environment modules)"

    try:
        # modulecmd python load cuda 2>&1 prints Python code that sets env
        out = subprocess.run(
            [modulecmd, "python", "load", "cuda"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if out.returncode != 0:
            return False, (out.stderr or out.stdout or "module load cuda failed").strip()
        # Execute the emitted Python code to apply env changes in current process
        exec(out.stdout)
        return True, "module load cuda succeeded"
    except FileNotFoundError:
        return False, "modulecmd not found"
    except subprocess.TimeoutExpired:
        return False, "module load cuda timed out"
    except Exception as e:
        return False, str(e)


def ensure_cuda_visible(use_module: bool = True) -> None:
    """
    Optionally run `module load cuda` so that CUDA is visible to this process.
    Call this before importing torch or using GPU features if you are in an
    HPC environment where CUDA is not on the default path.

    Args:
        use_module: If True, attempt `module load cuda` when CUDA is not
                    detected. If False, only check and do not run module.
    """
    try:
        import torch
        if torch.cuda.is_available():
            return
    except ImportError:
        pass

    if not use_module:
        return

    ok, msg = _try_module_load_cuda()
    if not ok:
        # Not fatal; user may have CUDA in path already or will set it
        import warnings
        warnings.warn(
            f"CUDA not visible and module load failed: {msg}. "
            "Set CUDA_HOME or load the cuda module manually if needed.",
            UserWarning,
            stacklevel=2,
        )


def check_environment(
    *,
    check_compiler: bool = True,
    check_torch: bool = True,
    check_cuda: bool = True,
    try_module_load: bool = False,
) -> dict:
    """
    Check that the environment is suitable for building and running deep_variance.

    Returns a dict with keys:
      - cxx: (bool, str) — C++ compiler found and path/name
      - torch: (bool, str) — PyTorch import and version or error
      - cuda: (bool, str) — CUDA available to PyTorch and version or error
    """
    result = {}

    if check_compiler:
        cxx = _find_cxx()
        result["cxx"] = (cxx is not None, cxx or "no C++ compiler found")
    else:
        result["cxx"] = (True, "skipped")

    if try_module_load:
        ensure_cuda_visible(use_module=True)

    if check_torch:
        try:
            import torch
            result["torch"] = (True, f"torch {torch.__version__}")
        except ImportError as e:
            result["torch"] = (False, str(e))
    else:
        result["torch"] = (True, "skipped")

    if check_cuda:
        try:
            import torch
            if torch.cuda.is_available():
                dev = torch.cuda.get_device_name(0) if torch.cuda.device_count() else "N/A"
                result["cuda"] = (True, dev)
            else:
                result["cuda"] = (False, "torch.cuda.is_available() is False")
        except Exception as e:
            result["cuda"] = (False, str(e))
    else:
        result["cuda"] = (True, "skipped")

    return result


def print_environment_report(report: Optional[dict] = None) -> None:
    """Print a short report of check_environment() to stderr."""
    if report is None:
        report = check_environment(try_module_load=False)
    sys.stderr.write("deep_variance environment:\n")
    for name, (ok, msg) in report.items():
        status = "ok" if ok else "MISSING"
        sys.stderr.write(f"  {name}: [{status}] {msg}\n")


def main() -> None:
    """Entry point for the deep_variance-check script."""
    import argparse
    p = argparse.ArgumentParser(description="Check deep_variance build/run environment (C++, PyTorch, CUDA).")
    p.add_argument("--module-load", action="store_true", help="Try 'module load cuda' if CUDA not visible.")
    p.add_argument("--quiet", "-q", action="store_true", help="Only exit 0 if all checks pass, else 1.")
    args = p.parse_args()
    report = check_environment(try_module_load=args.module_load)
    print_environment_report(report)
    if args.quiet:
        sys.exit(0 if all(ok for ok, _ in report.values()) else 1)
