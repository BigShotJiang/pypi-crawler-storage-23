# deep_variance.movie — GPU virtual memory allocator (MOVie-min) API
from __future__ import annotations

import torch
from torch.utils.dlpack import from_dlpack

# Lazy import so we can run check_environment before building
def _get_ext():
    from deep_variance import _movie_vmm_ext
    return _movie_vmm_ext

_DLPACK_INT = 0
_DLPACK_UINT = 1
_DLPACK_FLOAT = 2
_DLPACK_BFLOAT = 4


def _dtype_to_dlpack(dtype: torch.dtype):
    if dtype == torch.float32:
        return _DLPACK_FLOAT, 32, 1
    if dtype == torch.float16:
        return _DLPACK_FLOAT, 16, 1
    if dtype == torch.bfloat16:
        return _DLPACK_BFLOAT, 16, 1
    if dtype == torch.int8:
        return _DLPACK_INT, 8, 1
    if dtype == torch.uint8:
        return _DLPACK_UINT, 8, 1
    if dtype == torch.int32:
        return _DLPACK_INT, 32, 1
    if dtype == torch.int64:
        return _DLPACK_INT, 64, 1
    raise ValueError(f"Unsupported dtype: {dtype}")


def movie_empty(numel: int, dtype=torch.float32, device="cuda:0", chunk_bytes: int = 0):
    if numel <= 0:
        raise ValueError("numel must be > 0")
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is not available")

    dev = torch.device(device)
    if dev.type != "cuda":
        raise ValueError("device must be a CUDA device like 'cuda:0'")

    device_id = int(dev.index or 0)
    code, bits, lanes = _dtype_to_dlpack(dtype)

    ext = _get_ext()
    cap = ext.movie_alloc_dlpack(
        int(numel),
        int(device_id),
        int(chunk_bytes),
        int(code),
        int(bits),
        int(lanes),
    )

    t = from_dlpack(cap)

    if t.device.type != "cuda":
        raise RuntimeError(f"Expected CUDA tensor, got {t.device}")
    if t.dtype != dtype:
        raise RuntimeError(f"Dtype mismatch: expected {dtype}, got {t.dtype}")
    if t.numel() != numel:
        raise RuntimeError(f"Numel mismatch: expected {numel}, got {t.numel}")

    return t


def set_cache_limit(device_id: int = 0, chunk_bytes: int = 0, max_bytes: int = 2 * 1024**3):
    return _get_ext().set_cache_limit(int(device_id), int(chunk_bytes), int(max_bytes))


def cache_stats():
    return _get_ext().cache_stats()


def movie_empty_nd(shape, dtype=torch.float32, device="cuda:0", chunk_bytes: int = 0):
    if isinstance(shape, int):
        shape = (shape,)
    numel = 1
    for s in shape:
        s = int(s)
        if s <= 0:
            raise ValueError("All shape dims must be > 0")
        numel *= s
    t1d = movie_empty(numel, dtype=dtype, device=device, chunk_bytes=chunk_bytes)
    return t1d.view(*shape)
