#include <torch/extension.h>
#include <pybind11/pybind11.h>
#include <cuda.h>

#include <cstdint>
#include <cstdlib>
#include <stdexcept>
#include <vector>
#include <string>
#include <unordered_map>
#include <mutex>
#include <algorithm>

// -------------------- Minimal DLPack header --------------------
extern "C" {

typedef enum { kDLCPU = 1, kDLCUDA = 2 } DLDeviceType;

typedef struct {
  DLDeviceType device_type;
  int device_id;
} DLDevice;

typedef enum {
  kDLInt = 0U,
  kDLUInt = 1U,
  kDLFloat = 2U,
  kDLBfloat = 4U,
} DLDataTypeCode;

typedef struct {
  uint8_t code;
  uint8_t bits;
  uint16_t lanes;
} DLDataType;

typedef struct {
  void* data;
  DLDevice device;
  int ndim;
  DLDataType dtype;
  int64_t* shape;
  int64_t* strides;
  uint64_t byte_offset;
} DLTensor;

typedef struct DLManagedTensor {
  DLTensor dl_tensor;
  void* manager_ctx;
  void (*deleter)(struct DLManagedTensor* self);
} DLManagedTensor;

} // extern "C"

// -------------------- Helpers --------------------
static void throw_if(CUresult r, const char* what) {
  if (r != CUDA_SUCCESS) {
    const char* name = nullptr;
    const char* desc = nullptr;
    cuGetErrorName(r, &name);
    cuGetErrorString(r, &desc);
    std::string msg = std::string(what) + " failed: " +
                      (name ? name : "UNKNOWN") + " / " +
                      (desc ? desc : "no description");
    throw std::runtime_error(msg);
  }
}

static size_t round_up(size_t x, size_t a) {
  return ((x + a - 1) / a) * a;
}

// -------------------- MOVie-min cache (physical chunk handles) --------------------
struct CacheKey {
  int device_id;
  size_t chunk_bytes;
  bool operator==(const CacheKey& o) const {
    return device_id == o.device_id && chunk_bytes == o.chunk_bytes;
  }
};

struct CacheKeyHash {
  std::size_t operator()(const CacheKey& k) const noexcept {
    return std::hash<int>()(k.device_id) ^ (std::hash<size_t>()(k.chunk_bytes) << 1);
  }
};

struct ChunkPool {
  std::vector<CUmemGenericAllocationHandle> free_handles;
  size_t bytes_in_pool = 0;
  size_t max_bytes = (size_t)2 * 1024 * 1024 * 1024; // default 2GB cache per key
};

static std::unordered_map<CacheKey, ChunkPool, CacheKeyHash> g_cache;
static std::mutex g_cache_mu;

static std::vector<CUmemGenericAllocationHandle> cache_pop(int device_id, size_t chunk_bytes, size_t n) {
  std::lock_guard<std::mutex> lk(g_cache_mu);
  CacheKey key{device_id, chunk_bytes};
  auto it = g_cache.find(key);
  if (it == g_cache.end()) return {};

  ChunkPool& pool = it->second;
  size_t take = std::min(n, pool.free_handles.size());
  std::vector<CUmemGenericAllocationHandle> out;
  out.reserve(take);

  for (size_t i = 0; i < take; i++) {
    auto h = pool.free_handles.back();
    pool.free_handles.pop_back();
    pool.bytes_in_pool -= chunk_bytes;
    out.push_back(h);
  }
  return out;
}

static void cache_push_or_release(int device_id,
                                  size_t chunk_bytes,
                                  std::vector<CUmemGenericAllocationHandle>&& handles) {
  if (handles.empty()) return;

  std::vector<CUmemGenericAllocationHandle> to_release;

  {
    std::lock_guard<std::mutex> lk(g_cache_mu);
    CacheKey key{device_id, chunk_bytes};
    ChunkPool& pool = g_cache[key];

    for (auto h : handles) {
      if (pool.bytes_in_pool + chunk_bytes <= pool.max_bytes) {
        pool.free_handles.push_back(h);
        pool.bytes_in_pool += chunk_bytes;
      } else {
        to_release.push_back(h);
      }
    }
  }

  for (auto h : to_release) {
    (void)cuMemRelease(h);
  }
}

static void set_cache_limit(int device_id, size_t chunk_bytes, size_t max_bytes) {
  std::lock_guard<std::mutex> lk(g_cache_mu);
  CacheKey key{device_id, chunk_bytes};
  ChunkPool& pool = g_cache[key];
  pool.max_bytes = max_bytes;

  while (pool.bytes_in_pool > pool.max_bytes && !pool.free_handles.empty()) {
    auto h = pool.free_handles.back();
    pool.free_handles.pop_back();
    pool.bytes_in_pool -= chunk_bytes;
    (void)cuMemRelease(h);
  }
}

static pybind11::dict cache_stats() {
  std::lock_guard<std::mutex> lk(g_cache_mu);
  pybind11::dict d;
  for (const auto& kv : g_cache) {
    const auto& key = kv.first;
    const auto& pool = kv.second;
    std::string k = "dev" + std::to_string(key.device_id) + "_chunk" + std::to_string(key.chunk_bytes);
    pybind11::dict v;
    v["free_chunks"] = (long long)pool.free_handles.size();
    v["bytes_in_pool"] = (long long)pool.bytes_in_pool;
    v["max_bytes"] = (long long)pool.max_bytes;
    d[pybind11::str(k)] = v;
  }
  return d;
}

// -------------------- Allocation record --------------------
struct VmmAlloc {
  CUdeviceptr vaddr = 0;
  size_t total_bytes = 0;
  size_t chunk_bytes = 0;
  int device_id = 0;
  std::vector<CUmemGenericAllocationHandle> handles;
  bool cache_on_free = true;
};

// -------------------- DLPack deleter --------------------
static void dlpack_deleter(DLManagedTensor* self) {
  if (!self) return;
  VmmAlloc* rec = reinterpret_cast<VmmAlloc*>(self->manager_ctx);

  if (rec) {
    // Unmap
    size_t offset = 0;
    for (size_t i = 0; i < rec->handles.size(); i++) {
      (void)cuMemUnmap(rec->vaddr + offset, rec->chunk_bytes);
      offset += rec->chunk_bytes;
    }

    // Free VA
    if (rec->vaddr) {
      (void)cuMemAddressFree(rec->vaddr, rec->total_bytes);
    }

    // Return handles to cache (or release)
    if (rec->cache_on_free) {
      cache_push_or_release(rec->device_id, rec->chunk_bytes, std::move(rec->handles));
    } else {
      for (auto h : rec->handles) (void)cuMemRelease(h);
    }

    delete rec;
  }

  if (self->dl_tensor.shape) std::free(self->dl_tensor.shape);
  if (self->dl_tensor.strides) std::free(self->dl_tensor.strides);
  std::free(self);
}

// Safe capsule destructor: free only if still named "dltensor"
static void dlpack_capsule_destructor(PyObject* capsule) {
  if (!capsule) return;
  if (PyCapsule_IsValid(capsule, "dltensor")) {
    DLManagedTensor* mt =
        reinterpret_cast<DLManagedTensor*>(PyCapsule_GetPointer(capsule, "dltensor"));
    if (mt && mt->deleter) mt->deleter(mt);
  }
}

static pybind11::capsule make_dlpack_capsule(VmmAlloc* rec,
                                            int64_t numel,
                                            DLDataType dtype) {
  DLManagedTensor* mt = (DLManagedTensor*)std::calloc(1, sizeof(DLManagedTensor));
  if (!mt) throw std::runtime_error("calloc DLManagedTensor failed");

  mt->manager_ctx = rec;
  mt->deleter = &dlpack_deleter;

  mt->dl_tensor.data = (void*)rec->vaddr;
  mt->dl_tensor.device = {kDLCUDA, rec->device_id};
  mt->dl_tensor.ndim = 1;
  mt->dl_tensor.dtype = dtype;
  mt->dl_tensor.byte_offset = 0;

  mt->dl_tensor.shape = (int64_t*)std::malloc(sizeof(int64_t));
  mt->dl_tensor.strides = (int64_t*)std::malloc(sizeof(int64_t));
  if (!mt->dl_tensor.shape || !mt->dl_tensor.strides) {
    dlpack_deleter(mt);
    throw std::runtime_error("malloc shape/strides failed");
  }
  mt->dl_tensor.shape[0] = numel;
  mt->dl_tensor.strides[0] = 1;

  pybind11::capsule cap(mt, "dltensor", dlpack_capsule_destructor);
  return cap;
}

// -------------------- MOVie-min allocator (stitch + cache) --------------------
static pybind11::capsule movie_alloc_dlpack(int64_t numel,
                                           int device_id,
                                           size_t chunk_bytes,
                                           int dtype_code,
                                           int dtype_bits,
                                           int dtype_lanes) {
  if (numel <= 0) throw std::runtime_error("numel must be > 0");
  if (dtype_bits % 8 != 0) throw std::runtime_error("dtype_bits must be multiple of 8");
  int itemsize = (dtype_bits / 8) * dtype_lanes;
  if (itemsize <= 0) throw std::runtime_error("invalid dtype itemsize");

  throw_if(cuInit(0), "cuInit");
  CUdevice dev;
  throw_if(cuDeviceGet(&dev, device_id), "cuDeviceGet");

  CUcontext ctx;
  throw_if(cuDevicePrimaryCtxRetain(&ctx, dev), "cuDevicePrimaryCtxRetain");
  throw_if(cuCtxSetCurrent(ctx), "cuCtxSetCurrent");

  // Granularity
  CUmemAllocationProp prop{};
  prop.type = CU_MEM_ALLOCATION_TYPE_PINNED;
  prop.location.type = CU_MEM_LOCATION_TYPE_DEVICE;
  prop.location.id = device_id;

  size_t gran = 0;
  throw_if(cuMemGetAllocationGranularity(&gran, &prop, CU_MEM_ALLOC_GRANULARITY_MINIMUM),
           "cuMemGetAllocationGranularity");

  if (chunk_bytes == 0) chunk_bytes = gran;
  if (chunk_bytes < gran) chunk_bytes = gran;
  chunk_bytes = round_up(chunk_bytes, gran);

  size_t total = (size_t)numel * (size_t)itemsize;
  size_t total_rounded = round_up(total, chunk_bytes);
  size_t n_chunks = total_rounded / chunk_bytes;

  // MATCH+MERGE (min): pull from cache; create rest
  std::vector<CUmemGenericAllocationHandle> handles = cache_pop(device_id, chunk_bytes, n_chunks);
  if (handles.size() < n_chunks) {
    size_t need = n_chunks - handles.size();
    handles.reserve(n_chunks);
    for (size_t i = 0; i < need; i++) {
      CUmemGenericAllocationHandle h;
      throw_if(cuMemCreate(&h, chunk_bytes, &prop, 0), "cuMemCreate");
      handles.push_back(h);
    }
  }

  // Reserve contiguous VA
  CUdeviceptr vaddr = 0;
  throw_if(cuMemAddressReserve(&vaddr, total_rounded, 0, 0, 0), "cuMemAddressReserve");

  // Stitch map
  size_t offset = 0;
  for (size_t i = 0; i < n_chunks; i++) {
    throw_if(cuMemMap(vaddr + offset, chunk_bytes, 0, handles[i], 0), "cuMemMap");
    offset += chunk_bytes;
  }

  // Access
  CUmemAccessDesc accessDesc{};
  accessDesc.location.type = CU_MEM_LOCATION_TYPE_DEVICE;
  accessDesc.location.id = device_id;
  accessDesc.flags = CU_MEM_ACCESS_FLAGS_PROT_READWRITE;
  throw_if(cuMemSetAccess(vaddr, total_rounded, &accessDesc, 1), "cuMemSetAccess");

  auto* rec = new VmmAlloc();
  rec->vaddr = vaddr;
  rec->total_bytes = total_rounded;
  rec->chunk_bytes = chunk_bytes;
  rec->device_id = device_id;
  rec->handles = std::move(handles);
  rec->cache_on_free = true;

  DLDataType dt{};
  dt.code = (uint8_t)dtype_code;
  dt.bits = (uint8_t)dtype_bits;
  dt.lanes = (uint16_t)dtype_lanes;

  return make_dlpack_capsule(rec, numel, dt);
}

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
  m.def("movie_alloc_dlpack", &movie_alloc_dlpack,
        pybind11::arg("numel"),
        pybind11::arg("device_id") = 0,
        pybind11::arg("chunk_bytes") = 0,
        pybind11::arg("dtype_code") = (int)kDLFloat,
        pybind11::arg("dtype_bits") = 32,
        pybind11::arg("dtype_lanes") = 1,
        "MOVie-min: stitched contiguous CUDA tensor via VMM with cached physical chunks.");

  m.def("set_cache_limit", &set_cache_limit,
        pybind11::arg("device_id"),
        pybind11::arg("chunk_bytes"),
        pybind11::arg("max_bytes"),
        "Set max cache bytes for a given (device_id, chunk_bytes) pool.");

  m.def("cache_stats", &cache_stats,
        "Get cache stats for all pools.");
}