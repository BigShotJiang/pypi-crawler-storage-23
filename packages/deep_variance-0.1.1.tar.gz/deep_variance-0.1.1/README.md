# deep_variance

**GPU Virtual Memory Stitching SDK** — CUDA virtual memory management (VMM) with physical chunk caching and DLPack-backed PyTorch tensors.

Use this package on machines where **you have a CUDA-capable GPU**. The package is distributed as a **source distribution (sdist)** so it compiles on your environment, matching your CUDA and PyTorch versions.

## Requirements

- **Python** 3.8+
- **PyTorch** (any version with CUDA support; install the build that matches your CUDA, e.g. `pip install torch`)
- **CUDA** toolkit and driver (e.g. via `module load cuda` on HPC clusters)
- **C++ compiler** (e.g. `g++`, `clang++`) — set `CXX` if needed

## Install

1. Install PyTorch for your CUDA version (see [pytorch.org](https://pytorch.org)):

   ```bash
   pip install torch
   ```

2. On HPC, load CUDA if it’s not in your path:

   ```bash
   module load cuda   # or your site’s module name
   ```

3. Install from PyPI (source build on your machine):

   ```bash
   pip install deep_variance
   ```

   Or install from a source tree:

   ```bash
   pip install -e .
   ```

The build uses your environment’s C++ compiler (`CXX` or `g++`/`clang++`) and the CUDA/PyTorch configuration already present, so it works with different CUDA and PyTorch versions.

## Optional: environment check

Before building or at runtime you can check that the environment is suitable:

```python
from deep_variance import check_environment

report = check_environment()
for name, (ok, msg) in report.items():
    print(f"{name}: {'ok' if ok else 'MISSING'} — {msg}")
```

To try loading CUDA via environment modules (e.g. `module load cuda`) when it’s not visible:

```python
from deep_variance import ensure_cuda_visible
ensure_cuda_visible(use_module=True)
```

## Usage

```python
import torch
from deep_variance import movie_empty, movie_empty_nd, set_cache_limit, cache_stats

# Allocate a 1D tensor (1M float32 elements) on the default CUDA device
t = movie_empty(1_000_000, dtype=torch.float32, device="cuda:0")

# Allocate with a shape
t = movie_empty_nd((100, 1000), dtype=torch.float32)

# Optional: set cache limit (e.g. 2 GB per pool)
set_cache_limit(device_id=0, chunk_bytes=0, max_bytes=2 * 1024**3)

# Inspect cache stats
stats = cache_stats()
```

## Build customization

- **C++ compiler**: set `CXX` (e.g. `export CXX=clang++`).
- **C++ flags**: set `DEEP_VARIANCE_CXXFLAGS` (space-separated).
- **NVCC flags**: set `DEEP_VARIANCE_NVCCFLAGS` (space-separated).

## Publishing to PyPI (maintainers)

You can build the sdist on any machine (no GPU needed); the archive only contains source. Users compile when they `pip install` on their own GPU machines.

1. Install build and twine: `pip install build twine`
2. Install PyTorch (CPU-only is enough for building the sdist): `pip install torch`
3. Create a **source distribution** only (no wheel; users compile on their GPU):

   ```bash
   python -m build --sdist
   ```

3. Upload to PyPI:

   ```bash
   twine upload dist/deep_variance-*.tar.gz
   ```

   Use `twine upload -r testpypi dist/deep_variance-*.tar.gz` for TestPyPI first.

4. Users install with: `pip install deep_variance` (pip will fetch the sdist and build locally).

## License

MIT
