"""Tests for CLI task type and LLM resolution."""

from milco.cli import main


def _write_contract(tmp_path, task_type="map-gen", confirm=True):
    text = (
        "# Task Contract\n\n"
        f"## Task Type\n\n{task_type}\n\n"
        "## Goal\n\nTest.\n\n"
        "## Scope\n\nTest.\n\n"
        "## Out of scope\n\nNone.\n\n"
        "## Success Criteria\n\nPass.\n\n"
        "## Constraints\n\nNone.\n\n"
        "## Approvals required\n\n"
    )
    if confirm:
        text += "CONFIRM APPLY\n\n"
    else:
        text += "None.\n\n"
    text += "## Notes\n\nNone.\n"
    p = tmp_path / "TASK_CONTRACT.md"
    p.write_text(text, encoding="utf-8")
    return str(p)


def test_run_with_map_gen_task(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    contract = _write_contract(tmp_path, "map-gen")
    exit_code = main(["run", "--contract", contract])
    assert exit_code == 0


def test_run_unknown_task_type_refused(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    contract = _write_contract(tmp_path, "nonexistent-task")
    exit_code = main(["run", "--contract", contract])
    assert exit_code == 1


def test_run_llm_task_without_config_refused(tmp_path, monkeypatch):
    """doc-gen requires LLM, but no milco.toml exists -> REFUSED."""
    monkeypatch.chdir(tmp_path)
    import milco.tasks.map_gen  # noqa: F401
    from milco.tasks.registry import _registry, TaskBase, register_task

    if "doc-gen" not in _registry:

        @register_task("doc-gen")
        class _StubDocGen(TaskBase):
            needs_llm = True

            def fix(self, ctx):
                pass

    contract = _write_contract(tmp_path, "doc-gen")
    exit_code = main(["run", "--contract", contract])
    assert exit_code == 1
