"""Tests for task type registry."""

import pytest
from milco.tasks.registry import (
    register_task,
    get_task,
    list_tasks,
    TaskBase,
    _registry,
)


def setup_function():
    _registry.clear()


def test_register_and_retrieve():
    @register_task("test-task")
    class MyTask(TaskBase):
        needs_llm = False

        def fix(self, ctx):
            pass

    task_cls = get_task("test-task")
    assert task_cls is MyTask


def test_get_unknown_task_returns_none():
    assert get_task("nonexistent") is None


def test_list_tasks_empty():
    assert list_tasks() == []


def test_list_tasks_populated():
    @register_task("aaa")
    class A(TaskBase):
        needs_llm = False

        def fix(self, ctx):
            pass

    @register_task("bbb")
    class B(TaskBase):
        needs_llm = True

        def fix(self, ctx):
            pass

    names = list_tasks()
    assert "aaa" in names
    assert "bbb" in names


def test_duplicate_registration_raises():
    @register_task("dup")
    class First(TaskBase):
        needs_llm = False

        def fix(self, ctx):
            pass

    with pytest.raises(ValueError, match="already registered"):

        @register_task("dup")
        class Second(TaskBase):
            needs_llm = False

            def fix(self, ctx):
                pass


def test_task_needs_llm_attribute():
    @register_task("llm-task")
    class LlmTask(TaskBase):
        needs_llm = True

        def fix(self, ctx):
            pass

    cls = get_task("llm-task")
    assert cls.needs_llm is True
