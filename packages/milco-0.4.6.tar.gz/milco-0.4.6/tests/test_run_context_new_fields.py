"""Tests for new RunContext fields: task_type and llm."""

from milco.core.run_context import RunContext
from milco.llm.base import LLMProvider


def test_run_context_defaults():
    ctx = RunContext(repo_root=".")
    assert ctx.task_type is None
    assert ctx.llm is None


def test_run_context_with_task_type():
    ctx = RunContext(repo_root=".", task_type="doc-gen")
    assert ctx.task_type == "doc-gen"


def test_run_context_with_llm():
    provider = LLMProvider()
    ctx = RunContext(repo_root=".", llm=provider)
    assert ctx.llm is provider


def test_run_context_existing_fields_unchanged():
    ctx = RunContext(
        repo_root="/tmp/repo",
        run_id="abc",
        apply_mode=True,
        contract_path="contract.md",
    )
    assert str(ctx.repo_root) == "/tmp/repo"
    assert ctx.run_id == "abc"
    assert ctx.apply_mode is True
    assert ctx.contract_path == "contract.md"
