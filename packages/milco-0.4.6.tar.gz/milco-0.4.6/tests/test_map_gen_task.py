"""Tests for map-gen task type."""

from milco.core.run_context import RunContext
from milco.core.artifacts import write_artifact
from milco.tasks.registry import get_task

import milco.tasks.map_gen  # noqa: F401 -- force registration


def _make_ctx(tmp_path):
    contract = tmp_path / "TASK_CONTRACT.md"
    contract.write_text(
        "# Task Contract\n\n"
        "## Task Type\n\nmap-gen\n\n"
        "## Goal\n\nGenerate map.json.\n\n"
        "## Scope\n\nRepo scan.\n\n"
        "## Out of scope\n\nNothing.\n\n"
        "## Success Criteria\n\nmap.json created.\n\n"
        "## Constraints\n\nNone.\n\n"
        "## Approvals required\n\nCONFIRM APPLY\n\n"
        "## Notes\n\nNone.\n",
        encoding="utf-8",
    )
    ctx = RunContext(
        repo_root=tmp_path,
        run_id="test-mapgen",
        apply_mode=False,
        contract_path=str(contract),
    )
    write_artifact(ctx, "evidence.md", "# Evidence\n\nSome evidence.\n")
    return ctx


def test_map_gen_registered():
    cls = get_task("map-gen")
    assert cls is not None
    assert cls.needs_llm is False


def test_map_gen_fix_produces_diff(tmp_path):
    ctx = _make_ctx(tmp_path)
    cls = get_task("map-gen")
    task = cls()
    result = task.fix(ctx)
    assert result.success is True
    assert result.diff_text != ""


def test_map_gen_fix_writes_patches_diff(tmp_path):
    ctx = _make_ctx(tmp_path)
    task = get_task("map-gen")()
    task.fix(ctx)
    diff_path = ctx.artifact_path("patches.diff")
    assert diff_path.exists()
