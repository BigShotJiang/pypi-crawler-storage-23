"""Tests for milco run REFUSED state (--apply without CONFIRM APPLY)."""

from milco.core.run_context import RunContext
from milco.core.artifacts import all_artifacts_present
from milco.cli import main


def _write_contract_no_confirm(tmp_path):
    contract = tmp_path / "TASK_CONTRACT.md"
    contract.write_text(
        "# Task Contract\n\n"
        "## Goal\n\nTest.\n\n"
        "## Scope\n\nTest.\n\n"
        "## Out of scope\n\nNone.\n\n"
        "## Success Criteria\n\nPass.\n\n"
        "## Constraints\n\nNone.\n\n"
        "## Approvals required\n\nNone.\n\n"
        "## Notes\n\nNone.\n",
        encoding="utf-8",
    )
    return contract


def test_run_apply_without_confirm_exits_1(tmp_path, monkeypatch):
    """milco run --apply with contract lacking CONFIRM APPLY -> exit 1."""
    contract = _write_contract_no_confirm(tmp_path)
    monkeypatch.chdir(tmp_path)

    exit_code = main(
        [
            "run",
            "--apply",
            "--contract",
            str(contract),
            "--run-id",
            "refuse-test",
        ]
    )

    assert exit_code == 1


def test_run_refusal_artifacts_exist(tmp_path, monkeypatch):
    """Even on REFUSED, all 5 artifacts must exist."""
    contract = _write_contract_no_confirm(tmp_path)
    monkeypatch.chdir(tmp_path)

    main(
        [
            "run",
            "--apply",
            "--contract",
            str(contract),
            "--run-id",
            "refuse-art",
        ]
    )

    ctx = RunContext(repo_root=tmp_path, run_id="refuse-art")
    assert all_artifacts_present(ctx)


def test_run_refusal_summary_decision(tmp_path, monkeypatch):
    """summary.md must start with DECISION: REFUSED."""
    contract = _write_contract_no_confirm(tmp_path)
    monkeypatch.chdir(tmp_path)

    main(
        [
            "run",
            "--apply",
            "--contract",
            str(contract),
            "--run-id",
            "refuse-dec",
        ]
    )

    summary_path = tmp_path / "runs" / "refuse-dec" / "summary.md"
    assert summary_path.exists()
    text = summary_path.read_text(encoding="utf-8")
    assert text.startswith("DECISION: REFUSED")


def test_run_refusal_confirm_apply_shows_what_to_do_next(tmp_path, monkeypatch, capsys):
    """REFUSED (CONFIRM APPLY missing) prints What to do next."""
    contract = _write_contract_no_confirm(tmp_path)
    monkeypatch.chdir(tmp_path)

    main(
        [
            "run",
            "--apply",
            "--contract",
            str(contract),
            "--run-id",
            "refuse-msg",
        ]
    )

    output = capsys.readouterr().out
    assert "What to do next" in output
    assert "CONFIRM APPLY" in output

    summary_path = tmp_path / "runs" / "refuse-msg" / "summary.md"
    assert summary_path.exists()
    assert "What to do next" in summary_path.read_text(encoding="utf-8")


def test_dry_run_without_apply_exits_0(tmp_path, monkeypatch):
    """milco run without --apply (dry-run) should exit 0."""
    contract = _write_contract_no_confirm(tmp_path)
    monkeypatch.chdir(tmp_path)

    exit_code = main(
        [
            "run",
            "--contract",
            str(contract),
            "--run-id",
            "dryrun-ok",
        ]
    )

    assert exit_code == 0
