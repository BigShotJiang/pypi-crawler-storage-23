"""Tests for contract loading and validation."""

import pytest
from milco.core.contract import validate_contract, load_and_validate

VALID_CONTRACT = """\
# Task Contract

## Goal

Test goal.

## Scope

Test scope.

## Out of scope

Nothing.

## Success Criteria

Tests pass.

## Constraints

None.

## Approvals required

CONFIRM APPLY

## Notes

None.
"""

MISSING_GOAL = """\
# Task Contract

## Scope

Test scope.

## Out of scope

Nothing.

## Success Criteria

Tests pass.

## Constraints

None.

## Approvals required

CONFIRM APPLY

## Notes

None.
"""


def test_valid_contract():
    missing = validate_contract(VALID_CONTRACT)
    assert missing == [], f"Expected no missing sections, got: {missing}"


def test_missing_section():
    missing = validate_contract(MISSING_GOAL)
    assert "Goal" in missing


def test_case_insensitive():
    text = VALID_CONTRACT.replace("## Goal", "## goal")
    missing = validate_contract(text)
    assert missing == []


def test_load_file_not_found():
    with pytest.raises(FileNotFoundError):
        load_and_validate("nonexistent_contract.md")


def test_load_and_validate_valid(tmp_path):
    p = tmp_path / "contract.md"
    p.write_text(VALID_CONTRACT, encoding="utf-8")
    text, missing = load_and_validate(p)
    assert missing == []
    assert "Goal" in text
