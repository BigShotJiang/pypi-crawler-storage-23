"""Tests for REFUSED 'What to do next' helper."""

from milco.cli import _refusal_what_next


def test_refusal_what_next_confirm_apply():
    lines = _refusal_what_next("confirm_apply")
    assert len(lines) >= 1
    assert "What to do next" in lines[0]
    assert "CONFIRM APPLY" in " ".join(lines)


def test_refusal_what_next_unknown_task_no_suggestion():
    lines = _refusal_what_next("unknown_task")
    assert len(lines) >= 1
    assert "What to do next" in lines[0]
    assert "--list-tasks" in " ".join(lines)


def test_refusal_what_next_unknown_task_with_suggestion():
    lines = _refusal_what_next("unknown_task", suggestion="doc-gen")
    assert len(lines) >= 2
    assert "What to do next" in lines[0]
    assert "doc-gen" in " ".join(lines)
    assert "Did you mean" in " ".join(lines)


def test_refusal_what_next_llm_required():
    lines = _refusal_what_next("llm_required")
    assert len(lines) >= 1
    assert "What to do next" in lines[0]
    assert "milco.toml" in " ".join(lines) or "milco init" in " ".join(lines)


def test_refusal_what_next_unknown_reason_returns_empty():
    lines = _refusal_what_next("other")
    assert lines == []
