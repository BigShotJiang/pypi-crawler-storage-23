"""Fixer: delegates to the task registry for fix operations."""

from __future__ import annotations

from milco.core.run_context import RunContext

import milco.tasks.map_gen  # noqa: F401
import milco.tasks.scaffold_task  # noqa: F401

try:
    import milco.tasks.format_task  # noqa: F401
except ImportError:
    pass
try:
    import milco.tasks.lint_task  # noqa: F401
except ImportError:
    pass


def run_fix(ctx: RunContext) -> dict:
    """Execute the fix phase via task registry. Returns a status dict."""
    from milco.tasks.registry import get_task

    task_name = ctx.task_type or "map-gen"
    task_cls = get_task(task_name)

    if task_cls is None:
        return {
            "phase": "fix",
            "run_id": ctx.run_id,
            "applied": False,
            "errors": [f"Unknown task type: '{task_name}'"],
            "success": False,
        }

    result = task_cls().fix(ctx)

    return {
        "phase": "fix",
        "run_id": ctx.run_id,
        "applied": result.applied,
        "errors": result.errors,
        "success": result.success,
    }
