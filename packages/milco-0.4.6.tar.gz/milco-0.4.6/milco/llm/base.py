"""Base class for LLM providers."""

from __future__ import annotations


class LLMProvider:
    """Abstract base for all LLM providers."""

    @property
    def name(self) -> str:
        raise NotImplementedError

    def complete(self, prompt: str, system: str | None = None) -> str:
        raise NotImplementedError

    def ping(self) -> bool:
        raise NotImplementedError
