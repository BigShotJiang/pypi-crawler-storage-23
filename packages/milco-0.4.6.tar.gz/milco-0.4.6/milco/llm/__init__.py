"""LLM provider abstraction."""
