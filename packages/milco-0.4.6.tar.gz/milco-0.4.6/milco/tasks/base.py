"""Base types for task implementations."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class FixResult:
    success: bool
    applied: bool
    diff_text: str = ""
    errors: list[str] = field(default_factory=list)
