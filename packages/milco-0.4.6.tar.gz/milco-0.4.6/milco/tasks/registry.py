"""Task type registry with decorator-based registration."""

from __future__ import annotations

from typing import Any

from milco.tasks.base import FixResult

_registry: dict[str, type] = {}


class TaskBase:
    """Base class for all task types."""

    needs_llm: bool = False
    description: str = ""

    def fix(self, ctx: Any) -> FixResult:
        raise NotImplementedError


def register_task(name: str):
    """Decorator to register a task type by name."""

    def decorator(cls):
        if name in _registry:
            raise ValueError(f"Task '{name}' already registered.")
        _registry[name] = cls
        return cls

    return decorator


def get_task(name: str) -> type | None:
    return _registry.get(name)


def list_tasks() -> list[str]:
    return sorted(_registry.keys())
