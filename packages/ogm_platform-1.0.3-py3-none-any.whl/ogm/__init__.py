"""
OGM-Dev: All-in-One K3s Development Environment for GenAI Applications.

A comprehensive platform for managing local K3s clusters, deploying GenAI applications,
and orchestrating development workflows.
"""

__version__ = "1.0.0"
__author__ = "OGM-Dev Team"
__email__ = "dev@ogm.local"

from .config import OGMConfig
from . import insight

__all__ = ["OGMConfig", "insight", "__version__"]
