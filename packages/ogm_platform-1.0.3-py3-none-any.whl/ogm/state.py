"""
State management module.

Handles persistence of OGM-Dev state including deployments, repositories, and sync history.
"""

import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, cast


class StateManager:
    """Manages application state persistence."""

    def __init__(self, state_file: Path):
        """
        Initialize state manager.

        Args:
            state_file: Path to state JSON file
        """
        self.state_file = Path(state_file)
        self.state_file.parent.mkdir(parents=True, exist_ok=True)
        self._load_state()

    def _load_state(self) -> None:
        """Load state from file."""
        if self.state_file.exists():
            with open(self.state_file, "r") as f:
                self.state = cast(Dict[str, Any], json.load(f))
        else:
            self.state = {
                "version": "1.0.0",
                "initialized_at": datetime.now().isoformat(),
                "k3s": {},
                "repositories": {},
                "deployments": {},
                "sync_history": [],
            }
            self._save_state()

    def _save_state(self) -> None:
        """Save state to file."""
        self.state["last_updated"] = datetime.now().isoformat()
        with open(self.state_file, "w") as f:
            json.dump(self.state, f, indent=2, default=str)

    def update_k3s_state(self, data: Dict[str, Any]) -> None:
        """Update K3s installation state."""
        self.state["k3s"].update(data)
        self._save_state()

    def get_k3s_state(self) -> Dict[str, Any]:
        """Get K3s installation state."""
        return cast(Dict[str, Any], self.state.get("k3s", {}))

    def update_repository_state(self, repo_name: str, data: Dict[str, Any]) -> None:
        """Update repository state."""
        if "repositories" not in self.state:
            self.state["repositories"] = {}
        self.state["repositories"][repo_name] = data
        self._save_state()

    def get_repository_state(self, repo_name: str) -> Optional[Dict[str, Any]]:
        """Get repository state."""
        return cast(Optional[Dict[str, Any]], self.state.get("repositories", {}).get(repo_name))

    def get_all_repository_states(self) -> Dict[str, Dict[str, Any]]:
        """Get all repository states."""
        return cast(Dict[str, Dict[str, Any]], self.state.get("repositories", {}))

    def update_deployment_state(self, app_name: str, data: Dict[str, Any]) -> None:
        """Update deployment state."""
        if "deployments" not in self.state:
            self.state["deployments"] = {}
        self.state["deployments"][app_name] = data
        self._save_state()

    def get_deployment_state(self, app_name: str) -> Optional[Dict[str, Any]]:
        """Get deployment state."""
        return cast(Optional[Dict[str, Any]], self.state.get("deployments", {}).get(app_name))

    def get_deployments(self) -> Dict[str, Dict[str, Any]]:
        """Get all deployments."""
        return cast(Dict[str, Dict[str, Any]], self.state.get("deployments", {}))

    def remove_deployment(self, app_name: str) -> None:
        """Remove deployment from state."""
        if "deployments" in self.state and app_name in self.state["deployments"]:
            del self.state["deployments"][app_name]
            self._save_state()

    def add_sync_history(self, repo_name: str, sync_data: Dict[str, Any]) -> None:
        """Add sync history entry."""
        if "sync_history" not in self.state:
            self.state["sync_history"] = []

        sync_entry = {"repository": repo_name, **sync_data}
        self.state["sync_history"].append(sync_entry)

        # Keep only last 100 entries
        self.state["sync_history"] = self.state["sync_history"][-100:]
        self._save_state()

    def get_sync_history(
        self, repo_name: Optional[str] = None, limit: int = 10
    ) -> List[Dict[str, Any]]:
        """Get sync history."""
        history = cast(List[Dict[str, Any]], self.state.get("sync_history", []))

        if repo_name:
            history = [h for h in history if h.get("repository") == repo_name]

        return history[-limit:]

    def reset_state(self) -> None:
        """Reset state to initial values."""
        self.state = {
            "version": "1.0.0",
            "initialized_at": datetime.now().isoformat(),
            "k3s": {},
            "repositories": {},
            "deployments": {},
            "sync_history": [],
        }
        self._save_state()

    def export_state(self, output_path: Path) -> None:
        """Export state to file."""
        with open(output_path, "w") as f:
            json.dump(self.state, f, indent=2, default=str)

    def import_state(self, input_path: Path) -> None:
        """Import state from file."""
        with open(input_path, "r") as f:
            self.state = cast(Dict[str, Any], json.load(f))
        self._save_state()
        self._save_state()
