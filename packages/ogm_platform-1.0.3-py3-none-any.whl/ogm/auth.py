"""
Authentication and secrets management module.

Handles credentials for Git, Docker/Container Registry, and Kubernetes deployments.
"""

import json
import os
import subprocess
from pathlib import Path
from typing import Dict, Optional, cast

try:
    from rich.console import Console
    from rich.prompt import Prompt

    console = Console()
except ImportError:

    class MockConsole:
        def print(self, *args, **kwargs):
            print(*args)

    class MockPrompt:
        @staticmethod
        def ask(prompt, default=None):
            return input(f"{prompt} [{default}]: ") or default

    console = MockConsole()  # type: ignore
    Prompt = MockPrompt  # type: ignore

try:
    from rich.password import getpass  # type: ignore
except ImportError:

    def getpass(prompt=""):
        import getpass as gp

        return gp.getpass(prompt)


class AuthManager:
    """Manages authentication credentials and secrets."""

    def __init__(self, state_dir: Optional[Path] = None):
        """Initialize auth manager.

        Args:
            state_dir: Directory to store encrypted credentials (defaults to ~/.ogm)
        """
        if state_dir is None:
            state_dir = Path.home() / ".ogm"

        self.state_dir = Path(state_dir)
        self.state_dir.mkdir(parents=True, exist_ok=True)
        self.credentials_file = self.state_dir / "credentials.json"
        self.credentials = self._load_credentials()

    def _load_credentials(self) -> Dict:
        """Load credentials from file."""
        if self.credentials_file.exists():
            try:
                with open(self.credentials_file, "r") as f:
                    return cast(Dict, json.load(f))
            except Exception as e:
                console.print(f"[yellow]Warning: Could not load credentials: {e}[/yellow]")
        return {}

    def _save_credentials(self) -> None:
        """Save credentials to file."""
        try:
            with open(self.credentials_file, "w") as f:
                json.dump(self.credentials, f, indent=2)
            os.chmod(self.credentials_file, 0o600)  # Restrict to owner only
        except Exception as e:
            console.print(f"[red]Error saving credentials: {e}[/red]")

    # ===== Git Credentials =====

    def set_git_credentials(
        self,
        username: Optional[str] = None,
        personal_token: Optional[str] = None,
        url: Optional[str] = None,
    ) -> bool:
        """Set Git authentication credentials.

        Args:
            username: Git username
            personal_token: Personal access token or password
            url: Git server URL (for GitHub, GitLab, etc.)

        Returns:
            True if credentials were set successfully
        """
        console.print("\n[bold cyan]Git Credentials Configuration[/bold cyan]")

        if username is None:
            username = Prompt.ask("Git username", default="mksaraf")

        if url is None:
            url = Prompt.ask("Git server URL", default="https://github.com")

        if personal_token is None:
            console.print(
                "[yellow]You can use a Personal Access Token instead of password[/yellow]"
            )
            console.print("GitHub: https://github.com/settings/tokens")
            console.print("GitLab: https://gitlab.com/-/user_settings/personal_access_tokens")
            personal_token = getpass("Git token/password: ")

        self.credentials["git"] = {"username": username, "token": personal_token, "url": url}

        self._save_credentials()
        console.print("[green]✓ Git credentials saved[/green]")
        return True

    def get_git_credentials(self) -> Optional[Dict]:
        """Get stored Git credentials."""
        return self.credentials.get("git")

    # ===== Container Registry Credentials =====

    def set_registry_credentials(
        self,
        registry: Optional[str] = None,
        username: Optional[str] = None,
        password: Optional[str] = None,
    ) -> bool:
        """Set container registry authentication.

        Args:
            registry: Registry URL (e.g., registry.gitlab.com, docker.io)
            username: Registry username
            password: Registry password or token

        Returns:
            True if credentials were set successfully
        """
        console.print("\n[bold cyan]Container Registry Configuration[/bold cyan]")

        if registry is None:
            registry = Prompt.ask("Registry URL", default="registry.gitlab.com")

        if username is None:
            username = Prompt.ask("Registry username", default="mksaraf")

        if password is None:
            console.print(f"[yellow]For {registry}[/yellow]")
            console.print("Use personal access token with 'read' scope for pull, 'write' for push")
            password = getpass("Registry password/token: ")

        if "registries" not in self.credentials:
            self.credentials["registries"] = {}

        self.credentials["registries"][registry] = {"username": username, "password": password}

        self._save_credentials()
        console.print(f"[green]✓ Registry credentials saved for {registry}[/green]")
        return True

    def get_registry_credentials(self, registry: str) -> Optional[Dict]:
        """Get stored registry credentials."""
        registries = self.credentials.get("registries", {})
        return registries.get(registry)

    # ===== Kubernetes Image Pull Secrets =====

    def create_image_pull_secret(
        self, registry: str, namespace: str = "default", secret_name: Optional[str] = None
    ) -> bool:
        """Create Kubernetes ImagePullSecret from stored credentials.

        Args:
            registry: Registry URL
            namespace: Kubernetes namespace
            secret_name: Secret name (defaults to registry name normalized)

        Returns:
            True if secret was created successfully
        """
        creds = self.get_registry_credentials(registry)
        if not creds:
            console.print(f"[red]No credentials found for {registry}[/red]")
            return False

        if secret_name is None:
            secret_name = registry.replace(".", "-").replace("/", "-").lower()

        cmd = [
            "kubectl",
            "create",
            "secret",
            "docker-registry",
            secret_name,
            f"--docker-server={registry}",
            f"--docker-username={creds['username']}",
            f"--docker-password={creds['password']}",
            f"--namespace={namespace}",
            "--dry-run=client",
            "-o",
            "yaml",
        ]

        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode == 0:
            console.print(f"[green]✓ ImagePullSecret created: {secret_name}[/green]")
            console.print("[cyan]Manifest:[/cyan]")
            console.print(result.stdout)
            return True
        else:
            console.print(f"[red]✗ Failed to create secret: {result.stderr}[/red]")
            return False

    # ===== Kubernetes Context =====

    def validate_kubeconfig(self, kubeconfig_path: Optional[str] = None) -> bool:
        """Validate kubeconfig file and current context.

        Args:
            kubeconfig_path: Path to kubeconfig file

        Returns:
            True if kubeconfig is valid and accessible
        """
        import subprocess

        if kubeconfig_path:
            os.environ["KUBECONFIG"] = str(Path(kubeconfig_path).expanduser())

        # Check cluster info
        result = subprocess.run(["kubectl", "cluster-info"], capture_output=True, text=True)

        if result.returncode == 0:
            console.print("[green]✓ Kubeconfig valid[/green]")

            # Get current context
            result = subprocess.run(
                ["kubectl", "config", "current-context"], capture_output=True, text=True
            )
            if result.returncode == 0:
                context = result.stdout.strip()
                console.print(f"[cyan]Current context: {context}[/cyan]")

            return True
        else:
            console.print("[red]✗ Kubeconfig invalid[/red]")
            return False

    # ===== OAuth/OIDC Credentials =====

    def set_oauth_credentials(
        self,
        provider: Optional[str] = None,
        client_id: Optional[str] = None,
        client_secret: Optional[str] = None,
    ) -> bool:
        """Set OAuth/OIDC provider credentials.

        Args:
            provider: OAuth provider (github, gitlab, google, etc.)
            client_id: OAuth client ID
            client_secret: OAuth client secret

        Returns:
            True if credentials were set successfully
        """
        console.print("\n[bold cyan]OAuth/OIDC Configuration[/bold cyan]")

        if provider is None:
            provider = Prompt.ask("Provider (github/gitlab/google)", default="github")

        if client_id is None:
            client_id = Prompt.ask(f"{provider} Client ID")

        if client_secret is None:
            client_secret = getpass(f"{provider} Client Secret: ")

        if "oauth" not in self.credentials:
            self.credentials["oauth"] = {}

        self.credentials["oauth"][provider] = {
            "client_id": client_id,
            "client_secret": client_secret,
        }

        self._save_credentials()
        console.print(f"[green]✓ OAuth credentials saved for {provider}[/green]")
        return True

    def get_oauth_credentials(self, provider: str) -> Optional[Dict]:
        """Get stored OAuth credentials."""
        oauth = self.credentials.get("oauth", {})
        return oauth.get(provider)

    # ===== Environment Variables =====

    def export_credentials_to_env(self) -> bool:
        """Export all credentials as environment variables.

        Useful for CI/CD pipelines and automated deployments.

        Returns:
            True if export was successful
        """
        console.print("\n[bold cyan]Exporting credentials as environment variables...[/bold cyan]")

        # Git
        git_creds = self.get_git_credentials()
        if git_creds:
            os.environ["GIT_USERNAME"] = git_creds.get("username", "")
            os.environ["GIT_TOKEN"] = git_creds.get("token", "")
            os.environ["GIT_URL"] = git_creds.get("url", "")
            console.print("[green]✓ Git credentials exported[/green]")

        # Registry
        registries = self.credentials.get("registries", {})
        for registry, creds in registries.items():
            env_key = registry.replace(".", "_").replace("/", "_").upper()
            os.environ[f"{env_key}_USERNAME"] = creds.get("username", "")
            os.environ[f"{env_key}_PASSWORD"] = creds.get("password", "")

        if registries:
            console.print(
                f"[green]✓ Registry credentials exported ({len(registries)} registries)[/green]"
            )

        return True

    # ===== Credential Verification =====

    def verify_all_credentials(self) -> Dict:
        """Verify all stored credentials are valid.

        Returns:
            Dictionary with verification results
        """
        console.print("\n[bold cyan]Verifying credentials...[/bold cyan]")
        results = {}

        # Verify Git
        git_creds = self.get_git_credentials()
        if git_creds:
            import subprocess

            result = subprocess.run(["git", "ls-remote", git_creds["url"]], capture_output=True)
            results["git"] = result.returncode == 0
            status = "[green]✓[/green]" if results["git"] else "[red]✗[/red]"
            console.print(f"{status} Git credentials")

        # Verify Registry
        registries = self.credentials.get("registries", {})
        for registry in registries:
            # Note: This is a simplified check. Real verification would use docker/container CLI
            results[f"registry_{registry}"] = True  # Placeholder
            console.print(f"[cyan]✓ Registry {registry}[/cyan]")

        # Verify Kubeconfig
        kubeconfig_result = self.validate_kubeconfig()
        results["kubeconfig"] = kubeconfig_result

        return results

    # ===== Display Credentials Summary =====

    def display_credentials_summary(self) -> None:
        """Display summary of stored credentials."""
        console.print("\n[bold cyan]═══════════════════════════════════════[/bold cyan]")
        console.print("[bold cyan]     Stored Credentials Summary[/bold cyan]")
        console.print("[bold cyan]═══════════════════════════════════════[/bold cyan]\n")

        # Git
        if "git" in self.credentials:
            git = self.credentials["git"]
            console.print("[cyan]Git[/cyan]")
            console.print(f"  Username: {git.get('username', 'N/A')}")
            console.print(f"  URL: {git.get('url', 'N/A')}")
            console.print(f"  Token: {'*' * 8}{'*' * 8}\n")

        # Registries
        registries = self.credentials.get("registries", {})
        if registries:
            console.print("[cyan]Container Registries[/cyan]")
            for registry, creds in registries.items():
                console.print(f"  {registry}")
                console.print(f"    Username: {creds.get('username', 'N/A')}")
                console.print(f"    Password: {'*' * 8}{'*' * 8}\n")

        # OAuth
        oauth = self.credentials.get("oauth", {})
        if oauth:
            console.print("[cyan]OAuth Providers[/cyan]")
            for provider in oauth:
                console.print(f"  {provider}")
            console.print()


if __name__ == "__main__":
    # Example usage
    auth = AuthManager()

    # Set credentials
    # auth.set_git_credentials()
    # auth.set_registry_credentials()
    # auth.set_oauth_credentials()

    # Verify
    # auth.verify_all_credentials()

    # Display summary
    auth.display_credentials_summary()
