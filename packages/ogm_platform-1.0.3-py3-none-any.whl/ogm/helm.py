"""Helm chart deployment module."""

import subprocess
from pathlib import Path
from typing import Dict, List, Optional

try:
    from rich.console import Console
    from rich.table import Table

    console = Console()
    TableClass = Table
except ImportError:

    class MockConsole:
        def print(self, *args, **kwargs):
            print(*args)

    class MockTable:
        def __init__(self, *args, **kwargs):
            pass

        def add_column(self, *args, **kwargs):
            pass

        def add_row(self, *args, **kwargs):
            pass

    console = MockConsole()  # type: ignore
    TableClass = MockTable  # type: ignore


class HelmManager:
    """Manages Helm chart operations."""

    def __init__(self):
        self.verify_helm_installed()

    def verify_helm_installed(self) -> bool:
        try:
            result = subprocess.run(
                ["helm", "version", "--short"], capture_output=True, text=True, check=False
            )
            return result.returncode == 0
        except FileNotFoundError:
            console.print("[red]✗ Helm not installed[/red]")
            return False

    def add_repository(self, name: str, url: str, force_update: bool = False) -> bool:
        cmd = ["helm", "repo", "add", name, url]
        if force_update:
            cmd.append("--force-update")
        result = subprocess.run(cmd, capture_output=True, text=True)
        return result.returncode == 0

    def update_repositories(self) -> bool:
        console.print("[cyan]Updating Helm repositories...[/cyan]")
        result = subprocess.run(["helm", "repo", "update"], capture_output=True, text=True)
        if result.returncode == 0:
            console.print("[green]✓ Repositories updated[/green]")
            return True
        return False

    def install_chart(
        self, config, values_file: Optional[Path] = None, dry_run: bool = False
    ) -> bool:
        console.print(f"[cyan]Installing: {config.name}[/cyan]")

        # Handle local chart path (starts with ./ or /)
        chart_path = config.chart
        if chart_path.startswith("./") or chart_path.startswith("/"):
            # Update dependencies for local charts
            chart_abs_path = Path(chart_path).resolve()
            if chart_abs_path.exists():
                console.print("[dim]Updating dependencies for local chart...[/dim]")
                dep_result = subprocess.run(
                    ["helm", "dependency", "update", str(chart_abs_path)],
                    capture_output=True,
                    text=True,
                )
                if dep_result.returncode != 0:
                    console.print(f"[yellow]Warning: {dep_result.stderr}[/yellow]")
                chart_path = str(chart_abs_path)

        cmd = [
            "helm",
            "install",
            config.name,
            chart_path,
            "--namespace",
            config.namespace,
            "--create-namespace",
        ]

        if config.version and not chart_path.startswith(("./", "/")):
            cmd.extend(["--version", config.version])

        # Use config.values_file if specified, otherwise use passed values_file
        if config.values_file:
            values_path = Path(config.values_file)
            if values_path.exists():
                cmd.extend(["--values", str(values_path)])
            else:
                console.print(f"[yellow]Warning: values file not found: {values_path}[/yellow]")
        elif values_file:
            cmd.extend(["--values", str(values_file)])

        if config.wait:
            cmd.append("--wait")
            if hasattr(config, "timeout") and config.timeout:
                cmd.extend(["--timeout", config.timeout])

        if dry_run:
            cmd.append("--dry-run")

        result = subprocess.run(cmd, capture_output=True, text=True)

        if result.returncode == 0:
            console.print(f"[green]✓ Installed: {config.name}[/green]")
            return True
        else:
            console.print(f"[red]✗ Failed: {result.stderr}[/red]")
            return False

    def upgrade_chart(
        self, config, values_file: Optional[Path] = None, force: bool = False, dry_run: bool = False
    ) -> bool:
        console.print(f"[cyan]Upgrading: {config.name}[/cyan]")

        # Handle local chart path
        chart_path = config.chart
        if chart_path.startswith("./") or chart_path.startswith("/"):
            chart_abs_path = Path(chart_path).resolve()
            if chart_abs_path.exists():
                console.print("[dim]Updating dependencies for local chart...[/dim]")
                subprocess.run(
                    ["helm", "dependency", "update", str(chart_abs_path)],
                    capture_output=True,
                    text=True,
                )
                chart_path = str(chart_abs_path)

        cmd = [
            "helm",
            "upgrade",
            config.name,
            chart_path,
            "--namespace",
            config.namespace,
            "--install",
        ]

        if config.version and not chart_path.startswith(("./", "/")):
            cmd.extend(["--version", config.version])

        if config.values_file:
            values_path = Path(config.values_file)
            if values_path.exists():
                cmd.extend(["--values", str(values_path)])
        elif values_file:
            cmd.extend(["--values", str(values_file)])

        if config.wait:
            cmd.append("--wait")
            if hasattr(config, "timeout") and config.timeout:
                cmd.extend(["--timeout", config.timeout])

        if dry_run:
            cmd.append("--dry-run=client")

        result = subprocess.run(cmd, capture_output=True, text=True)

        if result.returncode == 0:
            console.print(f"[green]✓ Upgraded: {config.name}[/green]")
            return True
        else:
            console.print(f"[red]✗ Failed to upgrade: {config.name}[/red]")
            console.print(f"[red]Error: {result.stderr}[/red]")
            return False

    def uninstall_chart(self, name: str, namespace: str, keep_history: bool = False) -> bool:
        console.print(f"[red]Uninstalling: {name}[/red]")

        cmd = ["helm", "uninstall", name, "--namespace", namespace]
        if keep_history:
            cmd.append("--keep-history")

        result = subprocess.run(cmd, capture_output=True, text=True)

        if result.returncode == 0 or "not found" in result.stderr:
            console.print(f"[green]✓ Uninstalled: {name}[/green]")
            return True
        return False

    def list_releases(
        self, namespace: Optional[str] = None, all_namespaces: bool = False
    ) -> List[Dict]:
        cmd = ["helm", "list", "--output", "json"]

        if all_namespaces:
            cmd.append("--all-namespaces")
        elif namespace:
            cmd.extend(["--namespace", namespace])

        result = subprocess.run(cmd, capture_output=True, text=True)

        if result.returncode == 0:
            import json

            try:
                return json.loads(result.stdout) or []
            except Exception:
                return []
        return []

    def display_releases_table(self, releases: List[Dict]) -> None:
        if not releases:
            console.print("[yellow]No releases found[/yellow]")
            return

        table = TableClass(title="Helm Releases")
        table.add_column("Name", style="cyan")
        table.add_column("Namespace", style="blue")
        table.add_column("Status", style="green")
        table.add_column("Chart", style="yellow")

        for release in releases:
            table.add_row(
                release.get("name", ""),
                release.get("namespace", ""),
                release.get("status", ""),
                release.get("chart", ""),
            )
        console.print(table)
