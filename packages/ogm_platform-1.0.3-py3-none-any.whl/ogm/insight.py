"""
Insight module for comprehensive OGM system analysis.
"""

import json
import subprocess
from typing import Dict, List, Optional, Any
from pathlib import Path

try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.columns import Columns
    from rich.text import Text
    from rich.layout import Layout
    from rich.progress import Progress, SpinnerColumn, TextColumn

    console = Console()
    TableClass = Table
    PanelClass = Panel
    ColumnsClass = Columns
    TextClass = Text
    LayoutClass = Layout
    ProgressClass = Progress
    SpinnerColumnClass = SpinnerColumn
    TextColumnClass = TextColumn
except ImportError:
    # Fallback for environments without rich
    class MockConsole:
        def print(self, *args, **kwargs):
            print(*args)

        def rule(self, *args, **kwargs):
            print("=" * 50)

    class MockTable:
        def __init__(self, *args, **kwargs):
            pass

        def add_column(self, *args, **kwargs):
            pass

        def add_row(self, *args, **kwargs):
            pass

    class MockPanel:
        def __init__(self, content, *args, **kwargs):
            self.content = content

    class MockColumns:
        def __init__(self, panels, *args, **kwargs):
            self.panels = panels

    class MockText:
        def __init__(self, text, *args, **kwargs):
            self.plain = text

    class MockLayout:
        def __init__(self, *args, **kwargs):
            pass

    class MockProgress:
        def __init__(self, *args, **kwargs):
            pass

        def add_task(self, *args, **kwargs):
            pass

        def update(self, *args, **kwargs):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *args, **kwargs):
            pass

    console = MockConsole()  # type: ignore
    TableClass = MockTable  # type: ignore
    PanelClass = MockPanel  # type: ignore
    ColumnsClass = MockColumns  # type: ignore
    TextClass = MockText  # type: ignore
    LayoutClass = MockLayout  # type: ignore
    ProgressClass = MockProgress  # type: ignore
    SpinnerColumnClass = object  # type: ignore
    TextColumnClass = object  # type: ignore


class InsightManager:
    """Comprehensive insight into OGM system resources and services."""

    def __init__(self, config):
        self.config = config
        self.kubectl_available = self._check_kubectl()
        self.helm_available = self._check_helm()

    def _check_kubectl(self) -> bool:
        """Check if kubectl is available."""
        try:
            result = subprocess.run(
                ["kubectl", "version", "--client"],
                capture_output=True,
                text=True,
                timeout=5
            )
            return result.returncode == 0 and "Client Version:" in result.stdout
        except (subprocess.TimeoutExpired, FileNotFoundError, OSError, subprocess.SubprocessError):
            return False

    def _check_helm(self) -> bool:
        """Check if helm is available."""
        try:
            result = subprocess.run(
                ["helm", "version", "--short"],
                capture_output=True,
                text=True,
                timeout=5
            )
            return result.returncode == 0
        except (subprocess.TimeoutExpired, FileNotFoundError, OSError, subprocess.SubprocessError):
            return False

    def _run_kubectl(self, command: List[str], namespace: Optional[str] = None) -> Optional[Dict]:
        """Run kubectl command and return parsed JSON."""
        if not self.kubectl_available:
            return None

        cmd = ["kubectl"]
        if namespace:
            cmd.extend(["--namespace", namespace])
        cmd.extend(command)

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=30
            )
            if result.returncode == 0 and result.stdout.strip():
                return json.loads(result.stdout)
            return None
        except (subprocess.TimeoutExpired, json.JSONDecodeError, subprocess.SubprocessError):
            return None

    def _run_helm(self, command: List[str]) -> Optional[str]:
        """Run helm command and return output."""
        if not self.helm_available:
            return None

        try:
            result = subprocess.run(
                ["helm"] + command,
                capture_output=True,
                text=True,
                timeout=30
            )
            if result.returncode == 0:
                return result.stdout.strip()
            return None
        except (subprocess.TimeoutExpired, subprocess.SubprocessError):
            return None

    def get_cluster_info(self) -> Dict[str, Any]:
        """Get basic cluster information."""
        info = {
            "nodes": [],
            "version": "Unknown",
            "status": "Unavailable",
            "networking": {
                "service_cluster_ip_range": "Unknown",
                "pod_network_cidr": "Unknown",
                "cluster_dns": "Unknown"
            }
        }

        # Get nodes with detailed networking info
        nodes = self._run_kubectl(["get", "nodes", "-o", "json"])
        if nodes:
            for node in nodes.get("items", []):
                # Get node addresses
                addresses = node["status"].get("addresses", [])
                internal_ip = next((addr["address"] for addr in addresses if addr["type"] == "InternalIP"), "Unknown")
                external_ip = next((addr["address"] for addr in addresses if addr["type"] == "ExternalIP"), None)
                hostname = next((addr["address"] for addr in addresses if addr["type"] == "Hostname"), node["metadata"]["name"])

                info["nodes"].append({
                    "name": node["metadata"]["name"],
                    "hostname": hostname,
                    "internal_ip": internal_ip,
                    "external_ip": external_ip,
                    "status": node["status"]["conditions"][-1]["type"] if node["status"]["conditions"] else "Unknown",
                    "version": node["status"]["nodeInfo"]["kubeletVersion"],
                    "os": f"{node['status']['nodeInfo']['osImage']}",
                    "cpu": node["status"]["capacity"].get("cpu", "Unknown"),
                    "memory": node["status"]["capacity"].get("memory", "Unknown"),
                    "pod_cidr": node["spec"].get("podCIDR", "Unknown")
                })
            info["status"] = "Connected"

        # Get version
        version = self._run_kubectl(["version", "-o", "json"])
        if version:
            info["version"] = version.get("serverVersion", {}).get("gitVersion", "Unknown")

        # Get cluster networking info
        try:
            # Try to get service cluster IP range from kube-apiserver config
            configmaps = self._run_kubectl(["get", "configmap", "kube-apiserver", "-n", "kube-system", "-o", "json"])
            if configmaps:
                config_data = configmaps.get("data", {})
                if "--service-cluster-ip-range" in str(config_data):
                    # This is a simplified extraction - in practice, this would need more parsing
                    pass
        except:
            pass

        return info

    def get_pods_info(self, namespace: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get pods information."""
        pods = self._run_kubectl(["get", "pods", "-o", "json"], namespace=namespace)
        if not pods:
            return []

        pod_info = []
        for pod in pods.get("items", []):
            status = pod["status"]
            spec = pod["spec"]

            # Get container statuses
            container_statuses = status.get("containerStatuses", [])
            ready_containers = sum(1 for cs in container_statuses if cs.get("ready", False))
            total_containers = len(container_statuses)

            # Get restart count
            restart_count = sum(cs.get("restartCount", 0) for cs in container_statuses)

            # Get ports
            ports = []
            for container in spec.get("containers", []):
                for port in container.get("ports", []):
                    ports.append({
                        "name": port.get("name", ""),
                        "container_port": port.get("containerPort", ""),
                        "protocol": port.get("protocol", "TCP")
                    })

            pod_info.append({
                "name": pod["metadata"]["name"],
                "namespace": pod["metadata"]["namespace"],
                "status": status.get("phase", "Unknown"),
                "ready": f"{ready_containers}/{total_containers}",
                "restarts": restart_count,
                "age": self._calculate_age(pod["metadata"]["creationTimestamp"]),
                "node": spec.get("nodeName", "Unknown"),
                "ports": ports,
                "labels": pod["metadata"].get("labels", {})
            })

        return pod_info

    def get_services_info(self, namespace: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get services information."""
        services = self._run_kubectl(["get", "services", "-o", "json"], namespace=namespace)
        if not services:
            return []

        svc_info = []
        for svc in services.get("items", []):
            spec = svc["spec"]
            status = svc["status"]

            # Get ports
            ports = []
            for port in spec.get("ports", []):
                ports.append({
                    "name": port.get("name", ""),
                    "port": port.get("port", ""),
                    "target_port": str(port.get("targetPort", "")),
                    "protocol": port.get("protocol", "TCP")
                })

            # Get endpoints
            endpoints = []
            if spec.get("type") != "ExternalName":
                ep_data = self._run_kubectl(["get", "endpoints", svc["metadata"]["name"], "-o", "json"], namespace)
                if ep_data:
                    for subset in ep_data.get("subsets", []):
                        for address in subset.get("addresses", []):
                            endpoints.append(address.get("ip", ""))

            svc_info.append({
                "name": svc["metadata"]["name"],
                "namespace": svc["metadata"]["namespace"],
                "type": spec.get("type", "ClusterIP"),
                "cluster_ip": spec.get("clusterIP", ""),
                "external_ip": ", ".join(status.get("loadBalancer", {}).get("ingress", [{}])[0].get("ip", "")) if status.get("loadBalancer") else "",
                "ports": ports,
                "endpoints": endpoints,
                "selector": spec.get("selector", {})
            })

        return svc_info

    def get_deployments_info(self, namespace: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get deployments information."""
        deployments = self._run_kubectl(["get", "deployments", "-o", "json"], namespace=namespace)
        if not deployments:
            return []

        deploy_info = []
        for deploy in deployments.get("items", []):
            spec = deploy["spec"]
            status = deploy["status"]

            deploy_info.append({
                "name": deploy["metadata"]["name"],
                "namespace": deploy["metadata"]["namespace"],
                "ready": f"{status.get('readyReplicas', 0)}/{spec.get('replicas', 0)}",
                "up_to_date": status.get("updatedReplicas", 0),
                "available": status.get("availableReplicas", 0),
                "age": self._calculate_age(deploy["metadata"]["creationTimestamp"]),
                "images": [container["image"] for container in spec["template"]["spec"].get("containers", [])]
            })

        return deploy_info

    def get_ingress_info(self, namespace: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get ingress information."""
        ingresses = self._run_kubectl(["get", "ingress", "-o", "json"], namespace=namespace)
        if not ingresses:
            return []

        ingress_info = []
        for ingress in ingresses.get("items", []):
            spec = ingress["spec"]

            rules = []
            for rule in spec.get("rules", []):
                host = rule.get("host", "")
                for path in rule.get("http", {}).get("paths", []):
                    rules.append({
                        "host": host,
                        "path": path.get("path", "/"),
                        "service": path.get("backend", {}).get("service", {}).get("name", ""),
                        "port": path.get("backend", {}).get("service", {}).get("port", {}).get("number", "")
                    })

            ingress_info.append({
                "name": ingress["metadata"]["name"],
                "namespace": ingress["metadata"]["namespace"],
                "class": spec.get("ingressClassName", ""),
                "hosts": [rule.get("host", "") for rule in spec.get("rules", [])],
                "rules": rules,
                "tls": [tls.get("hosts", []) for tls in spec.get("tls", [])]
            })

        return ingress_info

    def get_storage_info(self, namespace: Optional[str] = None) -> Dict[str, List[Dict[str, Any]]]:
        """Get storage information."""
        info = {
            "pvcs": [],
            "pvs": [],
            "storage_classes": []
        }

        # PVCs
        pvcs = self._run_kubectl(["get", "pvc", "-o", "json"], namespace=namespace)
        if pvcs:
            for pvc in pvcs.get("items", []):
                spec = pvc["spec"]
                status = pvc["status"]
                info["pvcs"].append({
                    "name": pvc["metadata"]["name"],
                    "namespace": pvc["metadata"]["namespace"],
                    "status": status.get("phase", "Unknown"),
                    "volume": spec.get("volumeName", ""),
                    "capacity": status.get("capacity", {}).get("storage", ""),
                    "storage_class": spec.get("storageClassName", ""),
                    "access_modes": spec.get("accessModes", [])
                })

        # PVs
        pvs = self._run_kubectl(["get", "pv", "-o", "json"])
        if pvs:
            for pv in pvs.get("items", []):
                spec = pv["spec"]
                status = pv["status"]
                info["pvs"].append({
                    "name": pv["metadata"]["name"],
                    "capacity": spec.get("capacity", {}).get("storage", ""),
                    "access_modes": spec.get("accessModes", []),
                    "reclaim_policy": spec.get("persistentVolumeReclaimPolicy", ""),
                    "status": status.get("phase", "Unknown"),
                    "storage_class": spec.get("storageClassName", ""),
                    "claim": f"{spec.get('claimRef', {}).get('namespace', '')}/{spec.get('claimRef', {}).get('name', '')}" if spec.get("claimRef") else ""
                })

        # Storage Classes
        scs = self._run_kubectl(["get", "storageclass", "-o", "json"])
        if scs:
            for sc in scs.get("items", []):
                info["storage_classes"].append({
                    "name": sc["metadata"]["name"],
                    "provisioner": sc["provisioner"],
                    "reclaim_policy": sc.get("reclaimPolicy", ""),
                    "volume_binding_mode": sc.get("volumeBindingMode", ""),
                    "default": "Yes" if sc["metadata"].get("annotations", {}).get("storageclass.kubernetes.io/is-default-class") == "true" else "No"
                })

        return info

    def get_helm_releases(self) -> List[Dict[str, Any]]:
        """Get Helm releases information."""
        if not self.helm_available:
            return []

        releases_output = self._run_helm(["list", "--all-namespaces", "--output", "json"])
        if not releases_output:
            return []

        try:
            releases = json.loads(releases_output)
            return [{
                "name": release.get("name", ""),
                "namespace": release.get("namespace", ""),
                "status": release.get("status", ""),
                "chart": release.get("chart", ""),
                "app_version": release.get("app_version", ""),
                "updated": release.get("updated", "")
            } for release in releases]
        except json.JSONDecodeError:
            return []

    def get_statefulsets_info(self, namespace: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get statefulsets information."""
        statefulsets = self._run_kubectl(["get", "statefulsets", "-o", "json"], namespace=namespace)
        if not statefulsets:
            return []

        sts_info = []
        for sts in statefulsets.get("items", []):
            spec = sts["spec"]
            status = sts["status"]

            sts_info.append({
                "name": sts["metadata"]["name"],
                "namespace": sts["metadata"]["namespace"],
                "ready": f"{status.get('readyReplicas', 0)}/{spec.get('replicas', 0)}",
                "service": spec.get("serviceName", ""),
                "age": self._calculate_age(sts["metadata"]["creationTimestamp"]),
                "images": [container["image"] for container in spec["template"]["spec"].get("containers", [])]
            })

        return sts_info

    def get_configmaps_info(self, namespace: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get configmaps information."""
        configmaps = self._run_kubectl(["get", "configmaps", "-o", "json"], namespace=namespace)
        if not configmaps:
            return []

        cm_info = []
        for cm in configmaps.get("items", []):
            cm_info.append({
                "name": cm["metadata"]["name"],
                "namespace": cm["metadata"]["namespace"],
                "data_keys": list(cm.get("data", {}).keys()),
                "age": self._calculate_age(cm["metadata"]["creationTimestamp"])
            })

        return cm_info

    def get_secrets_info(self, namespace: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get secrets information."""
        secrets = self._run_kubectl(["get", "secrets", "-o", "json"], namespace=namespace)
        if not secrets:
            return []

        sec_info = []
        for sec in secrets.get("items", []):
            sec_info.append({
                "name": sec["metadata"]["name"],
                "namespace": sec["metadata"]["namespace"],
                "type": sec.get("type", ""),
                "data_keys": list(sec.get("data", {}).keys()),
                "age": self._calculate_age(sec["metadata"]["creationTimestamp"])
            })

        return sec_info

    def get_jobs_info(self, namespace: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get jobs information."""
        jobs = self._run_kubectl(["get", "jobs", "-o", "json"], namespace=namespace)
        if not jobs:
            return []

        job_info = []
        for job in jobs.get("items", []):
            spec = job["spec"]
            status = job["status"]

            job_info.append({
                "name": job["metadata"]["name"],
                "namespace": job["metadata"]["namespace"],
                "completions": f"{status.get('succeeded', 0)}/{spec.get('completions', 1)}",
                "duration": self._calculate_age(job["metadata"]["creationTimestamp"]),
                "status": "Complete" if status.get("succeeded") else "Running" if status.get("active") else "Failed"
            })

        return job_info

    def get_cronjobs_info(self, namespace: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get cronjobs information."""
        cronjobs = self._run_kubectl(["get", "cronjobs", "-o", "json"], namespace=namespace)
        if not cronjobs:
            return []

        cj_info = []
        for cj in cronjobs.get("items", []):
            spec = cj["spec"]
            status = cj["status"]

            cj_info.append({
                "name": cj["metadata"]["name"],
                "namespace": cj["metadata"]["namespace"],
                "schedule": spec.get("schedule", ""),
                "suspend": spec.get("suspend", False),
                "active": len(status.get("active", [])),
                "last_schedule": status.get("lastScheduleTime", ""),
                "age": self._calculate_age(cj["metadata"]["creationTimestamp"])
            })

        return cj_info

    def get_network_policies_info(self, namespace: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get network policies information."""
        policies = self._run_kubectl(["get", "networkpolicy", "-o", "json"], namespace=namespace)
        if not policies:
            return []

        np_info = []
        for np in policies.get("items", []):
            spec = np["spec"]

            # Count rules
            ingress_rules = len(spec.get("ingress", []))
            egress_rules = len(spec.get("egress", []))

            np_info.append({
                "name": np["metadata"]["name"],
                "namespace": np["metadata"]["namespace"],
                "pod_selector": spec.get("podSelector", {}).get("matchLabels", {}),
                "ingress_rules": ingress_rules,
                "egress_rules": egress_rules,
                "policy_types": spec.get("policyTypes", [])
            })

        return np_info

    def get_recent_events(self, namespace: Optional[str] = None, limit: int = 20) -> List[Dict[str, Any]]:
        """Get recent Kubernetes events."""
        events = self._run_kubectl(["get", "events", "--sort-by=.metadata.creationTimestamp", f"--limit={limit}", "-o", "json"], namespace)
        if not events:
            return []

        event_info = []
        for event in events.get("items", []):
            event_info.append({
                "type": event.get("type", ""),
                "reason": event.get("reason", ""),
                "object": f"{event['involvedObject']['kind']}/{event['involvedObject']['name']}",
                "message": event.get("message", ""),
                "age": self._calculate_age(event["metadata"]["creationTimestamp"]),
                "namespace": event["metadata"]["namespace"]
            })

        return event_info

    def _calculate_age(self, creation_timestamp: str) -> str:
        """Calculate age from creation timestamp."""
        try:
            from datetime import datetime
            created = datetime.fromisoformat(creation_timestamp.replace('Z', '+00:00'))
            now = datetime.now(created.tzinfo)
            delta = now - created

            if delta.days > 0:
                return f"{delta.days}d"
            elif delta.seconds >= 3600:
                return f"{delta.seconds // 3600}h"
            elif delta.seconds >= 60:
                return f"{delta.seconds // 60}m"
            else:
                return f"{delta.seconds}s"
        except:
            return "Unknown"

    def generate_full_insight(self, verbose: bool = False, json_output: bool = False):
        """Generate comprehensive insight report."""

        if json_output:
            self._generate_json_insight(verbose)
            return

        # Cluster Overview
        self._display_cluster_overview()

        # Resources Overview
        self._display_resources_overview(verbose)

        # Services & Networking
        self._display_services_networking(verbose)

        # Networking Details
        self._display_networking_details(verbose)

        # Storage
        self._display_storage_overview(verbose)

        # Workloads
        self._display_workloads_overview(verbose)

        # Configuration
        self._display_config_overview(verbose)

        # Network Policies
        self._display_network_policies_overview(verbose)

        # Helm Releases
        self._display_helm_overview(verbose)

        # Recent Events
        self._display_events_overview(verbose)

        # Raw kubectl output for all resources
        self._display_raw_kubectl_overview(verbose)

        console.print("\n[bold green]✓ Insight generation complete![/bold green]")

    def _display_cluster_overview(self):
        """Display cluster overview."""
        console.print("\n[bold blue]🏗️  CLUSTER OVERVIEW[/bold blue]")
        console.rule()

        cluster_info = self.get_cluster_info()

        # Cluster Status
        status_table = TableClass(title="Cluster Status")
        status_table.add_column("Component", style="cyan")
        status_table.add_column("Status", style="green")
        status_table.add_column("Details")

        status_table.add_row("Kubernetes API", cluster_info["status"], f"Version: {cluster_info['version']}")
        status_table.add_row("kubectl", "✓ Available" if self.kubectl_available else "✗ Unavailable", "")
        status_table.add_row("Helm", "✓ Available" if self.helm_available else "✗ Unavailable", "")

        console.print(status_table)

        # Nodes
        if cluster_info["nodes"]:
            nodes_table = TableClass(title="Nodes")
            nodes_table.add_column("Name", style="cyan")
            nodes_table.add_column("Status", style="green")
            nodes_table.add_column("Internal IP", style="blue")
            nodes_table.add_column("External IP", style="magenta")
            nodes_table.add_column("CPU")
            nodes_table.add_column("Memory")

            for node in cluster_info["nodes"]:
                status_color = "green" if node["status"] == "Ready" else "red"
                nodes_table.add_row(
                    node["name"][:20] + "..." if len(node["name"]) > 20 else node["name"],
                    f"[{status_color}]{node['status']}[/{status_color}]",
                    node["internal_ip"],
                    node["external_ip"] or "-",
                    node["cpu"],
                    node["memory"]
                )

            console.print(nodes_table)

            # Show additional node details
            console.print("\n[bold]Node Details:[/bold]")
            for node in cluster_info["nodes"]:
                console.print(f"  [cyan]{node['name']}[/cyan]:")
                console.print(f"    Hostname: {node['hostname']}")
                console.print(f"    Pod CIDR: {node['pod_cidr']}")
                console.print(f"    OS: {node['os'][:50]}..." if len(node['os']) > 50 else f"    OS: {node['os']}")
                console.print(f"    Kubelet: {node['version']}")
                console.print()

    def _display_resources_overview(self, verbose: bool = False):
        """Display resources overview."""
        console.print("\n[bold blue]📦 RESOURCES OVERVIEW[/bold blue]")
        console.rule()

        # Pods
        pods = self.get_pods_info()
        if pods:
            pods_table = TableClass(title="Pods")
            pods_table.add_column("Name", style="cyan")
            pods_table.add_column("Namespace", style="blue")
            pods_table.add_column("Status", style="green")
            pods_table.add_column("Ready")
            pods_table.add_column("Restarts")
            pods_table.add_column("Age")

            for pod in pods[:20] if not verbose else pods:  # Limit for non-verbose
                status_color = "green" if pod["status"] == "Running" else "red"
                pods_table.add_row(
                    pod["name"][:30] + "..." if len(pod["name"]) > 30 else pod["name"],
                    pod["namespace"],
                    f"[{status_color}]{pod['status']}[/{status_color}]",
                    pod["ready"],
                    str(pod["restarts"]),
                    pod["age"]
                )

            console.print(pods_table)
            if len(pods) > 20 and not verbose:
                console.print(f"[dim]... and {len(pods) - 20} more pods[/dim]")

        # Deployments
        deployments = self.get_deployments_info()
        if deployments:
            deploy_table = TableClass(title="Deployments")
            deploy_table.add_column("Name", style="cyan")
            deploy_table.add_column("Namespace", style="blue")
            deploy_table.add_column("Ready", style="green")
            deploy_table.add_column("Up-to-date")
            deploy_table.add_column("Available")
            deploy_table.add_column("Age")

            for deploy in deployments:
                deploy_table.add_row(
                    deploy["name"],
                    deploy["namespace"],
                    deploy["ready"],
                    str(deploy["up_to_date"]),
                    str(deploy["available"]),
                    deploy["age"]
                )

            console.print(deploy_table)

    def _display_services_networking(self, verbose: bool = False):
        """Display services and networking."""
        console.print("\n[bold blue]🌐 SERVICES & NETWORKING[/bold blue]")
        console.rule()

        # Services
        services = self.get_services_info()
        if services:
            svc_table = TableClass(title="Services")
            svc_table.add_column("Name", style="cyan")
            svc_table.add_column("Namespace", style="blue")
            svc_table.add_column("Type", style="yellow")
            svc_table.add_column("Cluster IP", style="green")
            svc_table.add_column("External IP", style="magenta")
            svc_table.add_column("Ports", style="red")

            for svc in services[:15] if not verbose else services:
                # Enhanced port display
                ports_info = []
                for port in svc["ports"]:
                    port_str = f"{port['port']}"
                    if port['target_port'] and str(port['target_port']) != str(port['port']):
                        port_str += f"→{port['target_port']}"
                    port_str += f"/{port['protocol']}"
                    if port['name']:
                        port_str = f"{port['name']}:{port_str}"
                    ports_info.append(port_str)

                ports_str = ", ".join(ports_info[:2])
                if len(ports_info) > 2:
                    ports_str += f" +{len(ports_info) - 2} more"

                svc_table.add_row(
                    svc["name"][:25] + "..." if len(svc["name"]) > 25 else svc["name"],
                    svc["namespace"],
                    svc["type"],
                    svc["cluster_ip"],
                    svc["external_ip"] or "-",
                    ports_str
                )

            console.print(svc_table)

            # Show detailed service information
            if verbose and services:
                console.print("\n[bold]Service Details:[/bold]")
                for svc in services[:5]:  # Limit detailed view
                    console.print(f"  [cyan]{svc['name']}[/cyan] ({svc['namespace']}):")
                    console.print(f"    Type: {svc['type']}")
                    console.print(f"    Cluster IP: {svc['cluster_ip']}")
                    if svc['external_ip']:
                        console.print(f"    External IP: {svc['external_ip']}")

                    console.print("    Ports:")
                    for port in svc["ports"]:
                        port_info = f"      {port['port']}/{port['protocol']}"
                        if port['target_port'] and str(port['target_port']) != str(port['port']):
                            port_info += f" → {port['target_port']}"
                        if port['name']:
                            port_info = f"      {port['name']}: {port_info}"
                        console.print(port_info)

                    if svc["endpoints"]:
                        console.print(f"    Endpoints: {', '.join(svc['endpoints'][:5])}")
                        if len(svc["endpoints"]) > 5:
                            console.print(f"      ... and {len(svc['endpoints']) - 5} more")

                    if svc["selector"]:
                        console.print(f"    Selector: {svc['selector']}")

                    console.print()

        # Ingress
        ingresses = self.get_ingress_info()
        if ingresses:
            ingress_table = TableClass(title="Ingress")
            ingress_table.add_column("Name", style="cyan")
            ingress_table.add_column("Namespace", style="blue")
            ingress_table.add_column("Class")
            ingress_table.add_column("Hosts")

            for ingress in ingresses:
                hosts_str = ", ".join(ingress["hosts"][:2])
                if len(ingress["hosts"]) > 2:
                    hosts_str += f" +{len(ingress['hosts']) - 2}"

                ingress_table.add_row(
                    ingress["name"],
                    ingress["namespace"],
                    ingress["class"],
                    hosts_str
                )

            console.print(ingress_table)

    def _display_networking_details(self, verbose: bool = False):
        """Display detailed networking information."""
        console.print("\n[bold blue]🌐 NETWORKING DETAILS[/bold blue]")
        console.rule()

        # Get cluster networking information
        cluster_info = self.get_cluster_info()

        # Network Configuration
        network_table = TableClass(title="Network Configuration")
        network_table.add_column("Component", style="cyan")
        network_table.add_column("Configuration", style="green")

        # Try to get service CIDR from various sources
        service_cidr = "10.43.0.0/16"  # Default for K3s
        try:
            # Check if we can get from kube-apiserver config
            configmaps = self._run_kubectl(["get", "configmap", "kube-apiserver", "-n", "kube-system", "-o", "json"])
            if configmaps:
                config_yaml = configmaps.get("data", {}).get("config.yaml", "")
                if "service-cluster-ip-range" in config_yaml:
                    # This would need proper YAML parsing
                    pass
        except:
            pass

        network_table.add_row("Service Cluster IP Range", service_cidr)
        network_table.add_row("Pod Network CIDR", "10.42.0.0/16")  # Default for K3s
        network_table.add_row("Cluster DNS", "10.43.0.10")  # Default for K3s

        console.print(network_table)

        # Node Networking
        if cluster_info["nodes"]:
            console.print("\n[bold]Node Networking:[/bold]")
            for node in cluster_info["nodes"]:
                console.print(f"  [cyan]{node['name']}[/cyan]:")
                console.print(f"    Internal IP: {node['internal_ip']}")
                if node['external_ip']:
                    console.print(f"    External IP: {node['external_ip']}")
                console.print(f"    Pod CIDR: {node['pod_cidr']}")
                console.print(f"    Hostname: {node['hostname']}")
                console.print()

        # DNS and CoreDNS information
        console.print("[bold]DNS Configuration:[/bold]")
        try:
            coredns = self._run_kubectl(["get", "deployment", "coredns", "-n", "kube-system", "-o", "json"])
            if coredns:
                console.print("  ✓ CoreDNS is deployed")
                # Get service IP
                dns_svc = self._run_kubectl(["get", "service", "kube-dns", "-n", "kube-system", "-o", "json"])
                if dns_svc:
                    cluster_ip = dns_svc.get("spec", {}).get("clusterIP", "Unknown")
                    console.print(f"  Cluster DNS IP: {cluster_ip}")
            else:
                console.print("  ✗ CoreDNS not found")
        except:
            console.print("  Unable to check DNS configuration")

        # Network Policies
        network_policies = self._run_kubectl(["get", "networkpolicy", "--all-namespaces", "-o", "json"])
        if network_policies and network_policies.get("items"):
            np_count = len(network_policies["items"])
            console.print(f"\n[bold]Network Policies:[/bold] {np_count} configured")
            if verbose and np_count > 0:
                for np in network_policies["items"][:3]:  # Show first 3
                    console.print(f"  - {np['metadata']['name']} ({np['metadata']['namespace']})")
                if np_count > 3:
                    console.print(f"  ... and {np_count - 3} more")
        else:
            console.print("\n[bold]Network Policies:[/bold] None configured")

    def _display_storage_overview(self, verbose: bool = False):
        """Display storage overview."""
        console.print("\n[bold blue]💾 STORAGE OVERVIEW[/bold blue]")
        console.rule()

        storage = self.get_storage_info()

        # PVCs
        if storage["pvcs"]:
            pvc_table = TableClass(title="Persistent Volume Claims")
            pvc_table.add_column("Name", style="cyan")
            pvc_table.add_column("Namespace", style="blue")
            pvc_table.add_column("Status", style="green")
            pvc_table.add_column("Capacity")
            pvc_table.add_column("Storage Class")

            for pvc in storage["pvcs"][:10] if not verbose else storage["pvcs"]:
                status_color = "green" if pvc["status"] == "Bound" else "red"
                pvc_table.add_row(
                    pvc["name"][:25] + "..." if len(pvc["name"]) > 25 else pvc["name"],
                    pvc["namespace"],
                    f"[{status_color}]{pvc['status']}[/{status_color}]",
                    pvc["capacity"],
                    pvc["storage_class"]
                )

            console.print(pvc_table)

        # PVs
        if storage["pvs"]:
            pv_table = TableClass(title="Persistent Volumes")
            pv_table.add_column("Name", style="cyan")
            pv_table.add_column("Capacity", style="green")
            pv_table.add_column("Access Modes")
            pv_table.add_column("Reclaim Policy")
            pv_table.add_column("Status", style="yellow")
            pv_table.add_column("Storage Class")
            pv_table.add_column("Claim")

            for pv in storage["pvs"][:10] if not verbose else storage["pvs"]:
                status_color = "green" if pv["status"] == "Bound" else "yellow" if pv["status"] == "Available" else "red"
                access_modes = ",".join(pv["access_modes"]) if pv["access_modes"] else ""
                pv_table.add_row(
                    pv["name"][:20] + "..." if len(pv["name"]) > 20 else pv["name"],
                    pv["capacity"],
                    access_modes,
                    pv["reclaim_policy"],
                    f"[{status_color}]{pv['status']}[/{status_color}]",
                    pv["storage_class"],
                    pv["claim"][:25] + "..." if len(pv["claim"]) > 25 else pv["claim"]
                )

            console.print(pv_table)

        # Storage Classes
        if storage["storage_classes"]:
            sc_table = TableClass(title="Storage Classes")
            sc_table.add_column("Name", style="cyan")
            sc_table.add_column("Provisioner", style="green")
            sc_table.add_column("Reclaim Policy")
            sc_table.add_column("Volume Binding")
            sc_table.add_column("Default")

            for sc in storage["storage_classes"]:
                default_marker = "[bold green]✓[/bold green]" if sc["default"] == "Yes" else ""
                sc_table.add_row(
                    sc["name"],
                    sc["provisioner"][:30] + "..." if len(sc["provisioner"]) > 30 else sc["provisioner"],
                    sc["reclaim_policy"],
                    sc["volume_binding_mode"],
                    default_marker
                )

            console.print(sc_table)

    def _display_helm_overview(self, verbose: bool = False):
        """Display Helm releases overview."""
        console.print("\n[bold blue]⚓ HELM RELEASES[/bold blue]")
        console.rule()

        releases = self.get_helm_releases()
        if releases:
            helm_table = TableClass(title="Helm Releases")
            helm_table.add_column("Name", style="cyan")
            helm_table.add_column("Namespace", style="blue")
            helm_table.add_column("Status", style="green")
            helm_table.add_column("Chart")
            helm_table.add_column("App Version")

            for release in releases[:15] if not verbose else releases:
                status_color = "green" if release["status"] == "deployed" else "red"
                helm_table.add_row(
                    release["name"],
                    release["namespace"],
                    f"[{status_color}]{release['status']}[/{status_color}]",
                    release["chart"][:30] + "..." if len(release["chart"]) > 30 else release["chart"],
                    release["app_version"]
                )

            console.print(helm_table)

    def _display_workloads_overview(self, verbose: bool = False):
        """Display workloads overview (StatefulSets, Jobs, CronJobs)."""
        console.print("\n[bold blue]⚙️  WORKLOADS OVERVIEW[/bold blue]")
        console.rule()

        # StatefulSets
        statefulsets = self.get_statefulsets_info()
        if statefulsets:
            sts_table = TableClass(title="StatefulSets")
            sts_table.add_column("Name", style="cyan")
            sts_table.add_column("Namespace", style="blue")
            sts_table.add_column("Ready", style="green")
            sts_table.add_column("Service")
            sts_table.add_column("Age")

            for sts in statefulsets:
                sts_table.add_row(
                    sts["name"],
                    sts["namespace"],
                    sts["ready"],
                    sts["service"],
                    sts["age"]
                )

            console.print(sts_table)

        # Jobs
        jobs = self.get_jobs_info()
        if jobs:
            jobs_table = TableClass(title="Jobs")
            jobs_table.add_column("Name", style="cyan")
            jobs_table.add_column("Namespace", style="blue")
            jobs_table.add_column("Completions", style="green")
            jobs_table.add_column("Duration")
            jobs_table.add_column("Status", style="yellow")

            for job in jobs[:10] if not verbose else jobs:
                status_color = "green" if job["status"] == "Complete" else "red" if job["status"] == "Failed" else "blue"
                jobs_table.add_row(
                    job["name"][:25] + "..." if len(job["name"]) > 25 else job["name"],
                    job["namespace"],
                    job["completions"],
                    job["duration"],
                    f"[{status_color}]{job['status']}[/{status_color}]"
                )

            console.print(jobs_table)

        # CronJobs
        cronjobs = self.get_cronjobs_info()
        if cronjobs:
            cj_table = TableClass(title="CronJobs")
            cj_table.add_column("Name", style="cyan")
            cj_table.add_column("Namespace", style="blue")
            cj_table.add_column("Schedule", style="green")
            cj_table.add_column("Suspend")
            cj_table.add_column("Active")
            cj_table.add_column("Last Schedule")

            for cj in cronjobs:
                suspend_status = "[red]Yes[/red]" if cj["suspend"] else "[green]No[/green]"
                cj_table.add_row(
                    cj["name"],
                    cj["namespace"],
                    cj["schedule"],
                    suspend_status,
                    str(cj["active"]),
                    cj["last_schedule"][:20] + "..." if len(cj["last_schedule"]) > 20 else cj["last_schedule"]
                )

            console.print(cj_table)

    def _display_config_overview(self, verbose: bool = False):
        """Display configuration resources overview (ConfigMaps, Secrets)."""
        console.print("\n[bold blue]🔧 CONFIGURATION OVERVIEW[/bold blue]")
        console.rule()

        # ConfigMaps
        configmaps = self.get_configmaps_info()
        if configmaps:
            cm_table = TableClass(title="ConfigMaps")
            cm_table.add_column("Name", style="cyan")
            cm_table.add_column("Namespace", style="blue")
            cm_table.add_column("Data Keys", style="green")
            cm_table.add_column("Age")

            for cm in configmaps[:15] if not verbose else configmaps:
                data_keys = ", ".join(cm["data_keys"][:3])
                if len(cm["data_keys"]) > 3:
                    data_keys += f" +{len(cm['data_keys']) - 3} more"
                cm_table.add_row(
                    cm["name"][:25] + "..." if len(cm["name"]) > 25 else cm["name"],
                    cm["namespace"],
                    data_keys,
                    cm["age"]
                )

            console.print(cm_table)

        # Secrets
        secrets = self.get_secrets_info()
        if secrets:
            sec_table = TableClass(title="Secrets")
            sec_table.add_column("Name", style="cyan")
            sec_table.add_column("Namespace", style="blue")
            sec_table.add_column("Type", style="yellow")
            sec_table.add_column("Data Keys", style="green")
            sec_table.add_column("Age")

            for sec in secrets[:15] if not verbose else secrets:
                data_keys = ", ".join(sec["data_keys"][:3])
                if len(sec["data_keys"]) > 3:
                    data_keys += f" +{len(sec['data_keys']) - 3} more"
                sec_table.add_row(
                    sec["name"][:25] + "..." if len(sec["name"]) > 25 else sec["name"],
                    sec["namespace"],
                    sec["type"],
                    data_keys,
                    sec["age"]
                )

            console.print(sec_table)

    def _display_network_policies_overview(self, verbose: bool = False):
        """Display network policies overview."""
        console.print("\n[bold blue]🔒 NETWORK POLICIES[/bold blue]")
        console.rule()

        policies = self.get_network_policies_info()
        if policies:
            np_table = TableClass(title="Network Policies")
            np_table.add_column("Name", style="cyan")
            np_table.add_column("Namespace", style="blue")
            np_table.add_column("Pod Selector", style="green")
            np_table.add_column("Ingress Rules")
            np_table.add_column("Egress Rules")
            np_table.add_column("Policy Types")

            for np in policies[:10] if not verbose else policies:
                selector_str = ", ".join([f"{k}={v}" for k, v in np["pod_selector"].items()][:2])
                if len(np["pod_selector"]) > 2:
                    selector_str += f" +{len(np['pod_selector']) - 2} more"
                policy_types = ", ".join(np["policy_types"])
                
                np_table.add_row(
                    np["name"][:25] + "..." if len(np["name"]) > 25 else np["name"],
                    np["namespace"],
                    selector_str,
                    str(np["ingress_rules"]),
                    str(np["egress_rules"]),
                    policy_types
                )

            console.print(np_table)
        else:
            console.print("[dim]No network policies configured[/dim]")

    def _display_events_overview(self, verbose: bool = False):
        """Display recent events."""
        console.print("\n[bold blue]📋 RECENT EVENTS[/bold blue]")
        console.rule()

        events = self.get_recent_events(limit=10 if not verbose else 25)
        if events:
            events_table = TableClass(title="Recent Events")
            events_table.add_column("Type", style="yellow")
            events_table.add_column("Reason", style="cyan")
            events_table.add_column("Object")
            events_table.add_column("Message")
            events_table.add_column("Age")

            for event in events:
                type_color = "red" if event["type"] == "Warning" else "blue"
                events_table.add_row(
                    f"[{type_color}]{event['type']}[/{type_color}]",
                    event["reason"],
                    event["object"][:25] + "..." if len(event["object"]) > 25 else event["object"],
                    event["message"][:50] + "..." if len(event["message"]) > 50 else event["message"],
                    event["age"]
                )

            console.print(events_table)

    def _display_raw_kubectl_overview(self, verbose: bool = False):
        """Display raw kubectl output for all resources (like kubectl get all)."""
        console.print("\n[bold blue]🔍 RAW KUBECTL OUTPUT - Complete Resource Overview[/bold blue]")
        console.rule()

        self._display_raw_kubectl_overview_content(verbose)

    def _display_raw_kubectl_overview_content(self, verbose: bool = False):
        """Display raw kubectl output content for all resources."""
        resources = [
            ("nodes", "Nodes"),
            ("namespaces", "Namespaces"),
            ("pods", "Pods"),
            ("services", "Services"),
            ("deployments", "Deployments"),
            ("statefulsets", "StatefulSets"),
            ("jobs", "Jobs"),
            ("cronjobs", "CronJobs"),
            ("configmaps", "ConfigMaps"),
            ("secrets", "Secrets"),
            ("pv", "Persistent Volumes"),
            ("pvc", "Persistent Volume Claims"),
            ("storageclass", "Storage Classes"),
            ("ingress", "Ingresses"),
            ("networkpolicy", "Network Policies"),
        ]

        for resource, display_name in resources:
            console.print(f"[bold yellow]{display_name}:[/bold yellow]")
            cmd = ["kubectl", "get", resource]

            # Use --all-namespaces for namespaced resources unless in verbose mode
            if not verbose and resource not in ["nodes", "namespaces", "pv", "storageclass"]:
                cmd.append("--all-namespaces")

            try:
                result = subprocess.run(
                    cmd,
                    capture_output=True,
                    text=True,
                    timeout=30
                )
                if result.returncode == 0:
                    # Count lines (subtract 1 for header)
                    lines = result.stdout.strip().split('\n')
                    count = len(lines) - 1 if len(lines) > 1 else 0
                    console.print(f"[green]✓ {count} {display_name.lower()}[/green]")
                    if count > 0:
                        console.print(result.stdout)
                    else:
                        console.print("[dim]  No resources found[/dim]")
                else:
                    console.print(f"[red]✗ Error getting {display_name.lower()}: {result.stderr}[/red]")
            except subprocess.TimeoutExpired:
                console.print(f"[red]✗ Command timed out for {display_name.lower()}[/red]")
            except FileNotFoundError:
                console.print("[red]kubectl not found. Please install kubectl.[/red]")
                return

            console.print()  # Empty line between resources

    def _get_raw_kubectl_data(self, verbose: bool = False) -> Dict[str, Any]:
        """Get raw kubectl output for all resources."""
        raw_data = {}

        resources = [
            ("nodes", "nodes"),
            ("namespaces", "namespaces"),
            ("pods", "pods"),
            ("services", "services"),
            ("deployments", "deployments"),
            ("statefulsets", "statefulsets"),
            ("jobs", "jobs"),
            ("cronjobs", "cronjobs"),
            ("configmaps", "configmaps"),
            ("secrets", "secrets"),
            ("pv", "persistentvolumes"),
            ("pvc", "persistentvolumeclaims"),
            ("storageclass", "storageclasses"),
            ("ingress", "ingresses"),
            ("networkpolicy", "networkpolicies"),
        ]

        for resource, key in resources:
            cmd = ["kubectl", "get", resource, "-o", "json"]

            # Use --all-namespaces for namespaced resources unless in verbose mode
            if not verbose and resource not in ["nodes", "namespaces", "pv", "storageclass"]:
                cmd.append("--all-namespaces")

            try:
                result = subprocess.run(
                    cmd,
                    capture_output=True,
                    text=True,
                    timeout=30
                )
                if result.returncode == 0:
                    try:
                        raw_data[key] = json.loads(result.stdout)
                    except json.JSONDecodeError:
                        raw_data[key] = {"error": "Failed to parse JSON output"}
                else:
                    raw_data[key] = {"error": result.stderr.strip()}
            except (subprocess.TimeoutExpired, subprocess.SubprocessError):
                raw_data[key] = {"error": "Command timed out or failed"}

        return raw_data

    def _generate_json_insight(self, verbose: bool = False):
        """Generate insight report in JSON format."""
        insight_data = {
            "cluster": self.get_cluster_info(),
            "resources": {
                "pods": self.get_pods_info(),
                "deployments": self.get_deployments_info(),
                "statefulsets": self.get_statefulsets_info(),
                "jobs": self.get_jobs_info(),
                "cronjobs": self.get_cronjobs_info()
            },
            "networking": {
                "services": self.get_services_info(),
                "ingress": self.get_ingress_info(),
                "network_policies": self.get_network_policies_info()
            },
            "storage": self.get_storage_info(),
            "configuration": {
                "configmaps": self.get_configmaps_info(),
                "secrets": self.get_secrets_info()
            },
            "helm": {
                "releases": self.get_helm_releases()
            },
            "events": self.get_recent_events(limit=50 if verbose else 20),
            "raw_kubectl": self._get_raw_kubectl_data(verbose)
        }

        console.print(json.dumps(insight_data, indent=2, default=str))

    def display_raw_kubectl_only(self, verbose: bool = False):
        """Display only raw kubectl output for all resources (like kubectl get all)."""
        console.print("\n[bold cyan]═══════════════════════════════════════════════════════════════[/bold cyan]")
        console.print("[bold cyan]  🔍 RAW KUBECTL OUTPUT - Complete Resource Overview[/bold cyan]")
        console.print("[bold cyan]═══════════════════════════════════════════════════════════════[/bold cyan]\n")

        # Call the raw kubectl display without its own header
        self._display_raw_kubectl_overview_content(verbose)

        console.print("\n[bold green]✓ Raw kubectl output complete![/bold green]")