"""
Y Build SDK Exceptions

All exceptions inherit from YBuildError for easy catching.
"""


class YBuildError(Exception):
    """Base exception for all Y Build SDK errors."""

    def __init__(self, message: str, status_code: int = None, response: dict = None):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.response = response or {}

    def __str__(self):
        if self.status_code:
            return f"[{self.status_code}] {self.message}"
        return self.message


class AuthenticationError(YBuildError):
    """Raised when API key is invalid or missing."""
    pass


class ContainerError(YBuildError):
    """Base exception for container-related errors."""
    pass


class ContainerNotFoundError(ContainerError):
    """Raised when container does not exist."""
    pass


class ContainerStoppedError(ContainerError):
    """Raised when trying to operate on a stopped container."""
    pass


class QuotaExceededError(YBuildError):
    """Raised when organization quota is exceeded."""
    pass


class RateLimitError(YBuildError):
    """Raised when API rate limit is hit."""

    def __init__(self, message: str, retry_after: int = None, **kwargs):
        super().__init__(message, **kwargs)
        self.retry_after = retry_after


class NetworkError(YBuildError):
    """Raised when network connection fails."""
    pass


class TimeoutError(YBuildError):
    """Raised when request times out."""
    pass


class ValidationError(YBuildError):
    """Raised when request validation fails."""
    pass


class ServerError(YBuildError):
    """Raised when server returns 5xx error."""
    pass
