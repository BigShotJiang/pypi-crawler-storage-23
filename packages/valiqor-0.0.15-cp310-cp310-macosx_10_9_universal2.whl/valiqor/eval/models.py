"""
Valiqor Eval Models - Data Classes for Evaluation Results
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class EvaluationResult:
    """Result from a quality evaluation request."""

    run_id: str
    project_id: str
    status: str
    overall_score: Optional[float]
    aggregate_scores: Dict[str, float]
    total_items: int
    items_evaluated: int
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __str__(self) -> str:
        score_str = f"{self.overall_score:.3f}" if self.overall_score is not None else "N/A"
        return (
            f"Evaluation Run {self.run_id}\n"
            f"Project: {self.project_id}\n"
            f"Status: {self.status}\n"
            f"Overall Score: {score_str}\n"
            f"Items: {self.items_evaluated}/{self.total_items} evaluated"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "run_id": self.run_id,
            "project_id": self.project_id,
            "status": self.status,
            "overall_score": self.overall_score,
            "aggregate_scores": self.aggregate_scores,
            "total_items": self.total_items,
            "items_evaluated": self.items_evaluated,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "EvaluationResult":
        """Create from a backend response dict."""
        return cls(
            run_id=data.get("run_id") or data.get("id", ""),
            project_id=data.get("project_id", ""),
            status=data.get("status", ""),
            overall_score=data.get("overall_score"),
            aggregate_scores=data.get("aggregate_scores", {}),
            total_items=data.get("total_items", 0),
            items_evaluated=data.get("evaluated_items", data.get("items_evaluated", 0)),
            metadata=data.get("metadata", {}),
        )


@dataclass
class AuthInfo:
    """Authentication validation response."""

    valid: bool
    user_id: Optional[str] = None
    org_id: Optional[str] = None
    org_name: Optional[str] = None
    plan: Optional[str] = None

    def __str__(self) -> str:
        return f"AuthInfo(valid={self.valid}, " f"org={self.org_name}, " f"plan={self.plan})"

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AuthInfo":
        """Create from a backend response dict."""
        return cls(
            valid=data.get("valid", False),
            user_id=data.get("user_id"),
            org_id=data.get("org_id"),
            org_name=data.get("org_name"),
            plan=data.get("plan"),
        )


@dataclass
class ProjectInfo:
    """Project information."""

    id: str
    name: str
    key: Optional[str] = None
    model_name: Optional[str] = None
    created_at: Optional[str] = None

    def __str__(self) -> str:
        return f"Project: {self.name} ({self.id})"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "id": self.id,
            "name": self.name,
            "key": self.key,
            "model_name": self.model_name,
            "created_at": self.created_at,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ProjectInfo":
        """Create from a backend response dict."""
        return cls(
            id=data.get("id", ""),
            name=data.get("name", ""),
            key=data.get("key"),
            model_name=data.get("model_name"),
            created_at=data.get("created_at"),
        )


@dataclass
class MetricInfo:
    """Metric template/definition information."""

    key: str
    display_name: str
    definition: Optional[str] = None
    value_type: str = "numeric"
    category: Optional[str] = None

    def __str__(self) -> str:
        return f"{self.key}: {self.display_name}"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "key": self.key,
            "display_name": self.display_name,
            "definition": self.definition,
            "value_type": self.value_type,
            "category": self.category,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MetricInfo":
        """Create from a backend response dict."""
        return cls(
            key=data.get("key", ""),
            display_name=data.get("display_name", data.get("key", "")),
            definition=data.get("definition"),
            value_type=data.get("value_type", "numeric"),
            category=data.get("category"),
        )


@dataclass
class JobStatus:
    """Status of an async evaluation job."""

    job_id: str
    job_type: str  # "evaluation"
    status: str  # "queued", "running", "completed", "failed", "cancelled"
    progress_percent: float = 0.0
    current_item: int = 0
    total_items: int = 0
    started_at: Optional[str] = None
    finished_at: Optional[str] = None
    error: Optional[str] = None
    result: Optional["EvaluationResult"] = None

    @property
    def is_running(self) -> bool:
        """Check if job is still running."""
        return self.status in ("queued", "running")

    @property
    def is_completed(self) -> bool:
        """Check if job completed successfully."""
        return self.status == "completed"

    @property
    def is_failed(self) -> bool:
        """Check if job failed."""
        return self.status in ("failed", "cancelled")

    def __str__(self) -> str:
        if self.is_running:
            return f"Job {self.job_id}: {self.status} ({self.progress_percent:.1f}% - {self.current_item}/{self.total_items})"
        return f"Job {self.job_id}: {self.status}"

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "JobStatus":
        """Create from a backend response dict."""
        return cls(
            job_id=data.get("job_id", ""),
            job_type=data.get("job_type", "evaluation"),
            status=data.get("status", ""),
            progress_percent=data.get("progress_percent", 0.0),
            current_item=data.get("current_item", 0),
            total_items=data.get("total_items", 0),
            started_at=data.get("started_at"),
            finished_at=data.get("finished_at"),
            error=data.get("error"),
        )


@dataclass
class AsyncJobHandle:
    """Handle returned when backend processes request asynchronously (HTTP 202).

    Use this to poll for job status or connect to WebSocket for real-time updates.

    Attributes:
        job_id: Unique identifier for the job
        job_type: Type of job ("evaluation", "security_audit", "redteam")
        status: Initial status (usually "queued")
        poll_url: URL to poll for job status
        websocket_url: WebSocket URL for real-time progress updates
        total_items: Total number of items to process
        message: Human-readable status message

    Example:
        # Submit large evaluation (returns AsyncJobHandle)
        handle = client.evaluate(large_dataset, metrics)

        # Poll for status
        status = client.get_job_status(handle.job_id)

        # Or use WebSocket for real-time updates
        # ws://backend/ws/progress/evaluation/{job_id}
    """

    job_id: str
    job_type: str
    status: str
    poll_url: str
    total_items: int
    websocket_url: Optional[str] = None
    message: Optional[str] = None
    project_id: Optional[str] = None

    def __str__(self) -> str:
        return f"AsyncJob({self.job_type}): {self.job_id} - {self.status} ({self.total_items} items)"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "job_id": self.job_id,
            "job_type": self.job_type,
            "status": self.status,
            "poll_url": self.poll_url,
            "websocket_url": self.websocket_url,
            "total_items": self.total_items,
            "message": self.message,
            "project_id": self.project_id,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AsyncJobHandle":
        """Create from a backend response dict."""
        return cls(
            job_id=data.get("job_id", ""),
            job_type=data.get("job_type", ""),
            status=data.get("status", "queued"),
            poll_url=data.get("poll_url", ""),
            total_items=data.get("total_items", 0),
            websocket_url=data.get("websocket_url"),
            message=data.get("message"),
            project_id=data.get("project_id"),
        )


@dataclass
class EvaluationItem:
    """Single evaluation item with scores."""

    input: str
    output: str
    context: Optional[str] = None
    expected: Optional[str] = None
    scores: Dict[str, float] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for API request."""
        result = {
            "input": self.input,
            "output": self.output,
        }
        if self.context:
            result["context"] = self.context
        if self.expected:
            result["expected"] = self.expected
        if self.metadata:
            result["metadata"] = self.metadata
        return result

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "EvaluationItem":
        """Create from a backend response dict."""
        return cls(
            input=data.get("input", ""),
            output=data.get("output", ""),
            context=data.get("context"),
            expected=data.get("expected"),
            scores=data.get("scores", {}),
            metadata=data.get("metadata", {}),
        )


# =========================================================================
# Typed models for eval client read-back methods
# =========================================================================


@dataclass
class RunMetric:
    """Per-metric score for a completed evaluation run."""

    key: str
    display_name: str
    score: float
    value_type: str = "numeric"

    def __str__(self) -> str:
        return f"{self.display_name}: {self.score:.2%}"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "key": self.key,
            "display_name": self.display_name,
            "score": self.score,
            "value_type": self.value_type,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "RunMetric":
        """Create from a backend response dict.

        Supports both the backend field names (metric_key, metric_name,
        mean_value) and the SDK's own field names (key, display_name, score)
        for round-trip compatibility.
        """
        key = data.get("metric_key", data.get("key", ""))
        return cls(
            key=key,
            display_name=data.get("metric_name", data.get("display_name", key)),
            score=data.get("mean_value", data.get("score", 0.0)),
            value_type=data.get("value_type", "numeric"),
        )


@dataclass
class EvalItemDetail:
    """Full detail for a single evaluated item."""

    id: str
    run_id: str
    input: str = ""
    output: str = ""
    context: Optional[str] = None
    expected: Optional[str] = None
    overall_score: Optional[float] = None
    metric_scores: Dict[str, float] = field(default_factory=dict)
    explanations: Dict[str, str] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __str__(self) -> str:
        score_str = f"{self.overall_score:.3f}" if self.overall_score is not None else "N/A"
        return f"Item {self.id[:12]}.. score={score_str}"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "run_id": self.run_id,
            "input": self.input,
            "output": self.output,
            "context": self.context,
            "expected": self.expected,
            "overall_score": self.overall_score,
            "metric_scores": self.metric_scores,
            "explanations": self.explanations,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "EvalItemDetail":
        """Create from a backend response dict."""
        return cls(
            id=data.get("id") or data.get("item_id", ""),
            run_id=data.get("run_id", ""),
            input=data.get("input", ""),
            output=data.get("output", ""),
            context=data.get("context"),
            expected=data.get("expected"),
            overall_score=data.get("overall_score"),
            metric_scores=data.get("metric_scores", data.get("scores", {})),
            explanations=data.get("explanations", {}),
            metadata=data.get("metadata", {}),
        )


@dataclass
class EvalItemsPage:
    """Paginated list of evaluated items for a run."""

    items: List[EvalItemDetail]
    total: int
    page: int
    page_size: int

    def __str__(self) -> str:
        return f"EvalItemsPage(page={self.page}, showing={len(self.items)}, total={self.total})"

    def __len__(self) -> int:
        return len(self.items)

    def __iter__(self):
        return iter(self.items)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "items": [item.to_dict() for item in self.items],
            "total": self.total,
            "page": self.page,
            "page_size": self.page_size,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "EvalItemsPage":
        """Create from a backend response dict."""
        raw_items = data.get("items", [])
        items = [EvalItemDetail.from_dict(item) for item in raw_items]
        return cls(
            items=items,
            total=data.get("total", len(items)),
            page=data.get("page", 1),
            page_size=data.get("page_size", 20),
        )


@dataclass
class EvalTrendPoint:
    """Single data point in an evaluation trend series."""

    date: str
    metric: str
    score: float
    run_count: int = 0

    def __str__(self) -> str:
        return f"{self.date} {self.metric}: {self.score:.2f} ({self.run_count} runs)"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "date": self.date,
            "metric": self.metric,
            "score": self.score,
            "run_count": self.run_count,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "EvalTrendPoint":
        """Create from a backend response dict."""
        return cls(
            date=data.get("date", ""),
            metric=data.get("metric", ""),
            score=data.get("score", 0.0),
            run_count=data.get("run_count", 0),
        )


@dataclass
class EvalRunComparison:
    """Side-by-side comparison of 2-5 evaluation runs."""

    runs: List[Dict[str, Any]]
    metrics: List[Dict[str, Any]]
    overall_scores: List[float]

    def __str__(self) -> str:
        return f"EvalRunComparison({len(self.runs)} runs, {len(self.metrics)} metrics)"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "runs": self.runs,
            "metrics": self.metrics,
            "overall_scores": self.overall_scores,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "EvalRunComparison":
        """Create from a backend response dict."""
        return cls(
            runs=data.get("runs", []),
            metrics=data.get("metrics", []),
            overall_scores=data.get("overall_scores", []),
        )


@dataclass
class CancelResponse:
    """Response from a job cancellation request."""

    status: str
    message: str = ""
    job_id: Optional[str] = None

    def __str__(self) -> str:
        return f"Cancel: {self.status} - {self.message}"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "status": self.status,
            "message": self.message,
            "job_id": self.job_id,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CancelResponse":
        """Create from a backend response dict."""
        return cls(
            status=data.get("status", ""),
            message=data.get("message", ""),
            job_id=data.get("job_id"),
        )
