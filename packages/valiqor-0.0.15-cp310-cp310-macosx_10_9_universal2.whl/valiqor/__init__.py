"""
Valiqor - Unified SDK for LLM Observability, Evaluation, and Security

Submodules:
    - valiqor.eval: Quality evaluation for LLM outputs
    - valiqor.security: Security testing and red-teaming
    - valiqor.trace: LLM tracing and observability
    - valiqor.scanner: Codebase scanning for LLM patterns

Installation:
    pip install valiqor              # Core (includes eval, security, scanner, tracing)
    pip install valiqor[openai]      # + OpenAI auto-instrumentation
    pip install valiqor[anthropic]   # + Anthropic auto-instrumentation
    pip install valiqor[langchain]   # + LangChain auto-instrumentation
    pip install valiqor[trace]       # + All provider auto-instrumentation
    pip install valiqor[all]         # Same as [trace]

Quick Start:
    # Unified client
    from valiqor import ValiqorClient
    client = ValiqorClient(api_key="vq_xxx", project_name="my-app")

    # Evaluation
    result = client.eval.evaluate(dataset=[...], metrics=["factual_accuracy"])

    # Security
    audit = client.security.audit(prompts=[...])

    # Tracing (zero-config)
    import valiqor.auto  # Auto-instruments OpenAI, Anthropic, etc.

Configuration:
    Create a .valiqorrc file or use environment variables.
    See valiqor.common.config for details.
"""

__version__ = "0.0.15"
__author__ = "Valiqor Team"

# Core exports from common
from valiqor.common import (
    ensure_output_dirs,
    find_config_file,
    get_config,
    load_config_file,
    save_config,
)

# Alias for compatibility
load_config = load_config_file

# Unified client - always available
from valiqor.client import ValiqorClient
from valiqor.common.exceptions import (
    AccountDeactivatedError,
    APIError,
    AuthenticationError,
    ConfigurationError,
    DatasetTooLargeError,
    NetworkError,
    QuotaExceededError,
    RateLimitError,
    ServiceUnavailableError,
    TimeoutError,
    TokenQuotaExceededError,
    ValidationError,
    ValiqorError,
)

# Configure function for programmatic setup
_config = None


def configure(
    api_key: str = None,
    project_name: str = None,
    environment: str = None,
    config_file: str = None,
    **kwargs,
) -> dict:
    """
    Configure Valiqor SDK globally.

    Args:
        api_key: API key for authentication
        project_name: Project name for grouping traces/evals
        environment: Environment name (production, staging, etc.)
        config_file: Path to .valiqorrc file
        **kwargs: Additional config overrides

    Returns:
        Merged configuration dictionary

    Example:
        import valiqor
        valiqor.configure(
            api_key="vq_xxx",
            project_name="my-app",
            environment="production"
        )
    """
    global _config

    overrides = {}
    if api_key:
        overrides["api_key"] = api_key
    if project_name:
        overrides["project_name"] = project_name
    if environment:
        overrides["environment"] = environment
    overrides.update(kwargs)

    _config = get_config(config_file=config_file, **overrides)

    # Propagate configuration to trace/autolog module so the tracer
    # picks up api_key, project_name, etc. set programmatically.
    try:
        from valiqor.trace import configure as trace_configure

        trace_configure(
            api_key=_config.get("api_key"),
            project_name=_config.get("project_name"),
            environment=_config.get("environment"),
            trace_dir=_config.get("trace_dir"),
            config_file=config_file,
        )
    except ImportError:
        pass  # trace module not installed

    return _config


def get_current_config() -> dict:
    """Get the current global configuration."""
    global _config
    if _config is None:
        _config = get_config()
    return _config


def autolog(providers: list = None):
    """
    Enable auto-instrumentation for LLM providers.

    Args:
        providers: List of providers to instrument.
                   Default: ["openai", "anthropic", "langchain"]

    Example:
        import valiqor
        valiqor.configure(api_key="vq_xxx")
        valiqor.autolog()  # Auto-instruments all supported providers

        # Or specific providers
        valiqor.autolog(["openai"])
    """
    try:
        from valiqor.trace import autolog as trace_autolog

        return trace_autolog(providers=providers)
    except ImportError:
        raise ImportError("Trace module not available. Install with: pip install valiqor")


def trace_workflow(name: str = "workflow", input_data: dict = None):
    """
    Context manager/decorator for grouping operations under a single trace.

    Use this to group multiple LLM calls into a single conversation trace.
    Without this, each LangGraph invoke/stream creates a separate trace file.

    Args:
        name: Name for the workflow trace
        input_data: Optional dict with initial input data (e.g., user_query)

    Example as context manager:
        with valiqor.trace_workflow("my_conversation", {"user_query": "Hello"}):
            response1 = graph.invoke(...)  # Same trace
            response2 = graph.invoke(...)  # Same trace

    Example as decorator:
        @valiqor.trace_workflow("chat_handler")
        def handle_chat(message):
            return graph.invoke({"messages": [message]})
    """
    try:
        from valiqor.trace import trace_workflow as _trace_workflow

        return _trace_workflow(name=name, input_data=input_data)
    except ImportError:
        # Return a no-op context manager if trace module not available
        from contextlib import contextmanager

        @contextmanager
        def noop():
            yield

        return noop()


def trace_function(name: str = None, capture_input: bool = True, capture_output: bool = True):
    """
    Decorator for tracing individual function calls.

    Use this to trace functions that make LLM calls from providers without
    auto-instrumentation support (e.g., instructor, DSPy, Google ADK).

    Args:
        name: Optional name for the trace span (defaults to function name)
        capture_input: Whether to capture function inputs
        capture_output: Whether to capture function outputs

    Example:
        @valiqor.trace_function(name="my_llm_call")
        def call_llm(prompt: str):
            response = client.generate(prompt)
            return response
    """
    try:
        from valiqor.trace import trace_function as _trace_function

        return _trace_function(
            name=name, capture_input=capture_input, capture_output=capture_output
        )
    except ImportError:
        # Return a no-op decorator if trace module not available
        def noop_decorator(func):
            return func

        return noop_decorator


def start_conversation_trace(name: str = "conversation", input_data: dict = None):
    """
    Start a conversation trace manually.

    Use this for long-running conversations where you need explicit control
    over when the trace starts and ends.

    Args:
        name: Name for the conversation trace
        input_data: Optional dict with initial input data

    Returns:
        Trace context that should be passed to end_conversation_trace()

    Example:
        trace_ctx = valiqor.start_conversation_trace("chat_session")
        # ... multiple interactions ...
        valiqor.end_conversation_trace(trace_ctx)
    """
    try:
        from valiqor.trace import start_conversation_trace as _start

        return _start(name=name, input_data=input_data)
    except ImportError:
        return None


def end_conversation_trace(trace_ctx=None):
    """
    End a conversation trace started with start_conversation_trace().

    Args:
        trace_ctx: The trace context returned by start_conversation_trace()
    """
    try:
        from valiqor.trace import end_conversation_trace as _end

        return _end(trace_ctx)
    except ImportError:
        pass


__all__ = [
    # Version
    "__version__",
    # Client
    "ValiqorClient",
    # Configuration
    "configure",
    "get_current_config",
    "autolog",
    "trace_workflow",
    "trace_function",
    "start_conversation_trace",
    "end_conversation_trace",
    "load_config",
    "get_config",
    "save_config",
    "find_config_file",
    "ensure_output_dirs",
    # Exceptions
    "ValiqorError",
    "ConfigurationError",
    "AuthenticationError",
    "AccountDeactivatedError",
    "ValidationError",
    "APIError",
    "NetworkError",
    "TimeoutError",
    "RateLimitError",
    "QuotaExceededError",
    "DatasetTooLargeError",
    "ServiceUnavailableError",
    "TokenQuotaExceededError",
    # Sub-clients (lazy imports — available for TYPE_CHECKING or direct use)
    "ValiqorEvalClient",
    "ValiqorSecurityClient",
    "ValiqorFAClient",
    "TraceQueryClient",
]


# ---------------------------------------------------------------------------
# Lazy imports for sub-module clients so users can do:
#   from valiqor import ValiqorFAClient
# without pulling in heavy dependencies at import time.
# ---------------------------------------------------------------------------

def __getattr__(name: str):
    if name == "ValiqorEvalClient":
        from valiqor.eval import ValiqorEvalClient
        return ValiqorEvalClient
    if name == "ValiqorSecurityClient":
        from valiqor.security import ValiqorSecurityClient
        return ValiqorSecurityClient
    if name == "ValiqorFAClient":
        from valiqor.failure_analysis import ValiqorFAClient
        return ValiqorFAClient
    if name == "TraceQueryClient":
        from valiqor.trace.query import TraceQueryClient
        return TraceQueryClient
    raise AttributeError(f"module 'valiqor' has no attribute {name!r}")
