"""
Valiqor Security Models - Data Classes for Security Results
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class SecurityAuditResult:
    """Result from a security audit request."""

    audit_id: str
    total_items: int
    safe_count: int
    unsafe_count: int
    safety_score: float  # 0.0 to 1.0
    triggered_categories: Dict[str, int]
    top_risk_category: Optional[str] = None
    details: List[Dict[str, Any]] = field(default_factory=list)

    def __str__(self) -> str:
        return (
            f"Security Audit {self.audit_id}\n"
            f"Safety Score: {self.safety_score:.2%}\n"
            f"Safe: {self.safe_count}/{self.total_items}\n"
            f"Unsafe: {self.unsafe_count}/{self.total_items}\n"
            f"Top Risk: {self.top_risk_category or 'None'}"
        )

    @property
    def overall_safety_score(self) -> float:
        """Alias for safety_score (backward compatibility)."""
        return self.safety_score

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "audit_id": self.audit_id,
            "total_items": self.total_items,
            "safe_count": self.safe_count,
            "unsafe_count": self.unsafe_count,
            "safety_score": self.safety_score,
            "triggered_categories": self.triggered_categories,
            "top_risk_category": self.top_risk_category,
            "details": self.details,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SecurityAuditResult":
        """Create from a backend response dict."""
        total = data.get("total_items", 0)
        unsafe = data.get("unsafe_items", data.get("unsafe_count", 0))
        safe = total - unsafe
        return cls(
            audit_id=data.get("audit_id") or data.get("batch_id") or data.get("id", ""),
            total_items=total,
            safe_count=data.get("safe_count", safe),
            unsafe_count=unsafe,
            safety_score=data.get("safety_score", 1.0 - data.get("unsafe_rate", 0.0)),
            triggered_categories=data.get("triggered_categories", {}),
            top_risk_category=data.get("top_risk_category"),
            details=data.get("details", []),
        )


# Alias for backward compatibility
SecurityEvaluationResult = SecurityAuditResult


@dataclass
class RedTeamResult:
    """Result from a red-team simulation."""

    run_id: str
    project_id: str
    name: str
    status: str
    total_attacks: int
    successful_attacks: int
    success_rate: float  # 0.0 to 1.0
    distinct_vulns_count: int
    top_vulnerability: Optional[str] = None
    started_at: Optional[str] = None

    def __str__(self) -> str:
        return (
            f"Red Team: {self.name} ({self.run_id})\n"
            f"Status: {self.status}\n"
            f"Attacks: {self.successful_attacks}/{self.total_attacks} successful\n"
            f"Success Rate: {self.success_rate:.1%}\n"
            f"Vulnerabilities Found: {self.distinct_vulns_count}\n"
            f"Top Vulnerability: {self.top_vulnerability or 'None'}"
        )

    @property
    def attack_success_rate(self) -> float:
        """Alias for success_rate (backward compatibility)."""
        return self.success_rate

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "run_id": self.run_id,
            "project_id": self.project_id,
            "name": self.name,
            "status": self.status,
            "total_attacks": self.total_attacks,
            "successful_attacks": self.successful_attacks,
            "success_rate": self.success_rate,
            "distinct_vulns_count": self.distinct_vulns_count,
            "top_vulnerability": self.top_vulnerability,
            "started_at": self.started_at,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "RedTeamResult":
        """Create from a backend response dict."""
        return cls(
            run_id=data.get("run_id") or data.get("id", ""),
            project_id=data.get("project_id", ""),
            name=data.get("name", ""),
            status=data.get("status", ""),
            total_attacks=data.get("total_attacks", 0),
            successful_attacks=data.get("successful_attacks", 0),
            success_rate=data.get("success_rate", 0.0),
            distinct_vulns_count=data.get("distinct_vulns_count", 0),
            top_vulnerability=data.get("top_vulnerability"),
            started_at=data.get("started_at"),
        )


@dataclass
class SecurityJobStatus:
    """Status of an async security job (audit or redteam)."""

    job_id: str
    job_type: str  # "security" or "redteam"
    status: str  # "queued", "running", "completed", "failed", "cancelled"
    progress_percent: float = 0.0
    current_item: int = 0
    total_items: int = 0
    started_at: Optional[str] = None
    finished_at: Optional[str] = None
    error: Optional[str] = None

    @property
    def is_running(self) -> bool:
        """Check if job is still running."""
        return self.status in ("queued", "running")

    @property
    def is_completed(self) -> bool:
        """Check if job completed successfully."""
        return self.status == "completed"

    @property
    def is_failed(self) -> bool:
        """Check if job failed."""
        return self.status in ("failed", "cancelled")

    def __str__(self) -> str:
        if self.is_running:
            return f"Job {self.job_id}: {self.status} ({self.progress_percent:.1f}% - {self.current_item}/{self.total_items})"
        return f"Job {self.job_id}: {self.status}"

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SecurityJobStatus":
        """Create from a backend response dict."""
        return cls(
            job_id=data.get("job_id", ""),
            job_type=data.get("job_type", "security"),
            status=data.get("status", ""),
            progress_percent=data.get("progress_percent", 0.0),
            current_item=data.get("current_item", 0),
            total_items=data.get("total_items", 0),
            started_at=data.get("started_at"),
            finished_at=data.get("finished_at"),
            error=data.get("error"),
        )


@dataclass
class AsyncJobHandle:
    """Handle returned when backend processes request asynchronously (HTTP 202).

    Use this to poll for job status or connect to WebSocket for real-time updates.

    Attributes:
        job_id: Unique identifier for the job
        job_type: Type of job ("evaluation", "security_audit", "redteam")
        status: Initial status (usually "queued")
        poll_url: URL to poll for job status
        websocket_url: WebSocket URL for real-time progress updates
        total_items: Total number of items to process
        message: Human-readable status message

    Example:
        # Submit large security audit (returns AsyncJobHandle)
        handle = client.audit(large_dataset)

        # Poll for status
        status = client.get_job_status(handle.job_id)
    """

    job_id: str
    job_type: str
    status: str
    poll_url: str
    total_items: int
    websocket_url: Optional[str] = None
    message: Optional[str] = None
    project_id: Optional[str] = None

    def __str__(self) -> str:
        return f"AsyncJob({self.job_type}): {self.job_id} - {self.status} ({self.total_items} items)"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "job_id": self.job_id,
            "job_type": self.job_type,
            "status": self.status,
            "poll_url": self.poll_url,
            "websocket_url": self.websocket_url,
            "total_items": self.total_items,
            "message": self.message,
            "project_id": self.project_id,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AsyncJobHandle":
        """Create from a backend response dict."""
        return cls(
            job_id=data.get("job_id", ""),
            job_type=data.get("job_type", ""),
            status=data.get("status", "queued"),
            poll_url=data.get("poll_url", ""),
            total_items=data.get("total_items", 0),
            websocket_url=data.get("websocket_url"),
            message=data.get("message"),
            project_id=data.get("project_id"),
        )


@dataclass
class UsageInfo:
    """Usage and quota information."""

    evaluations_used: int
    evaluations_limit: int
    evaluations_remaining: int
    tier: str
    reset_date: str

    def __str__(self) -> str:
        return (
            f"Usage: {self.evaluations_used}/{self.evaluations_limit}\n"
            f"Remaining: {self.evaluations_remaining}\n"
            f"Tier: {self.tier}\n"
            f"Resets: {self.reset_date}"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "evaluations_used": self.evaluations_used,
            "evaluations_limit": self.evaluations_limit,
            "evaluations_remaining": self.evaluations_remaining,
            "tier": self.tier,
            "reset_date": self.reset_date,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "UsageInfo":
        """Create from a backend response dict."""
        return cls(
            evaluations_used=data.get("evaluations_used", data.get("total_api_usage", 0)),
            evaluations_limit=data.get("evaluations_limit", data.get("api_quota_limit", 0)),
            evaluations_remaining=data.get("evaluations_remaining", data.get("api_quota_remaining", 0)),
            tier=data.get("tier", data.get("plan", "free")),
            reset_date=data.get("reset_date", ""),
        )


@dataclass
class AuthInfo:
    """Authentication validation response."""

    valid: bool
    user_id: Optional[str] = None
    org_id: Optional[str] = None
    org_name: Optional[str] = None
    plan: Optional[str] = None
    tier: Optional[str] = None
    evaluations_remaining: Optional[int] = None

    def __str__(self) -> str:
        return f"AuthInfo(valid={self.valid}, " f"org={self.org_name}, " f"plan={self.plan})"

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AuthInfo":
        """Create from a backend response dict."""
        return cls(
            valid=data.get("valid", False),
            user_id=data.get("user_id"),
            org_id=data.get("org_id"),
            org_name=data.get("org_name"),
            plan=data.get("plan"),
            tier=data.get("tier"),
            evaluations_remaining=data.get("evaluations_remaining"),
        )


@dataclass
class VulnerabilityInfo:
    """Vulnerability category information (S1-S23)."""

    key: str
    display_name: str
    description: Optional[str] = None
    severity: Optional[str] = None

    def __str__(self) -> str:
        return f"{self.key}: {self.display_name}"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "key": self.key,
            "display_name": self.display_name,
            "description": self.description,
            "severity": self.severity,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "VulnerabilityInfo":
        """Create from a backend response dict."""
        return cls(
            key=data.get("key", ""),
            display_name=data.get("display_name", data.get("key", "")),
            description=data.get("description"),
            severity=data.get("severity"),
        )


@dataclass
class AttackVectorInfo:
    """Attack vector/strategy information."""

    key: str
    name: str
    description: Optional[str] = None

    def __str__(self) -> str:
        return f"{self.key}: {self.name}"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "key": self.key,
            "name": self.name,
            "description": self.description,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AttackVectorInfo":
        """Create from a backend response dict."""
        return cls(
            key=data.get("key", data.get("name", "")),
            name=data.get("name", data.get("key", "")),
            description=data.get("description"),
        )


# =========================================================================
# Read-back / Dashboard-parity models
# =========================================================================


@dataclass
class AuditBatch:
    """Summary of a security audit batch (list/detail view)."""

    id: str
    project_id: str
    batch_name: Optional[str] = None
    status: str = "completed"
    total_items: int = 0
    unsafe_items: int = 0
    unsafe_rate: float = 0.0
    top_risk_category: Optional[str] = None
    created_at: Optional[str] = None

    @property
    def safety_score(self) -> float:
        return 1.0 - self.unsafe_rate

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "project_id": self.project_id,
            "batch_name": self.batch_name,
            "status": self.status,
            "total_items": self.total_items,
            "unsafe_items": self.unsafe_items,
            "unsafe_rate": self.unsafe_rate,
            "top_risk_category": self.top_risk_category,
            "created_at": self.created_at,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AuditBatch":
        """Create from a backend response dict."""
        return cls(
            id=data.get("id") or data.get("batch_id", ""),
            project_id=data.get("project_id", ""),
            batch_name=data.get("batch_name"),
            status=data.get("status", "completed"),
            total_items=data.get("total_items", 0),
            unsafe_items=data.get("unsafe_items", 0),
            unsafe_rate=data.get("unsafe_rate", 0.0),
            top_risk_category=data.get("top_risk_category"),
            created_at=data.get("created_at"),
        )


@dataclass
class AuditBatchItem:
    """Single evaluated item inside an audit batch."""

    id: str
    batch_id: str
    user_input: str = ""
    assistant_response: str = ""
    is_safe: bool = True
    triggered_categories: List[str] = field(default_factory=list)
    risk_score: float = 0.0
    explanation: Optional[str] = None
    input_safety_categories: List[str] = field(default_factory=list)
    output_safety_categories: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "batch_id": self.batch_id,
            "user_input": self.user_input,
            "assistant_response": self.assistant_response,
            "is_safe": self.is_safe,
            "triggered_categories": self.triggered_categories,
            "risk_score": self.risk_score,
            "explanation": self.explanation,
            "input_safety_categories": self.input_safety_categories,
            "output_safety_categories": self.output_safety_categories,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AuditBatchItem":
        """Create from a backend response dict."""
        return cls(
            id=data.get("id") or data.get("item_id", ""),
            batch_id=data.get("batch_id", ""),
            user_input=data.get("user_input", ""),
            assistant_response=data.get("assistant_response", ""),
            is_safe=data.get("is_safe", True),
            triggered_categories=data.get("triggered_categories", []),
            risk_score=data.get("risk_score", 0.0),
            explanation=data.get("explanation"),
            input_safety_categories=data.get("input_safety_categories", []),
            output_safety_categories=data.get("output_safety_categories", []),
        )


@dataclass
class RedTeamRun:
    """Summary of a red-team simulation run (list/detail view)."""

    id: str
    project_id: str
    name: str
    status: str
    total_attacks: int = 0
    successful_attacks: int = 0
    success_rate: float = 0.0
    distinct_vulns_count: int = 0
    top_vulnerability: Optional[str] = None
    started_at: Optional[str] = None
    finished_at: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "project_id": self.project_id,
            "name": self.name,
            "status": self.status,
            "total_attacks": self.total_attacks,
            "successful_attacks": self.successful_attacks,
            "success_rate": self.success_rate,
            "distinct_vulns_count": self.distinct_vulns_count,
            "top_vulnerability": self.top_vulnerability,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "RedTeamRun":
        """Create from a backend response dict."""
        return cls(
            id=data.get("id") or data.get("run_id", ""),
            project_id=data.get("project_id", ""),
            name=data.get("name", ""),
            status=data.get("status", ""),
            total_attacks=data.get("total_attacks", 0),
            successful_attacks=data.get("successful_attacks", 0),
            success_rate=data.get("success_rate", 0.0),
            distinct_vulns_count=data.get("distinct_vulns_count", 0),
            top_vulnerability=data.get("top_vulnerability"),
            started_at=data.get("started_at"),
            finished_at=data.get("finished_at"),
        )


@dataclass
class RedTeamAttack:
    """Single attack from a red-team run."""

    id: str
    run_id: str
    attack_vector: str = ""
    prompt: str = ""
    response: str = ""
    succeeded: bool = False
    vulnerability: Optional[str] = None
    severity: Optional[str] = None
    explanation: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "run_id": self.run_id,
            "attack_vector": self.attack_vector,
            "prompt": self.prompt,
            "response": self.response,
            "succeeded": self.succeeded,
            "vulnerability": self.vulnerability,
            "severity": self.severity,
            "explanation": self.explanation,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "RedTeamAttack":
        """Create from a backend response dict."""
        return cls(
            id=data.get("id") or data.get("attack_id", ""),
            run_id=data.get("run_id", ""),
            attack_vector=data.get("attack_vector", data.get("attack_vector_name", "")),
            prompt=data.get("prompt", data.get("full_input", "")),
            response=data.get("response", data.get("full_response", "")),
            succeeded=data.get("succeeded", data.get("status") == "succeeded"),
            vulnerability=data.get("vulnerability", data.get("vulnerability_name")),
            severity=data.get("severity"),
            explanation=data.get("explanation"),
        )


@dataclass
class ProjectVulnerability:
    """Vulnerability config for a specific project (enabled/threshold)."""

    id: str
    project_id: str
    key: str
    display_name: str
    enabled: bool = True
    threshold: float = 0.5
    severity: Optional[str] = None
    description: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "project_id": self.project_id,
            "key": self.key,
            "display_name": self.display_name,
            "enabled": self.enabled,
            "threshold": self.threshold,
            "severity": self.severity,
            "description": self.description,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ProjectVulnerability":
        """Create from a backend response dict."""
        return cls(
            id=data.get("id", ""),
            project_id=data.get("project_id", ""),
            key=data.get("key", ""),
            display_name=data.get("display_name", data.get("key", "")),
            enabled=data.get("enabled", True),
            threshold=data.get("threshold", 0.5),
            severity=data.get("severity"),
            description=data.get("description"),
        )


@dataclass
class ProjectAttackVector:
    """Attack vector config for a specific project (enabled/weight)."""

    id: str
    project_id: str
    key: str
    name: str
    enabled: bool = True
    weight: float = 1.0
    description: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "project_id": self.project_id,
            "key": self.key,
            "name": self.name,
            "enabled": self.enabled,
            "weight": self.weight,
            "description": self.description,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ProjectAttackVector":
        """Create from a backend response dict."""
        return cls(
            id=data.get("id", ""),
            project_id=data.get("project_id", ""),
            key=data.get("key", data.get("name", "")),
            name=data.get("name", data.get("key", "")),
            enabled=data.get("enabled", True),
            weight=data.get("weight", 1.0),
            description=data.get("description"),
        )


@dataclass
class CancelResponse:
    """Response from a job cancellation request."""

    status: str
    message: str = ""
    job_id: Optional[str] = None

    def __str__(self) -> str:
        return f"Cancel: {self.status} - {self.message}"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "status": self.status,
            "message": self.message,
            "job_id": self.job_id,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CancelResponse":
        """Create from a backend response dict."""
        return cls(
            status=data.get("status", ""),
            message=data.get("message", ""),
            job_id=data.get("job_id"),
        )


# =========================================================================
# Paginated Response Wrappers
# =========================================================================


@dataclass
class AuditBatchItemsPage:
    """Paginated list of audit items within a batch.

    Wraps the raw dict returned by ``get_batch_items()`` into typed objects.
    """

    items: List[AuditBatchItem]
    total: int
    page: int
    page_size: int

    def __str__(self) -> str:
        return f"AuditBatchItemsPage(page={self.page}, showing={len(self.items)}, total={self.total})"

    def __len__(self) -> int:
        return len(self.items)

    def __iter__(self):
        return iter(self.items)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "items": [item.to_dict() for item in self.items],
            "total": self.total,
            "page": self.page,
            "page_size": self.page_size,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AuditBatchItemsPage":
        """Create from a backend response dict."""
        raw_items = data.get("items", [])
        items = [
            AuditBatchItem(
                id=item.get("id", ""),
                batch_id=item.get("batch_id", ""),
                user_input=item.get("user_input", ""),
                assistant_response=item.get("assistant_response", ""),
                is_safe=item.get("is_safe", True),
                triggered_categories=item.get("triggered_categories", []),
                risk_score=item.get("risk_score", 0.0),
                explanation=item.get("explanation"),
                input_safety_categories=item.get("input_safety_categories", []),
                output_safety_categories=item.get("output_safety_categories", []),
            )
            for item in raw_items
        ]
        return cls(
            items=items,
            total=data.get("total", len(items)),
            page=data.get("page", 1),
            page_size=data.get("page_size", 20),
        )


@dataclass
class RedTeamAttacksPage:
    """Paginated list of attacks within a red-team run.

    Wraps the raw dict returned by ``get_redteam_attacks()`` into typed objects.
    """

    attacks: List[RedTeamAttack]
    total: int
    page: int
    page_size: int

    def __str__(self) -> str:
        return f"RedTeamAttacksPage(page={self.page}, showing={len(self.attacks)}, total={self.total})"

    def __len__(self) -> int:
        return len(self.attacks)

    def __iter__(self):
        return iter(self.attacks)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "attacks": [a.to_dict() for a in self.attacks],
            "total": self.total,
            "page": self.page,
            "page_size": self.page_size,
        }

    @classmethod
    def from_dict(cls, data) -> "RedTeamAttacksPage":
        """Create from a backend response dict or list.
        
        The backend returns a plain list of attack objects, but this method
        also handles the wrapped format {"attacks": [...], "total": ...}.
        """
        # Handle both list (backend returns List[...]) and dict formats
        if isinstance(data, list):
            raw_attacks = data
            total = len(data)
            page = 1
            page_size = len(data)
        else:
            raw_attacks = data.get("attacks", [])
            total = data.get("total", len(raw_attacks))
            page = data.get("page", 1)
            page_size = data.get("page_size", 20)
        attacks = [
            RedTeamAttack(
                id=a.get("id", ""),
                run_id=a.get("run_id", ""),
                attack_vector=a.get("attack_vector", a.get("attack_vector_name", "")),
                prompt=a.get("prompt", a.get("full_input", "")),
                response=a.get("response", a.get("full_response", "")),
                succeeded=a.get("succeeded", a.get("status") == "succeeded"),
                vulnerability=a.get("vulnerability", a.get("vulnerability_name")),
                severity=a.get("severity"),
                explanation=a.get("explanation"),
            )
            for a in raw_attacks
        ]
        return cls(
            attacks=attacks,
            total=total,
            page=page,
            page_size=page_size,
        )


@dataclass
class RedTeamComparison:
    """Side-by-side comparison of 2-5 red-team runs.

    Wraps the raw dict returned by ``compare_redteam_runs()``.
    """

    runs: List[Dict[str, Any]]
    vectors: List[Dict[str, Any]]
    overall_success_rates: Dict[str, float]
    baseline_run_id: Optional[str] = None

    def __str__(self) -> str:
        return f"RedTeamComparison({len(self.runs)} runs, {len(self.vectors)} vectors)"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "runs": self.runs,
            "vectors": self.vectors,
            "overall_success_rates": self.overall_success_rates,
            "baseline_run_id": self.baseline_run_id,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "RedTeamComparison":
        """Create from a backend response dict."""
        return cls(
            runs=data.get("runs", []),
            vectors=data.get("vectors", []),
            overall_success_rates=data.get("overall_success_rates", {}),
            baseline_run_id=data.get("baseline_run_id"),
        )
