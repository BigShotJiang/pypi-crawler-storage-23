"""
Valiqor Auto - Zero-Config Auto-Instrumentation

Import this module to automatically configure Valiqor and enable
auto-instrumentation for all supported LLM providers.

Usage:
    import valiqor.auto  # That's it!

    # Now all OpenAI, Anthropic, LangChain calls are traced
    import openai
    client = openai.OpenAI()
    response = client.chat.completions.create(...)  # Auto-traced!

Configuration:
    Set these environment variables or create .valiqorrc:
    - VALIQOR_API_KEY: Your API key
    - VALIQOR_PROJECT_NAME: Project name
    - VALIQOR_INTELLIGENCE: Enable cloud upload (default: true)
    - VALIQOR_QUIET: Suppress startup messages (default: false)
"""

import os

from valiqor.common import get_config


def _auto_init():
    """Initialize Valiqor with auto-instrumentation on import."""

    # Skip if explicitly disabled
    if os.environ.get("VALIQOR_DISABLE", "").lower() in ("true", "1", "yes"):
        return

    # Load config
    config = get_config()
    quiet = config.get("tracer", {}).get("quiet", False)

    # Print startup message unless quiet
    if not quiet:
        project = config.get("project_name", "default")
        intelligence = config.get("tracer", {}).get("intelligence", True)
        api_key = config.get("api_key", "")

        status = []
        if api_key:
            status.append("cloud sync enabled")
        else:
            status.append("local mode (no API key)")

        if intelligence:
            status.append("intelligence on")

        print(f"🔍 Valiqor initialized: project={project}, {', '.join(status)}")

    # Try to enable auto-instrumentation
    try:
        from valiqor.trace import autolog

        providers = config.get("tracer", {}).get("auto_instrument", [])
        autolog(providers=providers if providers else None)

        if not quiet:
            print("✓ Auto-instrumentation enabled for LLM providers")

    except ImportError:
        if not quiet:
            print("⚠ Trace module not installed. " "Install with: pip install valiqor")
    except Exception as e:
        if not quiet:
            print(f"⚠ Auto-instrumentation failed: {e}")


# Run auto-init on import
_auto_init()
