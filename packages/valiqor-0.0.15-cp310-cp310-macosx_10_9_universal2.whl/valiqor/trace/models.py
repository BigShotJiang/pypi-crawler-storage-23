"""
Valiqor Trace Models - Data Classes for Trace Query Results

Typed return types for :class:`TraceQueryClient` methods.
Mirrors the backend Pydantic schemas in ``tracing/schemas.py``
(TraceListItem, TraceSummaryResponse, TraceMessagesResponse, etc.)
while following the SDK dataclass pattern established in
``eval/models.py`` and ``security/models.py``.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


# =========================================================================
# Single Trace Record (list-view item)
# =========================================================================


@dataclass
class TraceRecord:
    """
    Single trace item returned in list views.

    Maps to the backend ``TraceListItem`` Pydantic model.
    """

    trace_id: str
    project_id: str
    status: str
    session_id: Optional[str] = None
    project_name: Optional[str] = None
    app_name: Optional[str] = None
    duration_ms: Optional[float] = None
    total_cost: Optional[float] = None
    total_tokens: Optional[int] = None
    llm_calls: Optional[int] = None
    tool_calls: Optional[int] = None
    input_preview: Optional[str] = None
    output_preview: Optional[str] = None
    eval_available: bool = False
    created_at: Optional[str] = None

    def __str__(self) -> str:
        dur = f"{self.duration_ms:.0f}ms" if self.duration_ms else "?"
        return f"Trace {self.trace_id[:12]}.. ({self.status}, {dur})"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "trace_id": self.trace_id,
            "project_id": self.project_id,
            "status": self.status,
            "session_id": self.session_id,
            "project_name": self.project_name,
            "app_name": self.app_name,
            "duration_ms": self.duration_ms,
            "total_cost": self.total_cost,
            "total_tokens": self.total_tokens,
            "llm_calls": self.llm_calls,
            "tool_calls": self.tool_calls,
            "input_preview": self.input_preview,
            "output_preview": self.output_preview,
            "eval_available": self.eval_available,
            "created_at": self.created_at,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TraceRecord":
        """Create from a backend response dict."""
        return cls(
            trace_id=data.get("trace_id", ""),
            project_id=data.get("project_id", ""),
            status=data.get("status", ""),
            session_id=data.get("session_id"),
            project_name=data.get("project_name"),
            app_name=data.get("app_name"),
            duration_ms=data.get("duration_ms"),
            total_cost=data.get("total_cost"),
            total_tokens=data.get("total_tokens"),
            llm_calls=data.get("llm_calls"),
            tool_calls=data.get("tool_calls"),
            input_preview=data.get("input_preview"),
            output_preview=data.get("output_preview"),
            eval_available=data.get("eval_available", False),
            created_at=data.get("created_at"),
        )


# =========================================================================
# Paginated list response
# =========================================================================


@dataclass
class TraceListResponse:
    """
    Paginated list of traces.

    Maps to the backend ``TracesListResponse`` Pydantic model.
    """

    traces: List[TraceRecord]
    total: int
    page: int
    page_size: int

    def __str__(self) -> str:
        return f"TraceList(page={self.page}, showing={len(self.traces)}, total={self.total})"

    def __len__(self) -> int:
        return len(self.traces)

    def __iter__(self):
        return iter(self.traces)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "traces": [t.to_dict() for t in self.traces],
            "total": self.total,
            "page": self.page,
            "page_size": self.page_size,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TraceListResponse":
        """Create from a backend response dict."""
        raw_traces = data.get("traces", [])
        return cls(
            traces=[TraceRecord.from_dict(t) for t in raw_traces],
            total=data.get("total", len(raw_traces)),
            page=data.get("page", 1),
            page_size=data.get("page_size", 20),
        )


# =========================================================================
# Single trace overview (metadata)
# =========================================================================


@dataclass
class TraceOverview:
    """
    Overview / metadata for a single trace.

    Maps to the backend ``TraceGetResponse`` Pydantic model.
    """

    trace_id: str
    status: str
    session_id: Optional[str] = None
    duration_ms: Optional[float] = None
    total_cost: Optional[float] = None
    llm_calls: Optional[int] = None
    tool_calls: Optional[int] = None
    created_at: Optional[str] = None

    def __str__(self) -> str:
        dur = f"{self.duration_ms:.0f}ms" if self.duration_ms else "?"
        return f"TraceOverview {self.trace_id[:12]}.. ({self.status}, {dur})"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "trace_id": self.trace_id,
            "status": self.status,
            "session_id": self.session_id,
            "duration_ms": self.duration_ms,
            "total_cost": self.total_cost,
            "llm_calls": self.llm_calls,
            "tool_calls": self.tool_calls,
            "created_at": self.created_at,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TraceOverview":
        """Create from a backend response dict."""
        return cls(
            trace_id=data.get("trace_id", ""),
            status=data.get("status", ""),
            session_id=data.get("session_id"),
            duration_ms=data.get("duration_ms"),
            total_cost=data.get("total_cost"),
            llm_calls=data.get("llm_calls"),
            tool_calls=data.get("tool_calls"),
            created_at=data.get("created_at"),
        )


# =========================================================================
# Rich trace summary
# =========================================================================


@dataclass
class TraceSummary:
    """
    Condensed summary of a trace including metrics, metadata, and diagnostics.

    Maps to the backend ``TraceSummaryResponse`` Pydantic model.
    Kept flat (not nested) to match the eval/security SDK pattern.
    """

    trace_id: str
    project_id: str
    status: str
    session_id: Optional[str] = None
    project_name: Optional[str] = None
    app_name: Optional[str] = None
    app_version: Optional[str] = None
    environment: Optional[str] = None
    created_at: Optional[str] = None
    started_at: Optional[str] = None
    ended_at: Optional[str] = None
    duration_ms: Optional[float] = None
    total_cost: Optional[float] = None
    total_tokens: Optional[int] = None
    input_tokens: Optional[int] = None
    output_tokens: Optional[int] = None
    llm_calls: Optional[int] = None
    tool_calls: Optional[int] = None
    retrieval_calls: Optional[int] = None
    tags: Optional[List[str]] = None
    custom_fields: Optional[Dict[str, Any]] = None
    summary: Optional[Dict[str, Any]] = None
    diagnostics: Optional[Dict[str, Any]] = None
    message_count: int = 0
    span_count: int = 0

    def __str__(self) -> str:
        dur = f"{self.duration_ms:.0f}ms" if self.duration_ms else "?"
        tokens = self.total_tokens or 0
        return (
            f"TraceSummary {self.trace_id[:12]}.. ({self.status}, "
            f"{dur}, {tokens} tokens, "
            f"{self.message_count} msgs, {self.span_count} spans)"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "trace_id": self.trace_id,
            "project_id": self.project_id,
            "status": self.status,
            "session_id": self.session_id,
            "project_name": self.project_name,
            "app_name": self.app_name,
            "app_version": self.app_version,
            "environment": self.environment,
            "created_at": self.created_at,
            "started_at": self.started_at,
            "ended_at": self.ended_at,
            "duration_ms": self.duration_ms,
            "total_cost": self.total_cost,
            "total_tokens": self.total_tokens,
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "llm_calls": self.llm_calls,
            "tool_calls": self.tool_calls,
            "retrieval_calls": self.retrieval_calls,
            "tags": self.tags,
            "custom_fields": self.custom_fields,
            "summary": self.summary,
            "diagnostics": self.diagnostics,
            "message_count": self.message_count,
            "span_count": self.span_count,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TraceSummary":
        """Create from a backend response dict."""
        return cls(
            trace_id=data.get("trace_id", ""),
            project_id=data.get("project_id", ""),
            status=data.get("status", ""),
            session_id=data.get("session_id"),
            project_name=data.get("project_name"),
            app_name=data.get("app_name"),
            app_version=data.get("app_version"),
            environment=data.get("environment"),
            created_at=data.get("created_at"),
            started_at=data.get("started_at"),
            ended_at=data.get("ended_at"),
            duration_ms=data.get("duration_ms"),
            total_cost=data.get("total_cost"),
            total_tokens=data.get("total_tokens"),
            input_tokens=data.get("input_tokens"),
            output_tokens=data.get("output_tokens"),
            llm_calls=data.get("llm_calls"),
            tool_calls=data.get("tool_calls"),
            retrieval_calls=data.get("retrieval_calls"),
            tags=data.get("tags"),
            custom_fields=data.get("custom_fields"),
            summary=data.get("summary"),
            diagnostics=data.get("diagnostics"),
            message_count=data.get("message_count", 0),
            span_count=data.get("span_count", 0),
        )


# =========================================================================
# Message (single conversation turn)
# =========================================================================


@dataclass
class TraceMessage:
    """
    Single message (user ↔ assistant turn) from a trace.

    The backend returns messages as plain dicts; this dataclass
    provides typed access to the common fields while preserving
    any extra keys in ``extra``.
    """

    role: str
    content: str = ""
    timestamp: Optional[str] = None
    tool_calls: Optional[List[Dict[str, Any]]] = None
    tool_call_id: Optional[str] = None
    name: Optional[str] = None
    extra: Dict[str, Any] = field(default_factory=dict)

    def __str__(self) -> str:
        preview = self.content[:60] + "..." if len(self.content) > 60 else self.content
        return f"[{self.role}] {preview}"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        d: Dict[str, Any] = {
            "role": self.role,
            "content": self.content,
        }
        if self.timestamp:
            d["timestamp"] = self.timestamp
        if self.tool_calls:
            d["tool_calls"] = self.tool_calls
        if self.tool_call_id:
            d["tool_call_id"] = self.tool_call_id
        if self.name:
            d["name"] = self.name
        if self.extra:
            d.update(self.extra)
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TraceMessage":
        """Create from a backend message dict."""
        known_keys = {"role", "content", "timestamp", "tool_calls", "tool_call_id", "name"}
        extra = {k: v for k, v in data.items() if k not in known_keys}
        return cls(
            role=data.get("role", "unknown"),
            content=data.get("content", ""),
            timestamp=data.get("timestamp"),
            tool_calls=data.get("tool_calls"),
            tool_call_id=data.get("tool_call_id"),
            name=data.get("name"),
            extra=extra,
        )


# =========================================================================
# Span (single execution unit)
# =========================================================================


@dataclass
class TraceSpan:
    """
    Single span from a trace's execution tree.

    Covers both LLM spans and tool/retrieval spans.
    Extra backend fields are preserved in ``attributes``.
    """

    span_id: str
    name: str
    kind: str = ""
    parent_span_id: Optional[str] = None
    start_time: Optional[str] = None
    end_time: Optional[str] = None
    duration_ms: Optional[float] = None
    status: Optional[str] = None
    attributes: Dict[str, Any] = field(default_factory=dict)
    events: List[Dict[str, Any]] = field(default_factory=list)

    def __str__(self) -> str:
        dur = f"{self.duration_ms:.0f}ms" if self.duration_ms else "?"
        return f"Span {self.name} ({self.kind}, {dur})"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "span_id": self.span_id,
            "name": self.name,
            "kind": self.kind,
            "parent_span_id": self.parent_span_id,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "duration_ms": self.duration_ms,
            "status": self.status,
            "attributes": self.attributes,
            "events": self.events,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TraceSpan":
        """Create from a backend span dict."""
        return cls(
            span_id=data.get("span_id", data.get("id", "")),
            name=data.get("name", ""),
            kind=data.get("kind", ""),
            parent_span_id=data.get("parent_span_id"),
            start_time=data.get("start_time"),
            end_time=data.get("end_time"),
            duration_ms=data.get("duration_ms"),
            status=data.get("status"),
            attributes=data.get("attributes", {}),
            events=data.get("events", []),
        )


# =========================================================================
# Full trace result (raw JSON tab)
# =========================================================================


@dataclass
class TraceFullResult:
    """
    Complete trace JSON as stored in the backend.

    Maps to the backend ``TraceFullResponse`` Pydantic model.
    Includes all messages, spans, retrievals, metadata, and execution tree.
    """

    trace_id: str
    metadata: Dict[str, Any] = field(default_factory=dict)
    summary: Dict[str, Any] = field(default_factory=dict)
    messages: List[Dict[str, Any]] = field(default_factory=list)
    spans: Dict[str, Any] = field(default_factory=dict)
    retrievals: List[Dict[str, Any]] = field(default_factory=list)
    diagnostics: Optional[Dict[str, Any]] = None
    execution_tree: Optional[Dict[str, Any]] = None

    def __str__(self) -> str:
        return (
            f"TraceFullResult {self.trace_id[:12]}.. "
            f"({len(self.messages)} msgs, {len(self.spans)} span groups)"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "trace_id": self.trace_id,
            "metadata": self.metadata,
            "summary": self.summary,
            "messages": self.messages,
            "spans": self.spans,
            "retrievals": self.retrievals,
            "diagnostics": self.diagnostics,
            "execution_tree": self.execution_tree,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TraceFullResult":
        """Create from a backend response dict."""
        return cls(
            trace_id=data.get("trace_id", ""),
            metadata=data.get("metadata", {}),
            summary=data.get("summary", {}),
            messages=data.get("messages", []),
            spans=data.get("spans", {}),
            retrievals=data.get("retrievals", []),
            diagnostics=data.get("diagnostics"),
            execution_tree=data.get("execution_tree"),
        )


# =========================================================================
# Eval step (per-metric evaluation against a trace)
# =========================================================================


@dataclass
class TraceEvalStep:
    """
    Single evaluation step run against a trace.

    Contains the metric key, computed score, and optional LLM explanation.
    """

    metric: str
    score: Optional[float] = None
    explanation: Optional[str] = None
    status: str = "completed"
    input_text: Optional[str] = None
    output_text: Optional[str] = None
    context: Optional[str] = None
    expected: Optional[str] = None
    extra: Dict[str, Any] = field(default_factory=dict)

    def __str__(self) -> str:
        score_str = f"{self.score:.3f}" if self.score is not None else "N/A"
        return f"EvalStep({self.metric}: {score_str})"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        d: Dict[str, Any] = {
            "metric": self.metric,
            "score": self.score,
            "explanation": self.explanation,
            "status": self.status,
        }
        if self.input_text:
            d["input_text"] = self.input_text
        if self.output_text:
            d["output_text"] = self.output_text
        if self.context:
            d["context"] = self.context
        if self.expected:
            d["expected"] = self.expected
        if self.extra:
            d.update(self.extra)
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TraceEvalStep":
        """Create from a backend eval-step dict."""
        known_keys = {
            "metric", "score", "explanation", "status",
            "input_text", "output_text", "context", "expected",
        }
        extra = {k: v for k, v in data.items() if k not in known_keys}
        return cls(
            metric=data.get("metric", data.get("metric_key", "")),
            score=data.get("score"),
            explanation=data.get("explanation"),
            status=data.get("status", "completed"),
            input_text=data.get("input_text"),
            output_text=data.get("output_text"),
            context=data.get("context"),
            expected=data.get("expected"),
            extra=extra,
        )
