"""
Input Variable Detector for trace_workflow auto-instrumentation.

This module provides deterministic detection of user input variables
for different LLM libraries, enabling automatic population of the
`input_data={"user_query": variable}` parameter in trace_workflow calls.

Approach: Library-specific kwarg analysis (deterministic) with fallback patterns.
"""

import re
from typing import Any, Dict, List, Optional

# ============================================================================
# LLM Library Input Patterns
# ============================================================================
# Each library has specific kwargs that contain the user input.
# We extract variables from these kwargs deterministically.

LLM_INPUT_PATTERNS = {
    # OpenAI: messages=[{"role": "user", "content": prompt}]
    "openai": {
        "kwargs": ["messages"],  # Primary input kwargs
        "positional": False,  # Input not typically in positional args
        "content_keys": ["content"],  # Keys within messages that hold input
    },
    # Anthropic: messages=[{"role": "user", "content": prompt}]
    "anthropic": {
        "kwargs": ["messages"],
        "positional": False,
        "content_keys": ["content"],
    },
    # LangChain: chain.invoke(query) or llm.invoke([HumanMessage(content=prompt)])
    "langchain": {
        "kwargs": ["input", "messages", "query"],
        "positional": True,  # First positional arg is often the input
        "content_keys": ["content", "input"],
        "invoke_methods": ["invoke", "ainvoke", "run", "arun", "call", "__call__"],
    },
    # LangGraph: graph.invoke({"messages": [HumanMessage(content=prompt)]})
    "langgraph": {
        "kwargs": ["input", "messages"],
        "positional": True,
        "content_keys": ["messages", "content", "input"],
    },
    # Ollama: requests.post(..., json={"prompt": prompt})
    "ollama": {
        "kwargs": ["prompt", "json"],
        "positional": False,
        "content_keys": ["prompt"],
    },
    # Google/Vertex AI: model.generate_content(prompt)
    "google": {
        "kwargs": ["contents", "prompt"],
        "positional": True,
        "content_keys": ["text", "content"],
    },
    "vertexai": {
        "kwargs": ["contents", "prompt"],
        "positional": True,
        "content_keys": ["text", "content"],
    },
    # LlamaIndex: query_engine.query(query)
    "llama_index": {
        "kwargs": ["query", "prompt", "str_or_query_bundle"],
        "positional": True,
        "content_keys": ["query_str"],
    },
    # CrewAI: crew.kickoff(inputs={"topic": topic})
    "crewai": {
        "kwargs": ["inputs"],
        "positional": False,
        "content_keys": ["topic", "query", "input"],
    },
    # AutoGen: user_proxy.initiate_chat(assistant, message=prompt)
    "autogen": {
        "kwargs": ["message", "messages"],
        "positional": False,
        "content_keys": ["content", "message"],
    },
    # Agno: agent.run(prompt)
    "agno": {
        "kwargs": ["message", "prompt"],
        "positional": True,
        "content_keys": ["content"],
    },
    # Generic fallback
    "default": {
        "kwargs": ["messages", "prompt", "input", "query", "content", "text"],
        "positional": True,
        "content_keys": ["content", "prompt", "text", "query", "message"],
    },
}

# Methods that indicate actual invocation (vs instantiation)
INVOCATION_METHODS = {
    "invoke",
    "ainvoke",
    "run",
    "arun",
    "call",
    "execute",
    "generate",
    "chat",
    "complete",
    "create",
    "send",
    "query",
    "ask",
    "kickoff",
    "initiate_chat",
}


def detect_input_variable(
    detection: Dict[str, Any], function_params: Optional[List[str]] = None
) -> Optional[str]:
    """
    Detect the user input variable from an LLM call detection.

    Uses a deterministic approach based on library-specific patterns:
    1. Check specific kwargs based on library (messages, prompt, input, etc.)
    2. Check first positional argument for invoke-style calls
    3. Fall back to function parameter mapping

    Args:
        detection: Detection dictionary from AST scanner containing:
            - library: str (openai, langchain, etc.)
            - callee: str (method/function called)
            - arguments: dict with positional_args, keyword_args, nested_variables
        function_params: Optional list of enclosing function's parameter names

    Returns:
        Variable name that likely contains user input, or None if not found
    """
    library = detection.get("library", "default").lower()
    callee = detection.get("callee", "")
    arguments = detection.get("arguments", {})

    # Get library-specific patterns, fall back to default
    patterns = LLM_INPUT_PATTERNS.get(library, LLM_INPUT_PATTERNS["default"])

    # Extract argument data
    kwargs = arguments.get("keyword_args", {})
    pos_args = arguments.get("positional_args", [])
    nested_vars = arguments.get("nested_variables", {})
    arg_vars = arguments.get("arg_variables", [])

    # Check if this is an invocation (vs instantiation like ChatOpenAI())
    is_invocation = _is_invocation_call(callee)

    # Strategy 1: Check nested variables in specific kwargs
    input_var = _find_in_kwargs_nested(nested_vars, patterns["kwargs"], patterns["content_keys"])
    if input_var:
        return input_var

    # Strategy 2: Check direct variable reference in kwargs
    input_var = _find_in_kwargs_direct(kwargs, arg_vars, patterns["kwargs"])
    if input_var:
        return input_var

    # Strategy 3: Check first positional argument (for invoke-style calls)
    if is_invocation and patterns.get("positional", False) and pos_args:
        input_var = _find_in_positional(pos_args, nested_vars, arg_vars)
        if input_var:
            return input_var

    # Strategy 4: Function parameter mapping (fallback)
    if function_params and arg_vars:
        input_var = _find_matching_param(function_params, arg_vars)
        if input_var:
            return input_var

    return None


def _is_invocation_call(callee: str) -> bool:
    """Check if the callee represents an actual LLM invocation."""
    callee_lower = callee.lower()
    # Extract method name from full path like "client.chat.completions.create"
    method = callee_lower.split(".")[-1] if "." in callee_lower else callee_lower
    return method in INVOCATION_METHODS


def _find_in_kwargs_nested(
    nested_vars: Dict[str, List[str]], target_kwargs: List[str], content_keys: List[str]
) -> Optional[str]:
    """
    Find input variable in nested structures within specific kwargs.

    For patterns like: messages=[{"role": "user", "content": prompt}]
    The nested_vars would be: {"messages": ["prompt"]}

    Filters out common non-input patterns like session state, history, etc.
    """
    # Variables that are typically NOT user input
    NON_INPUT_PATTERNS = {
        "session_state",
        "history",
        "chat_history",
        "messages_history",
        "context",
        "config",
        "settings",
        "options",
        "params",
    }

    for kwarg in target_kwargs:
        if kwarg in nested_vars:
            vars_in_kwarg = nested_vars[kwarg]
            if vars_in_kwarg:
                # Filter out non-input patterns
                for var in vars_in_kwarg:
                    var_lower = var.lower()
                    # Skip if variable looks like session state or history
                    if any(pattern in var_lower for pattern in NON_INPUT_PATTERNS):
                        continue
                    # Skip streamlit session state pattern
                    if var_lower == "st":
                        continue
                    return var
    return None


def _find_in_kwargs_direct(
    kwargs: Dict[str, str], arg_vars: List[str], target_kwargs: List[str]
) -> Optional[str]:
    """
    Find input variable directly referenced in kwargs.

    For patterns like: prompt=user_query or input=query

    Filters out patterns that are clearly NOT user input:
    - session_state.messages (chat history, not current input)
    - history, context patterns
    """
    # Patterns in kwarg VALUE that indicate non-user-input
    NON_INPUT_VALUE_PATTERNS = [
        "session_state.messages",
        "session_state.history",
        "chat_history",
        "message_history",
        "history",
        ".messages",
        ".history",
    ]

    for kwarg in target_kwargs:
        if kwarg in kwargs:
            value = kwargs[kwarg]

            # Skip if value matches non-input patterns
            value_lower = value.lower()
            if any(pattern in value_lower for pattern in NON_INPUT_VALUE_PATTERNS):
                continue

            # Check if value is a variable (not a string literal)
            if value in arg_vars:
                return value
            # Check if value looks like a variable reference (not quoted)
            if not value.startswith(('"', "'", "[", "{")):
                # Could be variable.attribute or just variable
                base_var = value.split(".")[0]
                if base_var in arg_vars:
                    return value  # Return full reference
    return None


def _find_in_positional(
    pos_args: List[str], nested_vars: Dict[str, List[str]], arg_vars: List[str]
) -> Optional[str]:
    """
    Find input variable in positional arguments.

    For patterns like: llm.invoke(query) or graph.run(input_data)
    """
    if not pos_args:
        return None

    first_arg = pos_args[0]

    # Check nested variables in first positional arg
    if "__pos_0" in nested_vars and nested_vars["__pos_0"]:
        return nested_vars["__pos_0"][0]

    # Check if first arg is a direct variable reference
    if first_arg in arg_vars:
        return first_arg

    # Check if first arg is an attribute access (user_input.text)
    if not first_arg.startswith(('"', "'", "[", "{", "<")):
        base_var = first_arg.split(".")[0]
        if base_var in arg_vars:
            return first_arg

    return None


def _find_matching_param(function_params: List[str], arg_vars: List[str]) -> Optional[str]:
    """
    Find a function parameter that appears in LLM call arguments.

    For cases like:
    def handle_query(user_input: str):
        response = llm.invoke(user_input)  # user_input came from function param
    """
    for param in function_params:
        if param in arg_vars:
            return param
    return None


def get_input_data_code(variable_name: str) -> str:
    """
    Generate the input_data parameter code for trace_workflow.

    Args:
        variable_name: Name of the detected input variable

    Returns:
        Code string like '{"user_query": prompt}'
    """
    return f'{{"user_query": {variable_name}}}'


def format_trace_workflow_call(
    workflow_name: str, input_variable: Optional[str] = None, is_context_manager: bool = True
) -> str:
    """
    Format a complete trace_workflow call with optional input_data.

    Args:
        workflow_name: Name for the workflow
        input_variable: Detected input variable name (optional)
        is_context_manager: Whether to format as context manager or decorator

    Returns:
        Formatted code string
    """
    if input_variable:
        input_data = get_input_data_code(input_variable)
        if is_context_manager:
            return f'with trace_workflow("{workflow_name}", {input_data}):'
        else:
            return f'@trace_workflow("{workflow_name}", {input_data})'
    else:
        if is_context_manager:
            return f'with trace_workflow("{workflow_name}"):'
        else:
            return f'@trace_workflow("{workflow_name}")'
