"""
Valiqor CLI - Command-line interface for Valiqor SDK

Unified CLI for configuration, LLM tracing and AST context scanning.

Command Structure:
    # General Commands
    valiqor config        - Main setup command (API key, project, directories)
    valiqor status        - Show current configuration status
    valiqor test          - Test your Valiqor configuration
    valiqor upload        - Upload trace/scan files (--type trace|scan|all)

    # Trace Commands (valiqor trace | valiqor t)
    valiqor trace init        - Initialize tracing with codebase scan
    valiqor trace apply       - Apply @trace decorators to functions
    valiqor trace uninstrument - Remove auto-applied decorators
    valiqor trace refresh     - Re-scan and regenerate suggestions

    # Scan Commands (valiqor scan | valiqor s)
    valiqor scan run          - Run AST context scan on repository
"""

import argparse
import importlib
import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, Optional

# Import from compiled config module (URLs protected)
_common = importlib.import_module("valiqor.common")


def get_cloud_api_url():
    """Get cloud API URL"""
    return _common.VALIQOR_CLOUD_API


def get_signup_url():
    """Get signup URL"""
    return _common.VALIQOR_SIGNUP_URL


VALIQOR_SIGNUP_URL = _common.VALIQOR_SIGNUP_URL
CONFIG_FILE = _common.CONFIG_FILE
DEFAULT_TRACE_DIR = _common.DEFAULT_TRACE_DIR
DEFAULT_SCAN_DIR = _common.DEFAULT_SCAN_DIR

# Simplified config format (aligned with common/config.py)
DEFAULT_CONFIG = {
    # Core settings (simplified)
    "project_name": "",
    "api_key": "",
    "trace_dir": DEFAULT_TRACE_DIR,
    "scan_dir": DEFAULT_SCAN_DIR,
    "valiqor_intelligence": True,  # Enable cloud upload
    # Optional settings
    "environment": "development",
    "debug": False,
}

# Global credentials file path
GLOBAL_CREDENTIALS_FILE = "credentials.json"
GLOBAL_CONFIG_DIR = ".valiqor"


# =============================================================================
# Feature Availability Checks
# =============================================================================


def check_trace_available() -> bool:
    """Check if trace module is available."""
    try:
        importlib.import_module("valiqor.trace.tracer")
        return True
    except ImportError:
        return False


def check_scanner_available() -> bool:
    """Check if scanner module is available."""
    try:
        importlib.import_module("valiqor.scanner")
        return True
    except ImportError:
        return False


def check_eval_available() -> bool:
    """Check if eval module is available."""
    try:
        importlib.import_module("valiqor.eval")
        return True
    except ImportError:
        return False


def check_security_available() -> bool:
    """Check if security module is available."""
    try:
        importlib.import_module("valiqor.security")
        return True
    except ImportError:
        return False


def check_fa_available() -> bool:
    """Check if failure analysis module is available."""
    try:
        importlib.import_module("valiqor.failure_analysis")
        return True
    except ImportError:
        return False


TRACE_AVAILABLE = check_trace_available()
SCANNER_AVAILABLE = check_scanner_available()
EVAL_AVAILABLE = check_eval_available()
SECURITY_AVAILABLE = check_security_available()
FA_AVAILABLE = check_fa_available()


# =============================================================================
# Configuration Helpers
# =============================================================================


def get_config_path() -> Path:
    """Get the path to the .valiqorrc config file."""
    return Path.cwd() / CONFIG_FILE


def load_config() -> Dict[str, Any]:
    """Load configuration from .valiqorrc file."""
    config_path = get_config_path()
    if config_path.exists():
        try:
            with open(config_path, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError) as e:
            print(f"Warning: Could not read config file: {e}")
    return DEFAULT_CONFIG.copy()


def save_config(config: Dict[str, Any]) -> bool:
    """Save configuration to .valiqorrc file."""
    config_path = get_config_path()
    try:
        with open(config_path, "w") as f:
            json.dump(config, f, indent=2)
        return True
    except IOError as e:
        print(f"Error: Could not save config file: {e}")
        return False


# =============================================================================
# Global Credentials Helpers (Authentication)
# =============================================================================


def get_global_config_dir() -> Path:
    """Get the path to the global Valiqor config directory (~/.valiqor)."""
    return Path.home() / GLOBAL_CONFIG_DIR


def get_global_credentials_path() -> Path:
    """Get the path to the global credentials file (~/.valiqor/credentials.json)."""
    return get_global_config_dir() / GLOBAL_CREDENTIALS_FILE


def load_global_credentials() -> Dict[str, Any]:
    """Load global credentials from ~/.valiqor/credentials.json."""
    creds_path = get_global_credentials_path()
    if creds_path.exists():
        try:
            with open(creds_path, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            pass
    return {}


def save_global_credentials(api_key: str, email: str = None) -> bool:
    """
    Save credentials globally to ~/.valiqor/credentials.json.

    Args:
        api_key: The API key to save
        email: Optional email associated with the account

    Returns:
        True if saved successfully, False otherwise
    """
    config_dir = get_global_config_dir()
    creds_path = get_global_credentials_path()

    try:
        # Create directory if needed
        config_dir.mkdir(parents=True, exist_ok=True)

        # Load existing credentials or create new
        creds = load_global_credentials()

        # Update credentials
        creds["api_key"] = api_key
        if email:
            creds["email"] = email
        creds["updated_at"] = __import__("datetime").datetime.now().isoformat()

        # Save
        with open(creds_path, "w") as f:
            json.dump(creds, f, indent=2)

        return True
    except IOError as e:
        print(f"Warning: Could not save global credentials: {e}")
        return False


def clear_global_credentials() -> bool:
    """Clear global credentials (for logout)."""
    creds_path = get_global_credentials_path()

    try:
        if creds_path.exists():
            creds_path.unlink()
        return True
    except IOError as e:
        print(f"Warning: Could not clear global credentials: {e}")
        return False


def get_api_key() -> tuple:
    """
    Get API key from local config or global credentials.

    Returns:
        Tuple of (api_key, source) where source is 'local', 'global', or None
    """
    # Check local .valiqorrc first
    config = load_config()
    local_key = config.get("api_key")
    if local_key:
        return (local_key, "local")

    # Fall back to global credentials
    creds = load_global_credentials()
    global_key = creds.get("api_key")
    if global_key:
        return (global_key, "global")

    return (None, None)


def ensure_configured(auto_configure: bool = True) -> Dict[str, Any]:
    """
    Ensure configuration exists. If not and auto_configure=True, run configure inline.

    Returns the config dict, or exits if user cancels.
    """
    config_path = get_config_path()

    if config_path.exists():
        return load_config()

    if not auto_configure:
        print("❌ Valiqor not configured. Run 'valiqor config' first.")
        sys.exit(1)

    print("⚠️  No configuration found. Let's set up Valiqor first.")
    print()

    # Run configure inline
    result = _run_configure_prompts(DEFAULT_CONFIG.copy())
    if result is None:
        print("❌ Configuration cancelled.")
        sys.exit(1)

    return result


def _validate_key_with_timeout(api_key: str, timeout: float = 5.0) -> bool:
    """
    Validate an API key with a short timeout.
    Returns True if valid, False otherwise (including network errors).
    """
    try:
        import httpx

        response = httpx.post(
            f"{get_cloud_api_url()}/v2/auth/validate",
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=timeout,
        )

        if response.status_code == 200:
            data = response.json()
            return data.get("valid", False)
        return False
    except Exception:
        return False


def _configure_api_key(config: Dict[str, Any]) -> Dict[str, Any]:
    """
    Smart API key configuration with multiple authentication options.

    Checks for existing credentials and offers appropriate options:
    - Use existing valid key from global credentials
    - Login with browser (device flow)
    - Sign up for new account
    - Enter API key manually
    - Skip (local-only mode)

    Returns updated config dict.
    """
    import webbrowser

    print()
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print("🔑 API Key Configuration")
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print()

    # Check for existing credentials
    global_creds = load_global_credentials()
    global_key = global_creds.get("api_key")
    global_email = global_creds.get("email")
    local_key = config.get("api_key")

    # Determine current key state
    existing_key = local_key or global_key
    key_source = "local" if local_key else ("global" if global_key else None)

    # If we have an existing key, validate it
    if existing_key:
        print("🔍 Found existing API key, validating...")
        is_valid = _validate_key_with_timeout(existing_key, timeout=5.0)

        if is_valid:
            # Key is valid - offer to use it
            key_display = (
                f"{existing_key[:8]}...{existing_key[-4:]}" if len(existing_key) > 12 else "****"
            )
            source_info = f" ({global_email})" if global_email else ""
            print(f"   ✅ Valid key found: {key_display}{source_info}")
            print()

            try:
                use_existing = input(f"   Use this key? [Y/n]: ").strip().lower()
                if use_existing in ["", "y", "yes"]:
                    config["api_key"] = existing_key
                    config["valiqor_intelligence"] = True
                    # Also sync to global if it was only local
                    if key_source == "local" and not global_key:
                        save_global_credentials(existing_key, global_email)
                    print("   ✅ Using existing API key")
                    return config
            except (KeyboardInterrupt, EOFError):
                print()
                return config
        else:
            print("   ⚠️  Existing key is invalid or expired")
            print()

    # No valid key - show authentication options
    print("   How would you like to authenticate?")
    print()
    print("   [1] Login with browser (recommended)")
    print("   [2] Sign up for new account")
    print("   [3] Enter API key manually")
    print("   [4] Skip (local-only mode)")
    print()

    try:
        choice = input("   Enter choice (1-4) [1]: ").strip()
        if choice == "" or choice == "1":
            # Login with browser (inline device flow)
            print()
            result = _configure_login_inline(config)
            return result

        elif choice == "2":
            # Sign up - open browser and wait for key
            print()
            print(f"   Opening signup page: {VALIQOR_SIGNUP_URL}")
            try:
                webbrowser.open(VALIQOR_SIGNUP_URL)
            except Exception:
                print(f"   Please open manually: {VALIQOR_SIGNUP_URL}")
            print()
            print("   After signing up, you can either:")
            print("   - Run 'valiqor login' to authenticate")
            print("   - Or paste your API key below")
            print()
            api_key = input("   API Key (or press Enter to skip): ").strip()
            if api_key:
                return _configure_manual_key(config, api_key)
            else:
                print("   ℹ️  No key entered. Run 'valiqor login' after signing up.")
                config["valiqor_intelligence"] = False
                return config

        elif choice == "3":
            # Manual key entry
            print()
            print(f"   💡 Get your API key from: {VALIQOR_SIGNUP_URL}")
            api_key = input("   API Key: ").strip()
            if api_key:
                return _configure_manual_key(config, api_key)
            else:
                print("   ℹ️  No key entered - traces will be saved locally only")
                config["valiqor_intelligence"] = False
                return config

        elif choice == "4":
            # Skip - local only mode
            print()
            print("   ℹ️  Skipping API key - traces will be saved locally only")
            config["valiqor_intelligence"] = False
            config["api_key"] = ""
            return config

        else:
            print("   Invalid choice, skipping API key configuration")
            return config

    except (KeyboardInterrupt, EOFError):
        print()
        return config


def _configure_login_inline(config: Dict[str, Any]) -> Dict[str, Any]:
    """Run device flow login inline during configure."""
    import time
    import webbrowser

    import httpx

    print("🔐 Starting device authorization flow...")
    print()

    try:
        # Step 1: Start device flow
        response = httpx.post(f"{get_cloud_api_url()}/v2/auth/device/start", timeout=30.0)

        if response.status_code != 200:
            print(f"   ❌ Failed to start device auth: {response.text}")
            print("   You can try 'valiqor login' later.")
            config["valiqor_intelligence"] = False
            return config

        data = response.json()
        device_code = data["device_code"]
        user_code = data["user_code"]
        verification_url = data["verification_url"]
        expires_in = data["expires_in"]
        interval = data.get("interval", 5)

        # Step 2: Show user the code and open browser
        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        print()
        print(f"   Open this URL: {verification_url}")
        print()
        print(f"   Enter code:    {user_code}")
        print()
        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        print()

        # Try to open browser automatically
        try:
            full_url = f"{verification_url}?code={user_code}"
            webbrowser.open(full_url)
            print("   (Browser opened automatically)")
        except Exception:
            print("   (Open the URL manually in your browser)")

        print()
        print(f"⏳ Waiting for authorization (expires in {expires_in // 60} minutes)...")
        print("   Press Ctrl+C to skip")
        print()

        # Step 3: Poll for completion
        start_time = time.time()
        max_time = min(expires_in, 300)  # Cap at 5 minutes for inline

        while time.time() - start_time < max_time:
            try:
                poll_response = httpx.post(
                    f"{get_cloud_api_url()}/v2/auth/device/poll",
                    json={"device_code": device_code},
                    timeout=30.0,
                )

                poll_data = poll_response.json()
                status = poll_data.get("status")

                if status == "approved":
                    print()
                    print("✅ Authorization approved!")

                    # Handle key choice inline
                    return _handle_key_choice_inline(
                        config=config,
                        device_code=device_code,
                        existing_keys=poll_data.get("existing_keys", []),
                        active_key_count=poll_data.get("active_key_count", 0),
                        max_keys=poll_data.get("max_keys", 5),
                        user_email=poll_data.get("user_email"),
                    )

                elif status == "complete":
                    api_key = poll_data.get("api_key")
                    key_name = poll_data.get("key_name")
                    user_email = poll_data.get("user_email")

                    if api_key:
                        config["api_key"] = api_key
                        config["valiqor_intelligence"] = True
                        save_global_credentials(api_key, user_email)
                        print()
                        print("✅ Login successful!")
                        print(f"   Key: {key_name}")
                        return config
                    else:
                        print("   ❌ No key returned")
                        config["valiqor_intelligence"] = False
                        return config

                elif status == "denied":
                    print("   ❌ Authorization denied.")
                    config["valiqor_intelligence"] = False
                    return config

                elif status == "expired":
                    print("   ❌ Authorization expired.")
                    config["valiqor_intelligence"] = False
                    return config

                elif status == "pending":
                    elapsed = int(time.time() - start_time)
                    remaining = max_time - elapsed
                    print(
                        f"\r   Waiting... ({remaining // 60}:{remaining % 60:02d} remaining)",
                        end="",
                        flush=True,
                    )

                time.sleep(interval)

            except KeyboardInterrupt:
                print("\n")
                print("   ⏭️  Skipped login. You can run 'valiqor login' later.")
                config["valiqor_intelligence"] = False
                return config
            except httpx.RequestError:
                time.sleep(interval)

        print("\n   ⏱️  Timed out. You can run 'valiqor login' later.")
        config["valiqor_intelligence"] = False
        return config

    except Exception as e:
        print(f"   ❌ Login error: {e}")
        print("   You can try 'valiqor login' later.")
        config["valiqor_intelligence"] = False
        return config


def _handle_key_choice_inline(
    config: Dict[str, Any],
    device_code: str,
    existing_keys: list,
    active_key_count: int,
    max_keys: int,
    user_email: str,
) -> Dict[str, Any]:
    """Handle key choice inline during configure."""
    import httpx

    # Check if user has room for a new key
    if active_key_count < max_keys:
        # Create a new key automatically
        return _create_key_inline(config, device_code, user_email)

    # User is at max keys - need to choose
    print()
    print(f"⚠️  You have reached the maximum of {max_keys} API keys.")
    print()

    # Show existing keys
    for i, key in enumerate(existing_keys, 1):
        name = key.get("name", "Unnamed")
        prefix = key.get("public_prefix", "???")
        created = key.get("created_at", "")[:10]
        print(f"   {i}. {name}")
        print(f"      Prefix: {prefix}...  (Created: {created})")

    print()
    print("   What would you like to do?")
    print()
    print("   [1] Delete a key and create a new one")
    print("   [2] Use an existing key (paste it)")
    print("   [3] Skip for now")
    print()

    try:
        choice = input("   Enter choice (1-3) [1]: ").strip()

        if choice == "" or choice == "1":
            # Delete and create
            return _delete_and_create_key_inline(config, device_code, existing_keys, user_email)
        elif choice == "2":
            # Use existing key
            print()
            api_key = input("   Paste your existing API key: ").strip()
            if api_key:
                return _configure_manual_key(config, api_key, user_email)
            else:
                print("   ℹ️  No key entered")
                config["valiqor_intelligence"] = False
                return config
        else:
            print("   ℹ️  Skipped. Run 'valiqor login' later.")
            config["valiqor_intelligence"] = False
            return config

    except (KeyboardInterrupt, EOFError):
        print()
        config["valiqor_intelligence"] = False
        return config


def _create_key_inline(config: Dict[str, Any], device_code: str, user_email: str) -> Dict[str, Any]:
    """Create a new API key inline."""
    import socket
    from datetime import datetime

    import httpx

    try:
        hostname = socket.gethostname()[:12]
    except Exception:
        hostname = "cli"

    key_name = f"CLI - {hostname} - {datetime.now().strftime('%Y%m%d-%H%M')}"

    print()
    print(f"🔑 Creating new API key: {key_name}")

    try:
        response = httpx.post(
            f"{get_cloud_api_url()}/v2/auth/device/create-key",
            json={"device_code": device_code, "key_name": key_name},
            timeout=30.0,
        )

        if response.status_code == 200:
            data = response.json()
            api_key = data.get("api_key")

            if api_key:
                config["api_key"] = api_key
                config["valiqor_intelligence"] = True
                save_global_credentials(api_key, user_email)

                print("   ✅ API key created and saved!")
                return config

        print(f"   ❌ Failed to create key: {response.text[:100]}")
        config["valiqor_intelligence"] = False
        return config

    except Exception as e:
        print(f"   ❌ Error creating key: {e}")
        config["valiqor_intelligence"] = False
        return config


def _delete_and_create_key_inline(
    config: Dict[str, Any], device_code: str, existing_keys: list, user_email: str
) -> Dict[str, Any]:
    """Delete an old key and create a new one inline."""
    import httpx

    print()
    print("   Which key would you like to delete?")
    print()

    for i, key in enumerate(existing_keys, 1):
        name = key.get("name", "Unnamed")
        prefix = key.get("public_prefix", "???")
        print(f"   [{i}] {name} ({prefix}...)")

    print()
    print("   [0] Cancel")
    print()

    try:
        choice = input(f"   Enter number (1-{len(existing_keys)}) or 0 to cancel: ").strip()

        if choice == "0" or not choice:
            print("   Cancelled.")
            config["valiqor_intelligence"] = False
            return config

        idx = int(choice) - 1
        if 0 <= idx < len(existing_keys):
            key_to_delete = existing_keys[idx]
            key_id = key_to_delete.get("id")
            key_name = key_to_delete.get("name", "Unnamed")

            print()
            confirm = input(f"   ⚠️  Delete '{key_name}'? Type 'yes' to confirm: ").strip().lower()

            if confirm == "yes":
                print()
                print(f"🗑️  Deleting '{key_name}'...")

                try:
                    response = httpx.post(
                        f"{get_cloud_api_url()}/v2/auth/device/delete-key",
                        json={"device_code": device_code, "key_id": key_id},
                        timeout=30.0,
                    )

                    if response.status_code == 200:
                        print("   ✅ Key deleted!")
                        return _create_key_inline(config, device_code, user_email)
                    else:
                        print(f"   ❌ Failed to delete: {response.text[:100]}")
                        config["valiqor_intelligence"] = False
                        return config

                except Exception as e:
                    print(f"   ❌ Error: {e}")
                    config["valiqor_intelligence"] = False
                    return config
            else:
                print("   Cancelled.")
                config["valiqor_intelligence"] = False
                return config
        else:
            print("   Invalid choice.")
            config["valiqor_intelligence"] = False
            return config

    except (ValueError, KeyboardInterrupt, EOFError):
        print()
        config["valiqor_intelligence"] = False
        return config


def _configure_manual_key(
    config: Dict[str, Any], api_key: str, email: str = None
) -> Dict[str, Any]:
    """Configure a manually entered API key."""
    print()
    print("🔍 Validating key...")

    is_valid = _validate_key_with_timeout(api_key, timeout=5.0)

    if is_valid:
        config["api_key"] = api_key
        config["valiqor_intelligence"] = True
        save_global_credentials(api_key, email)
        print("   ✅ API key validated and saved!")
    else:
        print("   ⚠️  Could not validate key (may be network issue)")
        save_key = input("   Save anyway? [y/N]: ").strip().lower()
        if save_key in ["y", "yes"]:
            config["api_key"] = api_key
            config["valiqor_intelligence"] = True
            save_global_credentials(api_key, email)
            print("   ✅ API key saved")
        else:
            print("   ℹ️  Key not saved")
            config["valiqor_intelligence"] = False

    return config


def _run_configure_prompts(
    config: Dict[str, Any], show_current: bool = False
) -> Optional[Dict[str, Any]]:
    """
    Run interactive configuration prompts.

    Handles project settings only (project_name, directories, environment).
    Authentication is handled separately via 'valiqor login' / 'valiqor signup'.

    Args:
        config: Current config to update
        show_current: Whether to show current values first

    Returns:
        Updated config dict, or None if cancelled
    """
    if show_current:
        print("Current configuration:")
        _display_config_table(config)
        print()

    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print("🔧 Valiqor Project Configuration")
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print()

    # Check auth status and hint if not logged in
    api_key, auth_source = get_api_key()
    if not api_key:
        print("💡 Not logged in yet. Run 'valiqor login' or 'valiqor signup' to authenticate.")
        print()

    try:
        # Project name
        current_project = config.get("project_name") or Path.cwd().name
        project_name = input(f"Project name [{current_project}]: ").strip()
        config["project_name"] = project_name if project_name else current_project

        # Trace directory
        trace_dir = input(
            f"Trace directory [{config.get('trace_dir', DEFAULT_TRACE_DIR)}]: "
        ).strip()
        if trace_dir:
            config["trace_dir"] = trace_dir

        # Scan directory
        scan_dir = input(f"Scan directory [{config.get('scan_dir', DEFAULT_SCAN_DIR)}]: ").strip()
        if scan_dir:
            config["scan_dir"] = scan_dir

        # Environment
        env = config.get("environment", "development")
        environment = input(f"Environment (development/staging/production) [{env}]: ").strip()
        if environment:
            config["environment"] = environment

    except KeyboardInterrupt:
        print()
        return None
    except EOFError:
        print()
        return None

    # Preserve existing auth-related fields from global credentials if present
    if api_key and not config.get("api_key"):
        config["api_key"] = api_key
        config["valiqor_intelligence"] = True

    # Save config
    if not save_config(config):
        print("❌ Failed to save configuration")
        return None

    # Create output directories
    trace_path = Path(config.get("trace_dir", DEFAULT_TRACE_DIR))
    scan_path = Path(config.get("scan_dir", DEFAULT_SCAN_DIR))

    if not trace_path.exists():
        trace_path.mkdir(parents=True, exist_ok=True)
    if not scan_path.exists():
        scan_path.mkdir(parents=True, exist_ok=True)

    print()
    print("✅ Configuration saved!")
    print(f"   📁 {get_config_path()}")

    return config


def _display_config_table(config: Dict[str, Any]) -> None:
    """Display config values in a readable format, masking sensitive values."""
    display_keys = [
        "project_name", "environment", "trace_dir", "scan_dir",
        "valiqor_intelligence", "api_key", "openai_api_key",
    ]
    for key in display_keys:
        value = config.get(key)
        if value is None:
            continue
        if key in ("api_key", "openai_api_key") and value:
            display = f"{value[:8]}...{value[-4:]}" if len(str(value)) > 12 else "****"
            print(f"  {key}: {display}")
        else:
            print(f"  {key}: {value}")


# =============================================================================
# Trace Helper Functions
# =============================================================================


def _run_scanner(repo_path: Path, config: Dict, verbose: bool = False) -> bool:
    """
    Run the scanner to generate feature.json and context.json.

    Returns True if scan was successful.
    """
    if not SCANNER_AVAILABLE:
        if verbose:
            print("   ⚠️  Scanner not available")
        return False

    try:
        from .scanner import ValiqorScanner

        print("📡 Running context scan (for better entry point detection)...")
        print()

        scanner = ValiqorScanner()
        scanner.configure(
            api_key=config.get("api_key"),
            project_name=config.get("project_name") or repo_path.name,
            backend_url=config.get("backend_url"),
            local_output_dir=config.get("scan_dir") or "valiqor_output/scans",
            verbose=verbose,
        )

        # Run scan locally (skip upload for this auto-scan)
        result = scanner.scan(str(repo_path), skip_upload=True)  # Don't upload for auto-scan

        if result.status in ("completed_local", "uploaded"):
            print(f"   ✅ Context scan complete: {result.local_output_dir}")
            print()
            return True
        else:
            if verbose:
                print(f"   ⚠️  Scan returned status: {result.status}")
            return False

    except Exception as e:
        if verbose:
            print(f"   ⚠️  Scanner error: {e}")
        return False


def _scan_codebase(repo_path: Path, verbose: bool = False) -> tuple:
    """
    Scan codebase for LLM usage using lightweight AST scanner.

    Returns:
        Tuple of (analysis, detections) or (None, []) if scanner unavailable
    """
    try:
        from .trace.analyzer import analyze_detections
        from .trace.init_scanner import detect_entry_points, quick_detect

        print("📂 Scanning codebase for LLM usage...")
        print()

        # Run quick detection
        detections = quick_detect(str(repo_path), verbose=verbose)
        entry_points = detect_entry_points(str(repo_path))

        # Analyze results (pass repo_path for call hierarchy analysis)
        analysis = analyze_detections(detections, entry_points, repo_path=str(repo_path))

        return analysis, detections

    except ImportError as e:
        if verbose:
            print(f"   ⚠️  Scanner not available: {e}")
        return None, []


def _print_scan_results(analysis) -> None:
    """Print scan results to CLI with tracing support hints."""
    if not analysis:
        return

    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print("📊 Scan Results")
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print()

    if analysis.total_llm_calls == 0:
        print("   No LLM calls detected in codebase.")
        print("   This is OK if you haven't written LLM code yet!")
        print()
        return

    print(
        f"   Found {analysis.total_llm_calls} LLM call(s) in {analysis.total_files_with_llm} file(s)"
    )
    print()

    # Build tracing support info
    try:
        from .scanner.core import get_pattern_loader

        pattern_loader = get_pattern_loader()
        auto_traced = pattern_loader.get_tracing_supported_providers()
    except ImportError:
        auto_traced = ["openai", "anthropic", "langchain", "ollama", "agno"]

    if analysis.providers:
        # Categorize providers by tracing support
        full_support = []
        manual_only = []

        for provider in analysis.providers:
            provider_lower = provider.lower()
            if provider_lower in [p.lower() for p in auto_traced]:
                full_support.append(provider)
            else:
                manual_only.append(provider)

        print(f"   Detected providers: {', '.join(analysis.providers)}")
        print()

        # Show tracing support status
        if full_support:
            print(f"   ✅ Auto-trace supported: {', '.join(full_support)}")
        if manual_only:
            print(f"   ⚠️  Manual trace only: {', '.join(manual_only)}")
            print(f"      💡 Use @valiqor.trace_function() or valiqor.trace_workflow()")
        print()

    # Show detections by file
    for file_path, detections in analysis.detections_by_file.items():
        llm_detections = [d for d in detections if d.get("call_type") == "llm.call"]
        if not llm_detections:
            continue

        print(f"   📄 {file_path}")
        for det in llm_detections[:3]:  # Show max 3 per file
            line = det.get("line", "?")
            callee = det.get("callee", "unknown")
            library = det.get("library", "")

            # Check if this provider has auto-trace support
            lib_lower = library.lower() if library else ""
            has_auto_trace = lib_lower in [p.lower() for p in auto_traced]

            trace_icon = "✅" if has_auto_trace else "⚠️"
            lib_str = f" [{library}]" if library else ""
            print(f"      {trace_icon} Line {line}: {callee}{lib_str}")
        if len(llm_detections) > 3:
            print(f"      ... and {len(llm_detections) - 3} more")
        print()

    # Show workflow suggestions
    if analysis.workflow_suggestions:
        # Separate entry points from auto-traced functions
        entry_point_suggestions = [s for s in analysis.workflow_suggestions if s.is_entry_point]
        auto_traced_suggestions = [s for s in analysis.workflow_suggestions if not s.is_entry_point]

        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        print("💡 Suggested trace_workflow placements")
        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        print()

        # Show entry points (the ones that need @trace_workflow)
        for i, suggestion in enumerate(entry_point_suggestions[:5], 1):
            print(f"   {i}. {suggestion.file}:{suggestion.line} - {suggestion.function_name}")
            if suggestion.suggestion_type == "decorator":
                print(f'      Add: @valiqor.trace_workflow("{suggestion.workflow_name}")')
            else:
                print(f'      Add: with valiqor.trace_workflow("{suggestion.workflow_name}"):')
            print()

        if len(entry_point_suggestions) > 5:
            print(
                f"   ... and {len(entry_point_suggestions) - 5} more entry points (see valiqor_init.py)"
            )
            print()

        # Show auto-traced functions (no action needed)
        if auto_traced_suggestions:
            print(
                f"   ✅ {len(auto_traced_suggestions)} nested function(s) auto-traced (no action needed)"
            )
            print(f"      See valiqor_init.py for details")
            print()


def _print_quickstart(config: Dict[str, Any], analysis, generated_init: bool = False) -> None:
    """Print quick start guide."""
    print()
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print("🎯 Quick Start (choose one)")
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print()

    print("Option 1 - Zero config (add to top of your entry file):")
    print("  import valiqor.auto")
    print()

    if generated_init:
        print("Option 2 - With workflow suggestions (generated file):")
        print("  import valiqor_init")
        print()

    print("Option 3 - Manual setup:")
    # Get providers from analysis
    providers = ["openai", "langchain", "anthropic"]
    if analysis and analysis.providers:
        providers = analysis.providers
    print("  import valiqor")
    print("  valiqor.configure()")
    print(f"  valiqor.autolog({providers})")
    print()

    print("💡 Run your app normally - LLM calls will be traced automatically!")
    print()

    if config.get("api_key"):
        print(f"🔍 View your traces at: {VALIQOR_SIGNUP_URL}")
    else:
        print(f"💡 Get cloud analytics: {VALIQOR_SIGNUP_URL}")


# =============================================================================
# General Commands
# =============================================================================


def cmd_configure(args: argparse.Namespace) -> int:
    """Configure Valiqor project settings interactively.

    Handles project name, directories, and environment.
    For authentication, use 'valiqor login' or 'valiqor signup'.
    """
    print("⚙️  Valiqor Project Configuration")
    print()

    config = load_config()
    show_current = get_config_path().exists()

    result = _run_configure_prompts(config, show_current=show_current)

    if result is None:
        return 1

    # Check auth and show appropriate next steps
    api_key, _ = get_api_key()
    print()
    print("💡 Next steps:")
    if not api_key:
        print("   • Run 'valiqor login' or 'valiqor signup' to authenticate")
    print("   • Run 'valiqor test' to verify configuration")
    if TRACE_AVAILABLE:
        print("   • Run 'valiqor trace init' to scan codebase and setup tracing")
    if SCANNER_AVAILABLE:
        print("   • Run 'valiqor scan run' to run AST context scan")

    return 0


def cmd_config(args: argparse.Namespace) -> int:
    """Config command group dispatcher."""
    config_command = getattr(args, "config_command", None)

    if config_command == "show":
        return cmd_config_show(args)
    elif config_command == "set":
        return cmd_config_set(args)
    else:
        # No subcommand: run interactive configure
        return cmd_configure(args)


def cmd_config_show(args: argparse.Namespace) -> int:
    """Show current configuration values."""
    config_path = get_config_path()

    # JSON-only output: skip human-readable
    if getattr(args, "json_output", False):
        if not config_path.exists():
            print(json.dumps({"error": "No .valiqorrc file found"}, indent=2))
            return 0
        config = load_config()
        safe_config = config.copy()
        for k in ("api_key", "openai_api_key"):
            if safe_config.get(k):
                v = safe_config[k]
                safe_config[k] = f"{v[:8]}...{v[-4:]}" if len(str(v)) > 12 else "****"
        print(json.dumps(safe_config, indent=2))
        return 0

    # Show auth info
    api_key, auth_source = get_api_key()
    global_creds = load_global_credentials()

    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print("🔧 Valiqor Configuration")
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print()

    # Auth
    print("Authentication:")
    if api_key:
        key_display = f"{api_key[:8]}...{api_key[-4:]}" if len(api_key) > 12 else "****"
        source_label = "local (.valiqorrc)" if auth_source == "local" else "global (~/.valiqor/)"
        print(f"  ✅ API key: {key_display} ({source_label})")
        email = global_creds.get("email")
        if email:
            print(f"  📧 Email: {email}")
    else:
        print("  ❌ Not authenticated")
        print("  💡 Run 'valiqor login' to authenticate")
    print()

    # Local config
    if not config_path.exists():
        print("Local config: No .valiqorrc file found")
        print(f"  💡 Run 'valiqor config set project_name=my-project' or 'valiqor config'")
        return 0

    config = load_config()
    print("Project settings:")
    _display_config_table(config)
    print()
    print(f"Config file: {config_path}")

    return 0


def cmd_config_set(args: argparse.Namespace) -> int:
    """Set individual configuration values non-interactively.

    Usage: valiqor config set key=value [key=value ...]

    Allowed keys: project_name, api_key, trace_dir, scan_dir, environment,
                  valiqor_intelligence, debug, openai_api_key
    """
    pairs = getattr(args, "pairs", [])

    if not pairs:
        print("❌ No key=value pairs provided.")
        print()
        print("Usage: valiqor config set key=value [key=value ...]")
        print()
        print("Allowed keys:")
        print("  api_key               Valiqor API key (for headless/VM/CI)")
        print("  project_name          Project name (e.g. my-app)")
        print("  trace_dir             Trace output directory")
        print("  scan_dir              Scan output directory")
        print("  environment           development | staging | production")
        print("  valiqor_intelligence  true | false (enable cloud upload)")
        print("  openai_api_key        Your OpenAI API key (for BYOM)")
        print("  debug                 true | false")
        print()
        print("Examples:")
        print('  valiqor config set api_key=vq_xxxxxxxxxx')
        print('  valiqor config set project_name=my-app environment=production')
        print('  valiqor config set valiqor_intelligence=false')
        return 1

    ALLOWED_KEYS = {
        "project_name", "trace_dir", "scan_dir", "environment",
        "valiqor_intelligence", "debug", "openai_api_key", "api_key",
    }
    BOOLEAN_KEYS = {"valiqor_intelligence", "debug"}

    config = load_config()
    changes = []

    for pair in pairs:
        if "=" not in pair:
            print(f"❌ Invalid format: '{pair}' — expected key=value")
            return 1

        key, value = pair.split("=", 1)
        key = key.strip()
        value = value.strip()

        if key not in ALLOWED_KEYS:
            print(f"❌ Unknown config key: '{key}'")
            print(f"   Allowed keys: {', '.join(sorted(ALLOWED_KEYS))}")
            return 1

        # Parse boolean values
        if key in BOOLEAN_KEYS:
            value = value.lower() in ("true", "1", "yes")

        config[key] = value
        changes.append((key, value))

    if not save_config(config):
        print("❌ Failed to save configuration")
        return 1

    # Create output directories if changed
    for key, value in changes:
        if key == "trace_dir":
            Path(value).mkdir(parents=True, exist_ok=True)
        elif key == "scan_dir":
            Path(value).mkdir(parents=True, exist_ok=True)

    print("✅ Configuration updated:")
    for key, value in changes:
        if key in ("api_key", "openai_api_key") and value:
            display = f"{str(value)[:8]}...{str(value)[-4:]}" if len(str(value)) > 12 else "****"
            print(f"   {key} = {display}")
        else:
            print(f"   {key} = {value}")
    print(f"   📁 {get_config_path()}")

    return 0


def cmd_test(args: argparse.Namespace) -> int:
    """Test the Valiqor configuration."""
    print("🧪 Testing Valiqor configuration...")
    print()

    config = load_config()
    errors = []
    warnings = []

    # Check trace directory
    trace_path = Path(config.get("trace_dir", DEFAULT_TRACE_DIR))
    if not trace_path.exists():
        warnings.append(f"Trace directory does not exist: {trace_path}")
    elif not os.access(trace_path, os.W_OK):
        errors.append(f"Trace directory is not writable: {trace_path}")
    else:
        print(f"✅ Trace directory OK: {trace_path}")

    # Check scan directory
    scan_path = Path(config.get("scan_dir", DEFAULT_SCAN_DIR))
    if not scan_path.exists():
        warnings.append(f"Scan directory does not exist: {scan_path}")
    elif not os.access(scan_path, os.W_OK):
        errors.append(f"Scan directory is not writable: {scan_path}")
    else:
        print(f"✅ Scan directory OK: {scan_path}")

    # Check API key — use get_api_key() to check BOTH local and global credentials
    api_key, auth_source = get_api_key()
    valiqor_intelligence = config.get("valiqor_intelligence", True)

    if valiqor_intelligence:
        if api_key:
            source_label = "local .valiqorrc" if auth_source == "local" else "global ~/.valiqor/"
            print(f"✅ Cloud upload enabled (API key from {source_label})")

            # Test API connection
            try:
                import requests

                response = requests.head(get_cloud_api_url(), timeout=5)
                if response.status_code < 500:
                    print(f"✅ API reachable (status: {response.status_code})")
                else:
                    warnings.append(f"API returned error status: {response.status_code}")
            except Exception as e:
                warnings.append(f"Could not reach API: {e}")
        else:
            warnings.append(
                "valiqor_intelligence enabled but no API key — run 'valiqor login' to authenticate"
            )
    else:
        print("ℹ️  Cloud upload disabled (valiqor_intelligence: false)")

    # Check module availability
    print()
    print("Module availability:")
    if TRACE_AVAILABLE:
        print("  ✅ Trace module: available")
    else:
        print("  ⚪ Trace module: not installed (pip install valiqor)")

    if SCANNER_AVAILABLE:
        print("  ✅ Scanner module: available")
    else:
        print("  ⚪ Scanner module: not installed (pip install valiqor)")

    if EVAL_AVAILABLE:
        print("  ✅ Eval module: available")
    else:
        print("  ⚪ Eval module: not installed (pip install valiqor)")

    if SECURITY_AVAILABLE:
        print("  ✅ Security module: available")
    else:
        print("  ⚪ Security module: not installed (pip install valiqor)")

    # Check for common provider packages
    print()
    print("Provider packages:")
    provider_packages = {
        "openai": "openai",
        "anthropic": "anthropic",
        "langchain": "langchain",
        "ollama": "ollama",
        "agno": "agno",
    }

    for provider, package in provider_packages.items():
        try:
            __import__(package)
            print(f"  ✅ {provider}: installed")
        except ImportError:
            print(f"  ⚪ {provider}: not installed")

    # Report results
    print()
    if errors:
        print("❌ Errors:")
        for error in errors:
            print(f"   - {error}")
    if warnings:
        print("⚠️  Warnings:")
        for warning in warnings:
            print(f"   - {warning}")

    if not errors and not warnings:
        print("✅ All tests passed! Valiqor is ready to use.")
        return 0
    elif errors:
        print()
        print("❌ Configuration has errors. Please run 'valiqor config' to fix.")
        return 1
    else:
        print()
        print("⚠️  Configuration has warnings but should work.")
        return 0


def cmd_status(args: argparse.Namespace) -> int:
    """Show current Valiqor configuration status."""
    print("📊 Valiqor Status")
    print("=" * 40)
    print()

    config_path = get_config_path()

    # Check authentication status
    api_key, auth_source = get_api_key()
    global_creds = load_global_credentials()
    global_email = global_creds.get("email")

    print("Authentication:")
    if api_key:
        if auth_source == "global":
            print(f"  ✅ Logged in (global credentials)")
            if global_email:
                print(f"  📧 Email: {global_email}")
            print(f"  📁 {get_global_credentials_path()}")
        else:
            print(f"  ✅ API key configured (local)")
            print(f"  📁 {config_path}")
        print(f"  🔑 Key: {api_key[:10]}...{api_key[-4:]}")
    else:
        print(f"  ❌ Not logged in")
        print(f"  💡 Run 'valiqor login' to authenticate")
    print()

    if not config_path.exists():
        print("Local Configuration:")
        print("  ❌ No .valiqorrc file")
        print("  💡 Run 'valiqor config' to setup project")
        print()
        if not api_key:
            print(f"💡 Get your free API key: {VALIQOR_SIGNUP_URL}")
        return 0 if api_key else 1

    config = load_config()

    print("Local Configuration:")
    print(f"  📁 Config file: {config_path}")
    print(f"  📂 Project: {config.get('project_name', '(unnamed)')}")
    print(f"  🌍 Environment: {config.get('environment', 'development')}")
    print()

    # Check valiqor_intelligence setting
    valiqor_intelligence = config.get("valiqor_intelligence", True)

    print("Cloud Connection:")
    if api_key and valiqor_intelligence:
        print(f"  ✅ Cloud upload: Enabled")
        print(f"  📤 Traces uploaded to: Valiqor Cloud")
        print(f"  🔍 View at: {VALIQOR_SIGNUP_URL}")
    elif valiqor_intelligence and not api_key:
        print(f"  ⚠️  Cloud upload: Enabled but no API key")
        print(f"  💾 Output saved locally")
        print()
        print(f"  💡 Run 'valiqor login' to authenticate")
    else:
        print(f"  ❌ Cloud upload: Disabled (valiqor_intelligence: false)")
        print(f"  💾 Output saved locally")
    print()

    # Show trace statistics
    trace_path = Path(config.get("trace_dir", DEFAULT_TRACE_DIR))
    if trace_path.exists():
        trace_files = list(trace_path.glob("*.json"))
        print(f"Traces: {len(trace_files)} files in {trace_path}")
    else:
        print(f"Traces: No trace directory yet ({trace_path})")

    # Show scan statistics
    scan_path = Path(config.get("scan_dir", DEFAULT_SCAN_DIR))
    if scan_path.exists():
        scan_files = list(scan_path.glob("*.json")) + list(scan_path.glob("*.jsonl"))
        print(f"Scans: {len(scan_files)} files in {scan_path}")
    else:
        print(f"Scans: No scan directory yet ({scan_path})")

    print()
    print("Module availability:")
    print(f"  Trace:    {'✅ available' if TRACE_AVAILABLE else '⚪ not installed'}")
    print(f"  Scanner:  {'✅ available' if SCANNER_AVAILABLE else '⚪ not installed'}")
    print(f"  Eval:     {'✅ available' if EVAL_AVAILABLE else '⚪ not installed'}")
    print(f"  Security: {'✅ available' if SECURITY_AVAILABLE else '⚪ not installed'}")

    print()
    print(f"SDK Version: ", end="")
    try:
        from . import __version__

        print(__version__)
    except ImportError:
        print("Unknown")

    return 0


def cmd_upload(args: argparse.Namespace) -> int:
    """Upload trace and/or scan files to Valiqor Cloud."""
    import requests

    config = load_config()

    # Get API key
    api_key = args.api_key or config.get("api_key") or os.environ.get("VALIQOR_API_KEY")

    # Use Valiqor Cloud by default if API key is provided
    if api_key and not args.endpoint:
        endpoint = get_cloud_api_url()
    else:
        endpoint = args.endpoint or os.environ.get("VALIQOR_BACKEND_URL")

    if not api_key and not endpoint:
        print("❌ No Valiqor API key configured")
        print()
        print(f"   Get your free API key at: {VALIQOR_SIGNUP_URL}")
        print()
        print("   Then either:")
        print("   1. Run 'valiqor config' and enter your API key")
        print("   2. Set VALIQOR_API_KEY environment variable")
        print("   3. Use --api-key flag with this command")
        return 1

    if not endpoint:
        print("❌ No upload endpoint available")
        print("   Provide --endpoint or set VALIQOR_API_KEY")
        return 1

    # Determine what to upload based on --type
    upload_type = args.type or "all"

    # Collect trace files and scan folders to upload
    trace_files = []
    scan_folders = []

    project_name = config.get("project_name") or "default"

    if args.path:
        # Explicit path provided
        path = Path(args.path)
        if path.is_file():
            trace_files.append(path)
        elif path.is_dir():
            # Check if it's a scan folder (has context.json or feature.json)
            if (path / "context.json").exists() or (path / "feature.json").exists():
                scan_folders.append(path)
            else:
                # Treat as trace files directory
                for f in path.glob("*.json"):
                    trace_files.append(f)
                for f in path.glob("*.jsonl"):
                    trace_files.append(f)
        else:
            print(f"❌ Path not found: {path}")
            return 1
    else:
        # Use default directories based on type
        if upload_type in ("trace", "all"):
            trace_dir = Path(config.get("trace_dir", DEFAULT_TRACE_DIR))
            if trace_dir.exists():
                for f in trace_dir.glob("*.json"):
                    trace_files.append(f)

        if upload_type in ("scan", "all"):
            scan_dir = Path(config.get("scan_dir", DEFAULT_SCAN_DIR))
            if scan_dir.exists():
                # Find scan folders (directories containing scan files)
                folders = [d for d in scan_dir.iterdir() if d.is_dir()]
                if folders:
                    # Sort by name (which includes timestamp) to get latest
                    folders.sort(key=lambda x: x.name, reverse=True)
                    # Get the latest scan folder
                    latest_scan = folders[0]
                    scan_folders.append(latest_scan)

    if not trace_files and not scan_folders:
        print(f"❌ No files found to upload (type: {upload_type})")
        if upload_type == "trace":
            print(f"   Trace directory: {config.get('trace_dir', DEFAULT_TRACE_DIR)}")
        elif upload_type == "scan":
            print(f"   Scan directory: {config.get('scan_dir', DEFAULT_SCAN_DIR)}")
        else:
            print(f"   Trace directory: {config.get('trace_dir', DEFAULT_TRACE_DIR)}")
            print(f"   Scan directory: {config.get('scan_dir', DEFAULT_SCAN_DIR)}")
        return 1

    is_valiqor_cloud = endpoint == get_cloud_api_url()
    dest_name = "Valiqor Cloud" if is_valiqor_cloud else endpoint

    print(f"📤 Uploading to {dest_name}")
    if trace_files:
        print(f"   • {len(trace_files)} trace file(s)")
    if scan_folders:
        print(f"   • {len(scan_folders)} scan folder(s)")
        for folder in scan_folders:
            print(f"     └── {folder.name}")
    print()

    # Prepare auth headers (no Content-Type for multipart)
    auth_headers = {}
    if api_key:
        auth_headers["Authorization"] = f"Bearer {api_key}"

    success_count = 0
    error_count = 0

    # Upload trace files (JSON body)
    for file_path in trace_files:
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                if file_path.suffix == ".jsonl":
                    data = [json.loads(line) for line in f if line.strip()]
                else:
                    data = json.load(f)

            if args.dry_run:
                print(f"  [DRY RUN] Would upload: {file_path.name} (trace)")
                success_count += 1
                continue

            upload_endpoint = f"{endpoint}/api/v1/traces/upload"
            upload_data = {"project_name": project_name, "trace": data, "generate_eval_steps": True}

            headers = {"Content-Type": "application/json", **auth_headers}
            response = requests.post(upload_endpoint, json=upload_data, headers=headers, timeout=30)

            if response.status_code in (200, 201):
                print(f"  ✅ {file_path.name} (trace)")
                success_count += 1
                if args.delete_after:
                    file_path.unlink()
                    print(f"     🗑️  Deleted local file")
            else:
                print(f"  ❌ {file_path.name} - HTTP {response.status_code}: {response.text[:100]}")
                error_count += 1

        except json.JSONDecodeError as e:
            print(f"  ❌ {file_path.name} - Invalid JSON: {e}")
            error_count += 1
        except requests.RequestException as e:
            print(f"  ❌ {file_path.name} - Network error: {e}")
            error_count += 1
        except Exception as e:
            print(f"  ❌ {file_path.name} - Error: {e}")
            error_count += 1

    # Upload scan folders (multipart file upload)
    for scan_folder in scan_folders:
        try:
            if args.dry_run:
                files_in_folder = list(scan_folder.glob("*.json")) + list(
                    scan_folder.glob("*.jsonl")
                )
                print(f"  [DRY RUN] Would upload scan folder: {scan_folder.name}")
                for f in files_in_folder:
                    print(f"     └── {f.name}")
                success_count += 1
                continue

            # Collect all files in the scan folder
            files_to_send = []
            file_handles = []

            for file_path in scan_folder.iterdir():
                if file_path.is_file() and file_path.suffix in (".json", ".jsonl", ".txt"):
                    fh = open(file_path, "rb")
                    file_handles.append(fh)
                    # Use 'files' as the field name (matches FastAPI File(...) parameter)
                    files_to_send.append(
                        ("files", (file_path.name, fh, "application/octet-stream"))
                    )

            if not files_to_send:
                print(f"  ⚠️  {scan_folder.name} - No files found in folder")
                continue

            upload_endpoint = f"{endpoint}/api/v1/scans/upload/{project_name}"

            print(f"  📁 Uploading {scan_folder.name} ({len(files_to_send)} files)...")

            response = requests.post(
                upload_endpoint, files=files_to_send, headers=auth_headers, timeout=60
            )

            # Close all file handles
            for fh in file_handles:
                fh.close()

            if response.status_code in (200, 201):
                result = response.json()
                scan_id = result.get("scan_id", "unknown")
                print(f"  ✅ {scan_folder.name} (scan_id: {scan_id})")
                success_count += 1
                if args.delete_after:
                    import shutil

                    shutil.rmtree(scan_folder)
                    print(f"     🗑️  Deleted local folder")
            else:
                print(
                    f"  ❌ {scan_folder.name} - HTTP {response.status_code}: {response.text[:200]}"
                )
                error_count += 1

        except requests.RequestException as e:
            print(f"  ❌ {scan_folder.name} - Network error: {e}")
            error_count += 1
        except Exception as e:
            print(f"  ❌ {scan_folder.name} - Error: {e}")
            error_count += 1

    print()
    print(f"Results: {success_count} succeeded, {error_count} failed")

    if success_count > 0 and is_valiqor_cloud:
        print()
        print(f"🔍 View your data at: {VALIQOR_SIGNUP_URL}")

    return 0 if error_count == 0 else 1


# =============================================================================
# Trace Commands
# =============================================================================


def cmd_trace_init(args: argparse.Namespace) -> int:
    """Initialize tracing with codebase scan and workflow suggestions."""
    if not TRACE_AVAILABLE:
        print("❌ Trace module not available")
        print("   Install with: pip install valiqor")
        return 1

    print("🚀 Initializing Valiqor Tracing...")
    print()

    # Ensure configuration exists (auto-configure if missing)
    config = ensure_configured(auto_configure=not args.defaults)

    # If using defaults and no config existed, set project name
    if args.defaults and not config.get("project_name"):
        config["project_name"] = Path.cwd().name
        save_config(config)

    # Track detected providers (goes into valiqor_init.py)
    detected_providers = []

    verbose = getattr(args, "verbose", False)

    # Phase 0: Always run context scan for fresh feature detection (unless --no-scan)
    if not getattr(args, "no_scan", False):
        _run_scanner(Path.cwd(), config, verbose=verbose)

    # Phase 1: Scan codebase for LLM usage (unless --no-scan)
    analysis = None
    if not getattr(args, "no_scan", False):
        analysis, detections = _scan_codebase(Path.cwd(), verbose=verbose)

        if analysis:
            _print_scan_results(analysis)

            # Store detected providers
            if analysis.providers:
                detected_providers = analysis.providers

    # Phase 2: Generate valiqor_init.py if scan found detections
    generated_init = False
    if analysis and (analysis.providers or analysis.workflow_suggestions):
        try:
            from .common import get_latest_scan_id
            from .trace.codegen import generate_init_file, should_update_gitignore, update_gitignore

            # Get the current scan_id to embed in the generated file
            current_scan_id = get_latest_scan_id(str(Path.cwd()))

            init_content = generate_init_file(analysis, config, scan_id=current_scan_id)
            init_path = Path.cwd() / "valiqor_init.py"

            # Check if file exists
            if init_path.exists() and not args.force:
                overwrite = input("   valiqor_init.py exists. Overwrite? (Y/n): ").strip().lower()
                if overwrite == "n":
                    print("   Skipped valiqor_init.py")
                else:
                    init_path.write_text(init_content, encoding="utf-8")
                    print(f"   📁 valiqor_init.py (updated)")
                    generated_init = True
            else:
                init_path.write_text(init_content, encoding="utf-8")
                print(f"   📁 valiqor_init.py (with workflow suggestions)")
                generated_init = True

        except Exception as e:
            if getattr(args, "verbose", False):
                print(f"   ⚠️  Could not generate valiqor_init.py: {e}")

    # Phase 3: Ensure trace directory exists
    trace_path = Path(config["trace_dir"])
    if not trace_path.exists():
        trace_path.mkdir(parents=True, exist_ok=True)
        print(f"   📁 {trace_path}/ (trace output)")

    # Phase 4: Update .gitignore
    try:
        from .trace.codegen import should_update_gitignore, update_gitignore

        if should_update_gitignore():
            if update_gitignore():
                print(f"   📁 .gitignore (updated)")
    except Exception:
        pass

    # Print quick start guide
    _print_quickstart(config, analysis, generated_init)

    return 0


def cmd_trace_apply(args: argparse.Namespace) -> int:
    """Apply trace_workflow decorators based on scan suggestions."""
    if not TRACE_AVAILABLE:
        print("❌ Trace module not available")
        print("   Install with: pip install valiqor")
        return 1

    from .common import get_latest_scan_id
    from .instrumentor import apply_decorators, print_results
    from .trace.codegen import generate_init_file, get_init_file_scan_id

    config_path = get_config_path()

    if not config_path.exists():
        print("❌ Valiqor not configured. Run 'valiqor config' first.")
        return 1

    config = load_config()
    verbose = getattr(args, "verbose", False)

    print("🔧 Applying trace_workflow decorators...")
    print()

    # Check if valiqor_init.py is stale (scan_id mismatch)
    init_path = Path.cwd() / "valiqor_init.py"
    current_scan_id = get_latest_scan_id(str(Path.cwd()))
    init_scan_id = get_init_file_scan_id(str(init_path)) if init_path.exists() else None

    needs_rescan = False
    if current_scan_id and init_scan_id:
        if current_scan_id != init_scan_id:
            print(f"⚠️  valiqor_init.py is stale (scan_id mismatch)")
            print(f"   Current scan: {current_scan_id}")
            print(f"   Init file: {init_scan_id}")
            print()
            needs_rescan = True
    elif not init_path.exists():
        print("ℹ️  No valiqor_init.py found, running fresh scan...")
        print()
        needs_rescan = True

    # Run fresh scan if needed
    if needs_rescan:
        print("🔄 Running fresh scan...")
        _run_scanner(Path.cwd(), config, verbose=verbose)

    # Scan codebase for LLM usage
    analysis, detections = _scan_codebase(Path.cwd(), verbose=verbose)

    if not analysis or not analysis.workflow_suggestions:
        print("ℹ️  No workflow suggestions found.")
        print("   Run 'valiqor trace init' to scan your codebase first.")
        return 0

    # Regenerate valiqor_init.py if stale
    if needs_rescan and analysis:
        try:
            new_scan_id = get_latest_scan_id(str(Path.cwd()))
            init_content = generate_init_file(analysis, config, scan_id=new_scan_id)
            init_path.write_text(init_content, encoding="utf-8")
            print(f"   ✅ Regenerated valiqor_init.py (scan_id: {new_scan_id})")
            print()
        except Exception as e:
            if verbose:
                print(f"   ⚠️  Could not regenerate valiqor_init.py: {e}")

    # Filter suggestions by category
    all_suggestions = analysis.workflow_suggestions
    recommended_suggestions = [s for s in all_suggestions if s.is_recommended]
    alternative_suggestions = [
        s for s in all_suggestions if s.is_entry_point and not s.is_recommended
    ]
    auto_traced_suggestions = [s for s in all_suggestions if not s.is_entry_point]

    # Determine which suggestions to apply
    apply_all = getattr(args, "all", False)

    if apply_all:
        # Apply to all entry points (recommended + alternatives)
        suggestions_to_apply = recommended_suggestions + alternative_suggestions
    else:
        # Default: Only apply to the RECOMMENDED entry point
        suggestions_to_apply = recommended_suggestions

    # Count module-level vs function-level
    function_suggestions = [s for s in suggestions_to_apply if s.function_name != "<module>"]
    module_suggestions = [s for s in suggestions_to_apply if s.function_name == "<module>"]

    # Show what will be applied
    if apply_all:
        print(f"Applying to ALL {len(suggestions_to_apply)} entry point(s):")
    else:
        print(f"Applying to {len(suggestions_to_apply)} RECOMMENDED entry point(s):")
        if alternative_suggestions:
            print(f"   💡 Use --all to also apply to {len(alternative_suggestions)} alternative(s)")

    if function_suggestions:
        print(f"   • {len(function_suggestions)} function-level (decorator)")
    if module_suggestions:
        print(f"   • {len(module_suggestions)} module-level (context manager)")

    if auto_traced_suggestions:
        print(
            f"\n✅ {len(auto_traced_suggestions)} nested function(s) will be auto-traced (no action needed)"
        )
    print()

    dry_run = getattr(args, "dry_run", False)
    first_only = getattr(args, "first", False)

    if dry_run:
        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        print("🔍 DRY RUN - Showing what would be instrumented")
        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    else:
        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        print("🔧 Applying trace_workflow decorators")
        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")

    # Only apply to selected suggestions (recommended only, or all if --all)
    results = apply_decorators(
        suggestions=suggestions_to_apply, create_backup=True, dry_run=dry_run, first_only=first_only
    )

    print_results(results)

    # Count successful instrumentations
    instrumented_count = sum(len(r.functions_instrumented) for r in results if r.success)
    if instrumented_count > 0 and not dry_run:
        print("💡 To undo: Run 'valiqor trace uninstrument'")

    return 0


def cmd_trace_uninstrument(args: argparse.Namespace) -> int:
    """Remove auto-applied valiqor instrumentation from files."""
    if not TRACE_AVAILABLE:
        print("❌ Trace module not available")
        print("   Install with: pip install valiqor")
        return 1

    from .instrumentor import print_results, remove_instrumentation

    print("🔧 Removing Valiqor instrumentation...")
    print()

    # Collect files to process
    if args.files:
        file_paths = args.files
    else:
        # Find all Python files recursively by default (use --no-recursive to disable)
        recursive = not getattr(args, "no_recursive", False)
        pattern = "**/*.py" if recursive else "*.py"
        file_paths = [
            str(f)
            for f in Path.cwd().glob(pattern)
            if not f.name.startswith(".") and "valiqor_init" not in f.name
        ]

    if not file_paths:
        print("No Python files found to process.")
        return 0

    if getattr(args, "dry_run", False):
        print(f"[DRY RUN] Would check {len(file_paths)} file(s) for instrumentation")
        print()

    results = remove_instrumentation(file_paths, dry_run=getattr(args, "dry_run", False))

    # Print results
    print_results(results, action="uninstrumented")

    # Count successes
    success_count = sum(1 for r in results if r.success and r.functions_instrumented)

    if success_count > 0:
        print("💡 Backup files (.bak) were not created for uninstrument.")
        print("   Use git to restore if needed.")

    return 0


def cmd_trace_refresh(args: argparse.Namespace) -> int:
    """Refresh workflow suggestions by re-scanning codebase."""
    if not TRACE_AVAILABLE:
        print("❌ Trace module not available")
        print("   Install with: pip install valiqor")
        return 1

    print("🔄 Refreshing Valiqor suggestions...")
    print()

    config_path = get_config_path()

    if not config_path.exists():
        print("❌ Valiqor not configured. Run 'valiqor config' first.")
        return 1

    config = load_config()
    verbose = getattr(args, "verbose", False)

    # Always run context scan for fresh feature detection
    _run_scanner(Path.cwd(), config, verbose=verbose)

    # Scan codebase for LLM usage
    analysis, detections = _scan_codebase(Path.cwd(), verbose=verbose)

    if not analysis:
        print("❌ Could not scan codebase (scanner not available)")
        return 1

    _print_scan_results(analysis)

    # Show newly detected providers
    if analysis.providers:
        print(f"   📦 Detected providers: {', '.join(analysis.providers)}")

    # Regenerate valiqor_init.py
    if analysis.providers or analysis.workflow_suggestions:
        try:
            from .common import get_latest_scan_id
            from .trace.codegen import generate_init_file

            # Get the current scan_id to embed in the generated file
            current_scan_id = get_latest_scan_id(str(Path.cwd()))

            init_content = generate_init_file(analysis, config, scan_id=current_scan_id)
            init_path = Path.cwd() / "valiqor_init.py"

            if init_path.exists():
                overwrite = input("   Overwrite existing valiqor_init.py? (Y/n): ").strip().lower()
                if overwrite == "n":
                    print("   Skipped valiqor_init.py")
                    return 0

            init_path.write_text(init_content, encoding="utf-8")
            print("   ✅ Updated valiqor_init.py")

        except Exception as e:
            print(f"   ⚠️  Could not update valiqor_init.py: {e}")

    print()
    print("✅ Refresh complete!")
    return 0


# =============================================================================
# Scan Commands
# =============================================================================


def cmd_scan_run(args: argparse.Namespace) -> int:
    """Run AST context scan on repository."""
    if not SCANNER_AVAILABLE:
        print("❌ Scanner module not available")
        print("   Install with: pip install valiqor")
        return 1

    # Ensure configuration exists
    config = ensure_configured(auto_configure=True)

    # Import and run scanner
    try:
        from .scanner import run_scan

        return run_scan(args, config)
    except ImportError as e:
        print(f"❌ Scanner import error: {e}")
        print("   Install with: pip install valiqor")
        return 1


# =============================================================================
# Authentication Commands (login, signup, keys)
# =============================================================================


def _validate_existing_key(api_key: str) -> bool:
    """
    Validate an existing API key against the backend.

    Returns True if the key is valid and active, False otherwise.
    """
    try:
        import httpx

        response = httpx.post(
            f"{get_cloud_api_url()}/v2/auth/validate",
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=10.0,
        )

        if response.status_code == 200:
            data = response.json()
            return data.get("valid", False)

        return False

    except Exception:
        return False


def _get_user_keys(api_key: str) -> dict:
    """
    Get list of user's API keys from backend.

    Returns dict with keys list, active_count, max_keys, or None on error.
    """
    try:
        import httpx

        response = httpx.get(
            f"{get_cloud_api_url()}/v2/auth/cli/keys",
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=10.0,
        )

        if response.status_code == 200:
            return response.json()

        return None

    except Exception:
        return None


def cmd_login(args: argparse.Namespace) -> int:
    """Login to Valiqor via browser (device flow) or email/password."""
    import time
    import webbrowser

    try:
        import httpx
    except ImportError:
        print("❌ httpx not installed. Run: pip install httpx")
        return 1

    email = getattr(args, "email", None)
    password = getattr(args, "password", None)
    force = getattr(args, "force", False)

    # Check for existing valid key (unless --force)
    if not force:
        # Check both local and global
        api_key, source = get_api_key()

        if api_key:
            print("🔍 Checking existing API key...")
            if _validate_existing_key(api_key):
                print()
                print("✅ Already logged in with a valid API key!")
                if source == "local":
                    print(f"   Source: {get_config_path()} (local)")
                else:
                    print(f"   Source: {get_global_credentials_path()} (global)")
                print()
                print("   Use 'valiqor login --force' to login again anyway.")
                print("   Use 'valiqor keys list' to view your API keys.")
                return 0
            else:
                print("   ⚠️  Existing key is invalid or expired. Proceeding with login...")
                print()

    # Direct email/password login (for CI/CD)
    if email and password:
        return _login_with_credentials(email, password)

    # Device flow (browser-based)
    return _login_device_flow()


def _login_with_credentials(email: str, password: str) -> int:
    """Login with email/password (for CI/CD environments)."""
    import httpx

    print("🔐 Logging in with email/password...")
    print()

    try:
        response = httpx.post(
            f"{get_cloud_api_url()}/v2/auth/cli/login",
            json={"email": email, "password": password},
            timeout=30.0,
        )

        if response.status_code == 501:
            print("❌ Direct login not available on this server.")
            print("   Use 'valiqor login' (browser flow) instead.")
            return 1

        data = response.json()

        if not data.get("success"):
            print(f"❌ Login failed: {data.get('error', 'Unknown error')}")
            return 1

        api_key = data["api_key"]

        # Save globally (primary auth storage)
        save_global_credentials(api_key, email)

        # Also save to local .valiqorrc for backwards compatibility
        config = load_config()
        config["api_key"] = api_key
        config["valiqor_intelligence"] = True
        # Set project_name from current directory if not already set
        if not config.get("project_name"):
            config["project_name"] = Path.cwd().name
        save_config(config)

        print("✅ Login successful!")
        print(f"   Key name: {data.get('key_name', 'CLI Key')}")
        print(f"   Project:  {config['project_name']}")
        print(f"   Global:   {get_global_credentials_path()}")
        print(f"   Local:    {get_config_path()}")
        print()
        print("📧 You have 3 trial runs. Verify your email to unlock 50 free runs:")
        print("   → valiqor verify")
        return 0

    except httpx.RequestError as e:
        print(f"❌ Network error: {e}")
        return 1
    except Exception as e:
        print(f"❌ Login error: {e}")
        return 1


def _login_device_flow() -> int:
    """Login via browser using device flow."""
    import time
    import webbrowser

    import httpx

    print("🔐 Starting device authorization flow...")
    print()

    try:
        # Step 1: Start device flow
        response = httpx.post(f"{get_cloud_api_url()}/v2/auth/device/start", timeout=30.0)

        if response.status_code != 200:
            print(f"❌ Failed to start device auth: {response.text}")
            return 1

        data = response.json()
        device_code = data["device_code"]
        user_code = data["user_code"]
        verification_url = data["verification_url"]
        expires_in = data["expires_in"]
        interval = data.get("interval", 5)

        # Step 2: Show user the code and open browser
        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        print()
        print(f"   Open this URL: {verification_url}")
        print()
        print(f"   Enter code:    {user_code}")
        print()
        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        print()

        # Try to open browser automatically
        try:
            full_url = f"{verification_url}?code={user_code}"
            webbrowser.open(full_url)
            print("   (Browser opened automatically)")
        except Exception:
            print("   (Open the URL manually in your browser)")

        print()
        print(f"⏳ Waiting for authorization (expires in {expires_in // 60} minutes)...")
        print("   Press Ctrl+C to cancel")
        print()

        # Step 3: Poll for completion
        start_time = time.time()
        max_time = expires_in

        while time.time() - start_time < max_time:
            try:
                poll_response = httpx.post(
                    f"{get_cloud_api_url()}/v2/auth/device/poll",
                    json={"device_code": device_code},
                    timeout=30.0,
                )

                poll_data = poll_response.json()
                status = poll_data.get("status")

                if status == "approved":
                    # User approved! Now prompt for key choice
                    print()
                    print("✅ Authorization approved!")
                    print()

                    return _handle_key_choice(
                        device_code=device_code,
                        existing_keys=poll_data.get("existing_keys", []),
                        active_key_count=poll_data.get("active_key_count", 0),
                        max_keys=poll_data.get("max_keys", 5),
                        user_email=poll_data.get("user_email"),
                    )

                elif status == "complete":
                    # Key was already created (shouldn't happen with new flow, but handle it)
                    api_key = poll_data.get("api_key")
                    key_name = poll_data.get("key_name")

                    if not api_key:
                        print("❌ Authorization complete but no key returned.")
                        print(f"   Error: {poll_data.get('error', 'Unknown')}")
                        return 1

                    # Save API key to config
                    config = load_config()
                    config["api_key"] = api_key
                    config["valiqor_intelligence"] = True
                    # Set project_name from current directory if not already set
                    if not config.get("project_name"):
                        config["project_name"] = Path.cwd().name

                    print()
                    if save_config(config):
                        print("✅ Login successful!")
                        print(f"   Key name: {key_name}")
                        print(f"   Saved to: {get_config_path()}")
                        print()
                        print("📧 You have 3 trial runs. Verify your email to unlock 50 free runs:")
                        print("   → valiqor verify")
                        return 0
                    else:
                        print("⚠️  Could not save config, but login succeeded.")
                        print(f"   API Key: {api_key}")
                        print("   Add this to your .valiqorrc manually.")
                        print()
                        print("📧 You have 3 trial runs. Verify your email to unlock 50 free runs:")
                        print("   → valiqor verify")
                        return 0

                elif status == "denied":
                    print("❌ Authorization denied by user.")
                    return 1

                elif status == "expired":
                    print("❌ Authorization expired. Please try again.")
                    return 1

                elif status == "pending":
                    # Still waiting, show progress
                    elapsed = int(time.time() - start_time)
                    remaining = max_time - elapsed
                    print(
                        f"\r   Waiting... ({remaining // 60}:{remaining % 60:02d} remaining)",
                        end="",
                        flush=True,
                    )

                time.sleep(interval)

            except KeyboardInterrupt:
                print("\n\n❌ Login cancelled.")
                return 1
            except httpx.RequestError as e:
                # Network error, wait and retry
                time.sleep(interval)

        print("\n❌ Authorization timed out. Please try again.")
        return 1

    except httpx.RequestError as e:
        print(f"❌ Network error: {e}")
        return 1
    except Exception as e:
        print(f"❌ Login error: {e}")
        return 1


def _handle_key_choice(
    device_code: str, existing_keys: list, active_key_count: int, max_keys: int, user_email: str
) -> int:
    """
    Handle the key choice after device auth is approved.

    If user has 0 keys: Create new automatically
    If user has 1+ keys but not at limit: Prompt to create new or use existing
    If user at key limit: Prompt to delete a key, or use existing
    """
    import httpx

    # Case 1: No existing keys - create new automatically
    if active_key_count == 0:
        print("   No existing API keys found. Creating your first key...")
        print()
        return _create_new_key_from_device(device_code)

    # Case 2: At key limit - offer delete or use existing
    if active_key_count >= max_keys:
        print(f"⚠️  You have reached the maximum of {max_keys} API keys.")
        print()
        _show_existing_keys(existing_keys)
        print()
        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        print("   What would you like to do?")
        print()
        print("   [1] Delete a key and create a new one")
        print("   [2] Use an existing key (paste it)")
        print()

        try:
            choice = input("   Enter choice (1 or 2): ").strip()

            if choice == "1":
                print()
                return _delete_key_and_create_new(device_code, existing_keys)
            elif choice == "2":
                print()
                return _prompt_for_existing_key()
            else:
                print()
                print("   Invalid choice. Please try again.")
                return _handle_key_choice(
                    device_code, existing_keys, active_key_count, max_keys, user_email
                )

        except KeyboardInterrupt:
            print("\n\n❌ Login cancelled.")
            return 1

    # Case 3: Has keys but not at limit - offer choice
    print(f"   You have {active_key_count} existing API key(s):")
    print()
    _show_existing_keys(existing_keys)
    print()
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print("   What would you like to do?")
    print()
    print(f"   [1] Create a new key ({active_key_count + 1}/{max_keys} will be used)")
    print("   [2] Use an existing key (paste it)")
    print()

    try:
        choice = input("   Enter choice (1 or 2): ").strip()

        if choice == "1":
            print()
            return _create_new_key_from_device(device_code)
        elif choice == "2":
            print()
            return _prompt_for_existing_key()
        else:
            print()
            print("   Invalid choice. Creating a new key by default...")
            print()
            return _create_new_key_from_device(device_code)

    except KeyboardInterrupt:
        print("\n\n❌ Login cancelled.")
        return 1


def _show_existing_keys(existing_keys: list):
    """Display existing keys in a formatted list."""
    for i, key in enumerate(existing_keys, 1):
        name = key.get("name", "Unnamed")
        key_id = key.get("id", "?")
        prefix = key.get("public_prefix", "vq_???")
        created = key.get("created_at", "?")

        # Format created date
        if created and created != "?":
            try:
                from datetime import datetime

                if "T" in created:
                    dt = datetime.fromisoformat(created.replace("Z", "+00:00"))
                    created = dt.strftime("%Y-%m-%d")
            except Exception:
                pass

        print(f"      {i}. {name}")
        print(f"         Prefix: {prefix}...  (Created: {created})")


def _delete_key_and_create_new(device_code: str, existing_keys: list) -> int:
    """Delete an existing key and create a new one during device auth flow."""
    import httpx

    if not existing_keys:
        print("❌ No keys available to delete.")
        return 1

    print("   Which key would you like to delete?")
    print()

    # Show numbered list of keys
    for i, key in enumerate(existing_keys, 1):
        name = key.get("name", "Unnamed")
        prefix = key.get("public_prefix", "vq_???")
        print(f"      [{i}] {name} ({prefix}...)")

    print()
    print("   [0] Cancel")
    print()

    try:
        choice = input(f"   Enter number (1-{len(existing_keys)}) or 0 to cancel: ").strip()

        if choice == "0":
            print("   Cancelled.")
            return 1

        try:
            key_index = int(choice) - 1
            if key_index < 0 or key_index >= len(existing_keys):
                print("❌ Invalid selection.")
                return 1
        except ValueError:
            print("❌ Please enter a number.")
            return 1

        selected_key = existing_keys[key_index]
        key_id = selected_key.get("id")
        key_name = selected_key.get("name", "Unnamed")

        if not key_id:
            print("❌ Key ID not available.")
            return 1

        # Confirm deletion
        print()
        print(f"   ⚠️  Are you sure you want to delete '{key_name}'?")
        confirm = input("   Type 'yes' to confirm: ").strip().lower()

        if confirm != "yes":
            print("   Cancelled.")
            return 1

        print()
        print(f"🗑️  Deleting '{key_name}'...")

        # Call the delete endpoint
        response = httpx.post(
            f"{get_cloud_api_url()}/v2/auth/device/delete-key",
            json={"device_code": device_code, "key_id": key_id},
            timeout=30.0,
        )

        if response.status_code != 200:
            data = response.json()
            print(f"❌ Failed to delete key: {data.get('detail', response.text)}")
            return 1

        data = response.json()

        if not data.get("success"):
            print(f"❌ Failed to delete key: {data.get('error', 'Unknown error')}")
            return 1

        print(f"   ✅ Key deleted!")
        print()

        # Now create a new key
        return _create_new_key_from_device(device_code)

    except KeyboardInterrupt:
        print("\n\n❌ Cancelled.")
        return 1
    except httpx.RequestError as e:
        print(f"❌ Network error: {e}")
        return 1
    except Exception as e:
        print(f"❌ Error: {e}")
        return 1


def _create_new_key_from_device(device_code: str) -> int:
    """Create a new API key using the device authorization."""
    import httpx

    print("🔑 Creating new API key...")

    try:
        response = httpx.post(
            f"{get_cloud_api_url()}/v2/auth/device/create-key",
            json={"device_code": device_code},
            timeout=30.0,
        )

        if response.status_code != 200:
            data = response.json()
            print(f"❌ Failed to create key: {data.get('detail', response.text)}")
            return 1

        data = response.json()

        if not data.get("success"):
            print(f"❌ Failed to create key: {data.get('detail', 'Unknown error')}")
            return 1

        api_key = data.get("api_key")
        key_name = data.get("key_name")
        active_count = data.get("active_count", "?")
        max_keys = data.get("max_keys", 5)
        user_email = data.get("user_email")

        # Save globally (primary auth storage)
        save_global_credentials(api_key, user_email)

        # Also save to local .valiqorrc for backwards compatibility
        config = load_config()
        config["api_key"] = api_key
        config["valiqor_intelligence"] = True
        # Set project_name from current directory if not already set
        if not config.get("project_name"):
            config["project_name"] = Path.cwd().name
        save_config(config)

        print()
        print("✅ Login successful!")
        print(f"   Key name: {key_name}")
        print(f"   Project: {config['project_name']}")
        print(f"   Keys used: {active_count}/{max_keys}")
        print(f"   Global:   {get_global_credentials_path()}")
        print(f"   Local:    {get_config_path()}")
        print()
        print("📧 You have 3 trial runs. Verify your email to unlock 50 free runs:")
        print("   → valiqor verify")
        return 0

    except httpx.RequestError as e:
        print(f"❌ Network error: {e}")
        return 1
    except Exception as e:
        print(f"❌ Error creating key: {e}")
        return 1


def _prompt_for_existing_key() -> int:
    """Prompt user to paste an existing API key."""
    print("   Paste your existing API key below.")
    print("   (You can find it in your existing .valiqorrc or from the web dashboard)")
    print()

    try:
        api_key = input("   API Key: ").strip()

        if not api_key:
            print("❌ No key provided.")
            return 1

        if not api_key.startswith("vq_"):
            print("❌ Invalid key format. Keys should start with 'vq_'")
            return 1

        # Validate the key
        print()
        print("   Validating key...")

        if not _validate_existing_key(api_key):
            print("❌ Invalid or inactive API key.")
            return 1

        # Save globally (primary auth storage)
        save_global_credentials(api_key)

        # Also save to local .valiqorrc for backwards compatibility
        config = load_config()
        config["api_key"] = api_key
        config["valiqor_intelligence"] = True
        # Set project_name from current directory if not already set
        if not config.get("project_name"):
            config["project_name"] = Path.cwd().name
        save_config(config)

        print()
        print("✅ Login successful!")
        print(f"   Project: {config['project_name']}")
        print(f"   Global:   {get_global_credentials_path()}")
        print(f"   Local:    {get_config_path()}")
        print()
        print("📧 You have 3 trial runs. Verify your email to unlock 50 free runs:")
        print("   → valiqor verify")
        return 0

    except KeyboardInterrupt:
        print("\n\n❌ Login cancelled.")
        return 1


def cmd_signup(args: argparse.Namespace) -> int:
    """Sign up for a new Valiqor account."""
    import getpass

    email = getattr(args, "email", None)
    password = getattr(args, "password", None)
    name = getattr(args, "name", None)
    org_name = getattr(args, "org", None)

    # Check if already logged in with a valid key
    config = load_config()
    existing_key = config.get("api_key")

    if existing_key and _validate_existing_key(existing_key):
        print("✅ You're already logged in with a valid API key!")
        print()
        print("   Use 'valiqor login' if you need to switch accounts.")
        print("   Use 'valiqor keys create' to create additional API keys.")
        return 0

    # Interactive mode if email not provided
    if not email:
        print("🚀 Create a new Valiqor account")
        print()
        try:
            email = input("   Email: ").strip()
            if not email:
                print("❌ Email is required")
                return 1

            password = getpass.getpass("   Password: ")
            if not password:
                print("❌ Password is required")
                return 1

            # Confirm password
            password_confirm = getpass.getpass("   Confirm password: ")
            if password != password_confirm:
                print("❌ Passwords do not match")
                return 1

        except KeyboardInterrupt:
            print("\n\nSignup cancelled.")
            return 1
        print()
    elif not password:
        # Email provided but no password - prompt for it
        try:
            password = getpass.getpass("   Password: ")
            if not password:
                print("❌ Password is required")
                return 1
        except KeyboardInterrupt:
            print("\n\nSignup cancelled.")
            return 1

    return _signup_with_credentials(email=email, password=password, name=name, org_name=org_name)


def _signup_with_credentials(
    email: str, password: str, name: str = None, org_name: str = None
) -> int:
    """Sign up with email/password (for CI/CD environments)."""
    import httpx

    print("🚀 Creating new account...")
    print()

    try:
        response = httpx.post(
            f"{get_cloud_api_url()}/v2/auth/cli/signup",
            json={"email": email, "password": password, "name": name, "org_name": org_name},
            timeout=30.0,
        )

        if response.status_code == 501:
            print("❌ Direct signup not available on this server.")
            print(f"   Sign up at: {VALIQOR_SIGNUP_URL}")
            return 1

        data = response.json()

        if not data.get("success"):
            print(f"❌ Signup failed: {data.get('error', 'Unknown error')}")
            return 1

        api_key = data["api_key"]

        # Save globally (primary auth storage)
        save_global_credentials(api_key, email)

        # Also save to local .valiqorrc for backwards compatibility
        config = load_config()
        config["api_key"] = api_key
        config["valiqor_intelligence"] = True
        # Set project_name from current directory if not already set
        if not config.get("project_name"):
            config["project_name"] = Path.cwd().name
        save_config(config)

        print("✅ Account created successfully!")
        print(f"   Key name: {data.get('key_name', 'CLI Key')}")
        print(f"   Project:  {config['project_name']}")
        print(f"   Global:   {get_global_credentials_path()}")
        print(f"   Local:    {get_config_path()}")
        print()
        print("📧 You have 3 trial runs. Verify your email to unlock 50 free runs:")
        print("   → valiqor verify")
        print()
        print(f"🌐 You can also sign in to the dashboard at:")
        print(f"   {VALIQOR_SIGNUP_URL}")
        return 0

    except httpx.RequestError as e:
        print(f"❌ Network error: {e}")
        return 1
    except Exception as e:
        print(f"❌ Signup error: {e}")
        return 1


def cmd_verify(args: argparse.Namespace) -> int:
    """Verify your email to unlock full free-tier usage."""
    import httpx
    import webbrowser

    config = load_config()
    api_key = config.get("api_key")

    if not api_key:
        print("❌ Not logged in. Run 'valiqor login' or 'valiqor signup' first.")
        return 1

    print("📧 Requesting verification email...")
    print()

    try:
        response = httpx.post(
            f"{get_cloud_api_url()}/v2/auth/resend-verification",
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=15.0,
        )

        if response.status_code == 200:
            data = response.json()
            if data.get("already_verified"):
                print("✅ Your email is already verified — you have full free-tier access!")
                return 0
            print("✅ Verification email sent! Check your inbox (and spam folder).")
        elif response.status_code == 401:
            print("❌ Invalid API key. Run 'valiqor login' to re-authenticate.")
            return 1
        else:
            # Non-fatal — still open the dashboard
            try:
                detail = response.json().get("detail", response.text)
            except Exception:
                detail = response.text
            print(f"⚠️  Could not send verification email ({response.status_code}: {detail})")
            print("   Please verify via the dashboard instead.")

    except httpx.RequestError as e:
        print(f"⚠️  Network error: {e}")
        print("   Opening the dashboard instead — you can verify there.")

    print()
    dashboard_url = "https://app.valiqor.com/account"
    print(f"🌐 Opening dashboard: {dashboard_url}")
    try:
        webbrowser.open(dashboard_url)
    except Exception:
        print(f"   Please open manually: {dashboard_url}")

    return 0


def cmd_keys(args: argparse.Namespace) -> int:
    """Manage API keys."""
    keys_command = getattr(args, "keys_command", None)

    if keys_command == "create":
        return cmd_keys_create(args)
    elif keys_command == "list":
        return cmd_keys_list(args)
    elif keys_command == "delete":
        return cmd_keys_delete(args)
    else:
        print("Usage: valiqor keys <create|list|delete>")
        print()
        print("Commands:")
        print("  create    Create a new API key")
        print("  list      List your API keys")
        print("  delete    Delete an API key")
        return 0


def cmd_keys_create(args: argparse.Namespace) -> int:
    """Create a new API key (requires existing authentication)."""
    import httpx

    api_key, source = get_api_key()

    if not api_key:
        print("❌ Not logged in. Run 'valiqor login' first.")
        return 1

    print("🔑 Creating new API key...")
    print()

    key_name = getattr(args, "name", None)

    try:
        response = httpx.post(
            f"{get_cloud_api_url()}/v2/auth/cli/keys/create",
            headers={"Authorization": f"Bearer {api_key}"},
            json={"name": key_name} if key_name else {},
            timeout=30.0,
        )

        if response.status_code == 401:
            print("❌ Invalid or expired API key. Run 'valiqor login' to re-authenticate.")
            return 1

        if response.status_code == 400:
            data = response.json()
            print(f"❌ {data.get('detail', 'Failed to create key')}")
            return 1

        data = response.json()

        print("✅ API key created!")
        print()
        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        print(f"   Name: {data.get('name')}")
        print(f"   Key:  {data.get('api_key')}")
        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        print()
        print("⚠️  Store this key securely. It won't be shown again!")
        print()

        # Optionally save to config
        save_to_config = getattr(args, "save", False)
        if save_to_config:
            local_config = load_config()
            local_config["api_key"] = data["api_key"]
            if save_config(local_config):
                print(f"   Saved to: {get_config_path()}")

        return 0

    except httpx.RequestError as e:
        print(f"❌ Network error: {e}")
        return 1
    except Exception as e:
        print(f"❌ Error: {e}")
        return 1


def cmd_keys_list(args: argparse.Namespace) -> int:
    """List API keys from the backend."""
    import httpx

    api_key, source = get_api_key()

    if not api_key:
        print("❌ Not logged in. Run 'valiqor login' first.")
        return 1

    print("🔑 Fetching your API keys...")
    print()

    try:
        response = httpx.get(
            f"{get_cloud_api_url()}/v2/auth/cli/keys",
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=30.0,
        )

        if response.status_code == 401:
            print("❌ Invalid or expired API key. Run 'valiqor login' to re-authenticate.")
            return 1

        data = response.json()

        if not data.get("success", True):
            print(f"❌ {data.get('error', 'Failed to fetch keys')}")
            return 1

        keys = data.get("keys", [])
        active_count = data.get("active_count", 0)
        max_keys = data.get("max_keys", 5)

        if not keys:
            print("   No API keys found.")
            print()
            print(f"   Use 'valiqor keys create' to create one (0/{max_keys} used)")
            return 0

        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        print(f"   Your API Keys ({active_count}/{max_keys} used)")
        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        print()

        for i, key in enumerate(keys, 1):
            key_id = key.get("id", "?")
            name = key.get("name", "Unnamed")
            prefix = key.get("public_prefix", "vq_???")
            is_active = key.get("is_active", True)
            created = key.get("created_at", "?")

            # Format created date
            if created and created != "?":
                try:
                    from datetime import datetime

                    if "T" in created:
                        dt = datetime.fromisoformat(created.replace("Z", "+00:00"))
                        created = dt.strftime("%Y-%m-%d %H:%M")
                except Exception:
                    pass

            status = "✅ active" if is_active else "❌ revoked"

            print(f"   {i}. {name}")
            print(f"      ID: {key_id}")
            print(f"      Prefix: {prefix}...")
            print(f"      Created: {created}")
            print(f"      Status: {status}")
            print()

        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        print()
        print("   Use 'valiqor keys delete <key_id>' to revoke a key")
        print("   Use 'valiqor keys create' to create a new key")

        return 0

    except httpx.RequestError as e:
        print(f"❌ Network error: {e}")
        return 1
    except Exception as e:
        print(f"❌ Error: {e}")
        return 1


def cmd_keys_delete(args: argparse.Namespace) -> int:
    """Delete (revoke) an API key."""
    import httpx

    api_key, source = get_api_key()

    if not api_key:
        print("❌ Not logged in. Run 'valiqor login' first.")
        return 1

    key_id = getattr(args, "key_id", None)

    if not key_id:
        print("❌ Key ID is required.")
        print()
        print("Usage: valiqor keys delete <key_id>")
        print()
        print("Run 'valiqor keys list' to see your key IDs.")
        return 1

    # Confirm deletion
    force = getattr(args, "force", False)
    if not force:
        print(f"⚠️  Are you sure you want to delete key '{key_id}'?")
        print("   This action cannot be undone.")
        print()
        try:
            confirm = input("   Type 'yes' to confirm: ").strip().lower()
            if confirm != "yes":
                print("   Cancelled.")
                return 0
        except KeyboardInterrupt:
            print("\n   Cancelled.")
            return 0
        print()

    print("🗑️  Deleting API key...")

    try:
        response = httpx.delete(
            f"{get_cloud_api_url()}/v2/auth/cli/keys/{key_id}",
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=30.0,
        )

        if response.status_code == 401:
            print("❌ Invalid or expired API key. Run 'valiqor login' to re-authenticate.")
            return 1

        data = response.json()

        if data.get("success"):
            print(f"✅ {data.get('message', 'API key deleted successfully')}")
            return 0
        else:
            print(f"❌ {data.get('error', 'Failed to delete key')}")
            return 1

    except httpx.RequestError as e:
        print(f"❌ Network error: {e}")
        return 1
    except Exception as e:
        print(f"❌ Error: {e}")
        return 1


def cmd_logout(args: argparse.Namespace) -> int:
    """Logout from Valiqor (clear global credentials)."""
    print("🔐 Logging out from Valiqor...")
    print()

    # Check what exists
    api_key, source = get_api_key()
    global_creds = load_global_credentials()
    config_path = get_config_path()
    local_config_exists = config_path.exists()

    # Check if there's anything to logout from
    has_global_key = bool(global_creds.get("api_key"))
    has_local_key = False
    if local_config_exists:
        config = load_config()
        has_local_key = bool(config.get("api_key"))

    if not has_global_key and not has_local_key:
        print("ℹ️  You're not logged in.")
        return 0

    # Show what will be cleared
    cleared_something = False

    # Clear global credentials (always if they have an API key)
    if has_global_key:
        email = global_creds.get("email", "Unknown")
        if clear_global_credentials():
            print(f"✅ Cleared global credentials")
            print(f"   Email: {email}")
            print(f"   File: {get_global_credentials_path()}")
            cleared_something = True
        else:
            print(f"⚠️  Could not clear global credentials")

    # Clear local .valiqorrc API key (with --all flag, or always if no global creds)
    all_flag = getattr(args, "all", False)

    if has_local_key and (all_flag or not has_global_key):
        config = load_config()
        config["api_key"] = ""
        if save_config(config):
            print(f"✅ Cleared API key from local config")
            print(f"   File: {config_path}")
            cleared_something = True
        else:
            print(f"⚠️  Could not clear local config")
    elif has_local_key and not all_flag:
        print(f"ℹ️  Local config still has API key ({config_path})")
        print(f"   Use 'valiqor logout --all' to clear it too")

    if cleared_something:
        print()
        print("👋 You have been logged out.")
        print("   Run 'valiqor login' to sign in again.")

    return 0


# =============================================================================
# Evaluation CLI Commands
# =============================================================================


def _get_eval_client(args: argparse.Namespace):
    """
    Build a ValiqorEvalClient from CLI args + config.

    Resolution order for each setting:
        1. CLI args (--api-key, --project, --base-url)
        2. Local .valiqorrc
        3. Global ~/.valiqor/credentials.json (api_key only)
        4. Environment variables (VALIQOR_API_KEY, VALIQOR_BACKEND_URL etc.)
    """
    from valiqor.eval import ValiqorEvalClient

    api_key, source = get_api_key()
    cli_key = getattr(args, "api_key", None)
    if cli_key:
        api_key = cli_key

    if not api_key:
        print("❌ Not logged in. Run 'valiqor login' first.")
        return None

    config = load_config()
    project = getattr(args, "project", None) or config.get("project_name", "")
    base_url = getattr(args, "base_url", None) or config.get("backend_url") or None
    openai_key = getattr(args, "openai_api_key", None) or config.get("openai_api_key") or None

    return ValiqorEvalClient(
        api_key=api_key,
        project_name=project,
        base_url=base_url,
        openai_api_key=openai_key,
    )


def cmd_eval_run(args: argparse.Namespace) -> int:
    """
    Run evaluation on a dataset or trace.

    Usage:
        valiqor eval run --dataset data.json --metrics factual_accuracy,coherence
        valiqor eval run --trace-file trace.json --metrics hallucination,answer_relevance
    """
    if not EVAL_AVAILABLE:
        print("❌ Eval module not installed.")
        print("   Install with: pip install valiqor")
        return 1

    dataset_path = getattr(args, "dataset", None)
    trace_file = getattr(args, "trace_file", None)
    metrics_str = getattr(args, "metrics", None)
    is_async = getattr(args, "async_mode", False)

    if not dataset_path and not trace_file:
        print("❌ Provide either --dataset or --trace-file")
        print()
        print("  valiqor eval run --dataset data.json --metrics factual_accuracy,coherence")
        print("  valiqor eval run --trace-file trace.json --metrics hallucination")
        return 1

    if not metrics_str:
        print("❌ --metrics is required")
        print()
        print("  Example: --metrics factual_accuracy,coherence,hallucination")
        print("  Run 'valiqor eval metrics' to see available metrics")
        return 1

    metrics = [m.strip() for m in metrics_str.split(",")]

    # Load dataset or trace from JSON file
    dataset = None
    trace = None

    if dataset_path:
        try:
            with open(dataset_path, "r") as f:
                dataset = json.load(f)
            if not isinstance(dataset, list):
                print("❌ Dataset file must contain a JSON array of items")
                return 1
            # Light client-side validation
            if dataset:
                first_item = dataset[0]
                if "input" not in first_item or "output" not in first_item:
                    print("❌ Dataset items must have 'input' and 'output' fields")
                    print('   Example: [{"input": "question", "output": "answer", "context": "..."}]')
                    return 1
            print(f"📂 Loaded {len(dataset)} items from {dataset_path}")
        except FileNotFoundError:
            print(f"❌ Dataset file not found: {dataset_path}")
            return 1
        except json.JSONDecodeError as e:
            print(f"❌ Invalid JSON in dataset file: {e}")
            return 1

    if trace_file:
        try:
            with open(trace_file, "r") as f:
                trace = json.load(f)
            if not isinstance(trace, dict):
                print("❌ Trace file must contain a JSON object")
                return 1
            print(f"📂 Loaded trace from {trace_file}")
        except FileNotFoundError:
            print(f"❌ Trace file not found: {trace_file}")
            return 1
        except json.JSONDecodeError as e:
            print(f"❌ Invalid JSON in trace file: {e}")
            return 1

    client = _get_eval_client(args)
    if not client:
        return 1

    run_name = getattr(args, "run_name", None)
    model = getattr(args, "model", None)
    metadata = {}
    if model:
        metadata["model"] = model

    try:
        if trace:
            # Trace evaluation (always sync)
            print(f"🔍 Running trace evaluation with metrics: {', '.join(metrics)}...")
            print()
            result = client.evaluate_trace(
                trace=trace,
                metrics=metrics,
                run_name=run_name,
                metadata=metadata if metadata else None,
            )
            _print_eval_result(result)
            client.close()
            return 0

        if is_async:
            print("🚀 Starting async evaluation...")
            job = client.evaluate_async(
                dataset=dataset,
                metrics=metrics,
                run_name=run_name,
                metadata=metadata if metadata else None,
            )
            print()
            print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            print(f"   Job ID:  {job.job_id}")
            print(f"   Status:  submitted")
            print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            print()
            print("  Track progress:  valiqor eval status --run-id " + job.job_id)
            print("  Get result:      valiqor eval result --run-id " + job.job_id)
            client.close()
            return 0

        # Synchronous evaluation
        print(f"🔍 Running evaluation on {len(dataset)} items with metrics: {', '.join(metrics)}...")
        print()
        result = client.evaluate(
            dataset=dataset,
            metrics=metrics,
            run_name=run_name,
            metadata=metadata if metadata else None,
        )
        _print_eval_result(result)
        client.close()
        return 0

    except Exception as e:
        print(f"❌ Evaluation failed: {e}")
        client.close()
        return 1


def cmd_eval_status(args: argparse.Namespace) -> int:
    """
    Poll the status of an evaluation run.

    Usage:
        valiqor eval status --run-id <id>
        valiqor eval status --run-id <id> --wait
    """
    if not EVAL_AVAILABLE:
        print("❌ Eval module not installed.")
        return 1

    import time

    run_id = args.run_id
    wait_mode = getattr(args, "wait", False)

    client = _get_eval_client(args)
    if not client:
        return 1

    try:
        if not wait_mode:
            status = client.get_job_status(run_id)
            _print_eval_status(status)
            client.close()
            return 0

        # Wait mode — poll until completion
        print(f"⏳ Waiting for evaluation {run_id[:12]}... to complete")
        print()
        while True:
            status = client.get_job_status(run_id)
            progress = status.progress_percent or 0
            bar_filled = int(progress / 5)
            bar = "█" * bar_filled + "░" * (20 - bar_filled)
            print(f"\r   [{bar}] {progress:.0f}%  {status.status}    ", end="", flush=True)

            if status.status in ("completed", "failed", "cancelled"):
                print()
                print()
                if status.status == "completed":
                    print("✅ Evaluation completed!")
                    print(f"   Use 'valiqor eval result --run-id {run_id}' to view results")
                elif status.status == "failed":
                    print(f"❌ Evaluation failed: {status.error or 'unknown error'}")
                else:
                    print("⚠️  Evaluation was cancelled.")
                break

            time.sleep(3)

        client.close()
        return 0 if status.status == "completed" else 1

    except KeyboardInterrupt:
        print("\n\n⚠️  Stopped polling. Evaluation is still in progress on the server.")
        print(f"   Resume with: valiqor eval status --run-id {run_id} --wait")
        client.close()
        return 0
    except Exception as e:
        print(f"❌ Error: {e}")
        client.close()
        return 1


def cmd_eval_result(args: argparse.Namespace) -> int:
    """
    Get and display the result of an evaluation run.

    Usage:
        valiqor eval result --run-id <id>
        valiqor eval result --run-id <id> --json
    """
    if not EVAL_AVAILABLE:
        print("❌ Eval module not installed.")
        return 1

    run_id = args.run_id
    json_mode = getattr(args, "json_output", False)

    client = _get_eval_client(args)
    if not client:
        return 1

    try:
        if not json_mode:
            print(f"📊 Fetching result for evaluation {run_id[:12]}...")
            print()

        result = client.get_run_result(run_id)

        if json_mode:
            output = result.to_dict()
            # Populate aggregate_scores from per-metric data if empty
            if not output.get("aggregate_scores"):
                try:
                    metrics = client.get_run_metrics(run_id)
                    if metrics:
                        output["aggregate_scores"] = {
                            (m.key or m.display_name or "unknown"): m.score
                            for m in metrics if m.score is not None
                        }
                except Exception:
                    pass
            print(json.dumps(output, indent=2, default=str))
        else:
            _print_eval_result(result)

            # Also fetch per-metric scores
            try:
                metrics = client.get_run_metrics(run_id)
                if metrics:
                    print()
                    print("  ── Per-Metric Scores ────────────────────────────────")
                    for m in metrics:
                        name = m.display_name or m.key or "unknown"
                        score = m.score
                        if score is not None:
                            print(f"   {name:<30} {score:.3f}")
                        else:
                            print(f"   {name:<30} N/A")
            except Exception:
                pass  # Per-metric detail is optional

        client.close()
        return 0

    except Exception as e:
        if json_mode:
            print(json.dumps({"error": str(e)}, indent=2))
        else:
            print(f"❌ Error: {e}")
        client.close()
        return 1


def cmd_eval_list(args: argparse.Namespace) -> int:
    """
    List evaluation runs.

    Usage:
        valiqor eval list [--project my-app]
    """
    if not EVAL_AVAILABLE:
        print("❌ Eval module not installed.")
        return 1

    client = _get_eval_client(args)
    if not client:
        return 1

    project_name = getattr(args, "project", None) or client._project_name

    try:
        if not project_name:
            print("❌ Project name required. Use --project or set in .valiqorrc")
            client.close()
            return 1

        # Get project stats which includes recent runs
        data = client.get_project_stats(project_name=project_name)

        recent_runs = data.get("recent_runs", [])

        if not recent_runs:
            print("   No evaluation runs found.")
            if project_name:
                print(f"   (project: {project_name})")
            client.close()
            return 0

        print(f"📋 Evaluation Runs for '{project_name}'")
        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        print(f"  {'RUN ID':<14} {'STATUS':<12} {'SCORE':<10} {'ITEMS':<10} {'NAME':<22} {'CREATED'}")
        print(f"  {'─'*14} {'─'*12} {'─'*10} {'─'*10} {'─'*22} {'─'*19}")

        for item in recent_runs:
            rid = item.get("id", item.get("run_id", "?"))
            rid_display = rid[:12] + ".." if len(str(rid)) > 12 else rid
            st = item.get("status", "?")
            score = item.get("overall_score")
            score_display = f"{score:.3f}" if score is not None else "-"
            items_count = item.get("total_items", "-")
            name = (item.get("run_name") or "-")[:20]
            created = (item.get("created_at") or "")[:19]

            if st == "completed":
                st_display = f"✅ {st}"
            elif st == "failed":
                st_display = f"❌ {st}"
            elif st in ("running", "processing", "queued"):
                st_display = f"⏳ {st}"
            else:
                st_display = f"   {st}"

            print(f"  {rid_display:<14} {st_display:<16} {score_display:<10} {str(items_count):<10} {name:<22} {created}")

        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")

        client.close()
        return 0

    except Exception as e:
        print(f"❌ Error: {e}")
        client.close()
        return 1


def cmd_eval_metrics(args: argparse.Namespace) -> int:
    """
    List available evaluation metrics.

    Usage:
        valiqor eval metrics
    """
    if not EVAL_AVAILABLE:
        print("❌ Eval module not installed.")
        return 1

    client = _get_eval_client(args)
    if not client:
        return 1

    try:
        metrics = client.list_metric_templates()

        if not metrics:
            print("   No metric templates found.")
            return 0

        print("📏 Available Evaluation Metrics")
        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        print(f"  {'KEY':<30} {'DISPLAY NAME':<25} {'TYPE':<10} {'CATEGORY'}")
        print(f"  {'─'*30} {'─'*25} {'─'*10} {'─'*15}")

        for m in metrics:
            key = m.key
            name = m.display_name[:23]
            vtype = m.value_type or "numeric"
            cat = m.category or "-"
            print(f"  {key:<30} {name:<25} {vtype:<10} {cat}")

        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        print(f"  {len(metrics)} metric(s) available")
        print()
        print("  Usage: valiqor eval run --dataset data.json --metrics factual_accuracy,coherence")

        return 0

    except Exception as e:
        print(f"❌ Error: {e}")
        return 1
    finally:
        client.close()


def _print_eval_status(status) -> None:
    """Pretty-print an eval JobStatus."""
    progress = status.progress_percent or 0
    bar_filled = int(progress / 5)
    bar = "█" * bar_filled + "░" * (20 - bar_filled)

    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print(f"   Job ID:   {status.job_id}")
    print(f"   Type:     {status.job_type}")
    print(f"   Status:   {status.status}")
    print(f"   Progress: [{bar}] {progress:.0f}%")
    if status.current_item and status.total_items:
        print(f"   Items:    {status.current_item}/{status.total_items}")
    if status.error:
        print(f"   Error:    {status.error}")
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")


def _print_eval_result(result) -> None:
    """Pretty-print an EvaluationResult to the terminal."""
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print("  📊 Evaluation Result")
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print(f"   Run ID:       {result.run_id}")
    print(f"   Project:      {result.project_id}")
    print(f"   Status:       {result.status}")
    print(f"   Items:        {result.items_evaluated}/{result.total_items} evaluated")

    if result.overall_score is not None:
        score = result.overall_score
        if score >= 0.8:
            icon = "✅"
        elif score >= 0.5:
            icon = "⚠️"
        else:
            icon = "❌"
        print(f"   Overall:      {icon} {score:.3f}")
    else:
        print(f"   Overall:      N/A")

    # Aggregate scores by metric
    agg = result.aggregate_scores or {}
    if agg:
        print()
        print("  ── Metric Scores ────────────────────────────────────")
        for metric_key, score in agg.items():
            if score is not None:
                if score >= 0.8:
                    icon = "✅"
                elif score >= 0.5:
                    icon = "⚠️"
                else:
                    icon = "❌"
                print(f"   {icon} {metric_key:<28} {score:.3f}")
            else:
                print(f"   ⚪ {metric_key:<28} N/A")

    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")


# =============================================================================
# Security CLI Commands
# =============================================================================


def _get_security_client(args: argparse.Namespace):
    """
    Build a ValiqorSecurityClient from CLI args + config.

    Resolution order for each setting:
        1. CLI args (--api-key, --project, --base-url)
        2. Local .valiqorrc
        3. Global ~/.valiqor/credentials.json (api_key only)
        4. Environment variables (VALIQOR_API_KEY, VALIQOR_BACKEND_URL etc.)
    """
    from valiqor.security import ValiqorSecurityClient

    api_key, source = get_api_key()
    cli_key = getattr(args, "api_key", None)
    if cli_key:
        api_key = cli_key

    if not api_key:
        print("❌ Not logged in. Run 'valiqor login' first.")
        return None

    config = load_config()
    project = getattr(args, "project", None) or config.get("project_name", "")
    base_url = getattr(args, "base_url", None) or config.get("backend_url") or None
    openai_key = getattr(args, "openai_api_key", None) or config.get("openai_api_key") or None

    return ValiqorSecurityClient(
        api_key=api_key,
        project_name=project,
        base_url=base_url,
        openai_api_key=openai_key,
    )


def cmd_security_audit(args: argparse.Namespace) -> int:
    """
    Run a security audit on a dataset or trace.

    Usage:
        valiqor security audit --dataset data.json
        valiqor security audit --trace-file trace.json
        valiqor security audit --dataset data.json --categories S1,S2,S3 --async
    """
    if not SECURITY_AVAILABLE:
        print("❌ Security module not installed.")
        print("   Install with: pip install valiqor")
        return 1

    dataset_path = getattr(args, "dataset", None)
    trace_file = getattr(args, "trace_file", None)
    is_async = getattr(args, "async_mode", False)

    if not dataset_path and not trace_file:
        print("❌ Provide either --dataset or --trace-file")
        print()
        print("  valiqor security audit --dataset data.json")
        print("  valiqor security audit --trace-file trace.json")
        return 1

    # Load dataset or trace from JSON file
    dataset = None
    trace = None

    if dataset_path:
        try:
            with open(dataset_path, "r") as f:
                dataset = json.load(f)
            if not isinstance(dataset, list):
                print("❌ Dataset file must contain a JSON array of items")
                return 1
            # Light client-side validation
            if dataset:
                first_item = dataset[0]
                if "user_input" not in first_item or "assistant_response" not in first_item:
                    print("❌ Dataset items must have 'user_input' and 'assistant_response' fields")
                    print('   Example: [{"user_input": "...", "assistant_response": "..."}]')
                    return 1
            print(f"📂 Loaded {len(dataset)} items from {dataset_path}")
        except FileNotFoundError:
            print(f"❌ Dataset file not found: {dataset_path}")
            return 1
        except json.JSONDecodeError as e:
            print(f"❌ Invalid JSON in dataset file: {e}")
            return 1

    if trace_file:
        try:
            with open(trace_file, "r") as f:
                trace = json.load(f)
            if not isinstance(trace, dict):
                print("❌ Trace file must contain a JSON object")
                return 1
            print(f"📂 Loaded trace from {trace_file}")
        except FileNotFoundError:
            print(f"❌ Trace file not found: {trace_file}")
            return 1
        except json.JSONDecodeError as e:
            print(f"❌ Invalid JSON in trace file: {e}")
            return 1

    client = _get_security_client(args)
    if not client:
        return 1

    categories_str = getattr(args, "categories", None)
    categories = [c.strip() for c in categories_str.split(",")] if categories_str else None

    try:
        if trace:
            # Trace audit (always sync)
            cats_info = f" categories: {', '.join(categories)}" if categories else " (all categories)"
            print(f"🔒 Running security audit on trace...{cats_info}")
            print()
            result = client.audit_trace(
                trace=trace,
                categories=categories,
            )
            _print_audit_result(result)
            client.close()
            return 0

        if is_async:
            print("🚀 Starting async security audit...")
            job = client.audit_async(
                dataset=dataset,
                categories=categories,
            )
            print()
            print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            print(f"   Job ID:  {job.job_id}")
            print(f"   Type:    security audit")
            print(f"   Status:  submitted")
            print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            print()
            print("  Track progress:  valiqor security status --job-id " + job.job_id + " --type audit")
            print("  Get result:      valiqor security result --job-id " + job.job_id + " --type audit")
            client.close()
            return 0

        # Synchronous audit
        cats_info = f" categories: {', '.join(categories)}" if categories else " (all categories)"
        print(f"🔒 Running security audit on {len(dataset)} items...{cats_info}")
        print()
        result = client.audit(
            dataset=dataset,
            categories=categories,
        )
        _print_audit_result(result)
        client.close()
        return 0

    except Exception as e:
        print(f"❌ Security audit failed: {e}")
        client.close()
        return 1


def cmd_security_redteam(args: argparse.Namespace) -> int:
    """
    Run red team adversarial attack simulation.

    Usage:
        valiqor security redteam --target-prompt "You are a helpful assistant" --attack-vectors jailbreak,prompt_injection
        valiqor security redteam --target-url http://localhost:8000/chat --attack-vectors jailbreak
    """
    if not SECURITY_AVAILABLE:
        print("❌ Security module not installed.")
        print("   Install with: pip install valiqor")
        return 1

    target_prompt = getattr(args, "target_prompt", None)
    target_url = getattr(args, "target_url", None)
    is_async = getattr(args, "async_mode", False)

    if not target_prompt and not target_url:
        print("❌ Provide at least one of --target-prompt or --target-url")
        print()
        print('  valiqor security redteam --target-prompt "You are a helpful assistant" --attack-vectors jailbreak')
        print("  valiqor security redteam --target-url http://localhost:8000/chat --attack-vectors jailbreak")
        return 1

    attack_vectors_str = getattr(args, "attack_vectors", None)
    if not attack_vectors_str:
        print("❌ --attack-vectors is required")
        print()
        print("  Example: --attack-vectors jailbreak,prompt_injection,rot13")
        print("  Run 'valiqor security vectors' to see available attack vectors")
        return 1

    attack_vectors = [v.strip() for v in attack_vectors_str.split(",")]

    client = _get_security_client(args)
    if not client:
        return 1

    run_name = getattr(args, "run_name", None)
    attacks_per_vector = getattr(args, "attacks_per_vector", 5)
    vulns_str = getattr(args, "vulnerabilities", None)
    target_vulnerabilities = [v.strip() for v in vulns_str.split(",")] if vulns_str else None

    # Build config with target info
    config = {}
    if target_prompt:
        config["target_prompt"] = target_prompt
    if target_url:
        config["target_url"] = target_url

    try:
        if is_async:
            print("🚀 Starting async red team simulation...")
            job = client.red_team_async(
                attack_vectors=attack_vectors,
                attacks_per_vector=attacks_per_vector,
                run_name=run_name,
                target_vulnerabilities=target_vulnerabilities,
                config=config,
            )
            print()
            print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            print(f"   Job ID:  {job.job_id}")
            print(f"   Type:    red team")
            print(f"   Status:  submitted")
            print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            print()
            print("  Track progress:  valiqor security status --job-id " + job.job_id + " --type redteam")
            print("  Get result:      valiqor security result --job-id " + job.job_id + " --type redteam")
            client.close()
            return 0

        # Synchronous red team
        total_attacks = len(attack_vectors) * attacks_per_vector
        print(f"🔴 Running red team simulation ({total_attacks} attacks across {len(attack_vectors)} vectors)...")
        if target_prompt:
            print(f"   Target prompt: {target_prompt[:60]}{'...' if len(target_prompt) > 60 else ''}")
        if target_url:
            print(f"   Target URL: {target_url}")
        print()

        result = client.red_team(
            attack_vectors=attack_vectors,
            attacks_per_vector=attacks_per_vector,
            run_name=run_name,
            target_vulnerabilities=target_vulnerabilities,
            config=config,
        )
        _print_redteam_result(result)
        client.close()
        return 0

    except Exception as e:
        print(f"❌ Red team simulation failed: {e}")
        client.close()
        return 1


def cmd_security_status(args: argparse.Namespace) -> int:
    """
    Poll the status of a security job.

    Usage:
        valiqor security status --job-id <id> --type audit
        valiqor security status --job-id <id> --type redteam --wait
    """
    if not SECURITY_AVAILABLE:
        print("❌ Security module not installed.")
        return 1

    import time

    job_id = args.job_id
    job_type = getattr(args, "type", "audit")
    wait_mode = getattr(args, "wait", False)

    # Normalize job_type for the API
    api_job_type = "security" if job_type == "audit" else job_type

    client = _get_security_client(args)
    if not client:
        return 1

    try:
        if not wait_mode:
            status = client.get_job_status(job_id, job_type=api_job_type)
            _print_security_status(status)
            client.close()
            return 0

        # Wait mode
        print(f"⏳ Waiting for {job_type} job {job_id[:12]}... to complete")
        print()
        while True:
            status = client.get_job_status(job_id, job_type=api_job_type)
            progress = status.progress_percent or 0
            bar_filled = int(progress / 5)
            bar = "█" * bar_filled + "░" * (20 - bar_filled)
            print(f"\r   [{bar}] {progress:.0f}%  {status.status}    ", end="", flush=True)

            if status.status in ("completed", "failed", "cancelled"):
                print()
                print()
                if status.status == "completed":
                    print(f"✅ {job_type.capitalize()} job completed!")
                    print(f"   Use 'valiqor security result --job-id {job_id} --type {job_type}' to view results")
                elif status.status == "failed":
                    print(f"❌ Job failed: {status.error or 'unknown error'}")
                else:
                    print("⚠️  Job was cancelled.")
                break

            time.sleep(3)

        client.close()
        return 0 if status.status == "completed" else 1

    except KeyboardInterrupt:
        print("\n\n⚠️  Stopped polling. Job is still in progress on the server.")
        print(f"   Resume with: valiqor security status --job-id {job_id} --type {job_type} --wait")
        client.close()
        return 0
    except Exception as e:
        print(f"❌ Error: {e}")
        client.close()
        return 1


def cmd_security_result(args: argparse.Namespace) -> int:
    """
    Get and display the result of a security job.

    Usage:
        valiqor security result --job-id <id> --type audit
        valiqor security result --job-id <id> --type redteam --json
    """
    if not SECURITY_AVAILABLE:
        print("❌ Security module not installed.")
        return 1

    job_id = args.job_id
    job_type = getattr(args, "type", "audit")
    json_mode = getattr(args, "json_output", False)

    client = _get_security_client(args)
    if not client:
        return 1

    try:
        if not json_mode:
            print(f"📊 Fetching {job_type} result for {job_id[:12]}...")
            print()

        if job_type == "audit":
            result = client.get_audit_result(job_id)
            if json_mode:
                print(json.dumps(result.to_dict(), indent=2, default=str))
            else:
                _print_audit_result(result)
        elif job_type == "redteam":
            result = client.get_redteam_result(job_id)
            if json_mode:
                print(json.dumps(result.to_dict(), indent=2, default=str))
            else:
                _print_redteam_result(result)
        else:
            print(f"❌ Unknown type: {job_type}. Use 'audit' or 'redteam'.")
            client.close()
            return 1

        client.close()
        return 0

    except Exception as e:
        if json_mode:
            print(json.dumps({"error": str(e)}, indent=2))
        else:
            print(f"❌ Error: {e}")
        client.close()
        return 1


def cmd_security_list(args: argparse.Namespace) -> int:
    """
    List security audit batches or red team runs.

    Usage:
        valiqor security list --type audit
        valiqor security list --type redteam
    """
    if not SECURITY_AVAILABLE:
        print("❌ Security module not installed.")
        return 1

    client = _get_security_client(args)
    if not client:
        return 1

    list_type = getattr(args, "type", "audit")
    project_name = getattr(args, "project", None) or client._project_name

    try:
        if list_type == "audit":
            items = client.list_audit_batches(project_name=project_name)

            if not items:
                print("   No audit batches found.")
                client.close()
                return 0

            print(f"📋 Security Audit Batches")
            print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            print(f"  {'BATCH ID':<14} {'STATUS':<12} {'SAFETY':<10} {'ITEMS':<8} {'UNSAFE':<8} {'TOP RISK':<20} {'CREATED'}")
            print(f"  {'─'*14} {'─'*12} {'─'*10} {'─'*8} {'─'*8} {'─'*20} {'─'*19}")

            for b in items:
                bid = str(b.id)[:12] + ".." if len(str(b.id)) > 12 else b.id
                st = b.status or "?"
                safety = f"{b.safety_score:.0%}" if b.safety_score is not None else "-"
                total = str(b.total_items)
                unsafe = str(b.unsafe_items)
                risk = (b.top_risk_category or "-")[:18]
                created = (b.created_at or "")[:19]

                st_display = f"✅ {st}" if st == "completed" else f"⏳ {st}"
                print(f"  {bid:<14} {st_display:<16} {safety:<10} {total:<8} {unsafe:<8} {risk:<20} {created}")

            print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")

        elif list_type == "redteam":
            items = client.list_redteam_runs(project_name=project_name)

            if not items:
                print("   No red team runs found.")
                client.close()
                return 0

            print(f"📋 Red Team Runs")
            print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            print(f"  {'RUN ID':<14} {'STATUS':<12} {'SUCCESS':<10} {'ATTACKS':<10} {'VULNS':<8} {'NAME':<22} {'STARTED'}")
            print(f"  {'─'*14} {'─'*12} {'─'*10} {'─'*10} {'─'*8} {'─'*22} {'─'*19}")

            for r in items:
                rid = str(r.id)[:12] + ".." if len(str(r.id)) > 12 else r.id
                st = r.status or "?"
                rate = f"{r.success_rate:.0%}" if r.success_rate is not None else "-"
                attacks = f"{r.successful_attacks}/{r.total_attacks}"
                vulns = str(r.distinct_vulns_count)
                name = (r.name or "-")[:20]
                started = (r.started_at or "")[:19]

                st_display = f"✅ {st}" if st == "completed" else f"⏳ {st}"
                print(f"  {rid:<14} {st_display:<16} {rate:<10} {attacks:<10} {vulns:<8} {name:<22} {started}")

            print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")

        else:
            print(f"❌ Unknown type: {list_type}. Use 'audit' or 'redteam'.")
            client.close()
            return 1

        client.close()
        return 0

    except Exception as e:
        print(f"❌ Error: {e}")
        client.close()
        return 1


def cmd_security_vulns(args: argparse.Namespace) -> int:
    """
    List available vulnerability categories (S1-S23).

    Usage:
        valiqor security vulns
    """
    if not SECURITY_AVAILABLE:
        print("❌ Security module not installed.")
        return 1

    client = _get_security_client(args)
    if not client:
        return 1

    try:
        vulns = client.list_vulnerabilities()

        if not vulns:
            print("   No vulnerability categories found.")
            client.close()
            return 0

        print("🛡️  Vulnerability Categories (S1-S23)")
        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        print(f"  {'KEY':<8} {'NAME':<30} {'SEVERITY':<12} {'DESCRIPTION'}")
        print(f"  {'─'*8} {'─'*30} {'─'*12} {'─'*35}")

        for v in vulns:
            key = v.key
            name = v.display_name[:28]
            severity = v.severity or "-"
            desc = (v.description or "-")[:35]
            print(f"  {key:<8} {name:<30} {severity:<12} {desc}")

        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        print(f"  {len(vulns)} vulnerability categories available")
        print()
        print("  Usage: valiqor security audit --dataset data.json --categories S1,S2,S8")

        client.close()
        return 0

    except Exception as e:
        print(f"❌ Error: {e}")
        client.close()
        return 1


def cmd_security_vectors(args: argparse.Namespace) -> int:
    """
    List available attack vectors for red-teaming.

    Usage:
        valiqor security vectors
    """
    if not SECURITY_AVAILABLE:
        print("❌ Security module not installed.")
        return 1

    client = _get_security_client(args)
    if not client:
        return 1

    try:
        vectors = client.list_attack_vectors()

        if not vectors:
            print("   No attack vectors found.")
            client.close()
            return 0

        print("⚔️  Attack Vectors (Red Team)")
        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        print(f"  {'KEY':<25} {'NAME':<30} {'DESCRIPTION'}")
        print(f"  {'─'*25} {'─'*30} {'─'*35}")

        for v in vectors:
            key = v.key[:23]
            name = v.name[:28]
            desc = (v.description or "-")[:35]
            print(f"  {key:<25} {name:<30} {desc}")

        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        print(f"  {len(vectors)} attack vectors available")
        print()
        print('  Usage: valiqor security redteam --target-prompt "..." --attack-vectors jailbreak,prompt_injection')

        client.close()
        return 0

    except Exception as e:
        print(f"❌ Error: {e}")
        client.close()
        return 1


def _print_security_status(status) -> None:
    """Pretty-print a SecurityJobStatus."""
    progress = status.progress_percent or 0
    bar_filled = int(progress / 5)
    bar = "█" * bar_filled + "░" * (20 - bar_filled)

    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print(f"   Job ID:   {status.job_id}")
    print(f"   Type:     {status.job_type}")
    print(f"   Status:   {status.status}")
    print(f"   Progress: [{bar}] {progress:.0f}%")
    if status.current_item and status.total_items:
        print(f"   Items:    {status.current_item}/{status.total_items}")
    if status.error:
        print(f"   Error:    {status.error}")
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")


def _print_audit_result(result) -> None:
    """Pretty-print a SecurityAuditResult to the terminal."""
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print("  🔒 Security Audit Result")
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print(f"   Audit ID:     {result.audit_id}")
    print(f"   Total Items:  {result.total_items}")
    print(f"   Safe:         {result.safe_count}")
    print(f"   Unsafe:       {result.unsafe_count}")

    # Safety score with indicator
    score = result.safety_score
    if score >= 0.9:
        icon = "✅"
    elif score >= 0.7:
        icon = "⚠️"
    else:
        icon = "❌"
    print(f"   Safety Score: {icon} {score:.2%}")

    if result.top_risk_category:
        print(f"   Top Risk:     {result.top_risk_category}")

    # Triggered categories
    if result.triggered_categories:
        print()
        print("  ── Triggered Categories ─────────────────────────────")
        for cat, count in result.triggered_categories.items():
            print(f"   🚨 {cat}: {count} violation(s)")

    # Details (show first few)
    if result.details:
        print()
        print(f"  ── Details ({len(result.details)} items) ──────────────────────────")
        for i, detail in enumerate(result.details[:5], 1):
            is_safe = detail.get("is_safe", True)
            icon = "✅" if is_safe else "❌"
            user_input = (detail.get("user_input") or "")[:60]
            cats = detail.get("triggered_categories", [])
            cats_str = ", ".join(cats) if cats else "none"
            print(f"   {i}. {icon} {user_input}{'...' if len(detail.get('user_input', '')) > 60 else ''}")
            if not is_safe:
                print(f"      Categories: {cats_str}")
        if len(result.details) > 5:
            print(f"   ... and {len(result.details) - 5} more")

    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")


def _print_redteam_result(result) -> None:
    """Pretty-print a RedTeamResult to the terminal."""
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print("  🔴 Red Team Simulation Result")
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print(f"   Run ID:       {result.run_id}")
    print(f"   Name:         {result.name}")
    print(f"   Status:       {result.status}")

    # Attack success rate with indicator
    rate = result.success_rate
    if rate <= 0.1:
        icon = "✅"  # Low success = good defenses
    elif rate <= 0.3:
        icon = "⚠️"
    else:
        icon = "❌"  # High success = vulnerable
    print(f"   Success Rate: {icon} {rate:.1%} ({result.successful_attacks}/{result.total_attacks} attacks succeeded)")
    print(f"   Vulns Found:  {result.distinct_vulns_count}")

    if result.top_vulnerability:
        print(f"   Top Vuln:     {result.top_vulnerability}")
    if result.started_at:
        print(f"   Started:      {result.started_at[:19]}")

    # Risk assessment
    print()
    if rate <= 0.1:
        print("  ✅ Strong defenses — low attack success rate")
    elif rate <= 0.3:
        print("  ⚠️  Moderate risk — some attacks succeeded")
    else:
        print("  ❌ High risk — significant vulnerabilities detected")

    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")


# =============================================================================
# Failure Analysis CLI Commands
# =============================================================================


def _get_fa_client(args: argparse.Namespace):
    """
    Build a ValiqorFAClient from CLI args + config.

    Resolution order for each setting:
        1. CLI args (--api-key, --project, --base-url)
        2. Local .valiqorrc
        3. Global ~/.valiqor/credentials.json (api_key only)
        4. Environment variables (VALIQOR_API_KEY, VALIQOR_BACKEND_URL etc.)
    """
    from valiqor.failure_analysis import ValiqorFAClient

    api_key, source = get_api_key()
    cli_key = getattr(args, "api_key", None)
    if cli_key:
        api_key = cli_key

    if not api_key:
        print("❌ Not logged in. Run 'valiqor login' first.")
        return None

    config = load_config()
    project = getattr(args, "project", None) or config.get("project_name", "")
    base_url = getattr(args, "base_url", None) or config.get("backend_url") or None

    return ValiqorFAClient(
        api_key=api_key,
        project_name=project,
        base_url=base_url,
    )


def cmd_fa_run(args: argparse.Namespace) -> int:
    """
    Run failure analysis on a trace or dataset.

    Usage:
        valiqor fa run --trace-id <id>
        valiqor fa run --dataset data.json [--feature-kind rag]
    """
    if not FA_AVAILABLE:
        print("❌ Failure analysis module not installed.")
        return 1

    trace_id = getattr(args, "trace_id", None)
    dataset_path = getattr(args, "dataset", None)
    is_async = getattr(args, "async_mode", False)

    if not trace_id and not dataset_path:
        print("❌ Provide either --trace-id or --dataset")
        print()
        print("  valiqor fa run --trace-id <trace-uuid>")
        print("  valiqor fa run --dataset data.json")
        return 1

    # Load dataset from JSON file if provided
    dataset = None
    if dataset_path:
        try:
            with open(dataset_path, "r") as f:
                dataset = json.load(f)
            if not isinstance(dataset, list):
                print(f"❌ Dataset file must contain a JSON array of items")
                return 1
            print(f"📂 Loaded {len(dataset)} items from {dataset_path}")
        except FileNotFoundError:
            print(f"❌ Dataset file not found: {dataset_path}")
            return 1
        except json.JSONDecodeError as e:
            print(f"❌ Invalid JSON in dataset file: {e}")
            return 1

    client = _get_fa_client(args)
    if not client:
        return 1

    feature_kind = getattr(args, "feature_kind", None)
    run_eval = not getattr(args, "no_eval", False)
    run_security = not getattr(args, "no_security", False)
    buckets = getattr(args, "buckets", None)
    if buckets:
        buckets = [b.strip() for b in buckets.split(",")]

    try:
        if is_async:
            print("🚀 Starting async failure analysis...")
            job = client.run_async(
                trace_id=trace_id,
                dataset=dataset,
                feature_kind=feature_kind,
                run_eval=run_eval,
                run_security=run_security,
                buckets=buckets,
            )
            print()
            print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            print(f"   Job ID:  {job.job_id}")
            print(f"   Status:  submitted")
            print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            print()
            print("  Track progress:  valiqor fa status --run-id " + job.job_id)
            print("  Get result:      valiqor fa result --run-id " + job.job_id)
            client.close()
            return 0

        # Synchronous run
        mode = f"trace {trace_id}" if trace_id else f"{len(dataset)} dataset items"
        print(f"🔍 Running failure analysis on {mode}...")
        if feature_kind:
            print(f"   Feature kind: {feature_kind}")
        if not run_eval:
            print(f"   ⏭ Eval metrics skipped")
        if not run_security:
            print(f"   ⏭ Security audit skipped")
        print()

        result = client.run(
            trace_id=trace_id,
            dataset=dataset,
            feature_kind=feature_kind,
            run_eval=run_eval,
            run_security=run_security,
            buckets=buckets,
        )

        _print_fa_result(result)
        client.close()
        return 0

    except Exception as e:
        print(f"❌ Failure analysis failed: {e}")
        client.close()
        return 1


def cmd_fa_status(args: argparse.Namespace) -> int:
    """
    Poll the status of a failure analysis run.

    Usage:
        valiqor fa status --run-id <id>
        valiqor fa status --run-id <id> --wait
    """
    if not FA_AVAILABLE:
        print("❌ Failure analysis module not installed.")
        return 1

    import time

    run_id = args.run_id
    wait_mode = getattr(args, "wait", False)

    client = _get_fa_client(args)
    if not client:
        return 1

    try:
        if not wait_mode:
            status = client.poll_status(run_id)
            _print_fa_status(status)
            client.close()
            return 0

        # Wait mode — poll until completion
        print(f"⏳ Waiting for run {run_id[:12]}... to complete")
        print()
        while True:
            status = client.poll_status(run_id)
            progress = status.progress_percent or 0
            bar_filled = int(progress / 5)  # 20 chars wide
            bar = "█" * bar_filled + "░" * (20 - bar_filled)
            eta = f"  ETA: {status.estimated_remaining_seconds}s" if status.estimated_remaining_seconds else ""
            print(f"\r   [{bar}] {progress:.0f}%  {status.status}{eta}    ", end="", flush=True)

            if status.status in ("completed", "failed", "cancelled"):
                print()  # newline after progress bar
                print()
                if status.status == "completed":
                    print("✅ Run completed!")
                    print(f"   Use 'valiqor fa result --run-id {run_id}' to view results")
                elif status.status == "failed":
                    print(f"❌ Run failed: {status.error or 'unknown error'}")
                else:
                    print("⚠️  Run was cancelled.")
                break

            time.sleep(3)

        client.close()
        return 0 if status.status == "completed" else 1

    except KeyboardInterrupt:
        print("\n\n⚠️  Stopped polling. Run is still in progress on the server.")
        print(f"   Resume with: valiqor fa status --run-id {run_id} --wait")
        client.close()
        return 0
    except Exception as e:
        print(f"❌ Error: {e}")
        client.close()
        return 1


def cmd_fa_result(args: argparse.Namespace) -> int:
    """
    Get and display the result of a failure analysis run.

    Usage:
        valiqor fa result --run-id <id>
        valiqor fa result --run-id <id> --json
    """
    if not FA_AVAILABLE:
        print("❌ Failure analysis module not installed.")
        return 1

    run_id = args.run_id
    json_mode = getattr(args, "json_output", False)

    client = _get_fa_client(args)
    if not client:
        return 1

    try:
        if not json_mode:
            print(f"📊 Fetching result for run {run_id[:12]}...")
            print()

        result = client.get_run(run_id)

        if json_mode:
            # Raw JSON output — no emoji, machine-readable
            out = {
                "run_id": result.run_id,
                "status": result.status,
                "mode": result.mode,
                "input_type": result.input_type,
                "feature_kind": result.feature_kind,
                "summary": {
                    "total_failures_detected": result.summary.total_failures_detected,
                    "total_passes": result.summary.total_passes,
                    "overall_severity": result.summary.overall_severity,
                    "overall_confidence": result.summary.overall_confidence,
                    "primary_failure": result.summary.primary_failure,
                    "primary_failure_name": result.summary.primary_failure_name,
                    "should_alert": result.summary.should_alert,
                    "should_gate_ci": result.summary.should_gate_ci,
                } if result.summary else None,
                "failure_tags": [
                    {
                        "bucket": t.bucket_name,
                        "subcategory": t.subcategory_name,
                        "decision": t.decision,
                        "severity": t.severity,
                        "confidence": t.confidence,
                        "detector": t.detector_type_used,
                        "rationale": t.judge_rationale,
                    }
                    for t in result.failure_tags
                ],
                "eval_run_id": result.eval_run_id,
                "security_batch_id": result.security_batch_id,
                "duration_ms": result.duration_ms,
                "tokens_used": result.tokens_used,
            }
            print(json.dumps(out, indent=2, default=str))
        else:
            _print_fa_result(result)

        client.close()
        return 0

    except Exception as e:
        if json_mode:
            print(json.dumps({"error": str(e)}, indent=2))
        else:
            print(f"❌ Error: {e}")
        client.close()
        return 1


def cmd_fa_list(args: argparse.Namespace) -> int:
    """
    List failure analysis runs.

    Usage:
        valiqor fa list [--project my-app] [--status completed] [--page 1]
    """
    if not FA_AVAILABLE:
        print("❌ Failure analysis module not installed.")
        return 1

    client = _get_fa_client(args)
    if not client:
        return 1

    project = getattr(args, "project", None)
    status_filter = getattr(args, "status_filter", None)
    page = getattr(args, "page", 1)
    page_size = getattr(args, "page_size", 15)

    try:
        data = client.list_runs(
            project_name=project,
            status=status_filter,
            page=page,
            page_size=page_size,
        )

        items = data.items
        total = data.total
        has_more = data.has_more

        if not items:
            print("   No failure analysis runs found.")
            if project:
                print(f"   (filtered by project: {project})")
            return 0

        print(f"📋 Failure Analysis Runs  (page {page}, {total} total)")
        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        print(f"  {'RUN ID':<14} {'STATUS':<12} {'TYPE':<10} {'FAILURES':<10} {'PRIMARY':<22} {'CREATED'}")
        print(f"  {'─'*14} {'─'*12} {'─'*10} {'─'*10} {'─'*22} {'─'*19}")

        for item in items:
            rid = item.run_id[:12] + ".." if len(item.run_id) > 12 else item.run_id
            st = item.status or "?"
            itype = item.input_type or "?"
            fails = str(item.total_failures_detected) if item.total_failures_detected is not None else "-"
            primary = (item.primary_failure or "-")[:20]
            created = (item.created_at or "")[:19]

            # Status icon
            if st == "completed":
                st_display = f"✅ {st}"
            elif st == "failed":
                st_display = f"❌ {st}"
            elif st in ("running", "processing"):
                st_display = f"⏳ {st}"
            else:
                st_display = f"   {st}"

            print(f"  {rid:<14} {st_display:<16} {itype:<10} {fails:<10} {primary:<22} {created}")

        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        if has_more:
            print(f"  ▸ More results available. Use --page {page + 1} to see next page.")

        client.close()
        return 0

    except Exception as e:
        print(f"❌ Error: {e}")
        client.close()
        return 1


def _print_fa_status(status) -> None:
    """Pretty-print an FAJobStatus."""
    progress = status.progress_percent or 0
    bar_filled = int(progress / 5)
    bar = "█" * bar_filled + "░" * (20 - bar_filled)

    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print(f"   Run ID:   {status.job_id}")
    print(f"   Status:   {status.status}")
    print(f"   Progress: [{bar}] {progress:.0f}%")
    if status.current_item and status.total_items:
        print(f"   Items:    {status.current_item}/{status.total_items}")
    if status.estimated_remaining_seconds:
        print(f"   ETA:      {status.estimated_remaining_seconds}s")
    if status.error:
        print(f"   Error:    {status.error}")
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")


def _print_fa_result(result) -> None:
    """Pretty-print an FARunResult to the terminal."""
    s = result.summary

    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print("  📊 Failure Analysis Result")
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print(f"   Run ID:       {result.run_id}")
    print(f"   Status:       {result.status}")
    print(f"   Mode:         {result.mode}")
    if result.feature_kind:
        print(f"   Feature Kind: {result.feature_kind}")
    if result.duration_ms:
        print(f"   Duration:     {result.duration_ms}ms")
    if result.tokens_used:
        print(f"   Tokens Used:  {result.tokens_used}")

    if s:
        print()
        print("  ── Summary ──────────────────────────────────────────")
        fails = s.total_failures_detected or 0
        passes = s.total_passes or 0
        total = fails + passes + (s.total_uncertain or 0)

        if fails == 0:
            print(f"   ✅ No failures detected ({passes} passed, {total} total checks)")
        else:
            print(f"   ❌ {fails} failure(s) detected  ({passes} passed, {total} total)")
            print(f"   Severity:     {s.overall_severity:.1f}/10")
            print(f"   Confidence:   {s.overall_confidence:.0%}")
            if s.primary_failure_name:
                print(f"   Primary:      {s.primary_failure_name}")
            if s.should_alert:
                print(f"   🚨 Alert recommended")
            if s.should_gate_ci:
                print(f"   🚫 CI gate: BLOCK")

    tags = result.failure_tags or []
    if tags:
        print()
        print(f"  ── Failure Tags ({len(tags)}) ─────────────────────────────")
        for i, tag in enumerate(tags, 1):
            decision_icon = "❌" if tag.decision == "fail" else "⚠️" if tag.decision == "uncertain" else "✅"
            print(f"   {i}. {decision_icon} [{tag.bucket_name}] {tag.subcategory_name}")
            print(f"      Severity: {tag.severity:.1f}  Confidence: {tag.confidence:.0%}  Detector: {tag.detector_type_used}")
            if tag.judge_rationale:
                rationale = tag.judge_rationale[:120]
                if len(tag.judge_rationale) > 120:
                    rationale += "..."
                print(f"      Rationale: {rationale}")
    elif s and (s.total_failures_detected or 0) == 0:
        pass  # already showed "no failures"
    else:
        print()
        print("   No failure tags returned.")

    # Linked results
    if result.eval_run_id or result.security_batch_id:
        print()
        print("  ── Linked Results ───────────────────────────────────")
        if result.eval_run_id:
            print(f"   Eval Run:      {result.eval_run_id}")
        if result.security_batch_id:
            print(f"   Security Batch: {result.security_batch_id}")

    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")


# =============================================================================
# Main CLI Entry Point
# =============================================================================


class CustomHelpFormatter(argparse.RawDescriptionHelpFormatter):
    """Custom formatter for grouped help output."""

    pass


def main() -> int:
    """Main entry point for the CLI."""
    # Fix UnicodeEncodeError on Windows terminals using CP1252/other non-UTF-8 encodings.
    # CLI output uses emoji and box-drawing characters that cannot be encoded in CP1252.
    # This replaces unencodable characters with '?' instead of crashing.
    import io
    if hasattr(sys.stdout, 'reconfigure'):
        try:
            sys.stdout.reconfigure(errors='replace')
        except Exception:
            pass
    elif not isinstance(sys.stdout, io.TextIOWrapper):
        # Fallback for older Python or wrapped stdout
        pass
    if hasattr(sys.stderr, 'reconfigure'):
        try:
            sys.stderr.reconfigure(errors='replace')
        except Exception:
            pass

    parser = argparse.ArgumentParser(
        prog="valiqor",
        description="Valiqor CLI - Configuration, LLM tracing and AST scanning",
        formatter_class=CustomHelpFormatter,
        epilog=f"""
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Authentication:
  login             Login to Valiqor (opens browser, or use --email/--password)
  logout            Logout from Valiqor (clear credentials)
  signup            Create a new Valiqor account
  verify            Verify your email to unlock full free-tier usage
  keys create       Create additional API keys
  keys list         View your API keys

Project Configuration:
  config            Interactive project configuration
  config show       Show current configuration (--json for machine output)
  config set        Set config values: config set key=value [key=value ...]

General Commands:
  status            Show auth status, config, and module availability
  test              Test your Valiqor configuration
  upload            Upload trace/scan files to cloud (--type trace|scan|all)

Trace Commands (valiqor trace | valiqor t):
  trace init        Initialize tracing with codebase scan
  trace apply       Apply @trace_workflow decorators to functions
  trace uninstrument Remove auto-applied decorators
  trace refresh     Re-scan and regenerate workflow suggestions

Scan Commands (valiqor scan | valiqor s):
  scan run          Run AST context scan on repository

Evaluation Commands (valiqor eval):
  eval run          Run evaluation (--dataset or --trace-file, --metrics)
  eval status       Check status of an async eval run (--run-id)
  eval result       Get and display eval results (--run-id [--json])
  eval list         List evaluation runs ([--project])
  eval metrics      List available evaluation metrics

Security Commands (valiqor security):
  security audit    Run security audit (--dataset or --trace-file)
  security redteam  Run red team simulation (--target-prompt/--target-url)
  security status   Check status of a security job (--job-id --type)
  security result   Get security results (--job-id --type [--json])
  security list     List audit batches or red team runs (--type)
  security vulns    List vulnerability categories (S1-S23)
  security vectors  List available attack vectors

Failure Analysis Commands (valiqor fa):
  fa run            Run failure analysis (--trace-id or --dataset)
  fa status         Check status of an async FA run (--run-id)
  fa result         Get and display FA results (--run-id [--json])
  fa list           List FA runs ([--project] [--status])
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Quick Start:
  valiqor login                # Login (opens browser for device flow)
  valiqor test                 # Verify setup
  python my_app.py             # Start building!

CI/CD Quick Start:
  valiqor login -e EMAIL -p PW # Login with credentials
  valiqor config set project_name=my-app  # Set project non-interactively

Get your free API key: {VALIQOR_SIGNUP_URL}
Documentation: https://docs.valiqor.com
        """,
    )

    parser.add_argument("--version", "-v", action="store_true", help="Show version and exit")

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # =========================================================================
    # General Commands
    # =========================================================================

    # config command group (valiqor config | valiqor config show | valiqor config set)
    config_parser = subparsers.add_parser(
        "config", help="Project configuration (show, set, or interactive)"
    )
    config_subparsers = config_parser.add_subparsers(dest="config_command", help="Config commands")

    # config show
    config_show_parser = config_subparsers.add_parser(
        "show", help="Show current configuration"
    )
    config_show_parser.add_argument(
        "--json", dest="json_output", action="store_true",
        help="Output as JSON",
    )
    config_show_parser.set_defaults(func=cmd_config_show)

    # config set
    config_set_parser = config_subparsers.add_parser(
        "set", help="Set config values non-interactively (key=value ...)"
    )
    config_set_parser.add_argument(
        "pairs", nargs="*",
        help="key=value pairs (e.g. project_name=my-app environment=production)",
    )
    config_set_parser.set_defaults(func=cmd_config_set)

    # config with no subcommand -> interactive configure
    config_parser.set_defaults(func=cmd_config)

    # status command
    status_parser = subparsers.add_parser("status", help="Show configuration status")
    status_parser.set_defaults(func=cmd_status)

    # test command
    test_parser = subparsers.add_parser("test", help="Test your configuration")
    test_parser.set_defaults(func=cmd_test)

    # upload command
    upload_parser = subparsers.add_parser("upload", help="Upload trace/scan files to cloud")
    upload_parser.add_argument(
        "path",
        nargs="?",
        help="Path to file or directory to upload (default: use configured directories)",
    )
    upload_parser.add_argument(
        "-t",
        "--type",
        choices=["trace", "scan", "all"],
        default="all",
        help="Type of files to upload (default: all)",
    )
    upload_parser.add_argument("--endpoint", help="Custom backend API endpoint URL")
    upload_parser.add_argument("--api-key", help="API key for authentication")
    upload_parser.add_argument(
        "--delete-after", action="store_true", help="Delete local files after successful upload"
    )
    upload_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be uploaded without actually uploading",
    )
    upload_parser.set_defaults(func=cmd_upload)

    # =========================================================================
    # Trace Command Group (valiqor trace | valiqor t)
    # =========================================================================

    trace_parser = subparsers.add_parser(
        "trace", aliases=["t"], help="Trace commands (init, apply, uninstrument, refresh)"
    )
    trace_subparsers = trace_parser.add_subparsers(dest="trace_command", help="Trace commands")

    # trace init
    trace_init_parser = trace_subparsers.add_parser(
        "init", help="Initialize tracing with codebase scan"
    )
    trace_init_parser.add_argument(
        "--defaults", "-d", action="store_true", help="Use default settings without prompting"
    )
    trace_init_parser.add_argument(
        "--force", "-f", action="store_true", help="Overwrite existing valiqor_init.py"
    )
    trace_init_parser.add_argument(
        "--no-scan", action="store_true", help="Skip codebase scanning (faster, no suggestions)"
    )
    trace_init_parser.add_argument(
        "--verbose", "-v", action="store_true", help="Show detailed scan output"
    )
    trace_init_parser.set_defaults(func=cmd_trace_init)

    # trace apply
    trace_apply_parser = trace_subparsers.add_parser(
        "apply", help="Apply @trace_workflow decorators to functions"
    )
    trace_apply_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Preview what would be instrumented without making changes",
    )
    trace_apply_parser.add_argument(
        "--all",
        action="store_true",
        help="Apply to ALL entry points (including alternatives), not just recommended",
    )
    trace_apply_parser.add_argument(
        "--first", action="store_true", help="Apply to first suggestion per file only"
    )
    trace_apply_parser.add_argument(
        "--verbose", "-v", action="store_true", help="Show detailed output"
    )
    trace_apply_parser.set_defaults(func=cmd_trace_apply)

    # trace uninstrument
    trace_uninstrument_parser = trace_subparsers.add_parser(
        "uninstrument", help="Remove auto-applied instrumentation from files"
    )
    trace_uninstrument_parser.add_argument(
        "files", nargs="*", help="Files to uninstrument (default: all Python files)"
    )
    trace_uninstrument_parser.add_argument(
        "--dry-run", action="store_true", help="Show what would be removed without making changes"
    )
    trace_uninstrument_parser.add_argument(
        "--no-recursive",
        action="store_true",
        help="Only process current directory (default: recursive)",
    )
    trace_uninstrument_parser.set_defaults(func=cmd_trace_uninstrument)

    # trace refresh
    trace_refresh_parser = trace_subparsers.add_parser(
        "refresh", help="Re-scan codebase and update suggestions"
    )
    trace_refresh_parser.add_argument(
        "--verbose", "-v", action="store_true", help="Show detailed scan output"
    )
    trace_refresh_parser.set_defaults(func=cmd_trace_refresh)

    # =========================================================================
    # Scan Command Group (valiqor scan | valiqor s)
    # =========================================================================

    scan_parser = subparsers.add_parser("scan", aliases=["s"], help="Scan commands (run)")
    scan_subparsers = scan_parser.add_subparsers(dest="scan_command", help="Scan commands")

    # scan run
    scan_run_parser = scan_subparsers.add_parser("run", help="Run AST context scan on repository")
    scan_run_parser.add_argument(
        "path", nargs="?", default=".", help="Path to scan (default: current directory)"
    )
    scan_run_parser.add_argument(
        "--verbose", "-v", action="store_true", help="Show detailed scan output"
    )
    scan_run_parser.set_defaults(func=cmd_scan_run)

    # =========================================================================
    # Auth Commands (login, signup, keys)
    # =========================================================================

    # login command
    login_parser = subparsers.add_parser(
        "login", help="Login to Valiqor (opens browser or use --email/--password)"
    )
    login_parser.add_argument("--email", "-e", help="Email for direct login (CI/CD mode)")
    login_parser.add_argument("--password", "-p", help="Password for direct login (CI/CD mode)")
    login_parser.add_argument(
        "--force", "-f", action="store_true", help="Force login even if already logged in"
    )
    login_parser.set_defaults(func=cmd_login)

    # signup command
    signup_parser = subparsers.add_parser("signup", help="Create a new Valiqor account")
    signup_parser.add_argument("--email", "-e", help="Email for direct signup (CI/CD mode)")
    signup_parser.add_argument("--password", "-p", help="Password for direct signup (CI/CD mode)")
    signup_parser.add_argument("--name", "-n", help="Your name (required for direct signup)")
    signup_parser.add_argument("--org", "-o", help="Organization name (required for direct signup)")
    signup_parser.set_defaults(func=cmd_signup)

    # logout command
    logout_parser = subparsers.add_parser("logout", help="Logout from Valiqor (clear credentials)")
    logout_parser.add_argument(
        "--all", "-a", action="store_true", help="Also clear API key from local .valiqorrc"
    )
    logout_parser.set_defaults(func=cmd_logout)

    # verify command
    verify_parser = subparsers.add_parser(
        "verify", help="Verify your email to unlock full free-tier usage"
    )
    verify_parser.set_defaults(func=cmd_verify)

    # keys command group
    keys_parser = subparsers.add_parser("keys", help="Manage API keys")
    keys_subparsers = keys_parser.add_subparsers(dest="keys_command", help="Key commands")

    # keys create
    keys_create_parser = keys_subparsers.add_parser("create", help="Create a new API key")
    keys_create_parser.add_argument(
        "--name", "-n", help="Name for the new key (auto-generated if not provided)"
    )
    keys_create_parser.add_argument(
        "--save", "-s", action="store_true", help="Save the new key to .valiqorrc"
    )
    keys_create_parser.set_defaults(func=cmd_keys_create)

    # keys list
    keys_list_parser = keys_subparsers.add_parser("list", help="List your API keys")
    keys_list_parser.set_defaults(func=cmd_keys_list)

    # keys delete
    keys_delete_parser = keys_subparsers.add_parser("delete", help="Delete (revoke) an API key")
    keys_delete_parser.add_argument("key_id", help="ID of the key to delete")
    keys_delete_parser.add_argument(
        "--force", "-f", action="store_true", help="Skip confirmation prompt"
    )
    keys_delete_parser.set_defaults(func=cmd_keys_delete)

    # =========================================================================
    # Evaluation Command Group (valiqor eval)
    # =========================================================================

    eval_parser = subparsers.add_parser(
        "eval", help="Evaluation commands (run, status, result, list, metrics)"
    )
    eval_subparsers = eval_parser.add_subparsers(dest="eval_command", help="Eval commands")

    # Shared args helper
    def _add_eval_common_args(p):
        p.add_argument("--api-key", help="API key override")
        p.add_argument("--project", help="Project name override")
        p.add_argument("--base-url", help="Backend URL override")
        p.add_argument("--openai-api-key", help="OpenAI API key for LLM-based metrics")

    # eval run
    eval_run_parser = eval_subparsers.add_parser(
        "run", help="Run evaluation on a dataset or trace"
    )
    eval_run_input = eval_run_parser.add_mutually_exclusive_group()
    eval_run_input.add_argument("--dataset", help="Path to dataset JSON file")
    eval_run_input.add_argument("--trace-file", help="Path to trace JSON file")
    eval_run_parser.add_argument(
        "--metrics", required=True,
        help="Comma-separated list of metrics (e.g. factual_accuracy,coherence,hallucination)",
    )
    eval_run_parser.add_argument("--run-name", help="Name for this evaluation run")
    eval_run_parser.add_argument("--model", help="Model name metadata")
    eval_run_parser.add_argument(
        "--async", dest="async_mode", action="store_true",
        help="Submit async and return job ID (don't wait for result)",
    )
    _add_eval_common_args(eval_run_parser)
    eval_run_parser.set_defaults(func=cmd_eval_run)

    # eval status
    eval_status_parser = eval_subparsers.add_parser(
        "status", help="Check status of an evaluation run"
    )
    eval_status_parser.add_argument(
        "--run-id", required=True, help="Evaluation run/job ID"
    )
    eval_status_parser.add_argument(
        "--wait", "-w", action="store_true",
        help="Poll until completion (with progress bar)",
    )
    _add_eval_common_args(eval_status_parser)
    eval_status_parser.set_defaults(func=cmd_eval_status)

    # eval result
    eval_result_parser = eval_subparsers.add_parser(
        "result", help="Get full evaluation result"
    )
    eval_result_parser.add_argument(
        "--run-id", required=True, help="Evaluation run ID"
    )
    eval_result_parser.add_argument(
        "--json", dest="json_output", action="store_true",
        help="Output raw JSON instead of formatted display",
    )
    _add_eval_common_args(eval_result_parser)
    eval_result_parser.set_defaults(func=cmd_eval_result)

    # eval list
    eval_list_parser = eval_subparsers.add_parser(
        "list", help="List evaluation runs"
    )
    _add_eval_common_args(eval_list_parser)
    eval_list_parser.set_defaults(func=cmd_eval_list)

    # eval metrics
    eval_metrics_parser = eval_subparsers.add_parser(
        "metrics", help="List available evaluation metrics"
    )
    _add_eval_common_args(eval_metrics_parser)
    eval_metrics_parser.set_defaults(func=cmd_eval_metrics)

    # =========================================================================
    # Security Command Group (valiqor security)
    # =========================================================================

    security_parser = subparsers.add_parser(
        "security", help="Security commands (audit, redteam, status, result, list, vulns, vectors)"
    )
    security_subparsers = security_parser.add_subparsers(dest="security_command", help="Security commands")

    # Shared args helper
    def _add_security_common_args(p):
        p.add_argument("--api-key", help="API key override")
        p.add_argument("--project", help="Project name override")
        p.add_argument("--base-url", help="Backend URL override")
        p.add_argument("--openai-api-key", help="OpenAI API key for security operations")

    # security audit
    security_audit_parser = security_subparsers.add_parser(
        "audit", help="Run security audit on a dataset or trace"
    )
    security_audit_input = security_audit_parser.add_mutually_exclusive_group()
    security_audit_input.add_argument("--dataset", help="Path to dataset JSON file")
    security_audit_input.add_argument("--trace-file", help="Path to trace JSON file")
    security_audit_parser.add_argument(
        "--categories",
        help="Comma-separated safety categories to check (e.g. S1,S2,S8). Default: all",
    )
    security_audit_parser.add_argument(
        "--async", dest="async_mode", action="store_true",
        help="Submit async and return job ID",
    )
    _add_security_common_args(security_audit_parser)
    security_audit_parser.set_defaults(func=cmd_security_audit)

    # security redteam
    security_redteam_parser = security_subparsers.add_parser(
        "redteam", help="Run red team adversarial attack simulation"
    )
    security_redteam_parser.add_argument(
        "--target-prompt",
        help="System prompt of the target model to attack",
    )
    security_redteam_parser.add_argument(
        "--target-url",
        help="Endpoint URL of the target model to attack",
    )
    security_redteam_parser.add_argument(
        "--attack-vectors", required=True,
        help="Comma-separated attack vectors (e.g. jailbreak,prompt_injection,rot13)",
    )
    security_redteam_parser.add_argument(
        "--attacks-per-vector", type=int, default=5,
        help="Number of attacks per vector (default: 5)",
    )
    security_redteam_parser.add_argument(
        "--vulnerabilities",
        help="Comma-separated target vulnerability codes (e.g. S1,S2,S9)",
    )
    security_redteam_parser.add_argument(
        "--run-name", help="Name for this red team run",
    )
    security_redteam_parser.add_argument(
        "--async", dest="async_mode", action="store_true",
        help="Submit async and return job ID",
    )
    _add_security_common_args(security_redteam_parser)
    security_redteam_parser.set_defaults(func=cmd_security_redteam)

    # security status
    security_status_parser = security_subparsers.add_parser(
        "status", help="Check status of a security job"
    )
    security_status_parser.add_argument(
        "--job-id", required=True, help="Security job ID"
    )
    security_status_parser.add_argument(
        "--type", choices=["audit", "redteam"], default="audit",
        help="Job type (audit or redteam, default: audit)",
    )
    security_status_parser.add_argument(
        "--wait", "-w", action="store_true",
        help="Poll until completion (with progress bar)",
    )
    _add_security_common_args(security_status_parser)
    security_status_parser.set_defaults(func=cmd_security_status)

    # security result
    security_result_parser = security_subparsers.add_parser(
        "result", help="Get security result"
    )
    security_result_parser.add_argument(
        "--job-id", required=True, help="Security job/batch/run ID"
    )
    security_result_parser.add_argument(
        "--type", choices=["audit", "redteam"], default="audit",
        help="Job type (audit or redteam, default: audit)",
    )
    security_result_parser.add_argument(
        "--json", dest="json_output", action="store_true",
        help="Output raw JSON instead of formatted display",
    )
    _add_security_common_args(security_result_parser)
    security_result_parser.set_defaults(func=cmd_security_result)

    # security list
    security_list_parser = security_subparsers.add_parser(
        "list", help="List audit batches or red team runs"
    )
    security_list_parser.add_argument(
        "--type", choices=["audit", "redteam"], default="audit",
        help="List type (audit or redteam, default: audit)",
    )
    _add_security_common_args(security_list_parser)
    security_list_parser.set_defaults(func=cmd_security_list)

    # security vulns
    security_vulns_parser = security_subparsers.add_parser(
        "vulns", help="List vulnerability categories (S1-S23)"
    )
    _add_security_common_args(security_vulns_parser)
    security_vulns_parser.set_defaults(func=cmd_security_vulns)

    # security vectors
    security_vectors_parser = security_subparsers.add_parser(
        "vectors", help="List available attack vectors for red-teaming"
    )
    _add_security_common_args(security_vectors_parser)
    security_vectors_parser.set_defaults(func=cmd_security_vectors)

    # =========================================================================
    # Failure Analysis Command Group (valiqor fa)
    # =========================================================================

    fa_parser = subparsers.add_parser(
        "fa", help="Failure analysis commands (run, status, result, list)"
    )
    fa_subparsers = fa_parser.add_subparsers(dest="fa_command", help="FA commands")

    # Shared args helper
    def _add_fa_common_args(p):
        p.add_argument("--api-key", help="API key override")
        p.add_argument("--project", help="Project name override")
        p.add_argument("--base-url", help="Backend URL override")

    # fa run
    fa_run_parser = fa_subparsers.add_parser(
        "run", help="Run failure analysis on a trace or dataset"
    )
    fa_run_input = fa_run_parser.add_mutually_exclusive_group()
    fa_run_input.add_argument("--trace-id", help="Trace UUID to analyze")
    fa_run_input.add_argument("--dataset", help="Path to dataset JSON file")
    fa_run_parser.add_argument(
        "--feature-kind",
        choices=["rag", "agent", "agentic_rag", "generic_llm"],
        help="App type hint (auto-detected if omitted)",
    )
    fa_run_parser.add_argument(
        "--no-eval", action="store_true", help="Skip eval metrics"
    )
    fa_run_parser.add_argument(
        "--no-security", action="store_true", help="Skip security audit"
    )
    fa_run_parser.add_argument(
        "--buckets", help="Comma-separated bucket filter (e.g. hallucination,safety)"
    )
    fa_run_parser.add_argument(
        "--async", dest="async_mode", action="store_true",
        help="Submit async and return job ID (don't wait for result)",
    )
    _add_fa_common_args(fa_run_parser)
    fa_run_parser.set_defaults(func=cmd_fa_run)

    # fa status
    fa_status_parser = fa_subparsers.add_parser(
        "status", help="Check status of an FA run"
    )
    fa_status_parser.add_argument(
        "--run-id", required=True, help="FA run/job ID"
    )
    fa_status_parser.add_argument(
        "--wait", "-w", action="store_true",
        help="Poll until completion (with progress bar)",
    )
    _add_fa_common_args(fa_status_parser)
    fa_status_parser.set_defaults(func=cmd_fa_status)

    # fa result
    fa_result_parser = fa_subparsers.add_parser(
        "result", help="Get full FA result"
    )
    fa_result_parser.add_argument(
        "--run-id", required=True, help="FA run ID"
    )
    fa_result_parser.add_argument(
        "--json", dest="json_output", action="store_true",
        help="Output raw JSON instead of formatted display",
    )
    _add_fa_common_args(fa_result_parser)
    fa_result_parser.set_defaults(func=cmd_fa_result)

    # fa list
    fa_list_parser = fa_subparsers.add_parser(
        "list", help="List FA runs"
    )
    fa_list_parser.add_argument(
        "--status", dest="status_filter",
        choices=["completed", "failed", "running", "cancelled"],
        help="Filter by status",
    )
    fa_list_parser.add_argument("--page", type=int, default=1, help="Page number")
    fa_list_parser.add_argument("--page-size", type=int, default=15, help="Items per page")
    _add_fa_common_args(fa_list_parser)
    fa_list_parser.set_defaults(func=cmd_fa_list)

    # =========================================================================
    # Parse and Execute
    # =========================================================================

    args = parser.parse_args()

    # Handle --version
    if args.version:
        try:
            from . import __version__

            print(f"valiqor {__version__}")
            print(f"  • Trace:    {'available' if TRACE_AVAILABLE else 'not installed'}")
            print(f"  • Scanner:  {'available' if SCANNER_AVAILABLE else 'not installed'}")
            print(f"  • Eval:     {'available' if EVAL_AVAILABLE else 'not installed'}")
            print(f"  • Security: {'available' if SECURITY_AVAILABLE else 'not installed'}")
            print(f"  • FA:       {'available' if FA_AVAILABLE else 'not installed'}")
        except ImportError:
            print("valiqor (version unknown)")
        return 0

    # Handle no command
    if not args.command:
        parser.print_help()
        return 0

    # Handle trace subcommand group without subcommand
    if args.command in ("trace", "t") and not getattr(args, "trace_command", None):
        trace_parser.print_help()
        return 0

    # Handle scan subcommand group without subcommand
    if args.command in ("scan", "s") and not getattr(args, "scan_command", None):
        scan_parser.print_help()
        return 0

    # Handle keys subcommand group without subcommand
    if args.command == "keys" and not getattr(args, "keys_command", None):
        keys_parser.print_help()
        return 0

    # Handle config subcommand group without subcommand
    if args.command == "config" and not getattr(args, "config_command", None):
        return cmd_configure(args)

    # Handle eval subcommand group without subcommand
    if args.command == "eval" and not getattr(args, "eval_command", None):
        eval_parser.print_help()
        return 0

    # Handle security subcommand group without subcommand
    if args.command == "security" and not getattr(args, "security_command", None):
        security_parser.print_help()
        return 0

    # Handle fa subcommand group without subcommand
    if args.command == "fa" and not getattr(args, "fa_command", None):
        fa_parser.print_help()
        return 0

    # Run command
    if hasattr(args, "func"):
        return args.func(args)

    parser.print_help()
    return 0


if __name__ == "__main__":
    sys.exit(main())
