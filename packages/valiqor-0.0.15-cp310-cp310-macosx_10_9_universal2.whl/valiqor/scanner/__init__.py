"""
Scanner Module - AST Context Scanning for LLM Applications

Scan codebases to identify LLM patterns, RAG implementations,
and generate context for evaluation and security testing.

Usage:
    from valiqor.scanner import ValiqorScanner

    scanner = ValiqorScanner()
    scanner.configure(api_key="vq_xxx", project_name="my-app")
    result = scanner.scan("/path/to/repo")

Or quick scan:
    from valiqor.scanner import quick_scan

    result = quick_scan(
        api_key="vq_xxx",
        project_name="my-app",
        repo_path="/path/to/repo"
    )
"""

import sys
from typing import TYPE_CHECKING

# =============================================================================
# COMPILED MODULE LOADER
# =============================================================================
# Scanner modules are compiled for distribution (core IP):
# - scanner.py -> _scanner_impl.so/.pyd
# - pipeline.py -> _pipeline_impl.so/.pyd
# - commands.py -> _commands_impl.so/.pyd


def _load_scanner_module():
    """Load the scanner module (compiled or source)."""
    try:
        # Try compiled extension first (PyPI distribution)
        from valiqor.scanner import _scanner_impl

        return _scanner_impl
    except ImportError:
        try:
            # Fallback to source (development mode)
            from valiqor.scanner import scanner as scanner_mod

            return scanner_mod
        except ImportError as e:
            raise ImportError(
                "Scanner module not available. Install with: pip install valiqor\n"
                f"Original error: {e}"
            ) from None


def _load_commands_module():
    """Load the commands module (compiled or source)."""
    try:
        from valiqor.scanner import _commands_impl

        return _commands_impl
    except ImportError:
        try:
            from valiqor.scanner import commands as commands_mod

            return commands_mod
        except ImportError as e:
            raise ImportError(
                "Scanner commands not available. Install with: pip install valiqor\n"
                f"Original error: {e}"
            ) from None


def _load_pipeline_module():
    """Load the pipeline module (compiled or source)."""
    try:
        from valiqor.scanner import _pipeline_impl

        return _pipeline_impl
    except ImportError:
        try:
            from valiqor.scanner import pipeline as pipeline_mod

            return pipeline_mod
        except ImportError as e:
            raise ImportError(
                "Pipeline module not available. Install with: pip install valiqor\n"
                f"Original error: {e}"
            ) from None


# ---------------------------------------------------------------------------
# Load modules in dependency order and register each under its original
# module name in ``sys.modules``.
#
# Why?  In PyPI wheels the proprietary .py source files are removed and
# replaced by Cython-compiled ``_*_impl`` extensions.  But the compiled
# bytecode still contains the *original* import paths, e.g.
#   _commands_impl  ➜  ``from .scanner import ValiqorScanner``
#   _scanner_impl   ➜  ``from .pipeline import run_local_pipeline``
#   _pipeline_impl  ➜  ``from .core.ast_scanner import run_scanner``
#
# By storing the loaded module object in ``sys.modules`` under the
# original dotted name, Python finds it there instead of searching
# the file-system for a now-deleted .py file.
# ---------------------------------------------------------------------------

# 1) Ensure core sub-package modules are loaded and registered first
#    (pipeline depends on core.ast_scanner, core.merger, etc.)
import valiqor.scanner.core  # noqa: F401  – triggers core/__init__.py

# 2) Load scanner module (no intra-scanner deps at import time)
_scanner_mod = _load_scanner_module()
sys.modules.setdefault("valiqor.scanner.scanner", _scanner_mod)

# 3) Load pipeline module (depends on core.* – already registered)
#    Made graceful: pipeline imports gitingest which may be incompatible
#    with some Python versions (e.g. 3.9) at import time.  Pipeline is
#    only needed at runtime when scanner.scan() is called, so a failure
#    here is non-fatal — the module will be loaded lazily if needed.
try:
    _pipeline_mod = _load_pipeline_module()
    sys.modules.setdefault("valiqor.scanner.pipeline", _pipeline_mod)
except (ImportError, TypeError, Exception):
    _pipeline_mod = None

# 4) Load commands module (depends on .scanner – already registered)
_commands_mod = _load_commands_module()
sys.modules.setdefault("valiqor.scanner.commands", _commands_mod)

# Export main classes
ValiqorScanner = _scanner_mod.ValiqorScanner
ScanResult = _scanner_mod.ScanResult

# Export run_scan from commands module
run_scan = _commands_mod.run_scan

# Alias for convenience
Scanner = ValiqorScanner


def quick_scan(
    api_key: str, project_name: str, repo_path: str, backend_url: str = None, verbose: bool = False
) -> "ScanResult":
    """
    Convenience function for quick one-off scans.

    Args:
        api_key: API key for authentication
        project_name: Name of the project
        repo_path: Path to the repository to scan
        backend_url: Optional custom backend URL
        verbose: Enable verbose logging

    Returns:
        ScanResult with scan details
    """
    scanner = ValiqorScanner()
    scanner.configure(
        api_key=api_key, project_name=project_name, backend_url=backend_url, verbose=verbose
    )
    return scanner.scan(repo_path)


# =============================================================================
# PUBLIC API
# =============================================================================
__all__ = [
    "ValiqorScanner",
    "Scanner",
    "ScanResult",
    "quick_scan",
    "run_scan",
]
