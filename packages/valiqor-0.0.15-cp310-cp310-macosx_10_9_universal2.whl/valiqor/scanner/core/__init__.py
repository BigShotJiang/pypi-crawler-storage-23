"""
Valiqor SDK Scanner Core Modules

This package contains the core analysis modules:
- ast_scanner: AST-based code analysis
- gitingest_preprocessor: Metadata extraction from gitingest
- merger: Combines AST and gitingest data
- stage1_classifier: Feature classification

These modules are compiled for distribution to protect core IP.
"""

import sys
from typing import TYPE_CHECKING

# =============================================================================
# COMPILED MODULE LOADERS
# =============================================================================


def _load_ast_scanner():
    """Load AST scanner module."""
    try:
        from valiqor.scanner.core import _ast_scanner_impl as mod

        return mod
    except ImportError:
        try:
            from valiqor.scanner.core import ast_scanner as mod

            return mod
        except ImportError as e:
            raise ImportError(
                "AST scanner not available. Install with: pip install valiqor\n"
                f"Original error: {e}"
            ) from None


def _load_preprocessor():
    """Load gitingest preprocessor module."""
    try:
        from valiqor.scanner.core import _gitingest_preprocessor_impl as mod

        return mod
    except ImportError:
        try:
            from valiqor.scanner.core import gitingest_preprocessor as mod

            return mod
        except ImportError as e:
            raise ImportError(
                "Preprocessor not available. Install with: pip install valiqor\n"
                f"Original error: {e}"
            ) from None


def _load_merger():
    """Load merger module."""
    try:
        from valiqor.scanner.core import _merger_impl as mod

        return mod
    except ImportError:
        try:
            from valiqor.scanner.core import merger as mod

            return mod
        except ImportError as e:
            raise ImportError(
                "Merger not available. Install with: pip install valiqor\n" f"Original error: {e}"
            ) from None


def _load_classifier():
    """Load stage1 classifier module."""
    try:
        from valiqor.scanner.core import _stage1_classifier_impl as mod

        return mod
    except ImportError:
        try:
            from valiqor.scanner.core import stage1_classifier as mod

            return mod
        except ImportError as e:
            raise ImportError(
                "Classifier not available. Install with: pip install valiqor\n"
                f"Original error: {e}"
            ) from None


def _load_pattern_loader():
    """Load pattern loader module."""
    try:
        from valiqor.scanner.core import _pattern_loader_impl as mod

        return mod
    except ImportError:
        try:
            from valiqor.scanner.core import pattern_loader as mod

            return mod
        except ImportError as e:
            raise ImportError(
                "Pattern loader not available. Install with: pip install valiqor\n"
                f"Original error: {e}"
            ) from None


# Load modules and register under original names in sys.modules.
# This is critical for PyPI builds where source .py files are removed and
# replaced by _*_impl compiled extensions.  Other compiled modules
# (e.g. _pipeline_impl) still contain hard-coded imports like
# ``from .core.ast_scanner import run_scanner`` which resolve to
# ``valiqor.scanner.core.ast_scanner``.  Registering the _impl module
# under the original name lets Python satisfy those imports.
_ast_mod = _load_ast_scanner()
sys.modules.setdefault("valiqor.scanner.core.ast_scanner", _ast_mod)

_prep_mod = _load_preprocessor()
sys.modules.setdefault("valiqor.scanner.core.gitingest_preprocessor", _prep_mod)

_merge_mod = _load_merger()
sys.modules.setdefault("valiqor.scanner.core.merger", _merge_mod)

_class_mod = _load_classifier()
sys.modules.setdefault("valiqor.scanner.core.stage1_classifier", _class_mod)

_pattern_mod = _load_pattern_loader()
sys.modules.setdefault("valiqor.scanner.core.pattern_loader", _pattern_mod)

# Export functions
run_scanner = _ast_mod.run_scanner
run_preprocessor = _prep_mod.run_preprocessor
run_merger = _merge_mod.run_merger
run_classifier = _class_mod.run_classifier
get_pattern_loader = _pattern_mod.get_pattern_loader

# =============================================================================
# PUBLIC API
# =============================================================================
__all__ = [
    "run_scanner",
    "run_preprocessor",
    "run_merger",
    "run_classifier",
    "get_pattern_loader",
]
