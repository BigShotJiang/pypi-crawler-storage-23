"""
Valiqor Exceptions - Unified Exception Hierarchy

All Valiqor SDK exceptions inherit from ValiqorError for easy catching.
"""


class ValiqorError(Exception):
    """Base exception for all Valiqor errors."""

    pass


# =============================================================================
# Configuration Errors
# =============================================================================


class ConfigurationError(ValiqorError):
    """Invalid or missing configuration."""

    pass


# =============================================================================
# Authentication & Authorization Errors
# =============================================================================


class AuthenticationError(ValiqorError):
    """API key or authentication failure."""

    pass


class AccountDeactivatedError(AuthenticationError):
    """User account has been deactivated by an administrator.

    The API key is no longer valid because the owning account was deactivated.
    Contact support or visit https://app.valiqor.com/account for assistance.
    """

    pass


class RateLimitError(ValiqorError):
    """Rate limit exceeded.

    Attributes:
        retry_after: Seconds to wait before retrying (from Retry-After header)
    """

    def __init__(self, message: str, retry_after: int = None):
        super().__init__(message)
        self.retry_after = retry_after


class QuotaExceededError(ValiqorError):
    """Monthly API request quota exceeded.

    Attributes:
        current_usage: Current usage count
        quota_limit: Maximum allowed quota
        service: Which service hit the quota (evaluation, security_audit, etc.)
    """

    def __init__(
        self,
        message: str,
        current_usage: int = None,
        quota_limit: int = None,
        service: str = None,
    ):
        super().__init__(message)
        self.current_usage = current_usage
        self.quota_limit = quota_limit
        self.service = service


class TokenQuotaExceededError(QuotaExceededError):
    """Monthly token quota exceeded.

    Attributes:
        current_tokens: Tokens already used this period
        predicted_tokens: Tokens predicted for this request
        token_limit: Maximum token quota
    """

    def __init__(
        self,
        message: str,
        current_tokens: int = None,
        predicted_tokens: int = None,
        token_limit: int = None,
        service: str = None,
    ):
        super().__init__(message, current_tokens, token_limit, service)
        self.current_tokens = current_tokens
        self.predicted_tokens = predicted_tokens
        self.token_limit = token_limit


# =============================================================================
# Request & Validation Errors
# =============================================================================


class ValidationError(ValiqorError):
    """Request or data validation failure."""

    pass


class DatasetTooLargeError(ValidationError):
    """Dataset size exceeds maximum allowed limit.

    Attributes:
        dataset_size: Number of items in the submitted dataset
        max_allowed: Maximum allowed dataset size
    """

    def __init__(self, message: str, dataset_size: int = None, max_allowed: int = None):
        super().__init__(message)
        self.dataset_size = dataset_size
        self.max_allowed = max_allowed


class TimeoutError(ValiqorError):
    """Request timeout."""

    pass


# =============================================================================
# Network & API Errors
# =============================================================================


class NetworkError(ValiqorError):
    """HTTP/connection failure."""

    pass


class APIError(ValiqorError):
    """API returned an error response."""

    def __init__(self, message: str, status_code: int = None, response: dict = None):
        super().__init__(message)
        self.status_code = status_code
        self.response = response


class ServiceUnavailableError(APIError):
    """Server temporarily unavailable (503).

    Raised after an automatic retry has already been attempted.

    Attributes:
        retry_after: Suggested seconds to wait before retrying again
    """

    def __init__(self, message: str, retry_after: int = None, response: dict = None):
        super().__init__(message, status_code=503, response=response)
        self.retry_after = retry_after


class UploadError(NetworkError):
    """File or trace upload failure."""

    pass


# =============================================================================
# Module-Specific Errors
# =============================================================================


class TracingError(ValiqorError):
    """Tracing-specific error."""

    pass


class ScanError(ValiqorError):
    """Scanner-specific error."""

    pass


class EvaluationError(ValiqorError):
    """Evaluation-specific error."""

    pass


class SecurityError(ValiqorError):
    """Security evaluation-specific error."""

    pass
