import random

def main():
    # List of common English words to choose from
    word_pool = [
        "apple", "banana", "cherry", "dragon", "elephant",
        "forest", "garden", "harmony", "island", "jungle",
        "kitchen", "lemon", "mountain", "notebook", "ocean",
        "penguin", "quantum", "rainbow", "sunshine", "thunder",
        "umbrella", "village", "whisper", "xylophone", "yellow",
        "zebra", "adventure", "butterfly", "chocolate", "diamond",
        "energy", "freedom", "gravity", "horizon", "imagine",
        "journey", "knowledge", "library", "mystery", "nature",
        "optimism", "paradise", "question", "rhythm", "silence",
        "treasure", "universe", "velocity", "wonder", "zenith"
    ]
    
    # Select 5 random words
    random_words = random.sample(word_pool, 5)
    
    result = {
        "random_words": random_words,
        "count": len(random_words),
        "description": "A list of 5 randomly selected words"
    }
    
    return result

# For non-async context, just call main directly
result = main()