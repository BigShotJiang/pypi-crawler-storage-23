"""
PeerClient - Direct peer-to-peer communication for agents.

Provides a simple API for agents to discover and communicate
with other agents in the mesh without going through workflow orchestration.

Example:
    class MyAgent(JarvisAgent):
        async def run(self):
            # Discovery
            analyst = self.peers.get_peer(role="analyst")

            # Notify (fire-and-forget)
            await self.peers.notify("analyst", {"event": "done", "data": result})

            # Request-response
            response = await self.peers.request("scout", {"need": "clarification"}, timeout=30)

            # Receive incoming messages
            message = await self.peers.receive(timeout=5)
"""
import asyncio
import logging
import random
import time
from typing import List, Dict, Any, Optional, TYPE_CHECKING
from uuid import uuid4

from .messages import PeerInfo, IncomingMessage, OutgoingMessage, MessageType

if TYPE_CHECKING:
    from .coordinator import P2PCoordinator

logger = logging.getLogger(__name__)


class RemoteAgentProxy:
    """
    Proxy object for remote agents.

    Used by PeerClient to represent agents on other nodes in the mesh.
    Contains enough information to route messages via P2P coordinator.
    """

    def __init__(
        self,
        agent_id: str,
        role: str,
        node_id: str,
        capabilities: List[str] = None
    ):
        self.agent_id = agent_id
        self.role = role
        self.node_id = node_id
        self.capabilities = capabilities or []
        self.peers = None  # Remote agents don't have local PeerClient

    def __repr__(self):
        return f"<RemoteAgentProxy {self.role}@{self.node_id}>"


class PeerClient:
    """
    Client for peer-to-peer agent communication.

    Injected into agents during mesh startup, provides direct access
    to peer discovery and messaging without workflow orchestration.
    """

    def __init__(
        self,
        coordinator: 'P2PCoordinator',
        agent_id: str,
        agent_role: str,
        agent_registry: Dict[str, List],
        node_id: str = ""
    ):
        """
        Initialize PeerClient.

        Args:
            coordinator: P2P coordinator for message routing
            agent_id: This agent's unique ID
            agent_role: This agent's role
            agent_registry: Registry mapping roles to agent lists
            node_id: This node's P2P identifier (host:port)
        """
        self._coordinator = coordinator
        self._agent_id = agent_id
        self._agent_role = agent_role
        self._agent_registry = agent_registry
        self._node_id = node_id

        # Message queue for incoming messages
        self._message_queue: asyncio.Queue[IncomingMessage] = asyncio.Queue()

        # Pending requests waiting for responses (correlation_id -> Future)
        self._pending_requests: Dict[str, asyncio.Future] = {}

        # Async request inbox (correlation_id -> response data or None)
        self._async_inbox: Dict[str, Optional[Dict[str, Any]]] = {}

        # Async request metadata (correlation_id -> metadata dict)
        self._async_requests: Dict[str, Dict[str, Any]] = {}

        # Load balancing state
        self._round_robin_index: Dict[str, int] = {}  # key -> current index
        self._peer_last_used: Dict[str, float] = {}   # agent_id -> timestamp

        self._logger = logging.getLogger(f"jarviscore.peer_client.{agent_id}")

    # ─────────────────────────────────────────────────────────────────
    # DISCOVERY
    # ─────────────────────────────────────────────────────────────────

    def get_peer(self, role: str) -> Optional[PeerInfo]:
        """
        Get information about a peer by role.

        Args:
            role: The role to look for (e.g., "analyst", "scout")

        Returns:
            PeerInfo if found, None otherwise

        Example:
            analyst = self.peers.get_peer(role="analyst")
            if analyst:
                print(f"Found analyst: {analyst.agent_id}")
        """
        agents = self._agent_registry.get(role, [])
        if not agents:
            self._logger.debug(f"No peer found with role: {role}")
            return None

        # Return first agent with this role
        agent = agents[0]
        return PeerInfo(
            agent_id=agent.agent_id,
            role=agent.role,
            capabilities=list(agent.capabilities),
            node_id=self._node_id,
            status="alive"
        )

    def discover(
        self,
        capability: str = None,
        role: str = None,
        strategy: str = "first"
    ) -> List[PeerInfo]:
        """
        Discover peers by capability or role.

        Args:
            capability: Filter by capability (e.g., "analysis")
            role: Filter by role (e.g., "analyst")
            strategy: Selection strategy for ordering results:
                - "first": Return in discovery order (default, current behavior)
                - "random": Shuffle results randomly
                - "round_robin": Rotate through peers on each call
                - "least_recent": Return least recently used peers first

        Returns:
            List of matching PeerInfo objects, ordered by strategy

        Example:
            # Get a random analyst for load balancing
            analysts = self.peers.discover(role="analyst", strategy="random")
            if analysts:
                await self.peers.request(analysts[0].role, {"task": "..."})

            # Round-robin across workers
            workers = self.peers.discover(capability="processing", strategy="round_robin")
        """
        results = []

        # Search LOCAL agents first
        if role:
            agents = self._agent_registry.get(role, [])
            for agent in agents:
                if agent.agent_id != self._agent_id:  # Exclude self
                    results.append(PeerInfo(
                        agent_id=agent.agent_id,
                        role=agent.role,
                        capabilities=list(agent.capabilities),
                        node_id=self._node_id,
                        status="alive"
                    ))

        elif capability:
            # Search all local agents for capability
            for role_name, agents in self._agent_registry.items():
                for agent in agents:
                    if agent.agent_id != self._agent_id:  # Exclude self
                        if capability in agent.capabilities:
                            results.append(PeerInfo(
                                agent_id=agent.agent_id,
                                role=agent.role,
                                capabilities=list(agent.capabilities),
                                node_id=self._node_id,
                                status="alive"
                            ))

        else:
            # Return all local peers
            for role_name, agents in self._agent_registry.items():
                for agent in agents:
                    if agent.agent_id != self._agent_id:  # Exclude self
                        results.append(PeerInfo(
                            agent_id=agent.agent_id,
                            role=agent.role,
                            capabilities=list(agent.capabilities),
                            node_id=self._node_id,
                            status="alive"
                        ))

        # BUG FIX: Also search REMOTE agents from other nodes
        # Access coordinator's _remote_agent_registry
        if self._coordinator and hasattr(self._coordinator, '_remote_agent_registry'):
            remote_registry = self._coordinator._remote_agent_registry

            for agent_id, info in remote_registry.items():
                if agent_id == self._agent_id:  # Exclude self
                    continue

                # Filter by role if specified
                if role and info.get('role') != role:
                    continue

                # Filter by capability if specified
                if capability and capability not in info.get('capabilities', []):
                    continue

                # Add remote peer
                results.append(PeerInfo(
                    agent_id=info['agent_id'],
                    role=info['role'],
                    capabilities=info.get('capabilities', []),
                    node_id=info.get('node_id', 'unknown'),
                    status="alive"
                ))

        # Apply selection strategy
        if results and strategy != "first":
            key = capability or role or "all"
            results = self._apply_strategy(results, key, strategy)

        return results

    def _apply_strategy(
        self,
        peers: List[PeerInfo],
        key: str,
        strategy: str
    ) -> List[PeerInfo]:
        """Apply selection strategy to reorder peer list."""
        if len(peers) <= 1:
            return peers

        if strategy == "random":
            shuffled = peers.copy()
            random.shuffle(shuffled)
            return shuffled

        elif strategy == "round_robin":
            # Get current index for this key
            idx = self._round_robin_index.get(key, 0)
            # Rotate list to start from current index
            rotated = peers[idx:] + peers[:idx]
            # Increment index for next call
            self._round_robin_index[key] = (idx + 1) % len(peers)
            return rotated

        elif strategy == "least_recent":
            # Sort by last used time (oldest first)
            def get_last_used(peer: PeerInfo) -> float:
                return self._peer_last_used.get(peer.agent_id, 0.0)
            return sorted(peers, key=get_last_used)

        else:  # "first" or unknown
            return peers

    def discover_one(
        self,
        capability: str = None,
        role: str = None,
        strategy: str = "first"
    ) -> Optional[PeerInfo]:
        """
        Discover a single peer by capability or role.

        Convenience method that returns just the first peer from discover().

        Args:
            capability: Filter by capability
            role: Filter by role
            strategy: Selection strategy ("first", "random", "round_robin", "least_recent")

        Returns:
            Single PeerInfo or None if no match found

        Example:
            # Get a random analyst
            analyst = self.peers.discover_one(role="analyst", strategy="random")
            if analyst:
                response = await self.peers.request(analyst.agent_id, {...})
        """
        peers = self.discover(capability=capability, role=role, strategy=strategy)
        return peers[0] if peers else None

    def record_peer_usage(self, peer_id: str):
        """
        Record that a peer was used (for least_recent strategy).

        Call this after successfully communicating with a peer
        to update the usage timestamp for load balancing.

        Args:
            peer_id: The agent_id of the peer that was used
        """
        self._peer_last_used[peer_id] = time.time()

    @property
    def registry(self) -> Dict[str, PeerInfo]:
        """
        Read-only access to the full agent registry.

        Returns:
            Dictionary mapping agent_id to PeerInfo

        Example:
            for agent_id, info in self.peers.registry.items():
                print(f"{agent_id}: {info.role}")
        """
        result = {}
        for role_name, agents in self._agent_registry.items():
            for agent in agents:
                if agent.agent_id != self._agent_id:  # Exclude self
                    result[agent.agent_id] = PeerInfo(
                        agent_id=agent.agent_id,
                        role=agent.role,
                        capabilities=list(agent.capabilities),
                        node_id=self._node_id,
                        status="alive"
                    )
        return result

    # ─────────────────────────────────────────────────────────────────
    # IDENTITY
    # ─────────────────────────────────────────────────────────────────

    @property
    def my_role(self) -> str:
        """This agent's role."""
        return self._agent_role

    @property
    def my_id(self) -> str:
        """This agent's unique ID."""
        return self._agent_id

    # ─────────────────────────────────────────────────────────────────
    # DISCOVERY (simplified for tool use)
    # ─────────────────────────────────────────────────────────────────

    def list_roles(self) -> List[str]:
        """
        Get list of available peer roles (excluding self).

        Returns:
            List of role strings like ["scout", "analyst"]

        Example:
            roles = self.peers.list_roles()
            # ["scout", "analyst", "reporter"]
        """
        roles = set()
        # Check local agents
        for role_name, agents in self._agent_registry.items():
            for agent in agents:
                if agent.agent_id != self._agent_id:
                    roles.add(role_name)
        
        # BUG FIX: Also check remote agents from SWIM mesh
        if self._coordinator and hasattr(self._coordinator, '_remote_agent_registry'):
            remote_registry = self._coordinator._remote_agent_registry
            for agent_id, info in remote_registry.items():
                if agent_id != self._agent_id:  # Exclude self
                    roles.add(info.get('role'))
        
        return sorted(list(roles))

    def list_peers(self) -> List[Dict[str, Any]]:
        """
        Get detailed list of peers with capabilities.

        Includes both local and remote agents in the mesh.

        Returns:
            List of dicts with role, agent_id, capabilities, status, location

        Example:
            peers = self.peers.list_peers()
            # [
            #     {"role": "scout", "capabilities": ["reasoning"], "location": "local", ...},
            #     {"role": "analyst", "capabilities": ["analysis"], "location": "remote", ...}
            # ]
        """
        seen = set()
        peers = []

        # 1. Local agents
        for role_name, agents in self._agent_registry.items():
            for agent in agents:
                if agent.agent_id != self._agent_id and agent.agent_id not in seen:
                    seen.add(agent.agent_id)
                    peers.append({
                        "role": agent.role,
                        "agent_id": agent.agent_id,
                        "capabilities": list(agent.capabilities),
                        "description": getattr(agent, 'description', ''),
                        "status": "online",
                        "location": "local"
                    })

        # 2. Remote agents from coordinator
        if self._coordinator:
            for remote in self._coordinator.list_remote_agents():
                agent_id = remote.get('agent_id')
                if agent_id and agent_id not in seen:
                    seen.add(agent_id)
                    peers.append({
                        "role": remote.get('role', 'unknown'),
                        "agent_id": agent_id,
                        "capabilities": remote.get('capabilities', []),
                        "description": remote.get('description', ''),
                        "status": "online",
                        "location": "remote",
                        "node_id": remote.get('node_id', '')
                    })

        return peers

    # ─────────────────────────────────────────────────────────────────
    # MESSAGING - SEND
    # ─────────────────────────────────────────────────────────────────

    async def notify(
        self,
        target: str,
        message: Dict[str, Any],
        context: Optional[Dict[str, Any]] = None
    ) -> bool:
        """
        Send a fire-and-forget notification to a peer.

        Args:
            target: Target agent role (e.g., "analyst") or agent_id
            message: Message payload (any JSON-serializable dict)
            context: Optional metadata (mission_id, priority, trace_id, etc.)

        Returns:
            True if message was sent successfully

        Example:
            await self.peers.notify("analyst", {
                "event": "scouting_complete",
                "data": {"findings": 42}
            }, context={"mission_id": "abc123"})
        """
        target_agent = self._resolve_target(target)
        if not target_agent:
            self._logger.warning(f"Cannot notify: no peer found for '{target}'")
            return False

        outgoing = OutgoingMessage(
            target=target,
            type=MessageType.NOTIFY,
            data=message,
            sender=self._agent_id,
            sender_node=self._node_id,
            context=context
        )

        return await self._send_message(target_agent, outgoing)

    async def request(
        self,
        target: str,
        message: Dict[str, Any],
        timeout: float = 30.0,
        context: Optional[Dict[str, Any]] = None
    ) -> Optional[Dict[str, Any]]:
        """
        Send a request and wait for a response.

        Args:
            target: Target agent role (e.g., "scout") or agent_id
            message: Request payload
            timeout: Max seconds to wait for response (default: 30)
            context: Optional metadata (mission_id, priority, trace_id, etc.)

        Returns:
            Response data dict, or None if timeout/failure

        Example:
            response = await self.peers.request("scout", {
                "need": "clarification",
                "entity": "Entity_X"
            }, timeout=10, context={"mission_id": "abc123", "priority": "high"})

            if response:
                print(f"Got clarification: {response}")
        """
        target_agent = self._resolve_target(target)
        if not target_agent:
            self._logger.warning(f"Cannot request: no peer found for '{target}'")
            return None

        # Generate correlation ID for request-response matching
        correlation_id = f"req-{uuid4().hex[:12]}"

        outgoing = OutgoingMessage(
            target=target,
            type=MessageType.REQUEST,
            data=message,
            correlation_id=correlation_id,
            sender=self._agent_id,
            sender_node=self._node_id,
            context=context
        )

        # Create future to wait for response (use running loop — this is an async method)
        response_future: asyncio.Future = asyncio.get_running_loop().create_future()
        self._pending_requests[correlation_id] = response_future

        try:
            # Send request
            sent = await self._send_message(target_agent, outgoing)
            if not sent:
                return None

            # Wait for response with timeout
            response = await asyncio.wait_for(response_future, timeout=timeout)
            return response

        except asyncio.TimeoutError:
            self._logger.debug(f"Request to '{target}' timed out after {timeout}s")
            return None

        finally:
            # Cleanup pending request
            self._pending_requests.pop(correlation_id, None)

    async def respond(
        self,
        message: IncomingMessage,
        response: Dict[str, Any],
        context: Optional[Dict[str, Any]] = None
    ) -> bool:
        """
        Respond to an incoming request.

        Args:
            message: The incoming request message
            response: Response data to send back
            context: Optional metadata to include in response.
                     If None, automatically propagates the original request's context.

        Returns:
            True if response was sent successfully

        Example:
            message = await self.peers.receive()
            if message and message.is_request:
                # Context is auto-propagated from the request
                await self.peers.respond(message, {"result": "done"})

                # Or override with custom context
                await self.peers.respond(message, {"result": "done"},
                                         context={"status": "completed"})
        """
        if not message.correlation_id:
            self._logger.warning("Cannot respond: message has no correlation_id")
            return False

        # Find target agent
        target_agent = self._resolve_target(message.sender)
        if not target_agent:
            self._logger.warning(f"Cannot respond: sender '{message.sender}' not found")
            return False

        # Auto-propagate context from request if not overridden
        response_context = context if context is not None else message.context

        outgoing = OutgoingMessage(
            target=message.sender,
            type=MessageType.RESPONSE,
            data=response,
            correlation_id=message.correlation_id,
            sender=self._agent_id,
            sender_node=self._node_id,
            context=response_context
        )

        return await self._send_message(target_agent, outgoing)

    async def broadcast(
        self,
        message: Dict[str, Any],
        context: Optional[Dict[str, Any]] = None
    ) -> int:
        """
        Broadcast notification to ALL peers.

        Args:
            message: Message payload to broadcast
            context: Optional metadata (mission_id, priority, trace_id, etc.)

        Returns:
            Number of peers successfully notified

        Example:
            count = await self.peers.broadcast({
                "event": "status_update",
                "status": "completed"
            }, context={"mission_id": "abc123"})
            print(f"Notified {count} peers")
        """
        count = 0
        for peer in self.discover():
            if await self.notify(peer.role, message, context=context):
                count += 1
        return count

    # ─────────────────────────────────────────────────────────────────
    # ASYNC REQUEST PATTERN
    # ─────────────────────────────────────────────────────────────────

    async def ask_async(
        self,
        target: str,
        message: Dict[str, Any],
        timeout: float = 120.0,
        context: Optional[Dict[str, Any]] = None
    ) -> str:
        """
        Send a request asynchronously without blocking for response.

        Unlike request(), this method returns immediately with a request_id.
        Use check_inbox() to retrieve the response later.

        Args:
            target: Target agent role or agent_id
            message: Request payload
            timeout: Max time to keep request active (default: 120s)
            context: Optional context metadata

        Returns:
            Request ID to use with check_inbox()

        Raises:
            ValueError: If target not found or send fails

        Example:
            # Fire off multiple requests in parallel
            request_ids = []
            for analyst in analysts:
                req_id = await self.peers.ask_async(analyst, {"question": "..."})
                request_ids.append(req_id)

            # Do other work...
            await process_other_tasks()

            # Collect responses later
            for req_id in request_ids:
                response = await self.peers.check_inbox(req_id, timeout=5)
                if response:
                    results.append(response)
        """
        target_agent = self._resolve_target(target)
        if not target_agent:
            raise ValueError(f"No peer found for target: {target}")

        # Generate correlation ID
        correlation_id = f"async-{uuid4().hex[:12]}"

        # Create outgoing message
        outgoing = OutgoingMessage(
            target=target,
            type=MessageType.REQUEST,
            data=message,
            correlation_id=correlation_id,
            sender=self._agent_id,
            sender_node=self._node_id,
            context=context
        )

        # Initialize inbox slot
        self._async_inbox[correlation_id] = None
        self._async_requests[correlation_id] = {
            'target': target,
            'sent_at': time.time(),
            'timeout': timeout
        }

        # Create future for async response handling (use running loop — this is an async method)
        response_future: asyncio.Future = asyncio.get_running_loop().create_future()
        self._pending_requests[correlation_id] = response_future

        # Setup background task to move response to inbox
        asyncio.create_task(
            self._async_response_handler(correlation_id, response_future, timeout)
        )

        # Send request
        sent = await self._send_message(target_agent, outgoing)
        if not sent:
            # Cleanup on send failure
            self._async_inbox.pop(correlation_id, None)
            self._async_requests.pop(correlation_id, None)
            self._pending_requests.pop(correlation_id, None)
            raise ValueError(f"Failed to send async request to {target}")

        self._logger.debug(f"Sent async request {correlation_id} to {target}")
        return correlation_id

    async def _async_response_handler(
        self,
        correlation_id: str,
        future: asyncio.Future,
        timeout: float
    ):
        """Background handler that moves response to inbox when received."""
        try:
            response = await asyncio.wait_for(future, timeout=timeout)
            self._async_inbox[correlation_id] = response
            self._logger.debug(f"Async response received for {correlation_id}")
        except asyncio.TimeoutError:
            self._async_inbox[correlation_id] = None  # Mark as timed out
            self._logger.debug(f"Async request {correlation_id} timed out")
        except asyncio.CancelledError:
            self._async_inbox.pop(correlation_id, None)
        finally:
            self._pending_requests.pop(correlation_id, None)

    async def check_inbox(
        self,
        request_id: str,
        timeout: float = 0.0,
        remove: bool = True
    ) -> Optional[Dict[str, Any]]:
        """
        Check for a response to an async request.

        Args:
            request_id: The ID returned by ask_async()
            timeout: How long to wait for response (0 = don't wait, return immediately)
            remove: Remove from inbox after reading (default: True)

        Returns:
            Response data dict if available, None if not ready or timed out

        Example:
            # Non-blocking check
            response = await self.peers.check_inbox(request_id)

            # Wait up to 5 seconds
            response = await self.peers.check_inbox(request_id, timeout=5)
        """
        if request_id not in self._async_inbox:
            self._logger.debug(f"Request {request_id} not found in inbox")
            return None

        # If response already available
        response = self._async_inbox.get(request_id)
        if response is not None:
            if remove:
                self._async_inbox.pop(request_id, None)
                self._async_requests.pop(request_id, None)
            return response

        # If no timeout, return None immediately
        if timeout <= 0:
            return None

        # Wait for response with timeout
        start_time = time.time()
        while time.time() - start_time < timeout:
            await asyncio.sleep(0.1)  # Check every 100ms
            response = self._async_inbox.get(request_id)
            if response is not None:
                if remove:
                    self._async_inbox.pop(request_id, None)
                    self._async_requests.pop(request_id, None)
                return response

        return None

    def get_pending_async_requests(self) -> List[Dict[str, Any]]:
        """
        Get list of pending async requests.

        Returns:
            List of dicts with request_id, target, sent_at, timeout

        Example:
            pending = self.peers.get_pending_async_requests()
            for req in pending:
                print(f"Waiting for {req['target']} since {req['sent_at']}")
        """
        return [
            {
                'request_id': req_id,
                **metadata
            }
            for req_id, metadata in self._async_requests.items()
        ]

    def clear_inbox(self, request_id: Optional[str] = None):
        """
        Clear async request inbox.

        Args:
            request_id: Specific request to clear, or None to clear all
        """
        if request_id:
            self._async_inbox.pop(request_id, None)
            self._async_requests.pop(request_id, None)
        else:
            self._async_inbox.clear()
            self._async_requests.clear()

    # ─────────────────────────────────────────────────────────────────
    # TOOL ADAPTER
    # ─────────────────────────────────────────────────────────────────

    def as_tool(self) -> 'PeerTool':
        """
        Get LLM tool adapter for this PeerClient.

        Returns a PeerTool that wraps this client, providing:
        - Tool definitions for LLM injection
        - Tool execution dispatch

        Returns:
            PeerTool instance

        Example:
            # In your agent
            tools = [SearchTool(), self.peers.as_tool()]
            response = llm.chat(task, tools=[t.schema for t in tools])
        """
        from .peer_tool import PeerTool
        return PeerTool(self)

    # ─────────────────────────────────────────────────────────────────
    # COGNITIVE CONTEXT (for LLM prompts)
    # ─────────────────────────────────────────────────────────────────

    def get_cognitive_context(
        self,
        format: str = "markdown",
        include_capabilities: bool = True,
        include_description: bool = True,
        tool_name: str = "ask_peer"
    ) -> str:
        """
        Generate a prompt-ready description of available mesh peers.

        Bridges the gap between the Network Layer (who is connected)
        and the Cognitive Layer (who the LLM should know about).

        This enables dynamic system prompts that automatically update
        as peers join or leave the mesh, eliminating hardcoded peer names.

        Args:
            format: Output format - "markdown", "json", or "text"
            include_capabilities: Include peer capabilities in output
            include_description: Include peer descriptions in output
            tool_name: Name of the tool for peer communication

        Returns:
            Formatted string suitable for inclusion in system prompts

        Example - Basic Usage:
            system_prompt = BASE_PROMPT + "\\n\\n" + self.peers.get_cognitive_context()

        Example - Output (markdown):
            ## AVAILABLE MESH PEERS

            You are part of a multi-agent mesh. The following peers are available:

            - **analyst** (`agent-analyst-abc123`)
              - Capabilities: analysis, charting, reporting
              - Description: Analyzes data and generates insights

            - **scout** (`agent-scout-def456`)
              - Capabilities: research, reconnaissance
              - Description: Gathers information from external sources

            Use the `ask_peer` tool to delegate tasks to these specialists.
        """
        peers = self.list_peers()

        if not peers:
            return "No other agents are currently available in the mesh."

        if format == "json":
            return self._format_cognitive_json(peers)
        elif format == "text":
            return self._format_cognitive_text(peers, include_capabilities, tool_name)
        else:  # markdown (default)
            return self._format_cognitive_markdown(
                peers, include_capabilities, include_description, tool_name
            )

    def _format_cognitive_markdown(
        self,
        peers: List[Dict[str, Any]],
        include_capabilities: bool,
        include_description: bool,
        tool_name: str
    ) -> str:
        """Format peers as markdown for LLM consumption."""
        lines = [
            "## AVAILABLE MESH PEERS",
            "",
            "You are part of a multi-agent mesh. The following peers are available for collaboration:",
            ""
        ]

        for peer in peers:
            role = peer.get("role", "unknown")
            agent_id = peer.get("agent_id", "unknown")
            capabilities = peer.get("capabilities", [])
            description = peer.get("description", "")

            # Role line with agent ID
            lines.append(f"- **{role}** (`{agent_id}`)")

            # Capabilities
            if include_capabilities and capabilities:
                lines.append(f"  - Capabilities: {', '.join(capabilities)}")

            # Description
            if include_description:
                desc = description if description else f"Specialist in {role} tasks"
                lines.append(f"  - Description: {desc}")

            lines.append("")  # Blank line between peers

        # Usage instructions
        lines.append(f"Use the `{tool_name}` tool to delegate tasks to these specialists.")
        lines.append("When delegating, be specific about what you need and provide relevant context.")

        return "\n".join(lines)

    def _format_cognitive_text(
        self,
        peers: List[Dict[str, Any]],
        include_capabilities: bool,
        tool_name: str
    ) -> str:
        """Format peers as plain text for simpler LLM contexts."""
        lines = ["Available Peers:"]

        for peer in peers:
            role = peer.get("role", "unknown")
            capabilities = peer.get("capabilities", [])

            if include_capabilities and capabilities:
                lines.append(f"- {role}: {', '.join(capabilities)}")
            else:
                lines.append(f"- {role}")

        lines.append(f"\nUse {tool_name} tool to communicate with peers.")

        return "\n".join(lines)

    def _format_cognitive_json(self, peers: List[Dict[str, Any]]) -> str:
        """Format peers as JSON string for structured LLM contexts."""
        import json
        return json.dumps({
            "available_peers": [
                {
                    "role": p.get("role"),
                    "agent_id": p.get("agent_id"),
                    "capabilities": p.get("capabilities", [])
                }
                for p in peers
            ],
            "instruction": "Use ask_peer tool to communicate with these agents"
        }, indent=2)

    def build_system_prompt(self, base_prompt: str, **context_kwargs) -> str:
        """
        Build a complete system prompt with peer context appended.

        Convenience method that combines your base prompt with
        dynamic peer context.

        Args:
            base_prompt: Your base system prompt
            **context_kwargs: Arguments passed to get_cognitive_context()
                - format: "markdown", "json", or "text"
                - include_capabilities: bool
                - include_description: bool
                - tool_name: str

        Returns:
            Complete system prompt with peer awareness

        Example:
            # Simple usage
            prompt = self.peers.build_system_prompt("You are a helpful analyst.")

            # With options
            prompt = self.peers.build_system_prompt(
                "You are a data processor.",
                include_capabilities=True,
                include_description=False
            )

            # Use in LLM call
            response = await llm.chat(
                messages=[{"role": "system", "content": prompt}, ...],
                tools=[self.peers.as_tool().schema]
            )
        """
        context = self.get_cognitive_context(**context_kwargs)
        return f"{base_prompt}\n\n{context}"

    # ─────────────────────────────────────────────────────────────────
    # MESSAGING - RECEIVE
    # ─────────────────────────────────────────────────────────────────

    async def receive(self, timeout: float = None) -> Optional[IncomingMessage]:
        """
        Receive the next incoming message.

        Args:
            timeout: Max seconds to wait (None = wait forever)

        Returns:
            IncomingMessage if received, None if timeout

        Example:
            # Wait up to 5 seconds for a message
            message = await self.peers.receive(timeout=5)
            if message:
                print(f"Got message from {message.sender}: {message.data}")
        """
        try:
            if timeout is not None:
                message = await asyncio.wait_for(
                    self._message_queue.get(),
                    timeout=timeout
                )
            else:
                message = await self._message_queue.get()

            return message

        except asyncio.TimeoutError:
            return None

    def has_pending_messages(self) -> bool:
        """Check if there are messages waiting to be received."""
        return not self._message_queue.empty()

    # ─────────────────────────────────────────────────────────────────
    # INTERNAL METHODS
    # ─────────────────────────────────────────────────────────────────

    def _resolve_target(self, target: str):
        """
        Resolve target string to agent (local or remote).

        Checks:
        1. Local registry (same mesh)
        2. Remote registry (other nodes via P2P coordinator)

        Args:
            target: Role name or agent_id

        Returns:
            Agent instance (local) or RemoteAgentProxy (remote), or None
        """
        # 1. Try local registry first (by role)
        agents = self._agent_registry.get(target, [])
        if agents:
            return agents[0]

        # 2. Try local agent_id match
        for role_name, agents in self._agent_registry.items():
            for agent in agents:
                if agent.agent_id == target:
                    return agent

        # 3. Try remote agents via coordinator
        if self._coordinator:
            remote_info = self._coordinator.get_remote_agent(target)
            if remote_info:
                return RemoteAgentProxy(
                    agent_id=remote_info.get('agent_id', target),
                    role=remote_info.get('role', target),
                    node_id=remote_info.get('node_id', ''),
                    capabilities=remote_info.get('capabilities', [])
                )

        return None

    async def _send_message(self, target_agent, message: OutgoingMessage) -> bool:
        """
        Send message to target agent via coordinator.

        For local agents (same mesh), delivers directly to their queue.
        For remote agents (RemoteAgentProxy), sends via P2P coordinator.
        """
        try:
            # Check if it's a RemoteAgentProxy (remote agent on another node)
            if isinstance(target_agent, RemoteAgentProxy):
                # Remote delivery via P2P coordinator
                if self._coordinator:
                    msg_type = f"PEER_{message.type.value.upper()}"
                    payload = {
                        'sender': message.sender,
                        'sender_node': message.sender_node,
                        'target': target_agent.agent_id,
                        'target_role': target_agent.role,
                        'data': message.data,
                        'correlation_id': message.correlation_id,
                        'timestamp': message.timestamp,
                        'context': message.context
                    }
                    result = await self._coordinator._send_p2p_message(
                        target_agent.node_id,
                        msg_type,
                        payload
                    )
                    if result:
                        self._logger.debug(
                            f"Sent {message.type.value} to remote agent "
                            f"{target_agent.role}@{target_agent.node_id}"
                        )
                    return result
                self._logger.warning("No coordinator available for remote delivery")
                return False

            # Check if target has a peer client (local agent)
            if hasattr(target_agent, 'peers') and target_agent.peers:
                # Direct local delivery
                incoming = IncomingMessage(
                    sender=message.sender,
                    sender_node=message.sender_node,
                    type=message.type,
                    data=message.data,
                    correlation_id=message.correlation_id,
                    timestamp=message.timestamp,
                    context=message.context
                )
                await target_agent.peers._deliver_message(incoming)
                self._logger.debug(
                    f"Delivered {message.type.value} to local agent {target_agent.agent_id}"
                )
                return True

            # Fallback: Remote delivery via P2P coordinator
            if self._coordinator:
                msg_type = f"PEER_{message.type.value.upper()}"
                payload = {
                    'sender': message.sender,
                    'sender_node': message.sender_node,
                    'target': message.target,
                    'data': message.data,
                    'correlation_id': message.correlation_id,
                    'timestamp': message.timestamp,
                    'context': message.context
                }
                node_id = getattr(target_agent, 'node_id', None) or self._node_id
                return await self._coordinator._send_p2p_message(
                    node_id,
                    msg_type,
                    payload
                )

            self._logger.warning("No delivery mechanism available")
            return False

        except Exception as e:
            self._logger.error(f"Failed to send message: {e}")
            return False

    async def _deliver_message(self, message: IncomingMessage):
        """
        Deliver an incoming message to this client.

        Called by other PeerClients (local) or coordinator (remote).
        """
        # Check if this is a response to a pending request
        if message.type == MessageType.RESPONSE and message.correlation_id:
            future = self._pending_requests.get(message.correlation_id)
            if future and not future.done():
                fut_loop = future.get_loop()
                try:
                    running_loop = asyncio.get_running_loop()
                except RuntimeError:
                    running_loop = None
                if running_loop is not None and running_loop is fut_loop:
                    future.set_result(message.data)
                else:
                    # Called from a different event loop (e.g. SWIM thread) —
                    # schedule the set_result on the future's own loop
                    fut_loop.call_soon_threadsafe(future.set_result, message.data)
                self._logger.debug(
                    f"Delivered response for {message.correlation_id}"
                )
                return

        # Otherwise queue for receive()
        await self._message_queue.put(message)
        self._logger.debug(
            f"Queued {message.type.value} from {message.sender}"
        )
