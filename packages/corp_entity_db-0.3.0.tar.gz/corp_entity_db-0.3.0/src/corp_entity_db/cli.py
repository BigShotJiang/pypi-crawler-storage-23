"""CLI entry point — delegates to commands package."""

from .commands import main

if __name__ == "__main__":
    main()
