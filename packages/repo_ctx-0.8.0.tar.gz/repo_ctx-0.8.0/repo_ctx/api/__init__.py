"""FastAPI application for repo-ctx.

This module provides the REST API for the repo-ctx service.
"""

from repo_ctx.api.app import app

__all__ = ["app"]
