"""API version information."""

VERSION = "2.0.0"
