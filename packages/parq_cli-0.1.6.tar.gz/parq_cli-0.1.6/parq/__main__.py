"""
Entry point for running parq as a module.
Allows execution via: python -m parq
"""

from parq.cli import app

if __name__ == "__main__":
    app()
