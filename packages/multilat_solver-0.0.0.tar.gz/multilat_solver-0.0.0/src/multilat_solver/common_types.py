"""Common types for the MultiLat Localization System."""

from enum import Enum


class CalibrationType(str, Enum):
    """Calibration type enumeration."""

    NONE = "none"
    LINEAR = "linear"
    QUADRATIC = "quadratic"
    CUBIC = "cubic"


class MessageType(str, Enum):
    """Output message type enumeration."""

    GPS = "gps"
    POSITION = "position"
    BOTH = "both"
