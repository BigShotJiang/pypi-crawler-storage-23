# MultiLat Localizer

Universal multilateration localization with pluggable input/output adapters for distance measurements and position output.

**Version:** 1.0.0

## Features

- **Inputs:** Serial (UWB/RTK-DW1000), MQTT, UDP, File; custom adapters via `with_input()`
- **Outputs:** MAVLink, MAVROS (ROS2), UDP, File, Console; multiple outputs at once
- **Calibration:** None, Linear, Quadratic, Cubic
- **GPS:** ENU → GPS via pymap3d; frequency throttling; message type (GPS / Position / Both)
- **Config:** Python API only (no config files)

## Installation

```bash
pip install multilat_solver
```

Optional: `pip install multilat_solver[mqtt]` (MQTT), `multilat_solver[ros2]` (ROS2), `.[dev]` (development).

## Quick Start

```python
from multilat_solver import ConfigBuilder, MultiLatLocalizerApp, CalibrationType
from multilat_solver.common_types import MessageType
from multilat_solver.output_adapters import ConsoleOutputAdapter
import logging

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

config = (ConfigBuilder()
    .with_localization(
        anchor_positions={1: (0, 0, 0), 2: (3, 0, 0), 3: (0, 3, 0)},
        calibration_type=CalibrationType.LINEAR,
        calibration_params=[1.0, 0.0],
    )
    .with_serial_input(port="/dev/ttyUSB0", baud=460800)
    .with_output("console", ConsoleOutputAdapter(format="human", message_type=MessageType.BOTH, frequency=10))
    .build())

app = MultiLatLocalizerApp(config)
app.run()
```

## Documentation

- [Configuration](docs/configuration.md) · [Input adapters](docs/input-adapters.md) · [Output adapters](docs/output-adapters.md)
- [Calibration](docs/calibration.md) · [Examples](docs/examples.md) · [Custom adapters](docs/extension.md)

## Adapters

| Input   | Description                    |
|---------|--------------------------------|
| Serial  | Binary protocol (UWB/RTK-DW1000) |
| MQTT    | JSON over MQTT `[mqtt]`        |
| UDP     | JSON over UDP                  |
| File    | JSON file polling              |

| Output  | Description                    |
|---------|--------------------------------|
| MAVLink | ArduPilot/PX4                  |
| MAVROS  | ROS2 topics `[ros2]`           |
| UDP     | JSON over UDP                  |
| File    | JSONL file                     |
| Console | Human or JSON                  |

## Examples

- `examples/basic_usage.py` — Serial in, console/file/MAVLink out
- `examples/multi_output.py` — Multiple outputs
- `examples/mavlink_input_with_sim.py` — MAVLink distances in + simulator
- `examples/uavcan_input_mavlink_output.py` — Custom UAVCAN input → MAVLink out

## Development

```bash
git clone https://github.com/Innopolis-UAV-Team/multilat_solver
cd multilat_solver
pip install -e ".[dev]"
pytest
```

Layout: `src/multilat_solver/` — `core.py`, `config.py`, `app.py`, `input_adapters.py`, `output_adapters.py`, `common_types.py`.
