"""Tests for SessionManager"""

import pytest
import time
from monkai_trace.session_manager import SessionManager


def test_session_creation():
    """Test session creation"""
    manager = SessionManager(inactivity_timeout=60)
    
    session1 = manager.get_or_create_session("user1", "test-ns")
    assert session1.startswith("test-ns-user1-")
    
    # Same user within timeout should return same session
    session2 = manager.get_or_create_session("user1", "test-ns")
    assert session1 == session2


def test_session_timeout():
    """Test session expires after timeout"""
    manager = SessionManager(inactivity_timeout=1)  # 1 segundo
    
    session1 = manager.get_or_create_session("user1", "test-ns")
    time.sleep(2)  # Esperar expirar
    
    session2 = manager.get_or_create_session("user1", "test-ns")
    assert session1 != session2  # Nova sessão criada


def test_activity_update():
    """Test activity update extends session"""
    manager = SessionManager(inactivity_timeout=2)
    
    session1 = manager.get_or_create_session("user1", "test-ns")
    time.sleep(1)
    manager.update_activity("user1")
    time.sleep(1)
    
    # Ainda dentro do timeout devido ao update_activity
    session2 = manager.get_or_create_session("user1", "test-ns")
    assert session1 == session2


def test_force_new_session():
    """Test force_new parameter"""
    manager = SessionManager(inactivity_timeout=60)
    
    session1 = manager.get_or_create_session("user1", "test-ns")
    session2 = manager.get_or_create_session("user1", "test-ns", force_new=True)
    
    assert session1 != session2


def test_multi_user_isolation():
    """Test multiple users have separate sessions"""
    manager = SessionManager(inactivity_timeout=60)
    
    session1 = manager.get_or_create_session("user1", "test-ns")
    session2 = manager.get_or_create_session("user2", "test-ns")
    
    assert session1 != session2
    assert "user1" in session1
    assert "user2" in session2


def test_close_session():
    """Test explicit session closure"""
    manager = SessionManager(inactivity_timeout=60)
    
    session1 = manager.get_or_create_session("user1", "test-ns")
    manager.close_session("user1")
    
    # Should create new session after closing
    session2 = manager.get_or_create_session("user1", "test-ns")
    assert session1 != session2


def test_cleanup_expired():
    """Test automatic cleanup of expired sessions"""
    manager = SessionManager(inactivity_timeout=1)
    
    # Create multiple sessions
    manager.get_or_create_session("user1", "test-ns")
    manager.get_or_create_session("user2", "test-ns")
    manager.get_or_create_session("user3", "test-ns")
    
    time.sleep(2)  # Wait for expiration
    
    # Cleanup should remove all expired sessions
    removed = manager.cleanup_expired()
    assert removed == 3


def test_get_session_info():
    """Test session info retrieval"""
    manager = SessionManager(inactivity_timeout=60)
    
    session_id = manager.get_or_create_session("user1", "test-ns")
    
    info = manager.get_session_info("user1")
    assert info is not None
    assert info['session_id'] == session_id
    assert info['duration'] >= 0
    assert info['inactive_for'] >= 0
    
    # Non-existent user
    info = manager.get_session_info("nonexistent")
    assert info is None


def test_session_id_format():
    """Test session ID format"""
    manager = SessionManager(inactivity_timeout=60)
    
    session_id = manager.get_or_create_session("user123", "my-namespace")
    
    # Format: {namespace}-{user_id}-{YYYYMMDD}-{HHMMSS}-{ffffff}
    assert session_id.startswith("my-namespace-user123-")
    
    # Extract timestamp portion after prefix
    prefix = "my-namespace-user123-"
    timestamp_part = session_id[len(prefix):]
    assert len(timestamp_part) == 22  # YYYYMMDD-HHMMSS-ffffff


# ==================== PersistentSessionManager Tests ====================

class MockMonkAIClient:
    """Mock client for testing PersistentSessionManager"""
    
    def __init__(self, responses=None):
        self.responses = responses or []
        self._call_count = 0
        self.calls = []
    
    def get_or_create_session(self, namespace, user_id, inactivity_timeout=120, force_new=False):
        self.calls.append({
            'namespace': namespace,
            'user_id': user_id,
            'inactivity_timeout': inactivity_timeout,
            'force_new': force_new
        })
        if self._call_count < len(self.responses):
            resp = self.responses[self._call_count]
            self._call_count += 1
            if isinstance(resp, Exception):
                raise resp
            return resp
        # Default response
        self._call_count += 1
        return {'session_id': f'{namespace}-{user_id}-default', 'reused': False}


def test_persistent_session_reuses_from_backend():
    """Test PersistentSessionManager reuses sessions from backend"""
    from monkai_trace.session_manager import PersistentSessionManager
    
    mock_client = MockMonkAIClient(responses=[
        {'session_id': 'ns-user1-20260213-100000', 'reused': False},
        {'session_id': 'ns-user1-20260213-100000', 'reused': True},
    ])
    
    manager = PersistentSessionManager(client=mock_client, inactivity_timeout=300)
    
    # First call: creates new session via backend
    session1 = manager.get_or_create_session("user1", "ns")
    assert session1 == "ns-user1-20260213-100000"
    
    # Second call within timeout: should use local cache (no backend call)
    session2 = manager.get_or_create_session("user1", "ns")
    assert session1 == session2
    assert len(mock_client.calls) == 1  # Only 1 backend call, second used cache


def test_persistent_session_fallback_on_error():
    """Test PersistentSessionManager falls back to in-memory on backend error"""
    from monkai_trace.session_manager import PersistentSessionManager
    
    mock_client = MockMonkAIClient(responses=[
        Exception("Connection refused"),
    ])
    
    manager = PersistentSessionManager(client=mock_client, inactivity_timeout=60)
    
    # Should fallback to in-memory session creation
    session = manager.get_or_create_session("user1", "ns")
    assert session.startswith("ns-user1-")
    assert len(mock_client.calls) == 1


def test_persistent_session_force_new():
    """Test PersistentSessionManager with force_new bypasses cache"""
    from monkai_trace.session_manager import PersistentSessionManager
    
    mock_client = MockMonkAIClient(responses=[
        {'session_id': 'ns-user1-session1', 'reused': False},
        {'session_id': 'ns-user1-session2', 'reused': False},
    ])
    
    manager = PersistentSessionManager(client=mock_client, inactivity_timeout=300)
    
    session1 = manager.get_or_create_session("user1", "ns")
    session2 = manager.get_or_create_session("user1", "ns", force_new=True)
    
    assert session1 != session2
    assert len(mock_client.calls) == 2  # Both hit backend


def test_persistent_session_expired_cache_hits_backend():
    """Test PersistentSessionManager queries backend when local cache expires"""
    from monkai_trace.session_manager import PersistentSessionManager
    
    mock_client = MockMonkAIClient(responses=[
        {'session_id': 'ns-user1-session1', 'reused': False},
        {'session_id': 'ns-user1-session1', 'reused': True},
    ])
    
    manager = PersistentSessionManager(client=mock_client, inactivity_timeout=1)
    
    session1 = manager.get_or_create_session("user1", "ns")
    time.sleep(2)  # Wait for local cache to expire
    
    session2 = manager.get_or_create_session("user1", "ns")
    assert session2 == "ns-user1-session1"  # Backend returned same session
    assert len(mock_client.calls) == 2  # Both hit backend
