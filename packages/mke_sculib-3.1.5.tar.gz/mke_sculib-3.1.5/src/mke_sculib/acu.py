import socket
import struct
import threading
import enum
import time
from astropy.time import Time

from typing import Dict, List

from dataclasses import dataclass, field

PORT_COMMAND = 8000
PORT_STATUS = 8001

class CommandSource(enum.IntEnum):
    LMC = 1
    ODC_Engineering_GUI = 2
    ODC_SCU = 3
    #HHD = 4

# Define the module identifiers as an int enum
class Module(enum.IntEnum):
    VOID = 0  # VOID
    AZ = 1  # Azimuth Axis Modules
    EL = 2  # Elevation Axis Modules
    FI = 3  # Feed Indexer Modules
    TIM = 10  # Time Controller
    CMD = 20  # Command Arbiter
    STPA = 21  # Stow Pin Controller Azimuth
    STPE = 22  # Stow Pin Controller Elevation
    SAF = 25  # Safety System Controller
    TRX = 30  # Tracking Controller
    POI = 40  # Pointing Controller
    PWR = 50  # Power Distribution Controller
    DMC = 100  # Dish Management Controller

class dtypes(enum.Enum):
    INT8 = '<b'
    INT16 = '<h'
    INT32 = '<i'
    UINT8 = '<B'
    UINT16 = '<H'
    UINT32 = '<I'
    WORD = '<H'
    DWORD = '<I'
    REAL32 = '<f'
    REAL64 = '<d'
    CHAR = '<{}s'


def pack_d(data_type, data):
    # Pack the data into the byte string
    if data_type == dtypes.CHAR:
        raise NotImplementedError("Need to implement this still!")
        # For character strings, we need to specify the length of the string
        packed_data = struct.pack(data_type.value.format(len(data)), data.encode())
    else:
        if data_type in {dtypes.REAL32, dtypes.REAL64}:
            d = float(data)
        else:
            d = int(data)
        packed_data = struct.pack(data_type.value, d)
    return packed_data



class bData:
    def __init__(self, dtype:dtypes, value):
        self.dtype = dtype
        self.value = value

    def pack(self) -> bytes:
        return pack_d(self.dtype, self.value)
    
    def __len__(self):
        return len(self.pack())
    
    @staticmethod
    def INT8(value):
        return bData(dtypes.INT8, value)

    @staticmethod
    def INT16(value):
        return bData(dtypes.INT16, value)

    @staticmethod
    def INT32(value):
        return bData(dtypes.INT32, value)

    @staticmethod
    def UINT8(value):
        return bData(dtypes.UINT8, value)

    @staticmethod
    def UINT16(value):
        return bData(dtypes.UINT16, value)

    @staticmethod
    def UINT32(value):
        return bData(dtypes.UINT32, value)

    @staticmethod
    def WORD(value):
        return bData(dtypes.WORD, value)

    @staticmethod
    def DWORD(value):
        return bData(dtypes.DWORD, value)

    @staticmethod
    def REAL32(value):
        return bData(dtypes.REAL32, value)

    @staticmethod
    def REAL64(value):
        return bData(dtypes.REAL64, value)

    @staticmethod
    def CHAR(value, length):
        return bData(dtypes.CHAR.format(length), value)

    def __str__(self):
        return f'{self.dtype.name}({self.value})'
    
    def __repr__(self):
        return str(self)
    
def pack_payload(payload:List) -> bytes:
    if isinstance(payload, tuple) and len(payload) == 2 and isinstance(payload[0], dtypes):
        return pack_d(*payload)
    
    packed_commands = b''
    # Pack each command into the byte string
    for data_tpl in payload:
        if isinstance(data_tpl, bData):
            packed_commands += data_tpl.pack()
        else:
            data_type, data = data_tpl
            packed_commands += pack_d(data_type, data)

    return packed_commands

# start_flag_b = pack_d(*start_flag)
# end_flag_b = pack_d(*end_flag)


START_FLAG = 0x1DFCCF1A
END_FLAG = 0xA1FCCFD1

class Command:
    start_flag = bData.UINT32(START_FLAG)
    end_flag = bData.UINT32(END_FLAG)

    start_flag_b = bData.UINT32(START_FLAG).pack()
    end_flag_b = bData.UINT32(END_FLAG).pack()
    LEN_STARTEND = 12 # 4 bytes per flag + 4 bytes for length itself

    def __init__(self, module, command_id, data, source = CommandSource.LMC):
        assert isinstance(data, list), f'data MUST be list of bData, but was {type(data)=} {data=}'

        self.module = Module(module) if isinstance(module, int) else module
        self.command_id = command_id
        self.data = [] if data is None else data
        self.source = source

    def to_list(self, full = False):
        payload = [
            bData.REAL64(Time.now().mjd),
            bData.UINT32(self.source.value),
            bData.UINT16(self.module.value), 
            bData.UINT16(self.command_id),
            *self.data
        ]
        if full:
            n = sum([len(b) for b in payload]) + Command.LEN_STARTEND
            payload = [Command.start_flag, bData.UINT32(n), *payload, Command.end_flag]

        return payload
    
    def encode(self):
        payload = self.to_list()
        n = sum([len(b) for b in payload]) + Command.LEN_STARTEND
        data_b = pack_payload(payload)
        n_b = bData.UINT32(n).pack()
        ret = Command.start_flag_b + n_b + data_b + Command.end_flag_b
        return ret

class AcuCommandInterface():
    def __init__(self, ip, port = PORT_COMMAND):
        self.remote_ip = ip
        self.port = port
        self.socket = None

    def __enter__(self):
        print('connecting...')
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.connect((self.remote_ip, self.port))
        print('connecting...DONE')
        return self
    
    def __exit__(self, *args, **kwargs):
        print('closing...')
        self.socket.close()
        print('closing...DONE')
    def _test_socket(self):
        if self.socket is None:
            raise Exception("AcuCommandInterface can only be used with a contect manager!")

    def send_cmd(self, command:Command):
        print('sending....')
        self._test_socket()
        self.socket.sendall(command.encode())
        print('sending....DONE')
        print('receiving...')
        d = self.socket.recv(8)
        print('receiving...DONE')
        return d

# def start_threaded():
#     # Create threads for sending commands and receiving status updates
#     commands_thread = threading.Thread(target=send_commands)
#     status_thread = threading.Thread(target=receive_status_updates)

#     # Start the threads
#     commands_thread.start()
#     status_thread.start()

#     # Wait for both threads to finish
#     commands_thread.join()
#     status_thread.join()

#print(len(pack_payload([start_flag])))

auth_take = Command(Module.CMD, 10,  [bData.UINT16(1)])
auth_release = Command(Module.CMD, 10, [bData.UINT16(2)])

print(auth_take.to_list(1))
print(auth_take.encode())
print(auth_release.to_list(1))
print(auth_release.encode())

with AcuCommandInterface('10.96.71.10') as dish:
    print('auth_take', dish.send_cmd(auth_take))
    time.sleep(20)
    print('auth_release', dish.send_cmd(auth_release))