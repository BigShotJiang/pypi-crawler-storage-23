<!-- ---
!-- Timestamp: 2025-05-17 04:54:09
!-- Author: ywatanabe
!-- File: /ssh:ywatanabe@sp:/home/ywatanabe/.dotfiles/.claude/guidelines/README.md
!-- --- -->

This directory contains guidelines for agents to understand user's intentions.

<!-- EOF -->
