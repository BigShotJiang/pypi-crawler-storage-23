<!-- ---
!-- Timestamp: 2025-06-07 02:32:20
!-- Author: ywatanabe
!-- File: /ssh:ywatanabe@sp:/home/ywatanabe/.claude/to_claude/guidelines/programming_common/IMPORTANT-regression-prevention.md
!-- --- -->

## Regression Prevention
- Check for regressions after any implementation changes
- Use test codes and example codes for validation
  - ./tests/run_tests.sh
  - ./examples/run_examples.sh
- Maintain dedicated testing attitude

<!-- EOF -->
