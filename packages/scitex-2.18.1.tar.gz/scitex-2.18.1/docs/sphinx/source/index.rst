SciTeX Documentation
====================

SciTeX is a scientific computing and visualization library for Python.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   installation
   quickstart
   gallery
   api/index

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
