import os
import shutil
import tempfile
import zipfile
from datetime import datetime
import subprocess
import pathspec
from rich.console import Console
from rich.table import Table
from rich import box

console = Console()

EXCLUDE_DIRS = {
    ".git",
    "node_modules",
    "__pycache__",
    "venv",
    ".venv",
    "env",
    ".idea",
    ".vscode",
    "dist"
}

EXCLUDE_FILES = {
    ".env"
}

def should_exclude(name):
    return name in EXCLUDE_DIRS or name in EXCLUDE_FILES

def get_directory_size(path):
    total = 0
    for root, _, files in os.walk(path):
        for file in files:
            full_path = os.path.join(root, file)
            if os.path.isfile(full_path):
                total += os.path.getsize(full_path)
    return total

def format_size(size_bytes):
    for unit in ["B", "KB", "MB", "GB"]:
        if size_bytes < 1024:
            return f"{round(size_bytes, 2)} {unit}"
        size_bytes /= 1024
    return f"{round(size_bytes, 2)} TB"

def generate_env_example(project_path, temp_project):
    env_path = os.path.join(project_path, ".env")

    if not os.path.exists(env_path):
        return

    example_path = os.path.join(temp_project, ".env.example")

    with open(env_path, "r") as f:
        lines = f.readlines()

    cleaned = []
    for line in lines:
        line = line.strip()
        if not line or line.startswith("#"):
            continue

        if "=" in line:
            key = line.split("=")[0]
            cleaned.append(f"{key}=\n")

    with open(example_path, "w") as f:
        f.writelines(cleaned)

def create_snapshot(project_path, output_dir, build=False, dry_run=False):
    project_path = os.path.abspath(project_path)
    original_size = get_directory_size(project_path)
    gitignore_path = os.path.join(project_path, ".gitignore")
    spec = None

    config_path = os.path.join(project_path, ".snapclean.toml")

    if os.path.exists(config_path):
        import tomllib

        with open(config_path, "rb") as f:
            config = tomllib.load(f)

        build = config.get("build", build)
        output_dir = config.get("output", output_dir)
    if os.path.exists(gitignore_path):
        with open(gitignore_path) as f:
            spec = pathspec.PathSpec.from_lines("gitwildmatch", f)
    if build:
        print("Running build command...")
        subprocess.run(["npm", "run", "build"], cwd=project_path)

    with tempfile.TemporaryDirectory() as temp_dir:
        temp_project = os.path.join(temp_dir, "project_copy")
        removed_items = []

        def ignore_filter(directory, contents):
            ignored = []
            for item in contents:
                full_path = os.path.join(directory, item)
                rel_path = os.path.relpath(full_path, project_path)

                should_ignore = False

                if item in EXCLUDE_DIRS or item in EXCLUDE_FILES:
                    should_ignore = True

                if spec and spec.match_file(rel_path):
                    should_ignore = True

                if should_ignore:
                    ignored.append(item)
                    removed_items.append(full_path)

            return ignored
        shutil.copytree(
            project_path,
            temp_project,
            ignore=ignore_filter
        )

        generate_env_example(project_path, temp_project)

        os.makedirs(output_dir, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        zip_name = f"snapshot_{timestamp}.zip"
        zip_path = os.path.join(output_dir, zip_name)

        if dry_run:
            console.print("[bold magenta]Dry run mode enabled.[/bold magenta]")
            if removed_items:
                console.print("\n[bold yellow]Items that would be removed:[/bold yellow]")
                for item in removed_items:
                    console.print(f"[red]- {item}[/red]")
            else:
                console.print("\n[bold green]No items would be removed.[/bold green]")
            return
        
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
            for root, _, files in os.walk(temp_project):
                for file in files:
                    full_path = os.path.join(root, file)
                    rel_path = os.path.relpath(full_path, temp_project)
                    zipf.write(full_path, rel_path)
        print("\nRemoved items:")
        for item in removed_items:
            print(f"- {item}")
        print(f"Snapshot created: {zip_path}")
        snapshot_size = os.path.getsize(zip_path)

        reduction = 0
        if original_size > 0:
            reduction = 100 - ((snapshot_size / original_size) * 100)

        table = Table(title="Snapshot Summary", box=box.ROUNDED)

        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="green")

        table.add_row("Original size", format_size(original_size))
        table.add_row("Snapshot size", format_size(snapshot_size))
        table.add_row("Reduced by", f"{round(reduction, 2)}%")

        console.print(table)