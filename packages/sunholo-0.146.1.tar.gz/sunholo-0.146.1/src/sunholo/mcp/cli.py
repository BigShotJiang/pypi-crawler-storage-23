#   Copyright [2024] [Holosun ApS]
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.

"""
CLI for MCP server commands using FastMCP.
"""

# Import the FastMCP implementation
from .cli_fastmcp import cli_mcp, cli_mcp_bridge, setup_mcp_subparser

__all__ = ['cli_mcp', 'cli_mcp_bridge', 'setup_mcp_subparser']