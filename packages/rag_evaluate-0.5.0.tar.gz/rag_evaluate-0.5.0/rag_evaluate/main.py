from nltk.translate.bleu_score import corpus_bleu
from nltk.tokenize import word_tokenize, sent_tokenize
import nltk
from rouge_score import rouge_scorer
from bert_score import score

class RAG_Evaluator:

    def __init__(self):
        nltk.download('punkt_tab')
         
    def bleu_score(self, question, reference_answer, generated_answer):
        #tokenize the generated and reference text
        generated_text_tokens = word_tokenize(generated_answer.lower())
        reference_text_tokens = [word_tokenize(sentence) for sentence in sent_tokenize(reference_answer.lower())]

        #calculate the BLEU score
        bleu_score = corpus_bleu([reference_text_tokens], [generated_text_tokens], weights=(0,1,0,0))
        return {"BLEU":bleu_score}

    def rouge_score(self, question, reference_answer, generated_answer):
        scorer = rouge_scorer.RougeScorer(['rouge1', 'rougeL'], use_stemmer=True)
        rouge_scores = scorer.score(reference_answer, generated_answer)
        rouge_1 = rouge_scores['rouge1'].fmeasure
        rouge_L = rouge_scores['rougeL'].fmeasure
        return {"ROUGE-1":rouge_1, "ROUGE-L":rouge_L}

    def bert_score(self, question, reference_answer, generated_answer):
        P,R,F1 = score([generated_answer], [reference_answer], lang="en")
        P = P.mean().item()
        R = R.mean().item()
        F1 = F1.mean().item()
        return {"BERT P":P, "BERT R":R, "BERT F1":F1}