# DataCheck: The Linter for Data Contracts

[![PyPI version](https://img.shields.io/pypi/v/datacheck-cli.svg)](https://pypi.org/project/datacheck-cli/)
[![Python 3.10+](https://img.shields.io/badge/python-3.10%2B-blue.svg)](https://www.python.org/downloads/)
[![License: Apache 2.0](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)
[![Downloads](https://img.shields.io/pypi/dm/datacheck-cli.svg)](https://pypi.org/project/datacheck-cli/)

**Enforce deterministic data gates at the pipeline boundary. No servers. No side-effects. Just valid data.**

DataCheck is a CLI-first enforcement layer for the modern data stack. It brings the discipline of **Software Linting** to data engineering, allowing you to "Fail Fast" in CI/CD before bad data ever hits your warehouse.

## Why DataCheck?

* **SQL Pushdown:** For Snowflake, BigQuery, Redshift, PostgreSQL, and MySQL, validation runs as a single aggregate `SELECT`. We don't pull your data; we move the logic to the database.
* **Zero Infrastructure:** No databases to manage or SaaS accounts to pay for. It's a stateless binary that runs anywhere.
* **CI-Native:** Generates native **SARIF** output so data failures appear directly in your GitHub Security tab.
* **Schema Guard:** Capture a baseline and detect breaking changes (`schema compare`) with a single command.

## How it compares

| Feature | DataCheck | Great Expectations / SaaS |
| :--- | :--- | :--- |
| **Philosophy** | **Gatekeeper** (Block bad data) | **Reporter** (Find it later) |
| **Compute** | **Pushdown** (Zero Egress) | **Pull** (Expensive compute) |
| **Setup** | < 1 Minute | Hours / Days |
| **CI/CD** | Native SARIF / GitHub Action | Webhooks / APIs |

## Installation

```bash
pip install datacheck-cli
```

To install with support for a specific data source, use extras:

```bash
pip install datacheck-cli[postgresql]    # PostgreSQL
pip install datacheck-cli[mysql]         # MySQL
pip install datacheck-cli[snowflake]     # Snowflake
pip install datacheck-cli[bigquery]      # BigQuery
pip install datacheck-cli[redshift]      # Redshift
pip install datacheck-cli[s3]            # S3
pip install datacheck-cli[all]           # All data sources
```

## Quickstart

**Option 1 - Start from a template:**

```bash
datacheck config init --with-sample-data
datacheck config init --template ecommerce --with-sample-data
```

**Option 2 - Write manually.** Create a `sources.yaml` and `.datacheck.yaml` with your data source and validation rules:

```yaml
# sources.yaml
sources:
  orders:
    type: duckdb
    path: ./data/orders.csv
```

```yaml
# .datacheck.yaml
sources_file: sources.yaml
source: orders

checks:
  - name: id_check
    column: id
    rules:
      not_null: true
      unique: true

  - name: amount_check
    column: amount
    rules:
      not_null: true
      min: 0
      max: 10000
```

Run validation:

```bash
datacheck validate                          # auto-discover config
datacheck validate --config checks.yaml     # explicit config path
echo $?  # 1 if any error-severity rule fails
```

## CI/CD Integration

### GitHub Actions (with SARIF to Security tab)

```yaml
# .github/workflows/data-quality.yml
name: Data Quality Gate
on: [push, pull_request]

permissions:
  contents: read
  security-events: write

jobs:
  validate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: squrtech/datacheck-action@v1
        with:
          config: .datacheck.yaml
```

Or generate SARIF manually and upload to the GitHub Security tab:

```yaml
      - name: Run data quality gate
        run: |
          pip install datacheck-cli
          datacheck validate -c .datacheck.yaml --format sarif --output results.sarif

      - name: Upload SARIF
        uses: github/codeql-action/upload-sarif@v3
        if: always()
        with:
          sarif_file: results.sarif
```

### Apache Airflow

```python
from airflow_provider_datacheck.operators.datacheck import DataCheckOperator

validate_orders = DataCheckOperator(
    task_id="validate_orders",
    config_path="/config/orders.datacheck.yaml",
    source_name="production_db",
    table="orders",
    fail_on_error=True,
)
```

## Database and Cloud Sources

For databases and cloud storage, define named sources in a `sources.yaml` file:

```yaml
# sources.yaml
sources:
  production_db:
    type: postgresql
    host: ${DB_HOST}
    port: ${DB_PORT:-5432}
    database: ${DB_NAME}
    user: ${DB_USER}
    password: ${DB_PASSWORD}

  analytics_wh:
    type: snowflake
    account: ${SF_ACCOUNT}
    user: ${SF_USER}
    password: ${SF_PASSWORD}
    warehouse: ${SF_WAREHOUSE:-COMPUTE_WH}
    database: ${SF_DATABASE}
    schema: ${SF_SCHEMA:-PUBLIC}

  s3_data:
    type: s3
    bucket: ${S3_BUCKET}
    path: data/orders.csv
    region: ${AWS_REGION:-us-east-1}
    access_key: ${AWS_ACCESS_KEY_ID}
    secret_key: ${AWS_SECRET_ACCESS_KEY}
```

Reference in your config:

```yaml
# datacheck.yaml
sources_file: ./sources.yaml
source: production_db
table: orders
```

## Enforce Schema Contracts

```bash
datacheck schema capture                                                          # Save current schema as baseline
datacheck schema capture data.csv                                                 # Direct file path
datacheck schema capture --source production_db --sources-file sources.yaml       # Named source
datacheck schema compare                                                          # Compare against baseline
datacheck schema compare --fail-on-breaking                                       # Exit 1 on breaking changes
```

## Python API

```python
from datacheck import ValidationEngine

engine = ValidationEngine(config_path=".datacheck.yaml")
summary = engine.validate_sources()

print(f"Passed: {summary.passed_rules}/{summary.total_rules}")

for result in summary.get_failed_results():
    print(f"  FAIL: {result.rule_name} on {result.column} ({result.failed_rows} rows)")

if not summary.all_passed:
    raise ValueError("Data quality gate failed - halting pipeline")
```

## Available Rules

| Category | Rules |
|----------|-------|
| Null & Uniqueness | `not_null`, `unique`, `unique_combination` |
| Numeric | `min`, `max`, `range`, `boolean` |
| String & Pattern | `regex`, `allowed_values`, `length`, `min_length`, `max_length`, `type` |
| Temporal | `max_age`, `timestamp_range` (or `date_range`), `no_future_timestamps`, `date_format_valid` (or `date_format`) |
| Cross-Column | `unique_combination`, `sum_equals` |

## Links

- [Full Documentation](https://squrtech.github.io/datacheck/)
- [Available Rules Reference](https://squrtech.github.io/datacheck/#available-rules)
- [CLI Command Reference](https://squrtech.github.io/datacheck/#cli-command-reference)
- [GitHub](https://github.com/squrtech/datacheck)
- [Issues](https://github.com/squrtech/datacheck/issues)
- [Changelog](https://github.com/squrtech/datacheck/blob/main/CHANGELOG.md)

## License

Copyright © 2026 Squrtech. Licensed under the **Apache License, Version 2.0**.
