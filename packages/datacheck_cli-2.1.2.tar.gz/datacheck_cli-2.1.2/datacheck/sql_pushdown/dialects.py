"""SQL dialect definitions for multi-database aggregate pushdown.

Each Dialect subclass encapsulates the SQL syntax differences for one database
engine: identifier quoting, type casts, string functions, aggregate functions,
temporal expressions, and the set of rules that can be pushed down.

Usage::

    from datacheck.sql_pushdown.dialects import get_dialect

    dialect = get_dialect("mysql")   # → MySQLDialect or None if unsupported
    if dialect:
        sql = builder.build_query(table, where, limit, checks, dialect)
"""

from __future__ import annotations


def _format_to_regex(fmt: str) -> str | None:
    """Convert a Python strftime format string to an anchored regex pattern.

    Only the most common format codes are supported.  Returns ``None`` if the
    format contains an unrecognised ``%X`` code so the caller can fall back to
    the Python path rather than emitting a wrong pattern.

    Example::

        _format_to_regex("%Y-%m-%d")          # -> r'^[0-9]{4}-[0-9]{2}-[0-9]{2}$'
        _format_to_regex("%Y-%m-%d %H:%M:%S") # -> r'^[0-9]{4}-[0-9]{2}-[0-9]{2} ...$'
    """
    _CODES: dict[str, str] = {
        "%Y": "[0-9]{4}",
        "%m": "[0-9]{2}",
        "%d": "[0-9]{2}",
        "%H": "[0-9]{2}",
        "%M": "[0-9]{2}",
        "%S": "[0-9]{2}",
        "%f": "[0-9]{1,6}",
        "%I": "[0-9]{2}",
        "%p": "(?:AM|am|PM|pm)",
        "%j": "[0-9]{3}",
        "%U": "[0-9]{2}",
        "%W": "[0-9]{2}",
    }
    _REGEX_SPECIAL = set(r"\.^$*+?{}|()[]")
    parts: list[str] = []
    i = 0
    while i < len(fmt):
        if fmt[i] == "%" and i + 1 < len(fmt):
            code = fmt[i : i + 2]
            if code not in _CODES:
                return None  # unsupported format code — cannot safely push down
            parts.append(_CODES[code])
            i += 2
        else:
            ch = fmt[i]
            parts.append(("\\" + ch) if ch in _REGEX_SPECIAL else ch)
            i += 1
    return "^" + "".join(parts) + "$"


# ── Base pushable-rule set (supported by every dialect) ───────────────────────
# Rules that rely on dialect-specific functions (regex, percentile, max_age)
# are added per-dialect in their pushable_rules property.
_BASE_RULES: frozenset[str] = frozenset(
    {
        "not_null",
        "boolean",
        "min",
        "max",
        "range",
        "positive",
        "non_negative",
        "allowed_values",
        "unique",
        "unique_combination",
        "sum_equals",
        "min_length",
        "max_length",
        "no_future_timestamps",
        "timestamp_range",
        "date_range",
    }
)


class Dialect:
    """Abstract SQL dialect.  Subclasses override only what differs."""

    name: str = ""

    # ── Identifier quoting ────────────────────────────────────────────────────

    def q(self, name: str) -> str:
        """Return a safely quoted database identifier."""
        return '"' + name.replace('"', '""') + '"'

    # ── Type casts ────────────────────────────────────────────────────────────

    def cast_to_text(self, col: str) -> str:
        """Expression that casts *col* (already quoted) to a text/string type."""
        return f"CAST({col} AS VARCHAR)"

    # ── String functions ──────────────────────────────────────────────────────

    def str_length(self, col: str) -> str:
        """Character-length expression for *col*."""
        return f"LENGTH({col})"

    # ── Temporal expressions ──────────────────────────────────────────────────

    def current_timestamp(self) -> str:
        """SQL expression for the current wall-clock timestamp."""
        return "CURRENT_TIMESTAMP"

    def age_violation_expr(self, col: str, duration: str) -> str | None:
        """Inner CASE condition that is TRUE when *col* is older than *duration*.

        Returns *None* if the dialect cannot express this in SQL (the rule then
        falls back to the Python path).  The base implementation uses the
        standard ``INTERVAL '…'`` syntax supported by PostgreSQL, Redshift, and
        Snowflake.
        """
        interval = self._duration_to_interval_str(duration)
        if interval is None:
            return None
        ts = self.current_timestamp()
        return f"{col} < {ts} - INTERVAL '{interval}'"

    def _duration_to_interval_str(self, duration: str) -> str | None:
        """Convert a duration token (e.g. ``'24h'``) to a standard interval string."""
        s = str(duration).strip().lower()
        unit_map = {"m": "minutes", "h": "hours", "d": "days", "w": "weeks"}
        if s and s[-1] in unit_map:
            return f"{s[:-1]} {unit_map[s[-1]]}"
        return None

    # ── Regex ──────────────────────────────────────────────────────────────────

    def cast_for_temporal(self, col: str) -> str:
        """Cast *col* for use in temporal comparisons (e.g. with NOW() or INTERVAL).

        The base implementation returns *col* unchanged, assuming the column is
        already a native timestamp/date type.  Dialects that store dates as TEXT
        should override this to add an appropriate cast.
        """
        return col

    def regex_violation_expr(self, col: str, pattern: str) -> str | None:
        """Inner CASE condition that is TRUE when *col* does NOT match *pattern*.

        Returns *None* if the dialect has no native regex operator.
        """
        return None  # subclasses override

    # ── Type checking ─────────────────────────────────────────────────────────

    def type_violation_expr(self, col: str, type_name: str) -> str | None:
        """Inner CASE condition that is TRUE when *col* does NOT conform to *type_name*.

        Supported type names: ``int``/``integer``, ``float``/``numeric``,
        ``bool``, ``date``/``datetime``.

        Returns ``None`` for ``string`` (schema-level enforcement, not
        row-level) and for any unrecognised type name.  Subclasses override
        with dialect-optimal expressions.
        """
        return None  # base class: unsupported; concrete dialects override

    def date_format_violation_expr(self, col: str, fmt: str) -> str | None:
        """Inner CASE condition that is TRUE when *col* does NOT match *fmt*.

        *fmt* is a Python ``strftime`` format string (e.g. ``'%Y-%m-%d'``).
        Converts the format to a regex pattern and delegates to
        ``regex_violation_expr``.  Returns ``None`` if the format contains
        unsupported codes or if this dialect has no regex support.
        """
        return None  # base class: unsupported; concrete dialects override

    # ── Concatenation helpers ─────────────────────────────────────────────────

    def sep1(self) -> str:
        """SQL expression for the CHR(1) / CHAR(1) separator used in multi-column
        uniqueness checks.  It is a non-printable control character that is
        effectively never present in real data values."""
        return "CHR(1)"

    def concat_parts(self, parts: list[str]) -> str:
        """Concatenate *parts* with a CHR(1) separator for unique_combination checks.

        The default implementation uses the SQL standard ``||`` operator (works in
        PostgreSQL, Snowflake, BigQuery, Redshift).  MySQL overrides this with
        ``CONCAT(...)`` because ``||`` is the logical-OR operator in MySQL by default.
        """
        sep = self.sep1()
        return f" || {sep} || ".join(parts)

    # ── LIMIT ──────────────────────────────────────────────────────────────────

    def limit_clause(self, n: int | None) -> str:
        """Trailing ``LIMIT n`` clause appended to the SELECT statement."""
        return f" LIMIT {n}" if n is not None else ""

    # ── Pushable rule set ──────────────────────────────────────────────────────

    @property
    def pushable_rules(self) -> frozenset[str]:
        """Set of rule types that this dialect can handle in SQL."""
        return _BASE_RULES


# ── Concrete dialect implementations ──────────────────────────────────────────

class PostgreSQLDialect(Dialect):
    """PostgreSQL (and any PostgreSQL-wire-compatible DB)."""

    name = "postgresql"

    def q(self, name: str) -> str:
        return '"' + name.replace('"', '""') + '"'

    def cast_to_text(self, col: str) -> str:
        # PostgreSQL cast operator — also works for ENUM, UUID, etc.
        return f"{col}::text"

    def str_length(self, col: str) -> str:
        return f"LENGTH({col})"

    def current_timestamp(self) -> str:
        return "NOW()"

    def cast_for_temporal(self, col: str) -> str:
        # Safely cast TEXT columns to timestamp: only cast values that look like
        # ISO dates (YYYY-MM-DD...) to avoid errors on badly-formatted strings.
        # Non-ISO values become NULL and are not counted as violations.
        return (
            f"(CASE WHEN {col} ~ '^\\d{{4}}-\\d{{2}}-\\d{{2}}'"
            f" THEN {col}::timestamp ELSE NULL END)"
        )

    def age_violation_expr(self, col: str, duration: str) -> str | None:
        interval = self._duration_to_interval_str(duration)
        if interval is None:
            return None
        safe_ts = self.cast_for_temporal(col)
        return f"{safe_ts} < NOW() - INTERVAL '{interval}'"

    def regex_violation_expr(self, col: str, pattern: str) -> str | None:
        # !~ is the case-sensitive "does not match regex" operator in PostgreSQL.
        # Cast to text so non-text columns (enums, UUIDs) are handled correctly.
        p = pattern.replace("'", "''")
        return f"{col}::text !~ '{p}'"

    def type_violation_expr(self, col: str, type_name: str) -> str | None:
        t = type_name.lower()
        if t in ("int", "integer"):
            # Text representation of an integer contains only digits (optional sign).
            return f"{col}::text !~ '^-?[0-9]+$'"
        if t in ("float", "numeric"):
            return f"{col}::text !~ '^-?[0-9]*\\.?[0-9]+([eE][+-]?[0-9]+)?$'"
        if t in ("bool",):
            return f"LOWER({col}::text) NOT IN ('true', 'false')"
        if t in ("date", "datetime"):
            # Accept any value whose text starts with YYYY-MM-DD.
            return f"{col}::text !~ '^[0-9]{{4}}-[0-9]{{2}}-[0-9]{{2}}'"
        return None  # 'string' and unknown: leave to Python

    def date_format_violation_expr(self, col: str, fmt: str) -> str | None:
        pattern = _format_to_regex(fmt)
        if pattern is None:
            return None
        # regex_violation_expr already casts col to ::text
        return self.regex_violation_expr(col, pattern)

    @property
    def pushable_rules(self) -> frozenset[str]:
        return _BASE_RULES | frozenset({"regex", "max_age", "type", "date_format_valid", "date_format"})


class RedshiftDialect(PostgreSQLDialect):
    """Amazon Redshift — fully PostgreSQL-compatible SQL dialect."""

    name = "redshift"
    # PERCENTILE_CONT syntax is identical to PostgreSQL in Redshift.
    # All other methods inherited from PostgreSQLDialect without change.


class MySQLDialect(Dialect):
    """MySQL 8.0+ / MariaDB."""

    name = "mysql"

    def q(self, name: str) -> str:
        return "`" + name.replace("`", "``") + "`"

    def cast_to_text(self, col: str) -> str:
        return f"CAST({col} AS CHAR)"

    def str_length(self, col: str) -> str:
        # CHAR_LENGTH counts Unicode code points; LENGTH counts bytes.
        return f"CHAR_LENGTH({col})"

    def current_timestamp(self) -> str:
        return "NOW()"

    def age_violation_expr(self, col: str, duration: str) -> str | None:
        # MySQL INTERVAL syntax: NOW() - INTERVAL 24 HOUR  (no quotes, unit unquoted)
        s = str(duration).strip().lower()
        unit_map = {"m": "MINUTE", "h": "HOUR", "d": "DAY", "w": "WEEK"}
        if s and s[-1] in unit_map:
            return f"{col} < NOW() - INTERVAL {s[:-1]} {unit_map[s[-1]]}"
        return None

    def regex_violation_expr(self, col: str, pattern: str) -> str | None:
        # MySQL REGEXP operator performs case-insensitive matching by default.
        p = pattern.replace("'", "''")
        return f"{col} NOT REGEXP '{p}'"

    def type_violation_expr(self, col: str, type_name: str) -> str | None:
        t = type_name.lower()
        if t in ("int", "integer"):
            return f"CAST({col} AS CHAR) NOT REGEXP '^-?[0-9]+$'"
        if t in ("float", "numeric"):
            return f"CAST({col} AS CHAR) NOT REGEXP '^-?[0-9]*\\.?[0-9]+([eE][+-]?[0-9]+)?$'"
        if t in ("bool",):
            return f"LOWER(CAST({col} AS CHAR)) NOT IN ('true', 'false')"
        if t in ("date", "datetime"):
            # STR_TO_DATE returns NULL on parse failure.
            return f"STR_TO_DATE(CAST({col} AS CHAR), '%Y-%m-%d') IS NULL"
        return None

    def date_format_violation_expr(self, col: str, fmt: str) -> str | None:
        pattern = _format_to_regex(fmt)
        if pattern is None:
            return None
        # MySQL's REGEXP implicitly casts non-string columns to string.
        return self.regex_violation_expr(col, pattern)

    def sep1(self) -> str:
        return "CHAR(1)"

    def concat_parts(self, parts: list[str]) -> str:
        # MySQL's || is logical OR by default, not string concatenation.
        # Use CONCAT() to safely join column values with the separator.
        sep = self.sep1()
        args = f", {sep}, ".join(parts)
        return f"CONCAT({args})"

    @property
    def pushable_rules(self) -> frozenset[str]:
        return _BASE_RULES | frozenset({"regex", "max_age", "type", "date_format_valid", "date_format"})


class SnowflakeDialect(Dialect):
    """Snowflake Data Cloud."""

    name = "snowflake"

    def q(self, name: str) -> str:
        # Snowflake uses double-quotes for case-sensitive identifiers.
        return '"' + name.replace('"', '""') + '"'

    def cast_to_text(self, col: str) -> str:
        return f"TO_VARCHAR({col})"

    def str_length(self, col: str) -> str:
        return f"LENGTH({col})"

    def current_timestamp(self) -> str:
        return "CURRENT_TIMESTAMP()"

    def age_violation_expr(self, col: str, duration: str) -> str | None:
        # Snowflake supports standard INTERVAL '…' syntax.
        interval = self._duration_to_interval_str(duration)
        if interval is None:
            return None
        return f"{col} < CURRENT_TIMESTAMP() - INTERVAL '{interval}'"

    def regex_violation_expr(self, col: str, pattern: str) -> str | None:
        # Snowflake REGEXP_LIKE(subject, pattern) — negate for violations.
        p = pattern.replace("'", "''")
        return f"NOT REGEXP_LIKE({col}, '{p}')"

    def type_violation_expr(self, col: str, type_name: str) -> str | None:
        t = type_name.lower()
        if t in ("int", "integer"):
            return f"TRY_CAST({col} AS BIGINT) IS NULL"
        if t in ("float", "numeric"):
            return f"TRY_CAST({col} AS DOUBLE) IS NULL"
        if t in ("bool",):
            return f"LOWER(TO_VARCHAR({col})) NOT IN ('true', 'false')"
        if t in ("date", "datetime"):
            return f"TRY_CAST({col} AS TIMESTAMP) IS NULL"
        return None

    def date_format_violation_expr(self, col: str, fmt: str) -> str | None:
        pattern = _format_to_regex(fmt)
        if pattern is None:
            return None
        # Snowflake REGEXP_LIKE handles implicit cast from DATE/TIMESTAMP to string.
        return self.regex_violation_expr(col, pattern)

    @property
    def pushable_rules(self) -> frozenset[str]:
        return _BASE_RULES | frozenset({"regex", "max_age", "type", "date_format_valid", "date_format"})


class BigQueryDialect(Dialect):
    """Google BigQuery (Standard SQL)."""

    name = "bigquery"

    def q(self, name: str) -> str:
        # BigQuery uses backtick-quoted identifiers; escape embedded backticks.
        return "`" + name.replace("\\", "\\\\").replace("`", "\\`") + "`"

    def cast_to_text(self, col: str) -> str:
        return f"CAST({col} AS STRING)"

    def str_length(self, col: str) -> str:
        return f"LENGTH({col})"

    def current_timestamp(self) -> str:
        return "CURRENT_TIMESTAMP()"

    def age_violation_expr(self, col: str, duration: str) -> str | None:
        # BigQuery: TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL n UNIT)
        s = str(duration).strip().lower()
        unit_map = {"m": "MINUTE", "h": "HOUR", "d": "DAY", "w": "WEEK"}
        if s and s[-1] in unit_map:
            return (
                f"{col} < TIMESTAMP_SUB(CURRENT_TIMESTAMP(),"
                f" INTERVAL {s[:-1]} {unit_map[s[-1]]})"
            )
        return None

    def regex_violation_expr(self, col: str, pattern: str) -> str | None:
        # BigQuery REGEXP_CONTAINS(value, regexp) — negate for violations.
        # The r'' prefix is cosmetic in the generated SQL string.
        p = pattern.replace("'", "''")
        return f"NOT REGEXP_CONTAINS({col}, r'{p}')"

    def type_violation_expr(self, col: str, type_name: str) -> str | None:
        t = type_name.lower()
        if t in ("int", "integer"):
            return f"SAFE_CAST({col} AS INT64) IS NULL"
        if t in ("float", "numeric"):
            return f"SAFE_CAST({col} AS FLOAT64) IS NULL"
        if t in ("bool",):
            return f"LOWER(CAST({col} AS STRING)) NOT IN ('true', 'false')"
        if t in ("date", "datetime"):
            return f"SAFE_CAST({col} AS TIMESTAMP) IS NULL"
        return None

    def date_format_violation_expr(self, col: str, fmt: str) -> str | None:
        pattern = _format_to_regex(fmt)
        if pattern is None:
            return None
        # REGEXP_CONTAINS requires STRING; cast explicitly.
        return self.regex_violation_expr(self.cast_to_text(col), pattern)

    @property
    def pushable_rules(self) -> frozenset[str]:
        return _BASE_RULES | frozenset({"regex", "max_age", "type", "date_format_valid", "date_format"})


class DuckDBDialect(PostgreSQLDialect):
    """DuckDB — in-process analytical SQL engine for CSV and Parquet files.

    DuckDB is PostgreSQL-compatible: same regex operator (``~``), same
    ``INTERVAL '…'`` syntax, same ``||`` concatenation, and ``NOW()`` for
    the current timestamp.  The only key difference is how table/file
    references are quoted: file paths (ending in ``.csv``/``.parquet`` or
    containing a slash) use single-quote ``FROM 'file.csv'`` syntax instead
    of the standard double-quote identifier syntax.
    """

    name = "duckdb"

    def cast_for_temporal(self, col: str) -> str:
        """Cast *col* for temporal comparisons.

        DuckDB auto-infers CSV column types, so timestamp-looking columns
        arrive as native TIMESTAMP (not VARCHAR).  The PostgreSQL parent uses
        a ``CASE WHEN col ~ regex THEN col::timestamp`` pattern that requires
        a VARCHAR input and would fail on TIMESTAMP columns.

        ``TRY_CAST`` is safe for both: it is a no-op for already-typed
        TIMESTAMP columns and parses VARCHAR values on the way, returning
        NULL for any unparseable strings instead of raising an error.
        """
        return f"TRY_CAST({col} AS TIMESTAMP)"

    def type_violation_expr(self, col: str, type_name: str) -> str | None:
        """Use TRY_CAST for type checking — safe for both typed and VARCHAR columns.

        DuckDB auto-infers CSV column types, so a column declared as BIGINT is
        already typed; TRY_CAST is a no-op for native-typed columns and returns
        NULL only when the cast genuinely fails (violation).
        """
        t = type_name.lower()
        if t in ("int", "integer"):
            return f"TRY_CAST({col} AS BIGINT) IS NULL"
        if t in ("float", "numeric"):
            return f"TRY_CAST({col} AS DOUBLE) IS NULL"
        if t in ("bool",):
            return f"LOWER(CAST({col} AS VARCHAR)) NOT IN ('true', 'false')"
        if t in ("date", "datetime"):
            return f"TRY_CAST({col} AS TIMESTAMP) IS NULL"
        return None  # 'string': schema enforces this, always 0 violations in SQL

    def q(self, name: str) -> str:
        """Quote a table reference or file path.

        File paths (CSV/Parquet) use DuckDB's ``FROM 'file.csv'`` single-quote
        syntax.  Regular identifiers (table/view names) use standard
        double-quote escaping.
        """
        lowered = name.lower()
        if (
            lowered.endswith(".csv")
            or lowered.endswith(".parquet")
            or "/" in name
            or "\\" in name
            or name.startswith(".")
        ):
            return "'" + name.replace("'", "''") + "'"
        return '"' + name.replace('"', '""') + '"'


# ── Dialect registry ──────────────────────────────────────────────────────────

_DIALECT_MAP: dict[str, Dialect] = {
    "postgresql": PostgreSQLDialect(),
    "redshift":   RedshiftDialect(),
    "mysql":      MySQLDialect(),
    "snowflake":  SnowflakeDialect(),
    "bigquery":   BigQueryDialect(),
    "duckdb":     DuckDBDialect(),
}

# Source types for which SQL pushdown is available.
PUSHDOWN_CAPABLE_TYPES: frozenset[str] = frozenset(_DIALECT_MAP)


def get_dialect(source_type: str) -> Dialect | None:
    """Return the SQL dialect for *source_type*, or ``None`` if pushdown is not supported."""
    return _DIALECT_MAP.get(source_type)


__all__ = [
    "Dialect",
    "PostgreSQLDialect",
    "RedshiftDialect",
    "MySQLDialect",
    "SnowflakeDialect",
    "BigQueryDialect",
    "DuckDBDialect",
    "PUSHDOWN_CAPABLE_TYPES",
    "get_dialect",
]
