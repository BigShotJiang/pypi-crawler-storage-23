"""SQL aggregate pushdown for database validation.

Generates a single aggregate SQL query from a set of rule configs,
executes it via the connector, and converts the scalar result row into
RuleResult objects.  Zero rows transferred — all computation happens
inside the database engine.

Supports all database types listed in ``PUSHDOWN_CAPABLE_TYPES``
(PostgreSQL, Redshift, MySQL, Snowflake, BigQuery).
Each database uses its own :class:`~datacheck.sql_pushdown.dialects.Dialect`
subclass to generate the correct SQL syntax.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from datacheck.results import FailureDetail, RuleResult

if TYPE_CHECKING:
    from datacheck.sql_pushdown.dialects import Dialect

# Maximum set of rules that CAN be pushed down to SQL across all dialects.
# Individual dialects may support a subset — use dialect.pushable_rules for
# the actual set available for a given database connection.
PUSHABLE_RULES: frozenset[str] = frozenset(
    {
        "not_null",
        "boolean",
        "min",
        "max",
        "range",
        "positive",
        "non_negative",
        "allowed_values",
        "min_length",
        "max_length",
        "unique",
        "unique_combination",
        "regex",
        "max_age",
        "sum_equals",
        "no_future_timestamps",
        "timestamp_range",
        "date_range",
        "type",
        "date_format_valid",
        "date_format",
    }
)


def _lit(value: Any) -> str:
    """Convert a scalar to a safe SQL literal (numeric or single-quoted string)."""
    if isinstance(value, bool):
        return "TRUE" if value else "FALSE"
    if isinstance(value, (int, float)):
        return repr(value)          # e.g. 3.14, -1, 100
    s = str(value).replace("'", "''")
    return f"'{s}'"


class SqlAggregateBuilder:
    """Build and parse SQL aggregate queries for pushdown validation."""

    def __init__(self) -> None:
        # Populated by build_query(); consumed by parse_results()
        self._items: list[tuple[str, Any, str, Any]] = []
        # alias → (check, rule_type, params)

    # ── Public API ──────────────────────────────────────────────────────────

    def partition_checks(
        self, checks: list[Any], dialect: Dialect
    ) -> tuple[list[Any], list[Any]]:
        """Split checks into (pushable, non_pushable) for the given *dialect*.

        A check is pushable if every rule_type in ``check.rules`` is in
        ``dialect.pushable_rules``.  Disabled rules (params == False) are
        still considered pushable (they are silently skipped in SQL generation).
        """
        pushable_rules = dialect.pushable_rules
        pushable: list[Any] = []
        non_pushable: list[Any] = []
        for check in checks:
            if all(rt in pushable_rules for rt in check.rules):
                pushable.append(check)
            else:
                non_pushable.append(check)
        return pushable, non_pushable

    def build_query(
        self,
        table: str,
        where: str | None,
        pushable_checks: list[Any],
        dialect: Dialect,
    ) -> str:
        """Build a single aggregate SELECT for all pushable checks.

        Internally stores alias→(check, rule_type, params) so that
        parse_results() can reconstruct RuleResult objects.
        """
        self._items = []
        exprs: list[str] = ["COUNT(*) AS _total_rows"]

        for i, check in enumerate(pushable_checks):
            col = dialect.q(check.column)
            for rule_type, params in check.rules.items():
                # params == False / None means the rule is disabled — skip
                if params is False or params is None:
                    continue
                alias_prefix = f"_c{i}_{rule_type}"
                pairs = self._rule_to_sql(col, rule_type, params, alias_prefix, dialect)
                for alias, expr in pairs:
                    exprs.append(f"{expr} AS {alias}")
                    self._items.append((alias, check, rule_type, params))

        select_clause = ", ".join(exprs)
        tbl = dialect.q(table)
        sql = f"SELECT {select_clause} FROM {tbl}"
        if where:
            sql += f" WHERE {where}"
        return sql

    def parse_results(
        self, row: dict[str, Any], pushable_checks: list[Any]
    ) -> list[RuleResult]:
        """Convert the aggregate result row into a list of RuleResult objects."""
        total_rows = int(row.get("_total_rows") or 0)
        results: list[RuleResult] = []

        for alias, check, rule_type, params in self._items:
            value = row.get(alias)
            result = self._parse_single(check, rule_type, params, value, total_rows)
            results.append(result)

        return results

    # ── SQL generation ──────────────────────────────────────────────────────

    def _rule_to_sql(
        self,
        col: str,
        rule_type: str,
        params: Any,
        alias_prefix: str,
        dialect: Dialect,
    ) -> list[tuple[str, str]]:
        """Return (alias, SQL_expression) pairs for one rule."""

        if rule_type == "not_null":
            return [
                (alias_prefix,
                 f"SUM(CASE WHEN {col} IS NULL THEN 1 ELSE 0 END)")
            ]

        if rule_type == "boolean":
            # Count non-null values whose text representation is not 'true' or 'false'.
            # For native boolean columns the DB type guarantees 0 violations.
            # For string columns this checks that every value is a boolean literal.
            text_col = dialect.cast_to_text(col)
            return [
                (alias_prefix,
                 f"SUM(CASE WHEN {col} IS NOT NULL"
                 f" AND LOWER({text_col}) NOT IN ('true', 'false')"
                 f" THEN 1 ELSE 0 END)")
            ]

        if rule_type == "min":
            v = _lit(params)
            return [
                (alias_prefix,
                 f"SUM(CASE WHEN {col} IS NOT NULL AND {col} < {v}"
                 f" THEN 1 ELSE 0 END)")
            ]

        if rule_type == "max":
            v = _lit(params)
            return [
                (alias_prefix,
                 f"SUM(CASE WHEN {col} IS NOT NULL AND {col} > {v}"
                 f" THEN 1 ELSE 0 END)")
            ]

        if rule_type == "range":
            lo = _lit(params["min"])
            hi = _lit(params["max"])
            return [
                (alias_prefix,
                 f"SUM(CASE WHEN {col} IS NOT NULL"
                 f" AND ({col} < {lo} OR {col} > {hi})"
                 f" THEN 1 ELSE 0 END)")
            ]

        if rule_type == "positive":
            return [
                (alias_prefix,
                 f"SUM(CASE WHEN {col} IS NOT NULL AND {col} <= 0"
                 f" THEN 1 ELSE 0 END)")
            ]

        if rule_type == "non_negative":
            return [
                (alias_prefix,
                 f"SUM(CASE WHEN {col} IS NOT NULL AND {col} < 0"
                 f" THEN 1 ELSE 0 END)")
            ]

        if rule_type == "allowed_values":
            values_sql = ", ".join(_lit(v) for v in params)
            # Cast to text so ENUM/typed columns compare safely against string literals.
            text_col = dialect.cast_to_text(col)
            return [
                (alias_prefix,
                 f"SUM(CASE WHEN {col} IS NOT NULL"
                 f" AND {text_col} NOT IN ({values_sql})"
                 f" THEN 1 ELSE 0 END)")
            ]

        if rule_type == "min_length":
            n = int(params)
            length_expr = dialect.str_length(dialect.cast_to_text(col))
            return [
                (alias_prefix,
                 f"SUM(CASE WHEN {col} IS NOT NULL"
                 f" AND {length_expr} < {n}"
                 f" THEN 1 ELSE 0 END)")
            ]

        if rule_type == "max_length":
            n = int(params)
            length_expr = dialect.str_length(dialect.cast_to_text(col))
            return [
                (alias_prefix,
                 f"SUM(CASE WHEN {col} IS NOT NULL"
                 f" AND {length_expr} > {n}"
                 f" THEN 1 ELSE 0 END)")
            ]

        if rule_type == "unique":
            # COUNT(*) - COUNT(DISTINCT col) = number of "extra" duplicate rows.
            return [
                (alias_prefix,
                 f"COUNT(*) - COUNT(DISTINCT {col})")
            ]

        if rule_type == "unique_combination":
            # params is a list of column names.
            # Strategy: count total non-null combination rows minus distinct non-null
            # combinations.  Result > 0 means duplicate combinations exist.
            # Uses CHR(1)/CHAR(1) as a separator that is not present in real data.
            cols: list[str] = params if isinstance(params, list) else []
            if not cols:
                return []
            not_null_cond = " AND ".join(f"{dialect.q(c)} IS NOT NULL" for c in cols)
            parts = [dialect.cast_to_text(dialect.q(c)) for c in cols]
            concat_expr = dialect.concat_parts(parts)
            return [
                (alias_prefix,
                 f"SUM(CASE WHEN {not_null_cond} THEN 1 ELSE 0 END)"
                 f" - COUNT(DISTINCT CASE WHEN {not_null_cond}"
                 f" THEN {concat_expr} ELSE NULL END)")
            ]

        if rule_type == "regex":
            expr = dialect.regex_violation_expr(col, str(params))
            if expr is None:
                return []  # guarded by partition_checks — should not reach here
            return [
                (alias_prefix,
                 f"SUM(CASE WHEN {col} IS NOT NULL AND {expr}"
                 f" THEN 1 ELSE 0 END)")
            ]

        if rule_type == "max_age":
            expr = dialect.age_violation_expr(col, str(params))
            if expr is None:
                return []
            return [
                (alias_prefix,
                 f"SUM(CASE WHEN {col} IS NOT NULL AND {expr}"
                 f" THEN 1 ELSE 0 END)")
            ]

        if rule_type == "sum_equals":
            col_a = dialect.q(str(params["column_a"]))
            col_b = dialect.q(str(params["column_b"]))
            tolerance = float(params.get("tolerance", 0.01))
            # col is the "total" column; col_a + col_b must equal it within tolerance
            return [
                (alias_prefix,
                 f"SUM(CASE WHEN {col} IS NOT NULL"
                 f" AND {col_a} IS NOT NULL AND {col_b} IS NOT NULL"
                 f" AND ABS({col_a} + {col_b} - {col}) > {tolerance}"
                 f" THEN 1 ELSE 0 END)")
            ]

        if rule_type == "no_future_timestamps":
            ts = dialect.current_timestamp()
            tcol = dialect.cast_for_temporal(col)
            return [
                (alias_prefix,
                 f"SUM(CASE WHEN {col} IS NOT NULL"
                 f" AND {tcol} > {ts}"
                 f" THEN 1 ELSE 0 END)")
            ]

        if rule_type in ("timestamp_range", "date_range"):
            lo = _lit(params["min"])
            hi = _lit(params["max"])
            return [
                (alias_prefix,
                 f"SUM(CASE WHEN {col} IS NOT NULL"
                 f" AND ({col} < {lo} OR {col} > {hi})"
                 f" THEN 1 ELSE 0 END)")
            ]

        if rule_type == "type":
            t = str(params).lower()
            if t == "string":
                # In SQL, column types are enforced by the schema — every value
                # in a VARCHAR/TEXT column is already a string.  Emit a constant
                # zero so the rule always passes (matches the Python behaviour
                # for properly-typed string columns).
                return [(alias_prefix, "0")]
            expr = dialect.type_violation_expr(col, t)
            if expr is None:
                return []  # unsupported subtype — guarded by pushable_rules
            return [
                (alias_prefix,
                 f"SUM(CASE WHEN {col} IS NOT NULL AND {expr}"
                 f" THEN 1 ELSE 0 END)")
            ]

        if rule_type in ("date_format_valid", "date_format"):
            expr = dialect.date_format_violation_expr(col, str(params))
            if expr is None:
                return []  # unsupported format — guarded by pushable_rules
            return [
                (alias_prefix,
                 f"SUM(CASE WHEN {col} IS NOT NULL AND {expr}"
                 f" THEN 1 ELSE 0 END)")
            ]

        return []  # Unknown rule — guarded by PUSHABLE_RULES before calling

    # ── Result parsing ──────────────────────────────────────────────────────

    def _parse_single(
        self,
        check: Any,
        rule_type: str,
        params: Any,
        value: Any,
        total_rows: int,
    ) -> RuleResult:
        rule_name = _rule_name(check.name, rule_type)

        # All rules: value is a violation count
        violation_count = int(value or 0)
        passed = violation_count == 0
        reasons = (
            []
            if passed
            else [f"SQL aggregate: {violation_count:,} violations detected"]
        )
        return self._make_result(
            check, rule_type, rule_name, passed, total_rows,
            violation_count, reasons,
        )

    def _make_result(
        self,
        check: Any,
        rule_type: str,
        rule_name: str,
        passed: bool,
        total_rows: int,
        failed_rows: int,
        reasons: list[str],
        metric_value: Any = None,
    ) -> RuleResult:
        failure_details = None
        if not passed and total_rows > 0:
            sample_values = [metric_value] if metric_value is not None else []
            failure_details = FailureDetail(
                rule_name=rule_name,
                column=check.column,
                failed_count=failed_rows,
                total_count=total_rows,
                failure_rate=failed_rows / total_rows * 100,
                sample_failures=[],
                sample_values=sample_values,
                sample_reasons=reasons,
            )
        return RuleResult(
            rule_name=rule_name,
            column=check.column,
            passed=passed,
            total_rows=total_rows,
            failed_rows=failed_rows,
            failure_details=failure_details,
            rule_type=rule_type,
            check_name=check.name,
            severity=check.severity,
        )


def _rule_name(check_name: str, rule_type: str) -> str:
    """Match the naming convention used by the rule factory."""
    if rule_type == "min":
        return f"{check_name}_min"
    if rule_type == "max":
        return f"{check_name}_max"
    return check_name


__all__ = ["SqlAggregateBuilder", "PUSHABLE_RULES"]
