"""String validation rules."""

import re
from functools import lru_cache
from typing import Any

import numpy as np
import pandas as pd

from datacheck.exceptions import ColumnNotFoundError, RuleDefinitionError
from datacheck.results import RuleResult
from datacheck.rules.base import Rule


@lru_cache(maxsize=256)
def _compile_regex(pattern: str) -> re.Pattern[str]:
    """Compile and cache a regex pattern."""
    return re.compile(pattern)


class RegexRule(Rule):
    """Rule to check values match a regular expression pattern."""

    def __init__(self, name: str, column: str, pattern: str) -> None:
        """Initialize RegexRule.

        Args:
            name: Name of the rule
            column: Column to validate
            pattern: Regular expression pattern

        Raises:
            RuleDefinitionError: If pattern is invalid
        """
        super().__init__(name, column)
        try:
            self.pattern = _compile_regex(pattern)
        except re.error as e:
            raise RuleDefinitionError(f"Invalid regex pattern '{pattern}': {e}") from e
        self.pattern_str = pattern

    def validate(self, df: pd.DataFrame) -> RuleResult:
        """Validate that values match regex pattern.

        Args:
            df: DataFrame to validate

        Returns:
            RuleResult with validation outcome
        """
        try:
            self._check_column_exists(df)

            total_rows = len(df)

            # Filter out null values
            non_null_mask = df[self.column].notna()
            data = df[self.column][non_null_mask]

            # Convert to string only if not already string-typed
            if pd.api.types.is_string_dtype(data):
                data_str = data
            else:
                data_str = data.astype(str)
            # Use string pattern (not compiled re.Pattern) for Arrow compatibility
            matches = data_str.str.match(self.pattern_str, na=False)

            # Invert to get violations
            violation_indices = data.index[~matches]

            if len(violation_indices) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="regex",
                    check_name=self.name,
                )

            # Get failed values and create reasons
            failed_values = data.loc[violation_indices]
            reasons = [f"Does not match pattern: {self.pattern_str}"] * len(violation_indices)

            failure_detail = self._create_failure_detail(
                violation_indices, total_rows, failed_values, reasons
            )

            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=total_rows,
                failed_rows=len(violation_indices),
                failure_details=failure_detail,
                rule_type="regex",
                check_name=self.name,
            )

        except ColumnNotFoundError:
            raise
        except Exception as e:
            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=len(df),
                error=f"Error executing regex rule: {e}",
                rule_type="regex",
                check_name=self.name,
            )


class AllowedValuesRule(Rule):
    """Rule to check values are in an allowed set."""

    def __init__(self, name: str, column: str, allowed_values: list[Any]) -> None:
        """Initialize AllowedValuesRule.

        Args:
            name: Name of the rule
            column: Column to validate
            allowed_values: List of allowed values

        Raises:
            RuleDefinitionError: If allowed_values is empty
        """
        super().__init__(name, column)
        if not allowed_values:
            raise RuleDefinitionError("allowed_values cannot be empty")
        self.allowed_values = set(allowed_values)

    def validate(self, df: pd.DataFrame) -> RuleResult:
        """Validate that values are in allowed set.

        Args:
            df: DataFrame to validate

        Returns:
            RuleResult with validation outcome
        """
        try:
            self._check_column_exists(df)

            total_rows = len(df)

            # Filter out null values
            non_null_mask = df[self.column].notna()
            data = df[self.column][non_null_mask]

            # Check if values are in allowed set
            in_allowed = data.isin(self.allowed_values)
            violation_indices = data.index[~in_allowed]

            if len(violation_indices) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="allowed_values",
                    check_name=self.name,
                )

            # Get failed values and create reasons
            failed_values = data.loc[violation_indices]
            allowed_str = ", ".join([str(v) for v in sorted(self.allowed_values)])
            reasons = [f"Not in allowed values: [{allowed_str}]"] * len(violation_indices)

            failure_detail = self._create_failure_detail(
                violation_indices, total_rows, failed_values, reasons
            )

            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=total_rows,
                failed_rows=len(violation_indices),
                failure_details=failure_detail,
                rule_type="allowed_values",
                check_name=self.name,
            )

        except ColumnNotFoundError:
            raise
        except Exception as e:
            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=len(df),
                error=f"Error executing allowed_values rule: {e}",
                rule_type="allowed_values",
                check_name=self.name,
            )


class LengthRule(Rule):
    """Rule to check string length constraints.

    Validates that string values have length within specified bounds.
    Only applies to string columns - non-string values fail explicitly.
    """

    def __init__(
        self,
        name: str,
        column: str,
        min_length: int | None = None,
        max_length: int | None = None,
    ) -> None:
        """Initialize LengthRule.

        Args:
            name: Name of the rule
            column: Column to validate
            min_length: Minimum string length (inclusive)
            max_length: Maximum string length (inclusive)

        Raises:
            RuleDefinitionError: If neither min nor max is specified,
                or if values are invalid
        """
        super().__init__(name, column)
        if min_length is None and max_length is None:
            raise RuleDefinitionError("LengthRule requires at least min_length or max_length")
        if min_length is not None and min_length < 0:
            raise RuleDefinitionError("min_length cannot be negative")
        if max_length is not None and max_length < 0:
            raise RuleDefinitionError("max_length cannot be negative")
        if min_length is not None and max_length is not None and min_length > max_length:
            raise RuleDefinitionError("min_length cannot be greater than max_length")
        self.min_length = min_length
        self.max_length = max_length

    def validate(self, df: pd.DataFrame) -> RuleResult:
        """Validate that string values have valid length.

        Args:
            df: DataFrame to validate

        Returns:
            RuleResult with validation outcome
        """
        try:
            self._check_column_exists(df)

            total_rows = len(df)

            # Filter out null values
            non_null_mask = df[self.column].notna()
            data = df[self.column][non_null_mask]

            if len(data) == 0:
                # All null - passes (nulls are ignored)
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="length",
                    check_name=self.name,
                )

            # Check for non-string values (skip check if dtype is already string)
            is_string_col = pd.api.types.is_string_dtype(data)
            if not is_string_col:
                check_fn = np.frompyfunc(lambda v: isinstance(v, str), 1, 1)
                non_string_mask = ~pd.Series(check_fn(data.values).astype(bool), index=data.index)
                if non_string_mask.any():
                    non_string_indices = data.index[non_string_mask]
                    failed_values = data.loc[non_string_indices]
                    reasons = [
                        f"Value '{v}' is not a string (type: {type(v).__name__})"
                        for v in failed_values.iloc[:100]
                    ]

                    failure_detail = self._create_failure_detail(
                        non_string_indices, total_rows, failed_values, reasons
                    )

                    return RuleResult(
                        rule_name=self.name,
                        column=self.column,
                        passed=False,
                        total_rows=total_rows,
                        failed_rows=len(non_string_indices),
                        failure_details=failure_detail,
                        rule_type="length",
                        check_name=self.name,
                    )

            # All values are strings - check length
            lengths = data.str.len()

            if self.min_length is not None and self.max_length is not None:
                violation_mask = (lengths < self.min_length) | (lengths > self.max_length)
            elif self.min_length is not None:
                violation_mask = lengths < self.min_length
            elif self.max_length is not None:
                violation_mask = lengths > self.max_length
            else:
                violation_mask = pd.Series(False, index=data.index)

            violation_indices = data.index[violation_mask]

            if len(violation_indices) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="length",
                    check_name=self.name,
                )

            # Get failed values and create reasons using pre-computed lengths
            failed_values = data.loc[violation_indices]
            sample_idx = violation_indices[:100]
            sample_lengths = lengths.loc[sample_idx]
            reasons = []
            for length in sample_lengths:
                if self.min_length is not None and length < self.min_length:
                    reasons.append(f"Length {length} is below minimum {self.min_length}")
                elif self.max_length is not None and length > self.max_length:
                    reasons.append(f"Length {length} exceeds maximum {self.max_length}")

            failure_detail = self._create_failure_detail(
                violation_indices, total_rows, failed_values, reasons
            )

            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=total_rows,
                failed_rows=len(violation_indices),
                failure_details=failure_detail,
                rule_type="length",
                check_name=self.name,
            )

        except ColumnNotFoundError:
            raise
        except Exception as e:
            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=len(df),
                error=f"Error executing length rule: {e}",
                rule_type="length",
                check_name=self.name,
            )
