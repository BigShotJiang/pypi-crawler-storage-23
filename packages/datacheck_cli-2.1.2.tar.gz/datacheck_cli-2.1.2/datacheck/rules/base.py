"""Base rule classes."""

from abc import ABC, abstractmethod
from typing import Any

import pandas as pd

from datacheck.exceptions import ColumnNotFoundError
from datacheck.results import FailureDetail, RuleResult


class Rule(ABC):
    """Abstract base class for validation rules.

    Attributes:
        name: Name of the rule
        column: Column to validate
    """

    def __init__(self, name: str, column: str) -> None:
        """Initialize rule.

        Args:
            name: Name of the rule
            column: Column to validate
        """
        self.name = name
        self.column = column

    @abstractmethod
    def validate(self, df: pd.DataFrame) -> RuleResult:
        """Validate data against this rule.

        Args:
            df: DataFrame to validate

        Returns:
            RuleResult with validation outcome

        Raises:
            ColumnNotFoundError: If column not found in DataFrame
        """
        pass

    def _check_column_exists(self, df: pd.DataFrame) -> None:
        """Check if column exists in DataFrame.

        Args:
            df: DataFrame to check

        Raises:
            ColumnNotFoundError: If column not found
        """
        if self.column not in df.columns:
            raise ColumnNotFoundError(self.column, list(df.columns))

    def _create_failure_detail(
        self,
        failed_indices: pd.Index,
        total_count: int,
        failed_values: pd.Series | None = None,
        reasons: list[str] | None = None,
    ) -> FailureDetail:
        """Create failure detail from failed indices.

        Args:
            failed_indices: Indices of failed rows
            total_count: Total number of rows
            failed_values: Series containing failed values (optional)
            reasons: List of failure reasons for each failed value (optional)

        Returns:
            FailureDetail with failure information
        """
        failed_count = len(failed_indices)
        failure_rate = (failed_count / total_count * 100) if total_count > 0 else 0.0

        # Limit sample failures to 100 for memory efficiency
        sample_failures = failed_indices.tolist()[:100]

        # Extract sample values if provided
        sample_values: list[Any] = []
        if failed_values is not None:
            sample_values = failed_values.iloc[:100].tolist()

        # Extract sample reasons if provided
        sample_reasons: list[str] = []
        if reasons is not None:
            sample_reasons = reasons[:100]

        return FailureDetail(
            rule_name=self.name,
            column=self.column,
            failed_count=failed_count,
            total_count=total_count,
            failure_rate=failure_rate,
            sample_failures=sample_failures,
            sample_values=sample_values,
            sample_reasons=sample_reasons,
        )
