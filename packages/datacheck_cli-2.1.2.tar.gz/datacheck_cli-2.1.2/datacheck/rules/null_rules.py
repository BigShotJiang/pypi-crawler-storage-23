"""Null validation rules."""

import pandas as pd

from datacheck.exceptions import ColumnNotFoundError
from datacheck.results import RuleResult
from datacheck.rules.base import Rule


class NotNullRule(Rule):
    """Rule to check for null/missing values."""

    def validate(self, df: pd.DataFrame) -> RuleResult:
        """Validate that column has no null values.

        Args:
            df: DataFrame to validate

        Returns:
            RuleResult with validation outcome
        """
        try:
            self._check_column_exists(df)

            total_rows = len(df)
            col = df[self.column]

            # Fast path: use Arrow's null_count to avoid materializing boolean mask
            if hasattr(col, "array") and hasattr(col.array, "_pa_array"):
                if col.array._pa_array.null_count == 0:
                    return RuleResult(
                        rule_name=self.name,
                        column=self.column,
                        passed=True,
                        total_rows=total_rows,
                        failed_rows=0,
                        rule_type="not_null",
                        check_name=self.name,
                    )

            null_mask = col.isna()
            null_indices = df.index[null_mask]

            if len(null_indices) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="not_null",
                    check_name=self.name,
                )

            # Create reasons for null values
            failed_values = df[self.column].loc[null_indices]
            reasons = ["Value is null/missing"] * len(null_indices)

            failure_detail = self._create_failure_detail(
                null_indices, total_rows, failed_values, reasons
            )

            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=total_rows,
                failed_rows=len(null_indices),
                failure_details=failure_detail,
                rule_type="not_null",
                check_name=self.name,
            )

        except ColumnNotFoundError:
            raise
        except Exception as e:
            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=len(df),
                error=f"Error executing not_null rule: {e}",
                rule_type="not_null",
                check_name=self.name,
            )
