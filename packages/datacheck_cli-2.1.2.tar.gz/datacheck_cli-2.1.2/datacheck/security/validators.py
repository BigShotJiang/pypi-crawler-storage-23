"""Input validation and sanitization for DataCheck.

Provides security-focused validation for user inputs including file paths,
column names, SQL identifiers, and other potentially dangerous inputs.
"""

import re
from pathlib import Path
from urllib.parse import urlparse


class ValidationError(Exception):
    """Input validation error."""
    pass


class PathValidator:
    """Validate and sanitize file paths.

    Prevents path traversal attacks and ensures files are within allowed directories.

    Example:
        >>> validator = PathValidator(allowed_dirs=["/data"])
        >>> safe_path = validator.validate("/data/users.csv")
        >>> validator.validate("../../etc/passwd")  # Raises ValidationError
    """

    # Default allowed file extensions for data files
    DEFAULT_EXTENSIONS = {
        '.csv', '.parquet', '.json', '.jsonl',
        '.tsv', '.txt', '.xlsx', '.xls', '.yaml', '.yml'
    }

    # Maximum file size in bytes (default 10GB)
    DEFAULT_MAX_SIZE = 10 * 1024 * 1024 * 1024

    def __init__(
        self,
        allowed_dirs: list[str | Path] | None = None,
        allowed_extensions: set[str] | None = None,
        max_size_bytes: int = DEFAULT_MAX_SIZE,
        allow_symlinks: bool = False,
    ):
        """Initialize path validator.

        Args:
            allowed_dirs: List of allowed base directories. If None, allows any directory.
            allowed_extensions: Set of allowed file extensions. If None, uses defaults.
            max_size_bytes: Maximum allowed file size in bytes.
            allow_symlinks: Whether to allow symbolic links.
        """
        self.allowed_dirs = [Path(d).resolve() for d in (allowed_dirs or [])]
        self.allowed_extensions = allowed_extensions or self.DEFAULT_EXTENSIONS
        self.max_size_bytes = max_size_bytes
        self.allow_symlinks = allow_symlinks

    def validate(
        self,
        path: str | Path,
        must_exist: bool = True,
        check_size: bool = True,
    ) -> Path:
        """Validate a file path for security.

        Args:
            path: File path to validate
            must_exist: Whether the file must exist
            check_size: Whether to check file size

        Returns:
            Validated absolute Path object

        Raises:
            ValidationError: If path is invalid or unsafe
        """
        # Check for null bytes (injection attack)
        if isinstance(path, str) and '\x00' in path:
            raise ValidationError("Path contains null bytes (possible injection attack)")

        try:
            path = Path(path)
        except (TypeError, ValueError) as e:
            raise ValidationError(f"Invalid path format: {e}")

        # Resolve to absolute path (also handles .. and .)
        try:
            resolved = path.resolve()
        except (OSError, RuntimeError, ValueError) as e:
            # ValueError can occur with embedded null bytes
            raise ValidationError(f"Could not resolve path: {e}")

        # Check for path traversal attempts in original input
        path_str = str(path)
        if '..' in path_str or path_str.startswith('~'):
            # Double-check the resolved path is safe
            if self.allowed_dirs:
                if not any(self._is_subpath(resolved, allowed) for allowed in self.allowed_dirs):
                    raise ValidationError(
                        f"Path traversal detected: {path} resolves outside allowed directories"
                    )

        # Check against allowed directories
        if self.allowed_dirs:
            if not any(self._is_subpath(resolved, allowed) for allowed in self.allowed_dirs):
                raise ValidationError(
                    f"Path {resolved} is not within allowed directories: {self.allowed_dirs}"
                )

        # Check for symbolic links
        if not self.allow_symlinks and resolved != path.absolute():
            if path.is_symlink():
                raise ValidationError(f"Symbolic links not allowed: {path}")

        # Check existence
        if must_exist:
            if not resolved.exists():
                raise ValidationError(f"File does not exist: {resolved}")
            if not resolved.is_file():
                raise ValidationError(f"Path is not a file: {resolved}")

        # Check extension
        if self.allowed_extensions:
            ext = resolved.suffix.lower()
            if ext not in self.allowed_extensions:
                raise ValidationError(
                    f"File extension '{ext}' not allowed. "
                    f"Allowed: {sorted(self.allowed_extensions)}"
                )

        # Check size
        if check_size and must_exist and resolved.exists():
            size = resolved.stat().st_size
            if size > self.max_size_bytes:
                size_mb = size / 1024 / 1024
                max_mb = self.max_size_bytes / 1024 / 1024
                raise ValidationError(
                    f"File too large: {size_mb:.1f}MB (max: {max_mb:.1f}MB)"
                )

        return resolved

    def _is_subpath(self, path: Path, parent: Path) -> bool:
        """Check if path is a subpath of parent.

        Args:
            path: Path to check
            parent: Parent directory

        Returns:
            True if path is under parent
        """
        try:
            path.relative_to(parent)
            return True
        except ValueError:
            return False

    def validate_directory(
        self,
        path: str | Path,
        must_exist: bool = True,
        create_if_missing: bool = False,
    ) -> Path:
        """Validate a directory path.

        Args:
            path: Directory path to validate
            must_exist: Whether directory must exist
            create_if_missing: Create directory if it doesn't exist

        Returns:
            Validated absolute Path object

        Raises:
            ValidationError: If path is invalid or unsafe
        """
        try:
            path = Path(path)
            resolved = path.resolve()
        except (TypeError, ValueError, OSError) as e:
            raise ValidationError(f"Invalid directory path: {e}")

        # Check against allowed directories
        if self.allowed_dirs:
            if not any(self._is_subpath(resolved, allowed) for allowed in self.allowed_dirs):
                raise ValidationError(
                    f"Directory {resolved} is not within allowed directories"
                )

        if must_exist or create_if_missing:
            if not resolved.exists():
                if create_if_missing:
                    try:
                        resolved.mkdir(parents=True, mode=0o755)
                    except OSError as e:
                        raise ValidationError(f"Could not create directory: {e}")
                else:
                    raise ValidationError(f"Directory does not exist: {resolved}")

            if resolved.exists() and not resolved.is_dir():
                raise ValidationError(f"Path exists but is not a directory: {resolved}")

        return resolved


class SQLValidator:
    """Validate and sanitize SQL identifiers.

    Prevents SQL injection by validating table names, column names, and other
    SQL identifiers against safe patterns.

    Example:
        >>> validator = SQLValidator()
        >>> safe_name = validator.validate_identifier("user_id")
        >>> validator.validate_identifier("'; DROP TABLE--")  # Raises ValidationError
    """

    # SQL reserved keywords that cannot be used as identifiers
    SQL_KEYWORDS = {
        'SELECT', 'INSERT', 'UPDATE', 'DELETE', 'DROP', 'CREATE', 'ALTER',
        'TABLE', 'DATABASE', 'INDEX', 'VIEW', 'TRIGGER', 'PROCEDURE',
        'FUNCTION', 'FROM', 'WHERE', 'JOIN', 'ON', 'AND', 'OR', 'NOT',
        'NULL', 'TRUE', 'FALSE', 'IN', 'LIKE', 'BETWEEN', 'IS', 'AS',
        'ORDER', 'BY', 'GROUP', 'HAVING', 'LIMIT', 'OFFSET', 'UNION',
        'INTERSECT', 'EXCEPT', 'ALL', 'DISTINCT', 'INTO', 'VALUES', 'SET',
        'GRANT', 'REVOKE', 'COMMIT', 'ROLLBACK', 'TRUNCATE', 'CASCADE',
        'EXEC', 'EXECUTE', 'DECLARE', 'CURSOR', 'FETCH', 'OPEN', 'CLOSE',
    }

    # Pattern for valid SQL identifiers
    IDENTIFIER_PATTERN = re.compile(r'^[a-zA-Z_][a-zA-Z0-9_]*$')

    # Maximum identifier length (most databases limit to 64-128 chars)
    MAX_IDENTIFIER_LENGTH = 128

    def __init__(
        self,
        allow_keywords: bool = False,
        max_length: int = MAX_IDENTIFIER_LENGTH,
        additional_keywords: set[str] | None = None,
    ):
        """Initialize SQL validator.

        Args:
            allow_keywords: Whether to allow SQL keywords as identifiers
            max_length: Maximum identifier length
            additional_keywords: Additional keywords to disallow
        """
        self.allow_keywords = allow_keywords
        self.max_length = max_length
        self.keywords = self.SQL_KEYWORDS.copy()
        if additional_keywords:
            self.keywords.update(additional_keywords)

    def validate_identifier(self, identifier: str) -> str:
        """Validate a SQL identifier (table/column name).

        Args:
            identifier: Identifier to validate

        Returns:
            Validated identifier

        Raises:
            ValidationError: If identifier is invalid
        """
        if not identifier:
            raise ValidationError("Identifier cannot be empty")

        if len(identifier) > self.max_length:
            raise ValidationError(
                f"Identifier too long: {len(identifier)} chars (max: {self.max_length})"
            )

        if not self.IDENTIFIER_PATTERN.match(identifier):
            raise ValidationError(
                f"Invalid identifier '{identifier}'. "
                "Must start with letter/underscore and contain only letters, numbers, underscores."
            )

        if not self.allow_keywords and identifier.upper() in self.keywords:
            raise ValidationError(
                f"Identifier '{identifier}' is a SQL reserved keyword"
            )

        return identifier

    def quote_identifier(self, identifier: str, quote_char: str = '"') -> str:
        """Quote a SQL identifier to prevent injection.

        Args:
            identifier: Identifier to quote
            quote_char: Quote character ('"' for standard SQL, '`' for MySQL)

        Returns:
            Quoted identifier

        Example:
            >>> validator.quote_identifier("user")
            '"user"'
        """
        # Remove any existing quotes
        cleaned = identifier.replace(quote_char, '')

        # Validate the cleaned identifier
        if not self.IDENTIFIER_PATTERN.match(cleaned):
            raise ValidationError(f"Invalid identifier for quoting: {identifier}")

        return f'{quote_char}{cleaned}{quote_char}'

    def validate_table_reference(self, reference: str) -> str:
        """Validate a table reference (possibly with schema).

        Args:
            reference: Table reference like "schema.table" or "table"

        Returns:
            Validated reference

        Raises:
            ValidationError: If reference is invalid
        """
        parts = reference.split('.')

        if len(parts) > 3:  # catalog.schema.table
            raise ValidationError(f"Invalid table reference: {reference}")

        for part in parts:
            self.validate_identifier(part)

        return reference


class InputValidator:
    """General input validation utilities.

    Combines path and SQL validation with additional input sanitization.
    """

    # Common dangerous patterns
    SHELL_METACHARACTERS = re.compile(r'[;&|`$(){}[\]<>\\]')
    CONTROL_CHARACTERS = re.compile(r'[\x00-\x1f\x7f]')

    @staticmethod
    def validate_string(
        value: str,
        max_length: int = 1000,
        allow_empty: bool = False,
        pattern: str | None = None,
    ) -> str:
        """Validate a string input.

        Args:
            value: String to validate
            max_length: Maximum allowed length
            allow_empty: Whether empty strings are allowed
            pattern: Optional regex pattern to match

        Returns:
            Validated string

        Raises:
            ValidationError: If validation fails
        """
        if not isinstance(value, str):
            raise ValidationError(f"Expected string, got {type(value).__name__}")

        if not allow_empty and not value:
            raise ValidationError("String cannot be empty")

        if len(value) > max_length:
            raise ValidationError(f"String too long: {len(value)} (max: {max_length})")

        # Check for control characters
        if InputValidator.CONTROL_CHARACTERS.search(value):
            raise ValidationError("String contains invalid control characters")

        if pattern and not re.match(pattern, value):
            raise ValidationError("String does not match required pattern")

        return value

    @staticmethod
    def sanitize_for_logging(value: str, max_length: int = 100) -> str:
        """Sanitize a value for safe logging.

        Args:
            value: Value to sanitize
            max_length: Maximum length in log output

        Returns:
            Sanitized string safe for logging
        """
        # Remove control characters
        sanitized = InputValidator.CONTROL_CHARACTERS.sub('', value)

        # Truncate if needed
        if len(sanitized) > max_length:
            sanitized = sanitized[:max_length] + '...'

        return sanitized

    @staticmethod
    def validate_url(url: str, allowed_schemes: set[str] | None = None) -> str:
        """Validate a URL.

        Args:
            url: URL to validate
            allowed_schemes: Allowed URL schemes (default: http, https)

        Returns:
            Validated URL

        Raises:
            ValidationError: If URL is invalid
        """
        allowed = allowed_schemes or {'http', 'https'}

        try:
            parsed = urlparse(url)
        except Exception as e:
            raise ValidationError(f"Invalid URL format: {e}")

        if not parsed.scheme:
            raise ValidationError("URL must include scheme (http/https)")

        if parsed.scheme.lower() not in allowed:
            raise ValidationError(
                f"URL scheme '{parsed.scheme}' not allowed. Allowed: {sorted(allowed)}"
            )

        if not parsed.netloc:
            raise ValidationError("URL must include host")

        return url

    @staticmethod
    def validate_email(email: str) -> str:
        """Validate an email address format.

        Args:
            email: Email to validate

        Returns:
            Validated email

        Raises:
            ValidationError: If email format is invalid
        """
        # Basic email pattern (not exhaustive but covers common cases)
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'

        if not re.match(pattern, email):
            raise ValidationError(f"Invalid email format: {email}")

        if len(email) > 254:  # RFC 5321
            raise ValidationError("Email address too long")

        return email

    @staticmethod
    def validate_column_name(column: str) -> str:
        """Validate a DataFrame column name.

        Args:
            column: Column name to validate

        Returns:
            Validated column name

        Raises:
            ValidationError: If column name is invalid
        """
        validator = SQLValidator()
        return validator.validate_identifier(column)

    @staticmethod
    def validate_file_path(
        path: str | Path,
        allowed_extensions: list[str] | None = None,
        max_size_mb: int = 1000,
    ) -> Path:
        """Validate a file path for security.

        Args:
            path: File path to validate
            allowed_extensions: List of allowed extensions (with dots)
            max_size_mb: Maximum file size in MB

        Returns:
            Validated Path object

        Raises:
            ValidationError: If path is invalid or unsafe
        """
        extensions = set(allowed_extensions) if allowed_extensions else None
        validator = PathValidator(
            allowed_extensions=extensions,
            max_size_bytes=max_size_mb * 1024 * 1024,
        )
        return validator.validate(path)

    @staticmethod
    def sanitize_shell_arg(arg: str) -> str:
        """Sanitize an argument for shell command use.

        WARNING: Prefer using subprocess with shell=False and passing
        arguments as a list. This is only for cases where shell=True
        is absolutely necessary.

        Args:
            arg: Argument to sanitize

        Returns:
            Sanitized argument

        Raises:
            ValidationError: If argument contains dangerous characters
        """
        if InputValidator.SHELL_METACHARACTERS.search(arg):
            raise ValidationError(
                f"Argument contains shell metacharacters: {arg}"
            )

        if InputValidator.CONTROL_CHARACTERS.search(arg):
            raise ValidationError(
                "Argument contains control characters"
            )

        return arg
