"""CSV exporter for validation failure details.

Provides CSV export functionality for detailed failure analysis
and downstream processing in tools like Excel or data pipelines.
"""

import csv
from datetime import datetime, timezone
from io import StringIO
from pathlib import Path
from typing import Any

from datacheck.results import ValidationSummary


class CsvExporter:
    """Exporter for CSV output of validation failures.

    Provides detailed CSV exports of validation failures for:
    - Detailed analysis in spreadsheet tools
    - Integration with data pipelines
    - Audit and compliance reporting
    """

    @staticmethod
    def export_failures(
        summary: ValidationSummary,
        output_path: str | Path | None = None,
        include_passed: bool = False,
        include_suggestions: bool = True,
    ) -> str:
        """Export validation failures to CSV format.

        Args:
            summary: ValidationSummary to export
            output_path: Optional file path to write CSV (writes to file if provided)
            include_passed: Whether to include passed rules (default: False)
            include_suggestions: Whether to include fix suggestions (default: True)

        Returns:
            CSV string representation of failures
        """
        # Build CSV rows
        rows: list[dict[str, Any]] = []

        # Process each result
        for result in summary.results:
            # Skip passed rules unless requested
            if result.passed and not include_passed:
                continue

            # Base row data
            base_row = {
                "check_name": result.check_name or result.rule_name,
                "column": result.column,
                "rule_type": result.rule_type or "",
                "severity": result.severity,
                "status": "PASS" if result.passed else ("ERROR" if result.has_error else "FAIL"),
                "total_rows": result.total_rows,
                "failed_rows": result.failed_rows,
                "failure_rate": f"{(result.failed_rows / result.total_rows * 100):.2f}%" if result.total_rows > 0 else "0%",
                "error_message": result.error or "",
            }

            # If no failure details, add base row only
            if not result.failure_details or not result.failure_details.sample_failures:
                rows.append(base_row)
                continue

            # Add rows for each sample failure
            details = result.failure_details
            for i, row_idx in enumerate(details.sample_failures):
                row = base_row.copy()
                row["sample_row_index"] = row_idx
                row["sample_value"] = (
                    str(details.sample_values[i])
                    if i < len(details.sample_values)
                    else ""
                )
                row["failure_reason"] = (
                    details.sample_reasons[i]
                    if i < len(details.sample_reasons)
                    else ""
                )

                # Add suggestions if enabled
                if include_suggestions:
                    row["suggested_fix"] = CsvExporter._get_suggestion_for_value(
                        details.sample_values[i] if i < len(details.sample_values) else None,
                        result.rule_type or "",
                    )

                rows.append(row)

        # Generate CSV
        csv_string = CsvExporter._rows_to_csv(rows)

        # Write to file if path provided
        if output_path:
            path = Path(output_path)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(csv_string, encoding="utf-8")

        return csv_string

    @staticmethod
    def export_summary(
        summary: ValidationSummary,
        output_path: str | Path | None = None,
    ) -> str:
        """Export validation summary statistics to CSV format.

        Args:
            summary: ValidationSummary to export
            output_path: Optional file path to write CSV

        Returns:
            CSV string representation of summary
        """
        rows: list[dict[str, Any]] = []

        for result in summary.results:
            rows.append({
                "check_name": result.check_name or result.rule_name,
                "column": result.column,
                "rule_type": result.rule_type or "",
                "severity": result.severity,
                "status": "PASS" if result.passed else ("ERROR" if result.has_error else "FAIL"),
                "total_rows": result.total_rows,
                "failed_rows": result.failed_rows,
                "passed_rows": result.total_rows - result.failed_rows,
                "failure_rate": f"{(result.failed_rows / result.total_rows * 100):.2f}%" if result.total_rows > 0 else "0%",
                "success_rate": f"{result.success_rate:.2f}%",
                "error_message": result.error or "",
            })

        csv_string = CsvExporter._rows_to_csv(rows)

        if output_path:
            path = Path(output_path)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(csv_string, encoding="utf-8")

        return csv_string

    @staticmethod
    def export_detailed_failures(
        summary: ValidationSummary,
        output_path: str | Path | None = None,
    ) -> str:
        """Export detailed failure report with all sample values.

        Exports one row per failed sample value for detailed analysis.

        Args:
            summary: ValidationSummary to export
            output_path: Optional file path to write CSV

        Returns:
            CSV string representation of detailed failures
        """
        rows: list[dict[str, Any]] = []
        export_timestamp = datetime.now(timezone.utc).isoformat()

        for result in summary.get_failed_results():
            if not result.failure_details:
                continue

            details = result.failure_details

            for i, row_idx in enumerate(details.sample_failures):
                value = (
                    details.sample_values[i]
                    if i < len(details.sample_values)
                    else None
                )
                reason = (
                    details.sample_reasons[i]
                    if i < len(details.sample_reasons)
                    else ""
                )

                rows.append({
                    "export_timestamp": export_timestamp,
                    "rule_name": result.rule_name,
                    "check_name": result.check_name or result.rule_name,
                    "column": result.column,
                    "rule_type": result.rule_type or "",
                    "row_index": row_idx,
                    "failed_value": str(value) if value is not None else "NULL",
                    "value_type": type(value).__name__ if value is not None else "NoneType",
                    "failure_reason": reason,
                    "total_failures": result.failed_rows,
                    "total_rows": result.total_rows,
                    "failure_rate_pct": round((result.failed_rows / result.total_rows * 100), 2) if result.total_rows > 0 else 0,
                })

        csv_string = CsvExporter._rows_to_csv(rows)

        if output_path:
            path = Path(output_path)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(csv_string, encoding="utf-8")

        return csv_string

    @staticmethod
    def _rows_to_csv(rows: list[dict[str, Any]]) -> str:
        """Convert list of row dictionaries to CSV string.

        Args:
            rows: List of dictionaries representing CSV rows

        Returns:
            CSV formatted string
        """
        if not rows:
            return ""

        output = StringIO()

        # Collect all unique fieldnames from all rows (preserve order from first appearance)
        seen_fields: set[str] = set()
        fieldnames: list[str] = []
        for row in rows:
            for key in row.keys():
                if key not in seen_fields:
                    seen_fields.add(key)
                    fieldnames.append(key)

        writer = csv.DictWriter(
            output,
            fieldnames=fieldnames,
            quoting=csv.QUOTE_MINIMAL,
            lineterminator="\n",
            extrasaction="ignore",
        )

        writer.writeheader()
        writer.writerows(rows)

        return output.getvalue()

    @staticmethod
    def _get_suggestion_for_value(value: Any, rule_type: str) -> str:
        """Get a fix suggestion for a failed value.

        Args:
            value: The failed value
            rule_type: Type of the validation rule

        Returns:
            Suggestion string
        """
        if value is None:
            return "Replace NULL with default value"

        if rule_type == "not_null":
            return "Replace with default value"

        elif rule_type == "unique":
            return "Remove duplicate or assign unique ID"

        elif rule_type in ("min", "max"):
            return "Adjust value to meet threshold"

        elif rule_type == "date_format_valid":
            return "Convert to YYYY-MM-DD format"

        return "Review and correct value"


__all__ = [
    "CsvExporter",
]
