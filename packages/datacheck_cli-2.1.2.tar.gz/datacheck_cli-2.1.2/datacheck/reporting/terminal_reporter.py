"""Terminal reporter with table-based output."""

import sys

from rich import box
from rich.console import Console
from rich.table import Table
from rich.text import Text

from datacheck.reporting.suggestion_engine import Suggestion, SuggestionEngine
from datacheck.results import RuleResult, ValidationSummary


def _safe_encoding() -> bool:
    """Check if stdout can handle Unicode symbols."""
    encoding = getattr(sys.stdout, "encoding", None) or ""
    return encoding.lower().replace("-", "") in ("utf8", "utf16", "utf32", "utf16le", "utf16be")


_BULLET = "•" if _safe_encoding() else "*"
_ARROW = "→" if _safe_encoding() else "->"


class TerminalReporter:
    """Table-based terminal reporter modelled on datacontract CLI output.

    Renders every rule as a row in a rounded Rich table:

        ╭─────────┬─────────────────────────┬──────────┬──────────────────────────────────╮
        │ Result  │ Check                   │ Column   │ Details                          │
        ├─────────┼─────────────────────────┼──────────┼──────────────────────────────────┤
        │ passed  │ id_check · not_null     │ id       │                                  │
        │ failed  │ amount_check · min      │ amount   │ 42/1,000 rows (4.2%) — e.g. -5  │
        │ warning │ email_check · regex     │ email    │ 5/1,000 rows (0.5%)              │
        ╰─────────┴─────────────────────────┴──────────┴──────────────────────────────────╯
        🔴 Validation failed. Ran 10 checks on 1,000 rows — 8 passed, 1 failed, 1 warning.
    """

    def __init__(
        self,
        console: Console | None = None,
        show_suggestions: bool = True,
    ) -> None:
        self.console = console or Console()
        self.show_suggestions = show_suggestions
        self._suggestion_engine = SuggestionEngine()

    def report(
        self,
        summary: ValidationSummary,
        elapsed: float | None = None,
        source_info: str | None = None,
    ) -> None:
        """Print the full validation report.

        Args:
            summary: ValidationSummary to report
            elapsed: Optional elapsed time in seconds to display in the footer
            source_info: Human-readable description of the data source (e.g. "orders.csv" or "production_db → orders")
        """
        if source_info:
            self._print_source_header(source_info)
        self._print_table(summary)
        self._print_footer(summary, elapsed)

        # Print full error messages for execution errors (too long to fit in the table)
        error_results = summary.get_error_results()
        if error_results:
            self._print_execution_errors(error_results)

        if self.show_suggestions and (summary.has_failures or summary.has_errors):
            suggestions = self._suggestion_engine.analyze(summary)
            if suggestions:
                self._print_suggestions(suggestions)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    _ERROR_DETAIL_MAX = 60  # chars shown inline in the table for execution errors

    def _print_source_header(self, source_info: str) -> None:
        """Print a dim header line showing what is being validated."""
        self.console.print(f"[dim]Validating[/dim] [bold]{source_info}[/bold]")

    def _result_cell(self, result: RuleResult) -> Text:
        """Return a styled Text object for the Result column."""
        if result.has_error:
            return Text("error", style="bold red")
        if result.passed:
            return Text("passed", style="bold green")
        if result.severity == "warning":
            return Text("warning", style="bold yellow")
        if result.severity == "info":
            return Text("info", style="bold blue")
        return Text("failed", style="bold red")

    def _details_cell(self, result: RuleResult) -> str:
        """Return the Details column string for a rule result."""
        if result.has_error:
            err = str(result.error)
            if len(err) > self._ERROR_DETAIL_MAX:
                return err[: self._ERROR_DETAIL_MAX] + "… (see below)"
            return err
        if result.passed:
            return ""
        failure_rate = (
            result.failed_rows / result.total_rows * 100
            if result.total_rows > 0
            else 0.0
        )
        detail = f"{result.failed_rows:,}/{result.total_rows:,} rows failed ({failure_rate:.1f}%)"
        if result.failure_details and result.failure_details.sample_values:
            samples = [
                str(v)
                for v in result.failure_details.sample_values[:3]
                if v is not None
            ]
            if samples:
                detail += f" — e.g. {', '.join(samples)}"
        return detail

    def _print_table(self, summary: ValidationSummary) -> None:
        """Render all rule results as a single Rich table."""
        self.console.print()
        table = Table(
            show_header=True,
            header_style="bold",
            box=box.ROUNDED,
            padding=(0, 1),
            show_lines=False,
        )
        table.add_column("Result", width=9, no_wrap=True)
        table.add_column("Check")
        table.add_column("Column", style="cyan", no_wrap=True)
        table.add_column("Details")

        for result in summary.results:
            check_label = result.check_name or result.rule_name
            rule_type = result.rule_type or ""
            check_display = f"{check_label} · {rule_type}" if rule_type else check_label

            table.add_row(
                self._result_cell(result),
                check_display,
                result.column,
                self._details_cell(result),
            )

        self.console.print(table)
        self.console.print()

    def _print_footer(self, summary: ValidationSummary, elapsed: float | None) -> None:
        """Print the one-line summary footer."""
        if summary.all_passed and not summary.has_failures:
            icon = "🟢" if _safe_encoding() else "[OK]"
            status = "[green]All checks passed.[/green]"
        elif summary.all_passed:
            # Only warnings/info — pipeline not blocked
            icon = "🟡" if _safe_encoding() else "[WARN]"
            status = "[yellow]Passed with warnings.[/yellow]"
        else:
            icon = "🔴" if _safe_encoding() else "[FAIL]"
            status = "[red]Validation failed.[/red]"

        # Build the run summary
        if summary.total_rows > 0:
            run_info = f"Ran {summary.total_rules} checks on {summary.total_rows:,} rows"
        else:
            run_info = f"Ran {summary.total_rules} checks"

        counts = [f"[green]{summary.passed_rules} passed[/green]"]
        if summary.failed_errors > 0:
            counts.append(f"[red]{summary.failed_errors} failed[/red]")
        if summary.failed_warnings > 0:
            counts.append(f"[yellow]{summary.failed_warnings} warning{'s' if summary.failed_warnings != 1 else ''}[/yellow]")
        if summary.failed_info > 0:
            counts.append(f"[blue]{summary.failed_info} info[/blue]")
        if summary.error_rules > 0:
            counts.append(f"[red]{summary.error_rules} execution error{'s' if summary.error_rules != 1 else ''}[/red]")

        line = f"{icon} {status} {run_info} — {', '.join(counts)}."
        if elapsed is not None:
            line += f" Took {elapsed:.2f}s."

        self.console.print(line)
        self.console.print()

    def _print_execution_errors(self, error_results: list[RuleResult]) -> None:
        """Print full error messages for rules that had execution errors."""
        from rich.panel import Panel

        self.console.print(
            Panel.fit(
                "[bold red]Execution Errors[/bold red]",
                border_style="red",
            )
        )
        self.console.print()
        for result in error_results:
            check_label = result.check_name or result.rule_name
            rule_type = result.rule_type or ""
            check_display = f"{check_label} · {rule_type}" if rule_type else check_label
            self.console.print(
                f"[red]error[/red]  [bold]{check_display}[/bold] ([cyan]{result.column}[/cyan])"
            )
            self.console.print(f"  {result.error}")
            self.console.print()

    def _print_suggestions(self, suggestions: list[Suggestion]) -> None:
        """Print actionable suggestions below the table."""
        from rich.panel import Panel

        self.console.print(
            Panel.fit(
                "[bold]Suggestions[/bold]",
                border_style="cyan",
            )
        )
        self.console.print()

        for i, suggestion in enumerate(suggestions, 1):
            severity_styles = {
                "high": "[red]HIGH[/red]",
                "medium": "[yellow]MEDIUM[/yellow]",
                "low": "[blue]LOW[/blue]",
            }
            severity = severity_styles.get(suggestion.severity, suggestion.severity)

            self.console.print(
                f"{i}. {severity} - [bold]{suggestion.rule_name}[/bold] "
                f"([cyan]{suggestion.column}[/cyan])"
            )
            self.console.print(f"   [dim]Issue:[/dim] {suggestion.message}")
            self.console.print(f"   [dim]Action:[/dim] {suggestion.action}")

            if suggestion.impact:
                self.console.print(f"   [dim]Impact:[/dim] {suggestion.impact}")

            if suggestion.sample_fixes:
                self.console.print("   [dim]Sample Fixes:[/dim]")
                for fix in suggestion.sample_fixes[:3]:
                    self.console.print(
                        f"     {_BULLET} {fix['original_value']} {_ARROW} {fix['suggested_fix']}"
                    )

            self.console.print()


__all__ = [
    "TerminalReporter",
]
