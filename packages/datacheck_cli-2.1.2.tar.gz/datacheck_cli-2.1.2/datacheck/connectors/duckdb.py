"""DuckDB connector for DataCheck.

Queries CSV and Parquet files using DuckDB's in-process SQL engine.
Enables SQL aggregate pushdown for file-based sources with zero infrastructure.
"""

from __future__ import annotations

import re

import pandas as pd

from datacheck.connectors.base import DatabaseConnector
from datacheck.exceptions import DataLoadError

# Pattern for safe file paths: alphanumeric, slashes, dots, underscores, hyphens, colons (Windows)
_FILE_PATH_PATTERN = re.compile(r"^[a-zA-Z0-9_./:@\\\-]+$")


def _is_file_path(name: str) -> bool:
    """Return True if name looks like a file path rather than a SQL identifier."""
    lowered = name.lower()
    return (
        lowered.endswith(".csv")
        or lowered.endswith(".parquet")
        or "/" in name
        or "\\" in name
        or name.startswith(".")
    )


class DuckDBConnector(DatabaseConnector):
    """DuckDB connector that queries CSV and Parquet files via in-process SQL.

    DuckDB supports querying files directly using standard SQL:
        SELECT * FROM 'data.csv'
        SELECT * FROM 'data.parquet'

    This enables SQL aggregate pushdown for local file-based sources with no
    external database required.

    Args:
        path: Path to the CSV or Parquet file to query.
    """

    def __init__(self, path: str) -> None:
        super().__init__(connection_string=path)
        self._path = path
        self._conn = None

    def connect(self) -> None:
        """Open an in-memory DuckDB connection.

        Raises:
            DataLoadError: If duckdb package is not installed.
        """
        try:
            import duckdb
        except ImportError:
            raise DataLoadError(
                "DuckDB is not installed. "
                "Install it with: pip install datacheck-cli"
            )
        self._conn = duckdb.connect(database=":memory:")
        self._is_connected = True

    def disconnect(self) -> None:
        """Close the DuckDB connection."""
        if self._conn is not None:
            self._conn.close()
            self._conn = None
        self._is_connected = False

    def load_table(
        self,
        table_name: str,
        where: str | None = None,
        limit: int | None = None,
        columns: set[str] | None = None,
        **kwargs,
    ) -> pd.DataFrame:
        """Load data from a file or DuckDB table/view.

        Args:
            table_name: File path (e.g. './data.csv') or DuckDB table/view name.
            where: Optional WHERE clause (without 'WHERE' keyword).
            limit: Optional row limit.
            columns: Optional set of column names to project.

        Returns:
            DataFrame containing the loaded data.

        Raises:
            DataLoadError: If the query fails or connector is not connected.
        """
        if self._conn is None:
            raise DataLoadError("DuckDB connector is not connected")

        self._validate_table_name(table_name)

        if _is_file_path(table_name):
            table_ref = "'" + table_name.replace("'", "''") + "'"
        else:
            table_ref = '"' + table_name.replace('"', '""') + '"'

        if columns:
            col_list = ", ".join(f'"{c}"' for c in sorted(columns))
        else:
            col_list = "*"

        sql = f"SELECT {col_list} FROM {table_ref}"
        if where:
            self._validate_where_clause(where)
            sql += f" WHERE {where}"
        if limit is not None:
            sql += f" LIMIT {limit}"

        try:
            return self._conn.execute(sql).df()
        except Exception as e:
            raise DataLoadError(f"DuckDB query failed: {e}") from e

    def execute_query(self, query: str) -> pd.DataFrame:
        """Execute a SQL query and return results as a DataFrame.

        Args:
            query: SQL query to execute (used for aggregate pushdown queries).

        Returns:
            DataFrame containing query results.

        Raises:
            DataLoadError: If query fails or connector is not connected.
        """
        if self._conn is None:
            raise DataLoadError("DuckDB connector is not connected")
        try:
            return self._conn.execute(query).df()
        except Exception as e:
            raise DataLoadError(f"DuckDB query failed: {e}") from e

    def _validate_table_name(self, name: str) -> None:
        """Validate table name or file path to prevent injection.

        Accepts both SQL identifiers (letters, digits, underscores, dots)
        and file paths (additionally allows slashes, hyphens, colons).

        Raises:
            DataLoadError: If the name contains unsafe characters.
        """
        if _is_file_path(name):
            if not _FILE_PATH_PATTERN.match(name):
                raise DataLoadError(
                    f"Invalid file path '{name}'. "
                    "File paths must contain only alphanumeric characters, "
                    "slashes, dots, underscores, and hyphens."
                )
        else:
            super()._validate_table_name(name)


__all__ = ["DuckDBConnector"]
