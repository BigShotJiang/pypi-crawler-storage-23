"""Database connectors for DataCheck.

Uses lazy loading for heavy cloud connector dependencies to improve startup time.
"""

from datacheck.connectors.base import DatabaseConnector
from datacheck.connectors.mysql import MySQLConnector
from datacheck.connectors.postgresql import PostgreSQLConnector

# Lazy-loaded cloud data warehouse connectors
# These are loaded on first access to avoid startup overhead
_snowflake_connector = None
_bigquery_connector = None
_redshift_connector = None
_duckdb_connector = None


def __getattr__(name: str):
    """Lazy load cloud connectors on first access."""
    global _snowflake_connector, _bigquery_connector, _redshift_connector, _duckdb_connector

    if name == "SnowflakeConnector":
        if _snowflake_connector is None:
            try:
                from datacheck.connectors.snowflake import SnowflakeConnector as _SC
                _snowflake_connector = _SC
            except ImportError:
                _snowflake_connector = None
        return _snowflake_connector

    if name == "BigQueryConnector":
        if _bigquery_connector is None:
            try:
                from datacheck.connectors.bigquery import BigQueryConnector as _BQ
                _bigquery_connector = _BQ
            except ImportError:
                _bigquery_connector = None
        return _bigquery_connector

    if name == "RedshiftConnector":
        if _redshift_connector is None:
            try:
                from datacheck.connectors.redshift import RedshiftConnector as _RS
                _redshift_connector = _RS
            except ImportError:
                _redshift_connector = None
        return _redshift_connector

    if name == "DuckDBConnector":
        if _duckdb_connector is None:
            try:
                from datacheck.connectors.duckdb import DuckDBConnector as _DDB
                _duckdb_connector = _DDB
            except ImportError:
                _duckdb_connector = None
        return _duckdb_connector

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


# Note: SnowflakeConnector, BigQueryConnector, and RedshiftConnector are
# available via lazy loading through __getattr__ but are not listed in __all__
# to avoid CodeQL "Explicit export is not defined" errors.
__all__ = [
    "DatabaseConnector",
    "PostgreSQLConnector",
    "MySQLConnector",
]
