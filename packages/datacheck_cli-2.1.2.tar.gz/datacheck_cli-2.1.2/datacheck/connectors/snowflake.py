"""Snowflake data warehouse connector."""

import logging
from typing import Any

import pandas as pd

try:
    from snowflake.connector import connect as snowflake_connect
    from snowflake.connector.connection import SnowflakeConnection
    from snowflake.connector.errors import DatabaseError, ProgrammingError

    SNOWFLAKE_AVAILABLE = True
except ImportError:
    SNOWFLAKE_AVAILABLE = False
    SnowflakeConnection = Any  # type: ignore[assignment,misc]

from datacheck.connectors.base import DatabaseConnector
from datacheck.exceptions import DataLoadError

logger = logging.getLogger(__name__)


class SnowflakeConnector(DatabaseConnector):
    """Snowflake data warehouse connector.

    Connects to Snowflake and loads data into pandas DataFrames.

    Example:
        >>> connector = SnowflakeConnector(
        ...     account='xy12345.us-east-1',
        ...     user='myuser',
        ...     password='mypass',
        ...     warehouse='COMPUTE_WH',
        ...     database='ANALYTICS',
        ...     schema='PUBLIC'
        ... )
        >>> with connector:
        ...     df = connector.load_table("customers", sample_rate=0.1)
    """

    def __init__(
        self,
        account: str,
        user: str,
        password: str | None = None,
        warehouse: str | None = None,
        database: str | None = None,
        schema: str | None = None,
        role: str | None = None,
        authenticator: str | None = None,
        private_key_path: str | None = None,
        **kwargs: Any,
    ) -> None:
        """Initialize Snowflake connector.

        Args:
            account: Snowflake account identifier (e.g., 'xy12345.us-east-1')
            user: Username
            password: Password (not required if using SSO or key pair)
            warehouse: Virtual warehouse name
            database: Database name
            schema: Schema name (default: PUBLIC)
            role: Role to use
            authenticator: Authentication method ('snowflake', 'externalbrowser' for SSO)
            private_key_path: Path to private key file for key pair auth
            **kwargs: Additional connection parameters

        Raises:
            DataLoadError: If snowflake-connector-python is not installed
        """
        if not SNOWFLAKE_AVAILABLE:
            raise DataLoadError(
                "Snowflake connector dependencies are not installed. "
                "Install with: pip install 'datacheck[snowflake]'"
            )

        # Build connection string for base class
        connection_string = f"snowflake://{account}/{database or ''}"
        super().__init__(connection_string)

        self.account = account
        self.user = user
        self.password = password
        self.warehouse = warehouse
        self.database = database
        self.schema = schema or "PUBLIC"
        self.role = role
        self.authenticator = authenticator or "snowflake"
        self.private_key_path = private_key_path
        self.kwargs = kwargs
        self.connection: SnowflakeConnection | None = None

    def connect(self) -> None:
        """Establish connection to Snowflake.

        Raises:
            DataLoadError: If connection fails
        """
        try:
            # Build connection parameters
            conn_params: dict[str, Any] = {
                "account": self.account,
                "user": self.user,
                "authenticator": self.authenticator,
            }

            # Add password if using password auth
            if self.password and self.authenticator == "snowflake":
                conn_params["password"] = self.password

            # Add optional parameters
            if self.warehouse:
                conn_params["warehouse"] = self.warehouse
            if self.database:
                conn_params["database"] = self.database
            if self.schema:
                conn_params["schema"] = self.schema
            if self.role:
                conn_params["role"] = self.role

            # Add any extra kwargs
            conn_params.update(self.kwargs)

            # Establish connection
            self.connection = snowflake_connect(**conn_params)
            self._is_connected = True
            logger.info(f"Connected to Snowflake account: {self.account}")

        except (DatabaseError, ProgrammingError) as e:
            raise DataLoadError(f"Failed to connect to Snowflake: {e}") from e
        except Exception as e:
            raise DataLoadError(f"Unexpected error connecting to Snowflake: {e}") from e

    def disconnect(self) -> None:
        """Close Snowflake connection."""
        if self.connection:
            try:
                self.connection.close()
                logger.info("Snowflake connection closed successfully")
            except Exception as e:
                logger.warning(f"Error closing Snowflake connection: {e}")
            finally:
                self._is_connected = False
                self.connection = None

    def load_table(
        self,
        table_name: str,
        where: str | None = None,
        limit: int | None = None,
        schema: str | None = None,
        sample_rate: float | None = None,
        sample_rows: int | None = None,
        columns: set[str] | None = None,
    ) -> pd.DataFrame:
        """Load data from Snowflake table.

        Args:
            table_name: Name of the table to load
            where: Optional WHERE clause (without 'WHERE' keyword)
            limit: Optional row limit
            schema: Schema name (overrides default)
            sample_rate: Sample fraction 0.0-1.0 (uses Snowflake SAMPLE)
            sample_rows: Number of rows to sample (alternative to sample_rate)

        Returns:
            DataFrame containing table data

        Raises:
            DataLoadError: If not connected or table loading fails

        Example:
            # Read full table
            df = connector.load_table('CUSTOMERS')

            # Read with 10% sampling
            df = connector.load_table('CUSTOMERS', sample_rate=0.1)

            # Read specific number of sampled rows
            df = connector.load_table('CUSTOMERS', sample_rows=1000)

            # Read with filter
            df = connector.load_table('CUSTOMERS', where="created_at > '2024-01-01'")
        """
        if not self.is_connected:
            raise DataLoadError("Not connected to Snowflake. Call connect() first.")

        self._validate_table_name(table_name)

        try:
            # Build fully qualified table name
            effective_schema = schema or self.schema
            if "." in table_name:
                # Already qualified
                full_table_name = table_name
            elif effective_schema:
                full_table_name = f"{effective_schema}.{table_name}"
            else:
                full_table_name = table_name

            # Build query (table_name validated by _validate_table_name above)
            if columns:
                col_list = ", ".join(f'"{c}"' for c in sorted(columns))
                query_parts = [f"SELECT {col_list} FROM {full_table_name}"]  # nosec B608
            else:
                query_parts = [f"SELECT * FROM {full_table_name}"]  # nosec B608

            # Add sampling clause (Snowflake specific)
            # SAMPLE clause comes before WHERE
            if sample_rate is not None:
                if not 0.0 < sample_rate <= 1.0:
                    raise DataLoadError(
                        f"Invalid sample_rate: {sample_rate}. Must be between 0.0 and 1.0"
                    )
                percentage = sample_rate * 100
                query_parts.append(f" SAMPLE ({percentage})")
            elif sample_rows is not None:
                if sample_rows <= 0:
                    raise DataLoadError(
                        f"Invalid sample_rows: {sample_rows}. Must be positive"
                    )
                query_parts.append(f" SAMPLE ({sample_rows} ROWS)")

            # Add WHERE clause
            if where:
                self._validate_where_clause(where)
                query_parts.append(f" WHERE {where}")

            # Add LIMIT
            if limit:
                if not isinstance(limit, int) or limit <= 0:
                    raise DataLoadError(
                        f"Invalid limit: {limit}. Must be a positive integer."
                    )
                query_parts.append(f" LIMIT {int(limit)}")

            query = "".join(query_parts)
            logger.debug(f"Executing Snowflake query: {query}")

            # Execute query using cursor for better performance
            cursor = self.connection.cursor()  # type: ignore[union-attr]
            try:
                cursor.execute(query)
                df = cursor.fetch_pandas_all()
                return df
            finally:
                cursor.close()

        except DataLoadError:
            raise
        except (DatabaseError, ProgrammingError) as e:
            raise DataLoadError(f"Failed to load table '{table_name}': {e}") from e
        except Exception as e:
            raise DataLoadError(
                f"Unexpected error loading table '{table_name}': {e}"
            ) from e

    def execute_query(self, query: str) -> pd.DataFrame:
        """Execute custom SQL query on Snowflake.

        Args:
            query: SQL query to execute

        Returns:
            DataFrame containing query results

        Raises:
            DataLoadError: If not connected or query execution fails
        """
        if not self.is_connected:
            raise DataLoadError("Not connected to Snowflake. Call connect() first.")

        try:
            cursor = self.connection.cursor()  # type: ignore[union-attr]
            try:
                cursor.execute(query)
                df = cursor.fetch_pandas_all()
                return df
            finally:
                cursor.close()
        except (DatabaseError, ProgrammingError) as e:
            raise DataLoadError(f"Failed to execute query: {e}") from e
        except Exception as e:
            raise DataLoadError(f"Unexpected error executing query: {e}") from e

    def get_current_warehouse(self) -> str:
        """Get the current warehouse name.

        Returns:
            Current warehouse name

        Raises:
            DataLoadError: If not connected or query fails
        """
        if not self.is_connected:
            raise DataLoadError("Not connected to Snowflake. Call connect() first.")
        try:
            df = self.execute_query("SELECT CURRENT_WAREHOUSE()")
            return df.iloc[0, 0] if len(df) > 0 else ""
        except Exception as e:
            raise DataLoadError(f"Failed to get current warehouse: {e}") from e

    def get_current_database(self) -> str:
        """Get the current database name.

        Returns:
            Current database name

        Raises:
            DataLoadError: If not connected or query fails
        """
        if not self.is_connected:
            raise DataLoadError("Not connected to Snowflake. Call connect() first.")
        try:
            df = self.execute_query("SELECT CURRENT_DATABASE()")
            return df.iloc[0, 0] if len(df) > 0 else ""
        except Exception as e:
            raise DataLoadError(f"Failed to get current database: {e}") from e


__all__ = ["SnowflakeConnector"]
