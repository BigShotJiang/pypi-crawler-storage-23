"""Airflow integration for DataCheck.

Provides two operators for enforcing DataCheck validation rules
in Airflow pipelines:

- DataCheckOperator: Enforce validation rules against configured data sources
- DataCheckSchemaOperator: Enforce schema contracts against saved baselines

For complex workflows, you can also use the CLI via BashOperator.
"""

from datacheck.airflow.operators import (
    DataCheckOperator,
    DataCheckSchemaOperator,
)

__all__ = [
    "DataCheckOperator",
    "DataCheckSchemaOperator",
]
