"""Custom log formatters for DataCheck."""

import json
import logging
from datetime import datetime, timezone
from typing import Any


class JsonFormatter(logging.Formatter):
    """JSON formatter for machine-parseable log output.

    Produces JSON logs suitable for log aggregators like ELK, Splunk,
    or CloudWatch.

    Example output:
        {"timestamp": "2026-01-27T10:30:45.123Z", "level": "INFO",
         "logger": "datacheck.engine", "message": "validation_started",
         "rows": 10000, "trace_id": "abc-123"}
    """

    def __init__(
        self,
        include_timestamp: bool = True,
        include_level: bool = True,
        include_logger: bool = True,
        timestamp_format: str = "iso",
    ) -> None:
        """Initialize JSON formatter.

        Args:
            include_timestamp: Include timestamp in output
            include_level: Include log level in output
            include_logger: Include logger name in output
            timestamp_format: Timestamp format ("iso" or strftime format)
        """
        super().__init__()
        self.include_timestamp = include_timestamp
        self.include_level = include_level
        self.include_logger = include_logger
        self.timestamp_format = timestamp_format

    def format(self, record: logging.LogRecord) -> str:
        """Format log record as JSON.

        Args:
            record: Log record to format

        Returns:
            JSON string
        """
        log_data: dict[str, Any] = {}

        # Add timestamp
        if self.include_timestamp:
            if self.timestamp_format == "iso":
                log_data["timestamp"] = datetime.fromtimestamp(
                    record.created, tz=timezone.utc
                ).isoformat()
            else:
                log_data["timestamp"] = datetime.fromtimestamp(
                    record.created, tz=timezone.utc
                ).strftime(self.timestamp_format)

        # Add level
        if self.include_level:
            log_data["level"] = record.levelname.lower()

        # Add logger name
        if self.include_logger:
            log_data["logger"] = record.name

        # Add message
        log_data["event"] = record.getMessage()

        # Add extra fields from record
        if hasattr(record, "__dict__"):
            # Skip standard LogRecord attributes
            skip_attrs = {
                "name",
                "msg",
                "args",
                "created",
                "filename",
                "funcName",
                "levelname",
                "levelno",
                "lineno",
                "module",
                "msecs",
                "pathname",
                "process",
                "processName",
                "relativeCreated",
                "stack_info",
                "exc_info",
                "exc_text",
                "thread",
                "threadName",
                "message",
                "taskName",
            }

            for key, value in record.__dict__.items():
                if key not in skip_attrs and not key.startswith("_"):
                    try:
                        # Ensure value is JSON serializable
                        json.dumps(value)
                        log_data[key] = value
                    except (TypeError, ValueError):
                        log_data[key] = str(value)

        # Add exception info if present
        if record.exc_info:
            log_data["exc_info"] = self.formatException(record.exc_info)

        return json.dumps(log_data, default=str)


class ConsoleFormatter(logging.Formatter):
    """Human-readable console formatter for development.

    Produces colorized, easy-to-read log output for terminal use.

    Example output:
        2026-01-27 10:30:45 [INFO    ] validation_started rows=10000 trace_id=abc-123
    """

    # ANSI color codes
    COLORS = {
        "DEBUG": "\033[36m",  # Cyan
        "INFO": "\033[32m",  # Green
        "WARNING": "\033[33m",  # Yellow
        "ERROR": "\033[31m",  # Red
        "CRITICAL": "\033[35m",  # Magenta
    }
    RESET = "\033[0m"

    def __init__(
        self,
        colorize: bool = True,
        show_timestamp: bool = True,
        show_level: bool = True,
        show_logger: bool = False,
        timestamp_format: str = "%Y-%m-%d %H:%M:%S",
    ) -> None:
        """Initialize console formatter.

        Args:
            colorize: Enable ANSI color codes
            show_timestamp: Show timestamp
            show_level: Show log level
            show_logger: Show logger name
            timestamp_format: strftime format for timestamp
        """
        super().__init__()
        self.colorize = colorize
        self.show_timestamp = show_timestamp
        self.show_level = show_level
        self.show_logger = show_logger
        self.timestamp_format = timestamp_format

    def format(self, record: logging.LogRecord) -> str:
        """Format log record for console output.

        Args:
            record: Log record to format

        Returns:
            Formatted string
        """
        parts: list[str] = []

        # Timestamp
        if self.show_timestamp:
            timestamp = datetime.fromtimestamp(record.created).strftime(
                self.timestamp_format
            )
            parts.append(timestamp)

        # Level with color
        if self.show_level:
            level = record.levelname
            if self.colorize and level in self.COLORS:
                level_str = f"{self.COLORS[level]}[{level:8}]{self.RESET}"
            else:
                level_str = f"[{level:8}]"
            parts.append(level_str)

        # Logger name
        if self.show_logger:
            parts.append(f"[{record.name}]")

        # Message
        message = record.getMessage()
        parts.append(message)

        # Extra fields
        extras: list[str] = []
        skip_attrs = {
            "name",
            "msg",
            "args",
            "created",
            "filename",
            "funcName",
            "levelname",
            "levelno",
            "lineno",
            "module",
            "msecs",
            "pathname",
            "process",
            "processName",
            "relativeCreated",
            "stack_info",
            "exc_info",
            "exc_text",
            "thread",
            "threadName",
            "message",
            "taskName",
        }

        for key, value in record.__dict__.items():
            if key not in skip_attrs and not key.startswith("_"):
                if self.colorize:
                    extras.append(f"\033[34m{key}\033[0m={value}")
                else:
                    extras.append(f"{key}={value}")

        if extras:
            parts.append(" ".join(extras))

        result = " ".join(parts)

        # Add exception info
        if record.exc_info:
            result += "\n" + self.formatException(record.exc_info)

        return result
