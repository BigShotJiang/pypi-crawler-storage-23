"""Logging utilities for trace IDs and performance metrics."""

import contextvars
import time
import uuid
from contextlib import contextmanager
from functools import wraps
from typing import Any, TypeVar
from collections.abc import Callable, Generator

# Context variable for trace ID (thread-safe)
_trace_id_var: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "trace_id", default=None
)

# Type variable for generic function signatures
F = TypeVar("F", bound=Callable[..., Any])


def generate_trace_id() -> str:
    """Generate a unique trace ID.

    Returns:
        A UUID4 string for tracking requests across log entries.

    Example:
        >>> trace_id = generate_trace_id()
        >>> print(trace_id)  # e.g., "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
    """
    return str(uuid.uuid4())


def set_trace_id(trace_id: str | None = None) -> str:
    """Set trace ID for current context.

    Args:
        trace_id: Trace ID to set. If None, generates a new one.

    Returns:
        The trace ID that was set.

    Example:
        >>> trace_id = set_trace_id()  # Generate new
        >>> set_trace_id("custom-trace-123")  # Use custom
    """
    if trace_id is None:
        trace_id = generate_trace_id()
    _trace_id_var.set(trace_id)
    return trace_id


def get_trace_id() -> str | None:
    """Get trace ID for current context.

    Returns:
        Current trace ID or None if not set.

    Example:
        >>> set_trace_id("my-trace-id")
        >>> get_trace_id()
        'my-trace-id'
    """
    return _trace_id_var.get()


def clear_trace_id() -> None:
    """Clear trace ID for current context."""
    _trace_id_var.set(None)


def add_trace_id(
    logger: Any, method_name: str, event_dict: dict[str, Any]
) -> dict[str, Any]:
    """Structlog processor to add trace ID to events.

    This processor automatically adds the current trace ID to all log events,
    enabling request tracking across distributed systems.

    Args:
        logger: Logger instance (unused, required by structlog)
        method_name: Log method name (unused, required by structlog)
        event_dict: Event dictionary to process

    Returns:
        Event dictionary with trace_id added if available.

    Example:
        Used as a structlog processor:
        >>> processors = [add_trace_id, ...]
    """
    trace_id = get_trace_id()
    if trace_id:
        event_dict["trace_id"] = trace_id
    return event_dict


@contextmanager
def trace_context(trace_id: str | None = None) -> Generator[str, None, None]:
    """Context manager for trace ID scope.

    Automatically sets and clears trace ID within a context.

    Args:
        trace_id: Trace ID to use. If None, generates a new one.

    Yields:
        The trace ID being used.

    Example:
        >>> with trace_context() as tid:
        ...     logger.info("operation", trace_id=tid)
    """
    previous_trace_id = get_trace_id()
    current_trace_id = set_trace_id(trace_id)
    try:
        yield current_trace_id
    finally:
        if previous_trace_id:
            _trace_id_var.set(previous_trace_id)
        else:
            clear_trace_id()


@contextmanager
def timed_operation(
    operation_name: str, logger: Any = None
) -> Generator[dict[str, Any], None, None]:
    """Context manager for timing operations.

    Tracks start time, end time, and duration of an operation.

    Args:
        operation_name: Name of the operation being timed
        logger: Optional logger to log timing info

    Yields:
        Dictionary with timing information (updated on exit)

    Example:
        >>> with timed_operation("data_validation") as timing:
        ...     # perform validation
        ...     pass
        >>> print(timing["duration_seconds"])
    """
    timing: dict[str, Any] = {
        "operation": operation_name,
        "start_time": time.time(),
        "end_time": None,
        "duration_seconds": None,
    }

    try:
        yield timing
    finally:
        timing["end_time"] = time.time()
        timing["duration_seconds"] = round(timing["end_time"] - timing["start_time"], 4)

        if logger:
            logger.debug(
                "operation_timed",
                operation=operation_name,
                duration_seconds=timing["duration_seconds"],
            )


def log_timing(logger: Any) -> Callable[[F], F]:
    """Decorator to log function execution time.

    Args:
        logger: Logger instance to use for logging

    Returns:
        Decorator function

    Example:
        >>> @log_timing(logger)
        ... def my_function():
        ...     pass
    """

    def decorator(func: F) -> F:
        """Wrap the function with timing instrumentation."""
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            """Execute the wrapped function and log its duration."""
            start_time = time.time()
            try:
                result = func(*args, **kwargs)
                duration = time.time() - start_time
                logger.debug(
                    "function_completed",
                    function=func.__name__,
                    duration_seconds=round(duration, 4),
                )
                return result
            except Exception as e:
                duration = time.time() - start_time
                logger.error(
                    "function_failed",
                    function=func.__name__,
                    duration_seconds=round(duration, 4),
                    error=str(e),
                    error_type=type(e).__name__,
                )
                raise

        return wrapper  # type: ignore[return-value]

    return decorator
