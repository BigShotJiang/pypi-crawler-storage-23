"""Structured logging for DataCheck.

This module provides production-ready structured logging with:
- Multiple log levels (DEBUG, INFO, WARNING, ERROR, CRITICAL)
- Multiple formats (console for development, JSON for production)
- File output with rotation
- Trace IDs for request tracking
- Sensitive data masking
- Performance metrics

Example:
    >>> from datacheck.logging import configure_logging, get_logger
    >>> configure_logging(level="DEBUG", format_type="json")
    >>> logger = get_logger(__name__)
    >>> logger.info("validation_started", extra={"rows": 1000})
"""

from datacheck.logging.config import (
    configure_logging,
    get_logger,
    create_logger_with_context,
    LoggerAdapter,
    reset_logging,
)
from datacheck.logging.filters import (
    mask_sensitive_data,
    SensitiveDataFilter,
    is_sensitive_key,
    mask_value,
    REDACTED,
)
from datacheck.logging.formatters import (
    JsonFormatter,
    ConsoleFormatter,
)
from datacheck.logging.utils import (
    generate_trace_id,
    set_trace_id,
    get_trace_id,
    clear_trace_id,
    add_trace_id,
    trace_context,
    timed_operation,
    log_timing,
)

__all__ = [
    # Configuration
    "configure_logging",
    "get_logger",
    "create_logger_with_context",
    "LoggerAdapter",
    "reset_logging",
    # Filters
    "mask_sensitive_data",
    "SensitiveDataFilter",
    "is_sensitive_key",
    "mask_value",
    "REDACTED",
    # Formatters
    "JsonFormatter",
    "ConsoleFormatter",
    # Trace ID utilities
    "generate_trace_id",
    "set_trace_id",
    "get_trace_id",
    "clear_trace_id",
    "add_trace_id",
    "trace_context",
    # Timing utilities
    "timed_operation",
    "log_timing",
]
