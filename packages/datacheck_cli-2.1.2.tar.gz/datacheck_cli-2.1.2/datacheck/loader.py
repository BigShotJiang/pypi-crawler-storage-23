"""Data loaders for various formats."""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import TYPE_CHECKING, Any

import pandas as pd

from datacheck.exceptions import DataLoadError, EmptyDatasetError, UnsupportedFormatError

if TYPE_CHECKING:
    from datacheck.connectors.base import DatabaseConnector


class DataLoader(ABC):
    """Abstract base class for data loaders.

    Attributes:
        file_path: Path to the data file
    """

    def __init__(self, file_path: str | Path) -> None:
        """Initialize data loader.

        Args:
            file_path: Path to the data file

        Raises:
            DataLoadError: If file does not exist
        """
        self.file_path = Path(file_path)
        if not self.file_path.exists():
            raise DataLoadError(f"File not found: {file_path}")
        if not self.file_path.is_file():
            raise DataLoadError(f"Path is not a file: {file_path}")

    @abstractmethod
    def load(self) -> pd.DataFrame:
        """Load data from file into a pandas DataFrame.

        Returns:
            DataFrame containing the loaded data

        Raises:
            DataLoadError: If data cannot be loaded
            EmptyDatasetError: If loaded data is empty
        """
        pass

    def _validate_dataframe(self, df: pd.DataFrame) -> None:
        """Validate that DataFrame is not empty.

        Args:
            df: DataFrame to validate

        Raises:
            EmptyDatasetError: If DataFrame is empty
        """
        if df.empty:
            raise EmptyDatasetError(f"Dataset is empty: {self.file_path}")


class CSVLoader(DataLoader):
    """Loader for CSV files with automatic encoding detection."""

    def __init__(
        self,
        file_path: str | Path,
        encoding: str | None = None,
        delimiter: str = ",",
        columns: list[str] | None = None,
        **kwargs: Any,
    ) -> None:
        """Initialize CSV loader.

        Args:
            file_path: Path to the CSV file
            encoding: File encoding (auto-detected if None)
            delimiter: CSV delimiter character
            columns: Column subset to load (None = all columns)
            **kwargs: Additional arguments passed to pandas.read_csv
        """
        super().__init__(file_path)
        self.encoding = encoding
        self.delimiter = delimiter
        self.columns = columns
        self.kwargs = kwargs

    def _detect_encoding(self) -> str:
        """Detect file encoding.

        Returns:
            Detected encoding (defaults to utf-8 if detection fails)
        """
        if self.encoding:
            return self.encoding

        # Try common encodings
        encodings = ["utf-8", "utf-8-sig", "latin-1", "iso-8859-1", "cp1252"]

        for encoding in encodings:
            try:
                with open(self.file_path, encoding=encoding) as f:
                    f.read(1024)  # Try to read first 1KB
                return encoding
            except (UnicodeDecodeError, LookupError):
                continue

        # Default to utf-8 if all fail
        return "utf-8"

    def load(self) -> pd.DataFrame:
        """Load CSV file into DataFrame.

        Returns:
            DataFrame containing CSV data

        Raises:
            DataLoadError: If CSV cannot be loaded
            EmptyDatasetError: If CSV is empty
        """
        try:
            encoding = self._detect_encoding()
            usecols_kwarg = {"usecols": self.columns} if self.columns is not None else {}
            try:
                # Use PyArrow engine for faster CSV parsing + Arrow-backed dtypes
                df: pd.DataFrame = pd.read_csv(  # type: ignore[call-overload]
                    self.file_path,
                    encoding=encoding,
                    delimiter=self.delimiter,
                    dtype_backend="pyarrow",
                    engine="pyarrow",
                    **usecols_kwarg,
                    **self.kwargs,
                )
            except Exception:
                # Fallback to default engine for exotic encodings or edge cases
                df = pd.read_csv(  # type: ignore[call-overload]
                    self.file_path,
                    encoding=encoding,
                    delimiter=self.delimiter,
                    dtype_backend="pyarrow",
                    **usecols_kwarg,
                    **self.kwargs,
                )
            self._validate_dataframe(df)
            return df
        except EmptyDatasetError:
            raise
        except Exception as e:
            raise DataLoadError(f"Error loading CSV file {self.file_path}: {e}") from e


class ParquetLoader(DataLoader):
    """Loader for Parquet files."""

    def __init__(
        self,
        file_path: str | Path,
        columns: list[str] | None = None,
        **kwargs: Any,
    ) -> None:
        """Initialize Parquet loader.

        Args:
            file_path: Path to the Parquet file
            columns: Optional list of columns to read (None for all)
            **kwargs: Additional arguments passed to pandas.read_parquet
        """
        super().__init__(file_path)
        self.columns = columns
        self.kwargs = kwargs

    def load(self) -> pd.DataFrame:
        """Load Parquet file into DataFrame.

        Returns:
            DataFrame containing Parquet data

        Raises:
            DataLoadError: If Parquet cannot be loaded
            EmptyDatasetError: If Parquet is empty
        """
        try:
            df = pd.read_parquet(
                self.file_path,
                columns=self.columns,
                dtype_backend="pyarrow",
                **self.kwargs,
            )
            self._validate_dataframe(df)
            return df
        except EmptyDatasetError:
            raise
        except Exception as e:
            raise DataLoadError(f"Error loading Parquet file {self.file_path}: {e}") from e


class DatabaseLoader(DataLoader):
    """Loader for database sources."""

    connector: "DatabaseConnector"

    def __init__(
        self,
        source: str,
        table: str | None = None,
        where: str | None = None,
        query: str | None = None
    ) -> None:
        """Initialize database loader.

        Args:
            source: Database connection string
            table: Table name to load (if not using custom query)
            where: Optional WHERE clause
            query: Optional custom SQL query
        """
        # Skip parent __init__ file-path checks; databases don't use file paths.
        # Call ABC.__init__ directly to satisfy the MRO.
        ABC.__init__(self)
        self.source = source
        self.table = table
        self.where = where
        self.query = query

        # Detect database type from connection string
        from datacheck.connectors.base import DatabaseConnector
        connector: DatabaseConnector
        if source.startswith("postgresql://") or source.startswith("postgres://"):
            from datacheck.connectors.postgresql import PostgreSQLConnector
            connector = PostgreSQLConnector(source)
        elif source.startswith("mysql://"):
            from datacheck.connectors.mysql import MySQLConnector
            connector = MySQLConnector(source)
        else:
            raise DataLoadError(f"Unsupported database type in: {source}")
        self.connector = connector

    def load(self) -> pd.DataFrame:
        """Load data from database.

        Returns:
            DataFrame containing database data

        Raises:
            DataLoadError: If loading fails
        """
        if not self.connector:
            raise DataLoadError("Database connector not initialized")

        with self.connector:
            if self.query:
                return self.connector.execute_query(self.query)
            if self.table:
                return self.connector.load_table(self.table, where=self.where)

        raise DataLoadError("Either 'table' or 'query' must be specified")


class LoaderFactory:
    """Factory for creating appropriate data loaders based on file format."""

    @staticmethod
    def create_loader(source: str | Path, **kwargs: Any) -> DataLoader:
        """Create appropriate loader based on source type.

        Args:
            source: Data source (file path or connection string)
            **kwargs: Additional arguments for specific loaders

        Returns:
            DataLoader instance

        Raises:
            DataLoadError: If source type cannot be determined
            UnsupportedFormatError: If file format is not supported
        """
        source_str = str(source)

        # Check if it's a database connection string
        if source_str.startswith(("postgresql://", "postgres://", "mysql://")):
            return DatabaseLoader(
                source_str,
                table=kwargs.get("table"),
                where=kwargs.get("where"),
                query=kwargs.get("query")
            )

        # File-based loaders
        source_path = Path(source)

        if not source_path.exists():
            raise DataLoadError(f"File not found: {source}")

        if not source_path.is_file():
            raise DataLoadError(f"Path is not a file: {source}")

        ext = source_path.suffix.lower()

        # Filter out non-file-loader kwargs
        file_kwargs = {k: v for k, v in kwargs.items()
                      if k not in ["table", "where", "query", "columns"]}

        if ext == ".csv":
            csv_columns = kwargs.get("columns")
            return CSVLoader(source_path, columns=csv_columns, **file_kwargs)
        elif ext in [".parquet", ".pq"]:
            parquet_columns = kwargs.get("columns")
            return ParquetLoader(source_path, columns=parquet_columns, **file_kwargs)
        else:
            raise UnsupportedFormatError(
                f"Unsupported file format: {ext}. "
                f"Supported formats: .csv, .parquet, .pq"
            )

    @staticmethod
    def load(file_path: str | Path, **kwargs: Any) -> pd.DataFrame:
        """Load data from file using appropriate loader.

        Args:
            file_path: Path to the data file
            **kwargs: Additional arguments passed to the loader

        Returns:
            DataFrame containing the loaded data

        Raises:
            UnsupportedFormatError: If file format is not supported
            DataLoadError: If data cannot be loaded
            EmptyDatasetError: If loaded data is empty
        """
        loader = LoaderFactory.create_loader(file_path, **kwargs)
        return loader.load()


__all__ = [
    "DataLoader",
    "CSVLoader",
    "ParquetLoader",
    "DatabaseLoader",
    "LoaderFactory",
]
