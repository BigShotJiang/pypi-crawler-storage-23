"""Schema commands for DataCheck CLI."""

import sys
from pathlib import Path

import typer
from rich.table import Table

import pandas as pd

from datacheck.cli import console


def _safe_encoding() -> bool:
    """Check if stdout can handle Unicode symbols."""
    encoding = getattr(sys.stdout, "encoding", None) or ""
    return encoding.lower().replace("-", "") in ("utf8", "utf16", "utf32", "utf16le", "utf16be")


_TICK = "✓" if _safe_encoding() else "v"
from datacheck.exceptions import DataLoadError

# Schema sub-app for schema contract enforcement commands
schema_app = typer.Typer(
    name="schema",
    help="Enforce schema contracts - capture baselines and fail on breaking changes",
)


def _resolve_data_source(
    data_source: str | None,
    config: str | None,
    source: str | None,
    sources_file: str | None,
    table: str | None = None,
    query: str | None = None,
) -> tuple[pd.DataFrame, str]:
    """Resolve and load data from various source options.

    Returns:
        Tuple of (DataFrame, resolved_source_name)
    """
    from datacheck.loader import LoaderFactory
    from datacheck.config import ConfigLoader
    from datacheck.config.source import load_sources
    from datacheck.connectors.factory import load_source_data

    df = None
    resolved_source_name = None

    # Option 1: Named source from sources file
    if source:
        if sources_file:
            sources_path = Path(sources_file)
        else:
            # Try to find sources from config
            if config:
                config_data = ConfigLoader.load(config)
                if config_data.sources_file:
                    sources_path = Path(config).parent / config_data.sources_file
                else:
                    console.print(
                        "[red]Error:[/red] --source requires --sources-file or sources_file in config",
                        style="red",
                    )
                    raise typer.Exit(code=2)
            else:
                console.print(
                    "[red]Error:[/red] --source requires --sources-file",
                    style="red",
                )
                raise typer.Exit(code=2)

        sources = load_sources(sources_path)
        if source not in sources:
            console.print(
                f"[red]Error:[/red] Source '{source}' not found. "
                f"Available: {', '.join(sorted(sources.keys()))}",
                style="red",
            )
            raise typer.Exit(code=2)

        source_config = sources[source]
        df = load_source_data(source_config, table=table, query=query)
        resolved_source_name = source

    # Option 2: Default source from config
    elif data_source is None and config:
        config_data = ConfigLoader.load(config)
        config_dir = Path(config).parent
        if config_data.sources_file and config_data.source:
            sources_path = config_dir / config_data.sources_file
            sources = load_sources(sources_path)
            if config_data.source not in sources:
                console.print(
                    f"[red]Error:[/red] Default source '{config_data.source}' not found",
                    style="red",
                )
                raise typer.Exit(code=2)
            source_config = sources[config_data.source]
            df = load_source_data(source_config, table=table, query=query)
            resolved_source_name = config_data.source
        else:
            console.print(
                "[red]Error:[/red] Config file has no sources_file/source defined. "
                "Use --source with --sources-file.",
                style="red",
            )
            raise typer.Exit(code=2)

    # Option 3: Auto-discover config file
    elif data_source is None:
        found_config = ConfigLoader.find_config()
        if found_config:
            config_data = ConfigLoader.load(found_config)
            config_dir = found_config.parent
            if config_data.sources_file and config_data.source:
                sources_path = config_dir / config_data.sources_file
                sources = load_sources(sources_path)
                if config_data.source in sources:
                    source_config = sources[config_data.source]
                    df = load_source_data(source_config, table=table, query=query)
                    resolved_source_name = config_data.source
                else:
                    console.print(
                        f"[red]Error:[/red] Source '{config_data.source}' not found",
                        style="red",
                    )
                    raise typer.Exit(code=2)
            else:
                console.print(
                    "[red]Error:[/red] No data source specified. "
                    "Provide a file path as argument, or use --source with --sources-file.",
                    style="red",
                )
                raise typer.Exit(code=2)
        else:
            console.print(
                "[red]Error:[/red] No data source specified. "
                "Provide a file path as argument, or use --source with --sources-file.",
                style="red",
            )
            raise typer.Exit(code=2)

    # Option 4: Direct data source argument
    else:
        df = LoaderFactory.load(data_source, table=table, query=query)
        resolved_source_name = data_source

    return df, resolved_source_name


@schema_app.command("capture")
def schema_capture(
    data_source: str | None = typer.Argument(
        None,
        help="Data source: file path, connection string, or omit when using config/sources",
    ),
    name: str = typer.Option(
        "baseline",
        "--name",
        "-n",
        help="Name for the baseline schema",
    ),
    config: str | None = typer.Option(
        None,
        "--config",
        "-c",
        help="Path to config file with data_source defined",
    ),
    source: str | None = typer.Option(
        None,
        "--source",
        help="Named source from sources.yaml",
    ),
    sources_file: str | None = typer.Option(
        None,
        "--sources-file",
        help="Path to sources YAML file",
    ),
    table: str | None = typer.Option(
        None,
        "--table",
        "-t",
        help="Database table name (for database sources)",
    ),
    query: str | None = typer.Option(
        None,
        "--query",
        "-q",
        help="Custom SQL query (alternative to --table)",
    ),
    baseline_dir: str | None = typer.Option(
        None,
        "--baseline-dir",
        help="Directory to store schema baselines (default: .datacheck/schemas)",
    ),
    save_history: bool = typer.Option(
        True,
        "--save-history/--no-history",
        help="Save schema to history for tracking changes over time",
    ),
) -> None:
    """Capture current schema as a baseline.

    Detects the schema from the data source and saves it as a baseline
    for future comparison. Optionally saves to history for tracking.

    Examples:
        datacheck schema capture
        datacheck schema capture data.csv
        datacheck schema capture --config checks.yaml
        datacheck schema capture --source production_db --sources-file sources.yaml

    Exit codes:
      0 - Schema captured successfully
      2 - Configuration error
      3 - Data loading error
      4 - Unexpected error
    """
    try:
        from datacheck.schema import SchemaDetector, BaselineManager

        # Load data using the resolver
        _status = console.status("[bold blue]Loading data...", spinner="dots")
        _status.start()
        try:
            df, resolved_source_name = _resolve_data_source(
                data_source=data_source,
                config=config,
                source=source,
                sources_file=sources_file,
                table=table,
                query=query,
            )
        except DataLoadError as e:
            console.print(f"[red]Data Load Error:[/red] {e}", style="red")
            raise typer.Exit(code=3) from e
        except typer.Exit:
            raise
        except Exception as e:
            console.print(f"[red]Data Load Error:[/red] {e}", style="red")
            raise typer.Exit(code=3) from e
        finally:
            _status.stop()

        # Detect schema
        schema = SchemaDetector.detect(df, name=name, source=resolved_source_name)

        # Save baseline
        manager = BaselineManager(baseline_dir=baseline_dir)
        filepath = manager.save_baseline(schema, name=name)
        console.print(f"[green]{_TICK}[/green] Schema saved to: {filepath}")

        # Save to history if requested
        if save_history:
            history_path = manager.save_to_history(schema)
            console.print(f"[green]{_TICK}[/green] Schema added to history: {history_path}")

        # Display summary
        console.print("\n[bold]Schema Summary:[/bold]")
        console.print(f"  Name: {schema.name}")
        console.print(f"  Columns: {len(schema.columns)}")
        console.print(f"  Rows: {schema.row_count:,}")
        console.print(f"  Source: {schema.source}")

        raise typer.Exit(code=0)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}", style="red")
        raise typer.Exit(code=4) from e


@schema_app.command("compare")
def schema_compare(
    data_source: str | None = typer.Argument(
        None,
        help="Data source: file path, connection string, or omit when using config/sources",
    ),
    baseline_name: str = typer.Option(
        "baseline",
        "--baseline",
        "-b",
        help="Name of the baseline schema to compare against",
    ),
    config: str | None = typer.Option(
        None,
        "--config",
        "-c",
        help="Path to config file with data_source defined",
    ),
    source: str | None = typer.Option(
        None,
        "--source",
        help="Named source from sources.yaml",
    ),
    sources_file: str | None = typer.Option(
        None,
        "--sources-file",
        help="Path to sources YAML file",
    ),
    table: str | None = typer.Option(
        None,
        "--table",
        "-t",
        help="Database table name (for database sources)",
    ),
    query: str | None = typer.Option(
        None,
        "--query",
        "-q",
        help="Custom SQL query (alternative to --table)",
    ),
    baseline_dir: str | None = typer.Option(
        None,
        "--baseline-dir",
        help="Directory containing schema baselines (default: .datacheck/schemas)",
    ),
    rename_threshold: float = typer.Option(
        0.8,
        "--rename-threshold",
        help="Similarity threshold for detecting column renames (0.0 to 1.0)",
    ),
    fail_on_breaking: bool = typer.Option(
        False,
        "--fail-on-breaking",
        help="Exit with error code if breaking changes are detected",
    ),
    output_format: str = typer.Option(
        "terminal",
        "--format",
        "-f",
        help="Output format: 'terminal' or 'json'",
    ),
) -> None:
    """Compare current schema against a baseline.

    Detects schema changes including added/removed columns, type changes,
    and potential column renames. Reports compatibility level.

    Examples:
        datacheck schema compare
        datacheck schema compare data.csv
        datacheck schema compare --config checks.yaml
        datacheck schema compare --source production_db --sources-file sources.yaml

    Exit codes:
      0 - Schemas are compatible (no breaking changes)
      1 - Breaking changes detected (with --fail-on-breaking)
      2 - Baseline not found or configuration error
      3 - Data loading error
      4 - Unexpected error
    """
    try:
        from datacheck.schema import SchemaDetector, SchemaComparator, BaselineManager
        from datacheck.schema.models import CompatibilityLevel, ChangeType

        # Load baseline
        manager = BaselineManager(baseline_dir=baseline_dir)
        baseline = manager.load_baseline(baseline_name)

        if baseline is None:
            console.print(
                f"[red]Error:[/red] Baseline '{baseline_name}' not found. "
                f"Run 'datacheck schema capture' first.",
                style="red",
            )
            raise typer.Exit(code=2)

        # Load current data using the resolver
        _status = console.status("[bold blue]Loading data...", spinner="dots")
        _status.start()
        try:
            df, resolved_source_name = _resolve_data_source(
                data_source=data_source,
                config=config,
                source=source,
                sources_file=sources_file,
                table=table,
                query=query,
            )
        except DataLoadError as e:
            console.print(f"[red]Data Load Error:[/red] {e}", style="red")
            raise typer.Exit(code=3) from e
        except typer.Exit:
            raise
        except Exception as e:
            console.print(f"[red]Data Load Error:[/red] {e}", style="red")
            raise typer.Exit(code=3) from e
        finally:
            _status.stop()

        # Detect current schema
        current_schema = SchemaDetector.detect(df, name="current", source=resolved_source_name)

        # Compare schemas
        console.print("[cyan]Comparing schemas...[/cyan]\n")
        comparator = SchemaComparator(rename_threshold=rename_threshold)
        comparison = comparator.compare(baseline, current_schema)

        if output_format == "json":
            import json
            result = {
                "baseline": baseline.to_dict(),
                "current": current_schema.to_dict(),
                "is_compatible": comparison.is_compatible,
                "compatibility_level": comparison.compatibility_level.value,
                "changes": [
                    {
                        "type": c.change_type.value,
                        "column": c.column_name,
                        "old_value": str(c.old_value) if c.old_value is not None else None,
                        "new_value": str(c.new_value) if c.new_value is not None else None,
                        "compatibility": c.compatibility.value,
                        "message": c.message,
                    }
                    for c in comparison.changes
                ],
            }
            # Use print() instead of console.print() to avoid ANSI escape codes in JSON
            print(json.dumps(result, indent=2))
        else:
            # Terminal output
            if not comparison.changes:
                console.print(f"[green]{_TICK} No schema changes detected[/green]")
            else:
                # Compatibility summary
                compat_style = {
                    CompatibilityLevel.COMPATIBLE: "[green]COMPATIBLE[/green]",
                    CompatibilityLevel.WARNING: "[yellow]WARNING[/yellow]",
                    CompatibilityLevel.BREAKING: "[red]BREAKING[/red]",
                }
                console.print(
                    f"[bold]Compatibility:[/bold] {compat_style[comparison.compatibility_level]}"
                )
                console.print(f"[bold]Changes Detected:[/bold] {len(comparison.changes)}\n")

                # Changes table
                changes_table = Table(title="Schema Changes")
                changes_table.add_column("Type", style="cyan")
                changes_table.add_column("Column")
                changes_table.add_column("Details")
                changes_table.add_column("Compatibility")

                for change in comparison.changes:
                    compat_cell = {
                        CompatibilityLevel.COMPATIBLE: "[green]Compatible[/green]",
                        CompatibilityLevel.WARNING: "[yellow]Warning[/yellow]",
                        CompatibilityLevel.BREAKING: "[red]Breaking[/red]",
                    }[change.compatibility]

                    type_label = {
                        ChangeType.COLUMN_ADDED: "Added",
                        ChangeType.COLUMN_REMOVED: "Removed",
                        ChangeType.COLUMN_RENAMED: "Renamed",
                        ChangeType.TYPE_CHANGED: "Type Changed",
                        ChangeType.NULLABLE_CHANGED: "Nullable Changed",
                        ChangeType.ORDER_CHANGED: "Order Changed",
                    }.get(change.change_type, change.change_type.value)

                    changes_table.add_row(
                        type_label,
                        change.column_name,
                        change.message,
                        compat_cell,
                    )

                console.print(changes_table)

        # Exit code based on compatibility
        if fail_on_breaking and comparison.compatibility_level == CompatibilityLevel.BREAKING:
            console.print("\n[red]Breaking changes detected. Failing as requested.[/red]")
            raise typer.Exit(code=1)

        raise typer.Exit(code=0)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}", style="red")
        raise typer.Exit(code=4) from e


@schema_app.command("show")
def schema_show(
    name: str = typer.Option(
        "baseline",
        "--name",
        "-n",
        help="Name of the baseline schema to show",
    ),
    baseline_dir: str | None = typer.Option(
        None,
        "--baseline-dir",
        help="Directory containing schema baselines (default: .datacheck/schemas)",
    ),
    output_format: str = typer.Option(
        "terminal",
        "--format",
        "-f",
        help="Output format: 'terminal' or 'json'",
    ),
) -> None:
    """Show a baseline schema.

    Displays the columns, types, and metadata of a saved baseline schema.

    Exit codes:
      0 - Success
      2 - Baseline not found
      4 - Unexpected error
    """
    try:
        from datacheck.schema import BaselineManager

        manager = BaselineManager(baseline_dir=baseline_dir)
        schema = manager.load_baseline(name)

        if schema is None:
            console.print(
                f"[red]Error:[/red] Baseline '{name}' not found.",
                style="red",
            )
            raise typer.Exit(code=2)

        if output_format == "json":
            import json
            print(json.dumps(schema.to_dict(), indent=2))
        else:
            # Terminal output
            console.print(f"\n[bold]Schema: {schema.name}[/bold]")
            console.print(f"Source: {schema.source or 'N/A'}")
            console.print(f"Rows: {schema.row_count:,}")
            console.print(f"Created: {schema.created_at.isoformat()}")

            # Columns table
            columns_table = Table(title=f"\nColumns ({len(schema.columns)})")
            columns_table.add_column("#", style="dim")
            columns_table.add_column("Column Name", style="cyan")
            columns_table.add_column("Type")
            columns_table.add_column("Nullable")
            columns_table.add_column("Unique Values")
            columns_table.add_column("Null %")

            for col in schema.columns:
                columns_table.add_row(
                    str(col.position),
                    col.name,
                    col.dtype.value,
                    "[green]Yes[/green]" if col.nullable else "[red]No[/red]",
                    str(col.unique_values) if col.unique_values is not None else "N/A",
                    f"{col.null_percentage:.1f}%",
                )

            console.print(columns_table)

        raise typer.Exit(code=0)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}", style="red")
        raise typer.Exit(code=4) from e


@schema_app.command("history")
def schema_history(
    baseline_dir: str | None = typer.Option(
        None,
        "--baseline-dir",
        help="Directory containing schema baselines (default: .datacheck/schemas)",
    ),
    limit: int = typer.Option(
        10,
        "--limit",
        "-l",
        help="Maximum number of history entries to show",
    ),
) -> None:
    """Show schema history.

    Lists saved schema snapshots in chronological order (newest first).

    Exit codes:
      0 - Success
      4 - Unexpected error
    """
    try:
        from datacheck.schema import BaselineManager

        manager = BaselineManager(baseline_dir=baseline_dir)
        history = manager.list_history(limit=limit)

        if not history:
            console.print("[yellow]No schema history found.[/yellow]")
            console.print("Run 'datacheck schema capture' to create a schema snapshot.")
            raise typer.Exit(code=0)

        console.print(f"\n[bold]Schema History[/bold] (showing {len(history)} of {manager.get_history_count()})\n")

        history_table = Table()
        history_table.add_column("Timestamp", style="cyan")
        history_table.add_column("Filename")
        history_table.add_column("Columns")
        history_table.add_column("Rows")

        for filepath in history:
            schema = manager.load_from_history(filepath.stem)
            if schema:
                # Parse timestamp from filename
                timestamp_str = filepath.stem.replace("schema_", "")
                formatted_ts = f"{timestamp_str[:4]}-{timestamp_str[4:6]}-{timestamp_str[6:8]} {timestamp_str[9:11]}:{timestamp_str[11:13]}:{timestamp_str[13:15]}"
                history_table.add_row(
                    formatted_ts,
                    filepath.name,
                    str(len(schema.columns)),
                    f"{schema.row_count:,}",
                )

        console.print(history_table)
        raise typer.Exit(code=0)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}", style="red")
        raise typer.Exit(code=4) from e


@schema_app.command("list")
def schema_list(
    baseline_dir: str | None = typer.Option(
        None,
        "--baseline-dir",
        help="Directory containing schema baselines (default: .datacheck/schemas)",
    ),
) -> None:
    """List all saved baseline schemas.

    Exit codes:
      0 - Success
      4 - Unexpected error
    """
    try:
        from datacheck.schema import BaselineManager

        manager = BaselineManager(baseline_dir=baseline_dir)
        baselines = manager.list_baselines()

        if not baselines:
            console.print("[yellow]No baselines found.[/yellow]")
            console.print("Run 'datacheck schema capture' to create a baseline.")
            raise typer.Exit(code=0)

        console.print(f"\n[bold]Saved Baselines[/bold] ({len(baselines)})\n")

        for name in baselines:
            schema = manager.load_baseline(name)
            if schema:
                console.print(f"  [cyan]{name}[/cyan]")
                console.print(f"    Columns: {len(schema.columns)}, Rows: {schema.row_count:,}")
                console.print(f"    Created: {schema.created_at.isoformat()}")
                console.print()

        raise typer.Exit(code=0)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}", style="red")
        raise typer.Exit(code=4) from e
