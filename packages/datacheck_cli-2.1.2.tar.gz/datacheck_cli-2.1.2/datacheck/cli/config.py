"""Config commands for DataCheck CLI."""

import typer
from rich.table import Table

from datacheck.cli import console

# Config sub-app for configuration management commands
config_app = typer.Typer(
    name="config",
    help="Configuration management commands",
)


@config_app.command("init")
def config_init(
    output: str = typer.Option(
        "datacheck.yaml",
        "--output",
        "-o",
        help="Output config file path",
    ),
    template: str = typer.Option(
        "basic",
        "--template",
        "-t",
        help="Config template to use (basic, ecommerce, healthcare, finance, saas, iot)",
    ),
    with_sample_data: bool = typer.Option(
        False,
        "--with-sample-data",
        "-s",
        help="Generate sample CSV data file matching the template",
    ),
    sample_rows: int = typer.Option(
        100,
        "--sample-rows",
        help="Number of sample rows to generate (default: 100)",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        "-f",
        help="Overwrite existing config file",
    ),
) -> None:
    """Initialize a new DataCheck configuration file.

    Creates a config file from a template.

    Examples:
        datacheck config init
        datacheck config init --template ecommerce
        datacheck config init --template finance --with-sample-data
        datacheck config init --template iot --with-sample-data --sample-rows 500

    Exit codes:
      0 - Config created successfully
      1 - Config file already exists (use --force to overwrite)
      2 - Template not found
      4 - Unexpected error
    """
    try:
        from pathlib import Path

        output_path = Path(output)

        # Check if file exists
        if output_path.exists() and not force:
            console.print(
                f"[red]Error:[/red] Config file '{output}' already exists. "
                f"Use --force to overwrite.",
                style="red",
            )
            raise typer.Exit(code=1)

        # Use template
        from datacheck.config import list_templates, load_template

        available = list_templates()
        if template not in available:
            console.print(
                f"[red]Error:[/red] Template '{template}' not found. "
                f"Available templates: {', '.join(available)}",
                style="red",
            )
            raise typer.Exit(code=2)

        template_content = load_template(template)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(template_content)
        console.print(f"[green]OK:[/green] Config created from '{template}' template: {output}")

        # Generate sample data if requested
        if with_sample_data:
            from datacheck.config.sample_data import generate_sample_data, get_default_filename

            data_filename = get_default_filename(template)
            data_path = output_path.parent / data_filename

            if data_path.exists() and not force:
                console.print(
                    f"[yellow]Warning:[/yellow] Sample data file '{data_filename}' already exists. "
                    f"Use --force to overwrite.",
                )
            else:
                generate_sample_data(template, data_path, sample_rows)
                console.print(f"[green]OK:[/green] Sample data generated: {data_filename} ({sample_rows} rows)")

        console.print("\n[dim]Edit the config file to customize validation rules.[/dim]")

        raise typer.Exit(code=0)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}", style="red")
        raise typer.Exit(code=4) from e


@config_app.command("validate")
def config_validate(
    config_path: str = typer.Argument(
        "datacheck.yaml",
        help="Path to config file to validate",
    ),
    strict: bool = typer.Option(
        False,
        "--strict",
        "-s",
        help="Enable strict validation (fail on warnings)",
    ),
) -> None:
    """Validate a DataCheck configuration file.

    Checks config syntax, rule definitions, and reports any issues.

    Exit codes:
      0 - Config is valid
      1 - Config has validation errors
      2 - Config file not found
      4 - Unexpected error
    """
    try:
        from pathlib import Path
        from datacheck.config import ConfigValidator

        path = Path(config_path)
        if not path.exists():
            console.print(
                f"[red]Error:[/red] Config file not found: {config_path}",
                style="red",
            )
            raise typer.Exit(code=2)

        console.print(f"[cyan]Validating:[/cyan] {config_path}")

        validator = ConfigValidator()
        is_valid, errors, warnings = validator.validate_file(path)

        # Show warnings
        if warnings:
            console.print(f"\n[yellow]Warnings ({len(warnings)}):[/yellow]")
            for warning in warnings:
                console.print(f"  ! {warning}")

        # Show errors
        if errors:
            console.print(f"\n[red]Errors ({len(errors)}):[/red]")
            for error in errors:
                console.print(f"  X {error}")

        # Summary
        if is_valid and (not strict or not warnings):
            console.print("\n[green]OK: Config is valid[/green]")
            raise typer.Exit(code=0)
        elif strict and warnings:
            console.print("\n[yellow]Config has warnings (strict mode enabled)[/yellow]")
            raise typer.Exit(code=1)
        else:
            console.print("\n[red]FAIL: Config has validation errors[/red]")
            raise typer.Exit(code=1)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}", style="red")
        raise typer.Exit(code=4) from e


@config_app.command("show")
def config_show(
    config_path: str = typer.Argument(
        "datacheck.yaml",
        help="Path to config file to show",
    ),
    resolve_env: bool = typer.Option(
        True,
        "--resolve-env/--no-resolve-env",
        help="Resolve environment variables",
    ),
    resolve_extends: bool = typer.Option(
        True,
        "--resolve-extends/--no-resolve-extends",
        help="Resolve config inheritance (extends)",
    ),
    output_format: str = typer.Option(
        "yaml",
        "--format",
        "-f",
        help="Output format: 'yaml' or 'json'",
    ),
) -> None:
    """Show parsed configuration.

    Displays the fully resolved configuration with env vars and
    inheritance resolved.

    Exit codes:
      0 - Success
      2 - Config file not found
      4 - Unexpected error
    """
    try:
        from pathlib import Path
        from datacheck.config import ConfigParser
        import yaml
        import json

        path = Path(config_path)
        if not path.exists():
            console.print(
                f"[red]Error:[/red] Config file not found: {config_path}",
                style="red",
            )
            raise typer.Exit(code=2)

        parser = ConfigParser()
        config = parser.load(
            path,
            resolve_env=resolve_env,
            resolve_extends=resolve_extends,
        )

        if output_format == "json":
            print(json.dumps(config, indent=2, default=str))
        else:
            console.print(yaml.dump(config, default_flow_style=False, sort_keys=False))

        raise typer.Exit(code=0)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}", style="red")
        raise typer.Exit(code=4) from e


@config_app.command("merge")
def config_merge(
    configs: list[str] = typer.Argument(
        ...,
        help="Config files to merge (later files override earlier)",
    ),
    output: str = typer.Option(
        None,
        "--output",
        "-o",
        help="Output file path (prints to stdout if not specified)",
    ),
) -> None:
    """Merge multiple configuration files.

    Later files override values from earlier files. Useful for
    combining base configs with environment-specific overrides.

    Examples:
        datacheck config merge base.yaml production.yaml
        datacheck config merge base.yaml prod.yaml -o merged.yaml

    Exit codes:
      0 - Success
      2 - Config file not found
      4 - Unexpected error
    """
    try:
        from pathlib import Path
        from datacheck.config import ConfigParser
        import yaml

        parser = ConfigParser()
        merged_config: dict = {}

        for config_path in configs:
            path = Path(config_path)
            if not path.exists():
                console.print(
                    f"[red]Error:[/red] Config file not found: {config_path}",
                    style="red",
                )
                raise typer.Exit(code=2)

            config = parser.load(path)
            merged_config = parser._deep_merge(merged_config, config)
            console.print(f"[cyan]Merged:[/cyan] {config_path}")

        yaml_output = yaml.dump(merged_config, default_flow_style=False, sort_keys=False)

        if output:
            output_path = Path(output)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(yaml_output)
            console.print(f"[green]OK:[/green] Merged config written to: {output}")
        else:
            console.print("\n[bold]Merged Configuration:[/bold]")
            console.print(yaml_output)

        raise typer.Exit(code=0)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}", style="red")
        raise typer.Exit(code=4) from e


@config_app.command("templates")
def config_templates() -> None:
    """List available configuration templates.

    Shows all built-in templates that can be used with 'config init'.

    Exit codes:
      0 - Success
      4 - Unexpected error
    """
    try:
        from datacheck.config import list_templates, get_template_path
        import yaml

        templates = list_templates()

        console.print("\n[bold]Available Templates[/bold]\n")

        for template_name in sorted(templates):
            # Load template to get description
            try:
                template_path = get_template_path(template_name)
                with open(template_path) as f:
                    config = yaml.safe_load(f)
                    metadata = config.get("metadata", {})
                    description = metadata.get("description", "No description")
                    domain = metadata.get("domain", "general")
            except Exception:
                description = "No description"
                domain = "general"

            console.print(f"  [cyan]{template_name}[/cyan]")
            console.print(f"    {description}")
            console.print(f"    Domain: {domain}")
            console.print()

        console.print("[dim]Use 'datacheck config init --template <name>' to create a config.[/dim]")
        raise typer.Exit(code=0)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}", style="red")
        raise typer.Exit(code=4) from e


@config_app.command("env")
def config_env(
    config_path: str = typer.Argument(
        "datacheck.yaml",
        help="Path to config file to analyze",
    ),
) -> None:
    """List environment variables referenced in config.

    Shows all ${VAR} and ${VAR:-default} references in the config file.

    Exit codes:
      0 - Success
      2 - Config file not found
      4 - Unexpected error
    """
    try:
        from pathlib import Path
        from datacheck.config import ConfigParser

        path = Path(config_path)
        if not path.exists():
            console.print(
                f"[red]Error:[/red] Config file not found: {config_path}",
                style="red",
            )
            raise typer.Exit(code=2)

        parser = ConfigParser()
        env_vars = parser.get_env_vars(path)

        if not env_vars:
            console.print("[dim]No environment variables referenced in config.[/dim]")
            raise typer.Exit(code=0)

        console.print(f"\n[bold]Environment Variables in {config_path}[/bold]\n")

        import os

        env_table = Table()
        env_table.add_column("Variable", style="cyan")
        env_table.add_column("Default")
        env_table.add_column("Current Value")
        env_table.add_column("Status")

        for var_name, default_value in env_vars.items():
            current_value = os.environ.get(var_name)
            default_str = default_value if default_value else "[dim]None[/dim]"

            if current_value:
                status = "[green]Set[/green]"
                value_display = current_value[:30] + "..." if len(current_value) > 30 else current_value
            elif default_value:
                status = "[yellow]Using default[/yellow]"
                value_display = default_value
            else:
                status = "[red]Missing[/red]"
                value_display = "[dim]N/A[/dim]"

            env_table.add_row(var_name, default_str, value_display, status)

        console.print(env_table)
        raise typer.Exit(code=0)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}", style="red")
        raise typer.Exit(code=4) from e
