"""Notification integrations for DataCheck."""

from datacheck.notifications.slack import SlackNotifier

__all__ = ["SlackNotifier"]
