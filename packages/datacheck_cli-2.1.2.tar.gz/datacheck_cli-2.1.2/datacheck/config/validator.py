"""Configuration validation."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from datacheck.config.schema import CONFIG_SCHEMA, VALID_RULE_TYPES

# Try to import jsonschema, fall back to basic validation if not available
try:
    import jsonschema

    HAS_JSONSCHEMA = True
except ImportError:
    HAS_JSONSCHEMA = False


class ConfigValidator:
    """Validate DataCheck configuration files.

    Validates configuration against JSON schema and performs
    additional semantic validation checks.

    Example:
        >>> validator = ConfigValidator()
        >>> is_valid, errors = validator.validate_file("config.yaml")
        >>> if not is_valid:
        ...     for error in errors:
        ...         print(f"Error: {error}")
    """

    def __init__(self, schema: dict[str, Any] | None = None):
        """
        Initialize validator.

        Args:
            schema: Optional custom schema (defaults to CONFIG_SCHEMA)
        """
        self.schema = schema or CONFIG_SCHEMA

    def validate_file(
        self, config_path: str | Path
    ) -> tuple[bool, list[str], list[str]]:
        """
        Validate YAML config file.

        Args:
            config_path: Path to YAML config file

        Returns:
            Tuple of (is_valid, errors, warnings)
        """
        config_path = Path(config_path)

        # Check file exists
        if not config_path.exists():
            return False, [f"Config file not found: {config_path}"], []

        if not config_path.is_file():
            return False, [f"Path is not a file: {config_path}"], []

        # Load YAML
        try:
            with open(config_path, encoding="utf-8") as f:
                config = yaml.safe_load(f)
        except yaml.YAMLError as e:
            return False, [f"YAML parsing error: {e}"], []
        except Exception as e:
            return False, [f"Error reading file: {e}"], []

        # Check for empty file
        if config is None:
            return False, ["Config file is empty"], []

        # Validate the config dictionary
        return self.validate_dict(config)

    def validate_dict(
        self, config: dict[str, Any]
    ) -> tuple[bool, list[str], list[str]]:
        """
        Validate config dictionary.

        Args:
            config: Config dictionary

        Returns:
            Tuple of (is_valid, errors, warnings)
        """
        errors: list[str] = []
        warnings: list[str] = []

        # Check it's a dictionary
        if not isinstance(config, dict):
            return (
                False,
                [f"Config must be a dictionary, got {type(config).__name__}"],
                [],
            )

        # Validate against JSON schema (if jsonschema is available)
        if HAS_JSONSCHEMA:
            schema_errors = self._validate_schema(config)
            errors.extend(schema_errors)
        else:
            # Basic validation without jsonschema
            basic_errors = self._validate_basic(config)
            errors.extend(basic_errors)

        # Additional semantic validations
        if "checks" in config:
            check_errors, check_warnings = self._validate_checks(config["checks"])
            errors.extend(check_errors)
            warnings.extend(check_warnings)

        # Validate sampling config
        if "sampling" in config:
            sampling_errors = self._validate_sampling(config["sampling"])
            errors.extend(sampling_errors)

        # Validate reporting config
        if "reporting" in config:
            reporting_errors = self._validate_reporting(config["reporting"])
            errors.extend(reporting_errors)

        # Validate source settings
        source_errors, source_warnings = self._validate_source_settings(config)
        errors.extend(source_errors)
        warnings.extend(source_warnings)

        return len(errors) == 0, errors, warnings

    def _validate_schema(self, config: dict[str, Any]) -> list[str]:
        """
        Validate config against JSON schema.

        Collects all schema errors at once instead of stopping at the first.

        Args:
            config: Config dictionary

        Returns:
            List of error messages
        """
        errors: list[str] = []

        try:
            validator_cls = jsonschema.Draft7Validator
            validator = validator_cls(self.schema)
            for error in sorted(validator.iter_errors(config), key=str):
                path = ".".join(str(p) for p in error.path) if error.path else "root"
                errors.append(f"Schema validation failed at '{path}': {error.message}")
        except jsonschema.SchemaError as e:
            errors.append(f"Invalid schema: {e.message}")

        return errors

    def _validate_basic(self, config: dict[str, Any]) -> list[str]:
        """
        Basic validation when jsonschema is not available.

        Args:
            config: Config dictionary

        Returns:
            List of error messages
        """
        errors: list[str] = []

        # Check required fields
        if "checks" not in config:
            errors.append("Missing required field: 'checks'")
        elif not isinstance(config["checks"], list):
            errors.append("'checks' must be a list")

        return errors

    def _validate_checks(
        self, checks: list[Any]
    ) -> tuple[list[str], list[str]]:
        """
        Validate check definitions.

        Args:
            checks: List of check definitions

        Returns:
            Tuple of (errors, warnings)
        """
        errors: list[str] = []
        warnings: list[str] = []

        if not isinstance(checks, list):
            return [f"'checks' must be a list, got {type(checks).__name__}"], []

        if len(checks) == 0:
            # Empty checks is a warning, not an error
            warnings.append("'checks' list is empty")
            return errors, warnings

        # Collect check names for duplicate detection
        names: list[str] = []

        for i, check in enumerate(checks):
            if not isinstance(check, dict):
                errors.append(f"Check at index {i} must be a dictionary")
                continue

            # Validate required fields
            if "name" not in check:
                errors.append(f"Check at index {i} missing 'name' field")
            else:
                names.append(check["name"])

            if "column" not in check:
                name = check.get("name", f"index {i}")
                errors.append(f"Check '{name}' missing 'column' field")

            if "rules" not in check:
                name = check.get("name", f"index {i}")
                errors.append(f"Check '{name}' missing 'rules' field")
            elif isinstance(check.get("rules"), dict):
                # Validate rule types
                rule_errors, rule_warnings = self._validate_rule_types(
                    check["rules"], check.get("name", f"index {i}")
                )
                errors.extend(rule_errors)
                warnings.extend(rule_warnings)

        # Check for duplicate names
        duplicates = [name for name in set(names) if names.count(name) > 1]
        if duplicates:
            errors.append(f"Duplicate check names: {', '.join(sorted(duplicates))}")

        return errors, warnings

    def _validate_rule_types(
        self, rules: dict[str, Any], check_name: str
    ) -> tuple[list[str], list[str]]:
        """
        Validate that rule types are valid.

        Args:
            rules: Rules dictionary
            check_name: Name of the check (for error messages)

        Returns:
            Tuple of (errors, warnings)
        """
        errors: list[str] = []
        warnings: list[str] = []

        # Check for unknown rule types (but don't fail on snippets)
        known_rules = set(VALID_RULE_TYPES) | {"use_snippet"}
        invalid_rules = set(rules.keys()) - known_rules
        if invalid_rules:
            errors.append(
                f"Check '{check_name}' has invalid rule types: "
                f"{', '.join(sorted(invalid_rules))}"
            )

        # Validate specific rule parameters
        for rule_type, params in rules.items():
            if rule_type == "use_snippet":
                # Skip snippet references
                continue
            param_errors = self._validate_rule_params(rule_type, params, check_name)
            errors.extend(param_errors)

        return errors, warnings

    def _validate_rule_params(
        self, rule_type: str, params: Any, check_name: str
    ) -> list[str]:
        """
        Validate rule parameters.

        Args:
            rule_type: Type of rule
            params: Rule parameters
            check_name: Name of the check

        Returns:
            List of error messages
        """
        errors: list[str] = []

        # Rules that require specific parameter types
        numeric_rules = {"min", "max", "min_length", "max_length"}
        if rule_type in numeric_rules:
            if not isinstance(params, (int, float)) and params is not True:
                if isinstance(params, dict) and "value" in params:
                    if not isinstance(params["value"], (int, float)):
                        errors.append(
                            f"Check '{check_name}': '{rule_type}' value must be numeric"
                        )
                elif params is not True:
                    errors.append(
                        f"Check '{check_name}': '{rule_type}' requires a numeric value"
                    )

        # allowed_values must be a list
        if rule_type == "allowed_values":
            if not isinstance(params, list):
                errors.append(
                    f"Check '{check_name}': 'allowed_values' must be a list"
                )

        # regex must be a string or dict with pattern
        if rule_type == "regex":
            if isinstance(params, dict):
                if "pattern" not in params:
                    errors.append(
                        f"Check '{check_name}': 'regex' dict must have 'pattern' key"
                    )
            elif not isinstance(params, str):
                errors.append(
                    f"Check '{check_name}': 'regex' must be a string pattern or dict with 'pattern'"
                )

        # range must have min and max
        if rule_type == "range":
            if isinstance(params, dict):
                if "min" not in params and "max" not in params:
                    errors.append(
                        f"Check '{check_name}': 'range' requires 'min' and/or 'max'"
                    )

        return errors

    def _validate_sampling(self, sampling: Any) -> list[str]:
        """
        Validate sampling configuration.

        Args:
            sampling: Sampling config dictionary

        Returns:
            List of error messages
        """
        errors: list[str] = []

        if not isinstance(sampling, dict):
            return ["'sampling' must be a dictionary"]

        method = sampling.get("method", "none")
        valid_methods = ["none", "random", "stratified", "top", "systematic"]

        if method not in valid_methods:
            errors.append(
                f"Invalid sampling method '{method}'. "
                f"Valid methods: {', '.join(valid_methods)}"
            )

        if method == "random":
            if "rate" not in sampling and "count" not in sampling and "size" not in sampling:
                errors.append("Random sampling requires 'rate', 'count', or 'size'")

        if method == "stratified":
            if "stratify_by" not in sampling:
                errors.append("Stratified sampling requires 'stratify_by'")
            if "count" not in sampling:
                errors.append("Stratified sampling requires 'count'")

        if method == "top":
            if "count" not in sampling:
                errors.append("Top-N sampling requires 'count'")

        return errors

    def _validate_reporting(self, reporting: Any) -> list[str]:
        """
        Validate reporting configuration.

        Args:
            reporting: Reporting config dictionary

        Returns:
            List of error messages
        """
        if not isinstance(reporting, dict):
            return ["'reporting' must be a dictionary"]

        return []


    def _validate_source_settings(
        self, config: dict[str, Any]
    ) -> tuple[list[str], list[str]]:
        """Validate source-related settings in config.

        Args:
            config: Config dictionary

        Returns:
            Tuple of (errors, warnings)
        """
        errors: list[str] = []
        warnings: list[str] = []

        # Validate sources_file is a string if present
        sources_file = config.get("sources_file")
        if sources_file is not None and not isinstance(sources_file, str):
            errors.append(
                f"'sources_file' must be a string, got {type(sources_file).__name__}"
            )

        # Validate top-level source is a string if present
        source = config.get("source")
        if source is not None and not isinstance(source, str):
            errors.append(
                f"'source' must be a string, got {type(source).__name__}"
            )

        # Validate top-level table is a string if present
        table = config.get("table")
        if table is not None and not isinstance(table, str):
            errors.append(
                f"'table' must be a string, got {type(table).__name__}"
            )

        # If source is specified, sources_file should also be present
        if source and not sources_file:
            warnings.append(
                "'source' is set but 'sources_file' is not specified. "
                "Sources file must be provided via CLI --sources-file option."
            )

        # Validate per-check source/table overrides
        checks = config.get("checks", [])
        if isinstance(checks, list):
            for i, check in enumerate(checks):
                if not isinstance(check, dict):
                    continue
                check_name = check.get("name", f"index {i}")
                check_source = check.get("source")
                check_table = check.get("table")
                if check_source is not None and not isinstance(check_source, str):
                    errors.append(
                        f"Check '{check_name}': 'source' must be a string"
                    )
                if check_table is not None and not isinstance(check_table, str):
                    errors.append(
                        f"Check '{check_name}': 'table' must be a string"
                    )

        return errors, warnings


__all__ = ["ConfigValidator"]
