"""Configuration parsing and validation (original config module)."""

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

from datacheck.config.schema import get_valid_rule_types
from datacheck.exceptions import ConfigurationError


@dataclass
class RuleConfig:
    """Configuration for a single validation rule.

    Attributes:
        name: Unique name for this rule
        column: Name of the column to validate
        rules: Dictionary of rule types and their parameters
        source: Optional source name override (references a named source)
        table: Optional table name override (for database sources)
        severity: Severity level (error, warning, info). Default is error.
        enabled: Whether this check is enabled. Default is True.
    """

    name: str
    column: str
    rules: dict[str, Any]
    source: str | None = None
    table: str | None = None
    severity: str = "error"  # error, warning, info
    enabled: bool = True

    def __post_init__(self) -> None:
        """Validate rule configuration after initialization."""
        if not self.name:
            raise ConfigurationError("Rule name cannot be empty")
        if not self.column:
            raise ConfigurationError(f"Column name cannot be empty for rule '{self.name}'")
        if not self.rules:
            raise ConfigurationError(f"Rules cannot be empty for rule '{self.name}'")

        # Validate severity
        valid_severities = ["error", "warning", "info"]
        if self.severity not in valid_severities:
            raise ConfigurationError(
                f"Invalid severity '{self.severity}' for rule '{self.name}'. "
                f"Must be one of: {', '.join(valid_severities)}"
            )

        # Validate rule types — use the canonical list from schema.py so this
        # stays in sync automatically when new rules are added.
        valid_rule_types = set(get_valid_rule_types())
        invalid_rules = set(self.rules.keys()) - valid_rule_types
        if invalid_rules:
            raise ConfigurationError(
                f"Invalid rule types in '{self.name}': {', '.join(invalid_rules)}. "
                f"Valid types: {', '.join(sorted(valid_rule_types))}"
            )


@dataclass
class ReportingConfig:
    """Configuration for validation output and reporting.

    Attributes:
        output_path: Directory or file path for output files
        export_failures: Whether to export failures to CSV
        failures_file: Optional specific path for failures CSV
    """

    output_path: str | None = None
    export_failures: bool = False
    failures_file: str | None = None


@dataclass
class NotificationsConfig:
    """Configuration for validation notifications.

    Attributes:
        slack_webhook: Slack webhook URL for sending results
        mention_on_failure: Whether to mention @channel on failures
    """

    slack_webhook: str | None = None
    mention_on_failure: bool = False

    def __post_init__(self) -> None:
        """Validate notifications configuration."""
        if self.slack_webhook is not None:
            from urllib.parse import urlparse

            url = self.slack_webhook.strip()
            if not url:
                raise ConfigurationError("Slack webhook URL cannot be empty")
            parsed = urlparse(url)
            if parsed.scheme != "https":
                raise ConfigurationError(
                    "Slack webhook URL must use HTTPS scheme"
                )
            self.slack_webhook = url


@dataclass
class ValidationConfig:
    """Complete validation configuration.

    Attributes:
        checks: List of rule configurations
        sources_file: Path to external sources YAML file
        source: Default source name for all checks
        table: Default table name for all checks
        data_source: Inline data source configuration (for single-source validation)
        reporting: Output and reporting configuration
        notifications: Optional notifications configuration
    """

    checks: list[RuleConfig]
    sources_file: str | None = None
    source: str | None = None
    table: str | None = None
    reporting: ReportingConfig | None = None
    notifications: NotificationsConfig | None = None

    def __post_init__(self) -> None:
        """Validate configuration after initialization."""
        # Check for duplicate rule names
        names = [check.name for check in self.checks]
        duplicates = [name for name in names if names.count(name) > 1]
        if duplicates:
            raise ConfigurationError(
                f"Duplicate rule names found: {', '.join(set(duplicates))}"
            )



class ConfigLoader:
    """Loader for YAML configuration files."""

    @staticmethod
    def load(config_path: str | Path) -> ValidationConfig:
        """Load and parse a YAML configuration file.

        Args:
            config_path: Path to the YAML configuration file

        Returns:
            ValidationConfig object

        Raises:
            ConfigurationError: If file not found, invalid YAML, or invalid schema
        """
        path = Path(config_path)

        # Check if file exists
        if not path.exists():
            raise ConfigurationError(f"Configuration file not found: {config_path}")

        if not path.is_file():
            raise ConfigurationError(f"Configuration path is not a file: {config_path}")

        # Read and parse YAML (with env-var substitution and extends resolution)
        try:
            from datacheck.config.parser import ConfigParser

            parser = ConfigParser()
            data = parser.load(path, resolve_env=True, resolve_extends=True)
        except ConfigurationError:
            raise
        except yaml.YAMLError as e:
            raise ConfigurationError(f"Invalid YAML in {config_path}: {e}") from e
        except Exception as e:
            raise ConfigurationError(f"Error reading {config_path}: {e}") from e

        # Validate schema
        if data is None:
            raise ConfigurationError(f"Configuration file is empty: {config_path}")

        if not isinstance(data, dict):
            raise ConfigurationError(
                f"Configuration must be a dictionary, got {type(data).__name__}"
            )

        if "checks" not in data:
            raise ConfigurationError("Configuration must contain 'checks' key")

        if not isinstance(data["checks"], list):
            raise ConfigurationError(
                f"'checks' must be a list, got {type(data['checks']).__name__}"
            )

        # Parse checks — collect all errors before raising
        checks = []
        check_errors: list[str] = []
        for idx, check_data in enumerate(data["checks"]):
            if not isinstance(check_data, dict):
                check_errors.append(
                    f"Check at index {idx} must be a dictionary, "
                    f"got {type(check_data).__name__}"
                )
                continue

            # Validate required fields
            missing = False
            if "name" not in check_data:
                check_errors.append(f"Check at index {idx} missing 'name' field")
                missing = True
            if "column" not in check_data:
                name = check_data.get("name", f"index {idx}")
                check_errors.append(f"Check '{name}' missing 'column' field")
                missing = True
            if "rules" not in check_data:
                name = check_data.get("name", f"index {idx}")
                check_errors.append(f"Check '{name}' missing 'rules' field")
                missing = True

            if missing:
                continue

            try:
                rule_config = RuleConfig(
                    name=check_data["name"],
                    column=check_data["column"],
                    rules=check_data["rules"],
                    source=check_data.get("source"),
                    table=check_data.get("table"),
                    severity=check_data.get("severity", "error"),
                    enabled=check_data.get("enabled", True),
                )
                # Only add enabled checks
                if rule_config.enabled:
                    checks.append(rule_config)
            except ConfigurationError as e:
                check_errors.append(str(e))
            except Exception as e:
                check_errors.append(
                    f"Error parsing check '{check_data.get('name', idx)}': {e}"
                )

        if check_errors:
            raise ConfigurationError(
                "Configuration has errors:\n  - " + "\n  - ".join(check_errors)
            )

        # Parse source settings (optional)
        sources_file = data.get("sources_file")
        default_source = data.get("source")
        default_table = data.get("table")

        # Parse reporting (optional)
        reporting = None
        if "reporting" in data:
            reporting_data = data["reporting"]
            if not isinstance(reporting_data, dict):
                raise ConfigurationError("'reporting' must be a dictionary")

            try:
                reporting = ReportingConfig(
                    output_path=reporting_data.get("output_path"),
                    export_failures=reporting_data.get("export_failures", False),
                    failures_file=reporting_data.get("failures_file"),
                )
            except ConfigurationError:
                raise
            except Exception as e:
                raise ConfigurationError(f"Error parsing reporting config: {e}") from e

        # Parse notifications (optional)
        notifications = None
        if "notifications" in data:
            notif_data = data["notifications"]
            if not isinstance(notif_data, dict):
                raise ConfigurationError("'notifications' must be a dictionary")

            try:
                notifications = NotificationsConfig(
                    slack_webhook=notif_data.get("slack_webhook"),
                    mention_on_failure=notif_data.get("mention_on_failure", False),
                )
            except ConfigurationError:
                raise
            except Exception as e:
                raise ConfigurationError(f"Error parsing notifications config: {e}") from e

        return ValidationConfig(
            checks=checks,
            sources_file=sources_file,
            source=default_source,
            table=default_table,
            reporting=reporting,
            notifications=notifications,
        )

    @staticmethod
    def find_config() -> Path | None:
        """Find configuration file in common locations.

        Searches for configuration files in the following order:
        1. .datacheck.yaml
        2. .datacheck.yml
        3. datacheck.yaml
        4. datacheck.yml

        Returns:
            Path to configuration file if found, None otherwise
        """
        search_names = [
            ".datacheck.yaml",
            ".datacheck.yml",
            "datacheck.yaml",
            "datacheck.yml",
        ]

        for name in search_names:
            path = Path(name)
            if path.exists() and path.is_file():
                return path

        return None


__all__ = [
    "NotificationsConfig",
    "ReportingConfig",
    "RuleConfig",
    "ValidationConfig",
    "ConfigLoader",
]
