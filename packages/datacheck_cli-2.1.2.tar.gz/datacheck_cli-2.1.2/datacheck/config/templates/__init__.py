"""Config templates for common validation scenarios."""

from pathlib import Path

TEMPLATES_DIR = Path(__file__).parent


def get_template_path(template_name: str) -> Path:
    """Get path to a template file.

    Args:
        template_name: Name of template (without .yaml extension)

    Returns:
        Path to template file

    Raises:
        FileNotFoundError: If template doesn't exist
    """
    template_path = TEMPLATES_DIR / f"{template_name}.yaml"
    if not template_path.exists():
        available = list_templates()
        raise FileNotFoundError(
            f"Template '{template_name}' not found. "
            f"Available templates: {', '.join(available)}"
        )
    return template_path


def list_templates() -> list[str]:
    """List available template names.

    Returns:
        List of template names (without .yaml extension)
    """
    return [
        p.stem for p in TEMPLATES_DIR.glob("*.yaml")
        if not p.name.startswith("_")
    ]


def load_template(template_name: str) -> str:
    """Load template content.

    Args:
        template_name: Name of template

    Returns:
        Template YAML content
    """
    template_path = get_template_path(template_name)
    return template_path.read_text()


__all__ = [
    "TEMPLATES_DIR",
    "get_template_path",
    "list_templates",
    "load_template",
]
