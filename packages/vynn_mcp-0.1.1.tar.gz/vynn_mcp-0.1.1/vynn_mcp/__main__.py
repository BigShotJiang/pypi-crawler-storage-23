"""Entry point: python -m vynn_mcp"""
from vynn_mcp.server import mcp

if __name__ == "__main__":
    mcp.run()
