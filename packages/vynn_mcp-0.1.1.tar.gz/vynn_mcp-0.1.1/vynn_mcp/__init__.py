"""Vynn MCP Server — expose self-improving workflows & backtesting as tools."""
__version__ = "0.1.0"
