class Field:
    def __init__(self, alias: str | None = None):
        self.alias = alias
