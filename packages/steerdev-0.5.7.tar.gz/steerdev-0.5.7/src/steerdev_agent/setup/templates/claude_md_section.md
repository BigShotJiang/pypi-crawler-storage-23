## Task Management

This project uses steerdev.com for task management. **You must respect the task lifecycle.**

### Task Lifecycle

Tasks follow this Linear-compatible lifecycle:

```
BACKLOG → TODO → IN-PROGRESS → DONE
```

| Status | Description | Your Action |
|--------|-------------|-------------|
| `backlog` | Task is queued, not ready for work | Do not work on these tasks |
| `todo` | Ready to be worked on | Pick up task and move to `in-progress` |
| `in-progress` | Currently being worked on | Implement the task |
| `done` | Task completed | No action needed |
| `cancelled` | Task was cancelled | No action needed |

### Available Commands

| Command | Description |
|---------|-------------|
| `steerdev tasks next` | Get the next task to work on |
| `steerdev tasks list` | List all tasks with optional filters |
| `steerdev tasks get TASK_ID` | Get details of a specific task |
| `steerdev tasks update TASK_ID --status STATUS` | Update task status |
| `steerdev tasks create --title "..." --prompt "..."` | Create a new task |

### Workflow

#### Standard Mode (one task at a time)

1. Run `steerdev tasks next` to get the next task
2. Update task to `in-progress` before starting work
3. **Create a feature branch**: `git checkout -b task/<task-id-short>`
4. Implement the task
5. **Commit your changes** with clear, descriptive commit messages
6. **Push and create a pull request**: `git push -u origin HEAD && gh pr create`
7. Update task to `done` with a result summary and PR URL: `--result "Summary of work done. PR: <url>"`

#### Wave Mode (multiple tasks in one session)

When your prompt includes a **"Wave Context"** section, you are in wave mode. One branch and one PR cover the entire wave.

1. **Create a wave branch once**: `git checkout -b wave/<wave-number>` (e.g. `wave/1`)
2. For **each task** in the wave:
   a. Update task to `in-progress`
   b. Implement the task
   c. **Commit** with a message that references the task: `[task:<id>] feat: ...`
   d. Update task to `done` with a result summary (no PR yet)
3. After **all tasks** are complete:
   a. `git push -u origin HEAD`
   b. Create a **single PR** for the wave (title: `Wave <N>: <description>`, body lists all completed tasks)
   c. Update all tasks with the PR URL

### Git Workflow (Required)

**You MUST use Git and GitHub CLI to manage your work.** Every task implementation must result in a pull request.

#### Branch Naming

Create a branch before starting any implementation work:

```bash
# Standard mode: use task ID (first 8 chars of UUID)
git checkout -b task/<short-task-id>
# Example: git checkout -b task/abc12345

# Wave mode: use wave number
git checkout -b wave/<wave-number>
# Example: git checkout -b wave/1
```

#### Committing Changes

Make atomic commits with clear messages:

```bash
# Stage and commit your changes
git add .
git commit -m "feat: implement user authentication

- Add JWT token generation
- Create login/logout endpoints
- Add auth middleware"
```

Follow conventional commit format:
- `feat:` - New features
- `fix:` - Bug fixes
- `refactor:` - Code refactoring
- `docs:` - Documentation changes
- `test:` - Adding or updating tests
- `chore:` - Maintenance tasks

#### Creating Pull Requests

##### Standard Mode PR (per task)

```bash
git push -u origin HEAD
gh pr create --title "Task: <title>" --body "## Summary

<description of changes>

## Task Reference
Task ID: <task-id>

## Changes Made
- Change 1
- Change 2

## Testing
- How to test the changes"
```

##### Wave Mode PR (per wave)

After all wave tasks are complete, create a single PR:

```bash
git push -u origin HEAD
gh pr create --title "Wave <N>: <brief description>" --body "## Summary

Wave <N> implementation covering <number> tasks.

## Tasks Completed
- [task:<id1>] <title1>
- [task:<id2>] <title2>

## Changes Made
- Change 1
- Change 2

## Testing
- How to test the changes"
```

#### Standard Workflow Example

```bash
# 1. Get next task
steerdev tasks next

# 2. Mark as in-progress
steerdev tasks update abc123-... --status in-progress

# 3. Create feature branch
git checkout -b task/abc12345

# 4. Implement the feature (make commits as you go)
git add .
git commit -m "feat: add new endpoint for user data"

# 5. Push and create PR
git push -u origin HEAD
gh pr create --title "Add user data endpoint" --body "Implementation for task abc123..."

# 6. Update task to done with PR link
steerdev tasks update abc123-... --status done --result "Implemented user data endpoint. PR: https://github.com/org/repo/pull/42"
```

#### Wave Workflow Example

```bash
# 1. Create wave branch (once for the entire wave)
git checkout -b wave/1

# 2. First task
steerdev tasks update task-aaa... --status in-progress
# ... implement ...
git add . && git commit -m "[task:task-aaa] feat: add user endpoint"
steerdev tasks update task-aaa... --status done --result "Added user endpoint"

# 3. Second task (same branch)
steerdev tasks update task-bbb... --status in-progress
# ... implement ...
git add . && git commit -m "[task:task-bbb] fix: validate email format"
steerdev tasks update task-bbb... --status done --result "Fixed email validation"

# 4. All tasks done — push and create single PR
git push -u origin HEAD
gh pr create --title "Wave 1: User management improvements" \
  --body "## Tasks Completed
- [task:task-aaa] Add user endpoint
- [task:task-bbb] Fix email validation"
# Returns: https://github.com/org/repo/pull/42

# 5. Update all tasks with PR URL
steerdev tasks update task-aaa... --result "PR: https://github.com/org/repo/pull/42"
steerdev tasks update task-bbb... --result "PR: https://github.com/org/repo/pull/42"
```

**IMPORTANT:** Never leave work uncommitted. Always create a PR before marking a task as `done`.

### Status Values

- `backlog` - Task queued, not ready for work
- `todo` - Ready to be worked on
- `in-progress` - Currently working on task
- `done` - Task completed
- `cancelled` - Task was cancelled

### Environment Variables

- `STEERDEV_API_KEY` - Required for API authentication
- `STEERDEV_PROJECT_ID` - Optional, default project ID
- `STEERDEV_AGENT_ID` - Optional, agent identifier for tracking
- `STEERDEV_API_ENDPOINT` - Optional, defaults to https://platform.steerdev.com/api/v1
