"""Version management utilities for SteerDev Agent.

Provides functions to get and manage the project version from pyproject.toml.
"""

import subprocess
import tomllib
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path


def get_project_root() -> Path:
    """Get the project root directory (where pyproject.toml lives)."""
    return Path(__file__).parent.parent.parent


def get_version() -> str:
    """Get the current project version.

    Resolution order:
    1. Installed package metadata (works when installed via pip/uv)
    2. `uv version --short` (works in dev with uv)
    3. Read pyproject.toml directly (works in dev without uv)

    Returns:
        The current version string (e.g., "0.5.4")
    """
    # 1. Try installed package metadata (always works for installed packages)
    try:
        return version("steerdev")
    except PackageNotFoundError:
        pass

    # 2. Try uv (dev environment)
    try:
        result = subprocess.run(
            ["uv", "version", "--short"],
            capture_output=True,
            text=True,
            check=True,
            cwd=get_project_root(),
        )
        return result.stdout.strip()
    except (subprocess.CalledProcessError, FileNotFoundError):
        pass

    # 3. Fallback: read directly from pyproject.toml (dev environment)
    pyproject_path = get_project_root() / "pyproject.toml"
    if pyproject_path.exists():
        with open(pyproject_path, "rb") as f:
            data = tomllib.load(f)
            return data.get("project", {}).get("version", "unknown")
    return "unknown"


def bump_version(
    bump_type: str,
    dry_run: bool = False,
) -> tuple[str, str]:
    """Bump the project version.

    Args:
        bump_type: Type of bump (major, minor, patch, stable, alpha, beta, rc, post, dev)
        dry_run: If True, don't actually change the version

    Returns:
        Tuple of (old_version, new_version)

    Raises:
        ValueError: If bump_type is invalid
        RuntimeError: If version bump fails
    """
    valid_bumps = [
        "major",
        "minor",
        "patch",
        "stable",
        "alpha",
        "beta",
        "rc",
        "post",
        "dev",
    ]
    if bump_type not in valid_bumps:
        raise ValueError(
            f"Invalid bump type '{bump_type}'. Valid options: {', '.join(valid_bumps)}"
        )

    old_version = get_version()

    cmd = ["uv", "version", "--bump", bump_type]
    if dry_run:
        cmd.append("--dry-run")

    try:
        subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            check=True,
            cwd=get_project_root(),
        )
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"Failed to bump version: {e.stderr}") from e

    new_version = get_version() if not dry_run else _predict_new_version(old_version, bump_type)
    return old_version, new_version


def set_version(version: str, dry_run: bool = False) -> str:
    """Set the project version to a specific value.

    Args:
        version: The version string to set (e.g., "1.2.3")
        dry_run: If True, don't actually change the version

    Returns:
        The new version string

    Raises:
        RuntimeError: If setting version fails
    """
    cmd = ["uv", "version", version]
    if dry_run:
        cmd.append("--dry-run")

    try:
        subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            check=True,
            cwd=get_project_root(),
        )
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"Failed to set version: {e.stderr}") from e

    return version if not dry_run else get_version()


def _predict_new_version(current: str, bump_type: str) -> str:
    """Predict the new version after a bump (for dry-run display)."""
    parts = current.split(".")
    if len(parts) < 3:
        return f"{current} -> ?"

    try:
        major, minor, patch_str = parts[0], parts[1], parts[2]
        # Handle versions like "0.1.0a1" or "0.1.0-alpha"
        patch = int("".join(c for c in patch_str if c.isdigit()))

        if bump_type == "major":
            return f"{int(major) + 1}.0.0"
        elif bump_type == "minor":
            return f"{major}.{int(minor) + 1}.0"
        elif bump_type == "patch":
            return f"{major}.{minor}.{patch + 1}"
        else:
            return f"{current} -> (uv will calculate)"
    except (ValueError, IndexError):
        return f"{current} -> ?"
