# labquiz
[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/jfbercher/labquiz/main?urlpath=%2Fdoc%2Ftree%2Fextras%2FlabQuizDemo_en_binder.ipynb)


Integration of quizzes in jupyter notebooks
- For self-assessment and evaluation
- Also featuring realtime monitoring and correction. 

Companion programs: 
- quiz_editor: [streamlit app](https://jfb-quizeditor.streamlit.app/) | [src code](https://github.com/jfbercher/quiz_editor)
- quiz_dash: [streamlit app](https://jfb-quizdash.streamlit.app/) | [src code](https://github.com/jfbercher/quiz_dash)
  

Sponsor:

[![ESIEE Paris](esiee_logo_moyen.png)](https://www.esiee.fr)   