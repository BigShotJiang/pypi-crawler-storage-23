"""Unit tests for synth.deploy.agentcore.credentials.

Covers CredentialResolver, IDE detection helpers, Kiro token parsing,
IdC token exchange, and the credential redaction / masking utilities.
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from synth.deploy.agentcore.credentials import (
    CredentialResolver,
    IDEType,
    ResolvedCredentials,
    _detect_ide,
    _exchange_idc_token_for_credentials,
    _find_kiro_token,
)
from synth.errors import SynthConfigError


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_FUTURE = (datetime.now(timezone.utc) + timedelta(hours=8)).strftime(
    "%Y-%m-%dT%H:%M:%S.000Z"
)
_PAST = (datetime.now(timezone.utc) - timedelta(hours=1)).strftime(
    "%Y-%m-%dT%H:%M:%S.000Z"
)

_VALID_KIRO_TOKEN = {
    "accessToken": "eyJhbGciOiJSUzI1NiJ9.valid",
    "refreshToken": "refresh-token-value",
    "expiresAt": _FUTURE,
    "clientIdHash": "06df7ec9abcd1234",
    "authMethod": "IdC",
    "provider": "Internal",
    "region": "us-east-1",
}

_TEMP_CREDS = {
    "accessKeyId": "ASIAIOSFODNN7EXAMPLE",
    "secretAccessKey": "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY",
    "sessionToken": "AQoDYXdzEJr//example",
    "expiration": 1234567890,
}


def _make_boto3_mock(account_id: str = "123456789012") -> MagicMock:
    """Return a boto3 mock whose STS client returns *account_id*."""
    mock_boto3 = MagicMock()
    mock_session = MagicMock()
    mock_sts = MagicMock()
    mock_sts.get_caller_identity.return_value = {"Account": account_id}
    mock_session.client.return_value = mock_sts
    mock_boto3.Session.return_value = mock_session
    return mock_boto3


# ---------------------------------------------------------------------------
# IDEType / _detect_ide
# ---------------------------------------------------------------------------


class TestDetectIde:
    def test_kiro_detected_from_term_program(self):
        with patch.dict(os.environ, {"TERM_PROGRAM": "kiro"}):
            assert _detect_ide() == IDEType.KIRO

    def test_kiro_detection_is_case_insensitive(self):
        with patch.dict(os.environ, {"TERM_PROGRAM": "KIRO"}):
            assert _detect_ide() == IDEType.KIRO

    def test_vscode_detected(self):
        with patch.dict(os.environ, {"TERM_PROGRAM": "vscode"}):
            assert _detect_ide() == IDEType.VSCODE

    def test_unknown_term_program_returns_other(self):
        with patch.dict(os.environ, {"TERM_PROGRAM": "iTerm.app"}):
            assert _detect_ide() == IDEType.OTHER

    def test_missing_term_program_returns_other(self):
        env = {k: v for k, v in os.environ.items() if k != "TERM_PROGRAM"}
        with patch.dict(os.environ, env, clear=True):
            assert _detect_ide() == IDEType.OTHER


# ---------------------------------------------------------------------------
# _find_kiro_token
# ---------------------------------------------------------------------------


class TestFindKiroToken:
    def test_returns_token_data_when_valid(self, tmp_path: Path):
        sso_dir = tmp_path / ".aws" / "sso" / "cache"
        sso_dir.mkdir(parents=True)
        (sso_dir / "kiro-auth-token.json").write_text(json.dumps(_VALID_KIRO_TOKEN))

        with patch("pathlib.Path.home", return_value=tmp_path):
            result = _find_kiro_token()

        assert result is not None
        assert result["accessToken"] == _VALID_KIRO_TOKEN["accessToken"]

    def test_returns_none_when_file_missing(self, tmp_path: Path):
        (tmp_path / ".aws" / "sso" / "cache").mkdir(parents=True)

        with patch("pathlib.Path.home", return_value=tmp_path):
            result = _find_kiro_token()

        assert result is None

    def test_returns_none_when_token_expired(self, tmp_path: Path):
        sso_dir = tmp_path / ".aws" / "sso" / "cache"
        sso_dir.mkdir(parents=True)
        (sso_dir / "kiro-auth-token.json").write_text(
            json.dumps({**_VALID_KIRO_TOKEN, "expiresAt": _PAST})
        )

        with patch("pathlib.Path.home", return_value=tmp_path):
            result = _find_kiro_token()

        assert result is None

    def test_returns_none_when_auth_method_not_idc(self, tmp_path: Path):
        sso_dir = tmp_path / ".aws" / "sso" / "cache"
        sso_dir.mkdir(parents=True)
        (sso_dir / "kiro-auth-token.json").write_text(
            json.dumps({**_VALID_KIRO_TOKEN, "authMethod": "SomeOtherMethod"})
        )

        with patch("pathlib.Path.home", return_value=tmp_path):
            result = _find_kiro_token()

        assert result is None

    def test_returns_none_when_provider_not_internal(self, tmp_path: Path):
        sso_dir = tmp_path / ".aws" / "sso" / "cache"
        sso_dir.mkdir(parents=True)
        (sso_dir / "kiro-auth-token.json").write_text(
            json.dumps({**_VALID_KIRO_TOKEN, "provider": "External"})
        )

        with patch("pathlib.Path.home", return_value=tmp_path):
            result = _find_kiro_token()

        assert result is None

    def test_returns_none_when_access_token_missing(self, tmp_path: Path):
        sso_dir = tmp_path / ".aws" / "sso" / "cache"
        sso_dir.mkdir(parents=True)
        bad = {k: v for k, v in _VALID_KIRO_TOKEN.items() if k != "accessToken"}
        (sso_dir / "kiro-auth-token.json").write_text(json.dumps(bad))

        with patch("pathlib.Path.home", return_value=tmp_path):
            result = _find_kiro_token()

        assert result is None

    def test_returns_none_when_file_is_malformed_json(self, tmp_path: Path):
        sso_dir = tmp_path / ".aws" / "sso" / "cache"
        sso_dir.mkdir(parents=True)
        (sso_dir / "kiro-auth-token.json").write_text("not valid json {{")

        with patch("pathlib.Path.home", return_value=tmp_path):
            result = _find_kiro_token()

        assert result is None

    def test_proceeds_when_expires_at_unparseable(self, tmp_path: Path):
        """Unparseable expiresAt should not block token use."""
        sso_dir = tmp_path / ".aws" / "sso" / "cache"
        sso_dir.mkdir(parents=True)
        (sso_dir / "kiro-auth-token.json").write_text(
            json.dumps({**_VALID_KIRO_TOKEN, "expiresAt": "not-a-date"})
        )

        with patch("pathlib.Path.home", return_value=tmp_path):
            result = _find_kiro_token()

        assert result is not None


# ---------------------------------------------------------------------------
# _exchange_idc_token_for_credentials
# ---------------------------------------------------------------------------


class TestExchangeIdcToken:
    def _make_sso_mock(
        self,
        account_id: str = "123456789012",
        role_name: str = "DevRole",
    ) -> MagicMock:
        mock_boto3 = MagicMock()
        mock_sso = MagicMock()
        mock_sso.list_accounts.return_value = {
            "accountList": [{"accountId": account_id}]
        }
        mock_sso.list_account_roles.return_value = {
            "roleList": [{"roleName": role_name}]
        }
        mock_sso.get_role_credentials.return_value = {"roleCredentials": _TEMP_CREDS}
        mock_boto3.client.return_value = mock_sso
        return mock_boto3

    def test_returns_credentials_on_success(self):
        mock_boto3 = self._make_sso_mock()
        with patch(
            "synth.deploy.agentcore.credentials._import_boto3",
            return_value=mock_boto3,
        ):
            result = _exchange_idc_token_for_credentials("token", "us-east-1")

        assert result == _TEMP_CREDS

    def test_skips_list_accounts_when_account_id_provided(self):
        mock_boto3 = self._make_sso_mock()
        with patch(
            "synth.deploy.agentcore.credentials._import_boto3",
            return_value=mock_boto3,
        ):
            _exchange_idc_token_for_credentials(
                "token", "us-east-1", account_id="111122223333"
            )

        mock_boto3.client.return_value.list_accounts.assert_not_called()

    def test_returns_none_when_no_accounts(self):
        mock_boto3 = MagicMock()
        mock_sso = MagicMock()
        mock_sso.list_accounts.return_value = {"accountList": []}
        mock_boto3.client.return_value = mock_sso

        with patch(
            "synth.deploy.agentcore.credentials._import_boto3",
            return_value=mock_boto3,
        ):
            result = _exchange_idc_token_for_credentials("token", "us-east-1")

        assert result is None

    def test_returns_none_when_no_roles(self):
        mock_boto3 = MagicMock()
        mock_sso = MagicMock()
        mock_sso.list_accounts.return_value = {
            "accountList": [{"accountId": "123456789012"}]
        }
        mock_sso.list_account_roles.return_value = {"roleList": []}
        mock_boto3.client.return_value = mock_sso

        with patch(
            "synth.deploy.agentcore.credentials._import_boto3",
            return_value=mock_boto3,
        ):
            result = _exchange_idc_token_for_credentials("token", "us-east-1")

        assert result is None

    def test_returns_none_on_sso_exception(self):
        mock_boto3 = MagicMock()
        mock_boto3.client.side_effect = RuntimeError("network error")

        with patch(
            "synth.deploy.agentcore.credentials._import_boto3",
            return_value=mock_boto3,
        ):
            result = _exchange_idc_token_for_credentials("token", "us-east-1")

        assert result is None


# ---------------------------------------------------------------------------
# CredentialResolver._resolve_ide_toolkit
# ---------------------------------------------------------------------------


class TestResolveIdeToolkit:
    def test_returns_credentials_for_kiro_with_valid_token(self):
        mock_boto3 = _make_boto3_mock("123456789012")

        with (
            patch.dict(os.environ, {"TERM_PROGRAM": "kiro"}),
            patch(
                "synth.deploy.agentcore.credentials._find_kiro_token",
                return_value=_VALID_KIRO_TOKEN,
            ),
            patch(
                "synth.deploy.agentcore.credentials._exchange_idc_token_for_credentials",
                return_value=_TEMP_CREDS,
            ),
            patch(
                "synth.deploy.agentcore.credentials._import_boto3",
                return_value=mock_boto3,
            ),
        ):
            resolver = CredentialResolver()
            result = resolver._resolve_ide_toolkit()

        assert result is not None
        assert result.source == "ide_toolkit:kiro"
        assert result.account_id == "123456789012"
        assert result.profile_name is None

    def test_injects_env_vars_from_temp_credentials(self):
        mock_boto3 = _make_boto3_mock()
        keys_to_clean = ["AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY", "AWS_SESSION_TOKEN"]
        saved = {k: os.environ.pop(k, None) for k in keys_to_clean}

        try:
            with (
                patch.dict(os.environ, {"TERM_PROGRAM": "kiro"}, clear=False),
                patch(
                    "synth.deploy.agentcore.credentials._find_kiro_token",
                    return_value=_VALID_KIRO_TOKEN,
                ),
                patch(
                    "synth.deploy.agentcore.credentials._exchange_idc_token_for_credentials",
                    return_value=_TEMP_CREDS,
                ),
                patch(
                    "synth.deploy.agentcore.credentials._import_boto3",
                    return_value=mock_boto3,
                ),
            ):
                resolver = CredentialResolver()
                resolver._resolve_ide_toolkit()

                # Assert inside the with block before patch.dict restores env
                assert os.environ.get("AWS_ACCESS_KEY_ID") == _TEMP_CREDS["accessKeyId"]
                assert os.environ.get("AWS_SECRET_ACCESS_KEY") == _TEMP_CREDS["secretAccessKey"]
                assert os.environ.get("AWS_SESSION_TOKEN") == _TEMP_CREDS["sessionToken"]
        finally:
            for k in keys_to_clean:
                os.environ.pop(k, None)
            for k, v in saved.items():
                if v is not None:
                    os.environ[k] = v

    def test_returns_none_when_not_kiro(self):
        with patch.dict(os.environ, {"TERM_PROGRAM": "iTerm.app"}):
            resolver = CredentialResolver()
            result = resolver._resolve_ide_toolkit()

        assert result is None

    def test_returns_none_when_token_exchange_fails(self):
        with (
            patch.dict(os.environ, {"TERM_PROGRAM": "kiro"}),
            patch(
                "synth.deploy.agentcore.credentials._find_kiro_token",
                return_value=_VALID_KIRO_TOKEN,
            ),
            patch(
                "synth.deploy.agentcore.credentials._exchange_idc_token_for_credentials",
                return_value=None,
            ),
        ):
            resolver = CredentialResolver()
            result = resolver._resolve_ide_toolkit()

        assert result is None

    def test_returns_none_when_kiro_token_missing(self):
        with (
            patch.dict(os.environ, {"TERM_PROGRAM": "kiro"}),
            patch(
                "synth.deploy.agentcore.credentials._find_kiro_token",
                return_value=None,
            ),
        ):
            resolver = CredentialResolver()
            result = resolver._resolve_ide_toolkit()

        assert result is None


# ---------------------------------------------------------------------------
# CredentialResolver._resolve_aws_credentials_file (expiry handling)
# ---------------------------------------------------------------------------


class TestResolveAwsCredentialsFile:
    def _write_credentials(self, tmp_path: Path, content: str) -> None:
        creds_dir = tmp_path / ".aws"
        creds_dir.mkdir(parents=True, exist_ok=True)
        (creds_dir / "credentials").write_text(content)

    def test_returns_none_when_file_missing(self, tmp_path: Path):
        with patch("pathlib.Path.home", return_value=tmp_path):
            resolver = CredentialResolver()
            result = resolver._resolve_aws_credentials_file()

        assert result is None

    def test_returns_none_when_default_profile_absent(self, tmp_path: Path):
        self._write_credentials(
            tmp_path,
            "[other-profile]\naws_access_key_id = AKIAIOSFODNN7EXAMPLE\n",
        )
        with patch("pathlib.Path.home", return_value=tmp_path):
            resolver = CredentialResolver()
            result = resolver._resolve_aws_credentials_file()

        assert result is None

    def test_returns_none_when_keys_missing_from_default(self, tmp_path: Path):
        self._write_credentials(tmp_path, "[default]\nregion = us-east-1\n")
        with patch("pathlib.Path.home", return_value=tmp_path):
            resolver = CredentialResolver()
            result = resolver._resolve_aws_credentials_file()

        assert result is None

    def test_returns_credentials_on_valid_profile(self, tmp_path: Path):
        self._write_credentials(
            tmp_path,
            "[default]\naws_access_key_id = AKIAIOSFODNN7EXAMPLE\naws_secret_access_key = secret\n",
        )
        mock_boto3 = _make_boto3_mock("999988887777")

        with (
            patch("pathlib.Path.home", return_value=tmp_path),
            patch(
                "synth.deploy.agentcore.credentials._import_boto3",
                return_value=mock_boto3,
            ),
        ):
            resolver = CredentialResolver()
            result = resolver._resolve_aws_credentials_file()

        assert result is not None
        assert result.source == "aws_file"
        assert result.account_id == "999988887777"
        assert result.profile_name == "default"

    def test_returns_none_on_expired_token_exception(self, tmp_path: Path):
        self._write_credentials(
            tmp_path,
            "[default]\naws_access_key_id = AKIAIOSFODNN7EXAMPLE\naws_secret_access_key = secret\n",
        )
        mock_boto3 = MagicMock()
        mock_session = MagicMock()
        mock_sts = MagicMock()

        class ExpiredTokenError(Exception):
            pass

        mock_sts.get_caller_identity.side_effect = ExpiredTokenError("Token has expired")
        mock_session.client.return_value = mock_sts
        mock_boto3.Session.return_value = mock_session

        with (
            patch("pathlib.Path.home", return_value=tmp_path),
            patch(
                "synth.deploy.agentcore.credentials._import_boto3",
                return_value=mock_boto3,
            ),
        ):
            resolver = CredentialResolver()
            result = resolver._resolve_aws_credentials_file()

        assert result is None


# ---------------------------------------------------------------------------
# CredentialResolver.resolve — source priority ordering
# ---------------------------------------------------------------------------


class TestResolveAwsProfileEnv:
    """Tests for CredentialResolver._resolve_aws_profile_env."""

    def test_returns_credentials_when_aws_profile_set(self):
        mock_boto3 = _make_boto3_mock("444455556666")

        with (
            patch.dict(os.environ, {"AWS_PROFILE": "my-dev-profile"}, clear=False),
            patch(
                "synth.deploy.agentcore.credentials._import_boto3",
                return_value=mock_boto3,
            ),
        ):
            resolver = CredentialResolver()
            result = resolver._resolve_aws_profile_env()

        assert result is not None
        assert result.source == "env:AWS_PROFILE=my-dev-profile"
        assert result.account_id == "444455556666"
        assert result.profile_name == "my-dev-profile"

    def test_returns_none_when_aws_profile_not_set(self):
        env = {k: v for k, v in os.environ.items() if k != "AWS_PROFILE"}
        with patch.dict(os.environ, env, clear=True):
            resolver = CredentialResolver()
            result = resolver._resolve_aws_profile_env()

        assert result is None

    def test_returns_none_when_aws_profile_empty(self):
        with patch.dict(os.environ, {"AWS_PROFILE": ""}, clear=False):
            resolver = CredentialResolver()
            result = resolver._resolve_aws_profile_env()

        assert result is None

    def test_returns_none_when_session_creation_fails(self):
        mock_boto3 = MagicMock()
        mock_boto3.Session.side_effect = Exception("profile not found")

        with (
            patch.dict(os.environ, {"AWS_PROFILE": "bad-profile"}, clear=False),
            patch(
                "synth.deploy.agentcore.credentials._import_boto3",
                return_value=mock_boto3,
            ),
        ):
            resolver = CredentialResolver()
            result = resolver._resolve_aws_profile_env()

        assert result is None


# ---------------------------------------------------------------------------
# CredentialResolver._resolve_named_profiles
# ---------------------------------------------------------------------------


class TestResolveNamedProfiles:
    """Tests for CredentialResolver._resolve_named_profiles."""

    def test_returns_first_valid_named_profile(self):
        mock_boto3 = _make_boto3_mock("777788889999")

        resolver = CredentialResolver()
        with (
            patch.object(
                resolver, "list_available_profiles", return_value=["default", "dev", "prod"]
            ),
            patch(
                "synth.deploy.agentcore.credentials._import_boto3",
                return_value=mock_boto3,
            ),
        ):
            result = resolver._resolve_named_profiles()

        assert result is not None
        assert result.source == "profile:dev"
        assert result.account_id == "777788889999"
        assert result.profile_name == "dev"

    def test_skips_default_profile(self):
        """default is handled by _resolve_aws_credentials_file, so it's excluded."""
        mock_boto3 = _make_boto3_mock("111122223333")

        resolver = CredentialResolver()
        with (
            patch.object(
                resolver, "list_available_profiles", return_value=["default"]
            ),
            patch(
                "synth.deploy.agentcore.credentials._import_boto3",
                return_value=mock_boto3,
            ),
        ):
            result = resolver._resolve_named_profiles()

        assert result is None

    def test_returns_none_when_no_profiles_available(self):
        resolver = CredentialResolver()
        with patch.object(resolver, "list_available_profiles", return_value=[]):
            result = resolver._resolve_named_profiles()

        assert result is None

    def test_skips_failing_profiles_and_returns_next(self):
        """If the first non-default profile fails, try the next one."""
        mock_boto3 = MagicMock()
        call_count = 0

        def session_side_effect(profile_name: str = "default", **kwargs):
            nonlocal call_count
            call_count += 1
            if profile_name == "broken":
                raise Exception("invalid profile")
            mock_session = MagicMock()
            mock_sts = MagicMock()
            mock_sts.get_caller_identity.return_value = {"Account": "888899990000"}
            mock_session.client.return_value = mock_sts
            return mock_session

        mock_boto3.Session.side_effect = session_side_effect

        resolver = CredentialResolver()
        with (
            patch.object(
                resolver,
                "list_available_profiles",
                return_value=["default", "broken", "working"],
            ),
            patch.object(
                resolver,
                "get_profile_region",
                return_value="us-east-1",
            ),
            patch(
                "synth.deploy.agentcore.credentials._import_boto3",
                return_value=mock_boto3,
            ),
        ):
            result = resolver._resolve_named_profiles()

        assert result is not None
        assert result.source == "profile:working"
        assert result.account_id == "888899990000"

    def test_returns_none_when_all_named_profiles_fail(self):
        mock_boto3 = MagicMock()
        mock_boto3.Session.side_effect = Exception("all fail")

        resolver = CredentialResolver()
        with (
            patch.object(
                resolver, "list_available_profiles", return_value=["alpha", "beta"]
            ),
            patch(
                "synth.deploy.agentcore.credentials._import_boto3",
                return_value=mock_boto3,
            ),
        ):
            result = resolver._resolve_named_profiles()

        assert result is None


# ---------------------------------------------------------------------------
# CredentialResolver.resolve — source priority ordering
# ---------------------------------------------------------------------------


class TestResolveSourcePriority:
    def test_env_vars_take_priority_over_file(self):
        mock_boto3 = _make_boto3_mock("111111111111")

        with (
            patch.dict(
                os.environ,
                {
                    "AWS_ACCESS_KEY_ID": "AKIAIOSFODNN7EXAMPLE",
                    "AWS_SECRET_ACCESS_KEY": "secret",
                },
            ),
            patch(
                "synth.deploy.agentcore.credentials._import_boto3",
                return_value=mock_boto3,
            ),
        ):
            resolver = CredentialResolver()
            result = resolver.resolve()

        assert result is not None
        assert result.source == "env"

    def test_full_resolution_order(self):
        """Verify all six sources are tried in the correct order."""
        resolver = CredentialResolver()
        call_order: list[str] = []

        def _tracker(name: str, result=None):
            def fn():
                call_order.append(name)
                return result
            return fn

        with (
            patch.object(resolver, "_resolve_env_vars", _tracker("env")),
            patch.object(resolver, "_resolve_aws_profile_env", _tracker("profile_env")),
            patch.object(resolver, "_resolve_aws_credentials_file", _tracker("file")),
            patch.object(resolver, "_resolve_named_profiles", _tracker("named")),
            patch.object(resolver, "_resolve_ide_toolkit", _tracker("ide")),
            patch.object(resolver, "_resolve_aws_toolkit", _tracker("toolkit")),
        ):
            result = resolver.resolve()

        assert result is None
        assert call_order == ["env", "profile_env", "file", "named", "ide", "toolkit"]

    def test_aws_profile_env_takes_priority_over_credentials_file(self):
        """AWS_PROFILE env var is checked before ~/.aws/credentials default."""
        resolver = CredentialResolver()
        call_order: list[str] = []

        profile_env_result = ResolvedCredentials(
            source="env:AWS_PROFILE=dev",
            account_id="444455556666",
            profile_name="dev",
        )

        def _tracker(name: str, result=None):
            def fn():
                call_order.append(name)
                return result
            return fn

        with (
            patch.object(resolver, "_resolve_env_vars", _tracker("env")),
            patch.object(
                resolver, "_resolve_aws_profile_env", _tracker("profile_env", profile_env_result)
            ),
            patch.object(resolver, "_resolve_aws_credentials_file", _tracker("file")),
            patch.object(resolver, "_resolve_named_profiles", _tracker("named")),
            patch.object(resolver, "_resolve_ide_toolkit", _tracker("ide")),
            patch.object(resolver, "_resolve_aws_toolkit", _tracker("toolkit")),
        ):
            result = resolver.resolve()

        assert result is not None
        assert result.source == "env:AWS_PROFILE=dev"
        # file, named, ide, toolkit should not be reached
        assert call_order == ["env", "profile_env"]

    def test_named_profiles_checked_before_ide_toolkit(self):
        """Named profiles are tried before IDE toolkit sources."""
        resolver = CredentialResolver()
        call_order: list[str] = []

        named_result = ResolvedCredentials(
            source="profile:staging",
            account_id="777788889999",
            profile_name="staging",
        )

        def _tracker(name: str, result=None):
            def fn():
                call_order.append(name)
                return result
            return fn

        with (
            patch.object(resolver, "_resolve_env_vars", _tracker("env")),
            patch.object(resolver, "_resolve_aws_profile_env", _tracker("profile_env")),
            patch.object(resolver, "_resolve_aws_credentials_file", _tracker("file")),
            patch.object(resolver, "_resolve_named_profiles", _tracker("named", named_result)),
            patch.object(resolver, "_resolve_ide_toolkit", _tracker("ide")),
            patch.object(resolver, "_resolve_aws_toolkit", _tracker("toolkit")),
        ):
            result = resolver.resolve()

        assert result is not None
        assert result.source == "profile:staging"
        assert call_order == ["env", "profile_env", "file", "named"]

    def test_ide_toolkit_used_before_aws_toolkit(self):
        """_resolve_ide_toolkit must be called before _resolve_aws_toolkit."""
        resolver = CredentialResolver()
        call_order: list[str] = []

        def _tracker(name: str, result=None):
            def fn():
                call_order.append(name)
                return result
            return fn

        ide_result = ResolvedCredentials(
            source="ide_toolkit:kiro",
            account_id="123456789012",
            profile_name=None,
        )

        with (
            patch.object(resolver, "_resolve_env_vars", _tracker("env")),
            patch.object(resolver, "_resolve_aws_profile_env", _tracker("profile_env")),
            patch.object(resolver, "_resolve_aws_credentials_file", _tracker("file")),
            patch.object(resolver, "_resolve_named_profiles", _tracker("named")),
            patch.object(resolver, "_resolve_ide_toolkit", _tracker("ide", ide_result)),
            patch.object(resolver, "_resolve_aws_toolkit", _tracker("toolkit")),
        ):
            result = resolver.resolve()

        assert result is not None
        assert result.source == "ide_toolkit:kiro"
        assert call_order == ["env", "profile_env", "file", "named", "ide"]

    def test_returns_none_when_all_sources_fail(self):
        resolver = CredentialResolver()

        with (
            patch.object(resolver, "_resolve_env_vars", return_value=None),
            patch.object(resolver, "_resolve_aws_profile_env", return_value=None),
            patch.object(resolver, "_resolve_aws_credentials_file", return_value=None),
            patch.object(resolver, "_resolve_named_profiles", return_value=None),
            patch.object(resolver, "_resolve_ide_toolkit", return_value=None),
            patch.object(resolver, "_resolve_aws_toolkit", return_value=None),
        ):
            result = resolver.resolve()

        assert result is None

    def test_source_exception_does_not_abort_resolution(self):
        """A source that raises must be skipped; subsequent sources are tried."""
        resolver = CredentialResolver()
        fallback = ResolvedCredentials(
            source="aws_file", account_id="222233334444", profile_name="default"
        )

        def _raise():
            raise RuntimeError("boom")

        with (
            patch.object(resolver, "_resolve_env_vars", _raise),
            patch.object(resolver, "_resolve_aws_profile_env", return_value=None),
            patch.object(resolver, "_resolve_aws_credentials_file", return_value=fallback),
            patch.object(resolver, "_resolve_named_profiles", return_value=None),
            patch.object(resolver, "_resolve_ide_toolkit", return_value=None),
            patch.object(resolver, "_resolve_aws_toolkit", return_value=None),
        ):
            result = resolver.resolve()

        assert result is not None
        assert result.source == "aws_file"


# ---------------------------------------------------------------------------
# CredentialResolver.resolve_profile
# ---------------------------------------------------------------------------


class TestResolveProfile:
    def test_returns_credentials_for_valid_profile(self):
        mock_boto3 = _make_boto3_mock("555566667777")

        with patch(
            "synth.deploy.agentcore.credentials._import_boto3",
            return_value=mock_boto3,
        ):
            resolver = CredentialResolver()
            result = resolver.resolve_profile("my-profile")

        assert result is not None
        assert result.source == "profile:my-profile"
        assert result.account_id == "555566667777"
        assert result.profile_name == "my-profile"

    @pytest.mark.parametrize("bad_name", ["", "   "])
    def test_raises_synth_config_error_for_empty_profile_name(self, bad_name: str):
        resolver = CredentialResolver()
        with pytest.raises(SynthConfigError) as exc_info:
            resolver.resolve_profile(bad_name)

        assert exc_info.value.component == "CredentialResolver"

    def test_returns_none_when_profile_not_found(self):
        mock_boto3 = MagicMock()
        mock_boto3.Session.side_effect = Exception("profile not found")

        with patch(
            "synth.deploy.agentcore.credentials._import_boto3",
            return_value=mock_boto3,
        ):
            resolver = CredentialResolver()
            result = resolver.resolve_profile("nonexistent")

        assert result is None


# ---------------------------------------------------------------------------
# CredentialResolver.mask_account_id
# ---------------------------------------------------------------------------


class TestMaskAccountId:
    @pytest.mark.parametrize(
        "account_id, expected",
        [
            ("123456789012", "****9012"),
            ("000000000001", "****0001"),
            ("", "****"),
        ],
    )
    def test_masks_correctly(self, account_id: str, expected: str):
        resolver = CredentialResolver()
        assert resolver.mask_account_id(account_id) == expected


# ---------------------------------------------------------------------------
# CredentialResolver.redact_credentials
# ---------------------------------------------------------------------------


class TestRedactCredentials:
    def test_redacts_akia_access_key(self):
        resolver = CredentialResolver()
        text = "key=AKIAIOSFODNN7EXAMPLEKEY1"
        result = resolver.redact_credentials(text)
        assert "AKIA" not in result
        assert "[REDACTED]" in result

    def test_redacts_asia_access_key(self):
        resolver = CredentialResolver()
        text = "token=ASIAIOSFODNN7EXAMPLEKEY1"
        result = resolver.redact_credentials(text)
        assert "ASIA" not in result
        assert "[REDACTED]" in result

    def test_plain_text_unchanged(self):
        resolver = CredentialResolver()
        text = "no credentials here"
        assert resolver.redact_credentials(text) == text
