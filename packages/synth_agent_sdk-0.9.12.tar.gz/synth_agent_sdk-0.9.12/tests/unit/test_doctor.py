"""Tests for ``synth.cli.doctor`` — environment and dependency checks."""

from __future__ import annotations

import os
import subprocess
import sys
from unittest.mock import MagicMock, patch

import pytest

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_REAL_IMPORT = __import__

# Packages that doctor.py checks via __import__ at runtime (not module-level imports)
# Note: "click" is excluded — it's a real module-level import used by run_doctor itself
_DOCTOR_PKGS = frozenset({
    "pydantic", "httpx",
    "anthropic", "openai", "google.genai", "boto3",
})

# Env vars that doctor.py checks — cleared between tests via _clean_env
_DOCTOR_ENV_VARS = (
    "ANTHROPIC_API_KEY", "OPENAI_API_KEY", "GOOGLE_API_KEY",
    "SYNTH_TRACE_ENDPOINT", "AWS_ACCESS_KEY_ID",
)


def _make_import_mock(fail: set[str] | None = None) -> object:
    """Return a side_effect for builtins.__import__.

    All packages in ``_DOCTOR_PKGS`` return a MagicMock unless they are in
    ``fail``.  Everything else falls through to the real import.

    Parameters
    ----------
    fail:
        Package names that should raise ImportError.
    """
    fail = fail or set()

    def _import(name: str, *args: object, **kwargs: object) -> object:
        if name in fail:
            raise ImportError(f"No module named '{name}'")
        if name in _DOCTOR_PKGS:
            m = MagicMock()
            m.__version__ = "1.0.0"
            return m
        return _REAL_IMPORT(name, *args, **kwargs)

    return _import


def _clean_env(**overrides: str) -> dict[str, str]:
    """Return env overrides that clear all doctor-checked vars then apply overrides."""
    env = {k: "" for k in _DOCTOR_ENV_VARS}
    env.update(overrides)
    return env


# ===================================================================
# run_doctor — main function
# ===================================================================


class TestRunDoctor:
    """Tests for the ``run_doctor`` function."""

    def test_all_checks_pass_with_full_environment(self, capsys):
        """All checks pass when Python 3.10+, core deps, and providers are available."""
        env = _clean_env(
            ANTHROPIC_API_KEY="sk-ant-test",
            OPENAI_API_KEY="sk-test",
            GOOGLE_API_KEY="test-key",
            SYNTH_TRACE_ENDPOINT="https://trace.example.com",
            AWS_ACCESS_KEY_ID="AKIATEST",
        )

        with patch.dict("os.environ", env), \
             patch("builtins.__import__", side_effect=_make_import_mock()):
            from synth.cli.doctor import run_doctor
            run_doctor()

        captured = capsys.readouterr()
        assert "All checks passed" in captured.out
        assert "[  OK  ]" in captured.out
        assert "[FAIL]" not in captured.out

    def test_python_version_check_passes_on_3_10_plus(self, capsys):
        """Python version check passes on 3.10+."""
        with patch.dict("os.environ", _clean_env()), \
             patch("builtins.__import__", side_effect=_make_import_mock()):
            from synth.cli.doctor import run_doctor
            run_doctor()

        captured = capsys.readouterr()
        v = sys.version_info
        assert f"Python {v.major}.{v.minor}.{v.micro}" in captured.out
        assert "[  OK  ]" in captured.out

    def test_python_version_check_fails_on_old_version(self, capsys):
        """Python version check fails and increments issue count on Python < 3.10."""
        with patch.dict("os.environ", _clean_env()), \
             patch("synth.cli.doctor.sys") as mock_sys, \
             patch("builtins.__import__", side_effect=_make_import_mock()):
            mock_sys.version_info = MagicMock(
                major=3, minor=9, micro=0,
                __ge__=lambda self, other: (3, 9) >= other,
            )
            from synth.cli.doctor import run_doctor
            run_doctor()

        captured = capsys.readouterr()
        assert "Python 3.9 — requires 3.10+" in captured.out
        assert "[FAIL]" in captured.out
        assert "issue(s) found" in captured.out

    def test_core_dependency_missing_increments_issues(self, capsys):
        """Missing core dependency increments issue count and shows install command."""
        import importlib.metadata as _meta

        real_version = _meta.version

        def _version_side_effect(pkg: str) -> str:
            if pkg == "pydantic":
                raise _meta.PackageNotFoundError(pkg)
            return real_version(pkg)

        with patch.dict("os.environ", _clean_env()), \
             patch("importlib.metadata.version", side_effect=_version_side_effect), \
             patch("builtins.__import__", side_effect=_make_import_mock()):
            from synth.cli.doctor import run_doctor
            run_doctor()

        captured = capsys.readouterr()
        assert "pydantic not installed" in captured.out
        assert "pip install synth-agent-sdk" in captured.out
        assert "[FAIL]" in captured.out
        assert "issue(s) found" in captured.out

    def test_provider_env_vars_show_ok_when_set(self, capsys):
        """Provider env vars show OK status when set."""
        env = _clean_env(
            ANTHROPIC_API_KEY="sk-ant-test",
            OPENAI_API_KEY="sk-test",
            GOOGLE_API_KEY="test-key",
        )

        with patch.dict("os.environ", env), \
             patch("builtins.__import__", side_effect=_make_import_mock()):
            from synth.cli.doctor import run_doctor
            run_doctor()

        captured = capsys.readouterr()
        assert "Anthropic (ANTHROPIC_API_KEY set)" in captured.out
        assert "OpenAI (OPENAI_API_KEY set)" in captured.out
        assert "Google (GOOGLE_API_KEY set)" in captured.out

    def test_provider_env_vars_show_info_when_not_set(self, capsys):
        """Provider env vars show INFO status when not set."""
        with patch.dict("os.environ", _clean_env()), \
             patch("builtins.__import__", side_effect=_make_import_mock()):
            from synth.cli.doctor import run_doctor
            run_doctor()

        captured = capsys.readouterr()
        assert "Anthropic (ANTHROPIC_API_KEY not set)" in captured.out
        assert "OpenAI (OPENAI_API_KEY not set)" in captured.out
        assert "Google (GOOGLE_API_KEY not set)" in captured.out
        assert "[INFO]" in captured.out

    def test_trace_endpoint_https_passes(self, capsys):
        """SYNTH_TRACE_ENDPOINT with HTTPS passes validation."""
        env = _clean_env(SYNTH_TRACE_ENDPOINT="https://trace.example.com/api")

        with patch.dict("os.environ", env), \
             patch("builtins.__import__", side_effect=_make_import_mock()):
            from synth.cli.doctor import run_doctor
            run_doctor()

        captured = capsys.readouterr()
        assert "SYNTH_TRACE_ENDPOINT: https://trace.example.com" in captured.out
        assert "[  OK  ]" in captured.out

    def test_trace_endpoint_http_fails(self, capsys):
        """SYNTH_TRACE_ENDPOINT with HTTP fails validation and increments issues."""
        env = _clean_env(SYNTH_TRACE_ENDPOINT="http://trace.example.com")

        with patch.dict("os.environ", env), \
             patch("builtins.__import__", side_effect=_make_import_mock()):
            from synth.cli.doctor import run_doctor
            run_doctor()

        captured = capsys.readouterr()
        assert "SYNTH_TRACE_ENDPOINT should use HTTPS" in captured.out
        assert "[FAIL]" in captured.out
        assert "issue(s) found" in captured.out

    def test_trace_endpoint_not_set_shows_info(self, capsys):
        """SYNTH_TRACE_ENDPOINT not set shows info message."""
        with patch.dict("os.environ", _clean_env()), \
             patch("builtins.__import__", side_effect=_make_import_mock()):
            from synth.cli.doctor import run_doctor
            run_doctor()

        captured = capsys.readouterr()
        assert "SYNTH_TRACE_ENDPOINT not set (traces local only)" in captured.out
        assert "[INFO]" in captured.out

    def test_optional_packages_missing_show_info_and_suggestions(self, capsys):
        """Missing optional packages show INFO and helpful install suggestions."""
        with patch.dict("os.environ", _clean_env()), \
             patch("builtins.__import__", side_effect=_make_import_mock(
                 fail={"anthropic", "openai", "google.genai", "boto3"}
             )):
            from synth.cli.doctor import run_doctor
            run_doctor()

        captured = capsys.readouterr()
        assert "synth[anthropic] not installed" in captured.out
        assert "synth[openai] not installed" in captured.out
        assert "synth[google] not installed" in captured.out
        assert "synth[bedrock] not installed" in captured.out
        assert "Missing provider packages:" in captured.out
        assert "Install all: pip install synth-agent-sdk[all]" in captured.out

    def test_aws_credentials_from_env_vars(self, capsys):
        """AWS credentials detected from environment variables."""
        env = _clean_env(AWS_ACCESS_KEY_ID="AKIATEST")

        with patch.dict("os.environ", env), \
             patch("builtins.__import__", side_effect=_make_import_mock()):
            from synth.cli.doctor import run_doctor
            run_doctor()

        captured = capsys.readouterr()
        assert "AWS credentials found (env vars)" in captured.out
        assert "[  OK  ]" in captured.out

    def test_aws_credentials_from_file(self, capsys):
        """AWS credentials detected from ~/.aws/credentials file."""
        with patch.dict("os.environ", _clean_env()), \
             patch("builtins.__import__", side_effect=_make_import_mock()), \
             patch("os.path.exists", return_value=True):
            from synth.cli.doctor import run_doctor
            run_doctor()

        captured = capsys.readouterr()
        assert "AWS credentials found (~/.aws/credentials)" in captured.out
        assert "[  OK  ]" in captured.out

    def test_aws_credentials_not_configured_shows_info(self, capsys):
        """AWS credentials not configured shows info with setup instructions."""
        with patch.dict("os.environ", _clean_env()), \
             patch("builtins.__import__", side_effect=_make_import_mock()), \
             patch("os.path.exists", return_value=False):
            from synth.cli.doctor import run_doctor
            run_doctor()

        captured = capsys.readouterr()
        assert "AWS credentials not configured" in captured.out
        assert "pip install awscli && aws configure" in captured.out
        assert "[INFO]" in captured.out

    def test_no_missing_providers_no_suggestions_shown(self, capsys):
        """When all providers are installed, no missing provider suggestions shown."""
        with patch.dict("os.environ", _clean_env()), \
             patch("builtins.__import__", side_effect=_make_import_mock()):
            from synth.cli.doctor import run_doctor
            run_doctor()

        captured = capsys.readouterr()
        assert "Missing provider packages:" not in captured.out
        assert "Install all: pip install synth-agent-sdk[all]" not in captured.out


# ===================================================================
# Helper functions
# ===================================================================


class TestHelperFunctions:
    """Tests for the helper output functions."""

    def test_ok_prints_green_status(self, capsys):
        """_ok prints a green OK status line."""
        from synth.cli.doctor import _ok

        _ok("Test message")
        captured = capsys.readouterr()
        assert "[  OK  ]" in captured.out
        assert "Test message" in captured.out

    def test_fail_prints_red_status(self, capsys):
        """_fail prints a red FAIL status line."""
        from synth.cli.doctor import _fail

        _fail("Test error")
        captured = capsys.readouterr()
        assert "[FAIL]" in captured.out
        assert "Test error" in captured.out

    def test_info_prints_yellow_status(self, capsys):
        """_info prints a yellow INFO status line."""
        from synth.cli.doctor import _info

        _info("Test info")
        captured = capsys.readouterr()
        assert "[INFO]" in captured.out
        assert "Test info" in captured.out


# ===================================================================
# Integration tests
# ===================================================================


class TestDoctorIntegration:
    """Integration tests for the doctor command."""

    def test_multiple_issues_counted_correctly(self, capsys):
        """Multiple issues are counted and reported correctly."""
        import importlib.metadata as _meta

        real_version = _meta.version

        def _version_side_effect(pkg: str) -> str:
            if pkg == "pydantic":
                raise _meta.PackageNotFoundError(pkg)
            return real_version(pkg)

        env = _clean_env(SYNTH_TRACE_ENDPOINT="http://insecure.example.com")

        with patch.dict("os.environ", env), \
             patch("synth.cli.doctor.sys") as mock_sys, \
             patch("importlib.metadata.version", side_effect=_version_side_effect), \
             patch("builtins.__import__", side_effect=_make_import_mock()):
            mock_sys.version_info = MagicMock(
                major=3, minor=9, micro=0,
                __ge__=lambda self, other: (3, 9) >= other,
            )
            from synth.cli.doctor import run_doctor
            run_doctor()

        captured = capsys.readouterr()
        # 3 issues: Python version, pydantic missing, HTTP endpoint
        assert "3 issue(s) found" in captured.out

    def test_zero_issues_shows_success_message(self, capsys):
        """Zero issues shows success message in green."""
        env = _clean_env(
            ANTHROPIC_API_KEY="sk-ant-test",
            SYNTH_TRACE_ENDPOINT="https://trace.example.com",
        )

        with patch.dict("os.environ", env), \
             patch("builtins.__import__", side_effect=_make_import_mock()):
            from synth.cli.doctor import run_doctor
            run_doctor()

        captured = capsys.readouterr()
        assert "All checks passed" in captured.out
        assert "issue(s) found" not in captured.out


# ===================================================================
# Platform and environment checks
# ===================================================================


class TestCheckPlatform:
    """Tests for the ``_check_platform`` function."""

    def test_venv_detected_shows_ok(self, capsys):
        """Running inside a venv shows OK status."""
        from synth.cli.doctor import _check_platform

        with patch("synth.cli.doctor.sys") as mock_sys, \
             patch("synth.cli.doctor.platform") as mock_platform:
            mock_sys.platform = "linux"
            mock_sys.prefix = "/home/user/.venv"
            mock_sys.base_prefix = "/usr"
            mock_platform.machine.return_value = "x86_64"
            issues = _check_platform()

        captured = capsys.readouterr()
        assert issues == 0
        assert "Running inside venv" in captured.out

    def test_conda_env_detected_shows_ok(self, capsys):
        """Running inside a conda env shows OK status."""
        from synth.cli.doctor import _check_platform

        with patch("synth.cli.doctor.sys") as mock_sys, \
             patch("synth.cli.doctor.platform") as mock_platform, \
             patch.dict("os.environ", {"CONDA_DEFAULT_ENV": "myenv"}):
            mock_sys.platform = "darwin"
            mock_sys.prefix = "/opt/conda/envs/myenv"
            mock_sys.base_prefix = "/opt/conda/envs/myenv"
            mock_platform.machine.return_value = "arm64"
            mock_platform.processor.return_value = "arm"
            issues = _check_platform()

        captured = capsys.readouterr()
        assert "Running inside conda" in captured.out

    def test_no_venv_on_macos_shows_fail(self, capsys):
        """Not running in a venv on macOS shows FAIL with instructions."""
        from synth.cli.doctor import _check_platform

        with patch("synth.cli.doctor.sys") as mock_sys, \
             patch("synth.cli.doctor.platform") as mock_platform, \
             patch("synth.cli.doctor.subprocess") as mock_sub, \
             patch("synth.cli.doctor._check_awscrt_apple_silicon", return_value=0), \
             patch.dict("os.environ", {}, clear=True):
            mock_sys.platform = "darwin"
            mock_sys.prefix = "/usr/local"
            mock_sys.base_prefix = "/usr/local"
            mock_platform.machine.return_value = "arm64"
            mock_platform.processor.return_value = "arm"
            mock_sub.run.return_value = MagicMock(returncode=0)
            issues = _check_platform()

        captured = capsys.readouterr()
        assert issues >= 1
        assert "Not running in a virtual environment" in captured.out
        assert "python3 -m venv" in captured.out

    def test_no_venv_on_linux_shows_info_not_fail(self, capsys):
        """Not running in a venv on Linux shows INFO, not FAIL."""
        from synth.cli.doctor import _check_platform

        with patch("synth.cli.doctor.sys") as mock_sys, \
             patch("synth.cli.doctor.platform") as mock_platform, \
             patch.dict("os.environ", {}, clear=True):
            mock_sys.platform = "linux"
            mock_sys.prefix = "/usr"
            mock_sys.base_prefix = "/usr"
            mock_platform.machine.return_value = "x86_64"
            issues = _check_platform()

        captured = capsys.readouterr()
        assert issues == 0
        assert "Not running in a virtual environment" in captured.out
        assert "[INFO]" in captured.out

    def test_macos_xcode_clt_installed_shows_ok(self, capsys):
        """Xcode CLT installed on macOS shows OK."""
        from synth.cli.doctor import _check_platform

        with patch("synth.cli.doctor.sys") as mock_sys, \
             patch("synth.cli.doctor.platform") as mock_platform, \
             patch("synth.cli.doctor.subprocess") as mock_sub, \
             patch("synth.cli.doctor._check_awscrt_apple_silicon", return_value=0), \
             patch.dict("os.environ", {"VIRTUAL_ENV": "/home/user/.venv"}):
            mock_sys.platform = "darwin"
            mock_sys.prefix = "/home/user/.venv"
            mock_sys.base_prefix = "/usr"
            mock_platform.machine.return_value = "arm64"
            mock_platform.processor.return_value = "arm"
            mock_sub.run.return_value = MagicMock(returncode=0)
            issues = _check_platform()

        captured = capsys.readouterr()
        assert issues == 0
        assert "Xcode Command Line Tools installed" in captured.out

    def test_macos_xcode_clt_missing_shows_info(self, capsys):
        """Xcode CLT missing on macOS shows INFO with install command."""
        from synth.cli.doctor import _check_platform

        with patch("synth.cli.doctor.sys") as mock_sys, \
             patch("synth.cli.doctor.platform") as mock_platform, \
             patch("synth.cli.doctor.subprocess") as mock_sub, \
             patch("synth.cli.doctor._check_awscrt_apple_silicon", return_value=0), \
             patch.dict("os.environ", {"VIRTUAL_ENV": "/home/user/.venv"}):
            mock_sys.platform = "darwin"
            mock_sys.prefix = "/home/user/.venv"
            mock_sys.base_prefix = "/usr"
            mock_platform.machine.return_value = "arm64"
            mock_platform.processor.return_value = "arm"
            mock_sub.run.return_value = MagicMock(returncode=2)
            issues = _check_platform()

        captured = capsys.readouterr()
        assert "Xcode Command Line Tools not detected" in captured.out
        assert "xcode-select --install" in captured.out

    def test_non_macos_skips_macos_checks(self, capsys):
        """Non-macOS platforms skip Xcode and Apple Silicon checks."""
        from synth.cli.doctor import _check_platform

        with patch("synth.cli.doctor.sys") as mock_sys, \
             patch("synth.cli.doctor.platform") as mock_platform, \
             patch.dict("os.environ", {"VIRTUAL_ENV": "/home/user/.venv"}):
            mock_sys.platform = "win32"
            mock_sys.prefix = "/home/user/.venv"
            mock_sys.base_prefix = "/usr"
            mock_platform.machine.return_value = "AMD64"
            issues = _check_platform()

        captured = capsys.readouterr()
        assert issues == 0
        assert "Xcode" not in captured.out
        assert "Apple Silicon" not in captured.out


class TestHasXcodeClt:
    """Tests for the ``_has_xcode_clt`` helper."""

    def test_returns_true_when_xcode_select_succeeds(self):
        """Returns True when xcode-select -p exits 0."""
        from synth.cli.doctor import _has_xcode_clt

        with patch("synth.cli.doctor.subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0)
            assert _has_xcode_clt() is True

    def test_returns_false_when_xcode_select_fails(self):
        """Returns False when xcode-select -p exits non-zero."""
        from synth.cli.doctor import _has_xcode_clt

        with patch("synth.cli.doctor.subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=2)
            assert _has_xcode_clt() is False

    def test_returns_false_when_command_not_found(self):
        """Returns False when xcode-select is not on PATH."""
        from synth.cli.doctor import _has_xcode_clt

        with patch("synth.cli.doctor.subprocess.run",
                    side_effect=FileNotFoundError):
            assert _has_xcode_clt() is False

    def test_returns_false_on_timeout(self):
        """Returns False when xcode-select times out."""
        from synth.cli.doctor import _has_xcode_clt

        with patch("synth.cli.doctor.subprocess.run",
                    side_effect=subprocess.TimeoutExpired("xcode-select", 5)):
            assert _has_xcode_clt() is False


class TestCheckAwscrtAppleSilicon:
    """Tests for the ``_check_awscrt_apple_silicon`` helper."""

    def test_awscrt_installed_shows_ok(self, capsys):
        """awscrt importable shows OK."""
        from synth.cli.doctor import _check_awscrt_apple_silicon

        with patch("builtins.__import__", side_effect=_make_import_mock()):
            issues = _check_awscrt_apple_silicon()

        captured = capsys.readouterr()
        assert issues == 0
        assert "awscrt installed" in captured.out

    def test_awscrt_missing_without_boto3_no_warning(self, capsys):
        """awscrt missing but boto3 also missing shows nothing."""
        from synth.cli.doctor import _check_awscrt_apple_silicon

        with patch("builtins.__import__",
                    side_effect=_make_import_mock(fail={"awscrt", "boto3"})):
            issues = _check_awscrt_apple_silicon()

        captured = capsys.readouterr()
        assert issues == 0
        assert "awscrt" not in captured.out

    def test_awscrt_missing_with_boto3_shows_info(self, capsys):
        """awscrt missing but boto3 installed shows INFO with workaround."""
        from synth.cli.doctor import _check_awscrt_apple_silicon

        def _import(name: str, *args: object, **kwargs: object) -> object:
            if name == "awscrt":
                raise ImportError("No module named 'awscrt'")
            if name == "boto3":
                return MagicMock()
            return _REAL_IMPORT(name, *args, **kwargs)

        with patch("builtins.__import__", side_effect=_import):
            issues = _check_awscrt_apple_silicon()

        captured = capsys.readouterr()
        assert issues == 0
        assert "awscrt not installed" in captured.out
        assert "botocore[crt]" in captured.out
