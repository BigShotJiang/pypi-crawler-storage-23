"""Unit tests for the Synth error hierarchy."""

from __future__ import annotations

import pytest

from synth.errors import (
    CostLimitError,
    GraphLoopError,
    GraphRoutingError,
    GuardViolationError,
    PipelineError,
    RunNotFoundError,
    SynthConfigError,
    SynthError,
    SynthParseError,
    ToolDefinitionError,
    ToolExecutionError,
)


# ---------------------------------------------------------------------------
# SynthError base
# ---------------------------------------------------------------------------


class TestSynthError:
    def test_instantiation(self):
        err = SynthError("boom", component="Core", suggestion="fix it")
        assert str(err) == "boom"
        assert err.component == "Core"
        assert err.suggestion == "fix it"

    def test_is_exception(self):
        assert issubclass(SynthError, Exception)


# ---------------------------------------------------------------------------
# Simple subclasses (no extra fields)
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "cls",
    [SynthConfigError, ToolDefinitionError, SynthParseError],
)
class TestSimpleSubclasses:
    def test_inherits_from_synth_error(self, cls):
        assert issubclass(cls, SynthError)

    def test_instantiation(self, cls):
        err = cls("msg", component="Comp", suggestion="do this")
        assert str(err) == "msg"
        assert err.component == "Comp"
        assert err.suggestion == "do this"

    def test_can_be_caught_as_synth_error(self, cls):
        with pytest.raises(SynthError):
            raise cls("msg", component="C", suggestion="S")


# ---------------------------------------------------------------------------
# ToolExecutionError
# ---------------------------------------------------------------------------


class TestToolExecutionError:
    def test_inherits_from_synth_error(self):
        assert issubclass(ToolExecutionError, SynthError)

    def test_preserves_fields(self):
        orig = ValueError("kaboom")
        err = ToolExecutionError(
            "tool failed",
            component="ToolExecutor",
            suggestion="check args",
            tool_name="get_weather",
            tool_args={"city": "Seattle"},
            original_error=orig,
        )
        assert str(err) == "tool failed"
        assert err.component == "ToolExecutor"
        assert err.suggestion == "check args"
        assert err.tool_name == "get_weather"
        assert err.tool_args == {"city": "Seattle"}
        assert err.original_error is orig

    def test_str_is_meaningful(self):
        err = ToolExecutionError(
            "Tool 'fetch' raised RuntimeError: timeout",
            component="ToolExecutor",
            suggestion="Increase timeout",
            tool_name="fetch",
            tool_args={},
            original_error=RuntimeError("timeout"),
        )
        assert "fetch" in str(err)
        assert "timeout" in str(err)


# ---------------------------------------------------------------------------
# GuardViolationError
# ---------------------------------------------------------------------------


class TestGuardViolationError:
    def test_inherits_from_synth_error(self):
        assert issubclass(GuardViolationError, SynthError)

    def test_fields(self):
        err = GuardViolationError(
            "PII detected",
            component="PIIGuard",
            suggestion="Remove PII",
            guard_name="no_pii_output",
            violating_content="email@example.com",
            remediation="Strip emails before returning",
        )
        assert err.guard_name == "no_pii_output"
        assert err.violating_content == "email@example.com"
        assert err.remediation == "Strip emails before returning"
        assert str(err) == "PII detected"


# ---------------------------------------------------------------------------
# CostLimitError
# ---------------------------------------------------------------------------


class TestCostLimitError:
    def test_inherits_from_guard_violation_error(self):
        assert issubclass(CostLimitError, GuardViolationError)

    def test_inherits_from_synth_error(self):
        assert issubclass(CostLimitError, SynthError)

    def test_instantiation(self):
        err = CostLimitError(
            "Cost exceeded $0.10",
            component="CostGuard",
            suggestion="Increase limit",
            guard_name="max_cost",
            violating_content="$0.15",
            remediation="Raise Guard.max_cost(dollars=0.20)",
        )
        assert err.guard_name == "max_cost"
        assert str(err) == "Cost exceeded $0.10"

    def test_can_be_caught_as_guard_violation(self):
        with pytest.raises(GuardViolationError):
            raise CostLimitError(
                "over budget",
                component="CostGuard",
                suggestion="raise limit",
                guard_name="max_cost",
                violating_content="$1",
                remediation="increase",
            )


# ---------------------------------------------------------------------------
# GraphRoutingError
# ---------------------------------------------------------------------------


class TestGraphRoutingError:
    def test_inherits_from_synth_error(self):
        assert issubclass(GraphRoutingError, SynthError)

    def test_fields(self):
        state = {"step": 3, "data": "abc"}
        err = GraphRoutingError(
            "No matching edge",
            component="GraphEngine",
            suggestion="Add a default edge",
            node_name="review_node",
            current_state=state,
        )
        assert err.node_name == "review_node"
        assert err.current_state is state
        assert str(err) == "No matching edge"


# ---------------------------------------------------------------------------
# GraphLoopError
# ---------------------------------------------------------------------------


class TestGraphLoopError:
    def test_inherits_from_synth_error(self):
        assert issubclass(GraphLoopError, SynthError)

    def test_fields(self):
        history = ["a", "b", "a", "b"]
        err = GraphLoopError(
            "Max iterations exceeded",
            component="GraphEngine",
            suggestion="Increase max_iterations or fix loop",
            node_history=history,
            max_iterations=4,
        )
        assert err.node_history == history
        assert err.max_iterations == 4
        assert str(err) == "Max iterations exceeded"


# ---------------------------------------------------------------------------
# RunNotFoundError
# ---------------------------------------------------------------------------


class TestRunNotFoundError:
    def test_inherits_from_synth_error(self):
        assert issubclass(RunNotFoundError, SynthError)

    def test_fields(self):
        err = RunNotFoundError(
            "No checkpoint for run abc123",
            component="CheckpointStore",
            suggestion="Verify the run_id",
            run_id="abc123",
        )
        assert err.run_id == "abc123"
        assert str(err) == "No checkpoint for run abc123"


# ---------------------------------------------------------------------------
# PipelineError
# ---------------------------------------------------------------------------


class TestPipelineError:
    def test_inherits_from_synth_error(self):
        assert issubclass(PipelineError, SynthError)

    def test_fields(self):
        partial = ["result_0", "result_1"]
        err = PipelineError(
            "Step 2 failed",
            component="Pipeline",
            suggestion="Check agent_c",
            failed_step=2,
            agent_name="agent_c",
            partial_results=partial,
        )
        assert err.failed_step == 2
        assert err.agent_name == "agent_c"
        assert err.partial_results == partial
        assert str(err) == "Step 2 failed"


# ---------------------------------------------------------------------------
# str() produces meaningful messages for all error types
# ---------------------------------------------------------------------------


class TestStrMessages:
    """Verify that str() on each error type produces a non-empty, meaningful message."""

    def test_synth_error_str(self):
        err = SynthError("base error", component="X", suggestion="Y")
        assert len(str(err)) > 0

    def test_config_error_str(self):
        err = SynthConfigError(
            "Model 'bad-model' unknown",
            component="ProviderRouter",
            suggestion="Use claude- or gpt- prefix",
        )
        assert "bad-model" in str(err)

    def test_tool_definition_error_str(self):
        err = ToolDefinitionError(
            "Missing docstring on 'my_tool'",
            component="ToolDecorator",
            suggestion="Add a docstring",
        )
        assert "my_tool" in str(err)

    def test_tool_execution_error_str(self):
        err = ToolExecutionError(
            "Tool 'search' raised ValueError",
            component="ToolExecutor",
            suggestion="Fix the tool",
            tool_name="search",
            tool_args={"q": "test"},
            original_error=ValueError("bad"),
        )
        assert "search" in str(err)

    def test_guard_violation_error_str(self):
        err = GuardViolationError(
            "PII found in output",
            component="PIIGuard",
            suggestion="Remove PII",
            guard_name="no_pii",
            violating_content="555-1234",
            remediation="Strip phone numbers",
        )
        assert "PII" in str(err)

    def test_cost_limit_error_str(self):
        err = CostLimitError(
            "Cost $0.15 exceeds limit $0.10",
            component="CostGuard",
            suggestion="Raise limit",
            guard_name="max_cost",
            violating_content="$0.15",
            remediation="Increase budget",
        )
        assert "$0.15" in str(err)

    def test_parse_error_str(self):
        err = SynthParseError(
            "Failed to parse output as MyModel",
            component="StructuredOutput",
            suggestion="Check schema",
        )
        assert "MyModel" in str(err)

    def test_graph_routing_error_str(self):
        err = GraphRoutingError(
            "No edge from 'review' matches state",
            component="GraphEngine",
            suggestion="Add default edge",
            node_name="review",
            current_state={},
        )
        assert "review" in str(err)

    def test_graph_loop_error_str(self):
        err = GraphLoopError(
            "Exceeded 100 iterations",
            component="GraphEngine",
            suggestion="Fix loop",
            node_history=["a"] * 100,
            max_iterations=100,
        )
        assert "100" in str(err)

    def test_run_not_found_error_str(self):
        err = RunNotFoundError(
            "Run 'xyz' not found",
            component="CheckpointStore",
            suggestion="Check ID",
            run_id="xyz",
        )
        assert "xyz" in str(err)

    def test_pipeline_error_str(self):
        err = PipelineError(
            "Pipeline failed at step 1 (summarizer)",
            component="Pipeline",
            suggestion="Check summarizer agent",
            failed_step=1,
            agent_name="summarizer",
            partial_results=[],
        )
        assert "summarizer" in str(err)
