"""AgentCore Browser tool.

Provides a framework-agnostic ``BrowserTools`` class that wraps the
Amazon Bedrock AgentCore Browser service.  The Browser tool gives agents
the ability to navigate websites, extract content, and interact with
web elements in a secure, managed Chrome environment — no third-party
API keys required.

This is a built-in AgentCore service that uses AWS credentials for
authentication, making it a zero-config alternative to API-based web
search providers.

Usage with Synth ``@tool`` decorator::

    from synth.deploy.agentcore.browser import BrowserTools

    browser = BrowserTools()

    @tool
    def browse_web(url: str, instruction: str) -> str:
        \"\"\"Navigate to a URL and follow the instruction.\"\"\"
        return browser.navigate(url, instruction)

    @tool
    def search_web(query: str) -> str:
        \"\"\"Search the web using AgentCore Browser.\"\"\"
        return browser.search(query)

    agent = Agent(model="bedrock/...", tools=[browse_web, search_web])
"""

from __future__ import annotations

import json
import logging
import os

from synth.errors import SynthConfigError

logger = logging.getLogger(__name__)


class BrowserTools:
    """Framework-agnostic wrapper for AgentCore Browser.

    Manages browser session lifecycle and provides ``navigate()``,
    ``search()``, and ``extract()`` methods for common web interaction
    patterns.  Sessions are created lazily on first use and cleaned up
    via ``cleanup()`` or automatically by AgentCore after timeout.

    Parameters
    ----------
    region:
        AWS region.  Defaults to ``AWS_DEFAULT_REGION`` env var or
        ``us-east-1``.
    session_timeout:
        Browser session timeout in seconds.  Defaults to ``900``
        (15 minutes).

    Examples
    --------
    ::

        browser = BrowserTools(region="us-west-2")
        result = browser.search("business class flights LHR to Tokyo")
        print(result)
    """

    def __init__(
        self,
        region: str | None = None,
        session_timeout: int = 900,
    ) -> None:
        self._region = region or os.environ.get(
            "AWS_DEFAULT_REGION", "us-east-1",
        )
        self._session_timeout = session_timeout
        self._client: object | None = None

    # ------------------------------------------------------------------
    # Session management
    # ------------------------------------------------------------------

    def _get_client(self) -> object:
        """Lazily initialise the Browser client and start a session."""
        if self._client is not None:
            return self._client

        try:
            from bedrock_agentcore.tools.browser_client import (
                BrowserClient,
            )
        except ImportError:
            raise SynthConfigError(
                message=(
                    "bedrock-agentcore is not installed. "
                    "Run: pip install synth-agent-sdk[agentcore]"
                ),
                component="BrowserTools",
                suggestion="pip install synth-agent-sdk[agentcore]",
            )

        client = BrowserClient(self._region)
        client.start(
            session_timeout_seconds=self._session_timeout,
        )
        self._client = client
        logger.info(
            "AgentCore Browser session started in region %s",
            self._region,
        )
        return self._client

    def cleanup(self) -> None:
        """Stop the browser session and release resources.

        AgentCore automatically cleans up inactive sessions after the
        configured timeout, so calling this is optional but recommended
        for immediate resource release.
        """
        if self._client is not None:
            try:
                self._client.stop()  # type: ignore[attr-defined]
            except Exception as exc:
                logger.warning(
                    "Error stopping Browser session: %s", exc,
                )
            finally:
                self._client = None
                logger.info("AgentCore Browser session stopped.")

    # ------------------------------------------------------------------
    # High-level operations
    # ------------------------------------------------------------------

    def navigate(self, url: str, instruction: str = "") -> str:
        """Navigate to a URL and extract its text content.

        Uses a lightweight ``httpx`` fetch by default.  Falls back to
        the managed AgentCore Browser (via Playwright) only when the
        simple fetch fails.

        Parameters
        ----------
        url:
            The URL to navigate to.
        instruction:
            Optional instruction (used only with Playwright path).

        Returns
        -------
        str
            Page title and extracted content, or error message.
        """
        # Fast path: httpx fetch + HTML strip
        try:
            return self._navigate_httpx(url)
        except Exception as exc:
            logger.debug("httpx navigate failed, trying browser: %s", exc)

        # Slow path: Playwright via AgentCore Browser
        try:
            return self._navigate_playwright(url)
        except ImportError:
            logger.debug("playwright not installed, skipping")
        except Exception as exc:
            logger.error("Browser navigation also failed: %s", exc)
            return json.dumps(
                {"error": f"Navigation failed: {exc}"},
            )

        return f"Could not fetch content from: {url}"

    @staticmethod
    def _navigate_httpx(url: str) -> str:
        """Fetch a page with httpx and strip HTML tags."""
        import re

        import httpx

        resp = httpx.get(
            url,
            headers={
                "User-Agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/120.0.0.0 Safari/537.36"
                ),
            },
            follow_redirects=True,
            timeout=15.0,
        )
        resp.raise_for_status()
        html = resp.text

        # Extract title
        title_match = re.search(
            r"<title[^>]*>(.*?)</title>", html, re.DOTALL,
        )
        title = (
            title_match.group(1).strip() if title_match else url
        )

        # Strip scripts, styles, then tags
        text = re.sub(
            r"<script[^>]*>.*?</script>", "", html, flags=re.DOTALL,
        )
        text = re.sub(
            r"<style[^>]*>.*?</style>", "", text, flags=re.DOTALL,
        )
        text = re.sub(r"<[^>]+>", " ", text)
        text = re.sub(r"\s+", " ", text).strip()

        max_chars = 8000
        if len(text) > max_chars:
            text = text[:max_chars] + "\n\n[truncated]"

        return f"Title: {title}\nURL: {url}\n\n{text}"

    def _navigate_playwright(self, url: str) -> str:
        """Fetch a page via AgentCore Browser + Playwright."""
        client = self._get_client()
        ws_url, headers = client.generate_ws_headers()  # type: ignore[attr-defined]

        from playwright.sync_api import sync_playwright

        with sync_playwright() as pw:
            browser = pw.chromium.connect_over_cdp(
                ws_url, headers=headers,
            )
            context = browser.contexts[0]
            page = context.pages[0]

            page.goto(url, wait_until="domcontentloaded")
            title = page.title()
            content = page.inner_text("body")

            max_chars = 8000
            if len(content) > max_chars:
                content = content[:max_chars] + "\n\n[truncated]"

            page.close()
            browser.close()

        return f"Title: {title}\nURL: {url}\n\n{content}"

    def search(self, query: str, limit: int = 5) -> str:
        """Search the web using DuckDuckGo.

        Uses a lightweight ``httpx`` request to DuckDuckGo's HTML
        endpoint by default.  Falls back to the managed AgentCore
        Browser (via Playwright) only when the simple fetch fails
        (e.g. rate-limited or blocked).  No third-party API key
        required in either path.

        Parameters
        ----------
        query:
            The search query string.
        limit:
            Maximum number of results to extract.  Defaults to ``5``.

        Returns
        -------
        str
            Formatted search results, or error message.
        """
        # Fast path: lightweight httpx fetch (no browser needed)
        try:
            results = self._search_httpx(query, limit)
            if results:
                return self._format_results(results)
        except Exception as exc:
            logger.debug("httpx search failed, trying browser: %s", exc)

        # Slow path: full AgentCore Browser via Playwright
        try:
            results = self._search_playwright(query, limit)
            if results:
                return self._format_results(results)
        except ImportError:
            logger.debug("playwright not installed, skipping browser path")
        except Exception as exc:
            logger.error("Browser search also failed: %s", exc)
            return json.dumps({"error": f"Browser search failed: {exc}"})

        return f"No results found for: {query}"


    def extract(self, url: str, selector: str = "body") -> str:
        """Extract text content from a specific element on a page.

        Parameters
        ----------
        url:
            The URL to navigate to.
        selector:
            CSS selector for the element to extract.  Defaults to
            ``"body"`` (full page text).

        Returns
        -------
        str
            Extracted text content, or error message.
        """
        client = self._get_client()
        try:
            ws_url, headers = client.generate_ws_headers()  # type: ignore[attr-defined]

            from playwright.sync_api import sync_playwright

            with sync_playwright() as pw:
                browser = pw.chromium.connect_over_cdp(
                    ws_url, headers=headers,
                )
                context = browser.contexts[0]
                page = context.pages[0]

                page.goto(url, wait_until="domcontentloaded")
                element = page.query_selector(selector)
                content = (
                    element.inner_text() if element
                    else f"No element found for selector: {selector}"
                )

                max_chars = 8000
                if len(content) > max_chars:
                    content = content[:max_chars] + "\n\n[truncated]"

                page.close()
                browser.close()

            return content

        except ImportError:
            return json.dumps({
                "error": (
                    "playwright is not installed. "
                    "Run: pip install playwright"
                ),
            })
        except Exception as exc:
            logger.error("Browser extraction failed: %s", exc)
            return json.dumps({
                "error": f"Extraction failed: {exc}",
            })

    # ------------------------------------------------------------------
    # Search internals
    # ------------------------------------------------------------------

    @staticmethod
    def _search_httpx(
        query: str, limit: int,
    ) -> list[dict[str, str]]:
        """Fetch DuckDuckGo results with httpx (no browser).

        Tries the HTML endpoint first, then falls back to the lite
        endpoint which is more tolerant of automated requests.
        """
        import re
        from html import unescape
        from urllib.parse import parse_qs, unquote, urlparse

        import httpx

        _UA = (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/120.0.0.0 Safari/537.36"
        )
        strip_tags = re.compile(r"<[^>]+>")

        def _resolve_ddg_url(raw: str) -> str | None:
            """Extract the real URL from a DuckDuckGo redirect."""
            href = unescape(raw)
            if "duckduckgo.com/y.js" in href:
                # Ad redirect — extract u3 param
                parsed = parse_qs(urlparse(href).query)
                u3 = parsed.get("u3") or parsed.get("uddg")
                return unescape(u3[0]) if u3 else None
            if "duckduckgo.com/l/" in href or "//duckduckgo.com" in href:
                # Organic redirect — extract uddg param
                full = href if href.startswith("http") else "https:" + href
                parsed = parse_qs(urlparse(full).query)
                uddg = parsed.get("uddg")
                return unquote(unescape(uddg[0])) if uddg else href
            return href

        # --- Try HTML endpoint first ---
        try:
            resp = httpx.post(
                "https://html.duckduckgo.com/html/",
                data={"q": query, "b": ""},
                headers={"User-Agent": _UA},
                follow_redirects=True,
                timeout=15.0,
            )
            if resp.status_code == 200 and "result__a" in resp.text:
                links = re.findall(
                    r'class="result__a"\s+href="([^"]*)"[^>]*>'
                    r"(.*?)</a>",
                    resp.text,
                    re.DOTALL,
                )
                snippets = re.findall(
                    r'class="result__snippet"[^>]*>(.*?)</(?:a|td)',
                    resp.text,
                    re.DOTALL,
                )
                results: list[dict[str, str]] = []
                for i, (raw_href, raw_title) in enumerate(links):
                    if len(results) >= limit:
                        break
                    url = _resolve_ddg_url(raw_href)
                    if not url:
                        continue
                    title = unescape(
                        strip_tags.sub("", raw_title).strip(),
                    )
                    snippet = (
                        unescape(
                            strip_tags.sub("", snippets[i]).strip(),
                        )
                        if i < len(snippets)
                        else ""
                    )
                    results.append({
                        "title": title,
                        "url": url,
                        "snippet": snippet,
                    })
                if results:
                    return results
        except Exception:
            pass

        # --- Fallback: lite endpoint ---
        resp = httpx.get(
            "https://lite.duckduckgo.com/lite/",
            params={"q": query},
            headers={"User-Agent": _UA},
            follow_redirects=True,
            timeout=15.0,
        )
        resp.raise_for_status()

        # Lite format: <a rel="nofollow" href="...">title</a>
        # followed by snippet text in a <td> or plain text
        links = re.findall(
            r'<a[^>]+rel="nofollow"[^>]+href="([^"]*)"[^>]*>'
            r"(.*?)</a>",
            resp.text,
            re.DOTALL,
        )
        # Extract snippet lines (text between </a> and next <tr>)
        snippet_blocks = re.findall(
            r'<td>\s*<span[^>]*>(.*?)</span>\s*</td>',
            resp.text,
            re.DOTALL,
        )

        results = []
        snippet_idx = 0
        for raw_href, raw_title in links:
            if len(results) >= limit:
                break
            title = unescape(strip_tags.sub("", raw_title).strip())
            if not title or title.startswith("More at"):
                continue
            url = _resolve_ddg_url(raw_href)
            if not url:
                continue
            snippet = (
                unescape(
                    strip_tags.sub("", snippet_blocks[snippet_idx]).strip(),
                )
                if snippet_idx < len(snippet_blocks)
                else ""
            )
            snippet_idx += 1
            results.append({
                "title": title,
                "url": url,
                "snippet": snippet,
            })

        return results

    def _search_playwright(
        self, query: str, limit: int,
    ) -> list[dict[str, str]]:
        """Search via AgentCore Browser + Playwright."""
        client = self._get_client()
        ws_url, headers = client.generate_ws_headers()  # type: ignore[attr-defined]

        from playwright.sync_api import sync_playwright

        with sync_playwright() as pw:
            browser = pw.chromium.connect_over_cdp(
                ws_url, headers=headers,
            )
            context = browser.contexts[0]
            page = context.pages[0]

            search_url = (
                f"https://html.duckduckgo.com/html/?q={query}"
            )
            page.goto(search_url, wait_until="domcontentloaded")

            results: list[dict[str, str]] = []
            links = page.query_selector_all(".result__a")
            snippets = page.query_selector_all(
                ".result__snippet",
            )

            for i in range(min(limit, len(links))):
                title = links[i].inner_text()
                href = links[i].get_attribute("href") or ""
                snippet = (
                    snippets[i].inner_text()
                    if i < len(snippets)
                    else ""
                )
                results.append({
                    "title": title,
                    "url": href,
                    "snippet": snippet,
                })

            page.close()
            browser.close()

        return results

    @staticmethod
    def _format_results(results: list[dict[str, str]]) -> str:
        """Format search results into a readable string."""
        lines: list[str] = []
        for i, r in enumerate(results, 1):
            lines.append(
                f"{i}. {r['title']}\n"
                f"   URL: {r['url']}\n"
                f"   {r['snippet']}"
            )
        return "\n\n".join(lines)
