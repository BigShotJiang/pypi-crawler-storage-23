"""UI template strings for ``synth create ui``.

Separated from create_cmd.py for maintainability. These are the
file contents generated when a user runs ``synth create ui <name>``.

Templates are stored as plain files in the ``_ui_assets/`` directory
alongside this module, loaded lazily on first access.
"""

from __future__ import annotations

from pathlib import Path

_ASSETS_DIR = Path(__file__).parent / "_ui_assets"

# Cache for loaded assets
_cache: dict[str, str] = {}

_ASSET_MAP = {
    "UI_SERVER": "server.py",
    "UI_HTML": "index.html",
    "UI_CSS": "style.css",
    "UI_JS": "app.js",
    "UI_README": "README.md",
}


def _load(name: str) -> str:
    """Load and cache a UI asset file."""
    if name not in _cache:
        filename = _ASSET_MAP[name]
        path = _ASSETS_DIR / filename
        _cache[name] = path.read_text(encoding="utf-8")
    return _cache[name]


def __getattr__(name: str) -> str:
    """Module-level lazy loading for UI template strings."""
    if name in _ASSET_MAP:
        return _load(name)
    raise AttributeError(
        f"module {__name__!r} has no attribute {name!r}",
    )
