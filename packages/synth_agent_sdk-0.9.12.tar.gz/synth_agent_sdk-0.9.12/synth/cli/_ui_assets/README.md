# {name}

A developer dashboard for testing your SynthAgentSDK agent locally.

## Setup

```bash
pip install uvicorn fastapi
```

## Usage

1. Edit `server.py` and set `AGENT_FILE` to point at your agent module.
2. Start the server:

```bash
python server.py
```

3. Open http://localhost:8420 in your browser.

## Features

- **Chat interface** — streaming SSE responses with thinking block support
- **Conversation history** — sidebar with multiple conversations, persistence to disk
- **Telemetry panel** — per-response and session-level token count, cost, latency, and cost-per-turn sparkline
- **Tool playground** — bottom drawer to test individual tools with custom arguments
- **Prompt library** — save, version, and manage prompt templates with variable injection
- **A/B testing** — run the same input against two prompt variants side-by-side with diff view
- **Eval runner** — create test cases, run them with keyword scoring or LLM judge, set golden baselines for regression
- **Session replay** — observe tab with timeline view, token heatmap, and anomaly detection
- **Scenario builder** — script multi-turn conversations and execute them
- **Hot-reload** — reload your agent from disk without restarting the server
- **Fallout terminal aesthetic** — CRT scanlines, green-on-dark theme matching the Synth boot sequence
