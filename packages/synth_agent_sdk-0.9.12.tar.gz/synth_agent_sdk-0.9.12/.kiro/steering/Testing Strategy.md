---
inclusion: fileMatch
fileMatchPattern: "tests/**/*"
---

# Testing Strategy

Rules for writing and organizing tests in the Synth SDK.

## Test Organization

- `tests/unit/` — deterministic unit tests for individual modules. One test file per
  source module: `test_tools.py` covers `synth/tools/`, `test_errors.py` covers
  `synth/errors.py`, etc.
- `tests/property/` — Hypothesis property-based tests that verify correctness properties
  from the design doc. These test invariants across randomized inputs.
- `tests/conftest.py` — shared fixtures, mock providers, and reusable Hypothesis strategies.
- `tests/test_scaffold.py` — structural tests that verify package layout, `pyproject.toml`
  config, and import health. Run these as a smoke test.

## Unit Test Conventions

- Use `pytest` as the runner. Configure via `[tool.pytest.ini_options]` in `pyproject.toml`.
- Use `@pytest.mark.asyncio` for all async test functions. The `asyncio_mode = "auto"`
  setting in pyproject.toml handles event loop management.
- Group related tests into classes (e.g., `TestToolExecutionError`, `TestConcreteProvider`).
- Use `@pytest.mark.parametrize` when testing the same assertion across multiple inputs,
  especially for error subclass behavior and provider prefix routing.
- Assert on specific error attributes, not just that an exception was raised. Check
  `err.component`, `err.suggestion`, `err.tool_name`, etc.
- Use `warnings.catch_warnings(record=True)` with `warnings.simplefilter("always")` to
  test `TypeMismatchWarning` and other SDK warnings.

## Property-Based Test Conventions

- Use Hypothesis (`from hypothesis import given, settings, assume`).
- Set `@settings(max_examples=100)` as the default for property tests.
- Each property test file MUST have a module docstring that states which design doc
  properties and requirements it validates, using the format:
  ```
  **Property N: <name>**
  **Validates: Requirements X.Y**
  ```
- Each test function docstring MUST reference the property number and requirement.
- Define reusable strategies at the top of each file or in `conftest.py`:
  - `_VALID_IDENTS` — valid Python identifiers filtered against keywords.
  - `_type_strategy` — `st.sampled_from(SUPPORTED_TYPES)` for tool parameter types.
  - `_docstring_strategy` — non-empty text for tool docstrings.
  - `_param_list_strategy` — lists of `(name, type)` tuples with unique names.
- Use `assume()` to filter out invalid combinations rather than complex strategy logic.
- Use `_make_function()` / `_make_tool_fn()` helpers to dynamically create decorated
  functions for property tests. These use `exec()` to build functions with controlled
  signatures — this is acceptable in test code only, never in production code.

## Mock Provider Pattern

- Define a `ConcreteProvider(BaseProvider)` in test files that returns canned responses.
  This is the pattern used in `test_providers.py`.
- For router tests, use `unittest.mock.patch("importlib.import_module", ...)` to mock
  the lazy import mechanism without needing real provider SDKs installed.
- Mock both the module and the class: `mock_module = MagicMock()`,
  `setattr(mock_module, class_name, mock_cls)`.
- For Agent-level tests that need a provider, create a `MockProvider` fixture in
  `conftest.py` that returns configurable `ProviderResponse` objects.

## Async Test Patterns

- Use `@pytest.mark.asyncio` and `async def test_...()` for testing async methods.
- For property tests that need to call async code, use `asyncio.run()` inside the
  test function (Hypothesis doesn't natively support async test functions).
- Never use `asyncio.run()` in production code — only in tests and `_compat.py`.

## Coverage

- Target 90%+ line coverage as configured in `pyproject.toml` (`fail_under = 90`).
- Run coverage with `pytest --cov=synth --cov-report=term-missing`.
- Stub modules (files with only `# Implementation in Task X` comments) don't count
  against coverage until implemented.

## What to Test

For each module, test:
1. Happy path — correct inputs produce correct outputs.
2. Error paths — invalid inputs raise the correct `SynthError` subclass with correct
   attributes (`component`, `suggestion`, and any subclass-specific fields).
3. Edge cases — empty inputs, `None` values, boundary conditions.
4. Type contracts — return types match annotations, `TypeMismatchWarning` is emitted
   when they don't.
5. Integration between components — e.g., `ToolKit` → `ToolExecutor`, router → provider.

## Test Naming

- Use descriptive names: `test_<what>_<condition>_<expected>` or plain English.
- Good: `test_optional_param_not_in_required`, `test_executor_wraps_exception_in_tool_execution_error`
- Avoid: `test_1`, `test_basic`, `test_it_works`
