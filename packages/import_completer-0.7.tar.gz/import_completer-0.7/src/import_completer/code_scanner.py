import re
from collections.abc import Generator, Iterator
from pathlib import Path
from typing import Literal

import tree_sitter_python as tspython
from tree_sitter import Language, Node, Parser

from import_completer.types import ScannedSymbol

PYTHON_TS_LANGUAGE = Language(tspython.language())
PYTHON_TS_PARSER = Parser()
PYTHON_TS_PARSER.language = PYTHON_TS_LANGUAGE

PYTHON_TOP_LEVEL_SYMBOLS_QUERY = PYTHON_TS_LANGUAGE.query(
    """
    [
      ; Direct module children
      (module
        (function_definition name: (identifier) @function-name))
      (module
        (class_definition name: (identifier) @class-name))
      (module
        (decorated_definition
          (function_definition name: (identifier) @function-name)))
      (module
        (decorated_definition
          (class_definition name: (identifier) @class-name)))
      (module
        (expression_statement
          (assignment left: (identifier) @assignment-name)))

      ; Inside top-level if statements
      (module
        (if_statement
          (block
            (function_definition name: (identifier) @function-name))))
      (module
        (if_statement
          (block
            (class_definition name: (identifier) @class-name))))
      (module
        (if_statement
          (block
            (decorated_definition
              (function_definition name: (identifier) @function-name)))))
      (module
        (if_statement
          (block
            (decorated_definition
              (class_definition name: (identifier) @class-name)))))
      (module
        (if_statement
          (block
            (expression_statement
              (assignment left: (identifier) @assignment-name)))))
      ; Else clause
      (module
        (if_statement
          (else_clause
            (block
              (function_definition name: (identifier) @function-name)))))
      (module
        (if_statement
          (else_clause
            (block
              (class_definition name: (identifier) @class-name)))))
      (module
        (if_statement
          (else_clause
            (block
              (decorated_definition
                (function_definition name: (identifier) @function-name))))))
      (module
        (if_statement
          (else_clause
            (block
              (decorated_definition
                (class_definition name: (identifier) @class-name))))))
      (module
        (if_statement
          (else_clause
            (block
              (expression_statement
                (assignment left: (identifier) @assignment-name))))))
    ]
    """
)

PYTHON_TOP_LEVEL_IMPORTS_QUERY = PYTHON_TS_LANGUAGE.query(
    """
    (module
      (import_from_statement
        module_name: (dotted_name) @module
        name: (dotted_name) @name
      ) @import)
    (module
      (import_statement
        name: (dotted_name) @module
      ) @import)
    """
)

RE_PYTHON_VALID_MODULE_FILE_NAME = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*\.pyi?$")
RE_PYTHON_VALID_MODULE_DIRECTORY_NAME = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*$")


def discover_python_modules(directory: str | Path) -> Generator[Path]:
    """
    Walk through directory and yield Python module files (.py and .pyi).
    Descends into subdirectories only if they are Python modules (contain __init__.py).

    Args:
        directory: Root directory to start scanning from

    Yields:
        Path objects for Python module files
    """

    directory = Path(directory)

    if not directory.is_dir():
        return

    for child_entity_path in directory.iterdir():
        if (
            child_entity_path.is_file()
            and RE_PYTHON_VALID_MODULE_FILE_NAME.match(child_entity_path.name)
            is not None
        ):
            yield child_entity_path
        elif (
            child_entity_path.is_dir()
            and RE_PYTHON_VALID_MODULE_DIRECTORY_NAME.match(child_entity_path.name)
            is not None
        ):
            # Recursively process subdirectories if they are Python packages
            if (child_entity_path / "__init__.py").exists() or (
                child_entity_path / "__init__.pyi"
            ).exists():
                yield from discover_python_modules(child_entity_path)
        else:
            pass
            # print(f"Skipping {child_entity_path}")


def convert_path_to_module_name(file_path: Path, origin_path: Path) -> str:
    module_relative_path = Path(file_path.relative_to(origin_path))
    if module_relative_path == Path("."):  # path represents origin root
        return ""

    module_parts = module_relative_path.with_suffix("").parts
    if module_parts[-1] == "__init__":
        module_parts = module_parts[:-1]
    return ".".join(module_parts)


def validate_module_path(file_path: Path, origin_path: Path) -> bool:
    """
    Checks if a given file path is a valid Python module.
    Checks:
        - if each module name along the contains valid characters,
        - if the module directory contains a __init__.py file.
    """

    # Check if file_path is relative to origin_path
    try:
        relative_path = file_path.relative_to(origin_path)
    except ValueError:
        return False

    # Validate the final file name
    if not RE_PYTHON_VALID_MODULE_FILE_NAME.match(file_path.name):
        return False

    # Check each directory part along the path
    parts = relative_path.parts[:-1]  # Exclude the file name itself
    for i, part in enumerate(parts):
        # Validate directory name
        if not RE_PYTHON_VALID_MODULE_DIRECTORY_NAME.match(part):
            return False

        # Check if directory contains __init__.py or __init__.pyi
        current_dir = origin_path.joinpath(*parts[: i + 1])
        if (
            not (current_dir / "__init__.py").exists()
            and not (current_dir / "__init__.pyi").exists()
        ):
            return False

    return True


def extract_symbols_from_origin(origin_path: Path) -> Iterator[ScannedSymbol]:
    for module_path in discover_python_modules(origin_path):
        yield from extract_symbols_from_file(module_path, origin_path)
        if module_symbol := module_to_symbol(module_path, origin_path):
            yield module_symbol


def module_to_symbol(file_path: Path, origin_path: Path) -> ScannedSymbol | None:
    name = file_path.name.removesuffix(".py").removesuffix(".pyi")
    parent_module_path = file_path.parent
    if name == "__main__":
        return None
    if name == "__init__":
        name = file_path.parent.name.removesuffix(".py").removesuffix(".pyi")
        parent_module_path = file_path.parent.parent
    return ScannedSymbol(
        kind="module",
        name=name,
        parent_module=convert_path_to_module_name(parent_module_path, origin_path),
        metadata={},
    )


def extract_symbols_from_file(
    file_path: Path, origin_path: Path
) -> Iterator[ScannedSymbol]:
    """
    Extract all top-level symbols from a given Python file.
    """

    with open(file_path, "rb") as fh:
        source_code = fh.read()

    yield from extract_symbols(
        source_code, annotated_file_path=file_path, origin_path=origin_path
    )


def extract_symbols(
    source_code: bytes, annotated_file_path: Path, origin_path: Path
) -> Iterator[ScannedSymbol]:
    """
    Extract all top-level symbols from a given Python source code.
    """

    parent_module = convert_path_to_module_name(annotated_file_path, origin_path)

    def _make_scanned_symbol(
        kind: Literal["function", "class", "variable"], node: Node
    ) -> ScannedSymbol:
        assert node.text is not None
        return ScannedSymbol(
            kind=kind,
            name=node.text.decode("utf-8"),
            parent_module=parent_module,
            metadata={},
        )

    tree = PYTHON_TS_PARSER.parse(source_code)
    root_node = tree.root_node

    captures = PYTHON_TOP_LEVEL_SYMBOLS_QUERY.captures(root_node)
    for node in captures.get("function-name", []):
        if node.text:
            yield _make_scanned_symbol("function", node)

    for node in captures.get("class-name", []):
        if node.text:
            yield _make_scanned_symbol("class", node)

    for node in captures.get("assignment-name", []):
        if node.text:
            yield _make_scanned_symbol("variable", node)


def parse_import_statements(source_code: bytes) -> tuple[dict[str, set[str]], int]:
    """
    Parses the source code to find a suitable insertion point for an import statement.
    Returns line number (0-based). Insertion point should be add by creating this line
    (so after insertion, the import statement is located at that line).
    """

    tree = PYTHON_TS_PARSER.parse(source_code)
    root_node = tree.root_node

    imports_map: dict[str, set[str]] = {}

    last_import: Node | None = None
    for _, captures in PYTHON_TOP_LEVEL_IMPORTS_QUERY.matches(root_node):
        import_nodes = captures.get("import", [])
        assert len(import_nodes) == 1
        last_import = import_nodes[0]

        module_nodes = captures.get("module", [])
        assert len(module_nodes) == 1
        module_name = module_nodes[0].text.decode("utf-8")
        if module_name not in imports_map:
            imports_map[module_name] = set()

        name_nodes = captures.get("name", [])
        if name_nodes:
            name = name_nodes[0].text.decode("utf-8")
            imports_map[module_name].add(name)

    return imports_map, (last_import.end_point[0] + 1) if last_import else 0


if __name__ == "__main__":
    import sys

    with open(sys.argv[1], "rb") as fh:
        source_code = fh.read()

    for symbol in extract_symbols(
        source_code,
        annotated_file_path=Path(sys.argv[1]).absolute(),
        origin_path=Path(sys.argv[1]).absolute().parent,
    ):
        print(f"  + {symbol.kind}: {symbol.name}")

    imports_map, insertion_line = parse_import_statements(source_code)
    print("Imports:")
    for module, names in imports_map.items():
        print(f" + {module}: {names}")
    print(f"Import insertion line: {insertion_line + 1} (1-based)")
