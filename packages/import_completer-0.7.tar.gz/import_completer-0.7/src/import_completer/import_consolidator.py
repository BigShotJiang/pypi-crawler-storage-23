from dataclasses import dataclass

from loguru import logger
from lsprotocol.types import Position, Range, TextEdit

from import_completer.code_scanner import (
    PYTHON_IMPORT_STATEMENTS_QUERY,
    PYTHON_TS_PARSER,
)


@dataclass
class ParsedImport:
    """Represents a parsed from-import statement."""

    module_name: str  # e.g., "collections.abc"
    imported_names: list[str]  # e.g., ["Iterator", "Callable"]
    has_parentheses: bool  # Formatting metadata
    is_wildcard: bool  # True if "import *"
    start_line: int  # Location in document (0-indexed)
    end_line: int  # Inclusive end line
    start_byte: int  # Start byte offset
    end_byte: int  # End byte offset


class ImportConsolidator:
    """Handles import statement parsing and consolidation."""

    def __init__(self, document_source: str):
        """Parse document and extract import statements."""
        self.source = document_source
        self.lines = document_source.splitlines(keepends=True)
        self.parsed_imports = self._parse_imports()

    def _parse_imports(self) -> list[ParsedImport]:
        """Use tree-sitter to extract all from-imports."""
        imports: list[ParsedImport] = []

        try:
            # Parse the document with tree-sitter
            tree = PYTHON_TS_PARSER.parse(bytes(self.source, "utf8"))
            root_node = tree.root_node

            # Execute query to find all import_from_statement nodes
            captures = PYTHON_IMPORT_STATEMENTS_QUERY.captures(root_node)

            # Process each import_from_statement by grouping captures
            # captures is a dict: {"module": [nodes], "imported": [nodes], "wildcard": [nodes]}

            # Get all unique import statements by finding all module nodes
            module_nodes = captures.get("module", [])
            imported_nodes = captures.get("imported", [])
            wildcard_nodes = captures.get("wildcard", [])

            for module_node in module_nodes:
                # Get the import_from_statement node (parent of module)
                statement_node = module_node.parent
                module_name = module_node.text.decode("utf8")

                # Find all imported names that belong to this statement
                imported_names = []
                is_wildcard = False

                # Check if this statement has wildcard
                for wildcard_node in wildcard_nodes:
                    if wildcard_node.parent == statement_node:
                        is_wildcard = True
                        break

                # Collect imported names for this statement
                if not is_wildcard:
                    for imported_node in imported_nodes:
                        if imported_node.parent == statement_node or (
                            imported_node.parent.parent == statement_node
                        ):
                            imported_names.append(imported_node.text.decode("utf8"))

                self._add_parsed_import(
                    imports, statement_node, module_name, imported_names, is_wildcard
                )

        except Exception as e:
            logger.warning("Failed to parse imports: {}", e)

        return imports

    def _add_parsed_import(
        self, imports: list[ParsedImport], statement_node, module_name, imported_names, is_wildcard
    ):
        """Helper to add a parsed import to the list."""
        # Determine if import has parentheses
        import_text = statement_node.text.decode("utf8")
        has_parentheses = "(" in import_text

        # Get location information
        start_line = statement_node.start_point[0]
        end_line = statement_node.end_point[0]
        start_byte = statement_node.start_byte
        end_byte = statement_node.end_byte

        imports.append(
            ParsedImport(
                module_name=module_name,
                imported_names=imported_names,
                has_parentheses=has_parentheses,
                is_wildcard=is_wildcard,
                start_line=start_line,
                end_line=end_line,
                start_byte=start_byte,
                end_byte=end_byte,
            )
        )

    def _find_matching_import(self, module_name: str) -> ParsedImport | None:
        """Find existing import from module_name."""
        for imp in self.parsed_imports:
            if imp.module_name == module_name and not imp.is_wildcard:
                return imp
        return None

    def _format_import_statement(
        self, module_name: str, imported_names: list[str], use_parentheses: bool = None
    ) -> str:
        """Format import statement with proper style."""
        # Sort names alphabetically (PEP 8)
        sorted_names = sorted(imported_names)

        # Construct single-line version
        single_line = f"from {module_name} import {', '.join(sorted_names)}"

        # Decide whether to use parentheses
        if use_parentheses is None:
            # Auto-decide based on line length (88 chars is Black default)
            use_parentheses = len(single_line) > 88

        if not use_parentheses:
            return single_line + "\n"

        # Multiline format with parentheses (Black style)
        lines = [f"from {module_name} import ("]
        for name in sorted_names:
            lines.append(f"    {name},")
        lines.append(")")

        return "\n".join(lines) + "\n"

    def _generate_merge_edit(
        self, existing_import: ParsedImport, new_symbol: str
    ) -> TextEdit:
        """Generate edit to merge new_symbol into existing import."""
        # Combine existing names with new symbol
        all_names = existing_import.imported_names + [new_symbol]

        # Format the new import statement
        new_import_text = self._format_import_statement(
            existing_import.module_name,
            all_names,
            use_parentheses=existing_import.has_parentheses,
        )

        # Create TextEdit to replace entire existing import
        return TextEdit(
            new_text=new_import_text,
            range=Range(
                start=Position(line=existing_import.start_line, character=0),
                end=Position(line=existing_import.end_line + 1, character=0),
            ),
        )

    def _generate_new_import_edit(
        self, module_name: str, symbol_name: str
    ) -> TextEdit:
        """Generate edit to insert new import statement."""
        # Find smart insertion point
        insertion_line = self._find_insertion_point(module_name)

        # Format the import statement
        new_import_text = self._format_import_statement(module_name, [symbol_name])

        # Create TextEdit to insert at the determined line
        return TextEdit(
            new_text=new_import_text,
            range=Range(
                start=Position(line=insertion_line, character=0),
                end=Position(line=insertion_line, character=0),
            ),
        )

    def _find_insertion_point(self, module_name: str) -> int:
        """Find the best line to insert a new import statement."""
        if not self.parsed_imports:
            # No existing imports, insert at line 0
            return 0

        # Try to place after imports from same top-level package
        target_package = module_name.split(".")[0]
        same_package_imports = [
            imp
            for imp in self.parsed_imports
            if imp.module_name.split(".")[0] == target_package
        ]

        if same_package_imports:
            # Place after last import from same package
            return max(imp.end_line for imp in same_package_imports) + 1

        # Otherwise, place after all imports
        return max(imp.end_line for imp in self.parsed_imports) + 1

    def generate_import_edit(self, module_name: str, symbol_name: str) -> TextEdit:
        """
        Generate TextEdit for adding symbol import.
        Either merges with existing import or creates new one.
        """
        # Check if symbol is already imported
        matching_import = self._find_matching_import(module_name)
        if matching_import and symbol_name in matching_import.imported_names:
            logger.debug(
                "Symbol {} already imported from {}, skipping",
                symbol_name,
                module_name,
            )
            # Return empty edit (no change needed)
            return TextEdit(
                new_text="",
                range=Range(
                    start=Position(line=0, character=0), end=Position(line=0, character=0)
                ),
            )

        if matching_import:
            return self._generate_merge_edit(matching_import, symbol_name)
        else:
            return self._generate_new_import_edit(module_name, symbol_name)
