from import_completer.types import ScannedSymbol


def generate_import_for_symbol(symbol: ScannedSymbol) -> str:
    if symbol.parent_module:
        return f"from {symbol.parent_module} import {symbol.name}"
    else:
        return f"import {symbol.name}"
