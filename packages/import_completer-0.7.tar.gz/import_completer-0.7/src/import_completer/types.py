from typing import Literal, NamedTuple


class ScannedSymbol(NamedTuple):
    kind: Literal["variable", "function", "class", "module"]
    name: str
    parent_module: str
    metadata: dict
