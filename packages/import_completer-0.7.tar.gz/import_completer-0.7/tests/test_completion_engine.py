from collections.abc import Callable, Iterable
from typing import TypeVar

import pytest

T = TypeVar("T")


def find_with_predicate(
    predicate: Callable[[T], bool], iterable: Iterable[T]
) -> tuple[T | None, int]:
    for i, item in enumerate(iterable):
        if predicate(item):
            return item, i
    return None, -1


def assert_match_with_predicate(
    predicate: Callable[[T], tuple[bool, ...]], iterable: Iterable[T]
) -> None:
    items = [(sum(predicate(obj)) / len(predicate(obj)), obj) for obj in iterable]
    items.sort(key=lambda item: item[0], reverse=True)
    if items[0][0] < 1.0:
        closest_matches = [item[1] for item in items[:5]]
        raise AssertionError(
            f"Failed to satisfy predicate, closest matches: {closest_matches}"
        )


@pytest.mark.parametrize(
    "lookup,expected_symbol_name",
    [
        ("", "AsyncGenerator"),
        ("Async", "AsyncGenerator"),
        ("AsyncGenerator", "AsyncGenerator"),
    ],
)
async def test_basic_lookup_typing(
    completion_engine, stdlib_symbols_typing, lookup, expected_symbol_name
):
    completions = [c async for c in completion_engine.lookup_symbol_prefix(lookup)]
    assert len(completions) > 0

    target_symbol, _ = find_with_predicate(
        lambda symbol: symbol.name == expected_symbol_name, completions
    )
    assert target_symbol is not None
    assert target_symbol.parent_module == "typing"


@pytest.mark.parametrize(
    "lookup,expected_symbol_name",
    [
        ("", "dataclass"),
        ("", "field"),
        ("dataclass", "dataclass"),
        ("@dataclass", "dataclass"),
    ],
)
async def test_basic_lookup_dataclasses(
    completion_engine, stdlib_symbols_dataclasses, lookup, expected_symbol_name
):
    completions = [c async for c in completion_engine.lookup_symbol_prefix(lookup)]
    assert len(completions) > 0

    target_symbol, _ = find_with_predicate(
        lambda symbol: symbol.name == expected_symbol_name, completions
    )
    assert target_symbol is not None
    assert target_symbol.parent_module == "dataclasses"


@pytest.mark.parametrize(
    "lookup,expected_symbol_name",
    [
        ("", "dataclass"),
    ],
)
async def test_basic_lookup_attr(
    completion_engine, virtualenv_symbols_attr, lookup, expected_symbol_name
):
    completions = [c async for c in completion_engine.lookup_symbol_prefix(lookup)]
    assert len(completions) > 0

    target_symbol, _ = find_with_predicate(
        lambda symbol: symbol.name == expected_symbol_name, completions
    )
    assert target_symbol is not None
    assert target_symbol.parent_module == "attr"


@pytest.mark.parametrize(
    "lookup,expected_module_name,expected_parent_module",
    [
        ("dataclasses", "dataclasses", ""),
        ("data", "dataclasses", ""),
        ("futures", "futures", "concurrent"),
        ("parse", "parse", "urllib"),
        ("abc", "abc", "importlib.resources"),
    ],
)
async def test_module_lookup_stdlib(
    completion_engine,
    stdlib_symbols_all,
    lookup,
    expected_module_name,
    expected_parent_module,
):
    completions = [c async for c in completion_engine.lookup_symbol_prefix(lookup)]
    assert len(completions) > 0

    assert_match_with_predicate(
        lambda symbol: (
            symbol.name == expected_module_name,
            symbol.kind == "module",
            symbol.parent_module == expected_parent_module,
        ),
        completions,
    )
