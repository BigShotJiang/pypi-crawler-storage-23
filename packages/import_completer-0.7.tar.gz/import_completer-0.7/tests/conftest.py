from collections.abc import AsyncGenerator
from pathlib import Path

import pytest

from import_completer.completion_engine import CompletionEngine
from import_completer.symbols_database import DatabaseHandler


@pytest.fixture()
async def symbols_database() -> AsyncGenerator[DatabaseHandler]:
    symbols_database = DatabaseHandler()
    async with symbols_database:
        await symbols_database.create_schema()
        await symbols_database.create_indices()
        yield symbols_database


@pytest.fixture()
def stdlib_origin() -> Path:
    import abc

    return Path(abc.__file__).parent


@pytest.fixture()
def virtualenv_origin() -> Path:
    return Path(pytest.__file__).parent.parent


@pytest.fixture()
def completion_engine(
    symbols_database: DatabaseHandler, stdlib_origin: Path, virtualenv_origin: Path
) -> CompletionEngine:
    completion_engine = CompletionEngine(
        symbols_database=symbols_database,
        origin_paths=[stdlib_origin, virtualenv_origin],
    )
    return completion_engine


@pytest.fixture()
async def stdlib_symbols_typing(
    completion_engine: CompletionEngine, stdlib_origin: Path
) -> Path:
    typing_module_path = stdlib_origin / "typing.py"
    await completion_engine.reload_symbols_for_file(typing_module_path)
    return typing_module_path


@pytest.fixture()
async def stdlib_symbols_dataclasses(
    completion_engine: CompletionEngine, stdlib_origin: Path
) -> Path:
    dataclasses_module_path = stdlib_origin / "dataclasses.py"
    await completion_engine.reload_symbols_for_file(dataclasses_module_path)
    return dataclasses_module_path


@pytest.fixture()
async def virtualenv_symbols_attr(
    completion_engine: CompletionEngine, virtualenv_origin: Path
) -> Path:
    module_path = virtualenv_origin / "attr" / "__init__.py"
    await completion_engine.reload_symbols_for_file(module_path)
    return module_path


@pytest.fixture()
async def stdlib_symbols_all(
    completion_engine: CompletionEngine, stdlib_origin: Path
) -> Path:
    await completion_engine.reload_symbols_for_origin(
        completion_engine.lookup_origin_index_by_path(stdlib_origin)
    )
    return stdlib_origin
