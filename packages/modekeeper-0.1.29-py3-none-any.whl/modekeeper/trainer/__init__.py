"""Minimal trainer process for k8s demos."""

from .knobs import parse_downward_annotations

__all__ = ["parse_downward_annotations"]
