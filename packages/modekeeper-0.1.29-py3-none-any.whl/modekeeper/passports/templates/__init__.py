"""Built-in passport.v0 templates."""
