"""
Entry point for running snapagent as a module: python -m snapagent
"""

from snapagent.cli.commands import app

if __name__ == "__main__":
    app()
