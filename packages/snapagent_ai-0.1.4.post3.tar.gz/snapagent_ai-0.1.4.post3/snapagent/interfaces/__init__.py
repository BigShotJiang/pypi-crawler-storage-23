"""Public interface helpers (migration and compatibility)."""

from snapagent.interfaces.config_migration import migrate_config_dict_v1_to_v2

__all__ = ["migrate_config_dict_v1_to_v2"]
