"""CLI module for snapagent."""
