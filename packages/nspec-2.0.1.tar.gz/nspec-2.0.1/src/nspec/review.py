"""Automated code review via Codex CLI.

This module provides:
- generate_review_prompt: Assembles a structured review prompt from spec data and git diff
- prepare_mcp_review: Prepares prompt for codex CLI invocation
- parse_review_verdict: Extracts verdict from Codex output (text parsing)
- write_review_to_impl: Writes verdict and feedback to the IMPL file

Review path: The caller generates a prompt with prepare_mcp_review(),
invokes ``execute_codex(prompt=...)`` to spawn the codex CLI subprocess,
parses the verdict from the response, and writes it via
write_review_to_impl().

Verdict parsing supports two formats:
1. P-level findings (P0/P1 → NEEDS_WORK, P2/P3 only → APPROVED)
2. Explicit VERDICT: line (legacy fallback)
"""

import contextlib
import json
import logging
import re
import subprocess
import uuid
from dataclasses import dataclass
from pathlib import Path

from nspec.crud import (
    _find_impl_file,
    _get_impl_field,
    approve_review,
    request_changes,
    request_review,
    start_review,
)
from nspec.paths import NspecPaths, get_paths

logger = logging.getLogger("nspec")


@dataclass
class ReviewPrompt:
    """Structured review prompt data."""

    spec_id: str
    title: str
    acceptance_criteria: str
    task_list: str
    git_diff: str
    prompt_text: str


@dataclass
class ReviewVerdict:
    """Parsed review verdict from Codex output."""

    verdict: str  # "APPROVED" or "NEEDS_WORK"
    feedback: str  # Feedback text (empty for APPROVED with no comments)
    raw_output: str  # Full Codex output


def generate_review_prompt(
    spec_id: str,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
    *,
    uncommitted: bool = False,
    commit_sha: str | None = None,
    base_branch: str | None = None,
) -> ReviewPrompt:
    """Generate a structured review prompt from spec data and git diff.

    Reads the FR acceptance criteria, IMPL task list, and generates
    a git diff for the spec's changes.

    Args:
        spec_id: Spec ID (e.g., "S020")
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root for config lookup

    Returns:
        ReviewPrompt with all assembled data

    Raises:
        FileNotFoundError: If FR or IMPL not found
    """
    paths = get_paths(docs_root, config=paths_config, project_root=project_root)

    # Find FR file
    fr_dir = paths.active_frs_dir
    fr_pattern = f"FR-{spec_id}-*.md"
    fr_files = list(fr_dir.glob(fr_pattern))
    if not fr_files:
        # Check completed
        completed_dir = paths.completed_frs_dir
        fr_files = list(completed_dir.glob(fr_pattern))
    if not fr_files:
        raise FileNotFoundError(f"FR-{spec_id}-*.md not found")

    fr_content = fr_files[0].read_text()

    # Find IMPL file
    impl_path = _find_impl_file(spec_id, docs_root, paths_config, project_root)
    impl_content = impl_path.read_text()

    # Extract title from FR
    title = _extract_title(fr_content)

    # Extract acceptance criteria section
    ac_text = _extract_section(fr_content, "Acceptance Criteria")
    if not ac_text:
        ac_text = _extract_section(fr_content, "Success Criteria")
    if not ac_text:
        ac_text = "(No acceptance criteria found)"

    # Extract task list section
    task_text = _extract_section(impl_content, "Tasks")
    if not task_text:
        task_text = "(No task list found)"

    # Get git diff using the requested mode
    git_diff = _get_git_diff(
        uncommitted=uncommitted,
        commit_sha=commit_sha,
        base_branch=base_branch,
    )

    # Assemble the prompt
    prompt_text = _assemble_prompt(spec_id, title, ac_text, task_text, git_diff, project_root)

    return ReviewPrompt(
        spec_id=spec_id,
        title=title,
        acceptance_criteria=ac_text,
        task_list=task_text,
        git_diff=git_diff,
        prompt_text=prompt_text,
    )


def parse_review_verdict(codex_output: str) -> ReviewVerdict | None:
    """Parse Codex MCP output to extract the review verdict.

    Supports two output formats:

    1. **Explicit VERDICT line** (legacy): ``VERDICT: APPROVED`` or
       ``VERDICT: NEEDS_WORK``. Legacy fallback format.
    2. **P-level findings** (codex-cli): Findings tagged ``[P0]``–``[P3]``.
       P0/P1 findings → NEEDS_WORK; only P2/P3 (or no findings) → APPROVED.

    The explicit VERDICT line takes precedence when present.

    When the output contains ANSI-styled ``codex`` markers (from Codex CLI
    terminal output), only the text after the last marker is searched to
    avoid matching VERDICT strings from prompt instructions.

    Args:
        codex_output: Text output from Codex (via codex-cli MCP)

    Returns:
        ReviewVerdict if a verdict was found, None if no verdict detected
    """
    # Codex output may contain ANSI-styled "codex" markers from the CLI.
    # Only search after the last marker to avoid matching prompt text.
    codex_marker = re.compile(r"(?:\x1b\[[\d;]*m)*codex(?:\x1b\[[\d;]*m)*\s*$", re.MULTILINE)
    search_text = codex_output

    markers = list(codex_marker.finditer(codex_output))
    if markers:
        search_text = codex_output[markers[-1].end() :]

    # Strategy 1: Look for explicit VERDICT: line (case-insensitive)
    pattern = r"VERDICT:\s*(APPROVED|NEEDS_WORK)"
    match = re.search(pattern, search_text, re.IGNORECASE)

    if match:
        verdict = match.group(1).upper()
        feedback = search_text[match.end() :].strip()
        feedback = _clean_terminal_output(feedback)
        return ReviewVerdict(verdict=verdict, feedback=feedback, raw_output=codex_output)

    # Strategy 2: Parse P-level findings from codex-cli output
    p_level_result = _parse_p_level_findings(search_text)
    if p_level_result is not None:
        return ReviewVerdict(
            verdict=p_level_result[0],
            feedback=p_level_result[1],
            raw_output=codex_output,
        )

    return None


def _parse_p_level_findings(text: str) -> tuple[str, str] | None:
    """Extract verdict from codex-cli P-level findings.

    Looks for ``[P0]``, ``[P1]``, ``[P2]``, ``[P3]`` tagged findings.
    If any P0 or P1 findings exist, returns NEEDS_WORK.
    If only P2/P3 findings exist (or no findings with other review
    indicators), returns APPROVED.

    Returns:
        (verdict, feedback) tuple, or None if no P-level findings detected.
    """
    # Match [P0], [P1], [P2], [P3] at the start of lines or inline
    p_pattern = re.compile(r"\[P([0-3])\]\s*(.*?)(?:\n|$)", re.MULTILINE)
    findings = p_pattern.findall(text)

    if not findings:
        return None

    # Separate by severity
    blocking = []  # P0, P1
    advisory = []  # P2, P3

    for level, description in findings:
        level_int = int(level)
        desc = description.strip()
        if level_int <= 1:
            blocking.append(f"[P{level}] {desc}")
        else:
            advisory.append(f"[P{level}] {desc}")

    if blocking:
        all_findings = blocking + advisory
        feedback = _clean_terminal_output("\n".join(all_findings))
        return ("NEEDS_WORK", feedback)

    # Only P2/P3 findings — approved
    feedback = _clean_terminal_output("\n".join(advisory)) if advisory else ""
    return ("APPROVED", feedback)


def write_review_to_impl(
    spec_id: str,
    verdict: ReviewVerdict,
    reviewer: str,
    implementer: str,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> Path:
    """Write review verdict and feedback to the IMPL file.

    Persists all review fields: Implementer, Reviewer, Verdict, Reviewed
    date, and full feedback text in the Findings section.

    Uses the existing crud.py review workflow functions:
    - request_review (sets implementer, moves to Testing)
    - start_review (sets reviewer)
    - approve_review or request_changes (sets verdict + findings)

    Args:
        spec_id: Spec ID
        verdict: Parsed review verdict from Codex
        reviewer: Reviewer name (e.g., "codex")
        implementer: Implementer name (e.g., "claude")
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root for config lookup

    Returns:
        Path to updated IMPL file
    """
    from nspec.atomic import batch_writes, spec_read
    from nspec.crud import _validate_after_write

    impl_path = _find_impl_file(spec_id, docs_root, paths_config, project_root)

    # Batch all writes so the IMPL file is updated atomically — the TUI
    # polls for file changes and would otherwise see intermediate states.
    with batch_writes():
        content = spec_read(impl_path)

        # Check if implementer is already set (spec may already be in review)
        existing_implementer = _get_impl_field(content, "Implementer")
        existing_reviewer = _get_impl_field(content, "Reviewer")

        if not existing_implementer:
            # Need to set up review first — may already be in Testing or beyond
            with contextlib.suppress(ValueError):
                request_review(spec_id, implementer, docs_root, paths_config, project_root)

        if not existing_reviewer:
            start_review(spec_id, reviewer, docs_root, paths_config, project_root)

        # Apply verdict
        if verdict.verdict == "APPROVED":
            notes = verdict.feedback if verdict.feedback else None
            result = approve_review(spec_id, notes, docs_root, paths_config, project_root)
        else:
            notes = (
                verdict.feedback if verdict.feedback else "Changes requested by automated review"
            )
            result = request_changes(spec_id, notes, docs_root, paths_config, project_root)

    # Validate after the batch flush — files are now on disk
    _validate_after_write(spec_id, docs_root, paths_config)
    return result


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _extract_title(content: str) -> str:
    """Extract title from first heading line."""
    for line in content.split("\n"):
        if line.startswith("# "):
            return line[2:].strip()
    return "(untitled)"


def _extract_section(content: str, section_name: str) -> str:
    """Extract a markdown section by heading name.

    Returns everything from the heading to the next heading of same or higher level.
    """
    lines = content.split("\n")
    in_section = False
    section_lines: list[str] = []
    section_level = 0

    for line in lines:
        if line.startswith("#"):
            level = len(line) - len(line.lstrip("#"))
            heading_text = line.lstrip("#").strip()

            if heading_text.lower() == section_name.lower():
                in_section = True
                section_level = level
                continue
            elif in_section and level <= section_level:
                break

        if in_section:
            section_lines.append(line)

    return "\n".join(section_lines).strip()


def _get_git_diff(
    *,
    uncommitted: bool = False,
    commit_sha: str | None = None,
    base_branch: str | None = None,
) -> str:
    """Get git diff for current changes.

    Args:
        uncommitted: Show staged + unstaged changes against HEAD (tracked files only).
            Note: Untracked files are not included in git diff output.
        commit_sha: Show changes from a specific commit
        base_branch: Show changes against a base branch

    Falls back to trying main...HEAD, HEAD, then unstaged.
    """
    # Build command list based on mode
    if commit_sha:
        cmds = [["git", "diff", f"{commit_sha}~1..{commit_sha}"]]
    elif base_branch:
        cmds = [["git", "diff", f"{base_branch}...HEAD"]]
    elif uncommitted:
        cmds = [["git", "diff", "HEAD"], ["git", "diff"]]
    else:
        cmds = [
            ["git", "diff", "main...HEAD"],
            ["git", "diff", "HEAD"],
            ["git", "diff"],
        ]

    for cmd in cmds:
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=30,
            )
            if result.returncode == 0 and result.stdout.strip():
                diff = result.stdout
                # Truncate very large diffs
                max_chars = 50000
                if len(diff) > max_chars:
                    diff = diff[:max_chars] + "\n\n... (diff truncated at 50k chars)"
                return diff
        except (subprocess.TimeoutExpired, FileNotFoundError):
            continue

    return "(no git diff available)"


def _assemble_prompt(
    spec_id: str,
    title: str,
    ac_text: str,
    task_text: str,
    git_diff: str,
    project_root: Path | None = None,
) -> str:
    """Assemble the structured review prompt for Codex.

    Loads the prompt template from the ``review-prompt`` resource handle,
    then substitutes variables via ``str.format_map()``.
    """
    from nspec.resources.registry import load_resource

    template = load_resource("review-prompt", project_root)
    return template.format_map(
        {
            "spec_id": spec_id,
            "title": title,
            "ac_text": ac_text,
            "task_text": task_text,
            "git_diff": git_diff,
        }
    )


def extract_verdict_from_impl(content: str) -> str | None:
    """Extract review verdict from IMPL file content.

    Looks for the **Verdict:** line in the Review section.

    Args:
        content: IMPL file content

    Returns:
        Verdict string (APPROVED, NEEDS_WORK, PENDING, TBD) or None if not found
    """
    # Look for **Verdict:** at start of line (avoid matching inside task descriptions)
    pattern = r"^\*\*Verdict:\*\*\s*(\S+)"
    match = re.search(pattern, content, re.MULTILINE)
    if match:
        verdict = match.group(1).strip()
        # Normalize common values
        verdict_upper = verdict.upper()
        if verdict_upper in ("APPROVED", "NEEDS_WORK", "PENDING", "TBD"):
            return verdict_upper
        # Handle dash/em-dash as "not set"
        if verdict in ("—", "-", "–"):
            return None
        return verdict
    return None


def _clean_terminal_output(text: str) -> str:
    """Remove terminal control sequences and artifacts from output."""
    # Remove ANSI escape codes
    ansi_escape = re.compile(r"\x1b\[[0-9;]*[a-zA-Z]")
    text = ansi_escape.sub("", text)

    # Remove common terminal artifacts
    text = text.replace("\r\n", "\n")
    text = text.replace("\r", "")

    # Remove leading/trailing whitespace and empty lines
    lines = [line.rstrip() for line in text.split("\n")]
    # Remove empty lines at start and end
    while lines and not lines[0]:
        lines.pop(0)
    while lines and not lines[-1]:
        lines.pop()

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Codex MCP Integration
# ---------------------------------------------------------------------------


@dataclass
class MCPReviewRequest:
    """Review request prepared for Codex CLI invocation.

    This dataclass contains everything needed to invoke a Codex review
    via ``execute_codex()``.
    """

    spec_id: str
    prompt: str  # The full review prompt for codex-cli


def prepare_mcp_review(
    spec_id: str,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
    *,
    uncommitted: bool = False,
    commit_sha: str | None = None,
    base_branch: str | None = None,
) -> MCPReviewRequest:
    """Prepare a review request for Codex CLI invocation.

    This function generates the review prompt but does NOT invoke Codex.
    The caller (typically Claude via the /review skill) should:
    1. Call this function to get the prompt
    2. Invoke execute_codex(prompt=...) to run the review
    3. Parse the response with parse_review_verdict()
    4. Write the verdict with write_review_to_impl()

    This design allows the MCP server to prepare the prompt while the
    actual codex CLI invocation is a separate step.

    Args:
        spec_id: Spec ID (e.g., "S020")
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root for config lookup
        uncommitted: Include staged/unstaged changes in diff
        commit_sha: Review changes from a specific commit
        base_branch: Review changes against a base branch

    Returns:
        MCPReviewRequest with the prompt ready for codex-cli
    """
    prompt = generate_review_prompt(
        spec_id,
        docs_root,
        paths_config,
        project_root,
        uncommitted=uncommitted,
        commit_sha=commit_sha,
        base_branch=base_branch,
    )

    return MCPReviewRequest(
        spec_id=spec_id,
        prompt=prompt.prompt_text,
    )


# ---------------------------------------------------------------------------
# Review Token (anti-rubber-stamping)
# ---------------------------------------------------------------------------

_SELF_REVIEW_PATTERNS = [
    "self-review",
    "self_review",
    "self review",
    "manual-review",
    "manual_review",
    "manual review",
    "manual",
]


def _token_path(spec_id: str, project_root: Path) -> Path:
    """Return path to the review token file for a spec."""
    return project_root / ".novabuilt.dev" / "nspec" / f"review-token-{spec_id}.json"


def generate_review_token(spec_id: str, project_root: Path) -> str:
    """Create a single-use review token and persist it to disk.

    Called by ``codex_review()`` to prove the review flow was initiated
    through the proper channel.

    Returns:
        The generated token string (UUID4).
    """
    from nspec.timestamps import now_iso

    token = uuid.uuid4().hex
    path = _token_path(spec_id, project_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({"token": token, "spec_id": spec_id, "issued_at": now_iso()}) + "\n")
    return token


def consume_review_token(spec_id: str, token: str, project_root: Path) -> bool:
    """Validate and delete a review token (single-use).

    Returns True if the token was valid, False otherwise.
    The token file is deleted on success to prevent reuse.
    """
    path = _token_path(spec_id, project_root)
    if not path.exists():
        return False
    try:
        data = json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return False
    if data.get("token") != token or data.get("spec_id") != spec_id:
        return False
    # Valid — consume by deleting
    path.unlink(missing_ok=True)
    return True


def is_self_review(reviewer: str, implementer: str) -> bool:
    """Check if the reviewer identity indicates a self-review.

    Catches:
    - Exact match (reviewer == implementer)
    - Implementer name as substring (e.g. reviewer="claude-review", implementer="claude")
    - Known self-review patterns ("self-review", "manual-review", etc.)
    """
    r = reviewer.lower().strip()
    i = implementer.lower().strip()

    # Exact match
    if r == i:
        return True

    # Implementer name appears in reviewer
    if i and i in r:
        return True

    # Known self-review patterns
    return any(pat in r for pat in _SELF_REVIEW_PATTERNS)
