You are updating a project changelog. Given the following completed spec
and its code changes, write a concise changelog entry.

## Context
- Spec: {{spec_title}}
- Priority: {{priority}}
- Acceptance Criteria:
{{acceptance_criteria}}

## Code Changes
{{git_diff}}

## Instructions
Write a changelog entry in Keep-a-Changelog format. Categories:
Added, Changed, Fixed, Removed. Be concise — one line per change.
