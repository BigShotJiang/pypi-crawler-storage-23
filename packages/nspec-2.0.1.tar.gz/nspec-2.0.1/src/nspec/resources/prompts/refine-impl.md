You are refining the implementation plan for spec {spec_id}: {title}

## Feature Request (FR)

{fr_content}

## Current IMPL Tasks (skeleton — needs refinement)

{current_tasks}

## Your Task

Replace the placeholder tasks above with a concrete implementation plan.

### Rules

1. Use action verbs (Create, Add, Implement, Wire, Write)
2. Each task gets a `File:` annotation with the target source file
3. Each task gets a `Validates:` reference to FR acceptance criteria where applicable
4. Aim for 5-15 tasks total, grouped into phases (Core Logic, Integration, Testing)
5. Tasks should be completable in one sitting
6. Use subtasks (1.1, 1.2) only when a task has 2+ distinct steps
7. Include a testing phase with unit tests
8. Every task checkbox must use `- [ ]` format

### Output Format

Respond with exactly this structure:

EXECUTIVE_SUMMARY: [1-2 sentences describing what we're building and the key approach]

LOE: [estimated level of effort, e.g., "1d", "2d", "3d"]

TASKS_START
### Phase 1: Core Logic

- [ ] 1. [First real task]
  - File: `src/path/to/file.py`
  - Validates: FR AC-F1

- [ ] 2. [Second real task]
  - File: `src/path/to/file.py`

### Phase 2: Integration

- [ ] 3. [Integration task]
  - File: `src/path/to/file.py`

### Phase 3: Testing

- [ ] N. [Test task]
  - File: `tests/test_file.py`
  - Validates: FR AC-Q1
TASKS_END

Be specific about files, functions, and what each task produces. No placeholders.
