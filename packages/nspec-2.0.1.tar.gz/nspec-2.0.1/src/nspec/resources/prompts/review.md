You are reviewing an implementation for spec {spec_id}: {title}

## Acceptance Criteria

{ac_text}

## Implementation Tasks (with completion state)

{task_text}

## Code Changes (git diff)

```diff
{git_diff}
```

## Your Task

Review this implementation against the acceptance criteria above. Check:
1. Do the code changes satisfy each acceptance criterion?
2. Are there any bugs, security issues, or quality concerns?
3. Is the implementation complete (all tasks checked)?

Respond with exactly one of these verdicts on its own line:

VERDICT: APPROVED
(if the implementation satisfies all criteria and is production-ready)

VERDICT: NEEDS_WORK
(followed by specific feedback on what needs to change)

Be concise and specific in your feedback.
