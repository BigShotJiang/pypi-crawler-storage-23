You are authoring the Feature Request for spec {spec_id}: {title}

The FR currently has only template placeholders. Your job is to write real content
based on the spec title and any available context.
{impl_context}
## Your Task

Write a complete FR body with real content. The FR header (title, priority, status, deps)
is already written — you are authoring everything from "## Executive Summary" onward.

### Rules

1. Write concrete, specific content — no template placeholders like "[Description]"
2. Acceptance Criteria must be testable and use `- [ ] AC-F1:` / `- [ ] AC-Q1:` format
3. Include 2-5 functional acceptance criteria and 1-2 quality criteria
4. Problem and Solution sections should be specific to the feature described by the title
5. Delete optional sections (Technical Design, Test Specifications,
   Source Files, Dependencies, Notes) if not relevant
6. Keep it concise — prefer short, clear descriptions over verbose explanations

### Output Format

Respond with exactly this structure (FR_START/FR_END delimiters are mandatory):

FR_START
## Executive Summary

[1-2 sentences: what this feature does and why.]

## Problem

[What problem does this solve?]

## Solution

### Core Concept

[High-level description of the approach.]

## Acceptance Criteria

### Functional

- [ ] AC-F1: [Core behavior that MUST work]
- [ ] AC-F2: [Secondary behavior or variant]

### Quality

- [ ] AC-Q1: Tests pass (`make test-quick`)
- [ ] AC-Q2: No lint/type errors
FR_END

Be specific. No placeholders. Write as if you are the product owner defining what "done" means.
