"""Package resources for nspec templates.

Canonical FR and IMPL templates are stored as package data files in this
directory and loaded via ``importlib.resources``.  During ``nspec init``,
they are copied to ``.novabuilt.dev/nspec/resources/`` for project-level
customization.

Template profiles (quick/standard/full/formal) are stored under
``templates/{profile}/fr.md`` and ``impl.md``.

Template and prompt resolution is delegated to the resource handle registry
(``nspec.resources.registry``).
"""

from __future__ import annotations

from importlib import resources
from pathlib import Path

from nspec.resources.registry import ResourceNotFoundError, load_resource  # noqa: F401

_TEMPLATES = {
    "fr": "fr-template.md",
    "impl": "impl-template.md",
    "claudemd": "claudemd-template.md",
    "changelog": "changelog-template.md",
}

BUILTIN_PROFILES = ("quick", "standard", "full", "formal")


def load_template(kind: str) -> str:
    """Load a template from package resources.

    Args:
        kind: Template kind — ``"fr"``, ``"impl"``, or ``"claudemd"``.

    Returns:
        Template content as a string.

    Raises:
        ValueError: If *kind* is not a recognised template name.
    """
    filename = _TEMPLATES.get(kind)
    if filename is None:
        raise ValueError(f"Unknown template kind {kind!r}, expected one of {list(_TEMPLATES)}")

    ref = resources.files("nspec.resources").joinpath(filename)
    return ref.read_text(encoding="utf-8")


def resolve_template(kind: str, project_root: Path | None = None) -> str:
    """Resolve a template, preferring project-local override.

    Delegates to the resource handle registry for resolution. The handle
    name is ``{kind}-template`` (e.g., ``"fr-template"``).

    Args:
        kind: Template kind — ``"fr"``, ``"impl"``, or ``"claudemd"``.
        project_root: Project root directory.  If *None*, skips project-local
            lookup and returns the package resource directly.

    Returns:
        Template content as a string.
    """
    handle = f"{kind}-template"
    return load_resource(handle, project_root)


def load_template_profile(profile: str, doc_type: str) -> str:
    """Load a template from a ceremony-level profile.

    Args:
        profile: Profile name — ``"quick"``, ``"standard"``, ``"full"``,
                 or ``"formal"``.
        doc_type: Document type — ``"fr"`` or ``"impl"``.

    Returns:
        Template content as a string.

    Raises:
        ValueError: If *profile* or *doc_type* is not recognised.
    """
    if doc_type not in ("fr", "impl"):
        raise ValueError(f"Unknown doc_type {doc_type!r}, expected 'fr' or 'impl'")

    ref = resources.files("nspec.resources").joinpath(f"templates/{profile}/{doc_type}.md")
    try:
        return ref.read_text(encoding="utf-8")
    except (FileNotFoundError, TypeError):
        available = list_builtin_profiles()
        raise ValueError(
            f"Unknown template profile {profile!r}. Available profiles: {', '.join(available)}"
        ) from None


def resolve_template_profile(
    profile: str,
    doc_type: str,
    project_root: Path | None = None,
) -> str:
    """Resolve a profile template, preferring project-local override.

    Delegates to the resource handle registry. The handle name is
    ``{doc_type}-template:{profile}`` (e.g., ``"fr-template:quick"``).

    Args:
        profile: Profile name (e.g., ``"standard"``).
        doc_type: ``"fr"`` or ``"impl"``.
        project_root: Project root directory.

    Returns:
        Template content as a string.

    Raises:
        ValueError: If *profile* or *doc_type* is not recognised.
    """
    if doc_type not in ("fr", "impl"):
        raise ValueError(f"Unknown doc_type {doc_type!r}, expected 'fr' or 'impl'")

    from nspec.resources.registry import ResourceNotFoundError as _RNFE
    from nspec.resources.registry import UnknownHandleError as _UHE

    handle = f"{doc_type}-template:{profile}"
    try:
        return load_resource(handle, project_root)
    except (_RNFE, _UHE):
        available = list_builtin_profiles()
        raise ValueError(
            f"Unknown template profile {profile!r}. Available profiles: {', '.join(available)}"
        ) from None


def list_builtin_profiles() -> list[str]:
    """List available built-in template profiles.

    Returns:
        Sorted list of profile names.
    """
    return list(BUILTIN_PROFILES)
