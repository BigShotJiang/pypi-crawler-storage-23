# IMPL-XXX: Title

**Status:** 🟡 Planning
**LOE:** N/A

<!--
STATUS FLOW: 🟡 Planning → 🔵 Active → 🧪 Testing → ✅ Completed

Use nspec MCP tools to change status (never edit manually):
  activate(spec_id)                   → Start work
  task_complete(spec_id, task_id)     → Mark task done
  criteria_complete(spec_id, ac_id)   → Mark AC satisfied
  advance(spec_id)                    → Move to next status
  complete(spec_id)                   → Archive when done

CHECKBOX RULE: Only checkbox items (- [ ]) are tracked as tasks.
Plain bullets are documentation/notes and are NOT counted.

PROFILE: formal (Crystal Red — maximum ceremony)
This is the highest-ceremony IMPL template. It includes everything from the
"full" profile plus Daily Roadmap, Test Data Examples, Test Execution Strategy,
expanded Quality Gates, Testing Checklist, Risks & Mitigation, Dependencies
with Rationale, Lessons Learned, Completion Checklist, and Progress Tracking.
-->

## Executive Summary

<!-- 1-2 sentences: what we're building and the key approach.
     Update this section as implementation progresses to reflect actual state.
     Include the key design decision that shapes the implementation. -->

**Progress:** Phase 1 of 3 — not started.
**Blocked:** No.
**Risk level:** <!-- Low/Medium/High based on Risks & Mitigation table -->

## Implementation Strategy

### Approach

<!-- Describe the overall implementation strategy: key design decisions,
     trade-offs considered, and the rationale for the chosen approach.
     Include alternatives that were considered and why they were rejected. -->

### Key Design Decisions

<!-- Document the critical design decisions that shape this implementation.
     Each decision should reference the FR section it supports. -->

- **Decision 1:** <!-- what and why -->
- **Decision 2:** <!-- what and why -->

### Phasing

**Phase 1: Core Logic** — Data models, core logic, test fixtures
**Phase 2: Integration** — Wire into CLI/MCP/TUI entry points
**Phase 3: Testing** — Unit tests, integration tests, verification

### Rollback Strategy

<!-- How to revert this change if something goes wrong after merge.
     Include specific steps and any data migration considerations. -->

## Daily Roadmap

<!-- Break down the implementation into day-sized increments. Each day has
     concrete tasks, success criteria, and time estimates. Adjust the number
     of days to match the LOE. This section uses plain text descriptions
     (not checkboxes) to avoid being counted as tasks. -->

### Day 1: Foundation

Tasks for this day:
- Set up project scaffolding and data models
- Implement core data structures and type definitions
- Write initial test fixtures and factory functions
- Validate data model against FR Technical Design section

Success criteria: Core data structures compile and pass basic smoke tests.
Estimated time: 6-8 hours.
Dependencies: None.

### Day 2: Core Implementation

Tasks for this day:
- Implement primary business logic
- Add error handling and validation
- Write unit tests for core logic (positive cases)
- Begin integration with existing subsystems

Success criteria: Core logic passes unit tests with positive and negative cases.
Estimated time: 6-8 hours.
Dependencies: Day 1 complete.

### Day 3: Integration

Tasks for this day:
- Wire into CLI entry points
- Wire into MCP server tool functions
- Wire into TUI components if applicable
- End-to-end flow verification through each entry point
- Fix integration issues discovered during wiring

Success criteria: Feature is accessible through all intended entry points.
Estimated time: 6-8 hours.
Dependencies: Day 2 complete.

### Day 4: Testing & Hardening

Tasks for this day:
- Write comprehensive negative and edge case tests
- Write integration tests spanning multiple components
- Performance testing against AC-P targets
- Security testing against TC-PS cases
- Fix bugs and regressions discovered during testing

Success criteria: All test specifications from FR pass. Coverage targets met.
Estimated time: 6-8 hours.
Dependencies: Day 3 complete.

### Day 5: Review & Polish

Tasks for this day:
- Code review preparation: self-review all changed files
- Documentation updates: changelog, help text, comments
- Submit for Codex review
- Address review findings
- Final verification and cleanup

Success criteria: Codex review verdict is APPROVED. All DoD items satisfied.
Estimated time: 4-6 hours.
Dependencies: Day 4 complete.

## Tasks

### Phase 1: Core Logic

- [ ] 1. <!-- First concrete task: data models or core structures -->
  - File: <!-- target file path -->
  - Validates: FR AC-F1
  - Estimated: <!-- time estimate -->

- [ ] 2. <!-- Second task: primary business logic -->
  - File: <!-- target file path -->
  - Validates: FR AC-F2
  - Estimated: <!-- time estimate -->

- [ ] 3. <!-- Third task: error handling and validation -->
  - File: <!-- target file path -->
  - Validates: FR AC-F3
  - Estimated: <!-- time estimate -->

### Phase 2: Integration

- [ ] 4. <!-- Wire into CLI entry point -->
  - File: <!-- target file path -->
  - Validates: FR AC-F4

- [ ] 5. <!-- Wire into MCP server -->
  - File: <!-- target file path -->
  - Validates: FR AC-F4

- [ ] 6. <!-- Wire into TUI if applicable -->
  - File: <!-- target file path -->
  - Validates: FR AC-F4

### Phase 3: Testing

- [ ] 7. <!-- Unit tests for core logic -->
  - File: <!-- test file path -->
  - Validates: FR TC-P1, TC-P2, TC-P3

- [ ] 8. <!-- Negative and edge case tests -->
  - File: <!-- test file path -->
  - Validates: FR TC-N1, TC-N2, TC-N3, TC-E1, TC-E2, TC-E3

- [ ] 9. <!-- Integration tests -->
  - File: <!-- test file path -->
  - Validates: FR TC-I1, TC-I2, TC-I3

- [ ] 10. <!-- Performance and security tests -->
  - File: <!-- test file path -->
  - Validates: FR TC-PS1, TC-PS2

- [ ] 11. <!-- Documentation updates -->
  - File: <!-- docs or help text file path -->
  - Validates: FR AC-D1, AC-D2

## Files Modified

| File | Change | LOE |
|------|--------|-----|
| <!-- file path --> | <!-- New or Modified — description --> | <!-- e.g. 2h --> |
| <!-- file path --> | <!-- New or Modified — description --> | <!-- e.g. 4h --> |
| <!-- file path --> | <!-- New or Modified — description --> | <!-- e.g. 1h --> |
| <!-- file path --> | <!-- New or Modified — description --> | <!-- e.g. 2h --> |
| <!-- file path --> | <!-- New or Modified — description --> | <!-- e.g. 3h --> |

## Test Implementation Details

<!-- Detailed test architecture: file organization, shared fixtures,
     mock strategies, and test doubles. This section guides the test
     implementation and ensures consistency across the test suite. -->

### File Organization

<!-- How test files are structured: naming conventions, directory layout,
     which tests go in which files. -->

| Test File | Covers | Type |
|-----------|--------|------|
| <!-- tests/test_module.py --> | <!-- core logic --> | <!-- Unit --> |
| <!-- tests/test_integration.py --> | <!-- end-to-end flows --> | <!-- Integration --> |
| <!-- tests/test_performance.py --> | <!-- latency/throughput --> | <!-- Performance --> |

### Fixture Design

<!-- Shared fixtures: what they provide, where they live, how they're
     parameterized. Include factory functions and builders. -->

**Shared fixtures (conftest.py):**

- <!-- fixture_name: what it provides and when to use it -->
- <!-- fixture_name: what it provides and when to use it -->

**Factory functions:**

- <!-- factory_name(): creates test instances with sensible defaults -->
- <!-- factory_name(): creates test instances with specific configuration -->

### Mocks & Test Doubles

<!-- External dependencies that need mocking: file system, network,
     database, time. Document the mock strategy for each. -->

| Dependency | Mock Strategy | Scope |
|-----------|---------------|-------|
| <!-- file system --> | <!-- tmp_path fixture --> | <!-- per-test --> |
| <!-- network --> | <!-- responses library or httpx mock --> | <!-- per-test --> |
| <!-- time --> | <!-- freezegun or manual patching --> | <!-- per-test --> |

### Test Doubles

<!-- Fakes, stubs, and spies used in the test suite.
     Document what each double replaces and why. -->

- <!-- FakeRepository: in-memory implementation replacing database calls -->
- <!-- StubConfig: returns fixed configuration without reading files -->

## Test Data Examples

<!-- Concrete examples of test inputs and expected outputs. These serve as
     documentation and can be directly used in test implementations. -->

### Valid Inputs

| # | Input | Expected Output | Notes |
|---|-------|----------------|-------|
| 1 | <!-- example valid input --> | <!-- expected result --> | <!-- why this case matters --> |
| 2 | <!-- example valid input --> | <!-- expected result --> | <!-- variant or boundary --> |
| 3 | <!-- example valid input --> | <!-- expected result --> | <!-- all optional params provided --> |

### Invalid Inputs

| # | Input | Expected Error | Notes |
|---|-------|---------------|-------|
| 1 | <!-- example invalid input --> | <!-- expected error message or type --> | <!-- what validation it tests --> |
| 2 | <!-- example invalid input --> | <!-- expected error message or type --> | <!-- what validation it tests --> |
| 3 | <!-- example invalid input --> | <!-- expected error message or type --> | <!-- malformed or corrupted input --> |

### Edge Cases

| # | Input | Expected Behavior | Notes |
|---|-------|------------------|-------|
| 1 | <!-- edge case input --> | <!-- expected behavior --> | <!-- why this is an edge case --> |
| 2 | <!-- edge case input --> | <!-- expected behavior --> | <!-- boundary condition details --> |
| 3 | <!-- edge case input --> | <!-- expected behavior --> | <!-- concurrency or timing edge --> |

## Test Execution Strategy

<!-- How to run the tests and in what order. Includes both local
     development workflow and CI pipeline expectations. -->

**Local development:**
- Run `make test-quick` after each task completion for fast feedback
- Run full suite with `make test-cov` before submitting for review
- Use `pytest -k "test_name"` for focused iteration on specific tests

**CI pipeline:**
- All tests must pass on the target Python version
- Coverage must meet or exceed the per-module targets below
- No new lint or type-check warnings introduced

**Test isolation:**
- Each test must be independent and idempotent
- Tests must not depend on execution order
- Shared state must be managed through fixtures with proper teardown

**Regression testing:**
- Any bug found during implementation gets a regression test
- Regression tests reference the bug description in a comment
- Run the full suite before each commit to catch regressions early

**Performance testing:**
- Performance tests run in isolation to avoid interference
- Use benchmarks with warmup iterations for stable measurements
- Compare against baseline values from FR AC-P targets

## Coverage Targets

<!-- Per-module coverage targets. These ensure that the implementation
     is adequately tested across all modified modules. -->

| Module | Target | Notes |
|--------|--------|-------|
| <!-- src/module.py --> | <!-- 90% --> | <!-- core logic, high coverage required --> |
| <!-- src/other.py --> | <!-- 85% --> | <!-- integration layer --> |
| <!-- src/cli_entry.py --> | <!-- 80% --> | <!-- CLI wiring, some paths hard to test --> |
| <!-- tests/ --> | <!-- N/A --> | <!-- test code is not coverage-measured --> |

### Coverage Validation

<!-- How to verify coverage targets are met. -->

- Run `make test-cov` to generate the HTML coverage report
- Check per-file coverage in `htmlcov/index.html`
- Any module below its target must have a documented justification

## Quality Gates

<!-- Multi-stage quality checks that must pass before each milestone.
     Formal ceremony requires pre-commit, pre-PR, and pre-merge gates. -->

### Pre-commit Checklist

- `make format` produces no changes (code is already formatted)
- `make lint` reports zero warnings
- `make typecheck` reports zero errors
- `make test-quick` passes with zero failures

### Pre-PR Checklist

- All IMPL tasks are marked complete
- All FR acceptance criteria are marked complete
- `make test-cov` meets per-module coverage targets
- No TODO/FIXME/HACK comments introduced without tracking spec
- All modified files have been reviewed for unintended changes
- Session Notes updated with key decisions and findings

### Pre-merge Checklist

- Codex review verdict is APPROVED
- All review findings have been addressed
- `make check` passes (format + lint + typecheck + test)
- No merge conflicts with target branch
- Commit messages follow project conventions

## Risks & Mitigation

<!-- Technical and schedule risks specific to this implementation.
     Track status as work progresses. -->

| Risk | Likelihood | Impact | Mitigation | Status |
|------|------------|--------|------------|--------|
| <!-- risk description --> | <!-- Low/Med/High --> | <!-- Low/Med/High --> | <!-- mitigation approach --> | <!-- Open/Mitigated/Accepted --> |
| <!-- risk description --> | <!-- Low/Med/High --> | <!-- Low/Med/High --> | <!-- mitigation approach --> | <!-- Open/Mitigated/Accepted --> |
| <!-- risk description --> | <!-- Low/Med/High --> | <!-- Low/Med/High --> | <!-- mitigation approach --> | <!-- Open/Mitigated/Accepted --> |

## Dependencies

<!-- Implementation-specific dependencies: libraries, services, specs
     that must be completed first, or data that must be available. -->

| Dependency | Type | Status | Notes |
|-----------|------|--------|-------|
| <!-- dependency name --> | <!-- Spec / Library / Service --> | <!-- Available / Pending --> | <!-- additional context --> |
| <!-- dependency name --> | <!-- Spec / Library / Service --> | <!-- Available / Pending --> | <!-- additional context --> |

### Rationale

<!-- Explain why each dependency exists and what would happen if it
     were unavailable. For pending dependencies, describe the fallback
     or blocking strategy. -->

### Version Constraints

<!-- For library dependencies, document minimum version requirements
     and any known incompatibilities. -->

## Progress Tracking

<!-- Phase-by-phase progress narrative. Update this section as work proceeds.
     Use plain descriptions, not checkbox items, to avoid task counting.
     This provides a high-level view complementing the granular task list. -->

### Phase 1: Core Logic

Status: Not started.
Completion estimate: 0%.
Notes: No work begun yet.

### Phase 2: Integration

Status: Not started. Blocked on Phase 1 completion.
Completion estimate: 0%.
Notes: No work begun yet.

### Phase 3: Testing

Status: Not started. Blocked on Phase 2 completion.
Completion estimate: 0%.
Notes: No work begun yet.

## Testing Checklist

<!-- Verification steps organized by implementation stage. These are
     documentation reminders, not tracked tasks. -->

### Before Starting Implementation

- Review all FR acceptance criteria and test specifications
- Identify test fixtures and data needed
- Set up test file structure and shared fixtures
- Verify baseline: `make test-quick` passes before changes

### During Implementation

- Run `make test-quick` after each task completion
- Write tests alongside implementation (not after)
- Verify negative cases and error paths explicitly
- Check coverage incrementally with `make test-cov`

### After Implementation Complete

- Run full quality gate: `make check`
- Verify all TC-* test cases from the FR are covered
- Review coverage report for gaps in modified modules
- Run integration tests in isolation to verify independence
- Perform manual smoke test if applicable (TUI, CLI)

## Lessons Learned

<!-- Capture insights during implementation for future reference.
     Update this section as work progresses. -->

| # | Area | Learning | Applied |
|---|------|----------|---------|
| 1 | <!-- area: design/testing/tooling/process --> | <!-- what was learned --> | <!-- how it was applied or will be applied --> |
| 2 | <!-- area: design/testing/tooling/process --> | <!-- what was learned --> | <!-- how it was applied or will be applied --> |

## Completion Checklist

<!-- Final verification before marking the spec as done. This is the
     last gate before calling complete(spec_id). -->

- All IMPL tasks show [x] (verified via `show(spec_id)`)
- All FR acceptance criteria show [x]
- All DoD items below are satisfied
- Quality gates (pre-commit, pre-PR, pre-merge) all pass
- Session Notes capture key decisions and findings
- Lessons Learned table is populated
- Risks table statuses are updated (all Mitigated or Accepted)
- Progress Tracking sections reflect final state
- No open BLOCKED markers on any task

## Definition of Done

- [ ] dod-1. Tests pass (`make test-quick`)
- [ ] dod-2. Lint/typecheck clean (`make check`)
- [ ] dod-3. All FR acceptance criteria marked complete
- [ ] dod-4. Code committed with descriptive message
- [ ] dod-5. Codex review verdict is APPROVED

## Review

**Implementer:** —
**Reviewer:** —
**Verdict:** PENDING

### Review History
| # | Date | Verdict | Reviewer |
|---|------|---------|----------|

### Findings

<!-- Reviewer writes findings here -->

## Session Notes

<!-- Record each working session. This provides continuity across
     sessions and helps with post-mortem analysis. -->

### YYYY-MM-DD

- **Started:** <!-- What phase/task -->
- **Completed:** <!-- What was finished this session -->
- **Decision:** <!-- Choice made and why -->
- **Finding:** <!-- Unexpected insight -->
- **Blocker:** <!-- What is blocking progress, if anything -->
- **Risk update:** <!-- Any changes to risk assessment -->
- **Next:** <!-- What to pick up next session -->
