# IMPL-XXX: Title

**Status:** 🟡 Planning
**LOE:** N/A

<!--
STATUS FLOW: 🟡 Planning → 🔵 Active → 🧪 Testing → ✅ Completed

Use nspec MCP tools to change status (never edit manually):
  activate(spec_id)                   → Start work
  task_complete(spec_id, task_id)     → Mark task done
  criteria_complete(spec_id, ac_id)   → Mark AC satisfied
  advance(spec_id)                    → Move to next status
  complete(spec_id)                   → Archive when done

CHECKBOX RULE: Only checkbox items (- [ ]) are tracked as tasks.
Plain bullets are documentation/notes and are NOT counted.

PROFILE: full (Crystal Orange — high ceremony)
Use for complex features, multi-component work, and new subsystems (2-5d LOE).
Strict superset of "standard" — all standard sections appear here plus
Test Implementation Details, Coverage Targets, Quality Gates, and Progress Tracking.
-->

## Executive Summary

<!-- 1-2 sentences: what we're building and the key implementation approach. -->

## Implementation Strategy

### Approach

<!-- Describe the high-level implementation plan. What design patterns,
     libraries, or techniques will be used? What are the key decisions? -->

### Phasing

**Phase 1: Foundation** — Data models, core logic, test fixtures
**Phase 2: Integration** — Wire into CLI/MCP/TUI entry points
**Phase 3: Testing** — Unit tests, integration tests, verification

## Tasks

### Phase 1: Core Logic

- [ ] 1. <!-- First concrete task — describe the specific deliverable -->
  - File: `src/module.py`
  - Validates: FR AC-F1

- [ ] 2. <!-- Second concrete task -->
  - File: `src/other.py`
  - Validates: FR AC-F2

### Phase 2: Integration

- [ ] 3. <!-- Wire feature into entry points -->
  - File: `src/cli.py`

- [ ] 4. <!-- Connect to downstream consumers -->
  - File: `src/mcp_server.py`

### Phase 3: Testing

- [ ] 5. <!-- Unit tests for core logic -->
  - File: `tests/test_module.py`
  - Validates: FR TC-P1, TC-N1, TC-E1

- [ ] 6. <!-- Integration tests for end-to-end flows -->
  - File: `tests/test_integration.py`
  - Validates: FR TC-I1, TC-I2

## Test Implementation Details

<!-- How tests are organized and what infrastructure they need.
     This section distinguishes "full" from "standard" — include it when
     the feature requires non-trivial test setup. -->

### File Organization

<!-- Where test files live and how they map to source modules. -->

- `tests/test_module.py` — Unit tests for core logic
- `tests/test_integration.py` — Integration tests spanning multiple modules

### Fixture Design

<!-- Shared fixtures, factories, or builders needed for testing. -->

- <!-- Describe key fixtures and their purpose -->
- <!-- Describe any mock objects or test doubles needed -->

## Coverage Targets

<!-- Per-module coverage expectations. Helps track whether testing is
     proportional to complexity. -->

| Module | Target | Notes |
|--------|--------|-------|
| `src/module.py` | 90% | <!-- Core logic, high coverage needed --> |
| `src/cli.py` | 80% | <!-- Integration layer, moderate coverage --> |

## Quality Gates

<!-- Pre-commit checklist. Items here are reminders, not tracked tasks.
     For tracked items, use the Definition of Done section. -->

**Pre-commit:**
- All tests pass (`make test-quick`)
- Lint and typecheck clean (`make check`)
- No regressions in existing tests
- New code has test coverage above module target
- HTML coverage report reviewed for uncovered branches

## Files Modified

| File | Change |
|------|--------|
| `path/to/file.py` | New — <!-- describe purpose --> |
| `path/to/existing.py` | Modified — <!-- describe change --> |

## Progress Tracking

<!-- Phase-by-phase progress overview. This is a summary view — the
     canonical progress is tracked via task checkboxes above.
     Update these notes as phases complete. -->

**Phase 1: Foundation**
- Status: Not started
- Blockers: None

**Phase 2: Integration**
- Status: Not started
- Blockers: Phase 1 completion

**Phase 3: Testing**
- Status: Not started
- Blockers: Phase 2 completion

## Definition of Done

- [ ] dod-1. Tests pass
- [ ] dod-2. Lint/typecheck clean
- [ ] dod-3. All FR acceptance criteria marked complete
- [ ] dod-4. Code committed with descriptive message
- [ ] dod-5. Codex review verdict is APPROVED

## Review

**Implementer:** —
**Reviewer:** —
**Verdict:** PENDING

### Review History
| # | Date | Verdict | Reviewer |
|---|------|---------|----------|

### Findings

<!-- Reviewer writes findings here -->

## Session Notes

### YYYY-MM-DD

- **Started:** <!-- What phase/task -->
- **Decision:** <!-- Choice made and why -->
- **Finding:** <!-- Unexpected insight -->
- **Next:** <!-- What to pick up next session -->
