# FR-XXX: Title

**Priority:** 🟡 P2
**Status:** 🟡 Proposed
deps: []

<!--
PRIORITY:  🔥P0 Critical | 🟠P1 High | 🟡P2 Medium | 🔵P3 Low
STATUS:    🟡 Proposed → 🔵 Active → ✅ Completed

Use nspec MCP tools to change status (never edit manually):
  activate(spec_id)    → Start work
  advance(spec_id)     → Move to next status
  complete(spec_id)    → Archive when done
-->

## Executive Summary

<!-- One sentence: what this does and why. -->

## Problem

<!-- What pain point does this address? -->

## Solution

### Core Concept

<!-- High-level approach in one paragraph. -->

## Acceptance Criteria

### Functional

- [ ] AC-F1: <!-- Core behavior that must work -->
- [ ] AC-F2: <!-- Secondary behavior or variant -->
- [ ] AC-F3: <!-- Error handling behavior -->

### Quality

- [ ] AC-Q1: Tests pass (`make test-quick`)
- [ ] AC-Q2: No lint/type errors
