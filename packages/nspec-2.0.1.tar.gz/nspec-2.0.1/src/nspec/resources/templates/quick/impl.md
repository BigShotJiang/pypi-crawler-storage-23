# IMPL-XXX: Title

**Status:** 🟡 Planning
**LOE:** N/A

<!--
STATUS FLOW: 🟡 Planning → 🔵 Active → 🧪 Testing → ✅ Completed

CHECKBOX RULE: Only checkbox items (- [ ]) are tracked as tasks.
Plain bullets are documentation/notes and are NOT counted.
-->

## Executive Summary

<!-- One sentence: what we're building and the key approach. -->

## Tasks

- [ ] 1. <!-- First concrete task -->
- [ ] 2. <!-- Second concrete task -->

## Definition of Done

- [ ] dod-1. Tests pass
- [ ] dod-2. Lint/typecheck clean
- [ ] dod-3. All FR acceptance criteria marked complete

## Review

**Implementer:** —
**Reviewer:** —
**Verdict:** PENDING

### Review History
| # | Date | Verdict | Reviewer |
|---|------|---------|----------|

### Findings

<!-- Reviewer writes findings here -->
