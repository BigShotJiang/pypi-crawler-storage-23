<!-- managed-by: nspec -->
# {{project_name}} Dev Process

## Active Work Tracking (MANDATORY)

**There must always be an active epic when work is in flight.** At session start:
1. Call `get_epic()` to check if an active epic is set
2. If not, call `epics()` to see available epics, then set the active one via `activate(epic_id)`
3. Call `next_spec(epic_id)` to find the highest-priority unblocked spec

**Never leave state.json with `active_epic: null` during a work session.** The TUI dashboard, session handoff, and `/loop` all depend on knowing which epic is being worked.

## Progress Tracking (MANDATORY)

When working on an nspec spec, you MUST call nspec MCP tools to track progress incrementally. Do not batch updates — call each tool immediately after the corresponding work is done.

### After completing each IMPL task:
1. Verify the work is done (tests pass if applicable)
2. Call `task_complete` with the spec_id and task_id
3. Read the response to see remaining tasks and progress %
4. Continue to the next task

### After satisfying an acceptance criterion:
1. Call `criteria_complete` with the spec_id and criteria_id

### After all tasks are done:
1. Call `advance` to move the spec to the next status

### Why this matters:
- The TUI dashboard shows real-time progress to the user
- Session state is persisted for cross-session handoff
- Skipping these calls means the spec stays at 0% even though work is complete

## Quality Gates

```
make test-quick    → Fast tests, fail-fast
make check         → Full quality gate (format + lint + typecheck + test)
```

## Commit Format

```
feat(scope): Add new feature
fix(scope): Fix bug description
test(scope): Add tests for feature
docs(scope): Update documentation
refactor(scope): Refactor module
chore: Update dependencies
```

## nspec MCP Tools Reference

### Query Tools
| Tool | Purpose |
|------|---------|
| `epics()` | List epics with progress |
| `show(spec_id)` | Show spec details (FR + IMPL) |
| `next_spec(epic_id)` | Find highest-priority unblocked spec |
| `validate()` | Run 6-layer validation engine |
| `blocked_specs()` | List blocked/paused/exception specs |

### Mutation Tools
| Tool | Purpose |
|------|---------|
| `create_spec(title, priority)` | Create new FR + IMPL pair |
| `activate(spec_id)` | Start working on a spec |
| `task_complete(spec_id, task_id)` | Mark an IMPL task done |
| `criteria_complete(spec_id, criteria_id)` | Mark an acceptance criterion done |
| `advance(spec_id)` | Advance spec to next status |
| `complete(spec_id)` | Archive a completed spec |

### Session Tools
| Tool | Purpose |
|------|---------|
| `session_start(spec_id)` | Initialize work session |
| `session_save(spec_id)` | Save session state for handoff |
| `session_resume(spec_id)` | Resume previous session |
| `session_clear()` | Clear session state |

## File Structure

```
{{docs_root}}/
├── {{feature_requests}}/   # Active feature requests
├── {{implementation}}/     # Active implementation plans
└── {{completed}}/          # Archived work
    ├── done/               # Completed specs
    ├── superseded/         # Superseded specs
    └── rejected/           # Rejected specs
```
