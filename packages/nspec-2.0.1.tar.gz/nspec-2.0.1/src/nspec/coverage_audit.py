"""Whole-suite coverage audit with dead-code detection.

Parses pytest-cov JSON artifacts, builds candidate inventories of uncovered
and behaviorally suspicious code, and reconciles triage decisions
(DELETE / ADD_TEST / JUSTIFY_KEEP) against the candidate set.
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any


class DecisionAction(str, Enum):
    """Triage actions for coverage audit candidates."""

    DELETE = "DELETE"
    ADD_TEST = "ADD_TEST"
    JUSTIFY_KEEP = "JUSTIFY_KEEP"


class CandidateType(str, Enum):
    """Classification of coverage audit candidates."""

    UNCOVERED = "uncovered"
    SUSPICIOUS = "suspicious"


# ---------------------------------------------------------------------------
# Schema dataclasses
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class FileCoverage:
    """Per-file line coverage extracted from pytest-cov JSON."""

    filename: str
    executed_lines: list[int]
    missing_lines: list[int]
    excluded_lines: list[int]
    line_rate: float  # 0.0-1.0


@dataclass(frozen=True)
class CoverageArtifact:
    """Parsed whole-suite coverage artifact."""

    files: dict[str, FileCoverage]
    total_statements: int
    total_missing: int
    total_rate: float  # 0.0-1.0
    source_path: str  # path to original coverage.json


@dataclass(frozen=True)
class CoverageCandidate:
    """A code location flagged for triage."""

    candidate_id: str  # stable hash-based ID
    file: str
    start_line: int
    end_line: int
    candidate_type: CandidateType
    snippet: str  # source context around the lines
    reason: str  # human-readable explanation


@dataclass(frozen=True)
class CoverageDecision:
    """A triage decision for a candidate."""

    candidate_id: str
    action: DecisionAction
    rationale: str
    reviewer: str
    timestamp: str  # ISO 8601


@dataclass
class DecisionRegistry:
    """Persisted set of decisions keyed by candidate_id."""

    decisions: dict[str, CoverageDecision] = field(default_factory=dict)
    source_path: str | None = None


@dataclass(frozen=True)
class AuditResult:
    """Full reconciliation result from an audit run."""

    artifact: CoverageArtifact
    candidates: list[CoverageCandidate]
    resolved: list[CoverageCandidate]
    unresolved: list[CoverageCandidate]
    stale_decisions: list[str]  # decision IDs with no matching candidate
    registry: DecisionRegistry


# ---------------------------------------------------------------------------
# Candidate ID generation
# ---------------------------------------------------------------------------

_CANDIDATE_ID_PREFIX = "cov"


def _stable_candidate_id(file: str, start_line: int, end_line: int, ctype: CandidateType) -> str:
    """Generate a stable, deterministic candidate ID from location + type."""
    raw = f"{file}:{start_line}-{end_line}:{ctype.value}"
    digest = hashlib.sha256(raw.encode()).hexdigest()[:12]
    return f"{_CANDIDATE_ID_PREFIX}:{digest}"


# ---------------------------------------------------------------------------
# Coverage artifact loading
# ---------------------------------------------------------------------------


def load_coverage_artifact(coverage_json_path: Path) -> CoverageArtifact:
    """Parse a pytest-cov JSON report into a CoverageArtifact.

    Expects the format produced by ``pytest --cov --cov-report=json``.
    """
    if not coverage_json_path.exists():
        raise FileNotFoundError(f"Coverage artifact not found: {coverage_json_path}")

    raw = json.loads(coverage_json_path.read_text())

    # pytest-cov JSON structure: {"meta": {...}, "files": {...}, "totals": {...}}
    if "files" not in raw or "totals" not in raw:
        raise ValueError(
            f"Invalid coverage JSON format (missing 'files' or 'totals'): {coverage_json_path}"
        )

    files: dict[str, FileCoverage] = {}
    for fname, fdata in raw["files"].items():
        summary = fdata.get("summary", {})
        files[fname] = FileCoverage(
            filename=fname,
            executed_lines=sorted(fdata.get("executed_lines", [])),
            missing_lines=sorted(fdata.get("missing_lines", [])),
            excluded_lines=sorted(fdata.get("excluded_lines", [])),
            line_rate=summary.get("percent_covered", 0.0) / 100.0,
        )

    totals = raw["totals"]
    return CoverageArtifact(
        files=files,
        total_statements=totals.get("num_statements", 0),
        total_missing=totals.get("missing_lines", 0),
        total_rate=totals.get("percent_covered", 0.0) / 100.0,
        source_path=str(coverage_json_path),
    )


# ---------------------------------------------------------------------------
# Candidate inventory
# ---------------------------------------------------------------------------

# Lines within this distance are grouped into a single candidate range.
_LINE_GROUP_GAP = 3


def _group_lines(lines: list[int]) -> list[tuple[int, int]]:
    """Group consecutive (or near-consecutive) line numbers into ranges."""
    if not lines:
        return []
    ranges: list[tuple[int, int]] = []
    start = lines[0]
    end = lines[0]
    for ln in lines[1:]:
        if ln - end <= _LINE_GROUP_GAP:
            end = ln
        else:
            ranges.append((start, end))
            start = ln
            end = ln
    ranges.append((start, end))
    return ranges


def _read_snippet(file_path: str, start_line: int, end_line: int, context: int = 2) -> str:
    """Read source lines with context. Returns empty string if file unreadable."""
    try:
        source = Path(file_path).read_text().splitlines()
    except OSError:
        return ""
    lo = max(0, start_line - 1 - context)
    hi = min(len(source), end_line + context)
    lines = []
    for i in range(lo, hi):
        marker = ">" if start_line - 1 <= i <= end_line - 1 else " "
        lines.append(f"{marker} {i + 1:4d} | {source[i]}")
    return "\n".join(lines)


def inventory_uncovered_candidates(
    artifact: CoverageArtifact,
    *,
    include_patterns: list[str] | None = None,
    exclude_patterns: list[str] | None = None,
) -> list[CoverageCandidate]:
    """Build candidate list from uncovered lines in the artifact.

    Args:
        artifact: Parsed coverage data.
        include_patterns: If set, only files matching at least one pattern.
        exclude_patterns: If set, skip files matching any pattern.
    """
    candidates: list[CoverageCandidate] = []
    for fname, fcov in sorted(artifact.files.items()):
        if not _file_matches(fname, include_patterns, exclude_patterns):
            continue
        if not fcov.missing_lines:
            continue
        for start, end in _group_lines(fcov.missing_lines):
            cid = _stable_candidate_id(fname, start, end, CandidateType.UNCOVERED)
            snippet = _read_snippet(fname, start, end)
            candidates.append(
                CoverageCandidate(
                    candidate_id=cid,
                    file=fname,
                    start_line=start,
                    end_line=end,
                    candidate_type=CandidateType.UNCOVERED,
                    snippet=snippet,
                    reason=f"Lines {start}-{end} not executed by any test",
                )
            )
    return candidates


def _file_matches(
    fname: str,
    include_patterns: list[str] | None,
    exclude_patterns: list[str] | None,
) -> bool:
    """Check if a file passes inclusion/exclusion filters."""
    if exclude_patterns:
        for pat in exclude_patterns:
            if re.search(pat, fname):
                return False
    if include_patterns:
        return any(re.search(pat, fname) for pat in include_patterns)
    return True


# ---------------------------------------------------------------------------
# Suspicious-covered candidate heuristics
# ---------------------------------------------------------------------------

# Patterns that suggest code is executed but not meaningfully tested.
_SUSPICIOUS_PATTERNS: list[tuple[str, str]] = [
    (r"^\s*pass\s*$", "pass-only block (no behavior to test)"),
    (r"^\s*\.\.\.\s*$", "ellipsis placeholder (stub)"),
    (r"^\s*raise NotImplementedError", "NotImplementedError stub"),
    (r"^\s*#\s*pragma:\s*no\s*cover", "pragma no-cover marker in covered code"),
    (r"^\s*logging\.\w+\(", "logging-only line (no assertable behavior)"),
]


def detect_suspicious_covered(
    artifact: CoverageArtifact,
    *,
    include_patterns: list[str] | None = None,
    exclude_patterns: list[str] | None = None,
) -> list[CoverageCandidate]:
    """Identify executed-but-suspicious code using heuristics.

    These are lines that appear in executed_lines but match patterns
    suggesting they aren't meaningfully tested.
    """
    candidates: list[CoverageCandidate] = []
    for fname, fcov in sorted(artifact.files.items()):
        if not _file_matches(fname, include_patterns, exclude_patterns):
            continue
        if not fcov.executed_lines:
            continue
        try:
            source_lines = Path(fname).read_text().splitlines()
        except OSError:
            continue
        for ln in fcov.executed_lines:
            if ln < 1 or ln > len(source_lines):
                continue
            line_text = source_lines[ln - 1]
            for pattern, reason in _SUSPICIOUS_PATTERNS:
                if re.match(pattern, line_text):
                    cid = _stable_candidate_id(fname, ln, ln, CandidateType.SUSPICIOUS)
                    snippet = _read_snippet(fname, ln, ln, context=3)
                    candidates.append(
                        CoverageCandidate(
                            candidate_id=cid,
                            file=fname,
                            start_line=ln,
                            end_line=ln,
                            candidate_type=CandidateType.SUSPICIOUS,
                            snippet=snippet,
                            reason=reason,
                        )
                    )
                    break  # one match per line is enough
    return candidates


# ---------------------------------------------------------------------------
# Decision registry I/O
# ---------------------------------------------------------------------------

_REGISTRY_VERSION = 1


def load_decision_registry(registry_path: Path) -> DecisionRegistry:
    """Load a decision registry from JSON."""
    if not registry_path.exists():
        return DecisionRegistry(source_path=str(registry_path))
    raw = json.loads(registry_path.read_text())
    if raw.get("version") != _REGISTRY_VERSION:
        raise ValueError(f"Unsupported registry version: {raw.get('version')}")
    decisions: dict[str, CoverageDecision] = {}
    for cid, ddata in raw.get("decisions", {}).items():
        try:
            action = DecisionAction(ddata["action"])
        except (KeyError, ValueError) as exc:
            raise ValueError(f"Invalid decision for {cid}: {exc}") from exc
        decisions[cid] = CoverageDecision(
            candidate_id=cid,
            action=action,
            rationale=ddata.get("rationale", ""),
            reviewer=ddata.get("reviewer", ""),
            timestamp=ddata.get("timestamp", ""),
        )
    return DecisionRegistry(decisions=decisions, source_path=str(registry_path))


def save_decision_registry(registry: DecisionRegistry, registry_path: Path) -> None:
    """Persist a decision registry to JSON."""
    data: dict[str, Any] = {
        "version": _REGISTRY_VERSION,
        "decisions": {},
    }
    for cid, dec in sorted(registry.decisions.items()):
        data["decisions"][cid] = {
            "action": dec.action.value,
            "rationale": dec.rationale,
            "reviewer": dec.reviewer,
            "timestamp": dec.timestamp,
        }
    registry_path.parent.mkdir(parents=True, exist_ok=True)
    registry_path.write_text(json.dumps(data, indent=2) + "\n")


# ---------------------------------------------------------------------------
# Reconciliation
# ---------------------------------------------------------------------------


def reconcile(
    candidates: list[CoverageCandidate],
    registry: DecisionRegistry,
) -> AuditResult:
    """Reconcile candidates against the decision registry.

    Returns an AuditResult partitioning candidates into resolved/unresolved
    and identifying stale decisions (decisions for candidates that no longer exist).
    """
    candidate_ids = {c.candidate_id for c in candidates}
    resolved: list[CoverageCandidate] = []
    unresolved: list[CoverageCandidate] = []

    for c in candidates:
        if c.candidate_id in registry.decisions:
            resolved.append(c)
        else:
            unresolved.append(c)

    stale = [cid for cid in registry.decisions if cid not in candidate_ids]

    # Build a dummy artifact for the result (caller typically provides the real one)
    return AuditResult(
        artifact=CoverageArtifact(
            files={}, total_statements=0, total_missing=0, total_rate=0.0, source_path=""
        ),
        candidates=candidates,
        resolved=resolved,
        unresolved=unresolved,
        stale_decisions=stale,
        registry=registry,
    )


# ---------------------------------------------------------------------------
# Full audit pipeline
# ---------------------------------------------------------------------------


def run_audit(
    coverage_json_path: Path,
    registry_path: Path,
    *,
    include_patterns: list[str] | None = None,
    exclude_patterns: list[str] | None = None,
) -> AuditResult:
    """Run the full audit pipeline: load, inventory, detect, reconcile.

    Args:
        coverage_json_path: Path to pytest-cov JSON output.
        registry_path: Path to decision registry JSON.
        include_patterns: Regex patterns to include files.
        exclude_patterns: Regex patterns to exclude files.
    """
    artifact = load_coverage_artifact(coverage_json_path)
    uncovered = inventory_uncovered_candidates(
        artifact, include_patterns=include_patterns, exclude_patterns=exclude_patterns
    )
    suspicious = detect_suspicious_covered(
        artifact, include_patterns=include_patterns, exclude_patterns=exclude_patterns
    )
    all_candidates = uncovered + suspicious
    registry = load_decision_registry(registry_path)
    result = reconcile(all_candidates, registry)
    # Replace the dummy artifact with the real one
    return AuditResult(
        artifact=artifact,
        candidates=result.candidates,
        resolved=result.resolved,
        unresolved=result.unresolved,
        stale_decisions=result.stale_decisions,
        registry=result.registry,
    )


# ---------------------------------------------------------------------------
# Report generation
# ---------------------------------------------------------------------------


def audit_report_json(result: AuditResult) -> dict[str, Any]:
    """Generate a JSON-serializable audit summary report."""
    return {
        "coverage": {
            "total_statements": result.artifact.total_statements,
            "total_missing": result.artifact.total_missing,
            "total_rate": round(result.artifact.total_rate * 100, 2),
            "files_count": len(result.artifact.files),
        },
        "candidates": {
            "total": len(result.candidates),
            "uncovered": sum(
                1 for c in result.candidates if c.candidate_type == CandidateType.UNCOVERED
            ),
            "suspicious": sum(
                1 for c in result.candidates if c.candidate_type == CandidateType.SUSPICIOUS
            ),
        },
        "decisions": {
            "resolved": len(result.resolved),
            "unresolved": len(result.unresolved),
            "stale": len(result.stale_decisions),
            "by_action": {
                action.value: sum(
                    1
                    for c in result.resolved
                    if result.registry.decisions[c.candidate_id].action == action
                )
                for action in DecisionAction
            },
        },
        "gate_pass": len(result.unresolved) == 0 and len(result.stale_decisions) == 0,
    }


def format_audit_summary(result: AuditResult) -> str:
    """Format a human-readable audit summary."""
    report = audit_report_json(result)
    lines = [
        "Coverage Audit Summary",
        "=" * 40,
        f"Coverage: {report['coverage']['total_rate']}% "
        f"({report['coverage']['total_statements']} stmts, "
        f"{report['coverage']['total_missing']} missing)",
        f"Files: {report['coverage']['files_count']}",
        "",
        f"Candidates: {report['candidates']['total']} "
        f"({report['candidates']['uncovered']} uncovered, "
        f"{report['candidates']['suspicious']} suspicious)",
        "",
        f"Resolved: {report['decisions']['resolved']}",
        f"  DELETE:       {report['decisions']['by_action']['DELETE']}",
        f"  ADD_TEST:     {report['decisions']['by_action']['ADD_TEST']}",
        f"  JUSTIFY_KEEP: {report['decisions']['by_action']['JUSTIFY_KEEP']}",
        f"Unresolved: {report['decisions']['unresolved']}",
        f"Stale: {report['decisions']['stale']}",
        "",
    ]
    if report["gate_pass"]:
        lines.append("GATE: PASS")
    else:
        lines.append("GATE: FAIL")
        if report["decisions"]["unresolved"] > 0:
            lines.append(f"  {report['decisions']['unresolved']} unresolved candidate(s)")
        if report["decisions"]["stale"] > 0:
            lines.append(f"  {report['decisions']['stale']} stale decision(s)")
    return "\n".join(lines)
