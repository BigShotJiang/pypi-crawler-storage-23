"""nspec MCP Server — Expose backlog tools via Model Context Protocol.

Provides both stdio and SSE transports for AI coding assistant integration.
Each tool is a thin wrapper calling existing crud/reports/session functions.

Usage:
    nspec-mcp          # stdio transport (default, for Claude Code)
    nspec-mcp --sse    # SSE transport (for web clients)
"""

from __future__ import annotations

import contextlib
import logging
import os
import subprocess
import sys
from builtins import print as _builtin_print
from pathlib import Path
from typing import Any

from mcp.server.fastmcp import FastMCP

logger = logging.getLogger("nspec.mcp")

mcp = FastMCP(
    "nspec",
    instructions="Specification-driven backlog management tools for AI-native development",
)

# ---------------------------------------------------------------------------
# Telemetry: auto-instrument every @mcp.tool() with logging + timeout
# ---------------------------------------------------------------------------
_original_mcp_tool = mcp.tool


def _instrumented_tool(**kwargs: Any):  # type: ignore[no-untyped-def]
    """Wrap mcp.tool() so every registered tool gets telemetry + timeout."""
    from nspec.telemetry import mcp_telemetry, mcp_timeout

    def decorator(fn):  # type: ignore[no-untyped-def]
        wrapped = mcp_timeout()(mcp_telemetry(fn))
        return _original_mcp_tool(**kwargs)(wrapped)

    return decorator


mcp.tool = _instrumented_tool  # type: ignore[assignment]


def _redirect_print_to_stderr_for_stdio() -> None:
    """Ensure incidental print() calls never write to MCP's stdout transport."""
    import builtins

    if getattr(_redirect_print_to_stderr_for_stdio, "_patched", False):
        return

    def _stderr_print(*args: Any, **kwargs: Any) -> None:
        kwargs.setdefault("file", sys.stderr)
        _builtin_print(*args, **kwargs)

    builtins.print = _stderr_print
    _redirect_print_to_stderr_for_stdio._patched = True


def _resolve_project_root(docs_root: Path) -> Path:
    """Resolve project root from a docs_root-like path.

    MCP clients usually pass `docs_root` as the docs directory (e.g. `.../docs`),
    but tests and some callers may pass the project root directly. This helper
    supports both.
    """
    resolved = docs_root.resolve()

    # Common case: `.../docs`
    if resolved.name == "docs":
        return resolved.parent

    # Heuristic: docs roots contain `frs/` and `impls/`.
    if (resolved / "frs").exists() or (resolved / "impls").exists():
        return resolved.parent

    # Otherwise assume the caller already provided a project root.
    return resolved


def _normalize_id(raw: str) -> str:
    """Normalize and validate spec/epic IDs at the MCP boundary (E###/S###)."""
    from nspec.ids import normalize_spec_ref

    return normalize_spec_ref(raw)


def _resolve_id(raw: str, known_ids: set[str]) -> str:
    """Resolve a fuzzy spec/epic ID against known IDs.

    Accepts prefixed IDs (S022, E007) and bare numbers (022, 7).
    """
    from nspec.ids import resolve_fuzzy_id

    return resolve_fuzzy_id(raw, known_ids)


def _scan_known_ids(docs_root: Path) -> set[str]:
    """Lightweight scan of FR/IMPL filenames to collect known spec IDs.

    Avoids full dataset parsing — just extracts IDs from filenames.
    """
    import re

    from nspec.paths import get_paths

    pattern = re.compile(r"^(?:FR|IMPL)-([ES]\d{3}[a-z]?)-", re.IGNORECASE)
    paths = get_paths(docs_root)
    ids: set[str] = set()
    for directory in [
        paths.active_frs_dir,
        paths.active_impls_dir,
        paths.completed_done,
        paths.completed_superseded,
        paths.completed_rejected,
    ]:
        if directory.exists():
            for f in directory.iterdir():
                m = pattern.match(f.name)
                if m:
                    ids.add(m.group(1).upper())
    return ids


def _resolve_id_from_disk(raw: str, docs_root: Path) -> str:
    """Resolve a fuzzy ID using a lightweight disk scan.

    Tries prefixed normalization first (no disk needed).
    Falls back to scanning filenames for bare-number resolution.
    """
    from nspec.ids import parse_bare_number, resolve_fuzzy_id

    # Fast path: prefixed IDs don't need disk scan
    try:
        return _normalize_id(raw)
    except ValueError:
        pass

    # Only scan disk if it looks like a bare number
    if parse_bare_number(raw) is None:
        raise ValueError(f"Invalid spec ref: {raw!r}")

    return resolve_fuzzy_id(raw, _scan_known_ids(docs_root))


def _invalid_id_error(raw: str) -> dict[str, Any]:
    return {
        "success": False,
        "error": f"Invalid ID: {raw!r} (expected E###, S###, or bare number)",
    }


def _tool_error(message: str) -> dict[str, Any]:
    result: dict[str, Any] = {"success": False, "error": message}
    # Attempt error capture using caller context
    _try_capture_from_frame(message, depth=2)
    return result


def _exception_error(exc: Exception) -> dict[str, Any]:
    """Convert an exception to a tool error dict, and attempt error capture."""
    result: dict[str, Any] = {"success": False, "error": str(exc)}
    _try_capture_from_frame(str(exc), depth=2)
    return result


def _try_capture_from_frame(error_message: str, *, depth: int = 2) -> None:
    """Extract tool name and docs_root from the call stack and attempt capture.

    Walks up the stack to find the first MCP tool function (skipping internal
    helpers like _tool_error, _exception_error, _invalid_id_error).
    Extracts `root` or `docs_root` from the caller's locals for correct
    project targeting.
    """
    import sys

    _skip = {"_tool_error", "_exception_error", "_invalid_id_error", "_try_capture_from_frame"}
    try:
        frame = sys._getframe(depth)
        # Walk up to find the actual MCP tool function
        while frame and frame.f_code.co_name in _skip:
            frame = frame.f_back
        if not frame:
            return
        caller_name = frame.f_code.co_name
        # Extract docs_root from caller's locals (standard name in MCP tools)
        local_vars = frame.f_locals
        docs_root = local_vars.get("root") or local_vars.get("docs_root")
        if isinstance(docs_root, str):
            docs_root = Path(docs_root)
        _capture_mcp_error(caller_name, error_message, docs_root)
    except (ValueError, AttributeError):
        pass


def _capture_mcp_error(
    tool_name: str,
    error_message: str,
    docs_root: Path | None = None,
) -> None:
    """Attempt to capture an MCP error as a spec via the error agent."""
    try:
        from nspec.config import _find_config_file
        from nspec.error_agent import ErrorContext, ErrorType, maybe_capture_error
        from nspec.session import StateDAO

        root = docs_root or Path("docs")

        # Derive project root by searching upward for config.toml
        # (don't assume the docs dir is named "docs")
        config_file = _find_config_file(root)
        project_root = config_file.parent.parent.parent if config_file else root.parent

        # Get active spec from session state (but NOT task — MCP errors
        # are not task-specific and shouldn't trigger auto-park)
        dao = StateDAO(project_root)
        state = dao.load()
        active_spec = state.spec_id if state else None

        ctx = ErrorContext(
            error_type=ErrorType.MCP,
            command_or_tool=tool_name,
            error_message=error_message,
            active_spec_id=active_spec,
            # active_task_id intentionally None: general MCP errors
            # shouldn't auto-park the active spec
        )
        maybe_capture_error(ctx, root)
    except Exception:
        pass  # Never break MCP tools for error capture


def _capture_test_gate_error(
    output: str,
    docs_root: Path | None = None,
    spec_id: str | None = None,
    task_id: str | None = None,
) -> None:
    """Attempt to capture a test gate failure as a spec via the error agent."""
    try:
        from nspec.error_agent import ErrorContext, ErrorType, maybe_capture_error

        ctx = ErrorContext(
            error_type=ErrorType.TEST_GATE,
            command_or_tool="make test-quick",
            exit_code=1,
            stdout=output,
            error_message="Test gate failed",
            active_spec_id=spec_id,
            active_task_id=task_id,
        )
        maybe_capture_error(ctx, docs_root)
    except Exception:
        pass  # Never break MCP tools for error capture


def _normalize_epic_id(
    raw: str, docs_root: Path | None = None
) -> tuple[str | None, dict[str, Any] | None]:
    """Normalize and validate an epic ID at the MCP boundary."""
    try:
        if docs_root is not None:
            epic_id = _resolve_id_from_disk(raw, docs_root)
        else:
            epic_id = _normalize_id(raw)
    except ValueError:
        return None, _invalid_id_error(raw)
    if not epic_id.upper().startswith("E"):
        return None, _tool_error(f"Invalid epic_id: {raw!r} (expected E###)")
    return epic_id, None


def _verify_epic_exists(*, epic_id: str, docs_root: Path) -> dict[str, Any] | None:
    """Verify that epic_id corresponds to a real Epic FR on disk.

    Uses a lightweight file scan (not a full dataset load) so create_spec can
    fail with a clear message even when unrelated specs are invalid.
    """
    import re

    from nspec.paths import get_paths

    paths = get_paths(docs_root)
    matches = sorted(paths.active_frs_dir.glob(f"FR-{epic_id}-*.md"))
    if not matches:
        return _tool_error(f"Epic {epic_id} not found in {paths.active_frs_dir}")

    try:
        content = matches[0].read_text()
    except OSError as e:
        return _tool_error(f"Failed to read epic file {matches[0]}: {e}")

    if not re.search(r"^\*\*Type:\*\*\s*Epic\b", content, re.MULTILINE):
        return _tool_error(
            f"{epic_id} is not an Epic (missing '**Type:** Epic' in {matches[0].name})"
        )

    return None


def _resolve_docs_root(docs_root: str | None = None) -> Path:
    """Resolve docs root path, defaulting to ./docs.

    Priority: explicit parameter > NSPEC_DOCS_ROOT env var > ./docs default.

    When no config.toml exists and no NSPEC_* env vars are set,
    silently creates a minimal config (MCP is non-interactive).
    Note: This does NOT create the full project structure — use the
    `init` tool for complete project initialization.

    Also applies configurable emojis from config.toml.
    """
    if docs_root:
        root = Path(docs_root)
    elif env_root := os.environ.get("NSPEC_DOCS_ROOT"):
        root = Path(env_root)
    else:
        root = Path("docs")
    resolved = root.resolve()
    logger.debug("docs_root: %s (resolved: %s, exists: %s)", root, resolved, resolved.exists())

    project_root = _resolve_project_root(root)
    try:
        from nspec.init import needs_init

        if needs_init(project_root):
            from nspec.config import NspecConfig

            # Only scaffold config — don't auto-create full project
            # User should explicitly call `init` tool for complete setup
            NspecConfig.scaffold(project_root)
    except OSError:
        pass  # Read-only filesystem or other I/O issue

    # Apply configurable emojis from config.toml
    try:
        from nspec.config import NspecConfig
        from nspec.statuses import configure as configure_statuses

        config = NspecConfig.load(project_root)
        configure_statuses(config.emojis)
    except Exception:
        pass  # Don't break MCP on config issues

    # Update last_activity timestamp on every MCP tool invocation (S120 audit trail)
    try:
        from nspec.session import StateDAO

        StateDAO(project_root).touch_activity()
    except Exception:
        pass  # Never break MCP tools for activity tracking

    return root


def _run_test_gate(*, cwd: Path | None = None) -> tuple[bool, str]:
    """Run make test-quick as a quality gate.

    Returns:
        (passed, output) tuple
    """
    # Load MCP timeout from config
    from nspec.config import NspecConfig

    _cfg = NspecConfig.load(cwd)
    _mcp_timeout = _cfg.timeouts.mcp_s

    try:
        result = subprocess.run(
            ["make", "test-quick"],
            capture_output=True,
            text=True,
            timeout=_mcp_timeout,
            cwd=str(cwd) if cwd else None,
        )
        passed = result.returncode == 0
        output = result.stdout + result.stderr
        return passed, output.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError) as e:
        return False, f"Test gate failed: {e}"


def _get_task_tag(spec_id: str, task_id: str, docs_root: Path) -> str:
    """Get the verification tag for a task, defaulting to 'code'.

    Loads the IMPL file, parses tasks, and finds the matching task
    to read its tag. Returns 'code' if task not found or no tag set.
    """
    from nspec.datasets import DatasetLoader
    from nspec.tasks import TaskParser

    try:
        loader = DatasetLoader(docs_root)
        datasets = loader.load()
        impl = datasets.get_impl(spec_id)
        if impl and impl.tasks:
            parser = TaskParser()
            flat = parser.flatten(impl.tasks)
            for task in flat:
                if task.id == task_id:
                    return task.effective_tag
    except Exception:
        pass
    return "code"


def _compute_task_progress(impl_path: Path) -> dict[str, Any]:
    """Read an IMPL file and return task progress counts.

    Returns dict with 'done', 'total', 'remaining' keys.
    """
    import re

    try:
        content = impl_path.read_text()
    except OSError:
        return {}

    done = len(re.findall(r"^\s*- \[x\]", content, re.MULTILINE))
    obsolete = len(re.findall(r"^\s*- \[~\]", content, re.MULTILINE))
    delegated = len(re.findall(r"^\s*- \[→", content, re.MULTILINE))
    pending = len(re.findall(r"^\s*- \[ \]", content, re.MULTILINE))
    total = done + obsolete + delegated + pending

    remaining: list[str] = []
    for line in content.split("\n"):
        if re.match(r"^\s*- \[ \]", line):
            remaining.append(line.strip().removeprefix("- [ ] "))

    return {
        "done": done + obsolete + delegated,
        "total": total,
        "remaining_tasks": remaining[:10],  # Cap at 10 to avoid huge responses
    }


def _find_epic_for_spec(spec_id: str, docs_root: Path) -> str | None:
    """Find which epic a spec belongs to by scanning active epic deps."""
    if spec_id.startswith("E"):
        return None
    try:
        from nspec.datasets import DatasetLoader

        loader = DatasetLoader(docs_root)
        datasets = loader.load()
        for epic_id, fr in datasets.active_frs.items():
            if fr.type != "Epic":
                continue
            if spec_id in (fr.deps or []):
                return epic_id
    except Exception:
        return None

    return None


# ---------------------------------------------------------------------------
# Query Tools
# ---------------------------------------------------------------------------


@mcp.tool()
def epics(docs_root: str | None = None) -> dict[str, Any]:
    """List all epics with progress tracking.

    Shows epic ID, priority, title, and completion percentages
    for specs grouped under each epic.

    Args:
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.reports import ReportContext, epic_summary_report

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)
    try:
        ctx = ReportContext.load(root, project_root=project_root)
        return epic_summary_report(ctx)
    except Exception as e:
        return _exception_error(e)


@mcp.tool()
def show(spec_id: str, docs_root: str | None = None) -> dict[str, Any]:
    """Show full details for a spec (FR + IMPL).

    Returns title, priority, status, acceptance criteria,
    tasks, dependencies, and completion progress.

    Args:
        spec_id: ID (e.g., "S004", "E001", or bare number like "004")
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.datasets import DatasetLoader

    root = _resolve_docs_root(docs_root)

    try:
        loader = DatasetLoader(root)
        datasets = loader.load()
    except Exception as e:
        return _exception_error(e)

    try:
        spec_id = _resolve_id(spec_id, datasets.all_spec_ids())
    except ValueError:
        return _invalid_id_error(spec_id)

    fr = datasets.get_fr(spec_id)
    impl = datasets.get_impl(spec_id)

    if not fr and not impl:
        return {"error": f"Spec {spec_id} not found"}

    result: dict[str, Any] = {"spec_id": spec_id}

    if fr:
        result["fr"] = {
            "title": fr.title,
            "priority": fr.priority,
            "status": fr.status,
            "deps": fr.deps,
            "ac_completion": fr.ac_completion_percent,
        }

    if impl:
        result["impl"] = {
            "status": impl.status,
            "loe": impl.loe,
            "completion": impl.completion_percent,
        }

    result["is_active"] = datasets.is_active(spec_id)
    return result


@mcp.tool()
def next_spec(epic_id: str | None = None, docs_root: str | None = None) -> dict[str, Any]:
    """Find the next spec to work on based on priority and blockers.

    Returns the highest-priority unblocked spec, optionally
    filtered to a specific epic.

    Args:
        epic_id: Optional epic ID to filter by
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.datasets import DatasetLoader
    from nspec.ordering import eligible_next_specs
    from nspec.reports import ReportContext, blockers_report

    root = _resolve_docs_root(docs_root)
    try:
        loader = DatasetLoader(root)
        datasets = loader.load()
    except Exception as e:
        return _exception_error(e)

    # Normalize epic_id if provided
    if epic_id:
        normalized, error = _normalize_epic_id(epic_id, root)
        if error:
            return error
        assert normalized is not None
        epic_id = normalized

        epic_fr = datasets.get_fr(epic_id)
        if not epic_fr:
            return _tool_error(f"Epic {epic_id} not found")
        if getattr(epic_fr, "type", None) != "Epic":
            return _tool_error(f"{epic_id} is not an Epic (missing **Type:** Epic)")

    # Get blocked spec IDs
    ctx = ReportContext(datasets=datasets, docs_root=root)
    blockers = blockers_report(ctx)
    blocked_ids: set[str] = set()
    for section in blockers.get("sections", []):
        if section.get("type") == "blockers":
            for b in section.get("data", []):
                blocked_ids.add(b["id"])

    candidates = eligible_next_specs(datasets, epic_id=epic_id, blocked_ids=blocked_ids)

    if not candidates:
        return {"message": "No unblocked specs found", "candidates": []}

    return {"next": candidates[0], "alternatives": candidates[1:5]}


@mcp.tool()
def get_epic(docs_root: str | None = None) -> dict[str, str | None]:
    """Get the currently active epic from .novabuilt.dev/nspec/state.json.

    Args:
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.session import StateDAO

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)
    dao = StateDAO(project_root)
    try:
        epic = dao.get_active_epic()
    except Exception as e:
        return {"active_epic": None, "error": str(e)}
    if epic:
        return {"active_epic": epic}
    return {"active_epic": None, "message": "No active epic set"}


@mcp.tool()
def validate(docs_root: str | None = None) -> dict[str, Any]:
    """Run the 6-layer validation engine on all specs.

    Checks format, existence, dependencies, business logic,
    and ordering across all FR and IMPL documents.

    Args:
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.validator import NspecValidator

    root = _resolve_docs_root(docs_root)

    # Read enforce_epic_grouping from config
    strict_mode = False
    try:
        from nspec.config import NspecConfig

        project_root = _resolve_project_root(root)
        config = NspecConfig.load(project_root)
        strict_mode = config.validation.enforce_epic_grouping
    except Exception:
        pass

    validator = NspecValidator(root, strict_mode=strict_mode)
    try:
        success, errors = validator.validate()
    except Exception as e:
        return {"valid": False, "error_count": 1, "errors": [str(e)], "structured_errors": []}

    structured = [
        {
            "layer": ve.layer,
            "message": ve.message,
            "spec_id": ve.spec_id,
            "severity": ve.severity,
            "code": ve.code,
        }
        for ve in getattr(validator, "structured_errors", [])[:50]
    ]

    return {
        "valid": success,
        "error_count": len(errors),
        "errors": errors[:50],  # Cap at 50 to avoid huge responses
        "structured_errors": structured,
    }


@mcp.tool()
def estimate_loe(spec_id: str, docs_root: str | None = None) -> dict[str, Any]:
    """Estimate Level of Effort for a spec.

    Computes a weighted score from task structure, dependency count,
    and complexity signals. Uses historical data for calibration
    when enough completed specs exist.

    Args:
        spec_id: Spec ID to estimate (e.g., "S004")
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.config import NspecConfig
    from nspec.datasets import DatasetLoader
    from nspec.ids import normalize_spec_ref
    from nspec.loe import LoeWeights, estimate_spec_loe

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)

    try:
        config = NspecConfig.load(project_root)
    except Exception:
        config = NspecConfig()

    try:
        spec_id = normalize_spec_ref(spec_id)
    except (ValueError, KeyError):
        return {"success": False, "error": f"Invalid spec ID: {spec_id}"}

    loader = DatasetLoader(docs_root=root, project_root=project_root)
    datasets = loader.load()

    fr = datasets.get_fr(spec_id)
    impl = datasets.get_impl(spec_id)
    if fr is None:
        return {"success": False, "error": f"FR not found for {spec_id}"}
    if impl is None:
        return {"success": False, "error": f"IMPL not found for {spec_id}"}

    weights = LoeWeights(
        task_count=config.loe.weight_task_count,
        max_depth=config.loe.weight_max_depth,
        nested_ratio=config.loe.weight_nested_ratio,
        dep_count=config.loe.weight_dep_count,
        complexity_signal=config.loe.weight_complexity_signal,
        min_history_specs=config.loe.min_history_specs,
    )

    try:
        estimate = estimate_spec_loe(
            spec_id=spec_id,
            fr=fr,
            impl=impl,
            weights=weights,
            completed_impls=datasets.completed_impls,
            completed_frs=datasets.completed_frs,
        )
        result = estimate.to_dict()
        result["success"] = True
        return result
    except Exception as e:
        return _exception_error(e)


@mcp.tool()
def session_start(spec_id: str, docs_root: str | None = None) -> str:
    """Initialize a work session for a spec.

    Shows where work left off, pending tasks, blockers,
    and suggested first action.

    Args:
        spec_id: Spec ID to start working on
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.session import initialize_session

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return f"❌ Invalid ID: {spec_id!r} (expected E###, S###, or bare number)"
    try:
        result = initialize_session(spec_id, root)
        # Reset error agent session counter at session start
        try:
            from nspec.error_agent import reset_session_counter

            reset_session_counter()
        except Exception:
            pass
        return result
    except Exception as e:
        return f"❌ {e}"


# ---------------------------------------------------------------------------
# Mutation Tools
# ---------------------------------------------------------------------------


@mcp.tool()
def task_complete(
    spec_id: str,
    task_id: str,
    marker: str = "x",
    run_tests: bool = False,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Mark an IMPL task as complete.

    By default skips the test gate for fast feedback. The caller
    (e.g. the /loop skill) is expected to run ``make test-quick``
    via Bash where output streams to the terminal.
    Set run_tests=True to run the test gate inside this tool.

    Args:
        spec_id: ID (e.g., "S004")
        task_id: Task number (e.g., "1", "2.1", "dod-1")
        marker: "x" for complete, "~" for obsolete
        run_tests: Run test gate before marking (default: False)
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.crud import check_impl_task
    from nspec.tasks import VERIFICATION_ROUTES

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)
    project_root = _resolve_project_root(root)

    # Check task tag to determine verification route
    task_tag = _get_task_tag(spec_id, task_id, root)
    should_run_tests, verification_hint = VERIFICATION_ROUTES.get(
        task_tag, VERIFICATION_ROUTES["code"]
    )

    if run_tests and should_run_tests:
        passed, output = _run_test_gate(cwd=project_root)
        if not passed:
            _capture_test_gate_error(output, root, spec_id, task_id)
            return {
                "success": False,
                "reason": "Test gate failed — task not marked",
                "test_output": output[-2000:],  # Last 2000 chars
            }

    from nspec.locks import spec_lock

    try:
        with spec_lock(spec_id):
            path = check_impl_task(spec_id, task_id, root, marker=marker)
    except TimeoutError:
        return {
            "success": False,
            "error": f"Could not acquire lock for {spec_id}",
            "hint": "Another process may be operating on this spec. Try again shortly.",
        }
    except Exception as e:
        return _exception_error(e)

    # Compute progress from the updated file
    progress = _compute_task_progress(path)

    result: dict[str, Any] = {
        "success": True,
        "path": str(path),
        "task_id": task_id,
        "marker": marker,
        "tag": task_tag,
        "verification": verification_hint,
        **progress,
    }

    if progress.get("done") == progress.get("total") and progress.get("total", 0) > 0:
        result["next_action"] = (
            f"All {progress['total']} tasks complete. "
            "Call criteria_complete for any remaining ACs, then advance to move to Testing."
        )

    return result


@mcp.tool()
def criteria_complete(
    spec_id: str,
    criteria_id: str,
    marker: str = "x",
    run_tests: bool = False,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Mark an acceptance criterion as complete in the FR file.

    By default skips the test gate for fast feedback. The caller
    (e.g. the /loop skill) is expected to run ``make test-quick``
    via Bash where output streams to the terminal.
    Set run_tests=True to run the test gate inside this tool.

    Args:
        spec_id: ID (e.g., "S004")
        criteria_id: Criterion ID (e.g., "AC-F1", "AC-Q2")
        marker: "x" for complete, "~" for obsolete
        run_tests: Run test gate before marking (default: False)
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.crud import check_acceptance_criteria

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)
    project_root = _resolve_project_root(root)

    if run_tests:
        passed, output = _run_test_gate(cwd=project_root)
        if not passed:
            _capture_test_gate_error(output, root, spec_id)
            return {
                "success": False,
                "reason": "Test gate failed — criterion not marked",
                "test_output": output[-2000:],
            }

    from nspec.locks import spec_lock

    try:
        with spec_lock(spec_id):
            path = check_acceptance_criteria(spec_id, criteria_id, root, marker=marker)
    except TimeoutError:
        return {
            "success": False,
            "error": f"Could not acquire lock for {spec_id}",
            "hint": "Another process may be operating on this spec. Try again shortly.",
        }
    except Exception as e:
        return _exception_error(e)
    return {
        "success": True,
        "path": str(path),
        "criteria_id": criteria_id,
        "marker": marker,
    }


@mcp.tool()
def activate(spec_id: str, docs_root: str | None = None) -> dict[str, Any]:
    """Activate a spec by advancing its status and writing state.json.

    Sets IMPL to Active and FR to Active, and persists the spec ID
    to .novabuilt.dev/nspec/state.json for tool integration.

    Args:
        spec_id: Spec ID to activate
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.crud import set_status
    from nspec.locks import spec_lock
    from nspec.session import StateDAO

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)
    project_root = _resolve_project_root(root)

    try:
        with spec_lock(spec_id):
            # Set FR=Active(2), IMPL=Active(1)
            fr_path, impl_path = set_status(spec_id, 2, 1, root)
    except TimeoutError:
        return {
            "success": False,
            "error": f"Could not acquire lock for {spec_id}",
            "hint": "Another process may be operating on this spec. Try again shortly.",
        }
    except Exception as e:
        return _exception_error(e)

    # Persist session context to state.json
    dao = StateDAO(project_root)
    try:
        if spec_id.startswith("E"):
            dao.set_active_epic(spec_id)
            dao.set_spec_id("")
            epic_id = spec_id
        else:
            dao.set_spec_id(spec_id)
            epic_id = _find_epic_for_spec(spec_id, root)
            if epic_id:
                with contextlib.suppress(Exception):
                    dao.set_active_epic(epic_id)
    except Exception as e:
        return _exception_error(e)

    return {
        "success": True,
        "spec_id": spec_id,
        "epic_id": epic_id,
        "fr_path": str(fr_path),
        "impl_path": str(impl_path),
    }


@mcp.tool()
def advance(spec_id: str, docs_root: str | None = None) -> dict[str, Any]:
    """Advance a spec to the next logical status.

    Progresses IMPL through: Planning -> Active -> Testing -> Ready.
    Also auto-upgrades FR status when appropriate.

    Args:
        spec_id: Spec ID to advance
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.crud import next_status
    from nspec.locks import spec_lock

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)
    try:
        with spec_lock(spec_id):
            fr_path, impl_path = next_status(spec_id, root)
    except TimeoutError:
        return {
            "success": False,
            "error": f"Could not acquire lock for {spec_id}",
            "hint": "Another process may be operating on this spec. Try again shortly.",
        }
    except ValueError as e:
        error_msg = str(e)
        # Provide structured hints for terminal states
        if "already Ready" in error_msg:
            return {
                "success": False,
                "error": "IMPL already Ready (3) - use complete() to archive",
                "hint": f"Use complete(spec_id='{spec_id}') to archive this spec.",
            }
        if "Paused" in error_msg:
            return {
                "success": False,
                "error": error_msg,
                "hint": f"Use activate(spec_id='{spec_id}') to resume the spec, then advance.",
            }
        if "Exception" in error_msg:
            return {
                "success": False,
                "error": error_msg,
                "hint": "This spec requires human triage before it can proceed.",
            }
        return _exception_error(e)
    except Exception as e:
        return _exception_error(e)
    return {
        "success": True,
        "spec_id": spec_id,
        "fr_path": str(fr_path),
        "impl_path": str(impl_path),
    }


@mcp.tool()
def execute_codex(
    prompt: str,
    timeout: int | None = None,
    model: str | None = None,
    reasoning_effort: str | None = None,
    sandbox: str | None = None,
    approval_policy: str | None = None,
    flags: list[str] | None = None,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Execute a prompt via the Codex CLI subprocess.

    Spawns the codex binary via tmux (preferred) or subprocess (fallback)
    with self-managed timeout.

    Args:
        prompt: The prompt text to send to codex.
        timeout: Timeout in seconds (default: from [codex] config or 600).
        model: Model override (default: from [codex] config or "gpt-5.3-codex").
        reasoning_effort: Reasoning effort override (default: [codex].reasoning_effort).
        sandbox: Sandbox mode override (default: [codex].sandbox).
        approval_policy: Approval policy override (default: [codex].approval_policy).
        flags: Extra codex CLI flags (default: [codex].flags).
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.config import NspecConfig
    from nspec.executor import CodexTmuxExecutor

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)

    try:
        config = NspecConfig.load(project_root)
    except Exception:
        config = NspecConfig()

    executor = CodexTmuxExecutor(
        model=config.codex.model,
        reasoning_effort=config.codex.reasoning_effort,
        sandbox=config.codex.sandbox,
        approval_policy=config.codex.approval_policy,
        flags=config.codex.flags,
        default_timeout=config.codex.timeout,
        poll_interval=config.codex.poll_interval,
        session_prefix=config.codex.session_prefix,
    )

    kwargs: dict[str, Any] = {}
    if model is not None:
        kwargs["model"] = model
    if reasoning_effort is not None:
        kwargs["reasoning_effort"] = reasoning_effort
    if sandbox is not None:
        kwargs["sandbox"] = sandbox
    if approval_policy is not None:
        kwargs["approval_policy"] = approval_policy
    if flags is not None:
        kwargs["flags"] = flags

    result = executor.execute(
        prompt,
        timeout=timeout or 0,
        **kwargs,
    )

    return {
        "success": result.success,
        "output": result.output,
        "error": result.error,
        "duration_s": result.duration_s,
    }


@mcp.tool()
def codex_review(
    spec_id: str,
    docs_root: str | None = None,
    model: str | None = None,
    reasoning_effort: str | None = None,
    uncommitted: bool = False,
    base_branch: str | None = None,
    commit_sha: str | None = None,
    prompt_only: bool = False,
) -> dict[str, Any]:
    """Generate a review prompt for a spec to use with execute_codex().

    Returns a structured review prompt containing FR acceptance criteria,
    IMPL task list, and git diff. Pass the returned prompt to
    ``execute_codex(prompt=...)`` to execute the review.

    This tool is REQUIRED before calling complete(). The complete() tool
    will refuse to archive a spec without an APPROVED review verdict.

    Args:
        spec_id: Spec ID to review (e.g., "S020")
        docs_root: Path to docs directory (default: ./docs)
        model: Unused, kept for backward compatibility
        reasoning_effort: Unused, kept for backward compatibility
        uncommitted: Review staged and unstaged changes against HEAD (default: False)
        base_branch: Review changes against this branch
        commit_sha: Review changes from a specific commit
        prompt_only: Unused, kept for backward compatibility (always returns prompt)
    """
    from nspec.review import prepare_mcp_review

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)

    try:
        request = prepare_mcp_review(
            spec_id,
            root,
            uncommitted=uncommitted,
            base_branch=base_branch,
            commit_sha=commit_sha,
        )

        # Issue a single-use review token to prove the flow went through codex_review()
        from nspec.review import generate_review_token

        project_root = _resolve_project_root(root)
        token = generate_review_token(spec_id, project_root)

        return {
            "success": True,
            "spec_id": spec_id,
            "prompt_only": True,
            "prompt": request.prompt,
            "review_token": token,
            "hint": (
                "Pass this prompt to execute_codex(prompt=...) to execute the review. "
                "Then call write_review_verdict with the review_token from this response."
            ),
        }
    except Exception as e:
        return _exception_error(e)


@mcp.tool()
def write_review_verdict(
    spec_id: str,
    verdict: str,
    feedback: str | None = None,
    reviewer: str = "codex",
    implementer: str = "claude",
    review_token: str | None = None,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Write a review verdict to the IMPL file.

    Use this tool after obtaining a review verdict from codex-cli MCP
    (via execute_codex). This separates prompt generation and
    verdict writing from the actual review execution, enabling flexible
    review backends.

    **Anti-rubber-stamping guards:**
    - A ``review_token`` (from ``codex_review()``) is required. This proves
      the review flow was initiated through the proper channel.
    - Self-review is blocked: the reviewer name must not match or contain
      the implementer name, and known self-review patterns are rejected.

    Typical workflow with codex-cli MCP:
    1. Call codex_review(spec_id, base_branch="main") to get the review prompt and review_token
    2. Call execute_codex(prompt=...) to execute the review
    3. Parse the response content for P-level findings (P0/P1 → NEEDS_WORK) or "VERDICT:" line
    4. Call this tool with the review_token from step 1

    Args:
        spec_id: Spec ID (e.g., "S020")
        verdict: "APPROVED" or "NEEDS_WORK"
        feedback: Optional feedback text (shown in IMPL findings section)
        reviewer: Reviewer name (default: "codex")
        implementer: Implementer name (default: "claude")
        review_token: Single-use token from codex_review() (required)
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.review import (
        ReviewVerdict,
        consume_review_token,
        is_self_review,
        write_review_to_impl,
    )

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)

    # --- Guard 1: Self-review blocklist ---
    if is_self_review(reviewer, implementer):
        return {
            "success": False,
            "spec_id": spec_id,
            "error": (
                f"Self-review blocked: reviewer '{reviewer}' matches "
                f"implementer '{implementer}'. Use an external reviewer."
            ),
            "hint": "Call codex_review() first, then pass the review_token to this tool.",
        }

    # --- Guard 2: Review token required ---
    if not review_token:
        return {
            "success": False,
            "spec_id": spec_id,
            "error": "review_token is required. Call codex_review() first to get a token.",
            "hint": (
                "Workflow: codex_review(spec_id) → execute_codex(prompt=...) → "
                "write_review_verdict(spec_id, verdict, review_token=token)"
            ),
        }

    # --- Guard 3: Token must be valid and unused ---
    project_root = _resolve_project_root(root)
    if not consume_review_token(spec_id, review_token, project_root):
        return {
            "success": False,
            "spec_id": spec_id,
            "error": "Invalid or already-used review_token.",
            "hint": "Each token is single-use. Call codex_review() again to get a new token.",
        }

    # Validate verdict
    verdict_upper = verdict.upper()
    if verdict_upper not in ("APPROVED", "NEEDS_WORK"):
        return {
            "success": False,
            "spec_id": spec_id,
            "error": f"Invalid verdict: {verdict}. Must be APPROVED or NEEDS_WORK.",
        }

    # Create ReviewVerdict and write to IMPL
    review_verdict = ReviewVerdict(
        verdict=verdict_upper,
        feedback=feedback or "",
        raw_output="",  # No raw output when using MCP backend
    )

    from nspec.locks import spec_lock

    try:
        with spec_lock(spec_id):
            impl_path = write_review_to_impl(
                spec_id,
                review_verdict,
                reviewer,
                implementer,
                root,
            )
    except TimeoutError:
        return {
            "success": False,
            "error": f"Could not acquire lock for {spec_id}",
            "hint": "Another process may be operating on this spec. Try again shortly.",
        }
    except Exception as e:
        return _exception_error(e)

    return {
        "success": True,
        "spec_id": spec_id,
        "verdict": verdict_upper,
        "reviewer": reviewer,
        "implementer": implementer,
        "impl_path": str(impl_path),
    }


@mcp.tool()
def codex_refine(
    spec_id: str,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Check if an IMPL is a skeleton and generate a refinement prompt.

    Detects template placeholder tasks in the IMPL file. If the IMPL is
    a skeleton, returns a prompt for Codex to generate real tasks.
    If the IMPL already has real tasks, returns `{is_skeleton: False}`.

    Typical workflow:
    1. Call codex_refine(spec_id) to check and get the prompt
    2. If is_skeleton is True, call execute_codex(prompt=...)
    3. Call write_refinement(spec_id, codex_output) with the response content

    Args:
        spec_id: Spec ID to check/refine (e.g., "S077")
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.refine import generate_refinement_prompt, is_skeleton_impl

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)

    try:
        from nspec.crud import _find_impl_file

        impl_path = _find_impl_file(spec_id, root)
        impl_content = impl_path.read_text()
    except FileNotFoundError:
        return _tool_error(f"IMPL file not found for {spec_id}")

    if not is_skeleton_impl(impl_content):
        return {
            "success": True,
            "spec_id": spec_id,
            "is_skeleton": False,
            "message": f"IMPL for {spec_id} already has real tasks — no refinement needed.",
        }

    try:
        prompt = generate_refinement_prompt(spec_id, root)
        return {
            "success": True,
            "spec_id": spec_id,
            "is_skeleton": True,
            "prompt": prompt.prompt_text,
            "hint": (
                "Use this prompt with execute_codex(prompt=...) or "
                "mcp__codex__codex(prompt=...) if Codex MCP is configured. "
                "Then call write_refinement with the response content."
            ),
        }
    except Exception as e:
        return _exception_error(e)


@mcp.tool()
def write_refinement(
    spec_id: str,
    codex_output: str,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Write Codex refinement output to the IMPL file.

    Parses the Codex output for refined tasks (between TASKS_START/TASKS_END),
    executive summary, and LOE, then writes them to the IMPL.

    Use this after calling execute_codex(prompt=...) with the prompt
    from codex_refine(). Pass the response content as codex_output.

    Args:
        spec_id: Spec ID (e.g., "S077")
        codex_output: Raw text output (content field) from codex response
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.refine import parse_refinement_result, write_refinement_to_impl

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)

    # Parse the Codex output
    result = parse_refinement_result(codex_output)
    if result is None:
        return {
            "success": False,
            "spec_id": spec_id,
            "error": (
                "Could not parse refinement output. "
                "Expected TASKS_START/TASKS_END delimiters in Codex response."
            ),
        }

    from nspec.locks import spec_lock

    try:
        with spec_lock(spec_id):
            impl_path = write_refinement_to_impl(spec_id, result, root)
    except TimeoutError:
        return {
            "success": False,
            "error": f"Could not acquire lock for {spec_id}",
            "hint": "Another process may be operating on this spec. Try again shortly.",
        }
    except Exception as e:
        return _exception_error(e)

    # Count tasks in refined output
    import re

    task_count = len(re.findall(r"^\s*- \[ \]", result.tasks_markdown, re.MULTILINE))

    return {
        "success": True,
        "spec_id": spec_id,
        "impl_path": str(impl_path),
        "task_count": task_count,
        "loe": result.loe,
        "executive_summary": result.executive_summary,
    }


@mcp.tool()
def codex_refine_fr(
    spec_id: str,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Check if an FR is a skeleton and generate an authoring prompt.

    Detects template placeholder content in the FR file. If the FR is
    a skeleton, returns a prompt for Codex to author real FR content.
    If the FR already has real content, returns `{is_skeleton: False}`.

    Typical workflow:
    1. Call codex_refine_fr(spec_id) to check and get the prompt
    2. If is_skeleton is True, call execute_codex(prompt=...)
    3. Call write_fr_refinement(spec_id, codex_output) with the response content

    Args:
        spec_id: Spec ID to check/refine (e.g., "S129")
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.refine import generate_fr_refinement_prompt, is_skeleton_fr

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)

    try:
        from nspec.paths import get_paths

        paths = get_paths(root)
        fr_files = list(paths.active_frs_dir.glob(f"FR-{spec_id}-*.md"))
        if not fr_files:
            return _tool_error(f"FR file not found for {spec_id}")
        fr_content = fr_files[0].read_text()
    except FileNotFoundError:
        return _tool_error(f"FR file not found for {spec_id}")

    if not is_skeleton_fr(fr_content):
        return {
            "success": True,
            "spec_id": spec_id,
            "is_skeleton": False,
            "message": f"FR for {spec_id} already has real content — no authoring needed.",
        }

    try:
        prompt = generate_fr_refinement_prompt(spec_id, root)
        return {
            "success": True,
            "spec_id": spec_id,
            "is_skeleton": True,
            "prompt": prompt.prompt_text,
            "hint": (
                "Use this prompt with execute_codex(prompt=...) or "
                "mcp__codex__codex(prompt=...) if Codex MCP is configured. "
                "Then call write_fr_refinement with the response content."
            ),
        }
    except Exception as e:
        return _exception_error(e)


@mcp.tool()
def write_fr_refinement(
    spec_id: str,
    codex_output: str,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Write Codex FR authoring output to the FR file.

    Parses the Codex output for authored FR content (between FR_START/FR_END),
    then writes it to the FR file, replacing template placeholders.

    Use this after calling execute_codex(prompt=...) with the prompt
    from codex_refine_fr(). Pass the response content as codex_output.

    Args:
        spec_id: Spec ID (e.g., "S129")
        codex_output: Raw text output (content field) from codex response
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.refine import parse_fr_refinement_result
    from nspec.refine import write_fr_refinement as _write_fr_refinement

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)

    # Parse the Codex output
    result = parse_fr_refinement_result(codex_output)
    if result is None:
        return {
            "success": False,
            "spec_id": spec_id,
            "error": (
                "Could not parse FR authoring output. "
                "Expected FR_START/FR_END delimiters in Codex response."
            ),
        }

    from nspec.locks import spec_lock

    try:
        with spec_lock(spec_id):
            fr_path = _write_fr_refinement(spec_id, result, root)
    except TimeoutError:
        return {
            "success": False,
            "error": f"Could not acquire lock for {spec_id}",
            "hint": "Another process may be operating on this spec. Try again shortly.",
        }
    except Exception as e:
        return _exception_error(e)

    return {
        "success": True,
        "spec_id": spec_id,
        "fr_path": str(fr_path),
    }


def _complete_inner(
    spec_id: str,
    root: Path,
    project_root: Path | None,
    normalize_spec_ref: Any,
    get_paths: Any,
    _find_impl_file: Any,
    extract_verdict_from_impl: Any,
    complete_spec: Any,
    clear_session: Any,
) -> dict[str, Any]:
    """Inner logic for complete(), called under spec_lock."""
    paths = get_paths(root, project_root=project_root)
    normalized_id = normalize_spec_ref(spec_id)
    fr_pattern = f"FR-{normalized_id}-*.md"
    impl_pattern = f"IMPL-{normalized_id}-*.md"
    completed_frs = list(paths.completed_done.glob(fr_pattern))
    completed_impls = list(paths.completed_done.glob(impl_pattern))
    active_frs = list(paths.active_frs_dir.glob(fr_pattern))
    active_impls = list(paths.active_impls_dir.glob(impl_pattern))

    if completed_frs and completed_impls and not active_frs and not active_impls:
        return {
            "success": True,
            "spec_id": spec_id,
            "already_completed": True,
            "message": f"Spec {spec_id} is already completed",
            "fr_path": str(completed_frs[0]),
            "impl_path": str(completed_impls[0]),
        }

    # Partial completion state detection (corrupt state from interrupted operations)
    if completed_frs and not completed_impls:
        return {
            "success": False,
            "error": f"Corrupt state detected for {spec_id}",
            "details": "FR is in completed/done but IMPL is not",
            "fr_path": str(completed_frs[0]),
            "hint": (
                "Manual remediation required: either move IMPL to completed/done "
                "or move FR back to active and re-run completion."
            ),
        }
    if completed_impls and not completed_frs:
        return {
            "success": False,
            "error": f"Corrupt state detected for {spec_id}",
            "details": "IMPL is in completed/done but FR is not",
            "impl_path": str(completed_impls[0]),
            "hint": (
                "Manual remediation required: either move FR to completed/done "
                "or move IMPL back to active and re-run completion."
            ),
        }

    # Check review verdict before completing
    try:
        impl_path = _find_impl_file(spec_id, root, project_root=project_root)
        impl_content = impl_path.read_text()
        verdict = extract_verdict_from_impl(impl_content)
    except FileNotFoundError:
        return {"success": False, "error": f"IMPL file not found for {spec_id}"}
    except (OSError, UnicodeDecodeError) as e:
        return _exception_error(e)

    if verdict != "APPROVED":
        if verdict is None:
            return {
                "success": False,
                "error": f"Cannot complete {spec_id} — no review verdict found",
                "hint": f"Run `/review {spec_id}` to request Codex review before completion.",
            }
        else:
            return {
                "success": False,
                "error": f"Cannot complete {spec_id} — review verdict is {verdict}",
                "hint": f"Run `/review {spec_id}` to request a new review after fixing.",
            }

    try:
        fr_old, fr_new, impl_old, impl_new = complete_spec(spec_id, root)
    except Exception as e:
        return _exception_error(e)

    # Auto-clear session state on spec completion
    with contextlib.suppress(Exception):
        clear_session(project_root)

    # Post-completion doc generation (non-fatal)
    docgen_info: dict[str, Any] | None = None
    try:
        from nspec.config import NspecConfig
        from nspec.docgen import generate_docs

        cfg = NspecConfig.load(project_root)
        if cfg.docs.enabled:
            docgen_result = generate_docs(spec_id, root, project_root=project_root, config=cfg)
            docgen_info = {
                "success": docgen_result.success,
                "target": docgen_result.target,
            }
            if docgen_result.error:
                docgen_info["error"] = docgen_result.error
    except Exception as exc:
        logger.warning("Post-completion docgen failed for %s: %s", spec_id, exc)
        docgen_info = {"success": False, "error": str(exc)}

    result: dict[str, Any] = {
        "success": True,
        "spec_id": spec_id,
        "fr_moved": f"{fr_old} -> {fr_new}",
        "impl_moved": f"{impl_old} -> {impl_new}",
    }
    if docgen_info is not None:
        result["docgen"] = docgen_info
    return result


@mcp.tool()
def complete(spec_id: str, docs_root: str | None = None) -> dict[str, Any]:
    """Complete a spec and archive it to completed/done.

    Validates that all acceptance criteria and tasks are checked
    before archiving. Also requires an APPROVED review verdict.

    Args:
        spec_id: Spec ID to complete
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.crud import _find_impl_file, complete_spec, normalize_spec_ref
    from nspec.locks import spec_lock
    from nspec.paths import get_paths
    from nspec.review import extract_verdict_from_impl
    from nspec.session import clear_session

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)
    project_root = _resolve_project_root(root)

    # Acquire per-spec lock to prevent parallel agents from completing simultaneously
    try:
        with spec_lock(spec_id):
            return _complete_inner(
                spec_id,
                root,
                project_root,
                normalize_spec_ref,
                get_paths,
                _find_impl_file,
                extract_verdict_from_impl,
                complete_spec,
                clear_session,
            )
    except TimeoutError:
        return {
            "success": False,
            "error": f"Could not acquire lock for {spec_id}",
            "hint": "Another process may be operating on this spec. Try again shortly.",
        }


@mcp.tool()
def cheap_docs(spec_id: str, docs_root: str | None = None) -> dict[str, Any]:
    """Generate documentation for a spec using a low-reasoning agent.

    Runs the same docgen pipeline as post-completion (template rendering +
    agent invocation + target write) without requiring the spec to be archived.
    Useful for on-demand doc generation at any point.

    Requires ``[docs].enabled = true`` in config.toml.

    Args:
        spec_id: Spec ID to generate docs for (e.g., "S092")
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.config import NspecConfig
    from nspec.docgen import generate_docs

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)
    project_root = _resolve_project_root(root)

    cfg = NspecConfig.load(project_root)
    if not cfg.docs.enabled:
        return {
            "success": False,
            "error": "Doc generation is disabled",
            "hint": "Set [docs].enabled = true in .novabuilt.dev/nspec/config.toml",
        }

    result = generate_docs(spec_id, root, project_root=project_root, config=cfg)
    return {
        "success": result.success,
        "spec_id": spec_id,
        "target": result.target,
        "error": result.error,
    }


@mcp.tool()
def supersede(
    spec_id: str,
    superseded_by: str,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Supersede a spec and archive it to completed/superseded.

    Moves FR+IMPL to completed/superseded/, sets FR status to Superseded,
    records the replacing spec ID. Does NOT require completion readiness —
    a spec can be superseded at any stage.

    Args:
        spec_id: Spec ID to supersede (e.g., "S027")
        superseded_by: Spec/epic ID that replaces this one (e.g., "E002")
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.crud import supersede_spec
    from nspec.locks import spec_lock
    from nspec.session import clear_session, load_session

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)
    project_root = _resolve_project_root(root)

    try:
        with spec_lock(spec_id):
            try:
                fr_old, fr_new, impl_old, impl_new = supersede_spec(
                    spec_id, superseded_by, root, project_root=project_root
                )
            except Exception as e:
                return _exception_error(e)

            # Only clear session state if the superseded spec was the active one
            with contextlib.suppress(Exception):
                session = load_session(project_root)
                if session and session.spec_id == spec_id:
                    clear_session(project_root)

            return {
                "success": True,
                "spec_id": spec_id,
                "superseded_by": superseded_by,
                "fr_moved": f"{fr_old} -> {fr_new}",
                "impl_moved": f"{impl_old} -> {impl_new}",
            }
    except TimeoutError:
        return {
            "success": False,
            "error": f"Could not acquire lock for {spec_id}",
            "hint": "Another process may be operating on this spec. Try again shortly.",
        }


@mcp.tool()
def task_block(
    spec_id: str,
    task_id: str,
    reason: str,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Mark an IMPL task as blocked with a reason.

    Inserts a BLOCKED marker line after the task in the IMPL file.

    Args:
        spec_id: ID (e.g., "S004")
        task_id: Task number (e.g., "1", "2.1")
        reason: Why the task is blocked
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.crud import set_task_blocked
    from nspec.locks import spec_lock

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)
    try:
        with spec_lock(spec_id):
            path = set_task_blocked(spec_id, task_id, reason, root)
    except TimeoutError:
        return {
            "success": False,
            "error": f"Could not acquire lock for {spec_id}",
            "hint": "Another process may be operating on this spec. Try again shortly.",
        }
    except Exception as e:
        return _exception_error(e)
    return {
        "success": True,
        "path": str(path),
        "task_id": task_id,
        "reason": reason,
    }


@mcp.tool()
def task_unblock(
    spec_id: str,
    task_id: str,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Remove the BLOCKED marker from an IMPL task.

    Args:
        spec_id: ID (e.g., "S004")
        task_id: Task number (e.g., "1", "2.1")
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.crud import set_task_unblocked
    from nspec.locks import spec_lock

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)
    try:
        with spec_lock(spec_id):
            path = set_task_unblocked(spec_id, task_id, root)
    except TimeoutError:
        return {
            "success": False,
            "error": f"Could not acquire lock for {spec_id}",
            "hint": "Another process may be operating on this spec. Try again shortly.",
        }
    except Exception as e:
        return _exception_error(e)
    return {
        "success": True,
        "path": str(path),
        "task_id": task_id,
    }


@mcp.tool()
def park(
    spec_id: str,
    reason: str | None = None,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Park a spec by setting IMPL status to Paused.

    Use this when a spec is blocked and cannot proceed.

    Args:
        spec_id: Spec ID to park
        reason: Optional reason for parking
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.crud import park_spec
    from nspec.locks import spec_lock

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)
    try:
        with spec_lock(spec_id):
            fr_path, impl_path = park_spec(spec_id, root, reason=reason)
    except TimeoutError:
        return {
            "success": False,
            "error": f"Could not acquire lock for {spec_id}",
            "hint": "Another process may be operating on this spec. Try again shortly.",
        }
    except Exception as e:
        return _exception_error(e)
    result: dict[str, Any] = {
        "success": True,
        "spec_id": spec_id,
        "fr_path": str(fr_path),
        "impl_path": str(impl_path),
    }
    if reason:
        result["reason"] = reason
    return result


@mcp.tool()
def exception(
    spec_id: str,
    reason: str,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Set spec to Exception state for human triage.

    Use when:
    - Subagent timeout
    - Unexpected failure mode
    - Guardrail violation detected

    Exception is distinct from Paused - it indicates something went wrong
    that requires human investigation, not just temporary blocking.

    Args:
        spec_id: Spec ID to set to exception state
        reason: Why the spec entered exception state (required)
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.crud import set_exception
    from nspec.locks import spec_lock

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)
    try:
        with spec_lock(spec_id):
            impl_path = set_exception(spec_id, root, reason=reason)
    except TimeoutError:
        return {
            "success": False,
            "error": f"Could not acquire lock for {spec_id}",
            "hint": "Another process may be operating on this spec. Try again shortly.",
        }
    except Exception as e:
        return _exception_error(e)
    return {
        "success": True,
        "spec_id": spec_id,
        "impl_path": str(impl_path),
        "reason": reason,
        "status": "⚠️ Exception",
    }


@mcp.tool()
def blocked_specs(
    docs_root: str | None = None,
) -> dict[str, Any]:
    """List specs that have blocked tasks, are paused, or in exception state.

    Scans active IMPLs for BLOCKED task markers, Paused status, and
    Exception status. For Exception specs, extracts the reason from
    IMPL Execution Notes.

    Args:
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.datasets import DatasetLoader

    root = _resolve_docs_root(docs_root)
    try:
        loader = DatasetLoader(root)
        datasets = loader.load()
    except Exception as e:
        return _exception_error(e)

    def _collect_blocked(tasks: list, out: list[str]) -> None:
        for task in tasks:
            if task.blocked and task.blocked_reason:
                out.append(f"Task {task.id}: {task.blocked_reason}")
            if task.children:
                _collect_blocked(task.children, out)

    def _extract_exception_reason(impl_path: Path) -> str:
        """Extract the most recent exception reason from IMPL Execution Notes."""
        import re as _re

        try:
            content = impl_path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            return ""
        # Find last EXCEPTION marker in Execution Notes
        matches = _re.findall(r"⚠️ EXCEPTION — (.+)", content)
        return matches[-1].strip() if matches else ""

    blocked: list[dict[str, Any]] = []
    for spec_id, impl in datasets.active_impls.items():
        reasons: list[str] = []
        is_paused = "Paused" in impl.status
        is_exception = "Exception" in impl.status

        _collect_blocked(impl.tasks, reasons)

        if reasons or is_paused or is_exception:
            fr = datasets.get_fr(spec_id)
            entry: dict[str, Any] = {
                "spec_id": spec_id,
                "title": fr.title if fr else f"Spec {spec_id}",
                "status": impl.status,
                "is_paused": is_paused,
                "is_exception": is_exception,
                "blocked_tasks": reasons,
            }
            if is_exception:
                entry["exception_reason"] = _extract_exception_reason(impl.path)
            blocked.append(entry)

    return {
        "count": len(blocked),
        "specs": blocked,
    }


@mcp.tool()
def loop_pipeline(
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Return the resolved loop pipeline and agent map.

    Reads the ``[loop] pipeline`` and ``[agents]`` sections from config.
    Returns the step list, agent map, and whether it came from config or defaults.

    Args:
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.config import DEFAULT_AGENTS, DEFAULT_PIPELINE, NspecConfig

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)

    try:
        config = NspecConfig.load(project_root)
    except FileNotFoundError:
        config = NspecConfig()

    steps = [{"step": s.step, "params": list(s.params)} for s in config.loop.pipeline]
    agents = dict(config.agents.agents)

    # Determine if pipeline/agents come from config or are defaults
    is_default_pipeline = config.loop.pipeline == DEFAULT_PIPELINE
    is_default_agents = config.agents.agents == DEFAULT_AGENTS
    source = "default" if (is_default_pipeline and is_default_agents) else "config"

    return {
        "steps": steps,
        "agents": agents,
        "source": source,
    }


@mcp.tool()
def dep_graph(
    epic_id: str | None = None,
    spec_id: str | None = None,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Analyze dependency graph across active specs.

    Returns declared dependencies, file-level collisions (from git history),
    recommended execution order, and parallelization groupings.

    Args:
        epic_id: Optional epic ID to filter analysis to
        spec_id: Optional spec ID to show only its relationships
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.dep_graph import analyze

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)

    result = analyze(
        root,
        epic_id=epic_id,
        spec_id=spec_id,
        project_root=project_root,
    )

    return {
        "specs": {
            sid: {
                "deps": node.deps,
                "files": node.files,
                "file_source": node.file_source,
                "priority": node.priority,
                "title": node.title,
            }
            for sid, node in result.specs.items()
        },
        "declared_deps": result.declared_deps,
        "file_collisions": [
            {"file": c.file_path, "specs": c.spec_ids} for c in result.file_collisions
        ],
        "execution_order": result.execution_order,
        "parallel_groups": result.parallel_groups,
        "cycle": result.cycle,
    }


@mcp.tool()
def loop_init(spec_id: str, docs_root: str | None = None) -> dict[str, Any]:
    """Initialize a loop session targeting a specific spec.

    Single atomic call that resolves the spec, validates it is workable
    (not Paused/Exception), finds its parent epic, conditionally activates
    it, persists state, and returns a structured result with resume_phase.

    Use this instead of activate() + session_start() when /loop targets
    a specific spec ID. Key differences:
    - Rejects Paused/Exception specs upfront
    - Returns resume_phase as a structured int (no status string parsing)
    - Conditional activation (doesn't force Active on already-progressed specs)

    Args:
        spec_id: Spec ID (accepts "142", "S142", "s142")
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.datasets import DatasetLoader
    from nspec.session import StateDAO, initialize_session

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)
    project_root = _resolve_project_root(root)

    # Load datasets and verify spec exists in active backlog
    try:
        loader = DatasetLoader(docs_root=root)
        datasets = loader.load()
    except Exception as e:
        return _exception_error(e)

    fr = datasets.get_fr(spec_id)
    impl = datasets.get_impl(spec_id)
    if not impl:
        return _tool_error(f"Spec {spec_id} not found in active backlog")
    if not datasets.is_active(spec_id):
        return _tool_error(f"Spec {spec_id} is not in the active backlog")

    # Reject Paused/Exception specs
    status = impl.status
    if "Paused" in status:
        return _tool_error(f"Spec {spec_id} is Paused — unpark it first")
    if "Exception" in status:
        return _tool_error(f"Spec {spec_id} is in Exception state — requires human triage")

    # Find parent epic
    epic_id = _find_epic_for_spec(spec_id, root)

    # Determine resume_phase from IMPL status
    if "Active" in status:
        resume_phase = 4
    elif "Testing" in status:
        resume_phase = 5
    elif "Ready" in status:
        resume_phase = 6
    else:
        # Planning or Proposed — full pipeline
        resume_phase = 3

    # Activate only if at phase 3 (Planning/Proposed)
    activated = False
    if resume_phase == 3:
        try:
            from nspec.crud import set_status
            from nspec.locks import spec_lock

            with spec_lock(spec_id):
                set_status(spec_id, 2, 1, root)
            activated = True
        except TimeoutError:
            return _tool_error(f"Could not acquire lock for {spec_id}")
        except Exception as e:
            return _exception_error(e)

    # Persist to state.json
    try:
        dao = StateDAO(project_root)
        dao.set_spec_id(spec_id)
        if epic_id:
            with contextlib.suppress(Exception):
                dao.set_active_epic(epic_id)
    except Exception as e:
        return _exception_error(e)

    # Initialize session context
    try:
        session_context = initialize_session(spec_id, root, project_root=project_root)
    except Exception:
        session_context = ""

    # Reset error counter
    try:
        from nspec.error_agent import reset_session_counter

        reset_session_counter()
    except Exception:
        pass

    title = fr.title if fr else impl.spec_id
    priority = fr.priority if fr else "unknown"

    return {
        "success": True,
        "spec_id": spec_id,
        "epic_id": epic_id,
        "title": title,
        "priority": priority,
        "impl_status": status,
        "resume_phase": resume_phase,
        "activated": activated,
        "session_context": session_context,
        "completion": impl.completion_percent,
    }


@mcp.tool()
def queue_init(
    epic_id: str | None = None,
    max_agents: int | None = None,
    lease_ttl: int | None = None,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Initialize the agent assignment queue from the backlog.

    Populates the queue with eligible specs ordered by priority/dependency.
    Discards any previous queue state.

    Args:
        epic_id: Optional epic ID to filter specs.
        max_agents: Maximum concurrent agents (default: from [queue] config or 5).
        lease_ttl: Lease timeout in seconds (default: from [queue] config or 300).
        docs_root: Path to docs directory (default: ./docs).

    Returns:
        Queue state summary with entries count and configuration.
    """
    from nspec.config import NspecConfig
    from nspec.queue import QueueDAO

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)

    config = NspecConfig.load(project_root)
    resolved_max_agents = max_agents if max_agents is not None else config.queue.max_agents
    if config.queue.mode == "single":
        resolved_max_agents = 1
    resolved_lease = lease_ttl if lease_ttl is not None else config.queue.lease_ttl_seconds

    dao = QueueDAO(project_root)
    state = dao.initialize_from_backlog(
        root,
        epic_id=epic_id,
        max_agents=resolved_max_agents,
        lease_ttl=resolved_lease,
    )
    return {
        "success": True,
        "epic_id": state.epic_id,
        "entries": len(state.entries),
        "max_agents": state.max_agents,
        "lease_ttl_seconds": state.lease_ttl_seconds,
        "specs": [
            {"spec_id": e.spec_id, "priority": e.priority, "title": e.title} for e in state.entries
        ],
    }


@mcp.tool()
def queue_claim(
    agent_id: str,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Claim the next unclaimed spec from the queue.

    Atomically assigns the highest-priority unclaimed spec to the agent.
    Two concurrent claims will never return the same spec.

    Args:
        agent_id: Unique identifier for the claiming agent.
        docs_root: Path to docs directory (default: ./docs).

    Returns:
        Assignment details (spec_id, title, priority, lease_expires) or error.
    """
    from nspec.queue import QueueDAO

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)
    dao = QueueDAO(project_root)
    return dao.claim(agent_id)


@mcp.tool()
def queue_release(
    agent_id: str,
    spec_id: str,
    reason: str | None = None,
    completed: bool = False,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Release a claimed spec back to the queue or mark it completed.

    Args:
        agent_id: The agent releasing the spec.
        spec_id: The spec being released.
        reason: Optional reason for release.
        completed: If True, move to completed list instead of re-queuing.
        docs_root: Path to docs directory (default: ./docs).

    Returns:
        Release confirmation or error.
    """
    from nspec.queue import QueueDAO

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)
    dao = QueueDAO(project_root)
    return dao.release(agent_id, spec_id, reason=reason, completed=completed)


@mcp.tool()
def queue_heartbeat(
    agent_id: str,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Extend the lease for an agent's current claim.

    Call periodically to prevent lease expiry while working on a spec.

    Args:
        agent_id: The agent sending the heartbeat.
        docs_root: Path to docs directory (default: ./docs).

    Returns:
        Updated lease expiry or error.
    """
    from nspec.queue import QueueDAO

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)
    dao = QueueDAO(project_root)
    return dao.heartbeat(agent_id)


@mcp.tool()
def queue_status(
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Get full queue status: agents, queued specs, completed specs.

    Shows all active agent assignments with lease expiry, unclaimed specs
    waiting in queue, and specs already completed.

    Args:
        docs_root: Path to docs directory (default: ./docs).

    Returns:
        Full queue state with agents, queued, completed, and metadata.
    """
    from nspec.queue import QueueDAO

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)
    dao = QueueDAO(project_root)
    return dao.status()


def _to_bool(value: bool | str) -> bool:
    """Convert string/bool to bool (MCP clients may pass strings)."""
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.lower() in ("true", "1", "yes")
    return bool(value)


@mcp.tool()
def create_spec(
    title: str,
    priority: str = "P3",
    epic_id: str | None = None,
    is_epic: bool = False,
    set_default: bool = False,
    docs_root: str | None = None,
    spec_type: str | None = None,
    template: str | None = None,
) -> dict[str, Any]:
    """Create a new FR+IMPL spec pair.

    Auto-assigns the next available spec ID in the priority range.
    Optionally adds the spec to an epic.

    Args:
        title: Spec title (e.g., "Add search feature")
        priority: Priority level (P0-P3). Default: P2
        epic_id: Optional epic ID to group under (ignored if is_epic=True)
        is_epic: If True, create an epic (E###) instead of a spec (S###)
        set_default: If True and is_epic=True, set this epic as the default in config
        docs_root: Path to docs directory (default: ./docs)
        spec_type: Optional spec type name (e.g., "rfc"). When provided,
            creates file(s) for that SpecType instead of the default FR+IMPL pair.
        template: Optional template profile (quick, standard, full, formal).
            Controls ceremony level of generated spec files.
    """
    from nspec.config import NspecConfig
    from nspec.crud import create_new_spec, move_dependency
    from nspec.spec_types import default_registry

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)

    # Normalize boolean params (MCP clients may pass strings)
    is_epic = _to_bool(is_epic)
    set_default = _to_bool(set_default)

    # Resolve spec_type via registry if provided
    if spec_type is not None:
        try:
            config = NspecConfig.load(project_root)
            registry = default_registry(config)
        except (FileNotFoundError, KeyError, ValueError):
            registry = default_registry()
        try:
            resolved_type = registry.get(spec_type)
        except KeyError as e:
            return {"success": False, "error": str(e)}

        # Map spec_type to existing is_epic flag for built-in types.
        # IMPL is always created alongside its FR — reject standalone.
        if resolved_type.name == "epic":
            is_epic = True
        elif resolved_type.name == "fr":
            is_epic = False
        elif resolved_type.name == "impl":
            return {
                "success": False,
                "error": (
                    "IMPL specs are always created alongside their FR. "
                    "Use spec_type='fr' or omit spec_type to create an FR+IMPL pair."
                ),
            }
        else:
            # Custom type — not yet supported for creation via crud
            return {
                "success": False,
                "error": (
                    f"Custom spec type {spec_type!r} creation is not yet supported. "
                    f"Only built-in types (fr, epic) can be created."
                ),
                "spec_type": resolved_type.name,
                "prefix": resolved_type.prefix,
            }

    # Validate flag combinations
    if set_default and not is_epic:
        return {
            "success": False,
            "error": "set_default only valid when is_epic=True",
        }
    if is_epic and epic_id:
        return {
            "success": False,
            "error": "epic_id cannot be used with is_epic=True (epics don't nest)",
        }

    # Epic enforcement: use config default if no epic specified (only for specs, not epics)
    if not is_epic:
        require_default_epic = True  # default
        enforce_epic_grouping = False
        if epic_id is None:
            try:
                from nspec.config import NspecConfig

                config = NspecConfig.load(project_root)
                require_default_epic = config.strict.require_default_epic
                enforce_epic_grouping = config.validation.enforce_epic_grouping
                if config.defaults.epic:
                    default_epic = config.defaults.epic
                    # Config stores bare number (e.g. "001") — prefix with E
                    if default_epic and default_epic[0].isdigit():
                        default_epic = f"E{default_epic}"
                    epic_id = default_epic
            except (FileNotFoundError, ValueError):
                pass  # Don't break creation on config issues

        # Gate epic requirement on strict config and grouping enforcement policy
        if epic_id is None and (require_default_epic or enforce_epic_grouping):
            return {
                "success": False,
                "error": (
                    "Spec creation requires epic assignment. Set [defaults] epic in "
                    ".novabuilt.dev/nspec/config.toml or pass epic_id.\n"
                    "Current gates:\n"
                    f"  [strict] require_default_epic = {str(require_default_epic).lower()}\n"
                    "  [validation] "
                    f"enforce_epic_grouping = {str(enforce_epic_grouping).lower()}\n"
                    "To allow orphan creation, disable both gates."
                ),
            }

        # Normalize and verify epic (only when epic is provided)
        if epic_id is not None:
            normalized_epic, error = _normalize_epic_id(epic_id, root)
            if error:
                return error
            assert normalized_epic is not None
            epic_id = normalized_epic

            epic_error = _verify_epic_exists(epic_id=epic_id, docs_root=root)
            if epic_error:
                # Add helpful hint for new projects
                epic_error["hint"] = (
                    "For new projects, run init() first to create the project structure "
                    "and default epic. Example: init(epic_title='My Project')"
                )
                return epic_error

    try:
        fr_path, impl_path, spec_id = create_new_spec(
            title,
            priority,
            root,
            is_epic=is_epic,
            template=template,
        )
    except Exception as e:
        return _exception_error(e)

    # Verify files exist on disk after creation
    if not fr_path.exists():
        logger.error("create_spec: FR file missing after creation: %s", fr_path)
        return {"success": False, "error": f"FR file not found after creation: {fr_path}"}
    if not impl_path.exists():
        logger.error("create_spec: IMPL file missing after creation: %s", impl_path)
        return {"success": False, "error": f"IMPL file not found after creation: {impl_path}"}

    logger.debug("create_spec: created %s → FR=%s, IMPL=%s", spec_id, fr_path, impl_path)

    result: dict[str, Any] = {
        "success": True,
        "spec_id": spec_id,
        "fr_path": str(fr_path),
        "impl_path": str(impl_path),
    }

    # Set as default epic if requested
    if set_default and is_epic:
        try:
            from nspec.config import NspecConfig

            config = NspecConfig.load(project_root)
            # Store without E prefix (just the number)
            epic_num = spec_id[1:] if spec_id.startswith("E") else spec_id
            config.defaults.epic = epic_num
            config.save()
            result["set_as_default"] = True
        except Exception as e:
            logger.warning("create_spec: failed to set default epic: %s", e)
            result["set_default_warning"] = f"Failed to set as default: {e}"

    # Add spec to epic (only for specs, not epics)
    if epic_id and not is_epic:
        # Verify spec is loadable before adding to epic
        from nspec.datasets import DatasetLoader

        try:
            loader = DatasetLoader(root)
            datasets = loader.load()
            if spec_id not in datasets.active_frs:
                logger.warning(
                    "create_spec: spec %s created but not loadable — skipping add_dep to epic %s",
                    spec_id,
                    epic_id,
                )
                result["epic_warning"] = (
                    f"Spec {spec_id} created but failed validation — not added to epic {epic_id}"
                )
                return result
        except Exception as e:
            logger.warning("create_spec: dataset load failed after create: %s", e)

        try:
            move_dependency(spec_id, epic_id, root)
        except Exception as e:
            return _exception_error(e)
        result["epic_id"] = epic_id

    # If IMPL is a skeleton, include refinement prompt in response
    try:
        from nspec.refine import generate_refinement_prompt, is_skeleton_impl

        impl_content = impl_path.read_text()
        if is_skeleton_impl(impl_content):
            prompt = generate_refinement_prompt(spec_id, root)
            result["refinement_prompt"] = prompt.prompt_text
            result["refinement_hint"] = (
                "IMPL has placeholder tasks. Call execute_codex(prompt=...) "
                "with this prompt, then call "
                "write_refinement with the response content."
            )
    except Exception as e:
        logger.debug("create_spec: refinement prompt generation failed: %s", e)

    # Run validation and include results — catch issues at creation time
    try:
        from nspec.validator import NspecValidator

        strict_mode = False
        try:
            from nspec.config import NspecConfig as _Cfg

            _cfg = _Cfg.load(project_root)
            strict_mode = _cfg.validation.enforce_epic_grouping
        except Exception:
            pass

        validator = NspecValidator(root, strict_mode=strict_mode)
        valid, errors = validator.validate()
        structured = [
            {
                "layer": ve.layer,
                "message": ve.message,
                "spec_id": ve.spec_id,
                "severity": ve.severity,
                "code": ve.code,
            }
            for ve in getattr(validator, "structured_errors", [])[:20]
        ]
        result["validation"] = {
            "valid": valid,
            "error_count": len(errors),
            "errors": errors[:20],
            "structured_errors": structured,
        }
    except Exception as e:
        logger.debug("create_spec: post-creation validation failed: %s", e)

    return result


@mcp.tool()
def set_priority(spec_id: str, priority: str, docs_root: str | None = None) -> dict[str, Any]:
    """Change a spec's priority level.

    Automatically updates dependent spec priorities to maintain
    the priority inheritance rule (child <= parent).

    Args:
        spec_id: Spec ID to update
        priority: New priority (P0-P3)
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.crud import set_priority

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)
    try:
        path = set_priority(spec_id, priority, root)
    except Exception as e:
        return _exception_error(e)
    return {"success": True, "spec_id": spec_id, "priority": priority, "path": str(path)}


@mcp.tool()
def add_dep(spec_id: str, dep_id: str, docs_root: str | None = None) -> dict[str, Any]:
    """Add a dependency to a spec.

    If the target is an epic and the dependency belongs to another
    epic, it will be automatically moved.

    Args:
        spec_id: Spec ID to add dependency to
        dep_id: Dependency spec ID
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.crud import add_dependency

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
        dep_id = _resolve_id_from_disk(dep_id, root)
    except ValueError:
        return _invalid_id_error(f"{spec_id} / {dep_id}")
    try:
        result = add_dependency(spec_id, dep_id, root)
    except Exception as e:
        return _exception_error(e)
    return {
        "success": True,
        "spec_id": spec_id,
        "dep_id": dep_id,
        "path": str(result["path"]),
        "moved_from": result.get("moved_from"),
    }


@mcp.tool()
def remove_dep(spec_id: str, dep_id: str, docs_root: str | None = None) -> dict[str, Any]:
    """Remove a dependency from a spec.

    Args:
        spec_id: Spec ID to remove dependency from
        dep_id: Dependency spec ID to remove
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.crud import remove_dependency

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
        dep_id = _resolve_id_from_disk(dep_id, root)
    except ValueError:
        return _invalid_id_error(f"{spec_id} / {dep_id}")
    try:
        path = remove_dependency(spec_id, dep_id, root)
    except Exception as e:
        return _exception_error(e)
    return {"success": True, "spec_id": spec_id, "dep_id": dep_id, "path": str(path)}


@mcp.tool()
def session_save(
    spec_id: str,
    task_id: str | None = None,
    notes: str | None = None,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Persist session state for cross-session handoff.

    Saves spec progress to .novabuilt.dev/nspec/state.json.
    Increments attempt counter for the given task_id.

    Args:
        spec_id: Spec ID being worked on
        task_id: Current task ID (optional)
        notes: Session notes (optional)
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.session import SessionState, load_session, save_session

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)

    # Load existing session or create new
    try:
        existing = load_session(project_root)
    except Exception:
        existing = None
    if existing and existing.spec_id == spec_id:
        state = existing
        state.last_task = task_id or state.last_task
        state.notes = notes or state.notes
    else:
        # Carry forward active_epic from previous session
        prev_epic = existing.active_epic if existing else None
        state = SessionState(
            spec_id=spec_id,
            active_epic=prev_epic,
            last_task=task_id,
            notes=notes,
        )

    # If active_epic is still unset, look it up from the spec's parent epic
    if not state.active_epic and not spec_id.startswith("E"):
        epic_id = _find_epic_for_spec(spec_id, root)
        if epic_id:
            state.active_epic = epic_id

    # Increment attempt counter for task
    if task_id:
        state.attempts[task_id] = state.attempts.get(task_id, 0) + 1

    try:
        path = save_session(state, project_root)
    except Exception as e:
        return _exception_error(e)

    result: dict[str, Any] = {
        "success": True,
        "path": str(path),
        "spec_id": spec_id,
        "task_id": task_id,
        "attempts": state.attempts,
    }

    # Auto-park if a task hits 3 consecutive failures
    if task_id and state.attempts.get(task_id, 0) >= 3:
        from nspec.crud import park_spec

        root = _resolve_docs_root(docs_root)
        reason = (
            f"Auto-parked: task {task_id} failed {state.attempts[task_id]} consecutive attempts"
        )
        try:
            park_spec(spec_id, root, reason=reason)
            result["auto_parked"] = True
            result["park_reason"] = reason
        except (FileNotFoundError, ValueError):
            # Already paused or file not found — don't fail the save
            pass

    return result


@mcp.tool()
def session_resume(
    spec_id: str,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Load persisted session state for a spec.

    Returns saved session context if state.json has a matching spec_id.

    Args:
        spec_id: Spec ID to resume
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.session import load_session

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)
    try:
        state = load_session(project_root)
    except Exception as e:
        return _exception_error(e)

    if not state or state.spec_id != spec_id:
        return {
            "found": False,
            "spec_id": spec_id,
            "message": f"No saved session for spec {spec_id}",
        }

    return {
        "found": True,
        "spec_id": state.spec_id,
        "active_epic": state.active_epic,
        "last_task": state.last_task,
        "attempts": state.attempts,
        "notes": state.notes,
        "started_at": state.started_at,
        "updated_at": state.updated_at,
    }


@mcp.tool()
def session_clear(
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Delete the session state file.

    Args:
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.session import clear_session

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)
    try:
        deleted = clear_session(project_root)
    except Exception as e:
        return _exception_error(e)
    return {
        "success": True,
        "deleted": deleted,
    }


@mcp.tool()
def init(
    epic_title: str = "Default Epic",
    docs_root: str | None = None,
    force: bool = False,
) -> dict[str, Any]:
    """Initialize a new nspec project with full directory structure.

    Creates config.toml, docs directories, templates, and a default epic.
    This is the recommended way to start a new nspec project.

    If the project is already initialized, returns information about
    existing setup unless force=True.

    Args:
        epic_title: Title for the default epic (default: "Default Epic")
        docs_root: Path to docs directory (default: ./docs)
        force: Overwrite existing files if True
    """
    from nspec.crud import create_new_spec
    from nspec.init import scaffold_project

    # Determine paths
    root = Path(docs_root) if docs_root else Path("docs")
    project_root = _resolve_project_root(root)

    # Check if already initialized
    from nspec.config import CONFIG_REL_PATH

    config_file = project_root / CONFIG_REL_PATH
    force = _to_bool(force)

    if config_file.exists() and not force:
        # Already initialized — return info about existing setup
        from nspec.config import NspecConfig

        config = NspecConfig.load(project_root)
        return {
            "success": True,
            "already_initialized": True,
            "config_file": str(config_file),
            "default_epic": config.defaults.epic,
            "hint": "Project already initialized. Use force=True to reinitialize.",
        }

    # Scaffold the project structure
    try:
        created = scaffold_project(
            project_root,
            docs_root=root.resolve(),
            ci_platform_override="none",  # Don't auto-detect CI for MCP init
            force=force,
        )
    except Exception as e:
        return _exception_error(e)

    # Reload config to get the actual paths
    from nspec.config import NspecConfig

    config = NspecConfig.load(project_root)

    # Create default epic if one doesn't exist
    epic_id = None
    fr_dir = root / config.paths.feature_requests
    existing_epics = list(fr_dir.glob("FR-E*-*.md")) if fr_dir.exists() else []

    if not existing_epics:
        try:
            fr_path, impl_path, epic_id = create_new_spec(epic_title, "P2", root, is_epic=True)
            created.extend([fr_path, impl_path])

            # Set as default epic in config
            epic_num = epic_id[1:] if epic_id.startswith("E") else epic_id
            config.defaults.epic = epic_num
            config.save()
        except Exception as e:
            return {
                "success": True,
                "warning": f"Project scaffolded but failed to create default epic: {e}",
                "created": [str(p) for p in created if p.is_file()],
            }
    else:
        # Use existing epic as default if none set
        import re

        for epic_file in existing_epics:
            match = re.match(r"FR-(E\d{3})", epic_file.name)
            if match:
                epic_id = match.group(1)
                if config.defaults.epic is None:
                    epic_num = epic_id[1:] if epic_id.startswith("E") else epic_id
                    config.defaults.epic = epic_num
                    config.save()
                break

    return {
        "success": True,
        "project_root": str(project_root),
        "docs_root": str(root.resolve()),
        "config_file": str(config_file),
        "default_epic": epic_id,
        "created_files": [str(p) for p in created if p.is_file()],
        "created_dirs": [str(p) for p in created if p.is_dir()],
        "next_steps": [
            f"Create your first spec: create_spec('My Feature', epic_id='{epic_id}')",
            "View the backlog: epics()",
            "Validate setup: validate()",
        ],
    }


@mcp.tool()
def skills_install(docs_root: str | None = None, force: bool = False) -> dict[str, Any]:
    """Write resolved skills to `.claude/commands/`.

    Installs built-in nspec skills (and any custom sources from config)
    to the project's `.claude/commands/` directory. Only overwrites files
    that are managed by nspec (have the managed-by frontmatter field).

    Args:
        docs_root: Path to docs directory (default: ./docs)
        force: If True, overwrite all existing skill files regardless
               of managed-by status. Useful for fixing stale installs.
    """
    from nspec.config import NspecConfig
    from nspec.skills import install_skills, resolve_skills

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)
    try:
        config = NspecConfig.load(project_root)
        resolved = resolve_skills(config.skills.sources, project_root=project_root)
        installed = install_skills(project_root, resolved, force=force)
    except Exception as e:
        return _exception_error(e)

    return {
        "success": True,
        "installed": [str(p.relative_to(project_root)) for p in installed],
        "count": len(installed),
        "forced": force,
    }


@mcp.tool()
def skills_list(docs_root: str | None = None) -> dict[str, Any]:
    """List available skills with source info.

    Returns all resolved skills showing which source each comes from.

    Args:
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.config import NspecConfig
    from nspec.skills import VALID_TARGETS, resolve_skills

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)
    try:
        config = NspecConfig.load(project_root)
        skills_info = []
        for target in VALID_TARGETS:
            # Filesystem sources are Claude-only; Codex only has builtins
            sources = config.skills.sources if target == "claude" else ["builtin"]
            resolved = resolve_skills(sources, project_root=project_root, target=target)
            for name, info in sorted(resolved.items()):
                skills_info.append(
                    {
                        "name": name,
                        "source": info.source,
                        "target": info.target,
                        "size": len(info.content),
                    }
                )
    except Exception as e:
        return _exception_error(e)

    return {
        "sources": config.skills.sources,
        "skills": skills_info,
        "count": len(skills_info),
    }


@mcp.tool()
def skills_sync(docs_root: str | None = None, force: bool = False) -> dict[str, Any]:
    """Re-sync skills from sources (update after nspec upgrade).

    Re-resolves skills from configured sources and updates managed
    files in `.claude/commands/`. Useful after `pip install --upgrade nspec`.

    Args:
        docs_root: Path to docs directory (default: ./docs)
        force: If True, overwrite all existing skill files regardless
               of managed-by status. Useful for fixing stale installs.
    """
    from nspec.config import NspecConfig
    from nspec.skills import install_skills, resolve_skills

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)
    try:
        config = NspecConfig.load(project_root)
        resolved = resolve_skills(config.skills.sources, project_root=project_root)
        installed = install_skills(project_root, resolved, force=force)
    except Exception as e:
        return _exception_error(e)

    return {
        "success": True,
        "synced": [str(p.relative_to(project_root)) for p in installed],
        "count": len(installed),
        "forced": force,
    }


@mcp.tool()
def coverage_audit(
    coverage_json: str = "coverage.json",
    registry: str = "work/coverage_decisions.json",
    strict: bool = False,
    include: str | None = None,
    exclude: str | None = None,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Run full-suite coverage audit and return candidate status.

    Parses pytest-cov JSON, inventories uncovered and suspicious code,
    reconciles against the decision registry, and returns a summary.

    Args:
        coverage_json: Path to pytest-cov JSON output
        registry: Path to decision registry JSON
        strict: If True, gate_pass requires zero unresolved/stale
        include: Comma-separated regex patterns for files to include
        exclude: Comma-separated regex patterns for files to exclude
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.coverage_audit import audit_report_json, run_audit

    _resolve_docs_root(docs_root)  # ensure config is loaded

    include_patterns = [p.strip() for p in include.split(",")] if include else None
    exclude_patterns = [p.strip() for p in exclude.split(",")] if exclude else None

    try:
        result = run_audit(
            Path(coverage_json),
            Path(registry),
            include_patterns=include_patterns,
            exclude_patterns=exclude_patterns,
        )
    except (FileNotFoundError, ValueError) as exc:
        return _exception_error(exc)

    report = audit_report_json(result)
    report["strict"] = strict
    if strict:
        report["gate_pass"] = report["gate_pass"]  # already computed
    return {"success": True, **report}


def main() -> None:
    """Entry point for nspec-mcp command."""
    from nspec.telemetry import setup_telemetry_logging

    setup_telemetry_logging()
    logger.debug("MCP server starting: cwd=%s, argv=%s", Path.cwd(), sys.argv)
    if "--http" in sys.argv:
        transport = "streamable-http"
    elif "--sse" in sys.argv:
        transport = "sse"
    else:
        transport = "stdio"
    if transport == "stdio":
        _redirect_print_to_stderr_for_stdio()
    if transport in ("sse", "streamable-http"):
        mcp.settings.host = os.environ.get("NSPEC_MCP_HOST", "0.0.0.0")
        mcp.settings.port = int(os.environ.get("NSPEC_MCP_PORT", "8080"))
    mcp.run(transport=transport)


if __name__ == "__main__":
    main()
