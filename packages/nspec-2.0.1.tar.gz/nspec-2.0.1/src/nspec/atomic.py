"""Atomic file writes and write batching for multi-step MCP operations.

Provides:
- ``atomic_write(path, content)``: Write-to-temp + ``os.replace()`` for
  single atomic file replacement.
- ``batch_writes()``: Reentrant context manager that buffers all writes
  and flushes exactly once on outermost exit, ensuring external observers
  (like the TUI's mtime-based polling) never see intermediate states.

When a batch is active, ``spec_read()`` returns buffered content if available,
so chained functions that re-read the same file see the latest in-flight state.
"""

from __future__ import annotations

import logging
import os
import tempfile
import threading
from contextlib import contextmanager
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Generator

logger = logging.getLogger("nspec.atomic")

_thread_local = threading.local()


class WriteBatch:
    """Accumulates file writes in memory, flushing once on outermost exit."""

    __slots__ = ("_pending", "_depth")

    def __init__(self) -> None:
        self._pending: dict[str, str] = {}  # resolved path str → content
        self._depth: int = 0

    def write(self, path: Path, content: str) -> None:
        """Buffer a write for later flush."""
        self._pending[str(path.resolve())] = content

    def read(self, path: Path) -> str | None:
        """Return buffered content for *path*, or None if not buffered."""
        return self._pending.get(str(path.resolve()))

    @property
    def pending_count(self) -> int:
        """Number of distinct files with pending writes."""
        return len(self._pending)

    def flush(self) -> None:
        """Flush all pending writes via atomic replacement."""
        for path_str, content in self._pending.items():
            atomic_write(Path(path_str), content)
        self._pending.clear()

    def discard(self) -> None:
        """Discard all pending writes without touching disk."""
        self._pending.clear()


def atomic_write(path: Path, content: str) -> None:
    """Write *content* to *path* atomically.

    Creates a temporary file in the same directory, writes content, fsyncs,
    then replaces the target via ``os.replace()`` (atomic on POSIX when
    source and destination are on the same filesystem).
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    fd = -1
    tmp_path = ""
    try:
        fd, tmp_path = tempfile.mkstemp(
            dir=str(path.parent),
            prefix=f".{path.name}.",
            suffix=".tmp",
        )
        os.write(fd, content.encode("utf-8"))
        os.fsync(fd)
        os.close(fd)
        fd = -1  # mark as closed
        os.replace(tmp_path, str(path))
    except BaseException:
        if fd >= 0:
            os.close(fd)
        if tmp_path and os.path.exists(tmp_path):
            os.unlink(tmp_path)
        raise


@contextmanager
def batch_writes() -> Generator[WriteBatch]:
    """Reentrant context manager that batches file writes.

    All calls to ``spec_write()`` inside this context are buffered. On
    normal exit of the **outermost** context, all buffered writes are
    flushed atomically. On exception, buffered writes are discarded.

    Nested ``batch_writes()`` calls reuse the same batch — only the
    outermost exit triggers the flush.

    Example::

        with batch_writes():
            spec_write(impl_path, updated_content)
            set_status(...)  # internally calls spec_write too
        # ← single atomic flush happens here
    """
    batch: WriteBatch | None = getattr(_thread_local, "batch", None)

    if batch is not None:
        # Nested — reuse existing batch, bump depth
        batch._depth += 1
        try:
            yield batch
        finally:
            batch._depth -= 1
    else:
        # Outermost — create new batch
        batch = WriteBatch()
        batch._depth = 1
        _thread_local.batch = batch
        try:
            yield batch
            batch.flush()
        except BaseException:
            batch.discard()
            raise
        finally:
            _thread_local.batch = None


def is_batch_active() -> bool:
    """Return True if a ``batch_writes()`` context is currently active."""
    return getattr(_thread_local, "batch", None) is not None


def spec_write(path: Path, content: str) -> None:
    """Write *content* to *path*, buffering if a batch is active.

    When no batch is active, writes atomically to disk immediately.
    When a batch is active, buffers the write for later flush.
    """
    batch: WriteBatch | None = getattr(_thread_local, "batch", None)
    if batch is not None:
        batch.write(path, content)
    else:
        atomic_write(path, content)


def spec_read(path: Path) -> str:
    """Read *path*, returning buffered content if a batch has a pending write.

    When no batch is active (or the path has no pending write), reads
    directly from disk.
    """
    batch: WriteBatch | None = getattr(_thread_local, "batch", None)
    if batch is not None:
        buffered = batch.read(path)
        if buffered is not None:
            return buffered
    return path.read_text(encoding="utf-8")
