"""Claude Code stall detector & auto-recovery for tmux sessions.

Monitors a tmux pane for Claude Code API stalls — when the token count
stops incrementing while the "Crunching" or "Running" indicator is active.
On detection, sends Escape + recovery message to resume the session.

Usage:
    nspec watchdog --session my-session
    nspec watchdog --session my-session --stall-timeout 120 --poll-interval 10
"""

from __future__ import annotations

import logging
import re
import time
from dataclasses import dataclass, field

from nspec import tmux
from nspec.config import WatchdogConfig

logger = logging.getLogger("nspec.watchdog")

# Matches patterns like "↓ 28.0k tokens", "↓ 5k tokens", "⬇ 142.5k tokens"
_TOKEN_PATTERN = re.compile(r"[↓⬇]\s*([\d,]+\.?\d*)\s*(k)?\s*tokens", re.IGNORECASE)

# Patterns that indicate active processing (not idle at prompt)
_ACTIVE_PATTERNS = ("Crunching", "Running")

# Matches MCP tool call indicators in Claude Code tmux output.
# Examples:
#   "⏺ write_review_verdict (MCP)"
#   "⏺ nspec-mcp - task_complete"
#   "mcp__nspec-mcp__task_complete"
_MCP_TOOL_PATTERN = re.compile(
    r"(?:"
    r"⏺\s+([\w.-]+(?:\s*-\s*[\w.]+)?)\s*\(MCP\)"  # ⏺ tool-name (MCP)
    r"|⏺\s+([\w.-]+)\s+-\s+([\w.]+)"  # ⏺ server - tool_name
    r"|mcp__([\w.-]+)__([\w.]+)"  # mcp__server__tool
    r")"
)


@dataclass
class TokenSample:
    """A single observation of the tmux pane state."""

    token_count: float | None
    is_active: bool
    raw_text: str
    timestamp: float
    mcp_tool_pending: bool = False
    mcp_tool_name: str | None = None


@dataclass
class WatchdogState:
    """Tracks token progression for stall detection."""

    last_changing_sample: TokenSample | None = None
    recovery_count: int = 0
    consecutive_stall_polls: int = 0
    mcp_tool_first_seen: float | None = None
    mcp_tool_last_name: str | None = None


@dataclass
class Watchdog:
    """Claude Code stall detector & auto-recovery.

    Monitors a tmux session pane for frozen token counts during active
    processing. When a stall is detected, sends Escape + recovery message.
    """

    session: str
    config: WatchdogConfig = field(default_factory=WatchdogConfig)
    state: WatchdogState = field(default_factory=WatchdogState)

    @staticmethod
    def find_session(explicit: str | None = None) -> str:
        """Resolve the tmux session to monitor.

        Args:
            explicit: Explicitly provided session name.

        Returns:
            Session name to use.

        Raises:
            RuntimeError: If no session specified and tmux is not available
                         or no sessions exist.
        """
        if explicit:
            return explicit

        try:
            sessions = tmux.list_sessions()
        except tmux.TmuxNotFoundError:
            raise RuntimeError("tmux not found — install tmux or specify --session") from None
        except tmux.TmuxError as exc:
            raise RuntimeError(f"tmux error: {exc}") from None

        if not sessions:
            raise RuntimeError("No tmux sessions found — specify --session")

        if len(sessions) == 1:
            return sessions[0]

        raise RuntimeError(
            f"Multiple tmux sessions found ({', '.join(sessions)}) — specify --session"
        )

    @staticmethod
    def capture_pane(session: str) -> str:
        """Capture the visible content of a tmux pane.

        Args:
            session: tmux session name.

        Returns:
            Pane content as string.

        Raises:
            RuntimeError: If capture fails.
        """
        try:
            return tmux.capture_pane(session)
        except tmux.TmuxNotFoundError:
            raise RuntimeError("tmux not found") from None
        except tmux.TmuxError as exc:
            raise RuntimeError(f"tmux capture-pane failed: {exc}") from None

    @staticmethod
    def parse_token_count(content: str) -> TokenSample:
        """Parse token count, active status, and MCP tool state from pane content.

        Args:
            content: Raw tmux pane text.

        Returns:
            TokenSample with parsed data.
        """
        now = time.monotonic()

        is_active = any(p in content for p in _ACTIVE_PATTERNS)

        # Detect MCP tool call indicators in the last few lines only.
        # Active MCP indicators appear near the bottom of the tmux pane;
        # searching the full pane would cause false positives from stale
        # completed tool lines or quoted/pasted tool names in chat.
        tail_lines = content.splitlines()[-5:]
        tail_text = "\n".join(tail_lines)
        mcp_match = _MCP_TOOL_PATTERN.search(tail_text)
        mcp_tool_pending = mcp_match is not None
        mcp_tool_name: str | None = None
        if mcp_match:
            # Extract tool name from whichever group matched
            if mcp_match.group(1):
                # ⏺ tool-name (MCP)
                mcp_tool_name = mcp_match.group(1).strip()
            elif mcp_match.group(2) and mcp_match.group(3):
                # ⏺ server - tool_name
                mcp_tool_name = mcp_match.group(3).strip()
            elif mcp_match.group(4) and mcp_match.group(5):
                # mcp__server__tool
                mcp_tool_name = mcp_match.group(5).strip()

        match = _TOKEN_PATTERN.search(content)
        if not match:
            return TokenSample(
                token_count=None,
                is_active=is_active,
                raw_text=content,
                timestamp=now,
                mcp_tool_pending=mcp_tool_pending,
                mcp_tool_name=mcp_tool_name,
            )

        raw_num = match.group(1).replace(",", "")
        token_count = float(raw_num)

        # Group 2 captures the "k" suffix when present
        if match.group(2):
            token_count *= 1000

        return TokenSample(
            token_count=token_count,
            is_active=is_active,
            raw_text=content,
            timestamp=now,
            mcp_tool_pending=mcp_tool_pending,
            mcp_tool_name=mcp_tool_name,
        )

    def detect_stall(self, sample: TokenSample) -> str:
        """Check if the current sample indicates a stall.

        A stall is detected in two independent paths:

        1. **Token stall**: Session is actively processing ("Crunching" / "Running"),
           token count is present, and token count has not changed for > stall_timeout.

        2. **MCP stall**: An MCP tool call indicator is present and has persisted
           for > mcp_stall_timeout seconds.

        Args:
            sample: Current token observation.

        Returns:
            Empty string if no stall, ``"mcp"`` for MCP stall,
            ``"token"`` for token throughput stall.
        """
        # --- MCP stall detection ---
        if sample.mcp_tool_pending:
            # Reset timer if the tool name changed (new tool call between polls)
            if sample.mcp_tool_name != self.state.mcp_tool_last_name:
                self.state.mcp_tool_first_seen = sample.timestamp
                self.state.mcp_tool_last_name = sample.mcp_tool_name
            elif self.state.mcp_tool_first_seen is None:
                self.state.mcp_tool_first_seen = sample.timestamp
            else:
                mcp_elapsed = sample.timestamp - self.state.mcp_tool_first_seen
                if mcp_elapsed > self.config.mcp_stall_timeout:
                    return "mcp"
        else:
            # MCP tool indicator disappeared — tool completed, reset timer
            self.state.mcp_tool_first_seen = None
            self.state.mcp_tool_last_name = None

        # --- Token stall detection (existing) ---
        # Not actively processing — no token stall possible
        if not sample.is_active or sample.token_count is None:
            self.state.last_changing_sample = None
            return ""

        # First observation while active — record baseline
        if self.state.last_changing_sample is None:
            self.state.last_changing_sample = sample
            return ""

        # Token count changed — update baseline
        if sample.token_count != self.state.last_changing_sample.token_count:
            self.state.last_changing_sample = sample
            return ""

        # Token count frozen — check duration
        elapsed = sample.timestamp - self.state.last_changing_sample.timestamp
        if elapsed > self.config.stall_timeout:
            return "token"
        return ""

    def recover(self) -> None:
        """Send recovery keystrokes to the tmux session.

        Sequence:
        1. Send Escape to cancel current operation
        2. Wait 3 seconds for the prompt to appear
        3. Send the recovery message + Enter
        """
        logger.info("Sending recovery to session '%s'", self.session)

        try:
            tmux.send_keys(self.session, "Escape")
        except tmux.TmuxNotFoundError:
            logger.error("Failed to send Escape to tmux")
            return

        time.sleep(3)

        try:
            tmux.send_keys(self.session, self.config.recovery_message, "Enter")
        except tmux.TmuxNotFoundError:
            logger.error("Failed to send recovery message to tmux")
            return

        self.state.recovery_count += 1
        self.state.last_changing_sample = None
        self.state.mcp_tool_first_seen = None
        self.state.mcp_tool_last_name = None
        logger.info(
            "Recovery #%d sent (message: %s)",
            self.state.recovery_count,
            self.config.recovery_message,
        )

    def run(self) -> None:
        """Main poll loop. Runs until KeyboardInterrupt (Ctrl+C)."""
        logger.info(
            "Watchdog started: session=%s, stall_timeout=%ds, "
            "mcp_stall_timeout=%ds, poll_interval=%ds",
            self.session,
            self.config.stall_timeout,
            self.config.mcp_stall_timeout,
            self.config.poll_interval,
        )

        try:
            while True:
                try:
                    content = self.capture_pane(self.session)
                except RuntimeError as e:
                    logger.warning("Capture failed: %s", e)
                    time.sleep(self.config.poll_interval)
                    continue

                sample = self.parse_token_count(content)

                stall_type = self.detect_stall(sample)
                if stall_type:
                    if stall_type == "mcp":
                        logger.warning(
                            "MCP stall detected! Tool '%s' hung for >%ds",
                            sample.mcp_tool_name or "unknown",
                            self.config.mcp_stall_timeout,
                        )
                    else:
                        logger.warning(
                            "Token stall detected! Token count frozen at %.1f for >%ds",
                            sample.token_count or 0,
                            self.config.stall_timeout,
                        )
                    self.recover()

                time.sleep(self.config.poll_interval)
        except KeyboardInterrupt:
            logger.info(
                "Watchdog stopped. Recoveries: %d",
                self.state.recovery_count,
            )
