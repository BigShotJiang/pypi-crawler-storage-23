"""Post-completion doc generation via configurable template and low-reasoning agent.

Renders a user-provided template with spec metadata and git diff context,
invokes a cheap agent (Haiku via Task tool, or codex-cli with low reasoning),
and writes the output to a configured target file.

Target write modes:
- ``append``: Append generated content to the target file.
- ``replace-section``: Replace content between ``<!-- nspec:start -->`` and
  ``<!-- nspec:end -->`` markers in the target file.
"""

from __future__ import annotations

import logging
import re
import subprocess
from dataclasses import dataclass
from pathlib import Path

from nspec.config import DocsConfig, NspecConfig
from nspec.paths import get_paths

logger = logging.getLogger("nspec.docgen")

# Maximum diff size in characters before truncation
_MAX_DIFF_CHARS = 30_000


@dataclass
class DocGenResult:
    """Result of a doc generation run."""

    success: bool
    spec_id: str
    target: str  # Path to the target file (relative to project root)
    content: str  # Generated content (or error message on failure)
    error: str | None = None


def render_template(
    template_text: str,
    *,
    spec_title: str,
    priority: str,
    acceptance_criteria: str,
    git_diff: str,
) -> str:
    """Render a docgen template by substituting ``{{placeholders}}``.

    Supported placeholders:
    - ``{{spec_title}}``
    - ``{{priority}}``
    - ``{{acceptance_criteria}}``
    - ``{{git_diff}}``

    Unknown placeholders are left as-is.

    Args:
        template_text: Raw template content with ``{{...}}`` placeholders.
        spec_title: FR title (e.g., "FR-S092: Post-completion doc generation").
        priority: Priority string (e.g., "P2").
        acceptance_criteria: Extracted acceptance criteria text.
        git_diff: Git diff text (may be truncated).

    Returns:
        Rendered template string.
    """
    replacements = {
        "spec_title": spec_title,
        "priority": priority,
        "acceptance_criteria": acceptance_criteria,
        "git_diff": git_diff,
    }
    result = template_text
    for key, value in replacements.items():
        result = result.replace("{{" + key + "}}", value)
    return result


def resolve_template(template_name: str, project_root: Path | None = None) -> str:
    """Resolve a docgen template, preferring project-local override.

    Resolution order:
    1. ``{project_root}/.novabuilt.dev/nspec/templates/docs/{template_name}``
    2. Package resource fallback (``nspec.resources``)

    Args:
        template_name: Template filename (e.g., ``"changelog.md"``).
        project_root: Project root directory.

    Returns:
        Template content as a string.

    Raises:
        FileNotFoundError: If template cannot be found in any location.
    """
    # 1. Project-local override
    if project_root is not None:
        local_path = (
            project_root / ".novabuilt.dev" / "nspec" / "templates" / "docs" / template_name
        )
        if local_path.exists():
            return local_path.read_text(encoding="utf-8")

    # 2. Package resource fallback — map template name to resource filename
    #    e.g., "changelog.md" → "changelog-template.md"
    from importlib import resources

    stem = Path(template_name).stem  # "changelog"
    resource_name = f"{stem}-template.md"
    try:
        ref = resources.files("nspec.resources").joinpath(resource_name)
        content = ref.read_text(encoding="utf-8")
        return content
    except (FileNotFoundError, TypeError, ModuleNotFoundError):
        pass

    raise FileNotFoundError(
        f"Template '{template_name}' not found. "
        f"Create it at .novabuilt.dev/nspec/templates/docs/{template_name} "
        f"or ensure the nspec package includes a default."
    )


def get_git_diff_for_docgen(
    *,
    base_branch: str | None = None,
    max_chars: int = _MAX_DIFF_CHARS,
    timeout_s: int = 30,
) -> str:
    """Collect git diff for docgen context with truncation and fallbacks.

    Tries several diff strategies in order:
    1. ``git diff {base_branch}...HEAD`` (if base_branch provided)
    2. ``git diff main...HEAD``
    3. ``git diff HEAD``
    4. ``git diff``

    Args:
        base_branch: Base branch to diff against (optional).
        max_chars: Maximum diff length before truncation.
        timeout_s: Timeout for each git command in seconds.

    Returns:
        Diff text, truncated if necessary, or a placeholder on failure.
    """
    cmds: list[list[str]] = []
    if base_branch:
        cmds.append(["git", "diff", f"{base_branch}...HEAD"])
    cmds.extend(
        [
            ["git", "diff", "main...HEAD"],
            ["git", "diff", "HEAD"],
            ["git", "diff"],
        ]
    )

    for cmd in cmds:
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=timeout_s,
            )
            if result.returncode == 0 and result.stdout.strip():
                diff = result.stdout
                if len(diff) > max_chars:
                    diff = (
                        diff[:max_chars] + f"\n\n... (diff truncated at {max_chars // 1000}k chars)"
                    )
                return diff
        except (subprocess.TimeoutExpired, FileNotFoundError):
            continue

    return "(no git diff available)"


def invoke_agent(
    prompt: str,
    agent: str = "haiku",
    timeout_s: int = 120,
) -> str:
    """Invoke a low-reasoning agent with the rendered prompt.

    Uses ``CodexTmuxExecutor`` to spawn the codex CLI. Falls back
    to returning the rendered prompt as-is (the template with filled
    placeholders is still useful documentation).

    Args:
        prompt: The rendered template prompt.
        agent: Agent identifier — ``"haiku"``, ``"codex-low"``, or a model name.
        timeout_s: Timeout in seconds for the agent invocation.

    Returns:
        Agent response text, or the prompt itself on failure.
    """
    from nspec.executor import CodexTmuxExecutor

    # Map agent config values to codex model
    agent_model_map: dict[str, str] = {
        "haiku": "o4-mini",
        "codex-low": "o4-mini",
    }

    model = agent_model_map.get(agent, agent)

    executor = CodexTmuxExecutor(
        model=model,
        default_timeout=timeout_s,
    )
    result = executor.execute(prompt, timeout=timeout_s)

    if result.success and result.output:
        return result.output

    if result.error:
        logger.info("Agent invocation failed (%s): %s", agent, result.error)

    # Fallback: return the rendered prompt itself as documentation
    return prompt


def write_to_target(
    content: str,
    target_path: Path,
    mode: str = "append",
) -> None:
    """Write generated doc content to the target file.

    Args:
        content: Generated documentation content.
        target_path: Absolute path to the target file.
        mode: Write mode — ``"append"`` or ``"replace-section"``.

    For ``replace-section`` mode, the target file must contain markers:
    ``<!-- nspec:start -->`` and ``<!-- nspec:end -->``. Content between
    these markers is replaced. If markers are missing, content is appended
    with markers.
    """
    target_path.parent.mkdir(parents=True, exist_ok=True)

    if mode == "replace-section":
        _write_replace_section(content, target_path)
    else:
        _write_append(content, target_path)


def _write_append(content: str, target_path: Path) -> None:
    """Append content to target file."""
    with open(target_path, "a", encoding="utf-8") as f:
        if target_path.exists() and target_path.stat().st_size > 0:
            f.write("\n")
        f.write(content)
        if not content.endswith("\n"):
            f.write("\n")


def _write_replace_section(content: str, target_path: Path) -> None:
    """Replace content between nspec markers, or append with markers."""
    marker_start = "<!-- nspec:start -->"
    marker_end = "<!-- nspec:end -->"

    if target_path.exists():
        existing = target_path.read_text(encoding="utf-8")
        pattern = re.compile(
            re.escape(marker_start) + r".*?" + re.escape(marker_end),
            re.DOTALL,
        )
        if pattern.search(existing):
            replacement = f"{marker_start}\n{content}\n{marker_end}"
            new_content = pattern.sub(replacement, existing)
            target_path.write_text(new_content, encoding="utf-8")
            return

    # No markers found — append with markers
    with open(target_path, "a", encoding="utf-8") as f:
        if target_path.exists() and target_path.stat().st_size > 0:
            f.write("\n")
        f.write(f"{marker_start}\n{content}\n{marker_end}\n")


def _extract_priority(fr_content: str) -> str:
    """Extract priority from FR content."""
    match = re.search(r"\*\*Priority:\*\*\s*(.+?)$", fr_content, re.MULTILINE)
    if match:
        # Strip emoji prefix if present
        raw = match.group(1).strip()
        p_match = re.search(r"P[0-3]", raw)
        return p_match.group(0) if p_match else raw
    return "unknown"


def _extract_title(fr_content: str) -> str:
    """Extract title from first heading line."""
    for line in fr_content.split("\n"):
        if line.startswith("# "):
            return line[2:].strip()
    return "(untitled)"


def _extract_section(content: str, section_name: str) -> str:
    """Extract a markdown section by heading name."""
    lines = content.split("\n")
    in_section = False
    section_lines: list[str] = []
    section_level = 0

    for line in lines:
        if line.startswith("#"):
            level = len(line) - len(line.lstrip("#"))
            heading_text = line.lstrip("#").strip()

            if heading_text.lower() == section_name.lower():
                in_section = True
                section_level = level
                continue
            elif in_section and level <= section_level:
                break

        if in_section:
            section_lines.append(line)

    return "\n".join(section_lines).strip()


def generate_docs(
    spec_id: str,
    docs_root: Path,
    project_root: Path | None = None,
    config: NspecConfig | None = None,
) -> DocGenResult:
    """Generate documentation for a completed spec.

    Reads the FR metadata, collects the git diff, renders the template,
    and writes to the configured target. This is the main entry point
    called by ``complete()`` and the ``cheap_docs`` MCP tool.

    Args:
        spec_id: Spec ID (e.g., "S092").
        docs_root: Path to docs/ directory.
        project_root: Project root for config and template resolution.
        config: Pre-loaded config (avoids re-reading config.toml).

    Returns:
        DocGenResult with success status and output details.
    """
    if config is None:
        config = NspecConfig.load(project_root)

    docs_config = config.docs

    if not docs_config.enabled:
        return DocGenResult(
            success=True,
            spec_id=spec_id,
            target=docs_config.target,
            content="",
            error="Doc generation disabled ([docs].enabled = false)",
        )

    try:
        return _generate_docs_inner(spec_id, docs_root, project_root, docs_config)
    except Exception as exc:
        logger.warning("Doc generation failed for %s: %s", spec_id, exc)
        return DocGenResult(
            success=False,
            spec_id=spec_id,
            target=docs_config.target,
            content="",
            error=str(exc),
        )


def _generate_docs_inner(
    spec_id: str,
    docs_root: Path,
    project_root: Path | None,
    docs_config: DocsConfig,
) -> DocGenResult:
    """Inner implementation of doc generation (may raise)."""
    from nspec.ids import normalize_spec_ref

    spec_id = normalize_spec_ref(spec_id)
    spec_paths = get_paths(docs_root, project_root=project_root)

    # Find FR file
    fr_pattern = f"FR-{spec_id}-*.md"
    fr_files = list(spec_paths.active_frs_dir.glob(fr_pattern))
    if not fr_files:
        fr_files = list(spec_paths.completed_frs_dir.glob(fr_pattern))
    if not fr_files:
        raise FileNotFoundError(f"FR-{spec_id}-*.md not found")
    fr_content = fr_files[0].read_text(encoding="utf-8")

    # Extract metadata
    title = _extract_title(fr_content)
    priority = _extract_priority(fr_content)
    ac_text = _extract_section(fr_content, "Acceptance Criteria")
    if not ac_text:
        ac_text = "(No acceptance criteria found)"

    # Collect git diff
    git_diff = get_git_diff_for_docgen()

    # Resolve and render template into agent prompt
    template_text = resolve_template(docs_config.template, project_root=project_root)
    prompt = render_template(
        template_text,
        spec_title=title,
        priority=priority,
        acceptance_criteria=ac_text,
        git_diff=git_diff,
    )

    # Invoke the agent to generate docs from the rendered prompt
    content = invoke_agent(prompt, agent=docs_config.agent)

    # Resolve target path
    if project_root is not None:
        target_path = project_root / docs_config.target
    else:
        target_path = Path.cwd() / docs_config.target

    # Write agent output to target
    write_to_target(content, target_path, mode=docs_config.mode)

    logger.info("Generated docs for %s → %s", spec_id, target_path)

    return DocGenResult(
        success=True,
        spec_id=spec_id,
        target=docs_config.target,
        content=content,
    )
