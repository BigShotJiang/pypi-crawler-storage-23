"""Codex-powered spec refinement for skeleton IMPL and FR files.

This module provides:
- is_skeleton_impl: Detect template placeholder tasks in IMPL files
- generate_refinement_prompt: Assemble a Codex prompt from FR + IMPL context
- parse_refinement_result: Extract tasks/LOE/summary from Codex output
- write_refinement_to_impl: Write refined content back to IMPL file

FR authoring (parallel to IMPL refinement):
- is_skeleton_fr: Detect template placeholders in FR files
- generate_fr_refinement_prompt: Assemble a Codex prompt for FR authoring
- parse_fr_refinement_result: Extract FR sections from Codex output
- write_fr_refinement: Write authored FR content back to file

Refinement path: codex CLI via ``execute_codex()``.
The caller generates a prompt with generate_refinement_prompt(), sends it to
codex via execute_codex(), parses the result, and writes it via write_refinement_to_impl().
"""

import logging
import re
from dataclasses import dataclass
from pathlib import Path

from nspec.crud import _find_impl_file, _validate_after_write
from nspec.paths import NspecPaths, get_paths
from nspec.review import _clean_terminal_output, _extract_section, _extract_title

logger = logging.getLogger("nspec")

# Template placeholder markers that indicate a skeleton IMPL.
# These come from the IMPL template in init.py.
SKELETON_MARKERS = [
    "[First task",
    "[Second task]",
    "[Subtask:",
    "[Wire into",
    "[Unit tests for",
    "[concrete, verifiable action]",
    "[specific file or function",
    "[specific behavior to implement]",
    "[Error handling / validation]",
    "[Playwright terminal verification",
    "[Wire into existing entry points]",
    "[Wire into MCP server]",
    "[Wire into TUI if applicable]",
    "[Integration tests]",
]

# Minimum number of markers required to classify as skeleton.
# Threshold of 2 avoids false positives from legitimate brackets.
_SKELETON_THRESHOLD = 2

# Template placeholder markers for FR skeleton detection.
# These come from the FR template in resources/fr-template.md.
FR_SKELETON_MARKERS = [
    "[1-2 sentences:",
    "[What problem",
    "[What pain point",
    "[High-level description",
    "[Description]",
    "[Core happy-path behavior",
    "[Secondary behavior",
    "[Error handling — what happens",
    "[Normal operation",
    "[Invalid input rejection",
    "[Boundary conditions",
    "[How will users interact",
    "[System architecture",
    "[New CLI flags",
    "[What exists]",
    "[What to change]",
    "[What capability it provides]",
    "[Delete this section",
    "[Delete if",
]

_FR_SKELETON_THRESHOLD = 2


@dataclass
class FRRefinementPrompt:
    """Structured FR authoring prompt data."""

    spec_id: str
    title: str
    prompt_text: str


@dataclass
class FRRefinementResult:
    """Parsed FR refinement result from Codex output."""

    fr_content: str
    raw_output: str


@dataclass
class RefinementPrompt:
    """Structured refinement prompt data."""

    spec_id: str
    title: str
    fr_content: str
    current_tasks: str
    prompt_text: str


@dataclass
class RefinementResult:
    """Parsed refinement result from Codex output."""

    tasks_markdown: str
    executive_summary: str
    loe: str
    raw_output: str


def is_skeleton_impl(content: str) -> bool:
    """Detect whether an IMPL file contains template placeholder tasks.

    Extracts the Tasks section and checks for known placeholder markers
    from the IMPL template. Returns True if 2+ markers are found or if
    no Tasks section exists at all.

    Args:
        content: Full IMPL file content

    Returns:
        True if the IMPL appears to be an unrefined skeleton
    """
    tasks_section = _extract_section(content, "Tasks")

    # No Tasks section at all = skeleton
    if not tasks_section.strip():
        return True

    # Count how many skeleton markers appear in the tasks section
    marker_count = sum(1 for marker in SKELETON_MARKERS if marker in tasks_section)

    return marker_count >= _SKELETON_THRESHOLD


def is_skeleton_fr(content: str) -> bool:
    """Detect whether an FR file contains template placeholder content.

    Extracts the Acceptance Criteria section and checks for known placeholder
    markers from the FR template. Returns True if 2+ markers are found
    anywhere in the FR content.

    Args:
        content: Full FR file content

    Returns:
        True if the FR appears to be an unrefined skeleton
    """
    # Check the whole content since FR placeholders span multiple sections
    marker_count = sum(1 for marker in FR_SKELETON_MARKERS if marker in content)
    return marker_count >= _FR_SKELETON_THRESHOLD


def generate_fr_refinement_prompt(
    spec_id: str,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> FRRefinementPrompt:
    """Generate a structured FR authoring prompt from the spec title and codebase context.

    Reads the current skeleton FR to extract the title, then assembles a prompt
    asking Codex to write real FR content (problem, solution, acceptance criteria).

    Args:
        spec_id: Spec ID (e.g., "S129")
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root for config lookup

    Returns:
        FRRefinementPrompt with assembled prompt text

    Raises:
        FileNotFoundError: If FR not found
    """
    paths = get_paths(docs_root, config=paths_config, project_root=project_root)

    # Find FR file
    fr_dir = paths.active_frs_dir
    fr_pattern = f"FR-{spec_id}-*.md"
    fr_files = list(fr_dir.glob(fr_pattern))
    if not fr_files:
        raise FileNotFoundError(f"FR-{spec_id}-*.md not found")

    fr_content = fr_files[0].read_text()
    title = _extract_title(fr_content)

    # Also read IMPL if it exists for additional context
    impl_context = ""
    try:
        impl_path = _find_impl_file(spec_id, docs_root, paths_config, project_root)
        impl_content = impl_path.read_text()
        exec_summary = _extract_section(impl_content, "Executive Summary")
        if exec_summary.strip():
            impl_context = f"\n## IMPL Executive Summary (for context)\n\n{exec_summary.strip()}\n"
    except FileNotFoundError:
        pass

    prompt_text = _assemble_fr_refinement_prompt(spec_id, title, impl_context, project_root)

    return FRRefinementPrompt(
        spec_id=spec_id,
        title=title,
        prompt_text=prompt_text,
    )


def parse_fr_refinement_result(codex_output: str) -> FRRefinementResult | None:
    """Parse Codex output to extract authored FR content.

    Looks for content between FR_START/FR_END delimiters.

    Args:
        codex_output: Text output from Codex (via codex-cli MCP)

    Returns:
        FRRefinementResult if parsing succeeded, None if delimiters not found
    """
    cleaned = _clean_terminal_output(codex_output)

    fr_match = re.search(
        r"FR_START\s*\n(.*?)\nFR_END",
        cleaned,
        re.DOTALL,
    )
    if not fr_match:
        return None

    fr_content = fr_match.group(1).strip()

    return FRRefinementResult(
        fr_content=fr_content,
        raw_output=codex_output,
    )


def write_fr_refinement(
    spec_id: str,
    result: FRRefinementResult,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> Path:
    """Write authored FR content back to the FR file.

    Replaces sections (Executive Summary, Problem, Solution, Acceptance Criteria,
    Test Specifications) with the Codex-authored content while preserving the
    FR header (title, priority, status, deps).

    Args:
        spec_id: Spec ID
        result: Parsed FR refinement result from Codex
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root for config lookup

    Returns:
        Path to updated FR file

    Raises:
        FileNotFoundError: If FR not found
        ValueError: If FR is still skeleton after refinement
    """
    paths = get_paths(docs_root, config=paths_config, project_root=project_root)

    fr_dir = paths.active_frs_dir
    fr_pattern = f"FR-{spec_id}-*.md"
    fr_files = list(fr_dir.glob(fr_pattern))
    if not fr_files:
        raise FileNotFoundError(f"FR-{spec_id}-*.md not found")

    fr_path = fr_files[0]
    content = fr_path.read_text()

    # The Codex output contains the full FR body (everything after the header).
    # We preserve the header (title line, priority, status, deps, comment block)
    # and replace everything from "## Executive Summary" onward.
    header_end = _find_fr_header_end(content)
    new_content = content[:header_end] + "\n" + result.fr_content + "\n"

    fr_path.write_text(new_content)

    # Post-write validation
    _validate_after_write(spec_id, docs_root, paths_config, check_impl=False)

    # Verify refinement actually removed skeleton markers
    refreshed = fr_path.read_text()
    if is_skeleton_fr(refreshed):
        raise ValueError(
            f"FR for {spec_id} is still a skeleton after refinement. "
            "Codex output may not have produced valid content."
        )

    return fr_path


def generate_refinement_prompt(
    spec_id: str,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> RefinementPrompt:
    """Generate a structured refinement prompt from FR + IMPL context.

    Reads the FR content (problem, solution, ACs, design) and the current
    IMPL skeleton, then assembles a prompt asking Codex to replace
    placeholder tasks with real implementation tasks.

    Args:
        spec_id: Spec ID (e.g., "S077")
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root for config lookup

    Returns:
        RefinementPrompt with assembled prompt text

    Raises:
        FileNotFoundError: If FR or IMPL not found
    """
    paths = get_paths(docs_root, config=paths_config, project_root=project_root)

    # Find FR file
    fr_dir = paths.active_frs_dir
    fr_pattern = f"FR-{spec_id}-*.md"
    fr_files = list(fr_dir.glob(fr_pattern))
    if not fr_files:
        raise FileNotFoundError(f"FR-{spec_id}-*.md not found")

    fr_content = fr_files[0].read_text()

    # Find IMPL file
    impl_path = _find_impl_file(spec_id, docs_root, paths_config, project_root)
    impl_content = impl_path.read_text()

    # Extract title from FR
    title = _extract_title(fr_content)

    # Extract current tasks section from IMPL
    current_tasks = _extract_section(impl_content, "Tasks")
    if not current_tasks:
        current_tasks = "(No tasks section found)"

    # Truncate FR content if very large
    max_fr_chars = 10000
    if len(fr_content) > max_fr_chars:
        fr_content_for_prompt = fr_content[:max_fr_chars] + "\n\n... (FR truncated)"
    else:
        fr_content_for_prompt = fr_content

    # Assemble prompt
    prompt_text = _assemble_refinement_prompt(
        spec_id, title, fr_content_for_prompt, current_tasks, project_root
    )

    return RefinementPrompt(
        spec_id=spec_id,
        title=title,
        fr_content=fr_content_for_prompt,
        current_tasks=current_tasks,
        prompt_text=prompt_text,
    )


def parse_refinement_result(codex_output: str) -> RefinementResult | None:
    """Parse Codex output to extract refined tasks, LOE, and executive summary.

    Looks for content between TASKS_START/TASKS_END delimiters,
    plus EXECUTIVE_SUMMARY: and LOE: lines.

    Args:
        codex_output: Text output from Codex (via codex-cli MCP)

    Returns:
        RefinementResult if parsing succeeded, None if delimiters not found
    """
    cleaned = _clean_terminal_output(codex_output)

    # Extract tasks between delimiters
    tasks_match = re.search(
        r"TASKS_START\s*\n(.*?)\nTASKS_END",
        cleaned,
        re.DOTALL,
    )
    if not tasks_match:
        return None

    tasks_markdown = tasks_match.group(1).strip()

    # Extract executive summary
    summary_match = re.search(
        r"EXECUTIVE_SUMMARY:\s*(.+?)(?:\n\n|\nLOE:|\nTASKS_START|\Z)", cleaned, re.DOTALL
    )
    executive_summary = summary_match.group(1).strip() if summary_match else ""

    # Extract LOE
    loe_match = re.search(r"LOE:\s*(.+?)(?:\n|$)", cleaned)
    loe = loe_match.group(1).strip() if loe_match else ""

    return RefinementResult(
        tasks_markdown=tasks_markdown,
        executive_summary=executive_summary,
        loe=loe,
        raw_output=codex_output,
    )


def write_refinement_to_impl(
    spec_id: str,
    result: RefinementResult,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> Path:
    """Write refined tasks, LOE, and executive summary back to the IMPL file.

    Replaces the ## Tasks section content, updates **LOE:** field,
    and updates ## Executive Summary section.

    Args:
        spec_id: Spec ID
        result: Parsed refinement result from Codex
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root for config lookup

    Returns:
        Path to updated IMPL file

    Raises:
        FileNotFoundError: If IMPL not found
        ValueError: If IMPL is still skeleton after refinement
    """
    impl_path = _find_impl_file(spec_id, docs_root, paths_config, project_root)
    content = impl_path.read_text()

    # Replace ## Tasks section
    content = _replace_section(content, "Tasks", result.tasks_markdown)

    # Update LOE field
    if result.loe:
        content = re.sub(
            r"(\*\*LOE:\*\*)\s*\S+",
            rf"\1 {result.loe}",
            content,
            count=1,
        )

    # Update Executive Summary section
    if result.executive_summary:
        content = _replace_section(content, "Executive Summary", result.executive_summary)

    impl_path.write_text(content)

    # Post-write validation
    _validate_after_write(spec_id, docs_root, paths_config, check_fr=False)

    # Verify refinement actually removed skeleton markers
    refreshed = impl_path.read_text()
    if is_skeleton_impl(refreshed):
        raise ValueError(
            f"IMPL for {spec_id} is still a skeleton after refinement. "
            "Codex output may not have produced valid tasks."
        )

    return impl_path


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _replace_section(content: str, section_name: str, new_content: str) -> str:
    """Replace a markdown section's content (between its heading and the next same-level heading).

    Preserves the heading itself. If the section doesn't exist, returns content unchanged.
    """
    lines = content.split("\n")
    result_lines: list[str] = []
    in_section = False
    section_level = 0
    replaced = False

    for line in lines:
        if line.startswith("#"):
            level = len(line) - len(line.lstrip("#"))
            heading_text = line.lstrip("#").strip()

            if heading_text.lower() == section_name.lower() and not replaced:
                # Found the section heading - keep it and insert new content
                result_lines.append(line)
                result_lines.append("")
                result_lines.append(new_content)
                result_lines.append("")
                in_section = True
                section_level = level
                replaced = True
                continue
            elif in_section and level <= section_level:
                # End of the section - stop skipping
                in_section = False

        if not in_section:
            result_lines.append(line)

    return "\n".join(result_lines)


def _assemble_refinement_prompt(
    spec_id: str,
    title: str,
    fr_content: str,
    current_tasks: str,
    project_root: Path | None = None,
) -> str:
    """Assemble the structured refinement prompt for Codex.

    Loads the prompt template from the ``refine-impl-prompt`` resource handle.
    """
    from nspec.resources.registry import load_resource

    template = load_resource("refine-impl-prompt", project_root)
    return template.format_map(
        {
            "spec_id": spec_id,
            "title": title,
            "fr_content": fr_content,
            "current_tasks": current_tasks,
        }
    )


def _find_fr_header_end(content: str) -> int:
    """Find the character offset where the FR header ends and body begins.

    The header includes: title line, priority, status, deps, and the HTML comment block.
    The body starts at the first ``## `` heading (typically ``## Executive Summary``).

    Returns:
        Character offset of the first ``## `` heading, or len(content) if not found.
    """
    lines = content.split("\n")
    offset = 0
    for line in lines:
        if line.startswith("## "):
            return offset
        offset += len(line) + 1  # +1 for newline
    return len(content)


def _assemble_fr_refinement_prompt(
    spec_id: str,
    title: str,
    impl_context: str,
    project_root: Path | None = None,
) -> str:
    """Assemble the structured FR authoring prompt for Codex.

    Loads the prompt template from the ``refine-fr-prompt`` resource handle.
    """
    from nspec.resources.registry import load_resource

    template = load_resource("refine-fr-prompt", project_root)
    return template.format_map(
        {
            "spec_id": spec_id,
            "title": title,
            "impl_context": impl_context,
        }
    )
