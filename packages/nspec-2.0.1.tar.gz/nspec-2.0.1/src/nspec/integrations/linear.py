"""Linear integration — repo-to-Linear sync via GraphQL API.

Provides:
- FR header linkage parsing (``linear_issue_id:``)
- GraphQL client for Linear API mutations
- Payload mapping from nspec FR/IMPL state to Linear issue fields
- ``--since`` filtering for CI-friendly changed-spec detection
- ``--dry-run`` mode for previewing sync without API calls

Usage (CLI):
    nspec linear push --since HEAD~1
    nspec linear push --spec-id S168
    nspec linear push --dry-run
    nspec linear bootstrap
"""

from __future__ import annotations

import json
import logging
import os
import re
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from nspec.config import LinearConfig, NspecConfig
from nspec.datasets import DatasetLoader
from nspec.validators import FRMetadata

logger = logging.getLogger("nspec")

LINEAR_API_URL = "https://linear.app/api/graphql"

# Regex to extract linear_issue_id from FR header content
_LINEAR_ISSUE_ID_RE = re.compile(r"^linear_issue_id:\s*(\S+)\s*$", re.MULTILINE | re.IGNORECASE)


@dataclass
class SyncPayload:
    """What would be sent to Linear for a single issue."""

    spec_id: str
    linear_issue_id: str
    updates: dict[str, Any] = field(default_factory=dict)
    comment: str | None = None


@dataclass
class SyncResult:
    """Result of syncing a single spec to Linear."""

    spec_id: str
    linear_issue_id: str
    success: bool
    error: str | None = None


def parse_linear_issue_id(fr_content: str) -> str | None:
    """Extract ``linear_issue_id`` from FR file content.

    Looks for a line like ``linear_issue_id: <uuid>`` in the header
    section of the FR markdown.

    Args:
        fr_content: Raw FR file content.

    Returns:
        UUID string if found, None otherwise.
    """
    match = _LINEAR_ISSUE_ID_RE.search(fr_content)
    if match:
        return match.group(1).strip()
    return None


def _get_api_token(config: LinearConfig) -> str:
    """Read the Linear API token from the environment.

    Args:
        config: LinearConfig with token_env field.

    Returns:
        API token string.

    Raises:
        ValueError: If the env var is not set or empty.
    """
    token = os.environ.get(config.token_env, "").strip()
    if not token:
        raise ValueError(
            f"Linear API key not set. Export {config.token_env} or set "
            f"[linear] token_env in config.toml to a different env var name."
        )
    return token


def _graphql_request(
    token: str, query: str, variables: dict[str, Any] | None = None
) -> dict[str, Any]:
    """Execute a GraphQL request against Linear API.

    Args:
        token: Linear API bearer token.
        query: GraphQL query/mutation string.
        variables: Optional variables dict.

    Returns:
        Parsed JSON response data.

    Raises:
        ValueError: On GraphQL errors or HTTP failures.
    """
    payload: dict[str, Any] = {"query": query}
    if variables:
        payload["variables"] = variables

    body = json.dumps(payload).encode("utf-8")
    req = Request(
        LINEAR_API_URL,
        data=body,
        headers={
            "Content-Type": "application/json",
            "Authorization": token,
        },
        method="POST",
    )

    try:
        with urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read().decode("utf-8"))
    except HTTPError as e:
        raise ValueError(f"Linear API HTTP error {e.code}: {e.reason}") from None
    except URLError as e:
        raise ValueError(f"Linear API connection error: {e.reason}") from None

    if "errors" in result:
        errors_str = "; ".join(e.get("message", str(e)) for e in result["errors"])
        raise ValueError(f"Linear GraphQL errors: {errors_str}")

    return result.get("data", {})


def build_sync_payload(
    spec_id: str,
    linear_issue_id: str,
    fr: FRMetadata,
    impl_status: str,
    impl_completion: int,
    config: LinearConfig,
) -> SyncPayload:
    """Build a sync payload from nspec state.

    Maps FR/IMPL status to Linear issue fields using the
    configured state_mapping and priority_mapping.

    Args:
        spec_id: nspec spec ID (e.g., "S168").
        linear_issue_id: Linear issue UUID.
        fr: Parsed FR metadata.
        impl_status: IMPL status string (e.g., "Active").
        impl_completion: IMPL completion percentage (0-100).
        config: LinearConfig with mappings.

    Returns:
        SyncPayload with planned updates.
    """
    updates: dict[str, Any] = {}

    # Map priority
    priority_num = config.priority_mapping.get(fr.priority)
    if priority_num is not None:
        updates["priority"] = priority_num

    # Map state via IMPL status keyword
    for status_key, state_id in config.state_mapping.items():
        if status_key.lower() in impl_status.lower():
            updates["stateId"] = state_id
            break

    # Add labels if configured
    if config.label_ids:
        updates["labelIds"] = config.label_ids

    # Build progress comment
    comment = (
        f"[nspec sync] {spec_id}: "
        f"FR {fr.status} | IMPL {impl_status} | "
        f"Progress: {impl_completion}% "
        f"({fr.ac_completed}/{fr.ac_total} AC)"
    )

    return SyncPayload(
        spec_id=spec_id,
        linear_issue_id=linear_issue_id,
        updates=updates,
        comment=comment,
    )


def push_to_linear(payload: SyncPayload, token: str) -> SyncResult:
    """Push a sync payload to Linear via GraphQL.

    Executes an issueUpdate mutation and optionally adds a comment.

    Args:
        payload: SyncPayload with updates and optional comment.
        token: Linear API bearer token.

    Returns:
        SyncResult indicating success or failure.
    """
    if not payload.updates and not payload.comment:
        return SyncResult(
            spec_id=payload.spec_id,
            linear_issue_id=payload.linear_issue_id,
            success=True,
        )

    # Update issue fields
    if payload.updates:
        mutation = """
        mutation IssueUpdate($id: String!, $input: IssueUpdateInput!) {
            issueUpdate(id: $id, input: $input) {
                success
                issue { id title }
            }
        }
        """
        try:
            _graphql_request(
                token,
                mutation,
                {
                    "id": payload.linear_issue_id,
                    "input": payload.updates,
                },
            )
        except ValueError as e:
            return SyncResult(
                spec_id=payload.spec_id,
                linear_issue_id=payload.linear_issue_id,
                success=False,
                error=str(e),
            )

    # Add sync comment
    if payload.comment:
        comment_mutation = """
        mutation CommentCreate($input: CommentCreateInput!) {
            commentCreate(input: $input) {
                success
            }
        }
        """
        try:
            _graphql_request(
                token,
                comment_mutation,
                {
                    "input": {
                        "issueId": payload.linear_issue_id,
                        "body": payload.comment,
                    },
                },
            )
        except ValueError as e:
            return SyncResult(
                spec_id=payload.spec_id,
                linear_issue_id=payload.linear_issue_id,
                success=False,
                error=f"Issue updated but comment failed: {e}",
            )

    return SyncResult(
        spec_id=payload.spec_id,
        linear_issue_id=payload.linear_issue_id,
        success=True,
    )


def get_changed_spec_files(since_ref: str, docs_root: Path) -> list[Path]:
    """Get FR/IMPL files changed since a git ref.

    Args:
        since_ref: Git ref (commit SHA, branch, HEAD~N, etc.).
        docs_root: Path to docs directory.

    Returns:
        List of changed file paths (absolute).

    Raises:
        ValueError: If git ref is invalid or git command fails.
    """
    try:
        result = subprocess.run(
            ["git", "diff", "--name-only", since_ref, "--", str(docs_root)],
            capture_output=True,
            text=True,
            timeout=30,
            check=True,
        )
    except subprocess.CalledProcessError as e:
        raise ValueError(
            f"Invalid git ref '{since_ref}': {e.stderr.strip() or 'git diff failed'}"
        ) from None
    except subprocess.TimeoutExpired:
        raise ValueError(f"Git diff timed out for ref '{since_ref}'") from None
    except FileNotFoundError:
        raise ValueError("git not found on PATH") from None

    changed = []
    for line in result.stdout.strip().splitlines():
        path = Path(line)
        if path.name.startswith(("FR-", "IMPL-")) and path.name.endswith(".md"):
            abs_path = path if path.is_absolute() else Path.cwd() / path
            if abs_path.exists():
                changed.append(abs_path)
    return changed


def extract_spec_ids_from_paths(paths: list[Path]) -> set[str]:
    """Extract spec IDs from FR/IMPL file paths.

    Args:
        paths: List of FR/IMPL file paths.

    Returns:
        Set of spec IDs (e.g., {"S168", "S042"}).
    """
    spec_ids: set[str] = set()
    pattern = re.compile(r"(?:FR|IMPL)-((?:S|E)\d+[a-z]?)-")
    for path in paths:
        match = pattern.search(path.name)
        if match:
            spec_ids.add(match.group(1))
    return spec_ids


def linear_push(
    docs_root: Path,
    *,
    since_ref: str | None = None,
    spec_id: str | None = None,
    dry_run: bool = False,
    project_root: Path | None = None,
) -> list[SyncResult]:
    """Main sync entry point: push nspec state to Linear.

    Args:
        docs_root: Path to docs directory.
        since_ref: Git ref for ``--since`` filtering.
        spec_id: Single spec to sync (``--spec-id``).
        dry_run: If True, print planned updates without API calls.
        project_root: Project root for config loading.

    Returns:
        List of SyncResult for each synced spec.
    """
    config = NspecConfig.load(project_root)
    linear_config = config.linear

    if not linear_config.team_id:
        raise ValueError("Linear team_id not configured. Add [linear] section to config.toml.")

    token = _get_api_token(linear_config) if not dry_run else ""

    # Load datasets
    loader = DatasetLoader(docs_root=docs_root, project_root=project_root)
    datasets = loader.load()

    # Determine which specs to sync
    if spec_id:
        target_ids = {spec_id}
    elif since_ref:
        changed_paths = get_changed_spec_files(since_ref, docs_root)
        target_ids = extract_spec_ids_from_paths(changed_paths)
    else:
        target_ids = set(datasets.active_frs.keys())

    results: list[SyncResult] = []

    for sid in sorted(target_ids):
        fr = datasets.get_fr(sid)
        if not fr:
            continue

        # Read FR file to get linear_issue_id
        fr_content = fr.path.read_text()
        linear_issue_id = parse_linear_issue_id(fr_content)

        if not linear_issue_id:
            # Clean skip — no linkage
            continue

        impl = datasets.get_impl(sid)
        impl_status = impl.status if impl else "N/A"
        impl_completion = impl.completion_percent if impl else 0

        payload = build_sync_payload(
            spec_id=sid,
            linear_issue_id=linear_issue_id,
            fr=fr,
            impl_status=impl_status,
            impl_completion=impl_completion,
            config=linear_config,
        )

        if dry_run:
            print(f"[dry-run] {sid} -> Linear issue {linear_issue_id}")
            print(f"  Updates: {json.dumps(payload.updates, indent=2)}")
            if payload.comment:
                print(f"  Comment: {payload.comment}")
            results.append(
                SyncResult(
                    spec_id=sid,
                    linear_issue_id=linear_issue_id,
                    success=True,
                )
            )
        else:
            result = push_to_linear(payload, token)
            results.append(result)
            if result.success:
                print(f"Synced {sid} -> Linear issue {linear_issue_id}")
            else:
                print(
                    f"Failed {sid} (issue {linear_issue_id}): {result.error}",
                )

    return results


def linear_bootstrap(project_root: Path | None = None) -> str:
    """Print a config snippet with Linear team/workflow state IDs.

    Queries the Linear API for team and workflow state information
    to help users build their ``[linear]`` config section.

    Args:
        project_root: Project root for config loading.

    Returns:
        Config snippet string.

    Raises:
        ValueError: If API key is not set or API call fails.
    """
    config = NspecConfig.load(project_root)
    token = _get_api_token(config.linear)

    query = """
    query {
        teams {
            nodes {
                id
                name
                states {
                    nodes {
                        id
                        name
                        type
                    }
                }
            }
        }
    }
    """

    data = _graphql_request(token, query)
    teams = data.get("teams", {}).get("nodes", [])

    lines = [
        "# Add the following to .novabuilt.dev/nspec/config.toml",
        "# Adjust state_mapping to match your nspec workflow",
        "",
    ]

    for team in teams:
        lines.append("[linear]")
        lines.append(f'team_id = "{team["id"]}"')
        lines.append(f"# Team: {team['name']}")
        lines.append("")
        lines.append("[linear.state_mapping]")
        lines.append("# Map nspec status keywords -> Linear workflow state UUIDs")

        states = team.get("states", {}).get("nodes", [])
        for state in states:
            lines.append(f'# {state["name"]} ({state["type"]}) = "{state["id"]}"')

        lines.append("")
        lines.append("[linear.priority_mapping]")
        lines.append("P0 = 1  # Urgent")
        lines.append("P1 = 2  # High")
        lines.append("P2 = 3  # Medium")
        lines.append("P3 = 4  # Low")
        lines.append("")
        break  # Only show first team

    return "\n".join(lines)
