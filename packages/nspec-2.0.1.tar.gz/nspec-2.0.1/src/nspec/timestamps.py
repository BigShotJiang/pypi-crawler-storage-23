"""Centralized timestamp generation for audit trails.

All nspec mutations use this module to produce consistent ISO-8601 timestamps.
The format is YYYY-MM-DDTHH:MM:SS (no subseconds, no timezone) to keep
timestamps readable in markdown while remaining machine-parseable.

The `_clock` indirection allows tests to freeze time without monkeypatching.
"""

from __future__ import annotations

from collections.abc import Callable
from datetime import datetime

# Injectable clock for deterministic tests.
_clock: Callable[[], datetime] = datetime.now


def now_iso() -> str:
    """Return the current local time as ``YYYY-MM-DDTHH:MM:SS``."""
    return _clock().isoformat(timespec="seconds")
