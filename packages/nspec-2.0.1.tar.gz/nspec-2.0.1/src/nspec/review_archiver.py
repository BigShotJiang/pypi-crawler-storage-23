from __future__ import annotations

import shutil
from datetime import date
from pathlib import Path


def write_index(dest_dir: Path, archived: list[Path], archive_date: str) -> Path:
    index_path = dest_dir / "INDEX.md"
    lines: list[str] = []
    lines.append(f"# Review Packet Archive ({archive_date})")
    lines.append("")
    if not archived:
        lines.append("No review packets found under `work/review/*/REVIEW.md`.")
        lines.append("")
        index_path.write_text("\n".join(lines) + "\n")
        return index_path

    lines.append("## Archived Packets")
    for path in sorted(archived):
        lines.append(f"- `{path.as_posix()}`")
    lines.append("")
    index_path.write_text("\n".join(lines) + "\n")
    return index_path


def archive_one(
    *,
    project_root: Path,
    docs_root: Path,
    target_spec_id: str,
    archive_date: str | None = None,
    source_root: Path | None = None,
) -> tuple[Path, Path, Path]:
    """Archive a single target spec's review packet.

    Copies `<source_root>/<target_spec_id>/REVIEW.md` into:
      `docs/review/archives/YYYY-MM-DD/<target_spec_id>.md`
    and refreshes the per-day INDEX.md.
    """
    archive_date = archive_date or date.today().isoformat()
    target_spec_id = target_spec_id.strip().upper()

    effective_root = source_root or (project_root / "work" / "review")
    source_path = effective_root / target_spec_id / "REVIEW.md"
    if not source_path.exists():
        raise FileNotFoundError(f"Missing review packet: {source_path}")

    dest_dir = docs_root / "review" / "archives" / archive_date
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest_path = dest_dir / f"{target_spec_id}.md"
    shutil.copyfile(source_path, dest_path)

    archived_paths = sorted(path for path in dest_dir.glob("S*.md") if path.name != "INDEX.md")
    index_path = write_index(dest_dir, archived_paths, archive_date)
    return dest_path, index_path, dest_dir
