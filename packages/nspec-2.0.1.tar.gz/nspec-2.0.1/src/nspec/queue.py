"""Agent Assignment Queue for multi-agent parallel execution.

Provides atomic claim/release semantics on top of the existing
``eligible_next_specs()`` ordering. Agents claim specs from the queue,
work independently, and release on completion or crash. Lease-based
timeout recovery ensures crashed agents don't block the queue.

Queue state is persisted to ``.novabuilt.dev/nspec/queue.json``
(separate from ``state.json`` to avoid multi-agent collision).
"""

from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from nspec.timestamps import now_iso

QUEUE_FILE = ".novabuilt.dev/nspec/queue.json"

# Default config values (overridden by [queue] in config.toml)
DEFAULT_MAX_AGENTS = 5
DEFAULT_LEASE_TTL_SECONDS = 300  # 5 minutes


@dataclass
class QueueEntry:
    """A single spec in the queue."""

    spec_id: str
    priority: str
    title: str
    assigned_to: str | None = None
    lease_expires: float | None = None
    claimed_at: float | None = None

    @property
    def is_claimed(self) -> bool:
        return self.assigned_to is not None

    @property
    def is_expired(self) -> bool:
        if self.lease_expires is None:
            return False
        return time.time() > self.lease_expires


@dataclass
class QueueState:
    """Full queue state, serialized to queue.json."""

    epic_id: str | None = None
    entries: list[QueueEntry] = field(default_factory=list)
    completed: list[str] = field(default_factory=list)
    max_agents: int = DEFAULT_MAX_AGENTS
    lease_ttl_seconds: int = DEFAULT_LEASE_TTL_SECONDS
    created_at: str = ""
    updated_at: str = ""

    def __post_init__(self) -> None:
        now = now_iso()
        if not self.created_at:
            self.created_at = now
        if not self.updated_at:
            self.updated_at = now


class QueueDAO:
    """Data access object for queue.json.

    All mutations acquire the queue lock to prevent races between
    concurrent agents. The lock is separate from per-spec locks.
    """

    def __init__(self, project_root: Path) -> None:
        self._project_root = project_root

    @property
    def queue_path(self) -> Path:
        return self._project_root / QUEUE_FILE

    def exists(self) -> bool:
        return self.queue_path.exists()

    def load(self) -> QueueState | None:
        """Load queue state from disk. Returns None if no queue file."""
        path = self.queue_path
        if not path.exists():
            return None
        try:
            data = json.loads(path.read_text())
            entries = [QueueEntry(**e) for e in data.get("entries", [])]
            return QueueState(
                epic_id=data.get("epic_id"),
                entries=entries,
                completed=data.get("completed", []),
                max_agents=data.get("max_agents", DEFAULT_MAX_AGENTS),
                lease_ttl_seconds=data.get("lease_ttl_seconds", DEFAULT_LEASE_TTL_SECONDS),
                created_at=data.get("created_at", ""),
                updated_at=data.get("updated_at", ""),
            )
        except (json.JSONDecodeError, TypeError, KeyError):
            return None

    def save(self, state: QueueState) -> Path:
        """Save queue state to disk atomically.

        Uses atomic_write (temp file + os.replace) so that concurrent
        lock-free readers never observe a partially written file.
        """
        from nspec.atomic import atomic_write

        state.updated_at = now_iso()
        path = self.queue_path

        data: dict[str, Any] = {
            "epic_id": state.epic_id,
            "entries": [asdict(e) for e in state.entries],
            "completed": state.completed,
            "max_agents": state.max_agents,
            "lease_ttl_seconds": state.lease_ttl_seconds,
            "created_at": state.created_at,
            "updated_at": state.updated_at,
        }
        atomic_write(path, json.dumps(data, indent=2) + "\n")
        return path

    def get_agent_spec(self, agent_id: str) -> str | None:
        """Return the spec_id claimed by agent_id, or None."""
        state = self.load()
        if state is None:
            return None
        for entry in state.entries:
            if entry.assigned_to == agent_id and not entry.is_expired:
                return entry.spec_id
        return None

    def clear(self) -> bool:
        """Delete the queue file. Returns True if it existed."""
        path = self.queue_path
        if path.exists():
            path.unlink()
            return True
        return False

    def initialize_from_backlog(
        self,
        docs_root: Path,
        epic_id: str | None = None,
        max_agents: int = DEFAULT_MAX_AGENTS,
        lease_ttl: int = DEFAULT_LEASE_TTL_SECONDS,
    ) -> QueueState:
        """Populate queue from eligible_next_specs().

        Creates a fresh queue, discarding any previous state.
        Acquires the queue lock to prevent races during initialization.

        Args:
            docs_root: Docs root directory for loading datasets.
            epic_id: Optional epic ID to filter specs (normalized to E### format).
            max_agents: Maximum concurrent agents.
            lease_ttl: Lease TTL in seconds.

        Returns:
            The new QueueState.
        """
        from nspec.datasets import DatasetLoader
        from nspec.locks import queue_lock
        from nspec.ordering import eligible_next_specs

        # Normalize epic_id to E### format if provided
        if epic_id is not None:
            from nspec.ids import normalize_spec_ref

            epic_id = normalize_spec_ref(epic_id)

        with queue_lock():
            datasets = DatasetLoader(docs_root).load()
            candidates = eligible_next_specs(datasets, epic_id=epic_id)

            entries = [
                QueueEntry(
                    spec_id=c["spec_id"],
                    priority=c["priority"],
                    title=c["title"],
                )
                for c in candidates
            ]

            state = QueueState(
                epic_id=epic_id,
                entries=entries,
                max_agents=max_agents,
                lease_ttl_seconds=lease_ttl,
            )
            self.save(state)
            return state

    def reap_expired_leases(self, state: QueueState) -> list[str]:
        """Reclaim specs from agents whose leases have expired.

        Called on every queue operation. Modifies state in-place.

        Returns:
            List of spec_ids that were reclaimed.
        """
        reclaimed: list[str] = []
        now = time.time()
        for entry in state.entries:
            if entry.assigned_to and entry.lease_expires and now > entry.lease_expires:
                reclaimed.append(entry.spec_id)
                entry.assigned_to = None
                entry.lease_expires = None
                entry.claimed_at = None
        return reclaimed

    def claim(self, agent_id: str) -> dict[str, Any]:
        """Atomically claim the next unclaimed spec.

        Acquires the queue lock, reaps expired leases, finds the first
        unclaimed entry, assigns it, and saves.

        Args:
            agent_id: Unique identifier for the claiming agent.

        Returns:
            Dict with assignment details, or error if queue empty/full.
        """
        from nspec.locks import queue_lock

        with queue_lock():
            state = self.load()
            if state is None:
                return {"error": "No queue initialized. Call queue_init first."}

            self.reap_expired_leases(state)

            # Check agent limit
            active_agents = {e.assigned_to for e in state.entries if e.assigned_to}
            if agent_id not in active_agents and len(active_agents) >= state.max_agents:
                return {
                    "error": f"Max agents ({state.max_agents}) reached. "
                    f"Wait for an agent to finish or increase max_agents.",
                    "active_agents": len(active_agents),
                }

            # Check if this agent already has a claim
            for entry in state.entries:
                if entry.assigned_to == agent_id:
                    return {
                        "error": f"Agent {agent_id} already has spec {entry.spec_id} claimed. "
                        f"Release it first.",
                        "current_assignment": entry.spec_id,
                    }

            # Find first unclaimed entry
            for entry in state.entries:
                if not entry.is_claimed:
                    now = time.time()
                    entry.assigned_to = agent_id
                    entry.claimed_at = now
                    entry.lease_expires = now + state.lease_ttl_seconds
                    self.save(state)
                    return {
                        "spec_id": entry.spec_id,
                        "title": entry.title,
                        "priority": entry.priority,
                        "agent_id": agent_id,
                        "lease_expires": entry.lease_expires,
                    }

            return {"error": "Queue empty — no unclaimed specs remaining."}

    def release(
        self,
        agent_id: str,
        spec_id: str,
        reason: str | None = None,
        completed: bool = False,
    ) -> dict[str, Any]:
        """Release a claimed spec back to the queue or mark it completed.

        Args:
            agent_id: The agent releasing the spec.
            spec_id: The spec being released.
            reason: Optional reason for release (logged).
            completed: If True, move spec to completed list instead of re-queuing.

        Returns:
            Dict with release confirmation or error.
        """
        from nspec.locks import queue_lock

        with queue_lock():
            state = self.load()
            if state is None:
                return {"error": "No queue initialized."}

            self.reap_expired_leases(state)

            for entry in state.entries:
                if entry.spec_id == spec_id:
                    if entry.assigned_to != agent_id:
                        return {
                            "error": f"Spec {spec_id} is not assigned to {agent_id}. "
                            f"Current owner: {entry.assigned_to or 'unclaimed'}",
                        }

                    if completed:
                        state.entries.remove(entry)
                        state.completed.append(spec_id)
                    else:
                        entry.assigned_to = None
                        entry.lease_expires = None
                        entry.claimed_at = None

                    self.save(state)
                    return {
                        "released": True,
                        "spec_id": spec_id,
                        "agent_id": agent_id,
                        "completed": completed,
                        "reason": reason,
                    }

            return {"error": f"Spec {spec_id} not found in queue."}

    def heartbeat(self, agent_id: str) -> dict[str, Any]:
        """Extend lease for an agent's current claim.

        Args:
            agent_id: The agent sending the heartbeat.

        Returns:
            Dict with updated lease expiry, or error.
        """
        from nspec.locks import queue_lock

        with queue_lock():
            state = self.load()
            if state is None:
                return {"error": "No queue initialized."}

            self.reap_expired_leases(state)

            for entry in state.entries:
                if entry.assigned_to == agent_id:
                    now = time.time()
                    entry.lease_expires = now + state.lease_ttl_seconds
                    self.save(state)
                    return {
                        "lease_extended": True,
                        "agent_id": agent_id,
                        "spec_id": entry.spec_id,
                        "expires": entry.lease_expires,
                    }

            return {"error": f"No active claim found for agent {agent_id}."}

    def _format_status(self, state: QueueState) -> dict[str, Any]:
        """Format a QueueState into the standard status dict."""
        agents = []
        queued = []
        for entry in state.entries:
            if entry.is_claimed:
                agents.append(
                    {
                        "agent_id": entry.assigned_to,
                        "spec_id": entry.spec_id,
                        "title": entry.title,
                        "priority": entry.priority,
                        "lease_expires": entry.lease_expires,
                        "claimed_at": entry.claimed_at,
                    }
                )
            else:
                queued.append(
                    {
                        "spec_id": entry.spec_id,
                        "title": entry.title,
                        "priority": entry.priority,
                    }
                )

        return {
            "epic_id": state.epic_id,
            "agents": agents,
            "queued": queued,
            "completed": state.completed,
            "max_agents": state.max_agents,
            "lease_ttl_seconds": state.lease_ttl_seconds,
            "total_entries": len(state.entries),
            "active_agents": len(agents),
            "specs_remaining": len(queued),
            "specs_completed": len(state.completed),
        }

    def status(self) -> dict[str, Any]:
        """Get full queue status with lock-protected lease reaping.

        Acquires the queue lock, reaps expired leases, and persists changes.
        Use this for MCP tools and CLI commands that need authoritative state.

        Returns:
            Dict with agents, queued specs, completed specs, and metadata.
        """
        from nspec.locks import queue_lock

        with queue_lock():
            state = self.load()
            if state is None:
                return {"error": "No queue initialized."}

            self.reap_expired_leases(state)
            self.save(state)  # Persist any reaping

        return self._format_status(state)

    def status_snapshot(self) -> dict[str, Any]:
        """Read-only queue status without locking or persisting.

        Reads queue state and reaps expired leases in-memory only.
        Suitable for display polling (status bar, report tabs) where
        slightly stale data is acceptable and lock contention must be avoided.

        Returns:
            Dict with agents, queued specs, completed specs, and metadata.
        """
        state = self.load()
        if state is None:
            return {"error": "No queue initialized."}

        self.reap_expired_leases(state)
        return self._format_status(state)
