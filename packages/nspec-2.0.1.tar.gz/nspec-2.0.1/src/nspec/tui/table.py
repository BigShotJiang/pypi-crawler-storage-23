"""NspecTable widget for the Nspec TUI."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, ClassVar

from textual.message import Message
from textual.widgets import DataTable

from nspec.config import NspecConfig, TuiConfig
from nspec.ordering import PRIORITY_RANK, STATUS_RANK, spec_to_epic_map
from nspec.statuses import (
    DepDisplayEmoji,
    get_dep_display_emoji,
    parse_status_text,
)
from nspec.validators import _format_hours_to_loe

from .display_modes import SortDirection, SortMode, ViewPreset
from .filters import FilterEngine
from .utils import clean_title, format_status

if TYPE_CHECKING:
    from rich.style import Style

    from nspec.validators import FRMetadata

    from .state import NspecData

# Tree-drawing characters per priority: (top, mid, bot, horiz)
# P0/P1 use heavy box-drawing; P2/P3 use light
_PRIORITY_TREE_CHARS: dict[str, tuple[str, str, str, str]] = {
    "P0": ("┏", "┃", "┗", "━"),
    "P1": ("┏", "┃", "┗", "━"),
    "P2": ("┌", "│", "└", "─"),
    "P3": ("┌", "│", "└", "─"),
}
_DEFAULT_TREE_CHARS: tuple[str, str, str, str] = ("┌", "│", "└", "─")

# Style modifiers per priority (no colors — TCSS only)
_PRIORITY_TREE_STYLE: dict[str, str] = {"P0": "bold", "P1": "", "P2": "", "P3": "dim"}


def _get_tree_chars(priority: str) -> tuple[str, str, str, str]:
    """Return (top, mid, bot, horiz) box-drawing chars for a priority level."""
    return _PRIORITY_TREE_CHARS.get(priority, _DEFAULT_TREE_CHARS)


def _styled_tree_char(char: str, priority: str) -> str:
    """Wrap a tree-drawing character in Rich markup based on priority."""
    style = _PRIORITY_TREE_STYLE.get(priority, "")
    if style:
        return f"[{style}]{char}[/]"
    return char


def _load_tui_config() -> TuiConfig:
    """Load TUI display config from config.toml."""
    return NspecConfig.load().tui


def apply_sort(
    spec_data: list[tuple[str, str, str, str, str, str, str]],
    sort_mode: SortMode,
    status_rank_map: dict[str, int] | None = None,
    sort_direction: SortDirection = SortDirection.ASC,
) -> list[tuple[str, str, str, str, str, str, str]]:
    """Apply display-only sort to spec_data rows.

    Tuple layout: (spec_id, priority, status_str, title, deps, dependents, estimate)
    """
    if sort_mode == SortMode.DEPENDENCY:
        if sort_direction == SortDirection.DESC:
            return list(reversed(spec_data))
        return spec_data  # Already in dependency order

    def _extract_num(spec_id: str) -> int:
        """Extract numeric part from spec ID (e.g., 'S122' -> 122)."""
        digits = "".join(c for c in spec_id if c.isdigit())
        return int(digits) if digits else 0

    reverse = sort_direction == SortDirection.DESC
    ranks = status_rank_map or {}

    if sort_mode == SortMode.PRIORITY:
        original_index = {id(row): idx for idx, row in enumerate(spec_data)}
        return sorted(
            spec_data,
            key=lambda r: (PRIORITY_RANK.get(r[1], 9), original_index[id(r)]),
            reverse=reverse,
        )
    if sort_mode == SortMode.STATUS:
        return sorted(
            spec_data,
            key=lambda r: (ranks.get(r[0], 99), PRIORITY_RANK.get(r[1], 9)),
            reverse=reverse,
        )
    if sort_mode == SortMode.ID:
        return sorted(spec_data, key=lambda r: _extract_num(r[0]), reverse=reverse)
    # SortMode.ALPHA
    return sorted(spec_data, key=lambda r: r[3].lower(), reverse=reverse)


def calculate_epic_progress(data: NspecData, epic_id: str) -> str:
    """Calculate epic completion progress string like '3/7'."""
    if not data.datasets:
        return "0/0"

    epic_fr = data.datasets.active_frs.get(epic_id)
    if not epic_fr or not epic_fr.deps:
        return "0/0"

    total = 0
    completed = 0
    for dep_id in epic_fr.deps:
        # Skip epic-to-epic deps (check both active and completed)
        dep_fr = data.datasets.active_frs.get(dep_id)
        if dep_fr and dep_fr.type == "Epic":
            continue
        completed_fr = data.datasets.completed_frs.get(dep_id)
        if completed_fr and completed_fr.type == "Epic":
            continue
        total += 1
        if dep_id in data.datasets.completed_frs:
            completed += 1

    return f"{completed}/{total}"


def sort_epic_groups(
    data: NspecData,
    grouped: dict[str | None, list[tuple[str, str, str, str, str, str, str]]],
    epic_ids: set[str],
    sort_mode: SortMode,
    sort_direction: SortDirection,
    status_rank_map: dict[str, int] | None = None,
    unassigned_first: bool = False,
) -> list[str | None]:
    """Order epic groups based on the active sort mode.

    Returns an ordered list of epic IDs (and None for unassigned) to iterate.
    By default, "Unassigned" (None) is always last; pass unassigned_first=True
    to place it first instead.
    """

    def _extract_epic_num(epic_id: str) -> int:
        digits = "".join(c for c in epic_id if c.isdigit())
        return int(digits) if digits else 0

    reverse = sort_direction == SortDirection.DESC
    epic_keys = [eid for eid in grouped if eid is not None and eid in epic_ids]

    if sort_mode == SortMode.DEPENDENCY:
        # Preserve canonical ordering from ordered_specs
        order_index = {sid: i for i, sid in enumerate(data.ordered_specs)}
        epic_keys.sort(key=lambda eid: order_index.get(eid, 9999), reverse=reverse)

    elif sort_mode == SortMode.PRIORITY:
        epic_keys.sort(
            key=lambda eid: (
                PRIORITY_RANK.get(
                    (
                        data.datasets.active_frs.get(eid).priority
                        if data.datasets and data.datasets.active_frs.get(eid)
                        else "P3"
                    ),
                    3,
                ),
                eid,
            ),
            reverse=reverse,
        )

    elif sort_mode == SortMode.STATUS:
        # Sort by best (most active) child spec status within group
        ranks = status_rank_map or {}

        def _best_child_status(eid: str) -> int:
            group_rows = grouped.get(eid, [])
            if not group_rows:
                return 99
            return min(ranks.get(row[0], 99) for row in group_rows)

        def _epic_priority_rank(eid: str) -> int:
            if data.datasets:
                efr = data.datasets.active_frs.get(eid)
                if efr:
                    return PRIORITY_RANK.get(efr.priority, 9)
            return 9

        epic_keys.sort(
            key=lambda eid: (_best_child_status(eid), _epic_priority_rank(eid), eid),
            reverse=reverse,
        )

    elif sort_mode == SortMode.ID:
        epic_keys.sort(key=_extract_epic_num, reverse=reverse)

    elif sort_mode == SortMode.ALPHA:

        def _epic_title(eid: str) -> str:
            if data.datasets:
                fr = data.datasets.active_frs.get(eid)
                if fr:
                    return clean_title(fr.title).lower()
            return eid.lower()

        epic_keys.sort(key=_epic_title, reverse=reverse)

    # Place unassigned group
    result: list[str | None] = list(epic_keys)
    if None in grouped:
        if unassigned_first:
            result.insert(0, None)
        else:
            result.append(None)
    return result


class NspecTable(DataTable):
    """Custom DataTable for nspec display."""

    COMPONENT_CLASSES: ClassVar[set[str]] = DataTable.COMPONENT_CLASSES | {
        "nspectable--epic-header",
    }

    class SpecSelected(Message):
        """Message sent when a spec is selected."""

        def __init__(self, spec_id: str) -> None:
            """Initialize with spec ID."""
            super().__init__()
            self.spec_id = spec_id

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """Initialize nspec table."""
        super().__init__(*args, **kwargs)
        self.cursor_type = "row"
        self.zebra_stripes = True
        self.show_header = False
        self._header_row_keys: set[str] = set()

    def _get_row_style(self, row_index: int, base_style: Style) -> Style:
        """Apply epic header styling to header rows."""
        if row_index >= 0:
            row_key = self._row_locations.get_key(row_index)
            if row_key is not None and str(row_key.value).startswith("__hdr_"):
                return self.get_component_styles("nspectable--epic-header").rich_style
        return super()._get_row_style(row_index, base_style)

    def populate(
        self,
        data: NspecData,
        search_query: str = "",
        epic_filter: str | None = None,
        viewport_width: int = 120,
        view_preset: ViewPreset = ViewPreset.STANDARD,
        sort_mode: SortMode = SortMode.DEPENDENCY,
        sort_direction: SortDirection = SortDirection.ASC,
        filter_engine: FilterEngine | None = None,
    ) -> int:
        """Populate table with nspec data. Returns row count."""
        self.clear(columns=True)

        if not data.datasets:
            return 0

        tui_cfg = _load_tui_config()
        col_widths = {
            "id": tui_cfg.col_id,
            "priority": tui_cfg.col_priority,
            "status": tui_cfg.col_status,
            "deps": tui_cfg.col_upstream,
            "dependents": tui_cfg.col_downstream,
            "estimate": tui_cfg.col_estimate,
        }

        # Calculate fixed column width based on view preset
        visible_cols = view_preset.columns()
        fixed_cols_total = sum(w for k, w in col_widths.items() if k in visible_cols)
        min_title_width = tui_cfg.min_title_width

        epic_scope: set[str] | None = None
        completed_in_epic: list[str] = []
        if epic_filter and not search_query:
            epic_scope, completed_in_epic = self._get_epic_scope_with_completed(data, epic_filter)

        search_lower = search_query.lower()

        # Determine if epic grouping is active
        # (no search, no epic filter — sort mode controls ordering within groups)
        use_grouping = not search_query and not epic_filter

        # Build spec-to-epic mapping for grouped display
        spec_to_epic: dict[str, str] = {}
        epic_ids: set[str] = set()
        if use_grouping:
            spec_to_epic, epic_ids = spec_to_epic_map(data.datasets)

        # Collect spec data - title auto-expands so no truncation needed
        spec_data: list[tuple[str, str, str, str, str, str, str]] = []
        seen_ids: set[str] = set()  # Track IDs to avoid duplicates
        # Map spec_id → status rank for sorting (built from raw status text)
        status_rank_map: dict[str, int] = {}

        for spec_id in data.ordered_specs:
            # Skip epic entries in grouped mode (they become header rows)
            if use_grouping and spec_id in epic_ids:
                continue

            if epic_scope is not None and spec_id not in epic_scope:
                continue

            fr = data.datasets.get_fr(spec_id)
            impl = data.datasets.get_impl(spec_id)

            if not fr:
                continue

            title = clean_title(fr.title)
            if search_query:
                searchable = f"{spec_id} {title} {fr.priority}".lower()
                if search_lower not in searchable:
                    continue

            # Apply composable filter predicates
            if filter_engine and filter_engine.is_active and not filter_engine.matches(fr, impl):
                continue

            deps_str = self._format_deps(data, fr.deps)
            dependents_str = self._format_dependents(data, spec_id)
            raw_status = impl.status if impl else fr.status
            status_str = format_status(raw_status)
            estimate = impl.effective_loe if impl else "TBD"

            spec_data.append(
                (spec_id, fr.priority, status_str, title, deps_str, dependents_str, estimate)
            )
            status_rank_map[spec_id] = STATUS_RANK.get(parse_status_text(raw_status), 99)
            seen_ids.add(spec_id)

        # Add completed specs when filtering by epic (no search)
        completed_rank = STATUS_RANK.get("completed", 99)
        if epic_filter and completed_in_epic and not search_query:
            for spec_id in completed_in_epic:
                fr = data.datasets.completed_frs.get(spec_id)
                impl = data.datasets.completed_impls.get(spec_id)

                if not fr:
                    continue

                # Apply composable filter predicates to completed specs too
                if (
                    filter_engine
                    and filter_engine.is_active
                    and not filter_engine.matches(fr, impl)
                ):
                    continue

                title = clean_title(fr.title)
                status_str = "✅"
                estimate = impl.effective_loe if impl else "—"
                deps_str = self._format_deps(data, fr.deps)
                dependents_str = self._format_dependents(data, spec_id)
                spec_data.append(
                    (spec_id, fr.priority, status_str, title, deps_str, dependents_str, estimate)
                )
                status_rank_map[spec_id] = completed_rank

        # Search completed specs when there's a search query
        if search_query:
            for spec_id, fr in data.datasets.completed_frs.items():
                if spec_id in seen_ids:  # Skip duplicates
                    continue

                title = clean_title(fr.title)
                searchable = f"{spec_id} {title} {fr.priority}".lower()
                if search_lower not in searchable:
                    continue

                # Apply composable filter predicates to completed specs too
                impl = data.datasets.completed_impls.get(spec_id)
                if (
                    filter_engine
                    and filter_engine.is_active
                    and not filter_engine.matches(fr, impl)
                ):
                    continue
                status_str = "✅"
                estimate = impl.effective_loe if impl else "—"
                deps_str = self._format_deps(data, fr.deps)
                dependents_str = self._format_dependents(data, spec_id)
                spec_data.append(
                    (spec_id, fr.priority, status_str, title, deps_str, dependents_str, estimate)
                )
                status_rank_map[spec_id] = completed_rank

        # Show all completed specs when no epic filter and no search query.
        # This keeps "All Specs" consistent with epic views, which include completed specs.
        if not epic_filter and not search_query:
            for spec_id in sorted(data.datasets.completed_frs.keys()):
                if spec_id in seen_ids:
                    continue
                fr = data.datasets.completed_frs.get(spec_id)
                if not fr:
                    continue
                # Skip completed epics — they're header rows, not spec rows
                if use_grouping and fr.type == "Epic":
                    continue
                # Apply composable filter predicates to completed specs too
                impl = data.datasets.completed_impls.get(spec_id)
                if (
                    filter_engine
                    and filter_engine.is_active
                    and not filter_engine.matches(fr, impl)
                ):
                    continue
                title = clean_title(fr.title)
                status_str = "✅"
                estimate = impl.effective_loe if impl else "—"
                deps_str = self._format_deps(data, fr.deps)
                dependents_str = self._format_dependents(data, spec_id)
                spec_data.append(
                    (spec_id, fr.priority, status_str, title, deps_str, dependents_str, estimate)
                )
                status_rank_map[spec_id] = completed_rank

        # Apply sort mode (display-only reordering) — only for flat display;
        # grouped display sorts within _add_grouped_rows instead
        if not use_grouping:
            spec_data = apply_sort(spec_data, sort_mode, status_rank_map, sort_direction)

        # Tree chars are merged into the status column (no separate tree column)

        # Calculate title width from available space
        # Dynamic overhead: DataTable cell_padding=1 (2 chars/col) + scrollbar gutter
        num_columns = len(visible_cols)
        col_padding = num_columns * 2  # cell_padding=1 per side
        scrollbar_gutter = 1  # scrollbar-gutter: stable, scrollbar-size-vertical: 1
        title_width = max(
            min_title_width, viewport_width - fixed_cols_total - col_padding - scrollbar_gutter
        )

        # Build final rows - apply dim styling for completed specs and truncate titles
        def truncate_title(t: str, max_len: int) -> str:
            """Truncate title to max length with ellipsis."""
            if len(t) <= max_len:
                return t
            return t[: max_len - 1] + "…"

        rows: list[tuple[str, str, str, str, str, str, str]] = []
        for spec_id, priority, status_str, title, deps_str, dependents_str, estimate in spec_data:
            truncated = truncate_title(title, title_width)
            if status_str == "✅":
                display_title = f"[dim]{truncated}[/]"
            elif status_str == "⚠️":
                # Exception status: bold title for visual distinction
                display_title = f"[bold]{truncated}[/]"
            else:
                display_title = truncated
            rows.append(
                (spec_id, priority, status_str, display_title, deps_str, dependents_str, estimate)
            )

        # Map sort modes to column keys for header indicators
        sort_col_map = {
            SortMode.ID: "id",
            SortMode.PRIORITY: "priority",
            SortMode.STATUS: "status",
            SortMode.ALPHA: "title",
        }
        active_sort_col = sort_col_map.get(sort_mode)
        arrow = sort_direction.indicator if active_sort_col else ""

        # Column definitions keyed by column key
        column_defs = {
            "id": ("ID", col_widths["id"]),
            "priority": ("Pr", col_widths["priority"]),
            "status": ("St", col_widths["status"]),
            "title": ("Title", title_width),
            "deps": ("Up", col_widths["deps"]),
            "dependents": ("Dn", col_widths["dependents"]),
            "estimate": ("Est", col_widths["estimate"]),
        }

        # Add sort direction indicator to active column header
        if active_sort_col and active_sort_col in column_defs:
            label, width = column_defs[active_sort_col]
            column_defs[active_sort_col] = (f"{label}{arrow}", width)

        # Add only columns included in the view preset
        for col_key in visible_cols:
            label, width = column_defs[col_key]
            self.add_column(label, key=col_key, width=width)

        # Map column keys to row tuple indices
        col_index = {
            "id": 0,
            "priority": 1,
            "status": 2,
            "title": 3,
            "deps": 4,
            "dependents": 5,
            "estimate": 6,
        }

        # Add rows to table
        if use_grouping:
            return self._add_grouped_rows(
                data,
                rows,
                spec_to_epic,
                epic_ids,
                visible_cols,
                col_index,
                title_width,
                sort_mode,
                sort_direction,
                status_rank_map,
            )

        # Flat display — add rows with only visible columns
        for row in rows:
            visible_values = tuple(row[col_index[k]] for k in visible_cols)
            self.add_row(*visible_values, key=row[0])  # key is always spec_id

        return len(rows)

    @staticmethod
    def _apply_sort(
        spec_data: list[tuple[str, str, str, str, str, str, str]],
        sort_mode: SortMode,
        status_rank_map: dict[str, int] | None = None,
        sort_direction: SortDirection = SortDirection.ASC,
    ) -> list[tuple[str, str, str, str, str, str, str]]:
        """Apply display-only sort to spec_data rows (delegates to module-level)."""
        return apply_sort(spec_data, sort_mode, status_rank_map, sort_direction)

    def _get_epic_scope(self, data: NspecData, epic_id: str) -> set[str]:
        """Get the epic and its direct dependencies (no transitive traversal).

        Specs should only appear under their direct parent epic,
        not under grandparent epics.
        """
        result = {epic_id}
        fr = data.datasets.get_fr(epic_id) if data.datasets else None
        if fr and fr.deps:
            result.update(fr.deps)
        return result

    def _get_epic_scope_with_completed(
        self, data: NspecData, epic_id: str
    ) -> tuple[set[str], list[str]]:
        """Get epic scope split into active and completed specs.

        Returns:
            Tuple of (active_scope set, completed_specs list)
        """
        active_scope = {epic_id}
        completed_specs: list[str] = []

        fr = data.datasets.get_fr(epic_id) if data.datasets else None
        if fr and fr.deps:
            for dep_id in fr.deps:
                if data.datasets and dep_id in data.datasets.completed_frs:
                    completed_specs.append(dep_id)
                else:
                    active_scope.add(dep_id)

        return active_scope, completed_specs

    def _format_deps(self, data: NspecData, deps: list[str]) -> str:
        """Format dependencies with status emoji prefix."""
        if not deps or not data.datasets:
            return ""

        def is_superseded(dep_id: str) -> bool:
            dep_fr = data.datasets.active_frs.get(dep_id) if data.datasets else None
            return dep_fr is not None and "superseded" in dep_fr.status.lower()

        def is_epic(dep_id: str) -> bool:
            if not data.datasets:
                return False
            fr = data.datasets.active_frs.get(dep_id) or data.datasets.completed_frs.get(dep_id)
            return fr is not None and fr.type == "Epic"

        filtered_deps = [d for d in deps if not is_superseded(d) and not is_epic(d)]
        if not filtered_deps:
            return ""

        nspec_order = {sid: idx for idx, sid in enumerate(data.ordered_specs)}

        def dep_sort_key(dep_id: str) -> tuple[int, int, str]:
            if data.datasets and dep_id in data.datasets.completed_frs:
                return (0, 0, dep_id)
            elif dep_id in nspec_order:
                return (1, nspec_order[dep_id], dep_id)
            else:
                return (2, 9999, dep_id)

        sorted_deps = sorted(filtered_deps, key=dep_sort_key)[:2]

        def format_single_dep(dep_id: str) -> str:
            if data.datasets and dep_id in data.datasets.completed_frs:
                return f"{DepDisplayEmoji.COMPLETED}{dep_id}"
            elif data.datasets and dep_id in data.datasets.active_frs:
                dep_fr = data.datasets.active_frs[dep_id]
                emoji = get_dep_display_emoji(dep_fr.status)
                return f"{emoji}{dep_id}"
            else:
                return dep_id

        formatted = [format_single_dep(dep_id) for dep_id in sorted_deps]
        result = ",".join(formatted)
        if len(filtered_deps) > 2:
            result += f" [bold]+{len(filtered_deps) - 2}[/]"
        return result

    def _format_dependents(self, data: NspecData, spec_id: str) -> str:
        """Format specs that depend on this spec."""
        all_dependents = data.reverse_deps.get(spec_id, [])
        # Filter out epics — they're shown as group headers, not dep links
        dependents = []
        for dep_id in all_dependents:
            fr = (
                data.datasets.active_frs.get(dep_id) or data.datasets.completed_frs.get(dep_id)
                if data.datasets
                else None
            )
            if fr and fr.type == "Epic":
                continue
            dependents.append(dep_id)
        if not dependents:
            return ""

        nspec_order = {sid: idx for idx, sid in enumerate(data.ordered_specs)}

        def dep_sort_key(dep_id: str) -> tuple[int, int, str]:
            if dep_id in nspec_order:
                return (0, nspec_order[dep_id], dep_id)
            else:
                return (1, 9999, dep_id)

        sorted_dependents = sorted(dependents, key=dep_sort_key)[:2]

        def format_single_dependent(dep_id: str) -> str:
            if data.datasets:
                dep_fr = data.datasets.active_frs.get(dep_id)
                if dep_fr:
                    emoji = get_dep_display_emoji(dep_fr.status)
                    return f"{emoji}{dep_id}"
            return dep_id

        formatted = [format_single_dependent(dep_id) for dep_id in sorted_dependents]
        result = ",".join(formatted)
        if len(dependents) > 2:
            result += f" [bold]+{len(dependents) - 2}[/]"
        return result

    def _add_grouped_rows(
        self,
        data: NspecData,
        rows: list[tuple[str, str, str, str, str, str, str]],
        spec_to_epic: dict[str, str],
        epic_ids: set[str],
        visible_cols: list[str],
        col_index: dict[str, int],
        title_width: int,
        sort_mode: SortMode = SortMode.DEPENDENCY,
        sort_direction: SortDirection = SortDirection.ASC,
        status_rank_map: dict[str, int] | None = None,
    ) -> int:
        """Add rows grouped by parent epic with header rows."""
        # Group rows by epic
        grouped: dict[str | None, list[tuple[str, str, str, str, str, str, str]]] = {}
        for row in rows:
            spec_id = row[0]
            epic_id = spec_to_epic.get(spec_id)
            grouped.setdefault(epic_id, []).append(row)

        # Ensure all known epics have an entry (even if empty)
        for eid in epic_ids:
            grouped.setdefault(eid, [])
        grouped.setdefault(None, [])

        # Sort specs within each group, floating unfinished specs to top
        for key in grouped:
            sorted_group = self._apply_sort(
                grouped[key], sort_mode, status_rank_map, sort_direction
            )
            # Stable partition: non-completed first, completed last
            grouped[key] = sorted(sorted_group, key=lambda r: (r[2] == "✅",))

        # Determine epic group order
        epic_group_order = sort_epic_groups(
            data, grouped, epic_ids, sort_mode, sort_direction, status_rank_map
        )

        # Find status column index for merging tree chars into status values
        status_col_idx = visible_cols.index("status") if "status" in visible_cols else None

        row_count = 0
        for epic_id in epic_group_order:
            group_rows = grouped.get(epic_id, [])

            # Skip epic groups that are truly empty (no deps defined, no specs)
            if epic_id and not group_rows:
                epic_fr = data.datasets.active_frs.get(epic_id) if data.datasets else None
                if not epic_fr or not epic_fr.deps:
                    continue

            # Determine priority for tree styling
            epic_priority = "P2"  # default (no style)
            if epic_id and data.datasets:
                efr = data.datasets.active_frs.get(epic_id)
                if efr:
                    epic_priority = efr.priority

            # Build and add epic header row (above specs)
            tree_chars = _get_tree_chars(epic_priority)
            header = list(
                self._build_epic_header_row(
                    data,
                    epic_id,
                    visible_cols,
                    col_index,
                    title_width,
                    epic_priority,
                )
            )
            # Merge tree corner into status column value
            if status_col_idx is not None:
                styled_top = _styled_tree_char(tree_chars[0], epic_priority)
                header[status_col_idx] = styled_top + header[status_col_idx]
            header_key = f"__hdr_{epic_id or 'unassigned'}"
            self.add_row(*header, key=header_key)
            row_count += 1

            # Add spec rows in this group (below epic header)
            for idx, row in enumerate(group_rows):
                visible_values = list(row[col_index[k]] for k in visible_cols)
                # Merge tree char into status column value
                if status_col_idx is not None:
                    is_last = idx == len(group_rows) - 1
                    tree_char = tree_chars[2] if is_last else tree_chars[1]
                    styled = _styled_tree_char(tree_char, epic_priority)
                    visible_values[status_col_idx] = styled + visible_values[status_col_idx]
                self.add_row(*visible_values, key=row[0])
                row_count += 1

        return row_count

    def _epic_summary_columns(
        self,
        data: NspecData,
        epic_fr: FRMetadata,
    ) -> tuple[str, str, str]:
        """Compute cross-epic deps, dependents, and estimate for an epic header row.

        Returns:
            (deps_str, dependents_str, estimate_str) — e.g. ("↑3", "↓5", "📅3d")
            - deps_str: upstream cross-epic deps (specs outside this epic that children depend on)
            - dependents_str: downstream cross-epic dependents
              (specs outside this epic that depend on children)
            - estimate_str: remaining work estimate
              (sum of effective_loe_hours for non-completed children)
        """
        if not data.datasets:
            return ("", "", "")

        all_frs = {**data.datasets.active_frs, **data.datasets.completed_frs}

        def _is_epic(spec_id: str) -> bool:
            fr = all_frs.get(spec_id)
            return fr is not None and fr.type == "Epic"

        children_set = set(epic_fr.deps)

        # Upstream: specs outside this epic that children depend on
        cross_epic_ups: set[str] = set()
        for child_id in epic_fr.deps:
            child_fr = all_frs.get(child_id)
            if child_fr:
                for dep_id in child_fr.deps:
                    if dep_id not in children_set and not _is_epic(dep_id):
                        cross_epic_ups.add(dep_id)
        deps_str = f"↑{len(cross_epic_ups)}" if cross_epic_ups else ""

        # Downstream: specs outside this epic that depend on children
        cross_epic_downs: set[str] = set()
        for child_id in epic_fr.deps:
            for dependent_id in data.reverse_deps.get(child_id, []):
                if dependent_id not in children_set and not _is_epic(dependent_id):
                    cross_epic_downs.add(dependent_id)
        dependents_str = f"↓{len(cross_epic_downs)}" if cross_epic_downs else ""

        # Estimate: sum effective_loe_hours from non-completed child specs
        total_hours = 0
        for dep_id in epic_fr.deps:
            if dep_id in data.datasets.completed_frs:
                continue
            impl = data.datasets.active_impls.get(dep_id)
            if impl:
                total_hours += impl.effective_loe_hours
        estimate_str = f"📅{_format_hours_to_loe(total_hours)}" if total_hours > 0 else ""

        return (deps_str, dependents_str, estimate_str)

    def _build_epic_header_row(
        self,
        data: NspecData,
        epic_id: str | None,
        visible_cols: list[str],
        col_index: dict[str, int],
        title_width: int,
        epic_priority: str = "P2",
    ) -> tuple[str, ...]:
        """Build an epic header row tuple matching visible columns."""
        # Horizontal connector for the status column
        tree_chars = _get_tree_chars(epic_priority)
        horiz = tree_chars[3]
        # Use 2 horiz chars to match the 2-wide status emoji alignment
        status_fill = _styled_tree_char(horiz * 2, epic_priority)

        if epic_id:
            epic_fr = data.datasets.active_frs.get(epic_id) if data.datasets else None
            if epic_fr:
                title = clean_title(epic_fr.title)
                progress = calculate_epic_progress(data, epic_id)
                # Truncate title if needed, leaving room for progress
                progress_str = f" [{progress}]"
                max_title = title_width - len(progress_str) - 2
                if len(title) > max_title > 0:
                    title = title[: max_title - 1] + "…"
                header_title = f"[bold]{title}[/] [dim]{progress_str}[/]"
                deps_str, dependents_str, estimate_str = self._epic_summary_columns(data, epic_fr)
                full_row = (
                    f"[bold]{epic_id}[/]",
                    epic_fr.priority,
                    status_fill,
                    header_title,
                    deps_str,
                    dependents_str,
                    estimate_str,
                )
            else:
                full_row = (epic_id, "", status_fill, f"[bold]{epic_id}[/]", "", "", "")
        else:
            full_row = ("", "", status_fill, "[bold]Unassigned[/]", "", "", "")

        return tuple(full_row[col_index[k]] for k in visible_cols)

    @property
    def first_spec_row(self) -> int:
        """Return the index of the first non-header row, or 0 if none."""
        for idx in range(self.row_count):
            row_key = self._row_locations.get_key(idx)
            if row_key is not None and not str(row_key.value).startswith("__hdr_"):
                return idx
        return 0

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        """Handle row selection."""
        if event.row_key:
            key = str(event.row_key.value)
            # Skip epic group header rows (non-selectable dividers)
            if key.startswith("__hdr_"):
                return
            self.post_message(self.SpecSelected(key))
