"""Main NspecTUI application."""

from __future__ import annotations

from pathlib import Path

from textual import events, on, work
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal, Vertical
from textual.content import Content
from textual.widgets import DataTable, Footer, Header, Input, OptionList

from .command_modal import CommandModal
from .detail_screen import DetailViewScreen
from .display_modes import SortDirection, SortMode, ViewPreset
from .error_screen import ValidationErrorScreen
from .filters import FilterEngine
from .report_screen import ReportScreen
from .state import FollowModeState, NspecData
from .table import NspecTable
from .utils import clean_title
from .widgets import (
    EpicBanner,
    EpicSelector,
    FilterBar,
    HelpModal,
    MoveSpecModal,
    SearchBar,
    SpecDetailPanel,
    StatusIndicator,
)


class NspecTUI(App):
    """Main TUI application for nspec management."""

    CSS_PATH = "nspec.tcss"

    BINDINGS = [
        Binding("q", "quit", "Quit"),
        Binding("escape", "clear_search", "Clear", priority=True),
        Binding("/", "focus_search", "Search"),
        Binding("n", "next_match", "Next"),
        Binding("shift+n", "prev_match", "Prev", key_display="N"),
        Binding("enter", "toggle_details", "Details"),
        Binding("r", "refresh", "Refresh"),
        Binding("e", "set_epic_filter", "Epic Filter"),
        Binding("m", "move_spec", "Move"),
        Binding("s", "show_reports", "Reports"),
        Binding("f", "toggle_follow_mode", "Follow"),
        Binding("b", "toggle_compact", "Compact"),
        Binding("a", "toggle_activate", "Activate"),
        Binding("v", "cycle_view", "View"),
        Binding("p", "toggle_panel", "Panel"),
        Binding("o", "cycle_sort", "Sort"),
        Binding("O", "reverse_sort", "Reverse Sort", show=False),
        Binding("S", "filter_status", "Filter Status", show=False),
        Binding("P", "filter_priority", "Filter Priority", show=False),
        Binding("B", "filter_blocked", "Filter Blocked", show=False),
        Binding("C", "clear_filters", "Clear Filters", show=False),
        Binding("h", "show_help", "Help"),
        Binding("exclamation_mark", "show_errors", "Errors", key_display="!"),
        Binding("question_mark", "toggle_footer", "More", key_display="?"),
        # Vim navigation
        Binding("j", "cursor_down", "Down", show=False),
        Binding("k", "cursor_up", "Up", show=False),
        Binding("G", "cursor_last", "Last", show=False),
        Binding("g", "g_prefix", show=False),
        Binding("colon", "open_command_modal", "Command", show=False),
    ]

    def __init__(self, docs_root: Path | None = None, project_root: Path | None = None) -> None:
        """Initialize the TUI."""
        super().__init__()
        self.docs_root = docs_root or Path("docs")
        self.project_root = project_root
        self.data = NspecData(self.docs_root, project_root=self.project_root)
        self.search_query = ""
        self.epic_filter: str | None = None
        self.filter_engine = FilterEngine()
        self._filter_selector_active = False
        self._filter_callback: object = None
        self.detail_visible = False
        self.last_mtime = 0.0
        self.follow_mode = FollowModeState(project_root=self.project_root)
        self.show_extended_footer = False
        self.compact_table = False
        self._g_pending = False
        self._g_timer: object | None = None
        self._resize_timer: object | None = None
        self.title = "novaspec"

        # Initialize display modes from state.json, then config defaults
        self.view_preset, self.sort_mode, self.sort_direction = self._load_display_modes()

    def format_title(self, title: str, sub_title: str) -> Content:
        """Format title with orchid-toned subtitle for epic filter."""
        title_content = Content(title)
        if sub_title:
            sub_content = Content(sub_title)
            return Content.assemble(
                title_content,
                (" — ", "dim"),
                sub_content.stylize("medium_orchid"),
            )
        return title_content

    def compose(self) -> ComposeResult:
        """Create child widgets."""
        yield Header()
        with Vertical(id="main-container"):
            with Container(id="search-container"):
                yield SearchBar(id="search-bar")
            yield EpicBanner(id="epic-banner")
            yield FilterBar(id="filter-bar")
            with Horizontal(id="content-container"):
                yield NspecTable(id="nspec-table")
                with Container(id="detail-container"):
                    yield SpecDetailPanel(id="detail-panel")
            with Container(id="status-bar"):
                yield StatusIndicator(id="status-indicator")
        yield EpicSelector(id="epic-selector")
        yield MoveSpecModal(id="move-spec-modal")
        yield HelpModal(id="help-modal")
        yield Footer()

    def on_mount(self) -> None:
        """Handle mount - load initial data and start refresh timer."""
        self.load_data()
        self.set_interval(2, self.check_for_changes)

        table = self.query_one("#nspec-table", NspecTable)
        table.focus()
        if table.row_count > 0:
            table.move_cursor(row=0)

        # Re-refresh after layout so table.size.width is available
        self.call_after_refresh(self.refresh_table)

    def on_resize(self, event: events.Resize) -> None:
        """Refresh the table after terminal resize.

        Column widths depend on the viewport width; without an explicit refresh,
        the table may keep the previous layout until the next user action.
        """
        # The main table is only visible on the root screen.
        if len(self.screen_stack) > 1:
            return

        # Debounce rapid resize events (dragging terminal edges).
        try:
            if self._resize_timer:
                self._resize_timer.stop()
        except Exception:
            pass

        self._resize_timer = self.set_timer(0.05, self._on_resize_debounced)

    def _on_resize_debounced(self) -> None:
        """Handle resize after debounce delay."""
        # Only refresh if we're still on the main screen.
        if len(self.screen_stack) > 1:
            return
        self.refresh_table()

    def load_data(self) -> None:
        """Load nspec data and populate table."""
        self.data.load()
        self.last_mtime = self.data.get_mtime()
        self.refresh_table()

    @work(exclusive=True, thread=True)
    def check_for_changes(self) -> None:
        """Check if files have changed and reload if needed."""
        current_mtime = self.data.get_mtime()
        if current_mtime > self.last_mtime:
            self.last_mtime = current_mtime
            self.data.load()
            self.app.call_from_thread(self._on_data_reloaded)
        else:
            # Refresh status bar on every tick so swarm metrics stay current
            # even when docs files haven't changed (queue changes are independent)
            self.app.call_from_thread(self._update_status_bar)

        if self.follow_mode.enabled and self.follow_mode.check_for_changes():
            spec_id = self.follow_mode.current_spec_id
            if spec_id:
                self.app.call_from_thread(self._follow_mode_navigate, spec_id)

    def _on_data_reloaded(self) -> None:
        """Handle data reload — refresh table and update error screen if visible."""
        self.refresh_table()
        # If error screen is on top, update it
        if self.screen_stack and isinstance(self.screen, ValidationErrorScreen):
            self.screen.update_errors(self.data.validation_errors)
            if not self.data.validation_errors:
                self.notify("All validation errors resolved!", timeout=2)
                self.pop_screen()

    def _follow_mode_navigate(self, spec_id: str) -> None:
        """Navigate to spec in follow mode (called from thread)."""
        if self.data.datasets:
            fr = self.data.datasets.get_fr(spec_id)
            if not fr:
                if spec_id in self.data.datasets.completed_frs:
                    self.notify(f"Spec {spec_id} completed! Follow mode continues.", timeout=3)
                else:
                    self.notify(f"Spec {spec_id} not found", severity="warning", timeout=2)
                return

        while len(self.screen_stack) > 1:
            self.pop_screen()
        self._open_detail_view(spec_id)
        self._update_status_bar()
        self.notify(f"Following -> Spec {spec_id}", timeout=2)

    def refresh_table(self) -> None:
        """Refresh the table display."""
        if len(self.screen_stack) > 1:
            return

        try:
            table = self.query_one("#nspec-table", NspecTable)
            viewport_width = table.size.width or self.console.size.width
            count = table.populate(
                self.data,
                self.search_query,
                self.epic_filter,
                viewport_width,
                view_preset=self.view_preset,
                sort_mode=self.sort_mode,
                sort_direction=self.sort_direction,
                filter_engine=self.filter_engine if self.filter_engine.is_active else None,
            )
            self._update_status_bar(count)

            if self.data.error:
                self.notify(f"Error: {self.data.error}", severity="error")
        except Exception:
            pass

    def _update_status_bar(self, count: int | None = None) -> None:
        """Update status bar with current state."""
        try:
            if count is None:
                table = self.query_one("#nspec-table", NspecTable)
                count = table.row_count

            # Count only real errors (not warnings)
            error_count = sum(1 for e in self.data.validation_errors if e.severity == "error")

            # Read swarm queue status via lock-free snapshot to avoid
            # contention with queue_claim/release/heartbeat during polling
            swarm_active = False
            swarm_agents = 0
            swarm_queued = 0
            swarm_completed = 0
            try:
                from nspec.queue import QueueDAO

                dao = QueueDAO(self.project_root or self.data.docs_root.parent)
                queue_status = dao.status_snapshot()
                if "error" not in queue_status and queue_status.get("total_entries", 0) > 0:
                    swarm_active = True
                    swarm_agents = queue_status.get("active_agents", 0)
                    swarm_queued = queue_status.get("specs_remaining", 0)
                    swarm_completed = queue_status.get("specs_completed", 0)
            except Exception:
                pass

            status = self.query_one("#status-indicator", StatusIndicator)
            status.update_status(
                count,
                self.epic_filter,
                follow_mode=self.follow_mode.enabled,
                follow_spec=self.follow_mode.current_spec_id,
                error_count=error_count,
                view_preset=self.view_preset.value,
                sort_mode=f"{self.sort_mode.value}{self.sort_direction.indicator}",
                swarm_active=swarm_active,
                swarm_agents=swarm_agents,
                swarm_queued=swarm_queued,
                swarm_completed=swarm_completed,
            )
        except Exception:
            pass

    def _is_search_focused(self) -> bool:
        """Check if the search bar currently has focus."""
        try:
            search = self.query_one("#search-bar", SearchBar)
            return search.has_focus
        except Exception:
            return False

    def action_quit(self) -> None:
        """Quit the application."""
        if self._is_search_focused():
            return
        self.exit()

    def _focused_table(self) -> DataTable | None:
        """Get the currently focused DataTable, if any."""
        focused = self.screen.focused
        if isinstance(focused, DataTable):
            return focused
        return None

    def action_cursor_down(self) -> None:
        """Move cursor down in the focused table (vim j)."""
        if self._is_search_focused():
            return
        table = self._focused_table()
        if table and table.row_count > 0:
            table.action_cursor_down()

    def action_cursor_up(self) -> None:
        """Move cursor up in the focused table (vim k)."""
        if self._is_search_focused():
            return
        table = self._focused_table()
        if table and table.row_count > 0:
            table.action_cursor_up()

    def action_cursor_last(self) -> None:
        """Jump to last row in the focused table (vim G)."""
        if self._is_search_focused():
            return
        table = self._focused_table()
        if table and table.row_count > 0:
            table.move_cursor(row=table.row_count - 1)

    def action_g_prefix(self) -> None:
        """Handle g prefix for gg (jump to first row)."""
        if self._is_search_focused():
            return
        if self._g_pending:
            # Second g press — jump to first row
            self._g_pending = False
            if self._g_timer:
                self._g_timer.stop()
                self._g_timer = None
            table = self._focused_table()
            if table and table.row_count > 0:
                table.move_cursor(row=0)
        else:
            # First g press — wait for second
            self._g_pending = True
            self._g_timer = self.set_timer(0.5, self._reset_g_prefix)

    def _reset_g_prefix(self) -> None:
        """Reset g prefix state after timeout."""
        self._g_pending = False
        self._g_timer = None

    def action_open_command_modal(self) -> None:
        """Open the vim-style command modal."""
        if self._is_search_focused():
            return
        self.push_screen(CommandModal())

    def action_focus_search(self) -> None:
        """Focus the search bar."""
        container = self.query_one("#search-container", Container)
        container.add_class("visible")
        search = self.query_one("#search-bar", SearchBar)
        search.focus()

    def action_clear_search(self) -> None:
        """Clear search/epic filter and return to table."""
        if len(self.screen_stack) > 1:
            self.pop_screen()
            return

        try:
            move_modal = self.query_one("#move-spec-modal", MoveSpecModal)
            if "visible" in move_modal.classes:
                move_modal.remove_class("visible")
                table = self.query_one("#nspec-table", NspecTable)
                table.focus()
                return
        except Exception:
            pass

        try:
            selector = self.query_one("#epic-selector", EpicSelector)
            if "visible" in selector.classes:
                selector.remove_class("visible")
                table = self.query_one("#nspec-table", NspecTable)
                table.focus()
                return
        except Exception:
            pass

        if self.epic_filter:
            self.action_set_epic_filter()
            return

        try:
            search = self.query_one("#search-bar", SearchBar)
            search.value = ""
            self.search_query = ""
            container = self.query_one("#search-container", Container)
            container.remove_class("visible")
            self.refresh_table()
            table = self.query_one("#nspec-table", NspecTable)
            table.focus()
        except Exception:
            pass

    def action_next_match(self) -> None:
        """Jump to next search match."""
        if self._is_search_focused():
            return
        table = self.query_one("#nspec-table", NspecTable)
        if table.row_count > 0:
            current = table.cursor_row
            next_row = (current + 1) % table.row_count
            table.move_cursor(row=next_row)

    def action_prev_match(self) -> None:
        """Jump to previous search match."""
        if self._is_search_focused():
            return
        table = self.query_one("#nspec-table", NspecTable)
        if table.row_count > 0:
            current = table.cursor_row
            prev_row = (current - 1) % table.row_count
            table.move_cursor(row=prev_row)

    def action_toggle_details(self) -> None:
        """Open full-screen detail view for selected spec."""
        table = self.query_one("#nspec-table", NspecTable)
        if table.row_count == 0:
            self.notify("No specs to view", severity="warning", timeout=2)
            return

        row_key = table.cursor_row
        if row_key is None:
            return

        row_data = table.get_row_at(row_key)
        if not row_data:
            return

        spec_id = str(row_data[0])
        self._open_detail_view(spec_id)

    def _open_detail_view(self, spec_id: str) -> None:
        """Open the detail view screen for a spec."""
        fr = None
        impl = None

        if self.data.datasets:
            fr = self.data.datasets.get_fr(spec_id)
            impl = self.data.datasets.get_impl(spec_id)

            if not fr and spec_id in self.data.datasets.completed_frs:
                fr = self.data.datasets.completed_frs[spec_id]
            if not impl and spec_id in self.data.datasets.completed_impls:
                impl = self.data.datasets.completed_impls[spec_id]

        if not fr:
            self.notify(f"Spec {spec_id} not found", severity="error", timeout=2)
            return

        is_follow_target = self.follow_mode.enabled and self.follow_mode.current_spec_id == spec_id

        screen = DetailViewScreen(
            spec_id=spec_id,
            fr=fr,
            impl=impl,
            data=self.data,
            is_follow_target=is_follow_target,
        )
        self.push_screen(screen)

    def action_refresh(self) -> None:
        """Manual refresh."""
        if self._is_search_focused():
            return
        self.load_data()
        # Update error screen if it's on top
        if self.screen_stack and isinstance(self.screen, ValidationErrorScreen):
            self.screen.update_errors(self.data.validation_errors)
            if not self.data.validation_errors:
                self.notify("All validation errors resolved!", timeout=2)
                self.pop_screen()
                return
        self.notify("Refreshed", timeout=1)

    def action_toggle_activate(self) -> None:
        """Toggle selected spec between Planning and Active."""
        if self._is_search_focused():
            return

        table = self.query_one("#nspec-table", NspecTable)
        if table.row_count == 0:
            return

        row_key = table.cursor_row
        if row_key is None:
            return

        row_data = table.get_row_at(row_key)
        if not row_data:
            return

        spec_id = str(row_data[0])

        if not self.data.datasets:
            return

        impl = self.data.datasets.get_impl(spec_id)
        if not impl:
            self.notify(f"No IMPL for {spec_id}", severity="warning", timeout=2)
            return

        # Determine toggle direction based on current IMPL status
        if "Planning" in impl.status or "Proposed" in impl.status:
            # Planning/Proposed → Active
            target_fr, target_impl = 2, 1  # FR Active, IMPL Active
            label = "Active"
        elif "Active" in impl.status:
            # Active → Planning
            target_fr, target_impl = 0, 0  # FR Proposed, IMPL Planning
            label = "Planning"
        else:
            self.notify(
                f"Cannot toggle: {impl.status}",
                severity="warning",
                timeout=2,
            )
            return

        try:
            from nspec.crud import set_status

            set_status(
                spec_id=spec_id,
                fr_status=target_fr,
                impl_status=target_impl,
                docs_root=self.docs_root,
                force=True,
            )
            self.load_data()
            self.notify(f"{spec_id} → {label}", timeout=1)
        except (FileNotFoundError, ValueError) as e:
            self.notify(f"Failed: {e}", severity="error", timeout=3)

    def action_set_epic_filter(self) -> None:
        """Show epic selector."""
        if self._is_search_focused():
            return

        # Pop back to main screen if in detail/report view
        while len(self.screen_stack) > 1:
            self.pop_screen()

        selector = self.query_one("#epic-selector", EpicSelector)

        if selector.has_class("visible"):
            selector.remove_class("visible")
            table = self.query_one("#nspec-table", NspecTable)
            table.focus()
            return

        priority_rank = {"P0": 0, "P1": 1, "P2": 2, "P3": 3}
        epics: list[tuple[str, str, int, str]] = []
        if self.data.datasets:
            for spec_id, fr in self.data.datasets.active_frs.items():
                if fr.type == "Epic":
                    count = len(fr.deps) if fr.deps else 0
                    title = clean_title(fr.title)
                    epics.append((spec_id, title, count, fr.priority))

        nspec_order = {sid: idx for idx, sid in enumerate(self.data.ordered_specs)}
        epics.sort(key=lambda x: (priority_rank.get(x[3], 9), nspec_order.get(x[0], 9999)))

        selector.set_epics(epics)
        selector.add_class("visible")
        option_list = selector.query_one("#epic-list", OptionList)
        option_list.focus()
        if option_list.option_count > 0:
            if self.epic_filter:
                ids = [str(o.id) for o in option_list.options]
                option_list.highlighted = (
                    ids.index(self.epic_filter) if self.epic_filter in ids else 0
                )
            else:
                option_list.highlighted = 0

    def action_show_reports(self) -> None:
        """Show the reports screen."""
        if self._is_search_focused():
            return
        self.push_screen(ReportScreen(self.docs_root, project_root=self.project_root))

    def action_toggle_follow_mode(self) -> None:
        """Toggle Claude Follow Mode."""
        if self._is_search_focused():
            return

        self.follow_mode.enabled = not self.follow_mode.enabled

        if self.follow_mode.enabled:
            spec_id = self.follow_mode.read_current_spec()
            if spec_id:
                self.follow_mode.current_spec_id = spec_id
                self.follow_mode._last_state_mtime = (
                    self.follow_mode.state_file.stat().st_mtime
                    if self.follow_mode.state_file.exists()
                    else 0.0
                )
                self._open_detail_view(spec_id)
                self.notify(f"Follow mode ON - Spec {spec_id}", timeout=2)
            else:
                self.notify("Follow mode ON - No active spec", severity="warning", timeout=2)
        else:
            self.notify("Follow mode OFF", timeout=1)

        self._update_status_bar()

    def action_show_errors(self) -> None:
        """Show validation error detail screen."""
        if self._is_search_focused():
            return
        errors = self.data.validation_errors
        if not errors:
            self.notify("No validation errors", timeout=2)
            return
        screen = ValidationErrorScreen(errors=errors)
        self.push_screen(screen)

    def action_toggle_footer(self) -> None:
        """Toggle between normal and extended footer bindings."""
        if self._is_search_focused():
            return
        # Footer toggle not implemented with built-in Footer
        pass

    def action_toggle_compact(self) -> None:
        """Toggle compact table mode (borderless)."""
        if self._is_search_focused():
            return
        self.compact_table = not self.compact_table
        try:
            table = self.query_one("#nspec-table", NspecTable)
            if self.compact_table:
                table.add_class("compact")
            else:
                table.remove_class("compact")
        except Exception:
            pass

    def action_cycle_view(self) -> None:
        """Cycle table view preset (minimal → standard → full)."""
        if self._is_search_focused():
            return
        self.view_preset = self.view_preset.next()
        self.refresh_table()
        self._save_display_modes()
        self.notify(f"View: {self.view_preset.value}", timeout=1)

    def action_toggle_panel(self) -> None:
        """Toggle the detail side panel on the main screen."""
        if self._is_search_focused():
            return
        self.detail_visible = not self.detail_visible
        try:
            container = self.query_one("#detail-container", Container)
            if self.detail_visible:
                container.add_class("visible")
                # Update panel with currently highlighted spec
                table = self.query_one("#nspec-table", NspecTable)
                if table.row_count > 0:
                    row_key = table.cursor_row
                    if row_key is not None:
                        row_data = table.get_row_at(row_key)
                        if row_data:
                            self._update_detail_panel(str(row_data[0]))
            else:
                container.remove_class("visible")
            self.refresh_table()
            self.notify(f"Panel {'ON' if self.detail_visible else 'OFF'}", timeout=1)
        except Exception:
            pass

    def action_cycle_sort(self) -> None:
        """Cycle table sort mode (dependency → priority → status → id → alpha)."""
        if self._is_search_focused():
            return
        self.sort_mode = self.sort_mode.next()
        self.sort_direction = SortDirection.ASC  # Reset direction on column change
        self.refresh_table()
        self._save_display_modes()
        self.notify(f"Sort: {self.sort_mode.value}{self.sort_direction.indicator}", timeout=1)

    def action_reverse_sort(self) -> None:
        """Reverse sort direction on the current column."""
        if self._is_search_focused():
            return
        self.sort_direction = self.sort_direction.toggle()
        self.refresh_table()
        self._save_display_modes()
        self.notify(f"Sort: {self.sort_mode.value}{self.sort_direction.indicator}", timeout=1)

    def action_filter_status(self) -> None:
        """Open status filter selector."""
        if self._is_search_focused():
            return
        from nspec.statuses import parse_status_text

        # Collect unique statuses from current data
        statuses: list[str] = []
        seen: set[str] = set()
        if self.data.datasets:
            for spec_id in self.data.ordered_specs:
                impl = self.data.datasets.get_impl(spec_id)
                fr = self.data.datasets.get_fr(spec_id)
                raw = impl.status if impl else (fr.status if fr else "")
                text = parse_status_text(raw)
                if text and text not in seen:
                    seen.add(text)
                    statuses.append(text)

        if not statuses:
            self.notify("No statuses found", severity="warning", timeout=2)
            return

        # If already filtering by status, clear it
        if "status" in self.filter_engine.active_filters:
            self.filter_engine.remove("status")
            self._update_filter_bar()
            self.refresh_table()
            self.notify("Status filter cleared", timeout=1)
            return

        # Cycle through statuses or pick the first common one
        # For simplicity, show a selection via OptionList modal
        items = [(s.capitalize(), s) for s in sorted(statuses)]
        self._show_filter_selector("Status", items, self._on_status_selected)

    def _on_status_selected(self, value: str) -> None:
        """Apply status filter from selector."""
        from .filters import make_status_filter

        self.filter_engine.add("status", make_status_filter(value), f"Status: {value.capitalize()}")
        self._update_filter_bar()
        self.refresh_table()
        self.notify(f"Filter: status={value}", timeout=1)

    def action_filter_priority(self) -> None:
        """Open priority filter selector."""
        if self._is_search_focused():
            return

        # If already filtering by priority, clear it
        if "priority" in self.filter_engine.active_filters:
            self.filter_engine.remove("priority")
            self._update_filter_bar()
            self.refresh_table()
            self.notify("Priority filter cleared", timeout=1)
            return

        items = [
            ("P0 (Critical)", "P0"),
            ("P0-P1 (High+)", "P1"),
            ("P0-P2 (Medium+)", "P2"),
            ("All (P0-P3)", "P3"),
        ]
        self._show_filter_selector("Priority", items, self._on_priority_selected)

    def _on_priority_selected(self, value: str) -> None:
        """Apply priority filter from selector."""
        from .filters import make_priority_filter

        label = f"Priority: {value}+"
        if value == "P3":
            # P3 means "all" — just clear filter
            self.filter_engine.remove("priority")
        else:
            self.filter_engine.add("priority", make_priority_filter(value), label)
        self._update_filter_bar()
        self.refresh_table()
        self.notify(f"Filter: priority>={value}", timeout=1)

    def action_filter_blocked(self) -> None:
        """Toggle blocked-only filter."""
        if self._is_search_focused():
            return
        from .filters import make_blocked_filter

        active = self.filter_engine.toggle("blocked", make_blocked_filter(), "Blocked Only")
        self._update_filter_bar()
        self.refresh_table()
        self.notify(f"Blocked filter {'ON' if active else 'OFF'}", timeout=1)

    def action_clear_filters(self) -> None:
        """Clear all active filters."""
        if self._is_search_focused():
            return
        if not self.filter_engine.is_active:
            self.notify("No active filters", timeout=1)
            return
        self.filter_engine.clear()
        self._update_filter_bar()
        self.refresh_table()
        self.notify("All filters cleared", timeout=1)

    def _update_filter_bar(self) -> None:
        """Update the filter bar widget with current active filters."""
        try:
            bar = self.query_one("#filter-bar", FilterBar)
            bar.update_filters(self.filter_engine.active_filters)
        except Exception:
            pass

    def _show_filter_selector(
        self,
        title: str,
        items: list[tuple[str, str]],
        callback: object,
    ) -> None:
        """Show a filter selection modal (reuses OptionList pattern).

        Args:
            title: Selector title
            items: List of (display_label, value) tuples
            callback: Function to call with selected value
        """
        from textual.widgets.option_list import Option

        selector = self.query_one("#epic-selector", EpicSelector)

        # Repurpose epic selector for filter selection
        option_list = selector.query_one("#epic-list", OptionList)
        option_list.clear_options()

        for display, value in items:
            option_list.add_option(Option(display, id=value))

        # Store callback for when selection is made
        self._filter_callback = callback
        self._filter_selector_active = True

        label = selector.query_one("Label")
        label.update(f"[bold]Select {title}[/] (Enter to select, Esc to cancel)")

        selector.add_class("visible")
        option_list.focus()
        if option_list.option_count > 0:
            option_list.highlighted = 0

    def _load_display_modes(self) -> tuple[ViewPreset, SortMode, SortDirection]:
        """Load view/sort preferences from state.json, falling back to config."""
        from nspec.config import NspecConfig

        cfg = NspecConfig.load(self.project_root).tui
        view = ViewPreset.from_str(cfg.default_view)
        sort = SortMode.from_str(cfg.default_sort)
        direction = SortDirection.ASC

        # Try to load from session state
        try:
            from nspec.session import StateDAO

            state = StateDAO(self.project_root or Path(".")).load()
            if state:
                if state.view_preset:
                    view = ViewPreset.from_str(state.view_preset, view)
                if state.sort_mode:
                    sort = SortMode.from_str(state.sort_mode, sort)
                if state.sort_direction:
                    direction = SortDirection.from_str(state.sort_direction, direction)
        except Exception:
            pass

        return view, sort, direction

    def _save_display_modes(self) -> None:
        """Persist current view/sort preferences to state.json."""
        try:
            from nspec.session import SessionState, StateDAO

            dao = StateDAO(self.project_root or Path("."))
            state = dao.load() or SessionState(spec_id="")
            state.view_preset = self.view_preset.value
            state.sort_mode = self.sort_mode.value
            state.sort_direction = self.sort_direction.value
            dao.save(state)
        except Exception:
            pass

    def action_show_help(self) -> None:
        """Toggle help modal."""
        try:
            modal = self.query_one("#help-modal", HelpModal)
            if modal.has_class("visible"):
                modal.remove_class("visible")
                table = self.query_one("#nspec-table", NspecTable)
                table.focus()
            else:
                modal.add_class("visible")
        except Exception:
            pass

    def action_move_spec(self) -> None:
        """Show move spec modal."""
        if self._is_search_focused():
            return
        modal = self.query_one("#move-spec-modal", MoveSpecModal)

        if modal.has_class("visible"):
            modal.remove_class("visible")
            table = self.query_one("#nspec-table", NspecTable)
            table.focus()
            return

        table = self.query_one("#nspec-table", NspecTable)
        if table.row_count == 0:
            self.notify("No specs to move", severity="warning", timeout=2)
            return

        row_key = table.cursor_row
        if row_key is None:
            self.notify("No spec selected", severity="warning", timeout=2)
            return

        row_data = table.get_row_at(row_key)
        if not row_data:
            return

        spec_id = str(row_data[0])

        # Look up title from datasets (not row position, which varies by view preset)
        spec_title = spec_id
        if self.data.datasets:
            fr = self.data.datasets.get_fr(spec_id)
            if fr:
                spec_title = clean_title(fr.title)
                if fr.type == "Epic":
                    self.notify("Cannot move epics", severity="warning", timeout=2)
                    return

        current_epic: str | None = None
        if self.data.datasets:
            for epic_id, epic_fr in self.data.datasets.active_frs.items():
                if epic_fr.type == "Epic" and spec_id in epic_fr.deps:
                    current_epic = epic_id
                    break

        priority_rank = {"P0": 0, "P1": 1, "P2": 2, "P3": 3}
        epics: list[tuple[str, str, int, str]] = []
        if self.data.datasets:
            for epic_id, fr in self.data.datasets.active_frs.items():
                if fr.type == "Epic":
                    count = len(fr.deps) if fr.deps else 0
                    title = clean_title(fr.title)
                    epics.append((epic_id, title, count, fr.priority))

        nspec_order = {sid: idx for idx, sid in enumerate(self.data.ordered_specs)}
        epics.sort(key=lambda x: (priority_rank.get(x[3], 9), nspec_order.get(x[0], 9999)))

        modal.set_spec(spec_id, spec_title)
        modal.set_epics(epics, current_epic)
        modal.add_class("visible")
        option_list = modal.query_one("#move-epic-list", OptionList)
        option_list.focus()
        if option_list.option_count > 0:
            option_list.highlighted = 0

    def _apply_epic_filter(self, epic_id: str | None) -> None:
        """Apply epic filter and update UI."""
        self.epic_filter = epic_id

        banner = self.query_one("#epic-banner", EpicBanner)
        if epic_id and self.data.datasets:
            fr = self.data.datasets.get_fr(epic_id)
            if fr:
                title = clean_title(fr.title)
                scope = self._get_epic_scope(epic_id)
                banner.show_epic(epic_id, title, len(scope) - 1)
                banner.add_class("visible")
                self.sub_title = f"FILTER: {epic_id} — {title}"
        else:
            banner.hide()
            banner.remove_class("visible")
            self.sub_title = ""

        self.refresh_table()

    def _get_epic_scope(self, epic_id: str) -> set[str]:
        """Get the epic and its direct dependencies (no transitive traversal).

        Specs should only appear under their direct parent epic,
        not under grandparent epics.
        """
        result = {epic_id}
        fr = self.data.datasets.get_fr(epic_id) if self.data.datasets else None
        if fr and fr.deps:
            result.update(fr.deps)
        return result

    @on(Input.Changed, "#search-bar")
    def handle_search_change(self, event: Input.Changed) -> None:
        """Handle search input changes."""
        self.search_query = event.value
        self.refresh_table()

    @on(Input.Submitted, "#search-bar")
    def handle_search_submit(self, event: Input.Submitted) -> None:
        """Handle search submission - focus table."""
        table = self.query_one("#nspec-table", NspecTable)
        table.focus()

    @on(NspecTable.SpecSelected)
    def handle_spec_selected(self, event: NspecTable.SpecSelected) -> None:
        """Handle spec selection - navigate to epic or open detail view."""
        spec_id = event.spec_id

        # Check if selected spec is an epic
        is_epic = False
        if self.data.datasets:
            fr = self.data.datasets.get_fr(spec_id)
            if fr and fr.type == "Epic":
                is_epic = True

        # If it's an epic and different from current filter, navigate to it
        if is_epic and spec_id != self.epic_filter:
            # Clear search query so epic filter works correctly
            self.search_query = ""
            search_bar = self.query_one("#search-bar", SearchBar)
            search_bar.value = ""
            self._apply_epic_filter(spec_id)
            self.notify(f"Navigated to Epic {spec_id}", timeout=2)
        else:
            # Same epic or not an epic - show detail
            self._open_detail_view(spec_id)

    @on(DataTable.RowHighlighted)
    def handle_row_highlighted(self, event: DataTable.RowHighlighted) -> None:
        """Handle row highlight (cursor movement)."""
        if self.detail_visible and event.row_key:
            self._update_detail_panel(str(event.row_key.value))

    @on(EpicSelector.EpicSelected)
    def handle_epic_selected(self, event: EpicSelector.EpicSelected) -> None:
        """Handle epic selection from selector (also used for filter selectors)."""
        selector = self.query_one("#epic-selector", EpicSelector)
        selector.remove_class("visible")

        # Check if this was a filter selector callback
        if getattr(self, "_filter_selector_active", False):
            self._filter_selector_active = False
            callback = getattr(self, "_filter_callback", None)
            if callback and event.epic_id:
                callback(event.epic_id)
            table = self.query_one("#nspec-table", NspecTable)
            table.focus()
            return

        self._apply_epic_filter(event.epic_id)
        table = self.query_one("#nspec-table", NspecTable)
        table.focus()

        if event.epic_id:
            self.notify(f"Filtered to Epic {event.epic_id}", timeout=2)
        else:
            self.notify("Showing all specs", timeout=1)

    @on(MoveSpecModal.SpecMoved)
    def handle_spec_moved(self, event: MoveSpecModal.SpecMoved) -> None:
        """Handle spec moved from modal."""
        from nspec.operations import move_spec

        modal = self.query_one("#move-spec-modal", MoveSpecModal)
        modal.remove_class("visible")

        result = move_spec(event.spec_id, event.target_epic, self.docs_root)

        if result.success:
            self.load_data()

            msg = f"Moved {event.spec_id} to Epic {event.target_epic}"
            if result.removed_from:
                msg += f" (from {', '.join(result.removed_from)})"
            if result.priority_bumped:
                msg += f" [priority -> {result.priority_bumped}]"

            self.notify(msg, timeout=3)
        else:
            self.notify(f"Move failed: {result.error}", severity="error", timeout=4)

        table = self.query_one("#nspec-table", NspecTable)
        table.focus()

    def _update_detail_panel(self, spec_id: str) -> None:
        """Update the detail panel with spec info."""
        panel = self.query_one("#detail-panel", SpecDetailPanel)
        if self.data.datasets:
            fr = self.data.datasets.get_fr(spec_id)
            impl = self.data.datasets.get_impl(spec_id)
            panel.show_spec(spec_id, fr, impl)
        else:
            panel.clear_spec()


def main(docs_root: Path | None = None, project_root: Path | None = None) -> None:
    """Run the TUI application."""
    app = NspecTUI(docs_root=docs_root, project_root=project_root)
    app.run()
