"""Display mode enums for TUI view presets and sort modes."""

from __future__ import annotations

from enum import Enum


class ViewPreset(Enum):
    """Table column visibility presets."""

    MINIMAL = "minimal"
    STANDARD = "standard"
    FULL = "full"

    def columns(self) -> list[str]:
        """Return column keys for this preset."""
        if self == ViewPreset.MINIMAL:
            return ["id", "status", "title"]
        # STANDARD and FULL show all columns
        return ["id", "priority", "status", "title", "deps", "dependents", "estimate"]

    def next(self) -> ViewPreset:
        """Cycle to the next preset."""
        members = list(ViewPreset)
        idx = members.index(self)
        return members[(idx + 1) % len(members)]

    @classmethod
    def from_str(cls, value: str, default: ViewPreset | None = None) -> ViewPreset:
        """Parse a string to ViewPreset, returning default on invalid input."""
        if default is None:
            default = cls.STANDARD
        try:
            return cls(value.lower())
        except ValueError:
            return default


class SortDirection(Enum):
    """Sort direction for the spec table."""

    ASC = "asc"
    DESC = "desc"

    def toggle(self) -> SortDirection:
        """Flip between ascending and descending."""
        return SortDirection.DESC if self == SortDirection.ASC else SortDirection.ASC

    @property
    def indicator(self) -> str:
        """Return arrow indicator for column headers."""
        return "▲" if self == SortDirection.ASC else "▼"

    @classmethod
    def from_str(cls, value: str, default: SortDirection | None = None) -> SortDirection:
        """Parse a string to SortDirection, returning default on invalid input."""
        if default is None:
            default = cls.ASC
        try:
            return cls(value.lower())
        except ValueError:
            return default


class SortMode(Enum):
    """Row ordering modes for the spec table."""

    DEPENDENCY = "dependency"
    PRIORITY = "priority"
    STATUS = "status"
    ID = "id"
    ALPHA = "alpha"

    def next(self) -> SortMode:
        """Cycle to the next sort mode."""
        members = list(SortMode)
        idx = members.index(self)
        return members[(idx + 1) % len(members)]

    @classmethod
    def from_str(cls, value: str, default: SortMode | None = None) -> SortMode:
        """Parse a string to SortMode, returning default on invalid input."""
        if default is None:
            default = cls.DEPENDENCY
        try:
            return cls(value.lower())
        except ValueError:
            return default
