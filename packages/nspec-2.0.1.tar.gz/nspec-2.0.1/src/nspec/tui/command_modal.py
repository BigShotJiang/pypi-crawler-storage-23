"""Vim-style command modal for the Nspec TUI."""

from __future__ import annotations

from typing import Any

from textual import on
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Vertical
from textual.message import Message
from textual.screen import ModalScreen
from textual.widgets import Input, Static

from nspec.ids import parse_bare_number, parse_spec_ref, resolve_fuzzy_id


class CommandModal(ModalScreen):
    """Vim-style command line modal (like :command in vim/k9s).

    Appears at the bottom of the screen as an overlay.
    Accepts text commands and dispatches them to the app.
    """

    BINDINGS = [
        Binding("escape", "dismiss_modal", "Close", priority=True),
    ]

    DEFAULT_CSS = """
    CommandModal {
        align: center bottom;
    }
    """

    class CommandExecuted(Message):
        """Message sent when a command is executed."""

        def __init__(self, command: str, args: list[str]) -> None:
            super().__init__()
            self.command = command
            self.args = args

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self._error_message: str = ""

    def compose(self) -> ComposeResult:
        with Vertical(id="command-modal-container"):
            yield Input(id="command-input", placeholder=":")
            yield Static("", id="command-error")

    def on_mount(self) -> None:
        """Focus the input when the modal opens."""
        cmd_input = self.query_one("#command-input", Input)
        cmd_input.value = ""
        cmd_input.focus()
        error_label = self.query_one("#command-error", Static)
        error_label.update("")

    @on(Input.Submitted, "#command-input")
    def handle_command_submit(self, event: Input.Submitted) -> None:
        """Parse and dispatch the command."""
        raw = event.value.strip()
        if not raw:
            self.dismiss()
            return

        # Parse command and arguments
        parts = raw.split(None, 1)
        command = parts[0].lower()
        args_str = parts[1] if len(parts) > 1 else ""
        args = args_str.split() if args_str else []

        result = self._dispatch(command, args, raw)
        if result is not None:
            # Error — show inline
            error_label = self.query_one("#command-error", Static)
            error_label.update(f"[bold]Error:[/] {result}")
            # Clear input for correction
            cmd_input = self.query_one("#command-input", Input)
            cmd_input.value = ""

    def _dispatch(self, command: str, args: list[str], raw_input: str) -> str | None:
        """Dispatch command. Returns error message or None on success."""
        # :q / :quit — quit the application
        if command in ("q", "quit"):
            self.dismiss()
            self.app.exit()
            return None

        # :e <spec_id> — open detail view for spec
        if command == "e":
            if not args:
                return "Usage: :e <spec_id>"
            try:
                spec_id = self._resolve_id(args[0])
            except ValueError as exc:
                return str(exc)
            self.dismiss()
            if hasattr(self.app, "_open_detail_view"):
                # Pop to main screen first
                while len(self.app.screen_stack) > 1:
                    self.app.pop_screen()
                self.app._open_detail_view(spec_id)
            return None

        # :epic <epic_id> — apply epic filter
        if command == "epic":
            if not args:
                return "Usage: :epic <epic_id>"
            try:
                epic_id = self._resolve_epic_id(args[0])
            except ValueError as exc:
                return str(exc)
            self.dismiss()
            if hasattr(self.app, "_apply_epic_filter"):
                # Pop to main screen first
                while len(self.app.screen_stack) > 1:
                    self.app.pop_screen()
                self.app._apply_epic_filter(epic_id)
            return None

        # :help — show help screen
        if command == "help":
            self.dismiss()
            if hasattr(self.app, "action_show_help"):
                self.app.action_show_help()
            return None

        return f"Unknown command: {raw_input}"

    def _get_known_ids(self) -> set[str]:
        """Get known spec/epic IDs from the app's datasets."""
        data = getattr(self.app, "data", None)
        datasets = getattr(data, "datasets", None) if data else None
        if datasets:
            return datasets.all_spec_ids()
        return set()

    def _resolve_id(self, raw_id: str) -> str:
        """Resolve a spec/epic ID using fuzzy matching against known IDs."""
        known_ids = self._get_known_ids()
        if known_ids:
            return resolve_fuzzy_id(raw_id, known_ids)
        # Fallback: parse as prefixed ref (no bare number guessing without data)
        return parse_spec_ref(raw_id).text

    def _resolve_epic_id(self, raw_id: str) -> str:
        """Resolve an epic ID — bare digits get 'E' prefix."""
        parsed = parse_bare_number(raw_id)
        if parsed is not None:
            number, suffix = parsed
            return f"E{number:03d}{suffix}"
        # Prefixed — validate it's an epic
        ref = parse_spec_ref(raw_id)
        if not ref.is_epic:
            raise ValueError(f"Expected epic ID (E###), got {ref.text}")
        return ref.text

    def action_dismiss_modal(self) -> None:
        """Dismiss the modal without executing."""
        self.dismiss()
