"""Validation error detail screen for the Nspec TUI."""

from __future__ import annotations

from collections import defaultdict
from typing import Any

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Container
from textual.screen import Screen
from textual.widgets import DataTable, Footer, Header, Static

from nspec.checkers import ValidationError
from nspec.config import NspecConfig


class ValidationErrorScreen(Screen):
    """Full-screen view listing all validation errors grouped by spec ID."""

    BINDINGS = [
        Binding("escape", "dismiss_screen", "Close"),
        Binding("enter", "navigate_to_spec", "Go to Spec"),
        Binding("r", "refresh_errors", "Refresh"),
        # Vim navigation
        Binding("j", "cursor_down", "Down", show=False),
        Binding("k", "cursor_up", "Up", show=False),
        Binding("G", "cursor_last", "Last", show=False),
        Binding("g", "g_prefix", show=False),
    ]

    def __init__(
        self,
        errors: list[ValidationError],
        **kwargs: Any,
    ) -> None:
        """Initialize with validation errors."""
        super().__init__(**kwargs)
        self.errors = errors
        self._g_pending = False
        self._g_timer: object | None = None

    def compose(self) -> ComposeResult:
        """Create the error screen layout."""
        yield Header()
        yield Static(
            f"[bold]Validation Errors[/]  [dim]({len(self.errors)} issues)[/]",
            id="error-header",
        )
        with Container(id="error-table-container"):
            yield DataTable(id="error-table")
        yield Footer()

    def on_mount(self) -> None:
        """Set up the error table."""
        table = self.query_one("#error-table", DataTable)
        table.cursor_type = "row"
        table.add_columns("Spec", "Layer", "Sev", "Message")
        self._populate_table()
        table.focus()

    def _populate_table(self) -> None:
        """Populate the error table with grouped errors."""
        table = self.query_one("#error-table", DataTable)
        table.clear()

        # Group by spec_id
        by_spec: dict[str | None, list[ValidationError]] = defaultdict(list)
        for err in self.errors:
            by_spec[err.spec_id].append(err)

        # Sort: errors with spec_id first (sorted by ID), then None
        sorted_specs = sorted(
            by_spec.keys(),
            key=lambda s: (s is None, s or ""),
        )

        msg_max = NspecConfig.load().tui.error_message_max

        for spec_id in sorted_specs:
            errs = by_spec[spec_id]
            for err in errs:
                sev_icon = "!!" if err.severity == "error" else "W"
                # Shorten layer name for display
                layer_short = err.layer.split(": ", 1)[-1] if ": " in err.layer else err.layer
                table.add_row(
                    spec_id or "-",
                    layer_short,
                    sev_icon,
                    err.message[:msg_max],
                    key=spec_id or f"_none_{id(err)}",
                )

    def update_errors(self, errors: list[ValidationError]) -> None:
        """Update the error list and refresh display."""
        self.errors = errors
        header = self.query_one("#error-header", Static)
        header.update(f"[bold]Validation Errors[/]  [dim]({len(self.errors)} issues)[/]")
        self._populate_table()

    def action_cursor_down(self) -> None:
        """Move cursor down in the error table (vim j)."""
        table = self.query_one("#error-table", DataTable)
        if table.row_count > 0:
            table.action_cursor_down()

    def action_cursor_up(self) -> None:
        """Move cursor up in the error table (vim k)."""
        table = self.query_one("#error-table", DataTable)
        if table.row_count > 0:
            table.action_cursor_up()

    def action_cursor_last(self) -> None:
        """Jump to last row in the error table (vim G)."""
        table = self.query_one("#error-table", DataTable)
        if table.row_count > 0:
            table.move_cursor(row=table.row_count - 1)

    def action_g_prefix(self) -> None:
        """Handle g prefix for gg (jump to first row)."""
        if self._g_pending:
            self._g_pending = False
            if self._g_timer:
                self._g_timer.stop()
                self._g_timer = None
            table = self.query_one("#error-table", DataTable)
            if table.row_count > 0:
                table.move_cursor(row=0)
        else:
            self._g_pending = True
            self._g_timer = self.set_timer(0.5, self._reset_g_prefix)

    def _reset_g_prefix(self) -> None:
        """Reset g prefix state after timeout."""
        self._g_pending = False
        self._g_timer = None

    def action_dismiss_screen(self) -> None:
        """Close the error screen."""
        self.app.pop_screen()

    def action_navigate_to_spec(self) -> None:
        """Navigate to the selected spec's detail view."""
        table = self.query_one("#error-table", DataTable)
        if table.row_count == 0:
            return

        row_key = table.cursor_row
        if row_key is None:
            return

        row_data = table.get_row_at(row_key)
        if not row_data:
            return

        spec_id = str(row_data[0])
        if spec_id == "-":
            self.app.notify("No spec associated with this error", severity="warning", timeout=2)
            return

        # Pop this screen and open detail view
        self.app.pop_screen()
        # Use the app's _open_detail_view method
        if hasattr(self.app, "_open_detail_view"):
            self.app._open_detail_view(spec_id)

    def action_refresh_errors(self) -> None:
        """Refresh validation errors."""
        if hasattr(self.app, "data"):
            self.app.data.load()
            self.update_errors(self.app.data.validation_errors)
            if not self.errors:
                self.app.notify("No validation errors!", timeout=2)
                self.app.pop_screen()
            else:
                self.app.notify(f"Refreshed: {len(self.errors)} errors", timeout=1)
