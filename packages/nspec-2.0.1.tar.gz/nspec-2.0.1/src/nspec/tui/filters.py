"""Composable filter predicates for the TUI spec table."""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING

from nspec.statuses import parse_status_text

if TYPE_CHECKING:
    from nspec.validators import FRMetadata, IMPLMetadata

# A filter predicate takes (FR, IMPL | None) and returns True to include the spec
FilterPredicate = Callable[["FRMetadata", "IMPLMetadata | None"], bool]


class FilterEngine:
    """Holds named filter predicates and composes them with AND semantics.

    Each filter is identified by a string key (e.g., "status", "priority", "blocked").
    The engine also stores a human-readable label for each active filter, used by
    the FilterBar widget to display removable chips.
    """

    def __init__(self) -> None:
        self._predicates: dict[str, FilterPredicate] = {}
        self._labels: dict[str, str] = {}

    def add(self, key: str, predicate: FilterPredicate, label: str) -> None:
        """Add or replace a named filter predicate."""
        self._predicates[key] = predicate
        self._labels[key] = label

    def remove(self, key: str) -> None:
        """Remove a named filter predicate."""
        self._predicates.pop(key, None)
        self._labels.pop(key, None)

    def toggle(self, key: str, predicate: FilterPredicate, label: str) -> bool:
        """Toggle a filter on/off. Returns True if now active."""
        if key in self._predicates:
            self.remove(key)
            return False
        self.add(key, predicate, label)
        return True

    def clear(self) -> None:
        """Remove all filters."""
        self._predicates.clear()
        self._labels.clear()

    @property
    def active_filters(self) -> dict[str, str]:
        """Return {key: label} for all active filters."""
        return dict(self._labels)

    @property
    def is_active(self) -> bool:
        """True if any filters are set."""
        return bool(self._predicates)

    def matches(self, fr: FRMetadata, impl: IMPLMetadata | None) -> bool:
        """Return True if the spec passes all active filters (AND semantics)."""
        return all(pred(fr, impl) for pred in self._predicates.values())


# --- Predicate factories ---


def make_status_filter(target_status: str) -> FilterPredicate:
    """Create a predicate that matches specs with the given IMPL status.

    Args:
        target_status: Status text to match (e.g., "active", "planning", "testing").
                       Matched case-insensitively against parsed status text.
    """
    target_lower = target_status.lower()

    def predicate(fr: FRMetadata, impl: IMPLMetadata | None) -> bool:
        if impl:
            return parse_status_text(impl.status) == target_lower
        return parse_status_text(fr.status) == target_lower

    return predicate


def make_priority_filter(min_priority: str) -> FilterPredicate:
    """Create a predicate that matches specs at or above the given priority.

    Priority ordering: P0 (highest) > P1 > P2 > P3 (lowest).
    make_priority_filter("P1") matches P0 and P1 specs.

    Args:
        min_priority: Minimum priority level (e.g., "P0", "P1", "P2", "P3").
    """
    priority_rank = {"P0": 0, "P1": 1, "P2": 2, "P3": 3}
    threshold = priority_rank.get(min_priority.upper(), 3)

    def predicate(fr: FRMetadata, _impl: IMPLMetadata | None) -> bool:
        rank = priority_rank.get(fr.priority.upper(), 3)
        return rank <= threshold

    return predicate


def make_blocked_filter() -> FilterPredicate:
    """Create a predicate that matches only blocked/paused/exception specs.

    A spec is considered "blocked" if:
    - Its IMPL has any tasks with BLOCKED markers
    - Its IMPL status is Paused or Exception
    """

    def predicate(_fr: FRMetadata, impl: IMPLMetadata | None) -> bool:
        if impl:
            if impl.has_blocked_tasks:
                return True
            status = parse_status_text(impl.status)
            if status in ("paused", "exception"):
                return True
        return False

    return predicate
