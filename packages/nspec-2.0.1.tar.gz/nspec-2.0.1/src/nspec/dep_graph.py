"""Dependency graph analysis for nspec specs.

Extracts declared deps from FRs and file-level coupling from git history,
then produces execution ordering and parallelization groupings.
"""

from __future__ import annotations

import logging
import re
import subprocess
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)


@dataclass
class SpecNode:
    """A spec's dependency and file information."""

    spec_id: str
    deps: list[str] = field(default_factory=list)
    files: list[str] = field(default_factory=list)
    file_source: str = "none"  # "git", "fr", or "none"
    priority: str = ""
    status: str = ""
    title: str = ""


@dataclass
class FileCollision:
    """Two or more specs touching the same file."""

    file_path: str
    spec_ids: list[str]


@dataclass
class DepGraphResult:
    """Complete dependency analysis result."""

    specs: dict[str, SpecNode]
    declared_deps: dict[str, list[str]]
    file_collisions: list[FileCollision]
    execution_order: list[str]
    parallel_groups: list[list[str]]
    cycle: list[str] | None = None


def _git_files_for_spec(spec_id: str) -> list[str]:
    """Get files touched by a spec from git commit history."""
    try:
        result = subprocess.run(
            ["git", "log", "--name-only", "--pretty=format:", f"--grep=({spec_id})"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            return []
        files = {
            line.strip()
            for line in result.stdout.splitlines()
            if line.strip() and not line.strip().startswith("docs/")
        }
        return sorted(files)
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return []


def _parse_source_files_table(content: str) -> list[str]:
    """Extract file paths from FR 'Source Files' or 'Files Modified' tables."""
    files = []
    # Match backtick-quoted file paths in table rows
    for match in re.finditer(r"\|\s*`([^`]+)`", content):
        path = match.group(1)
        # Filter to source file paths (not descriptions)
        if "/" in path and not path.startswith("#"):
            # Strip line references like :142
            path = re.sub(r":\d+$", "", path)
            # Strip function references like (create_new_spec)
            path = re.sub(r"\s*\(.*\)$", "", path)
            files.append(path.strip())
    return files


def _topological_sort(graph: dict[str, list[str]]) -> tuple[list[str], list[str] | None]:
    """Topological sort with cycle detection.

    Returns (sorted_order, cycle_or_none).
    """
    in_degree: dict[str, int] = defaultdict(int)
    for node in graph:
        in_degree.setdefault(node, 0)
        for dep in graph[node]:
            if dep in graph:
                in_degree[dep] = in_degree.get(dep, 0) + 1

    # Kahn's algorithm
    queue = sorted([n for n in graph if in_degree.get(n, 0) == 0])
    result: list[str] = []

    while queue:
        node = queue.pop(0)
        result.append(node)
        for dep in sorted(graph.get(node, [])):
            if dep in in_degree:
                in_degree[dep] -= 1
                if in_degree[dep] == 0:
                    queue.append(dep)
                    queue.sort()

    if len(result) != len(graph):
        # Cycle detected — find it
        remaining = set(graph) - set(result)
        cycle = sorted(remaining)
        return result, cycle

    # Reverse so deps come first
    result.reverse()
    return result, None


def _find_connected_components(
    nodes: set[str],
    edges: dict[str, set[str]],
) -> list[list[str]]:
    """Find connected components in an undirected graph."""
    visited: set[str] = set()
    components: list[list[str]] = []

    for node in sorted(nodes):
        if node in visited:
            continue
        component: list[str] = []
        stack = [node]
        while stack:
            n = stack.pop()
            if n in visited:
                continue
            visited.add(n)
            component.append(n)
            for neighbor in edges.get(n, set()):
                if neighbor not in visited and neighbor in nodes:
                    stack.append(neighbor)
        components.append(sorted(component))

    return components


def analyze(
    docs_root: Path,
    *,
    epic_id: str | None = None,
    spec_id: str | None = None,
    project_root: Path | None = None,
) -> DepGraphResult:
    """Analyze dependency graph across active specs.

    Args:
        docs_root: Path to docs/ directory
        epic_id: Optional epic filter
        spec_id: Optional single-spec filter
        project_root: Project root for config
    """
    from nspec.datasets import DatasetLoader

    loader = DatasetLoader(docs_root=docs_root, project_root=project_root)
    datasets = loader.load()

    # Build spec nodes
    specs: dict[str, SpecNode] = {}
    for sid, fr in datasets.active_frs.items():
        node = SpecNode(
            spec_id=sid,
            deps=list(fr.deps),
            priority=fr.priority,
            status=fr.status,
            title=fr.title,
        )

        # Try git first for file data
        git_files = _git_files_for_spec(sid)
        if git_files:
            node.files = git_files
            node.file_source = "git"
        else:
            # Fall back to FR source files table
            fr_content = fr.path.read_text()
            table_files = _parse_source_files_table(fr_content)
            if table_files:
                node.files = table_files
                node.file_source = "fr"

        specs[sid] = node

    # Apply filters
    if epic_id:
        from nspec.ids import normalize_spec_ref

        epic_id = normalize_spec_ref(epic_id)
        epic_fr = datasets.get_fr(epic_id)
        if epic_fr:
            member_ids = set(epic_fr.deps) | {epic_id}
            specs = {k: v for k, v in specs.items() if k in member_ids}

    # Build file collision index (before spec_id filter so peers are discoverable)
    file_to_specs: dict[str, list[str]] = defaultdict(list)
    for sid, node in specs.items():
        for f in node.files:
            file_to_specs[f].append(sid)

    if spec_id:
        from nspec.ids import normalize_spec_ref

        spec_id = normalize_spec_ref(spec_id)
        if spec_id in specs:
            # Include the spec itself, deps, dependents, and file-collision peers
            related = {spec_id}
            related.update(specs[spec_id].deps)
            for sid, node in list(specs.items()):
                if spec_id in node.deps:
                    related.add(sid)
            # Add file-collision peers
            for f in specs[spec_id].files:
                for peer in file_to_specs.get(f, []):
                    related.add(peer)
            specs = {k: v for k, v in specs.items() if k in related}

    # Build declared deps map
    declared_deps = {sid: node.deps for sid, node in specs.items()}

    # Rebuild file index scoped to filtered specs
    filtered_file_to_specs: dict[str, list[str]] = defaultdict(list)
    for sid, node in specs.items():
        for f in node.files:
            filtered_file_to_specs[f].append(sid)

    file_collisions = [
        FileCollision(file_path=f, spec_ids=sorted(sids))
        for f, sids in sorted(filtered_file_to_specs.items())
        if len(sids) > 1
    ]

    # Topological sort on declared deps + file-collision scope ordering
    dep_graph: dict[str, list[str]] = {}
    for sid, node in specs.items():
        dep_graph[sid] = [d for d in node.deps if d in specs]

    # For file collisions with no declared deps between them, add synthetic
    # edges from smaller-scope to larger-scope specs (AC-F3: order by change
    # scope, smallest first).
    for collision in file_collisions:
        sorted_by_scope = sorted(collision.spec_ids, key=lambda s: len(specs[s].files))
        for i in range(len(sorted_by_scope) - 1):
            smaller = sorted_by_scope[i]
            larger = sorted_by_scope[i + 1]
            # Only add if no declared dep exists in either direction
            if larger not in dep_graph.get(smaller, []) and smaller not in dep_graph.get(
                larger, []
            ):
                dep_graph.setdefault(larger, []).append(smaller)

    execution_order, cycle = _topological_sort(dep_graph)

    # Parallel groups — connected components of deps + file collisions
    edges: dict[str, set[str]] = defaultdict(set)
    for sid, node in specs.items():
        for dep in node.deps:
            if dep in specs:
                edges[sid].add(dep)
                edges[dep].add(sid)
    for collision in file_collisions:
        for i, s1 in enumerate(collision.spec_ids):
            for s2 in collision.spec_ids[i + 1 :]:
                edges[s1].add(s2)
                edges[s2].add(s1)

    parallel_groups = _find_connected_components(set(specs.keys()), edges)

    return DepGraphResult(
        specs=specs,
        declared_deps=declared_deps,
        file_collisions=file_collisions,
        execution_order=execution_order,
        parallel_groups=parallel_groups,
        cycle=cycle,
    )
