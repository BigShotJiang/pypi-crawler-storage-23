"""Spec ordering and eligibility logic for next_spec picks.

Provides deterministic, dependency-aware ordering of specs grouped
by parent epic, with cross-epic dependency resolution. In-progress
specs (Active/Testing/Ready) are eligible and sort before new specs.
"""

from __future__ import annotations

from typing import Any

from nspec.datasets import NspecDatasets
from nspec.validators import _parse_loe_to_hours

# Shared ranking tables
PRIORITY_RANK: dict[str, int] = {"P0": 0, "P1": 1, "P2": 2, "P3": 3}
STATUS_RANK: dict[str, int] = {
    "active": 0,
    "testing": 0,
    "in-progress": 0,
    "in design": 1,
    "planning": 1,
    "proposed": 2,
    "paused": 3,
    "deferred": 4,
    "superseded": 99,
}


def _get_status_rank(status: str) -> int:
    """Extract status rank from emoji-prefixed status string."""
    status_text = status.split(maxsplit=1)[-1].lower().strip() if status else ""
    return STATUS_RANK.get(status_text, 2)


def ordered_specs(datasets: NspecDatasets) -> list[str]:
    """Generate ordered list of active spec IDs grouped by parent epic.

    Multi-pass algorithm:
        Pass 1: Load all specs, identify epics
        Pass 2: Build "epic sets" (epic + its direct spec dependencies)
        Pass 3: Topological sort of epics based on epic-to-epic dependencies
        Pass 3.5: Assign specs to earliest epic in topo order
        Pass 4: Cluster-aware sorting within each epic set
        Pass 5: Assemble final list: epic specs first, then orphans

    Args:
        datasets: Loaded nspec datasets

    Returns:
        List of spec IDs in nspec order
    """
    active_frs = datasets.active_frs
    spec_ids = list(active_frs.keys())

    # === PASS 1: Filter and identify epics ===
    spec_ids = [
        sid
        for sid in spec_ids
        if not (active_frs.get(sid) and "superseded" in active_frs[sid].status.lower())
    ]
    spec_ids_set = set(spec_ids)

    def is_epic(sid: str) -> bool:
        fr = active_frs.get(sid)
        return fr is not None and fr.type == "Epic"

    epics = [sid for sid in spec_ids if is_epic(sid)]
    epics_set = set(epics)

    # === PASS 2: Build epic-to-epic dependency graph ===
    epic_deps_on_epics: dict[str, list[str]] = {eid: [] for eid in epics}
    spec_deps_by_epic: dict[str, list[str]] = {eid: [] for eid in epics}

    for epic_id in epics:
        fr = active_frs.get(epic_id)
        if not fr:
            continue
        for dep_id in fr.deps:
            if dep_id not in spec_ids_set:
                continue  # Completed/external dep
            if dep_id in epics_set:
                epic_deps_on_epics[epic_id].append(dep_id)
            else:
                spec_deps_by_epic[epic_id].append(dep_id)

    # === PASS 3: Topological sort of epics ===
    epic_in_degree: dict[str, int] = {eid: 0 for eid in epics}
    epic_graph: dict[str, list[str]] = {eid: [] for eid in epics}

    for epic_id, dep_epics in epic_deps_on_epics.items():
        for dep_epic in dep_epics:
            if dep_epic in epics_set:
                epic_graph[dep_epic].append(epic_id)
                epic_in_degree[epic_id] += 1

    def epic_sort_key(eid: str) -> tuple[int, int, int, str]:
        fr = active_frs.get(eid)
        pri = PRIORITY_RANK.get(fr.priority if fr else "P3", 3)
        stat = _get_status_rank(fr.status if fr else "")
        # Epics with pending specs sort before those with all done/no specs
        no_pending = 1 if _is_epic_complete(eid, datasets) else 0
        return (no_pending, pri, stat, eid)

    epic_queue = [eid for eid in epics if epic_in_degree[eid] == 0]
    ordered_epics: list[str] = []

    while epic_queue:
        epic_queue.sort(key=epic_sort_key)
        node = epic_queue.pop(0)
        ordered_epics.append(node)

        for neighbor in epic_graph[node]:
            epic_in_degree[neighbor] -= 1
            if epic_in_degree[neighbor] == 0:
                epic_queue.append(neighbor)

    # Add any remaining epics (cycles)
    for eid in epics:
        if eid not in ordered_epics:
            ordered_epics.append(eid)

    # === PASS 3.5: Assign specs to earliest epic in topo order ===
    epic_sets: dict[str, list[str]] = {eid: [] for eid in epics}
    spec_to_epic: dict[str, str] = {}

    for epic_id in ordered_epics:
        for spec_id in spec_deps_by_epic[epic_id]:
            if spec_id not in spec_to_epic:
                spec_to_epic[spec_id] = epic_id
                epic_sets[epic_id].append(spec_id)

    orphan_specs = [sid for sid in spec_ids if sid not in epics_set and sid not in spec_to_epic]

    # === PASS 4: Cluster-aware sorting within each epic set ===
    def _get_spec_loe_hours(sid: str) -> int:
        impl = datasets.get_impl(sid)
        if impl and impl.loe:
            hours, _ = _parse_loe_to_hours(impl.loe)
            return hours
        return 0

    def _cluster_sort_specs(spec_list: list[str]) -> list[str]:
        if not spec_list:
            return []

        spec_set = set(spec_list)

        # Build sibling dependency graph
        sibling_deps: dict[str, set[str]] = {sid: set() for sid in spec_list}
        sibling_rdeps: dict[str, set[str]] = {sid: set() for sid in spec_list}
        for sid in spec_list:
            fr = active_frs.get(sid)
            if fr and fr.deps:
                for dep_id in fr.deps:
                    if dep_id in spec_set:
                        sibling_deps[sid].add(dep_id)
                        sibling_rdeps[dep_id].add(sid)

        # Find connected components via BFS
        visited: set[str] = set()
        clusters: list[list[str]] = []
        for sid in spec_list:
            if sid in visited:
                continue
            cluster: list[str] = []
            queue = [sid]
            while queue:
                current = queue.pop(0)
                if current in visited:
                    continue
                visited.add(current)
                cluster.append(current)
                for dep in sibling_deps.get(current, set()):
                    if dep not in visited:
                        queue.append(dep)
                for rdep in sibling_rdeps.get(current, set()):
                    if rdep not in visited:
                        queue.append(rdep)
            clusters.append(cluster)

        # Separate orphans from real clusters
        orphan_ids: set[str] = set()
        real_clusters: list[list[str]] = []
        for cluster in clusters:
            if len(cluster) == 1:
                sid = cluster[0]
                has_edges = bool(sibling_deps.get(sid)) or bool(sibling_rdeps.get(sid))
                if not has_edges:
                    orphan_ids.add(sid)
                    continue
            real_clusters.append(cluster)

        def _has_active_spec(sids: list[str]) -> bool:
            for sid in sids:
                impl = datasets.get_impl(sid)
                if impl and any(s in impl.status for s in ("Active", "Testing", "Ready")):
                    return True
                fr = active_frs.get(sid)
                if fr and "active" in fr.status.lower():
                    return True
            return False

        def cluster_sort_key(cluster: list[str]) -> tuple[int, int, int, int]:
            total_loe = sum(_get_spec_loe_hours(sid) for sid in cluster)
            best_pri = min(
                PRIORITY_RANK.get(active_frs[sid].priority if active_frs.get(sid) else "P3", 3)
                for sid in cluster
            )
            active = 0 if _has_active_spec(cluster) else 1
            return (active, best_pri, -total_loe, 0)

        def orphan_sort_key(sid: str) -> tuple[int, int, int, int, str]:
            fr = active_frs.get(sid)
            pri = PRIORITY_RANK.get(fr.priority if fr else "P3", 3)
            loe = _get_spec_loe_hours(sid)
            impl = datasets.get_impl(sid)
            active = (
                0 if (impl and any(s in impl.status for s in ("Active", "Testing", "Ready"))) else 1
            )
            return (active, pri, -loe, 1, sid)

        def topo_sort_key(sid: str) -> tuple[int, int, str]:
            fr = active_frs.get(sid)
            stat = 0 if (fr and "active" in fr.status.lower()) else 1
            pri = PRIORITY_RANK.get(fr.priority if fr else "P3", 3)
            return (stat, pri, sid)

        def topo_sort(cluster: list[str]) -> list[str]:
            cluster_set_inner = set(cluster)
            in_degree = {sid: 0 for sid in cluster}
            for sid in cluster:
                for dep in sibling_deps.get(sid, set()):
                    if dep in cluster_set_inner:
                        in_degree[sid] += 1
            queue = sorted([sid for sid in cluster if in_degree[sid] == 0], key=topo_sort_key)
            result: list[str] = []
            while queue:
                current = queue.pop(0)
                result.append(current)
                for dependent in sibling_rdeps.get(current, set()):
                    if dependent in cluster_set_inner:
                        in_degree[dependent] -= 1
                        if in_degree[dependent] == 0:
                            queue.append(dependent)
                            queue.sort(key=topo_sort_key)
            return result

        real_clusters.sort(key=cluster_sort_key)

        sorted_specs: list[str] = []
        for cluster in real_clusters:
            sorted_specs.extend(topo_sort(cluster))
        orphan_list = sorted([sid for sid in spec_list if sid in orphan_ids], key=orphan_sort_key)
        sorted_specs.extend(orphan_list)

        return sorted_specs

    # Apply cluster-aware sorting to each epic's specs
    for epic_id in epic_sets:
        epic_sets[epic_id] = _cluster_sort_specs(epic_sets[epic_id])

    # Sort orphan specs the same way
    orphan_specs = _cluster_sort_specs(orphan_specs)

    # === PASS 5: Assemble final ordered list ===
    ordered: list[str] = []

    for epic_id in ordered_epics:
        for spec_id in epic_sets[epic_id]:
            if spec_id not in ordered:
                ordered.append(spec_id)
        ordered.append(epic_id)

    for sid in orphan_specs:
        if sid not in ordered:
            ordered.append(sid)

    # Safety: add any remaining specs
    for sid in spec_ids:
        if sid not in ordered:
            ordered.append(sid)

    return ordered


def _resolve_epic_deps(datasets: NspecDatasets) -> dict[str, list[str]]:
    """Build a mapping of epic_id -> list of epic IDs it depends on (transitive).

    Returns:
        Dict mapping each epic to ALL upstream epic IDs (direct + transitive).
    """
    active_frs = datasets.active_frs
    epics = [sid for sid, fr in active_frs.items() if fr.type == "Epic"]
    epics_set = set(epics)

    # Direct epic-to-epic deps
    direct_deps: dict[str, list[str]] = {}
    for eid in epics:
        fr = active_frs.get(eid)
        direct_deps[eid] = [d for d in (fr.deps if fr else []) if d in epics_set]

    # Resolve transitive closure
    transitive: dict[str, set[str]] = {eid: set() for eid in epics}

    def _resolve(eid: str, seen: set[str] | None = None) -> set[str]:
        if seen is None:
            seen = set()
        if eid in seen:
            return set()  # Cycle protection
        seen.add(eid)
        result = set(direct_deps.get(eid, []))
        for dep in list(result):
            result |= _resolve(dep, seen)
        transitive[eid] = result
        return result

    for eid in epics:
        _resolve(eid)

    return {eid: sorted(deps) for eid, deps in transitive.items()}


def spec_to_epic_map(datasets: NspecDatasets) -> tuple[dict[str, str], set[str]]:
    """Build spec-to-epic mapping and epic ID set.

    Returns:
        Tuple of (spec_id -> epic_id mapping, set of epic IDs)
    """
    mapping: dict[str, str] = {}
    epic_ids: set[str] = set()
    for sid, fr in datasets.active_frs.items():
        if fr.type == "Epic":
            epic_ids.add(sid)
            for dep_id in fr.deps:
                mapping[dep_id] = sid
    return mapping, epic_ids


def _get_spec_epic(spec_id: str, datasets: NspecDatasets) -> str | None:
    """Find which epic owns a spec (if any)."""
    active_frs = datasets.active_frs
    for sid, fr in active_frs.items():
        if fr.type == "Epic" and spec_id in fr.deps:
            return sid
    return None


def _is_epic_complete(epic_id: str, datasets: NspecDatasets) -> bool:
    """Check if all specs in an epic are completed."""
    fr = datasets.get_fr(epic_id)
    if not fr:
        return True
    for dep_id in fr.deps:
        dep_fr = datasets.active_frs.get(dep_id)
        if dep_fr and dep_fr.type != "Epic":
            # This spec is still active (not completed)
            impl = datasets.get_impl(dep_id)
            if impl and ("Ready" in impl.status or "Completed" in impl.status):
                continue  # This one is done
            return False
    return True


def eligible_next_specs(
    datasets: NspecDatasets,
    epic_id: str | None = None,
    blocked_ids: set[str] | None = None,
) -> list[dict[str, Any]]:
    """Return eligible specs for next_spec pick, ordered by priority.

    A spec is eligible if:
    - It's not an epic
    - It's not completed, ready, or paused
    - It has no blocked tasks
    - All its direct spec deps are completed
    - Its parent epic's upstream epic deps are all fully complete
    - It's not in the blocked_ids set

    Args:
        datasets: Loaded nspec datasets
        epic_id: Optional epic ID to filter to
        blocked_ids: Set of spec IDs that are blocked (from blockers report)

    Returns:
        List of eligible spec dicts ordered by the standard ordering algorithm.
    """
    if blocked_ids is None:
        blocked_ids = set()

    active_frs = datasets.active_frs
    spec_order = ordered_specs(datasets)

    # Resolve epic-to-epic transitive deps
    epic_transitive_deps = _resolve_epic_deps(datasets)

    # Determine epic scope filter
    epic_scope: set[str] | None = None
    if epic_id:
        epic_fr = datasets.get_fr(epic_id)
        if epic_fr:
            epic_scope = set(epic_fr.deps) if epic_fr.deps else set()

    # Collect all completed spec IDs (both active-completed and archived)
    completed_ids: set[str] = set()
    for sid in datasets.completed_frs:
        completed_ids.add(sid)
    for sid, impl in datasets.active_impls.items():
        if "Completed" in impl.status or "Ready" in impl.status:
            completed_ids.add(sid)

    eligible: dict[str, dict[str, Any]] = {}

    for spec_id, fr in active_frs.items():
        if fr.type == "Epic":
            continue

        if spec_id in blocked_ids:
            continue

        # Filter by epic if specified
        if epic_scope is not None and spec_id not in epic_scope:
            continue

        impl = datasets.active_impls.get(spec_id)
        if impl and ("Paused" in impl.status or "Exception" in impl.status):
            continue
        if impl and impl.has_blocked_tasks:
            continue

        # Check direct spec deps are complete
        all_deps_met = True
        for dep_id in fr.deps:
            if dep_id in completed_ids:
                continue
            # Dep is still active — check if it's an epic
            dep_fr = active_frs.get(dep_id)
            if dep_fr and dep_fr.type == "Epic":
                # Epic dep — check if all its specs are done
                if not _is_epic_complete(dep_id, datasets):
                    all_deps_met = False
                    break
            elif dep_id in active_frs:
                # Spec dep still active and not completed
                all_deps_met = False
                break
            # If dep_id not in active_frs and not in completed, it's external/missing — OK

        if not all_deps_met:
            continue

        # Check cross-epic blocking: if this spec's epic depends on another epic,
        # that upstream epic must be fully complete
        spec_epic = _get_spec_epic(spec_id, datasets)
        if spec_epic:
            upstream_epics = epic_transitive_deps.get(spec_epic, [])
            epic_blocked = False
            for upstream_eid in upstream_epics:
                if not _is_epic_complete(upstream_eid, datasets):
                    epic_blocked = True
                    break
            if epic_blocked:
                continue

        rank = PRIORITY_RANK.get(fr.priority, 9)
        # In-progress specs (Active/Testing/Ready) sort before new specs
        in_progress = impl and any(s in impl.status for s in ("Active", "Testing", "Ready"))
        eligible[spec_id] = {
            "spec_id": spec_id,
            "title": fr.title,
            "priority": fr.priority,
            "priority_rank": rank,
            "phase_rank": 0 if in_progress else 1,
            "status": impl.status if impl else "Unknown",
            "completion": impl.completion_percent if impl else 0,
        }

    # Order: in-progress before new within same priority, then by spec_order
    spec_order_rank = {sid: i for i, sid in enumerate(spec_order)}
    return sorted(
        eligible.values(),
        key=lambda e: (e["priority_rank"], e["phase_rank"], spec_order_rank.get(e["spec_id"], 999)),
    )
