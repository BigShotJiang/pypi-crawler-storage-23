"""Template package for nspec scaffolding."""
