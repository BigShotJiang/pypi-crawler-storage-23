"""Per-spec file-based locking for MCP operations.

Prevents race conditions when multiple agents operate on the same spec
simultaneously. Uses fcntl.flock for advisory file locking.

Lock files are stored in /tmp/nspec-locks/{spec_id}.lock
"""

from __future__ import annotations

import contextlib
import errno
import fcntl
import os
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Generator

# Default lock directory — use /tmp explicitly per AC-F7 requirement
# (/tmp is the standard POSIX temp directory and is consistent across platforms)
LOCK_DIR = Path("/tmp/nspec-locks")

# Default timeout in seconds (overridden by config.toml [timeouts] section)
DEFAULT_TIMEOUT = 10.0


def _load_timeouts() -> tuple[float, int]:
    """Load timeout values from config, falling back to defaults.

    Returns:
        (lock_acquire_s, lock_stale_s) tuple.
    """
    from nspec.config import NspecConfig

    config = NspecConfig.load()
    return config.timeouts.lock_acquire_s, config.timeouts.lock_stale_s


def _get_lock_path(spec_id: str) -> Path:
    """Get the lock file path for a spec."""
    LOCK_DIR.mkdir(parents=True, exist_ok=True)
    # Normalize spec ID to avoid path traversal issues
    safe_id = spec_id.replace("/", "_").replace("\\", "_")
    return LOCK_DIR / f"{safe_id}.lock"


def _cleanup_stale_locks() -> int:
    """Remove stale lock files (older than 1 hour) that are not currently held.

    Called on process start to clean up locks from crashed processes.
    Only removes files that can be exclusively locked (i.e., not held by
    another process), preventing a race where we unlink a file that another
    process still holds an flock() on.

    Returns:
        Number of stale locks cleaned up.
    """
    if not LOCK_DIR.exists():
        return 0

    import time

    _, lock_stale_s = _load_timeouts()
    cleaned = 0
    cutoff = time.time() - lock_stale_s

    for lock_file in LOCK_DIR.glob("*.lock"):
        try:
            if lock_file.stat().st_mtime >= cutoff:
                continue
            # Try to acquire a non-blocking lock before unlinking.
            # If another process holds flock() on this inode, skip it.
            fd = os.open(str(lock_file), os.O_RDWR, 0o644)
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                # Lock acquired — no other process holds it, safe to remove.
                fcntl.flock(fd, fcntl.LOCK_UN)
                os.close(fd)
                lock_file.unlink(missing_ok=True)
                cleaned += 1
            except OSError:
                # Lock held by another process — skip.
                os.close(fd)
        except OSError:
            pass  # File may have been removed already

    return cleaned


@contextlib.contextmanager
def spec_lock(
    spec_id: str,
    timeout: float | None = None,
) -> Generator[None]:
    """Context manager for acquiring a per-spec lock.

    Uses fcntl.flock with LOCK_EX (exclusive lock). Non-blocking with
    polling to implement timeout.

    Args:
        spec_id: The spec ID to lock
        timeout: Maximum time to wait for lock (seconds).
                 If None, reads from config.toml [timeouts] lock_acquire_s.

    Raises:
        TimeoutError: If lock cannot be acquired within timeout
        OSError: If lock file cannot be created

    Example:
        with spec_lock("S042"):
            # Critical section - only one process can be here per spec
            complete_spec(...)
    """
    import time

    if timeout is None:
        timeout, _ = _load_timeouts()

    lock_path = _get_lock_path(spec_id)

    # Create lock file if it doesn't exist
    fd = os.open(str(lock_path), os.O_RDWR | os.O_CREAT, 0o644)
    try:
        start = time.monotonic()
        while True:
            try:
                # Try non-blocking exclusive lock
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break  # Lock acquired
            except OSError as e:
                if e.errno not in (errno.EWOULDBLOCK, errno.EAGAIN):
                    raise
                # Lock held by another process
                if time.monotonic() - start > timeout:
                    raise TimeoutError(
                        f"Could not acquire lock for {spec_id} within {timeout}s. "
                        f"Another process may be operating on this spec."
                    ) from None
                time.sleep(0.1)  # Poll every 100ms

        # Touch the lock file to update mtime (for stale lock detection)
        lock_path.touch()

        yield

    finally:
        # Release lock and close fd
        fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)


@contextlib.contextmanager
def queue_lock(
    timeout: float | None = None,
) -> Generator[None]:
    """Context manager for acquiring the global queue lock.

    Prevents race conditions between concurrent agents operating on
    the shared queue. Uses a dedicated lock file separate from per-spec locks.

    Args:
        timeout: Maximum time to wait for lock (seconds).
                 If None, reads from config.toml [timeouts] lock_acquire_s.

    Raises:
        TimeoutError: If lock cannot be acquired within timeout
        OSError: If lock file cannot be created
    """
    import time as _time

    if timeout is None:
        timeout, _ = _load_timeouts()

    LOCK_DIR.mkdir(parents=True, exist_ok=True)
    lock_path = LOCK_DIR / "queue.lock"

    fd = os.open(str(lock_path), os.O_RDWR | os.O_CREAT, 0o644)
    try:
        start = _time.monotonic()
        while True:
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except OSError as e:
                if e.errno not in (errno.EWOULDBLOCK, errno.EAGAIN):
                    raise
                if _time.monotonic() - start > timeout:
                    raise TimeoutError(
                        f"Could not acquire queue lock within {timeout}s. "
                        f"Another process may be operating on the queue."
                    ) from None
                _time.sleep(0.1)

        lock_path.touch()
        yield

    finally:
        fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)


@contextlib.contextmanager
def state_lock(
    timeout: float = 2.0,
) -> Generator[None]:
    """Context manager for acquiring the state.json lock.

    Prevents concurrent writes to state.json from corrupting JSON.
    Uses a dedicated lock file and a short timeout (state operations
    should be fast).

    Args:
        timeout: Maximum time to wait for lock (seconds). Default 2s.

    Raises:
        TimeoutError: If lock cannot be acquired within timeout
        OSError: If lock file cannot be created
    """
    import time as _time

    LOCK_DIR.mkdir(parents=True, exist_ok=True)
    lock_path = LOCK_DIR / "state.lock"

    fd = os.open(str(lock_path), os.O_RDWR | os.O_CREAT, 0o644)
    try:
        start = _time.monotonic()
        while True:
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except OSError as e:
                if e.errno not in (errno.EWOULDBLOCK, errno.EAGAIN):
                    raise
                if _time.monotonic() - start > timeout:
                    raise TimeoutError(
                        f"Could not acquire state lock within {timeout}s. "
                        f"Another process may be writing state.json."
                    ) from None
                _time.sleep(0.05)  # Poll every 50ms

        lock_path.touch()
        yield

    finally:
        fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)


def with_spec_lock(timeout: float | None = None) -> Any:
    """Decorator for functions that need per-spec locking.

    The decorated function must have spec_id as its first positional argument.

    Args:
        timeout: Maximum time to wait for lock (seconds).
                 If None, reads from config.toml [timeouts] lock_acquire_s.

    Example:
        @with_spec_lock()
        def complete_spec(spec_id: str, docs_root: Path) -> ...:
            ...
    """
    from functools import wraps

    def decorator(func: Any) -> Any:
        @wraps(func)
        def wrapper(spec_id: str, *args: Any, **kwargs: Any) -> Any:
            with spec_lock(spec_id, timeout=timeout):
                return func(spec_id, *args, **kwargs)

        return wrapper

    return decorator


# Clean up stale locks on module import
_cleanup_stale_locks()
