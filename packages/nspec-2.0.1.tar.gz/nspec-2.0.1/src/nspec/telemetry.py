"""MCP tool telemetry — structured logging and timeout enforcement.

Provides two decorators:
- ``mcp_telemetry``: Logs tool entry/exit/duration/error to a rotating file
- ``mcp_timeout``: Enforces wall-clock timeout on synchronous tool execution

Both are applied automatically to every MCP tool via monkey-patching in
``mcp_server.py``. Individual tool functions require zero changes.
"""

from __future__ import annotations

import contextlib
import logging
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import TimeoutError as FuturesTimeoutError
from functools import wraps
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Any

_telemetry_logger = logging.getLogger("nspec.telemetry")

_TIMEOUT_POOL_WORKERS = 5
_timeout_pool_lock = threading.Lock()
_timeout_pool = ThreadPoolExecutor(
    max_workers=_TIMEOUT_POOL_WORKERS,
    thread_name_prefix="mcp-timeout",
)


def _submit_timeout_job(fn: Any, *args: Any, **kwargs: Any) -> Any:
    """Submit a tool call to the current timeout pool."""
    with _timeout_pool_lock:
        pool = _timeout_pool
    return pool.submit(fn, *args, **kwargs)


def _recycle_timeout_pool(reason: str) -> None:
    """Replace the timeout pool to recover from stuck worker exhaustion."""
    global _timeout_pool

    with _timeout_pool_lock:
        old_pool = _timeout_pool
        _timeout_pool = ThreadPoolExecutor(
            max_workers=_TIMEOUT_POOL_WORKERS,
            thread_name_prefix="mcp-timeout",
        )
    with contextlib.suppress(Exception):
        old_pool.shutdown(wait=False, cancel_futures=True)
    _telemetry_logger.warning("timeout_pool_recycled reason=%s", reason)


def setup_telemetry_logging(
    log_dir: Path | None = None,
    max_bytes: int = 5 * 1024 * 1024,
    backup_count: int = 3,
) -> Path:
    """Configure the telemetry logger with a rotating file handler.

    Args:
        log_dir: Directory for the log file. Defaults to
                 ``.novabuilt.dev/nspec/`` under the current working directory.
        max_bytes: Maximum log file size before rotation (default 5 MB).
        backup_count: Number of backup files to keep (default 3).

    Returns:
        Path to the log file.
    """
    if log_dir is None:
        log_dir = Path.cwd() / ".novabuilt.dev" / "nspec"
    log_dir.mkdir(parents=True, exist_ok=True)

    log_file = log_dir / "mcp-telemetry.log"

    # Avoid duplicate handlers on repeated calls
    if not _telemetry_logger.handlers:
        handler = RotatingFileHandler(
            log_file,
            maxBytes=max_bytes,
            backupCount=backup_count,
        )
        handler.setFormatter(
            logging.Formatter("%(asctime)s %(levelname)s %(message)s", datefmt="%Y-%m-%d %H:%M:%S")
        )
        _telemetry_logger.addHandler(handler)
        _telemetry_logger.setLevel(logging.DEBUG)
        # Don't propagate to root logger (avoid double-logging to stderr)
        _telemetry_logger.propagate = False

    return log_file


def mcp_telemetry(fn: Any) -> Any:
    """Decorator that logs entry/exit/duration/error for an MCP tool call."""

    @wraps(fn)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        tool_name = fn.__name__
        _telemetry_logger.info("tool_enter tool=%s", tool_name)
        start = time.monotonic()
        try:
            result = fn(*args, **kwargs)
            elapsed_ms = (time.monotonic() - start) * 1000
            _telemetry_logger.info(
                "tool_exit tool=%s duration_ms=%.1f status=ok",
                tool_name,
                elapsed_ms,
            )
            return result
        except Exception as exc:
            elapsed_ms = (time.monotonic() - start) * 1000
            _telemetry_logger.error(
                "tool_error tool=%s duration_ms=%.1f error=%s",
                tool_name,
                elapsed_ms,
                type(exc).__name__,
            )
            raise

    return wrapper


def mcp_timeout(timeout_s: int | None = None) -> Any:
    """Decorator factory that enforces wall-clock timeout on an MCP tool call.

    Uses ``concurrent.futures.ThreadPoolExecutor`` to run the tool in a
    background thread. If the tool doesn't complete within ``timeout_s``,
    returns an error dict immediately (the underlying thread continues but
    the MCP caller is unblocked).

    Args:
        timeout_s: Timeout in seconds. If None, reads from
                   ``config.timeouts.mcp_s`` (default 120s).
    """

    def decorator(fn: Any) -> Any:
        @wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            effective_timeout = timeout_s
            if effective_timeout is None:
                try:
                    from nspec.config import NspecConfig

                    effective_timeout = NspecConfig.load().timeouts.mcp_s
                except Exception:
                    effective_timeout = 120

            future = _submit_timeout_job(fn, *args, **kwargs)
            try:
                return future.result(timeout=effective_timeout)
            except FuturesTimeoutError:
                # Best-effort cancel (no-op if already running). Recycle the pool so
                # stuck workers do not permanently starve subsequent MCP calls.
                future.cancel()
                _recycle_timeout_pool(reason=f"{fn.__name__}-timeout")
                tool_name = fn.__name__
                _telemetry_logger.error(
                    "tool_timeout tool=%s timeout_s=%d",
                    tool_name,
                    effective_timeout,
                )
                return {
                    "error": f"Tool '{tool_name}' timed out after {effective_timeout}s",
                    "timeout_s": effective_timeout,
                }

        return wrapper

    return decorator
