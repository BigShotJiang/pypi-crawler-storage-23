"""Project initialization for nspec.

Detects the project stack (language, package manager, test framework, CI platform)
and scaffolds nspec configuration files, directory structure, and CI config.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from nspec.config import NspecConfig


# Runner prefix mapping per detected stack
RUNNER_PREFIXES: dict[tuple[str, str], str] = {
    ("python", "poetry"): "poetry run nspec",
    ("python", "pip"): "python -m nspec",
    ("python", "hatch"): "hatch run nspec",
    ("python", "uv"): "uv run nspec",
    ("node", "npm"): "npx nspec",
    ("node", "yarn"): "npx nspec",
    ("node", "pnpm"): "npx nspec",
    ("rust", "cargo"): "cargo run --bin nspec --",
    ("go", "go"): "go run . --",
}

DEFAULT_RUNNER_PREFIX = "nspec"

# MCP server runner mapping per detected stack
MCP_RUNNER_PREFIXES: dict[tuple[str, str], tuple[str, list[str]]] = {
    ("python", "poetry"): ("poetry", ["run", "nspec-mcp"]),
    ("python", "pip"): ("nspec-mcp", []),
    ("python", "hatch"): ("hatch", ["run", "nspec-mcp"]),
    ("python", "uv"): ("uv", ["run", "nspec-mcp"]),
    ("node", "npm"): ("npx", ["nspec-mcp"]),
    ("node", "yarn"): ("npx", ["nspec-mcp"]),
    ("node", "pnpm"): ("npx", ["nspec-mcp"]),
    ("rust", "cargo"): ("nspec-mcp", []),
    ("go", "go"): ("nspec-mcp", []),
}

DEFAULT_MCP_RUNNER: tuple[str, list[str]] = ("nspec-mcp", [])


@dataclass
class DetectedStack:
    """Result of project stack detection."""

    language: str = "unknown"
    package_manager: str = "unknown"
    test_framework: str = "unknown"
    ci_platform: str = "none"

    @property
    def runner_prefix(self) -> str:
        """Return the nspec runner prefix for this stack."""
        return RUNNER_PREFIXES.get((self.language, self.package_manager), DEFAULT_RUNNER_PREFIX)


def detect_stack(project_root: Path) -> DetectedStack:
    """Detect the project's language, package manager, test framework, and CI platform.

    Args:
        project_root: Root directory of the project to analyze.

    Returns:
        DetectedStack with detected values, or defaults for undetectable fields.
    """
    stack = DetectedStack()

    # Detect language and package manager
    _detect_language(project_root, stack)

    # Detect test framework
    _detect_test_framework(project_root, stack)

    # Detect CI platform
    _detect_ci_platform(project_root, stack)

    return stack


def _detect_language(project_root: Path, stack: DetectedStack) -> None:
    """Detect language and package manager from project files."""
    # Python — check pyproject.toml for build system
    pyproject = project_root / "pyproject.toml"
    if pyproject.exists():
        stack.language = "python"
        content = pyproject.read_text()

        if "poetry" in content.lower():
            stack.package_manager = "poetry"
        elif "hatchling" in content.lower() or "hatch" in content.lower():
            stack.package_manager = "hatch"
        elif (project_root / "uv.lock").exists():
            stack.package_manager = "uv"
        else:
            stack.package_manager = "pip"
        return

    # Python — setup.py / requirements.txt fallback
    if (project_root / "setup.py").exists() or (project_root / "requirements.txt").exists():
        stack.language = "python"
        if (project_root / "uv.lock").exists():
            stack.package_manager = "uv"
        else:
            stack.package_manager = "pip"
        return

    # Node.js
    package_json = project_root / "package.json"
    if package_json.exists():
        stack.language = "node"
        if (project_root / "pnpm-lock.yaml").exists():
            stack.package_manager = "pnpm"
        elif (project_root / "yarn.lock").exists():
            stack.package_manager = "yarn"
        else:
            stack.package_manager = "npm"
        return

    # Rust
    if (project_root / "Cargo.toml").exists():
        stack.language = "rust"
        stack.package_manager = "cargo"
        return

    # Go
    if (project_root / "go.mod").exists():
        stack.language = "go"
        stack.package_manager = "go"
        return


def _detect_test_framework(project_root: Path, stack: DetectedStack) -> None:
    """Detect test framework from project files."""
    if stack.language == "python":
        pyproject = project_root / "pyproject.toml"
        if pyproject.exists():
            content = pyproject.read_text().lower()
            if "pytest" in content:
                stack.test_framework = "pytest"
                return
            if "unittest" in content:
                stack.test_framework = "unittest"
                return
        # Check for test directories
        if (project_root / "tests").exists() or (project_root / "test").exists():
            stack.test_framework = "pytest"
            return
        stack.test_framework = "pytest"
        return

    if stack.language == "node":
        package_json = project_root / "package.json"
        if package_json.exists():
            content = package_json.read_text().lower()
            if "vitest" in content:
                stack.test_framework = "vitest"
                return
            if "jest" in content:
                stack.test_framework = "jest"
                return
            if "mocha" in content:
                stack.test_framework = "mocha"
                return
        stack.test_framework = "jest"
        return

    if stack.language == "rust":
        stack.test_framework = "cargo-test"
        return

    if stack.language == "go":
        stack.test_framework = "go-test"
        return


def _detect_ci_platform(project_root: Path, stack: DetectedStack) -> None:
    """Detect CI platform from project files."""
    if (project_root / ".github" / "workflows").exists():
        stack.ci_platform = "github"
        return

    if (project_root / "cloudbuild.yaml").exists() or (project_root / "cloudbuild.yml").exists():
        stack.ci_platform = "cloudbuild"
        return

    if (project_root / ".gitlab-ci.yml").exists():
        stack.ci_platform = "gitlab"
        return


def needs_init(project_root: Path) -> bool:
    """Check whether a project needs nspec initialization.

    Returns True when no config.toml is found AND no NSPEC_* env vars are set.

    Args:
        project_root: Root directory of the project.

    Returns:
        True if the project has no nspec configuration.
    """
    from nspec.config import CONFIG_REL_PATH

    config_file = project_root / CONFIG_REL_PATH
    if config_file.exists():
        return False

    # Check for any NSPEC_* environment variables
    nspec_env_vars = [k for k in os.environ if k.startswith("NSPEC_")]
    return not nspec_env_vars


def interactive_init(
    project_root: Path,
    interactive: bool = True,
) -> NspecConfig:
    """Run interactive (or non-interactive) initialization to choose config paths.

    Args:
        project_root: Root directory of the project.
        interactive: If True, prompt the user for path choices.
                    If False, return defaults immediately (for MCP/scripting).

    Returns:
        NspecConfig with the chosen paths.
    """
    from nspec.config import CONFIG_REL_PATH, DefaultsConfig, NspecConfig, PathsConfig

    config_file = project_root / CONFIG_REL_PATH

    if not interactive:
        return NspecConfig(
            paths=PathsConfig(),
            defaults=DefaultsConfig(),
            config_file=config_file,
        )

    # Show defaults and ask user
    defaults = PathsConfig()
    print("\nDefault directory layout:")
    print(f"  Feature requests: {defaults.feature_requests}")
    print(f"  Implementation:   {defaults.implementation}")
    print(f"  Completed:        {defaults.completed}")
    print(f"    Done subdir:       {defaults.completed_done}")
    print(f"    Superseded subdir: {defaults.completed_superseded}")
    print(f"    Rejected subdir:   {defaults.completed_rejected}")

    try:
        answer = input("\nAccept these defaults? [Y/n] ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        answer = "y"

    if answer in ("", "y", "yes"):
        return NspecConfig(
            paths=defaults,
            defaults=DefaultsConfig(),
            config_file=config_file,
        )

    # Prompt for each path
    def _prompt(label: str, default: str) -> str:
        try:
            value = input(f"  {label} [{default}]: ").strip()
        except (EOFError, KeyboardInterrupt):
            value = ""
        return value if value else default

    print("\nEnter custom directory names (press Enter for default):")
    paths = PathsConfig(
        feature_requests=_prompt("Feature requests dir", defaults.feature_requests),
        implementation=_prompt("Implementation dir", defaults.implementation),
        completed=_prompt("Completed dir", defaults.completed),
        completed_done=_prompt("Completed/done subdir", defaults.completed_done),
        completed_superseded=_prompt("Completed/superseded subdir", defaults.completed_superseded),
        completed_rejected=_prompt("Completed/rejected subdir", defaults.completed_rejected),
    )

    return NspecConfig(
        paths=paths,
        defaults=DefaultsConfig(),
        config_file=config_file,
    )


def generate_mcp_json(project_root: Path, stack: DetectedStack | None = None) -> dict:
    """Generate .mcp.json content for a project.

    Includes nspec MCP server. Codex is invoked as a subprocess via the
    built-in ``execute_codex()`` tool — no external MCP server needed.

    Args:
        project_root: Root directory of the project.
        stack: Detected stack. If None, auto-detects.

    Returns:
        Dict suitable for json.dump to .mcp.json
    """
    if stack is None:
        stack = detect_stack(project_root)

    command, args = MCP_RUNNER_PREFIXES.get(
        (stack.language, stack.package_manager), DEFAULT_MCP_RUNNER
    )

    return {
        "mcpServers": {
            "nspec": {
                "command": command,
                "args": args,
            },
        }
    }


def generate_mcp_config(project_root: Path) -> str:
    """Generate MCP configuration instructions for the current project.

    Detects the project stack and produces a ready-to-paste instruction block
    with the correct runner command for .mcp.json.

    Args:
        project_root: Root directory of the project.

    Returns:
        Multi-line instruction string.
    """
    import json

    mcp_json = generate_mcp_json(project_root)
    formatted_json = json.dumps(mcp_json, indent=2)

    return f"""\
To configure Claude Code (or any MCP-compatible agent) to use nspec:

1. Add this to your project's .mcp.json:

{formatted_json}

2. Available MCP tools after configuration:
   - epics, show, next_spec, validate (query tools)
   - create_spec, activate, task_complete, criteria_complete, advance, complete (mutation tools)
   - session_start, session_save, session_resume, session_clear (session tools)
   - execute_codex: built-in codex CLI executor for AI code reviews

3. Verify with: nspec validate"""


def scaffold_project(
    project_root: Path,
    docs_root: Path | None = None,
    stack: DetectedStack | None = None,
    ci_platform_override: str | None = None,
    force: bool = False,
    config: NspecConfig | None = None,
) -> list[Path]:
    """Scaffold a new nspec project structure.

    Creates config.toml, nspec.mk, docs directories with templates, and CI config.

    Args:
        project_root: Root directory of the project.
        docs_root: Docs directory path. Defaults to project_root / "docs".
        stack: Detected stack. If None, auto-detects.
        ci_platform_override: Override CI platform (github/cloudbuild/gitlab/none).
        force: If True, overwrite existing files.

    Returns:
        List of paths that were created.

    Raises:
        FileExistsError: If files already exist and force is False.
    """
    if stack is None:
        stack = detect_stack(project_root)

    if docs_root is None:
        docs_root = project_root / "docs"

    ci_platform = ci_platform_override if ci_platform_override else stack.ci_platform
    created: list[Path] = []

    # 1. .novabuilt.dev/nspec/config.toml
    from nspec.config import NspecConfig

    config_file = project_root / ".novabuilt.dev" / "nspec" / "config.toml"
    if config is not None:
        # Use caller-provided config (from interactive_init)
        config.config_file = config_file
        if config_file.exists() and not force:
            raise FileExistsError(f"File already exists: {config_file} (use --force to overwrite)")
        config.save()
    else:
        config = NspecConfig.scaffold(project_root, force=force)
    created.append(config_file)

    # 2. nspec.mk
    created.extend(
        _write_file(
            project_root / "nspec.mk",
            _generate_nspec_mk(stack),
            force=force,
        )
    )

    # 3. Docs directories — use paths from config
    fr_dir = docs_root / config.paths.feature_requests
    impl_dir = docs_root / config.paths.implementation
    completed_base = docs_root / config.paths.completed

    dirs_to_create = [
        fr_dir,
        impl_dir,
        completed_base / config.paths.completed_done,
        completed_base / config.paths.completed_superseded,
        completed_base / config.paths.completed_rejected,
    ]

    for d in dirs_to_create:
        d.mkdir(parents=True, exist_ok=True)
        created.append(d)

    # 4. Templates — write to .novabuilt.dev/nspec/resources/ (legacy flat)
    from nspec.resources import BUILTIN_PROFILES, load_template, load_template_profile

    resources_dir = project_root / ".novabuilt.dev" / "nspec" / "resources"
    resources_dir.mkdir(parents=True, exist_ok=True)
    created.append(resources_dir)

    created.extend(
        _write_file(
            resources_dir / "fr-template.md",
            load_template("fr"),
            force=force,
        )
    )
    created.extend(
        _write_file(
            resources_dir / "impl-template.md",
            load_template("impl"),
            force=force,
        )
    )

    # 4a. Template profiles — write to .novabuilt.dev/nspec/templates/{profile}/
    for profile in BUILTIN_PROFILES:
        profile_dir = project_root / ".novabuilt.dev" / "nspec" / "templates" / profile
        profile_dir.mkdir(parents=True, exist_ok=True)
        created.append(profile_dir)

        for doc_type in ("fr", "impl"):
            created.extend(
                _write_file(
                    profile_dir / f"{doc_type}.md",
                    load_template_profile(profile, doc_type),
                    force=force,
                )
            )

    # 4b. Docs template — write to .novabuilt.dev/nspec/templates/docs/
    docs_templates_dir = project_root / ".novabuilt.dev" / "nspec" / "templates" / "docs"
    docs_templates_dir.mkdir(parents=True, exist_ok=True)
    created.append(docs_templates_dir)

    created.extend(
        _write_file(
            docs_templates_dir / "changelog.md",
            load_template("changelog"),
            force=force,
        )
    )

    # 5. CLAUDE.md — scaffolded dev process file
    _scaffold_claudemd(project_root, docs_root, config, force=force, created=created)

    # 6. CI config
    if ci_platform and ci_platform != "none":
        ci_files = _generate_ci_config(ci_platform)
        for rel_path, content in ci_files:
            created.extend(
                _write_file(
                    project_root / rel_path,
                    content,
                    force=force,
                )
            )

    # 7. Install built-in skills to .claude/commands/
    from nspec.skills import install_skills, resolve_skills

    skills_sources = config.skills.sources if hasattr(config, "skills") else ["builtin"]
    resolved = resolve_skills(skills_sources, project_root=project_root)
    installed = install_skills(project_root, resolved)
    created.extend(installed)

    # 8. Create .mcp.json with nspec and codex-cli servers
    mcp_json_path = project_root / ".mcp.json"
    if not mcp_json_path.exists() or force:
        import json

        mcp_config = generate_mcp_json(project_root, stack)
        created.extend(
            _write_file(
                mcp_json_path,
                json.dumps(mcp_config, indent=2) + "\n",
                force=force,
            )
        )

    return created


def _write_file(path: Path, content: str, *, force: bool = False) -> list[Path]:
    """Write content to a file, creating parent directories as needed.

    Returns:
        List containing the path if written, empty list if skipped.

    Raises:
        FileExistsError: If file exists and force is False.
    """
    if path.exists() and not force:
        raise FileExistsError(f"File already exists: {path} (use --force to overwrite)")

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content)
    return [path]


def _generate_nspec_mk(stack: DetectedStack) -> str:
    """Generate nspec.mk content for the given stack."""
    from nspec.templates.init.nspec_mk import render

    return render(runner_prefix=stack.runner_prefix)


def _generate_ci_config(platform: str) -> list[tuple[str, str]]:
    """Generate CI config file(s) for the given platform.

    Returns:
        List of (relative_path, content) tuples.
    """
    if platform == "github":
        from nspec.templates.init.ci_github import render

        return [(".github/workflows/nspec.yml", render())]

    if platform == "cloudbuild":
        from nspec.templates.init.ci_cloudbuild import render

        return [("cloudbuild.yaml", render())]

    if platform == "gitlab":
        from nspec.templates.init.ci_gitlab import render

        return [(".gitlab-ci.yml", render())]

    return []


_MANAGED_COMMENT = "<!-- managed-by: nspec -->"


def _is_managed_claudemd(path: Path) -> bool:
    """Check if a CLAUDE.md file is managed by nspec.

    Looks for ``<!-- managed-by: nspec -->`` in the first line.
    """
    if not path.exists():
        return False
    first_line = path.read_text(encoding="utf-8").split("\n", 1)[0]
    return _MANAGED_COMMENT in first_line


def _interpolate_template(content: str, variables: dict[str, str]) -> str:
    """Replace ``{{key}}`` placeholders with values from *variables*."""
    for key, value in variables.items():
        content = content.replace("{{" + key + "}}", value)
    return content


def _scaffold_claudemd(
    project_root: Path,
    docs_root: Path,
    config: NspecConfig,
    *,
    force: bool = False,
    created: list[Path],
) -> None:
    """Write a starter CLAUDE.md to the project root.

    Rules:
    - New file: always write.
    - Existing file without ``<!-- managed-by: nspec -->``: never overwrite.
    - Existing managed file: overwrite only when *force* is True.
    """
    from nspec.resources import load_template

    dest = project_root / "CLAUDE.md"

    if dest.exists():
        if not _is_managed_claudemd(dest):
            # User owns this file — never touch it
            return
        if not force:
            # Managed but not forced — skip
            return

    # Compute template variables
    project_name = project_root.name
    try:
        docs_rel = str(docs_root.relative_to(project_root))
    except ValueError:
        docs_rel = str(docs_root)
    epic_id = getattr(config.defaults, "epic", None) or "001"

    variables = {
        "project_name": project_name,
        "docs_root": docs_rel,
        "epic_id": epic_id,
        "feature_requests": config.paths.feature_requests,
        "implementation": config.paths.implementation,
        "completed": config.paths.completed,
    }

    content = _interpolate_template(load_template("claudemd"), variables)
    dest.write_text(content, encoding="utf-8")
    created.append(dest)
