"""Built-in skills bundled with nspec, organized by target agent.

Skills are markdown files organized into target-specific subdirectories:
- ``skills/claude/`` — Claude Code slash commands (installed to ``.claude/commands/``)
- ``skills/codex/`` — Codex prompt templates (used programmatically, not installed)

Claude skills are installed to ``.claude/commands/`` during ``nspec init`` or
via the ``skills_install`` MCP tool. Codex skills are injected into prompts
by the review and refinement workflows.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from importlib import resources
from pathlib import Path

# Frontmatter field added to installed skill files to track nspec management.
# Must be inside the YAML frontmatter (not before it) so Claude Code can
# still parse the frontmatter starting with '---' on line 1.
MANAGED_KEY = "managed-by"
MANAGED_VALUE = "nspec"

# Valid target values for skill loading.
VALID_TARGETS = ("claude", "codex")


def get_builtin_skills(target: str = "claude") -> dict[str, str]:
    """Return built-in skills for a target agent as a dict of {name: content}.

    Loads ``.md`` files from the ``skills/{target}/`` subdirectory using
    ``importlib.resources`` for correct package data access.

    Args:
        target: Agent target — ``"claude"`` (default) or ``"codex"``.

    Returns:
        Dict mapping skill name to markdown content.

    Raises:
        ValueError: If target is not a valid agent name.
    """
    if target not in VALID_TARGETS:
        raise ValueError(f"Invalid target {target!r}, must be one of {VALID_TARGETS}")

    skills: dict[str, str] = {}
    skills_dir = resources.files("nspec.skills").joinpath(target)

    for item in skills_dir.iterdir():
        if hasattr(item, "name") and item.name.endswith(".md"):
            name = item.name.removesuffix(".md")
            skills[name] = item.read_text(encoding="utf-8")

    return skills


def resolve_skills(
    sources: list[str],
    project_root: Path | None = None,
    *,
    target: str = "claude",
) -> dict[str, SkillInfo]:
    """Resolve skills from an ordered list of sources.

    Later sources override earlier ones by filename (merge semantics).
    Builtin skills are loaded from the target-specific subdirectory.
    External (filesystem) sources remain flat — no target filtering.

    Args:
        sources: Ordered list of source identifiers.
            - "builtin": skills bundled with the nspec package
            - Any other string: path to a directory of .md skill files
        project_root: Root directory for resolving relative paths.
        target: Agent target for builtin skills — ``"claude"`` or ``"codex"``.

    Returns:
        Dict mapping skill name to SkillInfo, in merge order.
    """
    resolved: dict[str, SkillInfo] = {}

    if not sources:
        sources = ["builtin"]
    elif "builtin" not in sources:
        sources = ["builtin", *sources]

    for source in sources:
        if source == "builtin":
            for name, content in get_builtin_skills(target=target).items():
                resolved[name] = SkillInfo(
                    name=name,
                    content=content,
                    source="builtin",
                    path=None,
                    target=target,
                )
        else:
            # Filesystem source — resolve relative to project root
            source_path = Path(source).expanduser()
            if not source_path.is_absolute() and project_root:
                source_path = project_root / source_path
            if source_path.is_dir():
                for md_file in sorted(source_path.glob("*.md")):
                    name = md_file.stem
                    content = md_file.read_text(encoding="utf-8")
                    resolved[name] = SkillInfo(
                        name=name,
                        content=content,
                        source=str(source),
                        path=md_file,
                        target=target,
                    )

    return resolved


def _is_managed(content: str) -> bool:
    """Check if file content is managed by nspec via frontmatter field."""
    if not content.startswith("---") or content.count("---") < 2:
        return False
    frontmatter = content.split("---", 2)[1]
    return f"{MANAGED_KEY}: {MANAGED_VALUE}" in frontmatter


def _inject_managed_field(content: str) -> str:
    """Inject managed-by field into YAML frontmatter.

    If content starts with '---', inserts 'managed-by: nspec' as the
    first field after the opening '---' line. If no frontmatter exists,
    wraps the content with frontmatter containing only the managed-by field.
    """
    marker = f"{MANAGED_KEY}: {MANAGED_VALUE}\n"

    if content.startswith("---\n"):
        # Insert after opening '---'
        return "---\n" + marker + content[4:]

    # No frontmatter — wrap with one
    return f"---\n{marker}---\n{content}"


def install_skills(
    project_root: Path,
    skills: dict[str, SkillInfo],
    *,
    force: bool = False,
) -> list[Path]:
    """Write resolved Claude skills to ``.claude/commands/`` in the project.

    Only installs skills with ``target="claude"``. Codex skills are used
    programmatically and are never written to the filesystem.

    Only writes files that are new or already managed by nspec (have the
    managed-by frontmatter field). User-created files are left untouched
    unless force=True.

    Symlinks are resolved before writing to prevent accidentally mutating
    source files in dogfooding repos where ``.claude/commands/`` contains
    symlinks to ``src/nspec/skills/``.

    Args:
        project_root: Project root directory.
        skills: Resolved skills from resolve_skills().
        force: If True, overwrite all files regardless of managed-by status.

    Returns:
        List of paths that were written.
    """
    commands_dir = project_root / ".claude" / "commands"
    commands_dir.mkdir(parents=True, exist_ok=True)
    written: list[Path] = []

    for name, info in skills.items():
        # Only install Claude skills to .claude/commands/
        if info.target != "claude":
            continue

        dest = commands_dir / f"{name}.md"

        # Resolve symlinks to avoid mutating source files
        real_dest = dest.resolve()

        # Skip files not managed by nspec (user-created) unless forced
        if not force and real_dest.exists():
            existing = real_dest.read_text(encoding="utf-8")
            if not _is_managed(existing):
                continue

        # If the dest is a symlink, remove it first and write a regular file
        if dest.is_symlink():
            dest.unlink()

        # Write with managed-by field in frontmatter
        dest.write_text(_inject_managed_field(info.content), encoding="utf-8")
        written.append(dest)

    return written


@dataclass
class SkillInfo:
    """Metadata about a resolved skill."""

    name: str
    content: str
    source: str  # "builtin" or a path string
    path: Path | None  # None for builtin skills
    target: str = field(default="claude")  # "claude" or "codex"
