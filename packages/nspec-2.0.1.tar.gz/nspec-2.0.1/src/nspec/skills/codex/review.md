---
description: Codex review prompt template for spec implementation review
target: codex
---

# Codex Review Prompt Template

This skill defines the prompt template used when Codex reviews a spec implementation via `codex_review` / `execute_codex`.

## Prompt Structure

The review prompt is assembled from three data sources:

1. **FR Acceptance Criteria** — extracted from the FR file's `## Acceptance Criteria` section
2. **IMPL Task List** — extracted from the IMPL file's `## Tasks` section (with completion state)
3. **Git Diff** — code changes via `git diff main...HEAD` (or other diff mode)

## Template

```
You are reviewing an implementation for spec {spec_id}: {title}

## Acceptance Criteria

{acceptance_criteria_from_fr}

## Implementation Tasks (with completion state)

{tasks_from_impl}

## Code Changes (git diff)

```diff
{git_diff}
```

## Your Task

Review this implementation against the acceptance criteria above. Check:
1. Do the code changes satisfy each acceptance criterion?
2. Are there any bugs, security issues, or quality concerns?
3. Is the implementation complete (all tasks checked)?

Respond with exactly one of these verdicts on its own line:

VERDICT: APPROVED
(if the implementation satisfies all criteria and is production-ready)

VERDICT: NEEDS_WORK
(followed by specific feedback on what needs to change)

Be concise and specific in your feedback.
```

## Expected Output

Codex must respond with exactly one verdict line:

- `VERDICT: APPROVED` — implementation satisfies all criteria
- `VERDICT: NEEDS_WORK` — followed by numbered feedback items

Alternatively, codex-cli `review` tool outputs P-level findings:
- `[P0]`/`[P1]` findings → NEEDS_WORK
- Only `[P2]`/`[P3]` findings → APPROVED

The verdict is parsed by `parse_review_verdict()` in `src/nspec/review.py`.

## Invocation

This template is assembled programmatically by `generate_review_prompt()` in `src/nspec/review.py` and invoked via the built-in executor:

```
codex_review(spec_id, base_branch="main")  # generates prompt + review_token
execute_codex(prompt="{assembled_prompt}")  # spawns codex CLI subprocess
```

The MCP tool `codex_review` generates the prompt and token; `execute_codex` runs it via the codex CLI subprocess.
