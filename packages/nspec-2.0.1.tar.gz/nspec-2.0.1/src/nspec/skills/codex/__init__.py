"""Codex agent skill definitions for nspec."""
