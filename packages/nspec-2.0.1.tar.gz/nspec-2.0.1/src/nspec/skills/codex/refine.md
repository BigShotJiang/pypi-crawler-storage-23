---
description: Codex refinement prompt template for skeleton IMPL task generation
target: codex
---

# Codex Refinement Prompt Template

This skill defines the prompt template used when Codex refines a skeleton IMPL file via `codex_refine` / `execute_codex`.

## Prompt Structure

The refinement prompt is assembled from two data sources:

1. **FR Content** — the full feature request document (problem, solution, acceptance criteria, design)
2. **Current IMPL Tasks** — the skeleton placeholder tasks from the IMPL template

## Template

```
You are refining the implementation plan for spec {spec_id}: {title}

## Feature Request (FR)

{fr_content}

## Current IMPL Tasks (skeleton -- needs refinement)

{current_tasks}

## Your Task

Replace the placeholder tasks above with a concrete implementation plan.

### Rules

1. Use action verbs (Create, Add, Implement, Wire, Write)
2. Each task gets a `File:` annotation with the target source file
3. Each task gets a `Validates:` reference to FR acceptance criteria where applicable
4. Aim for 5-15 tasks total, grouped into phases (Core Logic, Integration, Testing)
5. Tasks should be completable in one sitting
6. Use subtasks (1.1, 1.2) only when a task has 2+ distinct steps
7. Include a testing phase with unit tests
8. Every task checkbox must use `- [ ]` format

### Output Format

Respond with exactly this structure:

EXECUTIVE_SUMMARY: [1-2 sentences describing what we're building and the key approach]

LOE: [estimated level of effort, e.g., "1d", "2d", "3d"]

TASKS_START
### Phase 1: Core Logic

- [ ] 1. [First real task]
  - File: `src/path/to/file.py`
  - Validates: FR AC-F1

- [ ] 2. [Second real task]
  - File: `src/path/to/file.py`

### Phase 2: Integration

- [ ] 3. [Integration task]
  - File: `src/path/to/file.py`

### Phase 3: Testing

- [ ] N. [Test task]
  - File: `tests/test_file.py`
  - Validates: FR AC-Q1
TASKS_END

Be specific about files, functions, and what each task produces. No placeholders.
```

## Expected Output

Codex must respond with:

1. `EXECUTIVE_SUMMARY:` line — 1-2 sentence description
2. `LOE:` line — estimated level of effort
3. Tasks between `TASKS_START` and `TASKS_END` delimiters

The output is parsed by `parse_refinement_result()` in `src/nspec/refine.py`.

## Invocation

This template is assembled programmatically by `generate_refinement_prompt()` in `src/nspec/refine.py` and invoked via the built-in executor:

```
codex_refine(spec_id)                       # generates prompt
execute_codex(prompt="{assembled_prompt}")   # spawns codex CLI subprocess
write_refinement(spec_id, codex_output)     # parses and writes to IMPL
```

The MCP tool `codex_refine` orchestrates detection (is the IMPL a skeleton?) and prompt generation. `execute_codex` runs it via the codex CLI subprocess. `write_refinement` handles parsing and writing the result back to the IMPL.
