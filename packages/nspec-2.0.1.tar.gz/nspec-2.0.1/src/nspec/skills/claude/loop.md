---
description: Autonomous loop through the backlog — pick, execute, complete, repeat
argument-hint: [e###] [--max-specs <n>] [--dry-run] [--no-refine] [with <model> agent swarm]
---

Thin orchestrator that picks specs and delegates execution to `/go`. Pick specs in priority order, call `/go` for each one, handle failures, and loop until the backlog is clear or limits are reached.

**CRITICAL: This is an AUTONOMOUS LOOP. After completing or blocking a spec, you MUST immediately loop back to Phase 1 and pick the next spec. NEVER ask the user "should I continue?" or "do you want me to proceed?" — the answer is always yes. The ONLY reasons to stop are: (1) `next_spec` returns no candidates, (2) `--max-specs` limit reached, or (3) the user explicitly interrupts. Asking for confirmation defeats the entire purpose of autonomous execution.**

**All backlog state is managed through nspec MCP tools — zero direct file I/O.**

## Argument Parsing

Parse `$ARGUMENTS` for:
- `--epic <id>` or bare `e###` → filter to a specific epic
- bare `s###` or `###` (numeric, not matching `e###`) → target a specific spec (skip Phase 1, just call `/go`)
- `--max-specs <n>` → stop after N spec completions (default: unlimited)
- `--dry-run` → show next pick and exit without executing
- `--no-refine` → skip backlog refinement after each completion
- `with <model> agent swarm` → parallel execution mode (see Swarm Mode below)

Initialize counters: `completed = 0`, `blocked_list = []`.

## Swarm Mode

When `with <model> agent swarm` is specified (e.g., `with sonnet agent swarm`):

1. **Initialize queue**: Call `queue_init(epic_id, max_agents=5)` to populate the work queue from `eligible_next_specs()`
2. **Launch parallel agents**: For each agent slot, call `queue_claim(agent_id)` to atomically assign specs. Each agent gets a unique `agent_id` (e.g., `worker-1`, `worker-2`).
3. **Agent executes**: Each agent runs `/go {claimed_spec_id}`. Agents call `queue_heartbeat(agent_id)` periodically to extend their lease.
4. **Agent releases**: On completion, call `queue_release(agent_id, spec_id, completed=True)`. On failure, call `queue_release(agent_id, spec_id, reason="...")` to return the spec to the queue.
5. **Continue launching**: After each agent finishes, call `queue_claim` to get the next spec. Repeat until queue is empty.
6. **Monitor progress**: Call `queue_status()` between batches to track agents, queued specs, and completed specs.

**Swarm agent prompt**: Each agent gets `/go {spec_id}` with subagent guardrails.

**Batch continuation is critical**: After each batch completes, the orchestrator MUST call `queue_claim` for each free agent slot. Do NOT stop after one batch.

**Progress tracking between batches**:
```
Queue init: 10 specs for E002 (max_agents=5)
Batch 1: 5 agents claimed (S007, S033, S034, S035, S036)
  → 4 completed, 1 released (blocked)
Batch 2: 5 agents claimed (S037, S038, S039, S040, S041)
  → 5 completed
Queue empty — no more specs to claim
EXIT: 9 completed, 1 blocked
```

**Lease timeout recovery**: If an agent crashes without releasing, its spec is automatically reclaimed after `lease_ttl_seconds` (default: 300s). The next `queue_claim` call reaps expired leases before assigning.

For sequential mode (no swarm argument), continue to Phase 0 below.

## Loop Protocol

### Phase 0: Load Pipeline

1. Call `loop_pipeline()` to get the step list, agent map, and source indicator.
2. Store the result: `pipeline_steps`, `agent_map`, `pipeline_source`.
3. If `pipeline_source` is `"default"`, execute the phases below in their numbered order.
4. If `pipeline_source` is `"config"`, iterate through `pipeline_steps` and for each step:
   - Match `step.step` to the phase name below (e.g., `"pick"` → Phase 1, `"refine"` → Phase 8).
   - Skip unknown step types with a warning: `"Unknown pipeline step: {step.step}, skipping"`.
5. Steps not present in the pipeline are skipped entirely.

**Step type → Phase mapping:**

| Step type | Phase |
|-----------|-------|
| `pick` | Phase 1: Pick |
| `execute` | → `/go {spec_id}` (covers start, author_fr, auto_refine, execute, verify, review, complete) |
| `refine` | Phase 8: Refine |
| `report` | Phase 9: Progress Report |

**Note:** The `start`, `author_fr`, `auto_refine`, `verify`, `review`, and `complete` step types are all handled inside `/go`. If the pipeline config includes them individually, they map to the single `/go` call.

### Phase 0.5: Targeted Spec Shortcut <!-- not a pipeline step -->

**Only execute this phase if a spec ID argument was provided** (bare `s###` or `###`).

1. Call `/go {spec_id}` — the full executor handles everything (resolution, resume, execute, verify, review, complete).
2. If `/go` succeeds → increment `completed`, print completion summary, **EXIT**.
3. If `/go` fails (spec was parked) → append to `blocked_list`, print failure summary, **EXIT**.

Do NOT loop after a targeted spec — the user asked for one specific spec.

### Phase 1: Pick <!-- step_type: pick -->

1. Call `get_epic` to resolve epic scope. If `--epic` was provided, use that ID; otherwise use the active epic.
2. Call `next_spec` (pass `epic_id` if set) to get the highest-priority unblocked spec.
3. If `next_spec` returns no candidate:
   - Print a summary: specs completed this run, blocked specs list.
   - **EXIT** — backlog is clear (or fully blocked).

### Phase 2: Dry-Run Check <!-- not a pipeline step -->

If `--dry-run` is active:
- Call `show` with the picked spec ID to display full details.
- Print: "Dry run — would pick spec {id}: {title}"
- **EXIT**.

### → /go {spec_id} <!-- replaces Phases 3-7 -->

Call `/go {spec_id}` to execute the full spec lifecycle. `/go` handles:
- Resume detection (skips phases based on IMPL status)
- Phase 3: Start (activate + session_start + author FR + auto-refine)
- Phase 4: Execute (task loop + tests + task_complete)
- Phase 5: Verify (criteria_complete for each AC)
- Phase 6: Review (codex_review + write_review_verdict, 2 retries)
- Phase 7: Complete (advance + complete + session_clear + git commit)

**If `/go` succeeds** → increment `completed`, continue to Phase 8.
**If `/go` fails** (spec was parked or hit an exception) → append spec to `blocked_list`, **GOTO Phase 1** (pick next spec).

### Phase 8: Refine <!-- step_type: refine -->

Skip this phase if `--no-refine` is set.

After completing a spec, assess whether the backlog ordering still makes sense:

1. Call `epics` to review overall epic progress.
2. Call `blocked_specs` to check if anything is newly unblocked or still stuck.
3. Call `next_spec` (peek only — do not activate) to see what would be picked next.
4. Consider:
   - Did completing this spec unblock other specs? If so, are their priorities correct?
   - Did you learn something during execution that changes priorities?
   - Is there new work to capture? (missing specs, missing tasks on existing specs)
5. Take action using MCP tools:
   - `add_dep` / `remove_dep` to fix the dependency graph
   - `set_priority` to adjust priorities based on new knowledge
   - `create_spec` to capture newly discovered work
   - `task_unblock` to release tasks that were waiting on the completed spec
6. Print a brief refinement summary:
   - Dependencies changed (if any)
   - Priorities adjusted (if any)
   - New specs created (if any)
   - "No refinement needed" if nothing changed

### Phase 9: Progress Report <!-- step_type: report -->

Print after each spec completion:
- Specs completed this run: `{completed}`
- Specs remaining in epic (estimate from backlog)
- Specs blocked this run: `{blocked_list}`

If `--max-specs` was set and `completed >= max_specs`:
- Print full session summary.
- **EXIT**.

### GOTO Phase 1 (MANDATORY — DO NOT STOP HERE)

**You MUST loop back to Phase 1 now.** Call `next_spec` and continue. Do NOT ask the user if they want to continue. Do NOT summarize and wait. Do NOT treat this as a stopping point. The loop continues until `next_spec` returns no candidates or `--max-specs` is reached.

## Exit Summary

On any exit, print:
- Total specs completed this run
- Total specs blocked (with IDs and reasons)
- Blocked list for follow-up

## Resilience Notes

**`/go` handles its own failures:** `/go` parks specs on failure and returns control. `/loop` just needs to record the blocked spec and move on to the next one.

**Context limits:** Each `/go` call executes in the orchestrator context. For complex specs, `/go` may spawn subagents internally.

**Checkpointing:** `/go` calls `session_save` throughout execution. If the session crashes, `/go {spec_id}` will resume from the last checkpoint.

**Never crash the orchestrator:** If `/go` fails for any reason, record it and continue. The loop must keep going.

**Exception state:** `/go` uses `exception()` (not `park()`) for failures that indicate the agent is stuck or misbehaving (timeout exceeded, iteration limit exceeded, guardrail violations).

## Required MCP Tools

| Tool | Phase |
|------|-------|
| `loop_pipeline` | Phase 0 — load pipeline and agent map |
| `get_epic` | Phase 1 — resolve epic scope |
| `next_spec` | Phase 1 — select highest-priority unblocked spec |
| `show` | Phase 2 — display spec details (dry-run) |
| `epics` | Phase 8 — review epic progress |
| `blocked_specs` | Phase 8 — check for newly unblocked work |
| `set_priority` | Phase 8 — adjust priorities |
| `add_dep` | Phase 8 — add discovered dependencies |
| `remove_dep` | Phase 8 — remove outdated dependencies |
| `create_spec` | Phase 8 — capture newly discovered work |
| `task_unblock` | Phase 8 — release tasks waiting on completed spec |
| `queue_init` | Swarm — initialize work queue from backlog |
| `queue_claim` | Swarm — atomically claim next spec for an agent |
| `queue_release` | Swarm — release spec (completed or back to queue) |
| `queue_heartbeat` | Swarm — extend agent lease |
| `queue_status` | Swarm — monitor queue progress |

All execution-phase tools (`activate`, `session_start`, `task_complete`, `criteria_complete`, `codex_review`, `advance`, `complete`, etc.) are used by `/go` — not directly by `/loop`.
