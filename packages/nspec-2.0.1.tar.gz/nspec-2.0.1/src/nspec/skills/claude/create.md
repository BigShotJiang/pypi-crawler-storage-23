---
description: Create a new spec with codebase-aware pre-fill
argument-hint: <description of what to build>
---

Create a new nspec spec from a natural-language description. Analyzes the codebase to pre-fill acceptance criteria, tasks, and test specifications — producing a ready-to-work spec instead of a skeleton.

## Argument Parsing

Parse `$ARGUMENTS` for a natural-language description of the feature, fix, or change.

- If no argument is provided, use `AskUserQuestion` to ask: "What do you want to build?" with a free-text input.
- The description can be a sentence, phrase, or short paragraph.

## Step 1: Gather Context

### 1a: Determine Epic

1. Call `epics()` to get the list of active epics with their IDs, priorities, and titles.
2. Use `AskUserQuestion` to ask "Which epic should this spec belong to?" with options built from the epic list, plus "New epic" and let the user pick.
3. If the user selects "New epic", ask for the epic title, then call `create_spec(title, is_epic=True, set_default=True)` to create it first.
4. Store the chosen `epic_id`.

### 1b: Determine Priority

Use `AskUserQuestion` to ask "What priority?" with these options:
- **P1 High** — Blocking or urgent
- **P2 Medium (Recommended)** — Standard feature work
- **P3 Low** — Nice-to-have, backlog

Store the chosen priority.

### 1c: Explore the Codebase

Based on the user's description, explore the codebase to gather context for authoring:

1. **Identify relevant files:** Use `Glob` and `Grep` to find source files related to the description. Look for:
   - Files whose names match keywords in the description
   - Files containing functions/classes related to the described feature
   - Existing test files that test similar functionality

2. **Read key files:** Use `Read` to examine the most relevant 3-5 files. Understand:
   - Current architecture and patterns
   - Existing interfaces that the new feature would touch
   - Test patterns used in the project

3. **Check existing specs:** Use `Grep` to search `docs/frs/active/` and `docs/completed/done/` for related specs that might inform the design.

4. **Build a context summary** (internal — not shown to user):
   - Files that will likely be modified
   - Existing patterns to follow
   - Test file conventions
   - Dependencies on other modules

## Step 2: Create the Spec

Call `create_spec(title=<title>, priority=<priority>, epic_id=<epic_id>)`.

- Derive the `title` from the user's description — make it concise and imperative (e.g., "Add rate limiting to MCP server")
- Save the returned `spec_id`, `fr_path`, and `impl_path`

## Step 3: Author the FR

Read the created FR file (it will be a skeleton). Replace its contents with a fully-authored FR using the `Edit` tool. The FR must include:

### Required Sections

1. **Executive Summary:** 1-2 sentences describing what this feature does and why it matters. Ground it in the codebase context you discovered.

2. **Problem:** Describe the gap or pain point. Reference specific files or behaviors you found during exploration.

3. **Solution:**
   - **Core Concept:** High-level approach in one paragraph
   - **Key Components:** 2-4 bullet points describing what gets built/changed, referencing actual files
   - **User Experience:** How users interact — CLI commands, MCP calls, config changes, TUI behavior

4. **Acceptance Criteria:**
   - **Functional (AC-F1, AC-F2, ...):** Concrete, testable criteria derived from the description AND codebase context. Each should reference the actual behavior being added/changed.
   - **Quality (AC-Q1, AC-Q2):** Always include `Tests pass (make test-quick)` and `No lint/type errors (make check)`

5. **Test Specifications:**
   - **Positive (TC-P1, ...):** Happy-path test cases based on the acceptance criteria
   - **Negative (TC-N1, ...):** Error/edge cases — invalid input, missing config, boundary conditions

### Authoring Guidelines

- Reference actual file paths discovered during exploration (e.g., "`src/nspec/mcp_server.py`")
- Use patterns consistent with existing specs in the project
- Keep ACs atomic and independently verifiable
- Each AC should map to at least one test specification

## Step 4: Author the IMPL

Read the created IMPL file (it will be a skeleton). Replace its contents with a fully-authored IMPL using the `Edit` tool. The IMPL must include:

### Required Sections

1. **Executive Summary:** 1-2 sentences on what we're building and the key approach.

2. **Implementation Strategy:**
   - **Approach:** How we'll implement this, referencing actual files and patterns
   - **Phasing:** Group tasks into logical phases (Core Logic → Integration → Testing)

3. **Tasks:** Concrete, actionable checkbox items (`- [ ] N. Description`). Each task should:
   - Be completable in a single focused session
   - Reference the specific file(s) to modify
   - Note which FR acceptance criterion it validates
   - Follow the pattern: verb + what + where (e.g., "Add rate limiter middleware to `src/nspec/mcp_server.py`")

4. **Files Modified:** Table of files with change type (New/Modified) and description.

5. **LOE:** Realistic estimate based on task count and complexity. Use: 0.5d (1-3 tasks), 1d (4-7 tasks), 2d (8-12 tasks), 3d+ (13+ tasks).

6. **Definition of Done:** Standard DoD items (tests pass, lint clean, ACs marked, committed, codex review APPROVED).

### Task Guidelines

- Aim for 3-8 tasks. Fewer means the spec is too coarse; more means split into multiple specs.
- Tasks should be ordered by dependency (foundations first, then features, then tests).
- Every AC-F* should have at least one task that validates it.
- Include a testing task that covers both positive and negative test cases.

## Step 5: Validate and Report

1. Call `validate()` to ensure the authored spec passes all validation checks.
2. If validation fails, fix the issues and re-validate.
3. Print a summary:

```
Created S### — {title}
Epic: E### ({epic_title})
Priority: P#
Tasks: N tasks, LOE: Xd
ACs: N functional, 2 quality

Ready to execute: /go S###
```

## Error Handling

- **No description provided and user cancels:** Print "No description provided." and EXIT.
- **No epics exist:** Create the spec without an epic (omit `epic_id`). Suggest creating an epic.
- **Validation fails after authoring:** Fix the validation errors in the authored content and retry.
- **Codebase exploration finds nothing relevant:** Still create the spec, but note in the FR that the feature is net-new with no existing patterns to follow.

## Rules

- **Always explore first:** Never write the FR/IMPL without reading relevant source code.
- **Be specific:** Reference actual file paths, function names, and patterns — not generic placeholders.
- **Match project conventions:** Follow the same AC/task/test patterns used in existing completed specs.
- **Don't over-scope:** If the description implies multiple independent features, suggest splitting and create only the first spec.
- **Interactive only for decisions:** Use `AskUserQuestion` for epic/priority choices. Everything else (exploration, authoring) is autonomous.
