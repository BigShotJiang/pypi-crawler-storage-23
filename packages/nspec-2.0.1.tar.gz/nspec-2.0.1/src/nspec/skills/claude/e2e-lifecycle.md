---
description: Full e2e lifecycle test — scaffold project, create specs, run /loop, verify completion
argument-hint: [--pause <seconds>] [--cleanup]
---

Drive a full end-to-end lifecycle test of nspec using Playwright MCP terminal tools.

This is a spec driver doc for a future harness; it is not run automatically by nspec.

## Outline

1. Scaffold a virtual nspec project in `work/test_full_lifecycle/`
2. Launch an inner Claude Code session in tmux
3. Instruct the inner session to create 2 specs
4. Run `/loop --max-specs 2 --no-refine` in the inner session
5. Verify both specs reach `completed/done/`

## Arguments

Parse `$ARGUMENTS` for:
- `--pause <seconds>` → pause duration at checkpoints (default: `NSPEC_E2E_PAUSE_SECONDS` or 0)
- `--cleanup` → remove `work/test_full_lifecycle/` after verification
