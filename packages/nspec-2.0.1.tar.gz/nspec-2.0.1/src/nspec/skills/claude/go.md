---
description: Full spec executor — resolve, execute, verify, review, and complete a spec
argument-hint: [spec-id (optional)]
---

Execute the complete lifecycle for a single spec: resolve it, do the work, verify acceptance criteria, get a review, and archive it. Act autonomously — never ask the user what to do.

**This is the single source of truth for "how a spec gets done."** Both standalone `/go` and `/loop` (which calls `/go` for each spec) use this pipeline.

## Argument Parsing

Parse `$ARGUMENTS` for:
- A spec ID (bare `s###` or `###`) → use that spec directly
- If no argument → auto-resolve (see Resolution below)

## Phase 1: Resolve Spec

**If a spec ID was provided**, use it directly. Skip to Resume Detection.

**Otherwise, auto-resolve using this deterministic cascade:**

1. Call `session_resume` (no args) or `get_epic` to check for an active spec in `state.json`.

2. **If there is an active spec that is NOT 100% complete** → resume it. Skip to Resume Detection.

3. **If the active spec is 100% complete** → call `advance` to move it to the next status. If it reaches Ready, call `complete` to archive it. Then fall through to (4).

4. **Find the next spec:** Call `next_spec` (with epic_id if an active epic is set). If no epic is set, call `next_spec` without filtering.

5. **If a next spec is found** → call `activate` on it. Continue to Resume Detection.

6. **If no workable specs exist** → show the backlog summary from `epics` and state "No unblocked specs available. Create new specs or unblock existing ones." **EXIT**.

## Phase 2: Resume Detection

Check the IMPL status (from the `show(spec_id)` response or the status field from resolution) to determine which phases to skip. Store the result as `resume_phase`:

| IMPL Status contains | `resume_phase` | Skip |
|----------------------|----------------|------|
| "Planning" or "Proposed" | 3 | Nothing — full pipeline |
| "Active" | 4 | Skip Phase 3 (activate), Phase 3.0 (author_fr), Phase 3.5 (auto_refine) |
| "Testing" | 5 | Skip Phases 3, 3.0, 3.5, 4 |
| "Ready" | 6 | Skip Phases 3, 3.0, 3.5, 4, 5 |

Print: "Spec {id} at {status} — resuming from Phase {resume_phase}"

For Active specs, call `session_start(spec_id)` here to load the task list and identify which task to resume from.

## Phase 3: Start

**Skip this phase if `resume_phase > 3`.**

1. Call `activate` with the spec ID → sets spec to Active, writes state.json.
2. Call `session_start` with the spec ID → loads tasks and resume point.
3. Review the task list and identify pending tasks.

### Phase 3.0: Author FR (if skeleton)

**Skip this phase if `resume_phase > 3`.**

1. Call `codex_refine_fr(spec_id)` to check if the FR has placeholder content.
2. If `is_skeleton` is False → skip, continue to Phase 3.5.
3. If `is_skeleton` is True:
   a. Execute the prompt: call `execute_codex(prompt=...)`.
   b. If timeout or no response → `park(spec_id, reason="FR authoring timeout")`, **EXIT with failure**.
   c. Call `write_fr_refinement(spec_id, codex_output)` with the response `output` field.
   d. If write fails → `park(spec_id, reason="FR authoring parse failed")`, **EXIT with failure**.
   e. Continue to Phase 3.5.

### Phase 3.5: Auto-Refine IMPL (if skeleton)

**Skip this phase if `resume_phase > 3`.**

1. Call `codex_refine(spec_id)` to check if the IMPL has placeholder tasks.
2. If `is_skeleton` is False → skip, continue to Phase 4.
3. If `is_skeleton` is True:
   a. Execute the prompt: call `execute_codex(prompt=...)`.
   b. If timeout or no response → `park(spec_id, reason="Refinement timeout")`, **EXIT with failure**.
   c. Call `write_refinement(spec_id, codex_output)` with the response `output` field.
   d. If write fails → `park(spec_id, reason="Refinement parse failed")`, **EXIT with failure**.
   e. Call `session_start(spec_id)` again to reload the refined task list.
   f. Continue to Phase 4.

## Phase 4: Execute

**Skip this phase if `resume_phase > 4`.**

For each pending task in order:

1. **Do the work.** Read the task description, make code changes, write tests — whatever the task requires.
2. Call `task_complete` with the spec ID and task ID (fast — no test gate).
3. **Run `make test-quick` via Bash** so test output streams to the terminal in real time.
4. **If tests fail:**
   - Fix the issue and re-run `make test-quick` via Bash.
   - If it fails again, call `task_block` with the spec ID, task ID, and a reason describing what went wrong.
   - Call `session_save` with the spec ID and current task ID to checkpoint.
   - Call `park` with the spec ID to pause the spec.
   - **EXIT with failure.**
5. Call `session_save` with the spec ID and current task ID to checkpoint progress after each completed task.

## Phase 5: Verify

**Skip this phase if `resume_phase > 5`.**

1. **Run `make test-quick` via Bash** once before marking any criteria, to confirm the implementation is sound.
2. If tests fail, fix and retry before proceeding.
3. For each acceptance criterion listed in the FR:
   - Call `criteria_complete` with the spec ID and criterion ID (e.g., `AC-F1`).
   - If a criterion cannot be satisfied, treat it like a task failure: `task_block` the relevant task, `park` the spec, and **EXIT with failure**.

## Phase 6: Review (MANDATORY)

**No spec can be completed without an APPROVED Codex review.**

1. Call `session_save` to checkpoint before review (in case of timeout).
2. Call `codex_review(spec_id, base_branch="main")` to get the review prompt and `review_token`.
3. Call `execute_codex(prompt=<review_prompt>)` to execute the review. The response `output` field contains the review output.
4. Parse the review output for P-level findings or explicit VERDICT line.
5. **Handle the response:**

   **If timeout or no response:**
   - Call `park` with reason: "Review timeout — retry with /review {spec_id}"
   - **EXIT with failure.**

   **If verdict is APPROVED:**
   - Call `write_review_verdict` with `verdict="APPROVED"`
   - **Continue to Phase 7.**

   **If verdict is NEEDS_WORK:**
   - Call `write_review_verdict` with the verdict and feedback
   - **Attempt fix (max 2 retries):**
     1. Parse the feedback for specific issues
     2. Make the fixes (code changes, run `make format`, etc.)
     3. Run `make test-quick` to verify
     4. Call `codex_review(spec_id, base_branch="main")` to get updated prompt
     5. Call `execute_codex(prompt=<review_prompt>)` to execute the review
     6. If APPROVED → continue to Phase 7
     7. If still NEEDS_WORK after 2 retries:
        - Call `park` with reason: "Review failed after 2 retries — needs manual intervention"
        - **EXIT with failure.**

## Phase 7: Complete

1. Call `advance` with the spec ID to move through Testing → Ready.
2. Call `complete` with the spec ID to archive to completed/done.
   - **Note:** `complete()` will also verify APPROVED verdict as a safety gate.
3. Call `session_clear` to clean up session state.
4. Create exactly one git commit for this spec:
   - Ensure `git status --porcelain` shows only files related to this spec.
     If you have unrelated changes, call `park(spec_id, reason="Unrelated worktree changes prevent single-spec commit")`
     and **EXIT with failure**.
   - Stage: `git add -A`
   - Commit message MUST follow conventional commits:
     `fix|feat|docs|test|refactor|chore(<scope>): <short summary>`
     Then include the spec ID in the body, e.g.:
     `git commit -m "fix(tui): refresh table on resize" -m "Refs: S123"`
   - Verify clean: `git status --porcelain` should be empty after commit.
5. Print completion summary: spec ID, title, phases executed.
6. **EXIT with success.**

## Failure Handling

On any failure, `/go` parks the spec and exits — it does NOT loop. The caller (`/loop` or the user) decides what to do next.

| Failure Mode | Action | Exit |
|--------------|--------|------|
| FR authoring timeout/parse failure | `park(spec_id, reason)` | failure |
| IMPL refinement timeout/parse failure | `park(spec_id, reason)` | failure |
| Task failure (after retry) | `task_block` + `park(spec_id, reason)` | failure |
| Criteria unsatisfied | `task_block` + `park(spec_id, reason)` | failure |
| Review timeout | `park(spec_id, reason)` | failure |
| Review NEEDS_WORK after 2 retries | `park(spec_id, reason)` | failure |
| Unrelated worktree changes | `park(spec_id, reason)` | failure |
| No workable specs | (no park — nothing to park) | failure |

## Time Limit Protocol

When spawning subagents, calculate context-aware time limits:

```
base_minutes = {
    "review_packet": 10,
    "enhancement": 20,
    "feature": 30,
    "refactor": 25,
    "bug": 15,
}

loe_multiplier = max(1.0, loe_days * 2)
task_multiplier = 1 + (task_count / 10)
time_limit = base * loe_multiplier * task_multiplier * 1.5
time_limit = clamp(time_limit, min=10, max=120)
```

## Subagent Guardrails

Include these mandatory guardrails in every subagent prompt:

```
GUARDRAILS — MANDATORY:
1. SCOPE LOCK: Only modify files related to {SPEC_ID}.
2. SPEC ID CHECK: Before every MCP call, verify spec_id is "{SPEC_ID}".
3. NO SPEC CREATION: Do not call create_spec — that's orchestrator's job.
4. ITERATION LIMIT: Max 20 task_complete calls. If exceeded, STOP immediately.
5. TIME AWARENESS: If you've been running for >{TIME_LIMIT}m, checkpoint and STOP.

On guardrail violation or limit exceeded:
- Call session_save to checkpoint
- Report: "EXCEPTION: {SPEC_ID} — {reason}" and STOP

The caller will call exception() to set the spec to Exception state.
```

## Exception vs Paused

- **Paused:** Temporary block, retryable. Use `park()`. Can be resumed.
- **Exception:** Requires human investigation. Use `exception()`. Something went wrong that suggests the agent is stuck, hallucinating, or violating guardrails.

## Rules

- **Never ask** "what do you want to work on?" or "should I proceed?"
- **Never present options** for the user to pick from
- **Always act**: resolve → execute → verify → review → complete (or park on failure)
- All spec resolution MUST use nspec MCP tools (`session_start`, `next_spec`, `activate`, `advance`, `complete`, `get_epic`, `blocked_specs`) — never read FR/IMPL files directly to determine what to work on

## Required MCP Tools

| Tool | Phase |
|------|-------|
| `get_epic` | Resolve — check active epic |
| `session_resume` | Resolve — check for active spec |
| `next_spec` | Resolve — find highest-priority unblocked spec |
| `activate` | Resolve/Start — set spec Active |
| `show` | Resume Detection — check IMPL status |
| `session_start` | Start/Resume — load tasks and resume point |
| `codex_refine_fr` | Author FR — check skeleton and get prompt |
| `write_fr_refinement` | Author FR — write authored content to FR |
| `codex_refine` | Auto-Refine — check skeleton and get prompt |
| `write_refinement` | Auto-Refine — write refinement to IMPL |
| `task_complete` | Execute — mark task done |
| `task_block` | Execute — record failure reason |
| `park` | Any failure — pause blocked spec |
| `exception` | Guardrail violation — set Exception state |
| `session_save` | Execute/Review — checkpoint progress |
| `criteria_complete` | Verify — mark acceptance criteria met |
| `codex_review` | Review — get review prompt |
| `write_review_verdict` | Review — record verdict |
| `advance` | Complete — move spec through statuses |
| `complete` | Complete — archive to done |
| `session_clear` | Complete — clean up session state |
| `epics` | Resolve — backlog summary (no specs case) |
| `blocked_specs` | Resolve — check for blockers |

## Related commands
- `/backlog` - View dashboard (THE COMPASS)
- `/backlog:show <id>` - Show spec details
- `/loop` - Autonomous backlog loop (calls `/go` for each spec)
