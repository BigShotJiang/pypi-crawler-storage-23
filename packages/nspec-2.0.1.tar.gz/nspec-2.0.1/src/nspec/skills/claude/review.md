---
description: Request a Codex code review for a spec
argument-hint: <spec_id>
---

Request an automated code review from OpenAI Codex for the given spec. Uses nspec's built-in `execute_codex()` tool to spawn the codex CLI as a subprocess, captures the verdict, and writes it to the IMPL.

## Argument Parsing

Parse `$ARGUMENTS` for the spec ID (e.g., `S020`, `S015`). If no spec ID is provided, call `get_epic` and `show` the active spec to determine which spec to review.

## Review Flow

### Step 1: Validate spec

1. Call `show` with the spec ID to get current status.
2. If the spec is not in Active or Testing status, print a warning: "Spec {id} is in {status} — reviewing anyway." Continue regardless.
3. Check if `**Verdict:** APPROVED` already exists — if so, print "Already approved" and **EXIT**.

### Step 2: Run Codex review

1. Call `codex_review(spec_id, base_branch="main")` to generate a review prompt containing FR acceptance criteria, IMPL tasks, and git diff. **Save the `review_token` from the response** — it is required for Step 4.
2. Call `execute_codex(prompt=<review_prompt>)` with the prompt from step 1.

```
review_data = codex_review(spec_id, base_branch="main")
review_token = review_data["review_token"]
response = execute_codex(prompt=review_data["prompt"])
```

This runs a Codex review that:
- Includes the git diff against `main` (embedded in the prompt)
- Has FR acceptance criteria and IMPL task context
- Returns review content with P-level findings (P0-P3)
- Typically completes in ~30 seconds

**Alternative modes:**
- `codex_review(spec_id, uncommitted=true)` — review staged/unstaged changes
- `codex_review(spec_id, commit_sha="abc123")` — review a specific commit

### Step 3: Parse the verdict

Read the `output` field from the execute_codex response. Two verdict formats are supported:

**P-level findings (codex-cli native format):**
- Any `[P0]` or `[P1]` findings → `NEEDS_WORK`
- Only `[P2]`/`[P3]` findings or no findings → `APPROVED`

**Explicit VERDICT line (legacy fallback):**
- `VERDICT: APPROVED` — Codex approves the implementation
- `VERDICT: NEEDS_WORK` — Codex found issues, feedback follows

If no verdict can be parsed, the review is inconclusive. Print the raw output for debugging and **EXIT**.

### Step 4: Write verdict to IMPL

Call the nspec MCP tools to update the IMPL:

1. If not already in review status:
   - Call `advance(spec_id)` to move to Testing if needed
2. Call `write_review_verdict` with the parsed verdict, feedback, and the `review_token` from Step 2:
   - `verdict`: "APPROVED" or "NEEDS_WORK"
   - `feedback`: Finding text from the review
   - `reviewer`: "codex"
   - `implementer`: "claude"
   - `review_token`: the token from `codex_review()` response

Print the result:
- **APPROVED:** "Spec {id} APPROVED by Codex. Ready to complete."
- **NEEDS_WORK:** "Spec {id} NEEDS_WORK. Feedback:\n{feedback}"

### Step 5: Handle NEEDS_WORK

If the verdict is NEEDS_WORK and you're in an active work session:
1. Read the feedback from the response.
2. Make the requested changes.
3. Re-run Steps 2-4 (generate new review prompt via `codex_review()`, call `execute_codex()` again).
4. Max 2 retries. If still NEEDS_WORK after 2 retries, call `park(spec_id, reason="Failed review after 2 retries")`.

## Error Handling

- **codex CLI not found:** Print: "codex CLI not installed. Install with: npm install -g @openai/codex" and **EXIT**.
- **Timeout:** If the review takes >2 minutes, print: "Codex review timed out." and **EXIT**.
- **No verdict:** If the response doesn't contain parseable findings or VERDICT line, print the raw output for debugging. **EXIT**.
- **Empty response:** If Codex returns empty, print: "Codex produced no output." and **EXIT**.

## Example Session

```
User: /review S010

Claude: Let me review spec S010...

[Calls execute_codex(prompt=<review_prompt>)]

Codex response:
---
## Code Review: S010

[P2] Consider adding docstring to helper function
[P3] Minor style: prefer f-string over .format()

No critical issues found.
---

[Parses P-level findings: no P0/P1 → APPROVED]
[Updates IMPL-S010 with verdict]

Spec S010 APPROVED by Codex. Ready to complete.
```

## Notes

- `execute_codex()` spawns the `codex` CLI binary as a subprocess with self-managed timeout
- Reviews use `codex_review()` to generate the prompt, then `execute_codex()` to run it
- Configurable via `[codex]` section in config.toml (model, timeout, approval_policy)
