"""Claude Code skill definitions for nspec."""
