"""Entry point for nspec-loop — external loop orchestrator.

Finds and executes the nspec_loop.sh bash script bundled with the package.
"""

import os
import sys
from importlib import resources


def main() -> None:
    """Execute the nspec-loop bash script."""
    script_ref = resources.files("nspec.scripts").joinpath("nspec_loop.sh")
    with resources.as_file(script_ref) as script_path:
        os.execvp("bash", ["bash", str(script_path)] + sys.argv[1:])
