"""Configuration DAO for .novabuilt.dev/nspec/config.toml.

Single data access object that owns all reads and writes to the nspec
configuration file. Replaces scattered TOML parsing in paths.py, cli.py,
and init.py with a unified, typed interface.

Config file location: .novabuilt.dev/nspec/config.toml

Schema:
    [paths]
    feature_requests = "frs/active"
    implementation = "impls/active"
    completed = "completed"
    completed_done = "done"
    completed_superseded = "superseded"
    completed_rejected = "rejected"

    [defaults]
    epic = "001"

    [session]
    state_file = "state.json"

    [skills]
    sources = ["builtin"]

    [codex]
    model = "o4-mini"
    sandbox = "workspace-write"
    approval_policy = "on-request"
    flags = ["--full-auto"]

    [validation]
    enforce_epic_grouping = true

    [id_ranges]
    spec_min = 1
    spec_max = 899
    epic_min = 1
    epic_max = 99
    adr_min = 901
    adr_max = 999

    [emojis]
    # fr_proposed = "🟡"
    # impl_paused = "⏳"
    # priority_p0 = "🔥"
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

# Canonical config file location relative to project root
CONFIG_REL_PATH = ".novabuilt.dev/nspec/config.toml"

# Directories where upward config traversal should stop (exact match).
# Prevents traversal from escaping into system paths.
_TRAVERSAL_STOP_DIRS: frozenset[str] = frozenset(
    {
        "/tmp",
        "/private/tmp",
    }
)

# Valid values for [queue] mode
QUEUE_MODES = ("single", "multi")


@dataclass
class PathsConfig:
    """Typed representation of [paths] section."""

    feature_requests: str = "frs/active"
    implementation: str = "impls/active"
    completed: str = "completed"
    completed_done: str = "done"
    completed_superseded: str = "superseded"
    completed_rejected: str = "rejected"


@dataclass
class SessionConfig:
    """Typed representation of [session] section."""

    state_file: str = "state.json"


@dataclass
class SkillsConfig:
    """Typed representation of [skills] section."""

    sources: list[str] = field(default_factory=lambda: ["builtin"])


@dataclass
class EmojisConfig:
    """Typed representation of [emojis] section.

    All fields are optional. When set, they override the default emoji
    for the corresponding status/priority/display element.
    """

    # FR statuses
    fr_proposed: str | None = None
    fr_in_design: str | None = None
    fr_active: str | None = None
    fr_completed: str | None = None
    fr_rejected: str | None = None
    fr_superseded: str | None = None
    fr_deferred: str | None = None

    # IMPL statuses
    impl_planning: str | None = None
    impl_active: str | None = None
    impl_testing: str | None = None
    impl_ready: str | None = None
    impl_paused: str | None = None
    impl_hold: str | None = None

    # Priorities
    priority_p0: str | None = None
    priority_p1: str | None = None
    priority_p2: str | None = None
    priority_p3: str | None = None

    # Dependency display
    dep_completed: str | None = None
    dep_active: str | None = None
    dep_proposed: str | None = None
    dep_rejected: str | None = None
    dep_superseded: str | None = None
    dep_testing: str | None = None
    dep_paused: str | None = None
    dep_unknown: str | None = None

    # Epic display
    epic_proposed: str | None = None
    epic_active: str | None = None
    epic_completed: str | None = None


@dataclass
class IdRangesConfig:
    """Typed representation of [id_ranges] section.

    Controls the numeric range for auto-assigned spec and epic IDs.
    All priorities share the same range by default (sequential IDs).
    """

    spec_min: int = 1
    spec_max: int = 899
    epic_min: int = 1
    epic_max: int = 99
    adr_min: int = 901
    adr_max: int = 999


@dataclass
class TuiConfig:
    """Typed representation of [tui] section.

    Controls TUI display constants. All defaults match the previously
    hardcoded values so behavior is unchanged for users who don't customize.
    """

    # Column widths (table.py)
    col_id: int = 5
    col_priority: int = 3
    col_status: int = 3
    col_upstream: int = 6
    col_downstream: int = 6
    col_estimate: int = 5
    min_title_width: int = 25

    # Truncation limits
    detail_title_max: int = 35  # widgets.py SpecDetailPanel
    error_message_max: int = 120  # error_screen.py

    # Scroll context
    context_lines_divisor: int = 3  # detail_screen.py viewport_height // N

    # Display modes (display_modes.py)
    default_view: str = "standard"  # minimal, standard, full
    default_sort: str = "dependency"  # dependency, priority, status, id, alpha


@dataclass
class WatchdogConfig:
    """Typed representation of [watchdog] section.

    Controls the Claude Code stall detector & auto-recovery.
    """

    stall_timeout: int = 180  # seconds before declaring token stall
    mcp_stall_timeout: int = 120  # seconds before declaring MCP tool hang
    poll_interval: int = 15  # seconds between polls
    recovery_message: str = "Please continue from where you left off."


@dataclass(frozen=True)
class PipelineStep:
    """A single step in the loop pipeline.

    Each step has a type (e.g., "pick", "execute", "review") and
    optional parameters (e.g., agent name for review/auto_refine).
    """

    step: str
    params: tuple[str, ...] = ()


# Default 10-step pipeline matching the hardcoded /loop phases
DEFAULT_PIPELINE: tuple[PipelineStep, ...] = (
    PipelineStep("pick"),
    PipelineStep("start"),
    PipelineStep("author_fr", ("codex",)),
    PipelineStep("auto_refine", ("codex",)),
    PipelineStep("execute"),
    PipelineStep("verify"),
    PipelineStep("review", ("codex",)),
    PipelineStep("complete"),
    PipelineStep("refine"),
    PipelineStep("report"),
)

# Default agent map: logical name -> implementation
DEFAULT_AGENTS: dict[str, str] = {
    "claude": "self",
    "codex": "subprocess:codex",
}


@dataclass
class AgentsConfig:
    """Typed representation of [agents] section.

    Maps logical agent names to their backing implementation.
    "self" means the current session; "subprocess:codex" spawns the codex
    CLI binary; "mcp:<server>" means an external MCP server.
    """

    agents: dict[str, str] = field(default_factory=lambda: dict(DEFAULT_AGENTS))


@dataclass
class LoopConfig:
    """Typed representation of [loop] section.

    Controls the external loop orchestrator (nspec-loop).
    """

    session_timeout: str = "30m"  # timeout(1) format: 30m, 1h, etc.
    max_retries: int = 3  # Spec-level retries before Exception
    pipeline: tuple[PipelineStep, ...] = DEFAULT_PIPELINE


@dataclass
class TimeoutsConfig:
    """Typed representation of [timeouts] section.

    All values are in seconds. Defaults match the previously hardcoded values
    so behavior is unchanged for users who don't customize.
    """

    lock_acquire_s: float = 10.0
    lock_stale_s: int = 3600
    git_s: int = 30
    subprocess_s: int = 10
    mcp_s: int = 120


@dataclass
class CodexConfig:
    """Typed representation of [codex] section.

    Controls the codex CLI executor defaults.
    These are passed to the ``CodexTmuxExecutor``.
    """

    model: str = "gpt-5.3-codex"
    reasoning_effort: str = "medium"
    sandbox: str = "workspace-write"
    approval_policy: str = "on-request"
    flags: list[str] = field(default_factory=lambda: ["--full-auto"])
    timeout: int = 600
    poll_interval: float = 2.0
    session_prefix: str = "nspec-codex"


@dataclass
class LoeEstimatorConfig:
    """Typed representation of [loe] section.

    Controls the LOE estimation algorithm weights and thresholds.
    """

    weight_task_count: float = 1.0
    weight_max_depth: float = 2.0
    weight_nested_ratio: float = 1.5
    weight_dep_count: float = 1.5
    weight_complexity_signal: float = 3.0
    min_history_specs: int = 10


@dataclass
class ReviewConfig:
    """Typed representation of [review] section."""

    model: str = "o4-mini"
    reasoning_effort: str = "high"
    timeout: int = 600


@dataclass
class StrictConfig:
    """Typed representation of [strict] section.

    Controls project hygiene enforcement. Separate from [validation]
    which controls `--validate` warnings.
    """

    require_default_epic: bool = True


@dataclass
class ValidationConfig:
    """Typed representation of [validation] section."""

    enforce_epic_grouping: bool = False
    strict_completion_parity: bool = True


@dataclass
class QueueConfig:
    """Typed representation of [queue] section.

    Controls the agent assignment queue for multi-agent parallel execution.
    """

    mode: str = "single"  # "single" or "multi"
    max_agents: int = 5
    lease_ttl_seconds: int = 300  # 5 minutes

    def __post_init__(self) -> None:
        if self.mode not in QUEUE_MODES:
            raise ValueError(f"[queue] mode must be one of {QUEUE_MODES}, got: {self.mode!r}")

    @property
    def effective_max_agents(self) -> int:
        """Return max_agents capped to 1 in single mode."""
        return 1 if self.mode == "single" else self.max_agents


@dataclass
class DocsConfig:
    """Typed representation of [docs] section.

    Controls opt-in post-completion doc generation via a low-reasoning agent.
    """

    enabled: bool = False
    template: str = "changelog.md"
    target: str = "CHANGELOG.md"
    agent: str = "haiku"
    mode: str = "append"  # "append" | "replace-section"


@dataclass
class TemplatesConfig:
    """Typed representation of [templates] section.

    Controls which ceremony-level profile is used when creating new specs.
    Profiles: quick (Crystal Clear), standard (Crystal Yellow),
    full (Crystal Orange), formal (Crystal Red).
    """

    default: str = "standard"
    fr: str | None = None
    impl: str | None = None


@dataclass
class ErrorAgentTriggersConfig:
    """Typed representation of [error_agent.triggers] section."""

    exit_codes: list[int] = field(default_factory=lambda: [1, 2])
    mcp_errors: bool = True
    test_failures: bool = True
    subprocess_timeout: bool = True


@dataclass
class ErrorAgentConfig:
    """Typed representation of [error_agent] section.

    Controls automatic error-to-spec conversion during agent sessions.
    """

    enabled: bool = False
    auto_create_spec: bool = True
    auto_park_on_blocking: bool = True
    epic_id: str | None = None
    priority: str = "P3"
    max_per_session: int = 5
    triggers: ErrorAgentTriggersConfig = field(default_factory=ErrorAgentTriggersConfig)
    ignore_patterns: list[str] = field(default_factory=list)


@dataclass
class ResourcesConfig:
    """Typed representation of [resources] section.

    Maps logical handle names to file paths (relative to .novabuilt.dev/nspec/).
    """

    handles: dict[str, str] = field(default_factory=dict)


@dataclass
class LinearConfig:
    """Typed representation of [linear] section.

    Controls the repo-to-Linear sync integration. The API token is read
    from the environment variable specified by ``token_env`` (default:
    ``LINEAR_API_KEY``).

    State mapping translates nspec FR/IMPL statuses to Linear workflow
    state UUIDs. Priority mapping translates nspec priorities (P0-P3) to
    Linear priority integers (1=Urgent .. 4=Low).
    """

    token_env: str = "LINEAR_API_KEY"
    team_id: str = ""
    state_mapping: dict[str, str] = field(default_factory=dict)
    priority_mapping: dict[str, int] = field(
        default_factory=lambda: {
            "P0": 1,  # Urgent
            "P1": 2,  # High
            "P2": 3,  # Medium
            "P3": 4,  # Low
        }
    )
    label_ids: list[str] = field(default_factory=list)


@dataclass
class GitConfig:
    """Typed representation of [git] section."""

    auto_add: bool = False


@dataclass
class DefaultsConfig:
    """Typed representation of [defaults] section."""

    epic: str | None = None


@dataclass
class NspecConfig:
    """Single data access object for .novabuilt.dev/nspec/config.toml.

    Usage:
        # Load existing config
        config = NspecConfig.load(project_root)
        print(config.paths.feature_requests)
        print(config.defaults.epic)

        # Modify and persist
        config.defaults.epic = "002"
        config.save()

        # Scaffold new project
        config = NspecConfig.scaffold(project_root)
    """

    paths: PathsConfig = field(default_factory=PathsConfig)
    defaults: DefaultsConfig = field(default_factory=DefaultsConfig)
    session: SessionConfig = field(default_factory=SessionConfig)
    skills: SkillsConfig = field(default_factory=SkillsConfig)
    emojis: EmojisConfig = field(default_factory=EmojisConfig)
    strict: StrictConfig = field(default_factory=StrictConfig)
    validation: ValidationConfig = field(default_factory=ValidationConfig)
    codex: CodexConfig = field(default_factory=CodexConfig)
    review: ReviewConfig = field(default_factory=ReviewConfig)
    loe: LoeEstimatorConfig = field(default_factory=LoeEstimatorConfig)
    id_ranges: IdRangesConfig = field(default_factory=IdRangesConfig)
    tui: TuiConfig = field(default_factory=TuiConfig)
    timeouts: TimeoutsConfig = field(default_factory=TimeoutsConfig)
    loop: LoopConfig = field(default_factory=LoopConfig)
    agents: AgentsConfig = field(default_factory=AgentsConfig)
    watchdog: WatchdogConfig = field(default_factory=WatchdogConfig)
    docs: DocsConfig = field(default_factory=DocsConfig)
    queue: QueueConfig = field(default_factory=QueueConfig)
    templates: TemplatesConfig = field(default_factory=TemplatesConfig)
    git: GitConfig = field(default_factory=GitConfig)
    linear: LinearConfig = field(default_factory=LinearConfig)
    error_agent: ErrorAgentConfig = field(default_factory=ErrorAgentConfig)
    resources: ResourcesConfig = field(default_factory=ResourcesConfig)
    spec_types: dict[str, dict[str, Any]] = field(default_factory=dict)
    config_file: Path | None = field(default=None, repr=False)

    @classmethod
    def load(cls, project_root: Path | None = None) -> NspecConfig:
        """Load config from .novabuilt.dev/nspec/config.toml.

        Searches upward from project_root (or cwd) for the config file.
        Returns default config if no file is found.

        Args:
            project_root: Directory to start searching from.
                         If None, uses current working directory.

        Returns:
            NspecConfig with values from file, or defaults if not found.
        """
        if project_root is None:
            project_root = Path.cwd()

        config_file = _find_config_file(project_root)
        raw = _parse_toml(config_file) if config_file else {}

        paths_raw = raw.get("paths", {})
        defaults_raw = raw.get("defaults", {})
        session_raw = raw.get("session", {})
        skills_raw = raw.get("skills", {})
        emojis_raw = raw.get("emojis", {})
        strict_raw = raw.get("strict", {})
        validation_raw = raw.get("validation", {})
        codex_raw = raw.get("codex", {})
        review_raw = raw.get("review", {})
        loe_raw = raw.get("loe", {})
        id_ranges_raw = raw.get("id_ranges", {})
        tui_raw = raw.get("tui", {})
        spec_types_raw = raw.get("spec_types", {})
        timeouts_raw = raw.get("timeouts", {})
        loop_raw = raw.get("loop", {})
        watchdog_raw = raw.get("watchdog", {})
        docs_raw = raw.get("docs", {})
        queue_raw = raw.get("queue", {})
        templates_raw = raw.get("templates", {})
        git_raw = raw.get("git", {})
        linear_raw = raw.get("linear", {})
        error_agent_raw = raw.get("error_agent", {})
        resources_raw = raw.get("resources", {})

        paths = PathsConfig(
            feature_requests=paths_raw.get("feature_requests", PathsConfig.feature_requests),
            implementation=paths_raw.get("implementation", PathsConfig.implementation),
            completed=paths_raw.get("completed", PathsConfig.completed),
            completed_done=paths_raw.get("completed_done", PathsConfig.completed_done),
            completed_superseded=paths_raw.get(
                "completed_superseded", PathsConfig.completed_superseded
            ),
            completed_rejected=paths_raw.get("completed_rejected", PathsConfig.completed_rejected),
        )

        defaults = DefaultsConfig(
            epic=str(defaults_raw["epic"]) if "epic" in defaults_raw else None,
        )

        session = SessionConfig(
            state_file=session_raw.get("state_file", SessionConfig.state_file),
        )

        skills_sources = skills_raw.get("sources")
        skills = SkillsConfig(
            sources=skills_sources if isinstance(skills_sources, list) else ["builtin"],
        )

        # Build EmojisConfig — only set fields that are present in TOML
        emojis_kwargs = {}
        for field_name in EmojisConfig.__dataclass_fields__:
            if field_name in emojis_raw:
                emojis_kwargs[field_name] = str(emojis_raw[field_name])
        emojis = EmojisConfig(**emojis_kwargs)

        raw_require = strict_raw.get("require_default_epic", StrictConfig.require_default_epic)
        if not isinstance(raw_require, bool):
            kind = type(raw_require).__name__
            raise ValueError(
                f"[strict] require_default_epic must be a boolean, got {kind}: {raw_require!r}"
            )
        strict = StrictConfig(require_default_epic=raw_require)

        validation = ValidationConfig(
            enforce_epic_grouping=bool(
                validation_raw.get("enforce_epic_grouping", ValidationConfig.enforce_epic_grouping)
            ),
            strict_completion_parity=bool(
                validation_raw.get(
                    "strict_completion_parity", ValidationConfig.strict_completion_parity
                )
            ),
        )

        raw_codex_flags = codex_raw.get("flags", ["--full-auto"])
        if not isinstance(raw_codex_flags, list):
            kind = type(raw_codex_flags).__name__
            raise ValueError(f"[codex] flags must be a list, got {kind}: {raw_codex_flags!r}")
        if not all(isinstance(flag, str) for flag in raw_codex_flags):
            raise ValueError("[codex] flags must be a list of strings")

        codex = CodexConfig(
            model=str(codex_raw.get("model", CodexConfig.model)),
            reasoning_effort=str(codex_raw.get("reasoning_effort", CodexConfig.reasoning_effort)),
            sandbox=str(codex_raw.get("sandbox", CodexConfig.sandbox)),
            approval_policy=str(codex_raw.get("approval_policy", CodexConfig.approval_policy)),
            flags=list(raw_codex_flags),
            timeout=int(codex_raw.get("timeout", CodexConfig.timeout)),
            poll_interval=float(codex_raw.get("poll_interval", CodexConfig.poll_interval)),
            session_prefix=str(codex_raw.get("session_prefix", CodexConfig.session_prefix)),
        )

        review = ReviewConfig(
            model=str(review_raw.get("model", ReviewConfig.model)),
            reasoning_effort=str(review_raw.get("reasoning_effort", ReviewConfig.reasoning_effort)),
            timeout=int(review_raw.get("timeout", ReviewConfig.timeout)),
        )

        loe_config = LoeEstimatorConfig(
            weight_task_count=float(
                loe_raw.get("weight_task_count", LoeEstimatorConfig.weight_task_count)
            ),
            weight_max_depth=float(
                loe_raw.get("weight_max_depth", LoeEstimatorConfig.weight_max_depth)
            ),
            weight_nested_ratio=float(
                loe_raw.get("weight_nested_ratio", LoeEstimatorConfig.weight_nested_ratio)
            ),
            weight_dep_count=float(
                loe_raw.get("weight_dep_count", LoeEstimatorConfig.weight_dep_count)
            ),
            weight_complexity_signal=float(
                loe_raw.get("weight_complexity_signal", LoeEstimatorConfig.weight_complexity_signal)
            ),
            min_history_specs=int(
                loe_raw.get("min_history_specs", LoeEstimatorConfig.min_history_specs)
            ),
        )

        id_ranges = IdRangesConfig(
            spec_min=int(id_ranges_raw.get("spec_min", IdRangesConfig.spec_min)),
            spec_max=int(id_ranges_raw.get("spec_max", IdRangesConfig.spec_max)),
            epic_min=int(id_ranges_raw.get("epic_min", IdRangesConfig.epic_min)),
            epic_max=int(id_ranges_raw.get("epic_max", IdRangesConfig.epic_max)),
            adr_min=int(id_ranges_raw.get("adr_min", IdRangesConfig.adr_min)),
            adr_max=int(id_ranges_raw.get("adr_max", IdRangesConfig.adr_max)),
        )

        tui = TuiConfig(
            col_id=max(1, int(tui_raw.get("col_id", TuiConfig.col_id))),
            col_priority=max(1, int(tui_raw.get("col_priority", TuiConfig.col_priority))),
            col_status=max(1, int(tui_raw.get("col_status", TuiConfig.col_status))),
            col_upstream=max(1, int(tui_raw.get("col_upstream", TuiConfig.col_upstream))),
            col_downstream=max(1, int(tui_raw.get("col_downstream", TuiConfig.col_downstream))),
            col_estimate=max(1, int(tui_raw.get("col_estimate", TuiConfig.col_estimate))),
            min_title_width=max(1, int(tui_raw.get("min_title_width", TuiConfig.min_title_width))),
            detail_title_max=max(
                4, int(tui_raw.get("detail_title_max", TuiConfig.detail_title_max))
            ),
            error_message_max=max(
                1, int(tui_raw.get("error_message_max", TuiConfig.error_message_max))
            ),
            context_lines_divisor=max(
                1, int(tui_raw.get("context_lines_divisor", TuiConfig.context_lines_divisor))
            ),
            default_view=str(tui_raw.get("default_view", TuiConfig.default_view)),
            default_sort=str(tui_raw.get("default_sort", TuiConfig.default_sort)),
        )

        timeouts = TimeoutsConfig(
            lock_acquire_s=float(timeouts_raw.get("lock_acquire_s", TimeoutsConfig.lock_acquire_s)),
            lock_stale_s=int(timeouts_raw.get("lock_stale_s", TimeoutsConfig.lock_stale_s)),
            git_s=int(timeouts_raw.get("git_s", TimeoutsConfig.git_s)),
            subprocess_s=int(timeouts_raw.get("subprocess_s", TimeoutsConfig.subprocess_s)),
            mcp_s=int(timeouts_raw.get("mcp_s", TimeoutsConfig.mcp_s)),
        )

        # Parse pipeline from [loop] section
        pipeline_raw = loop_raw.get("pipeline")
        if pipeline_raw is not None:
            pipeline_steps: list[PipelineStep] = []
            for i, entry in enumerate(pipeline_raw):
                if not isinstance(entry, list | tuple) or len(entry) == 0:
                    raise ValueError(
                        f"[loop] pipeline[{i}]: each entry must be a non-empty list, "
                        f"got {type(entry).__name__}: {entry!r}"
                    )
                pipeline_steps.append(
                    PipelineStep(step=str(entry[0]), params=tuple(str(p) for p in entry[1:]))
                )
            pipeline = tuple(pipeline_steps)
        else:
            pipeline = DEFAULT_PIPELINE

        loop = LoopConfig(
            session_timeout=str(loop_raw.get("session_timeout", LoopConfig.session_timeout)),
            max_retries=int(loop_raw.get("max_retries", LoopConfig.max_retries)),
            pipeline=pipeline,
        )

        # Parse [agents] section
        agents_raw = raw.get("agents", {})
        agents = AgentsConfig(
            agents={str(k): str(v) for k, v in agents_raw.items()}
            if agents_raw
            else dict(DEFAULT_AGENTS),
        )

        watchdog = WatchdogConfig(
            stall_timeout=int(watchdog_raw.get("stall_timeout", WatchdogConfig.stall_timeout)),
            mcp_stall_timeout=int(
                watchdog_raw.get("mcp_stall_timeout", WatchdogConfig.mcp_stall_timeout)
            ),
            poll_interval=int(watchdog_raw.get("poll_interval", WatchdogConfig.poll_interval)),
            recovery_message=str(
                watchdog_raw.get("recovery_message", WatchdogConfig.recovery_message)
            ),
        )

        docs = DocsConfig(
            enabled=bool(docs_raw.get("enabled", DocsConfig.enabled)),
            template=str(docs_raw.get("template", DocsConfig.template)),
            target=str(docs_raw.get("target", DocsConfig.target)),
            agent=str(docs_raw.get("agent", DocsConfig.agent)),
            mode=str(docs_raw.get("mode", DocsConfig.mode)),
        )

        queue = QueueConfig(
            mode=str(queue_raw.get("mode", QueueConfig.mode)),
            max_agents=int(queue_raw.get("max_agents", QueueConfig.max_agents)),
            lease_ttl_seconds=int(
                queue_raw.get("lease_ttl_seconds", QueueConfig.lease_ttl_seconds)
            ),
        )

        templates_fr = templates_raw.get("fr")
        templates_impl = templates_raw.get("impl")
        templates = TemplatesConfig(
            default=str(templates_raw.get("default", TemplatesConfig.default)),
            fr=str(templates_fr) if templates_fr is not None else None,
            impl=str(templates_impl) if templates_impl is not None else None,
        )

        git = GitConfig(
            auto_add=bool(git_raw.get("auto_add", GitConfig.auto_add)),
        )

        # Parse [linear] section
        linear_state_raw = linear_raw.get("state_mapping", {})
        linear_priority_raw = linear_raw.get("priority_mapping", {})
        linear_label_ids = linear_raw.get("label_ids", [])
        if not isinstance(linear_label_ids, list):
            linear_label_ids = []
        linear = LinearConfig(
            token_env=str(linear_raw.get("token_env", LinearConfig.token_env)),
            team_id=str(linear_raw.get("team_id", LinearConfig.team_id)),
            state_mapping={str(k): str(v) for k, v in linear_state_raw.items()},
            priority_mapping={str(k): int(v) for k, v in linear_priority_raw.items()}
            if linear_priority_raw
            else {"P0": 1, "P1": 2, "P2": 3, "P3": 4},
            label_ids=[str(lid) for lid in linear_label_ids],
        )

        # Parse [error_agent] section
        ea_triggers_raw = error_agent_raw.get("triggers", {})
        ea_ignore_raw = error_agent_raw.get("ignore", {})
        ea_triggers = ErrorAgentTriggersConfig(
            exit_codes=ea_triggers_raw.get("exit_codes", [1, 2]),
            mcp_errors=bool(ea_triggers_raw.get("mcp_errors", ErrorAgentTriggersConfig.mcp_errors)),
            test_failures=bool(
                ea_triggers_raw.get("test_failures", ErrorAgentTriggersConfig.test_failures)
            ),
            subprocess_timeout=bool(
                ea_triggers_raw.get(
                    "subprocess_timeout", ErrorAgentTriggersConfig.subprocess_timeout
                )
            ),
        )
        ea_epic = error_agent_raw.get("epic_id")
        error_agent = ErrorAgentConfig(
            enabled=bool(error_agent_raw.get("enabled", ErrorAgentConfig.enabled)),
            auto_create_spec=bool(
                error_agent_raw.get("auto_create_spec", ErrorAgentConfig.auto_create_spec)
            ),
            auto_park_on_blocking=bool(
                error_agent_raw.get("auto_park_on_blocking", ErrorAgentConfig.auto_park_on_blocking)
            ),
            epic_id=str(ea_epic) if ea_epic is not None else None,
            priority=str(error_agent_raw.get("priority", ErrorAgentConfig.priority)),
            max_per_session=int(
                error_agent_raw.get("max_per_session", ErrorAgentConfig.max_per_session)
            ),
            triggers=ea_triggers,
            ignore_patterns=ea_ignore_raw.get("patterns", []),
        )

        return cls(
            paths=paths,
            defaults=defaults,
            session=session,
            skills=skills,
            emojis=emojis,
            strict=strict,
            validation=validation,
            codex=codex,
            review=review,
            loe=loe_config,
            id_ranges=id_ranges,
            tui=tui,
            timeouts=timeouts,
            loop=loop,
            agents=agents,
            watchdog=watchdog,
            docs=docs,
            queue=queue,
            templates=templates,
            git=git,
            linear=linear,
            error_agent=error_agent,
            resources=ResourcesConfig(handles=dict(resources_raw)),
            spec_types=dict(spec_types_raw),
            config_file=config_file,
        )

    def get(self, section: str, key: str, default: Any = None) -> Any:
        """Read an arbitrary value by section and key.

        Convenience method for callers that need ad-hoc access without
        knowing the typed fields. Prefer direct attribute access when possible.

        Returns the default if the section/key doesn't exist or if the
        value is None.

        Args:
            section: TOML section name (e.g., "defaults", "paths")
            key: Key within the section
            default: Fallback if not found or None

        Returns:
            The value, or default if not found or None.
        """
        section_obj = getattr(self, section, None)
        if section_obj is None:
            return default
        value = getattr(section_obj, key, None)
        if value is None:
            return default
        return value

    def save(self) -> None:
        """Persist current config state to disk.

        Writes to self.config_file. Raises ValueError if no config_file is set.
        """
        if self.config_file is None:
            raise ValueError("Cannot save: no config_file path set")

        content = self._to_toml()
        self.config_file.parent.mkdir(parents=True, exist_ok=True)
        self.config_file.write_text(content)

    @classmethod
    def scaffold(cls, project_root: Path, *, force: bool = False) -> NspecConfig:
        """Create default config.toml for a new project.

        Args:
            project_root: Project root directory.
            force: If True, overwrite existing file.

        Returns:
            NspecConfig with default values, saved to disk.

        Raises:
            FileExistsError: If config file exists and force is False.
        """
        config_file = project_root / CONFIG_REL_PATH
        if config_file.exists() and not force:
            raise FileExistsError(f"File already exists: {config_file} (use --force to overwrite)")

        config = cls(
            paths=PathsConfig(),
            defaults=DefaultsConfig(),
            config_file=config_file,
        )
        config.save()
        return config

    def _to_toml(self) -> str:
        """Serialize config to TOML string."""
        lines = [
            "# nspec configuration",
            f"# Location: {CONFIG_REL_PATH}",
            "# See: https://github.com/Novabuiltdevv/nspec",
            "",
            "[paths]",
        ]

        # Always write path values (even defaults) so users see the active config
        for field_name in (
            "feature_requests",
            "implementation",
            "completed",
            "completed_done",
            "completed_superseded",
            "completed_rejected",
        ):
            value = getattr(self.paths, field_name)
            lines.append(f'{field_name} = "{value}"')

        lines.extend(["", "[defaults]"])

        # Only write epic when actually set — None means "unset" for strict mode
        if self.defaults.epic is not None:
            lines.append(f'epic = "{self.defaults.epic}"')

        lines.extend(["", "[session]"])
        lines.append(f'state_file = "{self.session.state_file}"')

        lines.extend(["", "[skills]"])
        sources_str = ", ".join(f'"{s}"' for s in self.skills.sources)
        lines.append(f"sources = [{sources_str}]")

        lines.extend(["", "[strict]"])
        lines.append(f"require_default_epic = {str(self.strict.require_default_epic).lower()}")

        lines.extend(["", "[validation]"])
        lines.append(
            f"enforce_epic_grouping = {str(self.validation.enforce_epic_grouping).lower()}"
        )
        lines.append(
            f"strict_completion_parity = {str(self.validation.strict_completion_parity).lower()}"
        )

        lines.extend(["", "[git]"])
        lines.append(f"auto_add = {str(self.git.auto_add).lower()}")

        lines.extend(["", "[emojis]"])
        lines.append("# Override any status/priority/display emoji below.")
        lines.append("# Missing keys use built-in defaults.")

        # Import defaults for commented-out reference
        from nspec.statuses import (
            _DEFAULT_DEP_EMOJIS,
            _DEFAULT_EPIC_EMOJIS,
            _DEFAULT_FR_EMOJIS,
            _DEFAULT_FR_TEXTS,
            _DEFAULT_IMPL_EMOJIS,
            _DEFAULT_IMPL_TEXTS,
            _DEFAULT_PRIORITY_EMOJIS,
        )

        # FR statuses
        _FR_KEY_MAP = {
            0: "fr_proposed",
            1: "fr_in_design",
            2: "fr_active",
            3: "fr_completed",
            4: "fr_rejected",
            5: "fr_superseded",
            6: "fr_deferred",
        }
        for code, key in _FR_KEY_MAP.items():
            value = getattr(self.emojis, key, None)
            default = _DEFAULT_FR_EMOJIS[code]
            label = _DEFAULT_FR_TEXTS[code]
            if value is not None:
                lines.append(f'{key} = "{value}"  # {label}')
            else:
                lines.append(f'# {key} = "{default}"  # {label}')

        # IMPL statuses
        _IMPL_KEY_MAP = {
            0: "impl_planning",
            1: "impl_active",
            2: "impl_testing",
            3: "impl_ready",
            4: "impl_paused",
            5: "impl_hold",
        }
        for code, key in _IMPL_KEY_MAP.items():
            value = getattr(self.emojis, key, None)
            default = _DEFAULT_IMPL_EMOJIS[code]
            label = _DEFAULT_IMPL_TEXTS[code]
            if value is not None:
                lines.append(f'{key} = "{value}"  # {label}')
            else:
                lines.append(f'# {key} = "{default}"  # {label}')

        # Priorities
        for pcode in ("P0", "P1", "P2", "P3"):
            key = f"priority_{pcode.lower()}"
            value = getattr(self.emojis, key, None)
            default = _DEFAULT_PRIORITY_EMOJIS[pcode]
            if value is not None:
                lines.append(f'{key} = "{value}"  # {pcode}')
            else:
                lines.append(f'# {key} = "{default}"  # {pcode}')

        # Dependency display
        _DEP_KEY_MAP = {
            "COMPLETED": "dep_completed",
            "ACTIVE": "dep_active",
            "PROPOSED": "dep_proposed",
            "REJECTED": "dep_rejected",
            "SUPERSEDED": "dep_superseded",
            "TESTING": "dep_testing",
            "PAUSED": "dep_paused",
            "UNKNOWN": "dep_unknown",
        }
        for attr, key in _DEP_KEY_MAP.items():
            value = getattr(self.emojis, key, None)
            default = _DEFAULT_DEP_EMOJIS[attr]
            if value is not None:
                lines.append(f'{key} = "{value}"  # dep {attr.lower()}')
            else:
                lines.append(f'# {key} = "{default}"  # dep {attr.lower()}')

        # Epic display
        _EPIC_KEY_MAP = {
            "PROPOSED": "epic_proposed",
            "ACTIVE": "epic_active",
            "COMPLETED": "epic_completed",
        }
        for attr, key in _EPIC_KEY_MAP.items():
            value = getattr(self.emojis, key, None)
            default = _DEFAULT_EPIC_EMOJIS[attr]
            if value is not None:
                lines.append(f'{key} = "{value}"  # epic {attr.lower()}')
            else:
                lines.append(f'# {key} = "{default}"  # epic {attr.lower()}')

        # TUI display constants
        lines.extend(["", "[tui]"])
        lines.append(f"col_id = {self.tui.col_id}")
        lines.append(f"col_priority = {self.tui.col_priority}")
        lines.append(f"col_status = {self.tui.col_status}")
        lines.append(f"col_upstream = {self.tui.col_upstream}")
        lines.append(f"col_downstream = {self.tui.col_downstream}")
        lines.append(f"col_estimate = {self.tui.col_estimate}")
        lines.append(f"min_title_width = {self.tui.min_title_width}")
        lines.append(f"detail_title_max = {self.tui.detail_title_max}")
        lines.append(f"error_message_max = {self.tui.error_message_max}")
        lines.append(f"context_lines_divisor = {self.tui.context_lines_divisor}")
        lines.append(f'default_view = "{self.tui.default_view}"')
        lines.append(f'default_sort = "{self.tui.default_sort}"')

        # Timeouts
        lines.extend(["", "[timeouts]"])
        lines.append(f"lock_acquire_s = {self.timeouts.lock_acquire_s}")
        lines.append(f"lock_stale_s = {self.timeouts.lock_stale_s}")
        lines.append(f"git_s = {self.timeouts.git_s}")
        lines.append(f"subprocess_s = {self.timeouts.subprocess_s}")
        lines.append(f"mcp_s = {self.timeouts.mcp_s}")

        # ID ranges
        lines.extend(["", "[id_ranges]"])
        lines.append(f"spec_min = {self.id_ranges.spec_min}")
        lines.append(f"spec_max = {self.id_ranges.spec_max}")
        lines.append(f"epic_min = {self.id_ranges.epic_min}")
        lines.append(f"epic_max = {self.id_ranges.epic_max}")
        lines.append(f"adr_min = {self.id_ranges.adr_min}")
        lines.append(f"adr_max = {self.id_ranges.adr_max}")

        # Agents
        lines.extend(["", "[agents]"])
        for name, impl in sorted(self.agents.agents.items()):
            lines.append(f'{name} = "{impl}"')

        # Codex (subprocess executor defaults)
        lines.extend(["", "[codex]"])
        lines.append(f'model = "{self.codex.model}"')
        lines.append(f'reasoning_effort = "{self.codex.reasoning_effort}"')
        lines.append(f'sandbox = "{self.codex.sandbox}"')
        lines.append(f'approval_policy = "{self.codex.approval_policy}"')
        codex_flags = ", ".join(f'"{flag}"' for flag in self.codex.flags)
        lines.append(f"flags = [{codex_flags}]")
        lines.append(f"timeout = {self.codex.timeout}")
        lines.append(f"poll_interval = {self.codex.poll_interval}")
        lines.append(f'session_prefix = "{self.codex.session_prefix}"')

        # LOE estimator
        lines.extend(["", "[loe]"])
        lines.append(f"weight_task_count = {self.loe.weight_task_count}")
        lines.append(f"weight_max_depth = {self.loe.weight_max_depth}")
        lines.append(f"weight_nested_ratio = {self.loe.weight_nested_ratio}")
        lines.append(f"weight_dep_count = {self.loe.weight_dep_count}")
        lines.append(f"weight_complexity_signal = {self.loe.weight_complexity_signal}")
        lines.append(f"min_history_specs = {self.loe.min_history_specs}")

        # Loop
        lines.extend(["", "[loop]"])
        lines.append(f'session_timeout = "{self.loop.session_timeout}"')
        lines.append(f"max_retries = {self.loop.max_retries}")

        # Pipeline
        lines.append("pipeline = [")
        for step in self.loop.pipeline:
            parts = [f'"{step.step}"'] + [f'"{p}"' for p in step.params]
            lines.append(f"    [{', '.join(parts)}],")
        lines.append("]")

        # Watchdog
        lines.extend(["", "[watchdog]"])
        lines.append(f"stall_timeout = {self.watchdog.stall_timeout}")
        lines.append(f"mcp_stall_timeout = {self.watchdog.mcp_stall_timeout}")
        lines.append(f"poll_interval = {self.watchdog.poll_interval}")
        lines.append(f'recovery_message = "{self.watchdog.recovery_message}"')

        # Docs (post-completion doc generation)
        lines.extend(["", "[docs]"])
        lines.append(f"enabled = {str(self.docs.enabled).lower()}")
        lines.append(f'template = "{self.docs.template}"')
        lines.append(f'target = "{self.docs.target}"')
        lines.append(f'agent = "{self.docs.agent}"')
        lines.append(f'mode = "{self.docs.mode}"')

        # Queue (multi-agent parallel execution)
        lines.extend(["", "[queue]"])
        lines.append(f'mode = "{self.queue.mode}"')
        lines.append(f"max_agents = {self.queue.max_agents}")
        lines.append(f"lease_ttl_seconds = {self.queue.lease_ttl_seconds}")

        # Templates (ceremony-level profiles)
        lines.extend(["", "[templates]"])
        lines.append(f'default = "{self.templates.default}"')
        if self.templates.fr is not None:
            lines.append(f'fr = "{self.templates.fr}"')
        if self.templates.impl is not None:
            lines.append(f'impl = "{self.templates.impl}"')

        # Linear integration
        if self.linear.team_id:
            lines.extend(["", "[linear]"])
            lines.append(f'token_env = "{self.linear.token_env}"')
            lines.append(f'team_id = "{self.linear.team_id}"')
            if self.linear.label_ids:
                lid_str = ", ".join(f'"{lid}"' for lid in self.linear.label_ids)
                lines.append(f"label_ids = [{lid_str}]")

            if self.linear.state_mapping:
                lines.extend(["", "[linear.state_mapping]"])
                for status, state_id in sorted(self.linear.state_mapping.items()):
                    lines.append(f'"{status}" = "{state_id}"')

            if self.linear.priority_mapping:
                lines.extend(["", "[linear.priority_mapping]"])
                for prio, val in sorted(self.linear.priority_mapping.items()):
                    lines.append(f"{prio} = {val}")

        # Error agent
        lines.extend(["", "[error_agent]"])
        lines.append(f"enabled = {str(self.error_agent.enabled).lower()}")
        lines.append(f"auto_create_spec = {str(self.error_agent.auto_create_spec).lower()}")
        lines.append(
            f"auto_park_on_blocking = {str(self.error_agent.auto_park_on_blocking).lower()}"
        )
        if self.error_agent.epic_id is not None:
            lines.append(f'epic_id = "{self.error_agent.epic_id}"')
        lines.append(f'priority = "{self.error_agent.priority}"')
        lines.append(f"max_per_session = {self.error_agent.max_per_session}")

        lines.extend(["", "[error_agent.triggers]"])
        ec_str = ", ".join(str(c) for c in self.error_agent.triggers.exit_codes)
        lines.append(f"exit_codes = [{ec_str}]")
        lines.append(f"mcp_errors = {str(self.error_agent.triggers.mcp_errors).lower()}")
        lines.append(f"test_failures = {str(self.error_agent.triggers.test_failures).lower()}")
        lines.append(
            f"subprocess_timeout = {str(self.error_agent.triggers.subprocess_timeout).lower()}"
        )

        lines.extend(["", "[error_agent.ignore]"])
        pat_str = ", ".join(f'"{p}"' for p in self.error_agent.ignore_patterns)
        lines.append(f"patterns = [{pat_str}]")

        # Resources (handle overrides)
        if self.resources.handles:
            lines.extend(["", "[resources]"])
            for handle, path in sorted(self.resources.handles.items()):
                lines.append(f'{handle} = "{path}"')

        lines.append("")  # trailing newline
        return "\n".join(lines)


def _find_config_file(start_dir: Path) -> Path | None:
    """Search upward from start_dir for .novabuilt.dev/nspec/config.toml.

    Stops at git root, filesystem root, traversal stop dirs, or after 10 levels.

    Args:
        start_dir: Directory to start searching from.

    Returns:
        Path to config file if found, None otherwise.
    """
    import tempfile

    search_dir = start_dir.resolve()
    sys_tmp = str(Path(tempfile.gettempdir()).resolve())

    for _ in range(10):
        config_file = search_dir / CONFIG_REL_PATH
        if config_file.exists():
            return config_file

        if (search_dir / ".git").exists():
            break

        parent = search_dir.parent
        if parent == search_dir:
            break
        parent_str = str(parent)
        if parent_str in _TRAVERSAL_STOP_DIRS or parent_str == sys_tmp:
            break
        search_dir = parent

    return None


def _parse_toml(config_file: Path) -> dict[str, Any]:
    """Parse a TOML file into a dict.

    Args:
        config_file: Path to the TOML file.

    Returns:
        Parsed dict, or empty dict on error.
    """
    try:
        import tomllib
    except ImportError:
        try:
            import tomli as tomllib  # type: ignore[no-redefine]
        except ImportError:
            return {}

    try:
        with open(config_file, "rb") as f:
            return tomllib.load(f)
    except Exception:
        return {}
