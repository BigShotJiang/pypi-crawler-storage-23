"""Shared tmux primitives for nspec process management.

Thin typed wrappers around tmux CLI commands used by both the
``CodexTmuxExecutor`` and the ``Watchdog`` stall detector.

All functions raise ``TmuxNotFoundError`` when the tmux binary is
absent and ``TmuxError`` for non-zero exit codes.
"""

from __future__ import annotations

import contextlib
import shutil
import subprocess


class TmuxError(RuntimeError):
    """A tmux command failed (non-zero exit code)."""


class TmuxNotFoundError(TmuxError):
    """tmux binary is not installed or not on PATH."""


def is_available() -> bool:
    """Return True if the tmux binary is on PATH."""
    return shutil.which("tmux") is not None


def has_session(name: str) -> bool:
    """Check whether a tmux session exists.

    Returns False (rather than raising) when the session is absent,
    since "not found" is a normal poll-loop exit condition.
    """
    try:
        result = subprocess.run(
            ["tmux", "has-session", "-t", name],
            capture_output=True,
            text=True,
            timeout=5,
        )
        return result.returncode == 0
    except FileNotFoundError:
        raise TmuxNotFoundError("tmux not found") from None
    except subprocess.TimeoutExpired:
        return False


def new_session(
    name: str,
    command: str,
    *,
    cwd: str | None = None,
    remain_on_exit: bool = False,
) -> None:
    """Create a new detached tmux session running *command*.

    Args:
        name: Session name (must be unique).
        command: Shell command string to run inside the session.
        cwd: Working directory for the session (optional).
        remain_on_exit: If True, keep the pane alive after the process
            exits. This allows a final ``capture_pane`` to grab output
            that was written just before exit.
    """
    cmd = ["tmux", "new-session", "-d", "-s", name, "-x", "220", "-y", "60", command]
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=10,
            cwd=cwd,
        )
    except FileNotFoundError:
        raise TmuxNotFoundError("tmux not found") from None

    if result.returncode != 0:
        raise TmuxError(f"tmux new-session failed: {result.stderr.strip()}")

    if remain_on_exit:
        with contextlib.suppress(FileNotFoundError, subprocess.TimeoutExpired, OSError):
            subprocess.run(
                ["tmux", "set-option", "-t", name, "remain-on-exit", "on"],
                capture_output=True,
                timeout=5,
            )


def is_pane_dead(session: str) -> bool:
    """Check whether the process in a tmux pane has exited.

    Requires ``remain-on-exit on`` to be meaningful — otherwise the
    session disappears when the process exits.

    Returns True when the pane's process has exited (pane is "dead").
    Returns False when the process is still running, or on any error.
    """
    try:
        result = subprocess.run(
            ["tmux", "display-message", "-p", "-t", session, "#{pane_dead}"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        return result.returncode == 0 and result.stdout.strip() == "1"
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False


def capture_pane(session: str, *, history: bool = False) -> str:
    """Capture the visible content of a tmux pane.

    Args:
        session: tmux session name.
        history: If True, capture the full scrollback buffer.

    Returns:
        Pane content as string.
    """
    cmd = ["tmux", "capture-pane", "-p", "-t", session]
    if history:
        cmd.insert(3, "-S-")  # -S- captures from start of history
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=5,
        )
    except FileNotFoundError:
        raise TmuxNotFoundError("tmux not found") from None

    if result.returncode != 0:
        raise TmuxError(f"tmux capture-pane failed: {result.stderr.strip()}")

    return result.stdout


def send_keys(session: str, *keys: str) -> None:
    """Send one or more keystrokes to a tmux session.

    Args:
        session: tmux session name.
        *keys: Keys to send (e.g. ``"Escape"``, ``"Enter"``).
    """
    cmd = ["tmux", "send-keys", "-t", session, *keys]
    try:
        subprocess.run(cmd, capture_output=True, timeout=5)
    except FileNotFoundError:
        raise TmuxNotFoundError("tmux not found") from None
    except subprocess.TimeoutExpired:
        pass  # best-effort


def kill_session(session: str) -> None:
    """Kill a tmux session, swallowing errors.

    This is a cleanup helper — it should never raise, since the
    session may already be gone.
    """
    with contextlib.suppress(FileNotFoundError, subprocess.TimeoutExpired, OSError):
        subprocess.run(
            ["tmux", "kill-session", "-t", session],
            capture_output=True,
            timeout=5,
        )


def list_sessions() -> list[str]:
    """Return a list of active tmux session names."""
    try:
        result = subprocess.run(
            ["tmux", "list-sessions", "-F", "#{session_name}"],
            capture_output=True,
            text=True,
            timeout=5,
        )
    except FileNotFoundError:
        raise TmuxNotFoundError("tmux not found") from None

    if result.returncode != 0:
        raise TmuxError(f"tmux list-sessions failed: {result.stderr.strip()}")

    return [s.strip() for s in result.stdout.strip().splitlines() if s.strip()]
