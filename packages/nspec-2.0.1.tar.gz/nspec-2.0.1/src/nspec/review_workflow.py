from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

from nspec.crud import check_acceptance_criteria, check_impl_task, complete_spec, set_status
from nspec.ids import normalize_spec_ref
from nspec.review_archiver import archive_one

_REVIEW_PACKET_TITLE_RE = re.compile(r"^#\s+FR-(S\d{3}):\s+Review Packet:", re.MULTILINE)
_DEPS_RE = re.compile(r"^deps:\s*\[(.*?)\]\s*$", re.MULTILINE)


@dataclass(frozen=True)
class ReviewFinalizeResult:
    review_spec_id: str
    target_spec_id: str
    archived_path: Path
    completed_fr_path: Path
    completed_impl_path: Path


def _is_review_packet_fr(fr_content: str, fr_path: Path) -> bool:
    if _REVIEW_PACKET_TITLE_RE.search(fr_content):
        return True
    return "review-packet" in fr_path.name


def _parse_single_target_dep(fr_content: str) -> str:
    m = _DEPS_RE.search(fr_content)
    if not m:
        raise ValueError("Missing deps: [...] line in FR")
    raw = m.group(1).strip()
    if not raw:
        raise ValueError("Review packet spec must have exactly one target dep, found empty deps")
    deps = [normalize_spec_ref(d.strip()) for d in raw.split(",") if d.strip()]
    if len(deps) != 1:
        raise ValueError(f"Review packet spec must have exactly one target dep, found: {deps}")
    target = deps[0]
    if not target.startswith("S"):
        raise ValueError(f"Review packet target dep must be a spec (S###), got: {target}")
    return target


def _line_matches_task_id(line: str, task_id: str) -> bool:
    bold_pattern = f"**{task_id}**:"
    plain_pattern_dot = f"] {task_id}. "
    plain_pattern_colon = f"] {task_id}: "
    plain_pattern_space = f"] {task_id} "
    return (
        bold_pattern in line
        or plain_pattern_dot in line
        or plain_pattern_colon in line
        or plain_pattern_space in line
    )


def _impl_task_marker(impl_content: str, task_id: str) -> str | None:
    for line in impl_content.splitlines():
        stripped = line.strip()
        if not stripped.startswith("- ["):
            continue
        if not _line_matches_task_id(stripped, task_id):
            continue
        # "- [x]" marker at index 3 (space means unchecked)
        if len(stripped) >= 4:
            return stripped[3]
    return None


def _fr_criteria_marker(fr_content: str, criteria_id: str) -> str | None:
    # Expect "- [ ] AC-..." or "- [x] AC-..."
    pattern = rf"^- \[(.)\].*{re.escape(criteria_id)}:"
    m = re.search(pattern, fr_content, re.MULTILINE)
    return m.group(1) if m else None


def _ensure_task_marker(*, spec_id: str, docs_root: Path, task_id: str, marker: str) -> None:
    impl_candidates = list((docs_root / "impls" / "active").glob(f"IMPL-{spec_id}-*.md"))
    if not impl_candidates:
        raise FileNotFoundError(f"IMPL-{spec_id}-*.md not found under {docs_root}/impls/active")
    impl_content = impl_candidates[0].read_text()
    current = _impl_task_marker(impl_content, task_id)
    if current and current != " ":
        return
    check_impl_task(spec_id=spec_id, task_id=task_id, docs_root=docs_root, marker=marker)


def _ensure_criteria_marker(
    *, spec_id: str, docs_root: Path, criteria_id: str, marker: str
) -> None:
    fr_candidates = list((docs_root / "frs" / "active").glob(f"FR-{spec_id}-*.md"))
    if not fr_candidates:
        raise FileNotFoundError(f"FR-{spec_id}-*.md not found under {docs_root}/frs/active")
    fr_content = fr_candidates[0].read_text()
    current = _fr_criteria_marker(fr_content, criteria_id)
    if current and current != " ":
        return
    check_acceptance_criteria(
        spec_id=spec_id, criteria_id=criteria_id, docs_root=docs_root, marker=marker
    )


def finalize_review_packet_spec(
    *,
    review_spec_id: str,
    docs_root: Path,
    archive_date: str | None = None,
) -> ReviewFinalizeResult:
    """Finalize a review-packet spec end-to-end (archive + checkboxes + complete)."""
    review_spec_id = normalize_spec_ref(review_spec_id)
    project_root = docs_root.parent

    fr_candidates = list((docs_root / "frs" / "active").glob(f"FR-{review_spec_id}-*.md"))
    impl_candidates = list((docs_root / "impls" / "active").glob(f"IMPL-{review_spec_id}-*.md"))
    if not fr_candidates:
        raise FileNotFoundError(f"FR-{review_spec_id}-*.md not found under {docs_root}/frs/active")
    if not impl_candidates:
        raise FileNotFoundError(
            f"IMPL-{review_spec_id}-*.md not found under {docs_root}/impls/active"
        )

    fr_path = fr_candidates[0]
    fr_content = fr_path.read_text()
    if not _is_review_packet_fr(fr_content, fr_path):
        raise ValueError(f"{review_spec_id} does not look like a review-packet spec")

    target_spec_id = _parse_single_target_dep(fr_content)

    evidence_root = project_root / "work" / "review" / target_spec_id
    required = {
        "REVIEW.md": evidence_root / "REVIEW.md",
        "test-quick.txt": evidence_root / "test-quick.txt",
        "check.txt": evidence_root / "check.txt",
        "validate.txt": evidence_root / "validate.txt",
    }
    missing = [name for name, p in required.items() if not p.exists()]
    if missing:
        raise FileNotFoundError(
            f"Missing required review evidence for {target_spec_id}: {', '.join(missing)} "
            f"(expected under {evidence_root})"
        )

    archived_path, _index_path, _dest_dir = archive_one(
        project_root=project_root,
        docs_root=docs_root,
        target_spec_id=target_spec_id,
        archive_date=archive_date,
    )

    # Mark IMPL tasks based on the standard template (idempotent).
    _ensure_task_marker(spec_id=review_spec_id, docs_root=docs_root, task_id="1", marker="x")
    # Work around sequential-order + subtask gating by marking the parent as obsolete.
    _ensure_task_marker(spec_id=review_spec_id, docs_root=docs_root, task_id="2", marker="~")
    _ensure_task_marker(spec_id=review_spec_id, docs_root=docs_root, task_id="2.1", marker="x")
    _ensure_task_marker(spec_id=review_spec_id, docs_root=docs_root, task_id="2.2", marker="x")
    _ensure_task_marker(spec_id=review_spec_id, docs_root=docs_root, task_id="2.3", marker="x")
    _ensure_task_marker(spec_id=review_spec_id, docs_root=docs_root, task_id="3", marker="~")
    _ensure_task_marker(spec_id=review_spec_id, docs_root=docs_root, task_id="4", marker="~")
    _ensure_task_marker(spec_id=review_spec_id, docs_root=docs_root, task_id="5", marker="x")

    # Mark FR acceptance criteria (standard review packet template).
    _ensure_criteria_marker(
        spec_id=review_spec_id, docs_root=docs_root, criteria_id="AC-F1", marker="x"
    )
    _ensure_criteria_marker(
        spec_id=review_spec_id, docs_root=docs_root, criteria_id="AC-F2", marker="x"
    )
    _ensure_criteria_marker(
        spec_id=review_spec_id, docs_root=docs_root, criteria_id="AC-F3", marker="x"
    )
    _ensure_criteria_marker(
        spec_id=review_spec_id, docs_root=docs_root, criteria_id="AC-Q1", marker="x"
    )

    # Force statuses to terminal states for completion.
    set_status(spec_id=review_spec_id, fr_status=3, impl_status=3, docs_root=docs_root, force=True)

    _fr_old, fr_new, _impl_old, impl_new = complete_spec(review_spec_id, docs_root)

    return ReviewFinalizeResult(
        review_spec_id=review_spec_id,
        target_spec_id=target_spec_id,
        archived_path=archived_path,
        completed_fr_path=fr_new,
        completed_impl_path=impl_new,
    )
