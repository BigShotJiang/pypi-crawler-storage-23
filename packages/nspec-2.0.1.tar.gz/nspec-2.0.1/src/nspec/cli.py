"""Command-line interface for nspec management.

This module provides the CLI entry point. Business logic is delegated to:
- validator.py: NspecValidator for validation and generation
- table_formatter.py: NspecTableFormatter for table display
- session.py: Session handoff and management
- crud.py: CRUD operations for specs

Note: Directory paths are configurable via .novabuilt.dev/nspec/config.toml.
See nspec.paths module for configuration details.
"""

import argparse
import logging
import os
import sys
from pathlib import Path

from nspec.crud import (
    add_dependency,
    check_acceptance_criteria,
    check_impl_task,
    clean_dangling_deps,
    complete_spec,
    create_adr,
    create_new_spec,
    delete_spec,
    finalize_spec,
    list_adrs,
    move_dependency,
    next_status,
    reject_spec,
    remove_dependency,
    set_loe,
    set_priority,
    set_status,
    supersede_spec,
    validate_spec_criteria,
)
from nspec.datasets import DatasetLoader
from nspec.paths import get_paths
from nspec.session import (
    append_session_log,
    generate_handoff,
    get_modified_files,
    initialize_session,
    sync_spec_state,
)
from nspec.spinner import spinner
from nspec.statuses import print_status_codes
from nspec.table_formatter import NspecTableFormatter
from nspec.validator import NspecValidator

logger = logging.getLogger("nspec")

# Exceptions expected during nspec CLI operations
_NspecCliErrors = (RuntimeError, ValueError, KeyError, TypeError, OSError, IOError)


def run_validation_check(
    docs_root: Path, operation_name: str, project_root: Path | None = None
) -> bool:
    """Run validation after a mutation operation and report results."""
    print(f"\nRunning validation after {operation_name}...")
    validator = NspecValidator(docs_root=docs_root, project_root=project_root)
    success, errors = validator.validate()

    if success:
        print("Validation passed - nspec is consistent")
        return True
    else:
        print(f"Validation failed with {len(errors)} error(s):")
        for error in errors:
            print(f"  - {error}")
        print("\nFix these errors before proceeding with other nspec operations.")
        return False


# =============================================================================
# Command Handlers
# =============================================================================


def handle_statusline(args) -> int:
    """Output compact status line for Claude Code integration.

    Format: E{epic} · S{spec} · [{completed}/{total}]

    Uses the same TaskParser as the TUI for consistent counts.
    """
    from nspec.session import StateDAO
    from nspec.tasks import TaskParser

    project_root = getattr(args, "project_root", None) or Path.cwd()
    agent_id = getattr(args, "agent_id", None)

    if agent_id:
        # Swarm mode: look up agent's claim from queue.json
        from nspec.queue import QueueDAO

        queue_dao = QueueDAO(project_root)
        spec_id = queue_dao.get_agent_spec(agent_id) or "---"
        state = queue_dao.load()
        epic_id = state.epic_id if state and state.epic_id else "---"
    else:
        # Single-agent mode: read from state.json
        dao = StateDAO(project_root)
        spec_id = dao.get_spec_id() or "---"
        epic_id = dao.get_active_epic() or "---"

    # Normalize legacy/corrupt state where an epic ID was stored in spec_id.
    if spec_id and spec_id.startswith("E"):
        if epic_id == "---":
            epic_id = spec_id
        spec_id = "---"
    if not spec_id:
        spec_id = "---"
    if not epic_id:
        epic_id = "---"

    # Get task counts using the same parser as TUI
    completed = 0
    total = 0

    if spec_id.startswith("S"):
        paths = get_paths(args.docs_root, project_root=getattr(args, "project_root", None))
        impl_files = list(paths.active_impls_dir.glob(f"IMPL-{spec_id}-*.md"))

        if impl_files:
            impl_path = impl_files[0]
            content = impl_path.read_text()
            parser = TaskParser()
            tasks = parser.parse(content, impl_path)

            def count_all(task_list):
                t, c = 0, 0
                for task in task_list:
                    t += 1
                    if task.completed:
                        c += 1
                    if task.children:
                        ct, cc = count_all(task.children)
                        t += ct
                        c += cc
                return t, c

            total, completed = count_all(tasks)

    # ANSI colors for terminal statusline
    cyan = "\033[36m"
    yellow = "\033[33m"
    green = "\033[32m"
    dim = "\033[2m"
    reset = "\033[0m"

    if completed == total and total > 0:
        progress_color = green
    elif completed > 0:
        progress_color = yellow
    else:
        progress_color = dim

    # Avoid double prefix (StateDAO returns "E001", "S021" with prefix already)
    epic_display = epic_id if epic_id.startswith("E") else f"E{epic_id}"
    spec_display = spec_id if spec_id.startswith("S") else f"S{spec_id}"

    print(
        f"{cyan}{epic_display}{reset}"
        f" {dim}·{reset} "
        f"{yellow}{spec_display}{reset}"
        f" {dim}·{reset} "
        f"{progress_color}[{completed}/{total}]{reset}",
        end="",
    )
    return 0


def handle_mcp_config(args) -> int:
    """Print MCP configuration instructions."""
    from nspec.init import generate_mcp_config

    project_root = getattr(args, "project_root", None) or Path.cwd()
    output = generate_mcp_config(project_root)
    print(output)
    return 0


def _resolve_strict_mode(args) -> bool:
    """Resolve enforce_epic_grouping from config.toml."""
    try:
        from nspec.config import NspecConfig

        project_root = getattr(args, "project_root", None)
        config = NspecConfig.load(project_root)
        return config.validation.enforce_epic_grouping
    except Exception:
        return False


def handle_next(args) -> int:
    """Find and display the next unblocked spec to work on."""
    import json as json_mod

    from nspec.ordering import eligible_next_specs
    from nspec.reports import ReportContext, blockers_report

    try:
        loader = DatasetLoader(
            docs_root=args.docs_root, project_root=getattr(args, "project_root", None)
        )
        datasets = loader.load()
    except ValueError as e:
        print(f"Failed to load datasets: {e}", file=sys.stderr)
        return 1

    # Resolve epic filter
    epic_id = getattr(args, "epic", None)
    if epic_id:
        epic_id = resolve_epic(epic_id, args.docs_root)
        epic_fr = datasets.active_frs.get(epic_id)
        if not epic_fr:
            print(f"Epic {epic_id} not found", file=sys.stderr)
            return 1

    # Get blocked spec IDs
    ctx = ReportContext(datasets=datasets, docs_root=args.docs_root)
    blockers = blockers_report(ctx)
    blocked_ids: set[str] = set()
    for section in blockers.get("sections", []):
        if section.get("type") == "blockers":
            for b in section.get("data", []):
                blocked_ids.add(b["id"])

    candidates = eligible_next_specs(datasets, epic_id=epic_id, blocked_ids=blocked_ids)

    if not candidates:
        if getattr(args, "json_output", False):
            print(json_mod.dumps({"next": None, "message": "No unblocked specs found"}))
        else:
            print("No unblocked specs found", file=sys.stderr)
        return 1

    if getattr(args, "json_output", False):
        print(json_mod.dumps({"next": candidates[0], "alternatives": candidates[1:5]}))
    else:
        print(candidates[0]["spec_id"])

    return 0


def handle_validate(args) -> int:
    """Run all validation layers."""
    from nspec.config import NspecConfig

    project_root = getattr(args, "project_root", None)
    try:
        config = NspecConfig.load(project_root)
        strict_completion_parity = config.validation.strict_completion_parity
    except Exception:
        strict_completion_parity = True

    validator = NspecValidator(
        docs_root=args.docs_root,
        strict_mode=_resolve_strict_mode(args),
        strict_completion_parity=strict_completion_parity,
        project_root=project_root,
    )
    success, errors = validator.validate()

    if success:
        print("✅ Nspec validation passed - no errors found")
        return 0
    else:
        print(f"\nFound {len(errors)} errors:")
        for error in errors:
            print(error)
            print()
        return 1


def handle_generate(args) -> int:
    """Generate NSPEC.md from validated fRIMPLs."""
    # Pass 0: Auto-clean dangling dependencies
    cleaned = clean_dangling_deps(args.docs_root)
    if cleaned:
        for spec_id, _path, removed in cleaned:
            print(f"Spec {spec_id}: removed dangling deps {removed}")

    # Pass 1: Validate
    validator = NspecValidator(
        docs_root=args.docs_root, project_root=getattr(args, "project_root", None)
    )
    with spinner("Loading"):
        success, errors = validator.validate()

    if not success:
        print(f"\nValidation failed with {len(errors)} errors. Cannot generate.")
        for error in errors:
            print(error)
            print()
        print("Fix errors first, then run --generate again.")
        return 1

    # Pass 2: Generate files
    validator.generate_nspec(Path("NSPEC.md"))
    validator.generate_nspec_completed(Path("NSPEC_COMPLETED.md"))
    return 0


def handle_dashboard(args) -> int:
    """Generate + stats in one call."""
    from nspec.config import NspecConfig

    project_root = getattr(args, "project_root", None)
    try:
        config = NspecConfig.load(project_root)
        strict_completion_parity = config.validation.strict_completion_parity
        default_epic = config.defaults.epic
    except Exception:
        strict_completion_parity = True
        default_epic = None

    # Clean dangling deps
    cleaned = clean_dangling_deps(args.docs_root)
    if cleaned:
        for spec_id, _path, removed in cleaned:
            print(f"Spec {spec_id}: removed dangling deps {removed}")

    # Auto-assign ungrouped specs to default epic (from config)
    if default_epic:
        from nspec.crud import auto_assign_ungrouped_to_epic

        try:
            assigned = auto_assign_ungrouped_to_epic(default_epic, args.docs_root)
            if assigned:
                for spec_id, epic_id in assigned:
                    print(f"Spec {spec_id}: auto-assigned to Epic {epic_id}")
        except (FileNotFoundError, ValueError) as e:
            print(f"Auto-assign failed: {e}")

    # Validate and generate
    validator = NspecValidator(
        docs_root=args.docs_root,
        strict_mode=_resolve_strict_mode(args),
        strict_completion_parity=strict_completion_parity,
        project_root=project_root,
    )
    validator.verbose_status = getattr(args, "verbose_status", False)
    validator.epic_filter = getattr(args, "epic", None)

    with spinner("Loading"):
        success, errors = validator.validate()

    if not success:
        print(f"\nValidation failed with {len(errors)} errors.")
        for error in errors:
            print(error)
            print()
        return 1

    # Generate files
    validator.generate_nspec(Path("NSPEC.md"))
    validator.generate_nspec_completed(Path("NSPEC_COMPLETED.md"))

    # Show stats (without calendar)
    formatter = NspecTableFormatter(
        datasets=validator.datasets,
        ordered_active_specs=validator.ordered_active_specs,
        verbose_status=validator.verbose_status,
        epic_filter=validator.epic_filter,
    )
    formatter.show_stats(show_calendar=False)
    return 0


def handle_stats(args) -> int:
    """Show engineering metrics dashboard."""
    from nspec.dev_metrics import print_dev_metrics

    print_dev_metrics(Path("."))
    return 0


def handle_progress(args) -> int:
    """Show task/AC progress."""
    validator = NspecValidator(
        docs_root=args.docs_root, project_root=getattr(args, "project_root", None)
    )

    try:
        loader = DatasetLoader(
            docs_root=args.docs_root, project_root=getattr(args, "project_root", None)
        )
        validator.datasets = loader.load()
    except ValueError as e:
        print(f"Failed to load datasets: {e}")
        return 1

    if args.progress == "__summary__":
        validator.show_progress(show_all=args.all)
    else:
        validator.show_progress(spec_id=args.progress)
    return 0


def handle_deps(args) -> int:
    """List direct dependencies of a spec/epic."""
    loader = DatasetLoader(args.docs_root, project_root=getattr(args, "project_root", None))
    datasets = loader.load()

    fr = datasets.active_frs.get(args.deps)
    if not fr:
        print(f"Spec {args.deps} not found in active nspec")
        return 1

    if not fr.deps:
        print(f"Spec {args.deps} has no dependencies")
        return 0

    title = fr.path.stem.replace(f"FR-{args.deps}-", "").replace("-", " ").title()
    print(f"\nDependencies of {args.deps}: {title}")
    print(f"   Priority: {fr.priority} | Status: {fr.status}")
    print(f"   Count: {len(fr.deps)} dependencies\n")

    for dep_id in sorted(fr.deps, key=lambda x: int(x) if x.isdigit() else 0):
        dep_fr = datasets.active_frs.get(dep_id)
        if dep_fr:
            dep_title = dep_fr.path.stem.replace(f"FR-{dep_id}-", "").replace("-", " ").title()
            dep_impl = datasets.active_impls.get(dep_id)
            impl_status = dep_impl.status if dep_impl else "N/A"
            print(f"   {dep_id}: {dep_title}")
            print(f"        FR: {dep_fr.status} | IMPL: {impl_status} | Pri: {dep_fr.priority}")
        else:
            dep_fr = datasets.completed_frs.get(dep_id)
            if dep_fr:
                print(f"   {dep_id}: (completed)")
            else:
                print(f"   {dep_id}: (not found)")

    print()
    return 0


def handle_context(args) -> int:
    """Output LLM-friendly context for epic's dependencies."""
    from collections import defaultdict

    loader = DatasetLoader(args.docs_root, project_root=getattr(args, "project_root", None))
    datasets = loader.load()

    epic_fr = datasets.active_frs.get(args.context)
    if not epic_fr:
        print(f"Epic {args.context} not found in active nspec")
        return 1

    if not epic_fr.deps:
        print(f"Epic {args.context} has no dependencies")
        return 0

    epic_title = epic_fr.path.stem.replace(f"FR-{args.context}-", "").replace("-", " ").title()

    # Collect all incomplete deps
    incomplete: dict[str, dict] = {}
    completed: list[str] = []

    for dep_id in epic_fr.deps:
        dep_fr = datasets.active_frs.get(dep_id)
        if dep_fr:
            dep_impl = datasets.active_impls.get(dep_id)
            dep_title = dep_fr.path.stem.replace(f"FR-{dep_id}-", "").replace("-", " ")
            incomplete[dep_id] = {
                "title": dep_title,
                "fr_status": dep_fr.status,
                "impl_status": dep_impl.status if dep_impl else "N/A",
                "priority": dep_fr.priority,
                "upstream": list(dep_fr.deps) if dep_fr.deps else [],
            }
        else:
            if datasets.completed_frs.get(dep_id):
                completed.append(dep_id)

    # Build reverse dependency map
    downstream: dict[str, list[str]] = defaultdict(list)
    for spec_id, info in incomplete.items():
        for up_id in info["upstream"]:
            if up_id in incomplete:
                downstream[up_id].append(spec_id)

    # Categorize specs
    ready_to_start: list[tuple[str, str]] = []
    blocked_by_active: list[tuple[str, str, list[str]]] = []
    active_work: list[tuple[str, str]] = []

    for spec_id, info in incomplete.items():
        blockers = [u for u in info["upstream"] if u in incomplete]
        is_active = "Active" in info["impl_status"] or "Active" in info["fr_status"]
        is_hold = "Hold" in info["impl_status"] or "hold" in info["impl_status"].lower()

        if is_active and not is_hold:
            active_work.append((spec_id, info["title"]))
        elif not blockers:
            ready_to_start.append((spec_id, info["title"]))
        else:
            active_blockers = [
                b
                for b in blockers
                if incomplete.get(b, {}).get("impl_status", "").find("Active") >= 0
            ]
            if active_blockers:
                blocked_by_active.append((spec_id, info["title"], active_blockers))
            else:
                ready_to_start.append((spec_id, info["title"]))

    # Output YAML-like format
    print(f"""# LLM Context: Epic {args.context}
epic:
  id: {args.context}
  title: "{epic_title}"
  total_deps: {len(epic_fr.deps)}
  completed: {len(completed)}
  remaining: {len(incomplete)}

active_work:""")
    if active_work:
        for sid, title in sorted(active_work):
            print(f"  - {sid}: {title}")
    else:
        print("  []")

    print("\nready_to_start:")
    if ready_to_start:
        for sid, title in sorted(ready_to_start):
            print(f"  - {sid}: {title}")
    else:
        print("  []")

    print("\nblocked_by_active:")
    if blocked_by_active:
        for sid, title, blockers in sorted(blocked_by_active):
            print(f"  - {sid}: {title}")
            print(f"    blocked_by: [{', '.join(blockers)}]")
    else:
        print("  []")

    return 0


# =============================================================================
# Session Commands
# =============================================================================


def handle_handoff(args) -> int:
    """Generate session handoff summary."""
    if not args.id:
        print("Error: --id is required for session handoff")
        return 1

    output = generate_handoff(args.id, args.docs_root)
    print(output)
    return 0


def handle_session_start(args) -> int:
    """Initialize session context."""
    if not args.id:
        print("Error: --id is required for session start")
        return 1

    output = initialize_session(args.id, args.docs_root)
    print(output)
    return 0


def handle_session_log(args) -> int:
    """Append note to execution notes."""
    if not args.id or not args.note:
        print("Error: --id and --note are required for session log")
        return 1

    output = append_session_log(args.id, args.note, args.docs_root)
    print(output)
    return 0


def handle_modified_files(args) -> int:
    """List modified files."""
    files = get_modified_files(Path.cwd(), args.since_commit)
    for f in files:
        print(f)
    return 0


def handle_sync(args) -> int:
    """Sync spec state."""
    if not args.id:
        print("Error: --id is required for session sync")
        return 1

    output = sync_spec_state(args.id, args.docs_root, force=args.force)
    print(output)
    return 0


# =============================================================================
# CRUD Commands
# =============================================================================


def resolve_epic(explicit_epic: str | None, docs_root: Path) -> str | None:
    """Resolve epic ID: explicit flag > config default > None.

    Args:
        explicit_epic: Explicitly provided epic ID (--epic flag)
        docs_root: Path to docs/ directory

    Returns:
        Resolved epic ID (normalized to E### format), or None if no epic specified or configured
    """
    if explicit_epic:
        # Normalize to E### format if bare number provided
        if explicit_epic[0].isdigit():
            return f"E{explicit_epic.zfill(3)}"
        return explicit_epic

    # Check config for defaults.epic
    from nspec.config import NspecConfig

    config = NspecConfig.load(docs_root.parent)
    if config.defaults.epic:
        default_epic = config.defaults.epic
        # Config stores bare number (e.g. "001") — prefix with E
        if default_epic[0].isdigit():
            return f"E{default_epic.zfill(3)}"
        return default_epic

    return None


def validate_epic_exists(epic_id: str, docs_root: Path, project_root: Path | None = None) -> bool:
    """Validate that epic ID exists in active nspec.

    Args:
        epic_id: Epic ID to validate (can be "E001" or bare "001")
        docs_root: Path to docs/ directory

    Returns:
        True if epic exists

    Raises:
        ValueError: If epic doesn't exist
    """
    paths = get_paths(docs_root, project_root=project_root)
    # Normalize epic_id to E### format for pattern matching
    normalized = epic_id.upper() if epic_id.upper().startswith("E") else f"E{epic_id.zfill(3)}"
    pattern = f"FR-{normalized}-*.md"
    matches = list(paths.active_frs_dir.glob(pattern))

    if not matches:
        raise ValueError(f"Epic {epic_id} not found in {paths.active_frs_dir}")

    return True


def handle_create_new(args) -> int:
    """Create new FR+IMPL from templates."""
    from nspec.config import NspecConfig

    if not args.title:
        print("Error: --title is required for spec create")
        return 1

    is_epic = getattr(args, "type", "spec") == "epic"
    set_default = getattr(args, "set_default", False)

    # Load config for git.auto_add and templates.fr/impl
    try:
        config = NspecConfig.load(getattr(args, "project_root", None) or args.docs_root.parent)
        auto_add = config.git.auto_add
        fr_template = config.templates.fr
        impl_template = config.templates.impl
    except Exception:
        auto_add = False
        fr_template = None
        impl_template = None

    # Validate flag combinations
    if set_default and not is_epic:
        print("Error: --set-default only valid with --type epic")
        return 1
    if is_epic and getattr(args, "epic", None):
        print("Error: --epic cannot be used with --type epic (epics don't nest)")
        return 1

    try:
        # Resolve epic FIRST (before creating anything) — skip for epic creation
        epic_id = None
        if not is_epic:
            epic_id = resolve_epic(getattr(args, "epic", None), args.docs_root)

            # Config gates: require epic assignment when either gate is enabled
            if epic_id is None:
                require_default_epic = config.strict.require_default_epic
                enforce_epic_grouping = config.validation.enforce_epic_grouping
                if require_default_epic or enforce_epic_grouping:
                    raise ValueError(
                        "Spec creation requires epic assignment.\n"
                        "Set it in .novabuilt.dev/nspec/config.toml:\n"
                        "  [defaults]\n"
                        '  epic = "001"\n\n'
                        "Current gates:\n"
                        "  [strict]\n"
                        f"  require_default_epic = {str(require_default_epic).lower()}\n"
                        "  [validation]\n"
                        f"  enforce_epic_grouping = {str(enforce_epic_grouping).lower()}\n\n"
                        "To allow orphan creation, disable both gates."
                    )

            # Validate epic exists BEFORE creating files (only if epic specified)
            if epic_id:
                validate_epic_exists(
                    epic_id, args.docs_root, project_root=getattr(args, "project_root", None)
                )

        # Create spec/epic files
        fr_path, impl_path, spec_id = create_new_spec(
            title=args.title,
            priority=args.priority,
            docs_root=args.docs_root,
            fr_template=fr_template,
            impl_template=impl_template,
            is_epic=is_epic,
        )

        # Add spec to epic (only if epic specified and not creating an epic)
        if epic_id and not is_epic:
            move_dependency(
                spec_id=spec_id,
                target_epic_id=epic_id,
                docs_root=args.docs_root,
            )

        # Set as default epic if requested
        if set_default and is_epic:
            _set_default_epic(spec_id, getattr(args, "project_root", None))

        # Git add if enabled in config
        if auto_add:
            import subprocess

            subprocess.run(["git", "add", str(fr_path), str(impl_path)], check=True)

        if is_epic:
            if set_default:
                print(f"Created Epic {spec_id} (set as default)")
            else:
                print(f"Created Epic {spec_id}")
        elif epic_id:
            print(f"Created Spec {spec_id} in Epic {epic_id}")
        else:
            print(f"Created Spec {spec_id}")
        print(str(fr_path))
        print(str(impl_path))
        return 0
    except (ValueError, FileNotFoundError) as e:
        print(f"Failed to create spec: {e}")
        return 1


def _set_default_epic(epic_id: str, project_root: Path | None = None) -> None:
    """Update config.toml to set the default epic."""
    from nspec.config import CONFIG_REL_PATH, NspecConfig

    if project_root is None:
        project_root = Path.cwd()

    config = NspecConfig.load(project_root)
    # Ensure config_file is set (may be None if file didn't exist)
    if config.config_file is None:
        config.config_file = project_root / CONFIG_REL_PATH
    # Store without E prefix (just the number)
    epic_num = epic_id[1:] if epic_id.startswith("E") else epic_id
    config.defaults.epic = epic_num
    config.save()


def handle_delete(args) -> int:
    """Delete FR+IMPL for a spec."""
    if not args.id:
        print("Error: --id is required for spec delete")
        return 1

    # Auto-prefix numeric IDs with S
    spec_id = args.id.strip()
    if spec_id and spec_id[0].isdigit():
        spec_id = "S" + spec_id

    try:
        fr_path, impl_path = delete_spec(
            spec_id=args.id,
            docs_root=args.docs_root,
            force=args.force,
        )
        print(f"Deleted Spec {spec_id}")
        print(f"   Removed: {fr_path.name}")
        print(f"   Removed: {impl_path.name}")
        return 0
    except (RuntimeError, FileNotFoundError) as e:
        print(f"Failed to delete spec: {e}")
        return 1


def handle_complete(args) -> int:
    """Move FR+IMPL to completed directory."""
    if not args.id:
        print("Error: --id is required for spec complete")
        return 1

    spec_id = _normalize_spec_ref(args.id)
    try:
        fr_old, fr_new, impl_old, impl_new = complete_spec(
            spec_id=spec_id,
            docs_root=args.docs_root,
        )
        print(str(fr_old))
        print(str(fr_new))
        print(str(impl_old))
        print(str(impl_new))
        return 0
    except (RuntimeError, FileNotFoundError) as e:
        print(f"Failed to complete spec: {e}")
        return 1


def handle_supersede(args) -> int:
    """Move FR+IMPL to superseded directory."""
    if not args.id:
        print("Error: --id is required for spec supersede")
        return 1

    superseded_by = getattr(args, "by", None) or "unknown"

    spec_id = _normalize_spec_ref(args.id)
    try:
        fr_old, fr_new, impl_old, impl_new = supersede_spec(
            spec_id=spec_id,
            superseded_by=superseded_by,
            docs_root=args.docs_root,
        )
        print(str(fr_old))
        print(str(fr_new))
        print(str(impl_old))
        print(str(impl_new))
        return 0
    except (RuntimeError, FileNotFoundError) as e:
        print(f"Failed to supersede spec: {e}")
        return 1


def handle_reject(args) -> int:
    """Archive spec as rejected."""
    if not args.id:
        print("Error: --id is required for spec reject")
        return 1

    spec_id = _normalize_spec_ref(args.id)
    try:
        fr_old, fr_new, impl_old, impl_new = reject_spec(
            spec_id=spec_id,
            docs_root=args.docs_root,
            force=args.force,
        )
        print(str(fr_old))
        print(str(fr_new))
        print(str(impl_old))
        print(str(impl_new))
        return 0
    except (RuntimeError, FileNotFoundError) as e:
        print(f"Failed to reject spec: {e}")
        return 1


def handle_finalize(args) -> int:
    """Show completion status."""
    if not args.id:
        print("Error: --id is required for spec finalize")
        return 1

    spec_id = _normalize_spec_ref(args.id)
    try:
        finalize_spec(
            spec_id=spec_id,
            docs_root=args.docs_root,
            execute=args.execute,
        )
        return 0
    except FileNotFoundError as e:
        print(f"Failed to finalize spec: {e}")
        return 1


def handle_add_dep(args) -> int:
    """Add dependency to a spec."""
    if not args.to or not args.dep:
        print("Error: --to and --dep are required for dep add")
        return 1

    spec_id = _normalize_spec_ref(args.to)
    dependency_id = _normalize_spec_ref(args.dep)
    try:
        result = add_dependency(
            spec_id=spec_id,
            dependency_id=dependency_id,
            docs_root=args.docs_root,
        )
        print(f"Added dependency {dependency_id} to Spec {spec_id}")
        print(f"   Updated: {result['path']}")
        if result.get("moved_from"):
            print(f"   Moved from Epic {result['moved_from']}")

        run_validation_check(args.docs_root, "dependency addition")
        return 0
    except (FileNotFoundError, ValueError) as e:
        print(f"Failed to add dependency: {e}")
        return 1


def handle_remove_dep(args) -> int:
    """Remove dependency from a spec."""
    if not args.to or not args.dep:
        print("Error: --to and --dep are required for dep remove")
        return 1

    spec_id = _normalize_spec_ref(args.to)
    dependency_id = _normalize_spec_ref(args.dep)
    try:
        fr_path = remove_dependency(
            spec_id=spec_id,
            dependency_id=dependency_id,
            docs_root=args.docs_root,
        )
        print(f"Removed dependency {dependency_id} from Spec {spec_id}")
        print(f"   Updated: {fr_path}")

        run_validation_check(args.docs_root, "dependency removal")
        return 0
    except (FileNotFoundError, ValueError) as e:
        print(f"Failed to remove dependency: {e}")
        return 1


def handle_move_dep(args) -> int:
    """Move spec to target epic."""
    if not args.to or not args.dep:
        print("Error: --to and --dep are required for dep move")
        return 1

    try:
        result = move_dependency(
            spec_id=args.dep,
            target_epic_id=args.to,
            docs_root=args.docs_root,
        )

        print(f"Moved Spec {args.dep} to Epic {args.to}")
        if result["removed_from"]:
            for epic_id in result["removed_from"]:
                print(f"   Removed from Epic {epic_id}")
        if result["added_to"]:
            print(f"   Added to Epic {result['added_to']}")
        if result["priority_bumped"]:
            print(f"   Priority bumped to {result['priority_bumped']}")

        run_validation_check(args.docs_root, "dependency move")
        return 0
    except (FileNotFoundError, ValueError) as e:
        print(f"Failed to move dependency: {e}")
        return 1


def handle_dep_clean(args) -> int:
    """Remove dependencies pointing to non-existent specs."""
    cleaned = clean_dangling_deps(
        args.docs_root,
        project_root=getattr(args, "project_root", None),
        dry_run=getattr(args, "dry_run", False),
    )
    if not cleaned:
        print("No dangling deps found")
        return 0

    for spec_id, path, removed in cleaned:
        prefix = "[dry-run] " if getattr(args, "dry_run", False) else ""
        print(f"{prefix}Spec {spec_id}: removed dangling deps {removed}")
        print(f"   Updated: {path}")

    if not getattr(args, "dry_run", False):
        run_validation_check(args.docs_root, "dangling dependency cleanup")
    return 0


def handle_set_priority(args) -> int:
    """Change priority for a spec."""
    if not args.id or not args.priority:
        print("Error: --id and --priority are required for task set-priority")
        return 1

    spec_id = _normalize_spec_ref(args.id)
    try:
        fr_path = set_priority(
            spec_id=spec_id,
            priority=args.priority,
            docs_root=args.docs_root,
        )
        print(f"Updated Spec {spec_id} to {args.priority}")
        print(f"   Updated: {fr_path}")

        run_validation_check(args.docs_root, "priority change")
        return 0
    except (FileNotFoundError, ValueError) as e:
        print(f"Failed to set priority: {e}")
        return 1


def handle_set_loe(args) -> int:
    """Set LOE for a spec."""
    if not args.id or not args.loe:
        print("Error: --id and --loe are required for task set-loe")
        return 1

    spec_id = _normalize_spec_ref(args.id)
    try:
        impl_path = set_loe(
            spec_id=spec_id,
            loe=args.loe,
            docs_root=args.docs_root,
        )
        print(f"Updated Spec {spec_id} LOE to {args.loe}")
        print(f"   Updated: {impl_path}")

        run_validation_check(args.docs_root, "LOE change")
        return 0
    except (FileNotFoundError, ValueError) as e:
        print(f"Failed to set LOE: {e}")
        return 1


def handle_set_status(args) -> int:
    """Set status for FR and IMPL files atomically."""
    if not args.id or args.fr_status is None or args.impl_status is None:
        print("Error: --id, --fr-status, and --impl-status required")
        return 1

    try:
        set_status(
            spec_id=args.id,
            fr_status=args.fr_status,
            impl_status=args.impl_status,
            docs_root=args.docs_root,
            force=args.force,
        )
        return 0
    except (FileNotFoundError, ValueError) as e:
        print(f"Failed to set status: {e}")
        return 1


def handle_next_status(args) -> int:
    """Auto-advance IMPL to next logical state."""
    if not args.id:
        print("Error: --id is required for task next-status")
        return 1

    spec_id = _normalize_spec_ref(args.id)
    try:
        next_status(
            spec_id=spec_id,
            docs_root=args.docs_root,
        )
        return 0
    except (FileNotFoundError, ValueError) as e:
        print(f"Failed to advance status: {e}")
        return 1


def handle_check_criteria(args) -> int:
    """Mark acceptance criterion as complete or obsolete."""
    if not args.id or not args.criteria_id:
        print("Error: --id and --criteria-id are required for task criteria")
        return 1

    marker = getattr(args, "marker", "x")
    marker_desc = "complete" if marker == "x" else "obsolete"

    spec_id = _normalize_spec_ref(args.id)
    try:
        fr_path = check_acceptance_criteria(
            spec_id=spec_id,
            criteria_id=args.criteria_id,
            docs_root=args.docs_root,
            marker=marker,
        )
        print(f"Marked {args.criteria_id} as {marker_desc} for Spec {spec_id}")
        print(f"   Updated: {fr_path}")
        return 0
    except (FileNotFoundError, ValueError) as e:
        print(f"Failed to check criteria: {e}")
        return 1


def handle_check_task(args) -> int:
    """Mark IMPL task as complete or obsolete."""
    if not args.id or not args.task_id:
        print("Error: --id and --task-id are required for task check")
        return 1

    marker = getattr(args, "marker", "x")
    marker_desc = "complete" if marker == "x" else "obsolete"

    spec_id = _normalize_spec_ref(args.id)
    try:
        impl_path = check_impl_task(
            spec_id=spec_id,
            task_id=args.task_id,
            docs_root=args.docs_root,
            marker=marker,
        )
        print(f"Marked task '{args.task_id}' as {marker_desc} for Spec {spec_id}")
        print(f"   Updated: {impl_path}")
        return 0
    except (FileNotFoundError, ValueError) as e:
        print(f"Failed to check task: {e}")
        return 1


def handle_validate_criteria(args) -> int:
    """Validate acceptance criteria for a spec."""
    if not args.id:
        print("Error: --id is required for validate criteria")
        return 1

    try:
        is_valid, violations = validate_spec_criteria(
            spec_id=args.id,
            docs_root=args.docs_root,
            strict=args.strict,
        )

        if is_valid:
            print(f"Spec {args.id} acceptance criteria validation passed")
            return 0
        else:
            print(f"Spec {args.id} acceptance criteria validation failed:\n")
            for violation in violations:
                print(f"   {violation}")
            return 1
    except _NspecCliErrors as e:
        print(f"Validation error: {e}")
        return 1


def handle_review_finalize(args) -> int:
    """Finalize a review-packet spec end-to-end (archive + checkboxes + complete)."""
    if not args.id:
        print("Error: --id required")
        return 1

    from nspec.review_workflow import finalize_review_packet_spec

    spec_id = _normalize_spec_ref(args.id)
    try:
        result = finalize_review_packet_spec(
            review_spec_id=spec_id,
            docs_root=args.docs_root,
            archive_date=getattr(args, "date", None),
        )
        print(f"✅ Finalized review spec {result.review_spec_id} (target {result.target_spec_id})")
        print(f"   Archived: {result.archived_path}")
        print(f"   Completed FR: {result.completed_fr_path}")
        print(f"   Completed IMPL: {result.completed_impl_path}")
        return 0
    except (FileNotFoundError, ValueError, RuntimeError) as e:
        print(f"Failed to finalize review spec: {e}")
        return 1


def handle_loop_retry(args) -> int:
    """Manage loop retry state."""
    import json as json_mod

    from nspec.session import LoopRetriesDAO

    project_root = getattr(args, "project_root", None) or Path.cwd()
    dao = LoopRetriesDAO(project_root)
    action = getattr(args, "retry_action", None)

    if action == "increment":
        spec_id = _normalize_spec_ref(args.id)
        exit_reason = getattr(args, "exit_reason", "") or ""
        count = dao.increment(spec_id, exit_reason)
        print(count)
        return 0
    elif action == "count":
        spec_id = _normalize_spec_ref(args.id)
        print(dao.get_count(spec_id))
        return 0
    elif action == "clear":
        spec_id = _normalize_spec_ref(args.id)
        dao.clear(spec_id)
        return 0
    elif action == "list":
        entries = dao.list_all()
        print(
            json_mod.dumps(
                {
                    k: {
                        "count": v.count,
                        "last_exit": v.last_exit,
                        "last_failure_at": v.last_failure_at,
                    }
                    for k, v in entries.items()
                },
                indent=2,
            )
        )
        return 0
    elif action == "reset":
        dao.reset()
        return 0
    else:
        print(
            "Error: specify a retry action (increment, count, clear, list, reset)", file=sys.stderr
        )
        return 1


def handle_watchdog(args) -> int:
    """Run the Claude Code stall detector & auto-recovery."""
    from nspec.config import NspecConfig
    from nspec.watchdog import Watchdog, WatchdogState

    project_root = getattr(args, "project_root", None) or Path.cwd()
    config = NspecConfig.load(project_root)
    wdg_config = config.watchdog

    # CLI args override config.toml
    if args.stall_timeout is not None:
        wdg_config.stall_timeout = args.stall_timeout
    if getattr(args, "mcp_stall_timeout", None) is not None:
        wdg_config.mcp_stall_timeout = args.mcp_stall_timeout
    if args.poll_interval is not None:
        wdg_config.poll_interval = args.poll_interval

    try:
        session = Watchdog.find_session(getattr(args, "session", None))
    except RuntimeError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

    watchdog = Watchdog(session=session, config=wdg_config, state=WatchdogState())

    # Configure logging for watchdog output
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [watchdog] %(message)s",
        datefmt="%H:%M:%S",
        stream=sys.stderr,
        force=True,
    )

    watchdog.run()
    return 0


def handle_audit(args) -> int:
    """Run the coverage audit pipeline."""
    from nspec.coverage_audit import (
        format_audit_summary,
        run_audit,
    )

    coverage_json = Path(getattr(args, "coverage_json", "coverage.json"))
    registry = Path(getattr(args, "registry", "work/coverage_decisions.json"))
    strict = getattr(args, "strict", False)

    include = getattr(args, "include", None)
    include_patterns = [p.strip() for p in include.split(",")] if include else None
    exclude = getattr(args, "exclude", None)
    exclude_patterns = [p.strip() for p in exclude.split(",")] if exclude else None

    try:
        result = run_audit(
            coverage_json,
            registry,
            include_patterns=include_patterns,
            exclude_patterns=exclude_patterns,
        )
    except (FileNotFoundError, ValueError) as e:
        print(f"Audit error: {e}", file=sys.stderr)
        return 1

    print(format_audit_summary(result))

    if strict and (result.unresolved or result.stale_decisions):
        return 1
    return 0


def handle_linear_push(args) -> int:
    """Sync nspec state to Linear issues."""
    from nspec.integrations.linear import linear_push

    since_ref = getattr(args, "since", None)
    spec_id_arg = getattr(args, "spec_id", None)
    dry_run = getattr(args, "dry_run", False)

    if spec_id_arg:
        spec_id_arg = _normalize_spec_ref(spec_id_arg)

    try:
        results = linear_push(
            docs_root=args.docs_root,
            since_ref=since_ref,
            spec_id=spec_id_arg,
            dry_run=dry_run,
            project_root=getattr(args, "project_root", None),
        )
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

    if not results:
        print("No linked specs to sync")
        return 0

    failures = [r for r in results if not r.success]
    if failures:
        for f in failures:
            print(f"FAILED {f.spec_id} ({f.linear_issue_id}): {f.error}", file=sys.stderr)
        return 1

    return 0


def handle_linear_bootstrap(args) -> int:
    """Print Linear config snippet with team/workflow state IDs."""
    from nspec.integrations.linear import linear_bootstrap

    try:
        output = linear_bootstrap(project_root=getattr(args, "project_root", None))
        print(output)
        return 0
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def handle_config_get(args) -> int:
    """Read a config value by dotted key path."""
    from nspec.config import NspecConfig

    project_root = getattr(args, "project_root", None) or Path.cwd()
    config = NspecConfig.load(project_root)

    key_path = args.key
    parts = key_path.split(".", 1)
    if len(parts) != 2:
        print("Error: key must be section.field (e.g., loop.session_timeout)", file=sys.stderr)
        return 1

    value = config.get(parts[0], parts[1])
    if value is None:
        print(f"Error: unknown key '{key_path}'", file=sys.stderr)
        return 1

    print(value)
    return 0


def handle_queue(args) -> int:
    """Handle queue subcommands."""
    import json as _json

    from nspec.queue import QueueDAO

    docs_root = getattr(args, "docs_root", None) or Path.cwd() / "docs"
    # Derive project_root from docs_root (same logic as MCP tools)
    resolved_docs = Path(docs_root).resolve()
    if (
        resolved_docs.name == "docs"
        or (resolved_docs / "frs").exists()
        or (resolved_docs / "impls").exists()
    ):
        project_root = resolved_docs.parent
    else:
        project_root = resolved_docs
    dao = QueueDAO(project_root)

    action = getattr(args, "queue_action", None)
    if not action:
        print(
            "Error: specify a queue action (init, status, claim, release, drain)", file=sys.stderr
        )
        return 1

    if action == "init":
        epic_id = getattr(args, "epic_id", None)
        max_agents = getattr(args, "max_agents", 5)
        lease_ttl = getattr(args, "lease_ttl", 300)
        from nspec.config import NspecConfig

        config = NspecConfig.load(project_root)
        if config.queue.mode == "single":
            max_agents = 1
        state = dao.initialize_from_backlog(
            docs_root, epic_id=epic_id, max_agents=max_agents, lease_ttl=lease_ttl
        )
        print(f"Queue initialized: {len(state.entries)} specs")
        print(f"  Epic: {state.epic_id or 'all'}")
        print(f"  Max agents: {state.max_agents}")
        print(f"  Lease TTL: {state.lease_ttl_seconds}s")
        for e in state.entries:
            print(f"  - {e.spec_id}: {e.title} ({e.priority})")
        return 0

    if action == "status":
        result = dao.status()
        if "error" in result:
            print(f"Error: {result['error']}", file=sys.stderr)
            return 1
        print(_json.dumps(result, indent=2))
        return 0

    if action == "claim":
        agent_id = getattr(args, "agent_id", None)
        if not agent_id:
            print("Error: --agent-id required for claim", file=sys.stderr)
            return 1
        result = dao.claim(agent_id)
        if "error" in result:
            print(f"Error: {result['error']}", file=sys.stderr)
            return 1
        print(f"Claimed: {result['spec_id']} ({result['title']})")
        print(f"  Agent: {result['agent_id']}")
        print(f"  Lease expires: {result['lease_expires']}")
        return 0

    if action == "release":
        agent_id = getattr(args, "agent_id", None)
        spec_id = getattr(args, "spec_id", None)
        if not agent_id or not spec_id:
            print("Error: --agent-id and --spec-id required for release", file=sys.stderr)
            return 1
        reason = getattr(args, "reason", None)
        completed = getattr(args, "completed", False)
        result = dao.release(agent_id, spec_id, reason=reason, completed=completed)
        if "error" in result:
            print(f"Error: {result['error']}", file=sys.stderr)
            return 1
        status = "completed" if result.get("completed") else "released"
        print(f"Spec {spec_id} {status} by {agent_id}")
        return 0

    if action == "drain":
        result = dao.status()
        if "error" in result:
            print(f"Error: {result['error']}", file=sys.stderr)
            return 1
        print(f"Active agents: {result['active_agents']}")
        print(f"Specs remaining: {result['specs_remaining']}")
        print(f"Specs completed: {result['specs_completed']}")
        return 0

    print(f"Unknown queue action: {action}", file=sys.stderr)
    return 1


def handle_create_adr(args) -> int:
    """Create a new ADR."""
    if not args.title:
        print("Error: --title is required for adr create")
        return 1

    try:
        adr_id, fr_path = create_adr(args.title, args.docs_root)
        print(f"Created ADR-{adr_id}: {args.title}")
        print(f"   {fr_path}")
        return 0
    except _NspecCliErrors as e:
        print(f"Error creating ADR: {e}")
        return 1


def handle_list_adrs(args) -> int:
    """List all ADRs."""
    try:
        adrs = list_adrs(args.docs_root)
        if not adrs:
            print("No ADRs found (FR-900-999 range)")
            return 0

        print(f"\nArchitecture Decision Records ({len(adrs)} total)")
        print("=" * 60)
        for adr_id, status, title, _path in adrs:
            status_emoji = {
                "DRAFT": "D",
                "PROPOSED": "P",
                "ACCEPTED": "A",
                "DEPRECATED": "!",
                "SUPERSEDED": ">",
            }.get(status.upper(), "?")
            print(f"  ADR-{adr_id}: [{status_emoji}] {status}")
            print(f"           {title}")
            print()
        return 0
    except _NspecCliErrors as e:
        print(f"Error listing ADRs: {e}")
        return 1


# =============================================================================
# Main Entry Point
# =============================================================================


def handle_init(args: argparse.Namespace) -> int:
    """Initialize a new nspec project."""
    from nspec.init import detect_stack, interactive_init, scaffold_project

    project_root = Path.cwd()
    docs_root = getattr(args, "docs_root", None) or project_root / "docs"

    stack = detect_stack(project_root)
    ci_override = getattr(args, "ci", None)
    force = getattr(args, "force", False)

    print(f"Detected stack: {stack.language}/{stack.package_manager}")
    if stack.ci_platform != "none":
        print(f"Detected CI: {stack.ci_platform}")

    # Interactive path selection
    config = interactive_init(project_root, interactive=True)

    try:
        created = scaffold_project(
            project_root=project_root,
            docs_root=docs_root,
            stack=stack,
            ci_platform_override=ci_override,
            force=force,
            config=config,
        )
    except FileExistsError as e:
        print(f"Error: {e}")
        return 1

    # Create default epic if none exists (match MCP init behavior)
    from nspec.config import NspecConfig

    config = NspecConfig.load(project_root)
    fr_dir = docs_root / config.paths.feature_requests
    existing_epics = list(fr_dir.glob("FR-E*-*.md")) if fr_dir.exists() else []

    if not existing_epics:
        try:
            fr_path, impl_path, epic_id = create_new_spec(
                "Default Epic", "P2", docs_root, is_epic=True
            )
            created.extend([fr_path, impl_path])
            epic_num = epic_id[1:] if epic_id.startswith("E") else epic_id
            config.defaults.epic = epic_num
            config.save()
            print(f"Created default epic: {epic_id}")
        except Exception as e:
            print(f"Error: Failed to create default epic: {e}")
            return 1

    print(f"\nCreated {len(created)} files/directories:")
    for p in created:
        if p.is_file():
            try:
                rel = p.relative_to(project_root)
            except ValueError:
                rel = p
            print(f"  {rel}")

    print("\nNext steps:")
    print("  1. Review .novabuilt.dev/nspec/config.toml and adjust paths if needed")
    print("  2. Add 'include nspec.mk' to your Makefile")
    print("  3. Create your first spec: nspec spec create --title 'My Feature'")
    return 0


def _add_common_args(sub: argparse.ArgumentParser) -> None:
    """Add common arguments shared across subcommand parsers."""
    sub.add_argument("--docs-root", type=Path, default=Path("docs"), help="Docs root")
    sub.add_argument(
        "--project-root",
        type=Path,
        default=None,
        help="Project root for config (default: parent of --docs-root)",
    )


def _add_id_arg(sub: argparse.ArgumentParser) -> None:
    """Add --id argument to a subparser."""
    sub.add_argument("--id", type=str, required=True, help="Spec ID")


def _add_force_arg(sub: argparse.ArgumentParser) -> None:
    """Add --force argument to a subparser."""
    sub.add_argument("--force", action="store_true", help="Skip safety checks")


def build_parser() -> argparse.ArgumentParser:
    """Build and return the argument parser."""
    parser = argparse.ArgumentParser(
        description="Nspec management - validation, generation, and CRUD operations"
    )
    parser.add_argument("--tui", action="store_true", help="Launch interactive TUI (shorthand for 'nspec tui')")

    # Subcommands
    subparsers = parser.add_subparsers(dest="command")
    init_parser = subparsers.add_parser(
        "init",
        help="Initialize a new nspec project",
        description=(
            "Scaffold a new nspec project with docs structure, config, CLAUDE.md,\n"
            "and optional CI. The scaffolded CLAUDE.md contains nspec-aware dev\n"
            "process instructions (progress tracking, MCP tool reference, quality\n"
            "gates, commit format) with template variables interpolated from config.\n"
            "\n"
            "Overwrite rules for CLAUDE.md:\n"
            "  - New files are always created.\n"
            "  - Existing CLAUDE.md without '<!-- managed-by: nspec -->' is never\n"
            "    overwritten (user customizations are preserved).\n"
            "  - With --force, managed CLAUDE.md is updated; other init files\n"
            "    (config.toml, nspec.mk, CI, .mcp.json) are always overwritten."
        ),
        epilog=(
            "Examples:\n"
            "  nspec init\n"
            "  nspec init --ci github\n"
            "  nspec init --force --docs-root my-docs/"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    init_parser.add_argument(
        "--ci",
        type=str,
        choices=["github", "cloudbuild", "gitlab", "none"],
        default=None,
        help="CI platform (auto-detected if not specified)",
    )
    init_parser.add_argument(
        "--force",
        action="store_true",
        help="Overwrite existing files (CLAUDE.md only when managed-by header is present)",
    )
    init_parser.add_argument(
        "--docs-root", type=Path, default=None, help="Docs root directory (default: docs/)"
    )

    # -------------------------------------------------------------------------
    # Top-level subcommands
    # -------------------------------------------------------------------------

    # nspec tui
    tui_sub = subparsers.add_parser(
        "tui",
        help="Launch interactive TUI",
        description="Launch the interactive terminal UI for browsing and managing specs.",
        epilog=("Examples:\n  nspec tui\n  nspec tui --docs-root my-docs/"),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(tui_sub)
    tui_sub.set_defaults(handler=lambda args: _handle_tui_subcommand(args))

    # nspec statusline
    statusline_sub = subparsers.add_parser(
        "statusline",
        help="Output compact status line for Claude Code",
        description="Output a compact one-line status summary for Claude Code integration.",
        epilog=("Examples:\n  nspec statusline\n  nspec statusline --docs-root my-docs/"),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(statusline_sub)
    statusline_sub.add_argument(
        "--agent-id",
        help="Show spec claimed by this agent from queue.json (swarm mode)",
    )
    statusline_sub.set_defaults(handler=handle_statusline)

    # nspec next
    next_sub = subparsers.add_parser(
        "next",
        help="Show next unblocked spec to work on",
        description="Find the highest-priority unblocked spec, optionally filtered to an epic.",
        epilog=("Examples:\n  nspec next\n  nspec next --epic E001\n  nspec next --json"),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(next_sub)
    next_sub.add_argument("--epic", type=str, help="Filter to a specific epic")
    next_sub.add_argument(
        "--json", action="store_true", dest="json_output", help="Output structured JSON"
    )
    next_sub.set_defaults(handler=handle_next)

    # nspec generate
    generate_sub = subparsers.add_parser(
        "generate",
        help="Generate NSPEC.md",
        description="Generate NSPEC.md from validated FR and IMPL documents.",
        epilog=("Examples:\n  nspec generate\n  nspec generate --docs-root my-docs/"),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(generate_sub)
    generate_sub.set_defaults(handler=handle_generate)

    # nspec dashboard
    dashboard_sub = subparsers.add_parser(
        "dashboard",
        help="Generate + stats combined",
        description="Generate NSPEC.md and display engineering metrics in one command.",
        epilog=(
            "Examples:\n"
            "  nspec dashboard\n"
            "  nspec dashboard --epic E001\n"
            "  nspec dashboard --verbose-status"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(dashboard_sub)
    dashboard_sub.add_argument("--verbose-status", action="store_true", help="Full status text")
    dashboard_sub.add_argument("--epic", type=str, help="Filter by epic ID")
    dashboard_sub.set_defaults(handler=handle_dashboard)

    # nspec stats
    stats_sub = subparsers.add_parser(
        "stats",
        help="Show engineering metrics",
        description="Display engineering metrics: completion rates, velocity, and burndown.",
        epilog="Examples:\n  nspec stats",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(stats_sub)
    stats_sub.set_defaults(handler=handle_stats)

    # -------------------------------------------------------------------------
    # nspec review <cmd>
    # -------------------------------------------------------------------------
    review_sub = subparsers.add_parser(
        "review",
        help="Review packet workflow",
        description=(
            "Helpers for creating and finalizing per-spec review packets (evidence + archive)."
        ),
        epilog=(
            "Examples:\n"
            "  nspec review finalize --id S033\n"
            "  nspec review finalize --id S034 --date 2026-02-04"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    review_subs = review_sub.add_subparsers(dest="review_command")

    review_finalize = review_subs.add_parser(
        "finalize",
        help="Archive + mark done + complete review spec",
        description=(
            "Archive the target review packet, mark tasks/ACs, and complete the review spec."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(review_finalize)
    _add_id_arg(review_finalize)
    review_finalize.add_argument(
        "--date",
        type=str,
        default=None,
        help="Archive date (YYYY-MM-DD). Default: today.",
    )
    review_finalize.set_defaults(handler=handle_review_finalize)

    # -------------------------------------------------------------------------
    # nspec validate [criteria]
    # -------------------------------------------------------------------------
    validate_sub = subparsers.add_parser(
        "validate",
        help="Run validation",
        description="Run the 6-layer validation engine on all FR and IMPL documents.",
        epilog=(
            "Examples:\n"
            "  nspec validate\n"
            "  nspec validate\n"
            "  nspec validate criteria --id S002 --strict"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(validate_sub)
    validate_sub.set_defaults(handler=handle_validate)

    validate_subs = validate_sub.add_subparsers(dest="validate_command")
    validate_criteria_sub = validate_subs.add_parser(
        "criteria", help="Validate acceptance criteria"
    )
    _add_common_args(validate_criteria_sub)
    _add_id_arg(validate_criteria_sub)
    validate_criteria_sub.add_argument("--strict", action="store_true", help="Strict validation")
    validate_criteria_sub.set_defaults(handler=handle_validate_criteria)

    # -------------------------------------------------------------------------
    # nspec spec <cmd>
    # -------------------------------------------------------------------------
    spec_sub = subparsers.add_parser(
        "spec",
        help="Spec CRUD operations",
        description="Create, delete, complete, and manage spec lifecycle.",
        epilog=(
            "Examples:\n"
            "  nspec spec create --title 'Add search' --priority P1\n"
            "  nspec spec complete --id S003\n"
            "  nspec spec progress --id S002"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    spec_subs = spec_sub.add_subparsers(dest="spec_command")

    # nspec spec create
    spec_create = spec_subs.add_parser("create", help="Create new FR+IMPL spec")
    _add_common_args(spec_create)
    spec_create.add_argument("--title", type=str, required=True, help="Spec title")
    spec_create.add_argument("--priority", type=str, default="P3", help="Priority (P0-P3)")
    spec_create.add_argument("--epic", type=str, help="Target epic ID")
    spec_create.add_argument(
        "--type",
        type=str,
        choices=["spec", "epic"],
        default="spec",
        help="Create a spec (default) or an epic",
    )
    spec_create.add_argument(
        "--set-default",
        action="store_true",
        help="Set the created epic as the default in config (only valid with --type epic)",
    )
    spec_create.set_defaults(handler=handle_create_new)

    # nspec spec delete
    spec_delete = spec_subs.add_parser("delete", help="Delete FR+IMPL spec")
    _add_common_args(spec_delete)
    _add_id_arg(spec_delete)
    _add_force_arg(spec_delete)
    spec_delete.set_defaults(handler=handle_delete)

    # nspec spec complete
    spec_complete = spec_subs.add_parser("complete", help="Archive spec as completed")
    _add_common_args(spec_complete)
    _add_id_arg(spec_complete)
    spec_complete.set_defaults(handler=handle_complete)

    # nspec spec supersede
    spec_supersede = spec_subs.add_parser("supersede", help="Archive spec as superseded")
    _add_common_args(spec_supersede)
    _add_id_arg(spec_supersede)
    spec_supersede.add_argument("--by", help="Spec/epic ID that supersedes this one (e.g., E002)")
    spec_supersede.set_defaults(handler=handle_supersede)

    # nspec spec reject
    spec_reject = spec_subs.add_parser("reject", help="Archive spec as rejected")
    _add_common_args(spec_reject)
    _add_id_arg(spec_reject)
    _add_force_arg(spec_reject)
    spec_reject.set_defaults(handler=handle_reject)

    # nspec spec finalize
    spec_finalize = spec_subs.add_parser("finalize", help="Show spec completion status")
    _add_common_args(spec_finalize)
    _add_id_arg(spec_finalize)
    spec_finalize.add_argument("--execute", action="store_true", help="Execute finalization")
    spec_finalize.set_defaults(handler=handle_finalize)

    # nspec spec progress
    spec_progress = spec_subs.add_parser("progress", help="Show task/AC progress")
    _add_common_args(spec_progress)
    spec_progress.add_argument("--id", type=str, help="Spec ID (omit for summary)")
    spec_progress.add_argument("--all", action="store_true", help="Show all specs")
    spec_progress.set_defaults(handler=_handle_spec_progress)

    # nspec spec deps
    spec_deps = spec_subs.add_parser("deps", help="List dependencies")
    _add_common_args(spec_deps)
    _add_id_arg(spec_deps)
    spec_deps.set_defaults(handler=_handle_spec_deps)

    # nspec spec context
    spec_context = spec_subs.add_parser("context", help="LLM context for epic")
    _add_common_args(spec_context)
    _add_id_arg(spec_context)
    spec_context.set_defaults(handler=_handle_spec_context)

    # -------------------------------------------------------------------------
    # nspec dep <cmd>
    # -------------------------------------------------------------------------
    dep_sub = subparsers.add_parser(
        "dep",
        help="Dependency operations",
        description="Add, remove, and move dependencies between specs and epics.",
        epilog=(
            "Examples:\n"
            "  nspec dep add --to E001 --dep S003\n"
            "  nspec dep remove --to E001 --dep S003\n"
            "  nspec dep move --to E001 --dep S005\n"
            "  nspec dep clean\n"
            "  nspec dep clean --dry-run"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    dep_subs = dep_sub.add_subparsers(dest="dep_command")

    # nspec dep add
    dep_add = dep_subs.add_parser("add", help="Add dependency")
    _add_common_args(dep_add)
    dep_add.add_argument("--to", type=str, required=True, help="Target spec/epic ID")
    dep_add.add_argument("--dep", type=str, required=True, help="Dependency ID")
    dep_add.set_defaults(handler=handle_add_dep)

    # nspec dep remove
    dep_remove = dep_subs.add_parser("remove", help="Remove dependency")
    _add_common_args(dep_remove)
    dep_remove.add_argument("--to", type=str, required=True, help="Target spec/epic ID")
    dep_remove.add_argument("--dep", type=str, required=True, help="Dependency ID")
    dep_remove.set_defaults(handler=handle_remove_dep)

    # nspec dep move
    dep_move = dep_subs.add_parser("move", help="Move spec to epic")
    _add_common_args(dep_move)
    dep_move.add_argument("--to", type=str, required=True, help="Target epic ID")
    dep_move.add_argument("--dep", type=str, required=True, help="Spec ID to move")
    dep_move.set_defaults(handler=handle_move_dep)

    # nspec dep clean
    dep_clean = dep_subs.add_parser("clean", help="Remove dangling dependency references")
    _add_common_args(dep_clean)
    dep_clean.add_argument("--dry-run", action="store_true", help="Show changes without writing")
    dep_clean.set_defaults(handler=handle_dep_clean)

    # -------------------------------------------------------------------------
    # nspec task <cmd>
    # -------------------------------------------------------------------------
    task_sub = subparsers.add_parser(
        "task",
        help="Task and property operations",
        description="Check off tasks/criteria, set priority, LOE, and advance status.",
        epilog=(
            "Examples:\n"
            "  nspec task check --id S002 --task-id 1.1\n"
            "  nspec task criteria --id S002 --criteria-id AC-F1\n"
            "  nspec task set-priority --id S002 --priority P0\n"
            "  nspec task next-status --id S002"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    task_subs = task_sub.add_subparsers(dest="task_command")

    # nspec task check
    task_check = task_subs.add_parser("check", help="Mark task complete/obsolete")
    _add_common_args(task_check)
    _add_id_arg(task_check)
    task_check.add_argument("--task-id", type=str, required=True, help="Task ID (e.g., 1.1)")
    task_check.add_argument(
        "--marker",
        type=str,
        default="x",
        choices=["x", "~"],
        help="Marker: x=complete, ~=obsolete",
    )
    task_check.set_defaults(handler=handle_check_task)

    # nspec task criteria
    task_criteria = task_subs.add_parser("criteria", help="Mark criterion complete/obsolete")
    _add_common_args(task_criteria)
    _add_id_arg(task_criteria)
    task_criteria.add_argument(
        "--criteria-id", type=str, required=True, help="Criteria ID (e.g., AC-F1)"
    )
    task_criteria.add_argument(
        "--marker",
        type=str,
        default="x",
        choices=["x", "~"],
        help="Marker: x=complete, ~=obsolete",
    )
    task_criteria.set_defaults(handler=handle_check_criteria)

    # nspec task set-priority
    task_priority = task_subs.add_parser("set-priority", help="Change priority")
    _add_common_args(task_priority)
    _add_id_arg(task_priority)
    task_priority.add_argument("--priority", type=str, required=True, help="Priority (P0-P3)")
    task_priority.set_defaults(handler=handle_set_priority)

    # nspec task set-loe
    task_loe = task_subs.add_parser("set-loe", help="Set LOE estimate")
    _add_common_args(task_loe)
    _add_id_arg(task_loe)
    task_loe.add_argument("--loe", type=str, required=True, help="LOE value (5d, 3w, etc)")
    task_loe.set_defaults(handler=handle_set_loe)

    # nspec task next-status
    task_next = task_subs.add_parser("next-status", help="Advance to next status")
    _add_common_args(task_next)
    _add_id_arg(task_next)
    task_next.set_defaults(handler=handle_next_status)

    # nspec task set-status
    task_status = task_subs.add_parser("set-status", help="Set FR and IMPL status")
    _add_common_args(task_status)
    _add_id_arg(task_status)
    task_status.add_argument("--fr-status", type=int, required=True, help="FR status code")
    task_status.add_argument("--impl-status", type=int, required=True, help="IMPL status code")
    _add_force_arg(task_status)
    task_status.set_defaults(handler=handle_set_status)

    # -------------------------------------------------------------------------
    # nspec session <cmd>
    # -------------------------------------------------------------------------
    session_sub = subparsers.add_parser(
        "session",
        help="Session management",
        description="Manage work sessions: start, log notes, handoff, and sync state.",
        epilog=(
            "Examples:\n"
            "  nspec session start --id S002\n"
            "  nspec session log --id S002 --note 'Fixed parsing bug'\n"
            "  nspec session handoff --id S002\n"
            "  nspec session files --since-commit HEAD~3"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    session_subs = session_sub.add_subparsers(dest="session_command")

    # nspec session start
    session_start = session_subs.add_parser("start", help="Initialize session context")
    _add_common_args(session_start)
    _add_id_arg(session_start)
    session_start.set_defaults(handler=handle_session_start)

    # nspec session log
    session_log = session_subs.add_parser("log", help="Append session note")
    _add_common_args(session_log)
    _add_id_arg(session_log)
    session_log.add_argument("--note", type=str, required=True, help="Note text")
    session_log.set_defaults(handler=handle_session_log)

    # nspec session handoff
    session_handoff = session_subs.add_parser("handoff", help="Generate session handoff")
    _add_common_args(session_handoff)
    _add_id_arg(session_handoff)
    session_handoff.set_defaults(handler=handle_handoff)

    # nspec session sync
    session_sync = session_subs.add_parser("sync", help="Sync spec state")
    _add_common_args(session_sync)
    _add_id_arg(session_sync)
    _add_force_arg(session_sync)
    session_sync.set_defaults(handler=handle_sync)

    # nspec session files
    session_files = session_subs.add_parser("files", help="List modified files")
    _add_common_args(session_files)
    session_files.add_argument("--since-commit", type=str, help="Git ref for comparison")
    session_files.set_defaults(handler=handle_modified_files)

    # -------------------------------------------------------------------------
    # nspec adr <cmd>
    # -------------------------------------------------------------------------
    adr_sub = subparsers.add_parser(
        "adr",
        help="Architecture Decision Records",
        description="Create and list Architecture Decision Records (ADRs).",
        epilog="Examples:\n  nspec adr create --title 'Use argparse over click'\n  nspec adr list",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    adr_subs = adr_sub.add_subparsers(dest="adr_command")

    # nspec adr create
    adr_create = adr_subs.add_parser("create", help="Create new ADR")
    _add_common_args(adr_create)
    adr_create.add_argument("--title", type=str, required=True, help="ADR title")
    adr_create.set_defaults(handler=handle_create_adr)

    # nspec adr list
    adr_list = adr_subs.add_parser("list", help="List all ADRs")
    _add_common_args(adr_list)
    adr_list.set_defaults(handler=handle_list_adrs)

    # -------------------------------------------------------------------------
    # nspec loop-retry <cmd>
    # -------------------------------------------------------------------------
    loop_retry_sub = subparsers.add_parser(
        "loop-retry",
        help="Loop retry tracking",
        description="Track per-spec retry counts for nspec-loop crash resume.",
        epilog=(
            "Examples:\n"
            "  nspec loop-retry increment --id S064 --exit-reason timeout\n"
            "  nspec loop-retry count --id S064\n"
            "  nspec loop-retry clear --id S064\n"
            "  nspec loop-retry list\n"
            "  nspec loop-retry reset"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    loop_retry_subs = loop_retry_sub.add_subparsers(dest="retry_action")

    lr_increment = loop_retry_subs.add_parser("increment", help="Increment retry count")
    _add_common_args(lr_increment)
    _add_id_arg(lr_increment)
    lr_increment.add_argument("--exit-reason", type=str, default="", help="Why the session failed")
    lr_increment.set_defaults(handler=handle_loop_retry)

    lr_count = loop_retry_subs.add_parser("count", help="Show retry count")
    _add_common_args(lr_count)
    _add_id_arg(lr_count)
    lr_count.set_defaults(handler=handle_loop_retry)

    lr_clear = loop_retry_subs.add_parser("clear", help="Clear retry entry for a spec")
    _add_common_args(lr_clear)
    _add_id_arg(lr_clear)
    lr_clear.set_defaults(handler=handle_loop_retry)

    lr_list = loop_retry_subs.add_parser("list", help="List all retry entries")
    _add_common_args(lr_list)
    lr_list.set_defaults(handler=handle_loop_retry)

    lr_reset = loop_retry_subs.add_parser("reset", help="Delete all retry data")
    _add_common_args(lr_reset)
    lr_reset.set_defaults(handler=handle_loop_retry)

    # -------------------------------------------------------------------------
    # nspec config <key>
    # -------------------------------------------------------------------------
    config_sub = subparsers.add_parser(
        "config",
        help="Read config values",
        description="Read configuration values by dotted key path.",
        epilog=(
            "Examples:\n"
            "  nspec config loop.session_timeout\n"
            "  nspec config loop.max_retries\n"
            "  nspec config defaults.epic"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(config_sub)
    config_sub.add_argument("key", type=str, help="Dotted key path (e.g., loop.session_timeout)")
    config_sub.set_defaults(handler=handle_config_get)

    # -------------------------------------------------------------------------
    # nspec queue
    # -------------------------------------------------------------------------
    queue_sub = subparsers.add_parser(
        "queue",
        help="Agent assignment queue for parallel execution",
        description="Manage the work queue for multi-agent parallel spec execution.",
        epilog=(
            "Examples:\n"
            "  nspec queue init --epic E002 --max-agents 5\n"
            "  nspec queue status\n"
            "  nspec queue claim --agent-id worker-1\n"
            "  nspec queue release --agent-id worker-1 --spec-id S042\n"
            "  nspec queue drain"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    queue_subs = queue_sub.add_subparsers(dest="queue_action")

    q_init = queue_subs.add_parser("init", help="Initialize queue from backlog")
    q_init.add_argument("--epic", dest="epic_id", type=str, help="Epic ID to filter specs")
    q_init.add_argument(
        "--max-agents", type=int, default=5, help="Max concurrent agents (default: 5)"
    )
    q_init.add_argument(
        "--lease-ttl", type=int, default=300, help="Lease TTL in seconds (default: 300)"
    )
    q_init.add_argument("--docs-root", type=Path, default=Path("docs"), help="Docs root")
    q_init.add_argument("--project-root", type=Path, default=None, help="Project root")

    q_status = queue_subs.add_parser("status", help="Show queue state")
    q_status.add_argument("--docs-root", type=Path, default=Path("docs"), help="Docs root")
    q_status.add_argument("--project-root", type=Path, default=None, help="Project root")

    q_claim = queue_subs.add_parser("claim", help="Claim next spec")
    q_claim.add_argument("--agent-id", required=True, help="Agent identity")
    q_claim.add_argument("--docs-root", type=Path, default=Path("docs"), help="Docs root")
    q_claim.add_argument("--project-root", type=Path, default=None, help="Project root")

    q_release = queue_subs.add_parser("release", help="Release a claimed spec")
    q_release.add_argument("--agent-id", required=True, help="Agent identity")
    q_release.add_argument("--spec-id", required=True, help="Spec ID to release")
    q_release.add_argument("--reason", type=str, help="Reason for release")
    q_release.add_argument("--completed", action="store_true", help="Mark as completed")
    q_release.add_argument("--docs-root", type=Path, default=Path("docs"), help="Docs root")
    q_release.add_argument("--project-root", type=Path, default=None, help="Project root")

    q_drain = queue_subs.add_parser("drain", help="Show drain status")
    q_drain.add_argument("--docs-root", type=Path, default=Path("docs"), help="Docs root")
    q_drain.add_argument("--project-root", type=Path, default=None, help="Project root")

    queue_sub.set_defaults(handler=handle_queue)

    # -------------------------------------------------------------------------
    # nspec watchdog
    # -------------------------------------------------------------------------
    watchdog_sub = subparsers.add_parser(
        "watchdog",
        help="Claude Code stall detector & auto-recovery",
        description=(
            "Monitor a tmux session for Claude Code API stalls. "
            "When the token count stops incrementing during active processing, "
            "sends Escape + recovery message to resume."
        ),
        epilog=(
            "Examples:\n"
            "  nspec watchdog --session my-session\n"
            "  nspec watchdog --session my-session --stall-timeout 120\n"
            "  nspec watchdog --stall-timeout 60 --poll-interval 5"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(watchdog_sub)
    watchdog_sub.add_argument(
        "--session", type=str, help="tmux session name (auto-detected if omitted)"
    )
    watchdog_sub.add_argument(
        "--stall-timeout",
        type=int,
        default=None,
        help="Seconds before declaring token stall (default: 180)",
    )
    watchdog_sub.add_argument(
        "--mcp-stall-timeout",
        type=int,
        default=None,
        help="Seconds before declaring MCP tool hang (default: 120)",
    )
    watchdog_sub.add_argument(
        "--poll-interval", type=int, default=None, help="Seconds between polls (default: 15)"
    )
    watchdog_sub.set_defaults(handler=handle_watchdog)

    # -------------------------------------------------------------------------
    # nspec audit
    # -------------------------------------------------------------------------
    audit_sub = subparsers.add_parser(
        "audit",
        help="Run coverage audit with dead-code detection",
        description=(
            "Parse whole-suite coverage artifacts, build candidate inventories\n"
            "of uncovered and suspicious code, and reconcile triage decisions."
        ),
        epilog=(
            "Examples:\n"
            "  nspec audit\n"
            "  nspec audit --strict\n"
            "  nspec audit --coverage-json work/coverage.json --registry work/decisions.json"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(audit_sub)
    audit_sub.add_argument(
        "--coverage-json",
        type=str,
        default="coverage.json",
        help="Path to pytest-cov JSON output (default: coverage.json)",
    )
    audit_sub.add_argument(
        "--registry",
        type=str,
        default="work/coverage_decisions.json",
        help="Path to decision registry JSON (default: work/coverage_decisions.json)",
    )
    audit_sub.add_argument(
        "--strict",
        action="store_true",
        help="Exit non-zero if any candidates are unresolved or stale",
    )
    audit_sub.add_argument(
        "--include",
        type=str,
        default=None,
        help="Comma-separated regex patterns for files to include",
    )
    audit_sub.add_argument(
        "--exclude",
        type=str,
        default=None,
        help="Comma-separated regex patterns for files to exclude",
    )
    audit_sub.set_defaults(handler=handle_audit)

    # -------------------------------------------------------------------------
    # nspec linear <cmd>
    # -------------------------------------------------------------------------
    linear_sub = subparsers.add_parser(
        "linear",
        help="Linear integration (repo -> Linear sync)",
        description="Sync nspec spec state to Linear issues via GraphQL API.",
        epilog=(
            "Examples:\n"
            "  nspec linear push --since HEAD~1\n"
            "  nspec linear push --spec-id S168 --dry-run\n"
            "  nspec linear bootstrap"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    linear_subs = linear_sub.add_subparsers(dest="linear_command")

    # nspec linear push
    linear_push_sub = linear_subs.add_parser(
        "push",
        help="Push nspec state to linked Linear issues",
        description=(
            "Sync spec state to Linear. Reads linear_issue_id from FR headers "
            "and updates the corresponding Linear issues via GraphQL."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(linear_push_sub)
    linear_push_sub.add_argument(
        "--since",
        type=str,
        help="Sync only specs changed since this git ref (e.g., HEAD~1, abc123)",
    )
    linear_push_sub.add_argument(
        "--spec-id",
        type=str,
        help="Sync a single spec by ID",
    )
    linear_push_sub.add_argument(
        "--dry-run",
        action="store_true",
        help="Show planned updates without making API calls",
    )
    linear_push_sub.set_defaults(handler=handle_linear_push)

    # nspec linear bootstrap
    linear_bootstrap_sub = linear_subs.add_parser(
        "bootstrap",
        help="Print config snippet with Linear team/workflow state IDs",
        description=(
            "Query the Linear API for team and workflow state information, "
            "then print a config.toml snippet for the [linear] section."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(linear_bootstrap_sub)
    linear_bootstrap_sub.set_defaults(handler=handle_linear_bootstrap)

    # -------------------------------------------------------------------------
    # nspec status-codes
    # -------------------------------------------------------------------------
    status_codes_sub = subparsers.add_parser(
        "status-codes",
        help="Print FR and IMPL status codes reference",
        description="Print a reference table of all FR and IMPL status codes.",
        epilog="Examples:\n  nspec status-codes",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(status_codes_sub)
    status_codes_sub.set_defaults(handler=_handle_status_codes)

    # -------------------------------------------------------------------------
    # nspec mcp-config
    # -------------------------------------------------------------------------
    mcp_config_sub = subparsers.add_parser(
        "mcp-config",
        help="Print MCP configuration instructions",
        description="Print MCP server configuration instructions for Claude Code integration.",
        epilog="Examples:\n  nspec mcp-config",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(mcp_config_sub)
    mcp_config_sub.set_defaults(handler=handle_mcp_config)

    # Common options on top-level parser for backward compat
    parser.add_argument("--docs-root", type=Path, default=Path("docs"), help="Docs root")
    parser.add_argument(
        "--project-root",
        type=Path,
        default=None,
        help="Project root for .novabuilt.dev/nspec/config.toml (default: parent of --docs-root)",
    )

    return parser


def _handle_status_codes(args) -> int:  # noqa: ARG001
    """Adapter for 'nspec status-codes' subcommand."""
    print_status_codes()
    return 0


def _handle_tui_subcommand(args) -> int:
    """Adapter for 'nspec tui' subcommand."""
    from nspec.tui import main as tui_main

    tui_main(docs_root=args.docs_root, project_root=args.project_root)
    return 0


def _handle_spec_progress(args) -> int:
    """Adapter for 'nspec spec progress' — maps --id to args.progress."""
    args.progress = args.id if args.id else "__summary__"
    return handle_progress(args)


def _handle_spec_deps(args) -> int:
    """Adapter for 'nspec spec deps' — maps --id to args.deps."""
    args.deps = args.id
    return handle_deps(args)


def _handle_spec_context(args) -> int:
    """Adapter for 'nspec spec context' — maps --id to args.context."""
    args.context = args.id
    return handle_context(args)


def main() -> int:
    """Main CLI entry point."""
    # Configure logging
    log_level = logging.DEBUG if os.environ.get("NSPEC_DEBUG") == "Y" else logging.WARNING
    logging.basicConfig(level=log_level, format="%(message)s", stream=sys.stdout)

    parser = build_parser()

    # Enable tab completion if argcomplete is installed
    try:
        import argcomplete

        argcomplete.autocomplete(parser)
    except ImportError:
        pass

    args = parser.parse_args()

    # --tui flag: treat as 'nspec tui' subcommand
    if getattr(args, "tui", False) and not args.command:
        from nspec.tui import main as tui_main

        tui_main(docs_root=Path("docs"))
        return 0

    # Subcommand dispatch (before flag-based dispatch)
    if args.command == "init":
        return handle_init(args)

    # Handler-based dispatch for new subcommands
    if hasattr(args, "handler"):
        if getattr(args, "project_root", None) is None:
            args.project_root = args.docs_root.parent

        # Apply configurable emojis from config.toml
        from nspec.config import NspecConfig
        from nspec.statuses import configure as configure_statuses

        handler_config = NspecConfig.load(args.project_root)
        configure_statuses(handler_config.emojis)

        return args.handler(args)

    # No command specified
    parser.print_help()
    return 1


def _normalize_spec_ref(spec_str: str) -> str:
    """Auto-prefix numeric IDs with 'S'."""
    if not spec_str:
        return spec_str
    spec_str = spec_str.strip()
    if spec_str and spec_str[0].isdigit():
        return "S" + spec_str
    return spec_str


if __name__ == "__main__":
    sys.exit(main())
