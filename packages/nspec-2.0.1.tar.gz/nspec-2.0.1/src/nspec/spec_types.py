"""Pluggable spec format types for nspec.

Defines the SpecType dataclass and SpecTypeRegistry that encapsulate
spec format metadata (naming, statuses, sections, ID ranges). Built-in
types (FR, IMPL, Epic) are registered by default. Custom types can be
added via [spec_types.*] config sections.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from nspec.config import NspecConfig


@dataclass(frozen=True)
class SpecType:
    """A spec format type definition.

    Each SpecType encapsulates everything about a spec format:
    naming convention, status lifecycle, validation rules, and templates.

    Attributes:
        name: Short identifier for the type (e.g., "fr", "impl", "epic", "rfc").
        prefix: Unique type prefix for lookup (e.g., "FR", "IMPL", "E", "RFC").
        id_range: Inclusive (min, max) range for auto-assigned IDs.
        file_pattern: Python format string for filenames. Uses ``{id}`` (int)
            and ``{slug}`` (str) placeholders. Example: ``"FR-S{id:03d}-{slug}.md"``.
        statuses: Ordered list of valid status names for this type's lifecycle.
        initial_status: Default status when a new spec of this type is created.
        required_sections: Markdown section headings that must be present.
        template: Path to a template file relative to project resources,
            or None to use built-in templates.
        paired_with: Names of companion SpecTypes created alongside this one.
            For example, FR has ``["impl"]`` because creating an FR also creates
            its IMPL counterpart.
        directory: Relative directory (from docs_root) where files of this type live.
    """

    name: str
    prefix: str
    id_range: tuple[int, int]
    file_pattern: str
    statuses: tuple[str, ...]
    initial_status: str
    required_sections: tuple[str, ...]
    template: str | None = None
    paired_with: tuple[str, ...] = ()
    directory: str = ""

    def format_filename(self, id_num: int, slug: str) -> str:
        """Generate a filename from the file_pattern.

        Args:
            id_num: Numeric portion of the spec ID.
            slug: Slugified title.

        Returns:
            Complete filename (e.g., ``"FR-S044-search-feature.md"``).
        """
        return self.file_pattern.format(id=id_num, slug=slug)


class SpecTypeRegistry:
    """Registry mapping type names to SpecType instances.

    Initialized with built-in types via ``default_registry()``.
    Custom types from ``[spec_types.*]`` config are merged in after.
    """

    def __init__(self) -> None:
        self._types: dict[str, SpecType] = {}

    def register(self, spec_type: SpecType) -> None:
        """Register a SpecType (replaces any existing type with the same name)."""
        self._types[spec_type.name] = spec_type

    def get(self, name: str) -> SpecType:
        """Get a SpecType by name.

        Args:
            name: Type name (e.g., "fr", "impl", "epic").

        Returns:
            The matching SpecType.

        Raises:
            KeyError: If no type with this name is registered.
        """
        try:
            return self._types[name]
        except KeyError:
            available = ", ".join(sorted(self._types.keys()))
            raise KeyError(f"Unknown spec type: {name!r}. Available types: {available}") from None

    def get_by_prefix(self, prefix: str) -> SpecType:
        """Get a SpecType by its prefix.

        Args:
            prefix: Type prefix (e.g., "FR", "IMPL", "E").

        Returns:
            The matching SpecType.

        Raises:
            KeyError: If no type with this prefix is registered.
        """
        for spec_type in self._types.values():
            if spec_type.prefix == prefix:
                return spec_type
        available = ", ".join(sorted(st.prefix for st in self._types.values()))
        raise KeyError(
            f"No spec type with prefix: {prefix!r}. Available prefixes: {available}"
        ) from None

    def all(self) -> list[SpecType]:
        """Return all registered SpecTypes."""
        return list(self._types.values())

    def __contains__(self, name: str) -> bool:
        return name in self._types

    def __len__(self) -> int:
        return len(self._types)


# ── Built-in type definitions ──────────────────────────────────────────

BUILTIN_FR = SpecType(
    name="fr",
    prefix="FR",
    id_range=(1, 899),
    file_pattern="FR-S{id:03d}-{slug}.md",
    statuses=("Proposed", "In Design", "Active", "Completed", "Rejected", "Superseded", "Deferred"),
    initial_status="Proposed",
    required_sections=("Acceptance Criteria",),
    template=None,
    paired_with=("impl",),
    directory="frs/active",
)

BUILTIN_IMPL = SpecType(
    name="impl",
    prefix="IMPL",
    id_range=(1, 899),
    file_pattern="IMPL-S{id:03d}-{slug}.md",
    statuses=("Planning", "Active", "Testing", "Ready", "Paused", "Hold", "Exception"),
    initial_status="Planning",
    required_sections=("Tasks",),
    template=None,
    paired_with=(),
    directory="impls/active",
)

BUILTIN_EPIC = SpecType(
    name="epic",
    prefix="E",
    id_range=(1, 99),
    file_pattern="FR-E{id:03d}-{slug}.md",
    statuses=("Proposed", "In Design", "Active", "Completed", "Rejected", "Superseded", "Deferred"),
    initial_status="Proposed",
    required_sections=("Acceptance Criteria",),
    template=None,
    paired_with=("impl",),
    directory="frs/active",
)


# ── Registry factory ───────────────────────────────────────────────────


def default_registry(config: NspecConfig | None = None) -> SpecTypeRegistry:
    """Create a registry with built-in types, optionally customized by config.

    When a config is provided:
    - Built-in id_ranges are overridden from ``[id_ranges]``.
    - Custom types from ``[spec_types.*]`` sections are merged in.

    Args:
        config: Optional NspecConfig for id_range overrides and custom types.

    Returns:
        SpecTypeRegistry populated with built-in (and optionally custom) types.
    """
    registry = SpecTypeRegistry()

    if config is not None:
        ranges = config.id_ranges
        # Override built-in id_ranges from config
        fr = SpecType(
            name=BUILTIN_FR.name,
            prefix=BUILTIN_FR.prefix,
            id_range=(ranges.spec_min, ranges.spec_max),
            file_pattern=BUILTIN_FR.file_pattern,
            statuses=BUILTIN_FR.statuses,
            initial_status=BUILTIN_FR.initial_status,
            required_sections=BUILTIN_FR.required_sections,
            template=BUILTIN_FR.template,
            paired_with=BUILTIN_FR.paired_with,
            directory=config.paths.feature_requests,
        )
        impl = SpecType(
            name=BUILTIN_IMPL.name,
            prefix=BUILTIN_IMPL.prefix,
            id_range=(ranges.spec_min, ranges.spec_max),
            file_pattern=BUILTIN_IMPL.file_pattern,
            statuses=BUILTIN_IMPL.statuses,
            initial_status=BUILTIN_IMPL.initial_status,
            required_sections=BUILTIN_IMPL.required_sections,
            template=BUILTIN_IMPL.template,
            paired_with=BUILTIN_IMPL.paired_with,
            directory=config.paths.implementation,
        )
        epic = SpecType(
            name=BUILTIN_EPIC.name,
            prefix=BUILTIN_EPIC.prefix,
            id_range=(ranges.epic_min, ranges.epic_max),
            file_pattern=BUILTIN_EPIC.file_pattern,
            statuses=BUILTIN_EPIC.statuses,
            initial_status=BUILTIN_EPIC.initial_status,
            required_sections=BUILTIN_EPIC.required_sections,
            template=BUILTIN_EPIC.template,
            paired_with=BUILTIN_EPIC.paired_with,
            directory=config.paths.feature_requests,
        )
        registry.register(fr)
        registry.register(impl)
        registry.register(epic)

        # Merge custom types from [spec_types.*] config
        _load_custom_types(registry, config)
    else:
        registry.register(BUILTIN_FR)
        registry.register(BUILTIN_IMPL)
        registry.register(BUILTIN_EPIC)

    return registry


def _load_custom_types(registry: SpecTypeRegistry, config: NspecConfig) -> None:
    """Load custom SpecTypes from ``[spec_types.*]`` config sections.

    Validates that custom types don't have overlapping id_ranges with
    existing types (unless they override a built-in by name).

    Args:
        registry: Registry to add custom types to.
        config: NspecConfig with parsed spec_types.

    Raises:
        ValueError: If a custom type has missing required fields or
            overlapping id_range with another type.
    """
    if not hasattr(config, "spec_types") or not config.spec_types:
        return

    for name, type_config in config.spec_types.items():
        # Validate required fields
        required = ("prefix", "id_range", "file_pattern", "statuses", "initial_status")
        missing = [f for f in required if f not in type_config]
        if missing:
            raise ValueError(
                f"Custom spec type {name!r} missing required fields: {', '.join(missing)}"
            )

        id_range = tuple(type_config["id_range"])
        if len(id_range) != 2:
            raise ValueError(
                f"Custom spec type {name!r}: id_range must be [min, max], "
                f"got {type_config['id_range']}"
            )

        # Check for overlapping id_range — only for genuinely NEW types.
        # When replacing an existing type by name, skip: the user is
        # intentionally overriding, and built-in types share ID ranges
        # by design (FR/IMPL/Epic all overlap).
        is_replacement = name in registry
        if not is_replacement:
            for existing in registry.all():
                # Paired types intentionally share an ID range
                if name in existing.paired_with or existing.name in type_config.get(
                    "paired_with", []
                ):
                    continue
                e_min, e_max = existing.id_range
                n_min, n_max = id_range
                if n_min <= e_max and n_max >= e_min:
                    raise ValueError(
                        f"Custom spec type {name!r} id_range {list(id_range)} overlaps "
                        f"with {existing.name!r} id_range {list(existing.id_range)}"
                    )

        spec_type = SpecType(
            name=name,
            prefix=type_config["prefix"],
            id_range=(int(id_range[0]), int(id_range[1])),
            file_pattern=type_config["file_pattern"],
            statuses=tuple(type_config["statuses"]),
            initial_status=type_config["initial_status"],
            required_sections=tuple(type_config.get("required_sections", [])),
            template=type_config.get("template"),
            paired_with=tuple(type_config.get("paired_with", [])),
            directory=type_config.get("directory", ""),
        )
        registry.register(spec_type)
