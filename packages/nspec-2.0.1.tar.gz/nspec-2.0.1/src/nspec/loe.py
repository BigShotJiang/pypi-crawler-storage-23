"""LOE estimation algorithm for spec sizing.

Deterministic estimator that scores specs from task structure, dependency
load, and content-based complexity signals. Optionally calibrates weights
from completed-spec history.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from nspec.tasks import Task
    from nspec.validators import FRMetadata, IMPLMetadata


# ---------------------------------------------------------------------------
# Domain models
# ---------------------------------------------------------------------------


@dataclass
class LoeWeights:
    """Tunable weights for each scoring factor."""

    task_count: float = 1.0
    max_depth: float = 2.0
    nested_ratio: float = 1.5
    dep_count: float = 1.5
    complexity_signal: float = 3.0

    # Historical calibration minimum
    min_history_specs: int = 10


@dataclass
class LoeFactor:
    """Single contributing factor in the estimate breakdown."""

    name: str
    raw_value: float  # The measured value (e.g., task_count=12)
    weight: float  # The weight applied
    contribution: float  # raw_value * weight

    @property
    def description(self) -> str:
        return (
            f"{self.name}: {self.raw_value:.1f} "
            f"(weight {self.weight:.1f}, +{self.contribution:.1f})"
        )


# Bucket thresholds: (max_score, bucket_label, loe_string)
BUCKET_THRESHOLDS: list[tuple[float, str, str]] = [
    (10.0, "S", "0.5d"),
    (25.0, "M", "1d"),
    (50.0, "L", "2d"),
    (80.0, "XL", "3d"),
]
# Anything above the last threshold
BUCKET_OVERFLOW = ("XXL", "5d")


@dataclass
class LoeEstimate:
    """Result of LOE estimation for a spec."""

    spec_id: str
    score: float
    bucket: str  # S, M, L, XL, XXL
    estimated_loe: str  # e.g., "1d", "3d"
    factors: list[LoeFactor]
    calibrated: bool  # True if historical calibration was used

    @property
    def top_factors(self) -> list[LoeFactor]:
        """Top 3 contributing factors, sorted by contribution descending."""
        return sorted(self.factors, key=lambda f: f.contribution, reverse=True)[:3]

    @property
    def explanation(self) -> str:
        """Human-readable explanation of the estimate."""
        parts = [f"LOE estimate: {self.bucket} ({self.estimated_loe}), score={self.score:.1f}"]
        parts.append("Top factors:")
        for f in self.top_factors:
            parts.append(f"  - {f.description}")
        if self.calibrated:
            parts.append("(weights calibrated from historical data)")
        return "\n".join(parts)

    def to_dict(self) -> dict:
        """Serialize to dict for MCP response."""
        return {
            "spec_id": self.spec_id,
            "score": round(self.score, 1),
            "bucket": self.bucket,
            "estimated_loe": self.estimated_loe,
            "calibrated": self.calibrated,
            "factors": [
                {
                    "name": f.name,
                    "raw_value": round(f.raw_value, 2),
                    "weight": round(f.weight, 2),
                    "contribution": round(f.contribution, 2),
                }
                for f in self.factors
            ],
            "top_factors": [
                {
                    "name": f.name,
                    "raw_value": round(f.raw_value, 2),
                    "contribution": round(f.contribution, 2),
                    "description": f.description,
                }
                for f in self.top_factors
            ],
            "explanation": self.explanation,
        }


# ---------------------------------------------------------------------------
# Feature extraction
# ---------------------------------------------------------------------------

# Complexity signal patterns (case-insensitive)
_COMPLEXITY_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    (
        "external_integration",
        re.compile(r"\b(?:api|external|third.?party|webhook|oauth|http)\b", re.I),
    ),
    (
        "migration",
        re.compile(r"\b(?:migrat|schema.?change|data.?transform|backward.?compat)\b", re.I),
    ),
    (
        "cross_module",
        re.compile(r"\b(?:cross.?module|refactor|breaking.?change|multiple.?files)\b", re.I),
    ),
]


def _extract_task_features(tasks: list[Task]) -> dict[str, float]:
    """Extract task-structure features from parsed IMPL tasks."""
    if not tasks:
        return {
            "task_count": 0.0,
            "root_count": 0.0,
            "max_depth": 0.0,
            "nested_ratio": 0.0,
        }

    total = 0
    root_count = 0
    max_depth = 0

    def _walk(task_list: list[Task], depth: int = 0) -> None:
        nonlocal total, root_count, max_depth
        for t in task_list:
            total += 1
            if depth == 0:
                root_count += 1
            if depth > max_depth:
                max_depth = depth
            _walk(t.children, depth + 1)

    _walk(tasks)

    nested_ratio = (total - root_count) / root_count if root_count > 0 else 0.0

    return {
        "task_count": float(total),
        "root_count": float(root_count),
        "max_depth": float(max_depth),
        "nested_ratio": nested_ratio,
    }


def _extract_dep_count(fr: FRMetadata) -> float:
    """Count declared dependencies from FR metadata."""
    return float(len(fr.deps))


def _detect_complexity_signals(fr: FRMetadata, impl: IMPLMetadata) -> dict[str, bool]:
    """Detect complexity signals from spec text content."""
    # Read the actual file contents for richer signal detection
    text_parts: list[str] = [fr.title]
    if fr.path.exists():
        text_parts.append(fr.path.read_text(encoding="utf-8"))
    if impl.path.exists():
        text_parts.append(impl.path.read_text(encoding="utf-8"))
    text = "\n".join(text_parts)

    return {name: bool(pattern.search(text)) for name, pattern in _COMPLEXITY_PATTERNS}


# ---------------------------------------------------------------------------
# Historical calibration
# ---------------------------------------------------------------------------


def _parse_loe_hours(loe_str: str) -> float | None:
    """Parse LOE string to hours. Returns None if unparseable."""
    loe = loe_str.strip().lower()
    match = re.match(r"^(\d+(?:\.\d+)?)\s*(h|d|w)$", loe)
    if not match:
        return None
    value = float(match.group(1))
    unit = match.group(2)
    if unit == "h":
        return value
    if unit == "d":
        return value * 8.0
    if unit == "w":
        return value * 40.0
    return None


def calibrate_weights(
    base_weights: LoeWeights,
    completed_impls: dict[str, IMPLMetadata],
    completed_frs: dict[str, FRMetadata],
) -> tuple[LoeWeights, bool]:
    """Calibrate weights from completed spec history.

    If enough completed specs have valid LOE data, compute multipliers
    that adjust base weights toward observed outcomes. Otherwise return
    base weights unchanged.

    Returns:
        (calibrated_weights, was_calibrated)
    """
    # Collect completed specs with valid LOE and tasks
    samples: list[tuple[float, float]] = []  # (actual_hours, predicted_score)

    for spec_id, impl in completed_impls.items():
        actual_hours = _parse_loe_hours(impl.loe)
        if actual_hours is None or actual_hours <= 0:
            continue
        fr = completed_frs.get(spec_id)
        if fr is None:
            continue

        # Compute raw score with base weights for this completed spec
        features = _extract_task_features(impl.tasks)
        dep_count = _extract_dep_count(fr)
        signals = _detect_complexity_signals(fr, impl)
        score = _compute_raw_score(features, dep_count, signals, base_weights)
        if score > 0:
            samples.append((actual_hours, score))

    if len(samples) < base_weights.min_history_specs:
        return base_weights, False

    # Simple calibration: compute ratio of actual hours to predicted scores
    # and use median ratio as a global multiplier
    ratios = [actual / predicted for actual, predicted in samples]
    ratios.sort()
    median_idx = len(ratios) // 2
    global_multiplier = ratios[median_idx]

    # Clamp multiplier to reasonable range
    global_multiplier = max(0.5, min(3.0, global_multiplier))

    return LoeWeights(
        task_count=base_weights.task_count * global_multiplier,
        max_depth=base_weights.max_depth * global_multiplier,
        nested_ratio=base_weights.nested_ratio * global_multiplier,
        dep_count=base_weights.dep_count * global_multiplier,
        complexity_signal=base_weights.complexity_signal * global_multiplier,
        min_history_specs=base_weights.min_history_specs,
    ), True


# ---------------------------------------------------------------------------
# Scoring
# ---------------------------------------------------------------------------


def _compute_raw_score(
    features: dict[str, float],
    dep_count: float,
    signals: dict[str, bool],
    weights: LoeWeights,
) -> float:
    """Compute raw numeric score from extracted features."""
    score = 0.0
    score += features["task_count"] * weights.task_count
    score += features["max_depth"] * weights.max_depth
    score += features["nested_ratio"] * weights.nested_ratio
    score += dep_count * weights.dep_count
    signal_count = sum(1 for v in signals.values() if v)
    score += signal_count * weights.complexity_signal
    return score


def _score_to_bucket(score: float) -> tuple[str, str]:
    """Map score to (bucket, estimated_loe)."""
    for threshold, bucket, loe in BUCKET_THRESHOLDS:
        if score <= threshold:
            return bucket, loe
    return BUCKET_OVERFLOW


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def estimate_spec_loe(
    spec_id: str,
    fr: FRMetadata,
    impl: IMPLMetadata,
    weights: LoeWeights | None = None,
    completed_impls: dict[str, IMPLMetadata] | None = None,
    completed_frs: dict[str, FRMetadata] | None = None,
) -> LoeEstimate:
    """Estimate LOE for a spec.

    Args:
        spec_id: The spec ID being estimated.
        fr: Parsed FR metadata for the spec.
        impl: Parsed IMPL metadata for the spec.
        weights: Base weights (defaults to LoeWeights()).
        completed_impls: Completed IMPL data for calibration.
        completed_frs: Completed FR data for calibration.

    Returns:
        LoeEstimate with score, bucket, and factor breakdown.
    """
    base_weights = weights or LoeWeights()

    # Attempt historical calibration
    calibrated = False
    effective_weights = base_weights
    if completed_impls and completed_frs:
        effective_weights, calibrated = calibrate_weights(
            base_weights, completed_impls, completed_frs
        )

    # Extract features
    features = _extract_task_features(impl.tasks)
    dep_count = _extract_dep_count(fr)
    signals = _detect_complexity_signals(fr, impl)

    # Build factor list
    factors: list[LoeFactor] = []

    tc = features["task_count"] * effective_weights.task_count
    factors.append(
        LoeFactor("task_count", features["task_count"], effective_weights.task_count, tc)
    )

    md = features["max_depth"] * effective_weights.max_depth
    factors.append(LoeFactor("max_depth", features["max_depth"], effective_weights.max_depth, md))

    nr = features["nested_ratio"] * effective_weights.nested_ratio
    factors.append(
        LoeFactor("nested_ratio", features["nested_ratio"], effective_weights.nested_ratio, nr)
    )

    dc = dep_count * effective_weights.dep_count
    factors.append(LoeFactor("dep_count", dep_count, effective_weights.dep_count, dc))

    signal_count = float(sum(1 for v in signals.values() if v))
    cs = signal_count * effective_weights.complexity_signal
    factors.append(
        LoeFactor("complexity_signals", signal_count, effective_weights.complexity_signal, cs)
    )

    score = sum(f.contribution for f in factors)
    bucket, estimated_loe = _score_to_bucket(score)

    return LoeEstimate(
        spec_id=spec_id,
        score=score,
        bucket=bucket,
        estimated_loe=estimated_loe,
        factors=factors,
        calibrated=calibrated,
    )
