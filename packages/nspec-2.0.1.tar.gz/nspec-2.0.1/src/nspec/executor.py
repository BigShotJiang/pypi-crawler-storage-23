"""Agent executor plugin interface for dispatching prompts to backends.

Resolves agent names from the ``[agents]`` config section to concrete
executor implementations. Three built-in backends:

- ``subprocess:codex`` — spawns the ``codex`` CLI via tmux (default for codex)
- ``mcp:<server>`` — returns prompt for external MCP passthrough
- ``self`` — no-op, the current session handles it

Usage::

    from nspec.config import NspecConfig
    from nspec.executor import resolve_executor

    config = NspecConfig.load()
    executor = resolve_executor("codex", config)
    result = executor.execute("Review this code...")
    if result.success:
        print(result.output)
"""

from __future__ import annotations

import logging
import os
import subprocess
import time
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Protocol, runtime_checkable

from nspec import tmux
from nspec.config import NspecConfig

logger = logging.getLogger("nspec.executor")


@dataclass
class ExecutorResult:
    """Result from an agent executor invocation."""

    success: bool
    output: str  # Raw response text
    error: str = ""  # Error message on failure
    duration_s: float = 0.0


@runtime_checkable
class AgentExecutor(Protocol):
    """Execute a prompt and return the response text."""

    def execute(self, prompt: str, *, timeout: int = 600, **kwargs: Any) -> ExecutorResult: ...


@dataclass
class CodexTmuxExecutor:
    """Spawns the ``codex`` CLI inside a tmux session.

    Preferred execution path: spawn codex in a detached tmux session,
    poll for completion by watching the pane output, and capture the
    full output on exit. Falls back to ``subprocess.run()`` when tmux
    is not available (e.g. in containers).

    Pulls defaults from ``[codex]`` and ``[review]`` config sections.
    """

    model: str = "gpt-5.3-codex"
    reasoning_effort: str = "medium"
    sandbox: str = "workspace-write"
    approval_policy: str = "on-request"
    flags: list[str] = field(default_factory=lambda: ["--full-auto"])
    default_timeout: int = 600
    poll_interval: float = 2.0
    session_prefix: str = "nspec-codex"
    completion_patterns: list[str] = field(default_factory=list)

    def _write_log(self, prompt: str, result: ExecutorResult, model: str) -> None:
        """Write codex invocation to work/logs/ for debugging and audit."""
        try:
            log_dir = Path("work/logs")
            log_dir.mkdir(parents=True, exist_ok=True)
            ts = datetime.now(tz=UTC).strftime("%Y%m%d-%H%M%S")
            log_path = log_dir / f"codex-{ts}.md"
            status = "SUCCESS" if result.success else "FAILED"
            lines = [
                f"# Codex Execution Log — {status}",
                "",
                f"**Timestamp:** {datetime.now(tz=UTC).isoformat()}",
                f"**Model:** {model}",
                f"**Duration:** {result.duration_s:.1f}s",
                f"**Success:** {result.success}",
                "",
                "## Prompt",
                "",
                "```",
                prompt[:5000] + ("\n... (truncated)" if len(prompt) > 5000 else ""),
                "```",
                "",
                "## Output",
                "",
                "```",
                result.output or "(empty)",
                "```",
                "",
            ]
            if result.error:
                lines.extend(
                    [
                        "## Error",
                        "",
                        "```",
                        result.error,
                        "```",
                        "",
                    ]
                )
            log_path.write_text("\n".join(lines))
            logger.info("Codex log written to %s", log_path)
        except Exception:
            logger.debug("Failed to write codex log", exc_info=True)

    def _build_command(self, prompt: str, **kwargs: Any) -> tuple[list[str], str]:
        """Build the codex CLI command and return (cmd, model)."""
        model = kwargs.get("model", self.model)
        reasoning_effort = kwargs.get("reasoning_effort", self.reasoning_effort)
        sandbox = kwargs.get("sandbox", self.sandbox)
        approval_policy = kwargs.get("approval_policy", self.approval_policy)
        raw_flags = kwargs.get("flags", self.flags)
        if raw_flags is None:
            flags: list[str] = []
        elif isinstance(raw_flags, list | tuple) and all(
            isinstance(flag, str) for flag in raw_flags
        ):
            flags = list(raw_flags)
        else:
            raise TypeError("flags must be a list of strings")

        cmd = [
            "codex",
            "exec",
            "--model",
            model,
            "-c",
            f'model_reasoning_effort="{reasoning_effort}"',
            "-c",
            f'sandbox_mode="{sandbox}"',
            "-c",
            f'approval_policy="{approval_policy}"',
        ]
        cmd.extend(flags)
        cmd.append(prompt)
        return cmd, model

    def _generate_session_name(self) -> str:
        """Generate a unique tmux session name."""
        return f"{self.session_prefix}-{os.getpid()}-{int(time.time())}"

    def _check_completion(self, content: str) -> bool:
        """Check if pane content matches any completion pattern."""
        if not self.completion_patterns:
            return False
        return any(pattern in content for pattern in self.completion_patterns)

    def _execute_tmux(
        self, prompt: str, *, effective_timeout: int, **kwargs: Any
    ) -> ExecutorResult:
        """Execute via tmux: spawn session, poll for completion, capture output."""
        cmd, model = self._build_command(prompt, **kwargs)
        session_name = self._generate_session_name()

        # Build shell command string — pipe through cat to prevent pager
        shell_cmd = _shell_escape(cmd)

        logger.info(
            "Executing codex via tmux session %s: model=%s, timeout=%ds",
            session_name,
            model,
            effective_timeout,
        )
        start = time.monotonic()

        try:
            tmux.new_session(session_name, shell_cmd, remain_on_exit=True)
        except tmux.TmuxError as exc:
            exec_result = ExecutorResult(
                success=False,
                output="",
                error=f"Failed to create tmux session: {exc}",
                duration_s=0.0,
            )
            self._write_log(prompt, exec_result, model)
            return exec_result

        captured_output = ""
        try:
            while True:
                time.sleep(self.poll_interval)
                elapsed = time.monotonic() - start

                # Check if session still exists at all
                session_exists = tmux.has_session(session_name)

                if not session_exists:
                    # Session completely gone (no remain-on-exit).
                    # Return whatever we captured last.
                    duration = time.monotonic() - start
                    output = captured_output.strip()
                    if output:
                        logger.info("Codex tmux session completed in %.1fs", duration)
                        exec_result = ExecutorResult(
                            success=True,
                            output=output,
                            duration_s=duration,
                        )
                    else:
                        exec_result = ExecutorResult(
                            success=False,
                            output="",
                            error="Codex session exited with no output",
                            duration_s=duration,
                        )
                    self._write_log(prompt, exec_result, model)
                    return exec_result

                # Check if the process inside the pane has exited
                # (pane stays alive due to remain-on-exit)
                pane_dead = tmux.is_pane_dead(session_name)

                if pane_dead:
                    # Process exited but pane is still alive — do a final
                    # capture with full scrollback history to grab everything
                    duration = time.monotonic() - start
                    try:
                        final_output = tmux.capture_pane(session_name, history=True).strip()
                    except tmux.TmuxError:
                        final_output = captured_output.strip()

                    tmux.kill_session(session_name)

                    if final_output:
                        logger.info(
                            "Codex tmux session completed in %.1fs (final capture: %d chars)",
                            duration,
                            len(final_output),
                        )
                        exec_result = ExecutorResult(
                            success=True,
                            output=final_output,
                            duration_s=duration,
                        )
                    else:
                        exec_result = ExecutorResult(
                            success=False,
                            output="",
                            error="Codex session exited with no output",
                            duration_s=duration,
                        )
                    self._write_log(prompt, exec_result, model)
                    return exec_result

                # Process still running — capture current pane content
                try:
                    content = tmux.capture_pane(session_name, history=True)
                    captured_output = content
                except tmux.TmuxError:
                    continue  # transient capture failure

                # Check for completion patterns
                if self._check_completion(content):
                    duration = time.monotonic() - start
                    logger.info(
                        "Codex completion pattern matched in %.1fs",
                        duration,
                    )
                    tmux.kill_session(session_name)
                    exec_result = ExecutorResult(
                        success=True,
                        output=content.strip(),
                        duration_s=duration,
                    )
                    self._write_log(prompt, exec_result, model)
                    return exec_result

                # Check timeout
                if effective_timeout > 0 and elapsed > effective_timeout:
                    duration = time.monotonic() - start
                    logger.warning("Codex tmux session timed out after %.1fs", duration)
                    tmux.kill_session(session_name)
                    exec_result = ExecutorResult(
                        success=False,
                        output=captured_output.strip(),
                        error=f"Codex timed out after {effective_timeout}s",
                        duration_s=duration,
                    )
                    self._write_log(prompt, exec_result, model)
                    return exec_result
        finally:
            # Always cleanup
            tmux.kill_session(session_name)

    def _execute_subprocess(
        self, prompt: str, *, effective_timeout: int, **kwargs: Any
    ) -> ExecutorResult:
        """Fallback: execute via subprocess.run() when tmux is unavailable."""
        cmd, model = self._build_command(prompt, **kwargs)

        logger.info(
            "Executing codex subprocess (tmux unavailable): model=%s, timeout=%ds",
            model,
            effective_timeout,
        )
        start = time.monotonic()

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=effective_timeout,
            )
            duration = time.monotonic() - start

            if result.returncode == 0 and result.stdout.strip():
                logger.info("Codex subprocess completed in %.1fs", duration)
                exec_result = ExecutorResult(
                    success=True,
                    output=result.stdout.strip(),
                    duration_s=duration,
                )
                self._write_log(prompt, exec_result, model)
                return exec_result
            else:
                error_text = result.stderr.strip() or f"Exit code {result.returncode}"
                logger.warning(
                    "Codex subprocess failed (rc=%d) in %.1fs: %s",
                    result.returncode,
                    duration,
                    error_text[:200],
                )
                exec_result = ExecutorResult(
                    success=False,
                    output=result.stdout.strip(),
                    error=error_text,
                    duration_s=duration,
                )
                self._write_log(prompt, exec_result, model)
                return exec_result
        except subprocess.TimeoutExpired:
            duration = time.monotonic() - start
            logger.warning("Codex subprocess timed out after %.1fs", duration)
            exec_result = ExecutorResult(
                success=False,
                output="",
                error=f"Codex subprocess timed out after {effective_timeout}s",
                duration_s=duration,
            )
            self._write_log(prompt, exec_result, model)
            return exec_result
        except FileNotFoundError:
            exec_result = ExecutorResult(
                success=False,
                output="",
                error="codex CLI not found. Install it with: npm install -g @openai/codex",
                duration_s=0.0,
            )
            self._write_log(prompt, exec_result, model)
            return exec_result
        except OSError as exc:
            exec_result = ExecutorResult(
                success=False,
                output="",
                error=f"Failed to launch codex subprocess: {exc}",
                duration_s=0.0,
            )
            self._write_log(prompt, exec_result, model)
            return exec_result

    def execute(self, prompt: str, *, timeout: int = 0, **kwargs: Any) -> ExecutorResult:
        """Execute a prompt via the codex CLI.

        Tries tmux first for reliable output capture, falls back to
        subprocess.run() when tmux is unavailable.

        Args:
            prompt: The prompt text to send to codex.
            timeout: Timeout in seconds (0 = use default_timeout).
            **kwargs: Override model/reasoning_effort/sandbox/approval_policy/flags per-call.

        Returns:
            ExecutorResult with the codex output.
        """
        effective_timeout = timeout if timeout > 0 else self.default_timeout

        if tmux.is_available():
            return self._execute_tmux(prompt, effective_timeout=effective_timeout, **kwargs)
        else:
            return self._execute_subprocess(prompt, effective_timeout=effective_timeout, **kwargs)


@dataclass
class McpExecutor:
    """Passthrough executor for external MCP server backends.

    Does not execute the prompt itself — returns it as output so the
    caller can forward it to the appropriate MCP tool.
    """

    server_name: str = "codex-cli"

    def execute(
        self,
        prompt: str,
        *,
        timeout: int = 600,
        **kwargs: Any,  # noqa: ARG002
    ) -> ExecutorResult:
        return ExecutorResult(
            success=True,
            output=prompt,
            error="",
            duration_s=0.0,
        )


@dataclass
class SelfExecutor:
    """No-op executor — the current session handles the prompt."""

    def execute(
        self,
        prompt: str,
        *,
        timeout: int = 600,
        **kwargs: Any,  # noqa: ARG002
    ) -> ExecutorResult:
        return ExecutorResult(
            success=True,
            output=prompt,
            error="",
            duration_s=0.0,
        )


def _shell_escape(cmd: list[str]) -> str:
    """Join a command list into a shell-safe string.

    Uses shlex.join when available, with a fallback for edge cases.
    """
    import shlex

    return shlex.join(cmd)


def resolve_executor(agent_name: str, config: NspecConfig | None = None) -> AgentExecutor:
    """Resolve an agent name to a concrete executor.

    Reads ``config.agents.agents[agent_name]`` to determine the backend.
    Parses the prefix (``subprocess:``, ``mcp:``, ``self``) and returns
    the appropriate executor instance.

    Args:
        agent_name: Logical agent name (e.g., "codex", "claude").
        config: NspecConfig instance. If None, loads from cwd.

    Returns:
        An AgentExecutor implementation.
    """
    if config is None:
        config = NspecConfig.load()

    impl_string = config.agents.agents.get(agent_name, "self")

    if impl_string == "self":
        return SelfExecutor()

    if impl_string.startswith("subprocess:"):
        backend = impl_string.split(":", 1)[1]
        if backend == "codex":
            return CodexTmuxExecutor(
                model=config.codex.model,
                reasoning_effort=config.codex.reasoning_effort,
                sandbox=config.codex.sandbox,
                approval_policy=config.codex.approval_policy,
                flags=config.codex.flags,
                default_timeout=config.review.timeout,
                poll_interval=config.codex.poll_interval,
                session_prefix=config.codex.session_prefix,
            )
        # Unknown subprocess backend — fall through to codex as default
        logger.warning("Unknown subprocess backend %r, defaulting to codex", backend)
        return CodexTmuxExecutor(
            model=config.codex.model,
            reasoning_effort=config.codex.reasoning_effort,
            flags=config.codex.flags,
            default_timeout=config.review.timeout,
            poll_interval=config.codex.poll_interval,
            session_prefix=config.codex.session_prefix,
        )

    if impl_string.startswith("mcp:"):
        server_name = impl_string.split(":", 1)[1]
        return McpExecutor(server_name=server_name)

    # Unknown format — default to MCP passthrough for backward compat
    logger.warning("Unknown agent implementation %r, defaulting to MCP passthrough", impl_string)
    return McpExecutor(server_name=impl_string)
