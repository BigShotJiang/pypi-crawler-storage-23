"""Error-triggered agent spawning plugin system.

Detects tool/command errors during agent sessions and auto-creates
nspec specs for async resolution — turning transient failures into
tracked, actionable work items.
"""

from __future__ import annotations

import logging
import re
import threading
from dataclasses import dataclass
from enum import Enum
from pathlib import Path

logger = logging.getLogger(__name__)

# Thread-local flag to prevent recursion during spec creation
_creating_spec = threading.local()


class ErrorType(Enum):
    """Classification of error sources."""

    SUBPROCESS = "subprocess"
    MCP = "mcp"
    TEST_GATE = "test_gate"
    TIMEOUT = "timeout"


@dataclass
class ErrorContext:
    """Captured error context for spec generation.

    Collects all relevant information about an error occurrence
    to populate a new spec's FR with reproduction details.
    """

    error_type: ErrorType
    command_or_tool: str
    exit_code: int | None = None
    stdout: str = ""
    stderr: str = ""
    error_message: str = ""
    active_spec_id: str | None = None
    active_task_id: str | None = None
    timestamp: str = ""

    def __post_init__(self) -> None:
        if not self.timestamp:
            from nspec.timestamps import now_iso

            self.timestamp = now_iso()


# -- Session-level counter (in-memory, not persisted across restarts) --------

_session_error_count: int = 0
_session_lock = threading.Lock()


def reset_session_counter() -> None:
    """Reset the per-session error spec counter."""
    global _session_error_count
    with _session_lock:
        _session_error_count = 0


def get_session_error_count() -> int:
    """Return the current session error spec count."""
    return _session_error_count


def _increment_session_counter() -> int:
    """Increment and return the new session error spec count."""
    global _session_error_count
    with _session_lock:
        _session_error_count += 1
        return _session_error_count


# -- Detection ---------------------------------------------------------------


def should_trigger(ctx: ErrorContext, docs_root: Path | None = None) -> bool:
    """Decide whether an error should trigger spec creation.

    Checks:
    1. error_agent.enabled is True
    2. The error type matches a configured trigger
    3. The error message doesn't match any ignore pattern
    4. The session hasn't exceeded max_per_session
    """
    from nspec.config import NspecConfig

    cfg = NspecConfig.load(docs_root).error_agent

    if not cfg.enabled:
        return False

    if not cfg.auto_create_spec:
        return False

    # Check trigger type
    triggers = cfg.triggers
    if ctx.error_type == ErrorType.SUBPROCESS and ctx.exit_code not in triggers.exit_codes:
        return False
    if ctx.error_type == ErrorType.MCP and not triggers.mcp_errors:
        return False
    if ctx.error_type == ErrorType.TEST_GATE and not triggers.test_failures:
        return False
    if ctx.error_type == ErrorType.TIMEOUT and not triggers.subprocess_timeout:
        return False

    # Check ignore patterns
    text = f"{ctx.command_or_tool} {ctx.error_message} {ctx.stdout} {ctx.stderr}"
    for pattern in cfg.ignore_patterns:
        try:
            if re.search(pattern, text):
                logger.debug("Error matches ignore pattern %r, skipping", pattern)
                return False
        except re.error:
            logger.warning("Invalid ignore pattern: %r", pattern)

    # Check session cap (hold lock for atomic read to prevent race)
    with _session_lock:
        if _session_error_count >= cfg.max_per_session:
            logger.info(
                "Session error cap reached (%d/%d), skipping spec creation",
                _session_error_count,
                cfg.max_per_session,
            )
            return False

    return True


# -- Spec creation -----------------------------------------------------------


def _generate_title(ctx: ErrorContext) -> str:
    """Generate a descriptive spec title from error context."""
    prefix = {
        ErrorType.SUBPROCESS: "Fix subprocess failure",
        ErrorType.MCP: "Fix MCP tool error",
        ErrorType.TEST_GATE: "Fix test gate failure",
        ErrorType.TIMEOUT: "Fix subprocess timeout",
    }[ctx.error_type]

    # Extract a meaningful suffix from the command/tool
    tool = ctx.command_or_tool
    if len(tool) > 50:
        tool = tool[:47] + "..."

    return f"{prefix}: {tool}"


def _generate_fr_body(ctx: ErrorContext) -> str:
    """Generate FR body content with error reproduction details."""
    lines = [
        "## Error Context",
        "",
        f"- **Error Type:** {ctx.error_type.value}",
        f"- **Command/Tool:** `{ctx.command_or_tool}`",
    ]
    if ctx.exit_code is not None:
        lines.append(f"- **Exit Code:** {ctx.exit_code}")
    if ctx.active_spec_id:
        lines.append(f"- **Active Spec:** {ctx.active_spec_id}")
    if ctx.active_task_id:
        lines.append(f"- **Active Task:** {ctx.active_task_id}")
    lines.append(f"- **Timestamp:** {ctx.timestamp}")

    if ctx.error_message:
        lines += ["", "## Error Message", "", f"```\n{ctx.error_message}\n```"]

    if ctx.stdout:
        stdout = ctx.stdout[-2000:] if len(ctx.stdout) > 2000 else ctx.stdout
        lines += ["", "## stdout (last 2000 chars)", "", f"```\n{stdout}\n```"]

    if ctx.stderr:
        stderr = ctx.stderr[-2000:] if len(ctx.stderr) > 2000 else ctx.stderr
        lines += ["", "## stderr (last 2000 chars)", "", f"```\n{stderr}\n```"]

    lines += [
        "",
        "## Reproduction Steps",
        "",
        "1. This error was auto-captured during an agent session",
        f"2. Run: `{ctx.command_or_tool}`",
        "3. Observe the error output above",
    ]

    return "\n".join(lines)


def create_error_spec(
    ctx: ErrorContext,
    docs_root: Path | None = None,
) -> str | None:
    """Create a new spec from an error context.

    Returns the new spec ID if created, None if skipped (recursion guard).
    """
    # Recursion guard: if we're already creating a spec, bail
    if getattr(_creating_spec, "active", False):
        logger.warning("Recursion guard: already creating an error spec, skipping")
        return None

    _creating_spec.active = True
    try:
        from nspec.config import NspecConfig
        from nspec.crud import add_dependency, create_new_spec

        cfg = NspecConfig.load(docs_root).error_agent
        root = docs_root or Path("docs")

        title = _generate_title(ctx)
        priority = cfg.priority

        _fr_path, _, spec_id = create_new_spec(
            title=title,
            priority=priority,
            docs_root=root,
        )

        # Write error context into the FR
        fr_body = _generate_fr_body(ctx)
        fr_content = _fr_path.read_text()
        # Insert error context after the "## Problem" section placeholder
        # or at the end if no placeholder found
        if "## Problem" in fr_content:
            fr_content = fr_content.replace(
                "## Problem\n",
                f"## Problem\n\n{fr_body}\n",
            )
        else:
            fr_content += f"\n{fr_body}\n"
        _fr_path.write_text(fr_content)

        # Add to configured epic
        if cfg.epic_id:
            try:
                add_dependency(cfg.epic_id, spec_id, root)
            except Exception as e:
                logger.warning("Failed to add %s to epic %s: %s", spec_id, cfg.epic_id, e)

        _increment_session_counter()
        logger.info("Error captured → %s: %r", spec_id, title)

        return spec_id

    except Exception:
        logger.exception("Failed to create error spec")
        return None
    finally:
        _creating_spec.active = False


# -- Auto-park ---------------------------------------------------------------


def _auto_park_if_blocking(
    ctx: ErrorContext,
    error_spec_id: str,
    docs_root: Path | None = None,
) -> bool:
    """Park the active spec if the error is blocking and config says to.

    Returns True if the spec was parked.
    """
    from nspec.config import NspecConfig

    cfg = NspecConfig.load(docs_root).error_agent
    if not cfg.auto_park_on_blocking:
        return False

    if not ctx.active_spec_id:
        return False

    # Only park if the error is from the active spec's task context,
    # not from an unrelated ancillary tool call (e.g., show, epics)
    if not ctx.active_task_id:
        return False

    try:
        from nspec.crud import park_spec

        root = docs_root or Path("docs")
        reason = f"Blocked by error → {error_spec_id}"
        park_spec(ctx.active_spec_id, root, reason=reason)
        logger.info("Auto-parked %s due to blocking error %s", ctx.active_spec_id, error_spec_id)
        return True
    except Exception:
        logger.exception("Failed to auto-park %s", ctx.active_spec_id)
        return False


# -- Public entry point (called from MCP server) ----------------------------


def maybe_capture_error(
    ctx: ErrorContext,
    docs_root: Path | None = None,
) -> dict | None:
    """Main entry point: evaluate an error and optionally create a spec.

    Returns a dict with capture info if a spec was created, None otherwise.
    """
    if not should_trigger(ctx, docs_root):
        return None

    spec_id = create_error_spec(ctx, docs_root)
    if spec_id is None:
        return None

    result: dict = {
        "error_captured": True,
        "spec_id": spec_id,
        "title": _generate_title(ctx),
    }

    # Auto-park if blocking
    if _auto_park_if_blocking(ctx, spec_id, docs_root):
        result["parked_spec"] = ctx.active_spec_id

    return result
