#!/usr/bin/env bash
# nspec-loop — External loop orchestrator for nspec
#
# Spawns fresh Claude sessions per spec, clearing context between specs.
# Each spec gets a completely fresh session — no context accumulation.
#
# Usage:
#   nspec-loop                          # Process entire backlog
#   nspec-loop --max-specs 5            # Limit to 5 specs
#   nspec-loop --epic E001              # Filter to epic
#   nspec-loop --mcp-config path.json   # Custom MCP config

set -euo pipefail

# Defaults
MAX_SPECS=0  # 0 = unlimited
MCP_CONFIG=""
DOCS_ROOT=""
EPIC=""
COMPLETED=0
BLOCKED=0

usage() {
    cat <<'EOF'
nspec-loop — External loop orchestrator for nspec

Spawns fresh Claude Code sessions per spec, clearing context between specs.
Each spec gets a completely fresh session — no context accumulation.

USAGE:
    nspec-loop [OPTIONS]

OPTIONS:
    --max-specs N       Stop after completing N specs (default: unlimited)
    --epic EPIC_ID      Filter to a specific epic (e.g., E001)
    --mcp-config PATH   Path to MCP config JSON (default: auto-detect)
    --docs-root PATH    Path to docs directory (default: docs)
    -h, --help          Show this help message

CONFIGURATION:
    [loop] section in .novabuilt.dev/nspec/config.toml:
      session_timeout = "30m"   # Wall-clock limit per claude session
      max_retries = 3           # Retries before marking spec as Exception

EXAMPLES:
    nspec-loop                          # Process entire backlog
    nspec-loop --max-specs 5            # Complete up to 5 specs
    nspec-loop --epic E001              # Only work on Epic E001
    nspec-loop --mcp-config .mcp.json   # Use specific MCP config
EOF
}

log() {
    echo "[nspec-loop] $*" >&2
}

# Parse arguments
while [[ $# -gt 0 ]]; do
    case "$1" in
        --max-specs)
            if [[ $# -lt 2 ]]; then
                echo "Error: --max-specs requires a numeric argument" >&2
                exit 1
            fi
            MAX_SPECS="$2"
            if ! [[ "$MAX_SPECS" =~ ^[0-9]+$ ]]; then
                echo "Error: --max-specs must be a positive integer, got '$MAX_SPECS'" >&2
                exit 1
            fi
            shift 2
            ;;
        --epic)
            if [[ $# -lt 2 ]]; then
                echo "Error: --epic requires an argument" >&2
                exit 1
            fi
            EPIC="$2"
            shift 2
            ;;
        --mcp-config)
            if [[ $# -lt 2 ]]; then
                echo "Error: --mcp-config requires an argument" >&2
                exit 1
            fi
            MCP_CONFIG="$2"
            shift 2
            ;;
        --docs-root)
            if [[ $# -lt 2 ]]; then
                echo "Error: --docs-root requires an argument" >&2
                exit 1
            fi
            DOCS_ROOT="$2"
            shift 2
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            usage >&2
            exit 1
            ;;
    esac
done

# Auto-detect MCP config if not provided
if [[ -z "$MCP_CONFIG" ]]; then
    if [[ -f ".mcp.json" ]]; then
        MCP_CONFIG=".mcp.json"
    elif [[ -f "$HOME/.claude/mcp.json" ]]; then
        MCP_CONFIG="$HOME/.claude/mcp.json"
    else
        log "WARNING: No MCP config found (.mcp.json or ~/.claude/mcp.json)"
        log "Claude sessions will run without nspec MCP tools"
        log "Use --mcp-config to specify a config file"
    fi
fi

# Detect timeout command (macOS ships without GNU timeout)
TIMEOUT_CMD=""
if command -v timeout &>/dev/null; then
    TIMEOUT_CMD="timeout"
elif command -v gtimeout &>/dev/null; then
    TIMEOUT_CMD="gtimeout"
fi

# Read loop config from nspec config
read_config() {
    local key="$1"
    local default="$2"
    local value
    value=$(nspec config "$key" 2>/dev/null) || true
    if [[ -n "$value" ]]; then
        echo "$value"
    else
        echo "$default"
    fi
}

SESSION_TIMEOUT=$(read_config "loop.session_timeout" "30m")
MAX_RETRIES=$(read_config "loop.max_retries" "3")

# Build nspec next command as an array (safe from word-splitting)
build_next_args() {
    NEXT_ARGS=(next)
    if [[ -n "$EPIC" ]]; then
        NEXT_ARGS+=(--epic "$EPIC")
    fi
    if [[ -n "$DOCS_ROOT" ]]; then
        NEXT_ARGS+=(--docs-root "$DOCS_ROOT")
    fi
}

# Main loop
log "Starting nspec-loop"
[[ -n "$EPIC" ]] && log "Epic filter: $EPIC"
[[ "$MAX_SPECS" -gt 0 ]] && log "Max specs: $MAX_SPECS"
[[ -n "$MCP_CONFIG" ]] && log "MCP config: $MCP_CONFIG"
log "Session timeout: $SESSION_TIMEOUT"
log "Max retries: $MAX_RETRIES"
if [[ -z "$TIMEOUT_CMD" ]]; then
    log "WARNING: No timeout command found (install coreutils for gtimeout on macOS)"
    log "Sessions will run without wall-clock timeout"
fi

build_next_args

while true; do
    # Check max-specs limit
    if [[ "$MAX_SPECS" -gt 0 && "$COMPLETED" -ge "$MAX_SPECS" ]]; then
        log "Reached max-specs limit ($MAX_SPECS)"
        break
    fi

    # Get next spec — capture both stdout and exit code
    log "Running: nspec ${NEXT_ARGS[*]}"
    NEXT_OUTPUT=""
    NEXT_EXIT=0
    NEXT_OUTPUT=$(nspec "${NEXT_ARGS[@]}" 2>&1) || NEXT_EXIT=$?

    if [[ "$NEXT_EXIT" -ne 0 ]]; then
        # Check if this is a "no candidates" result vs a real error
        if echo "$NEXT_OUTPUT" | grep -qi "no unblocked specs"; then
            log "No more unblocked specs — backlog clear (or fully blocked)"
            break
        fi
        # Real error — surface it and exit
        log "ERROR: nspec next failed (exit $NEXT_EXIT):"
        log "$NEXT_OUTPUT"
        exit 1
    fi

    # Extract spec ID (first line of output)
    SPEC_ID=$(echo "$NEXT_OUTPUT" | head -1)
    if [[ -z "$SPEC_ID" ]]; then
        log "No more unblocked specs — backlog clear (or fully blocked)"
        break
    fi

    log "Picked: $SPEC_ID"

    # Build Claude command as array (safe from injection)
    CLAUDE_ARGS=(-p "/go $SPEC_ID")
    if [[ -n "$MCP_CONFIG" ]]; then
        CLAUDE_ARGS+=(--mcp-config "$MCP_CONFIG")
    fi

    log "Spawning: claude ${CLAUDE_ARGS[*]}"

    # Run claude with wall-clock timeout if available
    EXIT_CODE=0
    EXIT_REASON=""
    if [[ -n "$TIMEOUT_CMD" ]]; then
        "$TIMEOUT_CMD" "$SESSION_TIMEOUT" claude "${CLAUDE_ARGS[@]}" || EXIT_CODE=$?
    else
        claude "${CLAUDE_ARGS[@]}" || EXIT_CODE=$?
    fi

    if [[ "$EXIT_CODE" -eq 0 ]]; then
        # Success — clear retry state and count completion
        COMPLETED=$((COMPLETED + 1))
        nspec loop-retry clear --id "$SPEC_ID" 2>/dev/null || true
        log "Session completed successfully (completed=$COMPLETED)"
    else
        # Failure — determine reason and track retry
        if [[ "$EXIT_CODE" -eq 124 ]]; then
            EXIT_REASON="timeout"
            log "Session timed out after $SESSION_TIMEOUT"
        else
            EXIT_REASON="exit:$EXIT_CODE"
            log "Session exited with code $EXIT_CODE"
        fi

        RETRY_COUNT=$(nspec loop-retry increment --id "$SPEC_ID" --exit-reason "$EXIT_REASON" 2>/dev/null) || RETRY_COUNT="?"

        if [[ "$RETRY_COUNT" =~ ^[0-9]+$ ]] && [[ "$RETRY_COUNT" -ge "$MAX_RETRIES" ]]; then
            log "Spec $SPEC_ID exhausted $MAX_RETRIES retries — marking Exception"
            nspec task set-status --id "$SPEC_ID" --fr-status 2 --impl-status 6 --force 2>/dev/null || true
            nspec session log --id "$SPEC_ID" --note "⚠️ EXCEPTION — Exhausted $RETRY_COUNT/$MAX_RETRIES retries (last: $EXIT_REASON)" 2>/dev/null || true
        else
            log "Spec $SPEC_ID retry $RETRY_COUNT/$MAX_RETRIES (reason: $EXIT_REASON)"
        fi

        BLOCKED=$((BLOCKED + 1))
    fi

    log "Progress: completed=$COMPLETED blocked=$BLOCKED"
done

# Summary
log "=== Session Summary ==="
log "Specs completed: $COMPLETED"
log "Specs blocked:   $BLOCKED"
log "======================="

exit 0
