"""Repository layer for TerminusDB CRUD operations.

Provides type-safe repository classes for Spec, Epic, Task, and ADR
documents with filtering, dependency validation, and transaction support.
"""

from __future__ import annotations

from datetime import UTC, datetime

from terminusdb_client import WOQLClient

from nspec.terminusdb.schema import ADR, Epic, Spec, Task


class DocumentNotFoundError(Exception):
    """Raised when a document is not found in the database."""


class CyclicDependencyError(Exception):
    """Raised when adding a dependency would create a cycle."""


class BaseRepository:
    """Base class for document repositories.

    Provides common CRUD operations using WOQLClient's direct methods.
    """

    doc_type: str = ""

    def __init__(self, client: WOQLClient) -> None:
        self.client = client

    def _get_document(self, doc_id: str) -> dict:
        """Fetch a raw document by its full IRI ID."""
        try:
            return self.client.get_document(doc_id)
        except OSError:
            raise  # Let connection errors propagate unwrapped
        except Exception as e:
            raise DocumentNotFoundError(f"{doc_id} not found") from e

    def _get_all(self, **kwargs) -> list[dict]:
        """Get all documents of this repository's type."""
        return list(self.client.get_documents_by_type(self.doc_type, as_list=True, **kwargs))


class SpecRepository(BaseRepository):
    """Type-safe CRUD for Spec documents."""

    doc_type = "Spec"

    def get(self, spec_id: str) -> dict:
        """Fetch spec by ID.

        Args:
            spec_id: Spec identifier (e.g., "S001").

        Returns:
            Spec document as dict.

        Raises:
            DocumentNotFoundError: If spec does not exist.
        """
        return self._get_document(f"Spec/{spec_id}")

    def list(
        self,
        status: str | None = None,
        priority: str | None = None,
        epic_id: str | None = None,
    ) -> list[dict]:
        """Query specs with optional filters.

        Args:
            status: Filter by impl_status value.
            priority: Filter by priority value.
            epic_id: Filter by epic membership.

        Returns:
            List of matching spec documents.
        """
        docs = self._get_all()
        if status:
            docs = [d for d in docs if d.get("impl_status") == status]
        if priority:
            docs = [d for d in docs if d.get("priority") == priority]
        if epic_id:
            # Filter by epic membership via BelongsTo edges
            belongs_to_docs = list(self.client.get_documents_by_type("BelongsTo", as_list=True))
            spec_ids_in_epic = {
                bt["spec_id"] for bt in belongs_to_docs if bt.get("epic_id") == epic_id
            }
            docs = [d for d in docs if d.get("id") in spec_ids_in_epic]
        return docs

    def create(self, spec: Spec) -> None:
        """Insert a new spec document.

        Args:
            spec: Spec document to insert.
        """
        self.client.insert_document(spec, commit_msg=f"Create spec {spec.id}")

    def update(self, spec: Spec) -> None:
        """Update an existing spec document.

        Args:
            spec: Spec document with updated fields.
        """
        spec.updated_at = datetime.now(tz=UTC)
        self.client.update_document(spec, commit_msg=f"Update spec {spec.id}")

    def delete(self, spec_id: str) -> None:
        """Delete a spec and its associated tasks.

        Args:
            spec_id: Spec identifier to delete.
        """
        # Delete associated tasks first
        task_repo = TaskRepository(self.client)
        task_repo.delete_for_spec(spec_id)
        self.client.delete_document(f"Spec/{spec_id}", commit_msg=f"Delete spec {spec_id}")

    def next_unblocked(self, epic_id: str | None = None) -> dict | None:
        """Find highest-priority unblocked spec.

        Returns the spec with highest priority (lowest P-number) that has
        no incomplete dependencies.

        Args:
            epic_id: Optional epic filter.

        Returns:
            Highest-priority unblocked spec, or None if none available.
        """
        specs = self.list(epic_id=epic_id) if epic_id else self._get_all()

        # Filter out completed specs
        specs = [s for s in specs if s.get("impl_status") != "Completed"]

        # Get all dependency edges
        deps = list(self.client.get_documents_by_type("DependsOn", as_list=True))

        # Build dependency map: spec_id -> set of target_ids it depends on
        dep_map: dict[str, set[str]] = {}
        for dep in deps:
            if dep.get("source_type") == "Spec":
                source = dep["source_id"]
                target = dep["target_id"]
                dep_map.setdefault(source, set()).add(target)

        # Build completion set
        all_specs = self._get_all()
        completed_ids = {s["id"] for s in all_specs if s.get("impl_status") == "Completed"}

        # Filter to unblocked specs (all deps completed)
        unblocked = []
        for spec in specs:
            spec_deps = dep_map.get(spec["id"], set())
            if spec_deps.issubset(completed_ids):
                unblocked.append(spec)

        if not unblocked:
            return None

        # Sort by priority (P0 < P1 < P2 < P3)
        priority_order = {"P0": 0, "P1": 1, "P2": 2, "P3": 3}
        unblocked.sort(key=lambda s: priority_order.get(s.get("priority", "P3"), 9))

        return unblocked[0]

    def validate_dependency(self, source_id: str, target_id: str) -> None:
        """Ensure adding a dependency won't create a cycle.

        Checks if there's an existing path from target back to source,
        which would create a circular dependency.

        Args:
            source_id: Source spec ID (the one that depends).
            target_id: Target spec ID (the one depended upon).

        Raises:
            CyclicDependencyError: If adding the dependency creates a cycle.
        """
        if source_id == target_id:
            raise CyclicDependencyError(f"{source_id} cannot depend on itself")

        # Build adjacency list from existing DependsOn edges
        deps = list(self.client.get_documents_by_type("DependsOn", as_list=True))
        adj: dict[str, set[str]] = {}
        for dep in deps:
            adj.setdefault(dep["source_id"], set()).add(dep["target_id"])

        # Add the proposed edge
        adj.setdefault(source_id, set()).add(target_id)

        # BFS from target_id to see if we can reach source_id
        visited: set[str] = set()
        queue = [target_id]
        while queue:
            current = queue.pop(0)
            if current == source_id:
                raise CyclicDependencyError(f"{source_id} -> {target_id} creates a cycle")
            if current in visited:
                continue
            visited.add(current)
            for neighbor in adj.get(current, set()):
                if neighbor not in visited:
                    queue.append(neighbor)


class EpicRepository(BaseRepository):
    """Type-safe CRUD for Epic documents."""

    doc_type = "Epic"

    def get(self, epic_id: str) -> dict:
        """Fetch epic by ID."""
        return self._get_document(f"Epic/{epic_id}")

    def list(self) -> list[dict]:
        """Get all epics."""
        return self._get_all()

    def create(self, epic: Epic) -> None:
        """Insert a new epic."""
        self.client.insert_document(epic, commit_msg=f"Create epic {epic.id}")

    def update(self, epic: Epic) -> None:
        """Update an existing epic."""
        epic.updated_at = datetime.now(tz=UTC)
        self.client.update_document(epic, commit_msg=f"Update epic {epic.id}")

    def delete(self, epic_id: str) -> None:
        """Delete an epic."""
        self.client.delete_document(f"Epic/{epic_id}", commit_msg=f"Delete epic {epic_id}")


class TaskRepository(BaseRepository):
    """Type-safe CRUD for Task documents, scoped to specs."""

    doc_type = "Task"

    def get(self, spec_id: str, task_id: str) -> dict:
        """Fetch task by composite key."""
        return self._get_document(f"Task/{spec_id}/{task_id}")

    def list_for_spec(self, spec_id: str) -> list[dict]:
        """Get all tasks for a given spec."""
        all_tasks = self._get_all()
        return [t for t in all_tasks if t.get("spec_id") == spec_id]

    def create(self, task: Task) -> None:
        """Insert a new task."""
        self.client.insert_document(task, commit_msg=f"Create task {task.spec_id}/{task.task_id}")

    def update(self, task: Task) -> None:
        """Update an existing task."""
        self.client.update_document(task, commit_msg=f"Update task {task.spec_id}/{task.task_id}")

    def delete(self, spec_id: str, task_id: str) -> None:
        """Delete a single task."""
        self.client.delete_document(
            f"Task/{spec_id}/{task_id}",
            commit_msg=f"Delete task {spec_id}/{task_id}",
        )

    def delete_for_spec(self, spec_id: str) -> None:
        """Delete all tasks belonging to a spec."""
        tasks = self.list_for_spec(spec_id)
        if tasks:
            ids = [f"Task/{spec_id}/{t['task_id']}" for t in tasks]
            self.client.delete_document(ids, commit_msg=f"Delete tasks for {spec_id}")


class ADRRepository(BaseRepository):
    """Type-safe CRUD for ADR documents."""

    doc_type = "ADR"

    def get(self, adr_id: str) -> dict:
        """Fetch ADR by ID."""
        return self._get_document(f"ADR/{adr_id}")

    def list(self) -> list[dict]:
        """Get all ADRs."""
        return self._get_all()

    def create(self, adr: ADR) -> None:
        """Insert a new ADR."""
        self.client.insert_document(adr, commit_msg=f"Create ADR {adr.id}")

    def update(self, adr: ADR) -> None:
        """Update an existing ADR."""
        self.client.update_document(adr, commit_msg=f"Update ADR {adr.id}")

    def delete(self, adr_id: str) -> None:
        """Delete an ADR."""
        self.client.delete_document(f"ADR/{adr_id}", commit_msg=f"Delete ADR {adr_id}")


class UnitOfWork:
    """Transaction boundary for multi-document operations.

    Usage::

        with UnitOfWork(client) as uow:
            spec_repo = SpecRepository(uow.client)
            spec_repo.create(spec)
            task_repo = TaskRepository(uow.client)
            task_repo.create(task)
        # Auto-commits on success, rolls back on exception
    """

    def __init__(self, client: WOQLClient) -> None:
        self.client = client

    def __enter__(self) -> UnitOfWork:
        return self

    def __exit__(self, _exc_type, _exc_val, _exc_tb) -> None:
        # WOQLClient operations auto-commit via commit_msg parameter.
        # UnitOfWork provides a logical grouping boundary.
        # True transaction support requires TerminusDB branch operations
        # which will be implemented when needed.
        pass
