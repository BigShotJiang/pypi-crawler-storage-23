"""TerminusDB edge type definitions for entity relationships.

Defines DependsOn, SpecifiedBy, and BelongsTo as TerminusDB
DocumentTemplate subclasses representing graph edges between
core entities (Spec, Epic, Task, ADR from schema.py).

Uses string IDs with type discriminators for polymorphic edges
because terminusdb-client Union types don't serialize correctly.
"""

from __future__ import annotations

from terminusdb_client.schema import DocumentTemplate, LexicalKey


class CardinalityError(Exception):
    """Raised when an edge violates cardinality constraints."""


# Valid source/target type combinations for DependsOn
VALID_DEPENDS_ON = frozenset(
    {
        ("Spec", "Spec"),
        ("Epic", "Epic"),
        ("Epic", "Spec"),
    }
)

# Valid source types for SpecifiedBy
VALID_SPECIFIED_BY_SOURCES = frozenset({"Task", "ADR"})


class DependsOn(DocumentTemplate):
    """Dependency edge between specs or epics.

    Valid source→target combinations:
    - Spec → Spec (spec depends on another spec)
    - Epic → Epic (epic depends on another epic)
    - Epic → Spec (epic requires spec completion)

    INVALID (enforced by validate_edge):
    - Spec → Epic (specs cannot depend on epics; use BelongsTo)

    LexicalKey on (source_id, target_id) ensures each dependency
    pair has a deterministic document ID.
    """

    _key = LexicalKey(["source_id", "target_id"])

    source_id: str  # ID of source entity (S### or E###)
    target_id: str  # ID of target entity (S### or E###)
    source_type: str  # "Spec" or "Epic"
    target_type: str  # "Spec" or "Epic"

    @classmethod
    def validate_edge(cls, source_type: str, target_type: str) -> None:
        """Validate that the source→target type combination is allowed.

        Args:
            source_type: Type of source entity ("Spec" or "Epic").
            target_type: Type of target entity ("Spec" or "Epic").

        Raises:
            CardinalityError: If the combination is invalid.
        """
        pair = (source_type, target_type)
        if pair not in VALID_DEPENDS_ON:
            raise CardinalityError(
                f"{source_type} cannot depend on {target_type}. "
                f"Valid combinations: Spec→Spec, Epic→Epic, Epic→Spec."
            )


class SpecifiedBy(DocumentTemplate):
    """Links tasks and ADRs to their parent spec.

    Valid source→target combinations:
    - Task → Spec (task belongs to a spec)
    - ADR → Spec (ADR documents a spec decision)

    LexicalKey on (source_id, source_type) ensures each source
    entity can only specify one spec (N:1 cardinality).
    """

    _key = LexicalKey(["source_id", "source_type"])

    source_id: str  # ID of source entity (task_id or ADR ID)
    source_type: str  # "Task" or "ADR"
    target_id: str  # Spec ID (always a Spec)

    @classmethod
    def validate_edge(cls, source_type: str) -> None:
        """Validate that the source type is allowed.

        Args:
            source_type: Type of source entity ("Task" or "ADR").

        Raises:
            CardinalityError: If the source type is invalid.
        """
        if source_type not in VALID_SPECIFIED_BY_SOURCES:
            raise CardinalityError(
                f"{source_type} cannot be a SpecifiedBy source. Valid sources: Task, ADR."
            )


class BelongsTo(DocumentTemplate):
    """Epic membership edge (Spec → Epic).

    A spec can belong to at most one epic. This is enforced by
    LexicalKey on spec_id alone — creating a second BelongsTo
    for the same spec_id overwrites the first, naturally enforcing
    1:1 cardinality.
    """

    _key = LexicalKey(["spec_id"])

    spec_id: str  # Spec ID
    epic_id: str  # Epic ID
