"""TerminusDB schema definitions for nspec entities.

Defines document types (Spec, Epic, Task, ADR), edge types
(DependsOn, SpecifiedBy, BelongsTo), enum types, repository
layer, and template engine for the TerminusDB graph database backend.
"""

from nspec.terminusdb.edges import BelongsTo, CardinalityError, DependsOn, SpecifiedBy
from nspec.terminusdb.enums import (
    EMOJI_MAP,
    ADRStatus,
    Priority,
    ReviewVerdict,
    SpecType,
    Status,
)

# Database-backed MCP tool functions
from nspec.terminusdb.mcp_tools import (
    db_activate,
    db_add_dep,
    db_advance,
    db_complete,
    db_create_spec,
    db_criteria_complete,
    db_next_spec,
    db_show,
    db_task_complete,
)

# Migration tool
from nspec.terminusdb.migrate import MigrationResult, migrate_project
from nspec.terminusdb.repository import (
    ADRRepository,
    BaseRepository,
    CyclicDependencyError,
    DocumentNotFoundError,
    EpicRepository,
    SpecRepository,
    TaskRepository,
    UnitOfWork,
)
from nspec.terminusdb.schema import ADR, Epic, Spec, Task
from nspec.terminusdb.template_engine import TemplateEngine

__all__ = [
    "ADR",
    "ADRRepository",
    "ADRStatus",
    "BaseRepository",
    "BelongsTo",
    "CardinalityError",
    "CyclicDependencyError",
    "DependsOn",
    "DocumentNotFoundError",
    "EMOJI_MAP",
    "Epic",
    "EpicRepository",
    "Priority",
    "ReviewVerdict",
    "Spec",
    "SpecRepository",
    "SpecType",
    "SpecifiedBy",
    "Status",
    "Task",
    "TaskRepository",
    "TemplateEngine",
    "UnitOfWork",
    "db_activate",
    "db_add_dep",
    "db_advance",
    "db_complete",
    "db_create_spec",
    "db_criteria_complete",
    "db_next_spec",
    "db_show",
    "db_task_complete",
    "MigrationResult",
    "migrate_project",
]
