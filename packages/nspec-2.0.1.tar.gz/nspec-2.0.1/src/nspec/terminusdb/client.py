"""TerminusDB client connection and schema initialization.

Provides helpers for connecting to a TerminusDB instance and
registering the nspec schema (document types from schema.py).
"""

from __future__ import annotations

from terminusdb_client import WOQLClient
from terminusdb_client.schema import Schema

from nspec.terminusdb.edges import BelongsTo, DependsOn, SpecifiedBy
from nspec.terminusdb.enums import ADRStatus, Priority, ReviewVerdict, SpecType, Status
from nspec.terminusdb.schema import ADR, Epic, Spec, Task

# Shared schema registry — all document types register here
schema = Schema()

# Register core document types
schema.add_obj("Spec", Spec)
schema.add_obj("Epic", Epic)
schema.add_obj("Task", Task)
schema.add_obj("ADR", ADR)

# Register edge types
schema.add_obj("DependsOn", DependsOn)
schema.add_obj("SpecifiedBy", SpecifiedBy)
schema.add_obj("BelongsTo", BelongsTo)

# Register enum types
schema.add_obj("Priority", Priority)
schema.add_obj("Status", Status)
schema.add_obj("SpecType", SpecType)
schema.add_obj("ADRStatus", ADRStatus)
schema.add_obj("ReviewVerdict", ReviewVerdict)


def connect(
    server_url: str = "http://localhost:6363",
    team: str = "admin",
    db: str = "nspec",
    *,
    key: str = "root",
) -> WOQLClient:
    """Create and connect a WOQLClient to a TerminusDB instance.

    Args:
        server_url: TerminusDB server URL.
        team: Team/organization name.
        db: Database name.
        key: API key or password.

    Returns:
        Connected WOQLClient instance.
    """
    client = WOQLClient(server_url)
    client.connect(team=team, key=key, db=db)
    return client


def init_schema(client: WOQLClient) -> None:
    """Register all nspec document types with the database.

    Creates or updates the schema on the connected database.
    Safe to call multiple times — existing schema is updated.

    Args:
        client: Connected WOQLClient.
    """
    schema.commit(client, message="Initialize nspec schema")
