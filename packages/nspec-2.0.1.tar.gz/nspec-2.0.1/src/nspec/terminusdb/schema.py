"""TerminusDB document type definitions for nspec core entities.

Defines Spec, Epic, Task, and ADR as TerminusDB DocumentTemplate
subclasses with LexicalKey for deterministic IDs.

Status and priority fields use strings here. Enum types (Priority,
Status, ADRStatus) will be defined in S068 and wired in later.
"""

from __future__ import annotations

from datetime import datetime

from terminusdb_client.schema import DocumentTemplate, LexicalKey


class Spec(DocumentTemplate):
    """A specification (feature request + implementation plan).

    Represents both the FR and IMPL as a single entity in the graph.
    LexicalKey on ``id`` ensures deterministic document IDs (e.g. Spec/S001).
    """

    _key = LexicalKey(["id"])

    id: str  # S001, S002, etc.
    title: str
    priority: str  # P0, P1, P2, P3 (will be Priority enum in S068)
    fr_status: str  # Proposed, Active, Completed (will be Status enum in S068)
    impl_status: str  # Planning, Active, Testing, Ready, etc.
    loe: str | None = None  # "3d", "1w", etc.
    created_at: datetime | None = None
    updated_at: datetime | None = None


class Epic(DocumentTemplate):
    """A container for related specs.

    Epics group specs into logical units of work. The ``belongs_to``
    edge (S067) links specs to their parent epic.
    """

    _key = LexicalKey(["id"])

    id: str  # E001, E002, etc.
    title: str
    priority: str  # P0, P1, P2, P3
    status: str  # Active, Completed, etc.
    created_at: datetime | None = None
    updated_at: datetime | None = None


class Task(DocumentTemplate):
    """An implementation task within a spec.

    Uses a composite LexicalKey on (spec_id, task_id) so that
    task "1.1" in spec S001 gets a deterministic ID like
    Task/S001/1.1.
    """

    _key = LexicalKey(["spec_id", "task_id"])

    spec_id: str  # Parent spec ID
    task_id: str  # "1", "1.1", "2", etc.
    description: str
    completed: bool = False
    blocked: bool = False
    blocked_reason: str | None = None


class ADR(DocumentTemplate):
    """Architecture Decision Record.

    Captures architectural decisions with context, rationale, and
    consequences. Linked to specs via ``specified_by`` edge (S067).
    """

    _key = LexicalKey(["id"])

    id: str  # ADR-901, ADR-902, etc.
    title: str
    status: str  # Proposed, Accepted, Deprecated, Superseded (will be ADRStatus enum in S068)
    context: str
    decision: str
    consequences: str
    created_at: datetime | None = None
