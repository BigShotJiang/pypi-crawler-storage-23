"""Jinja2-based template engine for generating markdown from TerminusDB state.

Renders FR and IMPL markdown from spec data dicts returned by the
repository layer. All mutations go through MCP tools — the generated
markdown is read-only output.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from jinja2 import Environment, PackageLoader, select_autoescape

from nspec.terminusdb.enums import EMOJI_MAP


def _emoji_filter(value: str) -> str:
    """Map a priority or status value to its emoji character.

    Args:
        value: Priority (e.g., "P0") or status (e.g., "Active") string.

    Returns:
        Emoji character, or empty string if no mapping exists.
    """
    return EMOJI_MAP.get(value, "")


def _checkbox_filter(value: bool) -> str:
    """Render a boolean as a markdown checkbox marker.

    Args:
        value: True for checked, False for unchecked.

    Returns:
        "x" for True, " " for False.
    """
    return "x" if value else " "


def _create_environment() -> Environment:
    """Create a Jinja2 environment with custom filters and template loader."""
    env = Environment(
        loader=PackageLoader("nspec", "templates/terminusdb"),
        autoescape=select_autoescape([]),
        trim_blocks=True,
        lstrip_blocks=True,
        keep_trailing_newline=True,
    )
    env.filters["emoji"] = _emoji_filter
    env.filters["checkbox"] = _checkbox_filter
    return env


class TemplateEngine:
    """Renders spec data into markdown using Jinja2 templates.

    Usage::

        engine = TemplateEngine()
        fr_md = engine.render_fr(spec_data)
        impl_md = engine.render_impl(spec_data)
    """

    def __init__(self) -> None:
        self.env = _create_environment()

    def render_fr(self, spec_data: dict[str, Any]) -> str:
        """Render a functional requirements markdown document.

        Args:
            spec_data: Spec data dict with keys: id, title, priority,
                fr_status, dependencies, overview, problem, solution,
                acceptance_criteria, dependency_rationale.

        Returns:
            Rendered FR markdown string.
        """
        template = self.env.get_template("fr.md.j2")
        return template.render(spec=spec_data)

    def render_impl(self, spec_data: dict[str, Any]) -> str:
        """Render an implementation plan markdown document.

        Args:
            spec_data: Spec data dict with keys: id, title, impl_status,
                loe, tasks (list of task dicts), review (dict).

        Returns:
            Rendered IMPL markdown string.
        """
        template = self.env.get_template("impl.md.j2")
        return template.render(spec=spec_data)

    def render_spec(
        self,
        fr_data: dict[str, Any],
        impl_data: dict[str, Any],
    ) -> str:
        """Render both FR and IMPL as a combined markdown document.

        Args:
            fr_data: Data for FR template.
            impl_data: Data for IMPL template.

        Returns:
            Combined markdown with FR followed by IMPL.
        """
        fr_md = self.render_fr(fr_data)
        impl_md = self.render_impl(impl_data)
        return f"{fr_md}\n---\n\n{impl_md}"

    def export_all(
        self,
        specs: list[dict[str, Any]],
        output_dir: Path,
        tasks_by_spec: dict[str, list[dict[str, Any]]] | None = None,
    ) -> list[Path]:
        """Bulk export all specs to markdown files.

        Args:
            specs: List of spec data dicts from SpecRepository.list().
            output_dir: Directory to write generated markdown files.
            tasks_by_spec: Optional mapping of spec_id -> task list.
                If not provided, specs are rendered without task data.

        Returns:
            List of paths to generated files.
        """
        output_dir.mkdir(parents=True, exist_ok=True)
        generated: list[Path] = []
        tasks_by_spec = tasks_by_spec or {}

        for spec in specs:
            spec_id = spec.get("id", "unknown")
            title_slug = spec.get("title", "untitled").lower().replace(" ", "-")

            # Render FR
            fr_path = output_dir / f"FR-{spec_id}-{title_slug}.md"
            fr_md = self.render_fr(spec)
            fr_path.write_text(fr_md, encoding="utf-8")
            generated.append(fr_path)

            # Render IMPL (with tasks if available)
            impl_spec = dict(spec)
            impl_spec["tasks"] = tasks_by_spec.get(spec_id, [])
            impl_path = output_dir / f"IMPL-{spec_id}-{title_slug}.md"
            impl_md = self.render_impl(impl_spec)
            impl_path.write_text(impl_md, encoding="utf-8")
            generated.append(impl_path)

        return generated
