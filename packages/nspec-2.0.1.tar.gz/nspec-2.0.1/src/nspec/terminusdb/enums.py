"""TerminusDB enum type definitions for nspec.

Defines Priority, Status, SpecType, ADRStatus, and ReviewVerdict
as TerminusDB EnumTemplate subclasses, plus EMOJI_MAP for display.
"""

from __future__ import annotations

from terminusdb_client.schema import EnumTemplate


class Priority(EnumTemplate):
    """Spec/Epic priority levels."""

    P0 = "P0"  # Critical
    P1 = "P1"  # High
    P2 = "P2"  # Medium
    P3 = "P3"  # Low


class Status(EnumTemplate):
    """FR and IMPL status values.

    FR statuses: Proposed, Active, Completed
    IMPL statuses: Planning, Active, Testing, Ready, Paused, Exception, Completed
    """

    Proposed = "Proposed"
    Active = "Active"
    Planning = "Planning"
    Testing = "Testing"
    Ready = "Ready"
    Paused = "Paused"
    Exception_ = "Exception"
    Completed = "Completed"


class SpecType(EnumTemplate):
    """Type of specification."""

    Feature = "Feature"
    Enhancement = "Enhancement"
    Bug = "Bug"
    ADR = "ADR"
    Refactor = "Refactor"
    Epic = "Epic"


class ADRStatus(EnumTemplate):
    """ADR-specific status values."""

    Proposed = "Proposed"
    Accepted = "Accepted"
    Deprecated = "Deprecated"
    Superseded = "Superseded"


class ReviewVerdict(EnumTemplate):
    """Code review verdict."""

    PENDING = "PENDING"
    APPROVED = "APPROVED"
    NEEDS_WORK = "NEEDS_WORK"


# Display emoji mapping for enum values
EMOJI_MAP: dict[str, str] = {
    # Priority
    "P0": "\U0001f525",  # fire
    "P1": "\U0001f7e0",  # orange circle
    "P2": "\U0001f7e1",  # yellow circle
    "P3": "\U0001f535",  # blue circle
    # Status
    "Proposed": "\U0001f7e1",  # yellow circle
    "Planning": "\U0001f7e1",  # yellow circle
    "Active": "\U0001f535",  # blue circle
    "Testing": "\U0001f9ea",  # test tube
    "Ready": "\U0001f7e0",  # orange circle
    "Paused": "\u23f8\ufe0f",  # pause button
    "Exception": "\u26a0\ufe0f",  # warning
    "Completed": "\u2705",  # check mark
}
