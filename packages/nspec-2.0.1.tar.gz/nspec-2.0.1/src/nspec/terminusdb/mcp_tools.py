"""Database-backed MCP tool implementations.

Alternative backend for MCP tools that uses TerminusDB repository
layer instead of file operations. Each function takes a WOQLClient
and returns structured dicts matching the existing tool response format.
"""

from __future__ import annotations

import subprocess
from typing import Any

from terminusdb_client import WOQLClient

from nspec.terminusdb.repository import (
    CyclicDependencyError,
    DocumentNotFoundError,
    SpecRepository,
    TaskRepository,
)
from nspec.terminusdb.schema import Spec, Task
from nspec.terminusdb.template_engine import TemplateEngine

# Valid IMPL status progression
_IMPL_STATUS_ORDER = ["Planning", "Active", "Testing", "Ready", "Completed"]

# Exception types raised by repository logic (not connection failures)
_REPO_EXCEPTIONS = (DocumentNotFoundError, CyclicDependencyError)


def _error(msg: str) -> dict[str, Any]:
    """Create a structured error response."""
    return {"success": False, "error": msg}


def _connection_error(e: Exception) -> dict[str, Any]:
    """Create an error response for DB connection failures."""
    return _error(f"Database unavailable: {e}")


def _next_status(current: str) -> str | None:
    """Get the next status in the IMPL progression.

    Args:
        current: Current IMPL status string.

    Returns:
        Next status string, or None if already at the end.
    """
    try:
        idx = _IMPL_STATUS_ORDER.index(current)
    except ValueError:
        return None
    if idx >= len(_IMPL_STATUS_ORDER) - 1:
        return None
    return _IMPL_STATUS_ORDER[idx + 1]


def db_show(client: WOQLClient, spec_id: str) -> dict[str, Any]:
    """Get spec details and render as markdown.

    Args:
        client: TerminusDB client.
        spec_id: Spec identifier (e.g., "S001").

    Returns:
        Dict with spec_id, rendered markdown, and metadata.
    """
    try:
        repo = SpecRepository(client)
        task_repo = TaskRepository(client)

        spec = repo.get(spec_id)
        tasks = task_repo.list_for_spec(spec_id)
        spec["tasks"] = _build_task_tree(tasks)

        engine = TemplateEngine()
        fr_md = engine.render_fr(spec)
        impl_md = engine.render_impl(spec)

        return {
            "success": True,
            "spec_id": spec_id,
            "fr_markdown": fr_md,
            "impl_markdown": impl_md,
            "fr": {
                "title": spec.get("title", ""),
                "priority": spec.get("priority", ""),
                "status": spec.get("fr_status", ""),
            },
            "impl": {
                "status": spec.get("impl_status", ""),
                "loe": spec.get("loe", ""),
            },
        }
    except _REPO_EXCEPTIONS:
        return _error(f"Spec {spec_id} not found")
    except Exception as e:
        return _connection_error(e)


def db_next_spec(client: WOQLClient, epic_id: str | None = None) -> dict[str, Any]:
    """Find the highest-priority unblocked spec.

    Args:
        client: TerminusDB client.
        epic_id: Optional epic filter.

    Returns:
        Dict with next spec info, or empty if none available.
    """
    try:
        repo = SpecRepository(client)
        result = repo.next_unblocked(epic_id=epic_id)
    except Exception as e:
        return _connection_error(e)

    if result is None:
        return {"next": None, "message": "No unblocked specs available"}

    return {
        "next": {
            "spec_id": result["id"],
            "title": result.get("title", ""),
            "priority": result.get("priority", ""),
            "status": result.get("impl_status", ""),
        }
    }


def db_activate(client: WOQLClient, spec_id: str) -> dict[str, Any]:
    """Set a spec to Active status.

    Args:
        client: TerminusDB client.
        spec_id: Spec to activate.

    Returns:
        Success/failure dict.
    """
    try:
        repo = SpecRepository(client)

        spec_doc = repo.get(spec_id)
        current_status = spec_doc.get("impl_status", "")
        if current_status not in ("Planning", "Paused"):
            return _error(
                f"Cannot activate spec in '{current_status}' status. "
                "Must be 'Planning' or 'Paused'."
            )

        spec = Spec(
            id=spec_id,
            title=spec_doc.get("title", ""),
            priority=spec_doc.get("priority", "P2"),
            fr_status=spec_doc.get("fr_status", "Active"),
            impl_status="Active",
        )
        repo.update(spec)

        return {"success": True, "spec_id": spec_id, "status": "Active"}
    except _REPO_EXCEPTIONS:
        return _error(f"Spec {spec_id} not found")
    except Exception as e:
        return _connection_error(e)


def db_advance(client: WOQLClient, spec_id: str) -> dict[str, Any]:
    """Advance a spec to the next IMPL status.

    Args:
        client: TerminusDB client.
        spec_id: Spec to advance.

    Returns:
        Success/failure dict with new status.
    """
    try:
        repo = SpecRepository(client)

        spec_doc = repo.get(spec_id)
        current = spec_doc.get("impl_status", "")
        next_st = _next_status(current)

        if next_st is None:
            return _error(f"Cannot advance from '{current}' — already at end or invalid status")

        spec = Spec(
            id=spec_id,
            title=spec_doc.get("title", ""),
            priority=spec_doc.get("priority", "P2"),
            fr_status=spec_doc.get("fr_status", "Active"),
            impl_status=next_st,
        )
        repo.update(spec)

        return {"success": True, "spec_id": spec_id, "previous": current, "status": next_st}
    except _REPO_EXCEPTIONS:
        return _error(f"Spec {spec_id} not found")
    except Exception as e:
        return _connection_error(e)


def db_task_complete(
    client: WOQLClient,
    spec_id: str,
    task_id: str,
    run_tests: bool = True,
) -> dict[str, Any]:
    """Mark a task as complete, optionally running test gate.

    Args:
        client: TerminusDB client.
        spec_id: Spec containing the task.
        task_id: Task to mark complete.
        run_tests: Whether to run `make test-quick` before marking.

    Returns:
        Success/failure dict with progress info.
    """
    try:
        repo = SpecRepository(client)
        task_repo = TaskRepository(client)

        try:
            repo.get(spec_id)
        except DocumentNotFoundError:
            return _error(f"Spec {spec_id} not found")

        try:
            task_doc = task_repo.get(spec_id, task_id)
        except DocumentNotFoundError:
            return _error(f"Task {spec_id}/{task_id} not found")

        if run_tests:
            result = subprocess.run(
                ["make", "test-quick"],
                capture_output=True,
                timeout=120,
            )
            if result.returncode != 0:
                return _error("Tests failed — task not marked complete")

        task = Task(
            spec_id=spec_id,
            task_id=task_id,
            description=task_doc.get("description", ""),
            completed=True,
        )
        task_repo.update(task)

        # Calculate progress
        all_tasks = task_repo.list_for_spec(spec_id)
        total = len(all_tasks)
        done = sum(1 for t in all_tasks if t.get("completed"))
        remaining = [t["task_id"] for t in all_tasks if not t.get("completed")]

        return {
            "success": True,
            "spec_id": spec_id,
            "task_id": task_id,
            "done": done,
            "total": total,
            "remaining_tasks": remaining,
        }
    except _REPO_EXCEPTIONS:
        return _error(f"Spec {spec_id} not found")
    except Exception as e:
        return _connection_error(e)


def db_criteria_complete(
    client: WOQLClient,
    spec_id: str,
    criteria_id: str,
) -> dict[str, Any]:
    """Mark an acceptance criterion as complete.

    Args:
        client: TerminusDB client.
        spec_id: Spec containing the criterion.
        criteria_id: Criterion ID (e.g., "AC-F1").

    Returns:
        Success/failure dict.
    """
    try:
        repo = SpecRepository(client)

        spec_doc = repo.get(spec_id)
        acs = spec_doc.get("acceptance_criteria", [])
        found = False
        for ac in acs:
            if ac.get("id") == criteria_id:
                ac["completed"] = True
                found = True
                break

        if not found:
            return _error(f"Criterion {criteria_id} not found in spec {spec_id}")

        spec = Spec(
            id=spec_id,
            title=spec_doc.get("title", ""),
            priority=spec_doc.get("priority", "P2"),
            fr_status=spec_doc.get("fr_status", "Active"),
            impl_status=spec_doc.get("impl_status", "Active"),
        )
        repo.update(spec)

        return {"success": True, "spec_id": spec_id, "criteria_id": criteria_id}
    except _REPO_EXCEPTIONS:
        return _error(f"Spec {spec_id} not found")
    except Exception as e:
        return _connection_error(e)


def db_create_spec(
    client: WOQLClient,
    title: str,
    priority: str = "P2",
    epic_id: str | None = None,
) -> dict[str, Any]:
    """Create a new spec.

    Args:
        client: TerminusDB client.
        title: Spec title.
        priority: Priority level (P0-P3).
        epic_id: Optional epic to associate with.

    Returns:
        Success/failure dict with new spec ID.
    """
    try:
        repo = SpecRepository(client)

        # Generate next spec ID from existing specs
        all_specs = repo.list()
        existing_ids = [s.get("id", "") for s in all_specs]
        max_num = 0
        for sid in existing_ids:
            if sid.startswith("S") and sid[1:].isdigit():
                max_num = max(max_num, int(sid[1:]))
        new_id = f"S{max_num + 1:03d}"

        spec = Spec(
            id=new_id,
            title=title,
            priority=priority,
            fr_status="Proposed",
            impl_status="Planning",
        )
        repo.create(spec)

        result: dict[str, Any] = {
            "success": True,
            "spec_id": new_id,
            "title": title,
            "priority": priority,
        }

        if epic_id:
            # Associate with epic via BelongsTo edge
            from nspec.terminusdb.edges import BelongsTo

            belongs_to = BelongsTo(spec_id=new_id, epic_id=epic_id)
            client.insert_document(belongs_to, commit_msg=f"Associate {new_id} with {epic_id}")
            result["epic_id"] = epic_id

        return result
    except Exception as e:
        return _connection_error(e)


def db_add_dep(
    client: WOQLClient,
    spec_id: str,
    dep_id: str,
) -> dict[str, Any]:
    """Add a dependency with cycle validation.

    Args:
        client: TerminusDB client.
        spec_id: Source spec (the one that depends).
        dep_id: Target spec (the one depended upon).

    Returns:
        Success/failure dict.
    """
    try:
        repo = SpecRepository(client)

        # Validate both specs exist
        for sid in (spec_id, dep_id):
            try:
                repo.get(sid)
            except DocumentNotFoundError:
                return _error(f"Spec {sid} not found")

        # Validate no cycle
        try:
            repo.validate_dependency(spec_id, dep_id)
        except CyclicDependencyError as e:
            return _error(f"Dependency creates cycle: {e}")

        # Create DependsOn edge
        from nspec.terminusdb.edges import DependsOn

        edge = DependsOn(
            source_id=spec_id,
            target_id=dep_id,
            source_type="Spec",
            target_type="Spec",
        )
        client.insert_document(edge, commit_msg=f"Add dep {spec_id} -> {dep_id}")

        return {"success": True, "spec_id": spec_id, "dep_id": dep_id}
    except _REPO_EXCEPTIONS:
        return _error(f"Spec {spec_id} not found")
    except Exception as e:
        return _connection_error(e)


def db_complete(client: WOQLClient, spec_id: str) -> dict[str, Any]:
    """Complete a spec after validating all tasks and ACs are done.

    Args:
        client: TerminusDB client.
        spec_id: Spec to complete.

    Returns:
        Success/failure dict.
    """
    try:
        repo = SpecRepository(client)
        task_repo = TaskRepository(client)

        spec_doc = repo.get(spec_id)

        # Validate status is Ready
        current_status = spec_doc.get("impl_status", "")
        if current_status != "Ready":
            return _error(f"Cannot complete spec in '{current_status}' status. Must be 'Ready'.")

        # Validate all tasks complete
        tasks = task_repo.list_for_spec(spec_id)
        incomplete = [t["task_id"] for t in tasks if not t.get("completed")]
        if incomplete:
            return _error(
                f"Cannot complete — {len(incomplete)} tasks incomplete: " + ", ".join(incomplete)
            )

        # Validate all ACs complete
        acs = spec_doc.get("acceptance_criteria", [])
        incomplete_acs = [ac["id"] for ac in acs if not ac.get("completed")]
        if incomplete_acs:
            return _error(
                f"Cannot complete — {len(incomplete_acs)} acceptance criteria incomplete: "
                + ", ".join(incomplete_acs)
            )

        # Update status to Completed
        spec = Spec(
            id=spec_id,
            title=spec_doc.get("title", ""),
            priority=spec_doc.get("priority", "P2"),
            fr_status="Completed",
            impl_status="Completed",
        )
        repo.update(spec)

        return {"success": True, "spec_id": spec_id, "status": "Completed"}
    except _REPO_EXCEPTIONS:
        return _error(f"Spec {spec_id} not found")
    except Exception as e:
        return _connection_error(e)


def _build_task_tree(tasks: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Convert flat task list into a tree structure for template rendering.

    Tasks with IDs like "1", "2" are top-level; "1.1", "1.2" are children of "1".

    Args:
        tasks: Flat list of task dicts with "task_id" field.

    Returns:
        Nested task list with "children" and "depth" fields.
    """
    # Build parent mapping
    top_level: list[dict[str, Any]] = []
    children_map: dict[str, list[dict[str, Any]]] = {}

    for task in tasks:
        tid = task.get("task_id", "")
        task_copy = dict(task)
        task_copy["children"] = []

        if "." in tid:
            parent_id = tid.rsplit(".", 1)[0]
            task_copy["depth"] = tid.count(".")
            children_map.setdefault(parent_id, []).append(task_copy)
        else:
            task_copy["depth"] = 0
            top_level.append(task_copy)

    # Attach children
    for task in top_level:
        tid = task.get("task_id", "")
        task["children"] = children_map.get(tid, [])

    return top_level
