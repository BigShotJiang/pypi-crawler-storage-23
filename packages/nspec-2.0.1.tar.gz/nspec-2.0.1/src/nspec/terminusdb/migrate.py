"""Migration tool for importing markdown specs into TerminusDB.

Parses existing FR/IMPL markdown files using DatasetLoader, extracts
git timestamps, builds dependency graph, and inserts documents into
TerminusDB in topological order.
"""

from __future__ import annotations

import logging
import subprocess
from dataclasses import dataclass, field
from graphlib import CycleError, TopologicalSorter
from pathlib import Path
from typing import Any

from terminusdb_client import WOQLClient

from nspec.terminusdb.edges import DependsOn
from nspec.terminusdb.repository import SpecRepository, TaskRepository
from nspec.terminusdb.schema import Spec, Task

logger = logging.getLogger("nspec.migrate")


@dataclass
class MigrationResult:
    """Result of a migration operation."""

    success: bool
    count: int = 0
    errors: list[str] = field(default_factory=list)
    dry_run: bool = False
    specs_migrated: list[str] = field(default_factory=list)


def get_git_timestamp(file_path: Path, first: bool = True) -> str | None:
    """Extract a git timestamp for a file.

    Args:
        file_path: Path to the file.
        first: If True, get first commit date; if False, get last commit date.

    Returns:
        ISO 8601 timestamp string, or None if git is unavailable.
    """
    order_flag = "--reverse" if first else ""
    cmd = f"git log {order_flag} --format=%aI -1 -- {file_path}"
    try:
        result = subprocess.run(
            cmd.split(),
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        pass
    return None


def get_git_created_at(file_path: Path) -> str | None:
    """Get the first commit date for a file."""
    return get_git_timestamp(file_path, first=True)


def get_git_updated_at(file_path: Path) -> str | None:
    """Get the last commit date for a file."""
    return get_git_timestamp(file_path, first=False)


def parse_specs(docs_root: Path) -> list[dict[str, Any]]:
    """Parse all FR/IMPL markdown files into spec data dicts.

    Uses the existing DatasetLoader to parse and validate files,
    then converts to dicts suitable for TerminusDB insertion.

    Args:
        docs_root: Path to docs/ directory.

    Returns:
        List of spec data dicts with FR and IMPL metadata merged.
    """
    from nspec.datasets import DatasetLoader

    loader = DatasetLoader(docs_root)
    datasets = loader.load()

    specs: list[dict[str, Any]] = []

    for spec_id in datasets.all_spec_ids():
        fr = datasets.get_fr(spec_id)
        impl = datasets.get_impl(spec_id)

        spec_data: dict[str, Any] = {
            "id": spec_id,
            "title": fr.title if fr else f"Spec {spec_id}",
            "priority": fr.priority.split()[-1] if fr else "P2",
            "fr_status": _clean_status(fr.status) if fr else "Proposed",
            "impl_status": _clean_status(impl.status) if impl else "Planning",
            "deps": list(fr.deps) if fr else [],
        }

        if fr and fr.path:
            spec_data["fr_path"] = str(fr.path)
            spec_data["created_at"] = get_git_created_at(fr.path)

        if impl and impl.path:
            spec_data["impl_path"] = str(impl.path)
            spec_data["updated_at"] = get_git_updated_at(impl.path)
            spec_data["loe"] = impl.loe

        # Extract tasks from IMPL
        tasks: list[dict[str, Any]] = []
        if impl:
            for task in impl.tasks:
                tasks.append(
                    {
                        "spec_id": spec_id,
                        "task_id": task.id,
                        "description": task.description,
                        "completed": task.completed,
                    }
                )
        spec_data["tasks"] = tasks

        # Extract acceptance criteria from FR
        acs: list[dict[str, Any]] = []
        if fr:
            for ac in fr.acceptance_criteria:
                acs.append(
                    {
                        "id": ac.id,
                        "description": ac.description,
                        "completed": ac.completed,
                    }
                )
        spec_data["acceptance_criteria"] = acs

        specs.append(spec_data)

    return specs


def _clean_status(status: str) -> str:
    """Remove emoji prefix from status string.

    Args:
        status: Status like "🔵 Active" or "🟡 Planning".

    Returns:
        Clean status string like "Active" or "Planning".
    """
    parts = status.split(" ", 1)
    if len(parts) == 2:
        return parts[1]
    return status


def extract_dependencies(
    specs: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Build dependency edges from parsed spec data.

    Args:
        specs: List of spec data dicts with "deps" field.

    Returns:
        List of dependency edge dicts.
    """
    spec_ids = {s["id"] for s in specs}
    edges: list[dict[str, Any]] = []

    for spec in specs:
        for dep_id in spec.get("deps", []):
            if dep_id in spec_ids:
                edges.append(
                    {
                        "source_id": spec["id"],
                        "target_id": dep_id,
                        "source_type": "Spec",
                        "target_type": "Spec",
                    }
                )

    return edges


def topological_order(
    specs: list[dict[str, Any]],
    deps: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Sort specs in topological order (dependencies first).

    Args:
        specs: List of spec data dicts.
        deps: List of dependency edge dicts.

    Returns:
        Specs sorted so dependencies come before dependents.

    Raises:
        CycleError: If circular dependencies are detected.
    """
    spec_map = {s["id"]: s for s in specs}
    sorter: TopologicalSorter[str] = TopologicalSorter()

    for spec in specs:
        sorter.add(spec["id"])

    for dep in deps:
        # source depends on target → target must come first
        sorter.add(dep["source_id"], dep["target_id"])

    ordered: list[dict[str, Any]] = []
    for spec_id in sorter.static_order():
        if spec_id in spec_map:
            ordered.append(spec_map[spec_id])

    return ordered


def migrate_project(
    docs_root: Path,
    client: WOQLClient,
    dry_run: bool = False,
) -> MigrationResult:
    """Import markdown specs into TerminusDB.

    Main entry point for migration. Parses all FRs and IMPLs,
    extracts metadata, and inserts into the database in
    topological order.

    Args:
        docs_root: Path to docs/ directory.
        client: Connected WOQLClient.
        dry_run: If True, validate only — no database writes.

    Returns:
        MigrationResult with success status and details.
    """
    errors: list[str] = []

    # 1. Parse all specs
    try:
        specs = parse_specs(docs_root)
    except Exception as e:
        return MigrationResult(
            success=False,
            errors=[f"Parse failed: {e}"],
            dry_run=dry_run,
        )

    if not specs:
        return MigrationResult(
            success=True,
            count=0,
            dry_run=dry_run,
        )

    # 2. Extract dependencies
    deps = extract_dependencies(specs)

    # 3. Topological sort
    try:
        ordered_specs = topological_order(specs, deps)
    except CycleError as e:
        return MigrationResult(
            success=False,
            errors=[f"Circular dependency detected: {e}"],
            dry_run=dry_run,
        )

    # 4. Dry run — just report
    if dry_run:
        return MigrationResult(
            success=True,
            count=len(ordered_specs),
            dry_run=True,
            specs_migrated=[s["id"] for s in ordered_specs],
        )

    # 5. Insert into database
    spec_repo = SpecRepository(client)
    task_repo = TaskRepository(client)
    migrated: list[str] = []

    for spec_data in ordered_specs:
        try:
            # Create spec document
            spec = Spec(
                id=spec_data["id"],
                title=spec_data["title"],
                priority=spec_data["priority"],
                fr_status=spec_data.get("fr_status", "Proposed"),
                impl_status=spec_data.get("impl_status", "Planning"),
            )
            spec_repo.create(spec)

            # Create task documents
            for task_data in spec_data.get("tasks", []):
                task = Task(
                    spec_id=task_data["spec_id"],
                    task_id=task_data["task_id"],
                    description=task_data.get("description", ""),
                    completed=task_data.get("completed", False),
                )
                task_repo.create(task)

            migrated.append(spec_data["id"])
        except Exception as e:
            errors.append(f"Failed to migrate {spec_data['id']}: {e}")

    # 6. Insert dependency edges
    for dep in deps:
        try:
            edge = DependsOn(
                source_id=dep["source_id"],
                target_id=dep["target_id"],
                source_type=dep["source_type"],
                target_type=dep["target_type"],
            )
            client.insert_document(
                edge,
                commit_msg=f"Add dep {dep['source_id']} -> {dep['target_id']}",
            )
        except Exception as e:
            errors.append(
                f"Failed to create dependency {dep['source_id']} -> {dep['target_id']}: {e}"
            )

    return MigrationResult(
        success=len(errors) == 0,
        count=len(migrated),
        errors=errors,
        dry_run=False,
        specs_migrated=migrated,
    )
