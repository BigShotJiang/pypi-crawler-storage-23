"""
HyperStack Python SDK
Cloud memory for AI agents. 3 lines to integrate.

Usage:
    from hyperstack import HyperStack

    hs = HyperStack("hs_your_key")
    hs.store("project-api", "API", "FastAPI on AWS", stack="projects", keywords=["fastapi", "python"])
    results = hs.search("python")
    cards = hs.list()
    hs.delete("project-api")
    stats = hs.stats()

    # Graph features (Pro)
    graph = hs.graph("project-api", depth=2)
    impact = hs.impact("project-api")
    recs = hs.recommend("project-api")
    result = hs.smart_search("what depends on the API?")

    # Branching (v1.4.0)
    branch = hs.fork("experiment/auth-migration")
    diff = hs.diff(branch["branchWorkspaceId"])
    hs.merge(branch["branchWorkspaceId"], strategy="ours")
    hs.discard(branch["branchWorkspaceId"])

    # Agent Identity (v1.4.0)
    identity = hs.identify("researcher", display_name="Research Agent")
    profile = hs.profile("researcher")

Install:
    pip install hyperstack-py

Docs: https://cascadeai.dev
"""

import json
import os
import urllib.request
import urllib.error
import urllib.parse
from typing import Optional, List, Dict, Any

__version__ = "1.4.0"

DEFAULT_API_URL = "https://hyperstack-cloud.vercel.app"


class HyperStackError(Exception):
    """Base exception for HyperStack errors."""
    def __init__(self, message: str, status: int = 0):
        super().__init__(message)
        self.status = status


class HyperStack:
    """
    HyperStack client â€” cloud memory for AI agents.

    Args:
        api_key: Your HyperStack API key (starts with hs_)
        workspace: Workspace name (default: "default")
        api_url: API base URL. Overrides HYPERSTACK_BASE_URL env var.
                 Set HYPERSTACK_BASE_URL to point at a self-hosted backend.
    """

    def __init__(
        self,
        api_key: str,
        workspace: str = "default",
        api_url: Optional[str] = None,
    ):
        if not api_key:
            raise HyperStackError("API key required. Get one free at https://cascadeai.dev")
        self.api_key = api_key
        self.workspace = workspace
        # HYPERSTACK_BASE_URL supports self-hosted deployments
        self.api_url = (api_url or os.environ.get("HYPERSTACK_BASE_URL", DEFAULT_API_URL)).rstrip("/")
        # Session-level agent identity â€” set by identify(), auto-stamps store() calls
        self._session_agent_id: Optional[str] = None

    def _request(
        self,
        endpoint: str,
        method: str = "GET",
        body: Optional[dict] = None,
        params: Optional[dict] = None,
        base_params: bool = True,
    ) -> dict:
        """Make an API request."""
        url = f"{self.api_url}/api/{endpoint}"
        if base_params:
            url += f"?workspace={urllib.parse.quote(self.workspace)}"
            if params:
                for k, v in params.items():
                    url += f"&{urllib.parse.quote(str(k))}={urllib.parse.quote(str(v))}"
        elif params:
            url += "?" + "&".join(
                f"{urllib.parse.quote(str(k))}={urllib.parse.quote(str(v))}"
                for k, v in params.items()
            )

        headers = {
            "X-API-Key": self.api_key,
            "Content-Type": "application/json",
        }

        data = json.dumps(body).encode("utf-8") if body else None
        req = urllib.request.Request(url, data=data, headers=headers, method=method)

        try:
            with urllib.request.urlopen(req) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            body_text = e.read().decode("utf-8", errors="replace")
            try:
                err_data = json.loads(body_text)
                msg = err_data.get("error", body_text)
            except Exception:
                msg = body_text
            raise HyperStackError(msg, status=e.code)
        except urllib.error.URLError as e:
            raise HyperStackError(f"Connection failed: {e.reason}")

    def store(
        self,
        slug: str,
        title: str,
        body: str,
        stack: str = "general",
        keywords: Optional[List[str]] = None,
        card_type: str = "general",
        links: Optional[List[Dict[str, str]]] = None,
        source_agent: Optional[str] = None,
        target_agent: Optional[str] = None,
        confidence: Optional[float] = None,
        truth_stratum: str = "hypothesis",
        verified_by: Optional[str] = None,
        ttl: Optional[str] = None,
    ) -> dict:
        """
        Store or update a memory card.

        Args:
            slug: Unique ID (kebab-case, e.g. "project-webapp")
            title: Short title
            body: The knowledge to remember
            stack: Category (projects|people|decisions|preferences|workflows|general)
            keywords: Tags for search
            card_type: Type (person|project|decision|preference|workflow|event|general|signal|scratchpad)
            links: List of dicts with 'target' and 'relation' keys
            source_agent: Agent storing this card
            target_agent: Agent this card is directed at (for inter-agent signals)
            confidence: Self-reported certainty 0.0â€“1.0 (default 1.0)
            truth_stratum: Epistemic status â€” draft|hypothesis|confirmed
            verified_by: Who/what confirmed this card (e.g. 'human:deeq', 'tool:web_search')
            ttl: ISO datetime for auto-expiry. Use with scratchpad cards.

        Returns:
            Card data dict
        """
        payload = {
            "slug": slug,
            "title": title,
            "body": body,
            "stack": stack,
            "cardType": card_type,
            "keywords": keywords or [],
            "truthStratum": truth_stratum,
        }
        if links:
            payload["links"] = links
        if source_agent:
            payload["sourceAgent"] = source_agent
        if target_agent:
            payload["targetAgent"] = target_agent
        if confidence is not None:
            payload["confidence"] = confidence
        if verified_by:
            payload["verifiedBy"] = verified_by
        if ttl:
            payload["ttl"] = ttl
        # Auto-stamp agent identity if identified this session
        if self._session_agent_id:
            payload["agentIdentityId"] = self._session_agent_id

        return self._request("cards", method="POST", body=payload)

    def search(self, query: str) -> List[dict]:
        """Search memory cards using vector + graph (GraphRAG)."""
        result = self._request("search", params={"q": query})
        return result.get("results", result.get("cards", []))

    def smart_search(self, query: str, slug: Optional[str] = None) -> dict:
        """
        Agentic RAG â€” automatically routes to the best retrieval mode
        (search, graph traversal, or impact analysis) based on the query.
        """
        params = {"q": query, "mode": "auto"}
        if slug:
            params["slug"] = slug
        return self._request("search", params=params)

    def list(self, stack: Optional[str] = None) -> List[dict]:
        """List all memory cards, optionally filtered by stack."""
        result = self._request("cards")
        cards = result.get("cards", [])
        if stack:
            cards = [c for c in cards if c.get("stack") == stack]
        return cards

    def get(self, slug: str) -> Optional[dict]:
        """Get a specific card by slug."""
        cards = self.list()
        for card in cards:
            if card.get("slug") == slug:
                return card
        return None

    def delete(self, slug: str) -> dict:
        """Delete a memory card by slug."""
        return self._request("cards", method="DELETE", params={"id": slug})

    def graph(
        self,
        from_slug: str,
        depth: int = 1,
        relation: Optional[str] = None,
        at: Optional[str] = None,
    ) -> dict:
        """Traverse the knowledge graph forward from a starting card. Requires Pro."""
        params = {"from": from_slug, "depth": str(depth)}
        if relation:
            params["relation"] = relation
        if at:
            params["at"] = at
        return self._request("graph", params=params)

    def impact(self, slug: str, depth: int = 2, relation: Optional[str] = None) -> dict:
        """Reverse traversal â€” finds all cards that point TO a given card. Requires Pro."""
        params = {"from": slug, "depth": str(depth), "mode": "impact"}
        if relation:
            params["relation"] = relation
        return self._request("graph", params=params)

    def recommend(self, slug: str, limit: int = 5) -> List[dict]:
        """Find related cards using co-citation scoring. Requires Pro."""
        params = {"from": slug, "mode": "recommend", "limit": str(limit)}
        result = self._request("graph", params=params)
        return result.get("recommendations", result.get("nodes", []))

    def stats(self) -> dict:
        """Get memory usage stats."""
        result = self._request("cards")
        cards = result.get("cards", [])
        total_tokens = sum(c.get("tokens", 0) for c in cards)
        without_hs = len(cards) * 6000
        stacks: Dict[str, int] = {}
        for c in cards:
            s = c.get("stack", "general")
            stacks[s] = stacks.get(s, 0) + 1
        return {
            "cards": len(cards),
            "plan": result.get("plan", "FREE"),
            "limit": result.get("limit", 50),
            "tokens_stored": total_tokens,
            "tokens_without_hs": without_hs,
            "savings_pct": round((1 - total_tokens / without_hs) * 100) if without_hs > 0 else 0,
            "stacks": stacks,
        }

    def ingest(self, text: str, source: str = "conversation") -> dict:
        """Auto-extract memory cards from raw text."""
        return self._request("ingest", method="POST", body={
            "text": text,
            "workspace": self.workspace,
            "source": source,
        })

    def prune(self, days: int = 30, dry: bool = True) -> dict:
        """
        Remove stale cards older than N days that are no longer referenced.
        Always run with dry=True first. Pinned and confirmed cards are never pruned.
        """
        params = {"prune": "true", "days": str(days)}
        if dry:
            params["dry"] = "true"
        return self._request("cards", method="DELETE", params=params)

    def commit(
        self,
        task_slug: str,
        title: str,
        outcome: str,
        keywords: Optional[List[str]] = None,
        source_agent: Optional[str] = None,
        target_agent: Optional[str] = None,
    ) -> dict:
        """
        Commit a completed task outcome to long-term memory as a decision card.
        Links back to the original task card via a 'decided' relation.
        """
        payload = {
            "taskSlug": task_slug,
            "title": title,
            "outcome": outcome,
            "keywords": keywords or [],
        }
        if source_agent:
            payload["sourceAgent"] = source_agent
        if target_agent:
            payload["targetAgent"] = target_agent
        return self._request("cards", method="POST", body=payload, params={"commit": "true"})

    # â”€â”€ Branching (v1.4.0) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

    def fork(self, branch_name: str) -> dict:
        """
        Fork the current workspace into an isolated branch.
        Write cards freely, test hypotheses, run experiments.
        Merge back to main if it worked â€” discard if it didn't.
        Main memory is never touched until you merge. Requires Pro.

        Args:
            branch_name: Name for this branch (e.g. 'experiment/auth-migration')

        Returns:
            Dict with branchWorkspaceId, cardsCopied, branchName, forkedAt
        """
        return self._request(
            "workspaces",
            method="POST",
            body={"branchName": branch_name},
            params={"action": "fork"},
        )

    def diff(self, branch_workspace_id: str) -> dict:
        """
        Compare a branch workspace against its parent.
        Returns added, changed, and deleted card slugs. Lightweight â€” slugs only.
        Requires Pro.

        Args:
            branch_workspace_id: Branch ID returned by fork()

        Returns:
            Dict with added, changed, deleted lists of {slug, title}
        """
        return self._request(
            "workspaces",
            method="GET",
            params={"action": "diff", "branchWorkspaceId": branch_workspace_id},
        )

    def merge(self, branch_workspace_id: str, strategy: str = "ours") -> dict:
        """
        Merge a branch workspace back into its parent.
        Whole-card granularity â€” no per-field merging. Requires Pro.

        Args:
            branch_workspace_id: Branch ID to merge
            strategy: 'ours' = branch cards win (default). 'theirs' = parent cards win.

        Returns:
            Dict with merged count, skipped count
        """
        if strategy not in ("ours", "theirs"):
            raise HyperStackError("strategy must be 'ours' or 'theirs'")
        return self._request(
            "workspaces",
            method="POST",
            body={"branchWorkspaceId": branch_workspace_id, "strategy": strategy},
            params={"action": "merge"},
        )

    def discard(self, branch_workspace_id: str) -> dict:
        """
        Destroy a branch workspace and all its cards.
        Parent workspace is completely untouched. Requires Pro.

        Args:
            branch_workspace_id: Branch ID to destroy

        Returns:
            Dict with deleted: True
        """
        return self._request(
            "workspaces",
            method="POST",
            body={"branchWorkspaceId": branch_workspace_id},
            params={"action": "discard"},
        )

    # â”€â”€ Agent Identity (v1.4.0) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

    def identify(self, agent_slug: str, display_name: Optional[str] = None) -> dict:
        """
        Register this agent's identity and stamp all subsequent store() calls with it.
        Idempotent â€” safe to call multiple times. Requires Pro.

        Args:
            agent_slug: Unique identifier for this agent (e.g. 'researcher')
            display_name: Human-readable name (defaults to agent_slug)

        Returns:
            Dict with agentSlug, fingerprint, registeredAt, isNew
        """
        payload: dict = {"agentSlug": agent_slug}
        if display_name:
            payload["displayName"] = display_name

        result = self._request(
            "agent-tokens",
            method="POST",
            body=payload,
            params={"action": "register"},
        )
        # Store fingerprint â€” auto-stamps all subsequent store() calls
        if result.get("fingerprint"):
            self._session_agent_id = result["fingerprint"]
        return result

    def profile(self, agent_slug: str) -> dict:
        """
        Get an agent's identity profile including computed trustScore.
        trustScore is computed on read only (never on write). Requires Pro.

        trustScore formula:
            (verifiedCards / totalCards) * 0.7 + min(cardCount / 100, 1.0) * 0.3

        Args:
            agent_slug: Agent slug to look up

        Returns:
            Dict with agentSlug, displayName, cardCount, verifiedCards,
            trustScore, registeredAt, lastActiveAt
        """
        return self._request(
            "agent-tokens",
            method="GET",
            params={"action": "profile", "agentSlug": agent_slug},
        )

    def __repr__(self) -> str:
        return f"HyperStack(workspace='{self.workspace}', key='...{self.api_key[-6:]}')"
