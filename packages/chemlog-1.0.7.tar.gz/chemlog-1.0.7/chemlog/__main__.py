from chemlog.cli import cli

if __name__ == "__main__":
    """
    Entry point for the CLI application.

    This script calls the `cli` function from the `chebai.cli` module
    when executed as the main program.
    """
    cli()