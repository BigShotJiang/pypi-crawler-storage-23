"""Neo4j MCP tools package."""

from neo4j_mcp.tools.graph_tools import register_graph_tools

__all__ = ["register_graph_tools"]
