"""Run neo4j-mcp server as a module."""

from neo4j_mcp.cli import main

if __name__ == "__main__":
    main()
