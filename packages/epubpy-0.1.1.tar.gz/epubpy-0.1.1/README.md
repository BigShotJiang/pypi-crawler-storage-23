# EpubPy

EpubPy is a module for reading and writing EPUB files.

## Documentation

For a quick tutorial, look at
[Quickstart](https://github.com/Menotim72/epubpy/blob/master/docs/quickstart.md).

## Vs Ebooklib

The most commonly used EPUB package is
[ebooklib](https://github.com/aerkalov/ebooklib). I believe EpubPy's interface
is easier to use than ebooklib's; also, EpubPy supports reading an EPUB,
changing it directly, and writing it back to a file. But ebooklib is a good
library, and if EpubPy does not suit you, you might want to try it instead.
