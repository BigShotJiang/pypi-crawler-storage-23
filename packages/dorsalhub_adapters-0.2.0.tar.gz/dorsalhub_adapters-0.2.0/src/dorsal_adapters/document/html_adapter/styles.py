# Copyright 2026 Dorsal Hub LTD
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

CORE_CSS = """
    /* Core Structure (Do not override unless necessary) */
    .page-container { position: relative; box-sizing: border-box; }
    .layout-y { display: flex; flex-direction: column; width: 100%; }
    .layout-x { display: flex; flex-direction: row; width: 100%; align-items: flex-start; }
    .col { box-sizing: border-box; }
    .block-text { white-space: pre-wrap; word-break: break-word; }
    .figure-placeholder { display: flex; align-items: center; justify-content: center; text-transform: uppercase; }
    .wireframe-box { position: absolute; overflow: hidden; box-sizing: border-box; transition: all 0.15s ease-in-out; }
    .wireframe-box:hover { z-index: 1000; overflow: visible; height: auto !important; }
    .document-footer { margin: 4rem auto 2rem auto; max-width: 850px; padding: 2rem 1rem; text-align: center; border-top: 2px solid; }
"""

THEMES = {
    "none": "",
    "default": """
    /* DorsalHub Light Theme */
    body { font-family: 'Inter', system-ui, -apple-system, sans-serif; background-color: #f8fafc; color: #0f172a; line-height: 1.6; font-size: 14px; margin: 0; }
    
    .page-container { background-color: #ffffff; border: 1px solid #e2e8f0; border-radius: 0.5rem; box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px -1px rgba(0, 0, 0, 0.1); margin: 2rem auto; }
    .page-flow { max-width: 100%; padding: 2rem; margin: 1rem; }
    .page-wireframe { margin: 2rem auto; }
    
    .page-divider { text-align: center; font-size: 0.875rem; color: #64748b; margin: 2rem 0; text-transform: uppercase; letter-spacing: 0.05em; font-weight: 500; }
    .block-text { margin: 0 0 1.25rem 0; color: #334155; }
    .figure-placeholder { background-color: #f8fafc; border: 1px dashed #cbd5e1; color: #64748b; font-size: 0.875rem; letter-spacing: 0.05em; margin-bottom: 1.25rem; min-height: 4rem; border-radius: 0.375rem; }
    
    /* Wireframe highlights using sky-500 (#0ea5e9) */
    .wireframe-box { border: 1px solid rgba(14, 165, 233, 0.4); background-color: rgba(14, 165, 233, 0.05); font-size: 10px; line-height: 1.2; padding: 2px; color: #0369a1; border-radius: 2px; }
    .wireframe-box:hover { background-color: rgba(255, 255, 255, 0.95); border-color: #0ea5e9; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1); }

    /* Responsive Breakpoints */
    @media (min-width: 640px) { 
        .page-flow { padding: 3rem; font-size: 15px; margin: 2rem auto; } 
    }
    @media (min-width: 1024px) { 
        .page-flow { padding: 4rem; font-size: 16px; max-width: 1200px; } 
    }
    """,
    "dark": """
    /* DorsalHub Dark Theme */
    body { font-family: 'Inter', system-ui, -apple-system, sans-serif; background-color: #0f172a; color: #f8fafc; line-height: 1.6; font-size: 14px; margin: 0; }
    
    .page-container { background-color: #1e293b; border: 1px solid #334155; border-radius: 0.5rem; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -2px rgba(0, 0, 0, 0.1); margin: 2rem auto; }
    .page-flow { max-width: 100%; padding: 2rem; margin: 1rem; }
    .page-wireframe { margin: 2rem auto; }
    
    .page-divider { text-align: center; font-size: 0.875rem; color: #475569; margin: 2rem 0; text-transform: uppercase; letter-spacing: 0.05em; font-weight: 500; }
    .block-text { margin: 0 0 1.25rem 0; color: #cbd5e1; }
    .figure-placeholder { background-color: #0f172a; border: 1px dashed #475569; color: #94a3b8; font-size: 0.875rem; letter-spacing: 0.05em; margin-bottom: 1.25rem; min-height: 4rem; border-radius: 0.375rem; }
    
    /* Wireframe highlights using sky-400 (#38bdf8) and sky-500 (#0ea5e9) */
    .wireframe-box { border: 1px solid rgba(14, 165, 233, 0.5); background-color: rgba(14, 165, 233, 0.05); font-size: 10px; line-height: 1.2; padding: 2px; color: #7dd3fc; border-radius: 2px; }
    .wireframe-box:hover { background-color: rgba(15, 23, 42, 0.95); border-color: #38bdf8; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.5); }

    /* Responsive Breakpoints */
    @media (min-width: 640px) { 
        .page-flow { padding: 3rem; font-size: 15px; margin: 2rem auto; } 
    }
    @media (min-width: 1024px) { 
        .page-flow { padding: 4rem; font-size: 16px; max-width: 1200px; } 
    }
    """,
}
