# Copyright 2026 Dorsal Hub LTD
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pytest
from dorsal_adapters.document.md_adapter import to_md, from_md


def test_to_md_rich_rag_features():
    """Test all LLM-optimized enrichments and hit 100% coverage branches."""
    record = {
        "producer": "test-runner",
        "extraction_type": "mixed",
        "unit": "px",
        "score_explanation": "OCR Confidence",
        "attributes": {"doc_type": "invoice", "tags": ["finance", "2026"]},
        "blocks": [
            {"text": "Invoice", "block_type": "text", "page_number": 1, "attributes": {"visual_class": "title"}},
            {"text": "Summary", "block_type": "text", "page_number": 1, "attributes": {"visual_class": "h2"}},
            {"text": "Items", "block_type": "text", "page_number": 1, "attributes": {"visual_class": "heading"}},
            {"text": "Blurry", "block_type": "text", "page_number": 1, "score": 0.50},
            {"block_type": "image", "box": {"x": 10, "y": 20, "width": 100, "height": 100}, "page_number": 1},
        ],
    }

    # Test Full Feature Set
    result = to_md(record, validate=False)
    assert "producer: test-runner" in result
    assert "score_explanation: OCR Confidence" in result
    assert 'doc_type: "invoice"' in result
    assert "# Invoice" in result
    assert "## Summary" in result
    assert "### Items" in result
    assert "> ⚠️ **Low Confidence Read (0.50)**" in result

    no_fm = to_md(record, validate=False, include_frontmatter=False)
    assert "---" not in no_fm


def test_from_md_conversion():
    """Test ingress parsing including page header matching and validation coverage."""
    md_input = "---\nproducer: test\n---\n## Page 1\nHello\n## Page 2\nWorld"

    record = from_md(md_input, validate=True)

    assert record["blocks"][0]["page_number"] == 1
    assert record["blocks"][1]["page_number"] == 2


def test_md_errors():
    """Ensure ValueErrors are raised for empty inputs."""
    with pytest.raises(ValueError):
        to_md({"blocks": []}, validate=False)
    with pytest.raises(ValueError):
        from_md("   ", validate=False)


def test_from_md_empty():
    """Ensure ingress fails gracefully on empty text."""
    with pytest.raises(ValueError):
        from_md("   \n  ", validate=False)


def test_to_md_empty():
    """Ensure egress fails gracefully if blocks are missing."""
    with pytest.raises(ValueError):
        to_md({"extraction_type": "text", "blocks": []}, validate=False)


def test_to_md_validation_and_skips():
    """Test explicit validation and the skipping of empty text nodes."""
    record = {
        "producer": "test",
        "extraction_type": "mixed",
        "unit": "px",
        "blocks": [
            {
                "block_type": "text",
                "text": "Valid text",
                "page_number": 1,
                "box": {"x": 0, "y": 0, "width": 10, "height": 10},
            },
            {"block_type": "text", "text": "   ", "page_number": 1},
            {
                "block_type": "multi_polygon",
                "page_number": 1,
                "multi_polygon": [[{"x": 10, "y": 10}, {"x": 20, "y": 10}, {"x": 15, "y": 20}]],
            },
        ],
    }

    result = to_md(record, validate=True)

    assert "Valid text" in result
    assert "> *[Multi_polygon at x:10, y:10, w:10, h:10]*" in result
    assert "Valid text\n\n> *[Multi_polygon" in result


def test_from_md_line_skipping():
    """Test that the parser safely skips empty lines and separator artifacts."""
    md_input = """
    
    ---
    ## Page 1
    
    Actual Content
    
    ---
    
    """
    record = from_md(md_input, validate=False)

    assert len(record["blocks"]) == 1
    assert record["blocks"][0]["text"] == "Actual Content"
