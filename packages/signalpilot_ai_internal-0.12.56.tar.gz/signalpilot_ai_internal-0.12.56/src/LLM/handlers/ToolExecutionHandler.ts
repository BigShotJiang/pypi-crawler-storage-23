/**
 * ToolExecutionHandler - Handles tool execution during LLM loop
 *
 * This encapsulates all tool execution logic, including:
 * - Sequential vs parallel execution
 * - Tool approval workflows
 * - Tool result handling
 * - Code execution confirmation
 * - Terminal command approval (MCP terminal-execute)
 */

import { ToolService } from '../ToolService';
import { ChatMessages } from '@/ChatBox/services/ChatMessagesService';
import { ActionHistory, ActionType } from '@/ChatBox/services/ActionHistory';
import { CodeConfirmationDialog } from '../../Components/CodeConfirmationDialog';
import { useChatMessagesStore } from '../../stores/chatMessages';
import { useLLMStateStore } from '../../stores/llmStateStore';
import { useDiffStore } from '../../stores/diffStore';
import { useWaitingReplyStore } from '../../stores/waitingReplyStore';
import { ILLMContext, IToolCall, IToolProcessResult } from '../LLMTypes';
import { useSettingsStore } from '../../stores/settingsStore';
import { useServicesStore } from '../../stores/servicesStore';
import { StreamingUIHandler, ToolCallInfo } from './StreamingUIHandler';
import { DiffApprovalHandler } from './DiffApprovalHandler';
import {
  isMCPTool,
  isRulesTool,
  TERMINAL_EXECUTE_TOOL
} from '../../utils/toolClassification';
import { debuggerService } from '../../Services/DebuggerService';

// ═══════════════════════════════════════════════════════════════
// TOOL BEHAVIOR CONFIG
// ═══════════════════════════════════════════════════════════════

type ApprovalType = 'code_execution' | 'terminal_command' | 'none';

/**
 * Describes how a tool should be handled during execution.
 * - parallelizable: can run concurrently with other parallelizable tools
 * - approvalType: what kind of user approval is needed before execution
 * - stopsLoop: whether execution stops the LLM loop
 */
interface IToolBehavior {
  parallelizable: boolean;
  approvalType: ApprovalType;
  stopsLoop: boolean;
}

/**
 * Default behavior for any tool not explicitly configured.
 * Most tools (including MCP tools like terminal/grep, terminal/glob,
 * files/read) are parallelizable read-only operations that need no approval.
 */
const DEFAULT_TOOL_BEHAVIOR: IToolBehavior = {
  parallelizable: true,
  approvalType: 'none',
  stopsLoop: false
};

/**
 * Overrides for tools that deviate from the default behavior.
 * Only list tools that need non-default settings.
 */
const TOOL_BEHAVIOR_OVERRIDES: Record<string, Partial<IToolBehavior>> = {
  // Code execution: requires approval, not parallelizable (diff approval flow)
  'notebook-run_cell': {
    parallelizable: false,
    approvalType: 'code_execution'
  },
  'notebook-execute_cell': {
    parallelizable: false,
    approvalType: 'code_execution'
  },

  // Terminal execute: parallelizable but requires approval
  [TERMINAL_EXECUTE_TOOL]: { approvalType: 'terminal_command' },

  // Notebook mutation: not parallelizable (diff approval flow)
  'notebook-add_cell': { parallelizable: false },
  'notebook-edit_cell': { parallelizable: false },
  'notebook-remove_cells': { parallelizable: false },
  'notebook-edit_plan': { parallelizable: false },

  // Loop stopping
  'notebook-wait_user_reply': { stopsLoop: true, parallelizable: false },

  // Notebook switch: not parallelizable (stops loop via special handling)
  open_notebook: { parallelizable: false }
};

/**
 * Get the behavior config for a tool by name.
 * Returns default behavior merged with any overrides.
 */
function getToolBehavior(toolName: string): IToolBehavior {
  const overrides = TOOL_BEHAVIOR_OVERRIDES[toolName];
  if (!overrides) {
    return { ...DEFAULT_TOOL_BEHAVIOR };
  }
  return { ...DEFAULT_TOOL_BEHAVIOR, ...overrides };
}

// ═══════════════════════════════════════════════════════════════
// MAIN CLASS
// ═══════════════════════════════════════════════════════════════

/**
 * Handler for tool execution during the LLM loop
 */
export class ToolExecutionHandler {
  private toolService: ToolService;
  private actionHistory: ActionHistory;
  private messageComponent: ChatMessages;
  private codeConfirmationDialog: CodeConfirmationDialog;
  private streamingHandler: StreamingUIHandler | null = null;
  private diffHandler: DiffApprovalHandler | null = null;
  private notebookId: string | null = null;

  constructor(
    toolService: ToolService,
    actionHistory: ActionHistory,
    messageComponent?: ChatMessages,
    codeConfirmationDialog?: CodeConfirmationDialog
  ) {
    this.toolService = toolService;
    this.actionHistory = actionHistory;
    this.messageComponent = messageComponent!;
    this.codeConfirmationDialog = codeConfirmationDialog!;
  }

  /**
   * Set the streaming handler for accessing streaming tool call info
   */
  setStreamingHandler(handler: StreamingUIHandler): void {
    this.streamingHandler = handler;
  }

  /**
   * Set the diff handler
   */
  setDiffHandler(handler: DiffApprovalHandler): void {
    this.diffHandler = handler;
  }

  /**
   * Set the message component
   */
  setMessageComponent(component: ChatMessages): void {
    this.messageComponent = component;
  }

  /**
   * Set the code confirmation dialog
   */
  setCodeConfirmationDialog(dialog: CodeConfirmationDialog): void {
    this.codeConfirmationDialog = dialog;
  }

  /**
   * Set the notebook ID
   */
  setNotebookId(notebookId: string | null): void {
    this.notebookId = notebookId;
  }

  // ═══════════════════════════════════════════════════════════════
  // MAIN ENTRY POINT
  // ═══════════════════════════════════════════════════════════════

  /**
   * Process all tool calls from an API response
   */
  async processToolCalls(
    response: any,
    context: ILLMContext,
    messageComponent: ChatMessages
  ): Promise<IToolProcessResult> {
    const toolCalls = this.extractToolCalls(response);

    if (toolCalls.length === 0) {
      return {
        shouldContinue: true,
        hasToolCalls: false,
        toolResults: []
      };
    }

    console.log(
      `[ToolExecutionHandler] Processing ${toolCalls.length} tool calls`
    );

    const toolResults: any[] = [];
    let shouldContinue = true;

    // Process tools - batch parallelizable ones, execute others sequentially
    let i = 0;
    while (i < toolCalls.length && shouldContinue) {
      const tool = toolCalls[i];

      // Check if this tool allows parallelization
      if (this.allowsParallelization(tool.name)) {
        // Collect consecutive parallelizable tools
        const batch: IToolCall[] = [];
        while (
          i < toolCalls.length &&
          this.allowsParallelization(toolCalls[i].name)
        ) {
          batch.push(toolCalls[i]);
          i++;
        }

        // Execute batch concurrently
        const batchResults = await this.executeConcurrentTools(
          batch,
          context,
          messageComponent
        );
        toolResults.push(...batchResults.results);
        shouldContinue = batchResults.shouldContinue;
      } else {
        // Execute single tool
        const result = await this.executeSingleTool(
          tool,
          context,
          messageComponent
        );
        toolResults.push(result.result);
        shouldContinue = result.shouldContinue;
        i++;
      }
    }

    return {
      shouldContinue,
      hasToolCalls: true,
      toolResults
    };
  }

  // ═══════════════════════════════════════════════════════════════
  // TOOL EXTRACTION
  // ═══════════════════════════════════════════════════════════════

  /**
   * Check if a tool allows parallelization
   */
  allowsParallelization(toolName: string): boolean {
    return getToolBehavior(toolName).parallelizable;
  }

  // ═══════════════════════════════════════════════════════════════
  // SEQUENTIAL EXECUTION
  // ═══════════════════════════════════════════════════════════════

  /**
   * Check if a tool requires approval
   */
  requiresApproval(toolName: string): boolean {
    return getToolBehavior(toolName).approvalType !== 'none';
  }

  /**
   * Get the approval type for a tool
   */
  getApprovalType(toolName: string): ApprovalType {
    return getToolBehavior(toolName).approvalType;
  }

  /**
   * Check if a tool stops the LLM loop
   */
  isLoopStoppingTool(toolName: string): boolean {
    return getToolBehavior(toolName).stopsLoop;
  }

  /**
   * Check if response has any tool calls
   */
  hasToolCalls(response: any): boolean {
    if (!response?.content) return false;
    return response.content.some(
      (c: any) => c.type === 'tool_use' || c.type === 'server_tool_use'
    );
  }

  /**
   * Extract tool calls from API response
   * Includes only 'tool_use'
   * Type 'server_tool_use' is ignored
   * Server tools are added to history but NOT executed locally (they're executed by the API).
   */
  private extractToolCalls(response: any): IToolCall[] {
    if (!response?.content) return [];

    return response.content
      .filter((c: any) => c.type === 'tool_use')
      .map((c: any) => ({
        id: c.id,
        name: c.name,
        input: c.input,
        type: c.type // Preserve the type so we can check for server_tool_use
      }));
  }

  /**
   * Check if a tool call is a server-side tool (executed by API, not locally)
   */
  private isServerToolUse(tool: IToolCall): boolean {
    return (tool as any).type === 'server_tool_use';
  }

  // ═══════════════════════════════════════════════════════════════
  // SHARED EXECUTION PIPELINE
  // ═══════════════════════════════════════════════════════════════

  /**
   * Dispatch approval based on tool behavior config.
   */
  private async _dispatchApproval(
    tool: IToolCall,
    context: ILLMContext
  ): Promise<boolean> {
    const approvalType = this.getApprovalType(tool.name);
    if (approvalType === 'code_execution') {
      return this.handleCodeExecutionApproval(tool, context);
    }
    if (approvalType === 'terminal_command') {
      return this.handleTerminalCommandApproval(tool);
    }
    return true;
  }

  /**
   * Resolve tool result via streaming cache, pre-executed check,
   * diff creation, or direct execution.
   */
  private async _resolveToolResult(
    tool: IToolCall,
    streamingInfo: ToolCallInfo | undefined,
    actionState: any
  ): Promise<{ result: any; skipped: boolean }> {
    // Streaming cache hit
    if (streamingInfo?.toolResult) {
      return { result: streamingInfo.toolResult, skipped: false };
    }

    // notebook-run_cell: already executed during diff approval
    if (tool.name === 'notebook-run_cell') {
      const alreadyExecuted = await this.checkExecutedCells(
        tool.id,
        tool.input?.cell_id
      );
      if (alreadyExecuted) {
        console.log(
          '[ToolExecutionHandler] Skipping tool call - already executed'
        );
        return { result: null, skipped: true };
      }
    }

    // notebook-remove_cells: create pending diffs instead of directly removing
    if (tool.name === 'notebook-remove_cells' && actionState?.removedCells) {
      const diffManager = useServicesStore.getState().notebookDiffManager;
      if (diffManager) {
        const notebookId = this.notebookId || tool.input?.notebook_path;
        for (const cell of actionState.removedCells) {
          if (cell && (cell.id || cell.trackingId)) {
            const cellId = cell.trackingId || cell.id;
            const content = cell.content || cell.source || '';
            const summary =
              cell.custom?.summary ||
              cell.metadata?.custom?.summary ||
              'Remove cell';

            console.log(
              `[ToolExecutionHandler] Creating remove diff for cell: ${cellId}, notebookId: ${notebookId}`
            );
            diffManager.trackRemoveCell(cellId, content, summary, notebookId);
          }
        }
        console.log(
          '[ToolExecutionHandler] Created remove diffs, skipping direct removal'
        );
        return { result: { content: 'true' }, skipped: false };
      }
    }

    // Default: execute the tool
    return {
      result: await this.toolService.executeTool(tool),
      skipped: false
    };
  }

  /**
   * Shared pipeline for executing one tool after approval.
   * Handles: server check → streaming info → history → LLM state →
   * action capture → resolve → undo → record → cleanup.
   *
   * @param skipHistoryAdd - When true, skips adding tool_use to LLM history
   *   (caller already did it, e.g. executeSingleTool adds before approval).
   */
  private async _executeOneTool(
    tool: IToolCall,
    skipHistoryAdd = false
  ): Promise<{ result: any; skipped: boolean }> {
    // Server tools handled during streaming
    if (this.isServerToolUse(tool)) {
      console.log(
        `[ToolExecutionHandler] Server tool use - skipping: ${tool.name}`,
        tool.id
      );
      return { result: null, skipped: true };
    }

    // Get streaming info and merge cell_id
    const streamingInfo = this.streamingHandler?.getStreamingToolCall(tool.id);
    const mergedInput = {
      ...tool.input,
      ...(streamingInfo?.cellId ? { cell_id: streamingInfo.cellId } : {})
    };

    // Add tool_use to LLM history (unless caller already did)
    if (!skipHistoryAdd) {
      this.messageComponent?.addToolCalls([
        { id: tool.id, name: tool.name, input: mergedInput }
      ]);
    }

    // Show tool state
    const llmStateStore = useLLMStateStore.getState();
    if (!llmStateStore.isDiffState()) {
      llmStateStore.showTool(tool.name, tool.input);
    }

    // Capture action state for undo
    const actionState = await this.captureActionState(tool, streamingInfo);

    // Emit tool_call debug event
    debuggerService.emitToolCall({
      toolName: tool.name,
      toolId: tool.id,
      toolInput: mergedInput
    });

    try {
      const { result, skipped } = await this._resolveToolResult(
        tool,
        streamingInfo,
        actionState
      );

      if (skipped) {
        this.streamingHandler?.removeStreamingToolCall(tool.id);
        return { result: null, skipped: true };
      }

      // Track undo
      this.trackActionForUndo(tool, result, actionState);

      // Record result
      if (result) {
        this.messageComponent?.addToolResult(
          tool.name,
          tool.id,
          result.content || JSON.stringify(result),
          tool.input
        );

        // Emit tool_result debug event
        debuggerService.emitToolResult({
          toolName: tool.name,
          toolId: tool.id,
          toolResult: result.content || result,
          isError: false
        });

        // Update toolSearchResult for MCP tools and rules tools so the UI can show input/output
        if (isMCPTool(tool.name) || isRulesTool(tool.name)) {
          useChatMessagesStore
            .getState()
            .updateToolSearchResult(
              tool.id,
              tool.input,
              result.content || result
            );
        }
      }

      // Cleanup streaming
      this.streamingHandler?.removeStreamingToolCall(tool.id);
      return { result, skipped: false };
    } catch (error) {
      console.error(
        `[ToolExecutionHandler] Error executing ${tool.name}:`,
        error
      );
      const errorResult = {
        error: error instanceof Error ? error.message : 'Unknown error',
        success: false
      };

      // Emit tool_result debug event with error
      debuggerService.emitToolResult({
        toolName: tool.name,
        toolId: tool.id,
        toolResult: errorResult,
        isError: true
      });

      this.addToolResultToHistory(tool, errorResult, true);
      this.streamingHandler?.removeStreamingToolCall(tool.id);
      return { result: errorResult, skipped: false };
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // EXECUTION ENTRY POINTS
  // ═══════════════════════════════════════════════════════════════

  /**
   * Execute a single tool
   */
  private async executeSingleTool(
    tool: IToolCall,
    context: ILLMContext,
    messageComponent: ChatMessages
  ): Promise<{ result: any; shouldContinue: boolean }> {
    console.log(`[ToolExecutionHandler] Executing tool: ${tool.name}`);

    // Loop-stopping tools have a dedicated path
    if (this.isLoopStoppingTool(tool.name)) {
      console.log(
        `[ToolExecutionHandler] Adding loop-stopping tool to history: ${tool.name}`,
        tool.id
      );
      this.messageComponent?.addToolCalls([
        { id: tool.id, name: tool.name, input: tool.input }
      ]);
      const result = await this.executeLoopStoppingTool(tool, messageComponent);
      return { result, shouldContinue: false };
    }

    // Add tool_use to LLM history BEFORE approval (matches original behavior:
    // rejected tools still appear in conversation history)
    const streamingInfo = this.streamingHandler?.getStreamingToolCall(tool.id);
    const mergedInput = {
      ...tool.input,
      ...(streamingInfo?.cellId ? { cell_id: streamingInfo.cellId } : {})
    };
    this.messageComponent?.addToolCalls([
      { id: tool.id, name: tool.name, input: mergedInput }
    ]);

    // Handle approval
    const approved = await this._dispatchApproval(tool, context);
    if (!approved) {
      this.streamingHandler?.removeStreamingToolCall(tool.id);
      return { result: null, shouldContinue: false };
    }

    // Execute through shared pipeline (history already recorded above)
    const { result } = await this._executeOneTool(tool, true);

    // Update LLM state
    const llmState = useLLMStateStore.getState();
    if (!llmState.isDiffState()) {
      llmState.show('Generating...');
    }

    // open_notebook stops the loop for notebook switching
    if (tool.name === 'open_notebook') {
      console.log(
        '[ToolExecutionHandler] open_notebook executed - stopping loop for notebook switch'
      );
      return { result, shouldContinue: false };
    }

    return { result, shouldContinue: true };
  }

  /**
   * Handle code execution approval
   */
  private async handleCodeExecutionApproval(
    tool: IToolCall,
    context: ILLMContext
  ): Promise<boolean> {
    // Check for pending diffs before code execution
    if (this.diffHandler) {
      await this.diffHandler.handlePendingDiffs(this.notebookId, true);
    }

    const diffManager = useServicesStore.getState().notebookDiffManager;

    // Check if diffs were rejected
    if (diffManager?.hasRejectedDiffs()) {
      this.messageComponent?.addSystemMessage(
        '❌ Changes were rejected. Code execution has been cancelled.'
      );

      if (tool.input?.cell_id) {
        this.messageComponent?.addToolResult(
          'notebook-run_cell',
          tool.id,
          'User rejected changes, cell was not added or executed.',
          {
            cell_id: tool.input?.cell_id,
            notebook_path: this.notebookId
          }
        );
      }

      useDiffStore.getState().clearDiffs(null);
      return false;
    }

    // Check if user has made approval decisions that should stop the LLM loop
    if (this.diffHandler?.checkForApprovalDecisions()) {
      console.log(
        '[ToolExecutionHandler] User made approval decisions - stopping LLM loop'
      );

      this.messageComponent?.addToolResult(
        'notebook-run_cell',
        tool.id,
        'user accepted changes but did not run the cell.',
        { cell_id: tool.input?.cell_id, notebook_path: this.notebookId }
      );

      return false;
    }

    // Handle code execution confirmation
    let shouldRun = false;

    if (useSettingsStore.getState().autoRun) {
      shouldRun = true;
      this.messageComponent?.addSystemMessage(
        'Automatically running code (auto-run is enabled).'
      );
    } else if (diffManager && diffManager.shouldRunImmediately()) {
      shouldRun = true;
      this.messageComponent?.addSystemMessage(
        'Running code immediately after approving changes.'
      );
    } else {
      // Show confirmation dialog
      const llmState = useLLMStateStore.getState();
      if (this.codeConfirmationDialog) {
        llmState.showRunCellTool(
          () => this.codeConfirmationDialog.triggerApproval(),
          () => this.codeConfirmationDialog.triggerRejection()
        );
      }

      if (this.codeConfirmationDialog) {
        shouldRun = await this.codeConfirmationDialog.showConfirmation(
          tool.input.cell_id || tool.input.cellId || ''
        );
      }

      if (shouldRun) {
        llmState.show();
      } else {
        llmState.hide();
        this.messageComponent?.removeLoadingText();
      }
    }

    return shouldRun;
  }

  // ═══════════════════════════════════════════════════════════════
  // CONCURRENT EXECUTION
  // ═══════════════════════════════════════════════════════════════

  /**
   * Handle terminal command approval
   */
  private async handleTerminalCommandApproval(
    tool: IToolCall
  ): Promise<boolean> {
    const command = tool.input?.command || '';

    // If autorun is enabled, execute immediately
    if (useSettingsStore.getState().autoRun) {
      this.messageComponent?.addSystemMessage(
        `Automatically executing terminal command (auto-run is enabled): ${command}`
      );
      return true;
    }

    // Show confirmation dialog for terminal command
    const llmState = useLLMStateStore.getState();
    if (this.codeConfirmationDialog) {
      llmState.showRunTerminalCommandTool(
        () => this.codeConfirmationDialog.triggerApproval(),
        () => this.codeConfirmationDialog.triggerRejection(),
        tool.input
      );
    }

    let shouldRun = false;
    if (this.codeConfirmationDialog) {
      shouldRun = await this.codeConfirmationDialog.showConfirmation(command);
    }

    if (shouldRun) {
      llmState.show();
    } else {
      llmState.hide();
      this.messageComponent?.removeLoadingText();
    }

    return shouldRun;
  }

  // ═══════════════════════════════════════════════════════════════
  // SPECIAL TOOL HANDLERS
  // ═══════════════════════════════════════════════════════════════

  /**
   * Check if cells were executed during diff approval
   */
  private async checkExecutedCells(
    toolId: string,
    cellId?: string
  ): Promise<boolean> {
    const diffManager = useServicesStore.getState().notebookDiffManager;
    if (!diffManager) {
      return false;
    }

    const pendingDiffs = useDiffStore.getState().pendingDiffs;
    for (const diff of pendingDiffs.values()) {
      if (
        diff.cellId === cellId &&
        diff.userDecision === 'run' &&
        diff.runResult
      ) {
        // Cell was already executed during diff approval
        this.messageComponent?.addToolResult(
          'notebook-run_cell',
          toolId,
          JSON.stringify(diff.runResult),
          { cell_id: cellId, notebook_path: this.notebookId }
        );
        return true;
      }
    }

    return false;
  }

  /**
   * Capture action state before execution for undo functionality
   */
  private async captureActionState(
    tool: IToolCall,
    streamingToolCallInfo?: ToolCallInfo
  ): Promise<any> {
    if (tool.name === 'notebook-edit_cell') {
      try {
        const cellInfo = await this.toolService.executeTool({
          id: 'get_cell_before_edit',
          name: 'notebook-get_cell_info',
          input: { cell_id: tool.input.cell_id }
        });

        if (cellInfo && cellInfo.content) {
          const cellData = JSON.parse(cellInfo.content);
          return {
            originalCell: cellData,
            originalContent: streamingToolCallInfo?.originalContent || '',
            originalSummary: streamingToolCallInfo?.originalSummary || '',
            newSource: tool.input.new_source,
            cellId: tool.input.cell_id,
            cell_id: tool.input.cell_id,
            summary: tool.input.summary
          };
        }
      } catch (err) {
        console.error('Failed to get cell info before edit:', err);
      }
    } else if (tool.name === 'notebook-remove_cells') {
      try {
        const cellsToRemove = tool.input.cell_ids || [];
        const cellInfoPromises = cellsToRemove.map((cellId: string) =>
          this.toolService.executeTool({
            id: `get_cell_before_remove_${cellId}`,
            name: 'notebook-get_cell_info',
            input: { cell_id: cellId }
          })
        );

        const cellInfoResults = await Promise.all(cellInfoPromises);
        const removedCells = cellInfoResults
          .map(result =>
            result && result.content ? JSON.parse(result.content) : null
          )
          .filter(cell => cell !== null);

        if (removedCells.length > 0) {
          return { removedCells };
        }
      } catch (err) {
        console.error('Failed to get cell info before removal:', err);
      }
    }

    return null;
  }

  // ═══════════════════════════════════════════════════════════════
  // HISTORY MANAGEMENT
  // ═══════════════════════════════════════════════════════════════

  /**
   * Track action for undo functionality
   */
  private trackActionForUndo(
    tool: IToolCall,
    result: any,
    actionBeforeExecution: any
  ): void {
    // Map tool names to action types
    let actionType: ActionType | null = null;
    let actionData: any = {
      toolId: tool.id,
      toolName: tool.name,
      input: tool.input,
      result
    };

    switch (tool.name) {
      case 'notebook-add_cell':
        actionType = ActionType.ADD_CELL;
        // Get the streaming tool call info for the cell ID
        const streamingInfo = this.streamingHandler?.getStreamingToolCall(
          tool.id
        );
        actionData = {
          ...actionData,
          trackingId: streamingInfo?.cellId || result?.content,
          cellId: streamingInfo?.cellId || result?.content,
          newContent: tool.input.source,
          originalCellType: tool.input.cell_type,
          summary: tool.input.summary
        };
        break;
      case 'notebook-edit_cell':
        actionType = ActionType.EDIT_CELL;
        if (actionBeforeExecution) {
          actionData = {
            ...actionData,
            trackingId: tool.input.cell_id,
            cellId: tool.input.cell_id,
            originalContent: actionBeforeExecution.originalContent,
            originalSummary: actionBeforeExecution.originalSummary,
            newContent: tool.input.new_source,
            summary: tool.input.summary
          };
        }
        break;
      case 'notebook-remove_cells':
        actionType = ActionType.REMOVE_CELLS;
        if (actionBeforeExecution?.removedCells) {
          actionData = {
            ...actionData,
            removedCells: actionBeforeExecution.removedCells
          };
        }
        break;
      case 'notebook-edit_plan':
        actionType = ActionType.EDIT_PLAN;
        break;
    }

    if (actionType) {
      this.actionHistory.addActionWithCheckpoint(
        actionType,
        actionData,
        `${tool.name}: ${this.getToolDescription(tool)}`
      );
    }
  }

  /**
   * Execute multiple tools concurrently
   */
  private async executeConcurrentTools(
    tools: IToolCall[],
    context: ILLMContext,
    _messageComponent: ChatMessages
  ): Promise<{ results: any[]; shouldContinue: boolean }> {
    console.log(
      `[ToolExecutionHandler] Executing ${tools.length} tools concurrently`
    );

    // Step 1: Add all tools to LLM history BEFORE approval
    // (rejected tools still appear in conversation history)
    for (const tool of tools) {
      const streamingInfo = this.streamingHandler?.getStreamingToolCall(
        tool.id
      );
      const mergedInput = {
        ...tool.input,
        ...(streamingInfo?.cellId ? { cell_id: streamingInfo.cellId } : {})
      };
      this.messageComponent?.addToolCalls([
        { id: tool.id, name: tool.name, input: mergedInput }
      ]);
    }

    // Step 2: Collect approval for all tools concurrently
    const approvalResults = await Promise.all(
      tools.map(async tool => ({
        tool,
        approved: await this._dispatchApproval(tool, context)
      }))
    );

    // If any tool was rejected, stop processing
    if (approvalResults.some(r => !r.approved)) {
      for (const tool of tools) {
        this.streamingHandler?.removeStreamingToolCall(tool.id);
      }
      const llmState = useLLMStateStore.getState();
      if (!llmState.isDiffState()) {
        llmState.hide();
      }
      return { results: [], shouldContinue: false };
    }

    // Step 3: Execute all approved tools concurrently through shared pipeline
    // (history already recorded above, skip duplicate add)
    const executionResults = await Promise.all(
      approvalResults
        .filter(r => r.approved)
        .map(({ tool }) => this._executeOneTool(tool, true))
    );

    // Update LLM state
    const llmState = useLLMStateStore.getState();
    if (!llmState.isDiffState()) {
      llmState.show('Generating...');
    }

    return {
      results: executionResults.map(r => r.result),
      shouldContinue: true
    };
  }

  // ═══════════════════════════════════════════════════════════════
  // UTILITY METHODS
  // ═══════════════════════════════════════════════════════════════

  /**
   * Execute a tool that stops the LLM loop
   */
  private async executeLoopStoppingTool(
    tool: IToolCall,
    messageComponent: ChatMessages
  ): Promise<any> {
    console.log(`[ToolExecutionHandler] Loop stopping tool: ${tool.name}`);

    if (tool.name === 'notebook-wait_user_reply') {
      return this.handleWaitUserReply(tool, messageComponent);
    }

    // Default execution for other loop-stopping tools
    const result = await this.toolService.executeTool(tool);
    this.addToolResultToHistory(tool, result);
    return result;
  }

  /**
   * Handle the wait_user_reply tool
   */
  private async handleWaitUserReply(
    tool: IToolCall,
    _messageComponent: ChatMessages
  ): Promise<any> {
    // Support both field names: recommended_next_prompts (from LLM) and prompt_buttons (legacy)
    const promptButtons =
      tool.input?.recommended_next_prompts || tool.input?.prompt_buttons || [];
    const userMessage =
      tool.input?.message || 'What would you like to do next?';

    console.log(
      '[ToolExecutionHandler] handleWaitUserReply - tool.input:',
      tool.input
    );
    console.log(
      '[ToolExecutionHandler] handleWaitUserReply - promptButtons:',
      promptButtons
    );

    // Show the waiting for reply UI
    useWaitingReplyStore.getState().show(promptButtons);
    useLLMStateStore.getState().show('Waiting for your response...', true);

    // Add assistant message if provided via store
    // if (userMessage) {
    //   useChatMessagesStore.getState().addAssistantMessage(userMessage);
    // }

    // Return a result that indicates waiting
    const result = {
      status: 'waiting_for_user',
      message: 'Waiting for user input'
    };

    this.addToolResultToHistory(tool, result);
    return result;
  }

  /**
   * Add tool result to LLM history
   */
  private addToolResultToHistory(
    tool: IToolCall,
    result: any,
    isError: boolean = false
  ): void {
    const toolResultMessage = {
      role: 'user',
      content: [
        {
          type: 'tool_result',
          tool_use_id: tool.id,
          content: JSON.stringify(result),
          is_error: isError
        }
      ]
    };

    useChatMessagesStore.getState().addToLlmHistory(toolResultMessage);
  }

  /**
   * Get a human-readable description of a tool call
   */
  private getToolDescription(tool: IToolCall): string {
    switch (tool.name) {
      case 'notebook-add_cell':
        return `Added ${tool.input?.cell_type || 'code'} cell`;
      case 'notebook-edit_cell':
        return `Edited cell ${tool.input?.cell_id || 'unknown'}`;
      case 'notebook-remove_cells':
        return `Removed ${(tool.input?.cell_ids || []).length} cell(s)`;
      case 'notebook-edit_plan':
        return 'Updated plan';
      case 'notebook-run_cell':
        return `Ran cell ${tool.input?.cell_id || 'unknown'}`;
      default:
        return tool.name;
    }
  }
}
