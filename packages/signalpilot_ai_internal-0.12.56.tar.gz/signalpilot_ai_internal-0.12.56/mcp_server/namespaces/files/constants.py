"""Files namespace constants."""

BINARY_EXTENSIONS: frozenset[str] = frozenset({
    "zip", "gz", "tar", "bz2", "xz", "7z", "rar",
    "png", "jpg", "jpeg", "gif", "bmp", "ico", "webp", "tiff", "svg",
    "mp3", "wav", "flac", "aac", "ogg", "wma",
    "mp4", "avi", "mkv", "mov", "wmv", "webm",
    "exe", "dll", "so", "dylib", "bin",
    "whl", "egg",
    "pyc", "pyo", "class",
    "o", "a", "lib",
    "db", "sqlite", "sqlite3",
    "parquet", "feather", "arrow",
    "pkl", "pickle",
})
