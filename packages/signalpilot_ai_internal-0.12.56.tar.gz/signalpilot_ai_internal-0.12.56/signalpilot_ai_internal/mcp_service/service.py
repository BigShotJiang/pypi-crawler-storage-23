"""
MCP Connection Service - Main service class for managing MCP server connections.
"""
import asyncio
import logging
from typing import Dict, List, Any, Optional

from ..signalpilot_home import get_signalpilot_home
from ..oauth_token_store import get_oauth_token_store
from .config_manager import MCPConfigManager
from .whitelist_manager import MCPWhitelistManager
from .connections import MCPConnection, MCPCommandConnection, MCPHTTPConnection
from .errors import MCPConnectionError, MCPServerNotFoundError

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


class MCPConnectionService:
    """Service for managing MCP server connections and tool calls."""

    _instance = None

    def __init__(self):
        """Initialize the MCP connection service."""
        self.connections: Dict[str, MCPConnection] = {}
        self.tools_cache: Dict[str, List[Dict]] = {}
        self._home_manager = get_signalpilot_home()
        self._config_manager = MCPConfigManager(self._home_manager)
        self._whitelist_manager = MCPWhitelistManager(self._config_manager)

    @classmethod
    def get_instance(cls) -> 'MCPConnectionService':
        """Get singleton instance of MCP service."""
        if cls._instance is None:
            cls._instance = MCPConnectionService()
        return cls._instance

    def save_server_config(self, server_config: Dict) -> Dict:
        """Save MCP server configuration."""
        return self._config_manager.save_server_config(server_config)

    def load_all_configs(self) -> Dict[str, Dict]:
        """Load all MCP server configurations."""
        return self._config_manager.load_all_configs()

    def get_server_config(self, server_id: str) -> Optional[Dict]:
        """Get a specific server configuration. Returns None if not found."""
        return self._config_manager.get_server_config(server_id)

    def delete_server_config(self, server_id: str) -> bool:
        """Delete a server configuration."""
        success = self._config_manager.delete_server_config(server_id)
        if success and server_id in self.connections:
            asyncio.create_task(self.disconnect(server_id))
        return success

    async def connect(self, server_id: str) -> Dict:
        """Connect to an MCP server."""
        config = self._config_manager.get_server_config(server_id)
        if not config:
            raise MCPServerNotFoundError(f"Server not found: {server_id}")

        if not config.get('enabled', True):
            raise MCPConnectionError(f"Server {server_id} is disabled")

        # Check if already connected
        if server_id in self.connections:
            connection = self.connections[server_id]
            if connection.is_connected():
                logger.info(f"[MCP] Already connected to: {config['name']}")
                return self._get_server_info(server_id, config)
            else:
                del self.connections[server_id]

        # Create connection based on type
        connection_type = config['type']
        if connection_type == 'command':
            connection = MCPCommandConnection(server_id, config)
        elif connection_type in ['http', 'sse']:
            connection = MCPHTTPConnection(server_id, config)
        else:
            raise MCPConnectionError(f"Unknown connection type: {connection_type}")

        # Connect and cache tools
        await connection.connect()
        self.connections[server_id] = connection

        tools = await connection.list_tools()
        self.tools_cache[server_id] = tools

        # Auto-whitelist tools
        tool_names = [tool['name'] for tool in tools]
        self._whitelist_manager.ensure_default_whitelisted_tools(server_id, config, tool_names)

        logger.info(f"[MCP] Connected to {config['name']} ({len(tools)} tools)")
        return self._get_server_info(server_id, config)

    async def disconnect(self, server_id: str) -> bool:
        """Disconnect from an MCP server."""
        if server_id not in self.connections:
            return False

        connection = self.connections[server_id]
        await connection.disconnect()
        del self.connections[server_id]

        if server_id in self.tools_cache:
            del self.tools_cache[server_id]

        logger.info(f"[MCP] Disconnected from: {server_id}")
        return True

    async def list_tools(self, server_id: str) -> List[Dict]:
        """List tools available from a connected MCP server."""
        if server_id in self.tools_cache:
            tools = self.tools_cache[server_id]
        elif server_id in self.connections:
            tools = await self.connections[server_id].list_tools()
            self.tools_cache[server_id] = tools
        else:
            raise MCPConnectionError(f"Not connected to server: {server_id}")

        self._ensure_whitelist(server_id, tools)
        return tools

    def _ensure_whitelist(self, server_id: str, tools: List[Dict]) -> None:
        """Ensure default whitelisted tools are enabled for a server."""
        config = self.get_server_config(server_id)
        if config:
            tool_names = [tool['name'] for tool in tools]
            self._whitelist_manager.ensure_default_whitelisted_tools(server_id, config, tool_names)

    async def get_all_tools(self) -> List[Dict]:
        """Get all tools from all connected servers."""
        all_tools = []
        for server_id in self.connections.keys():
            try:
                tools = await self.list_tools(server_id)
                config = self._config_manager.get_server_config(server_id)
                server_name = config['name'] if config else server_id

                for tool in tools:
                    tool['serverId'] = server_id
                    tool['serverName'] = server_name

                all_tools.extend(tools)
            except Exception as e:
                logger.error(f"Error getting tools from {server_id}: {e}")

        return all_tools

    async def call_tool(self, server_id: str, tool_name: str, arguments: Dict) -> Any:
        """Call a tool on an MCP server."""
        if server_id not in self.connections:
            raise MCPConnectionError(f"Not connected to server: {server_id}")

        connection = self.connections[server_id]
        result = await connection.call_tool(tool_name, arguments)

        logger.info(f"[MCP] Called tool {tool_name} on {server_id}")
        return result

    def get_connection_status(self, server_id: str) -> str:
        """Get connection status for a server."""
        if server_id in self.connections:
            return 'connected' if self.connections[server_id].is_connected() else 'error'
        return 'disconnected'

    def _get_server_info(self, server_id: str, config: Dict) -> Dict:
        """Get server information for response."""
        tools = self.tools_cache.get(server_id, [])

        result = {
            'serverId': server_id,
            'name': config['name'],
            'status': self.get_connection_status(server_id),
            'type': config['type'],
            'toolCount': len(tools),
            'tools': tools,
            'enabled': config.get('enabled', True),
            'enabledTools': config.get('enabledTools', [])
        }

        result.update(self._get_oauth_info(server_id, config))
        return result

    def _get_oauth_info(self, server_id: str, config: Dict) -> Dict:
        """Get OAuth-related info for server response.

        Args:
            server_id: Server identifier
            config: Server configuration

        Returns:
            Dict with OAuth fields if server is OAuth-enabled, empty dict otherwise
        """
        token_store = get_oauth_token_store()
        is_oauth = config.get('isOAuthIntegration', False) or token_store.is_oauth_server(server_id)

        if not is_oauth:
            return {}

        return {
            'isOAuthIntegration': True,
            'integrationId': token_store.get_integration_id(server_id)
        }

    def enable_server(self, server_id: str) -> bool:
        """Enable an MCP server."""
        config = self._config_manager.get_server_config(server_id)
        if not config:
            return False

        config['enabled'] = True
        self._config_manager.save_server_config(config)
        logger.info(f"[MCP] Enabled server: {server_id}")
        return True

    def disable_server(self, server_id: str) -> bool:
        """Disable an MCP server and disconnect if connected."""
        config = self._config_manager.get_server_config(server_id)
        if not config:
            return False

        config['enabled'] = False
        self._config_manager.save_server_config(config)

        if server_id in self.connections:
            asyncio.create_task(self.disconnect(server_id))

        logger.info(f"[MCP] Disabled server: {server_id}")
        return True

    def update_tool_enabled(self, server_id: str, tool_name: str, enabled: bool) -> bool:
        """Update enabled/disabled state for a specific tool."""
        return self._whitelist_manager.update_tool_enabled(
            server_id, tool_name, enabled, self.tools_cache
        )

    async def connect_all_enabled(self) -> Dict[str, Dict]:
        """Connect to all enabled MCP servers."""
        results = {}
        configs = self._config_manager.load_all_configs()

        for server_id, config in configs.items():
            if config.get('enabled', True):
                try:
                    logger.info(f"[MCP] Auto-connecting: {server_id}")
                    server_info = await self.connect(server_id)
                    results[server_id] = {'success': True, 'server': server_info}
                except Exception as e:
                    logger.error(f"[MCP] Failed to auto-connect {server_id}: {e}")
                    results[server_id] = {'success': False, 'error': str(e)}

        return results

    def update_config_file(self, new_json_content: str) -> Dict[str, Any]:
        """Update the entire config file and apply changes."""
        return self._config_manager.update_config_file(
            new_json_content,
            disconnect_callback=self.disconnect,
            connect_callback=self.connect
        )

    def get_config_file_content(self) -> str:
        """Get the raw JSON file content."""
        return self._config_manager.get_config_file_content()


def get_mcp_service() -> MCPConnectionService:
    """Get singleton instance of MCP service."""
    return MCPConnectionService.get_instance()
