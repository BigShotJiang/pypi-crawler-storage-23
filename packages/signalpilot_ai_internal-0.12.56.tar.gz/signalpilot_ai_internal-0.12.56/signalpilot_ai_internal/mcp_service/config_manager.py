"""
MCP Config Manager - Handles loading, saving, and normalizing MCP server configurations.
"""
import asyncio
import json
import logging
import uuid
from typing import Dict, Any, Optional

from .constants import BUILTIN_SERVERS, get_builtin_servers
from .errors import MCPConfigError

logger = logging.getLogger(__name__)


class MCPConfigManager:
    """Manages MCP server configuration persistence and normalization."""

    def __init__(self, home_manager):
        """Initialize the config manager."""
        self._home_manager = home_manager

    def _infer_server_type(self, config: Dict) -> str:
        """Infer server type from config structure."""
        if 'command' in config:
            return 'command'
        if 'url' in config:
            return 'http'
        return config.get('type', 'command')

    def normalize_from_storage(self, server_id: str, config: Dict[str, Any]) -> Dict[str, Any]:
        """Convert storage format to internal format."""
        normalized: Dict[str, Any] = {'id': server_id, 'type': self._infer_server_type(config)}
        normalized.update(config)

        if 'name' not in normalized:
            normalized['name'] = server_id

        if 'enabled' not in normalized:
            normalized['enabled'] = True

        return normalized

    def normalize_for_storage(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Convert internal format to storage format."""
        storage: Dict[str, Any] = {}
        server_type = config.get('type') or self._infer_server_type(config)

        if server_type == 'command':
            storage['command'] = config['command']
            if 'args' in config:
                storage['args'] = config['args']
            if 'env' in config and not config.get('isOAuthIntegration'):
                storage['env'] = config['env']
        else:
            storage['name'] = config['name']
            storage['url'] = config['url']
            if 'token' in config:
                storage['token'] = config['token']

        if not config['enabled']:
            storage['enabled'] = False

        if 'enabledTools' in config:
            storage['enabledTools'] = config['enabledTools']

        if config.get('isOAuthIntegration'):
            storage['isOAuthIntegration'] = True

        return storage

    def is_builtin_server(self, server_id: str) -> bool:
        """Check if a server is a built-in server."""
        return server_id in BUILTIN_SERVERS

    def save_server_config(self, server_config: Dict) -> Dict:
        """Save MCP server configuration to JSON file.

        Built-in servers cannot be modified via this method.
        """
        if 'id' not in server_config:
            server_config['id'] = str(uuid.uuid4())

        server_id = server_config['id']

        # Don't persist built-in servers to user config
        if self.is_builtin_server(server_id):
            logger.debug(f"[MCP] Skipping save for built-in server: {server_id}")
            return server_config

        storage_config = self.normalize_for_storage(server_config)

        if not self._home_manager.set_mcp_server(server_id, storage_config):
            raise MCPConfigError(f"Failed to write MCP config for {server_id}")

        logger.info(f"[MCP] Saved config: {server_config['name']}")
        return server_config

    def _get_builtin_configs(self) -> Dict[str, Dict]:
        """Get normalized built-in server configurations with dynamic port."""
        builtin_servers = get_builtin_servers()
        return {
            server_id: {
                'id': server_id,
                'enabled': True,
                **config
            }
            for server_id, config in builtin_servers.items()
        }

    def load_all_configs(self) -> Dict[str, Dict]:
        """Load all MCP server configurations including built-in servers."""
        # Start with built-in servers (with dynamic port)
        configs = self._get_builtin_configs()
        builtin_ids = set(configs.keys())

        # Merge user-configured servers (user configs can override built-in if needed)
        mcp_servers = self._home_manager.get_mcp_servers()
        for server_id, config in mcp_servers.items():
            # Skip if user somehow added a built-in server to their config
            if server_id not in builtin_ids:
                configs[server_id] = self.normalize_from_storage(server_id, config)

        return configs

    def get_server_config(self, server_id: str) -> Optional[Dict]:
        """Get a specific server configuration. Returns None if not found."""
        # Check built-in servers first (use dynamic port)
        builtin_configs = self._get_builtin_configs()
        if server_id in builtin_configs:
            return builtin_configs[server_id]

        # Then check user configs
        mcp_servers = self._home_manager.get_mcp_servers()
        if server_id in mcp_servers:
            return self.normalize_from_storage(server_id, mcp_servers[server_id])

        return None

    def delete_server_config(self, server_id: str) -> bool:
        """Delete a server configuration.

        Built-in servers cannot be deleted.
        """
        if self.is_builtin_server(server_id):
            logger.warning(f"[MCP] Cannot delete built-in server: {server_id}")
            return False

        return self._home_manager.remove_mcp_server(server_id)

    def _get_user_config_ids(self) -> set:
        """Get IDs of user-configured servers (excluding built-in)."""
        return set(self._home_manager.get_mcp_servers().keys())

    def update_config_file(self, new_json_content: str, disconnect_callback, connect_callback) -> Dict[str, Any]:
        """Update the entire config file and detect changes.

        Built-in servers are ignored - they cannot be modified via config file.
        """
        try:
            new_data = json.loads(new_json_content)
        except json.JSONDecodeError as e:
            raise MCPConfigError(f"Invalid JSON: {e}") from e

        if 'mcpServers' not in new_data:
            raise MCPConfigError("JSON must contain 'mcpServers' object")

        new_servers = new_data['mcpServers']

        # Filter out built-in servers from new config (they shouldn't be in user config)
        new_servers = {k: v for k, v in new_servers.items() if not self.is_builtin_server(k)}
        new_data['mcpServers'] = new_servers

        # Only compare against user-configured servers (not built-in)
        old_user_ids = self._get_user_config_ids()
        new_ids = set(new_servers.keys())

        changes = {
            'added': list(new_ids - old_user_ids),
            'removed': list(old_user_ids - new_ids),
            'modified': [],
            'enabled_changes': []
        }

        # Load old configs for comparison
        old_configs = {
            server_id: self.normalize_from_storage(server_id, config)
            for server_id, config in self._home_manager.get_mcp_servers().items()
        }

        for server_id in new_ids & old_user_ids:
            old_config = old_configs[server_id]
            new_config = self.normalize_from_storage(server_id, new_servers[server_id])

            if old_config['enabled'] != new_config['enabled']:
                changes['enabled_changes'].append({
                    'server_id': server_id,
                    'new_enabled': new_config['enabled']
                })

            if self.normalize_for_storage(old_config) != new_servers[server_id]:
                changes['modified'].append(server_id)

        self._home_manager.write_mcp_config(new_data)

        async def apply_changes():
            for server_id in changes['removed']:
                await disconnect_callback(server_id)

            for server_id in changes['added']:
                new_config = self.normalize_from_storage(server_id, new_servers[server_id])
                if new_config['enabled']:
                    await connect_callback(server_id)

            for change in changes['enabled_changes']:
                server_id = change['server_id']
                if change['new_enabled']:
                    await connect_callback(server_id)
                else:
                    await disconnect_callback(server_id)

            for server_id in changes['modified']:
                new_config = self.normalize_from_storage(server_id, new_servers[server_id])
                await disconnect_callback(server_id)
                if new_config['enabled']:
                    await connect_callback(server_id)

        asyncio.create_task(apply_changes())
        return {'success': True, 'changes': changes}

    def get_config_file_content(self) -> str:
        """Get the raw JSON file content."""
        cursor_data = self._home_manager.read_mcp_config()
        return json.dumps(cursor_data, indent=2)
