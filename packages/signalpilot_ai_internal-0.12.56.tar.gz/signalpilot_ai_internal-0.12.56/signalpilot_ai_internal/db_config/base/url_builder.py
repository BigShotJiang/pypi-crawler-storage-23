"""Base classes for database URL builders."""

from abc import ABC, abstractmethod
from typing import Any, ClassVar, Dict, Optional


class BaseURLBuilder(ABC):
    """Abstract base class for building SQLAlchemy connection URLs."""

    @abstractmethod
    def build(self, config: Dict[str, Any]) -> str:
        """Build SQLAlchemy connection URL from config."""
        raise NotImplementedError

    def _get_required(self, config: Dict[str, Any], key: str) -> str:
        """Get required config value or raise ValueError."""
        value = config.get(key, "")
        if not value:
            raise ValueError(f"{key} is required")
        return value

    def _get_optional(self, config: Dict[str, Any], key: str, default: str = "") -> str:
        """Get optional config value with default."""
        return config.get(key, default)


class StandardURLBuilder(BaseURLBuilder):
    """URL builder for standard databases (postgres, mysql).

    Subclasses define class attributes:
        DRIVER: SQLAlchemy driver prefix (e.g., "postgresql", "mysql+pymysql")
        DEFAULT_PORT: Default port number as string
        URL_PREFIX: Optional prefix to fix in connectionUrl
        URL_PREFIX_FIX: Replacement for URL_PREFIX
    """

    DRIVER: ClassVar[str]
    DEFAULT_PORT: ClassVar[str]
    URL_PREFIX: ClassVar[Optional[str]] = None
    URL_PREFIX_FIX: ClassVar[Optional[str]] = None

    def build(self, config: Dict[str, Any]) -> str:
        """Build connection URL from connectionUrl or components."""
        connection_url = config.get("connectionUrl")
        if connection_url:
            return self._fix_url_prefix(connection_url)

        username = self._get_required(config, "username")
        password = self._get_optional(config, "password")
        host = self._get_optional(config, "host", "localhost")
        port = self._get_optional(config, "port", self.DEFAULT_PORT)
        database = self._get_optional(config, "database")

        return f"{self.DRIVER}://{username}:{password}@{host}:{port}/{database}"

    def _fix_url_prefix(self, url: str) -> str:
        """Fix URL prefix if needed (e.g., mysql:// -> mysql+pymysql://)."""
        if self.URL_PREFIX and self.URL_PREFIX_FIX and url.startswith(self.URL_PREFIX):
            return url.replace(self.URL_PREFIX, self.URL_PREFIX_FIX, 1)
        return url
