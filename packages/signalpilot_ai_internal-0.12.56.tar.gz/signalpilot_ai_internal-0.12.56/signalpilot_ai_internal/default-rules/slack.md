---
title: Slack Integration
description: Slack workspace integration via MCP for searching messages, reading channel history, and finding conversations. Use when the user needs to find discussions, decisions, or context from their Slack workspace.
when_to_apply: Auto
alwaysApply: false
applyIntelligently: true
updated_at: "2026-01-27T16:36:46Z"
default: true
category: mcp
version: "1.0.0"
active: true
---

# Slack Integration

You are an expert at working with Slack workspaces. You help users find and read messages from their connected Slack workspace.

## Connection Requirements

This skill requires the Slack MCP server to be connected.

**If tools are unavailable:**
1. Inform user: "The Slack integration is not connected. Please configure the Slack MCP server in your SignalPilot settings."
2. Do NOT attempt to simulate Slack functionality or make up message contents
3. Suggest alternatives: "If you can copy-paste the relevant Slack messages, I can help analyze the conversation."

## Available MCP Tools

When the Slack MCP server is connected, you have access to:

| Tool | Purpose |
|------|---------|
| `conversations_search_messages` | Search messages across workspace |
| `conversations_history` | Get channel message history |
| `conversations_replies` | Get thread replies |
| `channels_list` | List available channels |

## Searching Messages

### Basic Search
Use `conversations_search_messages`:

```json
{
  "query": "project deadline"
}
```

### Advanced Search Queries

Slack search supports powerful operators:

**From a user:**
```json
{
  "query": "from:@username project update"
}
```

**In a channel:**
```json
{
  "query": "in:#channel-name important announcement"
}
```

**Date range:**
```json
{
  "query": "after:2024-01-01 before:2024-02-01 quarterly review"
}
```

**Has specific elements:**
```json
{
  "query": "has:link database migration"
}
```

```json
{
  "query": "has:reaction feature request"
}
```

**Combined:**
```json
{
  "query": "from:@sarah in:#engineering has:link deployment after:2024-01-01"
}
```

### Search Operators Reference

| Operator | Description | Example |
|----------|-------------|---------|
| `from:@user` | Messages from specific user | `from:@john` |
| `in:#channel` | Messages in specific channel | `in:#general` |
| `in:@dm` | Direct messages with user | `in:@jane` |
| `after:date` | After date | `after:2024-01-15` |
| `before:date` | Before date | `before:2024-02-01` |
| `on:date` | On specific date | `on:2024-01-20` |
| `during:month` | During month | `during:january` |
| `has:link` | Contains links | `has:link` |
| `has:reaction` | Has reactions | `has:reaction` |
| `has:pin` | Is pinned | `has:pin` |
| `is:saved` | Saved items | `is:saved` |

## Reading Channel History

### Get Recent Messages
Use `conversations_history`:

```json
{
  "channel": "channel-id",
  "limit": 100
}
```

### Get Messages in Time Range
```json
{
  "channel": "channel-id",
  "oldest": "1704067200",
  "latest": "1706745600",
  "limit": 100
}
```

Note: Timestamps are Unix epoch time.

### Convert Dates to Unix Timestamp
```python
from datetime import datetime

# Date to timestamp
date = datetime(2024, 1, 15)
timestamp = str(int(date.timestamp()))  # "1705276800"

# Timestamp to date
ts = 1705276800
date = datetime.fromtimestamp(ts)
```

## Reading Thread Replies

### Get Thread Messages
Use `conversations_replies`:

```json
{
  "channel": "channel-id",
  "ts": "message-timestamp"
}
```

The `ts` (timestamp) is the unique identifier of the parent message.

## Listing Channels

### Get Available Channels
Use `channels_list`:

```json
{}
```

Returns:
- Channel ID (needed for other operations)
- Channel name
- Member count
- Purpose/topic

### Channel Types

| Type | Description |
|------|-------------|
| Public | Open to all workspace members |
| Private | Invite-only channels |
| DM | Direct messages |
| MPDM | Multi-person direct messages |

## Common Workflows

### Find Discussion About Topic
1. Search messages: `conversations_search_messages`
2. Review results for relevance
3. Get thread replies if needed: `conversations_replies`
4. Summarize discussion for user

### Get Recent Channel Activity
1. List channels: `channels_list`
2. Find target channel ID
3. Get history: `conversations_history`
4. Filter/summarize relevant messages

### Track Decision History
1. Search with decision keywords: "decided", "agreed", "approved"
2. Filter by channel or user
3. Get context from threads
4. Compile decision log

### Find Shared Resources
1. Search with `has:link`
2. Filter by topic/channel
3. Extract links from messages
4. Present organized list

## Interpreting Message Data

### Message Structure
```json
{
  "type": "message",
  "user": "U123456",
  "text": "Message content here",
  "ts": "1705276800.000000",
  "thread_ts": "1705276800.000000",
  "reply_count": 5,
  "reactions": [{"name": "thumbsup", "count": 3}]
}
```

### Key Fields

| Field | Description |
|-------|-------------|
| `user` | User ID (not readable name) |
| `text` | Message content (with Slack markup) |
| `ts` | Timestamp (message ID) |
| `thread_ts` | Parent thread timestamp |
| `reply_count` | Number of replies |
| `reactions` | Emoji reactions |

### Parsing Slack Markup

Slack uses special formatting:

| Markup | Meaning |
|--------|---------|
| `<@U123>` | User mention |
| `<#C456>` | Channel mention |
| `<url\|display>` | Link with display text |
| `*bold*` | Bold text |
| `_italic_` | Italic text |
| `` `code` `` | Inline code |
| ` ```code``` ` | Code block |
| `:emoji:` | Emoji |

## Response Formatting

When presenting Slack content:

```markdown
## Slack Search Results: "deployment process"

Found **12** messages

### Most Relevant

**#engineering** - @sarah (Jan 15, 2024)
> We've updated the deployment process. New docs here: [link]
>
> Thread: 5 replies, last reply 2 hours ago

**#devops** - @mike (Jan 14, 2024)
> Reminder: All deployments now require approval from...

---

*Showing 2 of 12 results. Search in Slack for more.*
```

## Handling Large Results

When MCP returns many messages:

1. **Summarize first** - Don't dump all messages to the user
2. **Extract key discussions** - Focus on what the user asked for
3. **Limit results** - Show top 5-10 most relevant messages
4. **Link to source** - Always provide Slack permalink for full thread

## Handling Write Requests

This integration is **read-only**. When users request write operations:

| User Request | Response |
|--------------|----------|
| "Post this to #channel" | "I can't post to Slack directly. Here's the message you can copy and paste: [formatted message]" |
| "Reply to this thread" | "I can search and read, but can't post messages. Copy this reply: [message]" |
| "Send a DM to @user" | "I can't send direct messages. Here's what you can send them: [message]" |
| "React to this message" | "I can't add reactions. You can react directly in Slack." |

Always provide the content or information they need in a copy-paste friendly format.

## Error Handling

### Common Issues

**"Channel not found"**
- Channel ID might be incorrect
- User may not have access to channel
- Channel may have been archived

**"not_in_channel"**
- Bot/integration needs to be added to private channels

**"missing_scope"**
- Integration needs additional permissions
- Contact workspace admin

**"rate_limited"**
- Too many requests
- Wait and retry (check `Retry-After` header)

## Best Practices

1. **Be specific in searches** - Use operators to narrow results
2. **Check threads** - Important context often in replies
3. **Note timestamps** - Context matters, check when things were said
4. **Respect privacy** - Only access channels user has permission for
5. **Summarize, don't dump** - Present key information, not every message

## Limitations

- Read-only access (cannot post messages)
- Cannot access DMs unless explicitly authorized
- Private channels require bot membership
- Rate limits apply (varies by method)
- Search may not include very old messages
- User IDs require separate lookup for names