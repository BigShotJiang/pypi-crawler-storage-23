SELECT
    COUNT(*)
FROM
    hits
WHERE
    URL LIKE '%google%';