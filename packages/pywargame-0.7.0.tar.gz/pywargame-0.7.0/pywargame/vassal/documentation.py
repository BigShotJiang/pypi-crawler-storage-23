## BEGIN_IMPORT
from .. common import VerboseGuard
from . base import *
from . element import Element
from . gameelements import GameElement
## END_IMPORT

# ====================================================================
def createKeyHelp(*args,**kwargs):
    '''Creates a help file with key-bindings

    See Documentation.createKeyHelp
    '''
    return Documentation.createKeyHelp(*args,**kwargs)

# --------------------------------------------------------------------
class Documentation(GameElement):
    TAG=Element.MODULE+'Documentation'
    def __init__(self,doc,node=None,**kwargs):
        '''Documentation (or help menu)

        Parameters
        ----------
        doc : Element
            Parent
        node : xml.dom.Element
            Node to read state from
        kwargs : dict
            Attributes
        '''
        super(Documentation,self).__init__(doc,self.TAG,node=node,**kwargs)

    def addAboutScreen(self,**kwargs):
        '''Add a `AboutScreen` element to this

        Parameters
        ----------
        kwargs : dict
            Dictionary of attribute key-value pairs
        
        Returns
        -------
        element : AboutScreen
            The added element
        '''
        return self.add(AboutScreen,**kwargs)
    def addHelpFile(self,**kwargs):
        '''Add a `HelpFile` element to this

        Parameters
        ----------
        kwargs : dict
            Dictionary of attribute key-value pairs
        
        Returns
        -------
        element : HelpFile
            The added element
        '''
        return self.add(HelpFile,**kwargs)
    def addBrowserHelpFile(self,**kwargs):
        '''Add a `BrowserHelpFile` element to this

        Parameters
        ----------
        kwargs : dict
            Dictionary of attribute key-value pairs
        
        Returns
        -------
        element : BrowserHelpFile
            The added element
        '''
        return self.add(BrowserHelpFile,**kwargs)
    def addBrowserPDFFile(self,**kwargs):
        '''Add a `BrowserPDFFile` element to this

        Parameters
        ----------
        kwargs : dict
            Dictionary of attribute key-value pairs
        
        Returns
        -------
        element : BrowserPDFFile
            The added element
        '''
        return self.add(BrowserPDFFile,**kwargs)
    def addTutorial(self,**kwargs):
        '''Add a `Tutorial` element to this

        Parameters
        ----------
        kwargs : dict
            Dictionary of attribute key-value pairs
        
        Returns
        -------
        element : Tutorial
            The added element
        '''
        return self.add(Tutorial,**kwargs)
    def addQuickStart(self):
        '''Add Vassal quick-start entry'''
        return self.add(HelpFile(title    ='Vassal Quick Start',
                                 fileName = '/help/Intro.html',
                                 fileType = HelpFile.RESOURCE,
                                 section  = HelpFile.SYSTEM))
    def getAboutScreens(self):
        return self.getElementsByKey(AboutScreen,'title')
    def getHelpFiles(self):
        return self.getElementsByKey(HelpFile,'title')
    def getBrowserHelpFiles(self):
        return self.getElementsByKey(BrowserHelpFile,'title')
    def getBrowserPDFFiles(self):
        return self.getElementsByKey(BrowserPDFFile,'title')
    def getTutorials(self):
        return self.getElementsByKey(Tutorial,'name')
    
    @classmethod
    def createKeyHelp(cls,keys,title='',version=''):
        '''Creates a help file with key-bindings
        
        Parameters
        ----------
        keys : list of list of str
             List of key-binding documentation
        title : str
             Title of help file
        version : str
             Version number
        
        Returns
        -------
        txt : str
            File content
        '''
        txt = '''
        <html>
        <head>
         <style>
           html {
             color: #1a1a1a;
             background-color: #fdfdfd;
           }
           body {
             margin: 0 auto;
             padding-left: 50px;
             padding-right: 50px;
             padding-top: 50px;
             padding-bottom: 50px;
             hyphens: auto;
             overflow-wrap: break-word;
             text-rendering: optimizeLegibility;
             font-kerning: normal;
             max-width:   600px;
             font-family: serif; 
             font-size:   12px;
             line-height: 1.5;
           }
           @media (max-width: 600px) {
             body {
               font-size: 0.9em;
               padding: 12px;
             }
             h1 {
               font-size: 1.8em;
             }
           }
           @media print {
             html {
               background-color: white;
             }
             body {
               background-color: transparent;
               color: black;
               font-size: 12pt;
             }
             p, h2, h3 {
               orphans: 3;
               widows: 3;
             }
             h2, h3, h4 {
               page-break-after: avoid;
             }
           }
           p {
             margin: 1em 0;
           }
           a {
             color: #1a1a1a;
           }
           a:visited {
             color: #1a1a1a;
           }
           img {
             max-width: 100%;
             text-align: center;
           }
           svg {
             height: auto;
             max-width: 100%;
           }
           h1, h2, h3, h4, h5, h6 {
             margin-top: 15px; 
           }
           h5, h6 {
             font-size: 1em;
             font-style: italic;
           }
           h6 {
             font-weight: normal;
           }
           h1 { margin-top: 30px; }
           h2 { margin-top: 20px; }
           h3 { margin-top: 10px; }
           h4 { margin-top: 10px; }
           ol { padding-left: 10px; margin-top: 5px; }
           ul { padding-left: 10px; margin-top: 5px; }
           li > ol, li > ul {
             margin-top: 0;
           }
           blockquote {
             border-left: 2px solid #e6e6e6;
             color: #606060;
             margin: 16px 0px 16px 20px;
             padding-left: 16px;
           }
           code {
             font-family: Menlo, Monaco, Consolas, 'Lucida Console', monospace;
             font-size: 85%;
             margin: 0;
             hyphens: manual;
           }
           pre {
             margin: 16px 0px;
             overflow: auto;
           }
           pre code {
             padding: 0px;
             overflow: visible;
             overflow-wrap: normal;
           }
           .sourceCode {
            background-color: transparent;
            overflow: visible;
           }
           hr {
             background-color: #1a1a1a;
             border: none;
             height: 1px;
             margin: 1em 0;
           }
           table {
             border-collapse: collapse;
             overflow-x: auto;
             display: block;
             font-variant-numeric: lining-nums tabular-nums;
             margin: 5px;
             border: thin solid gray;
             width:  fit-content;
             max-width: 500px;
             min-width: 10%;
           }
           table caption {
             margin-top:   10px;
             margin-bottom: 5px;
             font-weight: bold;
           }
           tbody {
             margin-top: 0.5em;
             border-top: 1px solid #1a1a1a;
             border-bottom: 1px solid #1a1a1a;
           }
           th {
             border-top: 1px solid #1a1a1a;
             padding: 0.25em 0.5em 0.25em 0.5em;
             padding-left: 5px;
             padding-right: 5px;
             border: none;
           }
           td {
             padding: 0.125em 0.5em 0.25em 0.5em;
             padding-left: 5px;
             padding-right: 5px;
           }
           header {
             margin-bottom: 4em;
             text-align: center;
           }
           .even { 
             background-color: #eef;
           }
           .odd {
             background-color: white;
           }
           .header {
             background-color: #eee;
           }
           #TOC li {
             list-style: none;
           }
           #TOC ul {
             padding-left: 20px;
           }
           #TOC > ul {
             padding-left: 0px;
           }
           #TOC a:not(:hover) {
             text-decoration: none;
           }
           code{white-space: pre-wrap;}
           span.smallcaps{font-variant: small-caps;}
           div.columns{display: flex; gap: min(4vw, 1.5em);}
           div.column{flex: auto; overflow-x: auto;}
           div.hanging-indent{margin-left: 1.5em; text-indent: -1.5em;}
           /* The extra [class] is a hack that increases specificity enough to
              override a similar rule in reveal.js */
           ul.task-list[class]{list-style: none;}
           ul.task-list li input[type="checkbox"] {
             font-size: inherit;
             width: 0.8em;
             margin: 0 0.8em 0.2em -1.6em;
             vertical-align: middle;
           }
           .display.math{display: block; text-align: center; margin: 0.5rem auto;}
         </style>
        </head>
        <body>'''
        txt += f''''
          <h1>{title} (Version {version}) Key bindings</h1>
          <table>
          <tr class=head><th>Key</th><th>Where</th><th>Effect</th></tr>'''
        
        for no, (key, where, description) in enumerate(keys):
            txt += (f'<tr class={"even" if no % 2 == 0 else "odd"}><td>{key}</td>'
                    f'<td>{where}</td>'
                    f'<td>{description}</td></tr>')
        
        txt += '''
          </table>
         </body>
        </html>'''
        
        return txt 

registerElement(Documentation)

# --------------------------------------------------------------------
class AboutScreen(Element):
    TAG = Element.MODULE+'documentation.AboutScreen'
    UNIQUE = ['title']
    def __init__(self,doc,node=None,title='',fileName=""):
        '''Create an about screen element that shows image

        Parameters
        ----------
        doc : Element
            Parent
        node : xml.dom.Element
            Node to read state from
        title : str
            Entry title
        fileName : str
            Internal file name        
        '''
        super(AboutScreen,self).__init__(doc,
                                         self.TAG,
                                         node     = node,
                                         fileName = fileName,
                                         title    = title)
    def getDocumentation(self):
        '''Get Parent element'''
        return self.getParent(Documentation)

registerElement(AboutScreen)

# --------------------------------------------------------------------
class BrowserPDFFile(Element):
    TAG = Element.MODULE+'documentation.BrowserPDFFile'
    UNIQUE = ['title','pdfFile']
    def __init__(self,doc,node=None,title='',pdfFile=''):
        '''Create help menu item that opens an embedded PDF
        
        Parameters
        ----------
        doc : Element
            Parent
        node : xml.dom.Element
            Node to read state from
        title : str
            Entry title
        pdfFile : str
            Internal file name
        '''
        super(BrowserPDFFile,self).__init__(doc,self.TAG,
                                            node    = node,
                                            pdfFile = pdfFile,
                                            title   = title)
    def getDocumentation(self):
        '''Get Parent element'''
        return self.getParent(Documentation)

registerElement(BrowserPDFFile)
    
# --------------------------------------------------------------------
class HelpFile(Element):
    TAG = Element.MODULE+'documentation.HelpFile'
    ARCHIVE = 'archive'
    RESOURCE = 'resource'
    LOCAL = 'file'
    USER = 'user'
    SYSTEM = 'vassal'
    UNIQUE = ['title','fileName']
    def __init__(self,doc,node=None,
                 title='',
                 fileName='',
                 fileType=ARCHIVE,
                 section=USER):
        '''Create a help menu entry that opens an embeddded file
        
        Parameters
        ----------
        doc : Element
            Parent
        node : xml.dom.Element
            Node to read state from
        title : str
            Entry title
        fileName : str
            Internal file name
        fileType : str
            How to find the file.  One of
            - ARCHIVE - for files in the module
            - RESOURCE - for files in the JAR
            - LOCAL - for file-system files (based in Vassal dir)
        section : str
            Which section the help entry goes into (USER or SYSTEM)
        '''
        super(HelpFile,self).__init__(doc,self.TAG,node=node,
                                      fileName  = fileName,
                                      fileType  = fileType,
                                      title     = title,
                                      vassalDoc = section)

    def getDocumentation(self):
        '''Get Parent element'''
        return self.getParent(Documentation)

registerElement(HelpFile)
    
# --------------------------------------------------------------------
class BrowserHelpFile(Element):
    TAG = Element.MODULE+'documentation.BrowserHelpFile'
    UNIQUE = ['title','startingPage']
    def __init__(self,doc,node=None,
                 title='',
                 startingPage='index.html'):
        '''Create a help menu entry that opens an embeddded HTML
        page (with possible sub-pages) file
        
        Parameters
        ----------
        doc : Element
            Parent
        node : xml.dom.Element
            Node to read state from
        title : str
            Entry title
        startingPage : str
            which file to start at
        '''
        super(BrowserHelpFile,self).__init__(doc,self.TAG,node=node,
                                             startingPage=startingPage,
                                             title=title)

    def getDocumentation(self):
        '''Get Parent element'''
        return self.getParent(Documentation)

registerElement(BrowserHelpFile)
    
# --------------------------------------------------------------------
class Tutorial(Element):
    TAG = Element.MODULE+'documentation.Tutorial'
    UNIQUE = ['name','logfile']
    def __init__(self,doc,node=None,
                 name            = 'Tutorial',
                 logfile         = 'tutorial.vlog',
                 promptMessage   = 'Load the tutorial?',
                 welcomeMessage  = 'Press "Step forward" (PnDn) to step through the tutorial',
                 launchOnStartup = True):
        '''Add a help menu item that loads the tutorial

        Also adds the start-up option to run the tutorial


        Parameters
        ----------
        doc : Element
            Parent
        node : xml.dom.Element
            Node to read state from
        name : str
            Name of entry
        logfile : str
            Internal file name
        promptMessage : str
            What to show
        launchOnStartup : bool
            By default, launch tutorial first time running module
        '''
        super(Tutorial,self).__init__(doc,self.TAG,node=node,
                                      name            = name,
                                      logfile         = logfile,
                                      promptMessage   = promptMessage,
                                      welcomeMessage  = welcomeMessage,
                                      launchOnStartup = launchOnStartup)

    def getDocumentation(self):
        '''Get Parent element'''
        return self.getParent(Documentation)

registerElement(Tutorial)
    

#
# EOF
#
