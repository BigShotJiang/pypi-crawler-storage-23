## BEGIN_IMPORT
from ... common import VerboseGuard
from .. trait import Trait
## END_IMPORT

# --------------------------------------------------------------------
class StackTrait(Trait):
    ID = 'stack'
    def __init__(self,
                 board     = '',
                 x         = '',  
                 y         = '',  
                 pieceIds  = [],
                 layer     = -1): 
        '''Create a stack trait in a save file'''
        self.setType()       # NAME
        # print('Piece IDs:',pieceIds)
        self.setState(board      = board,
                      x          = x,
                      y          = y,
                      pieceIds   = ';'.join([str(p) for p in pieceIds]),
                      layer      = f'@@{layer}')

    def print(self,file=None):
        pieceIds = [s for s in self._state[3:-1]]
        layer    = self._state[-1]

        if file is None:
            from sys import stdout
            file = stdout

        nt = max([len(i) for i in self._tnames]) if self._tnames else 0
        ns = max([len(i) for i in self._snames]) if self._snames else 0
        nw = max(nt,ns)

        print(f'Trait ID={self.ID}',file=file)
        print(f' Type:',            file=file)
        for n,v in zip(self._tnames,self._type):
            print(f'  {n:<{nw}s}: {v}',file=file)
        print(f' State:',           file=file)
        for n,v in zip(self._snames[:-2],self._state):
            print(f'  {n:<{nw}s}: {v}',file=file)
        print(f'  {self._snames[-2]:<{nw}s}: {",".join(pieceIds)}')
        print(f'  {self._snames[-1]:<{nw}s}: {layer}')

        
Trait.known_traits.append(StackTrait)

#
# EOF
#
