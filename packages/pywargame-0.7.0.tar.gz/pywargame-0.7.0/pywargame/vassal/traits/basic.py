## BEGIN_IMPORT
from ... common import VerboseGuard
from .. trait import Trait
## END_IMPORT

# --------------------------------------------------------------------
class BasicTrait(Trait):
    ID = 'piece'
    def __init__(self,
                 name      = '',
                 filename  = '',  # Can be empty
                 gpid      = '',  # Can be empty
                 cloneKey  = '',  # Deprecated
                 deleteKey = ''): # Deprecated
        '''Create a basic unit (VASSAL.counters.BasicPiece)'''
        self.setType(cloneKey  = cloneKey,   # CLONEKEY
                     deleteKey = deleteKey,  # DELETEKEY
                     filename  = filename,   # IMAGE  
                     name      = name)       # NAME
        self.setState(map        = 'null', # MAPID (possibly 'null')
                      x          = 0,
                      y          = 0,
                      gpid       = gpid,
                      properties = 0) # PROPERTY COUNT (followed by [; KEY; VALUE]+)

    def getProperties(self):
        n = int(self._state[4])
        return {k: v for k, v in zip(self._state[5::2],
                                     self._state[6::2])}

    def setProperties(self,**kw):
        for k,v in kw.items():
            if k in self._state[5::2]:
                idx = self._state[5::2].index(k)
                self._state[idx*2+6] = str(v)
            else:
                self._state.append(k)
                self._state.append(str(v))

    def hasProperty(self,name):
        return name in self._state[5::2]

    def print(self,file=None):
        super().print(file)
        
        if file is None:
            from sys import stdout
            file = stdout

        for k,v in self.getProperties().items():
            print(f'  {k}: {v}',file=file)
    
Trait.known_traits.append(BasicTrait)

# --------------------------------------------------------------------
class BasicDeck(Trait):
    ID     = 'deck'
    NEVER  = 'Never'
    ALWAYS = 'Always'
    MOUSE2 = 'Via right-click Menu'
    MENU   = 'MenuDefaultUp'
    def __init__(self,
                 drawOutline        = True,
                 color              = '0,0,0', # Color triplet
                 width              = 40,
                 height             = 40,
                 faceDown           = ALWAYS,
                 shuffle            = ALWAYS,
                 allowMultiple      = False,
                 allowSelect        = False,
                 reversible         = False,
                 reshuffleCommand   = '',
                 reshuffleTarget    = '',
                 reshuffleMessage   = '',
                 deckName           = 'Deck',
                 shuffleMsgFormat   = '',
                 reverseMsgFormat   = '',
                 facedownMsgFormat  = '',
                 maxStack           = 10,
                 countExpression    = [],
                 globalCommands     = [], #?
                 onEmptyKey         = '',
                 emptyKey           = '',
                 selectDisplay      = '$BasicName$',
                 selectSort         = '', # Expression
                 restrict           = '',
                 restrictExpression = '',
                 shuffleCommand     = 'Shuffle',
                 reverseCommand     = '',
                 reverseKey         = '',
                 multipleMessage    = 'Draw multiple',
                 specificMessage    = 'Draw specific',
                 faceupMessage      = 'Draw face-up',
                 facedownMessage    = 'Drwa face-down',
                 faceupKey          = '',
                 faceupMsgFormat    = '',
                 flipKey            = '',
                 facedownKey        = '',
                 saveMessage        = 'Save...',
                 saveKey            = '',
                 saveReport         = 'Deck saved',
                 loadMessage        = 'Load...',
                 loadKey            = '',
                 loadReport         = 'Deck loaded',
                 restrictAccess     = False,
                 owners             = ''):
        '''Create a basic unit (VASSAL.counters.BasicPiece)'''
        self.setType(drawOutline         = drawOutline,
                     color               = color,
                     width               = width,
                     height              = height,
                     faceDown            = faceDown,
                     shuffle             = shuffle,
                     allowMultiple       = allowMultiple,
                     allowSelect         = allowSelect,
                     reversible          = reversible,
                     reshuffleCommand    = reshuffleCommand,
                     reshuffleTarget     = reshuffleTarget,
                     reshuffleMessage    = reshuffleMessage,
                     deckName            = deckName,
                     shuffleMsgFormat    = shuffleMsgFormat,
                     reverseMsgFormat    = reverseMsgFormat,
                     facedownMsgFormat   = facedownMsgFormat,
                     maxStack            = maxStack,
                     countExpression     = ','.join(countExpression),
                     globalCommands      = ','.join(globalCommands),
                     onEmptyKey          = onEmptyKey,
                     emptyKey            = emptyKey,
                     selectDisplay       = selectDisplay,
                     selectSort          = selectSort,
                     restrict            = restrict,
                     restrictExpression  = restrictExpression,
                     shuffleCommand      = shuffleCommand,
                     reverseCommand      = reverseCommand,
                     reverseKey          = reverseKey,
                     multipleMessage     = multipleMessage,
                     specificMessage     = specificMessage,
                     faceupMessage       = faceupMessage,
                     facedownMessage     = facedownMessage,
                     faceupKey           = faceupKey,
                     faceupMsgFormat     = faceupMsgFormat,
                     flipKey             = flipKey,
                     facedownKey         = facedownKey,
                     saveMessage         = saveMessage,
                     saveKey             = saveKey,
                     saveReport          = saveReport,
                     loadMessage         = loadMessage,
                     loadKey             = loadKey,
                     loadReport          = loadReport,
                     restrictAccess      = restrictAccess,
                     owners              = owners)
        self.setState(map        = 'null', # MAPID (possibly 'null')
                      x          = 0,
                      y          = 0,
                      isFaceDown = False,
                      pids       = '')

    def getPids(self):
        return [int(s) for s in self._state[4].split(',')]
        
Trait.known_traits.append(BasicDeck)

#
# EOF
#
