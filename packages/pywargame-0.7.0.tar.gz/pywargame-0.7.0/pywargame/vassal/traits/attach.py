## BEGIN_IMPORT
from ... common import VerboseGuard
from .. trait import Trait
from .. base import rgb, key
## END_IMPORT

class AttachTrait(Trait):
    ID = 'attach'
    NOTHING = 'nothing'   # Do nothing
    CLEAR   = 'clear'     # Before attach
    BACK    = 'follow'    # Attach to attaching
    ALL     = 'attachAll' # Attach to attaching and it is attached to
    REMOVE  = 'remove'    # Also remove from other
    def __init__(self,
                 name                    = 'Attachment',
                 description             = '',
                 command                 = '', # Menu entry
                 key                     = '', # Key to attach
                 clearAllMenu            = '', # Meny entry
                 clearAllKey             = '', # Key to clear all
                 expression              = '', # Match expressing
                 ranged                  = False,
                 range                   = 0,
                 fixedRange              = False,
                 filter                  = '',
                 withinDeck              = -1, # All, None, Fixed no
                 target                  = '', # Fast select
                 clearMatchingMenu       = '', # Clear matching Menu
                 clearMatchingKey        = '', # Clear matching key
                 clearMatchingExpression = '', # Clear matching expression
                 onAttach                = NOTHING,
                 onDetach                = NOTHING,
                 beforeAttach            = NOTHING,
                 allowSelf               = False,
                 auto                    = True
                 ):
        super(AttachTrait,self).__init__()
        self.setType(name                    = name,
                     description             = description,
                     command                 = command,
                     key                     = key,
                     clearAllMenu            = clearAllMenu,
                     clearAllKey             = clearAllKey,
                     expression              = expression,
                     ranged                  = ranged,
                     range                   = range,
                     fixedRange              = fixedRange,
                     filter                  = filter,
                     withinDeck              = withinDeck,
                     target                  = target,
                     clearMatchingMenu       = clearMatchingMenu,
                     clearMatchingKey        = clearMatchingKey,
                     clearMatchingExpression = clearMatchingExpression,
                     onAttach                = onAttach,
                     onDetach                = onDetach,
                     beforeAttach            = beforeAttach,
                     allowSelf               = allowSelf,
                     auto                    = auto)
        '''Create an attachment trait

        '''
        self.setState(attached=0)

Trait.known_traits.append(AttachTrait)
#
# EOF
#
