## BEGIN_IMPORT
from ... common import VerboseGuard
from .. trait import Trait
## END_IMPORT

class SkeletonTrait(Trait):
    ID = 'Skeleton'  # Proper definition

    def __init__(self,
                 **kwargs): # Spell these out.
        self.setType(**kwargs.get('types',{})) # Spell these out
        self.setState(**kwargs.get('states',{})) # Spell these out
        
    
Trait.known_traits.append(SkeletonTrait)
#
# EOF
#
