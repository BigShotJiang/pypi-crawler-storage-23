## BEGIN_IMPORT
from ... common import VerboseGuard
from .. trait import Trait
from .. base import hexcolor
## END_IMPORT

# --------------------------------------------------------------------
class BorderTrait(Trait):
    ID = 'border'
    AND = 'AND'
    OR  = 'OR'
    XOR = 'XOR'
    NOR = 'NOR'
    
    def __init__(self,
                 property    = '',
                 description = 'Border outline',
                 thickness   = 2,
                 color       = hexcolor(0xff0000),
                 property2   = '',
                 compareMode = AND):
        '''Put an outline around a piece.

        If no property name is given (the parameter _property_ is the
        empty string `''`), then the outline is always shown.

        If a property name is given (parameters _property_ or
        _property2_), then they are considered `true` if the property
        value is _neither_ `0`, `false`, nor the empty string `''`.

        | Property value | Logical value |
        |----------------|---------------|
        | _empty_        | `false`       |
        | `0`            | `false`       |
        | `false`        | `false`       |
        | _otherwise_    | `true`        |
        

        The outline is shown if the property comparison is true.

        | Mode   | Property    | Property 2   |  Result   |
        |--------|-------------|--------------|-----------|
        | _any_  | `true`      | not given    | `true`    |
        |        | `false`     | not given    | `false`   |
        | `AND`  | `true`      | `true`       | `true`    |
        |        | `true`      | `false`      | `false`   |
        |        | `false`     | `true`       | `false`   |
        |        | `false`     | `false`      | `false`   |
        | `OR`   | `true`      | `true`       | `true`    |
        |        | `true`      | `false`      | `true`    |
        |        | `false`     | `true`       | `true`    |
        |        | `false`     | `false`      | `false`   |
        | `XOR`  | `true`      | `true`       | `false`   |
        |        | `true`      | `false`      | `true`    |
        |        | `false`     | `true`       | `true`    |
        |        | `false`     | `false`      | `false`   |
        | `NOR`  | `true`      | `true`       | `false`   |
        |        | `true`      | `false`      | `false`   |
        |        | `false`     | `true`       | `false`   |
        |        | `false`     | `false`      | `true`    |

        Parameters
        ----------
        property : str
            First property to test, or empty string for always true
        property2 : str
            Second property to test, or empty string for always true
        compareMore : str
            How to combine the two, non-empty, properties
        description : str
            Descriptive comment
        color : str
            Colour of outline
        thickness : int
            Thickness of outline
        '''
        super(BorderTrait,self).__init__()
        self.setType(property    = property,
                     description = description,
                     thickness   = thickness,
                     color       = color,
                     property2   = property2,
                     compareMode = compareMode)
        self.setState()


Trait.known_traits.append(BorderTrait)


#
# EOF
#
