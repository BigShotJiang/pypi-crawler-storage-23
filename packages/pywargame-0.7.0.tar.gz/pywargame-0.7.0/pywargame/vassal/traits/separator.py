## BEGIN_IMPORT
from ... common import VerboseGuard
from .. trait import Trait
## END_IMPORT

class SeparatorTrait(Trait):
    ID = 'menuSeparator'

    def __init__(self,
                 key         = '',  # Keys
                 description = ''):
        self.setType(key         = key,
                     description = description)
        self.setState() # PROPERTY COUNT (followed by [; KEY; VALUE]+)
        
    
Trait.known_traits.append(SeparatorTrait)
#
# EOF
#
