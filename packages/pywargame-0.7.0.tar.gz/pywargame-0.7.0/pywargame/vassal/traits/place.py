## BEGIN_IMPORT
from ... common import VerboseGuard
from .. trait import Trait
from .. base import *
# from .. widget import *
# from .. withtraits import PieceSlot
## END_IMPORT

# --------------------------------------------------------------------
class PlaceTrait(Trait):
    ID      = 'placemark'
    STACK_TOP = 0
    STACK_BOTTOM = 1
    ABOVE = 2
    BELOW = 3

    # How the LaTeX exporter organises the units.  Format with
    # 0: the group
    # 1: the piece name 
    # SKEL_PATH = (PieceWindow.TAG +r':Counters\/'        +
    #              TabWidget.TAG   +r':Counters\/'        +
    #              PanelWidget.TAG +':{0}'         +r'\/'+
    #              ListWidget.TAG  +':{0} counters'+r'\/'+
    #              PieceSlot.TAG   +':{1}')
    @classmethod
    # @property
    def SKEL_PATH(cls):
## BEGIN_IMPORT
        from .. widget import PieceWindow, TabWidget, PanelWidget, ListWidget
        from .. withtraits import PieceSlot
## END_IMPORT

        return (PieceWindow.TAG +r':Counters\/'        +
                TabWidget.TAG   +r':Counters\/'        +
                PanelWidget.TAG +':{0}'         +r'\/'+
                ListWidget.TAG  +':{0} counters'+r'\/'+
                PieceSlot.TAG   +':{1}')
    
    def __init__(self,
                 command         = '', # Context menu name
                 key             = '', # Context menu key
                 markerSpec      = '', # Full path in module
                 markerText      = 'null', # Hard coded message
                 xOffset         = 0,
                 yOffset         = 0,
                 matchRotation   = True,
                 afterKey        = '',
                 description     = '',
                 gpid            = '', # Set in JAVA, but with warning
                 placement       = ABOVE,
                 above           = False,
                 copy            = False, # Copy dynamic properties
                 parameters      = {}, # Name expression
                 version         = 1
                 ):
        '''Create a place marker trait (VASSAL.counter.PlaceMarker)'''
        super(PlaceTrait,self).__init__()
        
        if isinstance(parameters,dict):
            parameters = ','.join([f'{k}:{v}' for k,v in parameters.items()])
        elif isinstance(parameters,list):
            parameters = ','.join([f'{k}:{v}' for k,v, in parameters])
            
        self.setType(command         = command,          # Context menu name
                     key             = key,              # Context menu key
                     markerSpec      = markerSpec,
                     markerText      = markerText,
                     xOffset         = xOffset,
                     yOffset         = yOffset,
                     matchRotation   = matchRotation,
                     afterKey        = afterKey,
                     description     = description,
                     gpid            = gpid,
                     placement       = placement,
                     above           = above,
                     copy            = copy,
                     parameters      = parameters,
                     version         = version)
        self.setState()

    def isEmbedded(self):
        return self['markerSpec'].startswith('+')

    def cleanEmbedded(self):
        if not self.isEmbedded():
            return

        iden, traits       = self.getEmbedded()
        self.setEmbedded(*traits,iden=iden)

    def getEmbedded(self):
        if not self.isEmbedded():
            return None, None

## BEGIN IMPORT
        from .. withtraits import WithTraits
## END IMPORT

        return WithTraits.decodeAdd(self['markerSpec'],embedded=True)

    def setEmbedded(self,*traits,iden='null'):
## BEGIN IMPORT
        from .. withtraits import WithTraits
        from re import sub
## END IMPORT
        code               = WithTraits.encodeAdd(*traits,
                                                  iden=iden.strip('\\'))
        self['markerSpec'] = sub(r'(?<!\\);',r'\;', code).replace('/','\\/')
        self._type[-1] = self._type[-1].strip('\\')
        
    def encode(self,term=False,no=0):
        '''Returns type and state encode

        Overrides base class so that we may escape the embedded piece
        definition here.

        '''
        if self.isEmbedded():
            markerSpec         = self['markerSpec']
            markerSpec         = markerSpec.replace('\t','\\'*(no+1)+'\t')
            self['markerSpec'] = markerSpec
            
        return super().encode(term=term,no=no)
        
Trait.known_traits.append(PlaceTrait)

# --------------------------------------------------------------------
class ReplaceTrait(PlaceTrait):
    ID = 'replace'
    def __init__(self,
                 command         = '', # Context menu name
                 key             = '', # Context menu key
                 markerSpec      = '', # Full path in module
                 markerText      = 'null', # Hard message
                 xOffset         = 0,
                 yOffset         = 0,
                 matchRotation   = True,
                 afterKey        = '',
                 description     = '',
                 gpid            = '', # Set in JAVA
                 placement       = PlaceTrait.ABOVE,
                 above           = False,
                 copy            = False, # Copy dynamic properties
                 parameters      = {}, # Name expression
                 version         = 1
                 ):
        super(ReplaceTrait,self).__init__(
            command         = command, 
            key             = key,  
            markerSpec      = markerSpec,
            markerText      = markerText,
            xOffset         = xOffset,
            yOffset         = yOffset,
            matchRotation   = matchRotation,
            afterKey        = afterKey,
            description     = description,
            gpid            = gpid,
            placement       = placement,
            above           = above,
            copy            = copy,
            parameters      = parameters,
            version         = version)
    

Trait.known_traits.append(ReplaceTrait)

#
# EOF
#
