#!/usr/bin/env python

def scaleMain():
    from argparse         import ArgumentParser, FileType
    from pywargame        import version_string
    from pywargame.common import Verbose
    from pywargame.vassal import VMod

    ap = ArgumentParser(description='Scale a .vsav file')
    ap.add_argument('input',type=FileType('rb'),help='Input save')
    ap.add_argument('-f','--factor',type=float,default=1,
                    help='Scaling factor')
    ap.add_argument('--version',action='version',version=version_string)
    ap.add_argument('--verbose','-V',action='store_true',help='Be verbose')

    args = ap.parse_args()

    Verbose().setVerbose(args.verbose)

    VMod.scaleModule(args.input, args.factor)

if __name__ == '__main__':
    scaleMain()
