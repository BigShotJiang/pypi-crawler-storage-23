#!/usr/bin/env python
## BEGIN_IMPORT
from pywargame.vassal import SaveIO, VMod
from pywargame import version_string
## END_IMPORT

# ====================================================================
def saveMain():
    from argparse import ArgumentParser,  \
        RawDescriptionHelpFormatter, \
        FileType
    from textwrap import wrap, dedent
    from pathlib import Path

    w = lambda s : '\n\n'.join(['\n'.join(wrap(p))
                                for p in dedent(s).split('\n\n')])
    w = lambda s : '\n\n'.join(dedent(s).split('\n\n'))
    e = '''
        The input JSON file should have the format

            {
                [mapName]: {
                    [boardName]: {
                        [zoneName]: {
                            [places]
                        }
                    }
                }
            }

        where places can be either

            {
                 [location]: [list of piece names]
            }

        or

            {
                [pieceName]: [location]
            }
        '''
    ap = ArgumentParser(description='Create a scenario from JSON data',
                        formatter_class= RawDescriptionHelpFormatter,
                        epilog=w(e))
    ap.add_argument('module',type=FileType('rb'),help='Module')
    ap.add_argument('setup', type=FileType('r'), help='Setup JSON')
    ap.add_argument('-n','--name', type=str, help='Name of save',
                    default='Save')
    ap.add_argument('-o','--output',type=FileType('w'),help='Output file',
                    default='Save.vsav')
    ap.add_argument('-V','--verbose',action='store_true',
                    help='Be verbose')
    ap.add_argument('--version',action='version',version=version_string)

    args = ap.parse_args()

    vmodname = args.module.name
    args.module.close()

    from json import load
    setup = load(args.setup)
    
    with VMod(vmodname, 'r') as vmod:
        SaveIO.writeScenario(setup, vmod, args.name, args.output)


# ====================================================================
if __name__ == '__main__':
    saveMain()

#
#
#
    
        
                        
