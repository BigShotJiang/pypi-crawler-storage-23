from deepx_dock._version import __version__

