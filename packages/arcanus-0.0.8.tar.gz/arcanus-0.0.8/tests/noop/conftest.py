from __future__ import annotations

# NoOp Materia test fixtures
# This module contains fixtures specific to testing the NoOpMateria implementation.
# NoOpMateria allows transmuters to work as normal Pydantic models without a provider.
