"""Static resource files for the project.

Place static resource files here (templates, data files, etc.).
Resources can be accessed at runtime using `pyrig.src.resource.resource_path()`.
"""
