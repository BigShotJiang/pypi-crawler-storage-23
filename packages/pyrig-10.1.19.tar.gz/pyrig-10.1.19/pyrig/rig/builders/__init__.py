"""Custom artifact builders for creating distributable packages.

Add custom `BuilderConfigFile` subclasses here to create project-specific artifacts.
Builders are automatically discovered and executed when running `pyrig build`.
"""
