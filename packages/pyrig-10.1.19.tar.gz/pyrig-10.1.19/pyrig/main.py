"""Main entrypoint module for pyrig."""


def main() -> None:
    """Run the main entrypoint for the project."""


if __name__ == "__main__":
    main()
