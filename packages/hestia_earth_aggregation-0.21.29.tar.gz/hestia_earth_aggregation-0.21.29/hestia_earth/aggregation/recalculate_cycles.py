import os
import json
from hestia_earth.orchestrator import run

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(CURRENT_DIR, "config", "Cycle")
_TERM_TYPES = os.listdir(CONFIG_PATH)


def _load_config(term_type: str):
    with open(os.path.join(CONFIG_PATH, f"{term_type}.json")) as f:
        return json.load(f)


def should_recalculate(product: dict):
    return f"{product.get('termType')}.json" in _TERM_TYPES


def recalculate(cycle: dict, product: dict):
    return run(cycle, _load_config(product.get("termType")))
