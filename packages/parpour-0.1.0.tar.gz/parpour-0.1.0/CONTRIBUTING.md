# Contributing

## Development Setup

1. Clone the repository.
2. Install project dependencies.
3. Run local quality checks before opening a pull request.

## Branching

- Use short-lived feature/fix branches.
- Keep commits atomic and focused.

## Pull Requests

- Include scope, intent, and validation evidence.
- Link relevant specs, trackers, or issues.
- Ensure CI and quality checks are green.
