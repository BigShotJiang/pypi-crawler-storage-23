# Security Policy

## Supported Versions

The default branch is the supported release line.

## Reporting a Vulnerability

Please report vulnerabilities privately through GitHub Security Advisories or direct maintainer contact.
Do not post sensitive details in public issues.

## Response Targets

- Acknowledge: within 2 business days
- Triage: within 5 business days
- Mitigation plan: as soon as reproducibility is confirmed
