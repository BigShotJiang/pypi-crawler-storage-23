# Changelog

All notable changes to this project will be documented in this file.

## Unreleased

- Initial project scaffolding and governance setup.
