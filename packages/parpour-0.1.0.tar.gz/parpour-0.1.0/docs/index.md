# parpour

Venture Autonomy Platform & CIV Sim Planning Workspace.

Documentation for the parpour specification, standards, and planning tools.

## Key Sections

- [Guides](/guides/) — Implementation guides and best practices
- [Specs](/specs/) — Technical specifications and planning documents
- [Quality Gates](/QUALITY_GATES.md) — 9-gate quality system documentation
