# Topic -> Chunk Map

## Artifact IR Type System (SlideSpec, DocSpec, TimelineSpec, AudioSpec, BoardSpec)
- chunk_001.md — Core artifact compiler architecture and rich marketing material types
- chunk_002.md — Slotting NanoBanana (image) + Veo (video) into headless artifact compiler pipeline

## Headless Rendering Pipelines
- chunk_002.md — Fully headless artifact compiler pipeline design and key primitives
- chunk_003.md — Veo 3.1 headless async jobs, image-to-video, reference image support

## NanoBanana & Veo Integration
- chunk_002.md — NanoBanana image + Veo video integration architecture
- chunk_003.md — Veo 3.1 specifics: headless, async, image-to-video, 3-reference support

## Mobile App Build & Launch (Agent-Driven)
- chunk_004.md — Practical walk-through: building, launching, selling, and marketing a mobile app (B2B + B2C)
- chunk_005.md — No-BS guide: designing, building, and selling a mobile app fully agent-driven
- chunk_006.md — Fully agent-driven, no-HITL mobile app factory / company-in-a-box architecture

## Autonomous Digital Commerce Organism
- chunk_006.md — Agent-driven, no-HITL company-in-a-box design
- chunk_007.md — Fully autonomous digital commerce organism (beyond mobile app factory)

## Autonomous Physical Production & Commerce
- chunk_008.md — Leaving digital commerce; entering autonomous physical production + commerce systems (10k+ lines)

## Research Benchmarks & Simulation Environments
- chunk_009.md — Real-world research benchmarks and simulation environments for economics and autonomous agents

## Zero-HITL Venture Organism: Labor & Services Class Map
- chunk_010.md — 5-year labor + services class map for zero-HITL venture organism; real vendor categories

## Agent Frameworks, Orchestration & SaaS Primitives
- chunk_011.md — Current landscape of agent frameworks, orchestration systems, security tooling, SaaS primitives

## Agent Governance, Identity & Isolation
- chunk_012.md — Clean approach to agent governance, identity, isolation ("always-on office" control plane), prompt injection defense

## Treasury & Financial Control (Programmable Spend Firewall)
- chunk_013.md — Programmable treasury + spend firewall; agents only hit narrow authorized spend surfaces
- chunk_014.md — Real banking infrastructure for agents; agents never have direct bank access; narrow API surface only

## AI Venture Capital / Sovereign Fund Architecture
- chunk_008.md — Autonomous physical production systems; sovereign-scale autonomous commerce
- chunk_013.md — Programmable treasury architecture relevant to VC/sovereign fund control structures

## Compliance Automation (Zero-HITL)
- chunk_015.md — Boring compliance automation as leverage for zero-HITL systems; compliance-first design for autonomous orgs

## Deterministic Build & Idempotency
- chunk_002.md — Headless artifact compiler pipeline; deterministic artifact generation
- chunk_003.md — Veo 3.1 headless async jobs; deterministic rendering

## Autonomous Agent Commerce (End-to-End)
- chunk_006.md — No-HITL agent-driven company-in-a-box
- chunk_007.md — Fully autonomous digital commerce organism
- chunk_008.md — Physical production + autonomous commerce systems
- chunk_010.md — Zero-HITL venture organism labor and services class map
- chunk_011.md — Agent frameworks and orchestration landscape
- chunk_012.md — Agent governance and isolation control plane
- chunk_013.md — Programmable treasury and spend firewall
- chunk_014.md — Banking infrastructure for autonomous agents
- chunk_015.md — Compliance automation for zero-HITL orgs

## chunk_008 Sub-Parts (Physical Production & Autonomous Commerce — 10k lines)
See chunk_008_parts/INDEX.md for fine-grained navigation within this chunk.
