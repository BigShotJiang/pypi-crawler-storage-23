### **ChatGPT**

Research vend bench and other more economic or world based benchmarks and agent sim envs, will be highly useful to borrow their principles

---

