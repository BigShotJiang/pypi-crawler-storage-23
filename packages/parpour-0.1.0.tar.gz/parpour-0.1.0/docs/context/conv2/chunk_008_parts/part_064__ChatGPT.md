### **ChatGPT**

Remember it's meant to be a zero Hitl loop, the funding and constitution + governanc should suffice

---

