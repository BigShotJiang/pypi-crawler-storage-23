### **ChatGPT**

The assumption is user can grow and scale compute, eventually to data centers but in between say more subscription plans or higher usage etc or weaker llm models  on more local computers..

---

