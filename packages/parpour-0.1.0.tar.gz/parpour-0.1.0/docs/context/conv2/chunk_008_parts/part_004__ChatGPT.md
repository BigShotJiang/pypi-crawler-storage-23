### **ChatGPT**

All of the above, we can go in chunks

---

