### **ChatGPT**

Let's walk through life cycle Evo

User starts with their home 16gb ram laptop, a subscription plan to Claude code that we assume provides 100m input and 100m output a month, 2x usage on opus, 0.5 on haiku (so we have a strong medium and weak perd/cost model)

User pays 200 a mo here for their fungible labor budget, and contributes 100$ of investment capital a month + various ideas or other prompt nudges 

Give me a 5 yr granular timeline of how this system would . support developing this seed and scaling it to a full level "multi national"

---

