# Consolidated Index

## Files

* `CROSS_PROJECT_TRACEABILITY.md`
* `EVENT_TAXONOMY.md`
* `VENTURE_TRACEABILITY_MATRIX.md`

## Subdirectories

