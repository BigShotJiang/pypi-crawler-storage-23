# Technical Specifications

Canonical specification documents for the parpour platform.

All specification files are located at the parpour project root. This directory indexes and links to those specifications.

## Specification Categories

### Core Specifications

- **TECHNICAL_SPEC.md** — Overall technical architecture and system design
- **API_EVENTS.md** — Event schema and API contract documentation

### Planning Tracks

- **TRACK_A.md** — Track A: [Description from TRACK_A.md]
- **TRACK_B.md** — Track B: [Description from TRACK_B.md]
- **TRACK_C.md** — Track C: [Description from TRACK_C.md]

### Implementation Guides

- **VENTURE_SPEC.md** — Venture platform specifications
- **CIV_SIM_SPEC.md** — CIV simulation specifications

## How to Use

1. Start with **TECHNICAL_SPEC.md** for the overall system architecture
2. Review relevant track specs (TRACK_A/B/C) for your work area
3. Consult **API_EVENTS.md** for event/API contract details
4. Use **VENTURE_SPEC.md** and **CIV_SIM_SPEC.md** for implementation details

## Spec Standards

All specifications follow these standards:

- Stored at parpour project root (not in subdirectories)
- Maintained in Markdown format
- Include clear descriptions, diagrams, and examples
- Cross-referenced with code via FR IDs and traceability markers
- Updated as part of feature development (not deferred)

See [Quality Gates](/QUALITY_GATES.md) for enforcement of specification standards.
