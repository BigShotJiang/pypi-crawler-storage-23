# Guides

Implementation guides and best practices for parpour development.

## Available Guides

- [Anti-Patterns](/guides/anti-patterns.md) — Code anti-patterns to avoid
- [Quality Gates](/QUALITY_GATES.md) — 9-gate quality system
- [Agent Orchestration](/guides/agent-orchestration.md) — Running autonomous agents
