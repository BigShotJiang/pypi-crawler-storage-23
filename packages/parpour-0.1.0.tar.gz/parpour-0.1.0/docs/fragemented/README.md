# Fragmented Markdown Consolidation

Source files retained from docs by date filter: 120

Usage: source docs are authoritative; this directory keeps a deterministic subset for consolidation/merge operations.
