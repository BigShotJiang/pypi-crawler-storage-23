# Consolidated Index

## Files

* `ADR-001-workspace-structure.md`
* `ADR-002-headless-artifact-compiler.md`
* `ADR-003-joule-treasury-integration.md`

## Subdirectories

