# Consolidated Index

## Files

* `QUALITY_GATES.md`

## Subdirectories

* `adr/index.md`
* `adr/merged.md`
* `governance/index.md`
* `governance/merged.md`
* `guides/index.md`
* `guides/merged.md`
* `reference/index.md`
* `reference/merged.md`
* `research/index.md`
* `research/merged.md`
* `specs/index.md`
* `traceability/index.md`
* `traceability/merged.md`
