# Consolidated Index

## Files

* `GOVERNANCE_SUMMARY.md`
* `QUALITY_GATES.md`

## Subdirectories

