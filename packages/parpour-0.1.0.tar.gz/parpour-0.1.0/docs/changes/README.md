# Change Documentation

Each significant change should include:

- proposal.md
- design.md
- tasks.md

Archive completed change docs under docs/changes/archive/.
