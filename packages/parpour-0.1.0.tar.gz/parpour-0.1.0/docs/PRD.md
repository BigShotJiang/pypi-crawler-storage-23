# Product Requirements Document (PRD)

Product requirements for **parpour**.

---

## Milestones

| Milestone | Target | Status |
|-----------|--------|--------|
| v1.0 | TBD | 🔴 Pending |

---

*Last updated: 2026-02-23*
