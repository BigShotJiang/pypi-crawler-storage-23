import { defineConfig } from 'vitepress'

// Supported locales: en, zh-CN, zh-TW, fa, fa-Latn
const locales = {
  root: {
    label: "English",
    lang: "en",
    title: 'parpour',
    description: 'Venture Autonomy Platform & CIV Sim Planning Workspace'
  },
  "zh-CN": {
    label: "简体中文",
    lang: "zh-CN",
    title: 'parpour',
    description: '风险投资自主平台和CIV模拟规划工作区'
  },
  "zh-TW": {
    label: "繁體中文",
    lang: "zh-TW",
    title: 'parpour',
    description: '風險投資自主平台和CIV模擬規劃工作區'
  },
  fa: {
    label: "فارسی",
    lang: "fa",
    title: 'parpour',
    description: 'پلتفرم استقلال سرمایه گذاری و فضای کاری برنامه ریزی CIV'
  },
  "fa-Latn": {
    label: "Pinglish",
    lang: "fa-Latn",
    title: 'parpour',
    description: 'Venture Autonomy Platform (Latin)'
  }
};

export default defineConfig({
  title: 'parpour',
  description: 'Venture Autonomy Platform & CIV Sim Planning Workspace',
  srcDir: '.',
  outDir: '../docs-dist',
  cleanUrls: true,
  srcExclude: ['fragemented/**', 'context/**'],
  locales,
  markdown: {
    config: (md) => md.set({ html: false })
  },

  themeConfig: {
    nav: [
      { text: 'Home', link: '/' },
      { text: 'Guides', link: '/guides/' },
      { text: 'Specs', link: '/specs/' },
      {
        text: "🌐 Language",
        items: [
          { text: "English", link: "/" },
          { text: "简体中文", link: "/zh-CN/" },
          { text: "繁體中文", link: "/zh-TW/" },
          { text: "فارسی", link: "/fa/" },
          { text: "Pinglish", link: "/fa-Latn/" }
        ]
      }
    ],
    sidebar: 'auto',
    search: { provider: 'local' },
  },
})
