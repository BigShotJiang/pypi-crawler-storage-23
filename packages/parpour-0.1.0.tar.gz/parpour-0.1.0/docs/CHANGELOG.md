# Changelog

All notable changes to **parpour** are documented here.

## [Unreleased]

---

*Last updated: 2026-02-23*
