# PARPOUR Product Backlog

**Last Updated:** 2026-02-23

---

## Sprint 1: Foundation (Current)

### Completed
- [x] API Server setup
- [x] JWT Authentication
- [x] Basic tests
- [x] Technical spec

### In Progress
- [ ] Database connection
- [ ] Connect workflows to DB

---

## Sprint 2: Core Features

### Planned
| Feature | Story Points | Priority |
|---------|-------------|----------|
| Workflow CRUD in DB | 5 | P0 |
| Workflow execution engine | 8 | P0 |
| Task system | 8 | P0 |
| WebSocket real-time | 5 | P1 |

---

## Sprint 3: Policy & Events

### Planned
| Feature | Story Points | Priority |
|---------|-------------|----------|
| Policy CRUD | 3 | P1 |
| Policy evaluation | 5 | P1 |
| NATS integration | 8 | P1 |
| Event publishing | 5 | P1 |

---

## Sprint 4: Security & Performance

### Planned
| Feature | Story Points | Priority |
|---------|-------------|----------|
| RBAC | 5 | P1 |
| Rate limiting | 3 | P1 |
| Redis caching | 5 | P2 |
| Performance tuning | 8 | P2 |

---

## Sprint 5: Observability

### Planned
| Feature | Story Points | Priority |
|---------|-------------|----------|
| Metrics (Prometheus) | 3 | P2 |
| Tracing (OpenTelemetry) | 5 | P2 |
| Structured logging | 3 | P2 |
| Health endpoints | 2 | P2 |

---

## Sprint 6: Production Ready

### Planned
| Feature | Story Points | Priority |
|---------|-------------|----------|
| Docker/K8s deployment | 5 | P2 |
| CI/CD pipeline | 5 | P2 |
| Load testing | 3 | P2 |
| Security audit | 5 | P2 |

---

## Backlog (Unplanned)

| Feature | Story Points | Priority |
|---------|-------------|----------|
| Multi-tenancy | 13 | P2 |
| GraphQL API | 8 | P3 |
| Admin dashboard | 8 | P3 |
| CLI client | 5 | P3 |
| SDK (Python, JS) | 13 | P3 |
| Webhooks | 5 | P3 |
| Audit logs UI | 5 | P3 |

---

## Estimation

| Sprint | Points | Total |
|--------|--------|-------|
| Sprint 1 | 10 | 10 |
| Sprint 2 | 26 | 36 |
| Sprint 3 | 26 | 62 |
| Sprint 4 | 21 | 83 |
| Sprint 5 | 13 | 96 |
| Sprint 6 | 18 | 114 |

**Total Planned: 114 story points**
