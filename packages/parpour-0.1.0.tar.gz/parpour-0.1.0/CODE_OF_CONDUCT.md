# Code of Conduct

This project follows a professional, respectful collaboration model.

## Expectations

- Be respectful and constructive.
- Focus on technical outcomes and clear communication.
- Avoid personal attacks and harassment.

## Reporting

Report unacceptable behavior to repository maintainers through private channels.
