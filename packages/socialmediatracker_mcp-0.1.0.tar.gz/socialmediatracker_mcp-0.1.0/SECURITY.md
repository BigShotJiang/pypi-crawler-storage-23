# Security Architecture

This document provides a comprehensive overview of the security architecture, authentication flow, and token management for the Social Media Tracker MCP Server.

## Table of Contents

1. [Overview](#overview)
2. [Authentication Flow](#authentication-flow)
3. [Hardware-Bound Token Encryption](#hardware-bound-token-encryption)
4. [Token Storage and Lifecycle](#token-storage-and-lifecycle)
5. [Security Guarantees](#security-guarantees)
6. [Threat Model](#threat-model)
7. [Security Best Practices](#security-best-practices)
8. [Troubleshooting Security Issues](#troubleshooting-security-issues)

---

## Overview

The Social Media Tracker MCP Server implements a multi-layered security architecture that combines:

- **OAuth 2.0 Authorization Code Flow** with AWS Cognito
- **Hardware-bound token encryption** using machine-specific identifiers
- **Automatic token refresh** with 30-day validity
- **Midway integration** for user identification
- **Bearer token authentication** for API calls

### Security Principles

1. **Defense in Depth**: Multiple security layers protect credentials
2. **Non-Portability**: Tokens are bound to specific hardware and cannot be transferred
3. **Least Privilege**: Tokens have limited scope and expiration
4. **Secure by Default**: All tokens are encrypted at rest
5. **Zero Trust**: Every request requires valid authentication

---

## Authentication Flow

### Complete End-to-End Flow

```
┌─────────┐         ┌──────────┐         ┌──────────┐         ┌─────────┐         ┌──────────────┐
│  Kiro   │────────▶│   MCP    │────────▶│ Browser  │────────▶│ Cognito │────────▶│ AWS Federate │
│   IDE   │         │  Server  │         │  (User)  │         │  OAuth  │         │   (Amazon)   │
└─────────┘         └──────────┘         └──────────┘         └─────────┘         └──────────────┘
     │                    │                     │                    │                      │
     │                    │                     │                    │                      │
     │  1. Tool Call      │                     │                    │                      │
     │───────────────────▶│                     │                    │                      │
     │                    │                     │                    │                      │
     │                    │  2. Check Midway    │                    │                      │
     │                    │     Cookies         │                    │                      │
     │                    │─────────────────────┘                    │                      │
     │                    │                                           │                      │
     │                    │  3. Check Cached Tokens                  │                      │
     │                    │     (Hardware-Encrypted)                 │                      │
     │                    │──────────────────────┘                   │                      │
     │                    │                                           │                      │
     │                    │  4. If No Valid Token:                   │                      │
     │                    │     Start OAuth Flow                     │                      │
     │                    │──────────────────────────────────────────▶                      │
     │                    │                                           │                      │
     │                    │  5. Open Browser                          │                      │
     │                    │─────────────────────────────────────────▶│                      │
     │                    │                                           │                      │
     │                    │                                           │  6. Redirect to      │
     │                    │                                           │     Amazon Login     │
     │                    │                                           │─────────────────────▶│
     │                    │                                           │                      │
     │                    │                                           │  7. User Authenticates
     │                    │                                           │     with Amazon      │
     │                    │                                           │◀─────────────────────│
     │                    │                                           │                      │
     │                    │                                           │  8. Authorization    │
     │                    │  9. Auth Code                             │     Code             │
     │                    │◀──────────────────────────────────────────│◀─────────────────────│
     │                    │     (via localhost:8080/callback)         │                      │
     │                    │                                           │                      │
     │                    │  10. Exchange Code for Tokens             │                      │
     │                    │──────────────────────────────────────────▶│                      │
     │                    │                                           │                      │
     │                    │  11. Access Token + Refresh Token         │                      │
     │                    │◀──────────────────────────────────────────│                      │
     │                    │                                           │                      │
     │                    │  12. Encrypt & Cache Tokens               │                      │
     │                    │      (Hardware-Bound AES-256)             │                      │
     │                    │──────────────────────┘                    │                      │
     │                    │                                           │                      │
     │                    │  13. Call AgentCore Gateway               │                      │
     │                    │      with Bearer Token                    │                      │
     │  14. Tool Result   │──────────────────────────────────────────────────────────────────▶
     │◀───────────────────│                                           │                      │
     │                    │                                           │                      │
```

### Detailed Flow Steps

#### Step 1-2: Initial Request and User Identification

1. **Kiro IDE** sends a tool call request to the MCP server via stdio
2. **MCP Server** checks for Midway cookies at `~/.midway/cookie`
3. Extracts user alias from cookies (e.g., `sbattoo`)
4. If no Midway session exists, prompts user to run `mwinit`

#### Step 3: Token Cache Check

1. Server attempts to load cached tokens from `~/.socialmediatracker/tokens.enc`
2. Decrypts tokens using hardware-bound encryption key
3. Checks if access token is still valid (not expired)
4. If valid, proceeds directly to Step 13

#### Step 4-8: OAuth Authorization Flow (First Time or Expired)

1. **MCP Server** starts a temporary HTTP server on `localhost:8080`
   - Automatically kills any process blocking port 8080
   - Enables `SO_REUSEADDR` for socket reuse
2. Constructs Cognito authorization URL with parameters:
   ```
   https://{COGNITO_DOMAIN}/oauth2/authorize?
     identity_provider=Amazon&
     redirect_uri=http://localhost:8080/callback&
     response_type=code&
     client_id={CLIENT_ID}&
     scope=openid+email+profile
   ```
3. Opens user's default browser to the authorization URL
4. **Browser** redirects to **AWS Cognito**
5. **Cognito** redirects to **Amazon Federate** for corporate SSO
6. User authenticates with Amazon credentials (Midway-backed)
7. **Amazon Federate** returns authorization to **Cognito**
8. **Cognito** redirects browser to `http://localhost:8080/callback?code=AUTH_CODE`

#### Step 9-11: Token Exchange

1. **MCP Server** receives authorization code via callback handler
2. Displays success page in browser (auto-closes after 3 seconds)
3. Exchanges authorization code for tokens via POST request:
   ```http
   POST https://{COGNITO_DOMAIN}/oauth2/token
   Content-Type: application/x-www-form-urlencoded
   
   grant_type=authorization_code&
   client_id={CLIENT_ID}&
   code={AUTH_CODE}&
   redirect_uri=http://localhost:8080/callback
   ```
4. **Cognito** returns token response:
   ```json
   {
     "access_token": "eyJraWQiOiI...",
     "refresh_token": "eyJjdHkiOiJ...",
     "id_token": "eyJraWQiOiJ...",
     "token_type": "Bearer",
     "expires_in": 3600
   }
   ```

#### Step 12: Token Encryption and Storage

1. Server derives hardware-bound encryption key (see [Hardware-Bound Token Encryption](#hardware-bound-token-encryption))
2. Creates token data structure:
   ```json
   {
     "sbattoo": {
       "access_token": "eyJraWQiOiI...",
       "refresh_token": "eyJjdHkiOiJ...",
       "id_token": "eyJraWQiOiJ...",
       "expires_at": 1709123456.789
     }
   }
   ```
3. Encrypts entire structure with AES-256 (Fernet)
4. Saves to `~/.socialmediatracker/tokens.enc` with `0600` permissions
5. Shuts down temporary callback server

#### Step 13-14: API Call to AgentCore Gateway

1. **MCP Server** initializes Strands `MCPClient` with Bearer authentication
2. Calls AgentCore Gateway via HTTP with:
   ```http
   POST {AGENTCORE_GATEWAY_URL}
   Authorization: Bearer {ACCESS_TOKEN}
   Content-Type: application/json
   
   {tool_call_payload}
   ```
3. **AgentCore Gateway** validates token and executes tool
4. Returns result to **MCP Server**
5. **MCP Server** forwards result to **Kiro IDE**

### Token Refresh Flow

When an access token expires (after ~1 hour):

```
┌──────────┐         ┌─────────┐
│   MCP    │────────▶│ Cognito │
│  Server  │         │  OAuth  │
└──────────┘         └─────────┘
     │                    │
     │  1. Check Token    │
     │     Expiration     │
     │────────────────────┘
     │                    │
     │  2. POST /token    │
     │  grant_type=       │
     │    refresh_token   │
     │───────────────────▶│
     │                    │
     │  3. New Access     │
     │     Token          │
     │◀───────────────────│
     │                    │
     │  4. Update Cache   │
     │────────────────────┘
```

Refresh tokens are valid for 30 days. After 30 days, full OAuth flow is required.

---

## Hardware-Bound Token Encryption

### Overview

Tokens are encrypted using a key derived from machine-specific hardware identifiers, making them **non-portable** across machines. This provides defense-in-depth security even if token files are stolen.

### Key Derivation Process

```
┌──────────────────┐
│  Hardware UUID   │  ← Platform-specific, immutable identifier
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│   Username       │  ← Additional entropy from OS user
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│  PBKDF2-SHA256   │  ← 100,000 iterations
│  (100k rounds)   │
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│  32-byte Key     │  ← AES-256 encryption key
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│  Fernet Cipher   │  ← AES-128 CBC + HMAC-SHA256
└──────────────────┘
```

### Platform-Specific Hardware Identifiers

#### macOS
- **Source**: IOPlatformUUID from IOPlatformExpertDevice
- **Command**: `ioreg -rd1 -c IOPlatformExpertDevice`
- **Example**: `12345678-ABCD-EFGH-IJKL-MNOPQRSTUVWX`
- **Characteristics**:
  - Unique per Mac hardware
  - Survives OS reinstalls
  - Changes only with motherboard replacement
  - Cannot be easily modified

#### Linux
- **Primary Source**: `/sys/class/dmi/id/product_uuid`
- **Fallback Sources**:
  - `/etc/machine-id`
  - `/var/lib/dbus/machine-id`
- **Characteristics**:
  - Unique per physical machine
  - Survives OS reinstalls (product_uuid)
  - Requires root for product_uuid access
  - machine-id regenerates on OS reinstall

#### Windows
- **Source**: Machine GUID from WMI
- **Command**: `wmic csproduct get UUID`
- **Characteristics**:
  - Unique per Windows installation
  - Stored in registry
  - Survives most system changes
  - Changes with motherboard replacement

### Encryption Algorithm

**Fernet (Symmetric Encryption)**
- **Cipher**: AES-128 in CBC mode
- **Authentication**: HMAC-SHA256
- **Key Derivation**: PBKDF2-SHA256 with 100,000 iterations
- **IV**: Randomly generated per encryption
- **Format**: Base64-encoded token with version, timestamp, IV, ciphertext, and HMAC

### Key Storage

1. **Encryption Key**: `~/.socialmediatracker/.key`
   - Permissions: `0600` (read/write for owner only)
   - Content: 32-byte base64-encoded key
   - Verification: Checked against hardware UUID on every startup

2. **Encrypted Tokens**: `~/.socialmediatracker/tokens.enc`
   - Permissions: `0600`
   - Content: Fernet-encrypted JSON
   - Format: Multi-user token storage

### Key Verification

On every startup, the server:

1. Derives key from current hardware UUID + username
2. Compares with stored key in `.key` file
3. If mismatch detected:
   - Raises `Exception` with clear error message
   - Suggests deleting `~/.socialmediatracker/` and re-authenticating
   - Prevents token decryption

This prevents:
- Using tokens copied from another machine
- Using tokens after hardware changes
- Using tokens after username changes

---

## Token Storage and Lifecycle

### File Structure

```
~/.socialmediatracker/
├── .key                 # Hardware-derived encryption key (32 bytes)
└── tokens.enc           # Encrypted token storage (Fernet format)
```

### Token Data Structure

**Decrypted Format** (in memory only):
```json
{
  "user1": {
    "access_token": "eyJraWQiOiI...",
    "refresh_token": "eyJjdHkiOiJ...",
    "id_token": "eyJraWQiOiJ...",
    "expires_at": 1709123456.789
  },
  "user2": {
    "access_token": "eyJraWQiOiI...",
    "refresh_token": "eyJjdHkiOiJ...",
    "id_token": "eyJraWQiOiJ...",
    "expires_at": 1709127890.123
  }
}
```

### Token Lifecycle

```
┌─────────────────┐
│  Initial Auth   │  ← OAuth flow with browser
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Access Token   │  ← Valid for ~1 hour
│  (1 hour TTL)   │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Token Refresh  │  ← Automatic refresh before expiration
│  (30 day TTL)   │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Re-Auth        │  ← Full OAuth flow after 30 days
│  (30+ days)     │
└─────────────────┘
```

### Token Expiration Handling

1. **Access Token Expiration** (~1 hour):
   - Server checks `expires_at` before each API call
   - If expired, automatically refreshes using refresh token
   - Updates cache with new access token
   - Transparent to user

2. **Refresh Token Expiration** (30 days):
   - Refresh attempt fails with 400/401 error
   - Server initiates full OAuth flow
   - Opens browser for re-authentication
   - User must complete login again

3. **Expiration Buffer**:
   - Tokens are considered expired 60 seconds before actual expiration
   - Prevents race conditions and API call failures
   - Ensures smooth user experience

### Token Cleanup

**Manual Cleanup**:
```bash
# Delete all tokens
rm -rf ~/.socialmediatracker/

# Delete specific user tokens (requires Python)
python -c "from socialmediatracker_mcp.token_encryption import TokenEncryption; TokenEncryption().delete_tokens('username')"
```

**Automatic Cleanup**:
- No automatic cleanup implemented
- Tokens remain until manually deleted or overwritten
- Expired tokens are automatically refreshed or re-authenticated

---

## Security Guarantees

### What This Architecture Protects Against

1. **Token Theft from Disk**
   - ✅ Tokens are encrypted with AES-256
   - ✅ Encryption key is hardware-bound
   - ✅ Stolen files are useless on different machines

2. **Token Theft from Memory**
   - ⚠️ Tokens are decrypted in memory during use
   - ⚠️ Memory dumps could expose tokens
   - ✅ Tokens expire after 1 hour (limited window)

3. **Man-in-the-Middle (MITM) Attacks**
   - ✅ All communication uses HTTPS/TLS
   - ✅ OAuth callback uses localhost (not exposed to network)
   - ✅ Authorization code is single-use

4. **Replay Attacks**
   - ✅ Access tokens expire after 1 hour
   - ✅ Authorization codes are single-use
   - ✅ Refresh tokens are rotated on use (Cognito behavior)

5. **Credential Stuffing**
   - ✅ Uses Amazon SSO (Midway) with MFA
   - ✅ No password storage in MCP server
   - ✅ OAuth flow prevents password exposure

6. **Unauthorized Access**
   - ✅ Tokens are user-specific
   - ✅ AgentCore Gateway validates tokens
   - ✅ Territory-based access control at gateway level

### What This Architecture Does NOT Protect Against

1. **Compromised User Account**
   - ❌ If Amazon account is compromised, attacker can authenticate
   - Mitigation: Use strong passwords and MFA on Amazon account

2. **Malicious Code Execution**
   - ❌ If attacker has code execution, they can read tokens from memory
   - Mitigation: Keep system and dependencies updated

3. **Physical Access to Running System**
   - ❌ Attacker with physical access can extract tokens from memory
   - Mitigation: Lock screen when away, use full-disk encryption

4. **Social Engineering**
   - ❌ Attacker could trick user into authenticating on their behalf
   - Mitigation: User education, verify OAuth URLs

---

## Threat Model

### Assumptions

1. **Trusted Execution Environment**
   - User's machine is not compromised
   - Operating system is trustworthy
   - No malware or keyloggers present

2. **Secure Network**
   - TLS/HTTPS connections are secure
   - No MITM attacks on network layer
   - DNS is not poisoned

3. **Trusted Identity Provider**
   - AWS Cognito is secure
   - Amazon SSO (Midway) is secure
   - OAuth implementation is correct

### Attack Scenarios

#### Scenario 1: Stolen Token Files

**Attack**: Attacker copies `~/.socialmediatracker/` directory to their machine

**Defense**:
1. Encryption key is hardware-bound
2. Key verification fails on different machine
3. Token decryption raises exception
4. Attacker cannot use tokens

**Result**: ✅ Attack prevented

#### Scenario 2: Network Eavesdropping

**Attack**: Attacker intercepts network traffic

**Defense**:
1. All OAuth communication uses HTTPS
2. Callback server uses localhost (not exposed)
3. Authorization codes are single-use
4. TLS prevents eavesdropping

**Result**: ✅ Attack prevented

#### Scenario 3: Malicious MCP Client

**Attack**: Malicious Kiro extension tries to steal tokens

**Defense**:
1. Tokens are never exposed via stdio
2. MCP server only returns tool results
3. Token encryption key is not accessible
4. Tokens are stored outside workspace

**Result**: ✅ Attack prevented (tokens not exposed)

#### Scenario 4: Compromised Dependency

**Attack**: Malicious package in dependency chain

**Defense**:
1. ⚠️ Dependencies have access to memory
2. ⚠️ Could potentially extract tokens during use
3. ✅ Tokens expire after 1 hour (limited window)
4. ✅ Regular dependency audits recommended

**Result**: ⚠️ Partial protection (time-limited exposure)

#### Scenario 5: Insider Threat

**Attack**: Malicious user with valid credentials

**Defense**:
1. ✅ Territory-based access control at gateway
2. ✅ Audit logs at AgentCore Gateway
3. ✅ Token is tied to specific user identity
4. ❌ Cannot prevent authorized user from accessing their data

**Result**: ⚠️ Relies on gateway-level access control

---

## Security Best Practices

### For Users

1. **Protect Your Amazon Account**
   - Enable MFA on Amazon account
   - Use strong, unique password
   - Regularly review account activity

2. **Keep Midway Session Active**
   - Run `mwinit` regularly
   - Don't share Midway cookies
   - Log out when done

3. **Secure Your Machine**
   - Use full-disk encryption
   - Lock screen when away
   - Keep OS and software updated
   - Use antivirus/antimalware

4. **Monitor Token Usage**
   - Check `~/.socialmediatracker/` permissions
   - Delete tokens when no longer needed
   - Re-authenticate if suspicious activity

5. **Network Security**
   - Use trusted networks
   - Avoid public Wi-Fi for authentication
   - Use VPN when on untrusted networks

### For Developers

1. **Dependency Management**
   - Regularly audit dependencies
   - Use `pip-audit` or `safety` to check for vulnerabilities
   - Pin dependency versions
   - Review dependency changes before updating

2. **Secret Management**
   - Never log tokens or sensitive data
   - Use environment variables for configuration
   - Don't commit secrets to version control

3. **Error Handling**
   - Don't expose tokens in error messages
   - Sanitize logs before sharing
   - Use generic error messages for auth failures

4. **Code Review**
   - Review all changes to auth code
   - Test token encryption/decryption
   - Verify hardware UUID extraction

5. **Security Testing**
   - Test token portability (should fail)
   - Test token expiration handling
   - Test refresh token rotation
   - Test error scenarios

---

## Troubleshooting Security Issues

### Issue: "Encryption key mismatch"

**Cause**: Tokens were copied from another machine, hardware changed, or username changed

**Solution**:
```bash
rm -rf ~/.socialmediatracker/
# Re-authenticate on next MCP server start
```

### Issue: "No Midway session found"

**Cause**: Midway cookies expired or not present

**Solution**:
```bash
mwinit
# Then restart MCP server
```

### Issue: "Port 8080 already in use"

**Cause**: Another process is using port 8080

**Solution**:
- Server automatically kills blocking process
- If automatic cleanup fails, manually kill process:
  ```bash
  # macOS/Linux
  lsof -ti :8080 | xargs kill -9
  
  # Windows
  netstat -ano | findstr :8080
  taskkill /F /PID <PID>
  ```

### Issue: "Token refresh failed"

**Cause**: Refresh token expired (30 days)

**Solution**:
- Server automatically initiates OAuth flow
- Complete authentication in browser
- Tokens will be cached for another 30 days

### Issue: "Failed to get hardware UUID"

**Cause**: Insufficient permissions or unsupported platform

**Solution**:
- **macOS**: Ensure `ioreg` command is available
- **Linux**: Check permissions on `/sys/class/dmi/id/product_uuid`
  ```bash
  sudo chmod +r /sys/class/dmi/id/product_uuid
  ```
- **Windows**: Ensure `wmic` command is available

### Issue: "Gateway returned 401 Unauthorized"

**Cause**: Token is invalid or expired

**Solution**:
1. Delete cached tokens: `rm -rf ~/.socialmediatracker/`
2. Restart MCP server
3. Complete OAuth flow
4. If issue persists, check AgentCore Gateway configuration

---

## Security Contacts

### Reporting Security Issues

If you discover a security vulnerability, please report it to:

- **Email**: [security-contact-email]
- **Internal**: Create a security ticket in [internal-system]

**Please do not**:
- Open public GitHub issues for security vulnerabilities
- Share vulnerabilities publicly before they are fixed
- Attempt to exploit vulnerabilities in production systems

### Security Updates

- Security patches are released as soon as possible
- Users are notified via [notification-channel]
- Update to latest version immediately when security patches are released

---

## Compliance and Auditing

### Audit Logging

- **MCP Server**: Logs authentication events to stderr
- **AgentCore Gateway**: Logs all API calls with user identity
- **Cognito**: Logs all OAuth events in CloudWatch

### Data Retention

- **Tokens**: Stored until manually deleted or overwritten
- **Logs**: Retained per organizational policy
- **Audit Trails**: Available at AgentCore Gateway level

### Compliance Considerations

- **GDPR**: User can delete tokens at any time
- **SOC 2**: Encryption at rest, audit logging, access control
- **ISO 27001**: Secure authentication, token lifecycle management

---

## Appendix: Cryptographic Details

### Fernet Specification

- **Version**: Fernet v1
- **Cipher**: AES-128-CBC
- **MAC**: HMAC-SHA256
- **Key Derivation**: PBKDF2-HMAC-SHA256
- **IV**: 128-bit random (per encryption)
- **Timestamp**: 64-bit (for TTL support)

### Token Format

```
base64(version || timestamp || iv || ciphertext || hmac)
```

- **version**: 1 byte (0x80)
- **timestamp**: 8 bytes (big-endian)
- **iv**: 16 bytes (random)
- **ciphertext**: variable length (AES-128-CBC)
- **hmac**: 32 bytes (HMAC-SHA256)

### Key Derivation Parameters

- **Algorithm**: PBKDF2-HMAC-SHA256
- **Iterations**: 100,000
- **Salt**: Hardware UUID (platform-specific)
- **Key Length**: 32 bytes (256 bits)
- **Additional Entropy**: Username

---

**Document Version**: 1.0  
**Last Updated**: 2024  
**Maintained By**: Social Media Tracker MCP Team
