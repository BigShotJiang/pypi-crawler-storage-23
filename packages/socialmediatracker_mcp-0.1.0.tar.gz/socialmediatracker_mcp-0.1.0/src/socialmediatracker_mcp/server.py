#!/usr/bin/env python3
"""
Social Media Tracker MCP Server
Stdio-based MCP server that proxies to AgentCore Gateway with Cognito authentication
"""

import asyncio
import logging
import sys
from typing import Optional

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

from .auth_manager import AuthManager, AuthError
from .gateway_client import AgentCoreGatewayClient, GatewayError
from .config import validate_config


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(
            '/tmp/socialmediatracker_mcp_server.log',
            mode='a'
        ),
        logging.StreamHandler(sys.stderr)
    ]
)

logger = logging.getLogger(__name__)


# Global instances (lazy initialized)
auth_manager: Optional[AuthManager] = None
gateway_client: Optional[AgentCoreGatewayClient] = None
_initialized = False
_tool_name_mapping: dict[str, str] = {}  # Maps cleaned name -> original gateway name


def ensure_initialized():
    """
    Lazy initialization of auth manager and gateway client
    Raises appropriate errors if initialization fails
    """
    global auth_manager, gateway_client, _initialized
    
    if _initialized:
        return
    
    try:
        logger.info("Initializing Social Media Tracker MCP Server...")
        
        # Validate configuration
        validate_config()
        logger.info("✓ Configuration validated")
        
        # Initialize auth manager
        if auth_manager is None:
            auth_manager = AuthManager()
            logger.info("✓ Auth manager initialized")
        
        # Get user alias from Midway cookies
        user_alias = auth_manager.get_user_alias()
        logger.info(f"✓ User identified: {user_alias}")
        
        # Get valid access token (handles OAuth flow if needed)
        access_token = auth_manager.get_valid_token(user_alias)
        logger.info("✓ Access token obtained")
        
        # Initialize gateway client
        if gateway_client is None:
            gateway_client = AgentCoreGatewayClient(access_token)
            logger.info("✓ Gateway client initialized")
        
        _initialized = True
        logger.info("✓ MCP Server initialization complete")
        
    except AuthError as e:
        logger.error(f"Authentication error: {e}")
        raise
    except GatewayError as e:
        logger.error(f"Gateway error: {e}")
        raise
    except Exception as e:
        logger.error(f"Unexpected initialization error: {e}", exc_info=True)
        raise


def build_tool_name_mapping(mcp_agent_tools):
    """Build mapping from cleaned tool names to original gateway names"""
    global _tool_name_mapping
    
    _tool_name_mapping = {}
    for agent_tool in mcp_agent_tools:
        original_name = agent_tool.tool_name
        cleaned_name = original_name.split('___', 1)[1] if '___' in original_name else original_name
        _tool_name_mapping[cleaned_name] = original_name
    
    logger.info(f"Built tool name mapping for {len(_tool_name_mapping)} tools")


# Create MCP server instance
server = Server("socialmediatracker")


@server.list_tools()
async def list_tools() -> list[Tool]:
    """
    List all available tools from AgentCore Gateway
    Tools are discovered dynamically, no hardcoding required
    """
    try:
        # Ensure initialization in thread pool (sync code)
        await asyncio.to_thread(ensure_initialized)
        
        # Get tools from gateway in thread pool (sync code)
        # These are MCPAgentTool objects from strands
        mcp_agent_tools = await asyncio.to_thread(gateway_client.list_tools)
        
        # Build the tool name mapping for call_tool to use
        build_tool_name_mapping(mcp_agent_tools)
        
        # Convert MCPAgentTool objects to MCP Tool objects
        tools = []
        for agent_tool in mcp_agent_tools:
            tool_spec = agent_tool.tool_spec
            
            # Clean up tool name - remove "XXX-API___" prefix
            # e.g., "Activity-API___get_activities_by_customer" -> "get_activities_by_customer"
            tool_name = agent_tool.tool_name
            if '___' in tool_name:
                tool_name = tool_name.split('___', 1)[1]
            
            # Extract inputSchema - it's nested under 'inputSchema' -> 'json'
            input_schema = {}
            if isinstance(tool_spec, dict):
                if 'inputSchema' in tool_spec and isinstance(tool_spec['inputSchema'], dict):
                    if 'json' in tool_spec['inputSchema']:
                        input_schema = tool_spec['inputSchema']['json']
                    else:
                        input_schema = tool_spec['inputSchema']
            
            tools.append(
                Tool(
                    name=tool_name,
                    description=tool_spec.get('description', '') if isinstance(tool_spec, dict) else '',
                    inputSchema=input_schema
                )
            )
        
        logger.info(f"Listed {len(tools)} tools")
        return tools
        
    except AuthError as e:
        logger.error(f"Authentication error in list_tools: {e}")
        return []
    except Exception as e:
        logger.error(f"Error listing tools: {e}", exc_info=True)
        return []


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    """
    Forward tool call to AgentCore Gateway
    All tool logic is handled by the gateway
    """
    try:
        # Ensure initialization in thread pool (sync code)
        await asyncio.to_thread(ensure_initialized)
        
        # Map the cleaned tool name back to the original gateway name using cached mapping
        gateway_tool_name = _tool_name_mapping.get(name)
        
        if not gateway_tool_name:
            error_msg = f"Tool not found: {name}"
            logger.error(error_msg)
            return [TextContent(type="text", text=error_msg)]
        
        logger.info(f"Calling gateway tool: {gateway_tool_name} with args: {arguments}")
        
        # Call tool via gateway in thread pool (sync code) with original name
        result = await asyncio.to_thread(gateway_client.call_tool, gateway_tool_name, arguments)
        
        logger.info(f"Gateway returned result type: {type(result)}")
        logger.info(f"Gateway result: {result}")
        
        # Convert result to MCP TextContent
        # The result from gateway should already be in the right format
        if isinstance(result, list):
            # Check if it's already a list of TextContent
            if result and hasattr(result[0], 'type'):
                logger.info("Result is already TextContent list")
                return result
            # Otherwise convert
            import json
            return [TextContent(type="text", text=json.dumps(result, indent=2))]
        elif isinstance(result, dict):
            # Wrap dict result in TextContent
            import json
            return [TextContent(type="text", text=json.dumps(result, indent=2))]
        else:
            # Convert to string
            return [TextContent(type="text", text=str(result))]
        
    except AuthError as e:
        error_msg = (
            f"Authentication required: {e}\n\n"
            "Please ensure you have run 'mwinit' to authenticate with Midway.\n"
            "The MCP server will automatically open a browser for Cognito authentication."
        )
        logger.error(error_msg)
        return [TextContent(type="text", text=error_msg)]
        
    except GatewayError as e:
        error_msg = f"Gateway error: {e}"
        logger.error(error_msg)
        return [TextContent(type="text", text=error_msg)]
        
    except Exception as e:
        error_msg = f"Unexpected error calling tool {name}: {e}"
        logger.error(error_msg, exc_info=True)
        return [TextContent(type="text", text=error_msg)]


async def run_server():
    """Async server runner"""
    logger.info("Starting Social Media Tracker MCP Server...")
    
    try:
        async with stdio_server() as (read_stream, write_stream):
            logger.info("✓ Stdio server started")
            await server.run(
                read_stream,
                write_stream,
                server.create_initialization_options()
            )
    except KeyboardInterrupt:
        logger.info("Server stopped by user")
    except Exception as e:
        logger.error(f"Server error: {e}", exc_info=True)
        raise
    finally:
        # Cleanup
        if gateway_client:
            gateway_client.cleanup()
        logger.info("✓ Server shutdown complete")


def main():
    """Main entry point for the MCP server (used by package entry point)"""
    try:
        asyncio.run(run_server())
    except KeyboardInterrupt:
        logger.info("Server interrupted")
        sys.exit(0)
    except Exception as e:
        logger.error(f"Fatal error: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
