#!/usr/bin/env python3
"""
AgentCore Gateway Client for Social Media Tracker MCP Server
Manages connection to AgentCore Gateway and dynamically discovers tools
"""

import httpx
import logging
from typing import List, Dict, Any, Optional

from strands.tools.mcp import MCPClient
from mcp.client.streamable_http import streamablehttp_client

from . import config


logger = logging.getLogger(__name__)


class BearerAuth(httpx.Auth):
    """Bearer token authentication for httpx"""
    
    def __init__(self, token: str):
        self.token = token
    
    def auth_flow(self, request: httpx.Request):
        request.headers["Authorization"] = f"Bearer {self.token}"
        yield request


class AgentCoreGatewayClient:
    """
    Manages connection to AgentCore Gateway using Strands MCPClient
    Dynamically discovers and forwards tool calls
    """
    
    def __init__(self, access_token: str):
        self.access_token = access_token
        self.gateway_url = config.AGENTCORE_GATEWAY_URL
        self._mcp_client: Optional[MCPClient] = None
        self._tools_cache: Optional[List[Dict]] = None
        self._session_active = False
        
        logger.info(f"Initializing AgentCore Gateway client for: {self.gateway_url}")
    
    def _ensure_client(self):
        """Ensure MCP client is initialized and session is active"""
        if self._mcp_client is None:
            self._initialize_client()
        
        if not self._session_active:
            self._mcp_client.__enter__()
            self._session_active = True
    
    def _initialize_client(self):
        """Initialize MCPClient with Bearer authentication"""
        try:
            auth = BearerAuth(self.access_token)
            
            transport_factory = lambda: streamablehttp_client(
                url=self.gateway_url,
                auth=auth,
                headers={
                    "Content-Type": "application/json"
                }
            )
            
            self._mcp_client = MCPClient(transport_factory)
            logger.info("✓ MCP client initialized successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize MCP client: {e}")
            raise GatewayError(f"Failed to connect to AgentCore Gateway: {e}")
    
    def list_tools(self) -> List[Dict[str, Any]]:
        """
        Dynamically discover all tools from AgentCore Gateway
        Uses pagination to retrieve all available tools
        """
        if self._tools_cache is not None:
            return self._tools_cache
        
        self._ensure_client()
        
        try:
            tools = []
            pagination_token = None
            
            logger.info("Discovering tools from AgentCore Gateway...")
            
            while True:
                result = self._mcp_client.list_tools_sync(pagination_token=pagination_token)
                
                # The result is a ToolsList object with tools and pagination_token
                # Each tool is an MCPAgentTool object that can be used directly
                tools.extend(result)
                
                # Check for pagination
                if hasattr(result, 'pagination_token') and result.pagination_token:
                    pagination_token = result.pagination_token
                else:
                    break
            
            logger.info(f"✓ Discovered {len(tools)} tools from AgentCore Gateway")
            
            # Cache the tools (they're already MCPAgentTool objects)
            self._tools_cache = tools
            return tools
            
        except Exception as e:
            logger.error(f"Error listing tools from gateway: {e}")
            raise GatewayError(f"Failed to list tools from AgentCore Gateway: {e}")
    
    def call_tool(self, name: str, arguments: Dict[str, Any]) -> Any:
        """
        Forward tool call to AgentCore Gateway
        
        Args:
            name: Tool name
            arguments: Tool arguments
            
        Returns:
            Tool execution result
        """
        self._ensure_client()
        
        try:
            logger.info(f"Calling tool: {name}")
            logger.info(f"Tool arguments: {arguments}")
            
            # Generate a unique tool use ID
            import uuid
            tool_use_id = f"tool-{uuid.uuid4()}"
            
            # Call with tool_use_id as per Strands documentation
            result = self._mcp_client.call_tool_sync(
                tool_use_id=tool_use_id,
                name=name,
                arguments=arguments
            )
            
            logger.info(f"✓ Tool {name} executed successfully")
            logger.info(f"Raw result: {result}")
            
            # Check if result is an error from the gateway
            if isinstance(result, dict):
                if result.get('status') == 'error':
                    error_content = result.get('content', [{}])[0].get('text', str(result))
                    raise GatewayError(f"Gateway returned error: {error_content}")
                
                # Return the content from the result dict
                if 'content' in result:
                    return result['content']
            
            # If result has content attribute (object), return it
            if hasattr(result, 'content'):
                logger.info(f"Result has content attribute: {result.content}")
                return result.content
            
            # Otherwise return as-is
            logger.info("Returning result as-is")
            return result
            
        except Exception as e:
            logger.error(f"Error calling tool {name}: {e}")
            raise GatewayError(f"Failed to call tool {name}: {e}")
    
    def cleanup(self):
        """Clean up MCP client session"""
        if self._mcp_client and self._session_active:
            try:
                self._mcp_client.__exit__(None, None, None)
                self._session_active = False
                logger.info("✓ MCP client session closed")
            except Exception as e:
                logger.error(f"Error closing MCP client session: {e}")


class GatewayError(Exception):
    """Custom exception for gateway errors"""
    pass
