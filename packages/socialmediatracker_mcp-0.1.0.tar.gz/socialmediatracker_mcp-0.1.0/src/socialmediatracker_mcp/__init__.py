"""
Social Media Tracker MCP Server
Stdio-based MCP server with Cognito authentication for AgentCore Gateway
"""

__version__ = "0.1.0"

from .server import main

__all__ = ["main"]
