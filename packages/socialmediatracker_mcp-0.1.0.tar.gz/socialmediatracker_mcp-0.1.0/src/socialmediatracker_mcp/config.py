"""
Configuration for Local MCP Proxy with Cognito Authentication

Configuration is loaded from environment variables. Users can either:
1. Set environment variables directly in their shell
2. Use a .env file in their working directory (loaded by python-dotenv if installed)
3. Set them in their MCP client configuration
"""
import os

# Try to load .env file if python-dotenv is available (optional dependency)
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

# AgentCore Gateway Configuration
AGENTCORE_GATEWAY_URL = os.environ.get("AGENTCORE_GATEWAY_URL", "")

# Cognito Configuration
COGNITO_USER_POOL_ID = os.environ.get("COGNITO_USER_POOL_ID", "")
COGNITO_CLIENT_ID = os.environ.get("COGNITO_CLIENT_ID", "")
COGNITO_DOMAIN = os.environ.get("COGNITO_DOMAIN", "")
AMAZON_IDP_NAME = os.environ.get("AMAZON_IDP_NAME", "federate")

# Local Proxy Configuration
PROXY_HOST = os.environ.get("PROXY_HOST", "localhost")
PROXY_PORT = int(os.environ.get("PROXY_PORT", "8080"))

# Validate required configuration
def validate_config():
    """Validate that all required configuration is present"""
    required = {
        "AGENTCORE_GATEWAY_URL": AGENTCORE_GATEWAY_URL,
        "COGNITO_USER_POOL_ID": COGNITO_USER_POOL_ID,
        "COGNITO_CLIENT_ID": COGNITO_CLIENT_ID,
        "COGNITO_DOMAIN": COGNITO_DOMAIN,
    }
    missing = [k for k, v in required.items() if not v]
    if missing:
        raise ValueError(
            f"Missing required environment variables: {', '.join(missing)}.\n\n"
            f"Please set them using one of these methods:\n"
            f"1. Environment variables: export {missing[0]}=value\n"
            f"2. MCP config env section (recommended for MCP clients)\n"
            f"3. .env file in your working directory (requires python-dotenv)\n\n"
            f"See the README or .env.sample for configuration details."
        )
