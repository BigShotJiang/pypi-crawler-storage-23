"""
Local token encryption using Fernet (AES-128 CBC)
Tokens are encrypted with a hardware-bound, non-portable machine-specific key
"""

from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import os
import sys
import json
import base64
import subprocess
import platform

class TokenEncryption:
    """Handles encryption and decryption of OAuth tokens"""
    
    def __init__(self):
        self.key = self._get_or_create_key()
        self.cipher = Fernet(self.key)
    
    def _get_hardware_uuid(self):
        """
        Get hardware-bound UUID that is unique and non-portable across machines
        This UUID cannot be easily copied to another machine
        """
        system = platform.system()
        
        try:
            if system == 'Darwin':  # macOS
                # Get Hardware UUID from IOPlatformExpertDevice
                # This is the actual hardware UUID, not changeable
                result = subprocess.run(
                    ['ioreg', '-rd1', '-c', 'IOPlatformExpertDevice'],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                
                if result.returncode == 0:
                    # Parse the output to find IOPlatformUUID
                    for line in result.stdout.split('\n'):
                        if 'IOPlatformUUID' in line:
                            # Extract UUID from line like: "IOPlatformUUID" = "XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX"
                            uuid = line.split('"')[3]
                            return uuid
                
                raise Exception("Could not extract IOPlatformUUID from ioreg")
            
            elif system == 'Linux':
                # Try multiple sources for Linux hardware UUID
                uuid_sources = [
                    '/sys/class/dmi/id/product_uuid',  # Most reliable
                    '/etc/machine-id',                  # Fallback
                    '/var/lib/dbus/machine-id'         # Alternative fallback
                ]
                
                for uuid_path in uuid_sources:
                    if os.path.exists(uuid_path):
                        try:
                            with open(uuid_path, 'r') as f:
                                uuid = f.read().strip()
                                if uuid:
                                    return uuid
                        except PermissionError:
                            # Try next source if permission denied
                            continue
                
                raise Exception("Could not read hardware UUID from any Linux source")
            
            elif system == 'Windows':
                # Get Windows machine GUID from registry
                result = subprocess.run(
                    ['wmic', 'csproduct', 'get', 'UUID'],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                
                if result.returncode == 0:
                    lines = result.stdout.strip().split('\n')
                    if len(lines) >= 2:
                        uuid = lines[1].strip()
                        if uuid:
                            return uuid
                
                raise Exception("Could not extract UUID from wmic")
            
            else:
                raise Exception(f"Unsupported operating system: {system}")
        
        except Exception as e:
            raise Exception(
                f"Failed to get hardware UUID on {system}: {e}\n"
                f"This is required for secure token encryption. "
                f"Please ensure you have the necessary permissions."
            )
    
    def _get_or_create_key(self):
        """
        Generate or load encryption key from hardware-bound machine UUID
        The key is derived from non-portable hardware identifiers, making tokens
        non-transferable to other machines
        """
        key_dir = os.path.expanduser('~/.socialmediatracker')
        key_file = os.path.join(key_dir, '.key')
        
        # Get hardware UUID (this will fail on different machines)
        hardware_uuid = self._get_hardware_uuid()
        
        # Get username for additional entropy (system environment variable)
        user = os.getenv('USER') or os.getenv('USERNAME')
        if not user:
            raise Exception(
                "Could not determine username from environment variables (USER or USERNAME). "
                "This is required for token encryption."
            )
        
        # Derive a deterministic key from hardware UUID + username
        # This key will be the same on this machine but different on others
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=hardware_uuid.encode(),
            iterations=100000,
        )
        derived_key = base64.urlsafe_b64encode(kdf.derive(user.encode()))
        
        # Check if we have a stored key
        if os.path.exists(key_file):
            try:
                with open(key_file, 'rb') as f:
                    stored_key = f.read()
                
                # Verify the stored key matches our hardware-derived key
                if stored_key == derived_key:
                    return stored_key
                else:
                    # Key mismatch - this could mean:
                    # 1. Tokens were copied from another machine
                    # 2. Hardware changed
                    # 3. Username changed
                    raise Exception(
                        "Encryption key mismatch! This could indicate:\n"
                        "- Tokens were copied from another machine (not supported)\n"
                        "- Hardware UUID changed\n"
                        "- Username changed\n"
                        "Please delete ~/.socialmediatracker/ and re-authenticate."
                    )
            except Exception as e:
                if "Encryption key mismatch" in str(e):
                    raise
                # If we can't read the key file, regenerate
                print(f"Warning: Could not load encryption key: {e}")
        
        # Store the derived key for verification on next run
        try:
            os.makedirs(key_dir, exist_ok=True)
            with open(key_file, 'wb') as f:
                f.write(derived_key)
            os.chmod(key_file, 0o600)
            print(f"✓ Generated hardware-bound encryption key")
            print(f"  Hardware UUID: {hardware_uuid[:8]}...{hardware_uuid[-8:]}")
            print(f"  Key file: {key_file}")
        except Exception as e:
            print(f"Warning: Could not save encryption key: {e}")
        
        return derived_key
    
    def encrypt_tokens(self, tokens_dict):
        """Encrypt token dictionary"""
        json_data = json.dumps(tokens_dict)
        encrypted = self.cipher.encrypt(json_data.encode())
        return encrypted
    
    def decrypt_tokens(self, encrypted_data):
        """Decrypt token dictionary"""
        try:
            decrypted = self.cipher.decrypt(encrypted_data)
            return json.loads(decrypted.decode())
        except Exception as e:
            raise ValueError(f"Token decryption failed: {e}")
    
    def save_tokens(self, user_alias, tokens):
        """Save encrypted tokens to disk"""
        token_dir = os.path.expanduser('~/.socialmediatracker')
        token_file = os.path.join(token_dir, 'tokens.enc')
        
        # Load existing tokens
        all_tokens = {}
        if os.path.exists(token_file):
            try:
                with open(token_file, 'rb') as f:
                    all_tokens = self.decrypt_tokens(f.read())
            except Exception as e:
                print(f"Warning: Could not load existing tokens: {e}")
                # Start fresh if corrupted
        
        # Add/update user tokens
        all_tokens[user_alias] = {
            'access_token': tokens.get('access_token'),
            'refresh_token': tokens.get('refresh_token'),
            'id_token': tokens.get('id_token'),
            'expires_at': tokens.get('expires_at')
        }
        
        # Encrypt and save
        try:
            encrypted = self.encrypt_tokens(all_tokens)
            os.makedirs(token_dir, exist_ok=True)
            with open(token_file, 'wb') as f:
                f.write(encrypted)
            os.chmod(token_file, 0o600)
        except Exception as e:
            raise Exception(f"Failed to save tokens: {e}")
    
    def load_tokens(self, user_alias):
        """Load encrypted tokens from disk"""
        token_file = os.path.expanduser('~/.socialmediatracker/tokens.enc')
        
        if not os.path.exists(token_file):
            return None
        
        try:
            with open(token_file, 'rb') as f:
                all_tokens = self.decrypt_tokens(f.read())
            return all_tokens.get(user_alias)
        except Exception as e:
            print(f"Warning: Failed to load tokens: {e}")
            return None
    
    def delete_tokens(self, user_alias=None):
        """Delete tokens for a specific user or all tokens"""
        token_file = os.path.expanduser('~/.socialmediatracker/tokens.enc')
        
        if not os.path.exists(token_file):
            return
        
        if user_alias is None:
            # Delete entire file
            try:
                os.remove(token_file)
                print(f"✓ Deleted all tokens")
            except Exception as e:
                print(f"Warning: Could not delete tokens: {e}")
        else:
            # Delete specific user
            try:
                with open(token_file, 'rb') as f:
                    all_tokens = self.decrypt_tokens(f.read())
                
                if user_alias in all_tokens:
                    del all_tokens[user_alias]
                    
                    if all_tokens:
                        # Save remaining tokens
                        encrypted = self.encrypt_tokens(all_tokens)
                        with open(token_file, 'wb') as f:
                            f.write(encrypted)
                        os.chmod(token_file, 0o600)
                    else:
                        # No tokens left, delete file
                        os.remove(token_file)
                    
                    print(f"✓ Deleted tokens for {user_alias}")
            except Exception as e:
                print(f"Warning: Could not delete tokens: {e}")
