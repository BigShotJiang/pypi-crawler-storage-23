from setuptools import setup, find_namespace_packages


with open('README.md') as file:
    long_description = file.read()

setup(
    name = "OpenFisca-France-Data",
    version = "3.8.6",
    description = "OpenFisca-France-Data module to work with French survey data",
    long_description = long_description,
    long_description_content_type="text/markdown",
    author = "OpenFisca Team",
    author_email = "contact@openfisca.fr",
    url = "https://github.com/openfisca/openfisca-france-data",
    license = "http://www.fsf.org/licensing/licenses/agpl-3.0.html",
    keywords = "tax benefit social survey data microsimulation",
    classifiers = [
        "Development Status :: 2 - Pre-Alpha",
        "License :: OSI Approved :: GNU Affero General Public License v3",
        "Operating System :: POSIX",
        "Programming Language :: Python",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Topic :: Scientific/Engineering :: Information Analysis",
        ],
    package_data = {
        'openfisca_france_data': ['assets/aggregats/taxipp/agregats_tests_taxipp_2_0.xlsx',
                                  'reforms/old_openfisca_france_reforms/parameters/*.yaml',
                                  'assets/aggregats/ines/*.json',
                                  'assets/aggregats/france_entiere/*.json'],
        },
    entry_points = {
        'console_scripts': [
            'build-erfs-fpr=openfisca_france_data.erfs_fpr.input_data_builder:main',
            'compare-erfs-fpr-input=openfisca_france_data.erfs_fpr.comparison:compare',
            'create-test-erfs-fpr=openfisca_france_data.erfs_fpr.test_case_creation:create_test',
            'build-pote=openfisca_france_data.pote.input_data_builder.console:main',
            ],
        },
    python_requires = ">=3.10",
    install_requires = [
        "multipledispatch >=0.6.0, <1.0.0",
        "OpenFisca-France >=175.0.0, <176.0.0",
        "OpenFisca-survey-manager >=6.0.0, <7.0.0",
        "OpenFisca-Core == 44.2.2"
        ],
    extras_require = {
        "test": [
            "click >=8.0.0, <9.0.0",
            "autopep8 >=2.0.2, <3",
            "bumpver >=2025.1131",
            "flake8 >=7.0.0, <8.0.0",
            "mypy >=1.0.0, <2.0.0",
            "pypandoc",
            "scipy >=1.2.1, <2.0.0",
            "toolz >=1.0.0, <2.0.0",
            "openpyxl",
            "matplotlib",
            "seaborn"
            ]
        },

    packages = find_namespace_packages(exclude = ("docs", "tests")),
    )
