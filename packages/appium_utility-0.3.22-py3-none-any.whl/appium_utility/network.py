import requests

from appium_utility.decorator import request_validator


class NetworkUtility:

  @request_validator
  def get(
    self,
    url: str,
    headers: dict[str, str] | None = None,
    params: dict[str, str | int] | None = None,
    timeout: int = 30,
  ) -> requests.Response:
    return requests.get(url, headers=headers, params=params, timeout=timeout)

  @request_validator
  def post(
    self,
    url: str,
    body: dict[str, object] | None = None,
    headers: dict[str, str] | None = None,
    params: dict[str, str | int] | None = None,
    timeout: int = 30,
  ) -> requests.Response:
    return requests.post(
      url,
      json=body,
      headers=headers,
      params=params,
      timeout=timeout,
    )

  @request_validator
  def patch(
    self,
    url: str,
    body: dict[str, object] | None = None,
    headers: dict[str, str] | None = None,
    params: dict[str, str | int] | None = None,
    timeout: int = 30,
  ) -> requests.Response:
    return requests.patch(
      url,
      json=body,
      headers=headers,
      params=params,
      timeout=timeout,
    )

  @request_validator
  def put(
    self,
    url: str,
    body: dict[str, object] | None = None,
    headers: dict[str, str] | None = None,
    params: dict[str, str | int] | None = None,
    timeout: int = 30,
  ) -> requests.Response:
    return requests.put(
      url,
      json=body,
      headers=headers,
      params=params,
      timeout=timeout,
    )

  @request_validator
  def delete(
    self,
    url: str,
    headers: dict[str, str] | None = None,
    params: dict[str, str | int] | None = None,
    timeout: int = 30,
  ) -> requests.Response:
    return requests.delete(
      url,
      headers=headers,
      params=params,
      timeout=timeout,
    )
