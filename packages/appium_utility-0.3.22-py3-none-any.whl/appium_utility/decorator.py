import inspect
from collections.abc import Callable, Sequence
from functools import wraps
from typing import ParamSpec, TypeVar, cast

import requests
from selenium.common.exceptions import (InvalidElementStateException, NoSuchElementException,
                                        StaleElementReferenceException, TimeoutException)


def sanitize_action(action: str) -> str:
  return action.replace("_", " ").lower()


class AppiumActionError(RuntimeError):

  def __init__(self, message: str):
    super().__init__(message)

  @classmethod
  def from_action(cls, action: str, message: str) -> "AppiumActionError":
    return cls(f"Failed to {sanitize_action(action)}: {message}")


def unwrap_message(err: AppiumActionError) -> str:
  msg = str(err)
  if msg.startswith("Failed to "):
    return msg.split(":", 1)[1].strip()
  return msg


P = ParamSpec("P")
R = TypeVar("R")


def safe_action(skip_err: bool = False) -> Callable[[Callable[P, R]], Callable[P, R | None]]:

  def decorator(fn: Callable[P, R]) -> Callable[P, R | None]:

    @wraps(fn)
    def wrapper(*args: P.args, **kwargs: P.kwargs) -> R | None:
      should_skip = kwargs.pop('skip_err', skip_err)
      try:
        return fn(*args, **kwargs)
      except Exception:
        if should_skip:
          return None
        raise

    return wrapper

  return decorator


def map_exception(
  action: str,
  exc: Exception,
  details: str = "",
) -> AppiumActionError:

  if isinstance(exc, NoSuchElementException):
    msg = "element not found"
  elif isinstance(exc, TimeoutException):
    msg = "the operation took too long to complete"
  elif isinstance(exc, StaleElementReferenceException):
    msg = "the screen changed before the action could complete"
  elif isinstance(exc, InvalidElementStateException):
    msg = "the item is not ready for interaction"
  else:
    msg = f"exception occurred: {str(exc)}"

  if details:
    msg = f"{msg} ({details})"

  return AppiumActionError.from_action(action, msg)


def with_logging(
  action: str,
  details: str | Callable[..., str] | None = None,
):

  def decorator(fn):

    @wraps(fn)
    def wrapper(*args, **kwargs):
      details_str = ""

      if details is not None:
        try:
          if isinstance(details, str):
            bound = inspect.signature(fn).bind_partial(*args, **kwargs)
            details_str = details.format(**bound.arguments)
          else:
            details_str = details(*args, **kwargs)
        except Exception:
          details_str = ""

      action_name = sanitize_action(action)

      if details_str:
        print(f"Starting {action_name} ({details_str})")
      else:
        print(f"Starting {action_name}")

      try:
        result = fn(*args, **kwargs)

        print(f"Completed {action_name}")
        return result

      except AppiumActionError as e:
        print(e.with_traceback(None))
        raise AppiumActionError.from_action(
          action,
          unwrap_message(e),
        ) from e

      except Exception as e:
        print(e.with_traceback(None))
        raise map_exception(action, e, details_str) from e

    return wrapper

  return decorator


def request_validator(fn: Callable[P, requests.Response], ) -> Callable[P, dict]:

  @wraps(fn)
  def wrapper(*args: P.args, **kwargs: P.kwargs) -> dict:
    success_statuses = cast(
      Sequence[int] | None,
      kwargs.pop("success_statuses", None),
    )

    response = fn(*args, **kwargs)

    if success_statuses is not None and response.status_code not in success_statuses:
      response.raise_for_status()

    return response.json() if response.text else {}

  return wrapper
