#!/bin/bash
cd /app/auto-mcp-upload/data/9884
export MIGADU_TEST_MODE=true
uv run python -m migadu_mcp.main
