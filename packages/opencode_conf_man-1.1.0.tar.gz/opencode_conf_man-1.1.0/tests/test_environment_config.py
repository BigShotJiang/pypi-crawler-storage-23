import pytest
import os
import tempfile
from pathlib import Path
import yaml
import sys

sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))

from environment_config import EnvironmentConfig
from config_provider import ConfManProvider


class TestEnvironmentConfig:
    """Test EnvironmentConfig class"""

    @pytest.fixture
    def temp_dir(self):
        """Create temporary directory for testing"""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir)

    @pytest.fixture
    def config_file(self, temp_dir):
        """Create test config file with environment settings"""
        config_dir = temp_dir / "config"
        config_dir.mkdir()
        
        config_data = {
            'version': '1.0',
            'paths': {
                'data_dir': 'data',
                'config_dir': 'config',
                'log_dir': 'logs',
                'temp_dir': 'tmp'
            },
            'environment': {
                'mode': 'test',
                'allow_override': True
            }
        }
        
        config_path = config_dir / 'default_config.yaml'
        with open(config_path, 'w') as f:
            yaml.dump(config_data, f)
        
        return config_path

    def test_init_without_provider(self):
        """Test initialization without config provider"""
        env_config = EnvironmentConfig()
        assert env_config._env == "dev"

    def test_init_with_provider(self, config_file):
        """Test initialization with config provider"""
        provider = ConfManProvider(config_path=str(config_file))
        env_config = EnvironmentConfig(provider)
        assert env_config._config is provider

    def test_get_environment_from_env_var(self, temp_dir, monkeypatch):
        """Test get_environment from environment variable"""
        monkeypatch.setenv("CONF_MAN_ENV", "prod")
        provider = ConfManProvider(base_dir=temp_dir)
        env_config = EnvironmentConfig(provider)
        assert env_config.get_environment() == "prod"

    def test_get_environment_from_config(self, config_file):
        """Test get_environment from config file"""
        provider = ConfManProvider(config_path=str(config_file))
        env_config = EnvironmentConfig(provider)
        assert env_config.get_environment() == "test"

    def test_get_environment_default(self, temp_dir):
        """Test get_environment default value"""
        provider = ConfManProvider(base_dir=temp_dir)
        env_config = EnvironmentConfig(provider)
        assert env_config.get_environment() == "dev"

    def test_is_test_mode_from_env_var_true(self, temp_dir, monkeypatch):
        """Test is_test_mode from environment variable - true"""
        monkeypatch.setenv("CONF_MAN_TEST", "true")
        provider = ConfManProvider(base_dir=temp_dir)
        env_config = EnvironmentConfig(provider)
        assert env_config.is_test_mode() is True

    def test_is_test_mode_from_env_var_1(self, temp_dir, monkeypatch):
        """Test is_test_mode from environment variable - 1"""
        monkeypatch.setenv("CONF_MAN_TEST", "1")
        provider = ConfManProvider(base_dir=temp_dir)
        env_config = EnvironmentConfig(provider)
        assert env_config.is_test_mode() is True

    def test_is_test_mode_from_env_var_yes(self, temp_dir, monkeypatch):
        """Test is_test_mode from environment variable - yes"""
        monkeypatch.setenv("CONF_MAN_TEST", "yes")
        provider = ConfManProvider(base_dir=temp_dir)
        env_config = EnvironmentConfig(provider)
        assert env_config.is_test_mode() is True

    def test_is_test_mode_from_env_var_false(self, temp_dir, monkeypatch):
        """Test is_test_mode from environment variable - false"""
        monkeypatch.setenv("CONF_MAN_TEST", "false")
        provider = ConfManProvider(base_dir=temp_dir)
        env_config = EnvironmentConfig(provider)
        assert env_config.is_test_mode() is False

    def test_is_test_mode_from_config_test_mode(self, config_file):
        """Test is_test_mode from config file - test mode"""
        provider = ConfManProvider(config_path=str(config_file))
        env_config = EnvironmentConfig(provider)
        assert env_config.is_test_mode() is True

    def test_is_test_mode_from_env_var_prod(self, temp_dir, monkeypatch):
        """Test is_test_mode when env is prod"""
        monkeypatch.setenv("CONF_MAN_ENV", "prod")
        provider = ConfManProvider(base_dir=temp_dir)
        env_config = EnvironmentConfig(provider)
        assert env_config.is_test_mode() is False

    def test_is_test_mode_default(self, temp_dir):
        """Test is_test_mode default value (dev mode)"""
        provider = ConfManProvider(base_dir=temp_dir)
        env_config = EnvironmentConfig(provider)
        assert env_config.is_test_mode() is False

    def test_is_test_mode_without_provider(self, monkeypatch):
        """Test is_test_mode without provider and env var"""
        monkeypatch.delenv("CONF_MAN_TEST", raising=False)
        env_config = EnvironmentConfig()
        assert env_config.is_test_mode() is False
