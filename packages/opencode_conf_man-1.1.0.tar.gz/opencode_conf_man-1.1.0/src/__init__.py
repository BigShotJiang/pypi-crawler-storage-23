#!/usr/bin/env python3
"""conf-man CLI entry point."""

import click
import sys
from pathlib import Path

VERSION = "1.1.0"

try:
    from config_provider import ConfManProvider, get_provider
    from environment_config import EnvironmentConfig
except ImportError:
    from .config_provider import ConfManProvider, get_provider
    from .environment_config import EnvironmentConfig

__all__ = ['ConfManProvider', 'EnvironmentConfig', 'get_provider', 'VERSION', 'cli', 'main']


@click.group()
@click.version_option(version=VERSION)
def cli():
    """conf-man: 配置管理器 - 版本的"唯一真相来源" """
    pass


@cli.command()
def init():
    """初始化conf-man"""
    click.echo(f"conf-man v{VERSION}")
    click.echo("配置管理器已初始化")
    click.echo("\n目录结构:")
    click.echo("  versions/ - 版本记录")
    click.echo("  state/    - 状态文件")
    click.echo("  skills/   - Skill文档")


@cli.command()
@click.argument("version")
@click.option("--manifest", required=True, help="版本清单文件")
@click.option("--test-report", required=True, help="测试报告文件")
def register(version, manifest, test_report):
    """登记新版本"""
    click.echo(f"登记版本 {version}...")
    # TODO: 实现版本登记逻辑
    click.echo(f"版本 {version} 登记完成")


@cli.command()
def list():
    """列出所有版本"""
    # TODO: 实现版本列表
    click.echo("暂无登记版本")


@cli.command()
@click.argument("version")
def show(version):
    """显示版本详情"""
    # TODO: 实现版本详情
    click.echo(f"版本 {version} 详情")


@cli.command()
@click.argument("version")
def release(version):
    """触发发布"""
    # TODO: 实现发布逻辑
    click.echo(f"触发发布 {version}...")


def main():
    cli()


if __name__ == "__main__":
    main()
