# conf-man

配置管理器 - 版本的"唯一真相来源"

## 职责

| 职责 | 说明 |
|------|------|
| **版本登记** | 记录每个测试通过的版本 |
| **代码快照** | 保存当时的Git commit hash |
| **依赖锁定** | 记录所有依赖的精确版本 |
| **发布协调** | 触发发布、确认完成 |
| **回滚能力** | 能找回之前的版本 |

## 发布流程

```
oc-collab → test-agent → conf-man → pm-agent → 用户
```

## 命令

```bash
# 登记版本
conf-man register --version 2.3.0 --manifest manifest.yaml --test-report test_report.yaml

# 查询版本
conf-man list                    # 列出所有版本
conf-man show 2.3.0              # 显示版本详情

# 触发发布
conf-man release --version 2.3.0
```

## 目录结构

```
conf-man/
├── versions/          # 版本记录存储
│   └── v{x.y.z}.yaml
├── src/              # 源代码
├── state/            # 状态文件
├── tests/            # 测试
├── skills/           # Skill
├── docs/             # 文档
└── config/           # 配置
```

## 相关文档

- 发布流程: `../HQ/docs/04-releases/RELEASE_PROCESS.md`
- 发布管理Skill: `../HQ/skills/hq_release_management/content.md`
- 本系统Release Guide: `skills/conf_man_release_guide/content.md`
- 本系统Release Guide: `skills/conf_man_release_guide/content.md`
