"""
Configuration constants for the Connexity library.

This module defines default endpoint URLs used throughout the library.
These are production-ready defaults that work out of the box.

Constants:
    CONNEXITY_URL (str): Main SDK processing endpoint for Connexity call-processor (JSON).
    CONNEXITY_UPLOAD_URL (str): Upload endpoint for sending audio with session data (multipart).
    CONNEXITY_METRICS_URL (str): Metrics endpoint.
"""
CONNEXITY_URL = "https://call-processor.connexity.ai/process/sdk"
CONNEXITY_UPLOAD_URL = "https://call-processor.connexity.ai/process/sdk/upload"
CONNEXITY_METRICS_URL = (
    "https://call-processor.connexity.ai/process/sdk/llm_latency"
)
