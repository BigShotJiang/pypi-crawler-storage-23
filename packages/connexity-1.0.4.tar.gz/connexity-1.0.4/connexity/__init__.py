from importlib.metadata import PackageNotFoundError, version
import warnings

try:
    __version__ = version("connexity")
    _major, _minor, _patch = (int(x) for x in __version__.split(".")[:3])
    if (_major, _minor, _patch) < (1, 0, 4):
        warnings.warn(
            f"connexity version {__version__} is deprecated and no longer supported. "
            "Please upgrade to version 1.0.4 or later: pip install --upgrade connexity",
            DeprecationWarning,
            stacklevel=2,
        )
except PackageNotFoundError:
    __version__ = "unknown"