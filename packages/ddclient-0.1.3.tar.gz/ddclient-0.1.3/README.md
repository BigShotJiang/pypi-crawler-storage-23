# 使用指导
## Step 1
```bash
pip install ddclient
```

## Step 2
在项目根目录下新建.env文件
配置环境变量
```toml
DINGTALK_APP_KEY=xxxxxxxx
DINGTALK_APP_SECRET=xxxxxxxx
```
用你能想到的方法加载.env中的配置好的环境变量

## Step 3

```python
from ddapi import default_client as client
```

## 宜搭
配置环境变量
```toml
DINGTALK_APP_KEY=xxxxxxxx
DINGTALK_APP_SECRET=xxxxxxxx

YIDA_APP_TYPE=xxxxxx
YIDA_SYSTEM_TOKEN=xxxxxx
YIDA_USER_ID=xxxxxx
```

### 默认使用
```python
from ddapi import default_client as client

form_instance = client.yida.get_form_inst("FINST-XXXXXXX")
```

### 多应用
```python
from ddapi import default_client as client,YiDa,YiDaConfig

yida1 =  YiDa(client,YiDaConfig(app_type="app_type1",system_token="system_token1",user_id="user_id1"))
form_inst1 = yida1.get_form_inst("INST_ID")

yida2 = YiDa(client,YiDaConfig(app_type="app_type2",system_token="system_token2",user_id="user_id2"))
form_inst2 = yida2.get_form_inst("INST_ID")

```