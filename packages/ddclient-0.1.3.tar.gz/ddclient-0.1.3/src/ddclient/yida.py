from __future__ import annotations
from typing import TYPE_CHECKING, Any
from pydantic_settings import BaseSettings, SettingsConfigDict
import json

if TYPE_CHECKING:
    from .core import DingTalkClient


class YiDaConfig(BaseSettings):
    app_type: str | None = None
    system_token: str | None = None
    user_id: str | None = None

    model_config = SettingsConfigDict(
        env_file=".env",
        env_prefix="YIDA_",
        env_file_encoding="utf-8",
        extra="allow",
    )


class YiDa:
    def __init__(self, client: DingTalkClient, config: YiDaConfig) -> None:
        self.client = client
        self.config = config

    @property
    def _common_params(self):
        """
        通用参数
        """
        return {
            "appType": self.config.app_type,
            "systemToken": self.config.system_token,
            "userId": self.config.user_id,
        }

    def _prepare_params(
        self, base_params: dict[str, Any], use_alias: bool, form_uuid: str | None
    ):
        params = {**base_params, "useAlias": use_alias}

        if use_alias and form_uuid is None:
            raise ValueError(
                "when the 'use_alias' is true,the 'form_uuid' cannot be empty"
            )

        params["formUuid"] = form_uuid
        return params

    def get_form_inst(
        self, inst_id: str, use_alias=False, form_uuid: str | None = None
    ) -> dict[str, Any]:
        """
        获取表单实例
        https://open.dingtalk.com/document/development/api-getformdatabyid-v2#h2-aox-g1u-b5u

        """
        url = f"https://api.dingtalk.com/v2.0/yida/forms/instances/{inst_id}"

        params = self._prepare_params(self._common_params, use_alias, form_uuid)
        return self.client._request(url, "GET", params=params)

    def del_form_inst(self, inst_id: str):
        """
        删除表单实例
        """
        url = "https://api.dingtalk.com/v1.0/yida/forms/instances"
        return self.client._request(
            url,
            "DELETE",
            params={**self._common_params, "formInstanceId": inst_id},
        )

    def save_form_inst(
        self, form_uuid: str, form_data: dict[str, Any], use_alias: bool = False
    ) -> dict[str, str]:
        """
        新增表单实例
        https://open.dingtalk.com/document/development/api-saveformdata-v2

        """
        url = "https://api.dingtalk.com/v2.0/yida/forms/instances"
        body = self._prepare_params(
            {
                **self._common_params,
                "formDataJson": json.dumps(form_data),
            },
            use_alias,
            form_uuid,
        )

        return self.client._request(
            url,
            "POST",
            json=body,
        )

    def update_form_inst(
        self,
        inst_id: str,
        form_data: dict[str, Any],
        use_alias: bool = False,
        form_uuid: str | None = None,
        use_latest_version=False,
    ):
        """
        更新表单实例
        https://open.dingtalk.com/document/development/api-updateformdata-v2

        """

        url = "https://api.dingtalk.com/v2.0/yida/forms/instances"
        body = self._prepare_params(
            {
                **self._common_params,
                "formInstanceId": inst_id,
                "updateFormDataJson": json.dumps(form_data),
                "useLatestVersion": use_latest_version,
            },
            use_alias,
            form_uuid,
        )

        self.client._request(url, "PUT", json=body)

    def save_update_form_inst(
        self,
        form_uuid: str,
        search_condition: dict[str, Any],
        form_data: dict[str, Any],
        use_alias: bool = False,
        execute_expression: bool = True,
    ):
        """
        新增或更新表单实例
        https://open.dingtalk.com/document/development/api-createorupdateformdata-v2

        """

        url = "https://api.dingtalk.com/v2.0/yida/forms/instances/insertOrUpdate"
        body = self._prepare_params(
            {
                **self._common_params,
                "searchCondition": search_condition,
                "formDataJson": json.dumps(form_data),
                "noExecuteExpression": not execute_expression,
            },
            use_alias,
            form_uuid,
        )

        return self.client._request(
            url,
            "POST",
            json=body,
        )
