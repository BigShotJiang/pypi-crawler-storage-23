from .core import DingTalkClient, DingTalkConfig
from .yida import YiDa,YiDaConfig


_default_config = DingTalkConfig()

default_client = DingTalkClient(_default_config)

__all__ = ["DingTalkClient", "DingTalkConfig", "default_client","YiDa","YiDaConfig"]