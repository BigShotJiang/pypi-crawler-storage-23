from __future__ import annotations

import time
import httpx
import atexit
from typing_extensions import Self
from pydantic import BaseModel
from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import Literal, TYPE_CHECKING
from functools import cached_property

if TYPE_CHECKING:
    from .yida import YiDa

HttpMethod = Literal["GET", "PUT", "POST", "DELETE"]


class DingTalkConfig(BaseSettings):
    app_key: str = ""
    app_secret: str = ""

    model_config = SettingsConfigDict(
        env_prefix="DINGTALK_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="allow",
    )


class Token(BaseModel):
    access_token: str
    expire_at: float


class TokenManager:
    _instance = None
    _tokens: dict[str, Token] = {}

    def __new__(cls) -> Self:
        if cls._instance is None:
            cls._instance = super(TokenManager, cls).__new__(cls)

        return cls._instance

    def get_token(self, app_key: str, app_secret: str) -> str:
        token = self._tokens.get(app_key)

        if not token or token.expire_at < time.time():
            token = self._refresh_token(app_key, app_secret)

        return token.access_token

    def _refresh_token(self, app_key: str, app_secret: str) -> Token:
        url = "https://api.dingtalk.com/v1.0/oauth2/accessToken"
        body = {"appKey": app_key, "appSecret": app_secret}

        with httpx.Client() as client:
            res = client.post(url, json=body)

            try:
                res.raise_for_status()
            except httpx.HTTPStatusError as ex:
                raise Exception(ex.response.text)

            data = res.json()

        self._tokens[app_key] = Token(
            access_token=data["accessToken"], expire_at=time.time() + 3600
        )

        return self._tokens[app_key]


class DingTalkClient:
    def __init__(self, config: DingTalkConfig):
        self.config = config
        self.token_manager = TokenManager()
        self.http_client = httpx.Client(
            transport=httpx.HTTPTransport(retries=3), timeout=30.0
        )

        atexit.register(self.close)

    @property
    def acccess_token(self):
        return self.token_manager.get_token(self.config.app_key, self.config.app_secret)

    def _request(self, url: str, method: HttpMethod, **kwargs) -> dict:
        if "oapi.dingtalk.com" in url:
            params = kwargs.get("params", {})
            params["access_token"] = self.acccess_token
            kwargs["params"] = params
        else:
            headers = kwargs.get("headers", {})
            headers.setdefault("x-acs-dingtalk-access-token", self.acccess_token)
            kwargs["headers"] = headers

        res = self.http_client.request(method, url, **kwargs)
        try:
            res.raise_for_status()
            data = res.json()
        except httpx.HTTPStatusError as ex:
            try:
                error_detail = ex.response.json()
            except:  # noqa: E722
                error_detail = ex.response.text

            raise Exception(
                f"Http Error:{ex.response.status_code}, Detail:{error_detail}"
            )

        if "errcode" in data and data["errcode"] != 0:
            raise Exception(
                f"dingtalk api err: {data.get('errmsg', 'unknown')} code:{data.get['errcode']}"
            )
        return data

    def close(self):
        if hasattr(self, "http_client"):
            self.http_client.close()

    @cached_property
    def yida(self) -> YiDa:
        from .yida import YiDa, YiDaConfig

        return YiDa(self, YiDaConfig())
