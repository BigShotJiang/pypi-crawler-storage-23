from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .core import DingTalkClient


class Contact:
    def __init__(self, client: DingTalkClient) -> None:
        self.client = client

    def get_dept_list(self, dept_id: int = 1, lang: str = "zh_CN") -> dict[str, Any]:
        """
        获取部门列表
        https://open.dingtalk.com/document/development/user-management-acquires-the-list-departments

        """
        url = "https://oapi.dingtalk.com/topapi/v2/department/listsub"
        return self.client._request(
            url, "POST", json={"dept_id": dept_id, "language": lang}
        )

    def get_det_detail(self, dept_id: int, lang: str = "zh_CN") -> dict[str, Any]:
        """
        获取部门详情
        https://open.dingtalk.com/document/development/query-department-details0-v2
        
        """
        url = "https://oapi.dingtalk.com/topapi/v2/department/get"
        return self.client._request(
            url, "POST", json={"dept_id": dept_id, "language": lang}
        )
    
    def search_dept(self,query_word:str,offset:int = 0,size:int = 10):
        """
        搜索部门ID
        https://open.dingtalk.com/document/development/address-book-search-department-id

        """
        
        url = "https://api.dingtalk.com/v1.0/contact/departments/search"
        return self.client._request(url,"POST",json={
            "queryWord":query_word,
            "offset":offset,
            "size":size
        })
    


