 .. This file provides the instructions for how to display the API documentation generated using sphinx autodoc
   extension. Use it to declare Python documentation sub-directories via appropriate modules (autodoc, etc.).

Command Line Interfaces
=======================

.. click:: cindra.interface.cli:cindra_cli

Single-Day Pipeline Configuration
=================================
.. automodule:: cindra.configuration.single_day
   :members:
   :undoc-members:
   :show-inheritance:

Single-Day Pipeline API
=======================
.. automodule:: cindra.single_day
   :members:
   :undoc-members:
   :show-inheritance:

Multi-Day Pipeline Configuration
=================================
.. automodule:: cindra.configuration.multi_day
   :members:
   :undoc-members:
   :show-inheritance:

Multi-Day Pipeline API
======================
.. automodule:: cindra.multi_day
   :members:
   :undoc-members:
   :show-inheritance:

Multi-day Pipeline Algorithms
=============================
.. automodule:: cindra.multiday
   :members:
   :undoc-members:
   :show-inheritance:

Version API
===========
.. automodule:: cindra.version
   :members:
   :undoc-members:
   :show-inheritance:
