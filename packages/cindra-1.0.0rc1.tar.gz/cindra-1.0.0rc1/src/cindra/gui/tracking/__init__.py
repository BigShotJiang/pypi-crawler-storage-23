"""Provides the standalone multi-day cell tracking quality viewer GUI."""

from .app import run

__all__ = [
    "run",
]
