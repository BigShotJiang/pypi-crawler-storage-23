"""Provides the standalone single-day registration quality viewer GUI."""

from .app import run_registration_viewer

__all__ = [
    "run_registration_viewer",
]
