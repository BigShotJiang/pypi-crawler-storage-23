"""Provides the standalone ROI viewer and editor GUI for cindra data visualization and analysis."""

from .app import run

__all__ = [
    "run",
]
