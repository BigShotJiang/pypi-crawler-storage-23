class GroundControllerError(Exception):
    pass


class GraphError(GroundControllerError):
    pass
