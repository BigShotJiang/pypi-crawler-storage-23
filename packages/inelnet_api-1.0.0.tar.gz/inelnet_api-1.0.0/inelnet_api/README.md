# inelnet-api

Asynchrónny klientsky balík pre REST API ovládača INELNET rolet. Jeden objekt reprezentuje jeden kanál (host + číslo kanála).

## Inštalácia

```bash
pip install inelnet-api
```

## Použitie

Pre každý kanál vytvor jednu inštanciu `InelnetChannel` (host + číslo kanála 1–16):

```python
import asyncio
from inelnet_api import Action, InelnetChannel

async def main():
    channel = InelnetChannel(host="192.168.1.67", channel=1)

    # Kontrola dostupnosti
    ok = await channel.ping()
    if not ok:
        print("Kontrolér nedostupný")
        return

    # Pohyb: otvoriť / zatvoriť / stop
    await channel.up()
    await channel.down()
    await channel.stop()

    # Krátky posun a programovací režim
    await channel.up_short()
    await channel.down_short()
    await channel.program()

    # Príkaz podľa enumu (Action.UP, Action.DOWN, Action.STOP, …)
    # await channel.send_command(Action.UP_SHORT, session=hass_session)

    # Voliteľne: vlastná session (napr. z Home Assistant)
    # await channel.up(session=hass_session)

asyncio.run(main())
```

## API

- **`InelnetChannel(host: str, channel: int)`** – kanál musí byť 1–16.
- **`send_command(act, *, session=None, timeout=...)`** – odoslanie príkazu; `act` je člen enumu **`Action`** (napr. `Action.UP`, `Action.DOWN`, `Action.STOP`) alebo celé číslo.
- **`ping(*, session=None, timeout=...)`** – GET na kontrolér, vráti `True` ak je dostupný.
- **`up()`, `down()`, `stop()`, `up_short()`, `down_short()`, `program()`** – pohodlné metódy (voliteľne `session=`).

Ak nepredáš `session`, knižnica pre každý volanie dočasne vytvorí vlastnú `aiohttp.ClientSession()`. V prostredí ako Home Assistant môžeš predať `async_get_clientsession(hass)` kvôli zdieľanému HTTP klientskému session.

## Publikovanie na PyPI (pre maintainera)

```bash
# Jednorazovo
pip install build twine

# Build
python3 -m build

# Nahratie na PyPI (vyžaduje účet a token)
twine upload dist/*
# alebo len test PyPI:
twine upload --repository testpypi dist/*
```

Po úprave kódu zmeň `version` v `pyproject.toml` a v `inelnet_api/__init__.py`, potom znova `python3 -m build` a `twine upload dist/*`.
