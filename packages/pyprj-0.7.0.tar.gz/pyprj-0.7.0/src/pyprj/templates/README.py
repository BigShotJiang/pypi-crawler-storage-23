README_MD: str = r"""# {{pkg_name}}

Description of the package.
"""
