INDEX_MD = """# {pkg_name}

Description of the project.

## Installation

```bash
pip install {pkg_name}
```

```{{toctree}}
:caption: Table of contents
:maxdepth: 1

userguide
apireference
```

## Links

- Source repository:
  [{source_repo}]({source_repo})
- PyPI:
  [{pypi_project}]({pypi_project})
- Documentation:
  [{documentation_page}]({documentation_page})
"""
