import datetime
import decimal
import json
from typing import Any


class SafeEncoder(json.JSONEncoder):
    """JSON encoder that correctly handles types ``json.dumps(default=str)`` gets wrong.

    Handles: ``Decimal`` (as number), ``inf``/``nan`` floats, ``datetime``,
    ``bytes``, ``set``/``frozenset``, and falls back to ``str()`` for the rest.
    """

    def default(self, o: Any) -> Any:
        if isinstance(o, decimal.Decimal):
            return float(o)
        if isinstance(o, (datetime.datetime, datetime.date)):
            return o.isoformat()
        if isinstance(o, (bytes, bytearray)):
            return o.decode('utf-8', errors='replace')
        if isinstance(o, (set, frozenset)):
            return list(o)
        return str(o)
