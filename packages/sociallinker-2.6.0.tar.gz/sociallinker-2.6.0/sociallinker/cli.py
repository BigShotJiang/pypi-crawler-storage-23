import os
import sys
from urllib.parse import quote

VERSION = "2.6"

# --- FUNÇÕES DE UTILIDADE ---

def limpar_numero(texto):
    return "".join(filter(str.isdigit, texto))

def limpar_usuario(texto):
    return texto.replace("@", "").strip()

def codificar_texto(texto):
    return quote(texto)

def limpar_tela():
    os.system("cls" if os.name == "nt" else "clear")

# --- MOTORES DE GERAÇÃO ---

def gerar_whatsapp():
    print("\n--- GERADOR DE LINK WHATSAPP ---")
    ddi = limpar_numero(input("DDI (ex: 55): "))
    ddd = limpar_numero(input("DDD (ex: 51): "))
    num = limpar_numero(input("Número: "))
    text = codificar_texto(input("Mensagem: "))
    link = f"https://wa.me/{ddi}{ddd}{num}?text={text}"
    mostrar_resultado(link)

def gerar_telegram():
    print("\n--- GERADOR DE LINK TELEGRAM ---")
    usuario = limpar_usuario(input("Digite o @usuario: "))
    link = f"https://t.me/{usuario}"
    mostrar_resultado(link)

def gerar_instagram():
    print("\n--- GERADOR DE DIRECT INSTAGRAM ---")
    usuario = limpar_usuario(input("Digite o @usuario: "))
    link = f"https://ig.me/m/{usuario}"
    mostrar_resultado(link)

def gerar_messenger():
    print("\n--- GERADOR DE LINK MESSENGER ---")
    entrada = input("Nome de usuário ou link: ")
    usuario = entrada.split("/")[-1]
    link = f"https://m.me/{usuario}"
    mostrar_resultado(link)

def gerar_sms():
    print("\n--- GERADOR DE SMS UNIVERSAL ---")
    num = limpar_numero(input("Número com DDD: "))
    msg = codificar_texto(input("Mensagem: "))
    link = f"sms:{num}?body={msg}"
    mostrar_resultado(link)

def gerar_linkedin():
    print("\n--- GERADOR DE LINK LINKEDIN ---")
    usuario = limpar_usuario(input("Digite o nome de usuário do perfil: "))
    link = f"https://www.linkedin.com/in/{usuario}"
    mostrar_resultado(link)

def gerar_twitter():
    print("\n--- GERADOR DE LINK X (TWITTER) ---")
    usuario = limpar_usuario(input("Digite o @usuario: "))
    msg = codificar_texto(input("Mensagem (opcional): "))
    if msg:
        link = f"https://twitter.com/intent/tweet?text=@{usuario}%20{msg}"
    else:
        link = f"https://twitter.com/{usuario}"
    mostrar_resultado(link)

def gerar_signal():
    print("\n--- GERADOR DE LINK SIGNAL ---")
    num = limpar_numero(input("Número (DDI+DDD+Número): "))
    link = f"https://signal.me/#p/{num}"
    mostrar_resultado(link)

def gerar_youtube():
    print("\n--- GERADOR DE LINK INSCRIÇÃO YOUTUBE ---")
    print("Dica: Use o nome do canal ou o ID que aparece na URL")
    canal = input("ID/Nome do Canal: ")
    link = f"https://www.youtube.com/{canal}?sub_confirmation=1"
    mostrar_resultado(link)

def gerar_tiktok():
    print("\n--- GERADOR DE LINK TIKTOK ---")
    usuario = limpar_usuario(input("Digite o @usuario: "))
    link = f"https://www.tiktok.com/@{usuario}"
    mostrar_resultado(link)

def gerar_pinterest():
    print("\n--- GERADOR DE LINK PINTEREST ---")
    usuario = limpar_usuario(input("Digite o nome de usuário: "))
    link = f"https://www.pinterest.com/{usuario}/"
    mostrar_resultado(link)

def gerar_skype():
    print("\n--- GERADOR DE LINK SKYPE ---")
    usuario = input("Digite o nome de usuário/ID Skype: ")
    link = f"skype:{usuario}?chat"
    mostrar_resultado(link)

# --- FUNÇÃO AUXILIAR ---

def mostrar_resultado(link):
    print("\n\033[1;32m" + "=" * 45)
    print("LINK GERADO COM SUCESSO:")
    print(link)
    print("=" * 45 + "\033[0m")
    input("\nPressione ENTER para voltar ao SocialLinker...")

# --- MENU ---

def menu():
    while True:
        limpar_tela()
        print("\033[1;34m" + "=" * 45)
        print(f"         SOCIALLINKER CLI v{VERSION}")
        print("=" * 45 + "\033[0m")
        print("( 1 ) WhatsApp          ( 7 ) X (Twitter)")
        print("( 2 ) Telegram          ( 8 ) Signal")
        print("( 3 ) Instagram Direct  ( 9 ) YouTube (Inscrição)")
        print("( 4 ) Facebook Mess.    ( 10) TikTok")
        print("( 5 ) SMS Universal     ( 11) Pinterest")
        print("( 6 ) LinkedIn          ( 12) Skype")
        print("\033[1;31m( 0 ) Sair\033[0m")
        print("=" * 45)

        opcao = input("Escolha a plataforma: ")

        if opcao == "1": gerar_whatsapp()
        elif opcao == "2": gerar_telegram()
        elif opcao == "3": gerar_instagram()
        elif opcao == "4": gerar_messenger()
        elif opcao == "5": gerar_sms()
        elif opcao == "6": gerar_linkedin()
        elif opcao == "7": gerar_twitter()
        elif opcao == "8": gerar_signal()
        elif opcao == "9": gerar_youtube()
        elif opcao == "10": gerar_tiktok()
        elif opcao == "11": gerar_pinterest()
        elif opcao == "12": gerar_skype()
        elif opcao == "0":
            print("\nSocialLinker encerrado. Missão cumprida!")
            sys.exit()
        else:
            print("\nOpção inválida!")
            input("Aperte ENTER...")

# --- ENTRYPOINT OFICIAL ---

def main():
    menu()

if __name__ == "__main__":
    main()
