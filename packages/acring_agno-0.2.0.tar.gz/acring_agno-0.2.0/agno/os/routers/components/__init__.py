from agno.os.routers.components.components import get_components_router

__all__ = ["get_components_router"]
