from agno.os.routers.registry.registry import get_registry_router

__all__ = ["get_registry_router"]
