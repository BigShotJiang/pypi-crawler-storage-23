"""
Support for python -m dotted.
"""
from dotted.cli.main import main

if __name__ == '__main__':
    main()
