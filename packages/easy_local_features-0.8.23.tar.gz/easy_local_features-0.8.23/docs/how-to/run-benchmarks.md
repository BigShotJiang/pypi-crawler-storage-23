# Run benchmarks

- Use the provided tests and scripts as templates.
- Save visualizations into `results/` to compare outputs.
- Consider adding dataset loaders under `datasets/` for reproducible evaluations.
