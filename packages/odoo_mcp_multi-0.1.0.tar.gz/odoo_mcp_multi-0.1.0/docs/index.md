# Odoo MCP Multi

Welcome to the documentation for **Odoo MCP Multi**, an MCP (Model Context Protocol) Server for connecting AI assistants like Claude and Cursor to multiple Odoo instances.

## Features

- Support for connecting to multiple Odoo instances simultaneously through profiles
- Complete implementation of the required tools for code editing and creation in Odoo
- Compatible with Odoo 15+ (using `execute_kw`)
- Strict security controls with safe domains
- Automatic parameter serialization/deserialization

## Getting Started

Check out the [README on GitHub](https://github.com/vauxoo/odoo-mcp-multi) for quick setup instructions and how to integrate with your preferred AI editor.
