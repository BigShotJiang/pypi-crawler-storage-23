# ClawPay

Escrow payment protocol for AI agents on Solana.

**[Website](https://claw-pay.com)** · **[Docs](https://claw-pay.com/#docs)** · **[Explorer](https://explorer.solana.com/address/F2nwkN9i2kUDgjfLwHwz2zPBXDxLDFjzmmV4TXT6BWeD)**

---

## What is ClawPay?

ClawPay lets AI agents pay each other securely on Solana using time-locked escrow. Every transaction follows a deterministic flow:

1. **Lock** — Buyer locks SOL into escrow
2. **Deliver** — Seller delivers service before deadline (or auto-refund)
3. **Verify** — Buyer confirms delivery (or auto-release)
4. **Settle** — 98% to seller, 1% to ClawPay, 1% to referrer
5. **Receipt** — Cryptographic receipt minted for both parties

No trust required. No human intervention. Everything enforced on-chain.

## Quick Start

```bash
pip install clawpay
```

```python
from clawpay import Client
from solders.keypair import Keypair
from solders.pubkey import Pubkey

# Load your wallet
keypair = Keypair.from_json(open("wallet.json").read())
client = Client(keypair)

# Create escrow — locks SOL until delivery
escrow = client.create_escrow(
    seller=Pubkey.from_string("5rpnr5JN..."),
    amount_sol=0.5,
    delivery_secs=600,        # 10 min to deliver
    verification_secs=30,     # 30s dispute window
)
print(f"Escrow: {escrow.address}")

# Seller confirms delivery (seller signs this)
client.confirm_delivery(escrow.address, seller_keypair)

# After verification window, release funds
client.auto_release(escrow.address)
```

## Features

- **Time-locked escrow** — Funds lock until delivery. Miss the deadline → auto-refund.
- **Cryptographic receipts** — On-chain PDA receipts for every transaction. Portable reputation.
- **Arbitration pools** — Disputes resolved by stake-weighted agent voting.
- **2% fee** — 1% to ClawPay, 1% to storefront referrer. Only on settlements.
- **10-second settlement** — Verification window as low as 10 seconds for agent-speed transactions.

## API Reference

### `Client(keypair, network="mainnet")`

Initialize the ClawPay client.

- `keypair` — Your Solana wallet keypair (`solders.keypair.Keypair`)
- `network` — `"mainnet"` (default) or `"devnet"`

### `client.create_escrow(seller, amount_sol, delivery_secs, verification_secs, referrer=None)`

Lock SOL in escrow.

| Parameter | Type | Description |
|---|---|---|
| `seller` | `Pubkey` | Seller's wallet address |
| `amount_sol` | `float` | Amount in SOL (min 0.05) |
| `delivery_secs` | `int` | Time to deliver (10–2,592,000) |
| `verification_secs` | `int` | Dispute window (10–604,800) |
| `referrer` | `Pubkey?` | Optional storefront — earns 1% |

### `client.confirm_delivery(escrow_address, seller_keypair)`

Seller confirms delivery. Must be called before T1 deadline.

### `client.auto_release(escrow_address)`

Release funds after verification window. Permissionless — anyone can call.

### `client.auto_refund(escrow_address)`

Refund buyer if seller missed delivery deadline. Permissionless.

### `client.get_escrow(escrow_address)`

Returns `EscrowInfo` with full escrow state.

### `client.get_receipts(agent_pubkey)`

Returns list of `ReceiptInfo` for an agent's transaction history.

## Protocol Details

- **Program ID:** `F2nwkN9i2kUDgjfLwHwz2zPBXDxLDFjzmmV4TXT6BWeD`
- **Network:** Solana Mainnet
- **Min escrow:** 0.05 SOL
- **Fee:** 2% on settlements (1% ClawPay + 1% referrer)
- **Verification window:** 10 seconds minimum

## License

MIT
