"""
ClawPay Python SDK v0.6.0

Escrow payment protocol for AI agents on Solana.
https://claw-pay.com

Changes from v0.5.0:
- UPDATED: MIN_VERIFICATION_SECS reduced from 7200 to 10 (matches contract v0.6.0)
- UPDATED: MIN_ESCROW_AMOUNT_SOL raised from 0.01 to 0.05 (rent-exemption fix)
- UPDATED: Default network changed to mainnet
"""

from __future__ import annotations

import json
import secrets
import struct
import hashlib
from dataclasses import dataclass, field
from typing import Optional

from solders.keypair import Keypair
from solders.pubkey import Pubkey
from solders.system_program import ID as SYSTEM_PROGRAM_ID
from solders.instruction import Instruction, AccountMeta
from solders.transaction import Transaction
from solders.message import Message
from solana.rpc.api import Client as SolanaClient
from solana.rpc.commitment import Confirmed
from solana.rpc.types import TxOpts

# ── Program IDs ──────────────────────────────────────────────────────

PROGRAM_ID_DEVNET  = Pubkey.from_string("F2nwkN9i2kUDgjfLwHwz2zPBXDxLDFjzmmV4TXT6BWeD")
PROGRAM_ID_MAINNET = Pubkey.from_string("F2nwkN9i2kUDgjfLwHwz2zPBXDxLDFjzmmV4TXT6BWeD")  # UPDATE after mainnet deploy

RPC_DEVNET  = "https://api.devnet.solana.com"
RPC_MAINNET = "https://api.mainnet-beta.solana.com"

# ── Contract constants (must match lib.rs) ───────────────────────────

MIN_ESCROW_AMOUNT_SOL = 0.05
MAX_ESCROW_AMOUNT_SOL = 10.0
MIN_ESCROW_AMOUNT_LAMPORTS = 50_000_000
MAX_ESCROW_AMOUNT_LAMPORTS = 10_000_000_000
MAX_DELIVERY_SECS = 2_592_000       # 30 days
MIN_VERIFICATION_SECS = 10          # 10 seconds (v0.6.0 contract update)
MAX_VERIFICATION_SECS = 604_800     # 7 days
LAMPORTS_PER_SOL = 1_000_000_000

# ── PDA seeds ────────────────────────────────────────────────────────

ESCROW_SEED          = b"escrow"
CONFIG_SEED          = b"config"
RECEIPT_SEED         = b"receipt"
RECEIPT_COUNTER_SEED = b"receipt_counter"
ARBITRATOR_POOL_SEED = b"arbitrator_pool"

# ── Anchor discriminators ────────────────────────────────────────────

def _disc(name: str) -> bytes:
    return hashlib.sha256(f"global:{name}".encode()).digest()[:8]

DISC = {
    "initialize_config":              _disc("initialize_config"),
    "update_fee_wallet":              _disc("update_fee_wallet"),
    "toggle_pause":                   _disc("toggle_pause"),
    "lock_funds":                     _disc("lock_funds"),
    "confirm_delivery":               _disc("confirm_delivery"),
    "auto_refund_on_timeout":         _disc("auto_refund_on_timeout"),
    "auto_release_on_verification_end": _disc("auto_release_on_verification_end"),
    "close_escrow":                   _disc("close_escrow"),
    "initialize_receipt_counter":     _disc("initialize_receipt_counter"),
    "mint_receipt":                   _disc("mint_receipt"),
    "verify_receipt":                 _disc("verify_receipt"),
    "get_reputation":                 _disc("get_reputation"),
    "raise_dispute":                  _disc("raise_dispute"),
    "select_arbitrators":             _disc("select_arbitrators"),
    "arbitrator_vote":                _disc("arbitrator_vote"),
    "resolve_dispute":                _disc("resolve_dispute"),
    "claim_arbitrator_reward":        _disc("claim_arbitrator_reward"),
}

# ── Byte sizes for parser ────────────────────────────────────────────

# ArbitratorVote: Pubkey(32) + vote(1) + vote_weight(8) + timestamp(8) + claimed(1) = 50
ARBITRATOR_VOTE_SIZE = 50
# DisputeResolution: outcome(1) + buyer_w(8) + seller_w(8) + resolved_at(8) + fee_pool(8) = 33
DISPUTE_RESOLUTION_SIZE = 33


# ── Data classes ─────────────────────────────────────────────────────

@dataclass
class EscrowInfo:
    address: Pubkey
    buyer: Pubkey
    seller: Pubkey
    amount: int             # lamports
    nonce: int
    t0: int                 # unix timestamp
    t1: int                 # delivery deadline
    t2: int                 # verification window end
    delivered: bool
    disputed: bool
    released: bool
    referrer: Optional[Pubkey]
    bump: int = 0
    dispute_timestamp: int = 0
    arbitration_round: int = 0

    @property
    def amount_sol(self) -> float:
        return self.amount / LAMPORTS_PER_SOL

    @property
    def fee_sol(self) -> float:
        return self.amount_sol * 0.02

    @property
    def seller_amount_sol(self) -> float:
        return self.amount_sol * 0.98

    @property
    def status(self) -> str:
        if self.released:
            if self.disputed:
                # Dispute was resolved — check who actually got funds
                # If delivered=True but buyer won dispute, it's still a refund
                # We can't determine winner from delivered flag alone after dispute,
                # so report "dispute_resolved" and let caller check details
                return "dispute_resolved"
            return "released" if self.delivered else "refunded"
        if self.disputed:
            return "disputed"
        if self.delivered:
            return "delivered"
        return "locked"


@dataclass
class ConfigInfo:
    address: Pubkey
    owner: Pubkey
    fee_wallet: Pubkey
    is_paused: bool


@dataclass
class ReceiptInfo:
    address: Pubkey
    agent: Pubkey
    receipt_index: int
    escrow_id: Pubkey
    buyer: Pubkey
    seller: Pubkey
    amount: int
    outcome: int            # 0=released, 1=refunded, 2=disputed
    timestamp: int
    content_hash: bytes
    is_verified: bool

    @property
    def amount_sol(self) -> float:
        return self.amount / LAMPORTS_PER_SOL


@dataclass
class ArbitratorVoteInfo:
    arbitrator: Pubkey
    vote: int               # 0=BuyerWins, 1=SellerWins
    vote_weight: int
    timestamp: int
    claimed: bool


# ── PDA helpers ──────────────────────────────────────────────────────

def find_escrow_pda(buyer: Pubkey, seller: Pubkey, nonce: int, program_id: Pubkey) -> tuple[Pubkey, int]:
    return Pubkey.find_program_address(
        [ESCROW_SEED, bytes(buyer), bytes(seller), struct.pack("<Q", nonce)],
        program_id,
    )

def find_config_pda(program_id: Pubkey) -> tuple[Pubkey, int]:
    return Pubkey.find_program_address([CONFIG_SEED], program_id)

def find_receipt_counter_pda(agent: Pubkey, program_id: Pubkey) -> tuple[Pubkey, int]:
    return Pubkey.find_program_address([RECEIPT_COUNTER_SEED, bytes(agent)], program_id)

def find_receipt_pda(agent: Pubkey, receipt_index: int, program_id: Pubkey) -> tuple[Pubkey, int]:
    return Pubkey.find_program_address(
        [RECEIPT_SEED, bytes(agent), struct.pack("<I", receipt_index)],
        program_id,
    )

def find_arbitrator_pool_pda(escrow: Pubkey, program_id: Pubkey) -> tuple[Pubkey, int]:
    return Pubkey.find_program_address([ARBITRATOR_POOL_SEED, bytes(escrow)], program_id)


# ── Serialization helpers ────────────────────────────────────────────

def _encode_option_pubkey(pubkey: Optional[Pubkey]) -> bytes:
    if pubkey is None:
        return b"\x00"
    return b"\x01" + bytes(pubkey)

def _encode_string(s: str) -> bytes:
    encoded = s.encode("utf-8")
    return struct.pack("<I", len(encoded)) + encoded


# ── Client ───────────────────────────────────────────────────────────

class Client:
    """
    ClawPay SDK v0.6.0

    Usage:
        from clawpay import Client
        from solders.keypair import Keypair

        kp = Keypair.from_json(open("wallet.json").read())
        client = Client(kp)

        escrow = client.create_escrow(
            seller=Pubkey.from_string("5rpn..."),
            amount_sol=0.5,
            delivery_secs=600,
            verification_secs=30,
        )
    """

    def __init__(
        self,
        keypair: Keypair,
        network: str = "mainnet",
        program_id: Optional[Pubkey] = None,
        rpc_url: Optional[str] = None,
    ):
        if network == "mainnet":
            self.rpc_url    = rpc_url or RPC_MAINNET
            self.program_id = program_id or PROGRAM_ID_MAINNET
        else:
            self.rpc_url    = rpc_url or RPC_DEVNET
            self.program_id = program_id or PROGRAM_ID_DEVNET

        self.keypair = keypair
        self.network = network
        self._rpc    = SolanaClient(self.rpc_url, commitment=Confirmed)
        self._config_cache: Optional[ConfigInfo] = None

    @staticmethod
    def load_keypair(path: str) -> Keypair:
        with open(path) as f:
            data = json.load(f)
        if isinstance(data, list):
            return Keypair.from_bytes(bytes(data))
        elif isinstance(data, dict) and "secret" in data:
            return Keypair.from_bytes(bytes.fromhex(data["secret"]))
        raise ValueError(f"Unknown keypair format in {path}")

    def explorer_url(self, signature: str) -> str:
        cluster = "" if self.network == "mainnet" else f"?cluster={self.network}"
        return f"https://explorer.solana.com/tx/{signature}{cluster}"

    # ── Config ────────────────────────────────────────────────────

    def get_config(self, force_refresh: bool = False) -> ConfigInfo:
        """Read program config PDA (owner, fee wallet, pause status)."""
        if self._config_cache and not force_refresh:
            return self._config_cache
        config_pda, _ = find_config_pda(self.program_id)
        resp = self._rpc.get_account_info(config_pda, commitment=Confirmed)
        if not resp.value:
            raise ValueError("ProgramConfig not initialized. Call initialize_config first.")
        data = resp.value.data
        offset = 8  # discriminator
        owner = Pubkey.from_bytes(data[offset:offset+32]); offset += 32
        fee_wallet = Pubkey.from_bytes(data[offset:offset+32]); offset += 32
        is_paused = bool(data[offset])
        self._config_cache = ConfigInfo(
            address=config_pda, owner=owner,
            fee_wallet=fee_wallet, is_paused=is_paused,
        )
        return self._config_cache

    def initialize_config(self, fee_wallet: Pubkey) -> str:
        """Initialize program config. Can only be called once. Owner = signer."""
        config_pda, _ = find_config_pda(self.program_id)
        ix_data = DISC["initialize_config"] + bytes(fee_wallet)
        accounts = [
            AccountMeta(self.keypair.pubkey(), is_signer=True, is_writable=True),   # owner
            AccountMeta(config_pda, is_signer=False, is_writable=True),             # config
            AccountMeta(SYSTEM_PROGRAM_ID, is_signer=False, is_writable=False),     # system
        ]
        return self._send_tx([Instruction(self.program_id, ix_data, accounts)], [self.keypair])

    def update_fee_wallet(self, new_fee_wallet: Pubkey) -> str:
        """Update fee wallet. Owner only."""
        config_pda, _ = find_config_pda(self.program_id)
        ix_data = DISC["update_fee_wallet"] + bytes(new_fee_wallet)
        accounts = [
            AccountMeta(self.keypair.pubkey(), is_signer=True, is_writable=False),  # owner
            AccountMeta(config_pda, is_signer=False, is_writable=True),             # config
        ]
        self._config_cache = None
        return self._send_tx([Instruction(self.program_id, ix_data, accounts)], [self.keypair])

    def toggle_pause(self) -> str:
        """Toggle program pause. Owner only."""
        config_pda, _ = find_config_pda(self.program_id)
        ix_data = DISC["toggle_pause"]
        accounts = [
            AccountMeta(self.keypair.pubkey(), is_signer=True, is_writable=False),  # owner
            AccountMeta(config_pda, is_signer=False, is_writable=True),             # config
        ]
        self._config_cache = None
        return self._send_tx([Instruction(self.program_id, ix_data, accounts)], [self.keypair])

    # ── Escrow ────────────────────────────────────────────────────

    def create_escrow(
        self,
        seller: Pubkey,
        amount_sol: float,
        delivery_secs: int = 3600,
        verification_secs: int = 7200,
        referrer: Optional[Pubkey] = None,
        nonce: Optional[int] = None,
    ) -> EscrowInfo:
        """Lock funds in escrow. All times in seconds."""
        amount_lamports = int(amount_sol * LAMPORTS_PER_SOL)

        # Client-side validation (fail fast with clear errors)
        if amount_lamports < MIN_ESCROW_AMOUNT_LAMPORTS:
            raise ValueError(f"Amount {amount_sol} SOL below minimum {MIN_ESCROW_AMOUNT_SOL}")
        if amount_lamports > MAX_ESCROW_AMOUNT_LAMPORTS:
            raise ValueError(f"Amount {amount_sol} SOL above maximum {MAX_ESCROW_AMOUNT_SOL}")
        if delivery_secs <= 0 or delivery_secs > MAX_DELIVERY_SECS:
            raise ValueError(f"delivery_secs must be 1-{MAX_DELIVERY_SECS}")
        if verification_secs < MIN_VERIFICATION_SECS or verification_secs > MAX_VERIFICATION_SECS:
            raise ValueError(f"verification_secs must be {MIN_VERIFICATION_SECS}-{MAX_VERIFICATION_SECS}")
        if self.keypair.pubkey() == seller:
            raise ValueError("Buyer and seller cannot be the same account")

        if nonce is None:
            nonce = secrets.randbelow(2**64)

        escrow_pda, _ = find_escrow_pda(self.keypair.pubkey(), seller, nonce, self.program_id)
        config_pda, _ = find_config_pda(self.program_id)

        ix_data = (
            DISC["lock_funds"]
            + struct.pack("<Q", amount_lamports)
            + struct.pack("<I", delivery_secs)
            + struct.pack("<I", verification_secs)
            + _encode_option_pubkey(referrer)
            + struct.pack("<Q", nonce)
        )

        # Account order: escrow, buyer(S), seller, config, system_program
        accounts = [
            AccountMeta(escrow_pda, is_signer=False, is_writable=True),
            AccountMeta(self.keypair.pubkey(), is_signer=True, is_writable=True),
            AccountMeta(seller, is_signer=False, is_writable=False),
            AccountMeta(config_pda, is_signer=False, is_writable=False),
            AccountMeta(SYSTEM_PROGRAM_ID, is_signer=False, is_writable=False),
        ]

        self._send_tx([Instruction(self.program_id, ix_data, accounts)], [self.keypair])

        return EscrowInfo(
            address=escrow_pda, buyer=self.keypair.pubkey(), seller=seller,
            amount=amount_lamports, nonce=nonce,
            t0=0, t1=0, t2=0,  # populated on-chain, call get_escrow() for real values
            delivered=False, disputed=False, released=False, referrer=referrer,
        )

    def confirm_delivery(self, escrow_address: Pubkey, seller_keypair: Keypair) -> str:
        """Seller confirms delivery."""
        # Account order: seller(S), escrow
        accounts = [
            AccountMeta(seller_keypair.pubkey(), is_signer=True, is_writable=True),
            AccountMeta(escrow_address, is_signer=False, is_writable=True),
        ]
        return self._send_tx(
            [Instruction(self.program_id, DISC["confirm_delivery"], accounts)],
            [seller_keypair],
        )

    def auto_refund(self, escrow_address: Pubkey) -> str:
        """Trigger auto-refund after T1 timeout. Permissionless crank."""
        escrow = self.get_escrow(escrow_address)
        # Account order: buyer, escrow
        accounts = [
            AccountMeta(escrow.buyer, is_signer=False, is_writable=True),
            AccountMeta(escrow_address, is_signer=False, is_writable=True),
        ]
        return self._send_tx(
            [Instruction(self.program_id, DISC["auto_refund_on_timeout"], accounts)],
            [self.keypair],
        )

    def auto_release(self, escrow_address: Pubkey) -> str:
        """Trigger auto-release after T2. Reads fee wallet from config PDA."""
        escrow = self.get_escrow(escrow_address)
        config = self.get_config(force_refresh=True)
        config_pda, _ = find_config_pda(self.program_id)

        # Account order: seller, escrow, claw_pay_wallet, [referrer], config, system
        accounts = [
            AccountMeta(escrow.seller, is_signer=False, is_writable=True),
            AccountMeta(escrow_address, is_signer=False, is_writable=True),
            AccountMeta(config.fee_wallet, is_signer=False, is_writable=True),
        ]

        if escrow.referrer:
            accounts.append(
                AccountMeta(escrow.referrer, is_signer=False, is_writable=True)
            )

        accounts.extend([
            AccountMeta(config_pda, is_signer=False, is_writable=False),
            AccountMeta(SYSTEM_PROGRAM_ID, is_signer=False, is_writable=False),
        ])

        return self._send_tx(
            [Instruction(self.program_id, DISC["auto_release_on_verification_end"], accounts)],
            [self.keypair],
        )

    def close_escrow(self, escrow_address: Pubkey) -> str:
        """Close settled escrow, reclaim rent to buyer. Buyer must be signer."""
        # Account order: buyer(S), escrow
        accounts = [
            AccountMeta(self.keypair.pubkey(), is_signer=True, is_writable=True),
            AccountMeta(escrow_address, is_signer=False, is_writable=True),
        ]
        return self._send_tx(
            [Instruction(self.program_id, DISC["close_escrow"], accounts)],
            [self.keypair],
        )

    # ── Disputes ──────────────────────────────────────────────────

    def raise_dispute(self, escrow_address: Pubkey, reason: str) -> str:
        """Raise dispute. Caller must be buyer or seller."""
        config_pda, _ = find_config_pda(self.program_id)
        ix_data = DISC["raise_dispute"] + _encode_string(reason)
        # Account order: caller(S), escrow, config  (M-03 audit fix)
        accounts = [
            AccountMeta(self.keypair.pubkey(), is_signer=True, is_writable=True),
            AccountMeta(escrow_address, is_signer=False, is_writable=True),
            AccountMeta(config_pda, is_signer=False, is_writable=False),
        ]
        return self._send_tx(
            [Instruction(self.program_id, ix_data, accounts)],
            [self.keypair],
        )

    def arbitrator_vote(
        self,
        escrow_address: Pubkey,
        vote: int,  # 0=BuyerWins, 1=SellerWins
    ) -> str:
        """Vote on dispute. Signer must have >=5 receipts. Weight = receipt count."""
        arb_counter_pda, _ = find_receipt_counter_pda(self.keypair.pubkey(), self.program_id)
        ix_data = DISC["arbitrator_vote"] + struct.pack("<B", vote)
        # Account order: arbitrator(S), escrow, arbitrator_receipt_counter
        accounts = [
            AccountMeta(self.keypair.pubkey(), is_signer=True, is_writable=True),
            AccountMeta(escrow_address, is_signer=False, is_writable=True),
            AccountMeta(arb_counter_pda, is_signer=False, is_writable=False),
        ]
        return self._send_tx(
            [Instruction(self.program_id, ix_data, accounts)],
            [self.keypair],
        )

    def resolve_dispute(
        self,
        escrow_address: Pubkey,
        primary_recipient: Pubkey,
    ) -> str:
        """Resolve dispute by tallying votes. Caller must be buyer/seller/arbitrator."""
        config = self.get_config(force_refresh=True)
        config_pda, _ = find_config_pda(self.program_id)
        # Account order: caller(S), escrow, primary_recipient, claw_pay_wallet, config, system
        accounts = [
            AccountMeta(self.keypair.pubkey(), is_signer=True, is_writable=True),
            AccountMeta(escrow_address, is_signer=False, is_writable=True),
            AccountMeta(primary_recipient, is_signer=False, is_writable=True),
            AccountMeta(config.fee_wallet, is_signer=False, is_writable=True),
            AccountMeta(config_pda, is_signer=False, is_writable=False),
            AccountMeta(SYSTEM_PROGRAM_ID, is_signer=False, is_writable=False),
        ]
        return self._send_tx(
            [Instruction(self.program_id, DISC["resolve_dispute"], accounts)],
            [self.keypair],
        )

    def claim_arbitrator_reward(self, escrow_address: Pubkey) -> str:
        """Winning arbitrator claims reward share."""
        # Account order: arbitrator(S), escrow
        accounts = [
            AccountMeta(self.keypair.pubkey(), is_signer=True, is_writable=True),
            AccountMeta(escrow_address, is_signer=False, is_writable=True),
        ]
        return self._send_tx(
            [Instruction(self.program_id, DISC["claim_arbitrator_reward"], accounts)],
            [self.keypair],
        )

    # ── Receipts ──────────────────────────────────────────────────

    def initialize_receipt_counter(self, agent: Pubkey) -> str:
        """Initialize receipt counter for an agent. Must be called once before minting."""
        counter_pda, _ = find_receipt_counter_pda(agent, self.program_id)
        # Account order: payer(S), agent, receipt_counter, system
        accounts = [
            AccountMeta(self.keypair.pubkey(), is_signer=True, is_writable=True),
            AccountMeta(agent, is_signer=False, is_writable=False),
            AccountMeta(counter_pda, is_signer=False, is_writable=True),
            AccountMeta(SYSTEM_PROGRAM_ID, is_signer=False, is_writable=False),
        ]
        return self._send_tx(
            [Instruction(self.program_id, DISC["initialize_receipt_counter"], accounts)],
            [self.keypair],
        )

    def mint_receipt(
        self,
        escrow_address: Pubkey,
        agent: Pubkey,
        outcome: int,  # 0=released, 1=refunded, 2=disputed
    ) -> str:
        """Mint receipt for agent. Escrow must be settled (funds_released=true)."""
        if outcome > 2:
            raise ValueError("outcome must be 0, 1, or 2")

        counter_pda, _ = find_receipt_counter_pda(agent, self.program_id)
        # Read current index to derive receipt PDA
        receipt_count = self.get_receipt_count(agent)
        receipt_pda, _ = find_receipt_pda(agent, receipt_count, self.program_id)

        ix_data = (
            DISC["mint_receipt"]
            + bytes(agent)
            + struct.pack("<B", outcome)
        )

        # Account order: payer(S), escrow, agent, receipt_counter, receipt, system
        accounts = [
            AccountMeta(self.keypair.pubkey(), is_signer=True, is_writable=True),
            AccountMeta(escrow_address, is_signer=False, is_writable=False),
            AccountMeta(agent, is_signer=False, is_writable=False),
            AccountMeta(counter_pda, is_signer=False, is_writable=True),
            AccountMeta(receipt_pda, is_signer=False, is_writable=True),
            AccountMeta(SYSTEM_PROGRAM_ID, is_signer=False, is_writable=False),
        ]
        return self._send_tx(
            [Instruction(self.program_id, ix_data, accounts)],
            [self.keypair],
        )

    def get_receipt_count(self, agent: Pubkey, allow_missing: bool = False) -> int:
        counter_pda, _ = find_receipt_counter_pda(agent, self.program_id)
        resp = self._rpc.get_account_info(counter_pda, commitment=Confirmed)
        if not resp.value:
            if allow_missing:
                return 0
            raise ValueError(
                f"Receipt counter not found for {agent}. "
                f"Call initialize_receipt_counter() first."
            )
        # 8 disc + 32 agent + 4 total_receipts
        return struct.unpack_from("<I", resp.value.data, 40)[0]

    def get_receipt(self, agent: Pubkey, index: int) -> ReceiptInfo:
        receipt_pda, _ = find_receipt_pda(agent, index, self.program_id)
        resp = self._rpc.get_account_info(receipt_pda, commitment=Confirmed)
        if not resp.value:
            raise ValueError(f"Receipt not found: agent={agent}, index={index}")
        return self._parse_receipt(receipt_pda, resp.value.data)

    def get_all_receipts(self, agent: Pubkey) -> list[ReceiptInfo]:
        count = self.get_receipt_count(agent, allow_missing=True)
        receipts = []
        for i in range(count):
            try:
                receipts.append(self.get_receipt(agent, i))
            except ValueError:
                continue
        return receipts

    # ── Escrow queries ────────────────────────────────────────────

    def get_escrow(self, escrow_address: Pubkey) -> EscrowInfo:
        resp = self._rpc.get_account_info(escrow_address, commitment=Confirmed)
        if not resp.value:
            raise ValueError(f"Escrow not found: {escrow_address}")
        return self._parse_escrow(escrow_address, resp.value.data)

    def get_escrow_by_parts(self, buyer: Pubkey, seller: Pubkey, nonce: int) -> EscrowInfo:
        pda, _ = find_escrow_pda(buyer, seller, nonce, self.program_id)
        return self.get_escrow(pda)

    # ── Balance ───────────────────────────────────────────────────

    def balance(self, address: Optional[Pubkey] = None) -> float:
        addr = address or self.keypair.pubkey()
        resp = self._rpc.get_balance(addr, commitment=Confirmed)
        return resp.value / LAMPORTS_PER_SOL

    # ── Internal ──────────────────────────────────────────────────

    def _send_tx(self, instructions: list[Instruction], signers: list[Keypair]) -> str:
        recent = self._rpc.get_latest_blockhash(commitment=Confirmed)
        blockhash = recent.value.blockhash
        msg = Message.new_with_blockhash(instructions, signers[0].pubkey(), blockhash)
        tx = Transaction.new_unsigned(msg)
        tx.sign(signers, blockhash)
        result = self._rpc.send_transaction(
            tx, opts=TxOpts(skip_preflight=False, preflight_commitment=Confirmed),
        )
        return str(result.value)

    def _build_signed_tx(self, instructions: list[Instruction], signers: list[Keypair]) -> str:
        """Build and sign a transaction, return as base64 for relay."""
        import base64
        recent = self._rpc.get_latest_blockhash(commitment=Confirmed)
        blockhash = recent.value.blockhash
        msg = Message.new_with_blockhash(instructions, signers[0].pubkey(), blockhash)
        tx = Transaction.new_unsigned(msg)
        tx.sign(signers, blockhash)
        return base64.b64encode(bytes(tx)).decode("ascii")

    def relay_signed_tx(self, signed_tx_b64: str) -> str:
        """Relay a pre-signed base64 transaction to the network."""
        import base64
        tx = Transaction.from_bytes(base64.b64decode(signed_tx_b64))
        result = self._rpc.send_transaction(
            tx, opts=TxOpts(skip_preflight=False, preflight_commitment=Confirmed),
        )
        return str(result.value)

    def _parse_escrow(self, address: Pubkey, data: bytes) -> EscrowInfo:
        """
        Parse EscrowState — field order MUST match contract struct exactly:
        [8 disc] amount(8) buyer(32) seller(32) nonce(8) t0(8) t1(8) t2(8)
        delivered(1) referrer(1+0/32) bump(1) is_disputed(1) dispute_ts(8)
        arb_round(4) votes(4+n*50) resolution(1+0/33) funds_released(1)
        """
        o = 8  # skip discriminator

        amount = struct.unpack_from("<Q", data, o)[0]; o += 8
        buyer = Pubkey.from_bytes(data[o:o+32]); o += 32
        seller = Pubkey.from_bytes(data[o:o+32]); o += 32
        nonce = struct.unpack_from("<Q", data, o)[0]; o += 8       # SDK-01 FIX
        t0 = struct.unpack_from("<q", data, o)[0]; o += 8
        t1 = struct.unpack_from("<q", data, o)[0]; o += 8
        t2 = struct.unpack_from("<q", data, o)[0]; o += 8
        delivered = bool(data[o]); o += 1

        # Option<Pubkey> referrer
        has_referrer = data[o]; o += 1
        referrer = None
        if has_referrer:
            referrer = Pubkey.from_bytes(data[o:o+32]); o += 32

        bump = data[o]; o += 1
        is_disputed = bool(data[o]); o += 1
        dispute_timestamp = struct.unpack_from("<q", data, o)[0]; o += 8
        arbitration_round = struct.unpack_from("<I", data, o)[0]; o += 4

        # Vec<ArbitratorVote>
        vec_len = struct.unpack_from("<I", data, o)[0]; o += 4
        o += vec_len * ARBITRATOR_VOTE_SIZE

        # Option<DisputeResolution>                                # SDK-04 FIX
        has_resolution = data[o]; o += 1
        if has_resolution:
            o += DISPUTE_RESOLUTION_SIZE

        funds_released = bool(data[o])

        return EscrowInfo(
            address=address, buyer=buyer, seller=seller,
            amount=amount, nonce=nonce,
            t0=t0, t1=t1, t2=t2,
            delivered=delivered, disputed=is_disputed,
            released=funds_released, referrer=referrer,
            bump=bump, dispute_timestamp=dispute_timestamp,
            arbitration_round=arbitration_round,
        )

    def _parse_receipt(self, address: Pubkey, data: bytes) -> ReceiptInfo:
        o = 8  # skip discriminator
        agent = Pubkey.from_bytes(data[o:o+32]); o += 32
        receipt_index = struct.unpack_from("<I", data, o)[0]; o += 4
        escrow_id = Pubkey.from_bytes(data[o:o+32]); o += 32
        buyer = Pubkey.from_bytes(data[o:o+32]); o += 32
        seller = Pubkey.from_bytes(data[o:o+32]); o += 32
        amount = struct.unpack_from("<Q", data, o)[0]; o += 8
        outcome = data[o]; o += 1
        timestamp = struct.unpack_from("<q", data, o)[0]; o += 8
        content_hash = data[o:o+32]; o += 32
        is_verified = bool(data[o])
        return ReceiptInfo(
            address=address, agent=agent, receipt_index=receipt_index,
            escrow_id=escrow_id, buyer=buyer, seller=seller,
            amount=amount, outcome=outcome, timestamp=timestamp,
            content_hash=content_hash, is_verified=is_verified,
        )


# ── Convenience alias ────────────────────────────────────────────────
# API server can do: from clawpay_sdk import ClawPay
ClawPay = Client
