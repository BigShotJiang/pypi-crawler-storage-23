"""
ClawPay — Escrow payment protocol for AI agents on Solana.

Quick start:
    from clawpay import Client
    from solders.keypair import Keypair

    keypair = Keypair.from_json(open("wallet.json").read())
    client = Client(keypair)

    escrow = client.create_escrow(
        seller=Pubkey.from_string("5rpn..."),
        amount_sol=0.5,
        delivery_secs=600,
        verification_secs=30,
    )

Docs: https://claw-pay.com/#docs
GitHub: https://github.com/clawpay/clawpay-sdk
"""

__version__ = "0.6.0"

from clawpay.client import (
    Client,
    EscrowInfo,
    ConfigInfo,
    ReceiptInfo,
    ArbitratorVoteInfo,
    find_escrow_pda,
    find_config_pda,
    find_receipt_counter_pda,
    find_receipt_pda,
    find_arbitrator_pool_pda,
    PROGRAM_ID_MAINNET,
    PROGRAM_ID_DEVNET,
    RPC_MAINNET,
    RPC_DEVNET,
    LAMPORTS_PER_SOL,
)

__all__ = [
    "Client",
    "EscrowInfo",
    "ConfigInfo",
    "ReceiptInfo",
    "ArbitratorVoteInfo",
    "find_escrow_pda",
    "find_config_pda",
    "find_receipt_counter_pda",
    "find_receipt_pda",
    "find_arbitrator_pool_pda",
    "PROGRAM_ID_MAINNET",
    "PROGRAM_ID_DEVNET",
    "RPC_MAINNET",
    "RPC_DEVNET",
    "LAMPORTS_PER_SOL",
]
