"""Network Scanner module for discovering active devices in CIDR ranges."""
import ipaddress
import logging
import socket
from concurrent.futures import ThreadPoolExecutor
from typing import Any

logger = logging.getLogger(__name__)

class NetworkScanner:
    """Scans CIDR ranges to find active network devices."""

    def __init__(self, config: dict[str, Any]):
        self.cidrs = [ipaddress.ip_network(c) for c in config.get("cidrs", [])]
        self.exclude_ips = {ipaddress.ip_address(ip) for ip in config.get("exclude", [])}
        # Default to SSH (22) if not specified
        self.scan_ports = config.get("scan_ports", [22])
        # Concurrency control
        self.threads = config.get("threads", 50)
        # Default vendor for discovered devices (configurable via discovery.yaml)
        self.default_vendor = config.get("default_vendor", "cisco_ios")

    def is_port_open(self, ip: str, port: int, timeout: float = 1.0) -> bool:
        """Check if a TCP port is open."""
        try:
            with socket.create_connection((ip, port), timeout=timeout):
                return True
        except (TimeoutError, ConnectionRefusedError, OSError):
            return False

    def scan_ip(self, ip: ipaddress.IPv4Address) -> dict[str, Any] | None:
        """Check if an IP is active on any of the scan ports."""
        if ip in self.exclude_ips:
            return None

        ip_str = str(ip)
        for port in self.scan_ports:
            if self.is_port_open(ip_str, port):
                logger.debug("Found active device at %s:%d", ip_str, port)
                return {
                    "host": ip_str,
                    "port": port,
                    "hostname": ip_str,
                    "vendor": self.default_vendor
                }
        return None

    def scan(self) -> list[dict[str, Any]]:
        """Run the scan across all configured CIDRs."""
        active_devices = []

        # Flatten all IPs from all CIDRs
        all_ips = []
        for cidr in self.cidrs:
            # Skip network and broadcast addresses
            all_ips.extend([ip for ip in cidr.hosts()])

        logger.info("Starting scan of %d IPs with %d threads...", len(all_ips), self.threads)

        with ThreadPoolExecutor(max_workers=self.threads) as executor:
            results = executor.map(self.scan_ip, all_ips)

        for res in results:
            if res:
                active_devices.append(res)

        logger.info("Scan complete. Found %d active devices.", len(active_devices))
        return active_devices
