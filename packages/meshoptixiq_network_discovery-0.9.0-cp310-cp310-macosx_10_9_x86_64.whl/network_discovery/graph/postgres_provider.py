import logging
import os
from typing import Any

from psycopg.rows import dict_row
from psycopg_pool import ConnectionPool

from network_discovery.graph.provider import GraphProvider
from network_discovery.normalization.models import NetworkFacts

logger = logging.getLogger(__name__)

_DEFAULT_DSN = "postgresql://postgres:postgres@localhost:5432/network_discovery"
_MIN = int(os.environ.get("POSTGRES_POOL_MIN", "2"))
_MAX = int(os.environ.get("POSTGRES_POOL_MAX", "10"))


class PostgresProvider(GraphProvider):
    """PostgreSQL implementation of the GraphProvider backed by a connection pool."""

    def __init__(self, dsn: str | None = None):
        self._dsn = dsn or os.environ.get("POSTGRES_DSN", _DEFAULT_DSN)
        self._pool = ConnectionPool(
            self._dsn,
            min_size=_MIN,
            max_size=_MAX,
            reconnect_timeout=30,
            kwargs={"row_factory": dict_row, "autocommit": True},
        )
        self._init_schema()

    def _init_schema(self) -> None:
        """Idempotently create tables using a pool connection."""
        schema_path = os.path.join(os.path.dirname(__file__), "postgres", "schema.sql")
        if not os.path.exists(schema_path):
            logger.warning("Schema file not found at %s", schema_path)
            return
        with open(schema_path) as f:
            sql = f.read()
        with self._pool.connection() as conn:
            conn.execute(sql)
        self.migrate_vrf()

    def migrate_vrf(self) -> None:
        """Idempotent migration: add vrf/tenant columns to existing schemas.

        Safe to run on both fresh and pre-existing databases.  The PK change
        from (address) → (address, vrf) requires a manual migration step on
        live databases; this method only adds the new columns.
        """
        migrations = [
            "ALTER TABLE ip_addresses ADD COLUMN IF NOT EXISTS vrf TEXT NOT NULL DEFAULT 'global'",
            "ALTER TABLE subnets ADD COLUMN IF NOT EXISTS vrf TEXT NOT NULL DEFAULT 'global'",
            "ALTER TABLE subnets ADD COLUMN IF NOT EXISTS tenant TEXT",
            "ALTER TABLE ip_subnet_memberships ADD COLUMN IF NOT EXISTS ip_vrf TEXT NOT NULL DEFAULT 'global'",
            "ALTER TABLE ip_subnet_memberships ADD COLUMN IF NOT EXISTS subnet_vrf TEXT NOT NULL DEFAULT 'global'",
        ]
        with self._pool.connection() as conn:
            for stmt in migrations:
                try:
                    conn.execute(stmt)
                except Exception as exc:
                    logger.debug("VRF migration step skipped (%s): %s", stmt[:60], exc)
        logger.debug("VRF migration check complete")

    def pool_check(self) -> None:
        """Verify all pool connections are healthy (raises on failure)."""
        self._pool.check()

    def pool_stats(self) -> dict[str, Any]:
        """Return connection pool statistics."""
        return self._pool.get_stats()

    def close(self) -> None:
        self._pool.close()

    def execute_query(
        self, query_name: str, query_content: str, params: dict[str, Any]
    ) -> list[dict[str, Any]]:
        with self._pool.connection() as conn:
            with conn.cursor() as cur:
                cur.execute(query_content, params)
                return cur.fetchall() if cur.description else []

    def ingest(self, facts: NetworkFacts) -> dict[str, int]:
        counts: dict[str, int] = {}
        with self._pool.connection() as conn:
            with conn.transaction():
                if facts.devices:
                    counts["devices"] = self._ingest_devices(conn, facts.devices)
                if facts.interfaces:
                    counts["interfaces"] = self._ingest_interfaces(conn, facts.interfaces)
                if facts.ip_addresses:
                    counts["ip_addresses"] = self._ingest_ip_addresses(conn, facts.ip_addresses)
                if facts.subnets:
                    counts["subnets"] = self._ingest_subnets(conn, facts.subnets, facts.ip_addresses)
                if facts.vlans:
                    counts["vlans"] = self._ingest_vlans(conn, facts.vlans)
                if facts.macs:
                    counts["macs"] = self._ingest_macs(conn, facts.macs)
                if facts.endpoints:
                    counts["endpoints"] = self._ingest_endpoints(conn, facts.endpoints)
                if facts.firewall_rules:
                    counts["firewall_rules"] = self._ingest_firewall_rules(conn, facts.firewall_rules)
                if facts.address_objects:
                    counts["address_objects"] = self._ingest_address_objects(conn, facts.address_objects)
                if facts.service_objects:
                    counts["service_objects"] = self._ingest_service_objects(conn, facts.service_objects)
        return counts

    # --- SQL Ingestion Helpers ---

    def _ingest_devices(self, conn, devices: list[Any]) -> int:
        query = """
        INSERT INTO devices (hostname, vendor, model, serial, os_version, collected_at)
        VALUES (%(hostname)s, %(vendor)s, %(model)s, %(serial)s, %(os_version)s, %(collected_at)s)
        ON CONFLICT (hostname) DO UPDATE SET
            vendor = EXCLUDED.vendor,
            model = EXCLUDED.model,
            serial = EXCLUDED.serial,
            os_version = EXCLUDED.os_version,
            collected_at = EXCLUDED.collected_at;
        """
        params = [d.model_dump() for d in devices]
        with conn.cursor() as cur:
            cur.executemany(query, params)
        return len(devices)

    def _ingest_interfaces(self, conn, interfaces: list[Any]) -> int:
        query = """
        INSERT INTO interfaces (device_hostname, name, admin_status, oper_status, speed, mtu, description, mac_address)
        VALUES (%(device_hostname)s, %(name)s, %(admin_status)s, %(oper_status)s, %(speed)s, %(mtu)s, %(description)s, %(mac_address)s)
        ON CONFLICT (device_hostname, name) DO UPDATE SET
            admin_status = EXCLUDED.admin_status,
            oper_status = EXCLUDED.oper_status,
            speed = EXCLUDED.speed,
            mtu = EXCLUDED.mtu,
            description = EXCLUDED.description,
            mac_address = EXCLUDED.mac_address;
        """
        params = [i.model_dump() for i in interfaces]
        with conn.cursor() as cur:
            cur.executemany(query, params)
        return len(interfaces)

    def _ingest_ip_addresses(self, conn, ips: list[Any]) -> int:
        query = """
        INSERT INTO ip_addresses (address, vrf, prefix_length, version, interface_name, device_hostname)
        VALUES (%(address)s, %(vrf)s, %(prefix_length)s, %(version)s, %(interface_name)s, %(device_hostname)s)
        ON CONFLICT (address, vrf) DO UPDATE SET
            prefix_length = EXCLUDED.prefix_length,
            version = EXCLUDED.version,
            interface_name = EXCLUDED.interface_name,
            device_hostname = EXCLUDED.device_hostname;
        """
        params = [
            {**ip.model_dump(), "vrf": ip.vrf or "global"}
            for ip in ips
        ]
        with conn.cursor() as cur:
            cur.executemany(query, params)
        return len(ips)

    def _ingest_subnets(self, conn, subnets: list[Any], ips: list[Any]) -> int:
        query_sub = """
        INSERT INTO subnets (network_address, vrf, prefix_length, version, tenant)
        VALUES (%(network_address)s, %(vrf)s, %(prefix_length)s, %(version)s, %(tenant)s)
        ON CONFLICT (network_address, vrf) DO UPDATE SET
            prefix_length = EXCLUDED.prefix_length,
            version = EXCLUDED.version,
            tenant = EXCLUDED.tenant;
        """
        params_sub = [
            {**s.model_dump(), "vrf": s.vrf or "global"}
            for s in subnets
        ]
        with conn.cursor() as cur:
            cur.executemany(query_sub, params_sub)

        import ipaddress as ipaddr_mod

        # Build (network_address, vrf) → ipaddress.Network mapping
        subnet_networks: dict[tuple[str, str], Any] = {}
        for s in subnets:
            try:
                net = ipaddr_mod.ip_network(s.network_address, strict=False)
                subnet_networks[(s.network_address, s.vrf or "global")] = net
            except ValueError:
                continue

        sorted_subnets = sorted(
            subnet_networks.items(), key=lambda x: x[1].prefixlen, reverse=True
        )

        pairs = []
        for ip in ips:
            try:
                addr = ipaddr_mod.ip_address(ip.address)
                ip_vrf = ip.vrf or "global"
            except ValueError:
                continue
            for (net_addr, sub_vrf), network in sorted_subnets:
                if sub_vrf == ip_vrf and addr in network:
                    pairs.append({
                        "ip_address": ip.address,
                        "ip_vrf": ip_vrf,
                        "subnet_address": net_addr,
                        "subnet_vrf": ip_vrf,
                    })
                    break

        if pairs:
            query_rel = """
            INSERT INTO ip_subnet_memberships (ip_address, ip_vrf, subnet_address, subnet_vrf)
            VALUES (%(ip_address)s, %(ip_vrf)s, %(subnet_address)s, %(subnet_vrf)s)
            ON CONFLICT (ip_address, ip_vrf, subnet_address, subnet_vrf) DO NOTHING;
            """
            with conn.cursor() as cur:
                cur.executemany(query_rel, pairs)

        return len(subnets)

    def _ingest_vlans(self, conn, vlans: list[Any]) -> int:
        query = """
        INSERT INTO vlans (device_hostname, vlan_id, name)
        VALUES (%(device_hostname)s, %(vlan_id)s, %(name)s)
        ON CONFLICT (device_hostname, vlan_id) DO UPDATE SET
            name = EXCLUDED.name;
        """
        params = [v.model_dump() for v in vlans]
        with conn.cursor() as cur:
            cur.executemany(query, params)
        return len(vlans)

    def _ingest_macs(self, conn, macs: list[Any]) -> int:
        query_mac = """
        INSERT INTO macs (address, vendor_oui)
        VALUES (%(address)s, %(vendor_oui)s)
        ON CONFLICT (address) DO UPDATE SET
            vendor_oui = EXCLUDED.vendor_oui;
        """
        query_learn = """
        INSERT INTO mac_learned_on (mac_address, device_hostname, interface_name)
        VALUES (%(address)s, %(device_hostname)s, %(interface_name)s)
        ON CONFLICT (mac_address, device_hostname, interface_name) DO NOTHING;
        """
        params = [m.model_dump() for m in macs]
        with conn.cursor() as cur:
            cur.executemany(query_mac, params)
            valid_relations = [p for p in params if p["device_hostname"] and p["interface_name"]]
            cur.executemany(query_learn, valid_relations)
        return len(macs)

    def _ingest_endpoints(self, conn, endpoints: list[Any]) -> int:
        query = """
        INSERT INTO endpoints (mac_address, ip_address, first_seen, last_seen)
        VALUES (%(mac_address)s, %(ip_address)s, %(first_seen)s, %(last_seen)s)
        ON CONFLICT (mac_address, ip_address) DO UPDATE SET
            first_seen = LEAST(endpoints.first_seen, EXCLUDED.first_seen),
            last_seen = EXCLUDED.last_seen;
        """
        params = [e.model_dump() for e in endpoints]
        with conn.cursor() as cur:
            cur.executemany(query, params)
        return len(endpoints)

    def _ingest_firewall_rules(self, conn, rules: list[Any]) -> int:
        query = """
        INSERT INTO firewall_rules (
            device_hostname, rule_id, rule_name, rule_order, action,
            source_zones, destination_zones, source_addresses, destination_addresses,
            services, protocols, destination_ports,
            enabled, log_enabled, comments, vendor, collected_at
        )
        VALUES (
            %(device_hostname)s, %(rule_id)s, %(rule_name)s, %(rule_order)s, %(action)s,
            %(source_zones)s, %(destination_zones)s, %(source_addresses)s, %(destination_addresses)s,
            %(services)s, %(protocols)s, %(destination_ports)s,
            %(enabled)s, %(log_enabled)s, %(comments)s, %(vendor)s, %(collected_at)s
        )
        ON CONFLICT (device_hostname, rule_id) DO UPDATE SET
            rule_name = EXCLUDED.rule_name,
            rule_order = EXCLUDED.rule_order,
            action = EXCLUDED.action,
            source_zones = EXCLUDED.source_zones,
            destination_zones = EXCLUDED.destination_zones,
            source_addresses = EXCLUDED.source_addresses,
            destination_addresses = EXCLUDED.destination_addresses,
            services = EXCLUDED.services,
            protocols = EXCLUDED.protocols,
            destination_ports = EXCLUDED.destination_ports,
            enabled = EXCLUDED.enabled,
            log_enabled = EXCLUDED.log_enabled,
            comments = EXCLUDED.comments,
            vendor = EXCLUDED.vendor,
            collected_at = EXCLUDED.collected_at;
        """
        params = [
            {
                **r.model_dump(),
                "collected_at": r.collected_at.isoformat() if r.collected_at else None,
            }
            for r in rules
        ]
        with conn.cursor() as cur:
            cur.executemany(query, params)
        return len(rules)

    def _ingest_address_objects(self, conn, objects: list[Any]) -> int:
        query = """
        INSERT INTO address_objects (device_hostname, name, type, value, vendor)
        VALUES (%(device_hostname)s, %(name)s, %(type)s, %(value)s, %(vendor)s)
        ON CONFLICT (device_hostname, name) DO UPDATE SET
            type = EXCLUDED.type,
            value = EXCLUDED.value,
            vendor = EXCLUDED.vendor;
        """
        params = [o.model_dump() for o in objects]
        with conn.cursor() as cur:
            cur.executemany(query, params)
        return len(objects)

    def _ingest_service_objects(self, conn, objects: list[Any]) -> int:
        query = """
        INSERT INTO service_objects (device_hostname, name, protocol, dest_ports, vendor)
        VALUES (%(device_hostname)s, %(name)s, %(protocol)s, %(dest_ports)s, %(vendor)s)
        ON CONFLICT (device_hostname, name) DO UPDATE SET
            protocol = EXCLUDED.protocol,
            dest_ports = EXCLUDED.dest_ports,
            vendor = EXCLUDED.vendor;
        """
        params = [o.model_dump() for o in objects]
        with conn.cursor() as cur:
            cur.executemany(query, params)
        return len(objects)
