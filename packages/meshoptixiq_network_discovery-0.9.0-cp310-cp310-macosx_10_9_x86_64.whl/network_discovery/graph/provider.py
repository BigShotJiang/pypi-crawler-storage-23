from abc import ABC, abstractmethod
from typing import Any

from network_discovery.normalization.models import NetworkFacts


class GraphProvider(ABC):
    """Abstract interface for graph database backends."""

    @abstractmethod
    def ingest(self, facts: NetworkFacts) -> dict[str, int]:
        """Ingest normalized network facts into the graph."""
        pass

    @abstractmethod
    def execute_query(self, query_name: str, query_content: str, params: dict[str, Any]) -> list[dict[str, Any]]:
        """Execute a stored query (Cypher or SQL) against the backend.

        Args:
            query_name: The name of the query (for logging/metrics).
            query_content: The actual query string (Cypher or SQL).
            params: Parameters to pass to the query using the backend's native parameterization.
        """
        pass

    @abstractmethod
    def close(self):
        """Close any underlying connections."""
        pass


class GraphProviderFactory:
    """Factory for creating the configured GraphProvider backend."""

    @staticmethod
    def get_provider() -> "GraphProvider":
        """Create a GraphProvider based on the GRAPH_BACKEND env var.

        Returns Neo4jProvider by default, or PostgresProvider if
        GRAPH_BACKEND=postgres.
        """
        import os

        backend = os.environ.get("GRAPH_BACKEND", "neo4j").lower()
        if backend == "postgres":
            from network_discovery.graph.postgres_provider import PostgresProvider

            return PostgresProvider()
        elif backend == "inmemory":
            from network_discovery.graph.inmemory_provider import InMemoryGraphProvider

            return InMemoryGraphProvider()
        else:
            from network_discovery.graph.neo4j_provider import Neo4jProvider

            return Neo4jProvider()
