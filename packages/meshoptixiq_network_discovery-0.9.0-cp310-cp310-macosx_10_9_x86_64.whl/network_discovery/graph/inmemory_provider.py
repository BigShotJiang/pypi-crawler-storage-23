"""In-memory graph provider for demo / zero-dependency deployments.

Stores all ingested NetworkFacts in Python dicts and answers every registered
query without touching Neo4j or PostgreSQL.  Activate with::

    GRAPH_BACKEND=inmemory

Intended for ``MESHOPTIXIQ_DEMO_MODE`` and offline exploration only.  There is
no persistence; data is lost when the process exits.
"""

from __future__ import annotations

import ipaddress
import logging
from typing import Any

from network_discovery.graph.provider import GraphProvider
from network_discovery.normalization.models import NetworkFacts

logger = logging.getLogger(__name__)


class InMemoryGraphProvider(GraphProvider):
    """In-process graph backend — all data lives in Python dicts."""

    def __init__(self) -> None:
        self._data: dict[str, list[dict]] = {
            "devices": [],
            "interfaces": [],
            "ip_addresses": [],
            "subnets": [],
            "vlans": [],
            "macs": [],
            "endpoints": [],
            "firewall_rules": [],
            "address_objects": [],
            "service_objects": [],
        }

    # ------------------------------------------------------------------
    # GraphProvider interface
    # ------------------------------------------------------------------

    def ingest(self, facts: NetworkFacts) -> dict[str, int]:
        """Merge a NetworkFacts object into the in-memory store."""
        counts: dict[str, int] = {}

        for field in (
            "devices", "interfaces", "ip_addresses", "subnets",
            "vlans", "macs", "endpoints",
            "firewall_rules", "address_objects", "service_objects",
        ):
            items = getattr(facts, field, [])
            new_dicts = [m.model_dump() for m in items]
            if field == "devices":
                # Deduplicate by hostname
                existing = {d["hostname"] for d in self._data["devices"]}
                added = [d for d in new_dicts if d["hostname"] not in existing]
                self._data["devices"].extend(added)
                counts[field] = len(added)
            elif field == "ip_addresses":
                # VRF-aware deduplication: (address, vrf) must be unique
                existing = {
                    (ip["address"], ip.get("vrf") or "global")
                    for ip in self._data["ip_addresses"]
                }
                added = [
                    ip for ip in new_dicts
                    if (ip["address"], ip.get("vrf") or "global") not in existing
                ]
                self._data["ip_addresses"].extend(added)
                counts[field] = len(added)
            else:
                self._data[field].extend(new_dicts)
                counts[field] = len(new_dicts)

        logger.info(
            "InMemoryProvider ingested: %s",
            ", ".join(f"{v} {k}" for k, v in counts.items() if v),
        )
        return counts

    def execute_query(
        self,
        query_name: str,
        query_content: str,  # ignored — we use Python handlers
        params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        handler = _QUERY_HANDLERS.get(query_name)
        if handler is None:
            logger.debug("InMemoryProvider: no handler for query '%s'", query_name)
            return []
        try:
            return handler(self._data, params)
        except Exception as exc:
            logger.warning("InMemoryProvider query '%s' failed: %s", query_name, exc)
            return []

    def close(self) -> None:
        pass


# ---------------------------------------------------------------------------
# Query handlers — one function per registered query name
# ---------------------------------------------------------------------------

def _q_device_neighbors(data: dict, params: dict) -> list[dict]:
    """Devices directly connected to a given device."""
    target = (params.get("device_name") or "").lower()
    neighbors: list[str] = []
    for iface in data["interfaces"]:
        # Simple heuristic: interfaces named "GigabitEthernet0/0/0.link.<peer>" hold peer
        if iface["device_hostname"].lower() == target:
            desc = iface.get("description") or ""
            if desc.startswith("link:"):
                peer = desc[len("link:"):]
                if peer and peer not in neighbors:
                    neighbors.append(peer)
    return [{"neighbor": n} for n in neighbors]


def _q_interface_neighbors(data: dict, params: dict) -> list[dict]:
    """Interfaces connecting two devices."""
    a = (params.get("device_a") or "").lower()
    b = (params.get("device_b") or "").lower()
    rows = []
    for iface in data["interfaces"]:
        host = iface["device_hostname"].lower()
        desc = iface.get("description") or ""
        if host == a and desc.startswith("link:") and desc[len("link:"):].lower() == b:
            rows.append({
                "device_a": a,
                "interface_a": iface["name"],
                "device_b": b,
                "interface_b": "unknown",
            })
    return rows


def _q_locate_endpoint_by_ip(data: dict, params: dict) -> list[dict]:
    ip = (params.get("ip") or "").strip()
    vrf_filter = (params.get("vrf") or "").strip()
    rows = []
    for ep in data["endpoints"]:
        if ep["ip_address"] == ip:
            mac = ep["mac_address"]
            # Resolve VRF from ip_addresses
            ep_vrf = "global"
            for addr in data["ip_addresses"]:
                if addr["address"] == ip:
                    ep_vrf = addr.get("vrf") or "global"
                    break
            if vrf_filter and ep_vrf != vrf_filter:
                continue
            # Find which interface this MAC is seen on
            for iface in data["interfaces"]:
                if iface.get("mac_address") == mac:
                    rows.append({
                        "ip_address": ip,
                        "mac_address": mac,
                        "vrf": ep_vrf,
                        "device": iface["device_hostname"],
                        "interface": iface["name"],
                    })
                    return rows
            rows.append({
                "ip_address": ip,
                "mac_address": mac,
                "vrf": ep_vrf,
                "device": None,
                "interface": None,
            })
    return rows


def _q_locate_endpoint_by_mac(data: dict, params: dict) -> list[dict]:
    mac = (params.get("mac") or "").upper()
    rows = []
    for ep in data["endpoints"]:
        if ep["mac_address"].upper() == mac:
            for iface in data["interfaces"]:
                if (iface.get("mac_address") or "").upper() == mac:
                    rows.append({
                        "ip_address": ep["ip_address"],
                        "mac_address": mac,
                        "device": iface["device_hostname"],
                        "interface": iface["name"],
                    })
                    return rows
            rows.append({"ip_address": ep["ip_address"], "mac_address": mac,
                         "device": None, "interface": None})
    return rows


def _q_endpoints_on_interface(data: dict, params: dict) -> list[dict]:
    device = (params.get("device") or "").lower()
    iface = (params.get("interface") or "").lower()
    # Collect MACs assigned to this device/interface first — O(interfaces)
    macs: set[str] = {
        i["mac_address"]
        for i in data["interfaces"]
        if (i["device_hostname"].lower() == device
            and i["name"].lower() == iface
            and i.get("mac_address"))
    }
    if not macs:
        return []
    # Then scan endpoints once — O(endpoints)
    return [
        {"ip_address": ep["ip_address"], "mac_address": ep["mac_address"]}
        for ep in data["endpoints"]
        if ep["mac_address"] in macs
    ]


def _q_blast_radius_interface(data: dict, params: dict) -> list[dict]:
    device = (params.get("device") or "").lower()
    iface_name = (params.get("interface") or "").lower()
    # Return all endpoints on that device/interface
    macs: set[str] = set()
    for i in data["interfaces"]:
        if i["device_hostname"].lower() == device and i["name"].lower() == iface_name:
            if i.get("mac_address"):
                macs.add(i["mac_address"])
    rows = []
    for ep in data["endpoints"]:
        if ep["mac_address"] in macs:
            rows.append({"ip_address": ep["ip_address"], "mac_address": ep["mac_address"]})
    # Fallback — return some endpoints for demo richness
    if not rows:
        rows = [{"ip_address": ep["ip_address"], "mac_address": ep["mac_address"]}
                for ep in data["endpoints"][:10]]
    return rows


def _q_blast_radius_device(data: dict, params: dict) -> list[dict]:
    device = (params.get("device") or "").lower()
    # All endpoints that have an IP on a subnet assigned to this device
    device_ips = {
        ip["address"]
        for ip in data["ip_addresses"]
        if (ip.get("device_hostname") or "").lower() == device
    }
    device_subnets: set[ipaddress.IPv4Network | ipaddress.IPv6Network] = set()
    for ip_str in device_ips:
        for subnet in data["subnets"]:
            try:
                net = ipaddress.ip_network(
                    f"{subnet['network_address']}/{subnet['prefix_length']}", strict=False
                )
                if ipaddress.ip_address(ip_str) in net:
                    device_subnets.add(net)
            except ValueError:
                pass

    rows = []
    seen: set[str] = set()
    for ep in data["endpoints"]:
        try:
            ep_ip = ipaddress.ip_address(ep["ip_address"])
            for net in device_subnets:
                if ep_ip in net and ep["ip_address"] not in seen:
                    seen.add(ep["ip_address"])
                    rows.append({"ip_address": ep["ip_address"], "mac_address": ep["mac_address"]})
        except ValueError:
            pass

    # Demo fallback: return a slice of endpoints for richness
    if not rows:
        rows = [{"ip_address": ep["ip_address"], "mac_address": ep["mac_address"]}
                for ep in data["endpoints"][:30]]
    return rows


def _q_blast_radius_vlan(data: dict, params: dict) -> list[dict]:
    vlan_id = int(params.get("vlan") or 0)
    # Return VLANs that match, plus some endpoints
    matching = [v for v in data["vlans"] if v["vlan_id"] == vlan_id]
    if not matching and data["vlans"]:
        # fallback: use first vlan for demo
        vlan_id = data["vlans"][0]["vlan_id"]
    rows = [{"ip_address": ep["ip_address"], "mac_address": ep["mac_address"]}
            for ep in data["endpoints"][:20]]
    return rows


def _q_blast_radius_subnet(data: dict, params: dict) -> list[dict]:
    cidr = (params.get("cidr") or "").strip()
    try:
        target_net = ipaddress.ip_network(cidr, strict=False)
    except ValueError:
        return []
    rows = []
    for ep in data["endpoints"]:
        try:
            if ipaddress.ip_address(ep["ip_address"]) in target_net:
                rows.append({"ip_address": ep["ip_address"], "mac_address": ep["mac_address"]})
        except ValueError:
            pass
    # Demo fallback
    if not rows:
        rows = [{"ip_address": ep["ip_address"], "mac_address": ep["mac_address"]}
                for ep in data["endpoints"][:15]]
    return rows


def _q_ips_in_subnet(data: dict, params: dict) -> list[dict]:
    cidr = (params.get("cidr") or "").strip()
    vrf_filter = (params.get("vrf") or "").strip()
    try:
        target_net = ipaddress.ip_network(cidr, strict=False)
    except ValueError:
        return []
    rows = []
    for ip in data["ip_addresses"]:
        try:
            if ipaddress.ip_address(ip["address"]) in target_net:
                ip_vrf = ip.get("vrf") or "global"
                if vrf_filter and ip_vrf != vrf_filter:
                    continue
                rows.append({
                    "address": ip["address"],
                    "prefix_length": ip["prefix_length"],
                    "vrf": ip_vrf,
                    "device": ip.get("device_hostname"),
                    "interface": ip.get("interface_name"),
                })
        except ValueError:
            pass
    if not rows:
        rows = [
            {
                "address": ip["address"],
                "prefix_length": ip["prefix_length"],
                "vrf": ip.get("vrf") or "global",
                "device": ip.get("device_hostname"),
                "interface": ip.get("interface_name"),
            }
            for ip in data["ip_addresses"][:20]
        ]
    return rows


def _q_subnets_on_device(data: dict, params: dict) -> list[dict]:
    device = (params.get("device") or "").lower()
    device_ips = [
        ip for ip in data["ip_addresses"]
        if (ip.get("device_hostname") or "").lower() == device
    ]
    rows: list[dict] = []
    for ip in device_ips:
        try:
            net = ipaddress.ip_network(
                f"{ip['address']}/{ip['prefix_length']}", strict=False
            )
            cidr = str(net)
            if not any(r["cidr"] == cidr for r in rows):
                rows.append({"cidr": cidr, "device": ip.get("device_hostname"),
                             "interface": ip.get("interface_name")})
        except ValueError:
            pass
    return rows


def _q_orphaned_ips(data: dict, params: dict) -> list[dict]:
    # IPs whose network is not in any known subnet (VRF-aware matching)
    # Build: (vrf, network_object) pairs
    known_networks: list[tuple[str, ipaddress.IPv4Network | ipaddress.IPv6Network]] = []
    for s in data["subnets"]:
        try:
            net = ipaddress.ip_network(
                f"{s['network_address']}/{s['prefix_length']}", strict=False
            )
            known_networks.append((s.get("vrf") or "global", net))
        except ValueError:
            pass

    rows = []
    for ip in data["ip_addresses"]:
        try:
            addr = ipaddress.ip_address(ip["address"])
            ip_vrf = ip.get("vrf") or "global"
            in_subnet = any(
                sub_vrf == ip_vrf and addr in net
                for sub_vrf, net in known_networks
            )
            if not in_subnet:
                rows.append({
                    "address": ip["address"],
                    "vrf": ip_vrf,
                    "device": ip.get("device_hostname"),
                })
        except ValueError:
            pass
    return rows


def _q_devices_without_neighbors(data: dict, params: dict) -> list[dict]:
    # Devices whose hostname has no "link:*" description on any interface
    connected: set[str] = set()
    for iface in data["interfaces"]:
        desc = iface.get("description") or ""
        if desc.startswith("link:"):
            connected.add(iface["device_hostname"])
    rows = [
        {"hostname": d["hostname"], "vendor": d["vendor"]}
        for d in data["devices"]
        if d["hostname"] not in connected
    ]
    return rows


def _q_interfaces_without_ips(data: dict, params: dict) -> list[dict]:
    ips_by_iface: set[str] = {
        (ip.get("device_hostname", ""), ip.get("interface_name", ""))
        for ip in data["ip_addresses"]
    }
    rows = []
    for iface in data["interfaces"]:
        key = (iface["device_hostname"], iface["name"])
        if key not in ips_by_iface:
            rows.append({"device": iface["device_hostname"], "interface": iface["name"]})
    return rows[:50]


def _q_endpoints_without_location(data: dict, params: dict) -> list[dict]:
    located_macs: set[str] = {
        iface.get("mac_address", "")
        for iface in data["interfaces"]
        if iface.get("mac_address")
    }
    rows = []
    for ep in data["endpoints"]:
        if ep["mac_address"] not in located_macs:
            rows.append({"ip_address": ep["ip_address"], "mac_address": ep["mac_address"]})
    return rows[:50]


def _q_devices_missing_os_version(data: dict, params: dict) -> list[dict]:
    return [
        {"hostname": d["hostname"], "vendor": d.get("vendor"), "model": d.get("model")}
        for d in data["devices"]
        if not d.get("os_version")
    ]


def _q_devices_missing_hostname(data: dict, params: dict) -> list[dict]:
    return [
        {
            "vendor": d.get("vendor"),
            "model": d.get("model"),
            "collected_at": str(d.get("collected_at") or ""),
        }
        for d in data["devices"]
        if not d.get("hostname")
    ]


def _q_interfaces_no_description(data: dict, params: dict) -> list[dict]:
    return [
        {
            "device":    iface.get("device_hostname"),
            "interface": iface.get("name"),
            "ip":        iface.get("ip_address"),
        }
        for iface in data["interfaces"]
        if not iface.get("description") and iface.get("status") == "up"
    ]


def _q_duplicate_ip_addresses(data: dict, params: dict) -> list[dict]:
    from collections import Counter
    counts: Counter = Counter(
        (ip.get("address"), ip.get("vrf") or "global")
        for ip in data["ip_addresses"]
    )
    return sorted(
        [
            {"address": addr, "vrf": vrf, "occurrences": cnt}
            for (addr, vrf), cnt in counts.items()
            if cnt > 1
        ],
        key=lambda r: (-r["occurrences"], r["address"]),
    )


def _q_summary_stats(data: dict, params: dict) -> list[dict]:
    return [{
        "device_count":    len(data["devices"]),
        "interface_count": len(data["interfaces"]),
        "endpoint_count":  len(data["endpoints"]),
        "vlan_count":      len(set(v["vlan_id"] for v in data["vlans"])),
        "firewall_rule_count": len(data["firewall_rules"]),
    }]


def _q_all_devices(data: dict, params: dict) -> list[dict]:
    return [
        {
            "hostname":   d["hostname"],
            "vendor":     d["vendor"],
            "model":      d.get("model"),
            "serial":     d.get("serial"),
            "os_version": d.get("os_version"),
        }
        for d in data["devices"]
    ]


def _q_topology_edges(data: dict, params: dict) -> list[dict]:
    rows = []
    seen: set[frozenset] = set()
    for iface in data["interfaces"]:
        desc = iface.get("description") or ""
        if not desc.startswith("link:"):
            continue
        a = iface["device_hostname"]
        b = desc[len("link:"):]
        key = frozenset([a, b])
        if key not in seen and a != b:
            seen.add(key)
            rows.append({
                "device_a": a,
                "interface_a": iface["name"],
                "device_b": b,
                "interface_b": "unknown",
            })
    return rows


def _q_firewall_rules_by_device(data: dict, params: dict) -> list[dict]:
    device = (params.get("device") or "").lower()
    return [
        {
            "device_hostname":       r["device_hostname"],
            "rule_name":             r.get("rule_name") or r["rule_id"],
            "rule_order":            r["rule_order"],
            "action":                r["action"],
            "source_zones":          r.get("source_zones", []),
            "destination_zones":     r.get("destination_zones", []),
            "source_addresses":      r.get("source_addresses", []),
            "destination_addresses": r.get("destination_addresses", []),
            "services":              r.get("services", []),
            "enabled":               r.get("enabled", True),
            "log_enabled":           r.get("log_enabled", False),
        }
        for r in data["firewall_rules"]
        if r["device_hostname"].lower() == device
    ]


def _q_firewall_rules_by_zone_pair(data: dict, params: dict) -> list[dict]:
    src = (params.get("source_zone") or "").lower()
    dst = (params.get("destination_zone") or "").lower()
    rows = []
    for r in data["firewall_rules"]:
        r_src = [z.lower() for z in r.get("source_zones", [])]
        r_dst = [z.lower() for z in r.get("destination_zones", [])]
        if (not src or src in r_src or "any" in r_src) and \
           (not dst or dst in r_dst or "any" in r_dst):
            rows.append({
                "device_hostname": r["device_hostname"],
                "rule_name":       r.get("rule_name") or r["rule_id"],
                "action":          r["action"],
                "source_zones":    r.get("source_zones", []),
                "destination_zones": r.get("destination_zones", []),
                "services":        r.get("services", []),
            })
    return rows


def _q_path_analysis(data: dict, params: dict) -> list[dict]:
    src_ip = params.get("source_ip", "")
    dst_ip = params.get("destination_ip", "")
    proto  = params.get("protocol", "tcp").lower()
    params.get("destination_port", "")

    # Find which device each IP belongs to
    def _device_for_ip(ip_str: str) -> str | None:
        for ip in data["ip_addresses"]:
            if ip["address"] == ip_str:
                return ip.get("device_hostname")
        # Check endpoints
        for ep in data["endpoints"]:
            if ep["ip_address"] == ip_str:
                return None  # endpoint, not device
        return None

    _device_for_ip(src_ip)
    _device_for_ip(dst_ip)

    rows = []
    for fw in data["firewall_rules"]:
        src_addrs = [a.lower() for a in fw.get("source_addresses", [])]
        dst_addrs = [a.lower() for a in fw.get("destination_addresses", [])]
        services  = [s.lower() for s in fw.get("services", [])]

        src_match = not src_addrs or "any" in src_addrs
        dst_match = not dst_addrs or "any" in dst_addrs
        svc_match = not services or "any" in services or proto in services

        if src_match and dst_match and svc_match:
            rows.append({
                "device_hostname": fw["device_hostname"],
                "rule_name":       fw.get("rule_name") or fw["rule_id"],
                "action":          fw["action"],
                "services":        fw.get("services", []),
                "source_addresses": fw.get("source_addresses", []),
                "destination_addresses": fw.get("destination_addresses", []),
            })

    if not rows:
        # Demo fallback — return first 5 rules
        rows = [
            {
                "device_hostname": r["device_hostname"],
                "rule_name":       r.get("rule_name") or r["rule_id"],
                "action":          r["action"],
                "services":        r.get("services", []),
                "source_addresses": r.get("source_addresses", []),
                "destination_addresses": r.get("destination_addresses", []),
            }
            for r in data["firewall_rules"][:5]
        ]
    return rows


def _q_all_firewall_devices(data: dict, params: dict) -> list[dict]:
    hostnames = sorted({r["device_hostname"] for r in data["firewall_rules"]})
    return [{"hostname": h} for h in hostnames]


def _q_deny_rules_summary(data: dict, params: dict) -> list[dict]:
    return [
        {
            "device_hostname":       r["device_hostname"],
            "rule_name":             r.get("rule_name") or r["rule_id"],
            "rule_order":            r["rule_order"],
            "action":                r["action"],
            "source_zones":          r.get("source_zones", []),
            "destination_zones":     r.get("destination_zones", []),
            "source_addresses":      r.get("source_addresses", []),
            "destination_addresses": r.get("destination_addresses", []),
            "services":              r.get("services", []),
        }
        for r in data["firewall_rules"]
        if r["action"] in ("deny", "drop", "reject")
    ]


def _q_topology_neighborhood(data: dict, params: dict) -> list[dict]:
    """BFS N-hop neighborhood around a focal device, returns filtered topology edges."""
    focal = (params.get("device") or "").lower()
    depth = int(params.get("depth") or 2)
    if not focal:
        return []

    # Build adjacency from interface descriptions ("link:<peer>")
    def _neighbors_of(hostname_lower: str) -> set[str]:
        peers: set[str] = set()
        for iface in data["interfaces"]:
            if iface["device_hostname"].lower() == hostname_lower:
                desc = iface.get("description") or ""
                if desc.startswith("link:"):
                    peer = desc[len("link:"):].lower()
                    if peer:
                        peers.add(peer)
        return peers

    # BFS
    visited: set[str] = {focal}
    frontier: set[str] = {focal}
    for _ in range(depth):
        next_frontier: set[str] = set()
        for node in frontier:
            for peer in _neighbors_of(node):
                if peer not in visited:
                    next_frontier.add(peer)
        visited.update(next_frontier)
        frontier = next_frontier
        if not frontier:
            break

    # Return topology edges where both endpoints are in the neighborhood
    rows: list[dict] = []
    seen: set[frozenset] = set()
    for iface in data["interfaces"]:
        desc = iface.get("description") or ""
        if not desc.startswith("link:"):
            continue
        a = iface["device_hostname"].lower()
        b = desc[len("link:"):].lower()
        if a in visited and b in visited and a != b:
            key = frozenset([a, b])
            if key not in seen:
                seen.add(key)
                rows.append({
                    "device_a": iface["device_hostname"],
                    "interface_a": iface["name"],
                    "device_b": desc[len("link:"):],
                    "interface_b": "unknown",
                })
    return rows


def _q_update_device_metadata(data: dict, params: dict) -> list[dict]:
    hostname  = params.get("hostname", "")
    nb_site   = params.get("nb_site", "")
    nb_tenant = params.get("nb_tenant", "")
    nb_rack   = params.get("nb_rack", "")
    for d in data["devices"]:
        if d["hostname"] == hostname:
            d["nb_site"]   = nb_site
            d["nb_tenant"] = nb_tenant
            d["nb_rack"]   = nb_rack
            return [{"updated": 1, "hostname": hostname}]
    return [{"updated": 0, "hostname": hostname}]


# ---------------------------------------------------------------------------
# Handler registry — maps query_name → handler function
# ---------------------------------------------------------------------------
_QUERY_HANDLERS = {
    "device_neighbors":           _q_device_neighbors,
    "interface_neighbors":        _q_interface_neighbors,
    "locate_endpoint_by_ip":      _q_locate_endpoint_by_ip,
    "locate_endpoint_by_mac":     _q_locate_endpoint_by_mac,
    "endpoints_on_interface":     _q_endpoints_on_interface,
    "blast_radius_interface":     _q_blast_radius_interface,
    "blast_radius_device":        _q_blast_radius_device,
    "blast_radius_vlan":          _q_blast_radius_vlan,
    "blast_radius_subnet":        _q_blast_radius_subnet,
    "ips_in_subnet":              _q_ips_in_subnet,
    "subnets_on_device":          _q_subnets_on_device,
    "orphaned_ips":               _q_orphaned_ips,
    "devices_without_neighbors":  _q_devices_without_neighbors,
    "interfaces_without_ips":     _q_interfaces_without_ips,
    "endpoints_without_location": _q_endpoints_without_location,
    "devices_missing_os_version": _q_devices_missing_os_version,
    "devices_missing_hostname":   _q_devices_missing_hostname,
    "interfaces_no_description":  _q_interfaces_no_description,
    "duplicate_ip_addresses":     _q_duplicate_ip_addresses,
    "summary_stats":              _q_summary_stats,
    "all_devices":                _q_all_devices,
    "topology_edges":             _q_topology_edges,
    "firewall_rules_by_device":   _q_firewall_rules_by_device,
    "firewall_rules_by_zone_pair": _q_firewall_rules_by_zone_pair,
    "path_analysis":              _q_path_analysis,
    "all_firewall_devices":       _q_all_firewall_devices,
    "deny_rules_summary":         _q_deny_rules_summary,
    "update_device_metadata":     _q_update_device_metadata,
    "topology_neighborhood":      _q_topology_neighborhood,
}
