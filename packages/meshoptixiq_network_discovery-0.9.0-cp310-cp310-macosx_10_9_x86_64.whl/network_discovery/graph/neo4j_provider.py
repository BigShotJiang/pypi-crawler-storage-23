import logging
import os
from typing import Any

from neo4j import Driver, GraphDatabase, Session

from network_discovery.graph.provider import GraphProvider
from network_discovery.normalization.models import (
    AddressObjectModel,
    DeviceModel,
    EndpointModel,
    FirewallRuleModel,
    InterfaceModel,
    IPAddressModel,
    MACModel,
    NetworkFacts,
    ServiceObjectModel,
    SubnetModel,
    VLANModel,
)

logger = logging.getLogger(__name__)

class Neo4jProvider(GraphProvider):
    """Neo4j implementation of the GraphProvider."""

    def __init__(self, uri: str | None = None, user: str | None = None, password: str | None = None):
        self._uri = uri or os.environ.get("NEO4J_URI", "bolt://localhost:7687")
        self._user = user or os.environ.get("NEO4J_USER", "neo4j")
        self._password = password or os.environ.get("NEO4J_PASSWORD", "")

        if not self._password:
            logger.warning(
                "NEO4J_PASSWORD is empty. This is acceptable for local development "
                "but must be set in production environments."
            )

        self._driver: Driver = GraphDatabase.driver(
            self._uri, auth=(self._user, self._password)
        )
        self._ensure_schema()

    def _ensure_schema(self) -> None:
        """Idempotently create VRF-aware uniqueness constraints at startup."""
        try:
            with self._driver.session() as session:
                session.run(
                    "CREATE CONSTRAINT ip_address_vrf_unique IF NOT EXISTS "
                    "FOR (n:IPAddress) REQUIRE (n.address, n.vrf) IS NODE KEY"
                )
        except Exception as exc:
            # Node key constraints require Neo4j Enterprise or 5.x+; log and continue
            logger.warning("Could not create ip_address_vrf_unique constraint: %s", exc)

    def close(self):
        self._driver.close()

    def execute_query(self, query_name: str, query_content: str, params: dict[str, Any]) -> list[dict[str, Any]]:
        with self._driver.session() as session:
            result = session.run(query_content, **params)
            return [record.data() for record in result]

    def ingest(self, facts: NetworkFacts) -> dict[str, int]:
        counts: dict[str, int] = {}
        with self._driver.session() as session:
            try:
                if facts.devices:
                    counts["devices"] = self._ingest_devices(session, facts.devices)
                if facts.interfaces:
                    counts["interfaces"] = self._ingest_interfaces(session, facts.interfaces)
                if facts.ip_addresses:
                    counts["ip_addresses"] = self._ingest_ip_addresses(session, facts.ip_addresses)
                if facts.subnets:
                    counts["subnets"] = self._ingest_subnets(
                        session, facts.subnets, facts.ip_addresses
                    )
                if facts.vlans:
                    counts["vlans"] = self._ingest_vlans(session, facts.vlans)
                if facts.macs:
                    counts["macs"] = self._ingest_macs(session, facts.macs)
                if facts.endpoints:
                    counts["endpoints"] = self._ingest_endpoints(session, facts.endpoints)
                if facts.firewall_rules:
                    counts["firewall_rules"] = self._ingest_firewall_rules(session, facts.firewall_rules)
                if facts.address_objects:
                    counts["address_objects"] = self._ingest_address_objects(session, facts.address_objects)
                if facts.service_objects:
                    counts["service_objects"] = self._ingest_service_objects(session, facts.service_objects)
            except Exception:
                logger.exception(
                    "Neo4j ingestion failed. Entities written before error: %s", counts
                )
                raise

        logger.info("Ingestion complete (Neo4j): %s", counts)
        return counts

    # --- Ingestion Helpers (Moved from ingest.py) ---

    def _ingest_devices(self, session: Session, devices: list[DeviceModel]) -> int:
        query = """
        UNWIND $devices AS d
        MERGE (dev:Device {hostname: d.hostname})
        SET dev.vendor = d.vendor,
            dev.model = d.model,
            dev.serial = d.serial,
            dev.os_version = d.os_version,
            dev.collected_at = d.collected_at,
            dev.schema_version = $schema_version
        """
        params = [
            {
                "hostname": d.hostname,
                "vendor": d.vendor,
                "model": d.model,
                "serial": d.serial,
                "os_version": d.os_version,
                "collected_at": d.collected_at.isoformat() if d.collected_at else None,
            }
            for d in devices
        ]
        session.run(query, devices=params, schema_version=1)
        return len(devices)

    def _ingest_interfaces(self, session: Session, interfaces: list[InterfaceModel]) -> int:
        query = """
        UNWIND $interfaces AS i
        MERGE (iface:Interface {device_hostname: i.device_hostname, name: i.name})
        SET iface.admin_status = i.admin_status,
            iface.oper_status = i.oper_status,
            iface.speed = i.speed,
            iface.mtu = i.mtu,
            iface.description = i.description,
            iface.mac_address = i.mac_address,
            iface.schema_version = $schema_version
        WITH iface, i
        MATCH (dev:Device {hostname: i.device_hostname})
        MERGE (dev)-[:HAS_INTERFACE]->(iface)
        """
        params = [
            {
                "device_hostname": i.device_hostname,
                "name": i.name,
                "admin_status": i.admin_status,
                "oper_status": i.oper_status,
                "speed": i.speed,
                "mtu": i.mtu,
                "description": i.description,
                "mac_address": i.mac_address,
            }
            for i in interfaces
        ]
        session.run(query, interfaces=params, schema_version=1)
        return len(interfaces)

    def _ingest_ip_addresses(self, session: Session, ip_addresses: list[IPAddressModel]) -> int:
        query = """
        UNWIND $ips AS ip
        MERGE (addr:IPAddress {address: ip.address, vrf: coalesce(ip.vrf, 'global')})
        SET addr.prefix_length = ip.prefix_length,
            addr.version = ip.version,
            addr.vrf = coalesce(ip.vrf, 'global'),
            addr.interface_name = ip.interface_name,
            addr.device_hostname = ip.device_hostname,
            addr.schema_version = $schema_version
        WITH addr, ip
        WHERE ip.device_hostname IS NOT NULL AND ip.interface_name IS NOT NULL
        MATCH (iface:Interface {device_hostname: ip.device_hostname, name: ip.interface_name})
        MERGE (iface)-[:HAS_IP]->(addr)
        """
        params = [
            {
                "address": ip.address,
                "prefix_length": ip.prefix_length,
                "version": ip.version,
                "interface_name": ip.interface_name,
                "device_hostname": ip.device_hostname,
                "vrf": ip.vrf,
            }
            for ip in ip_addresses
        ]
        session.run(query, ips=params, schema_version=1)
        return len(ip_addresses)

    def _ingest_subnets(
        self, session: Session, subnets: list[SubnetModel], ip_addresses: list[IPAddressModel]
    ) -> int:
        import ipaddress as ipaddr_mod

        query_subnets = """
        UNWIND $subnets AS s
        MERGE (sub:Subnet {network_address: s.network_address, vrf: coalesce(s.vrf, 'global')})
        SET sub.prefix_length = s.prefix_length,
            sub.version = s.version,
            sub.vrf = coalesce(s.vrf, 'global'),
            sub.tenant = s.tenant,
            sub.schema_version = $schema_version
        """
        params = [
            {
                "network_address": s.network_address,
                "prefix_length": s.prefix_length,
                "version": s.version,
                "vrf": s.vrf,
                "tenant": s.tenant,
            }
            for s in subnets
        ]
        session.run(query_subnets, subnets=params, schema_version=1)

        # Pre-compute IP-to-subnet membership (VRF-aware: IP and Subnet must share VRF)
        subnet_networks: dict[tuple[str, str], Any] = {}
        for s in subnets:
            try:
                net = ipaddr_mod.ip_network(s.network_address, strict=False)
                subnet_networks[(s.network_address, s.vrf or "global")] = net
            except ValueError:
                logger.warning("Invalid subnet: %s", s.network_address)

        sorted_subnets = sorted(
            subnet_networks.items(),
            key=lambda x: x[1].prefixlen,
            reverse=True,
        )

        ip_subnet_pairs = []
        for ip in ip_addresses:
            try:
                addr = ipaddr_mod.ip_address(ip.address)
                ip_vrf = ip.vrf or "global"
            except ValueError:
                continue

            for (net_addr, sub_vrf), network in sorted_subnets:
                if sub_vrf == ip_vrf and addr in network:
                    ip_subnet_pairs.append({
                        "ip_address": ip.address,
                        "ip_vrf": ip_vrf,
                        "subnet_address": net_addr,
                    })
                    break

        if ip_subnet_pairs:
            query_rels = """
            UNWIND $pairs AS p
            MATCH (ip:IPAddress {address: p.ip_address, vrf: p.ip_vrf})
            MATCH (sub:Subnet {network_address: p.subnet_address, vrf: p.ip_vrf})
            MERGE (ip)-[:IN_SUBNET]->(sub)
            """
            session.run(query_rels, pairs=ip_subnet_pairs)

        return len(subnets)

    def _ingest_vlans(self, session: Session, vlans: list[VLANModel]) -> int:
        query = """
        UNWIND $vlans AS v
        MERGE (vlan:VLAN {device_hostname: v.device_hostname, vlan_id: v.vlan_id})
        SET vlan.name = v.name,
            vlan.schema_version = $schema_version
        """
        params = [
            {
                "device_hostname": v.device_hostname,
                "vlan_id": v.vlan_id,
                "name": v.name,
            }
            for v in vlans
        ]
        session.run(query, vlans=params, schema_version=1)
        return len(vlans)

    def _ingest_macs(self, session: Session, macs: list[MACModel]) -> int:
        query = """
        UNWIND $macs AS m
        MERGE (mac:MAC {address: m.address})
        SET mac.vendor_oui = m.vendor_oui,
            mac.schema_version = $schema_version
        WITH mac, m
        WHERE m.device_hostname IS NOT NULL AND m.interface_name IS NOT NULL
        MATCH (iface:Interface {device_hostname: m.device_hostname, name: m.interface_name})
        MERGE (mac)-[:LEARNED_ON]->(iface)
        """
        params = [
            {
                "address": m.address,
                "vendor_oui": m.vendor_oui,
                "interface_name": m.interface_name,
                "device_hostname": m.device_hostname,
            }
            for m in macs
        ]
        session.run(query, macs=params, schema_version=1)
        return len(macs)

    def _ingest_endpoints(self, session: Session, endpoints: list[EndpointModel]) -> int:
        query = """
        UNWIND $endpoints AS e
        MERGE (ep:Endpoint {mac_address: e.mac_address, ip_address: e.ip_address})
        SET ep.first_seen = COALESCE(ep.first_seen, e.first_seen),
            ep.last_seen = e.last_seen,
            ep.schema_version = $schema_version
        WITH ep, e
        MATCH (ip:IPAddress {address: e.ip_address})
        MERGE (ep)-[:USES_IP]->(ip)
        WITH ep, e
        MATCH (mac:MAC {address: e.mac_address})
        MERGE (ep)-[:USES_MAC]->(mac)
        """
        params = [
            {
                "mac_address": e.mac_address,
                "ip_address": e.ip_address,
                "first_seen": e.first_seen.isoformat() if e.first_seen else None,
                "last_seen": e.last_seen.isoformat() if e.last_seen else None,
            }
            for e in endpoints
        ]
        session.run(query, endpoints=params, schema_version=1)
        return len(endpoints)

    def _ingest_firewall_rules(self, session: Session, rules: list[FirewallRuleModel]) -> int:
        query = """
        UNWIND $rules AS r
        MERGE (fw:FirewallRule {device_hostname: r.device_hostname, rule_id: r.rule_id})
        SET fw += r
        WITH fw, r
        MATCH (d:Device {hostname: r.device_hostname})
        MERGE (d)-[:HAS_FIREWALL_RULE]->(fw)
        """
        params = [
            {
                "device_hostname": rule.device_hostname,
                "rule_id": rule.rule_id,
                "rule_name": rule.rule_name,
                "rule_order": rule.rule_order,
                "action": rule.action,
                "source_zones": rule.source_zones,
                "destination_zones": rule.destination_zones,
                "source_addresses": rule.source_addresses,
                "destination_addresses": rule.destination_addresses,
                "services": rule.services,
                "protocols": rule.protocols,
                "destination_ports": rule.destination_ports,
                "enabled": rule.enabled,
                "log_enabled": rule.log_enabled,
                "comments": rule.comments,
                "vendor": rule.vendor,
                "collected_at": rule.collected_at.isoformat() if rule.collected_at else None,
            }
            for rule in rules
        ]
        session.run(query, rules=params)
        return len(rules)

    def _ingest_address_objects(self, session: Session, objects: list[AddressObjectModel]) -> int:
        query = """
        UNWIND $objects AS o
        MERGE (ao:AddressObject {device_hostname: o.device_hostname, name: o.name})
        SET ao.type = o.type,
            ao.value = o.value,
            ao.vendor = o.vendor
        WITH ao, o
        MATCH (d:Device {hostname: o.device_hostname})
        MERGE (d)-[:HAS_ADDRESS_OBJECT]->(ao)
        """
        params = [
            {
                "device_hostname": obj.device_hostname,
                "name": obj.name,
                "type": obj.type,
                "value": obj.value,
                "vendor": obj.vendor,
            }
            for obj in objects
        ]
        session.run(query, objects=params)
        return len(objects)

    def _ingest_service_objects(self, session: Session, objects: list[ServiceObjectModel]) -> int:
        query = """
        UNWIND $objects AS o
        MERGE (so:ServiceObject {device_hostname: o.device_hostname, name: o.name})
        SET so.protocol = o.protocol,
            so.dest_ports = o.dest_ports,
            so.vendor = o.vendor
        WITH so, o
        MATCH (d:Device {hostname: o.device_hostname})
        MERGE (d)-[:HAS_SERVICE_OBJECT]->(so)
        """
        params = [
            {
                "device_hostname": obj.device_hostname,
                "name": obj.name,
                "protocol": obj.protocol,
                "dest_ports": obj.dest_ports,
                "vendor": obj.vendor,
            }
            for obj in objects
        ]
        session.run(query, objects=params)
        return len(objects)
