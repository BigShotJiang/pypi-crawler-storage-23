"""Graph Ingestion Module."""
import logging

from network_discovery.graph.provider import GraphProvider
from network_discovery.normalization.models import NetworkFacts

logger = logging.getLogger(__name__)

class GraphIngester:
    """Handles high-level ingestion logic."""

    def __init__(self, provider: GraphProvider):
        self.provider = provider

    def ingest(self, facts: NetworkFacts) -> dict[str, int]:
        """Ingest facts into the configured graph provider."""
        logger.info("Starting ingestion into %s", self.provider.__class__.__name__)
        return self.provider.ingest(facts)
