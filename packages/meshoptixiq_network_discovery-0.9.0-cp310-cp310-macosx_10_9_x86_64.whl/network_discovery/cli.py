"""MeshOptixIQ Network Discovery CLI (meshq)."""
import argparse
import asyncio
import json
import logging
import os
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import network_discovery.parsers.arista_eos
import network_discovery.parsers.aruba_os
import network_discovery.parsers.checkpoint_gaia
import network_discovery.parsers.cisco_asa
import network_discovery.parsers.cisco_ftd

# Import parsers to trigger registration
import network_discovery.parsers.cisco_ios
import network_discovery.parsers.fortinet
import network_discovery.parsers.juniper_junos
import network_discovery.parsers.paloalto_panos  # noqa: F401
from network_discovery.collectors.netmiko_collector import collect_all, collect_device
from network_discovery.graph.provider import GraphProviderFactory
from network_discovery.normalization.models import NetworkFacts
from network_discovery.normalization.normalize import normalize_pipeline
from network_discovery.parsers.registry import parse_raw_output

logger = logging.getLogger(__name__)

# Distinct exit codes for different failure modes
EXIT_OK = 0
EXIT_GENERAL_ERROR = 1
EXIT_LICENSE_ERROR = 2
EXIT_SOURCE_NOT_FOUND = 3
EXIT_COLLECTION_EMPTY = 4
EXIT_INGESTION_FAILED = 5


def setup_logging(verbose: bool = False) -> None:
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )


def resolve_fact_type(vendor: str, command: str) -> str | None:
    """Look up fact_type for a command from the vendor command map."""
    import yaml

    vendors_dir = Path(__file__).parent / "vendors"
    commands_path = vendors_dir / vendor / "commands.yaml"

    if not commands_path.exists():
        if hasattr(sys, '_MEIPASS'):
            vendors_dir = Path(sys._MEIPASS) / "network_discovery" / "vendors"
            commands_path = vendors_dir / vendor / "commands.yaml"

    if not commands_path.exists():
        return None

    with open(commands_path) as f:
        vendor_map = yaml.safe_load(f)

    for entry in vendor_map.get("commands", []):
        if entry["command"] == command:
            return entry["fact_type"]

    return None


def run_collect(inventory_path: str, output_dir: str, workers: int = 10) -> list[Path]:
    """Stage 1: Collect raw CLI output from devices."""
    logger.info("=== STAGE: COLLECT ===")
    raw_dir = str(Path(output_dir) / "raw")
    return collect_all(inventory_path, raw_dir, workers=workers)


def _parse_file(raw_file: Path) -> NetworkFacts:
    """Parse a single raw collection JSON into NetworkFacts.

    Thread-safe — reads one file with no shared mutable state.
    """
    facts = NetworkFacts()

    if raw_file.stat().st_size == 0:
        logger.warning("Skipping empty file %s", raw_file)
        return facts

    try:
        with open(raw_file) as f:
            raw_data = json.load(f)
    except json.JSONDecodeError:
        logger.error("Failed to decode JSON from %s", raw_file)
        return facts

    try:
        device = raw_data["device"]
        vendor = raw_data["vendor"]
        raw_outputs = raw_data["raw_outputs"]
    except KeyError as exc:
        logger.error("Malformed collection JSON in %s — missing key %s", raw_file, exc)
        return facts

    for command, output in raw_outputs.items():
        if output.startswith("ERROR:"):
            logger.warning("Skipping failed command '%s' on %s", command, device)
            continue

        fact_type = resolve_fact_type(vendor, command)
        if not fact_type:
            logger.debug("No fact_type mapping for command '%s'", command)
            continue

        parsed = parse_raw_output(vendor, fact_type, output, device)
        if parsed:
            facts = facts.merge(parsed)

    logger.info("Parsed %s", raw_file.name)
    return facts


def _parse_result(result: dict) -> NetworkFacts:
    """Parse a collect_device result dict directly into NetworkFacts (no disk I/O)."""
    facts = NetworkFacts()
    device = result.get("device", "")
    vendor = result.get("vendor", "")
    raw_outputs = result.get("raw_outputs", {})

    for command, output in raw_outputs.items():
        if output.startswith("ERROR:"):
            logger.warning("Skipping failed command '%s' on %s", command, device)
            continue

        fact_type = resolve_fact_type(vendor, command)
        if not fact_type:
            logger.debug("No fact_type mapping for command '%s'", command)
            continue

        parsed = parse_raw_output(vendor, fact_type, output, device)
        if parsed:
            facts = facts.merge(parsed)

    return facts


def run_parse(raw_files: list[Path]) -> NetworkFacts:
    """Stage 2: Parse raw output files into canonical models."""
    logger.info("=== STAGE: PARSE ===")
    combined = NetworkFacts()
    n_workers = min(4, len(raw_files)) if raw_files else 1

    with ThreadPoolExecutor(max_workers=n_workers) as executor:
        for facts in executor.map(_parse_file, raw_files):
            combined = combined.merge(facts)

    return combined


def _find_raw_files(source_dir: Path) -> list[Path]:
    """Discover JSON collection files in a directory."""
    files = sorted(source_dir.glob("**/*.json"))
    if not files:
        logger.error("No .json collection files found in %s", source_dir)
    return files


def _validate_source(args) -> Path:
    """Validate --source and return the resolved inventory file path."""
    source = Path(args.source)
    if not source.exists():
        logger.error(
            "Source path does not exist: %s\n"
            "  Provide a path to an inventory YAML file or a directory containing one.\n"
            "  Example: meshq ingest --source ./configs/inventory.yaml",
            source,
        )
        sys.exit(EXIT_SOURCE_NOT_FOUND)

    inventory_file = source / "inventory.yaml" if source.is_dir() else source

    if not inventory_file.exists():
        logger.error(
            "Inventory file not found: %s\n"
            "  Expected inventory.yaml inside the source directory.\n"
            "  Example: meshq ingest --source ./configs/",
            inventory_file,
        )
        sys.exit(EXIT_SOURCE_NOT_FOUND)

    return inventory_file


# ---------------------------------------------------------------------------
# Distributed collection helpers
# ---------------------------------------------------------------------------

async def _run_dispatch(inventory_file: str) -> None:
    """Push all devices from inventory onto the Redis collection queue."""
    from network_discovery.api.collect_queue import dispatch_devices
    from network_discovery.collectors.netmiko_collector import load_inventory

    devices = load_inventory(inventory_file)
    count = await dispatch_devices(devices)
    logger.info("Dispatched %d device(s) to collection queue", count)


async def _run_worker(provider, poll_interval: int) -> None:
    """Pop devices from queue, collect, parse, ingest — loop until interrupted."""
    from network_discovery.api.collect_queue import complete_device, pop_device

    logger.info("Worker started (poll_interval=%ds)", poll_interval)
    while True:
        device = await pop_device()
        if device is None:
            await asyncio.sleep(poll_interval)
            continue

        hostname = device.get("hostname", "?")
        try:
            result = collect_device(device)
            facts = _parse_result(result)
            normalized = normalize_pipeline(facts)
            provider.ingest(normalized)
            await complete_device(hostname, success=True)
            logger.info("Worker: ingested %s", hostname)
        except Exception as exc:
            logger.error("Worker: collection failed for %s: %s", hostname, exc)
            await complete_device(hostname, success=False)


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------
def main() -> None:
    parser = argparse.ArgumentParser(description="MeshOptixIQ Network Discovery CLI (meshq)")

    subparsers = parser.add_subparsers(dest="command", help="Command to run")

    # ingest command  — full pipeline: collect → parse → normalize → ingest
    ingest_parser = subparsers.add_parser("ingest", help="Run full ingestion pipeline")
    ingest_parser.add_argument("--source", required=True, help="Path to inventory/configs")
    ingest_parser.add_argument("--output-dir", default="output", help="Output directory")
    ingest_parser.add_argument("--dry-run", action="store_true", help="Skip DB writes")
    ingest_parser.add_argument(
        "--workers", type=int, default=10, metavar="N",
        help="Concurrent SSH collection threads (default: 10)"
    )

    # collect command — stop after netmiko collection
    collect_parser = subparsers.add_parser("collect", help="Collect raw CLI output only")
    collect_parser.add_argument("--source", default=None, help="Path to inventory file")
    collect_parser.add_argument("--output-dir", default="output", help="Output directory")
    collect_parser.add_argument(
        "--workers", type=int, default=10, metavar="N",
        help="Concurrent SSH collection threads (default: 10)"
    )
    # Distributed collection modes
    collect_mode = collect_parser.add_mutually_exclusive_group()
    collect_mode.add_argument(
        "--dispatch", action="store_true",
        help="Push all inventory devices to the Redis queue and exit (requires REDIS_URL)"
    )
    collect_mode.add_argument(
        "--worker", action="store_true",
        help="Run as a queue worker: pop → SSH → ingest → repeat (requires REDIS_URL)"
    )
    collect_parser.add_argument(
        "--poll-interval", type=int, default=5, metavar="N",
        help="Seconds to wait when the queue is empty in --worker mode (default: 5)"
    )

    # parse command — parse existing raw JSON files (skip collection)
    parse_parser = subparsers.add_parser("parse", help="Parse raw collection files only")
    parse_parser.add_argument("--raw-dir", required=True, help="Directory with raw JSON files")
    parse_parser.add_argument("--output", default=None, help="Write normalised facts to file (JSON)")

    # status command — check backend connectivity
    subparsers.add_parser("status", help="Check backend connectivity and configuration")

    # version command
    subparsers.add_parser("version", help="Show version")

    # export command — export inventory in various formats
    export_parser = subparsers.add_parser("export", help="Export graph data in various formats")
    export_parser.add_argument(
        "--format", required=True, choices=["ansible"],
        help="Export format (currently: ansible)",
    )
    export_parser.add_argument(
        "--output", default=None, metavar="FILE",
        help="Write output to FILE instead of stdout",
    )

    # license command — show plan tier and expiry
    subparsers.add_parser("license", help="Show license status (plan, expiry, days remaining)")

    # login command — store a Personal Access Token
    login_parser = subparsers.add_parser(
        "login", help="Store a Personal Access Token for CLI authentication"
    )
    login_parser.add_argument(
        "--token", default=None,
        help="PAT to store (prompted if omitted)",
    )

    # logout command — remove stored token
    subparsers.add_parser("logout", help="Remove stored CLI token")

    # sync command — synchronise with external systems
    sync_parser = subparsers.add_parser("sync", help="Synchronise with external systems")
    sync_parser.add_argument(
        "--target", required=True, choices=["netbox"],
        help="Sync target system",
    )
    sync_parser.add_argument(
        "--direction", default=None, choices=["push", "pull", "both"],
        help="Sync direction (default: NETBOX_SYNC_DIRECTION env var or 'both')",
    )
    sync_parser.add_argument(
        "--dry-run", action="store_true",
        help="Log intended actions without making any changes",
    )

    parser.add_argument("-v", "--verbose", action="store_true", help="Enable debug logging")

    args = parser.parse_args()
    setup_logging(args.verbose)

    if not args.command:
        parser.print_help()
        sys.exit(EXIT_GENERAL_ERROR)

    # --- login / logout are handled before any API or license checks ---
    if args.command == "login":
        _cmd_login(args)
        return

    if args.command == "logout":
        _cmd_logout()
        return

    # --- License check ---
    demo_mode = bool(os.environ.get("MESHOPTIXIQ_DEMO_MODE"))

    if args.command not in ("version", "status") and not demo_mode:
        from network_discovery.local_api_client import get_license_status
        try:
            _license_info = get_license_status()
            _plan = _license_info.get("plan", "community")
            if _license_info.get("demo_mode"):
                demo_mode = True
        except RuntimeError as exc:
            logger.error(str(exc))
            sys.exit(EXIT_LICENSE_ERROR)
    else:
        _plan = "community"
    # -----------------------

    # --- User auth check (PAT) ---
    # Verify the stored token is still valid before running any command.
    # Skipped for version/status and in demo mode (no auth required there).
    if not demo_mode and args.command not in ("version", "status"):
        from network_discovery.local_api_client import get_user_context
        try:
            ctx = get_user_context()
            if ctx:
                logger.debug(
                    "Authenticated as %s (role: %s)",
                    ctx.get("sub"), (ctx.get("roles") or ["?"])[0],
                )
        except RuntimeError as exc:
            logger.error(str(exc))
            sys.exit(EXIT_LICENSE_ERROR)
    # ----------------------------

    if args.command == "version":
        from network_discovery._version import __version__
        print(f"MeshOptixIQ CLI v{__version__}")
        return

    if args.command == "status":
        _cmd_status()
        return

    if args.command == "collect":
        if args.dispatch:
            # Dispatch mode: push inventory to Redis queue and exit
            if not args.source:
                logger.error("--dispatch requires --source <inventory.yaml>")
                sys.exit(EXIT_GENERAL_ERROR)
            if not os.environ.get("REDIS_URL"):
                logger.error("--dispatch requires REDIS_URL to be set")
                sys.exit(EXIT_GENERAL_ERROR)
            inventory_file = _validate_source(args)
            asyncio.run(_run_dispatch(str(inventory_file)))
            return

        if args.worker:
            # Worker mode: pop from queue, collect, ingest, repeat
            if not os.environ.get("REDIS_URL"):
                logger.error("--worker requires REDIS_URL to be set")
                sys.exit(EXIT_GENERAL_ERROR)
            provider = GraphProviderFactory.get_provider()
            try:
                asyncio.run(_run_worker(provider, args.poll_interval))
            except KeyboardInterrupt:
                logger.info("Worker interrupted — shutting down")
            finally:
                provider.close()
            return

        # Standard (non-distributed) collection
        if not args.source:
            logger.error("--source is required for standard collection mode")
            sys.exit(EXIT_GENERAL_ERROR)
        inventory_file = _validate_source(args)
        raw_files = run_collect(str(inventory_file), args.output_dir, workers=args.workers)
        if not raw_files:
            logger.error("No data collected from any device.")
            sys.exit(EXIT_COLLECTION_EMPTY)
        logger.info("Collection complete. %d file(s) written.", len(raw_files))
        for f in raw_files:
            logger.info("  %s", f)
        return

    if args.command == "parse":
        raw_dir = Path(args.raw_dir)
        if not raw_dir.is_dir():
            logger.error("--raw-dir is not a directory: %s", raw_dir)
            sys.exit(EXIT_SOURCE_NOT_FOUND)

        raw_files = _find_raw_files(raw_dir)
        if not raw_files:
            sys.exit(EXIT_COLLECTION_EMPTY)

        facts = run_parse(raw_files)
        normalized = normalize_pipeline(facts)

        output_json = normalized.model_dump_json(indent=2, exclude_none=True)
        if args.output:
            out_path = Path(args.output)
            out_path.write_text(output_json)
            logger.info("Normalised facts written to %s", out_path)
        else:
            print(output_json)
        return

    if args.command == "ingest":
        inventory_file = _validate_source(args)

        raw_files = run_collect(str(inventory_file), args.output_dir, workers=args.workers)
        if not raw_files:
            logger.error(
                "No data collected from any device. "
                "Check connectivity and credentials in the inventory file."
            )
            sys.exit(EXIT_COLLECTION_EMPTY)

        facts = run_parse(raw_files)
        normalized = normalize_pipeline(facts)

        if not args.dry_run:
            from network_discovery.local_api_client import post_cli_ingest
            try:
                counts = post_cli_ingest(normalized.model_dump_json(exclude_none=True))
                logger.info("Ingestion complete: %s", counts)
            except RuntimeError as exc:
                logger.error("Ingestion failed: %s", exc)
                sys.exit(EXIT_INGESTION_FAILED)
        else:
            logger.info("Dry run complete. Facts: %s", normalized.model_dump_json(exclude_none=True))

    if args.command == "license":
        _cmd_license()
        return

    if args.command == "export":
        _cmd_export(args)

    if args.command == "sync":
        _cmd_sync(args)


def _cmd_export(args) -> None:
    """Export graph data via the local API (/cli/export)."""
    from network_discovery.local_api_client import get_cli_export
    try:
        output = get_cli_export(fmt=args.format)
    except RuntimeError as exc:
        logger.error("Export failed: %s", exc)
        sys.exit(EXIT_GENERAL_ERROR)

    if args.output:
        out_path = Path(args.output)
        out_path.write_text(output)
        logger.info("%s inventory written to %s", args.format.title(), out_path)
    else:
        print(output)


def _cmd_sync(args) -> None:
    """Synchronise the graph with an external system via the local API (/cli/sync)."""
    from network_discovery.local_api_client import post_cli_sync
    try:
        result = post_cli_sync(
            target=args.target,
            direction=args.direction,
            dry_run=args.dry_run,
        )
        logger.info("Sync complete: %s", result)
    except RuntimeError as exc:
        logger.error("Sync failed: %s", exc)
        sys.exit(EXIT_GENERAL_ERROR)


def _cmd_login(args) -> None:
    """Store a Personal Access Token for CLI authentication."""
    from network_discovery.local_api_client import (
        delete_cli_token,
        get_user_context,
        save_cli_token,
    )
    token = args.token
    if not token:
        try:
            token = input("Enter your MeshOptixIQ Personal Access Token: ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            sys.exit(EXIT_GENERAL_ERROR)
    if not token:
        logger.error("No token provided.")
        sys.exit(EXIT_GENERAL_ERROR)

    save_cli_token(token)
    try:
        ctx = get_user_context()
        if ctx:
            role = (ctx.get("roles") or ["?"])[0]
            expires = ctx.get("expires_at", "")
            sub = ctx.get("sub", "?")
            print(f"Logged in as {sub} (role: {role}{', expires: ' + expires if expires else ''})")
            print("Token saved to ~/.meshoptixiq/credentials")
    except RuntimeError as exc:
        delete_cli_token()
        logger.error("Token validation failed: %s", exc)
        sys.exit(EXIT_GENERAL_ERROR)


def _cmd_logout() -> None:
    """Remove the stored CLI token."""
    from network_discovery.local_api_client import delete_cli_token
    delete_cli_token()
    print("Logged out.")


def _cmd_license() -> None:
    """Print license plan, expiry, and features."""
    api_url = os.environ.get("MESHOPTIXIQ_API_URL", "http://localhost:8000")

    if os.environ.get("MESHOPTIXIQ_DEMO_MODE"):
        print("Mode:    demo (no license required)")
        print("Plan:    community (all features unlocked in demo)")
        print(f"API Server: {api_url}")
        return

    from network_discovery.local_api_client import get_license_status
    try:
        info = get_license_status()
    except RuntimeError as exc:
        print(f"License error: {exc}", file=sys.stderr)
        sys.exit(EXIT_LICENSE_ERROR)

    plan = info.get("plan", "community")
    expiry = info.get("expires")
    days_remaining = info.get("days_remaining")

    from network_discovery.licensing.gates import get_features as _gf
    features = _gf(plan)

    # ── Identity ───────────────────────────────────────────────────────────────
    print(f"Plan:    {plan}")
    if expiry:
        if days_remaining is not None:
            if days_remaining > 30:
                status = "OK"
            elif days_remaining >= 0:
                status = f"EXPIRING SOON ({days_remaining} day(s))"
            else:
                status = f"EXPIRED {abs(days_remaining)} day(s) ago"
            print(f"Expires: {expiry}  [{status}]")
        else:
            print(f"Expires: {expiry}")
    else:
        print("Expires: (unknown)")

    print("Status:  OK")
    print(f"API Server: {api_url}")

    # ── Feature flags ──────────────────────────────────────────────────────────
    if features:
        print()
        print("Features:")
        _limit_keys = {"max_devices", "max_network_devices"}

        def _bool(v):
            if isinstance(v, bool):
                return v
            return str(v).lower() == "true"

        # Numeric limits first
        for key in sorted(k for k in features if k in _limit_keys):
            val = features[key]
            display = "unlimited" if val in (-1, "-1") else str(val)
            print(f"  {key.replace('_', ' ').title():<30} {display}")

        # Boolean flags
        for key in sorted(k for k in features if k not in _limit_keys):
            mark = "yes" if _bool(features[key]) else "no"
            print(f"  {key.replace('_', ' ').title():<30} {mark}")


def _cmd_status() -> None:
    """Check backend connectivity and report configuration."""
    backend = os.environ.get("GRAPH_BACKEND", "neo4j").lower()
    print(f"Backend:      {backend}")

    try:
        provider = GraphProviderFactory.get_provider()
    except Exception as exc:
        print(f"Connection:   FAILED — {exc}")
        sys.exit(EXIT_GENERAL_ERROR)

    try:
        from network_discovery.graph.neo4j_provider import Neo4jProvider

        if isinstance(provider, Neo4jProvider):
            provider.execute_query("_health", "RETURN 1 AS ok", {})
        else:
            provider.execute_query("_health", "SELECT 1 AS ok", {})
        print("Connection:   OK")
    except Exception as exc:
        print(f"Connection:   FAILED — {exc}")
        sys.exit(EXIT_GENERAL_ERROR)
    finally:
        provider.close()

    # Also report local API reachability
    from network_discovery.local_api_client import get_license_status
    try:
        info = get_license_status()
        print(f"API Server:   OK  (plan={info['plan']})")
    except RuntimeError:
        print("API Server:   UNREACHABLE")


if __name__ == "__main__":
    main()
