"""Snapshot ring buffer — dual-mode: in-process deque or shared Redis Sorted Set.

Standalone (REDIS_URL unset):
  Stores up to 288 snapshots in a per-process deque.  Data is lost on restart.

Clustered (REDIS_URL set):
  Snapshots are stored in the Redis Sorted Set ``meshq:snapshots`` (score =
  unix-ms timestamp, member = JSON bytes).  All instances share the same 288-
  item window.  Each ``record_snapshot_async`` call also publishes to the
  ``meshq:events`` Pub/Sub channel so SSE subscribers receive the update
  immediately.
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from collections import deque
from datetime import datetime, timezone
from typing import Any

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Ring buffer (standalone / fallback)
# ---------------------------------------------------------------------------

_MAX_SNAPSHOTS = 288  # 24 h x 12 samples/h
_snapshots: deque[dict[str, Any]] = deque(maxlen=_MAX_SNAPSHOTS)

_REDIS_KEY = "meshq:snapshots"
_REDIS_EVENTS_CHANNEL = "meshq:events"
_REDIS_LOCK_KEY = "meshq:collector_lock"


# ---------------------------------------------------------------------------
# Sync API (standalone fallback — unchanged from single-instance version)
# ---------------------------------------------------------------------------

def record_snapshot(snapshot: dict[str, Any]) -> None:
    """Append a snapshot dict to the in-process ring buffer."""
    _snapshots.append(snapshot)


def get_snapshots(limit: int = _MAX_SNAPSHOTS) -> list[dict[str, Any]]:
    """Return the most recent ``limit`` snapshots (oldest first)."""
    snaps = list(_snapshots)
    if limit < len(snaps):
        snaps = snaps[-limit:]
    return snaps


def clear_snapshots() -> int:
    """Clear all snapshots. Returns the number deleted."""
    count = len(_snapshots)
    _snapshots.clear()
    return count


# ---------------------------------------------------------------------------
# Async API (clustered Redis path)
# ---------------------------------------------------------------------------

async def record_snapshot_async(snapshot: dict[str, Any]) -> None:
    """Store a snapshot in the Redis Sorted Set and fan-out via Pub/Sub.

    Falls back to the in-process deque when Redis is unavailable.
    """
    from network_discovery.api.cluster import get_redis

    r = await get_redis()
    if r is None:
        record_snapshot(snapshot)
        return

    score = time.time() * 1000  # unix-ms as float
    member = json.dumps(snapshot, default=str).encode()
    try:
        pipe = r.pipeline()
        pipe.zadd(_REDIS_KEY, {member: score})
        # Trim to max 288 members — keep the newest ones
        pipe.zremrangebyrank(_REDIS_KEY, 0, -(_MAX_SNAPSHOTS + 1))
        pipe.publish(_REDIS_EVENTS_CHANNEL, member)
        await pipe.execute()
    except Exception as exc:
        logger.warning("Redis record_snapshot_async failed, using local deque: %s", exc)
        record_snapshot(snapshot)


async def get_snapshots_async(limit: int = _MAX_SNAPSHOTS) -> list[dict[str, Any]]:
    """Return the most recent ``limit`` snapshots from Redis (oldest first).

    Falls back to the in-process deque when Redis is unavailable.
    """
    from network_discovery.api.cluster import get_redis

    r = await get_redis()
    if r is None:
        return get_snapshots(limit)

    try:
        raw = await r.zrange(_REDIS_KEY, -limit, -1)
        return [json.loads(m) for m in raw]
    except Exception as exc:
        logger.warning("Redis get_snapshots_async failed, using local deque: %s", exc)
        return get_snapshots(limit)


async def clear_snapshots_async() -> int:
    """Delete all snapshots from Redis. Returns the number deleted.

    Falls back to the in-process deque when Redis is unavailable.
    """
    from network_discovery.api.cluster import get_redis

    r = await get_redis()
    if r is None:
        return clear_snapshots()

    try:
        count = await r.zcard(_REDIS_KEY)
        await r.delete(_REDIS_KEY)
        return count
    except Exception as exc:
        logger.warning("Redis clear_snapshots_async failed, using local deque: %s", exc)
        return clear_snapshots()


# ---------------------------------------------------------------------------
# Background collector task
# ---------------------------------------------------------------------------

_COLLECT_INTERVAL = 300  # seconds (5 min)


def _exec_snapshot_query(provider: Any, query_name: str, params: dict | None = None) -> list[dict]:
    """Run a named query against the provider — works for all backends.

    Resolves the query file from the registry for Neo4j/Postgres backends;
    passes an empty string for the in-memory backend (Python handlers).
    """
    import os
    from pathlib import Path

    import yaml

    params = params or {}
    backend = os.environ.get("GRAPH_BACKEND", "neo4j").lower()

    if backend == "inmemory":
        return provider.execute_query(query_name, "", params)

    registry_path = (
        Path(__file__).resolve().parent.parent / "queries" / "registry.yaml"
    )
    if not registry_path.exists():
        return []

    with open(registry_path) as f:
        registry = yaml.safe_load(f)

    query_def = {q["name"]: q for q in registry.get("queries", [])}.get(query_name)
    if not query_def:
        return []

    impl = query_def.get("implementations", {}).get(backend)
    if not impl:
        return []

    queries_root = Path(__file__).resolve().parent.parent / "queries" / "v1"
    query_path = queries_root / impl
    if not query_path.exists():
        return []

    return provider.execute_query(query_name, query_path.read_text(), params)


async def _collect_once() -> None:
    """Run one collection cycle.

    In clustered mode acquires a distributed lock so only one instance runs
    the DB query per interval.  TTL=290s ensures the lock expires before the
    next cycle even if the holder crashes.
    """
    from network_discovery.api.cluster import get_redis, is_clustered

    if is_clustered():
        r = await get_redis()
        if r is not None:
            acquired = await r.set(_REDIS_LOCK_KEY, b"1", nx=True, ex=290)
            if not acquired:
                logger.debug("Snapshot collector: lock held by another instance, skipping cycle")
                return

    try:
        from network_discovery.api import dependencies as _deps

        provider = _deps._provider
        if provider is None:
            logger.debug("Snapshot collector: provider not yet initialised, skipping")
            return

        summary_rows = _exec_snapshot_query(provider, "summary_stats", {})
        row = summary_rows[0] if summary_rows else {}

        fw_rows: list[dict] = []
        fw_count = 0
        try:
            fw_rows = _exec_snapshot_query(provider, "deny_rules_summary", {})
            fw_count = len(fw_rows)
        except Exception:
            pass

        device_hostnames: list[str] = []
        try:
            dev_rows = _exec_snapshot_query(provider, "all_devices", {})
            device_hostnames = sorted(
                r.get("hostname", "") for r in dev_rows if r.get("hostname")
            )
        except Exception:
            pass

        firewall_rule_ids: list[str] = []
        try:
            firewall_rule_ids = sorted(
                f"{r.get('device_hostname','')}/{r.get('rule_name') or ''}"
                for r in fw_rows
                if r.get("device_hostname")
            )
        except Exception:
            pass

        snapshot = {
            "timestamp":           datetime.now(timezone.utc).isoformat(),
            "device_count":        row.get("device_count", 0),
            "interface_count":     row.get("interface_count", 0),
            "endpoint_count":      row.get("endpoint_count", 0),
            "vlan_count":          row.get("vlan_count", 0),
            "firewall_rule_count": fw_count,
            "device_hostnames":    device_hostnames,
            "firewall_rule_ids":   firewall_rule_ids,
        }
        await record_snapshot_async(snapshot)
        logger.debug("Snapshot recorded: %s devices", snapshot["device_count"])
    except Exception as exc:
        logger.warning("Snapshot collection failed: %s", exc)


async def _snapshot_collector() -> None:
    """Collect summary stats every 5 min.

    Runs as an asyncio background task inside the FastAPI lifespan.
    Logs on failure but never raises.
    """
    while True:
        await asyncio.sleep(_COLLECT_INTERVAL)
        await _collect_once()
