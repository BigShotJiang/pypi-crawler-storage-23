"""Distributed device collection queue backed by Redis.

When Redis is unavailable, all operations are silent no-ops — the single-
instance ``meshq collect`` behaviour is unchanged.

Redis keys
----------
``meshq:collect_queue``       List  — pending device JSON blobs (LPOP / RPUSH)
``meshq:collect_processing``  Hash  — hostname → {"device": <json>, "started_at": <float>}
``meshq:collect_results``     Sorted Set — hostname → unix-ms timestamp of last success
``meshq:collect_lock``        String (SET NX, TTL=60s) — dispatch guard (one dispatcher)
"""

from __future__ import annotations

import json
import logging
import time
from typing import Any

from network_discovery.api.cluster import get_redis

logger = logging.getLogger(__name__)

_QUEUE_KEY       = "meshq:collect_queue"
_PROCESSING_KEY  = "meshq:collect_processing"
_RESULTS_KEY     = "meshq:collect_results"
_DISPATCH_LOCK   = "meshq:collect_lock"
_LOCK_TTL        = 60   # seconds


async def dispatch_devices(devices: list[dict[str, Any]]) -> int:
    """Push *devices* to the collection queue.

    Acquires a short-lived dispatch lock (NX, TTL=60 s) so only one
    dispatcher runs at a time.  Devices already in-flight (present in the
    processing hash) are skipped to avoid duplicate polling.

    Returns the number of devices actually enqueued.
    """
    r = await get_redis()
    if r is None:
        logger.debug("dispatch_devices: Redis unavailable — no-op")
        return 0

    # Try to acquire dispatch lock
    acquired = await r.set(_DISPATCH_LOCK, "1", nx=True, ex=_LOCK_TTL)
    if not acquired:
        logger.info("dispatch_devices: another dispatcher holds the lock — skipping")
        return 0

    try:
        # Find hostnames already in-flight
        in_flight = set(await r.hkeys(_PROCESSING_KEY))
        if in_flight:
            # Redis returns bytes when decode_responses=False
            in_flight = {
                h.decode() if isinstance(h, bytes) else h for h in in_flight
            }

        count = 0
        for device in devices:
            hostname = device.get("hostname", "")
            if hostname in in_flight:
                logger.debug("dispatch_devices: skipping in-flight device %s", hostname)
                continue
            await r.rpush(_QUEUE_KEY, json.dumps(device))
            count += 1

        logger.info("dispatch_devices: enqueued %d device(s)", count)
        return count
    finally:
        await r.delete(_DISPATCH_LOCK)


async def pop_device() -> dict[str, Any] | None:
    """Atomically pop one device from the queue and mark it in-flight.

    Returns the device dict, or ``None`` if the queue is empty.
    """
    r = await get_redis()
    if r is None:
        return None

    raw = await r.lpop(_QUEUE_KEY)
    if raw is None:
        return None

    device_json = raw.decode() if isinstance(raw, bytes) else raw
    device = json.loads(device_json)
    hostname = device.get("hostname", "")

    entry = json.dumps({"device": device_json, "started_at": time.time()})
    await r.hset(_PROCESSING_KEY, hostname, entry)

    return device


async def complete_device(hostname: str, success: bool) -> None:
    """Mark *hostname* as no longer in-flight.

    On success the hostname is recorded in the results sorted set with the
    current timestamp (unix milliseconds).
    """
    r = await get_redis()
    if r is None:
        return

    await r.hdel(_PROCESSING_KEY, hostname)
    if success:
        await r.zadd(_RESULTS_KEY, {hostname: time.time() * 1000})


async def recover_stale(max_age_seconds: int = 900) -> int:
    """Re-queue devices stuck in processing longer than *max_age_seconds*.

    Returns the number of devices re-queued.
    """
    r = await get_redis()
    if r is None:
        return 0

    now = time.time()
    count = 0

    raw_entries: dict = await r.hgetall(_PROCESSING_KEY)
    for raw_hostname, raw_entry in raw_entries.items():
        hostname = raw_hostname.decode() if isinstance(raw_hostname, bytes) else raw_hostname
        entry_str = raw_entry.decode() if isinstance(raw_entry, bytes) else raw_entry
        try:
            entry = json.loads(entry_str)
        except (json.JSONDecodeError, ValueError):
            continue

        started_at = entry.get("started_at", now)
        if now - started_at > max_age_seconds:
            device_json = entry.get("device")
            if device_json:
                await r.rpush(_QUEUE_KEY, device_json)
            await r.hdel(_PROCESSING_KEY, hostname)
            count += 1
            logger.info("recover_stale: re-queued stale device %s", hostname)

    return count


async def queue_status() -> dict[str, Any]:
    """Return current queue depths and recent results.

    Returns a dict with keys ``pending``, ``processing``, ``last_results``.
    """
    r = await get_redis()
    if r is None:
        return {"pending": 0, "processing": 0, "last_results": {}, "cluster_mode": False}

    pending = await r.llen(_QUEUE_KEY)
    processing = await r.hlen(_PROCESSING_KEY)

    # Latest success timestamps per host (top 50, most recent first)
    raw_results = await r.zrevrangebyscore(
        _RESULTS_KEY, "+inf", "-inf", withscores=True, start=0, num=50
    )
    last_results: dict[str, float] = {}
    for raw_host, score in raw_results:
        host = raw_host.decode() if isinstance(raw_host, bytes) else raw_host
        last_results[host] = score

    return {
        "pending": pending,
        "processing": processing,
        "last_results": last_results,
        "cluster_mode": True,
    }
