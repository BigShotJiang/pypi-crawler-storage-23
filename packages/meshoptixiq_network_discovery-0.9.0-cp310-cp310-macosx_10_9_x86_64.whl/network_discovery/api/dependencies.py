"""Singleton GraphProvider dependency for the FastAPI application.

A single provider instance is created at startup and shared across all
requests, avoiding the overhead and connection leaks of per-request
instantiation.  The provider is closed cleanly via the FastAPI lifespan
handler (see ``main.py``).
"""

import logging
import os
from collections.abc import Generator

from network_discovery.graph.provider import GraphProvider

logger = logging.getLogger(__name__)

_provider: GraphProvider | None = None


def init_provider() -> GraphProvider:
    """Create the singleton GraphProvider (called once at startup)."""
    global _provider
    backend = os.environ.get("GRAPH_BACKEND", "neo4j").lower()

    if backend == "postgres":
        from network_discovery.graph.postgres_provider import PostgresProvider

        _provider = PostgresProvider()
        logger.info("Initialised PostgresProvider singleton")
    elif backend == "inmemory":
        from network_discovery.graph.inmemory_provider import InMemoryGraphProvider

        _provider = InMemoryGraphProvider()
        logger.info("Initialised InMemoryGraphProvider singleton")
    else:
        from network_discovery.graph.neo4j_provider import Neo4jProvider

        _provider = Neo4jProvider()
        logger.info("Initialised Neo4jProvider singleton")

    return _provider


def close_provider() -> None:
    """Close the singleton provider (called once at shutdown)."""
    global _provider
    if _provider is not None:
        logger.info("Closing %s singleton", _provider.__class__.__name__)
        _provider.close()
        _provider = None


def get_db_driver() -> Generator[GraphProvider, None, None]:
    """FastAPI dependency — yields the shared provider instance."""
    if _provider is None:
        raise RuntimeError(
            "GraphProvider not initialised. "
            "Ensure the application lifespan handler has run."
        )
    yield _provider
