"""PAT (Personal Access Token) store for MeshOptixIQ.

Tokens are stored as HMAC-SHA256 hashes only — the raw token is shown
once on issuance and never persisted.

Environment variables:
    MESHQ_TOKEN_SALT       HMAC salt (set a strong value in production)
    MESHQ_USER_STORE_FILE  Path for JSON persistence (optional)
"""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
import os
import secrets
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path

logger = logging.getLogger(__name__)

_SALT = os.environ.get("MESHQ_TOKEN_SALT", "meshq-default-salt")
if _SALT == "meshq-default-salt":
    logging.getLogger(__name__).warning(
        "MESHQ_TOKEN_SALT is not set — using insecure default. "
        "Set this env var in production."
    )


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class UserContext:
    """Authenticated user identity — attached to request.state.user."""

    sub: str
    email: str | None = None
    roles: list[str] = field(default_factory=list)
    groups: list[str] = field(default_factory=list)
    auth_method: str = "pat"    # "pat" | "api_key" | "oidc"
    scopes: list[str] = field(default_factory=list)
    token_id: str | None = None


@dataclass
class TokenRecord:
    token_id: str           # first 12 chars of raw token (display ID)
    token_hash: str         # HMAC-SHA256 — raw token never stored
    username: str
    role: str
    scopes: list[str]
    expires_at: str         # ISO datetime
    created_at: str
    last_used_at: str | None = None
    last_used_ip: str | None = None
    description: str = ""
    revoked: bool = False


# ---------------------------------------------------------------------------
# Module-level state
# ---------------------------------------------------------------------------

_tokens: dict[str, TokenRecord] = {}   # token_hash → TokenRecord
_users: dict[str, str] = {}            # username → role

# Default scopes per role
_DEFAULT_SCOPES: dict[str, list[str]] = {
    "admin":     ["*"],
    "architect": ["cli:ingest", "cli:export", "cli:sync", "topology_*", "endpoints_*"],
    "network":   ["cli:ingest", "cli:export", "topology_*", "endpoints_*"],
    "security":  ["cli:export", "topology_*", "firewall_*"],
    "analyst":   ["cli:export", "topology_*"],
    "helpdesk":  ["cli:export"],
}


# ---------------------------------------------------------------------------
# Token operations
# ---------------------------------------------------------------------------

def _hash_token(raw: str) -> str:
    return hmac.new(_SALT.encode(), raw.encode(), hashlib.sha256).hexdigest()


def issue_token(
    username: str,
    role: str,
    description: str = "",
    scopes: list[str] | None = None,
    expires_in_days: int = 30,
) -> str:
    """Generate raw token, store only its hash. Returns raw token — shown once."""
    raw = f"mq_live_{secrets.token_hex(24)}"
    token_id = str(uuid.uuid4())
    token_hash = _hash_token(raw)
    expires = (datetime.now(timezone.utc) + timedelta(days=expires_in_days)).isoformat()
    record = TokenRecord(
        token_id=token_id,
        token_hash=token_hash,
        username=username,
        role=role,
        scopes=scopes if scopes is not None else _DEFAULT_SCOPES.get(role, []),
        expires_at=expires,
        created_at=datetime.now(timezone.utc).isoformat(),
        description=description,
    )
    _tokens[token_hash] = record
    _save()
    return raw   # caller shows this once; never stored again


def lookup_token(raw: str) -> TokenRecord | None:
    return _tokens.get(_hash_token(raw))


def revoke_token(token_id: str) -> bool:
    """Revoke by token_id (first 12 chars). Returns False if not found."""
    for record in _tokens.values():
        if record.token_id == token_id:
            record.revoked = True
            _save()
            return True
    return False


def revoke_user_tokens(username: str) -> int:
    count = 0
    for record in _tokens.values():
        if record.username == username and not record.revoked:
            record.revoked = True
            count += 1
    if count:
        _save()
    return count


def create_user(username: str, role: str) -> None:
    _users[username] = role
    _save()


def delete_user(username: str) -> None:
    revoke_user_tokens(username)
    _users.pop(username, None)
    _save()


def update_user_role(username: str, role: str) -> bool:
    if username not in _users:
        return False
    _users[username] = role
    _save()
    return True


def list_users() -> list[dict]:
    return [
        {
            "username": u,
            "role": r,
            "token_count": sum(
                1 for t in _tokens.values()
                if t.username == u and not t.revoked
            ),
        }
        for u, r in _users.items()
    ]


def list_tokens(username: str | None = None) -> list[dict]:
    records = [
        r for r in _tokens.values()
        if username is None or r.username == username
    ]
    return [
        {
            "token_id":     r.token_id,
            "username":     r.username,
            "role":         r.role,
            "scopes":       r.scopes,
            "description":  r.description,
            "created_at":   r.created_at,
            "expires_at":   r.expires_at,
            "last_used_at": r.last_used_at,
            "last_used_ip": r.last_used_ip,
            "revoked":      r.revoked,
        }
        for r in records
    ]


def update_token_last_used(token_hash: str, ip: str | None) -> None:
    if token_hash in _tokens:
        _tokens[token_hash].last_used_at = datetime.now(timezone.utc).isoformat()
        _tokens[token_hash].last_used_ip = ip


# ---------------------------------------------------------------------------
# Persistence
# ---------------------------------------------------------------------------

def _store_path() -> Path | None:
    p = os.environ.get("MESHQ_USER_STORE_FILE")
    return Path(p) if p else None


def _load() -> None:
    """Load state from MESHQ_USER_STORE_FILE (no-op if not set or missing)."""
    path = _store_path()
    if not path or not path.exists():
        return
    try:
        data = json.loads(path.read_text())
        _users.clear()
        _users.update(data.get("users", {}))
        _tokens.clear()
        for rec in data.get("tokens", []):
            tr = TokenRecord(**rec)
            _tokens[tr.token_hash] = tr
        logger.info(
            "Loaded %d user(s) and %d token(s) from %s",
            len(_users), len(_tokens), path,
        )
    except Exception as exc:
        logger.error("Failed to load user store from %s: %s", path, exc)


def _save() -> None:
    """Persist state to MESHQ_USER_STORE_FILE (no-op if not set)."""
    path = _store_path()
    if not path:
        return
    try:
        data = {
            "users":  dict(_users),
            "tokens": [asdict(r) for r in _tokens.values()],
        }
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.parent / f".{path.name}.tmp"
        tmp.write_text(json.dumps(data, indent=2))
        os.chmod(tmp, 0o600)
        tmp.rename(path)
    except Exception as exc:
        logger.error("Failed to save user store to %s: %s", path, exc)
