"""MeshOptixIQ Query API — FastAPI application."""

import asyncio
import logging
import os
import time
import uuid
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import Depends, FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.util import get_remote_address

from network_discovery._version import __version__
from network_discovery.api.auth import require_api_key
from network_discovery.api.cluster import close_redis, get_redis, is_clustered, limiter_storage_uri
from network_discovery.api.dependencies import (
    close_provider,
    get_db_driver,
    init_provider,
)
from network_discovery.api.routes import inventory, queries
from network_discovery.api.routes.admin import router as admin_router
from network_discovery.api.routes.auth import router as auth_router
from network_discovery.api.routes.cli import router as cli_router
from network_discovery.api.routes.collect import router as collect_router
from network_discovery.api.routes.demo import router as demo_router
from network_discovery.api.routes.events import router as events_router
from network_discovery.api.routes.history import router as history_router
from network_discovery.api.routes.metrics import router as metrics_router
from network_discovery.api.routes.users import admin_router as users_admin_router
from network_discovery.api.routes.users import auth_router as users_auth_router
from network_discovery.api.routes.whatif import router as whatif_router
from network_discovery.api.snapshot_store import _snapshot_collector

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Startup configuration validation — hard failure if API_KEY is missing
# ---------------------------------------------------------------------------
_DEMO_MODE: bool = False


def _validate_config() -> None:
    """Abort startup if required security configuration is missing."""
    global _DEMO_MODE
    _DEMO_MODE = bool(os.environ.get("MESHOPTIXIQ_DEMO_MODE"))

    if _DEMO_MODE:
        # Demo mode: set sensible defaults and skip all mandatory checks
        os.environ.setdefault("API_KEY", "demo")
        os.environ["GRAPH_BACKEND"] = "inmemory"
        logger.info("Demo mode active — pre-seeded synthetic network (no DB required)")
        return

    auth_mode = os.environ.get("AUTH_MODE", "api_key").lower()

    if auth_mode in ("api_key", "both"):
        api_key = os.environ.get("API_KEY")
        if not api_key:
            logger.warning(
                "API_KEY is not set — running in open-access mode (community plan). "
                "Set API_KEY to require authentication."
            )

    # Entra ID: auto-configure OIDC from ENTRA_* vars (must run before OIDC_DISCOVERY_URL check)
    if os.environ.get("ENTRA_TENANT_ID") or os.environ.get("ENTRA_CLIENT_ID"):
        try:
            from network_discovery.enterprise.auth.entra import configure_entra_oidc
            configure_entra_oidc()
        except ImportError:
            pass

    if auth_mode in ("oidc", "both"):
        if not os.environ.get("OIDC_DISCOVERY_URL"):
            raise RuntimeError(
                f"AUTH_MODE={auth_mode} requires OIDC_DISCOVERY_URL to be set."
            )
        if not os.environ.get("OIDC_CLIENT_ID"):
            raise RuntimeError(
                f"AUTH_MODE={auth_mode} requires OIDC_CLIENT_ID to be set."
            )

    if auth_mode not in ("api_key", "oidc", "both"):
        raise RuntimeError(
            f"AUTH_MODE='{auth_mode}' is not recognised. Must be 'api_key', 'oidc', or 'both'."
        )

    backend = os.environ.get("GRAPH_BACKEND", "neo4j").lower()
    if backend not in ("neo4j", "postgres", "inmemory"):
        raise RuntimeError(
            f"GRAPH_BACKEND='{backend}' is not recognised. Must be 'neo4j', 'postgres', or 'inmemory'."
        )

    from network_discovery.api.licensing import verify_license
    verify_license()


# ---------------------------------------------------------------------------
# Rate limiter — shared across instances when Redis is available
# ---------------------------------------------------------------------------
limiter = Limiter(
    key_func=get_remote_address,
    storage_uri=limiter_storage_uri(),
    in_memory_fallback_enabled=True,  # degrade gracefully if Redis drops
)


# ---------------------------------------------------------------------------
# RBAC reload listener — receives cross-instance cache-clear signals
# ---------------------------------------------------------------------------
async def _rbac_reload_listener() -> None:
    """Subscribe to the Redis RBAC reload channel and clear local cache on signal."""
    while True:
        try:
            r = await get_redis()
            if r is None:
                await asyncio.sleep(60)
                continue
            async with r.pubsub() as ps:
                await ps.subscribe("meshq:rbac_reload")
                async for msg in ps.listen():
                    if msg["type"] == "message":
                        try:
                            from network_discovery.enterprise.auth.rbac import _reset_policy_cache
                            _reset_policy_cache()
                            logger.info("RBAC cache cleared via pub/sub")
                        except ImportError:
                            pass
        except Exception as exc:
            logger.warning("rbac_reload_listener: %s — retrying in 5 s", exc)
            await asyncio.sleep(5)


# ---------------------------------------------------------------------------
# Lifespan — startup / shutdown
# ---------------------------------------------------------------------------
@asynccontextmanager
async def lifespan(app: FastAPI):
    """Initialise shared resources on startup; tear them down on shutdown."""
    _validate_config()
    logger.info("Starting MeshOptixIQ Query API")

    # Load persisted PAT/user store (no-op if MESHQ_USER_STORE_FILE is not set)
    from network_discovery.api import user_store as _user_store
    _user_store._load()

    # Enterprise observability — no-op if enterprise extras not installed
    try:
        from network_discovery.enterprise.observability.tracing import setup_tracing
        setup_tracing(app)
        logger.info("Enterprise observability active")
    except ImportError:
        pass

    # Initialise Redis connection pool (no-op when REDIS_URL is not set)
    await get_redis()
    if is_clustered():
        logger.info("Cluster mode active — shared state via Redis")

    provider = init_provider()

    # Demo mode — seed synthetic data into the in-memory provider
    if _DEMO_MODE:
        from network_discovery.demo.fixtures import build_demo_fixtures
        provider.ingest(build_demo_fixtures())
        logger.info("Demo fixtures seeded (20 devices, ~300 endpoints, ~60 firewall rules)")

    # Start background snapshot collector (5-min intervals)
    collector_task = asyncio.create_task(_snapshot_collector())

    # Start RBAC reload listener (no-op when Redis is absent)
    rbac_task = asyncio.create_task(_rbac_reload_listener())

    yield

    collector_task.cancel()
    rbac_task.cancel()
    logger.info("Shutting down MeshOptixIQ Query API")
    close_provider()
    await close_redis()


# ---------------------------------------------------------------------------
# Application
# ---------------------------------------------------------------------------
app = FastAPI(
    title="MeshOptixIQ Query API",
    description="Read-only API for executing Network Discovery queries.",
    version=__version__,
    lifespan=lifespan,
)

app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

# ---------------------------------------------------------------------------
# CORS — configurable via CORS_ORIGINS env var (comma-separated)
# Default: deny all origins. Never falls back to wildcard.
# ---------------------------------------------------------------------------
_allowed_origins = os.environ.get("CORS_ORIGINS", "").split(",")
_allowed_origins = [o.strip() for o in _allowed_origins if o.strip()]

if not _allowed_origins:
    logger.info(
        "CORS_ORIGINS is not set — all cross-origin requests will be denied. "
        "Set CORS_ORIGINS to allow browser clients."
    )

app.add_middleware(
    CORSMiddleware,
    allow_origins=_allowed_origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)

# Enterprise audit middleware — no-op if enterprise extras not installed
try:
    from network_discovery.enterprise.audit.logger import AuditMiddleware
    app.add_middleware(AuditMiddleware)
    logger.info("Enterprise audit logging active")
except ImportError:
    pass


# ---------------------------------------------------------------------------
# Security headers middleware
# ---------------------------------------------------------------------------
@app.middleware("http")
async def security_headers_middleware(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Strict-Transport-Security"] = "max-age=63072000; includeSubDomains"
    return response


# ---------------------------------------------------------------------------
# Request logging + request-ID middleware
# ---------------------------------------------------------------------------
@app.middleware("http")
async def request_logging_middleware(request: Request, call_next):
    request_id = request.headers.get("X-Request-ID", str(uuid.uuid4()))
    request.state.request_id = request_id

    start = time.perf_counter()
    response = await call_next(request)
    elapsed_ms = (time.perf_counter() - start) * 1000

    logger.info(
        "%s %s %s %.1fms [%s]",
        request.method,
        request.url.path,
        response.status_code,
        elapsed_ms,
        request_id,
    )
    response.headers["X-Request-ID"] = request_id

    # Prometheus request counter (no-op if prometheus-client not installed)
    from network_discovery.api.routes.metrics import http_requests_total
    if http_requests_total is not None:
        _path = request.url.path
        if _path.startswith("/queries/") and _path.endswith("/execute"):
            _path = "/queries/{name}/execute"
        elif _path.startswith("/queries/") and _path != "/queries/":
            _path = "/queries/{name}"
        http_requests_total.labels(
            method=request.method,
            path=_path,
            status=str(response.status_code),
        ).inc()

    return response


# ---------------------------------------------------------------------------
# Global exception handler — structured JSON errors
# ---------------------------------------------------------------------------
@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    request_id = getattr(request.state, "request_id", "unknown")
    logger.exception("Unhandled error [%s]: %s", request_id, exc)
    return JSONResponse(
        status_code=500,
        content={
            "error": "internal_server_error",
            "detail": "An unexpected error occurred.",
            "request_id": request_id,
        },
    )


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------
app.include_router(
    queries.router,
    prefix="/queries",
    tags=["Queries"],
    dependencies=[Depends(require_api_key)],
)

app.include_router(
    inventory.router,
    prefix="/inventory",
    tags=["Inventory"],
    dependencies=[Depends(require_api_key)],
)

app.include_router(
    auth_router,
    prefix="/auth",
    tags=["Auth"],
    dependencies=[Depends(require_api_key)],
)

app.include_router(
    events_router,
    prefix="/events",
    tags=["Events"],
    dependencies=[Depends(require_api_key)],
)

app.include_router(
    history_router,
    prefix="/history",
    tags=["History"],
    dependencies=[Depends(require_api_key)],
)

app.include_router(
    admin_router,
    prefix="/admin",
    tags=["Admin"],
    dependencies=[Depends(require_api_key)],
)

app.include_router(
    collect_router,
    prefix="/collect",
    tags=["Collect"],
    dependencies=[Depends(require_api_key)],
)

app.include_router(
    whatif_router,
    prefix="/graph",
    tags=["Graph"],
    dependencies=[Depends(require_api_key)],
)

# PAT token management — caller's own tokens (/auth/tokens/me)
app.include_router(
    users_auth_router,
    prefix="/auth",
    tags=["Auth"],
    dependencies=[Depends(require_api_key)],
)

# User + token admin (/admin/users, /admin/tokens)
app.include_router(
    users_admin_router,
    prefix="/admin",
    tags=["Admin"],
    dependencies=[Depends(require_api_key)],
)

# CLI proxy endpoints — double-gated (RBAC → License)
app.include_router(
    cli_router,
    prefix="/cli",
    tags=["CLI"],
    dependencies=[Depends(require_api_key)],
)

# Demo info — no auth required so browsers can call it before connecting
app.include_router(
    demo_router,
    prefix="/demo",
    tags=["Demo"],
)

# Prometheus metrics — no auth required; conventional /metrics path
app.include_router(metrics_router)


# ---------------------------------------------------------------------------
# Health checks
# ---------------------------------------------------------------------------
@app.get("/health", tags=["Health"])
def health_check():
    """Shallow health check — confirms the API process is alive."""
    return {"status": "ok"}


@app.get("/health/redis", tags=["Health"])
async def redis_health():
    """Redis connectivity check — reports cluster mode status."""
    if not is_clustered():
        return {"status": "ok", "cluster_mode": False}
    r = await get_redis()
    if r is None:
        return JSONResponse(
            status_code=503,
            content={"status": "unavailable", "cluster_mode": True, "detail": "Redis unreachable"},
        )
    try:
        await r.ping()
        return {"status": "ok", "cluster_mode": True}
    except Exception as exc:
        logger.warning("Redis health check failed: %s", exc)
        return JSONResponse(
            status_code=503,
            content={"status": "unavailable", "cluster_mode": True, "detail": "Redis ping failed"},
        )


@app.get("/health/license", tags=["Health"])
def license_health(request: Request):
    """License status — plan tier, expiry, and days remaining.

    Unauthenticated by default (for k8s liveness probes and monitoring).
    Set ``MESHQ_PROTECT_HEALTH=true`` to require the X-API-Key header.
    """
    if os.environ.get("MESHQ_PROTECT_HEALTH") == "true":
        from network_discovery.api.auth import _check_static_api_key
        _check_static_api_key(request)
    from network_discovery.api.licensing import get_expiry, get_plan

    if _DEMO_MODE:
        return {"plan": "community", "demo_mode": True}

    plan = get_plan()
    expiry = get_expiry()
    days_remaining: int | None = None
    if expiry:
        from datetime import date
        try:
            days_remaining = (date.fromisoformat(expiry) - date.today()).days
        except (TypeError, ValueError):
            pass

    return {
        "plan":           plan,
        "expires":        expiry,
        "days_remaining": days_remaining,
        "demo_mode":      False,
    }


@app.get("/health/ready", tags=["Health"])
def readiness_check(provider=Depends(get_db_driver)):
    """Deep health check — verifies the graph backend is reachable."""
    from network_discovery.graph.inmemory_provider import InMemoryGraphProvider

    try:
        if isinstance(provider, InMemoryGraphProvider):
            return {"status": "ok", "backend": "inmemory"}
        try:
            from network_discovery.graph.postgres_provider import PostgresProvider
            _has_postgres = True
        except ImportError:
            PostgresProvider = None  # type: ignore[assignment,misc]  # noqa: N806
            _has_postgres = False
        if _has_postgres and isinstance(provider, PostgresProvider):
            # Use pool.check() for a thorough connection pool health check
            provider.pool_check()
            stats = provider.pool_stats()
            return {
                "status": "ok",
                "backend": _backend_name(),
                "pool_available": stats.get("pool_available", 0),
            }
        else:
            provider.execute_query("_health", _health_query(provider), {})
            return {"status": "ok", "backend": _backend_name()}
    except Exception as e:
        logger.warning("Readiness probe failed: %s", e)
        return JSONResponse(
            status_code=503,
            content={
                "status": "unavailable",
                "backend": _backend_name(),
                "detail": "Backend connectivity check failed.",
            },
        )


def _backend_name() -> str:
    return os.environ.get("GRAPH_BACKEND", "neo4j").lower()


def _health_query(provider) -> str:
    """Return a trivial query appropriate for the configured backend."""
    from network_discovery.graph.neo4j_provider import Neo4jProvider

    if isinstance(provider, Neo4jProvider):
        return "RETURN 1 AS ok"
    return "SELECT 1 AS ok"


# ---------------------------------------------------------------------------
# Static UI — served only when UI_DIR points to a built React app
# ---------------------------------------------------------------------------
_UI_DIR = Path(os.environ.get("UI_DIR", "/app/static"))

if _UI_DIR.is_dir():
    _assets_dir = _UI_DIR / "assets"
    if _assets_dir.is_dir():
        app.mount("/assets", StaticFiles(directory=str(_assets_dir)), name="ui-assets")

    @app.get("/", include_in_schema=False)
    async def serve_ui_root():
        """Serve the React SPA root."""
        return FileResponse(str(_UI_DIR / "index.html"))

    @app.get("/{full_path:path}", include_in_schema=False)
    async def serve_ui_spa(full_path: str):
        """Catch-all: return index.html for React Router client-side routes."""
        return FileResponse(str(_UI_DIR / "index.html"))
