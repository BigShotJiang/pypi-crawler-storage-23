"""Structured audit logging for MeshOptixIQ CLI operations.

Emits JSON lines to stdout → Docker/K8s log aggregator.
Hooks into the enterprise SIEM path when AUDIT_LOG_ENABLED is set.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone

from fastapi import Request

_logger = logging.getLogger("meshoptixiq.audit")


def audit(request: Request, action: str, result: str, **extra) -> None:
    """Emit a structured audit log entry.

    Args:
        request: The current FastAPI request (provides user context + IP).
        action:  Operation name, e.g. ``"cli:ingest"``.
        result:  ``"ok"`` | ``"error"`` | ``"denied"``.
        **extra: Additional structured fields (e.g. counts, error message).
    """
    user = getattr(request.state, "user", None)
    entry: dict = {
        "ts":       datetime.now(timezone.utc).isoformat(),
        "user":     user.sub if user else "anonymous",
        "token_id": getattr(user, "token_id", None) if user else None,
        "role":     (user.roles[0] if user.roles else "?") if user else None,
        "ip":       request.client.host if request.client else None,
        "endpoint": str(request.url.path),
        "action":   action,
        "result":   result,
    }
    entry.update(extra)
    _logger.info(json.dumps(entry))
