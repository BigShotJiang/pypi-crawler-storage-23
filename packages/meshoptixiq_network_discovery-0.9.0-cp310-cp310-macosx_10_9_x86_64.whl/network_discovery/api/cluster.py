"""Redis cluster support — optional shared state for horizontal scaling.

When ``REDIS_URL`` is not set the module is a no-op and all callers fall back
to in-process behaviour (unchanged from the single-instance default).

When ``REDIS_URL`` is set:
- A single async Redis connection pool is created on first call to
  ``get_redis()`` and reused for the lifetime of the process.
- ``is_clustered()`` returns ``True`` so callers can activate the Redis path.
- ``limiter_storage_uri()`` returns the ``async+redis://`` URI required by
  ``slowapi`` / ``limits>=5`` for async-safe distributed rate limiting.
"""

from __future__ import annotations

import logging
import os
import re

logger = logging.getLogger(__name__)

_redis_client = None  # module-level singleton


def is_clustered() -> bool:
    """Return True when REDIS_URL is configured."""
    return bool(os.environ.get("REDIS_URL"))


async def get_redis():
    """Return the shared async Redis client, creating it on first call.

    Returns ``None`` if:
    - ``REDIS_URL`` is not set, or
    - the ``redis`` package is not installed.

    A ``ping()`` is issued on creation so a mis-configured URL fails fast
    with a log error rather than silently falling back to in-process state.
    """
    global _redis_client

    if _redis_client is not None:
        return _redis_client

    url = os.environ.get("REDIS_URL")
    if not url:
        return None

    try:
        import redis.asyncio as aioredis  # type: ignore[import-untyped]
    except ImportError:
        logger.warning(
            "REDIS_URL is set but the 'redis' package is not installed. "
            "Install it with: pip install 'meshoptixiq-network-discovery[cluster]'. "
            "Falling back to in-process (single-instance) mode."
        )
        return None

    try:
        client = aioredis.from_url(url, decode_responses=False)
        await client.ping()
        _redis_client = client
        logger.info("Redis cluster mode active: %s", _mask_url(url))
    except Exception as exc:
        logger.error(
            "REDIS_URL is set but Redis is unreachable (%s). "
            "Falling back to in-process (single-instance) mode.",
            exc,
        )
        return None

    return _redis_client


async def close_redis() -> None:
    """Drain the Redis connection pool on shutdown."""
    global _redis_client

    if _redis_client is None:
        return

    try:
        await _redis_client.aclose()
    except Exception as exc:
        logger.warning("Error closing Redis connection: %s", exc)
    finally:
        _redis_client = None


def limiter_storage_uri() -> str:
    """Return the storage URI for slowapi's Limiter.

    Rate limiting uses per-instance in-memory storage regardless of whether
    Redis is configured.  Redis is used for shared distributed state (snapshots,
    PubSub, work queues) but slowapi 0.1.9 / limits>=5 async storage is not
    compatible with the sync strategy assertion in limits.strategies.

    Returns ``"memory://"`` always.
    """
    return "memory://"


def _mask_url(url: str) -> str:
    """Replace password segments in a Redis URL with ***."""
    return re.sub(r"(:)[^:@/]+(@)", r"\1***\2", url)
