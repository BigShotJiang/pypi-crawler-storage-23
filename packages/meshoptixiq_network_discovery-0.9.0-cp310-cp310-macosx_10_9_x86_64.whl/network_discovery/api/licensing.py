"""API-side license enforcement.

Called once at startup (verify_license) to validate the key and cache the plan.
Per-request calls use get_plan() so feature gates use the actual license tier.
"""
from __future__ import annotations

import logging
import os

logger = logging.getLogger(__name__)

_PLAN: str | None = None
_EXPIRY: str | None = None


def verify_license() -> None:
    """Validate the license key at API startup. Raises RuntimeError on failure.

    Demo mode bypasses all checks. The LicenseVerifier's built-in 72-hour
    grace period handles transient server outages without failing startup.
    """
    global _PLAN, _EXPIRY

    if os.environ.get("MESHOPTIXIQ_DEMO_MODE"):
        _PLAN = "community"
        return

    key = os.environ.get("MESHOPTIXIQ_LICENSE_KEY")
    if not key:
        # No license key — run as community plan (free tier, local/open-access mode).
        logger.info(
            "No MESHOPTIXIQ_LICENSE_KEY set — running as community plan. "
            "Upgrade at https://meshoptixiq.com/pricing"
        )
        _PLAN = "community"
        return

    from network_discovery.licensing import (
        LicenseDeviceMismatchError,
        LicenseError,
        LicenseExpiredError,
        LicenseInvalidError,
        LicenseSignatureError,
        LicenseVerifier,
    )

    try:
        verifier = LicenseVerifier()
        verifier.verify()
        _PLAN = verifier.get_plan() or "community"
        _EXPIRY = verifier.get_expiration()

        if _EXPIRY:
            from datetime import date
            try:
                days = (date.fromisoformat(_EXPIRY) - date.today()).days
                if days <= 30:
                    logger.warning(
                        "License expires in %d day(s) (%s). Renew at https://meshoptixiq.com/renew",
                        days, _EXPIRY,
                    )
            except (TypeError, ValueError):
                pass  # malformed date from verifier — non-fatal
    except LicenseExpiredError as e:
        raise RuntimeError(
            f"License expired: {e}. Renew at https://meshoptixiq.com/renew"
        ) from e
    except LicenseDeviceMismatchError as e:
        raise RuntimeError(
            f"Device limit exceeded: {e}. Contact support@meshoptixiq.com"
        ) from e
    except LicenseInvalidError as e:
        raise RuntimeError(
            f"Invalid license key: {e}. Check MESHOPTIXIQ_LICENSE_KEY."
        ) from e
    except LicenseSignatureError as e:
        raise RuntimeError(
            f"License signature error: {e}. Contact support@meshoptixiq.com"
        ) from e
    except LicenseError as e:
        raise RuntimeError(
            f"License error: {e}. Contact support@meshoptixiq.com"
        ) from e


def get_plan() -> str:
    """Return the cached license plan. Falls back to 'community' if called before startup."""
    return _PLAN or "community"


def get_expiry() -> str | None:
    """Return the cached license expiry date (YYYY-MM-DD), or None if unknown."""
    return _EXPIRY


def reset_plan_cache() -> None:
    """Reset cached plan and expiry — for tests only."""
    global _PLAN, _EXPIRY
    _PLAN = None
    _EXPIRY = None
