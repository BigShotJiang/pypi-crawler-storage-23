"""API authentication for the MeshOptixIQ Query API.

Standard mode (``AUTH_MODE=api_key``, the default):
    Accepts either:
    - ``Authorization: Bearer mq_live_<token>`` — Personal Access Token (PAT)
    - ``X-API-Key: <root_key>``                — root API key (legacy/bootstrap)
    - ``?api_key=<root_key>``                  — query-param fallback (SSE)

    PATs are issued via the Admin UI and stored as HMAC-SHA256 hashes in
    ``api/user_store.py``.  The global API_KEY root bypass is deprecated in
    favour of a break-glass admin PAT once the PAT system is mature.

Enterprise OIDC mode (``AUTH_MODE=oidc``):
    Bearer JWT required from a configured OIDC provider.
    X-API-Key header is rejected.
    Requires the enterprise package extras and ``OIDC_DISCOVERY_URL`` + ``OIDC_CLIENT_ID``.

Enterprise combined mode (``AUTH_MODE=both``):
    Accepts either a valid Bearer JWT **or** a valid X-API-Key.
    Recommended for mixed-client environments (browser/SPA + server-to-server).
"""

import logging
import os
from datetime import datetime, timezone

from fastapi import HTTPException, Request, Security
from fastapi.security import APIKeyHeader

logger = logging.getLogger(__name__)

_AUTH_MODE = os.environ.get("AUTH_MODE", "api_key").lower()
_api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)

# ---------------------------------------------------------------------------
# Enterprise OIDC auth — activated when AUTH_MODE=oidc or AUTH_MODE=both
# ---------------------------------------------------------------------------
if _AUTH_MODE in ("oidc", "both"):
    try:
        from network_discovery.enterprise.auth.oidc import require_auth as require_api_key
    except ImportError as exc:
        raise RuntimeError(
            f"AUTH_MODE={_AUTH_MODE} requires the enterprise package extras. "
            "Install with: pip install 'meshoptixiq-network-discovery[enterprise]'"
        ) from exc
else:
    # ---------------------------------------------------------------------------
    # Standard authentication — PAT Bearer + root API_KEY fallback
    # ---------------------------------------------------------------------------
    async def require_api_key(  # type: ignore[misc]
        request: Request,
        key: str | None = Security(_api_key_header),
    ) -> None:
        """FastAPI dependency that enforces PAT or API-key authentication.

        Checks in order:
        1. ``Authorization: Bearer mq_live_*`` — Personal Access Token (preferred)
        2. ``X-API-Key`` header                — root API key (legacy/bootstrap)
        3. ``?api_key=`` query param           — SSE EventSource fallback

        On success, attaches a ``UserContext`` to ``request.state.user`` so
        that RBAC and audit logging have a consistent target.

        Note: The global API_KEY root bypass is kept for backward compatibility
        and bootstrap/break-glass scenarios.  Prefer issuing a named admin PAT
        once the PAT system is operational.
        """
        from network_discovery.api.user_store import (
            UserContext,
            _hash_token,
            lookup_token,
            update_token_last_used,
        )

        client_ip = request.client.host if request.client else None

        # --- PAT via Authorization: Bearer header ---
        authorization = request.headers.get("authorization", "")
        if authorization.lower().startswith("bearer "):
            raw = authorization[7:].strip()
            if raw.startswith("mq_live_") or raw.startswith("mq_auto_"):
                record = lookup_token(raw)
                if record and not record.revoked:
                    # Check expiry
                    try:
                        expires = datetime.fromisoformat(record.expires_at)
                        if expires < datetime.now(timezone.utc):
                            raise HTTPException(status_code=401, detail="Token expired")
                    except ValueError:
                        raise HTTPException(status_code=401, detail="Token has invalid expiry")

                    # Update last-used metadata (best-effort)
                    update_token_last_used(_hash_token(raw), client_ip)

                    request.state.user = UserContext(
                        sub=record.username,
                        roles=[record.role],
                        auth_method="pat",
                        scopes=record.scopes,
                        token_id=record.token_id,
                    )
                    return

                logger.warning(
                    "PAT auth failure from %s — path: %s (invalid or revoked)",
                    client_ip, request.url.path,
                )
                raise HTTPException(status_code=401, detail="Invalid or expired token")

        # --- Root API_KEY (backward compat — X-API-Key header or ?api_key= param) ---
        # ?api_key= query param is only accepted on /events (SSE EventSource can't set headers).
        # All other paths require the X-API-Key header to avoid leaking the key through
        # URL logs, proxies, and browser history.
        expected = os.environ.get("API_KEY")

        # Open-access mode: no API_KEY configured (community/local deployments).
        if not expected:
            request.state.user = UserContext(
                sub="local",
                roles=["admin"],
                auth_method="open",
                scopes=["*"],
            )
            return

        if not key and request.url.path == "/events":
            key = request.query_params.get("api_key")
        if key and expected and key == expected:
            request.state.user = UserContext(
                sub="api_key_client",
                roles=["admin"],
                auth_method="api_key",
                scopes=["*"],
            )
            return

        logger.warning(
            "Authentication failure from %s — path: %s",
            client_ip, request.url.path,
        )
        raise HTTPException(status_code=401, detail="Invalid or missing credentials")


def _check_static_api_key(request: Request) -> None:
    """Sync helper for health/metrics endpoints gated by MESHQ_PROTECT_HEALTH.

    Accepts only the X-API-Key header (no query param) to avoid leaking credentials
    in server logs when these endpoints are polled by Prometheus or k8s probes.
    Raises HTTPException(401) if the key is missing or wrong.
    """
    expected = os.environ.get("API_KEY")
    key = request.headers.get("X-API-Key")
    if not (key and expected and key == expected):
        raise HTTPException(status_code=401, detail="Invalid or missing credentials")
