"""History snapshot endpoints."""

from datetime import datetime

from fastapi import APIRouter, HTTPException, Query

from network_discovery.api.snapshot_store import (
    clear_snapshots_async,
    get_snapshots_async,
)

router = APIRouter(tags=["History"])


@router.get("/snapshots")
async def list_snapshots(
    limit: int = Query(default=288, ge=1, le=288, description="Maximum snapshots to return"),
):
    """Return recent summary-stats snapshots (oldest first).

    Up to 288 records (24 h at 5-min intervals).
    In clustered mode reads from the shared Redis Sorted Set so all instances
    return identical data.  Returns an empty list immediately after startup
    while waiting for the first collection cycle to complete.
    """
    return {"snapshots": await get_snapshots_async(limit=limit)}


@router.delete("/snapshots")
async def delete_snapshots():
    """Clear all stored snapshots.

    In clustered mode deletes from the shared Redis Sorted Set so the clear
    propagates to all instances.
    """
    deleted = await clear_snapshots_async()
    return {"deleted": deleted}


@router.get("/diff")
async def history_diff(
    from_ts: str = Query(..., description="ISO 8601 start timestamp (e.g. 2026-02-24T00:00:00Z)"),
    to_ts: str = Query(..., description="ISO 8601 end timestamp"),
):
    """Diff two snapshots identified by their nearest stored timestamps.

    Returns added/removed devices and firewall rules between the two points in
    time.  When snapshots pre-date entity-fingerprint collection the response
    includes count deltas only and sets ``fingerprints_available: false``.
    """
    snapshots = await get_snapshots_async()
    if not snapshots:
        raise HTTPException(status_code=404, detail="No snapshots available yet.")

    def _parse_ts(ts: str) -> datetime:
        try:
            return datetime.fromisoformat(ts.replace("Z", "+00:00"))
        except ValueError:
            raise HTTPException(status_code=400, detail=f"Invalid timestamp: {ts!r}")

    from_dt = _parse_ts(from_ts)
    to_dt   = _parse_ts(to_ts)

    def _nearest(target: datetime) -> dict:
        return min(
            snapshots,
            key=lambda s: abs(
                datetime.fromisoformat(
                    s["timestamp"].replace("Z", "+00:00")
                ).timestamp() - target.timestamp()
            ),
        )

    from_snap = _nearest(from_dt)
    to_snap   = _nearest(to_dt)

    has_fingerprints = (
        "device_hostnames" in from_snap and "device_hostnames" in to_snap
    )

    result: dict = {
        "from": {
            "timestamp":           from_snap["timestamp"],
            "device_count":        from_snap.get("device_count", 0),
            "firewall_rule_count": from_snap.get("firewall_rule_count", 0),
        },
        "to": {
            "timestamp":           to_snap["timestamp"],
            "device_count":        to_snap.get("device_count", 0),
            "firewall_rule_count": to_snap.get("firewall_rule_count", 0),
        },
        "fingerprints_available": has_fingerprints,
        "delta": {
            "device_count": (
                to_snap.get("device_count", 0) - from_snap.get("device_count", 0)
            ),
            "firewall_rule_count": (
                to_snap.get("firewall_rule_count", 0)
                - from_snap.get("firewall_rule_count", 0)
            ),
        },
        "devices_added":   [],
        "devices_removed": [],
        "rules_added":     [],
        "rules_removed":   [],
    }

    if has_fingerprints:
        from_devices = set(from_snap.get("device_hostnames", []))
        to_devices   = set(to_snap.get("device_hostnames", []))
        from_rules   = set(from_snap.get("firewall_rule_ids", []))
        to_rules     = set(to_snap.get("firewall_rule_ids", []))

        result["devices_added"]   = sorted(to_devices - from_devices)
        result["devices_removed"] = sorted(from_devices - to_devices)
        result["rules_added"]     = sorted(to_rules - from_rules)
        result["rules_removed"]   = sorted(from_rules - to_rules)

    return result
