"""Ansible dynamic inventory export route.

Endpoint: ``GET /inventory/ansible``

Returns an Ansible-compatible dynamic inventory JSON document derived from
the live graph database.  The response groups devices by vendor (using the
standard ``ansible_network_os`` mapping) and adds a ``firewalls`` group for
devices that have at least one collected ``FirewallRule`` node.

Optional query parameter: ``?format=ini`` returns legacy INI-style output.
"""

import logging
import os
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import PlainTextResponse

from network_discovery.api.dependencies import get_db_driver
from network_discovery.graph.provider import GraphProvider

logger = logging.getLogger(__name__)

router = APIRouter()

# ---------------------------------------------------------------------------
# Vendor → ansible_network_os mapping
# ---------------------------------------------------------------------------

VENDOR_TO_ANSIBLE_OS: dict[str, str] = {
    "cisco_ios":        "ios",
    "cisco_nxos":       "nxos",
    "cisco_asa":        "asa",
    "cisco_ftd":        "asa",
    "arista_eos":       "eos",
    "juniper_junos":    "junos",
    "paloalto_panos":   "panos",
    "fortinet":         "fortios",
    "checkpoint_gaia":  "checkpoint_gaia",
    "aruba_os":         "arubaos",
}

# ---------------------------------------------------------------------------
# Query helpers
# ---------------------------------------------------------------------------

_BACKEND = os.environ.get("GRAPH_BACKEND", "neo4j").lower()

_ALL_DEVICES_CYPHER = """
MATCH (d:Device)
RETURN d.hostname  AS hostname,
       d.vendor    AS vendor,
       d.model     AS model,
       d.os_version AS os_version,
       d.serial    AS serial,
       d.mgmt_ip   AS mgmt_ip
ORDER BY d.hostname
"""

_ALL_DEVICES_SQL = """
SELECT hostname, vendor, model, os_version, serial, mgmt_ip
FROM   devices
ORDER  BY hostname
"""

_FIREWALL_HOSTS_CYPHER = """
MATCH (d:Device)-[:HAS_FIREWALL_RULE]->(:FirewallRule)
RETURN DISTINCT d.hostname AS hostname
"""

_FIREWALL_HOSTS_SQL = """
SELECT DISTINCT d.hostname
FROM   devices d
JOIN   firewall_rules fr ON fr.device_hostname = d.hostname
"""


def _query_all_devices(provider: GraphProvider) -> list[dict[str, Any]]:
    backend = os.environ.get("GRAPH_BACKEND", "neo4j").lower()
    content = _ALL_DEVICES_CYPHER if backend == "neo4j" else _ALL_DEVICES_SQL
    return list(provider.execute_query("all_devices", content, {}))


def _query_firewall_hosts(provider: GraphProvider) -> set[str]:
    backend = os.environ.get("GRAPH_BACKEND", "neo4j").lower()
    content = _FIREWALL_HOSTS_CYPHER if backend == "neo4j" else _FIREWALL_HOSTS_SQL
    try:
        rows = list(provider.execute_query("_firewall_hosts", content, {}))
        return {r.get("hostname", "") for r in rows if r.get("hostname")}
    except Exception as exc:
        logger.warning("Could not query firewall hosts: %s", exc)
        return set()


# ---------------------------------------------------------------------------
# Inventory builder
# ---------------------------------------------------------------------------

def build_ansible_inventory(
    devices: list[dict[str, Any]],
    firewall_hostnames: set[str],
) -> dict[str, Any]:
    """Construct the Ansible dynamic inventory dict."""
    hostvars: dict[str, dict[str, Any]] = {}
    vendor_groups: dict[str, list[str]] = {}
    firewall_hosts: list[str] = []
    all_group_children: list[str] = []

    for device in devices:
        hostname: str = device.get("hostname") or ""
        if not hostname:
            continue

        vendor: str = (device.get("vendor") or "").lower()
        ansible_os = VENDOR_TO_ANSIBLE_OS.get(vendor, vendor)

        hostvars[hostname] = {
            "ansible_host":           device.get("mgmt_ip") or hostname,
            "ansible_network_os":     ansible_os,
            "meshoptixiq_vendor":     vendor,
            "meshoptixiq_model":      device.get("model") or "",
            "meshoptixiq_os_version": device.get("os_version") or "",
        }

        # Remove empty values for cleanliness
        hostvars[hostname] = {k: v for k, v in hostvars[hostname].items() if v}

        if vendor:
            vendor_groups.setdefault(vendor, []).append(hostname)

        if hostname in firewall_hostnames:
            firewall_hosts.append(hostname)

    # Build top-level groups
    for group_name in vendor_groups:
        if group_name not in all_group_children:
            all_group_children.append(group_name)

    if firewall_hosts:
        all_group_children.append("firewalls")

    inventory: dict[str, Any] = {
        "_meta": {"hostvars": hostvars},
        "all": {"children": all_group_children},
    }

    for vendor_key, hosts in vendor_groups.items():
        inventory[vendor_key] = {"hosts": sorted(hosts)}

    if firewall_hosts:
        inventory["firewalls"] = {"hosts": sorted(firewall_hosts)}

    return inventory


def _build_ini(inventory: dict[str, Any]) -> str:
    """Render inventory as legacy INI format."""
    lines: list[str] = []
    hostvars: dict[str, dict[str, Any]] = inventory.get("_meta", {}).get("hostvars", {})

    for group, data in inventory.items():
        if group in ("_meta", "all"):
            continue
        hosts = data.get("hosts", [])
        if not hosts:
            continue
        lines.append(f"[{group}]")
        for host in hosts:
            vars_str = ""
            hv = hostvars.get(host, {})
            if hv.get("ansible_host"):
                vars_str += f" ansible_host={hv['ansible_host']}"
            if hv.get("ansible_network_os"):
                vars_str += f" ansible_network_os={hv['ansible_network_os']}"
            lines.append(f"{host}{vars_str}")
        lines.append("")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Route
# ---------------------------------------------------------------------------

@router.get("/ansible")
def get_ansible_inventory(
    format: str = Query(default="json", description="Output format: json or ini"),
    provider: GraphProvider = Depends(get_db_driver),
):
    """Return the live graph as an Ansible dynamic inventory.

    Use ``?format=ini`` for legacy INI output.
    """
    try:
        devices = _query_all_devices(provider)
    except Exception as exc:
        logger.error("Failed to query devices for Ansible inventory: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to retrieve device inventory")

    firewall_hosts = _query_firewall_hosts(provider)
    inventory = build_ansible_inventory(devices, firewall_hosts)

    if format.lower() == "ini":
        ini_content = _build_ini(inventory)
        return PlainTextResponse(content=ini_content, media_type="text/plain")

    return inventory
