"""CLI proxy endpoints — double-gated (RBAC/scope first, then license).

Gate order matters:
    Gate 1 (RBAC / scope): Does this user's role/token allow this operation?
        → 403 Forbidden (generic — does NOT reveal license tier)
    Gate 2 (License):      Does the installation's plan include this feature?
        → 403 Forbidden with plan-upgrade detail

POST /cli/ingest  — ingest NetworkFacts JSON (cli:ingest scope, api_access license)
GET  /cli/export  — export Ansible inventory   (cli:export scope, api_access license)
POST /cli/sync    — NetBox sync                (cli:sync scope,   netbox_sync license)
"""

from __future__ import annotations

import logging
import os
from fnmatch import fnmatch

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel

from network_discovery.api.audit_log import audit
from network_discovery.api.dependencies import get_db_driver
from network_discovery.graph.provider import GraphProvider

logger = logging.getLogger(__name__)

router = APIRouter(tags=["CLI"])


# ---------------------------------------------------------------------------
# Gate helpers
# ---------------------------------------------------------------------------

def _check_scope(user, op: str) -> None:
    """Gate 1: scope/role check.

    Admin role bypasses scope restrictions.
    PAT users must have a matching scope pattern.
    Raises 403 (generic — no license tier detail) on failure.
    """
    if user is None:
        raise HTTPException(status_code=403, detail="Forbidden")

    roles: list[str] = getattr(user, "roles", [])
    scopes: list[str] = getattr(user, "scopes", [])

    # Admin role: always allow
    if "admin" in roles:
        return

    # PAT scope check
    if "*" in scopes:
        return
    for pattern in scopes:
        if fnmatch(op, pattern):
            return

    logger.warning(
        "CLI scope denied: user=%s op=%s scopes=%s roles=%s",
        getattr(user, "sub", "?"), op, scopes, roles,
    )
    # Generic 403 — does NOT reveal what plan would unlock this
    raise HTTPException(status_code=403, detail="Forbidden")


def _check_license(feature: str) -> None:
    """Gate 2: license feature check.

    Raises 403 with plan-upgrade detail on failure.
    Demo mode bypasses all license checks.
    """
    if os.environ.get("MESHOPTIXIQ_DEMO_MODE"):
        return
    from network_discovery.api.licensing import get_plan
    from network_discovery.licensing.gates import FeatureNotAvailableError, check_feature

    plan = get_plan()
    try:
        check_feature(plan, feature)
    except FeatureNotAvailableError as exc:
        raise HTTPException(
            status_code=403,
            detail=f"Feature requires {exc.required_plan} plan or higher",
        ) from exc


# ---------------------------------------------------------------------------
# POST /cli/ingest
# ---------------------------------------------------------------------------

@router.post("/ingest")
async def cli_ingest(
    request: Request,
    provider: GraphProvider = Depends(get_db_driver),
) -> dict:
    """Ingest a NetworkFacts JSON payload.

    Gate 1 (scope): ``cli:ingest``
    Gate 2 (license): ``api_access`` (pro+)
    """
    user = getattr(request.state, "user", None)
    _check_scope(user, "cli:ingest")
    _check_license("api_access")

    body = await request.body()
    if not body:
        raise HTTPException(status_code=422, detail="Empty request body")

    try:
        from network_discovery.normalization.models import NetworkFacts
        facts = NetworkFacts.model_validate_json(body)
    except Exception as exc:
        raise HTTPException(
            status_code=422, detail=f"Invalid NetworkFacts payload: {exc}"
        ) from exc

    try:
        from network_discovery.ingest import GraphIngester
        counts = GraphIngester(provider).ingest(facts)
    except Exception as exc:
        logger.exception("CLI ingest failed")
        audit(request, "cli:ingest", "error", error=str(exc))
        raise HTTPException(status_code=500, detail=f"Ingestion failed: {exc}") from exc

    audit(request, "cli:ingest", "ok", counts=counts or {})
    return counts or {}


# ---------------------------------------------------------------------------
# GET /cli/export
# ---------------------------------------------------------------------------

@router.get("/export")
def cli_export(
    request: Request,
    format: str = "ansible",
    provider: GraphProvider = Depends(get_db_driver),
) -> dict:
    """Export inventory data.

    Gate 1 (scope): ``cli:export``
    Gate 2 (license): ``api_access`` (pro+)
    """
    user = getattr(request.state, "user", None)
    _check_scope(user, "cli:export")
    _check_license("api_access")

    if format not in ("ansible", "ini"):
        raise HTTPException(status_code=400, detail="format must be 'ansible' or 'ini'")

    try:
        from network_discovery.api.routes.inventory import (
            _query_all_devices,
            _query_firewall_hosts,
            build_ansible_inventory,
        )
        devices = _query_all_devices(provider)
        firewall_hosts = _query_firewall_hosts(provider)
        inventory = build_ansible_inventory(devices, firewall_hosts)
    except Exception as exc:
        logger.exception("CLI export failed")
        audit(request, "cli:export", "error", error=str(exc))
        raise HTTPException(status_code=500, detail=f"Export failed: {exc}") from exc

    host_count = len(
        (inventory.get("all") or {}).get("hosts") or []
    )
    audit(request, "cli:export", "ok", format=format, device_count=host_count)

    if format == "ini":
        lines: list[str] = []
        for group, data in inventory.items():
            if group == "_meta":
                continue
            lines.append(f"[{group}]")
            for host in (data.get("hosts") or []):
                lines.append(host)
            lines.append("")
        return {"format": "ini", "content": "\n".join(lines)}

    return inventory


# ---------------------------------------------------------------------------
# POST /cli/sync
# ---------------------------------------------------------------------------

class SyncBody(BaseModel):
    target: str
    direction: str | None = None
    dry_run: bool = False


@router.post("/sync")
def cli_sync(
    body: SyncBody,
    request: Request,
    provider: GraphProvider = Depends(get_db_driver),
) -> dict:
    """Synchronise with an external system.

    Gate 1 (scope): ``cli:sync``
    Gate 2 (license): ``netbox_sync`` feature flag (pro+)
    """
    user = getattr(request.state, "user", None)
    _check_scope(user, "cli:sync")
    _check_license("netbox_sync")

    if body.target != "netbox":
        raise HTTPException(
            status_code=400, detail="Only 'netbox' sync target is supported"
        )

    try:
        from network_discovery.enterprise.integrations.netbox import run_sync
    except ImportError:
        raise HTTPException(
            status_code=501,
            detail=(
                "NetBox sync requires the integrations extras. "
                "Install with: pip install 'meshoptixiq-network-discovery[integrations]'"
            ),
        )

    try:
        run_sync(provider, direction=body.direction, dry_run=body.dry_run)
    except Exception as exc:
        logger.exception("CLI sync failed")
        audit(request, "cli:sync", "error", target=body.target, error=str(exc))
        raise HTTPException(status_code=500, detail=f"Sync failed: {exc}") from exc

    audit(request, "cli:sync", "ok", target=body.target, dry_run=body.dry_run)
    return {"synced": True, "target": body.target, "dry_run": body.dry_run}
