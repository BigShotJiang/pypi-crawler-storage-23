"""Demo mode info endpoint — always available, no auth required."""

import os

from fastapi import APIRouter

router = APIRouter()


@router.get("/info")
def demo_info() -> dict:
    """Return whether the API is running in demo mode and whether auth is required."""
    demo = bool(os.environ.get("MESHOPTIXIQ_DEMO_MODE"))
    auth_required = bool(os.environ.get("API_KEY")) and not demo
    return {"demo_mode": demo, "auth_required": auth_required}
