"""User management and Personal Access Token (PAT) endpoints.

auth_router  (mounted at /auth):
    GET  /auth/tokens/me            — list caller's own tokens
    DELETE /auth/tokens/{token_id}  — revoke own token

admin_router (mounted at /admin, admin role required):
    GET    /admin/users                     — list users
    POST   /admin/users                     — create user
    DELETE /admin/users/{username}          — delete user + revoke all tokens
    PATCH  /admin/users/{username}          — update role
    GET    /admin/users/{username}/tokens   — list tokens for user
    POST   /admin/users/{username}/tokens   — issue PAT (raw token shown once)
    DELETE /admin/tokens/{token_id}         — revoke any token
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field

from network_discovery.api import user_store
from network_discovery.api.routes.admin import _require_admin

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Auth router — caller's own token management
# ---------------------------------------------------------------------------

auth_router = APIRouter(tags=["Auth"])


@auth_router.get("/tokens/me")
def list_my_tokens(request: Request) -> list[dict]:
    """List the caller's own non-revoked tokens."""
    user = getattr(request.state, "user", None)
    if user is None:
        raise HTTPException(status_code=401, detail="Not authenticated")
    return user_store.list_tokens(username=user.sub)


@auth_router.delete("/tokens/{token_id}", status_code=200)
def revoke_my_token(token_id: str, request: Request) -> dict:
    """Revoke one of the caller's own tokens by token_id."""
    user = getattr(request.state, "user", None)
    if user is None:
        raise HTTPException(status_code=401, detail="Not authenticated")
    # Verify ownership before revoking
    owned = {t["token_id"] for t in user_store.list_tokens(username=user.sub)}
    if token_id not in owned:
        raise HTTPException(status_code=404, detail="Token not found")
    revoked = user_store.revoke_token(token_id)
    if not revoked:
        raise HTTPException(status_code=404, detail="Token not found")
    return {"revoked": True, "token_id": token_id}


# ---------------------------------------------------------------------------
# Admin router — user + token management
# ---------------------------------------------------------------------------

admin_router = APIRouter(tags=["Admin"])


class CreateUserBody(BaseModel):
    username: str = Field(..., min_length=1)
    role: str = Field(..., min_length=1)


class UpdateUserBody(BaseModel):
    role: str = Field(..., min_length=1)


class IssueTokenBody(BaseModel):
    description: str = ""
    scopes: list[str] | None = None
    expires_in_days: int = Field(default=30, ge=1, le=365)


@admin_router.get("/users")
def list_users(request: Request) -> list[dict]:
    """List all users with their active token counts. Admin role required."""
    _require_admin(request)
    return user_store.list_users()


@admin_router.post("/users", status_code=201)
def create_user(body: CreateUserBody, request: Request) -> dict:
    """Create a new user. Admin role required."""
    _require_admin(request)
    existing = {u["username"] for u in user_store.list_users()}
    if body.username in existing:
        raise HTTPException(status_code=409, detail="User already exists")
    user_store.create_user(body.username, body.role)
    return {"username": body.username, "role": body.role}


@admin_router.delete("/users/{username}", status_code=200)
def delete_user(username: str, request: Request) -> dict:
    """Delete a user and revoke all their tokens. Admin role required."""
    _require_admin(request)
    user_store.delete_user(username)
    return {"deleted": True, "username": username}


@admin_router.patch("/users/{username}", status_code=200)
def update_user(username: str, body: UpdateUserBody, request: Request) -> dict:
    """Update a user's role. Admin role required."""
    _require_admin(request)
    updated = user_store.update_user_role(username, body.role)
    if not updated:
        raise HTTPException(status_code=404, detail="User not found")
    return {"username": username, "role": body.role}


@admin_router.get("/users/{username}/tokens")
def list_user_tokens(username: str, request: Request) -> list[dict]:
    """List all tokens (including revoked) for a user. Admin role required."""
    _require_admin(request)
    return user_store.list_tokens(username=username)


@admin_router.post("/users/{username}/tokens", status_code=201)
def issue_token(username: str, body: IssueTokenBody, request: Request) -> dict:
    """Issue a new PAT for a user.

    The raw token is returned **once only** — save it immediately.
    Admin role required.
    """
    _require_admin(request)
    users = {u["username"]: u["role"] for u in user_store.list_users()}
    if username not in users:
        raise HTTPException(status_code=404, detail="User not found")
    role = users[username]
    raw = user_store.issue_token(
        username=username,
        role=role,
        description=body.description,
        scopes=body.scopes,
        expires_in_days=body.expires_in_days,
    )
    token_id = raw[:12]
    # Retrieve the expiry from the just-created record
    tokens = user_store.list_tokens(username=username)
    expires_at = next(
        (t["expires_at"] for t in tokens if t["token_id"] == token_id), None
    )
    return {
        "token":      raw,       # shown once — never stored again
        "token_id":   token_id,
        "expires_at": expires_at,
    }


@admin_router.delete("/tokens/{token_id}", status_code=200)
def admin_revoke_token(token_id: str, request: Request) -> dict:
    """Revoke any token by token_id. Admin role required."""
    _require_admin(request)
    revoked = user_store.revoke_token(token_id)
    if not revoked:
        raise HTTPException(status_code=404, detail="Token not found")
    return {"revoked": True, "token_id": token_id}
