"""Admin configuration introspection and management endpoints.

Returns a sanitized view of the running configuration — sensitive values
(URIs, tokens) are masked.  Restricted to users with the ``admin`` role.
"""

import logging
import os
import re

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Admin"])

_ADMIN_ROLES = {"admin", "sysadmin"}


def _mask_uri(uri: str) -> str:
    """Replace password and token segments in a URI with ``***``."""
    if not uri:
        return uri
    return re.sub(r"(:)[^:@/]+(@)", r"\1***\2", uri)


def _last4(value: str | None) -> str | None:
    if not value or len(value) < 4:
        return None
    return "…" + value[-4:]


def _detect_observability() -> str | None:
    if os.environ.get("DD_AGENT_HOST"):
        return "datadog"
    if os.environ.get("NEW_RELIC_LICENSE_KEY"):
        return "newrelic"
    if os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT"):
        return "otlp"
    return None


def _detect_secrets_provider() -> str:
    return os.environ.get("SECRETS_PROVIDER", "none").lower()


def _rbac_policy_source() -> str | None:
    if os.environ.get("RBAC_POLICY_FILE"):
        return "file"
    if os.environ.get("RBAC_POLICY"):
        return "env"
    return None


def _rbac_policy_yaml() -> str | None:
    """Return the raw RBAC policy YAML (from env or file), or None."""
    inline = os.environ.get("RBAC_POLICY")
    if inline:
        return inline

    policy_file = os.environ.get("RBAC_POLICY_FILE")
    if policy_file:
        try:
            with open(policy_file) as fh:
                return fh.read()
        except OSError:
            return None
    return None


def _require_admin(request: Request) -> None:
    """Raise 403 if the authenticated user does not have an admin role."""
    user = getattr(request.state, "user", None)
    if user is None:
        raise HTTPException(status_code=401, detail="Authentication required")
    roles = set(getattr(user, "roles", []))
    if not roles.intersection(_ADMIN_ROLES):
        raise HTTPException(status_code=403, detail="Admin role required")


def _redis_url_masked() -> str | None:
    """Return the configured Redis URL with password replaced by ***, or None."""
    url = os.environ.get("REDIS_URL")
    if not url:
        return None
    return _mask_uri(url)


def _secrets_provider_refs() -> dict:
    """Return non-sensitive provider-specific config references (paths/names only)."""
    provider = os.environ.get("SECRETS_PROVIDER", "none").lower()
    if provider == "vault":
        return {
            "vault_addr":        os.environ.get("VAULT_ADDR", "http://127.0.0.1:8200"),
            "vault_secret_path": os.environ.get("VAULT_SECRET_PATH"),
            "vault_auth_method": os.environ.get("VAULT_AUTH_METHOD", "token"),
        }
    if provider == "aws":
        return {
            "aws_secret_name": os.environ.get("AWS_SECRET_NAME"),
            "aws_region":      os.environ.get("AWS_REGION", "us-east-1"),
        }
    if provider == "azure":
        return {
            "azure_key_vault_url": os.environ.get("AZURE_KEY_VAULT_URL"),
            "azure_secret_names":  os.environ.get("AZURE_SECRET_NAMES"),
        }
    if provider == "gcp":
        return {
            "gcp_project_id": os.environ.get("GCP_PROJECT_ID"),
            "gcp_secret_ids": os.environ.get("GCP_SECRET_IDS"),
        }
    return {}


def _postgres_pool_stats() -> dict | None:
    """Return pool stats from the current PostgresProvider, or None."""
    from network_discovery.api.dependencies import _provider
    try:
        from network_discovery.graph.postgres_provider import PostgresProvider
    except ImportError:
        return None

    if isinstance(_provider, PostgresProvider):
        stats = _provider.pool_stats()
        return {
            "postgres_pool_min": int(os.environ.get("POSTGRES_POOL_MIN", "2")),
            "postgres_pool_max": int(os.environ.get("POSTGRES_POOL_MAX", "10")),
            "postgres_pool_available": stats.get("pool_available", 0),
        }
    return None


def _microsoft_status() -> dict:
    """Return Microsoft integration status for the admin config endpoint."""
    tenant = os.environ.get("ENTRA_TENANT_ID", "")
    return {
        "entra_id":     bool(os.environ.get("ENTRA_TENANT_ID") or os.environ.get("ENTRA_CLIENT_ID")),
        "entra_tenant": (tenant[:8] + "...") if tenant else None,
        "teams_soar":   bool(os.environ.get("TEAMS_SOAR_WEBHOOK_URL")),
        "teams_audit":  bool(os.environ.get("TEAMS_AUDIT_WEBHOOK_URL")),
        "sentinel":     bool(os.environ.get("SENTINEL_WORKSPACE_ID")),
    }


@router.get("/config")
def get_config(request: Request) -> dict:
    """Return sanitized runtime configuration (admin role required)."""
    _require_admin(request)

    from network_discovery.api.cluster import is_clustered
    from network_discovery.api.licensing import get_expiry, get_plan

    backend = os.environ.get("GRAPH_BACKEND", "neo4j").lower()
    backend_uri_env = (
        os.environ.get("NEO4J_URI", "")
        if backend == "neo4j"
        else os.environ.get("POSTGRES_URI", os.environ.get("DATABASE_URL", ""))
    )

    oidc_url = os.environ.get("OIDC_DISCOVERY_URL") or None
    oidc_client = os.environ.get("OIDC_CLIENT_ID") or None

    config: dict = {
        "auth_mode":              os.environ.get("AUTH_MODE", "api_key"),
        "graph_backend":          backend,
        "graph_uri_masked":       _mask_uri(backend_uri_env),
        "audit_enabled":          os.environ.get("AUDIT_LOG_ENABLED", "").lower() == "true",
        "secrets_provider":       _detect_secrets_provider(),
        "observability_provider": _detect_observability(),
        "oidc_discovery_url":     oidc_url,
        "oidc_client_id":         oidc_client,
        "api_key_last4":          _last4(os.environ.get("API_KEY")),
        "rbac_policy_source":     _rbac_policy_source(),
        "rbac_policy_yaml":       _rbac_policy_yaml(),
        "cluster_mode":           is_clustered(),
        "redis_url_masked":       _redis_url_masked(),
        "license_plan":           get_plan(),
        "license_expires":        get_expiry(),
    }

    # Add PostgreSQL pool stats when using the postgres backend
    pool_stats = _postgres_pool_stats()
    if pool_stats:
        config.update(pool_stats)

    # Add secrets provider config references (paths/names only — not values)
    config.update(_secrets_provider_refs())

    config["microsoft"] = _microsoft_status()

    return config


class RbacPolicyPatch(BaseModel):
    policy_yaml: str


@router.patch("/rbac/policy")
async def patch_rbac_policy(body: RbacPolicyPatch, request: Request) -> dict:
    """Write a new RBAC policy and immediately reload it. Admin role required.

    If RBAC_POLICY_FILE is configured the YAML is written to disk (persists
    across restarts). Otherwise the policy is applied in-memory only and will
    be lost on container restart — a warning is included in the response.
    """
    _require_admin(request)

    # Validate YAML before touching anything
    import yaml as _yaml
    try:
        parsed = _yaml.safe_load(body.policy_yaml)
    except _yaml.YAMLError as exc:
        raise HTTPException(status_code=422, detail=f"Invalid YAML: {exc}")

    if parsed is not None and not isinstance(parsed, dict):
        raise HTTPException(status_code=422, detail="RBAC policy must be a YAML mapping")

    try:
        from network_discovery.enterprise.auth.rbac import _reset_policy_cache
    except ImportError:
        raise HTTPException(status_code=501, detail="RBAC module not available")

    persisted = False
    warning: str | None = None
    policy_file = os.environ.get("RBAC_POLICY_FILE")

    if policy_file:
        try:
            with open(policy_file, "w") as fh:
                fh.write(body.policy_yaml)
            persisted = True
        except OSError as exc:
            raise HTTPException(status_code=500, detail=f"Could not write policy file: {exc}")
    else:
        # In-memory only — update the env var so the reloader picks it up
        os.environ["RBAC_POLICY"] = body.policy_yaml
        warning = (
            "RBAC_POLICY_FILE is not configured. "
            "Policy applied in-memory only and will not survive a restart."
        )

    _reset_policy_cache()

    # Broadcast in cluster mode
    broadcast = False
    from network_discovery.api.cluster import get_redis, is_clustered
    if is_clustered():
        r = await get_redis()
        if r is not None:
            await r.publish("meshq:rbac_reload", "reload")
            broadcast = True

    return {
        "applied":   True,
        "persisted": persisted,
        "broadcast": broadcast,
        "warning":   warning,
    }


@router.post("/rbac/reload")
async def rbac_reload(request: Request) -> dict:
    """Force an immediate RBAC policy reload on this instance.

    When cluster mode is active the reload signal is broadcast to all instances
    via Redis Pub/Sub so every pod picks up the new policy without a restart.

    Admin role required.
    """
    _require_admin(request)

    try:
        from network_discovery.enterprise.auth.rbac import _reset_policy_cache
        _reset_policy_cache()
        logger.info("RBAC policy cache cleared via /admin/rbac/reload")
    except ImportError:
        raise HTTPException(status_code=501, detail="RBAC module not available")

    broadcast = False
    from network_discovery.api.cluster import get_redis, is_clustered

    if is_clustered():
        r = await get_redis()
        if r is not None:
            await r.publish("meshq:rbac_reload", "reload")
            broadcast = True
            logger.info("RBAC reload signal broadcast via Redis Pub/Sub")

    return {"reloaded": True, "broadcast": broadcast}
