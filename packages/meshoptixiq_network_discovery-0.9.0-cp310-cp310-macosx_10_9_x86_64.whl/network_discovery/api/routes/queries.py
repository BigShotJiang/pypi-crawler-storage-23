"""Query API routes — list, inspect, and execute registered queries."""

import csv
import io
import logging
import os
from pathlib import Path
from typing import Any, Literal

import yaml
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from slowapi import Limiter
from slowapi.util import get_remote_address

from network_discovery.api.cluster import limiter_storage_uri
from network_discovery.api.dependencies import get_db_driver
from network_discovery.graph.provider import GraphProvider

_AUTH_MODE = os.environ.get("AUTH_MODE", "api_key").lower()

logger = logging.getLogger(__name__)

router = APIRouter()

limiter = Limiter(
    key_func=get_remote_address,
    storage_uri=limiter_storage_uri(),
    in_memory_fallback_enabled=True,
)

# Feature requirements per query.
# All queries need api_access (Pro+) as the baseline.
# Entries here add a second, more specific flag check.
_QUERY_FEATURE_REQUIREMENTS: dict[str, str] = {
    "firewall_rules_by_device":    "firewall_queries",
    "firewall_rules_by_zone_pair": "firewall_queries",
    "path_analysis":               "firewall_queries",
    "all_firewall_devices":        "firewall_queries",
    "deny_rules_summary":          "firewall_queries",
    "update_device_metadata":      "netbox_sync",
}

# Path to registry
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
REGISTRY_PATH = PROJECT_ROOT / "queries" / "registry.yaml"
QUERIES_ROOT = PROJECT_ROOT / "queries" / "v1"

# Load registry once on startup (simplified)
def load_registry():
    if not REGISTRY_PATH.exists():
        return {"queries": []}
    with open(REGISTRY_PATH) as f:
        return yaml.safe_load(f)

REGISTRY = load_registry()
QUERIES = {q["name"]: q for q in REGISTRY.get("queries", [])}

class QueryMetadata(BaseModel):
    name: str
    category: str
    description: str
    parameters: dict[str, str]

_MAX_PARAM_VALUE_LENGTH = 1024
_MAX_LIMIT = 10_000
_DEFAULT_LIMIT = 1000
_ALLOWED_PARAM_TYPES = (str, int, float, bool, type(None))


class QueryExecutionRequest(BaseModel):
    parameters: dict[str, Any]
    limit: int = Field(default=_DEFAULT_LIMIT, ge=1, le=_MAX_LIMIT)
    offset: int = Field(default=0, ge=0)
    output_format: Literal["json", "csv"] = "json"


@router.get("/", response_model=list[QueryMetadata])
def list_queries():
    """List all available queries."""
    return [
        QueryMetadata(
            name=q["name"],
            category=q["category"],
            description=q["description"],
            parameters=q["parameters"]
        )
        for q in REGISTRY.get("queries", [])
    ]

@router.get("/{query_name}", response_model=QueryMetadata)
def get_query_details(query_name: str):
    """Get details for a specific query."""
    if query_name not in QUERIES:
        raise HTTPException(status_code=404, detail="Query not found")

    q = QUERIES[query_name]
    return QueryMetadata(
        name=q["name"],
        category=q["category"],
        description=q["description"],
        parameters=q["parameters"]
    )

@router.post("/{query_name}/execute")
@limiter.limit("60/minute")
def execute_query(
    request: Request,
    query_name: str,
    body: QueryExecutionRequest,
    provider: GraphProvider = Depends(get_db_driver)
):
    """Execute a query with parameters.

    Supports pagination (``limit`` / ``offset``) and CSV export
    (``output_format: "csv"``).

    Rate limited to 60 requests per minute per IP.
    """
    if query_name not in QUERIES:
        raise HTTPException(status_code=404, detail="Query not found")

    # Feature gate — demo mode bypasses; uses plan cached at startup
    import os as _os
    if not _os.environ.get("MESHOPTIXIQ_DEMO_MODE"):
        try:
            from network_discovery.api.licensing import get_plan as _get_plan
            from network_discovery.licensing.gates import check_feature
            _plan = _get_plan()
            check_feature(_plan, "api_access")
            _extra = _QUERY_FEATURE_REQUIREMENTS.get(query_name)
            if _extra:
                check_feature(_plan, _extra)
        except Exception as _exc:
            if "FeatureNotAvailableError" in type(_exc).__name__ or "not available" in str(_exc).lower():
                raise HTTPException(
                    status_code=403,
                    detail=f"Query '{query_name}' is not available on your current license plan.",
                )
            raise

    # RBAC permission check (enterprise feature — no-op when not configured)
    try:
        from network_discovery.enterprise.auth.rbac import check_query_permission
        check_query_permission(getattr(request.state, "user", None), query_name)
    except ImportError:
        pass

    query_def = QUERIES[query_name]

    # Determine backend
    backend = os.environ.get("GRAPH_BACKEND", "neo4j").lower()

    # In-memory provider uses Python handlers — no query file required
    if backend == "inmemory":
        query_content = ""
    else:
        # Resolve implementation file
        if "implementations" in query_def:
            query_file = query_def["implementations"].get(backend)
            if not query_file:
                raise HTTPException(status_code=501, detail="Query not implemented for this backend")
        else:
            # Fallback for old registry format (default to neo4j/cypher)
            if backend != "neo4j":
                raise HTTPException(status_code=501, detail="Query not implemented for this backend")
            query_file = query_def.get("cypher")

        if not query_file:
            logger.error("Query definition invalid for '%s'", query_name)
            raise HTTPException(status_code=500, detail="Query configuration error")

        query_path = QUERIES_ROOT / query_file
        if not query_path.exists():
            logger.error("Query file missing for '%s': %s", query_name, query_file)
            raise HTTPException(status_code=500, detail="Query configuration error")

        query_content = query_path.read_text()

    # Validate parameters — presence
    required_params = query_def.get("parameters", {}).keys()
    provided_params = body.parameters.keys()

    missing = [p for p in required_params if p not in provided_params]
    if missing:
        logger.warning("Query '%s' called with missing parameters: %s", query_name, missing)
        raise HTTPException(status_code=400, detail="One or more required parameters are missing")

    # Validate parameters — types and size
    for key, value in body.parameters.items():
        if not isinstance(value, _ALLOWED_PARAM_TYPES):
            logger.warning(
                "Query '%s' parameter '%s' has unsupported type '%s'",
                query_name, key, type(value).__name__,
            )
            raise HTTPException(
                status_code=422,
                detail=f"Parameter '{key}' has an unsupported type. "
                       "Allowed types: string, integer, float, boolean, null.",
            )
        if isinstance(value, str) and len(value) > _MAX_PARAM_VALUE_LENGTH:
            raise HTTPException(
                status_code=422,
                detail=f"Parameter '{key}' exceeds the maximum allowed length.",
            )

    # Execute via Provider
    try:
        rows = provider.execute_query(query_name, query_content, body.parameters)
    except Exception:
        logger.exception("Query '%s' execution failed", query_name)
        raise HTTPException(
            status_code=500,
            detail="Query execution failed. Check server logs for details.",
        )

    # Materialise to list[dict] for pagination / formatting
    if not isinstance(rows, list):
        rows = list(rows)

    total = len(rows)
    paginated = rows[body.offset : body.offset + body.limit]

    # CSV export
    if body.output_format == "csv":
        return _csv_response(paginated, query_name)

    # Default JSON with pagination metadata
    return {
        "total": total,
        "offset": body.offset,
        "limit": body.limit,
        "rows": paginated,
    }


def _csv_response(rows: list[dict], query_name: str) -> StreamingResponse:
    """Serialise query result rows to a CSV streaming response."""
    buf = io.StringIO()
    if rows:
        writer = csv.DictWriter(buf, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)
    content = buf.getvalue()

    # query_name is validated against the registry above, so it's safe to use
    # in the filename. Sanitize anyway to strip any path separators.
    safe_name = Path(query_name).name

    return StreamingResponse(
        iter([content]),
        media_type="text/csv",
        headers={
            "Content-Disposition": f'attachment; filename="{safe_name}.csv"'
        },
    )
