"""Collection management endpoints.

Exposes device/network CRUD, poll-run lifecycle, and schedule management so
operators can drive collection entirely from the UI without needing the CLI.
All endpoints require API-key authentication (inherited from the router
registration in ``main.py``).

Existing endpoints (/status, /dispatch, /recover) are kept intact.
"""

from __future__ import annotations

import asyncio
import base64
import logging
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from network_discovery.api.cluster import is_clustered
from network_discovery.api.collect_queue import (
    dispatch_devices,
    queue_status,
    recover_stale,
)
from network_discovery.api.collect_store import (
    add_network,
    create_run,
    delete_device,
    delete_network,
    get_run,
    get_schedule,
    is_run_paused,
    list_devices,
    list_networks,
    list_runs,
    set_run_paused,
    set_schedule,
    update_device_in_run,
    update_run,
    upsert_device,
)

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Collect"])


# ---------------------------------------------------------------------------
# Pydantic request models
# ---------------------------------------------------------------------------

class DispatchRequest(BaseModel):
    devices: list[dict[str, Any]]


class DeviceConfig(BaseModel):
    hostname: str
    host: str
    vendor: str = "cisco_ios"
    port: int = 22
    username: str = ""
    credential_ref: str = ""
    tags: list[str] = []
    enabled: bool = True


class NetworkRequest(BaseModel):
    cidr: str


class StartRunRequest(BaseModel):
    devices: list[str] | None = None


class ScheduleConfig(BaseModel):
    enabled: bool = False
    cron: str = "*/5 * * * *"
    device_filter: list[str] = []


# ---------------------------------------------------------------------------
# Existing queue endpoints (unchanged)
# ---------------------------------------------------------------------------

@router.get("/status")
async def get_collect_status() -> dict[str, Any]:
    """Return the current collection queue depth and in-flight device count."""
    if not is_clustered():
        return {
            "pending": 0,
            "processing": 0,
            "last_results": {},
            "cluster_mode": False,
            "detail": "Cluster mode is not active — distributed collection requires REDIS_URL.",
        }
    return await queue_status()


@router.post("/dispatch")
async def post_dispatch(body: DispatchRequest) -> dict[str, Any]:
    """Push the supplied device list onto the collection queue."""
    if not is_clustered():
        raise HTTPException(
            status_code=503,
            detail="Cluster mode is not active — distributed collection requires REDIS_URL.",
        )
    if not body.devices:
        raise HTTPException(status_code=400, detail="devices list must not be empty")
    count = await dispatch_devices(body.devices)
    return {"dispatched": count, "submitted": len(body.devices)}


@router.post("/recover")
async def post_recover(max_age_seconds: int = 900) -> dict[str, Any]:
    """Re-queue devices stuck in-flight longer than *max_age_seconds*."""
    if not is_clustered():
        raise HTTPException(
            status_code=503,
            detail="Cluster mode is not active — distributed collection requires REDIS_URL.",
        )
    recovered = await recover_stale(max_age_seconds=max_age_seconds)
    return {"recovered": recovered}


# ---------------------------------------------------------------------------
# Device CRUD
# ---------------------------------------------------------------------------

@router.get("/devices")
async def get_devices() -> list[dict]:
    """List all registered poll-target devices."""
    return await list_devices()


@router.post("/devices", status_code=200)
async def post_device(body: DeviceConfig) -> dict[str, Any]:
    """Add or update a poll-target device."""
    config = body.model_dump()
    await upsert_device(config)
    return {"hostname": body.hostname, "stored": True}


@router.delete("/devices/{hostname}")
async def remove_device(hostname: str) -> dict[str, Any]:
    """Remove a poll-target device."""
    removed = await delete_device(hostname)
    if not removed:
        raise HTTPException(status_code=404, detail=f"Device '{hostname}' not found")
    return {"hostname": hostname, "removed": True}


# ---------------------------------------------------------------------------
# Network (CIDR) CRUD
# ---------------------------------------------------------------------------

@router.get("/networks")
async def get_networks() -> list[str]:
    """List all registered poll-target CIDRs."""
    return await list_networks()


@router.post("/networks", status_code=200)
async def post_network(body: NetworkRequest) -> dict[str, Any]:
    """Register a CIDR for auto-discovery sweeping."""
    cidr = body.cidr.strip()
    if not cidr:
        raise HTTPException(status_code=400, detail="cidr must not be empty")
    await add_network(cidr)
    return {"cidr": cidr, "stored": True}


@router.delete("/networks/{cidr_b64}")
async def remove_network(cidr_b64: str) -> dict[str, Any]:
    """Remove a CIDR. The path parameter is the base64-encoded CIDR string."""
    try:
        cidr = base64.b64decode(cidr_b64.encode()).decode()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid base64-encoded CIDR")
    removed = await delete_network(cidr)
    if not removed:
        raise HTTPException(status_code=404, detail=f"Network '{cidr}' not found")
    return {"cidr": cidr, "removed": True}


# ---------------------------------------------------------------------------
# Poll-run lifecycle
# ---------------------------------------------------------------------------

@router.get("/runs")
async def get_runs() -> list[dict]:
    """Return the 20 most recent poll runs."""
    return await list_runs(limit=20)


@router.post("/runs", status_code=201)
async def start_run(body: StartRunRequest) -> dict[str, Any]:
    """Start a new poll run.

    If ``devices`` is null/omitted, all enabled devices in the store are used.
    In clustered mode the devices are pushed to the Redis queue.
    In standalone mode a background asyncio task executes the poll sequentially.
    """
    if body.devices is not None:
        target_hostnames = body.devices
    else:
        all_devs = await list_devices()
        target_hostnames = [d["hostname"] for d in all_devs if d.get("enabled", True)]

    if not target_hostnames:
        raise HTTPException(status_code=400, detail="No enabled devices to poll")

    run_id = await create_run(target_hostnames, initiated_by="ui")
    await update_run(run_id, status="running")

    if is_clustered():
        # Load device configs for the selected hostnames and push to queue
        all_devs = await list_devices()
        dev_map = {d["hostname"]: d for d in all_devs}
        devs_to_dispatch = [dev_map[h] for h in target_hostnames if h in dev_map]
        if devs_to_dispatch:
            await dispatch_devices(devs_to_dispatch)
    else:
        # Standalone: run in background asyncio task
        all_devs = await list_devices()
        dev_map = {d["hostname"]: d for d in all_devs}
        devs_to_poll = [dev_map[h] for h in target_hostnames if h in dev_map]
        _task = asyncio.create_task(_run_poll_task(run_id, devs_to_poll))  # noqa: RUF006

    return {"run_id": run_id, "status": "running", "devices": target_hostnames}


@router.get("/runs/{run_id}")
async def get_run_detail(run_id: str) -> dict:
    """Return full details for a single run including per-device status."""
    record = await get_run(run_id)
    if record is None:
        raise HTTPException(status_code=404, detail=f"Run '{run_id}' not found")
    # Annotate pause state
    record["paused"] = await is_run_paused(run_id)
    return record


@router.post("/runs/{run_id}/pause")
async def pause_run(run_id: str) -> dict[str, Any]:
    """Pause an active run (workers stop taking new devices)."""
    record = await get_run(run_id)
    if record is None:
        raise HTTPException(status_code=404, detail=f"Run '{run_id}' not found")
    if record.get("status") not in ("running", "pending"):
        raise HTTPException(
            status_code=409,
            detail=f"Run is '{record.get('status')}' — only running/pending runs can be paused",
        )
    await set_run_paused(run_id, True)
    await update_run(run_id, status="paused")
    return {"run_id": run_id, "status": "paused"}


@router.post("/runs/{run_id}/resume")
async def resume_run(run_id: str) -> dict[str, Any]:
    """Resume a paused run."""
    record = await get_run(run_id)
    if record is None:
        raise HTTPException(status_code=404, detail=f"Run '{run_id}' not found")
    if record.get("status") != "paused":
        raise HTTPException(
            status_code=409,
            detail=f"Run is '{record.get('status')}' — only paused runs can be resumed",
        )
    await set_run_paused(run_id, False)
    await update_run(run_id, status="running")
    return {"run_id": run_id, "status": "running"}


@router.post("/runs/{run_id}/restart")
async def restart_run(run_id: str) -> dict[str, Any]:
    """Re-queue all failed or pending devices in a run."""
    record = await get_run(run_id)
    if record is None:
        raise HTTPException(status_code=404, detail=f"Run '{run_id}' not found")
    # Reset failed/pending devices back to pending status
    device_status: dict[str, str] = record.get("device_status", {})
    to_retry = [h for h, s in device_status.items() if s in ("failed", "pending", "skipped")]
    for hostname in to_retry:
        await update_device_in_run(run_id, hostname, "pending")
    await set_run_paused(run_id, False)
    await update_run(run_id, status="running", finished_at=None)

    if is_clustered() and to_retry:
        all_devs = await list_devices()
        dev_map = {d["hostname"]: d for d in all_devs}
        devs_to_dispatch = [dev_map[h] for h in to_retry if h in dev_map]
        if devs_to_dispatch:
            await dispatch_devices(devs_to_dispatch)
    elif to_retry:
        all_devs = await list_devices()
        dev_map = {d["hostname"]: d for d in all_devs}
        devs_to_poll = [dev_map[h] for h in to_retry if h in dev_map]
        _task = asyncio.create_task(_run_poll_task(run_id, devs_to_poll))  # noqa: RUF006

    return {"run_id": run_id, "status": "running", "retrying": to_retry}


@router.delete("/runs/{run_id}")
async def terminate_run(run_id: str) -> dict[str, Any]:
    """Terminate a run immediately."""
    record = await get_run(run_id)
    if record is None:
        raise HTTPException(status_code=404, detail=f"Run '{run_id}' not found")
    await set_run_paused(run_id, False)
    await update_run(
        run_id,
        status="terminated",
        finished_at=datetime.now(timezone.utc).isoformat(),
    )
    return {"run_id": run_id, "status": "terminated"}


# ---------------------------------------------------------------------------
# Schedule
# ---------------------------------------------------------------------------

@router.get("/schedule")
async def get_poll_schedule() -> dict:
    """Return the current poll schedule config."""
    return await get_schedule()


@router.put("/schedule")
async def put_poll_schedule(body: ScheduleConfig) -> dict[str, Any]:
    """Update the poll schedule config."""
    config = body.model_dump()
    await set_schedule(config)
    return {"stored": True, **config}


# ---------------------------------------------------------------------------
# Background standalone poll task
# ---------------------------------------------------------------------------

async def _run_poll_task(run_id: str, devices: list[dict]) -> None:
    """Background task: sequentially poll each device and ingest results.

    This runs only in standalone (non-clustered) mode.  In clustered mode
    the Redis worker processes handle actual collection.
    """
    for device in devices:
        hostname = device.get("hostname", "unknown")

        # Honour pause flag before each device
        if await is_run_paused(run_id):
            logger.info("Poll run %s paused before %s", run_id, hostname)
            # Wait until resumed or terminated
            while await is_run_paused(run_id):
                run_record = await get_run(run_id)
                if run_record and run_record.get("status") == "terminated":
                    return
                await asyncio.sleep(2)

        run_record = await get_run(run_id)
        if run_record and run_record.get("status") == "terminated":
            return

        await update_device_in_run(run_id, hostname, "running")
        try:
            # Real SSH collection happens here in production; in standalone
            # mode we attempt it but gracefully handle missing credentials.
            result = await asyncio.to_thread(_collect_device_sync, device)
            if result:
                logger.info("Poll run %s: %s collected successfully", run_id, hostname)
            await update_device_in_run(run_id, hostname, "completed")
        except Exception as exc:
            logger.warning("Poll run %s: %s failed: %s", run_id, hostname, exc)
            await update_device_in_run(run_id, hostname, "failed")

    await update_run(
        run_id,
        status="completed",
        finished_at=datetime.now(timezone.utc).isoformat(),
    )


def _collect_device_sync(device: dict) -> bool:
    """Synchronous collection attempt for a single device.

    Uses the CLI collect flow (netmiko → parser → ingest).  Returns True on
    success, raises on failure.
    """
    try:
        from network_discovery.network_discovery.cli import (
            collect_and_ingest,  # type: ignore[import]
        )
        collect_and_ingest(device)
        return True
    except Exception:
        # Fall back to a simpler import path used in some installations
        pass

    try:
        from network_discovery.cli import collect_and_ingest  # type: ignore[import,attr-defined]
        collect_and_ingest(device)
        return True
    except ImportError:
        pass

    # No collection function available (e.g., demo/test environment)
    raise RuntimeError(
        f"collect_and_ingest not available for device '{device.get('hostname')}'. "
        "Install SSH dependencies: pip install 'meshoptixiq-network-discovery[ssh]'"
    )
