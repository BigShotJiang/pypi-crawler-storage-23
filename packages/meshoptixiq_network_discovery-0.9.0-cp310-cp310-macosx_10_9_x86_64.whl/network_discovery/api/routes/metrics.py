"""Prometheus metrics endpoint — requires [metrics] extra."""
from __future__ import annotations

import os
from datetime import date

from fastapi import APIRouter, Request
from fastapi.responses import Response

router = APIRouter(tags=["Metrics"])

try:
    from prometheus_client import (
        CONTENT_TYPE_LATEST,
        CollectorRegistry,
        Counter,
        Gauge,
        generate_latest,
    )

    _registry = CollectorRegistry(auto_describe=True)

    # License gauge
    _license_days = Gauge(
        "meshoptixiq_license_days_remaining",
        "Days until license expiry (-1 if no expiry date, -2 if demo mode)",
        labelnames=["plan"],
        registry=_registry,
    )

    # Request counter (populated by middleware in main.py)
    http_requests_total = Counter(
        "meshoptixiq_http_requests_total",
        "Total HTTP requests processed",
        labelnames=["method", "path", "status"],
        registry=_registry,
    )

    _METRICS_ENABLED = True
except ImportError:
    _METRICS_ENABLED = False
    http_requests_total = None  # sentinel — checked in middleware


def _update_license_gauge() -> None:
    """Refresh license gauge from cached values. Called on each scrape."""
    if not _METRICS_ENABLED:
        return
    from network_discovery.api.licensing import get_expiry, get_plan

    if os.environ.get("MESHOPTIXIQ_DEMO_MODE"):
        _license_days.labels(plan="community").set(-2)
        return

    plan = get_plan()
    expiry = get_expiry()
    if expiry:
        try:
            days = (date.fromisoformat(expiry) - date.today()).days
            _license_days.labels(plan=plan).set(days)
        except (TypeError, ValueError):
            _license_days.labels(plan=plan).set(-1)
    else:
        _license_days.labels(plan=plan).set(-1)


@router.get("/metrics", include_in_schema=False)
def metrics_endpoint(request: Request):
    """Prometheus metrics scrape endpoint.

    Unauthenticated by default (for Prometheus scrapers without header support).
    Set ``MESHQ_PROTECT_HEALTH=true`` to require the X-API-Key header.
    """
    if os.environ.get("MESHQ_PROTECT_HEALTH") == "true":
        from network_discovery.api.auth import _check_static_api_key
        _check_static_api_key(request)
    if not _METRICS_ENABLED:
        return Response(
            content="# prometheus-client not installed\n",
            media_type="text/plain",
            status_code=200,
        )
    _update_license_gauge()
    return Response(
        content=generate_latest(_registry),
        media_type=CONTENT_TYPE_LATEST,
    )
