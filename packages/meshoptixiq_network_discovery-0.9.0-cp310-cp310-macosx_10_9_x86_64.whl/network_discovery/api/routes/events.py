"""SSE event stream — pushes summary stats to connected clients.

Standalone mode (REDIS_URL unset):
  Each instance runs the summary_stats query every 30 s and pushes the result
  directly to connected clients.  Clients on different instances may see
  slightly different data.

Clustered mode (REDIS_URL set):
  Instances subscribe to the ``meshq:events`` Redis Pub/Sub channel.  The
  background collector (only one instance per lock cycle) publishes to that
  channel after each 5-min collection.  All SSE clients across all instances
  receive the same payload at the same time.

  To avoid the client waiting up to 5 min for the first event after connecting,
  the latest snapshot from ``meshq:snapshots`` is sent immediately on connect.

  A keepalive comment (``": keepalive"``) is emitted every 30 s between
  Pub/Sub messages to prevent proxy idle-timeout disconnects.
"""

import asyncio
import json
import logging

from fastapi import APIRouter, Request
from fastapi.responses import StreamingResponse

from network_discovery.api.dependencies import get_db_driver

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Events"])

_PUSH_INTERVAL = 30  # seconds (standalone mode)
_REDIS_EVENTS_CHANNEL = "meshq:events"
_REDIS_SNAPSHOTS_KEY = "meshq:snapshots"


async def _stats_payload() -> str:
    """Run the summary_stats query and return an SSE-formatted string."""
    try:
        from network_discovery.queries.executor import QueryExecutor
        provider = get_db_driver()
        executor = QueryExecutor(provider)
        result = executor.run("summary_stats", {}, limit=1, offset=0)
        row = result.rows[0] if result.rows else {}
        data = {
            "device_count":    row.get("device_count", 0),
            "interface_count": row.get("interface_count", 0),
            "endpoint_count":  row.get("endpoint_count", 0),
            "vlan_count":      row.get("vlan_count", 0),
        }
    except Exception as exc:
        logger.warning("SSE stats query failed: %s", exc)
        data = {}

    return f"event: stats\ndata: {json.dumps(data)}\n\n"


async def _standalone_generator(request: Request):
    """Standalone SSE generator — queries DB directly every 30 s."""
    yield await _stats_payload()
    while True:
        if await request.is_disconnected():
            break
        await asyncio.sleep(_PUSH_INTERVAL)
        if await request.is_disconnected():
            break
        try:
            yield await _stats_payload()
        except Exception as exc:
            logger.warning("SSE generator error: %s", exc)
            break


async def _clustered_generator(request: Request, r):
    """Clustered SSE generator — fans out via Redis Pub/Sub."""
    async with r.pubsub() as ps:
        await ps.subscribe(_REDIS_EVENTS_CHANNEL)

        # Send the latest snapshot immediately so the client isn't blank
        # until the next 5-min collection cycle.
        try:
            latest = await r.zrange(_REDIS_SNAPSHOTS_KEY, -1, -1)
            if latest:
                yield f"event: stats\ndata: {latest[0].decode()}\n\n"
        except Exception as exc:
            logger.warning("SSE: could not fetch latest snapshot from Redis: %s", exc)

        while True:
            if await request.is_disconnected():
                break
            try:
                msg = await ps.get_message(ignore_subscribe_messages=True, timeout=30)
            except Exception as exc:
                logger.warning("SSE Pub/Sub error: %s", exc)
                break

            if await request.is_disconnected():
                break

            if msg is None:
                # No message in the 30 s window — send keepalive comment
                yield ": keepalive\n\n"
            elif msg["type"] == "message":
                yield f"event: stats\ndata: {msg['data'].decode()}\n\n"


@router.get("")
async def event_stream(request: Request):
    """Server-Sent Events stream.

    In standalone mode emits ``event: stats`` with a JSON payload every 30 s.
    In clustered mode subscribes to the Redis Pub/Sub channel and forwards
    messages to the client; keepalives are sent every 30 s between events.

    Authentication is enforced by the router-level dependency
    (``require_api_key``).  Because ``EventSource`` cannot send custom headers
    the API key may be passed as the ``?api_key=`` query parameter.
    """
    from network_discovery.api.cluster import get_redis, is_clustered

    if is_clustered():
        r = await get_redis()
        if r is not None:
            return StreamingResponse(
                _clustered_generator(request, r),
                media_type="text/event-stream",
                headers={
                    "Cache-Control":    "no-cache",
                    "X-Accel-Buffering": "no",
                    "Connection":       "keep-alive",
                },
            )

    # Standalone fallback
    return StreamingResponse(
        _standalone_generator(request),
        media_type="text/event-stream",
        headers={
            "Cache-Control":    "no-cache",
            "X-Accel-Buffering": "no",
            "Connection":       "keep-alive",
        },
    )
