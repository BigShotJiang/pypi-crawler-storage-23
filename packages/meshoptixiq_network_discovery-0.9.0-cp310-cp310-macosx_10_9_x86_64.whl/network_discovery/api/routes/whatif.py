"""What-if graph analysis endpoint.

POST /graph/whatif — simulate ingesting a proposed NetworkFacts payload into a
temporary in-memory graph and return the delta versus the current network state.

Requires pro+ license (``advanced_queries`` feature flag).
Rate limited to 10 requests per minute per IP.
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel
from slowapi import Limiter
from slowapi.util import get_remote_address

from network_discovery.api.cluster import limiter_storage_uri
from network_discovery.api.snapshot_store import get_snapshots_async
from network_discovery.graph.inmemory_provider import InMemoryGraphProvider

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Graph"])

limiter = Limiter(
    key_func=get_remote_address,
    storage_uri=limiter_storage_uri(),
    in_memory_fallback_enabled=True,
)


class WhatIfRequest(BaseModel):
    """Partial NetworkFacts payload — any subset of fields may be provided."""

    devices: list[dict[str, Any]] = []
    interfaces: list[dict[str, Any]] = []
    ip_addresses: list[dict[str, Any]] = []
    subnets: list[dict[str, Any]] = []
    vlans: list[dict[str, Any]] = []
    macs: list[dict[str, Any]] = []
    endpoints: list[dict[str, Any]] = []
    firewall_rules: list[dict[str, Any]] = []
    address_objects: list[dict[str, Any]] = []
    service_objects: list[dict[str, Any]] = []


@router.post("/whatif")
@limiter.limit("10/minute")
async def graph_whatif(request: Request, body: WhatIfRequest):
    """Simulate ingesting a proposed network state and return the impact delta.

    Spins up a temporary in-memory graph, injects the proposed devices /
    interfaces / firewall rules, runs ``summary_stats``, then compares the
    result against the most recent snapshot to compute the delta.

    Requires ``pro+`` license (``advanced_queries`` feature).
    Rate limited to 10 requests per minute per IP.
    """
    # Feature gate — demo mode bypasses; stale compiled .so may not have the
    # demo bypass built in, so we check the env var here explicitly first.
    import os as _os
    if not _os.environ.get("MESHOPTIXIQ_DEMO_MODE"):
        try:
            from network_discovery.api.licensing import get_plan as _get_api_plan
            from network_discovery.licensing.gates import check_feature
            check_feature(_get_api_plan(), "whatif_simulation")
        except Exception as exc:
            if "FeatureNotAvailableError" in type(exc).__name__ or "not available" in str(exc).lower():
                raise HTTPException(
                    status_code=403,
                    detail="Feature 'whatif_simulation' requires a pro+ license.",
                )
            # Unexpected error — let it propagate

    # Build a fresh in-memory provider from the proposed payload
    provider = InMemoryGraphProvider()

    _fields = (
        "devices", "interfaces", "ip_addresses", "subnets",
        "vlans", "macs", "endpoints",
        "firewall_rules", "address_objects", "service_objects",
    )
    for field in _fields:
        items: list[dict] = getattr(body, field, [])
        if items:
            provider._data[field].extend(items)

    # Run summary stats on proposed state
    try:
        proposed_rows = provider.execute_query("summary_stats", "", {})
        proposed_stats = proposed_rows[0] if proposed_rows else {}
    except Exception as exc:
        logger.warning("whatif summary_stats failed: %s", exc)
        proposed_stats = {}

    proposed_device_count  = proposed_stats.get("device_count", 0)
    proposed_fw_count      = proposed_stats.get("firewall_rule_count", 0)

    # Proposed fingerprints (derived directly from the payload)
    proposed_device_hostnames = sorted(
        d.get("hostname", "") for d in body.devices if d.get("hostname")
    )
    proposed_rule_ids = sorted(
        f"{r.get('device_hostname','')}/{r.get('rule_name') or r.get('rule_id','')}"
        for r in body.firewall_rules
        if r.get("device_hostname")
    )

    # Current state — use the most recent snapshot
    snapshots = await get_snapshots_async(limit=1)
    latest = snapshots[-1] if snapshots else {}

    current_device_count = latest.get("device_count", 0)
    current_fw_count     = latest.get("firewall_rule_count", 0)
    current_device_hostnames = set(latest.get("device_hostnames", []))
    current_rule_ids         = set(latest.get("firewall_rule_ids", []))

    # Compute delta
    new_devices = sorted(
        h for h in proposed_device_hostnames if h not in current_device_hostnames
    )
    new_firewall_rules = sorted(
        r for r in proposed_rule_ids if r not in current_rule_ids
    )

    return {
        "proposed": {
            "device_count":        proposed_device_count,
            "firewall_rule_count": proposed_fw_count,
        },
        "current": {
            "device_count":        current_device_count,
            "firewall_rule_count": current_fw_count,
        },
        "delta": {
            "device_count":        proposed_device_count - current_device_count,
            "firewall_rule_count": proposed_fw_count - current_fw_count,
        },
        "new_devices":       new_devices,
        "new_firewall_rules": new_firewall_rules,
    }
