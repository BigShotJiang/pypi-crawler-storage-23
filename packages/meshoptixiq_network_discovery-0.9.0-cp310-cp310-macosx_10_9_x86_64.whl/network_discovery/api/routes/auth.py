"""Auth introspection routes — identity and token management."""

import os

from fastapi import APIRouter, Request

router = APIRouter(tags=["Auth"])


@router.get("/me")
async def get_current_user(request: Request) -> dict:
    """Return identity information for the current authenticated session.

    In ``api_key`` mode returns a static admin context.
    In ``pat`` mode returns the PAT user's context (includes scopes, token_id).
    In ``oidc`` / ``both`` mode returns claims extracted from the JWT.
    """
    user = getattr(request.state, "user", None)

    if user is not None:
        return {
            "sub":        getattr(user, "sub", "api_key_client"),
            "email":      getattr(user, "email", None),
            "roles":      getattr(user, "roles", ["admin"]),
            "groups":     getattr(user, "groups", []),
            "auth_method": getattr(user, "auth_method", "api_key"),
            "scopes":     getattr(user, "scopes", []),
            "token_id":   getattr(user, "token_id", None),
        }

    # Fallback — API-key mode without enterprise extras installed
    auth_mode = os.environ.get("AUTH_MODE", "api_key").lower()
    return {
        "sub":        "api_key_client",
        "email":      None,
        "roles":      ["admin"],
        "groups":     [],
        "auth_method": auth_mode,
        "scopes":     ["*"],
        "token_id":   None,
    }
