"""Persistent store for poll targets and run state.

Dual-mode:
- Redis (when ``is_clustered()`` is True): all state lives in Redis Hashes/Sets.
- Standalone: in-memory dicts, optionally flushed to ``POLL_STORE_PATH``
  (default ``/tmp/meshq_poll_store.json``) on every write.

Redis keys
----------
``meshq:poll_devices``   Hash  hostname → JSON device config
``meshq:poll_networks``  Set   CIDR strings
``meshq:poll_runs``      Hash  run_id → JSON run record
``meshq:poll_schedule``  String JSON schedule config
``meshq:run:{run_id}:paused``  String flag — present when run is paused
"""

from __future__ import annotations

import json
import logging
import os
import uuid
from datetime import datetime, timezone
from typing import Any

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Redis keys
# ---------------------------------------------------------------------------
_KEY_DEVICES   = "meshq:poll_devices"
_KEY_NETWORKS  = "meshq:poll_networks"
_KEY_RUNS      = "meshq:poll_runs"
_KEY_SCHEDULE  = "meshq:poll_schedule"

_DEFAULT_SCHEDULE: dict[str, Any] = {
    "enabled": False,
    "cron": "*/5 * * * *",
    "device_filter": [],
}

# ---------------------------------------------------------------------------
# Standalone in-memory fallback
# ---------------------------------------------------------------------------
_devices:  dict[str, dict]  = {}   # hostname → device config
_networks: set[str]         = set()
_runs:     dict[str, dict]  = {}   # run_id → run record
_schedule: dict[str, Any]   = dict(_DEFAULT_SCHEDULE)
_paused_runs: set[str]      = set()


def _store_path() -> str | None:
    return os.environ.get("POLL_STORE_PATH", "/tmp/meshq_poll_store.json")


def _persist() -> None:
    """Flush in-memory state to JSON file (best-effort)."""
    path = _store_path()
    if not path:
        return
    try:
        with open(path, "w") as f:
            json.dump(
                {
                    "devices": _devices,
                    "networks": list(_networks),
                    "runs": _runs,
                    "schedule": _schedule,
                },
                f,
                default=str,
            )
    except Exception as exc:
        logger.debug("collect_store: persist failed: %s", exc)


def _load() -> None:
    """Load state from JSON file on startup (best-effort)."""
    path = _store_path()
    if not path or not os.path.exists(path):
        return
    try:
        with open(path) as f:
            data = json.load(f)
        _devices.update(data.get("devices", {}))
        _networks.update(data.get("networks", []))
        _runs.update(data.get("runs", {}))
        _schedule.update(data.get("schedule", {}))
    except Exception as exc:
        logger.debug("collect_store: load failed: %s", exc)


# Load persisted state at import time
_load()


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


# ---------------------------------------------------------------------------
# Device management
# ---------------------------------------------------------------------------

async def list_devices() -> list[dict]:
    """Return all registered poll-target devices."""
    from network_discovery.api.cluster import get_redis, is_clustered
    if is_clustered():
        r = await get_redis()
        if r is not None:
            raw = await r.hgetall(_KEY_DEVICES)
            result = []
            for v in raw.values():
                try:
                    result.append(json.loads(v))
                except Exception:
                    pass
            return sorted(result, key=lambda d: d.get("hostname", ""))
    return sorted(_devices.values(), key=lambda d: d.get("hostname", ""))


async def upsert_device(config: dict) -> None:
    """Add or update a poll-target device. ``hostname`` is the key."""
    hostname = config.get("hostname", "")
    if not hostname:
        raise ValueError("device config must have a 'hostname' field")
    from network_discovery.api.cluster import get_redis, is_clustered
    if is_clustered():
        r = await get_redis()
        if r is not None:
            await r.hset(_KEY_DEVICES, hostname, json.dumps(config))
            return
    _devices[hostname] = config
    _persist()


async def delete_device(hostname: str) -> bool:
    """Remove a device. Returns True if it existed."""
    from network_discovery.api.cluster import get_redis, is_clustered
    if is_clustered():
        r = await get_redis()
        if r is not None:
            removed = await r.hdel(_KEY_DEVICES, hostname)
            return bool(removed)
    existed = hostname in _devices
    _devices.pop(hostname, None)
    if existed:
        _persist()
    return existed


# ---------------------------------------------------------------------------
# Network (CIDR) management
# ---------------------------------------------------------------------------

async def list_networks() -> list[str]:
    """Return all registered poll-target CIDRs."""
    from network_discovery.api.cluster import get_redis, is_clustered
    if is_clustered():
        r = await get_redis()
        if r is not None:
            raw = await r.smembers(_KEY_NETWORKS)
            return sorted(
                v.decode() if isinstance(v, bytes) else v for v in raw
            )
    return sorted(_networks)


async def add_network(cidr: str) -> None:
    """Register a CIDR string."""
    from network_discovery.api.cluster import get_redis, is_clustered
    if is_clustered():
        r = await get_redis()
        if r is not None:
            await r.sadd(_KEY_NETWORKS, cidr)
            return
    _networks.add(cidr)
    _persist()


async def delete_network(cidr: str) -> bool:
    """Remove a CIDR. Returns True if it existed."""
    from network_discovery.api.cluster import get_redis, is_clustered
    if is_clustered():
        r = await get_redis()
        if r is not None:
            removed = await r.srem(_KEY_NETWORKS, cidr)
            return bool(removed)
    existed = cidr in _networks
    _networks.discard(cidr)
    if existed:
        _persist()
    return existed


# ---------------------------------------------------------------------------
# Run management
# ---------------------------------------------------------------------------

async def create_run(devices: list[str], initiated_by: str = "ui") -> str:
    """Create a new poll run record. Returns the run_id (UUID4)."""
    run_id = str(uuid.uuid4())
    record: dict[str, Any] = {
        "run_id": run_id,
        "status": "pending",
        "started_at": _now_iso(),
        "finished_at": None,
        "devices": devices,
        "device_status": {h: "pending" for h in devices},
        "initiated_by": initiated_by,
    }
    from network_discovery.api.cluster import get_redis, is_clustered
    if is_clustered():
        r = await get_redis()
        if r is not None:
            await r.hset(_KEY_RUNS, run_id, json.dumps(record, default=str))
            return run_id
    _runs[run_id] = record
    _persist()
    return run_id


async def get_run(run_id: str) -> dict | None:
    """Fetch a run record by ID."""
    from network_discovery.api.cluster import get_redis, is_clustered
    if is_clustered():
        r = await get_redis()
        if r is not None:
            raw = await r.hget(_KEY_RUNS, run_id)
            if raw is None:
                return None
            return json.loads(raw)
    return _runs.get(run_id)


async def list_runs(limit: int = 20) -> list[dict]:
    """Return the most recent ``limit`` runs (newest first)."""
    from network_discovery.api.cluster import get_redis, is_clustered
    if is_clustered():
        r = await get_redis()
        if r is not None:
            raw = await r.hgetall(_KEY_RUNS)
            runs = []
            for v in raw.values():
                try:
                    runs.append(json.loads(v))
                except Exception:
                    pass
            runs.sort(key=lambda x: x.get("started_at", ""), reverse=True)
            return runs[:limit]
    all_runs = sorted(
        _runs.values(),
        key=lambda x: x.get("started_at", ""),
        reverse=True,
    )
    return all_runs[:limit]


async def update_run(run_id: str, **fields: Any) -> None:
    """Patch top-level fields on a run record."""
    from network_discovery.api.cluster import get_redis, is_clustered
    if is_clustered():
        r = await get_redis()
        if r is not None:
            raw = await r.hget(_KEY_RUNS, run_id)
            if raw is None:
                return
            record = json.loads(raw)
            record.update(fields)
            await r.hset(_KEY_RUNS, run_id, json.dumps(record, default=str))
            return
    if run_id not in _runs:
        return
    _runs[run_id].update(fields)
    _persist()


async def update_device_in_run(run_id: str, hostname: str, status: str) -> None:
    """Update the per-device status inside a run record."""
    from network_discovery.api.cluster import get_redis, is_clustered
    if is_clustered():
        r = await get_redis()
        if r is not None:
            raw = await r.hget(_KEY_RUNS, run_id)
            if raw is None:
                return
            record = json.loads(raw)
            record.setdefault("device_status", {})[hostname] = status
            await r.hset(_KEY_RUNS, run_id, json.dumps(record, default=str))
            return
    if run_id not in _runs:
        return
    _runs[run_id].setdefault("device_status", {})[hostname] = status
    _persist()


# ---------------------------------------------------------------------------
# Pause / resume flags (Redis: ephemeral string key; standalone: in-memory set)
# ---------------------------------------------------------------------------

async def is_run_paused(run_id: str) -> bool:
    from network_discovery.api.cluster import get_redis, is_clustered
    if is_clustered():
        r = await get_redis()
        if r is not None:
            return bool(await r.exists(f"meshq:run:{run_id}:paused"))
    return run_id in _paused_runs


async def set_run_paused(run_id: str, paused: bool) -> None:
    from network_discovery.api.cluster import get_redis, is_clustered
    key = f"meshq:run:{run_id}:paused"
    if is_clustered():
        r = await get_redis()
        if r is not None:
            if paused:
                await r.set(key, "1")
            else:
                await r.delete(key)
            return
    if paused:
        _paused_runs.add(run_id)
    else:
        _paused_runs.discard(run_id)


# ---------------------------------------------------------------------------
# Schedule
# ---------------------------------------------------------------------------

async def get_schedule() -> dict:
    """Return the current poll schedule config."""
    from network_discovery.api.cluster import get_redis, is_clustered
    if is_clustered():
        r = await get_redis()
        if r is not None:
            raw = await r.get(_KEY_SCHEDULE)
            if raw is None:
                return dict(_DEFAULT_SCHEDULE)
            return json.loads(raw)
    return dict(_schedule)


async def set_schedule(config: dict) -> None:
    """Persist poll schedule config."""
    from network_discovery.api.cluster import get_redis, is_clustered
    if is_clustered():
        r = await get_redis()
        if r is not None:
            await r.set(_KEY_SCHEDULE, json.dumps(config))
            return
    _schedule.clear()
    _schedule.update(config)
    _persist()
