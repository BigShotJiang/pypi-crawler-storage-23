"""Netmiko-based network device data collector.

Connects to devices defined in a YAML inventory, executes vendor-specific
commands, and persists raw CLI output as JSON files. No parsing occurs here.
"""

from __future__ import annotations

import json
import logging
import os
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml
from netmiko import ConnectHandler, NetmikoAuthenticationException, NetmikoTimeoutException

logger = logging.getLogger(__name__)

_MAX_CONNECT_RETRIES = 3
_RETRY_DELAY_SECONDS = 5

VENDORS_DIR = Path(__file__).resolve().parent.parent / "vendors"


def load_inventory(inventory_path: str | Path) -> list[dict[str, Any]]:
    """Load device inventory from a YAML file.

    Expected format:
        devices:
          - hostname: core-sw-01
            host: 192.168.1.1
            vendor: cisco_ios
            username: admin
            password_env: DEVICE_PASSWORD
            port: 22
    """
    path = Path(inventory_path)
    if not path.exists():
        raise FileNotFoundError(f"Inventory file not found: {path}")

    with open(path) as f:
        data = yaml.safe_load(f)

    if not isinstance(data, dict) or "devices" not in data:
        raise ValueError("Inventory must contain a 'devices' key")

    return data["devices"]


def load_discovery_config(config_path: str | Path) -> dict[str, Any]:
    """Load discovery configuration from a YAML file."""
    path = Path(config_path)
    if not path.exists():
        # Fallback to inventory if discovery config doesn't exist
        return {}

    with open(path) as f:
        return yaml.safe_load(f) or {}


def load_vendor_commands(vendor: str) -> dict[str, Any]:
    """Load command map for a vendor from vendors/<vendor>/commands.yaml."""
    commands_path = VENDORS_DIR / vendor / "commands.yaml"
    if not commands_path.exists():
        raise FileNotFoundError(f"No command map for vendor '{vendor}': {commands_path}")

    with open(commands_path) as f:
        return yaml.safe_load(f)


def collect_device(device_entry: dict[str, Any]) -> dict[str, Any]:
    """Connect to a single device and collect raw CLI output.

    Returns a dict with device metadata and raw command outputs.
    Does not parse any output.
    """
    hostname = device_entry["hostname"]
    vendor = device_entry["vendor"]
    host = device_entry.get("host", hostname)
    username = device_entry.get("username", "admin")
    port = device_entry.get("port", 22)

    # Resolve password from environment variable
    password_env = device_entry.get("password_env", "DEVICE_PASSWORD")
    password = os.environ.get(password_env, "")
    if not password:
        logger.warning("No password found in env var '%s' for device '%s'", password_env, hostname)

    vendor_commands = load_vendor_commands(vendor)
    device_type = vendor_commands["device_type"]

    collected_at = datetime.now(timezone.utc).isoformat()
    raw_outputs: dict[str, str] = {}

    connection_params = {
        "device_type": device_type,
        "host": host,
        "username": username,
        "password": password,
        "port": port,
    }

    # Add optional SSH key if specified
    if "key_file" in device_entry:
        connection_params["key_file"] = device_entry["key_file"]

    for attempt in range(1, _MAX_CONNECT_RETRIES + 1):
        try:
            logger.info(
                "Connecting to %s (%s) at %s:%d (attempt %d/%d)",
                hostname, vendor, host, port, attempt, _MAX_CONNECT_RETRIES,
            )
            connection = ConnectHandler(**connection_params)

            for cmd_entry in vendor_commands["commands"]:
                command = cmd_entry["command"]
                try:
                    logger.info("  Running: %s", command)
                    output = connection.send_command(command)
                    raw_outputs[command] = output
                except Exception as e:
                    logger.error("  Failed command '%s' on %s: %s", command, hostname, e)
                    raw_outputs[command] = f"ERROR: {e}"

            connection.disconnect()
            logger.info("Disconnected from %s", hostname)
            break  # Success — exit retry loop

        except NetmikoAuthenticationException:
            logger.error("Authentication failed for %s at %s:%d", hostname, host, port)
            break  # Auth errors are not retryable

        except NetmikoTimeoutException:
            logger.error(
                "Connection timeout for %s at %s:%d (attempt %d/%d)",
                hostname, host, port, attempt, _MAX_CONNECT_RETRIES,
            )
            if attempt < _MAX_CONNECT_RETRIES:
                delay = _RETRY_DELAY_SECONDS * attempt
                logger.info("Retrying %s in %ds ...", hostname, delay)
                time.sleep(delay)

        except Exception as e:
            logger.error("Unexpected error connecting to %s: %s", hostname, e)
            if attempt < _MAX_CONNECT_RETRIES:
                delay = _RETRY_DELAY_SECONDS * attempt
                logger.info("Retrying %s in %ds ...", hostname, delay)
                time.sleep(delay)

    return {
        "device": hostname,
        "vendor": vendor,
        "collected_at": collected_at,
        "raw_outputs": raw_outputs,
    }


def save_raw_output(result: dict[str, Any], output_dir: str | Path) -> Path:
    """Save raw collection result to a JSON file."""
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    hostname = result["device"]
    timestamp = result["collected_at"].replace(":", "-").replace("+", "p")
    filename = f"{hostname}_{timestamp}.json"
    filepath = output_path / filename

    with open(filepath, "w") as f:
        json.dump(result, f, indent=2)

    logger.info("Saved raw output to %s", filepath)
    return filepath


def collect_all(
    inventory_path: str | Path,
    output_dir: str | Path = "output/raw",
    workers: int = 10,
) -> list[Path]:
    """Run collection for all devices in inventory or discovery config.

    Devices are collected concurrently using a thread pool (SSH is I/O-bound).
    One device failure does not block the rest.

    Args:
        inventory_path: Path to inventory YAML or discovery config directory.
        output_dir: Directory to write raw JSON output files.
        workers: Maximum number of concurrent SSH sessions (default 10).

    Returns:
        List of paths to saved raw output files.
    """
    # 1. Try to load static inventory
    try:
        devices = load_inventory(inventory_path)
    except FileNotFoundError:
        devices = []
    except ValueError:
        devices = []

    # 2. Try to load discovery config (sibling of inventory)
    discovery_path = Path(inventory_path).parent / "discovery.yaml"
    if discovery_path.exists():
        logger.info("Found discovery config at %s", discovery_path)
        from network_discovery.scanner import NetworkScanner

        config = load_discovery_config(discovery_path).get("discovery", {})
        if config:
            scanner = NetworkScanner(config)
            discovered_devices = scanner.scan()

            # Merge discovered devices, avoiding duplicates based on IP/Host
            existing_hosts = {d.get("host", d.get("hostname")) for d in devices}

            for d in discovered_devices:
                if d["host"] not in existing_hosts:
                    # Inject default credentials
                    d["username"] = config.get("credentials", {}).get("username", "admin")
                    d["password_env"] = config.get("credentials", {}).get("password_env", "DEVICE_PASSWORD")
                    devices.append(d)

    if not devices:
        logger.warning("No devices found in inventory or discovery.")
        return []

    logger.info("Collecting from %d device(s) with up to %d concurrent workers", len(devices), workers)

    saved_files: list[Path] = []

    with ThreadPoolExecutor(max_workers=workers) as executor:
        future_to_host = {
            executor.submit(collect_device, entry): entry.get("hostname", "unknown")
            for entry in devices
        }
        for future in as_completed(future_to_host):
            hostname = future_to_host[future]
            try:
                result = future.result()
                if result["raw_outputs"]:
                    filepath = save_raw_output(result, output_dir)
                    saved_files.append(filepath)
                    logger.info("Collected %s (%d commands)", hostname, len(result["raw_outputs"]))
                else:
                    logger.warning("No output collected from %s", hostname)
            except Exception as e:
                logger.error("Collection failed for %s: %s", hostname, e)

    logger.info("Collection complete: %d/%d devices saved", len(saved_files), len(devices))
    return saved_files
