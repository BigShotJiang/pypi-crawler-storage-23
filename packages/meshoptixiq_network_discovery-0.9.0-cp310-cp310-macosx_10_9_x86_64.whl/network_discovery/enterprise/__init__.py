"""Enterprise features package — secrets, OIDC auth, audit logging, observability."""
