"""Audit middleware — structured audit events shipped to multiple SIEM targets.

Targets (all active simultaneously if configured):
1. **Splunk HEC**     — ``SPLUNK_HEC_URL`` + ``SPLUNK_HEC_TOKEN``
2. **Elasticsearch**  — ``ELASTICSEARCH_URL`` (+ optional ``ELASTICSEARCH_API_KEY``)
3. **OpenSearch**     — ``OPENSEARCH_URL`` (+ optional ``OPENSEARCH_USERNAME``/``OPENSEARCH_PASSWORD``)
4. **Webhook**        — ``AUDIT_WEBHOOK_URL`` (+ optional ``AUDIT_WEBHOOK_TOKEN``)
5. **Structured stdout** — always written when ``AUDIT_LOG_ENABLED=true``

Event schema::

    {
        "event":        "query_executed",
        "timestamp":    "2026-02-22T10:30:00Z",
        "request_id":   "uuid",
        "client_ip":    "10.0.0.1",
        "user":         "alice@corp.com",   # JWT sub or "api_key_client"
        "method":       "POST",
        "path":         "/queries/topology_summary/execute",
        "query_name":   "topology_summary",
        "status":       200,
        "row_count":    42,
        "elapsed_ms":   85.3
    }
"""

import json
import logging
import os
import time
import uuid
from datetime import datetime, timezone
from typing import Any

import httpx
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
_AUDIT_ENABLED = os.environ.get("AUDIT_LOG_ENABLED", "false").lower() == "true"

_SPLUNK_HEC_URL: str | None = os.environ.get("SPLUNK_HEC_URL")
_SPLUNK_HEC_TOKEN: str | None = os.environ.get("SPLUNK_HEC_TOKEN")
_SPLUNK_INDEX: str = os.environ.get("SPLUNK_INDEX", "meshoptixiq")
_SPLUNK_SOURCETYPE: str = os.environ.get("SPLUNK_SOURCETYPE", "meshoptixiq:api")

_ES_URL: str | None = os.environ.get("ELASTICSEARCH_URL")
_ES_API_KEY: str | None = os.environ.get("ELASTICSEARCH_API_KEY")
_ES_INDEX: str = os.environ.get("ELASTICSEARCH_INDEX", "meshoptixiq-audit")

_OS_URL: str | None = os.environ.get("OPENSEARCH_URL")
_OS_USERNAME: str | None = os.environ.get("OPENSEARCH_USERNAME")
_OS_PASSWORD: str | None = os.environ.get("OPENSEARCH_PASSWORD")
_OS_INDEX: str = os.environ.get("OPENSEARCH_INDEX", "meshoptixiq-audit")

_WEBHOOK_URL: str | None = os.environ.get("AUDIT_WEBHOOK_URL")
_WEBHOOK_TOKEN: str | None = os.environ.get("AUDIT_WEBHOOK_TOKEN")

# ---------------------------------------------------------------------------
# Lazy-initialised backend clients
# ---------------------------------------------------------------------------
_es_client: Any = None
_os_client: Any = None


def _get_es_client() -> Any:
    global _es_client
    if _es_client is None:
        from elasticsearch import Elasticsearch  # type: ignore[import-untyped]

        kwargs: dict[str, Any] = {}
        if _ES_API_KEY:
            kwargs["api_key"] = _ES_API_KEY
        _es_client = Elasticsearch(_ES_URL, **kwargs)
    return _es_client


def _get_os_client() -> Any:
    global _os_client
    if _os_client is None:
        from opensearchpy import OpenSearch  # type: ignore[import-untyped]

        auth = (_OS_USERNAME, _OS_PASSWORD) if _OS_USERNAME and _OS_PASSWORD else None
        _os_client = OpenSearch(
            hosts=[_OS_URL],
            http_auth=auth,
            use_ssl=(_OS_URL or "").startswith("https"),
            verify_certs=True,
        )
    return _os_client


# ---------------------------------------------------------------------------
# Shipping helpers
# ---------------------------------------------------------------------------

def _ship_to_splunk(event: dict[str, Any]) -> None:
    if not (_SPLUNK_HEC_URL and _SPLUNK_HEC_TOKEN):
        return
    payload = {
        "time": time.time(),
        "host": os.environ.get("HOSTNAME", "meshoptixiq"),
        "source": "meshoptixiq-api",
        "sourcetype": _SPLUNK_SOURCETYPE,
        "index": _SPLUNK_INDEX,
        "event": event,
    }
    try:
        resp = httpx.post(
            _SPLUNK_HEC_URL,
            json=payload,
            headers={"Authorization": f"Splunk {_SPLUNK_HEC_TOKEN}"},
            timeout=5,
        )
        resp.raise_for_status()
    except Exception as exc:
        logger.warning("Splunk HEC shipping failed: %s", exc)


def _ship_to_elasticsearch(event: dict[str, Any]) -> None:
    if not _ES_URL:
        return
    try:
        client = _get_es_client()
        client.index(index=_ES_INDEX, document=event)
    except Exception as exc:
        logger.warning("Elasticsearch audit shipping failed: %s", exc)


def _ship_to_opensearch(event: dict[str, Any]) -> None:
    if not _OS_URL:
        return
    try:
        client = _get_os_client()
        client.index(index=_OS_INDEX, body=event)
    except Exception as exc:
        logger.warning("OpenSearch audit shipping failed: %s", exc)


def _ship_to_webhook(event: dict[str, Any]) -> None:
    if not _WEBHOOK_URL:
        return
    headers: dict[str, str] = {"Content-Type": "application/json"}
    if _WEBHOOK_TOKEN:
        headers["Authorization"] = f"Bearer {_WEBHOOK_TOKEN}"
    try:
        resp = httpx.post(_WEBHOOK_URL, json=event, headers=headers, timeout=5)
        resp.raise_for_status()
    except Exception as exc:
        logger.warning("Audit webhook shipping failed: %s", exc)


# ---------------------------------------------------------------------------
# Middleware
# ---------------------------------------------------------------------------

class AuditMiddleware(BaseHTTPMiddleware):
    """Emit structured audit events after requests to protected endpoints."""

    async def dispatch(self, request: Request, call_next) -> Response:
        start = time.perf_counter()
        response = await call_next(request)
        elapsed_ms = (time.perf_counter() - start) * 1000

        # Only audit query endpoints
        if not request.url.path.startswith("/queries/"):
            return response

        if not _AUDIT_ENABLED:
            return response

        # Extract user identity (set by OIDC dep or default)
        user_obj = getattr(request.state, "user", None)
        if user_obj is not None:
            user_identity = getattr(user_obj, "sub", "api_key_client")
        else:
            user_identity = "api_key_client"

        # Derive query name from path: /queries/{name}/execute → name
        path_parts = request.url.path.strip("/").split("/")
        query_name = path_parts[1] if len(path_parts) > 1 else ""

        row_count: int | None = None
        try:
            row_count = int(response.headers.get("X-Row-Count", ""))
        except (ValueError, TypeError):
            pass

        event: dict[str, Any] = {
            "event": "query_executed",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "request_id": getattr(request.state, "request_id", str(uuid.uuid4())),
            "client_ip": request.client.host if request.client else "unknown",
            "user": user_identity,
            "method": request.method,
            "path": request.url.path,
            "query_name": query_name,
            "status": response.status_code,
            "row_count": row_count,
            "elapsed_ms": round(elapsed_ms, 2),
        }

        # Structured stdout (always when enabled)
        logger.info("AUDIT %s", json.dumps(event))

        # Ship to configured backends
        _ship_to_splunk(event)
        _ship_to_elasticsearch(event)
        _ship_to_opensearch(event)
        _ship_to_webhook(event)

        # Microsoft Teams audit notification
        if os.environ.get("TEAMS_AUDIT_WEBHOOK_URL"):
            try:
                from network_discovery.enterprise.integrations.teams import send_audit_event
                send_audit_event(event)
            except ImportError:
                pass

        # Microsoft Sentinel / Log Analytics shipping
        if os.environ.get("SENTINEL_WORKSPACE_ID"):
            try:
                from network_discovery.enterprise.integrations.sentinel import ship_to_sentinel
                ship_to_sentinel(event)
            except ImportError:
                pass

        # SOAR / automation trigger (enterprise integrations — no-op if not configured)
        try:
            from network_discovery.enterprise.integrations.soar import (
                _soar_rules,
                dispatch_soar,
                evaluate_rules,
            )
            matched = evaluate_rules(event, _soar_rules)
            if matched:
                dispatch_soar(event, matched)
        except ImportError:
            pass

        return response
