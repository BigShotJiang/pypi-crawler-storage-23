"""OIDC/JWT authentication FastAPI dependency with JWKS caching.

Controlled by the ``AUTH_MODE`` environment variable:

- ``api_key``  — standard X-API-Key only (this module is not used)
- ``oidc``     — Bearer JWT required; X-API-Key rejected
- ``both``     — accepts a valid Bearer JWT **or** a valid X-API-Key

Required env vars::

    OIDC_DISCOVERY_URL   https://company.okta.com/.well-known/openid-configuration
    OIDC_CLIENT_ID       audience claim to validate
    OIDC_REQUIRED_SCOPES optional comma-separated required scopes (e.g. "read:queries")
"""

import logging
import os
import time
from dataclasses import dataclass, field
from typing import Any

import httpx
from fastapi import HTTPException, Request, Security
from fastapi.security import APIKeyHeader, HTTPAuthorizationCredentials, HTTPBearer

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
_DISCOVERY_URL: str = os.environ.get("OIDC_DISCOVERY_URL", "")
_CLIENT_ID: str = os.environ.get("OIDC_CLIENT_ID", "")
_REQUIRED_SCOPES: list[str] = [
    s.strip()
    for s in os.environ.get("OIDC_REQUIRED_SCOPES", "").split(",")
    if s.strip()
]
_JWKS_TTL: int = 3600  # 1 hour

# ---------------------------------------------------------------------------
# JWKS cache
# ---------------------------------------------------------------------------
_jwks_uri: str | None = None
_jwks_cache: dict[str, Any] | None = None
_jwks_fetched_at: float = 0.0


def _fetch_discovery() -> str:
    """Fetch OIDC discovery document and return ``jwks_uri``."""
    global _jwks_uri
    if _jwks_uri:
        return _jwks_uri
    if not _DISCOVERY_URL:
        raise RuntimeError(
            "OIDC_DISCOVERY_URL is not set. Required when AUTH_MODE=oidc or AUTH_MODE=both."
        )
    resp = httpx.get(_DISCOVERY_URL, timeout=10)
    resp.raise_for_status()
    _jwks_uri = resp.json()["jwks_uri"]
    logger.info("OIDC discovery loaded; jwks_uri=%s", _jwks_uri)
    return _jwks_uri


def _get_jwks() -> dict[str, Any]:
    """Return cached JWKS, refreshing if the TTL has expired."""
    global _jwks_cache, _jwks_fetched_at
    now = time.monotonic()
    if _jwks_cache is None or (now - _jwks_fetched_at) > _JWKS_TTL:
        jwks_uri = _fetch_discovery()
        resp = httpx.get(jwks_uri, timeout=10)
        resp.raise_for_status()
        _jwks_cache = resp.json()
        _jwks_fetched_at = now
        logger.debug("JWKS refreshed from %s", jwks_uri)
    return _jwks_cache


# ---------------------------------------------------------------------------
# UserContext
# ---------------------------------------------------------------------------
@dataclass
class UserContext:
    """Authenticated user identity extracted from a JWT."""

    sub: str
    email: str | None = None
    roles: list[str] = field(default_factory=list)
    groups: list[str] = field(default_factory=list)
    scopes: list[str] = field(default_factory=list)
    raw_claims: dict[str, Any] = field(default_factory=dict)
    auth_method: str = "oidc"  # "oidc" | "api_key"


# ---------------------------------------------------------------------------
# Bearer security scheme
# ---------------------------------------------------------------------------
_bearer = HTTPBearer(auto_error=False)
_api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)

_AUTH_MODE = os.environ.get("AUTH_MODE", "api_key").lower()
_API_KEY: str | None = os.environ.get("API_KEY")


def _validate_jwt(token: str) -> UserContext:
    """Decode and validate a JWT Bearer token.

    Performs: signature verification, ``exp``, ``iss``, ``aud`` checks.
    Raises ``HTTPException(401)`` on any failure.
    """
    try:
        from authlib.jose import JsonWebKey, jwt  # type: ignore[import-untyped]
    except ImportError as exc:
        raise RuntimeError(
            "OIDC JWT validation requires 'authlib'. "
            "Install with: pip install authlib>=1.3"
        ) from exc

    jwks = _get_jwks()
    key_set = JsonWebKey.import_key_set(jwks)

    try:
        claims = jwt.decode(token, key_set)
    except Exception:
        # kid not found — force JWKS refresh once and retry
        global _jwks_cache
        _jwks_cache = None
        jwks = _get_jwks()
        key_set = JsonWebKey.import_key_set(jwks)
        try:
            claims = jwt.decode(token, key_set)
        except Exception as exc:
            logger.warning("JWT decode failed: %s", exc)
            raise HTTPException(status_code=401, detail="Invalid or expired token") from exc

    try:
        claims.validate_exp()
        claims.validate_iss(_DISCOVERY_URL.split("/.well-known")[0])
        claims.validate_aud(_CLIENT_ID)
    except Exception as exc:
        logger.warning("JWT claim validation failed: %s", exc)
        raise HTTPException(status_code=401, detail="Token claim validation failed")

    # Convert to plain dict — authlib JWTClaims must not be mutated in-place
    _claims_data: dict = dict(claims)
    if os.environ.get("ENTRA_TENANT_ID") or os.environ.get("ENTRA_CLIENT_ID"):
        from network_discovery.enterprise.auth.entra import normalize_entra_claims
        _claims_data = normalize_entra_claims(_claims_data)

    # Scope check
    token_scopes = _claims_data.get("scope", "").split() or _claims_data.get("scp", [])
    if isinstance(token_scopes, str):
        token_scopes = token_scopes.split()
    if _REQUIRED_SCOPES and not all(s in token_scopes for s in _REQUIRED_SCOPES):
        missing = [s for s in _REQUIRED_SCOPES if s not in token_scopes]
        raise HTTPException(
            status_code=403,
            detail=f"Missing required scopes: {missing}",
        )

    return UserContext(
        sub=_claims_data.get("sub", ""),
        email=_claims_data.get("email"),
        roles=_claims_data.get("roles", []) or _claims_data.get("role", []),
        groups=_claims_data.get("groups", []),
        scopes=list(token_scopes),
        raw_claims=dict(claims),
    )


async def require_auth(
    request: Request,
    credentials: HTTPAuthorizationCredentials | None = Security(_bearer),
    api_key: str | None = Security(_api_key_header),
) -> None:
    """FastAPI dependency that enforces OIDC or combined auth.

    Attaches a ``UserContext`` to ``request.state.user`` for downstream use
    (e.g., audit logging).
    """
    client_ip = request.client.host if request.client else "unknown"

    if _AUTH_MODE == "oidc":
        if not credentials or credentials.scheme.lower() != "bearer":
            raise HTTPException(
                status_code=401,
                detail="Bearer token required. X-API-Key is not accepted in OIDC mode.",
                headers={"WWW-Authenticate": "Bearer"},
            )
        user = _validate_jwt(credentials.credentials)
        request.state.user = user
        return

    if _AUTH_MODE == "both":
        # Try Bearer first
        if credentials and credentials.scheme.lower() == "bearer":
            user = _validate_jwt(credentials.credentials)
            request.state.user = user
            return
        # Fall back to API key
        if api_key and _API_KEY and api_key == _API_KEY:
            request.state.user = UserContext(
                sub="api_key_client",
                auth_method="api_key",
            )
            return
        logger.warning(
            "Authentication failure from %s — path: %s", client_ip, request.url.path
        )
        raise HTTPException(
            status_code=401,
            detail="Provide a valid Bearer token or X-API-Key header.",
            headers={"WWW-Authenticate": "Bearer"},
        )

    # Should not reach here in normal flow
    raise HTTPException(status_code=401, detail="Authentication required")
