"""Microsoft Entra ID (Azure AD) OIDC normalization layer.

Sits between authlib's ``JWTClaims`` object and ``UserContext`` construction in
``oidc.py``.  Handles the quirks of Entra ID tokens:

- ``preferred_username`` used instead of ``email``
- ``scp`` string (delegated permissions) instead of ``scope``
- ``roles`` contains Azure AD App Role names (not meshq role strings)
- ``groups`` contains GUIDs instead of friendly names

Environment variables::

    ENTRA_TENANT_ID       Azure AD tenant (e.g. contoso.onmicrosoft.com or a GUID)
    ENTRA_CLIENT_ID       Azure AD application client ID (GUID)
    ENTRA_ROLE_MAPPING    JSON: {"AzureRoleName": "meshq_role", ...}
    ENTRA_GROUP_MAPPING   JSON: {"<guid>": "friendly_name", ...}
"""

import json
import logging
import os
from typing import Any

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Module-level config (supports importlib.reload() in tests)
# ---------------------------------------------------------------------------

_role_mapping: dict[str, str] = {}
_raw_role_map = os.environ.get("ENTRA_ROLE_MAPPING", "")
if _raw_role_map:
    try:
        _role_mapping = json.loads(_raw_role_map)
    except json.JSONDecodeError as _exc:
        logger.error("ENTRA_ROLE_MAPPING is not valid JSON: %s", _exc)

_group_mapping: dict[str, str] = {}
_raw_group_map = os.environ.get("ENTRA_GROUP_MAPPING", "")
if _raw_group_map:
    try:
        _group_mapping = json.loads(_raw_group_map)
    except json.JSONDecodeError as _exc:
        logger.error("ENTRA_GROUP_MAPPING is not valid JSON: %s", _exc)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def configure_entra_oidc() -> None:
    """Auto-configure OIDC env vars from ENTRA_* vars.

    Sets ``OIDC_DISCOVERY_URL`` (from ``ENTRA_TENANT_ID``) and
    ``OIDC_CLIENT_ID`` (from ``ENTRA_CLIENT_ID``) in ``os.environ`` using
    setdefault semantics — existing values are never overwritten.

    Also directly patches ``oidc._DISCOVERY_URL`` and ``oidc._CLIENT_ID``
    module globals, because ``oidc.py`` captures them at import time before
    ``_validate_config()`` runs.
    """
    tenant_id = os.environ.get("ENTRA_TENANT_ID", "")
    client_id = os.environ.get("ENTRA_CLIENT_ID", "")

    if tenant_id:
        discovery_url = (
            f"https://login.microsoftonline.com/{tenant_id}"
            "/v2.0/.well-known/openid-configuration"
        )
        os.environ.setdefault("OIDC_DISCOVERY_URL", discovery_url)

    if client_id:
        os.environ.setdefault("OIDC_CLIENT_ID", client_id)

    # Patch oidc module globals (captured at import time — env vars alone are too late)
    try:
        from network_discovery.enterprise.auth import oidc as _oidc_mod
        if tenant_id and not _oidc_mod._DISCOVERY_URL:
            _oidc_mod._DISCOVERY_URL = os.environ["OIDC_DISCOVERY_URL"]
        if client_id and not _oidc_mod._CLIENT_ID:
            _oidc_mod._CLIENT_ID = os.environ["OIDC_CLIENT_ID"]
    except ImportError:
        pass


def normalize_entra_claims(claims: dict[str, Any]) -> dict[str, Any]:
    """Normalize Entra ID token claims into meshq-compatible format.

    Receives a plain ``dict`` copy of authlib's ``JWTClaims`` — the original
    object must not be mutated.  Returns a new dict with normalizations applied.

    Normalizations:
    - ``preferred_username`` → ``email`` when ``email`` is absent
    - ``scp`` string → ``scope`` string (fixes delegated scope detection)
    - ``roles`` list → mapped via ``ENTRA_ROLE_MAPPING`` env var
    - ``groups`` list → mapped via ``ENTRA_GROUP_MAPPING`` env var
    """
    # Work on a shallow copy so callers are not surprised
    result = dict(claims)

    # 1. preferred_username → email
    if not result.get("email") and result.get("preferred_username"):
        result["email"] = result["preferred_username"]

    # 2. scp string → scope (Entra delegated permissions use "scp", not "scope")
    if "scp" in result and not result.get("scope"):
        result["scope"] = result["scp"]

    # 3. Map Azure AD App Role names → meshq role names
    raw_roles: list[str] = result.get("roles", []) or []
    if raw_roles and _role_mapping:
        result["roles"] = [_role_mapping.get(r, r) for r in raw_roles]

    # 4. Map group GUIDs → friendly names
    raw_groups: list[str] = result.get("groups", []) or []
    if raw_groups and _group_mapping:
        result["groups"] = [_group_mapping.get(g, g) for g in raw_groups]

    return result
