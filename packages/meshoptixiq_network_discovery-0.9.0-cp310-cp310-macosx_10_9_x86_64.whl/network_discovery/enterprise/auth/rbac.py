"""Role-Based Access Control (RBAC) for MeshOptixIQ query endpoints.

Policy is loaded from a YAML file (``RBAC_POLICY_FILE``) or an inline
YAML string (``RBAC_POLICY``).  If neither is set, all queries are
permitted (backward-compatible with API-key-only deployments).

Policy format::

    roles:
      admin:        ["*"]
      network-ops:  ["topology_*", "endpoints_*", "blast_radius_*"]
      security:     ["firewall_*", "path_analysis", "topology_summary"]
      helpdesk:     ["locate_endpoint_by_ip", "locate_endpoint_by_mac"]
    groups:
      network-team: ["*"]
      readonly:     ["topology_summary", "all_devices"]

Pattern matching uses ``fnmatch`` so ``*`` is a glob wildcard.

Hot-reload:
  File-based policy is re-read at most every ``RBAC_RELOAD_INTERVAL`` seconds
  (default 30) when the file mtime has changed.  Instant cross-instance
  propagation is available via ``POST /admin/rbac/reload`` which publishes to
  the ``meshq:rbac_reload`` Redis channel (cluster mode only).
"""

import logging
import os
import time
from fnmatch import fnmatch
from typing import Any

import yaml
from fastapi import HTTPException

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Policy state
# ---------------------------------------------------------------------------

_policy: dict[str, Any] = {}
_policy_file_mtime: float = 0.0
_policy_last_check: float = 0.0   # monotonic seconds of last check

_RELOAD_INTERVAL = float(os.environ.get("RBAC_RELOAD_INTERVAL", "30"))


def load_policy() -> dict[str, Any]:
    """Read and return the RBAC policy dict.

    Resolution order:
    1. ``RBAC_POLICY_FILE`` — path to a YAML file (polled every
       ``RBAC_RELOAD_INTERVAL`` seconds; reloaded when mtime changes).
    2. ``RBAC_POLICY``      — inline YAML string (loaded once).

    Returns an empty dict (allow-all) if neither variable is set.
    """
    global _policy, _policy_file_mtime, _policy_last_check

    now = time.monotonic()
    policy_file = os.environ.get("RBAC_POLICY_FILE")

    if policy_file:
        if now - _policy_last_check >= _RELOAD_INTERVAL:
            _policy_last_check = now
            try:
                mtime = os.path.getmtime(policy_file)
                if mtime != _policy_file_mtime:
                    with open(policy_file) as f:
                        _policy = yaml.safe_load(f) or {}
                    _policy_file_mtime = mtime
                    logger.info("RBAC policy reloaded from %s", policy_file)
            except OSError:
                logger.warning("RBAC policy file unreadable: %s", policy_file)
    elif _policy_last_check == 0.0:
        # Inline env var — load once on first call
        inline = os.environ.get("RBAC_POLICY")
        if inline:
            try:
                _policy = yaml.safe_load(inline) or {}
                logger.info("RBAC policy loaded from RBAC_POLICY env var")
            except Exception as exc:
                logger.error("Failed to parse RBAC_POLICY env var: %s", exc)
                _policy = {}
        else:
            _policy = {}
        _policy_last_check = now

    return _policy


def _reset_policy_cache() -> None:
    """Clear the cached policy — forces reload on next request.

    Used in tests and by ``POST /admin/rbac/reload``.
    """
    global _policy, _policy_file_mtime, _policy_last_check
    _policy = {}
    _policy_file_mtime = 0.0
    _policy_last_check = 0.0


# ---------------------------------------------------------------------------
# Permission check
# ---------------------------------------------------------------------------

def check_query_permission(user: Any, query_name: str) -> None:
    """Assert that *user* is permitted to execute *query_name*.

    Args:
        user:       A ``UserContext`` instance (or ``None`` for unauthenticated).
        query_name: The registry query name being executed.

    Raises:
        HTTPException(403): When the user has no role/group that permits the query.

    Note:
        If no policy is configured (``RBAC_POLICY_FILE`` / ``RBAC_POLICY`` are
        both unset), this function is a no-op — all queries are permitted.
    """
    policy = load_policy()
    if not policy:
        return

    roles_policy: dict[str, list[str]] = policy.get("roles", {})
    groups_policy: dict[str, list[str]] = policy.get("groups", {})

    user_roles: list[str] = getattr(user, "roles", []) if user else []
    user_groups: list[str] = getattr(user, "groups", []) if user else []

    for role in user_roles:
        patterns = roles_policy.get(role, [])
        for pattern in patterns:
            if fnmatch(query_name, pattern):
                return

    for group in user_groups:
        patterns = groups_policy.get(group, [])
        for pattern in patterns:
            if fnmatch(query_name, pattern):
                return

    logger.warning(
        "RBAC denied query '%s' for user '%s' (roles=%s, groups=%s)",
        query_name,
        getattr(user, "sub", "unknown"),
        user_roles,
        user_groups,
    )
    raise HTTPException(
        status_code=403,
        detail=f"missing permission: query:{query_name}",
    )
