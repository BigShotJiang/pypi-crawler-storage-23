"""Enterprise authentication package."""

from network_discovery.enterprise.auth.rbac import check_query_permission

__all__ = ["check_query_permission"]
