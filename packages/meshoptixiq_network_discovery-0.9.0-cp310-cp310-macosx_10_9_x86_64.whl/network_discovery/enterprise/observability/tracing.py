"""OpenTelemetry setup + FastAPI auto-instrumentation.

Exporter selection (checked in priority order):

1. **Datadog native** — ``DD_AGENT_HOST`` set → activates ``ddtrace``,
   patches all integrations, instruments FastAPI.
2. **New Relic native** — ``NEW_RELIC_LICENSE_KEY`` set → activates
   ``newrelic.agent``, wraps the ASGI app.
3. **OTLP** — ``OTEL_EXPORTER_OTLP_ENDPOINT`` set → configures the OTel SDK
   with an OTLP exporter (works with Datadog agent OTLP mode, New Relic OTLP
   ingest, Grafana Tempo, Jaeger, Splunk Observability, etc.).
4. No-op if none of the above are set.

Usage in ``api/main.py``::

    try:
        from network_discovery.enterprise.observability.tracing import setup_tracing
        setup_tracing(app)
        logger.info("Enterprise observability active")
    except ImportError:
        pass

Environment variables::

    DD_AGENT_HOST          Datadog agent host (enables ddtrace native mode)
    DD_SERVICE             Service name (default: meshoptixiq)
    DD_ENV                 Environment tag
    DD_VERSION             App version tag

    NEW_RELIC_LICENSE_KEY  New Relic ingest key (enables newrelic native mode)
    NEW_RELIC_APP_NAME     App name in New Relic UI

    OTEL_SERVICE_NAME                Service name (default: meshoptixiq)
    OTEL_EXPORTER_OTLP_ENDPOINT      e.g. http://otel-collector:4317
    OTEL_TRACES_EXPORTER             otlp | none
    OTEL_METRICS_EXPORTER            otlp | none
"""

import logging
import os
from typing import Any

logger = logging.getLogger(__name__)

_SERVICE_NAME = (
    os.environ.get("OTEL_SERVICE_NAME")
    or os.environ.get("DD_SERVICE")
    or os.environ.get("NEW_RELIC_APP_NAME")
    or "meshoptixiq"
)


def setup_tracing(app: Any) -> None:
    """Configure observability for the FastAPI *app*.

    Must be called **before** the first request is processed (i.e. during
    application startup / lifespan).
    """
    dd_agent_host = os.environ.get("DD_AGENT_HOST")
    nr_license_key = os.environ.get("NEW_RELIC_LICENSE_KEY")
    otlp_endpoint = os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT")

    if dd_agent_host:
        _setup_datadog(app, dd_agent_host)
    elif nr_license_key:
        _setup_newrelic(app, nr_license_key)
    elif otlp_endpoint:
        _setup_otlp(app, otlp_endpoint)
    else:
        logger.info(
            "No observability backend configured. "
            "Set DD_AGENT_HOST, NEW_RELIC_LICENSE_KEY, or OTEL_EXPORTER_OTLP_ENDPOINT."
        )


# ---------------------------------------------------------------------------
# Datadog native (ddtrace)
# ---------------------------------------------------------------------------

def _setup_datadog(app: Any, agent_host: str) -> None:
    """Activate ddtrace with FastAPI auto-instrumentation."""
    try:
        import ddtrace  # type: ignore[import-untyped]
        from ddtrace.contrib.fastapi import patch as patch_fastapi  # type: ignore[import-untyped]
    except ImportError as exc:
        raise ImportError(
            "DD_AGENT_HOST is set but 'ddtrace' is not installed. "
            "Install with: pip install ddtrace>=2.0"
        ) from exc

    os.environ.setdefault("DD_SERVICE", _SERVICE_NAME)
    ddtrace.patch_all()
    patch_fastapi()
    logger.info(
        "Datadog APM active (agent: %s, service: %s, env: %s)",
        agent_host,
        os.environ.get("DD_SERVICE", _SERVICE_NAME),
        os.environ.get("DD_ENV", ""),
    )


# ---------------------------------------------------------------------------
# New Relic native
# ---------------------------------------------------------------------------

def _setup_newrelic(app: Any, license_key: str) -> None:
    """Activate New Relic APM agent."""
    try:
        import newrelic.agent  # type: ignore[import-untyped]
    except ImportError as exc:
        raise ImportError(
            "NEW_RELIC_LICENSE_KEY is set but 'newrelic' is not installed. "
            "Install with: pip install newrelic>=9.0"
        ) from exc

    app_name = os.environ.get("NEW_RELIC_APP_NAME", _SERVICE_NAME)
    newrelic.agent.initialize(
        config_file=None,
        environment=None,
        ignore_errors=False,
        log_file="stderr",
        log_level=logging.WARNING,
        ignore_status_codes=None,
        app_name=app_name,
        license_key=license_key,
        ssl=True,
        host=None,
        port=None,
        proxy_scheme=None,
        proxy_host=None,
        proxy_port=None,
        proxy_user=None,
        proxy_pass=None,
        timeout=30,
        shutdown_timeout=30,
    )
    # Wrap ASGI app
    app.router.on_startup.insert(0, lambda: None)  # ensure app is initialised
    logger.info("New Relic APM active (app: %s)", app_name)


# ---------------------------------------------------------------------------
# OTLP (OpenTelemetry)
# ---------------------------------------------------------------------------

def _setup_otlp(app: Any, endpoint: str) -> None:
    """Configure OTel SDK with OTLP exporter and FastAPI auto-instrumentation."""
    try:
        from opentelemetry import trace  # type: ignore[import-untyped]
        from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import (  # type: ignore[import-untyped]
            OTLPSpanExporter,
        )
        from opentelemetry.instrumentation.fastapi import (
            FastAPIInstrumentor,  # type: ignore[import-untyped]
        )
        from opentelemetry.sdk.resources import Resource  # type: ignore[import-untyped]
        from opentelemetry.sdk.trace import TracerProvider  # type: ignore[import-untyped]
        from opentelemetry.sdk.trace.export import (
            BatchSpanProcessor,  # type: ignore[import-untyped]
        )
    except ImportError as exc:
        raise ImportError(
            "OTEL_EXPORTER_OTLP_ENDPOINT is set but OTel packages are not installed. "
            "Install with: pip install opentelemetry-sdk opentelemetry-exporter-otlp "
            "opentelemetry-instrumentation-fastapi"
        ) from exc

    resource = Resource.create({"service.name": _SERVICE_NAME})
    provider = TracerProvider(resource=resource)

    traces_exporter = os.environ.get("OTEL_TRACES_EXPORTER", "otlp").lower()
    if traces_exporter != "none":
        exporter = OTLPSpanExporter(endpoint=endpoint)
        provider.add_span_processor(BatchSpanProcessor(exporter))

    trace.set_tracer_provider(provider)

    # FastAPI auto-instrumentation
    FastAPIInstrumentor.instrument_app(app)

    logger.info(
        "OpenTelemetry active (endpoint: %s, service: %s, traces: %s)",
        endpoint,
        _SERVICE_NAME,
        traces_exporter,
    )
