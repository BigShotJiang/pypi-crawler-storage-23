"""Microsoft Sentinel / Azure Monitor Log Analytics integration.

Ships audit events to Azure Monitor using the Data Collector API
(HMAC-SHA256 signed REST endpoint).

Required environment variables::

    SENTINEL_WORKSPACE_ID   Log Analytics workspace ID (GUID)
    SENTINEL_SHARED_KEY     Workspace primary or secondary key (base64-encoded)

Optional::

    SENTINEL_LOG_TYPE       Custom log table name; Azure appends ``_CL``
                            (default: ``MeshOptixIQ``)

The module never raises — shipping failures are logged as warnings.
"""

import base64
import hashlib
import hmac
import json
import logging
import os
from datetime import datetime, timezone
from typing import Any

logger = logging.getLogger(__name__)

_DEFAULT_LOG_TYPE = "MeshOptixIQ"


# ---------------------------------------------------------------------------
# Signature builder
# ---------------------------------------------------------------------------

def _build_signature(
    workspace_id: str,
    shared_key: str,
    body: str,
    date: str,
) -> str:
    """Return the ``SharedKey`` Authorization header value.

    Signature string::

        POST\\n{content_length}\\napplication/json\\nx-ms-date:{date}\\n/api/logs

    The shared key is base64-decoded before use as the HMAC key.
    """
    string_to_sign = (
        f"POST\n{len(body.encode('utf-8'))}\napplication/json\n"
        f"x-ms-date:{date}\n/api/logs"
    )
    decoded_key = base64.b64decode(shared_key)
    sig = base64.b64encode(
        hmac.new(decoded_key, string_to_sign.encode("utf-8"), hashlib.sha256).digest()
    ).decode("utf-8")
    return f"SharedKey {workspace_id}:{sig}"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def ship_to_sentinel(event: dict[str, Any]) -> None:
    """POST *event* to the Azure Monitor Log Analytics Data Collector API.

    No-op when ``SENTINEL_WORKSPACE_ID`` or ``SENTINEL_SHARED_KEY`` are unset.
    Failures are logged as warnings and never raised.
    """
    workspace_id: str | None = os.environ.get("SENTINEL_WORKSPACE_ID")
    shared_key: str | None = os.environ.get("SENTINEL_SHARED_KEY")

    if not workspace_id or not shared_key:
        return

    log_type = os.environ.get("SENTINEL_LOG_TYPE", _DEFAULT_LOG_TYPE)

    body = json.dumps([event])
    date = datetime.now(timezone.utc).strftime("%a, %d %b %Y %H:%M:%S GMT")
    signature = _build_signature(workspace_id, shared_key, body, date)

    url = (
        f"https://{workspace_id}.ods.opinsights.azure.com"
        f"/api/logs?api-version=2016-04-01"
    )
    headers = {
        "Content-Type": "application/json",
        "Log-Type": log_type,
        "Authorization": signature,
        "x-ms-date": date,
    }

    try:
        import httpx  # already in integrations extra
        resp = httpx.post(url, content=body, headers=headers, timeout=10)
        resp.raise_for_status()
        logger.debug("Sentinel: shipped event to %s_CL", log_type)
    except ImportError:
        logger.warning("Sentinel shipping requires 'httpx' — install the integrations extra")
    except Exception as exc:
        logger.warning("Sentinel Log Analytics shipping failed: %s", exc)
