"""Microsoft Teams Adaptive Card notification integration.

Sends Adaptive Card messages to Teams Incoming Webhook URLs.

Two notification channels:
- ``TEAMS_SOAR_WEBHOOK_URL``  — SOAR alerts (filtered by ``TEAMS_SEVERITY_FILTER``)
- ``TEAMS_AUDIT_WEBHOOK_URL`` — audit events from ``AuditMiddleware``

Severity order: info < high < critical
Default filter: ``high`` (only ``high`` and ``critical`` SOAR alerts are sent)

The module never raises — shipping failures are logged as warnings.
"""

import json
import logging
import os
from typing import Any

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Severity ordering
# ---------------------------------------------------------------------------

_SEVERITY_ORDER = {"info": 0, "high": 1, "critical": 2, "error": 2, "warning": 1}
_SEVERITY_COLOR = {
    "critical": "attention",
    "error": "attention",
    "high": "warning",
    "warning": "warning",
    "info": "good",
}

# ---------------------------------------------------------------------------
# Module-level config (supports importlib.reload() in tests)
# ---------------------------------------------------------------------------

_TEAMS_SOAR_URL: str | None = os.environ.get("TEAMS_SOAR_WEBHOOK_URL")
_TEAMS_AUDIT_URL: str | None = os.environ.get("TEAMS_AUDIT_WEBHOOK_URL")
_SEVERITY_FILTER: str = os.environ.get("TEAMS_SEVERITY_FILTER", "high")


# ---------------------------------------------------------------------------
# Card builder
# ---------------------------------------------------------------------------

def _build_adaptive_card(
    title: str,
    facts: dict[str, Any],
    color: str = "default",
) -> dict[str, Any]:
    """Build a Teams ``type: message`` payload with an Adaptive Card attachment."""
    fact_items = [{"title": str(k), "value": str(v)} for k, v in facts.items()]

    card_body = [
        {
            "type": "TextBlock",
            "text": title,
            "weight": "Bolder",
            "size": "Medium",
            "color": color,
            "wrap": True,
        }
    ]
    if fact_items:
        card_body.append(
            {
                "type": "FactSet",
                "facts": fact_items,
            }
        )

    return {
        "type": "message",
        "attachments": [
            {
                "contentType": "application/vnd.microsoft.card.adaptive",
                "contentUrl": None,
                "content": {
                    "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                    "type": "AdaptiveCard",
                    "version": "1.4",
                    "body": card_body,
                },
            }
        ],
    }


def _post_card(url: str, payload: dict[str, Any]) -> None:
    """POST an Adaptive Card payload to ``url``.  Logs warnings on failure."""
    try:
        import httpx  # already in integrations extra
        resp = httpx.post(
            url,
            content=json.dumps(payload),
            headers={"Content-Type": "application/json"},
            timeout=10,
        )
        resp.raise_for_status()
    except ImportError:
        logger.warning("Teams notification requires 'httpx' — install the integrations extra")
    except Exception as exc:
        logger.warning("Teams webhook POST failed: %s", exc)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def send_soar_alert(event: dict[str, Any], rule: dict[str, Any]) -> None:
    """Send a SOAR alert as an Adaptive Card to ``TEAMS_SOAR_WEBHOOK_URL``.

    No-op when:
    - ``TEAMS_SOAR_WEBHOOK_URL`` is not set
    - alert severity is below ``TEAMS_SEVERITY_FILTER``
    """
    # Re-read at call time so tests can monkeypatch env
    url = os.environ.get("TEAMS_SOAR_WEBHOOK_URL") or _TEAMS_SOAR_URL
    if not url:
        return

    severity = rule.get("severity", "info")
    min_severity = os.environ.get("TEAMS_SEVERITY_FILTER", _SEVERITY_FILTER)

    # Filter: skip if severity is below threshold
    if _SEVERITY_ORDER.get(severity, 0) < _SEVERITY_ORDER.get(min_severity, 0):
        return

    color = _SEVERITY_COLOR.get(severity, "default")
    title = f"MeshOptixIQ SOAR Alert — {rule.get('query', 'unknown')} [{severity.upper()}]"

    facts: dict[str, Any] = {
        "Query": event.get("query_name", ""),
        "Severity": severity,
        "Condition": rule.get("condition", ""),
        "Row Count": event.get("row_count", ""),
        "Status": event.get("status", ""),
        "User": event.get("user", ""),
        "Elapsed (ms)": event.get("elapsed_ms", ""),
        "Timestamp": event.get("timestamp", ""),
    }

    payload = _build_adaptive_card(title, facts, color)
    _post_card(url, payload)


def send_audit_event(event: dict[str, Any]) -> None:
    """Send an audit event as an Adaptive Card to ``TEAMS_AUDIT_WEBHOOK_URL``.

    No-op when ``TEAMS_AUDIT_WEBHOOK_URL`` is not set.
    """
    url = os.environ.get("TEAMS_AUDIT_WEBHOOK_URL") or _TEAMS_AUDIT_URL
    if not url:
        return

    title = f"MeshOptixIQ Audit — {event.get('event', 'unknown')}"

    facts: dict[str, Any] = {
        "Event": event.get("event", ""),
        "User": event.get("user", ""),
        "Path": event.get("path", ""),
        "Status": event.get("status", ""),
        "Query": event.get("query_name", ""),
        "Client IP": event.get("client_ip", ""),
        "Elapsed (ms)": event.get("elapsed_ms", ""),
        "Timestamp": event.get("timestamp", ""),
    }

    payload = _build_adaptive_card(title, facts, "default")
    _post_card(url, payload)
