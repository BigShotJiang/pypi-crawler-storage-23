"""SOAR / Webhook event trigger integration.

When ``SOAR_WEBHOOK_URL`` is set, evaluated rules are checked against every
audit event.  Matching events are POSTed to the configured SOAR endpoint.

Rules format (``SOAR_RULES`` env var — JSON array)::

    [
      {"query": "blast_radius_device",  "condition": "row_count > 50",  "severity": "high"},
      {"query": "blast_radius_vlan",    "condition": "row_count > 200", "severity": "critical"},
      {"query": "*",                    "condition": "status >= 500",   "severity": "error"},
      {"query": "path_analysis",        "condition": "row_count > 0",   "severity": "info"}
    ]

Supported condition operators: ``>``, ``>=``, ``==``, ``<``, ``<=``.
Supported condition fields: ``row_count``, ``status``, ``elapsed_ms``.

The module never raises — shipping failures are logged as warnings.
"""

import json
import logging
import os
from fnmatch import fnmatch
from typing import Any

import httpx

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

_SOAR_WEBHOOK_URL: str | None = os.environ.get("SOAR_WEBHOOK_URL")
_SOAR_WEBHOOK_TOKEN: str | None = os.environ.get("SOAR_WEBHOOK_TOKEN")

_soar_rules: list[dict[str, Any]] = []

_raw_rules = os.environ.get("SOAR_RULES", "")
if _raw_rules:
    try:
        _soar_rules = json.loads(_raw_rules)
    except json.JSONDecodeError as _exc:
        logger.error("SOAR_RULES is not valid JSON: %s", _exc)

# ---------------------------------------------------------------------------
# Condition evaluation
# ---------------------------------------------------------------------------

_OPERATORS = {
    ">=": lambda a, b: a >= b,
    "<=": lambda a, b: a <= b,
    ">":  lambda a, b: a > b,
    "<":  lambda a, b: a < b,
    "==": lambda a, b: a == b,
}

_CONDITION_FIELDS = {"row_count", "status", "elapsed_ms"}


def _parse_condition(condition: str) -> tuple[str, str, float]:
    """Parse a condition string into ``(field, operator, threshold)``.

    Returns a 3-tuple or raises ``ValueError`` for unrecognised input.
    """
    condition = condition.strip()
    for op in (">=", "<=", ">", "<", "=="):
        if op in condition:
            parts = condition.split(op, 1)
            field = parts[0].strip()
            try:
                threshold = float(parts[1].strip())
            except ValueError as exc:
                raise ValueError(f"Non-numeric threshold in condition: '{condition}'") from exc
            if field not in _CONDITION_FIELDS:
                raise ValueError(
                    f"Unsupported condition field '{field}'. "
                    f"Allowed: {sorted(_CONDITION_FIELDS)}"
                )
            return field, op, threshold
    raise ValueError(f"No recognised operator in condition: '{condition}'")


def _evaluate_condition(event: dict[str, Any], condition: str) -> bool:
    """Return True if *event* satisfies *condition*."""
    try:
        field, op, threshold = _parse_condition(condition)
    except ValueError as exc:
        logger.warning("SOAR condition parse error: %s", exc)
        return False

    value = event.get(field)
    if value is None:
        return False

    try:
        return _OPERATORS[op](float(value), threshold)
    except (TypeError, ValueError):
        return False


def evaluate_rules(
    event: dict[str, Any],
    rules: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Return the subset of *rules* that match *event*.

    A rule matches when:
    - Its ``query`` pattern (fnmatch glob) matches ``event["query_name"]``
    - Its ``condition`` expression evaluates to True against event fields
    """
    query_name: str = event.get("query_name", "")
    matched: list[dict[str, Any]] = []

    for rule in rules:
        query_pattern = rule.get("query", "*")
        condition = rule.get("condition", "")

        if not fnmatch(query_name, query_pattern):
            continue

        if not condition or _evaluate_condition(event, condition):
            matched.append(rule)

    return matched


# ---------------------------------------------------------------------------
# Dispatch
# ---------------------------------------------------------------------------

def dispatch_soar(
    event: dict[str, Any],
    matched_rules: list[dict[str, Any]],
) -> None:
    """POST a SOAR trigger payload to ``SOAR_WEBHOOK_URL``.

    One POST is made per matched rule.  Failures are logged and swallowed —
    this function never raises.
    """
    url = os.environ.get("SOAR_WEBHOOK_URL") or _SOAR_WEBHOOK_URL
    if not url:
        return

    token = os.environ.get("SOAR_WEBHOOK_TOKEN") or _SOAR_WEBHOOK_TOKEN
    headers: dict[str, str] = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"

    for rule in matched_rules:
        payload: dict[str, Any] = {
            "source": "meshoptixiq",
            "severity": rule.get("severity", "info"),
            "rule": rule,
            "event": event,
        }
        try:
            resp = httpx.post(url, json=payload, headers=headers, timeout=5)
            resp.raise_for_status()
            logger.info(
                "SOAR trigger dispatched: query=%s severity=%s",
                event.get("query_name"),
                rule.get("severity"),
            )
        except Exception as exc:
            logger.warning("SOAR webhook dispatch failed: %s", exc)

    # Microsoft Teams SOAR notification (no-op if TEAMS_SOAR_WEBHOOK_URL not set)
    if os.environ.get("TEAMS_SOAR_WEBHOOK_URL"):
        try:
            from network_discovery.enterprise.integrations.teams import send_soar_alert
            for rule in matched_rules:
                send_soar_alert(event, rule)
        except ImportError:
            pass
