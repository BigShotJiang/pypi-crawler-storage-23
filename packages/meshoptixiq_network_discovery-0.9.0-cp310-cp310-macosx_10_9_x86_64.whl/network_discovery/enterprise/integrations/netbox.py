"""NetBox bidirectional synchronisation.

Controlled by the ``NETBOX_SYNC_DIRECTION`` env var:

- ``push`` — write discovered topology into NetBox (devices, interfaces, IPs, VLANs)
- ``pull`` — read business metadata (site/tenant/rack/role) from NetBox and update graph nodes
- ``both`` (default) — push then pull

Conflict strategy
-----------------
- NetBox is authoritative for *business* metadata (site, tenant, owner, role, rack).
- MeshOptixIQ is authoritative for *connectivity* facts (interfaces, neighbours, IPs
  discovered via SSH).  If NetBox has an IP that conflicts with the graph, a warning
  is logged and the NetBox record is left unchanged.

Required env vars::

    NETBOX_URL     https://netbox.corp.local
    NETBOX_TOKEN   <api-token>

Optional::

    NETBOX_SYNC_DIRECTION  both | push | pull  (default: both)
"""

import logging
import os
from typing import Any

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

_NETBOX_URL: str | None = os.environ.get("NETBOX_URL", "").rstrip("/")
_NETBOX_TOKEN: str | None = os.environ.get("NETBOX_TOKEN")
_SYNC_DIRECTION: str = os.environ.get("NETBOX_SYNC_DIRECTION", "both").lower()

# ---------------------------------------------------------------------------
# HTTP helpers
# ---------------------------------------------------------------------------


def _get_client():
    """Return an httpx.Client configured with the NetBox API token."""
    try:
        import httpx
    except ImportError as exc:
        raise RuntimeError(
            "NetBox sync requires httpx. "
            "Install with: pip install 'meshoptixiq-network-discovery[integrations]'"
        ) from exc

    token = os.environ.get("NETBOX_TOKEN") or _NETBOX_TOKEN
    if not token:
        raise RuntimeError("NETBOX_TOKEN environment variable is required for NetBox sync.")

    return httpx.Client(
        headers={
            "Authorization": f"Token {token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        },
        timeout=30,
    )


def _nb_url(path: str) -> str:
    base = (os.environ.get("NETBOX_URL") or _NETBOX_URL or "").rstrip("/")
    if not base:
        raise RuntimeError("NETBOX_URL environment variable is required for NetBox sync.")
    return f"{base}{path}"


def _upsert(client, list_url: str, lookup_params: dict[str, str], payload: dict[str, Any], dry_run: bool) -> dict[str, Any]:
    """GET existing record by lookup_params; PATCH if found, POST if not.

    Returns the final NetBox record dict.
    """
    resp = client.get(list_url, params=lookup_params)
    resp.raise_for_status()
    results = resp.json().get("results", [])

    if dry_run:
        if results:
            logger.info("[dry-run] PATCH %s %s", list_url, lookup_params)
        else:
            logger.info("[dry-run] POST %s %s", list_url, payload.get("name") or payload.get("address"))
        return results[0] if results else {}

    if results:
        record = results[0]
        patch_resp = client.patch(f"{list_url}{record['id']}/", json=payload)
        patch_resp.raise_for_status()
        return patch_resp.json()
    else:
        post_resp = client.post(list_url, json=payload)
        post_resp.raise_for_status()
        return post_resp.json()


# ---------------------------------------------------------------------------
# Push: Discovery → NetBox
# ---------------------------------------------------------------------------

def _push_devices(client, devices: list[dict[str, Any]], dry_run: bool) -> None:
    """Upsert devices into NetBox DCIM."""
    device_url = _nb_url("/api/dcim/devices/")

    for device in devices:
        hostname = device.get("hostname")
        if not hostname:
            continue

        payload: dict[str, Any] = {
            "name":     hostname,
            "slug":     hostname.lower().replace(" ", "-"),
            "comments": f"Discovered by MeshOptixIQ. Vendor: {device.get('vendor', '')}. "
                        f"Model: {device.get('model', '')}. OS: {device.get('os_version', '')}.",
        }

        try:
            _upsert(client, device_url, {"slug": payload["slug"]}, payload, dry_run)
            logger.debug("Upserted device: %s", hostname)
        except Exception as exc:
            logger.warning("Failed to upsert device '%s' in NetBox: %s", hostname, exc)


def _push_interfaces(client, devices: list[dict[str, Any]], dry_run: bool) -> None:
    """Upsert interfaces for each device."""
    iface_url = _nb_url("/api/dcim/interfaces/")

    for device in devices:
        hostname = device.get("hostname")
        if not hostname:
            continue

        interfaces = device.get("interfaces", [])
        if not interfaces:
            continue

        for iface in interfaces:
            iface_name = iface.get("name")
            if not iface_name:
                continue

            payload: dict[str, Any] = {
                "device":   {"name": hostname},
                "name":     iface_name,
                "type":     "1000base-t",
                "description": iface.get("description", ""),
            }

            try:
                _upsert(
                    client,
                    iface_url,
                    {"device": hostname, "name": iface_name},
                    payload,
                    dry_run,
                )
            except Exception as exc:
                logger.warning(
                    "Failed to upsert interface '%s' on '%s': %s", iface_name, hostname, exc
                )


def _push_ip_addresses(client, devices: list[dict[str, Any]], dry_run: bool) -> None:
    """Upsert IP addresses from device interfaces."""
    ip_url = _nb_url("/api/ipam/ip-addresses/")

    for device in devices:
        hostname = device.get("hostname")
        if not hostname:
            continue

        for iface in device.get("interfaces", []):
            for ip in iface.get("ip_addresses", []):
                address = ip.get("address")
                if not address:
                    continue

                payload: dict[str, Any] = {
                    "address":   address,
                    "status":    "active",
                    "description": f"{hostname} / {iface.get('name', '')}",
                }

                try:
                    _upsert(client, ip_url, {"address": address}, payload, dry_run)
                except Exception as exc:
                    logger.warning(
                        "Failed to upsert IP '%s' for '%s': %s", address, hostname, exc
                    )


def _push_vlans(client, vlans: list[dict[str, Any]], dry_run: bool) -> None:
    """Upsert VLANs into NetBox IPAM."""
    vlan_url = _nb_url("/api/ipam/vlans/")

    for vlan in vlans:
        vid = vlan.get("vlan_id") or vlan.get("vid")
        name = vlan.get("name") or f"VLAN{vid}"
        if not vid:
            continue

        payload: dict[str, Any] = {
            "vid":  int(vid),
            "name": str(name),
        }

        try:
            _upsert(client, vlan_url, {"vid": str(vid)}, payload, dry_run)
        except Exception as exc:
            logger.warning("Failed to upsert VLAN %s: %s", vid, exc)


# ---------------------------------------------------------------------------
# Pull: NetBox → Graph
# ---------------------------------------------------------------------------

def _pull_metadata(client, provider, dry_run: bool) -> None:
    """Fetch device CI records from NetBox and update graph node properties."""
    nb_url = _nb_url("/api/dcim/devices/")
    page_url: str | None = f"{nb_url}?limit=1000"

    nb_devices: list[dict[str, Any]] = []
    while page_url:
        try:
            resp = client.get(page_url)
            resp.raise_for_status()
            data = resp.json()
            nb_devices.extend(data.get("results", []))
            page_url = data.get("next")
        except Exception as exc:
            logger.error("Failed to fetch devices from NetBox: %s", exc)
            break

    logger.info("NetBox pull: fetched %d device records", len(nb_devices))

    for nb_device in nb_devices:
        hostname = nb_device.get("name")
        if not hostname:
            continue

        site = (nb_device.get("site") or {}).get("name") or ""
        tenant = (nb_device.get("tenant") or {}).get("name") or ""
        rack = (nb_device.get("rack") or {}).get("name") or ""
        role = (nb_device.get("device_role") or {}).get("name") or ""
        custom_fields = nb_device.get("custom_fields") or {}

        if dry_run:
            logger.info(
                "[dry-run] Would update graph node '%s': site=%s tenant=%s rack=%s role=%s",
                hostname, site, tenant, rack, role,
            )
            continue

        _update_graph_node(provider, hostname, site, tenant, rack, role, custom_fields)


def _update_graph_node(
    provider,
    hostname: str,
    site: str,
    tenant: str,
    rack: str,
    role: str,
    custom_fields: dict[str, Any],
) -> None:
    """Write NetBox metadata onto the graph device node."""
    backend = os.environ.get("GRAPH_BACKEND", "neo4j").lower()

    if backend == "neo4j":
        cypher = """
MATCH (d:Device {hostname: $hostname})
SET d.nb_site         = $nb_site,
    d.nb_tenant       = $nb_tenant,
    d.nb_rack         = $nb_rack,
    d.nb_role         = $nb_role,
    d.nb_custom_fields = $nb_custom_fields
"""
        try:
            provider.execute_query(
                "update_device_metadata",
                cypher,
                {
                    "hostname":         hostname,
                    "nb_site":          site,
                    "nb_tenant":        tenant,
                    "nb_rack":          rack,
                    "nb_role":          role,
                    "nb_custom_fields": str(custom_fields),
                },
            )
        except Exception as exc:
            logger.warning("Failed to update graph node '%s': %s", hostname, exc)
    else:
        sql = """
UPDATE devices
SET    nb_site         = %(nb_site)s,
       nb_tenant       = %(nb_tenant)s,
       nb_rack         = %(nb_rack)s,
       nb_role         = %(nb_role)s,
       nb_custom_fields = %(nb_custom_fields)s
WHERE  hostname = %(hostname)s
"""
        try:
            provider.execute_query(
                "update_device_metadata",
                sql,
                {
                    "hostname":         hostname,
                    "nb_site":          site,
                    "nb_tenant":        tenant,
                    "nb_rack":          rack,
                    "nb_role":          role,
                    "nb_custom_fields": str(custom_fields),
                },
            )
        except Exception as exc:
            logger.warning("Failed to update graph node '%s': %s", hostname, exc)


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def run_sync(
    provider,
    direction: str | None = None,
    dry_run: bool = False,
) -> None:
    """Execute the NetBox sync in the requested direction.

    Args:
        provider:   GraphProvider instance (already connected).
        direction:  ``"push"`` | ``"pull"`` | ``"both"`` (defaults to ``NETBOX_SYNC_DIRECTION``).
        dry_run:    If True, log intended actions but make no changes.
    """
    direction = (direction or os.environ.get("NETBOX_SYNC_DIRECTION") or _SYNC_DIRECTION).lower()
    logger.info("NetBox sync starting (direction=%s dry_run=%s)", direction, dry_run)

    client = _get_client()

    if direction in ("push", "both"):
        logger.info("NetBox push: querying all devices from graph")
        try:
            backend = os.environ.get("GRAPH_BACKEND", "neo4j").lower()
            if backend == "neo4j":
                cypher = """
MATCH (d:Device)
OPTIONAL MATCH (d)-[:HAS_INTERFACE]->(i:Interface)
OPTIONAL MATCH (i)-[:HAS_IP]->(ip:IPAddress)
WITH d,
     collect(DISTINCT {
         name: i.name,
         description: i.description,
         ip_addresses: [{address: ip.address}]
     }) AS interfaces
RETURN d.hostname AS hostname, d.vendor AS vendor,
       d.model AS model, d.os_version AS os_version,
       d.mgmt_ip AS mgmt_ip, interfaces
"""
                devices = list(provider.execute_query("_nb_push_devices", cypher, {}))
            else:
                sql = """
SELECT d.hostname, d.vendor, d.model, d.os_version, d.mgmt_ip
FROM   devices d
"""
                devices = list(provider.execute_query("_nb_push_devices", sql, {}))
        except Exception as exc:
            logger.error("Failed to query devices for NetBox push: %s", exc)
            devices = []

        _push_devices(client, devices, dry_run)
        _push_interfaces(client, devices, dry_run)
        _push_ip_addresses(client, devices, dry_run)

        # VLANs
        try:
            backend = os.environ.get("GRAPH_BACKEND", "neo4j").lower()
            if backend == "neo4j":
                vlan_q = "MATCH (v:Vlan) RETURN v.vlan_id AS vlan_id, v.name AS name"
            else:
                vlan_q = "SELECT vlan_id, name FROM vlans"
            vlans = list(provider.execute_query("_nb_push_vlans", vlan_q, {}))
            _push_vlans(client, vlans, dry_run)
        except Exception as exc:
            logger.warning("VLAN push skipped: %s", exc)

    if direction in ("pull", "both"):
        _pull_metadata(client, provider, dry_run)

    logger.info("NetBox sync complete (direction=%s)", direction)
