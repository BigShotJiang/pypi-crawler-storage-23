"""Multi-provider secret loader for the enterprise container.

Reads ``SECRETS_PROVIDER`` (``vault`` | ``aws`` | ``azure`` | ``gcp`` | ``none``)
and returns a ``dict[str, str]`` of resolved env-var names → values.

The secrets stored in each backend are JSON objects of the form::

    {"API_KEY": "...", "NEO4J_PASSWORD": "...", "MESHOPTIXIQ_LICENSE_KEY": "..."}

Each provider function is imported lazily so that missing provider SDKs only
raise an error when that provider is actually requested.
"""

import json
import logging
import os

logger = logging.getLogger(__name__)


def resolve_secrets() -> dict[str, str]:
    """Resolve secrets from the configured provider.

    Returns a flat ``{env_var: value}`` dict ready to be merged into
    ``os.environ``.  Raises ``RuntimeError`` on misconfiguration.
    """
    provider = os.environ.get("SECRETS_PROVIDER", "none").lower()
    logger.info("Resolving secrets via provider: %s", provider)

    if provider == "none":
        return {}
    if provider == "vault":
        return _resolve_vault()
    if provider == "aws":
        return _resolve_aws()
    if provider == "azure":
        return _resolve_azure()
    if provider == "gcp":
        return _resolve_gcp()

    raise RuntimeError(
        f"Unknown SECRETS_PROVIDER={provider!r}. "
        "Supported values: none, vault, aws, azure, gcp"
    )


# ---------------------------------------------------------------------------
# HashiCorp Vault
# ---------------------------------------------------------------------------
def _resolve_vault() -> dict[str, str]:
    """Fetch secrets from HashiCorp Vault KV v2."""
    try:
        import hvac  # type: ignore[import-untyped]
    except ImportError as exc:
        raise RuntimeError(
            "SECRETS_PROVIDER=vault requires 'hvac'. "
            "Install with: pip install hvac>=2.0"
        ) from exc

    addr = os.environ.get("VAULT_ADDR", "http://127.0.0.1:8200")
    auth_method = os.environ.get("VAULT_AUTH_METHOD", "token").lower()
    secret_path = os.environ.get("VAULT_SECRET_PATH", "secret/data/meshoptixiq")

    client = hvac.Client(url=addr)

    if auth_method == "token":
        token = os.environ.get("VAULT_TOKEN")
        if not token:
            raise RuntimeError("VAULT_AUTH_METHOD=token requires VAULT_TOKEN to be set.")
        client.token = token

    elif auth_method == "approle":
        role_id = os.environ.get("VAULT_ROLE_ID")
        secret_id = os.environ.get("VAULT_SECRET_ID")
        if not role_id or not secret_id:
            raise RuntimeError(
                "VAULT_AUTH_METHOD=approle requires VAULT_ROLE_ID and VAULT_SECRET_ID."
            )
        result = client.auth.approle.login(role_id=role_id, secret_id=secret_id)
        client.token = result["auth"]["client_token"]

    elif auth_method == "kubernetes":
        role = os.environ.get("VAULT_K8S_ROLE")
        if not role:
            raise RuntimeError("VAULT_AUTH_METHOD=kubernetes requires VAULT_K8S_ROLE.")
        sa_token_path = "/var/run/secrets/kubernetes.io/serviceaccount/token"
        with open(sa_token_path) as f:
            sa_token = f.read().strip()
        result = client.auth.kubernetes.login(role=role, jwt=sa_token)
        client.token = result["auth"]["client_token"]

    else:
        raise RuntimeError(
            f"Unknown VAULT_AUTH_METHOD={auth_method!r}. "
            "Supported: token, approle, kubernetes"
        )

    if not client.is_authenticated():
        raise RuntimeError("Vault authentication failed.")

    # KV v2: path format is mount/data/path; response at data.data
    response = client.secrets.kv.v2.read_secret_version(path=secret_path.replace("secret/data/", ""))
    secrets: dict[str, str] = response["data"]["data"]
    logger.info("Resolved %d secret(s) from Vault path %s", len(secrets), secret_path)
    return secrets


# ---------------------------------------------------------------------------
# AWS Secrets Manager
# ---------------------------------------------------------------------------
def _resolve_aws() -> dict[str, str]:
    """Fetch secrets from AWS Secrets Manager."""
    try:
        import boto3  # type: ignore[import-untyped]
    except ImportError as exc:
        raise RuntimeError(
            "SECRETS_PROVIDER=aws requires 'boto3'. "
            "Install with: pip install boto3>=1.26"
        ) from exc

    secret_name = os.environ.get("AWS_SECRET_NAME")
    region = os.environ.get("AWS_REGION", "us-east-1")

    if not secret_name:
        raise RuntimeError("SECRETS_PROVIDER=aws requires AWS_SECRET_NAME to be set.")

    client = boto3.client("secretsmanager", region_name=region)
    response = client.get_secret_value(SecretId=secret_name)
    secret_string = response.get("SecretString", "{}")
    secrets: dict[str, str] = json.loads(secret_string)
    logger.info("Resolved %d secret(s) from AWS Secrets Manager: %s", len(secrets), secret_name)
    return secrets


# ---------------------------------------------------------------------------
# Azure Key Vault
# ---------------------------------------------------------------------------
def _resolve_azure() -> dict[str, str]:
    """Fetch secrets from Azure Key Vault."""
    try:
        from azure.identity import DefaultAzureCredential  # type: ignore[import-untyped]
        from azure.keyvault.secrets import SecretClient  # type: ignore[import-untyped]
    except ImportError as exc:
        raise RuntimeError(
            "SECRETS_PROVIDER=azure requires 'azure-keyvault-secrets' and 'azure-identity'. "
            "Install with: pip install azure-keyvault-secrets>=4.8 azure-identity>=1.16"
        ) from exc

    vault_url = os.environ.get("AZURE_KEY_VAULT_URL")
    secret_names_raw = os.environ.get("AZURE_SECRET_NAMES", "")

    if not vault_url:
        raise RuntimeError("SECRETS_PROVIDER=azure requires AZURE_KEY_VAULT_URL to be set.")

    secret_names = [n.strip() for n in secret_names_raw.split(",") if n.strip()]
    if not secret_names:
        raise RuntimeError(
            "SECRETS_PROVIDER=azure requires AZURE_SECRET_NAMES (comma-separated list)."
        )

    credential = DefaultAzureCredential()
    client = SecretClient(vault_url=vault_url, credential=credential)

    secrets: dict[str, str] = {}
    for name in secret_names:
        secret = client.get_secret(name)
        # Secret value is JSON: {"API_KEY": "...", ...}
        try:
            parsed = json.loads(secret.value or "{}")
            secrets.update(parsed)
        except json.JSONDecodeError:
            # Treat entire value as a single env var named after the secret
            env_var = name.upper().replace("-", "_")
            secrets[env_var] = secret.value or ""

    logger.info("Resolved %d secret(s) from Azure Key Vault: %s", len(secrets), vault_url)
    return secrets


# ---------------------------------------------------------------------------
# GCP Secret Manager
# ---------------------------------------------------------------------------
def _resolve_gcp() -> dict[str, str]:
    """Fetch secrets from GCP Secret Manager."""
    try:
        from google.cloud import secretmanager  # type: ignore[import-untyped]
    except ImportError as exc:
        raise RuntimeError(
            "SECRETS_PROVIDER=gcp requires 'google-cloud-secret-manager'. "
            "Install with: pip install google-cloud-secret-manager>=2.20"
        ) from exc

    project_id = os.environ.get("GCP_PROJECT_ID")
    secret_ids_raw = os.environ.get("GCP_SECRET_IDS", "")

    if not project_id:
        raise RuntimeError("SECRETS_PROVIDER=gcp requires GCP_PROJECT_ID to be set.")

    # GCP_SECRET_IDS: comma-separated "name:version" pairs (version defaults to "latest")
    secret_ids = [s.strip() for s in secret_ids_raw.split(",") if s.strip()]
    if not secret_ids:
        raise RuntimeError(
            "SECRETS_PROVIDER=gcp requires GCP_SECRET_IDS (comma-separated name:version pairs)."
        )

    client = secretmanager.SecretManagerServiceClient()
    secrets: dict[str, str] = {}

    for entry in secret_ids:
        parts = entry.split(":", 1)
        name = parts[0]
        version = parts[1] if len(parts) > 1 else "latest"
        resource_name = f"projects/{project_id}/secrets/{name}/versions/{version}"
        response = client.access_secret_version(name=resource_name)
        payload = response.payload.data.decode("utf-8")
        try:
            parsed = json.loads(payload)
            secrets.update(parsed)
        except json.JSONDecodeError:
            env_var = name.upper().replace("-", "_")
            secrets[env_var] = payload

    logger.info("Resolved %d secret(s) from GCP Secret Manager (project: %s)", len(secrets), project_id)
    return secrets
