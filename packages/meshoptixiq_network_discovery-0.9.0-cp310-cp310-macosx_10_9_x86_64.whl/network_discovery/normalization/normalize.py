"""Normalization and deduplication pipeline.

Ensures facts are clean, deduplicated, and referentially consistent
before ingestion into Neo4j.
"""

from __future__ import annotations

import ipaddress
import logging
from typing import Any, TypeVar

from pydantic import BaseModel

from network_discovery.normalization.models import (
    SCHEMA_VERSION,
    NetworkFacts,
    SubnetModel,
    normalize_mac_address,
)

logger = logging.getLogger(__name__)

T = TypeVar("T", bound=BaseModel)


def normalize_mac(mac: str) -> str:
    """Normalize MAC address to XX:XX:XX:XX:XX:XX uppercase format."""
    return normalize_mac_address(mac)


def normalize_ip(ip: str) -> str:
    """Validate and normalize an IP address string."""
    try:
        return str(ipaddress.ip_address(ip))
    except ValueError:
        logger.warning("Invalid IP address: %s", ip)
        return ip


def compute_subnet(ip: str, prefix_length: int) -> str:
    """Compute the network address for an IP/prefix pair."""
    try:
        network = ipaddress.ip_network(f"{ip}/{prefix_length}", strict=False)
        return str(network.network_address) + "/" + str(network.prefixlen)
    except ValueError:
        return f"{ip}/{prefix_length}"


def _model_key(model: BaseModel) -> tuple[tuple[str, Any], ...]:
    """Return a hashable key for a Pydantic model (faster than JSON serialisation)."""
    return tuple(sorted(model.model_dump().items()))


def _deduplicate_models(models: list[T]) -> list[T]:
    """Remove exact duplicate models from a list, preserving order."""
    seen: set[tuple[tuple[str, Any], ...]] = set()
    unique: list[T] = []
    for model in models:
        key = _model_key(model)
        if key not in seen:
            seen.add(key)
            unique.append(model)
    return unique


def deduplicate_facts(facts: NetworkFacts) -> NetworkFacts:
    """Remove exact duplicate entries across all fact types."""
    return NetworkFacts(
        schema_version=facts.schema_version,
        devices=_deduplicate_models(facts.devices),
        interfaces=_deduplicate_models(facts.interfaces),
        ip_addresses=_deduplicate_models(facts.ip_addresses),
        subnets=_deduplicate_models(facts.subnets),
        vlans=_deduplicate_models(facts.vlans),
        macs=_deduplicate_models(facts.macs),
        endpoints=_deduplicate_models(facts.endpoints),
    )


def derive_subnets(facts: NetworkFacts) -> NetworkFacts:
    """Derive Subnet entities from IP addresses that have prefix_length > 0."""
    existing_subnets = {s.network_address for s in facts.subnets}
    new_subnets: list[SubnetModel] = []

    for ip in facts.ip_addresses:
        if ip.prefix_length <= 0:
            continue

        network_addr = compute_subnet(ip.address, ip.prefix_length)
        if network_addr not in existing_subnets:
            existing_subnets.add(network_addr)
            new_subnets.append(
                SubnetModel(
                    network_address=network_addr,
                    prefix_length=ip.prefix_length,
                    version=ip.version,
                )
            )

    return NetworkFacts(
        schema_version=facts.schema_version,
        devices=facts.devices,
        interfaces=facts.interfaces,
        ip_addresses=facts.ip_addresses,
        subnets=facts.subnets + new_subnets,
        vlans=facts.vlans,
        macs=facts.macs,
        endpoints=facts.endpoints,
    )


def check_referential_integrity(facts: NetworkFacts) -> list[str]:
    """Check that relationships between entities are valid.

    Returns a list of warning messages for any integrity issues found.
    """
    warnings: list[str] = []

    device_hostnames = {d.hostname for d in facts.devices}
    interface_keys = {(i.device_hostname, i.name) for i in facts.interfaces}

    # Interfaces should reference existing devices
    for iface in facts.interfaces:
        if device_hostnames and iface.device_hostname not in device_hostnames:
            warnings.append(
                f"Interface {iface.name} references unknown device {iface.device_hostname}"
            )

    # IPs should reference valid interfaces
    for ip in facts.ip_addresses:
        if ip.interface_name and ip.device_hostname:
            key = (ip.device_hostname, ip.interface_name)
            if interface_keys and key not in interface_keys:
                warnings.append(
                    f"IP {ip.address} references unknown interface "
                    f"{ip.device_hostname}:{ip.interface_name}"
                )

    # MACs should reference valid interfaces
    for mac in facts.macs:
        if mac.interface_name and mac.device_hostname:
            key = (mac.device_hostname, mac.interface_name)
            if interface_keys and key not in interface_keys:
                warnings.append(
                    f"MAC {mac.address} references unknown interface "
                    f"{mac.device_hostname}:{mac.interface_name}"
                )

    # VLANs should reference existing devices
    for vlan in facts.vlans:
        if device_hostnames and vlan.device_hostname not in device_hostnames:
            warnings.append(
                f"VLAN {vlan.vlan_id} references unknown device {vlan.device_hostname}"
            )

    for warning in warnings:
        logger.warning("Integrity: %s", warning)

    return warnings


def tag_schema_version(facts: NetworkFacts) -> NetworkFacts:
    """Ensure schema_version is set to current version."""
    if facts.schema_version != SCHEMA_VERSION:
        logger.info(
            "Updating schema_version from %d to %d",
            facts.schema_version,
            SCHEMA_VERSION,
        )
    return facts.model_copy(update={"schema_version": SCHEMA_VERSION})


def normalize_pipeline(facts: NetworkFacts) -> NetworkFacts:
    """Run the full normalization pipeline.

    Steps:
      1. Deduplicate
      2. Derive subnets from IPs
      3. Check referential integrity (warnings only)
      4. Tag schema version
    """
    logger.info("Starting normalization pipeline")

    facts = deduplicate_facts(facts)
    logger.info(
        "After dedup: %d devices, %d interfaces, %d IPs, %d MACs",
        len(facts.devices),
        len(facts.interfaces),
        len(facts.ip_addresses),
        len(facts.macs),
    )

    facts = derive_subnets(facts)
    logger.info("Derived %d subnets", len(facts.subnets))

    warnings = check_referential_integrity(facts)
    if warnings:
        logger.warning("Found %d integrity warnings", len(warnings))

    facts = tag_schema_version(facts)

    logger.info("Normalization complete")
    return facts
