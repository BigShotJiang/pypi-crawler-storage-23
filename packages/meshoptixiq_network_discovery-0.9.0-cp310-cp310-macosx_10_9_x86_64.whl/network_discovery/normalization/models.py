"""Canonical network data models.

These Pydantic models define the vendor-agnostic data contracts for the
network discovery pipeline. All vendor parsers must produce instances of
these models. Schema version: 1.
"""

from __future__ import annotations

import re
from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, field_validator

SCHEMA_VERSION = 1

MAC_PATTERN = re.compile(r"^([0-9A-F]{2}:){5}[0-9A-F]{2}$")


def normalize_mac_address(mac: str) -> str:
    """Normalize a MAC address to uppercase colon-separated format (XX:XX:XX:XX:XX:XX).

    Handles common formats:
      - aa:bb:cc:dd:ee:ff
      - aa-bb-cc-dd-ee-ff
      - aabb.ccdd.eeff
      - aabbccddeeff
    """
    cleaned = re.sub(r"[.:\-]", "", mac.strip().upper())
    if len(cleaned) != 12 or not re.match(r"^[0-9A-F]{12}$", cleaned):
        raise ValueError(f"Invalid MAC address: {mac}")
    return ":".join(cleaned[i : i + 2] for i in range(0, 12, 2))


class DeviceModel(BaseModel):
    model_config = ConfigDict(strict=True)

    hostname: str
    vendor: str
    model: str | None = None
    serial: str | None = None
    os_version: str | None = None
    collected_at: datetime

    @field_validator("hostname")
    @classmethod
    def hostname_not_empty(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("hostname must not be empty")
        return v.strip()


class InterfaceModel(BaseModel):
    model_config = ConfigDict(strict=True)

    device_hostname: str
    name: str
    admin_status: str | None = None
    oper_status: str | None = None
    speed: str | None = None
    mtu: int | None = None
    description: str | None = None
    mac_address: str | None = None

    @field_validator("name")
    @classmethod
    def name_not_empty(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("interface name must not be empty")
        return v.strip()

    @field_validator("mac_address")
    @classmethod
    def validate_mac(cls, v: str | None) -> str | None:
        if v is None:
            return None
        return normalize_mac_address(v)


class IPAddressModel(BaseModel):
    model_config = ConfigDict(strict=True)

    address: str
    prefix_length: int
    version: Literal[4, 6]
    interface_name: str | None = None
    device_hostname: str | None = None
    vrf: str | None = None  # VRF/routing-instance name; None → treated as "global"

    @field_validator("prefix_length")
    @classmethod
    def validate_prefix_length(cls, v: int) -> int:
        if v < 0 or v > 128:
            raise ValueError(f"prefix_length must be 0-128, got {v}")
        return v


class SubnetModel(BaseModel):
    model_config = ConfigDict(strict=True)

    network_address: str
    prefix_length: int
    version: Literal[4, 6]
    vrf: str | None = None     # VRF context; None → "global"
    tenant: str | None = None  # Tenant identifier for M&A / shared-address scenarios

    @field_validator("prefix_length")
    @classmethod
    def validate_prefix_length(cls, v: int) -> int:
        if v < 0 or v > 128:
            raise ValueError(f"prefix_length must be 0-128, got {v}")
        return v


class VLANModel(BaseModel):
    model_config = ConfigDict(strict=True)

    device_hostname: str
    vlan_id: int
    name: str | None = None

    @field_validator("vlan_id")
    @classmethod
    def validate_vlan_id(cls, v: int) -> int:
        if v < 1 or v > 4094:
            raise ValueError(f"vlan_id must be 1-4094, got {v}")
        return v


class MACModel(BaseModel):
    model_config = ConfigDict(strict=True)

    address: str
    vendor_oui: str | None = None
    interface_name: str | None = None
    device_hostname: str | None = None
    vlan_id: int | None = None

    @field_validator("address")
    @classmethod
    def validate_and_normalize_mac(cls, v: str) -> str:
        return normalize_mac_address(v)


class EndpointModel(BaseModel):
    model_config = ConfigDict(strict=True)

    mac_address: str
    ip_address: str
    first_seen: datetime | None = None
    last_seen: datetime | None = None

    @field_validator("mac_address")
    @classmethod
    def validate_mac(cls, v: str) -> str:
        return normalize_mac_address(v)


class FirewallRuleModel(BaseModel):
    model_config = ConfigDict(strict=True)

    device_hostname: str
    rule_id: str
    rule_name: str | None = None
    rule_order: int
    action: Literal["allow", "deny", "drop", "reject"]
    source_zones: list[str] = []
    destination_zones: list[str] = []
    source_addresses: list[str] = []
    destination_addresses: list[str] = []
    services: list[str] = []
    protocols: list[str] = []
    destination_ports: list[str] = []
    enabled: bool = True
    log_enabled: bool = False
    comments: str | None = None
    vendor: str
    collected_at: datetime


class AddressObjectModel(BaseModel):
    model_config = ConfigDict(strict=True)

    device_hostname: str
    name: str
    type: Literal["host", "network", "range", "fqdn", "group"]
    value: str
    vendor: str


class ServiceObjectModel(BaseModel):
    model_config = ConfigDict(strict=True)

    device_hostname: str
    name: str
    protocol: str
    dest_ports: str
    vendor: str


class NetworkFacts(BaseModel):
    """Container for all canonical network facts from a collection run."""

    model_config = ConfigDict(strict=True)

    schema_version: int = SCHEMA_VERSION
    devices: list[DeviceModel] = []
    interfaces: list[InterfaceModel] = []
    ip_addresses: list[IPAddressModel] = []
    subnets: list[SubnetModel] = []
    vlans: list[VLANModel] = []
    macs: list[MACModel] = []
    endpoints: list[EndpointModel] = []
    firewall_rules: list[FirewallRuleModel] = []
    address_objects: list[AddressObjectModel] = []
    service_objects: list[ServiceObjectModel] = []

    def merge(self, other: NetworkFacts) -> NetworkFacts:
        """Merge another NetworkFacts into this one, returning a new instance."""
        return NetworkFacts(
            schema_version=self.schema_version,
            devices=self.devices + other.devices,
            interfaces=self.interfaces + other.interfaces,
            ip_addresses=self.ip_addresses + other.ip_addresses,
            subnets=self.subnets + other.subnets,
            vlans=self.vlans + other.vlans,
            macs=self.macs + other.macs,
            endpoints=self.endpoints + other.endpoints,
            firewall_rules=self.firewall_rules + other.firewall_rules,
            address_objects=self.address_objects + other.address_objects,
            service_objects=self.service_objects + other.service_objects,
        )
