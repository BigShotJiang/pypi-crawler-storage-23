"""Metrics collection for monitoring and testing."""
import json
import logging
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class RequestMetrics:
    """Track API request metrics."""
    endpoint: str
    method: str
    start_time: float
    end_time: float = 0.0
    status_code: int = 0
    error: str = ""

    @property
    def duration_ms(self) -> float:
        """Calculate request duration in milliseconds."""
        return (self.end_time - self.start_time) * 1000


@dataclass
class LicenseMetrics:
    """Track licensing operations."""
    validation_count: int = 0
    cache_hits: int = 0
    server_checks: int = 0
    grace_period_activations: int = 0
    failures: list[str] = field(default_factory=list)
    response_times: list[float] = field(default_factory=list)


class MetricsCollector:
    """Collect and export metrics during testing and monitoring."""

    def __init__(self):
        self.requests: list[RequestMetrics] = []
        self.license: LicenseMetrics = LicenseMetrics()

    def record_request(self, metrics: RequestMetrics):
        """Record a request metrics entry."""
        self.requests.append(metrics)
        logger.info(
            "Request: %s %s - %.1f ms - status %d",
            metrics.method,
            metrics.endpoint,
            metrics.duration_ms,
            metrics.status_code
        )

    def export_json(self, path: str):
        """Export metrics to JSON for analysis."""
        data = {
            "requests": [vars(r) for r in self.requests],
            "license": vars(self.license),
            "summary": self.summarize()
        }
        with open(path, 'w') as f:
            json.dump(data, f, indent=2)

    def summarize(self) -> dict:
        """Generate summary statistics."""
        if not self.requests:
            return {
                "total_requests": 0,
                "total_errors": 0,
                "error_rate": 0.0,
            }

        durations = [r.duration_ms for r in self.requests]
        errors = [r for r in self.requests if r.status_code >= 400]

        return {
            "total_requests": len(self.requests),
            "total_errors": len(errors),
            "error_rate": len(errors) / len(self.requests) if self.requests else 0,
            "avg_response_time_ms": sum(durations) / len(durations),
            "p50_response_time_ms": sorted(durations)[len(durations)//2],
            "p95_response_time_ms": sorted(durations)[int(len(durations)*0.95)],
            "p99_response_time_ms": sorted(durations)[int(len(durations)*0.99)],
            "max_response_time_ms": max(durations),
            "min_response_time_ms": min(durations),
        }
