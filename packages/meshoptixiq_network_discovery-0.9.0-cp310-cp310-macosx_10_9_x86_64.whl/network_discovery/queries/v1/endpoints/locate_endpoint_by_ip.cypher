MATCH (ip:IPAddress {address: $ip})<-[:USES_IP]-(e:Endpoint)
WHERE ($vrf IS NULL OR $vrf = '' OR coalesce(ip.vrf, 'global') = $vrf)
OPTIONAL MATCH (e)-[:CONNECTED_VIA]->(i)<-[:HAS_INTERFACE]-(d:Device)
RETURN e.ip_address    AS ip_address,
       e.mac_address   AS mac_address,
       coalesce(ip.vrf, 'global') AS vrf,
       d.hostname      AS device,
       i.name          AS interface
