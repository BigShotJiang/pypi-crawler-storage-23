MATCH (:MAC {address: $mac})<-[:USES_MAC]-(e:Endpoint)-[:CONNECTED_VIA]->(i)<-[:HAS_INTERFACE]-(d:Device)
RETURN d.name AS device, i.name AS interface, e;
