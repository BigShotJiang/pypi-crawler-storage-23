-- Locate an endpoint by its IP address; includes VRF context
-- Parameters: %(ip)s, %(vrf)s (optional — empty string means any VRF)

SELECT
    e.mac_address,
    e.ip_address,
    COALESCE(ip.vrf, 'global') AS vrf,
    e.first_seen,
    e.last_seen
FROM endpoints e
LEFT JOIN ip_addresses ip ON ip.address = e.ip_address
WHERE e.ip_address = %(ip)s
  AND (%(vrf)s = '' OR COALESCE(ip.vrf, 'global') = %(vrf)s);
