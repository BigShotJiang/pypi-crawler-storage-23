-- Endpoints connected to a specific interface
-- Parameters: %(device)s, %(interface)s

SELECT DISTINCT
    e.mac_address,
    e.ip_address,
    e.first_seen,
    e.last_seen
FROM endpoints e
JOIN mac_learned_on mlo ON e.mac_address = mlo.mac_address
WHERE mlo.device_hostname = %(device)s AND mlo.interface_name = %(interface)s;
