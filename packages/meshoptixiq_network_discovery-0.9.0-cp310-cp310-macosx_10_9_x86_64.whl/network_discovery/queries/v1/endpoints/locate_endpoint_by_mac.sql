SELECT 
    e.mac_address,
    e.ip_address,
    e.first_seen,
    e.last_seen
FROM endpoints e
WHERE e.mac_address = %(mac)s;
