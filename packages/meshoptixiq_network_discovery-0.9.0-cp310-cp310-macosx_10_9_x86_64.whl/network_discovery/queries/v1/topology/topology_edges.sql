-- All device-to-device connections — used for full topology graph
-- Deduplicates by using LEAST/GREATEST to normalise direction
-- Parameters: {}

SELECT DISTINCT
    LEAST(src_device, dst_device)    AS device_a,
    GREATEST(src_device, dst_device) AS device_b
FROM links
ORDER BY device_a, device_b;
