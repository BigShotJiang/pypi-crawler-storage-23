-- Devices directly connected to a given device
-- Parameters: %(device_name)s

-- Return neighbors connected via links table.
-- We check both directions: where input is src or dst.

SELECT DISTINCT
    CASE 
        WHEN src_device = %(device_name)s THEN dst_device
        ELSE src_device
    END AS neighbor
FROM links
WHERE src_device = %(device_name)s OR dst_device = %(device_name)s;
