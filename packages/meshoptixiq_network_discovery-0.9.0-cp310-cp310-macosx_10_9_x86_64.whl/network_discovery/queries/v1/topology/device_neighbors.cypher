MATCH (d:Device {name: $device_name})-[:HAS_INTERFACE]->(:Interface)-[:CONNECTED_TO]->(:Interface)<-[:HAS_INTERFACE]-(n:Device)
RETURN DISTINCT n.name AS neighbor;
