-- BFS N-hop neighborhood around a focal device
-- Parameters: %(device)s (TEXT), %(depth)s (INTEGER)
WITH RECURSIVE neighbors(device, depth) AS (
    SELECT %(device)s::TEXT AS device, 0
    UNION ALL
    SELECT
        CASE WHEN l.src_device = n.device THEN l.dst_device ELSE l.src_device END,
        n.depth + 1
    FROM links l
    JOIN neighbors n ON (l.src_device = n.device OR l.dst_device = n.device)
    WHERE n.depth < %(depth)s
)
SELECT DISTINCT
    LEAST(src_device, dst_device)    AS device_a,
    GREATEST(src_device, dst_device) AS device_b,
    src_interface                    AS interface_a,
    dst_interface                    AS interface_b
FROM links
WHERE src_device IN (SELECT DISTINCT device FROM neighbors)
  AND dst_device IN (SELECT DISTINCT device FROM neighbors)
ORDER BY device_a, device_b;
