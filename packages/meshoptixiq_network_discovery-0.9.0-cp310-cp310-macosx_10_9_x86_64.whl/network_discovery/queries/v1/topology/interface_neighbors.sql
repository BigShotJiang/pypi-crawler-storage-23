-- Interfaces connecting two devices
-- Parameters: %(device_a)s, %(device_b)s

-- Find links between device_a and device_b
SELECT 
    l.src_interface AS interface_a,
    l.dst_interface AS interface_b
FROM links l
WHERE l.src_device = %(device_a)s AND l.dst_device = %(device_b)s
UNION
SELECT 
    l.dst_interface AS interface_a,
    l.src_interface AS interface_b
FROM links l
WHERE l.dst_device = %(device_a)s AND l.src_device = %(device_b)s;
