// N-hop neighborhood around a focal device
// Parameters: $device (string), $depth (integer 1-2)
// $depth*2 relationship hops: Device→Interface→Interface→Device = 4 hops for depth=2
MATCH path = (focal:Device {hostname: $device})-[:HAS_INTERFACE|CONNECTED_TO*1..4]-(neighbor:Device)
WITH DISTINCT focal, collect(DISTINCT neighbor.hostname) AS neighbor_names
WITH focal, neighbor_names
UNWIND [focal.hostname] + neighbor_names AS all_names
WITH COLLECT(DISTINCT all_names) AS neighborhood
MATCH (a:Device)-[:HAS_INTERFACE]->(ia:Interface)-[:CONNECTED_TO]->(ib:Interface)<-[:HAS_INTERFACE]-(b:Device)
WHERE a.hostname IN neighborhood
  AND b.hostname IN neighborhood
  AND a.hostname < b.hostname
RETURN a.hostname AS device_a, b.hostname AS device_b,
       ia.name AS interface_a, ib.name AS interface_b
