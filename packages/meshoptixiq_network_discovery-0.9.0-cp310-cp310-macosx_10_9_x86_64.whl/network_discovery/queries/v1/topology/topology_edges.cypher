// All device-to-device connections — used for full topology graph
// Deduplicates edges by enforcing alphabetical device ordering
// Parameters: {}

MATCH (a:Device)-[:HAS_INTERFACE]->(ia:Interface)-[:CONNECTED_TO]->(ib:Interface)<-[:HAS_INTERFACE]-(b:Device)
WHERE a.name < b.name
RETURN
    a.name   AS device_a,
    b.name   AS device_b,
    ia.name  AS interface_a,
    ib.name  AS interface_b
ORDER BY device_a, device_b
