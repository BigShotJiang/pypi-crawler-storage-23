MATCH (d1:Device {name: $device_a})-[:HAS_INTERFACE]->(i1)-[:CONNECTED_TO]->(i2)<-[:HAS_INTERFACE]-(d2:Device {name: $device_b})
RETURN i1.name AS device_a_interface, i2.name AS device_b_interface;
