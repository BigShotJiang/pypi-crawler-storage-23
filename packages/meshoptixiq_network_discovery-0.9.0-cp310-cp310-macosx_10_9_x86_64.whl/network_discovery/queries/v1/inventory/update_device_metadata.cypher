// Update business metadata on a Device node from an external CMDB/IPAM source (e.g. NetBox).
// Parameters: hostname, nb_site, nb_tenant, nb_rack, nb_role (optional)
MATCH (d:Device {hostname: $hostname})
SET d.nb_site   = $nb_site,
    d.nb_tenant = $nb_tenant,
    d.nb_rack   = $nb_rack
RETURN d.hostname AS hostname,
       d.nb_site  AS nb_site,
       d.nb_tenant AS nb_tenant,
       d.nb_rack  AS nb_rack
