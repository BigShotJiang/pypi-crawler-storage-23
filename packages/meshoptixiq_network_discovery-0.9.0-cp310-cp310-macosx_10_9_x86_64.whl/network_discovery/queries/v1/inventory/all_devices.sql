-- All discovered devices — hostname, vendor, model, OS, serial
-- Parameters: {}

SELECT
    hostname,
    vendor,
    model,
    serial,
    os_version,
    collected_at::text AS collected_at
FROM devices
ORDER BY hostname;
