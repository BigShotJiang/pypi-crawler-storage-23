-- Update business metadata on a device row from an external CMDB/IPAM source (e.g. NetBox).
-- Parameters: hostname, nb_site, nb_tenant, nb_rack
UPDATE devices
SET    nb_site   = %(nb_site)s,
       nb_tenant = %(nb_tenant)s,
       nb_rack   = %(nb_rack)s
WHERE  hostname  = %(hostname)s
RETURNING hostname, nb_site, nb_tenant, nb_rack;
