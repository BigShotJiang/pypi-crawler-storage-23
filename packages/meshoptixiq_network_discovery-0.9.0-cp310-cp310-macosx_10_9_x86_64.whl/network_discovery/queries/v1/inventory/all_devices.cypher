// All discovered devices — hostname, vendor, model, OS, serial
// Parameters: {}

MATCH (d:Device)
RETURN
    d.hostname    AS hostname,
    d.vendor      AS vendor,
    d.model       AS model,
    d.serial      AS serial,
    d.os_version  AS os_version,
    toString(d.collected_at) AS collected_at
ORDER BY d.hostname
