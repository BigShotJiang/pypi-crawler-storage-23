-- Interfaces that are up but have no description configured
-- Parameters: {}

SELECT d.hostname AS device, i.name AS interface, i.ip_address AS ip
FROM interfaces i
JOIN devices d ON d.hostname = i.device_hostname
WHERE (i.description IS NULL OR i.description = '')
  AND i.status = 'up'
ORDER BY d.hostname, i.name;
