-- IP addresses assigned to more than one device/interface (within the same VRF)
-- Parameters: {}

SELECT address, vrf, count(*) AS occurrences
FROM ip_addresses
GROUP BY address, vrf
HAVING count(*) > 1
ORDER BY occurrences DESC, address;
