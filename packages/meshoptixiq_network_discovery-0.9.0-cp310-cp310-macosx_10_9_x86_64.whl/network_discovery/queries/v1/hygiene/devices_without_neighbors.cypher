MATCH (d:Device)
WHERE NOT (d)-[:HAS_INTERFACE]->(:Interface)-[:CONNECTED_TO]->(:Interface)
RETURN d.name;
