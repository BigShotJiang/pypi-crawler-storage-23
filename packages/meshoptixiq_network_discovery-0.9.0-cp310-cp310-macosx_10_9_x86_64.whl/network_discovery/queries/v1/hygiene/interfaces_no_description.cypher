// Interfaces that are up but have no description configured
// Parameters: {}

MATCH (d:Device)-[:HAS_INTERFACE]->(i:Interface)
WHERE (i.description IS NULL OR i.description = '')
  AND i.status = 'up'
RETURN
    d.hostname   AS device,
    i.name       AS interface,
    i.ip_address AS ip
ORDER BY d.hostname, i.name
