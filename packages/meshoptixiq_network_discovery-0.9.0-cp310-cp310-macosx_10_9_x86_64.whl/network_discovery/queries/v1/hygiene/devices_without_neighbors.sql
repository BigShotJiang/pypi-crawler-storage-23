-- Devices with no detected neighbors
-- Parameters: {}

-- Devices that do not appear in any links (as src or dst).
-- Requires `links` table to be populated.
SELECT 
    d.hostname
FROM devices d
WHERE d.hostname NOT IN (SELECT src_device FROM links) 
  AND d.hostname NOT IN (SELECT dst_device FROM links);
