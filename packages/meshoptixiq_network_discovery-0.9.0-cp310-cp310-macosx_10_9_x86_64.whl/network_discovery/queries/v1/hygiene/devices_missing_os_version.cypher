// Devices with no OS version recorded
// Parameters: {}

MATCH (d:Device)
WHERE d.os_version IS NULL OR d.os_version = ''
RETURN
    d.hostname AS hostname,
    d.vendor   AS vendor,
    d.model    AS model
ORDER BY d.hostname
