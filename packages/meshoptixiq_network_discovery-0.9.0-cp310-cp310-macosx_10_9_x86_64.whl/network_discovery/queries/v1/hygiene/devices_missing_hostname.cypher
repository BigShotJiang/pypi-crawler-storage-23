// Devices with no hostname recorded
// Parameters: {}

MATCH (d:Device)
WHERE d.hostname IS NULL OR d.hostname = ''
RETURN
    d.vendor   AS vendor,
    d.model    AS model,
    toString(d.collected_at) AS collected_at
