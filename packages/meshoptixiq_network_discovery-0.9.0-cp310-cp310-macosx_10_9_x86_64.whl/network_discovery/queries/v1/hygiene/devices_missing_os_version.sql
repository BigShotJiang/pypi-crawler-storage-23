-- Devices with no OS version recorded
-- Parameters: {}

SELECT hostname, vendor, model
FROM devices
WHERE os_version IS NULL OR os_version = ''
ORDER BY hostname;
