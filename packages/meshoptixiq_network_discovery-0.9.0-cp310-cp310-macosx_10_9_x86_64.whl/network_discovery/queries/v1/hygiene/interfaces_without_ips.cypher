MATCH (i:Interface)
WHERE NOT (i)-[:HAS_IP]->(:IPAddress)
RETURN i.name, i.device;
