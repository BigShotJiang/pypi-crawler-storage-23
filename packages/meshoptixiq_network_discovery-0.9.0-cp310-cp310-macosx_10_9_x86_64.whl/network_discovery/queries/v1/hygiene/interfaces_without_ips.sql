-- Interfaces that have no IP address assigned
-- Parameters: {}

SELECT 
    i.device_hostname,
    i.name
FROM interfaces i
LEFT JOIN ip_addresses ip ON i.device_hostname = ip.device_hostname AND i.name = ip.interface_name
WHERE ip.address IS NULL;
