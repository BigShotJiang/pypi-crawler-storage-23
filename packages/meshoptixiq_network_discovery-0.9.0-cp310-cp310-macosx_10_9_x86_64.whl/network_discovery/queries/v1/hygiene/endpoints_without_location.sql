-- Endpoints that could not be traced to a physical location
-- "Physical location" = associated with a Switch Interface via MAC.
-- Parameters: {}

SELECT 
    e.mac_address,
    e.ip_address
FROM endpoints e
LEFT JOIN mac_learned_on mlo ON e.mac_address = mlo.mac_address
WHERE mlo.device_hostname IS NULL;
