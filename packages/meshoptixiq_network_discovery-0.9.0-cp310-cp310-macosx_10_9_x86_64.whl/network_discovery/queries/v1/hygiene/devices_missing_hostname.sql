-- Devices with no hostname recorded
-- Parameters: {}

SELECT vendor, model, collected_at::text
FROM devices
WHERE hostname IS NULL OR hostname = '';
