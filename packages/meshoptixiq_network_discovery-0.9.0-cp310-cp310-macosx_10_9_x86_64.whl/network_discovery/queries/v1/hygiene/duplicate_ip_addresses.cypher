// IP addresses assigned to more than one device/interface (within the same VRF)
// Parameters: {}

MATCH (ip:IPAddress)
WITH ip.address AS address, ip.vrf AS vrf, count(*) AS cnt
WHERE cnt > 1
RETURN address, vrf, cnt AS occurrences
ORDER BY occurrences DESC, address
