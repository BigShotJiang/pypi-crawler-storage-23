MATCH (e:Endpoint)
WHERE NOT (e)-[:CONNECTED_VIA]->(:Interface)
RETURN e;
