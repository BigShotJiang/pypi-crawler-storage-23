MATCH (sub:Subnet)<-[:IN_SUBNET]-(ip:IPAddress)
WHERE sub.network_address + '/' + toString(sub.prefix_length) = $cidr
  AND ($vrf IS NULL OR $vrf = '' OR ip.vrf = $vrf)
RETURN ip.address    AS address,
       ip.prefix_length AS prefix_length,
       coalesce(ip.vrf, 'global') AS vrf,
       ip.device_hostname AS device,
       ip.interface_name  AS interface
