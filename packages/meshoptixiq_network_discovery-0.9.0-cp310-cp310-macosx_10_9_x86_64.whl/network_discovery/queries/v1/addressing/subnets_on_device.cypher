MATCH (d:Device {name: $device})-[:HAS_INTERFACE]->(:Interface)-[:HAS_IP]->(ip:IPAddress)-[:IN_SUBNET]->(s:Subnet)
RETURN DISTINCT s.cidr;
