-- IPs not associated with any known subnet (VRF-aware)
-- Parameters: {}

SELECT
    ip.address,
    COALESCE(ip.vrf, 'global') AS vrf,
    ip.device_hostname,
    ip.interface_name
FROM ip_addresses ip
LEFT JOIN ip_subnet_memberships ism ON ip.address = ism.ip_address
WHERE ism.subnet_address IS NULL;
