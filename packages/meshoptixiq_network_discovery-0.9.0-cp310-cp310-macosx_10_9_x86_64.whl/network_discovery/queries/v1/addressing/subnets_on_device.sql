-- Subnets present on a device
-- Parameters: %(device)s

-- Found via IPs on the device's interfaces mapping to subnets.
SELECT DISTINCT
    s.network_address,
    s.prefix_length,
    s.version
FROM subnets s
JOIN ip_subnet_memberships ism ON s.network_address = ism.subnet_address
JOIN ip_addresses ip ON ism.ip_address = ip.address
WHERE ip.device_hostname = %(device)s;
