-- IP addresses allocated within a subnet (VRF-aware)
-- Parameters: %(cidr)s (TEXT), %(vrf)s (TEXT, optional — empty string means all VRFs)

SELECT
    ip.address,
    COALESCE(ip.vrf, 'global') AS vrf,
    ip.prefix_length,
    ip.version,
    ip.interface_name,
    ip.device_hostname
FROM ip_addresses ip
JOIN ip_subnet_memberships ism ON ip.address = ism.ip_address
WHERE ism.subnet_address = %(cidr)s
  AND (%(vrf)s = '' OR COALESCE(ip.vrf, 'global') = %(vrf)s);
