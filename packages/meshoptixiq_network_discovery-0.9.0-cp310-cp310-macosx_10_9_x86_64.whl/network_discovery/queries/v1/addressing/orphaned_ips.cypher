MATCH (ip:IPAddress)
WHERE NOT (ip)-[:IN_SUBNET]->(:Subnet)
RETURN ip.address AS address,
       coalesce(ip.vrf, 'global') AS vrf,
       ip.device_hostname AS device
