MATCH (:VLAN {id: $vlan})<-[:TAGGED_IN]-(:Interface)<-[:CONNECTED_VIA]-(e:Endpoint)
RETURN DISTINCT e;
