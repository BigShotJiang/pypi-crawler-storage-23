MATCH (d:Device {name: $device})-[:HAS_INTERFACE]->(i {name: $interface})
MATCH (i)<-[:CONNECTED_VIA]-(e:Endpoint)
RETURN e;
