-- Endpoints impacted if an interface goes down
-- Parameters: %(device)s, %(interface)s

-- 1. Endpoints learned on this interface (via MAC)
SELECT DISTINCT
    e.mac_address,
    e.ip_address,
    e.first_seen,
    e.last_seen
FROM endpoints e
JOIN mac_learned_on mlo ON e.mac_address = mlo.mac_address
WHERE mlo.device_hostname = %(device)s AND mlo.interface_name = %(interface)s

UNION

-- 2. Endpoints using IPs provided by this interface (via IP/Subnet?)
-- The graph model has (iface)-[:HAS_IP]->(ip)<-[:USES_IP]-(ep)
SELECT DISTINCT
    e.mac_address,
    e.ip_address,
    e.first_seen,
    e.last_seen
FROM endpoints e
JOIN ip_addresses ip ON e.ip_address = ip.address
JOIN interfaces i ON ip.device_hostname = i.device_hostname AND ip.interface_name = i.name
WHERE i.device_hostname = %(device)s AND i.name = %(interface)s;
