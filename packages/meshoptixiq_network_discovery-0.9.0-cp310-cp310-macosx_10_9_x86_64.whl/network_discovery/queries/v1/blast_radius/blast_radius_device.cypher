MATCH (d:Device {name: $device})-[:HAS_INTERFACE]->(i)
MATCH (i)<-[:CONNECTED_VIA]-(e:Endpoint)
RETURN DISTINCT e;
