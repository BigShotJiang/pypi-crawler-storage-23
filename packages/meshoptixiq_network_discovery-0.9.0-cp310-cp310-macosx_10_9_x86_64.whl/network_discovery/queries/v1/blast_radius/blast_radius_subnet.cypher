MATCH (s:Subnet {cidr: $cidr})<-[:IN_SUBNET]-(:IPAddress)<-[:USES_IP]-(e:Endpoint)
RETURN DISTINCT e;
