-- Endpoints impacted if a device goes down
-- Parameters: %(device)s

-- 1. Endpoints learned on any interface of this device
SELECT DISTINCT
    e.mac_address,
    e.ip_address,
    e.first_seen,
    e.last_seen
FROM endpoints e
JOIN mac_learned_on mlo ON e.mac_address = mlo.mac_address
WHERE mlo.device_hostname = %(device)s

UNION

-- 2. Endpoints using IPs provided by this device
SELECT DISTINCT
    e.mac_address,
    e.ip_address,
    e.first_seen,
    e.last_seen
FROM endpoints e
JOIN ip_addresses ip ON e.ip_address = ip.address
WHERE ip.device_hostname = %(device)s;
