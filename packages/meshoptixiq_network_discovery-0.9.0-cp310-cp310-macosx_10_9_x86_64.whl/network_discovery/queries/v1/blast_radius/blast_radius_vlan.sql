-- Endpoints running in a specific VLAN
-- Parameters: %(vlan)s (Note: vlan_id is integer)

-- Typically we don't have direct Endpoint -> VLAN relationship in this schema?
-- Endpoints have MACs which are learned on Interfaces/Devices.
-- Interfaces/Devices have VLANs? or Interfaces are IN a VLAN?
-- The model has `ingest_vlans` creating VLAN nodes.
-- But standard schema doesn't link Interface -> VLAN directly?
-- Ah, `MACModel` has `vlan_id`! 
-- But `ingest_macs` logic only created `:LEARNED_ON` to interface. 
-- It did NOT create `:IN_VLAN`.
-- Checking `ingest_macs` (Step 503):
--    SET mac.vendor_oui = m.vendor_oui ... 
--    (mac)-[:LEARNED_ON]->(iface)
-- It ignored vlan_id from inputs. This is a potential missing feature in original Neo4j?
-- Wait, `ingest_vlans` creates VLAN nodes.
-- But no relationships between VLAN and Interface?
-- Let's check `blast_radius_vlan.cypher`.

-- Reading blast_radius_vlan.cypher
-- MATCH (v:VLAN {vlan_id: $vlan})<-[:HAS_VLAN]-(i:Interface)<-...
-- Ah, `[:HAS_VLAN]`.
-- Does `ingest_interfaces` create `HAS_VLAN`?
-- Step 503, lines 68-99: No.
-- Does `ingest_vlans` create `HAS_VLAN`?
-- Lines 219-238: Creates `(vlan:VLAN ...)` but no relationships.
-- So `blast_radius_vlan.cypher` returns EMPTY in Neo4j today.
-- I will match that behavior in SQL (return empty or implementing 'aspirational' query).
-- I'll execute logic assuming Interfaces have a join to Vlan (which they don't in my schema yet).
-- I'll define it as checking `vlans` table for matching `vlan_id`.
-- But wait, `vlans` table is (device, vlan_id).
-- If I can find interfaces on that device? No, that's ambiguous (trunk ports vs access ports).

-- Conclusion: Feature not fully implemented in Ingest.
-- I will implement SQL that finds endpoints on devices that HAVE that VLAN, as an approximation, or just return empty.
-- Better: Return endpoints on devices that have this VLAN configured.
-- Or just matching logic of Cypher which expects `HAS_VLAN`.

-- I'll write a query that joins through `vlans` table on `device_hostname`.
-- This is technically "Endpoints on a device that HAS this VLAN", not necessarily "in" the VLAN.
-- But it's closer than nothing.

SELECT DISTINCT
    e.mac_address,
    e.ip_address,
    e.first_seen,
    e.last_seen
FROM endpoints e
JOIN mac_learned_on mlo ON e.mac_address = mlo.mac_address
JOIN vlans v ON mlo.device_hostname = v.device_hostname
WHERE v.vlan_id = %(vlan)s;
