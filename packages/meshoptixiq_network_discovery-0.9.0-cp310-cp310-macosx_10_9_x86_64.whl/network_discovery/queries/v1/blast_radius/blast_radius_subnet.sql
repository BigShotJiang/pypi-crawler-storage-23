-- Endpoints dependent on a specific subnet
-- Parameters: %(cidr)s

SELECT DISTINCT
    e.mac_address,
    e.ip_address,
    e.first_seen,
    e.last_seen
FROM endpoints e
JOIN ip_subnet_memberships ism ON e.ip_address = ism.ip_address
WHERE ism.subnet_address = %(cidr)s;
