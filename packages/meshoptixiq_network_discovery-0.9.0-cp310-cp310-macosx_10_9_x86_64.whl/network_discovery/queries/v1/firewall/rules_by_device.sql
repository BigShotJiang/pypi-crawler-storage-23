-- All firewall rules for a given device, ordered by rule_order
-- Parameters: %(device)s

SELECT rule_id,
       rule_name,
       rule_order,
       action,
       source_zones,
       destination_zones,
       source_addresses,
       destination_addresses,
       services,
       protocols,
       destination_ports,
       enabled,
       log_enabled,
       comments,
       vendor,
       collected_at
FROM firewall_rules
WHERE device_hostname = %(device)s
ORDER BY rule_order;
