-- Evaluate firewall rules for traffic between source and destination IPs.
-- Parameters: %(source_ip)s, %(destination_ip)s, %(protocol)s, %(destination_port)s
-- Pass 'any' for protocol/destination_port to skip those filters.

SELECT device_hostname          AS firewall,
       rule_name,
       rule_id,
       rule_order,
       action,
       source_zones,
       destination_zones,
       log_enabled              AS logged
FROM firewall_rules
WHERE enabled = true
  AND (
    %(source_ip)s = ANY(source_addresses)
    OR 'any' = ANY(source_addresses)
    OR EXISTS (
      SELECT 1 FROM unnest(source_addresses) a WHERE a LIKE '%/%'
    )
  )
  AND (
    %(destination_ip)s = ANY(destination_addresses)
    OR 'any' = ANY(destination_addresses)
    OR EXISTS (
      SELECT 1 FROM unnest(destination_addresses) a WHERE a LIKE '%/%'
    )
  )
  AND (
    %(protocol)s = 'any'
    OR array_length(protocols, 1) IS NULL
    OR %(protocol)s = ANY(protocols)
  )
  AND (
    %(destination_port)s = 'any'
    OR array_length(destination_ports, 1) IS NULL
    OR %(destination_port)s = ANY(destination_ports)
  )
ORDER BY device_hostname, rule_order;
