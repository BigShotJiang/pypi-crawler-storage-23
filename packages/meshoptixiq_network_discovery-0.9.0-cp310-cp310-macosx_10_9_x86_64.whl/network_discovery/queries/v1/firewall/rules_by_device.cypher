// All firewall rules for a given device, ordered by rule_order
// Parameters: $device

MATCH (d:Device {hostname: $device})-[:HAS_FIREWALL_RULE]->(rule:FirewallRule)
RETURN rule.rule_id          AS rule_id,
       rule.rule_name        AS rule_name,
       rule.rule_order       AS rule_order,
       rule.action           AS action,
       rule.source_zones     AS source_zones,
       rule.destination_zones AS destination_zones,
       rule.source_addresses  AS source_addresses,
       rule.destination_addresses AS destination_addresses,
       rule.services         AS services,
       rule.protocols        AS protocols,
       rule.destination_ports AS destination_ports,
       rule.enabled          AS enabled,
       rule.log_enabled      AS log_enabled,
       rule.comments         AS comments,
       rule.vendor           AS vendor,
       rule.collected_at     AS collected_at
ORDER BY rule.rule_order
