// All rules between a source zone and destination zone on any device
// Parameters: $source_zone, $destination_zone

MATCH (d:Device)-[:HAS_FIREWALL_RULE]->(rule:FirewallRule)
WHERE $source_zone IN rule.source_zones
  AND $destination_zone IN rule.destination_zones
RETURN d.hostname              AS firewall,
       rule.rule_id            AS rule_id,
       rule.rule_name          AS rule_name,
       rule.rule_order         AS rule_order,
       rule.action             AS action,
       rule.source_zones       AS source_zones,
       rule.destination_zones  AS destination_zones,
       rule.source_addresses   AS source_addresses,
       rule.destination_addresses AS destination_addresses,
       rule.services           AS services,
       rule.enabled            AS enabled
ORDER BY d.hostname, rule.rule_order
