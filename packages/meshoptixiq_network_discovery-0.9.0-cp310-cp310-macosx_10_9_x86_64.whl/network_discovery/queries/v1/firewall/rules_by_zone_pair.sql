-- All rules between a source zone and destination zone on any device
-- Parameters: %(source_zone)s, %(destination_zone)s

SELECT device_hostname         AS firewall,
       rule_id,
       rule_name,
       rule_order,
       action,
       source_zones,
       destination_zones,
       source_addresses,
       destination_addresses,
       services,
       enabled
FROM firewall_rules
WHERE %(source_zone)s = ANY(source_zones)
  AND %(destination_zone)s = ANY(destination_zones)
ORDER BY device_hostname, rule_order;
