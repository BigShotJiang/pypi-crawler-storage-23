-- All deny/drop rules across all firewalls
-- Parameters: {}

SELECT device_hostname          AS firewall,
       rule_id,
       rule_name,
       rule_order,
       action,
       source_zones,
       destination_zones,
       source_addresses,
       destination_addresses,
       enabled
FROM firewall_rules
WHERE action IN ('deny', 'drop', 'reject')
ORDER BY device_hostname, rule_order;
