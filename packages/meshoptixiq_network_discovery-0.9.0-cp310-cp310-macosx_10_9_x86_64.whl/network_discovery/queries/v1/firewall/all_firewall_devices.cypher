// All devices with at least one collected firewall rule
// Parameters: {}

MATCH (d:Device)-[:HAS_FIREWALL_RULE]->(rule:FirewallRule)
WITH d, count(rule) AS rule_count
RETURN d.hostname   AS hostname,
       d.vendor     AS vendor,
       d.model      AS model,
       d.os_version AS os_version,
       rule_count
ORDER BY d.hostname
