// All deny/drop rules across all firewalls
// Parameters: {}

MATCH (d:Device)-[:HAS_FIREWALL_RULE]->(rule:FirewallRule)
WHERE rule.action IN ["deny", "drop", "reject"]
RETURN d.hostname              AS firewall,
       rule.rule_id            AS rule_id,
       rule.rule_name          AS rule_name,
       rule.rule_order         AS rule_order,
       rule.action             AS action,
       rule.source_zones       AS source_zones,
       rule.destination_zones  AS destination_zones,
       rule.source_addresses   AS source_addresses,
       rule.destination_addresses AS destination_addresses,
       rule.enabled            AS enabled
ORDER BY d.hostname, rule.rule_order
