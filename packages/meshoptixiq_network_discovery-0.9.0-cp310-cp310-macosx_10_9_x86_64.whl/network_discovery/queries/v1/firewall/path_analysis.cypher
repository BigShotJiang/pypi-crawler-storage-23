// Evaluate firewall rules along the network path between source and destination IPs.
// Returns matching enabled rules ordered by firewall hostname and rule_order.
// The API layer appends an implicit default-deny for firewalls with no matching rows.
// Parameters: $source_ip, $destination_ip, $protocol (use "any" to skip), $destination_port (use "any" to skip)

MATCH (fw:Device)-[:HAS_FIREWALL_RULE]->(rule:FirewallRule)
WHERE rule.enabled = true
  AND (
    $source_ip IN rule.source_addresses
    OR "any" IN rule.source_addresses
    OR any(addr IN rule.source_addresses WHERE addr CONTAINS "/")
  )
  AND (
    $destination_ip IN rule.destination_addresses
    OR "any" IN rule.destination_addresses
    OR any(addr IN rule.destination_addresses WHERE addr CONTAINS "/")
  )
  AND (
    $protocol = "any"
    OR size(rule.protocols) = 0
    OR $protocol IN rule.protocols
  )
  AND (
    $destination_port = "any"
    OR size(rule.destination_ports) = 0
    OR $destination_port IN rule.destination_ports
  )
RETURN fw.hostname              AS firewall,
       rule.rule_name          AS rule_name,
       rule.rule_id            AS rule_id,
       rule.rule_order         AS rule_order,
       rule.action             AS action,
       rule.source_zones       AS source_zones,
       rule.destination_zones  AS destination_zones,
       rule.log_enabled        AS logged
ORDER BY fw.hostname, rule.rule_order
