-- All devices with at least one collected firewall rule
-- Parameters: {}

SELECT d.hostname,
       d.vendor,
       d.model,
       d.os_version,
       count(fr.rule_id) AS rule_count
FROM devices d
JOIN firewall_rules fr ON fr.device_hostname = d.hostname
GROUP BY d.hostname, d.vendor, d.model, d.os_version
ORDER BY d.hostname;
