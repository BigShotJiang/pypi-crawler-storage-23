// Dashboard summary counts: devices, interfaces, endpoints, VLANs
// Parameters: {}

MATCH (d:Device) WITH count(d) AS device_count
MATCH (i:Interface) WITH device_count, count(i) AS interface_count
OPTIONAL MATCH (e:Endpoint) WITH device_count, interface_count, count(e) AS endpoint_count
OPTIONAL MATCH (v:VLAN) RETURN device_count, interface_count, endpoint_count, count(v) AS vlan_count
