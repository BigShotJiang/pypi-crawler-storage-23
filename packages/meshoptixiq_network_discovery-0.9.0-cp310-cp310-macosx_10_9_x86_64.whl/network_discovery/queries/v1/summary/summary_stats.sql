-- Dashboard summary counts: devices, interfaces, endpoints, VLANs
-- Parameters: {}

SELECT
    (SELECT count(*) FROM devices)    AS device_count,
    (SELECT count(*) FROM interfaces) AS interface_count,
    (SELECT count(*) FROM endpoints)  AS endpoint_count,
    (SELECT count(*) FROM vlans)      AS vlan_count;
