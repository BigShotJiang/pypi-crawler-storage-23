"""MCP resource handlers."""
