"""MCP resource URI handlers.

Resources expose read-only network data that AI assistants can load as
background context before reasoning about the network.

URIs:
  network://inventory/summary   — device/interface/endpoint/VLAN counts
  network://inventory/devices   — full device inventory (cap 500)
  network://topology/edges      — all device-to-device connections
  network://health/hygiene      — merged hygiene report
  network://schema/queries      — all query definitions from registry.yaml
  network://firewall/policies   — firewall devices + deny-rule summary
"""

from __future__ import annotations

import json
from typing import Any

import anyio
from mcp.server import Server
from mcp.types import Resource

from network_discovery.mcp.licensing import require_feature
from network_discovery.mcp.query_engine import execute_query, get_registry

_RESOURCES = [
    Resource(
        uri="network://inventory/summary",  # type: ignore[arg-type]
        name="Network Inventory Summary",
        description="Device, interface, endpoint, and VLAN counts from the network graph.",
        mimeType="application/json",
    ),
    Resource(
        uri="network://inventory/devices",  # type: ignore[arg-type]
        name="Network Device Inventory",
        description="Full device inventory including vendor, model, OS version, and serial (capped at 500).",
        mimeType="application/json",
    ),
    Resource(
        uri="network://topology/edges",  # type: ignore[arg-type]
        name="Network Topology Edges",
        description="All device-to-device connections in the network topology graph.",
        mimeType="application/json",
    ),
    Resource(
        uri="network://health/hygiene",  # type: ignore[arg-type]
        name="Network Hygiene Report",
        description=(
            "Merged hygiene data: devices without neighbours, interfaces without IPs, "
            "and endpoints without a physical location."
        ),
        mimeType="application/json",
    ),
    Resource(
        uri="network://schema/queries",  # type: ignore[arg-type]
        name="Query Schema",
        description="All 23 query definitions from registry.yaml — no DB call required.",
        mimeType="application/json",
    ),
    Resource(
        uri="network://firewall/policies",  # type: ignore[arg-type]
        name="Firewall Policies",
        description="All firewall devices and deny-rule summary from the graph.",
        mimeType="application/json",
    ),
]


def register_resources(server: Server) -> None:
    """Register all resource list and read handlers on *server*."""

    @server.list_resources()
    async def list_resources() -> list[Resource]:
        return _RESOURCES

    @server.read_resource()
    async def read_resource(uri: Any) -> str:
        uri_str = str(uri)

        if uri_str == "network://inventory/summary":
            require_feature("api_access")
            rows = await anyio.to_thread.run_sync(lambda: execute_query("summary_stats", {}))
            return json.dumps(rows, default=str)

        if uri_str == "network://inventory/devices":
            require_feature("api_access")
            rows = await anyio.to_thread.run_sync(
                lambda: execute_query("all_devices", {}, limit=500)
            )
            return json.dumps(rows, default=str)

        if uri_str == "network://topology/edges":
            require_feature("api_access")
            rows = await anyio.to_thread.run_sync(
                lambda: execute_query("topology_edges", {})
            )
            return json.dumps(rows, default=str)

        if uri_str == "network://health/hygiene":
            require_feature("api_access")
            devices, interfaces, endpoints = await anyio.to_thread.run_sync(
                _fetch_hygiene
            )
            data: dict[str, Any] = {
                "devices_without_neighbors": devices,
                "interfaces_without_ips": interfaces,
                "endpoints_without_location": endpoints,
            }
            return json.dumps(data, default=str)

        if uri_str == "network://schema/queries":
            registry = get_registry()
            return json.dumps(list(registry.values()), default=str)

        if uri_str == "network://firewall/policies":
            require_feature("api_access")
            devices, deny_rules = await anyio.to_thread.run_sync(_fetch_firewall_policies)
            data = {
                "devices": devices,
                "deny_rules": deny_rules,
            }
            return json.dumps(data, default=str)

        raise ValueError(f"Unknown resource URI: {uri_str!r}")


# ---------------------------------------------------------------------------
# Synchronous helpers (run in thread pool)
# ---------------------------------------------------------------------------

def _fetch_hygiene() -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    """Fetch all three hygiene queries synchronously."""
    devices = execute_query("devices_without_neighbors", {})
    interfaces = execute_query("interfaces_without_ips", {})
    endpoints = execute_query("endpoints_without_location", {})
    return devices, interfaces, endpoints


def _fetch_firewall_policies() -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Fetch firewall devices and deny-rules summary synchronously."""
    devices = execute_query("all_firewall_devices", {})
    deny_rules = execute_query("deny_rules_summary", {})
    return devices, deny_rules
