"""MCP prompt templates."""
