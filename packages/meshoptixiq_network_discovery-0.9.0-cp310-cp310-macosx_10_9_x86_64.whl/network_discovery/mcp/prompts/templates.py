"""MCP pre-defined prompt templates.

Prompts guide AI assistants through common network operations by structuring
the right sequence of tool calls and reasoning steps.

Prompts:
  network_incident_triage           — blast radius + neighbour assessment
  network_change_impact_assessment  — pre-maintenance impact report
  network_endpoint_hunt             — locate endpoint and trace physical path
  network_addressing_audit          — IP gap and orphaned IP analysis
  network_hygiene_report            — full hygiene check + remediation
  network_firewall_audit            — security policy audit
"""

from __future__ import annotations

from mcp.server import Server
from mcp.types import (
    GetPromptResult,
    Prompt,
    PromptArgument,
    PromptMessage,
    TextContent,
)

_PROMPTS = [
    Prompt(
        name="network_incident_triage",
        description=(
            "Structured network incident triage: assess blast radius, retrieve neighbouring "
            "devices, and summarise the scope of impact for a named device."
        ),
        arguments=[
            PromptArgument(
                name="affected_device",
                description="Hostname of the device involved in the incident.",
                required=True,
            ),
            PromptArgument(
                name="incident_description",
                description="Brief description of the incident or alert (optional).",
                required=False,
            ),
        ],
    ),
    Prompt(
        name="network_change_impact_assessment",
        description=(
            "Pre-maintenance change impact report: identify affected endpoints, neighbouring "
            "devices, and subnets before a planned change."
        ),
        arguments=[
            PromptArgument(
                name="device",
                description="Hostname of the device to be changed.",
                required=True,
            ),
            PromptArgument(
                name="interface",
                description="Specific interface to be changed (optional — omit for device-level).",
                required=False,
            ),
            PromptArgument(
                name="change_description",
                description="Brief description of the planned change (optional).",
                required=False,
            ),
        ],
    ),
    Prompt(
        name="network_endpoint_hunt",
        description=(
            "Locate an endpoint by IP or MAC address and trace its physical path to the "
            "upstream network switch."
        ),
        arguments=[
            PromptArgument(
                name="identifier",
                description="The IP address or MAC address to search for.",
                required=True,
            ),
            PromptArgument(
                name="identifier_type",
                description="Type of identifier: 'ip' or 'mac'.",
                required=True,
            ),
        ],
    ),
    Prompt(
        name="network_addressing_audit",
        description=(
            "Audit IP addressing: identify gaps, orphaned IPs, and allocation efficiency "
            "for a specific subnet or the entire network."
        ),
        arguments=[
            PromptArgument(
                name="cidr",
                description="Subnet in CIDR notation to audit (optional — omit for full network).",
                required=False,
            ),
        ],
    ),
    Prompt(
        name="network_hygiene_report",
        description=(
            "Full network hygiene check: devices without neighbours, interfaces without IPs, "
            "endpoints without locations — with a prioritised remediation checklist."
        ),
        arguments=[],
    ),
    Prompt(
        name="network_firewall_audit",
        description=(
            "Audit firewall security policies: identify any/any permit rules, zone pairs "
            "with no deny rule, and deny-rule hit counts."
        ),
        arguments=[
            PromptArgument(
                name="device",
                description="Hostname of a specific firewall to audit (optional — omit for all).",
                required=False,
            ),
        ],
    ),
]


def register_prompts(server: Server) -> None:
    """Register all prompt list and get handlers on *server*."""

    @server.list_prompts()
    async def list_prompts() -> list[Prompt]:
        return _PROMPTS

    @server.get_prompt()
    async def get_prompt(name: str, arguments: dict[str, str] | None) -> GetPromptResult:
        args = arguments or {}

        if name == "network_incident_triage":
            device = args.get("affected_device", "<device>")
            description = args.get("incident_description", "")
            incident_ctx = f" Incident description: {description}" if description else ""
            text = (
                f"You are assisting with a network incident affecting device '{device}'.{incident_ctx}\n\n"
                "Please perform the following steps:\n"
                f"1. Call `meshq_blast_radius_device` with device='{device}' to identify all "
                "endpoints that may be impacted.\n"
                f"2. Call `meshq_topology_device_neighbors` with device_name='{device}' to "
                "find neighbouring devices that may be affected by cascading failures.\n"
                f"3. Call `meshq_inventory_summary_stats` to understand the overall network scale.\n"
                "4. Summarise the blast radius, list impacted endpoints, note any critical "
                "neighbouring devices, and recommend immediate remediation steps."
            )

        elif name == "network_change_impact_assessment":
            device = args.get("device", "<device>")
            interface = args.get("interface", "")
            change_desc = args.get("change_description", "")
            change_ctx = f" Change: {change_desc}" if change_desc else ""
            if interface:
                blast_tool = (
                    f"Call `meshq_blast_radius_interface` with device='{device}' and "
                    f"interface='{interface}'"
                )
            else:
                blast_tool = f"Call `meshq_blast_radius_device` with device='{device}'"
            text = (
                f"You are preparing a change impact assessment for device '{device}'.{change_ctx}\n\n"
                "Please perform the following steps:\n"
                f"1. {blast_tool} to identify endpoints at risk.\n"
                f"2. Call `meshq_topology_device_neighbors` with device_name='{device}' to "
                "identify upstream/downstream devices.\n"
                f"3. Call `meshq_addressing_subnets_on_device` with device='{device}' to list "
                "subnets that will be affected.\n"
                "4. Produce a pre-change impact report: number of affected endpoints, "
                "neighbouring devices, subnets, and a recommended change window."
            )

        elif name == "network_endpoint_hunt":
            identifier = args.get("identifier", "<identifier>")
            id_type = args.get("identifier_type", "ip").lower()
            if id_type == "mac":
                locate_step = (
                    f"Call `meshq_endpoints_locate_by_mac` with mac='{identifier}'"
                )
            else:
                locate_step = (
                    f"Call `meshq_endpoints_locate_by_ip` with ip='{identifier}'"
                )
            text = (
                f"You are hunting for endpoint '{identifier}' (type: {id_type}).\n\n"
                "Please perform the following steps:\n"
                f"1. {locate_step} to find the endpoint record.\n"
                "2. From the result, extract the device hostname and interface name where "
                "the endpoint is connected.\n"
                "3. Call `meshq_endpoints_endpoints_on_interface` with the device and interface "
                "to confirm the endpoint and list any co-located endpoints.\n"
                "4. Call `meshq_topology_device_neighbors` on the access device to trace the "
                "path toward the distribution/core layer.\n"
                "5. Summarise: endpoint identity, physical location (device + interface), "
                "upstream path, and any co-located endpoints."
            )

        elif name == "network_addressing_audit":
            cidr = args.get("cidr", "")
            if cidr:
                subnet_step = (
                    f"Call `meshq_addressing_ips_in_subnet` with cidr='{cidr}' to list "
                    "allocated IPs within the subnet."
                )
            else:
                subnet_step = (
                    "Omit the subnet-specific query (no CIDR provided); proceed with "
                    "the orphaned IPs query to cover the full network."
                )
            text = (
                "You are auditing network addressing.\n\n"
                "Please perform the following steps:\n"
                f"1. {subnet_step}\n"
                "2. Call `meshq_addressing_orphaned_ips` to find IPs not associated with "
                "any known subnet.\n"
                "3. Call `meshq_inventory_summary_stats` for network-wide counts as context.\n"
                "4. Produce an addressing audit report: allocated IPs, orphaned IPs, "
                "utilisation estimate, and recommended clean-up actions."
            )

        elif name == "network_hygiene_report":
            text = (
                "You are generating a full network hygiene report.\n\n"
                "Please perform the following steps:\n"
                "1. Call `meshq_hygiene_devices_without_neighbors` to find isolated devices.\n"
                "2. Call `meshq_hygiene_interfaces_without_ips` to find unaddressed interfaces.\n"
                "3. Call `meshq_hygiene_endpoints_without_location` to find unlocatable endpoints.\n"
                "4. Call `meshq_inventory_summary_stats` for overall network counts as context.\n"
                "5. Produce a prioritised remediation checklist: critical issues first "
                "(isolated devices), then medium (unaddressed interfaces), then low "
                "(unlocatable endpoints). Include specific hostnames and counts."
            )

        elif name == "network_firewall_audit":
            device = args.get("device", "")
            if device:
                rules_step = (
                    f"Call `meshq_firewall_rules_by_device` with device='{device}' to retrieve "
                    "all rules for this firewall."
                )
            else:
                rules_step = (
                    "Call `meshq_firewall_all_firewall_devices` to list all firewalls, then "
                    "call `meshq_firewall_deny_rules_summary` to get an overview of deny rules."
                )
            text = (
                "You are auditing firewall security policies.\n\n"
                "Please perform the following steps:\n"
                f"1. {rules_step}\n"
                "2. Call `meshq_firewall_deny_rules_summary` to identify deny rules across "
                "all firewalls.\n"
                "3. Review the rules and flag: (a) any/any permit rules, (b) zone pairs "
                "where only permit rules exist with no deny, (c) disabled rules that "
                "were previously denying traffic.\n"
                "4. Produce a security audit report with risk ratings (high/medium/low) "
                "and specific remediation recommendations for each finding."
            )

        else:
            raise ValueError(f"Unknown prompt: {name!r}")

        return GetPromptResult(
            description=next((p.description for p in _PROMPTS if p.name == name), name),
            messages=[
                PromptMessage(
                    role="user",
                    content=TextContent(type="text", text=text),
                )
            ],
        )
