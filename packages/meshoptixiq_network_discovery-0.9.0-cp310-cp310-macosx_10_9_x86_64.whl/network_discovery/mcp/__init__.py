"""MeshOptixIQ MCP Server — direct GraphProvider integration."""
