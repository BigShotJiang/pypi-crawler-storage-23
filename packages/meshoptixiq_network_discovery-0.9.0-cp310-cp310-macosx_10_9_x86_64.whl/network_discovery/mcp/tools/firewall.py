"""MCP tools — firewall category.

Tools (api_access gate):
  meshq_firewall_all_firewall_devices  — devices with collected firewall rules
  meshq_firewall_rules_by_device       — rules for a given device
  meshq_firewall_deny_rules_summary    — all deny/drop rules across all firewalls

Tools (advanced_queries gate):
  meshq_firewall_rules_by_zone_pair    — rules between two security zones
  meshq_firewall_path_analysis         — evaluate rules for a source→destination flow
"""

from __future__ import annotations

import json
from collections.abc import Callable
from typing import Any

import anyio
from mcp.types import TextContent, Tool

from network_discovery.mcp.licensing import require_feature
from network_discovery.mcp.query_engine import execute_query


def register_tools(
    tools: list[Tool],
    handlers: dict[str, Callable[..., Any]],
) -> None:
    """Append firewall tools and handlers to the shared registries."""

    tools.append(
        Tool(
            name="meshq_firewall_all_firewall_devices",
            description="All devices that have at least one collected firewall security rule.",
            inputSchema={"type": "object", "properties": {}, "required": []},
        )
    )

    tools.append(
        Tool(
            name="meshq_firewall_rules_by_device",
            description="All security policy rules for a given firewall device, ordered by precedence.",
            inputSchema={
                "type": "object",
                "properties": {
                    "device": {
                        "type": "string",
                        "description": "Hostname of the firewall device.",
                    }
                },
                "required": ["device"],
            },
        )
    )

    tools.append(
        Tool(
            name="meshq_firewall_deny_rules_summary",
            description="All deny/drop/reject rules across every firewall in the graph.",
            inputSchema={"type": "object", "properties": {}, "required": []},
        )
    )

    tools.append(
        Tool(
            name="meshq_firewall_rules_by_zone_pair",
            description=(
                "All rules between a source zone and destination zone across all devices. "
                "Requires advanced_queries feature."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "source_zone": {
                        "type": "string",
                        "description": "Name of the source security zone.",
                    },
                    "destination_zone": {
                        "type": "string",
                        "description": "Name of the destination security zone.",
                    },
                },
                "required": ["source_zone", "destination_zone"],
            },
        )
    )

    tools.append(
        Tool(
            name="meshq_firewall_path_analysis",
            description=(
                "Evaluate firewall rules along the network path between source and destination IPs. "
                "Returns the first-matching rule per firewall. "
                "Requires advanced_queries feature."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "source_ip": {
                        "type": "string",
                        "description": "Source IP address.",
                    },
                    "destination_ip": {
                        "type": "string",
                        "description": "Destination IP address.",
                    },
                    "protocol": {
                        "type": "string",
                        "description": "Optional protocol filter (tcp, udp, icmp, …).",
                    },
                    "destination_port": {
                        "type": "string",
                        "description": "Optional destination port filter (e.g. 443).",
                    },
                },
                "required": ["source_ip", "destination_ip"],
            },
        )
    )

    async def all_firewall_devices(arguments: dict[str, Any]) -> list[TextContent]:
        require_feature("api_access")
        rows = await anyio.to_thread.run_sync(
            lambda: execute_query("all_firewall_devices", {})
        )
        return [TextContent(type="text", text=json.dumps(rows, default=str))]

    async def rules_by_device(arguments: dict[str, Any]) -> list[TextContent]:
        require_feature("api_access")
        rows = await anyio.to_thread.run_sync(
            lambda: execute_query("firewall_rules_by_device", {"device": arguments["device"]})
        )
        return [TextContent(type="text", text=json.dumps(rows, default=str))]

    async def deny_rules_summary(arguments: dict[str, Any]) -> list[TextContent]:
        require_feature("api_access")
        rows = await anyio.to_thread.run_sync(
            lambda: execute_query("deny_rules_summary", {})
        )
        return [TextContent(type="text", text=json.dumps(rows, default=str))]

    async def rules_by_zone_pair(arguments: dict[str, Any]) -> list[TextContent]:
        require_feature("advanced_queries")
        rows = await anyio.to_thread.run_sync(
            lambda: execute_query(
                "firewall_rules_by_zone_pair",
                {
                    "source_zone": arguments["source_zone"],
                    "destination_zone": arguments["destination_zone"],
                },
            )
        )
        return [TextContent(type="text", text=json.dumps(rows, default=str))]

    async def path_analysis(arguments: dict[str, Any]) -> list[TextContent]:
        require_feature("advanced_queries")
        params: dict[str, Any] = {
            "source_ip": arguments["source_ip"],
            "destination_ip": arguments["destination_ip"],
        }
        if arguments.get("protocol"):
            params["protocol"] = arguments["protocol"]
        if arguments.get("destination_port"):
            params["destination_port"] = arguments["destination_port"]
        rows = await anyio.to_thread.run_sync(
            lambda: execute_query("path_analysis", params)
        )
        return [TextContent(type="text", text=json.dumps(rows, default=str))]

    handlers["meshq_firewall_all_firewall_devices"] = all_firewall_devices
    handlers["meshq_firewall_rules_by_device"] = rules_by_device
    handlers["meshq_firewall_deny_rules_summary"] = deny_rules_summary
    handlers["meshq_firewall_rules_by_zone_pair"] = rules_by_zone_pair
    handlers["meshq_firewall_path_analysis"] = path_analysis
