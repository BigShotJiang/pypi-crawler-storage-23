"""MCP tools — blast_radius category (advanced_queries gate).

Tools:
  meshq_blast_radius_interface  — endpoints impacted if an interface goes down
  meshq_blast_radius_device     — endpoints impacted if a device goes down
  meshq_blast_radius_vlan       — endpoints in a VLAN
  meshq_blast_radius_subnet     — endpoints dependent on a subnet
"""

from __future__ import annotations

import json
from collections.abc import Callable
from typing import Any

import anyio
from mcp.types import TextContent, Tool

from network_discovery.mcp.licensing import require_feature
from network_discovery.mcp.query_engine import execute_query


def register_tools(
    tools: list[Tool],
    handlers: dict[str, Callable[..., Any]],
) -> None:
    """Append blast-radius tools and handlers to the shared registries."""

    tools.append(
        Tool(
            name="meshq_blast_radius_interface",
            description=(
                "Endpoints impacted if a specific interface goes down. "
                "Requires advanced_queries feature."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "device": {
                        "type": "string",
                        "description": "Hostname of the device.",
                    },
                    "interface": {
                        "type": "string",
                        "description": "Interface name (e.g. GigabitEthernet0/1).",
                    },
                },
                "required": ["device", "interface"],
            },
        )
    )

    tools.append(
        Tool(
            name="meshq_blast_radius_device",
            description=(
                "Endpoints impacted if an entire device goes down. "
                "Requires advanced_queries feature."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "device": {
                        "type": "string",
                        "description": "Hostname of the device.",
                    }
                },
                "required": ["device"],
            },
        )
    )

    tools.append(
        Tool(
            name="meshq_blast_radius_vlan",
            description=(
                "Endpoints running in a specific VLAN. "
                "Requires advanced_queries feature."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "vlan": {
                        "type": "integer",
                        "description": "VLAN ID (1-4094).",
                    }
                },
                "required": ["vlan"],
            },
        )
    )

    tools.append(
        Tool(
            name="meshq_blast_radius_subnet",
            description=(
                "Endpoints dependent on a specific subnet (CIDR notation). "
                "Requires advanced_queries feature."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "cidr": {
                        "type": "string",
                        "description": "Subnet in CIDR notation, e.g. 10.0.0.0/24.",
                    }
                },
                "required": ["cidr"],
            },
        )
    )

    async def blast_radius_interface(arguments: dict[str, Any]) -> list[TextContent]:
        require_feature("advanced_queries")
        rows = await anyio.to_thread.run_sync(
            lambda: execute_query(
                "blast_radius_interface",
                {"device": arguments["device"], "interface": arguments["interface"]},
            )
        )
        return [TextContent(type="text", text=json.dumps(rows, default=str))]

    async def blast_radius_device(arguments: dict[str, Any]) -> list[TextContent]:
        require_feature("advanced_queries")
        rows = await anyio.to_thread.run_sync(
            lambda: execute_query("blast_radius_device", {"device": arguments["device"]})
        )
        return [TextContent(type="text", text=json.dumps(rows, default=str))]

    async def blast_radius_vlan(arguments: dict[str, Any]) -> list[TextContent]:
        require_feature("advanced_queries")
        vlan = int(arguments["vlan"])
        rows = await anyio.to_thread.run_sync(
            lambda: execute_query("blast_radius_vlan", {"vlan": vlan})
        )
        return [TextContent(type="text", text=json.dumps(rows, default=str))]

    async def blast_radius_subnet(arguments: dict[str, Any]) -> list[TextContent]:
        require_feature("advanced_queries")
        rows = await anyio.to_thread.run_sync(
            lambda: execute_query("blast_radius_subnet", {"cidr": arguments["cidr"]})
        )
        return [TextContent(type="text", text=json.dumps(rows, default=str))]

    handlers["meshq_blast_radius_interface"] = blast_radius_interface
    handlers["meshq_blast_radius_device"] = blast_radius_device
    handlers["meshq_blast_radius_vlan"] = blast_radius_vlan
    handlers["meshq_blast_radius_subnet"] = blast_radius_subnet
