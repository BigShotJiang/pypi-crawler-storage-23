"""MCP tool modules — one module per query category."""
