"""MCP tools — addressing category.

Tools:
  meshq_addressing_ips_in_subnet   — IPs allocated within a subnet
  meshq_addressing_subnets_on_device — subnets present on a device
  meshq_addressing_orphaned_ips    — IPs not associated with any known subnet
"""

from __future__ import annotations

import json
from collections.abc import Callable
from typing import Any

import anyio
from mcp.types import TextContent, Tool

from network_discovery.mcp.licensing import require_feature
from network_discovery.mcp.query_engine import execute_query


def register_tools(
    tools: list[Tool],
    handlers: dict[str, Callable[..., Any]],
) -> None:
    """Append addressing tools and handlers to the shared registries."""

    tools.append(
        Tool(
            name="meshq_addressing_ips_in_subnet",
            description="IP addresses allocated within a given subnet (CIDR notation).",
            inputSchema={
                "type": "object",
                "properties": {
                    "cidr": {
                        "type": "string",
                        "description": "Subnet in CIDR notation, e.g. 10.0.0.0/24.",
                    }
                },
                "required": ["cidr"],
            },
        )
    )

    tools.append(
        Tool(
            name="meshq_addressing_subnets_on_device",
            description="Subnets present on a specific network device.",
            inputSchema={
                "type": "object",
                "properties": {
                    "device": {
                        "type": "string",
                        "description": "Hostname of the device.",
                    }
                },
                "required": ["device"],
            },
        )
    )

    tools.append(
        Tool(
            name="meshq_addressing_orphaned_ips",
            description="IP addresses that are not associated with any known subnet.",
            inputSchema={"type": "object", "properties": {}, "required": []},
        )
    )

    async def ips_in_subnet(arguments: dict[str, Any]) -> list[TextContent]:
        require_feature("api_access")
        rows = await anyio.to_thread.run_sync(
            lambda: execute_query("ips_in_subnet", {"cidr": arguments["cidr"]})
        )
        return [TextContent(type="text", text=json.dumps(rows, default=str))]

    async def subnets_on_device(arguments: dict[str, Any]) -> list[TextContent]:
        require_feature("api_access")
        rows = await anyio.to_thread.run_sync(
            lambda: execute_query("subnets_on_device", {"device": arguments["device"]})
        )
        return [TextContent(type="text", text=json.dumps(rows, default=str))]

    async def orphaned_ips(arguments: dict[str, Any]) -> list[TextContent]:
        require_feature("api_access")
        rows = await anyio.to_thread.run_sync(lambda: execute_query("orphaned_ips", {}))
        return [TextContent(type="text", text=json.dumps(rows, default=str))]

    handlers["meshq_addressing_ips_in_subnet"] = ips_in_subnet
    handlers["meshq_addressing_subnets_on_device"] = subnets_on_device
    handlers["meshq_addressing_orphaned_ips"] = orphaned_ips
