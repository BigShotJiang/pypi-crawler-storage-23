"""MCP tools — inventory category.

Tools:
  meshq_inventory_summary_stats   — device/interface/endpoint/VLAN counts
  meshq_inventory_all_devices     — full device list (pageable)
"""

from __future__ import annotations

import json
from collections.abc import Callable
from typing import Any

import anyio
from mcp.types import TextContent, Tool

from network_discovery.mcp.licensing import require_feature
from network_discovery.mcp.query_engine import execute_query

_MAX_LIMIT = 500


def register_tools(
    tools: list[Tool],
    handlers: dict[str, Callable[..., Any]],
) -> None:
    """Append inventory tools and handlers to the shared registries."""

    tools.append(
        Tool(
            name="meshq_inventory_summary_stats",
            description=(
                "Dashboard counts — total devices, interfaces, endpoints, and VLANs "
                "in the network graph."
            ),
            inputSchema={"type": "object", "properties": {}, "required": []},
        )
    )

    tools.append(
        Tool(
            name="meshq_inventory_all_devices",
            description=(
                "All discovered devices with vendor, model, OS version, and serial number."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "limit": {
                        "type": "integer",
                        "description": "Maximum rows to return (default 500).",
                        "default": _MAX_LIMIT,
                    }
                },
                "required": [],
            },
        )
    )

    async def summary_stats(arguments: dict[str, Any]) -> list[TextContent]:
        require_feature("api_access")
        rows = await anyio.to_thread.run_sync(lambda: execute_query("summary_stats", {}))
        return [TextContent(type="text", text=json.dumps(rows, default=str))]

    async def all_devices(arguments: dict[str, Any]) -> list[TextContent]:
        require_feature("api_access")
        limit = int(arguments.get("limit", _MAX_LIMIT))
        rows = await anyio.to_thread.run_sync(
            lambda: execute_query("all_devices", {}, limit=limit)
        )
        return [TextContent(type="text", text=json.dumps(rows, default=str))]

    handlers["meshq_inventory_summary_stats"] = summary_stats
    handlers["meshq_inventory_all_devices"] = all_devices
