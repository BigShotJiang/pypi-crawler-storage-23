"""MCP tools — endpoints category.

Tools:
  meshq_endpoints_locate_by_ip           — find endpoint by IP address
  meshq_endpoints_locate_by_mac          — find endpoint by MAC address
  meshq_endpoints_endpoints_on_interface — endpoints on a specific interface
"""

from __future__ import annotations

import json
from collections.abc import Callable
from typing import Any

import anyio
from mcp.types import TextContent, Tool

from network_discovery.mcp.licensing import require_feature
from network_discovery.mcp.query_engine import execute_query
from network_discovery.normalization.models import normalize_mac_address


def register_tools(
    tools: list[Tool],
    handlers: dict[str, Callable[..., Any]],
) -> None:
    """Append endpoint tools and handlers to the shared registries."""

    tools.append(
        Tool(
            name="meshq_endpoints_locate_by_ip",
            description="Find an endpoint (host) by its IP address.",
            inputSchema={
                "type": "object",
                "properties": {
                    "ip": {
                        "type": "string",
                        "description": "IPv4 or IPv6 address to search for.",
                    }
                },
                "required": ["ip"],
            },
        )
    )

    tools.append(
        Tool(
            name="meshq_endpoints_locate_by_mac",
            description=(
                "Find an endpoint by its MAC address. "
                "Accepts any common MAC format (aa:bb:cc:dd:ee:ff, aabb.ccdd.eeff, etc.)."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "mac": {
                        "type": "string",
                        "description": "MAC address in any common format.",
                    }
                },
                "required": ["mac"],
            },
        )
    )

    tools.append(
        Tool(
            name="meshq_endpoints_endpoints_on_interface",
            description="List all endpoints connected to a specific device interface.",
            inputSchema={
                "type": "object",
                "properties": {
                    "device": {
                        "type": "string",
                        "description": "Hostname of the network device.",
                    },
                    "interface": {
                        "type": "string",
                        "description": "Interface name (e.g. GigabitEthernet0/1).",
                    },
                },
                "required": ["device", "interface"],
            },
        )
    )

    async def locate_by_ip(arguments: dict[str, Any]) -> list[TextContent]:
        require_feature("api_access")
        rows = await anyio.to_thread.run_sync(
            lambda: execute_query("locate_endpoint_by_ip", {"ip": arguments["ip"]})
        )
        return [TextContent(type="text", text=json.dumps(rows, default=str))]

    async def locate_by_mac(arguments: dict[str, Any]) -> list[TextContent]:
        require_feature("api_access")
        normalized = normalize_mac_address(arguments["mac"])
        rows = await anyio.to_thread.run_sync(
            lambda: execute_query("locate_endpoint_by_mac", {"mac": normalized})
        )
        return [TextContent(type="text", text=json.dumps(rows, default=str))]

    async def endpoints_on_interface(arguments: dict[str, Any]) -> list[TextContent]:
        require_feature("api_access")
        rows = await anyio.to_thread.run_sync(
            lambda: execute_query(
                "endpoints_on_interface",
                {"device": arguments["device"], "interface": arguments["interface"]},
            )
        )
        return [TextContent(type="text", text=json.dumps(rows, default=str))]

    handlers["meshq_endpoints_locate_by_ip"] = locate_by_ip
    handlers["meshq_endpoints_locate_by_mac"] = locate_by_mac
    handlers["meshq_endpoints_endpoints_on_interface"] = endpoints_on_interface
