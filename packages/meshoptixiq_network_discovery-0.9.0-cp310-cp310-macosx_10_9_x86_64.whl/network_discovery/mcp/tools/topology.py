"""MCP tools — topology category.

Tools:
  meshq_topology_device_neighbors      — devices directly connected to a device
  meshq_topology_interface_neighbors   — interfaces connecting two devices
  meshq_topology_topology_edges        — all device-to-device connections (advanced)
"""

from __future__ import annotations

import json
from collections.abc import Callable
from typing import Any

import anyio
from mcp.types import TextContent, Tool

from network_discovery.mcp.licensing import require_feature
from network_discovery.mcp.query_engine import execute_query


def register_tools(
    tools: list[Tool],
    handlers: dict[str, Callable[..., Any]],
) -> None:
    """Append topology tools and handlers to the shared registries."""

    tools.append(
        Tool(
            name="meshq_topology_device_neighbors",
            description="Devices directly connected to a given device in the topology graph.",
            inputSchema={
                "type": "object",
                "properties": {
                    "device_name": {
                        "type": "string",
                        "description": "Hostname of the device to look up.",
                    }
                },
                "required": ["device_name"],
            },
        )
    )

    tools.append(
        Tool(
            name="meshq_topology_interface_neighbors",
            description="Interfaces connecting two named devices.",
            inputSchema={
                "type": "object",
                "properties": {
                    "device_a": {
                        "type": "string",
                        "description": "Hostname of the first device.",
                    },
                    "device_b": {
                        "type": "string",
                        "description": "Hostname of the second device.",
                    },
                },
                "required": ["device_a", "device_b"],
            },
        )
    )

    tools.append(
        Tool(
            name="meshq_topology_topology_edges",
            description=(
                "All device-to-device connections for the full network topology graph. "
                "Requires advanced_queries feature."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "limit": {
                        "type": "integer",
                        "description": "Maximum rows to return (default 500).",
                        "default": 500,
                    }
                },
                "required": [],
            },
        )
    )

    async def device_neighbors(arguments: dict[str, Any]) -> list[TextContent]:
        require_feature("api_access")
        rows = await anyio.to_thread.run_sync(
            lambda: execute_query("device_neighbors", {"device_name": arguments["device_name"]})
        )
        return [TextContent(type="text", text=json.dumps(rows, default=str))]

    async def interface_neighbors(arguments: dict[str, Any]) -> list[TextContent]:
        require_feature("api_access")
        rows = await anyio.to_thread.run_sync(
            lambda: execute_query(
                "interface_neighbors",
                {"device_a": arguments["device_a"], "device_b": arguments["device_b"]},
            )
        )
        return [TextContent(type="text", text=json.dumps(rows, default=str))]

    async def topology_edges(arguments: dict[str, Any]) -> list[TextContent]:
        require_feature("advanced_queries")
        limit = int(arguments.get("limit", 500))
        rows = await anyio.to_thread.run_sync(
            lambda: execute_query("topology_edges", {}, limit=limit)
        )
        return [TextContent(type="text", text=json.dumps(rows, default=str))]

    handlers["meshq_topology_device_neighbors"] = device_neighbors
    handlers["meshq_topology_interface_neighbors"] = interface_neighbors
    handlers["meshq_topology_topology_edges"] = topology_edges
