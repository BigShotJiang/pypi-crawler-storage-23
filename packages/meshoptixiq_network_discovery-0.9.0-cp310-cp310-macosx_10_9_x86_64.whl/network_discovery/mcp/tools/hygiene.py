"""MCP tools — hygiene category.

Tools:
  meshq_hygiene_devices_without_neighbors   — devices with no detected neighbours
  meshq_hygiene_interfaces_without_ips      — interfaces without an IP address
  meshq_hygiene_endpoints_without_location  — endpoints that cannot be located
"""

from __future__ import annotations

import json
from collections.abc import Callable
from typing import Any

import anyio
from mcp.types import TextContent, Tool

from network_discovery.mcp.licensing import require_feature
from network_discovery.mcp.query_engine import execute_query


def register_tools(
    tools: list[Tool],
    handlers: dict[str, Callable[..., Any]],
) -> None:
    """Append hygiene tools and handlers to the shared registries."""

    tools.append(
        Tool(
            name="meshq_hygiene_devices_without_neighbors",
            description="Devices with no detected neighbours in the topology graph.",
            inputSchema={"type": "object", "properties": {}, "required": []},
        )
    )

    tools.append(
        Tool(
            name="meshq_hygiene_interfaces_without_ips",
            description="Interfaces that have no IP address assigned.",
            inputSchema={"type": "object", "properties": {}, "required": []},
        )
    )

    tools.append(
        Tool(
            name="meshq_hygiene_endpoints_without_location",
            description="Endpoints that could not be traced to a physical port/location.",
            inputSchema={"type": "object", "properties": {}, "required": []},
        )
    )

    async def devices_without_neighbors(arguments: dict[str, Any]) -> list[TextContent]:
        require_feature("api_access")
        rows = await anyio.to_thread.run_sync(
            lambda: execute_query("devices_without_neighbors", {})
        )
        return [TextContent(type="text", text=json.dumps(rows, default=str))]

    async def interfaces_without_ips(arguments: dict[str, Any]) -> list[TextContent]:
        require_feature("api_access")
        rows = await anyio.to_thread.run_sync(
            lambda: execute_query("interfaces_without_ips", {})
        )
        return [TextContent(type="text", text=json.dumps(rows, default=str))]

    async def endpoints_without_location(arguments: dict[str, Any]) -> list[TextContent]:
        require_feature("api_access")
        rows = await anyio.to_thread.run_sync(
            lambda: execute_query("endpoints_without_location", {})
        )
        return [TextContent(type="text", text=json.dumps(rows, default=str))]

    handlers["meshq_hygiene_devices_without_neighbors"] = devices_without_neighbors
    handlers["meshq_hygiene_interfaces_without_ips"] = interfaces_without_ips
    handlers["meshq_hygiene_endpoints_without_location"] = endpoints_without_location
