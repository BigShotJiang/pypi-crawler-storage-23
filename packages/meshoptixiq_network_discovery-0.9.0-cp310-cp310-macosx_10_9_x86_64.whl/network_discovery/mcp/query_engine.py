"""Query dispatch engine for the MCP server.

Replicates the logic from ``api/routes/queries.py`` without FastAPI.
Uses ``importlib.resources`` for wheel-safe path resolution.
"""

from __future__ import annotations

import importlib.resources as pkg_resources
import os
from typing import Any

import yaml

from network_discovery.graph.provider import GraphProvider, GraphProviderFactory

# ---------------------------------------------------------------------------
# Registry + provider singletons
# ---------------------------------------------------------------------------
_registry: dict[str, Any] = {}
_provider: GraphProvider | None = None

_MAX_ROWS = int(os.environ.get("MCP_MAX_RESULT_ROWS", "1000"))


def get_registry() -> dict[str, Any]:
    """Load and cache the query registry from registry.yaml."""
    global _registry
    if not _registry:
        registry_file = pkg_resources.files("network_discovery") / "queries" / "registry.yaml"
        with registry_file.open() as f:
            data = yaml.safe_load(f)
        _registry = {q["name"]: q for q in data.get("queries", [])}
    return _registry


def get_provider() -> GraphProvider:
    """Return the singleton graph provider, creating it on first call."""
    global _provider
    if _provider is None:
        _provider = GraphProviderFactory.get_provider()
    return _provider


def execute_query(query_name: str, params: dict[str, Any], limit: int = _MAX_ROWS) -> list[dict[str, Any]]:
    """Dispatch a named query to the configured graph backend.

    Args:
        query_name: Key from ``registry.yaml``.
        params: Query parameters (names must match the registry definition).
        limit: Maximum number of rows to return (default: ``MCP_MAX_RESULT_ROWS``).

    Returns:
        List of result rows as plain dicts.

    Raises:
        ValueError: If *query_name* is not in the registry or the backend has
            no implementation for the query.
    """
    registry = get_registry()
    if query_name not in registry:
        raise ValueError(f"Unknown query: {query_name!r}")

    backend = os.environ.get("GRAPH_BACKEND", "neo4j").lower()
    query_def = registry[query_name]

    implementations = query_def.get("implementations", {})
    query_file = implementations.get(backend)
    if not query_file:
        raise ValueError(f"Query {query_name!r} has no implementation for backend {backend!r}")

    queries_root = pkg_resources.files("network_discovery") / "queries" / "v1"
    query_content = (queries_root / query_file).read_text()  # type: ignore[arg-type]

    rows = get_provider().execute_query(query_name, query_content, params)
    return list(rows)[:limit]


def close_provider() -> None:
    """Close the singleton provider and release connections."""
    global _provider
    if _provider is not None:
        _provider.close()
        _provider = None
