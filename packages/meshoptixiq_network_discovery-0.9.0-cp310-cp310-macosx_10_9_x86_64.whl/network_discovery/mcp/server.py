"""MeshOptixIQ MCP Server — stdio entry point.

Run with:
    meshq-mcp

Or directly:
    python -m network_discovery.mcp.server

The MCP server requires a running MeshOptixIQ API instance. Plan and feature
access are resolved at startup by querying the local API (/health/license) —
no MESHOPTIXIQ_LICENSE_KEY is needed in the MCP process itself.

Required environment variables:
    MESHOPTIXIQ_API_URL       — base URL of the local API (default: http://localhost:8000)
    MESHOPTIXIQ_API_KEY       — API key matching the running server
    GRAPH_BACKEND             — neo4j (default) or postgres
    NEO4J_URI / NEO4J_PASSWORD / NEO4J_USER   — if using Neo4j
    POSTGRES_DSN              — if using postgres
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent

from network_discovery.mcp.licensing import FeatureNotAvailableError, check_mcp_access
from network_discovery.mcp.prompts.templates import register_prompts
from network_discovery.mcp.query_engine import close_provider
from network_discovery.mcp.resources.handlers import register_resources
from network_discovery.mcp.tools import (
    addressing,
    blast_radius,
    endpoints,
    firewall,
    hygiene,
    inventory,
    topology,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Build server + register all capabilities
# ---------------------------------------------------------------------------
server = Server("meshoptixiq")

# Central tool registry — populated by each module's register_tools()
_tools: list[Any] = []
_handlers: dict[str, Any] = {}

inventory.register_tools(_tools, _handlers)
topology.register_tools(_tools, _handlers)
endpoints.register_tools(_tools, _handlers)
blast_radius.register_tools(_tools, _handlers)
addressing.register_tools(_tools, _handlers)
hygiene.register_tools(_tools, _handlers)
firewall.register_tools(_tools, _handlers)

register_resources(server)
register_prompts(server)


@server.list_tools()
async def list_tools() -> list[Any]:
    return _tools


@server.call_tool()
async def call_tool(name: str, arguments: dict[str, Any] | None) -> list[TextContent]:
    handler = _handlers.get(name)
    if handler is None:
        raise ValueError(f"Unknown tool: {name!r}")
    return await handler(arguments or {})


# ---------------------------------------------------------------------------
# Entry points
# ---------------------------------------------------------------------------

async def run_stdio() -> None:
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options(),
        )


def main() -> None:
    """CLI entry point — called by ``meshq-mcp``."""
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    try:
        check_mcp_access()
    except FeatureNotAvailableError as exc:
        logger.error("MCP server requires a pro or enterprise license. %s", exc)
        raise SystemExit(1) from exc

    try:
        asyncio.run(run_stdio())
    finally:
        close_provider()


if __name__ == "__main__":
    main()
