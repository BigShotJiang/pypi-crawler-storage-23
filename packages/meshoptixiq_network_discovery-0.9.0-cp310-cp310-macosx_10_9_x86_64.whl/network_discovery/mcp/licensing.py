"""MCP licensing gate checks.

Wraps ``network_discovery.licensing.gates`` and ``verifier`` so tool handlers
can call ``require_feature()`` without knowing the underlying plan resolution
details.
"""

from __future__ import annotations

import logging
import os

from network_discovery.licensing.gates import FeatureNotAvailableError, check_feature

# Re-export so callers don't need to import gates directly.
__all__ = ["FeatureNotAvailableError", "check_mcp_access", "require_feature"]

logger = logging.getLogger(__name__)

_PLAN: str | None = None


def _get_plan() -> str:
    """Resolve plan by calling the local API. Cached after first successful call."""
    global _PLAN
    if _PLAN is not None:
        return _PLAN

    if os.environ.get("MESHOPTIXIQ_DEMO_MODE"):
        _PLAN = "community"
        return _PLAN

    from network_discovery.local_api_client import get_license_status
    try:
        info = get_license_status()
        _PLAN = info.get("plan", "community")
        if info.get("demo_mode"):
            _PLAN = "enterprise"  # demo mode → all features on
    except RuntimeError:
        logger.warning("Cannot reach local API; defaulting to community plan for MCP.")
        _PLAN = "community"
    return _PLAN


def check_mcp_access() -> None:
    """Raise ``FeatureNotAvailableError`` if the plan does not include API access.

    Call once at startup before the event loop begins.
    """
    check_feature(plan=_get_plan(), feature="mcp_server")


def require_feature(feature: str) -> None:
    """Raise ``FeatureNotAvailableError`` if the plan does not include *feature*.

    Call per-tool for features gated above the base ``api_access`` tier.
    """
    check_feature(plan=_get_plan(), feature=feature)
