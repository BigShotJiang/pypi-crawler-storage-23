"""Demo mode package — synthetic network fixtures for zero-dependency exploration."""
