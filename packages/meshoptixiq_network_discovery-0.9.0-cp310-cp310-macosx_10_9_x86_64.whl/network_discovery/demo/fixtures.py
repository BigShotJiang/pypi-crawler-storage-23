"""Demo network fixtures — a realistic mid-size campus + datacenter network.

Topology
--------
- 2  core switches     (Cisco IOS)
- 4  access switches   (Arista EOS)
- 2  WAN routers       (Juniper JunOS)
- 3  firewalls         (PAN-OS)
- 2  FortiGate FWs     (Fortinet)
- 3  Cisco ASA FWs     (Cisco ASA)
- 4  servers
= 20 devices total

~60 interfaces, ~120 IP addresses, 8 subnets, 12 VLANs, ~300 endpoints,
~60 firewall rules across 8 firewall devices.
"""

from __future__ import annotations

from datetime import datetime, timezone

from network_discovery.normalization.models import (
    AddressObjectModel,
    DeviceModel,
    EndpointModel,
    FirewallRuleModel,
    InterfaceModel,
    IPAddressModel,
    MACModel,
    NetworkFacts,
    ServiceObjectModel,
    SubnetModel,
    VLANModel,
)

_NOW = datetime.now(tz=timezone.utc)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _mac(idx: int) -> str:
    """Generate a deterministic MAC address from an index."""
    h = f"{idx:012X}"
    return ":".join(h[i : i + 2] for i in range(0, 12, 2))


def _fw_rule(
    device: str,
    rule_id: str,
    name: str,
    order: int,
    action: str,
    src_zones: list[str],
    dst_zones: list[str],
    src_addrs: list[str],
    dst_addrs: list[str],
    services: list[str],
    vendor: str,
    log: bool = True,
) -> FirewallRuleModel:
    return FirewallRuleModel(
        device_hostname=device,
        rule_id=rule_id,
        rule_name=name,
        rule_order=order,
        action=action,
        source_zones=src_zones,
        destination_zones=dst_zones,
        source_addresses=src_addrs,
        destination_addresses=dst_addrs,
        services=services,
        protocols=[],
        destination_ports=[],
        enabled=True,
        log_enabled=log,
        vendor=vendor,
        collected_at=_NOW,
    )


# ---------------------------------------------------------------------------
# Devices (20 total)
# ---------------------------------------------------------------------------

def _build_devices() -> list[DeviceModel]:
    return [
        # Core switches
        DeviceModel(hostname="core-sw-01", vendor="cisco_ios",    model="Catalyst 9500",  os_version="17.9.4a", serial="CAT2301ABCD", collected_at=_NOW),
        DeviceModel(hostname="core-sw-02", vendor="cisco_ios",    model="Catalyst 9500",  os_version="17.9.4a", serial="CAT2301EFGH", collected_at=_NOW),
        # Access switches
        DeviceModel(hostname="access-sw-01", vendor="arista_eos", model="DCS-7050TX",     os_version="4.30.3F", serial="SSJ18430001", collected_at=_NOW),
        DeviceModel(hostname="access-sw-02", vendor="arista_eos", model="DCS-7050TX",     os_version="4.30.3F", serial="SSJ18430002", collected_at=_NOW),
        DeviceModel(hostname="access-sw-03", vendor="arista_eos", model="DCS-7050CX3",    os_version="4.30.3F", serial="SSJ18430003", collected_at=_NOW),
        DeviceModel(hostname="access-sw-04", vendor="arista_eos", model="DCS-7050CX3",    os_version="4.30.3F", serial="SSJ18430004", collected_at=_NOW),
        # WAN routers
        DeviceModel(hostname="wan-rtr-01", vendor="juniper_junos", model="MX204",         os_version="22.4R2.8", serial="JN2201A1001", collected_at=_NOW),
        DeviceModel(hostname="wan-rtr-02", vendor="juniper_junos", model="MX204",         os_version="22.4R2.8", serial="JN2201A1002", collected_at=_NOW),
        # PAN-OS firewalls
        DeviceModel(hostname="fw-panos-01", vendor="paloalto_panos", model="PA-5250",     os_version="11.1.2", serial="013201234501", collected_at=_NOW),
        DeviceModel(hostname="fw-panos-02", vendor="paloalto_panos", model="PA-3260",     os_version="11.1.2", serial="013201234502", collected_at=_NOW),
        DeviceModel(hostname="fw-panos-03", vendor="paloalto_panos", model="PA-3260",     os_version="11.0.4", serial="013201234503", collected_at=_NOW),
        # FortiGate firewalls
        DeviceModel(hostname="fw-forti-01", vendor="fortinet",       model="FortiGate-600F", os_version="7.4.3", serial="FG6H0000001", collected_at=_NOW),
        DeviceModel(hostname="fw-forti-02", vendor="fortinet",       model="FortiGate-600F", os_version="7.4.3", serial="FG6H0000002", collected_at=_NOW),
        # Cisco ASA firewalls
        DeviceModel(hostname="fw-asa-01", vendor="cisco_asa", model="ASA 5525-X",        os_version="9.18.4", serial="JAD201100A1", collected_at=_NOW),
        DeviceModel(hostname="fw-asa-02", vendor="cisco_asa", model="ASA 5525-X",        os_version="9.18.4", serial="JAD201100A2", collected_at=_NOW),
        DeviceModel(hostname="fw-asa-03", vendor="cisco_asa", model="ASA 5516-X",        os_version="9.18.3", serial="JAD201100A3", collected_at=_NOW),
        # Servers
        DeviceModel(hostname="srv-web-01", vendor="linux",  model="PowerEdge R750",       os_version="Ubuntu 22.04", serial="SRV0001", collected_at=_NOW),
        DeviceModel(hostname="srv-db-01",  vendor="linux",  model="PowerEdge R750xs",      os_version="RHEL 9.3",    serial="SRV0002", collected_at=_NOW),
        DeviceModel(hostname="srv-app-01", vendor="linux",  model="ProLiant DL380 Gen10",  os_version="Ubuntu 22.04", serial="SRV0003", collected_at=_NOW),
        DeviceModel(hostname="srv-mgmt-01",vendor="linux",  model="ProLiant DL360 Gen10",  os_version="Ubuntu 22.04", serial="SRV0004", collected_at=_NOW),
    ]


# ---------------------------------------------------------------------------
# Interfaces (~60 total)
# ---------------------------------------------------------------------------

_TOPOLOGY_LINKS = [
    # core-sw-01 uplinks
    ("core-sw-01", "GigabitEthernet1/0/1",  "link:wan-rtr-01"),
    ("core-sw-01", "GigabitEthernet1/0/2",  "link:wan-rtr-02"),
    ("core-sw-01", "GigabitEthernet1/0/3",  "link:core-sw-02"),
    ("core-sw-01", "GigabitEthernet1/0/4",  "link:access-sw-01"),
    ("core-sw-01", "GigabitEthernet1/0/5",  "link:access-sw-02"),
    ("core-sw-01", "GigabitEthernet1/0/6",  "link:fw-panos-01"),
    ("core-sw-01", "GigabitEthernet1/0/7",  "link:fw-forti-01"),
    ("core-sw-01", "GigabitEthernet1/0/8",  "link:fw-asa-01"),
    # core-sw-02 uplinks
    ("core-sw-02", "GigabitEthernet1/0/1",  "link:wan-rtr-01"),
    ("core-sw-02", "GigabitEthernet1/0/2",  "link:wan-rtr-02"),
    ("core-sw-02", "GigabitEthernet1/0/3",  "link:core-sw-01"),
    ("core-sw-02", "GigabitEthernet1/0/4",  "link:access-sw-03"),
    ("core-sw-02", "GigabitEthernet1/0/5",  "link:access-sw-04"),
    ("core-sw-02", "GigabitEthernet1/0/6",  "link:fw-panos-02"),
    ("core-sw-02", "GigabitEthernet1/0/7",  "link:fw-forti-02"),
    ("core-sw-02", "GigabitEthernet1/0/8",  "link:fw-asa-02"),
    # access switches uplinks
    ("access-sw-01", "Ethernet1",           "link:core-sw-01"),
    ("access-sw-02", "Ethernet1",           "link:core-sw-01"),
    ("access-sw-03", "Ethernet1",           "link:core-sw-02"),
    ("access-sw-04", "Ethernet1",           "link:core-sw-02"),
    # WAN routers
    ("wan-rtr-01", "ge-0/0/0",              "link:core-sw-01"),
    ("wan-rtr-01", "ge-0/0/1",              "link:core-sw-02"),
    ("wan-rtr-02", "ge-0/0/0",              "link:core-sw-01"),
    ("wan-rtr-02", "ge-0/0/1",              "link:core-sw-02"),
    # Firewall uplinks
    ("fw-panos-01", "ethernet1/1",          "link:core-sw-01"),
    ("fw-panos-01", "ethernet1/2",          "link:fw-panos-03"),
    ("fw-panos-02", "ethernet1/1",          "link:core-sw-02"),
    ("fw-panos-03", "ethernet1/1",          "link:fw-panos-01"),
    ("fw-forti-01", "port1",                "link:core-sw-01"),
    ("fw-forti-02", "port1",                "link:core-sw-02"),
    ("fw-asa-01",   "GigabitEthernet0/0",   "link:core-sw-01"),
    ("fw-asa-02",   "GigabitEthernet0/0",   "link:core-sw-02"),
    ("fw-asa-03",   "GigabitEthernet0/0",   "link:fw-asa-01"),
    # Servers
    ("srv-web-01",  "eth0",                 "link:access-sw-01"),
    ("srv-db-01",   "eth0",                 "link:access-sw-02"),
    ("srv-app-01",  "eth0",                 "link:access-sw-03"),
    ("srv-mgmt-01", "eth0",                 "link:access-sw-04"),
]

# Extra management / loopback interfaces (no link)
_EXTRA_IFACES = [
    ("core-sw-01",    "Loopback0",          None),
    ("core-sw-01",    "Management1",        None),
    ("core-sw-02",    "Loopback0",          None),
    ("core-sw-02",    "Management1",        None),
    ("wan-rtr-01",    "lo0",                None),
    ("wan-rtr-02",    "lo0",                None),
    ("fw-panos-01",   "management",         None),
    ("fw-panos-02",   "management",         None),
    ("fw-forti-01",   "mgmt",              None),
    ("fw-forti-02",   "mgmt",              None),
    ("fw-asa-01",     "Management0/0",     None),
    ("fw-asa-02",     "Management0/0",     None),
    ("srv-web-01",    "eth1",              None),
    ("srv-db-01",     "eth1",              None),
    ("srv-app-01",    "eth1",              None),
    ("srv-mgmt-01",   "eth1",              None),
]


def _build_interfaces() -> list[InterfaceModel]:
    interfaces = []
    mac_idx = 1
    for device, name, desc in _TOPOLOGY_LINKS:
        mac = _mac(mac_idx)
        mac_idx += 1
        interfaces.append(InterfaceModel(
            device_hostname=device,
            name=name,
            admin_status="up",
            oper_status="up",
            speed="10G",
            mtu=9000,
            description=desc,
            mac_address=mac,
        ))
    for device, name, desc in _EXTRA_IFACES:
        interfaces.append(InterfaceModel(
            device_hostname=device,
            name=name,
            admin_status="up",
            oper_status="up",
            speed="1G",
            mtu=1500,
            description=desc,
        ))
    # Add access port interfaces (no links, for endpoints)
    for sw, base_port in [
        ("access-sw-01", "Ethernet10"),
        ("access-sw-02", "Ethernet10"),
        ("access-sw-03", "Ethernet10"),
        ("access-sw-04", "Ethernet10"),
    ]:
        for p in range(10, 20):
            mac = _mac(mac_idx)
            mac_idx += 1
            interfaces.append(InterfaceModel(
                device_hostname=sw,
                name=f"Ethernet{p}",
                admin_status="up",
                oper_status="up",
                speed="1G",
                mtu=1500,
                mac_address=mac,
            ))
    return interfaces


# ---------------------------------------------------------------------------
# Subnets (8)
# ---------------------------------------------------------------------------

_SUBNET_DEFS = [
    ("10.0.0.0",    24),  # core infrastructure
    ("10.0.1.0",    24),  # access layer A
    ("10.0.2.0",    24),  # access layer B
    ("10.0.10.0",   24),  # server DMZ
    ("10.0.20.0",   24),  # management
    ("10.0.30.0",   24),  # WAN transit
    ("192.168.100.0", 24),# guest / branch
    ("192.168.200.0", 24),# out-of-band
]


def _build_subnets() -> list[SubnetModel]:
    return [
        SubnetModel(network_address=net, prefix_length=pfx, version=4)
        for net, pfx in _SUBNET_DEFS
    ]


# ---------------------------------------------------------------------------
# IP addresses (~120)
# ---------------------------------------------------------------------------

def _build_ip_addresses() -> list[IPAddressModel]:
    ips = []

    # Device loopbacks and management IPs
    device_ips = [
        ("core-sw-01",    "Loopback0",       "10.0.0.1",   32),
        ("core-sw-01",    "Management1",     "10.0.20.1",  24),
        ("core-sw-02",    "Loopback0",       "10.0.0.2",   32),
        ("core-sw-02",    "Management1",     "10.0.20.2",  24),
        ("access-sw-01",  "Management1",     "10.0.20.11", 24),
        ("access-sw-02",  "Management1",     "10.0.20.12", 24),
        ("access-sw-03",  "Management1",     "10.0.20.13", 24),
        ("access-sw-04",  "Management1",     "10.0.20.14", 24),
        ("wan-rtr-01",    "lo0",             "10.0.0.11",  32),
        ("wan-rtr-01",    "ge-0/0/0",        "10.0.30.1",  30),
        ("wan-rtr-02",    "lo0",             "10.0.0.12",  32),
        ("wan-rtr-02",    "ge-0/0/0",        "10.0.30.5",  30),
        ("fw-panos-01",   "management",      "10.0.20.21", 24),
        ("fw-panos-01",   "ethernet1/1",     "10.0.0.101", 30),
        ("fw-panos-02",   "management",      "10.0.20.22", 24),
        ("fw-panos-02",   "ethernet1/1",     "10.0.0.105", 30),
        ("fw-panos-03",   "ethernet1/1",     "10.0.0.109", 30),
        ("fw-forti-01",   "mgmt",           "10.0.20.31", 24),
        ("fw-forti-01",   "port1",          "10.0.0.113", 30),
        ("fw-forti-02",   "mgmt",           "10.0.20.32", 24),
        ("fw-forti-02",   "port1",          "10.0.0.117", 30),
        ("fw-asa-01",     "Management0/0",  "10.0.20.41", 24),
        ("fw-asa-01",     "GigabitEthernet0/0", "10.0.0.121", 30),
        ("fw-asa-02",     "Management0/0",  "10.0.20.42", 24),
        ("fw-asa-02",     "GigabitEthernet0/0", "10.0.0.125", 30),
        ("fw-asa-03",     "Management0/0",  "10.0.20.43", 24),
        ("srv-web-01",    "eth0",           "10.0.10.10", 24),
        ("srv-db-01",     "eth0",           "10.0.10.20", 24),
        ("srv-app-01",    "eth0",           "10.0.10.30", 24),
        ("srv-mgmt-01",   "eth0",           "10.0.10.40", 24),
        ("srv-web-01",    "eth1",           "10.0.20.50", 24),
        ("srv-mgmt-01",   "eth1",           "10.0.20.51", 24),
    ]

    for device, iface, addr, pfx in device_ips:
        ips.append(IPAddressModel(
            address=addr, prefix_length=pfx, version=4,
            interface_name=iface, device_hostname=device,
        ))

    # Endpoint IPs in 10.0.1.x and 10.0.2.x subnets
    for i in range(2, 61):
        ips.append(IPAddressModel(
            address=f"10.0.1.{i}", prefix_length=24, version=4,
        ))
    for i in range(2, 61):
        ips.append(IPAddressModel(
            address=f"10.0.2.{i}", prefix_length=24, version=4,
        ))

    return ips


# ---------------------------------------------------------------------------
# VLANs (12)
# ---------------------------------------------------------------------------

_VLAN_DEFS = [
    (10,  "Users-A",    "access-sw-01"),
    (10,  "Users-A",    "access-sw-02"),
    (20,  "Users-B",    "access-sw-03"),
    (20,  "Users-B",    "access-sw-04"),
    (30,  "Servers",    "core-sw-01"),
    (30,  "Servers",    "core-sw-02"),
    (40,  "Management", "core-sw-01"),
    (40,  "Management", "core-sw-02"),
    (50,  "DMZ",        "fw-panos-01"),
    (60,  "WAN",        "wan-rtr-01"),
    (70,  "Guest",      "access-sw-01"),
    (80,  "OOB",        "srv-mgmt-01"),
]


def _build_vlans() -> list[VLANModel]:
    return [VLANModel(device_hostname=dev, vlan_id=vid, name=name)
            for vid, name, dev in _VLAN_DEFS]


# ---------------------------------------------------------------------------
# MACs and Endpoints (~300)
# ---------------------------------------------------------------------------

def _build_macs_and_endpoints() -> tuple[list[MACModel], list[EndpointModel]]:
    macs = []
    endpoints = []
    base_mac = 0xAABB00000001

    for i in range(300):
        mac_int = base_mac + i
        mac_str = ":".join(f"{(mac_int >> (8 * (5 - j))) & 0xFF:02X}" for j in range(6))
        subnet_idx = i % 2  # alternate between 10.0.1.x and 10.0.2.x
        host_octet = (i % 200) + 2
        ip = f"10.0.{subnet_idx + 1}.{host_octet}"

        macs.append(MACModel(address=mac_str, vendor_oui="Demo Corp"))
        endpoints.append(EndpointModel(
            mac_address=mac_str,
            ip_address=ip,
            first_seen=_NOW,
            last_seen=_NOW,
        ))

    return macs, endpoints


# ---------------------------------------------------------------------------
# Firewall rules (~60)
# ---------------------------------------------------------------------------

def _build_firewall_rules() -> list[FirewallRuleModel]:
    rules = []

    # --- PAN-OS fw-panos-01 (15 rules) ---
    panos01 = [
        ("rule-001", "Allow-Users-To-DMZ",    1,  "allow", ["trust"], ["dmz"],
         ["10.0.1.0/24", "10.0.2.0/24"], ["10.0.10.0/24"], ["tcp/80", "tcp/443"]),
        ("rule-002", "Allow-Users-To-Internet", 2, "allow", ["trust"], ["untrust"],
         ["10.0.1.0/24", "10.0.2.0/24"], ["any"], ["tcp/80", "tcp/443"]),
        ("rule-003", "Deny-Users-To-Mgmt",    3,  "deny",  ["trust"], ["management"],
         ["10.0.1.0/24"], ["10.0.20.0/24"], ["any"]),
        ("rule-004", "Allow-Servers-Outbound", 4, "allow", ["dmz"], ["untrust"],
         ["10.0.10.0/24"], ["any"], ["tcp/443", "tcp/80"]),
        ("rule-005", "Block-Ingress-SMB",      5, "deny",  ["untrust"], ["trust"],
         ["any"], ["any"], ["tcp/445", "tcp/139"]),
        ("rule-006", "Allow-HTTPS-Inbound",    6, "allow", ["untrust"], ["dmz"],
         ["any"], ["10.0.10.10/32"], ["tcp/443"]),
        ("rule-007", "Deny-Telnet",            7, "deny",  ["any"], ["any"],
         ["any"], ["any"], ["tcp/23"]),
        ("rule-008", "Allow-ICMP-Internal",    8, "allow", ["trust"], ["trust"],
         ["10.0.0.0/8"], ["10.0.0.0/8"], ["icmp"]),
        ("rule-009", "Allow-SSH-Mgmt",         9, "allow", ["management"], ["any"],
         ["10.0.20.0/24"], ["any"], ["tcp/22"]),
        ("rule-010", "Deny-FTP-Inbound",      10, "deny",  ["untrust"], ["any"],
         ["any"], ["any"], ["tcp/21"]),
        ("rule-011", "Allow-DNS",             11, "allow", ["trust"], ["dmz"],
         ["any"], ["10.0.10.40/32"], ["udp/53"]),
        ("rule-012", "Allow-NTP",             12, "allow", ["any"], ["any"],
         ["10.0.0.0/8"], ["10.0.20.50/32"], ["udp/123"]),
        ("rule-013", "Block-RDP-External",    13, "deny",  ["untrust"], ["any"],
         ["any"], ["any"], ["tcp/3389"]),
        ("rule-014", "Allow-App-Tier-DB",     14, "allow", ["dmz"], ["servers"],
         ["10.0.10.30/32"], ["10.0.10.20/32"], ["tcp/5432", "tcp/3306"]),
        ("rule-015", "Default-Deny",          15, "deny",  ["any"], ["any"],
         ["any"], ["any"], ["any"]),
    ]
    for rid, name, order, action, src_z, dst_z, src_a, dst_a, svcs in panos01:
        rules.append(_fw_rule("fw-panos-01", rid, name, order, action,
                               src_z, dst_z, src_a, dst_a, svcs, "paloalto_panos"))

    # --- PAN-OS fw-panos-02 (5 rules) ---
    panos02_defs = [
        ("rule-001", "Allow-Branch-HTTPS",    1,  "allow", ["branch"], ["internet"],
         ["192.168.100.0/24"], ["any"], ["tcp/443"]),
        ("rule-002", "Allow-Branch-VPN",      2,  "allow", ["branch"], ["corporate"],
         ["192.168.100.0/24"], ["10.0.0.0/8"], ["tcp/4500", "udp/500"]),
        ("rule-003", "Deny-P2P",              3,  "deny",  ["branch"], ["internet"],
         ["192.168.100.0/24"], ["any"], ["tcp/6881-6889"]),
        ("rule-004", "Allow-ICMP",            4,  "allow", ["any"], ["any"],
         ["10.0.0.0/8"], ["10.0.0.0/8"], ["icmp"]),
        ("rule-005", "Branch-Default-Deny",   5,  "deny",  ["any"], ["any"],
         ["any"], ["any"], ["any"]),
    ]
    for rid, name, order, action, src_z, dst_z, src_a, dst_a, svcs in panos02_defs:
        rules.append(_fw_rule("fw-panos-02", rid, name, order, action,
                               src_z, dst_z, src_a, dst_a, svcs, "paloalto_panos"))

    # --- PAN-OS fw-panos-03 (5 rules) ---
    panos03_defs = [
        ("rule-001", "Allow-Core-HTTPS",      1,  "allow", ["internal"], ["external"],
         ["10.0.0.0/8"], ["any"], ["tcp/443", "tcp/80"]),
        ("rule-002", "Allow-SSH-Internal",    2,  "allow", ["management"], ["internal"],
         ["10.0.20.0/24"], ["10.0.0.0/8"], ["tcp/22"]),
        ("rule-003", "Deny-SMB-Ext",          3,  "deny",  ["external"], ["internal"],
         ["any"], ["any"], ["tcp/445"]),
        ("rule-004", "Allow-SNMP",            4,  "allow", ["management"], ["any"],
         ["10.0.20.0/24"], ["10.0.0.0/8"], ["udp/161"]),
        ("rule-005", "Deny-All-Ext",          5,  "deny",  ["external"], ["any"],
         ["any"], ["any"], ["any"]),
    ]
    for rid, name, order, action, src_z, dst_z, src_a, dst_a, svcs in panos03_defs:
        rules.append(_fw_rule("fw-panos-03", rid, name, order, action,
                               src_z, dst_z, src_a, dst_a, svcs, "paloalto_panos"))

    # --- FortiGate fw-forti-01 (10 rules) ---
    forti01_defs = [
        ("1", "LAN-to-WAN-HTTP",        1,  "allow", ["lan"], ["wan"],
         ["all"], ["all"], ["HTTP", "HTTPS"]),
        ("2", "DMZ-to-Internal",        2,  "allow", ["dmz"], ["lan"],
         ["10.0.10.0/24"], ["10.0.1.0/24"], ["HTTPS"]),
        ("3", "Block-BitTorrent",       3,  "deny",  ["lan"], ["wan"],
         ["all"], ["all"], ["BitTorrent"]),
        ("4", "Allow-SMTP-Out",         4,  "allow", ["lan"], ["wan"],
         ["10.0.10.10/32"], ["all"], ["SMTP"]),
        ("5", "Allow-VPN-Access",       5,  "allow", ["vpn"], ["lan"],
         ["all"], ["10.0.0.0/8"], ["ALL"]),
        ("6", "Deny-Telnet-All",        6,  "deny",  ["all"], ["all"],
         ["all"], ["all"], ["TELNET"]),
        ("7", "Allow-DNS-Query",        7,  "allow", ["lan"], ["dmz"],
         ["all"], ["10.0.10.40/32"], ["DNS"]),
        ("8", "Allow-ICMP-Ping",        8,  "allow", ["lan"], ["lan"],
         ["all"], ["all"], ["PING"]),
        ("9", "Block-RDP-External",     9,  "deny",  ["wan"], ["lan"],
         ["all"], ["all"], ["RDP"]),
        ("10", "FortiGate-Default-Deny",10, "deny",  ["all"], ["all"],
         ["all"], ["all"], ["ALL"]),
    ]
    for rid, name, order, action, src_z, dst_z, src_a, dst_a, svcs in forti01_defs:
        rules.append(_fw_rule("fw-forti-01", rid, name, order, action,
                               src_z, dst_z, src_a, dst_a, svcs, "fortinet"))

    # --- FortiGate fw-forti-02 (5 rules) ---
    forti02_defs = [
        ("1", "Site2-LAN-WAN",     1, "allow", ["lan"], ["wan"],
         ["192.168.100.0/24"], ["all"], ["HTTP", "HTTPS"]),
        ("2", "Site2-VPN",         2, "allow", ["lan"], ["vpn"],
         ["192.168.100.0/24"], ["10.0.0.0/8"], ["ALL"]),
        ("3", "Site2-Deny-Telnet", 3, "deny",  ["all"], ["all"],
         ["all"], ["all"], ["TELNET"]),
        ("4", "Site2-Allow-PING",  4, "allow", ["lan"], ["lan"],
         ["all"], ["all"], ["PING"]),
        ("5", "Site2-Default",     5, "deny",  ["all"], ["all"],
         ["all"], ["all"], ["ALL"]),
    ]
    for rid, name, order, action, src_z, dst_z, src_a, dst_a, svcs in forti02_defs:
        rules.append(_fw_rule("fw-forti-02", rid, name, order, action,
                               src_z, dst_z, src_a, dst_a, svcs, "fortinet"))

    # --- Cisco ASA fw-asa-01 (10 rules) ---
    asa01_defs = [
        ("101", "permit-inside-outside-http",  1,  "allow", ["inside"], ["outside"],
         ["10.0.1.0/24"], ["any"], ["tcp/80", "tcp/443"]),
        ("102", "permit-inside-dmz-https",     2,  "allow", ["inside"], ["dmz"],
         ["10.0.1.0/24"], ["10.0.10.0/24"], ["tcp/443"]),
        ("103", "deny-outside-inside-smb",     3,  "deny",  ["outside"], ["inside"],
         ["any"], ["10.0.1.0/24"], ["tcp/445"]),
        ("104", "permit-dmz-outside-https",    4,  "allow", ["dmz"], ["outside"],
         ["10.0.10.0/24"], ["any"], ["tcp/443"]),
        ("105", "permit-mgmt-any-ssh",         5,  "allow", ["mgmt"], ["any"],
         ["10.0.20.0/24"], ["any"], ["tcp/22"]),
        ("106", "deny-outside-inside-rdp",     6,  "deny",  ["outside"], ["inside"],
         ["any"], ["any"], ["tcp/3389"]),
        ("107", "permit-inside-dns",           7,  "allow", ["inside"], ["dmz"],
         ["any"], ["10.0.10.40/32"], ["udp/53"]),
        ("108", "deny-telnet-all",             8,  "deny",  ["any"], ["any"],
         ["any"], ["any"], ["tcp/23"]),
        ("109", "permit-icmp-internal",        9,  "allow", ["inside"], ["inside"],
         ["10.0.0.0/8"], ["10.0.0.0/8"], ["icmp"]),
        ("110", "deny-all",                   10,  "deny",  ["any"], ["any"],
         ["any"], ["any"], ["ip"]),
    ]
    for rid, name, order, action, src_z, dst_z, src_a, dst_a, svcs in asa01_defs:
        rules.append(_fw_rule("fw-asa-01", rid, name, order, action,
                               src_z, dst_z, src_a, dst_a, svcs, "cisco_asa"))

    # --- ASA fw-asa-02 (5 rules) ---
    asa02_defs = [
        ("201", "permit-inside-http",   1, "allow", ["inside"], ["outside"],
         ["10.0.2.0/24"], ["any"], ["tcp/80", "tcp/443"]),
        ("202", "deny-outside-rfb",     2, "deny",  ["outside"], ["inside"],
         ["any"], ["any"], ["tcp/5900"]),
        ("203", "permit-mgmt-snmp",     3, "allow", ["mgmt"], ["inside"],
         ["10.0.20.0/24"], ["10.0.2.0/24"], ["udp/161"]),
        ("204", "permit-icmp",          4, "allow", ["inside"], ["inside"],
         ["10.0.0.0/8"], ["10.0.0.0/8"], ["icmp"]),
        ("205", "deny-all",             5, "deny",  ["any"], ["any"],
         ["any"], ["any"], ["ip"]),
    ]
    for rid, name, order, action, src_z, dst_z, src_a, dst_a, svcs in asa02_defs:
        rules.append(_fw_rule("fw-asa-02", rid, name, order, action,
                               src_z, dst_z, src_a, dst_a, svcs, "cisco_asa"))

    # --- ASA fw-asa-03 (3 rules) ---
    asa03_defs = [
        ("301", "permit-oob-ssh",  1, "allow", ["oob"], ["any"],
         ["192.168.200.0/24"], ["any"], ["tcp/22"]),
        ("302", "deny-oob-http",   2, "deny",  ["oob"], ["outside"],
         ["192.168.200.0/24"], ["any"], ["tcp/80"]),
        ("303", "deny-all",        3, "deny",  ["any"], ["any"],
         ["any"], ["any"], ["ip"]),
    ]
    for rid, name, order, action, src_z, dst_z, src_a, dst_a, svcs in asa03_defs:
        rules.append(_fw_rule("fw-asa-03", rid, name, order, action,
                               src_z, dst_z, src_a, dst_a, svcs, "cisco_asa"))

    return rules


# ---------------------------------------------------------------------------
# Address objects (for firewall rule context)
# ---------------------------------------------------------------------------

def _build_address_objects() -> list[AddressObjectModel]:
    objs = []
    definitions = [
        ("fw-panos-01", "LAN-Users-A",    "network",  "10.0.1.0/24"),
        ("fw-panos-01", "LAN-Users-B",    "network",  "10.0.2.0/24"),
        ("fw-panos-01", "DMZ-Web",        "host",     "10.0.10.10"),
        ("fw-panos-01", "DMZ-DB",         "host",     "10.0.10.20"),
        ("fw-panos-01", "Mgmt-Network",   "network",  "10.0.20.0/24"),
        ("fw-panos-01", "Corporate-Net",  "network",  "10.0.0.0/8"),
        ("fw-forti-01", "LAN-Subnet",     "network",  "10.0.1.0/24"),
        ("fw-forti-01", "DMZ-Subnet",     "network",  "10.0.10.0/24"),
        ("fw-asa-01",   "Inside-Net",     "network",  "10.0.1.0/24"),
        ("fw-asa-01",   "DMZ-Net",        "network",  "10.0.10.0/24"),
    ]
    for device, name, obj_type, value in definitions:
        objs.append(AddressObjectModel(
            device_hostname=device, name=name, type=obj_type, value=value, vendor="paloalto_panos"
        ))
    return objs


# ---------------------------------------------------------------------------
# Service objects
# ---------------------------------------------------------------------------

def _build_service_objects() -> list[ServiceObjectModel]:
    objs = []
    svc_defs = [
        ("fw-panos-01", "svc-https",  "tcp", "443"),
        ("fw-panos-01", "svc-http",   "tcp", "80"),
        ("fw-panos-01", "svc-ssh",    "tcp", "22"),
        ("fw-panos-01", "svc-dns",    "udp", "53"),
        ("fw-forti-01", "HTTPS",      "tcp", "443"),
        ("fw-forti-01", "HTTP",       "tcp", "80"),
        ("fw-asa-01",   "svc-80",     "tcp", "80"),
        ("fw-asa-01",   "svc-443",    "tcp", "443"),
    ]
    for device, name, proto, ports in svc_defs:
        objs.append(ServiceObjectModel(
            device_hostname=device, name=name, protocol=proto, dest_ports=ports, vendor="paloalto_panos"
        ))
    return objs


# ---------------------------------------------------------------------------
# Main builder
# ---------------------------------------------------------------------------

def build_demo_fixtures() -> NetworkFacts:
    """Return a NetworkFacts instance representing the demo campus + DC network."""
    macs, endpoints = _build_macs_and_endpoints()
    return NetworkFacts(
        devices=_build_devices(),
        interfaces=_build_interfaces(),
        ip_addresses=_build_ip_addresses(),
        subnets=_build_subnets(),
        vlans=_build_vlans(),
        macs=macs,
        endpoints=endpoints,
        firewall_rules=_build_firewall_rules(),
        address_objects=_build_address_objects(),
        service_objects=_build_service_objects(),
    )
