"""Thin client for the local MeshOptixIQ API server.

Used by the CLI and MCP server to delegate license resolution and
authenticated operations to the running API process.

Token resolution order for PAT authentication:
    1. ``MESHQ_CLI_TOKEN`` environment variable (CI/scripting override)
    2. ``~/.meshoptixiq/credentials`` file (written by ``meshq login``)
    3. Fallback: ``API_KEY`` environment variable → ``X-API-Key`` header (legacy root key)
"""

from __future__ import annotations

import os
from pathlib import Path

import requests

_DEFAULT_API_URL = "http://localhost:8000"
_CREDENTIALS_FILE = Path.home() / ".meshoptixiq" / "credentials"


# ---------------------------------------------------------------------------
# Token management helpers
# ---------------------------------------------------------------------------

def load_cli_token() -> str | None:
    """Return the stored PAT, or None if not configured."""
    token = os.environ.get("MESHQ_CLI_TOKEN")
    if token:
        return token
    if _CREDENTIALS_FILE.exists():
        return _CREDENTIALS_FILE.read_text().strip() or None
    return None


def save_cli_token(token: str) -> None:
    """Persist a PAT to ~/.meshoptixiq/credentials (mode 0o600)."""
    _CREDENTIALS_FILE.parent.mkdir(parents=True, exist_ok=True)
    _CREDENTIALS_FILE.write_text(token)
    _CREDENTIALS_FILE.chmod(0o600)


def delete_cli_token() -> None:
    """Remove the stored PAT credentials file."""
    if _CREDENTIALS_FILE.exists():
        _CREDENTIALS_FILE.unlink()


def _api_url(base_url: str | None = None) -> str:
    return (base_url or os.environ.get("MESHOPTIXIQ_API_URL", _DEFAULT_API_URL)).rstrip("/")


def _api_headers() -> dict[str, str]:
    """Build auth headers — PAT Bearer preferred; root API_KEY as fallback."""
    token = load_cli_token()
    if token:
        return {"Authorization": f"Bearer {token}"}
    key = os.environ.get("API_KEY")
    if key:
        return {"X-API-Key": key}
    return {}


def _raise_for_status_with_detail(resp: requests.Response) -> None:
    """Raise RuntimeError with FastAPI's ``detail`` field for 4xx/5xx responses."""
    if resp.status_code < 400:
        return
    try:
        detail = resp.json().get("detail", resp.reason)
    except Exception:
        detail = resp.reason
    raise RuntimeError(f"API error {resp.status_code}: {detail}")


# ---------------------------------------------------------------------------
# Auth / identity
# ---------------------------------------------------------------------------

def get_user_context(base_url: str | None = None) -> dict | None:
    """Call GET /auth/me using the stored PAT.

    Returns the user context dict, or None if no token is stored.
    Raises RuntimeError if the token is invalid or expired.
    """
    token = load_cli_token()
    if not token:
        return None
    url = _api_url(base_url)
    resp = requests.get(
        f"{url}/auth/me",
        headers={"Authorization": f"Bearer {token}"},
        timeout=5,
    )
    if resp.status_code == 401:
        raise RuntimeError("CLI token invalid or expired. Re-run 'meshq login'.")
    resp.raise_for_status()
    return resp.json()


# ---------------------------------------------------------------------------
# CLI proxy calls
# ---------------------------------------------------------------------------

def post_cli_ingest(facts_json: str, base_url: str | None = None) -> dict:
    """POST /cli/ingest — ingest NetworkFacts JSON through the API gates."""
    url = _api_url(base_url)
    resp = requests.post(
        f"{url}/cli/ingest",
        content=facts_json,
        headers={**_api_headers(), "Content-Type": "application/json"},
        timeout=60,
    )
    _raise_for_status_with_detail(resp)
    return resp.json()


def get_cli_export(fmt: str = "ansible", base_url: str | None = None) -> str:
    """GET /cli/export — fetch Ansible or INI inventory through the API gates."""
    url = _api_url(base_url)
    resp = requests.get(
        f"{url}/cli/export?format={fmt}",
        headers=_api_headers(),
        timeout=30,
    )
    _raise_for_status_with_detail(resp)
    return resp.text


def post_cli_sync(
    target: str,
    direction: str | None,
    dry_run: bool,
    base_url: str | None = None,
) -> dict:
    """POST /cli/sync — trigger NetBox sync through the API gates."""
    url = _api_url(base_url)
    resp = requests.post(
        f"{url}/cli/sync",
        json={"target": target, "direction": direction, "dry_run": dry_run},
        headers=_api_headers(),
        timeout=60,
    )
    _raise_for_status_with_detail(resp)
    return resp.json()


# ---------------------------------------------------------------------------
# License status (existing — kept for backward compat)
# ---------------------------------------------------------------------------

def get_license_status(base_url: str | None = None) -> dict:
    """Call GET /health/license on the local API server.

    Returns:
        {"plan": str, "expires": str|None, "days_remaining": int|None, "demo_mode": bool}

    Raises:
        RuntimeError: If the API is unreachable or returns an error.
    """
    url = _api_url(base_url)
    try:
        resp = requests.get(f"{url}/health/license", timeout=5)
        resp.raise_for_status()
        return resp.json()
    except requests.exceptions.ConnectionError as e:
        raise RuntimeError(
            f"Cannot reach local API at {url}. "
            "Ensure the MeshOptixIQ API server is running (see docker-compose.yml)."
        ) from e
    except Exception as e:
        raise RuntimeError(f"License check failed against local API at {url}: {e}") from e
