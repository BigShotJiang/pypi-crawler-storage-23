"""Aruba OS parsers for VLANs, MAC table, and device info.

Parses output from:
  - show vlan
  - show mac-address
  - show version
"""

from __future__ import annotations

import logging
import re
from datetime import datetime, timezone

from network_discovery.normalization.models import (
    DeviceModel,
    MACModel,
    NetworkFacts,
    VLANModel,
)
from network_discovery.parsers.base import BaseParser
from network_discovery.parsers.registry import register

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# show vlan
# ---------------------------------------------------------------------------
@register
class ArubaVLANParser(BaseParser):
    """Parses 'show vlan' output."""

    @property
    def vendor(self) -> str:
        return "aruba_os"

    @property
    def fact_type(self) -> str:
        return "vlans"

    def parse(self, raw_output: str, device_hostname: str) -> NetworkFacts:
        """Parse Aruba VLAN output.

        Example output:
        VLAN Name                             Status    Ports
        ---- -------------------------------- --------- -------------------------------
        1    default                          active    Fa0/1, Fa0/2, Fa0/3
        10   Management                       active    Fa0/10
        20   Guest                            active    Fa0/20
        """
        vlans: list[VLANModel] = []

        for line in raw_output.strip().splitlines():
            # Skip header lines and separators
            if line.startswith("VLAN") or line.startswith("----") or not line.strip():
                continue

            parts = line.split()
            if len(parts) < 3:
                continue

            vlan_id_str = parts[0]
            if not vlan_id_str.isdigit():
                continue

            vlan_id = int(vlan_id_str)
            vlan_name = parts[1]

            vlans.append(
                VLANModel(
                    device_hostname=device_hostname,
                    vlan_id=vlan_id,
                    name=vlan_name,
                )
            )

        if vlans:
            logger.info(
                "ArubaVLANParser found %d VLAN(s) on %s",
                len(vlans),
                device_hostname,
            )

        return NetworkFacts(vlans=vlans)


# ---------------------------------------------------------------------------
# show mac-address
# ---------------------------------------------------------------------------
@register
class ArubaMACTableParser(BaseParser):
    """Parses 'show mac-address' output."""

    @property
    def vendor(self) -> str:
        return "aruba_os"

    @property
    def fact_type(self) -> str:
        return "mac_table"

    def parse(self, raw_output: str, device_hostname: str) -> NetworkFacts:
        """Parse Aruba MAC address table.

        Example output:
          Vlan    Mac Address       Type        Ports
          ----    -----------       --------    -----
             1    0000.0c07.ac01    DYNAMIC     Fa0/1
             1    aabb.ccdd.eeff    DYNAMIC     Fa0/2
            10    1122.3344.5566    STATIC      Fa0/10
        """
        macs: list[MACModel] = []

        for line in raw_output.strip().splitlines():
            # Skip headers and separators
            if "Vlan" in line or "----" in line or not line.strip():
                continue

            parts = line.split()
            if len(parts) < 4:
                continue

            vlan_raw = parts[0]
            mac_addr = parts[1]
            # parts[2] = Type (DYNAMIC/STATIC)
            port = parts[3]

            # Convert VLAN to int
            vlan_id = int(vlan_raw) if vlan_raw.isdigit() else None

            # Convert Cisco-style MAC to standard format
            mac_raw = mac_addr.replace(".", "")
            if len(mac_raw) == 12:
                mac_formatted = ":".join([mac_raw[i:i+2].upper() for i in range(0, 12, 2)])
            else:
                mac_formatted = mac_addr.upper()

            macs.append(
                MACModel(
                    address=mac_formatted,
                    interface_name=port,
                    device_hostname=device_hostname,
                    vlan_id=vlan_id,
                )
            )

        if macs:
            logger.info(
                "ArubaMACTableParser found %d MAC(s) on %s",
                len(macs),
                device_hostname,
            )

        return NetworkFacts(macs=macs)


# ---------------------------------------------------------------------------
# show version
# ---------------------------------------------------------------------------
@register
class ArubaDeviceInfoParser(BaseParser):
    """Parses 'show version' output for device metadata."""

    @property
    def vendor(self) -> str:
        return "aruba_os"

    @property
    def fact_type(self) -> str:
        return "device_info"

    def parse(self, raw_output: str, device_hostname: str) -> NetworkFacts:
        """Extract key fields from 'show version'.

        Example output:
        ArubaOS Software, Version 6.5.4.8
        Compiled 2020-05-15 14:23:45 PDT

        ROM: System Bootstrap, Version 12.4(13r)T
        BOOTLDR: System Bootstrap, Version 12.4(13r)T

        switch-01 uptime is 42 days, 13 hours, 25 minutes
        System returned to ROM by power-on
        System image file is "flash:aruba-6.5.4.8.bin"

        cisco WS-C3750-24TS (PowerPC405) processor (revision C0) with 131072K bytes of memory.
        Model number: WS-C3750-24TS
        Serial number: FDO1234X5YZ
        """
        now = datetime.now(timezone.utc)

        # OS Version - Aruba-specific pattern
        os_version = None
        ver_m = re.search(r"ArubaOS.*?Version\s+(\S+)", raw_output)
        if ver_m:
            os_version = ver_m.group(1).rstrip(",")

        # Model
        model = None
        model_m = re.search(r"Model number:\s+(\S+)", raw_output)
        if model_m:
            model = model_m.group(1)
        else:
            # Try alternative pattern (hardware line)
            model_m = re.search(r"(\S+)\s+.*?processor", raw_output)
            if model_m:
                model = model_m.group(1)

        # Serial number
        serial = None
        serial_m = re.search(r"Serial [Nn]umber:\s+(\S+)", raw_output)
        if serial_m:
            serial = serial_m.group(1)

        # Hostname from uptime line
        hostname = device_hostname
        hostname_m = re.search(r"(\S+)\s+uptime is", raw_output)
        if hostname_m:
            hostname = hostname_m.group(1)

        devices = [
            DeviceModel(
                hostname=hostname,
                vendor="aruba",
                model=model,
                serial=serial,
                os_version=os_version,
                collected_at=now,
            )
        ]

        logger.info(
            "ArubaDeviceInfoParser extracted: hostname=%s, model=%s, version=%s",
            hostname,
            model,
            os_version,
        )

        return NetworkFacts(devices=devices)
