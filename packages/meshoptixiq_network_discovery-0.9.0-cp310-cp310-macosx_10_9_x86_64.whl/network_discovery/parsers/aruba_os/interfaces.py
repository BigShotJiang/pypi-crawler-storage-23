"""Aruba OS interface parsers.

Parses output from:
  - show ip interface brief
  - show interfaces

Note: Aruba OS (not ArubaOS-CX) has Cisco IOS-like syntax.
"""

from __future__ import annotations

import re
from ipaddress import ip_interface

from network_discovery.normalization.models import InterfaceModel, IPAddressModel, NetworkFacts
from network_discovery.parsers.base import BaseParser
from network_discovery.parsers.registry import register


@register
class ArubaInterfaceBriefParser(BaseParser):
    """Parses 'show ip interface brief' output."""

    @property
    def vendor(self) -> str:
        return "aruba_os"

    @property
    def fact_type(self) -> str:
        return "interfaces"

    def parse(self, raw_output: str, device_hostname: str) -> NetworkFacts:
        """Parse Aruba 'show ip interface brief' output.

        Example output:
        Interface                  IP-Address      OK? Method Status                Protocol
        FastEthernet 0/1           192.168.1.1     YES manual up                    up
        FastEthernet 0/2           10.0.0.1        YES manual up                    up
        FastEthernet 0/3           unassigned      YES unset  administratively down down
        Vlan1                      172.16.1.1      YES manual up                    up
        """
        interfaces: list[InterfaceModel] = []
        ip_addresses: list[IPAddressModel] = []

        for line in raw_output.strip().splitlines():
            # Skip header and empty lines
            if line.startswith("Interface") or not line.strip():
                continue

            parts = line.split()
            if len(parts) < 6:
                continue

            # Handle interfaces with spaces (e.g., "FastEthernet 0/1")
            # by taking the first two parts if the second part looks like a port number
            if len(parts) > 6 and "/" in parts[1]:
                iface_name = parts[0] + " " + parts[1]
                ip_addr = parts[2]
                # parts[3] = OK?  parts[4] = Method  parts[5] = Status  parts[6] = Protocol
                admin_status = parts[5].lower()
                oper_status = parts[6].lower()
            else:
                iface_name = parts[0]
                ip_addr = parts[1]
                # parts[2] = OK?  parts[3] = Method  parts[4] = Status  parts[5] = Protocol
                admin_status = parts[4].lower()
                oper_status = parts[5].lower()

            interfaces.append(
                InterfaceModel(
                    device_hostname=device_hostname,
                    name=iface_name,
                    admin_status=admin_status,
                    oper_status=oper_status,
                )
            )

            # Parse IP address if assigned
            if ip_addr and ip_addr != "unassigned":
                ip_addresses.append(
                    IPAddressModel(
                        address=ip_addr,
                        prefix_length=0,  # Not available in brief output
                        version=4,
                        interface_name=iface_name,
                        device_hostname=device_hostname,
                    )
                )

        return NetworkFacts(interfaces=interfaces, ip_addresses=ip_addresses)


@register
class ArubaInterfaceDetailParser(BaseParser):
    """Parses 'show interfaces' output for detailed interface info."""

    @property
    def vendor(self) -> str:
        return "aruba_os"

    @property
    def fact_type(self) -> str:
        return "interface_details"

    def parse(self, raw_output: str, device_hostname: str) -> NetworkFacts:
        """Parse Aruba 'show interfaces' output.

        Example output:
        FastEthernet 0/1 is up, line protocol is up
          Hardware is Fast Ethernet, address is 0000.0c07.ac01 (bia 0000.0c07.ac01)
          Internet address is 192.168.1.1/24
          MTU 1500 bytes, BW 100000 Kbit/sec
          ...
        """
        interfaces: list[InterfaceModel] = []
        ip_addresses: list[IPAddressModel] = []

        current_interface: dict[str, str | None] = {}

        for line in raw_output.splitlines():
            line = line.rstrip()

            # Interface status line (e.g., "FastEthernet 0/1 is up, line protocol is up")
            # Need to capture interface names with spaces like "FastEthernet 0/1"
            status_match = re.match(r"^(\S+(?:\s+\S+)?)\s+is\s+(\w+),\s+line protocol is\s+(\w+)", line)
            if status_match:
                # Save previous interface if exists
                if current_interface.get("name"):
                    interfaces.append(
                        InterfaceModel(
                            device_hostname=device_hostname,
                            name=current_interface["name"],
                            admin_status=current_interface.get("admin_status"),
                            oper_status=current_interface.get("oper_status"),
                            mac_address=current_interface.get("mac"),
                            speed=current_interface.get("speed"),
                            mtu=int(current_interface["mtu"]) if current_interface.get("mtu") else None,
                            description=current_interface.get("description"),
                        )
                    )

                    # Add IP if present
                    if current_interface.get("ip"):
                        try:
                            ip_iface = ip_interface(current_interface["ip"])
                            ip_addresses.append(
                                IPAddressModel(
                                    address=str(ip_iface.ip),
                                    prefix_length=ip_iface.network.prefixlen,
                                    version=4 if ip_iface.version == 4 else 6,
                                    interface_name=current_interface["name"],
                                    device_hostname=device_hostname,
                                )
                            )
                        except ValueError:
                            pass

                # Start new interface
                current_interface = {
                    "name": status_match.group(1),
                    "admin_status": status_match.group(2).lower(),
                    "oper_status": status_match.group(3).lower(),
                }
                continue

            # Skip if no current interface
            if not current_interface.get("name"):
                continue

            # Hardware/MAC address line
            if "Hardware is" in line and "address is" in line:
                mac_match = re.search(r"address is\s+([0-9a-fA-F.]+)", line)
                if mac_match:
                    # Convert from xxxx.xxxx.xxxx to XX:XX:XX:XX:XX:XX
                    mac_raw = mac_match.group(1).replace(".", "")
                    if len(mac_raw) == 12:
                        mac_formatted = ":".join([mac_raw[i:i+2].upper() for i in range(0, 12, 2)])
                        current_interface["mac"] = mac_formatted

            # IP address line
            elif "Internet address is" in line:
                ip_match = re.search(r"Internet address is\s+([\d.]+/\d+)", line)
                if ip_match:
                    current_interface["ip"] = ip_match.group(1)

            # MTU line
            elif "MTU" in line:
                mtu_match = re.search(r"MTU\s+(\d+)", line)
                if mtu_match:
                    current_interface["mtu"] = mtu_match.group(1)

                # Speed in same line
                speed_match = re.search(r"BW\s+([\d]+)\s+Kbit", line)
                if speed_match:
                    current_interface["speed"] = speed_match.group(1)

            # Description line
            elif line.strip().startswith("Description:"):
                desc = line.split("Description:", 1)[1].strip()
                if desc:
                    current_interface["description"] = desc

        # Save last interface
        if current_interface.get("name"):
            interfaces.append(
                InterfaceModel(
                    device_hostname=device_hostname,
                    name=current_interface["name"],
                    admin_status=current_interface.get("admin_status"),
                    oper_status=current_interface.get("oper_status"),
                    mac_address=current_interface.get("mac"),
                    speed=current_interface.get("speed"),
                    mtu=int(current_interface["mtu"]) if current_interface.get("mtu") else None,
                    description=current_interface.get("description"),
                )
            )

            if current_interface.get("ip"):
                try:
                    ip_iface = ip_interface(current_interface["ip"])
                    ip_addresses.append(
                        IPAddressModel(
                            address=str(ip_iface.ip),
                            prefix_length=ip_iface.network.prefixlen,
                            version=4 if ip_iface.version == 4 else 6,
                            interface_name=current_interface["name"],
                            device_hostname=device_hostname,
                        )
                    )
                except ValueError:
                    pass

        return NetworkFacts(interfaces=interfaces, ip_addresses=ip_addresses)
