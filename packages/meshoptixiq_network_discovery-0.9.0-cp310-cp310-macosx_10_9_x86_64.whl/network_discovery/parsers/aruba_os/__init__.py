"""Aruba OS parser module.

Imports all parser submodules to trigger @register decorators.
"""

# Import all parser modules to trigger registration
from . import (
    arp,  # noqa: F401
    interfaces,  # noqa: F401
    stubs,  # noqa: F401
)
