"""Aruba OS ARP and LLDP parsers.

Parses output from:
  - show arp
  - show lldp neighbors detail
"""

from __future__ import annotations

from datetime import datetime, timezone

from network_discovery.normalization.models import (
    EndpointModel,
    MACModel,
    NetworkFacts,
)
from network_discovery.parsers.base import BaseParser
from network_discovery.parsers.registry import register


@register
class ArubaARPParser(BaseParser):
    """Parses 'show arp' output."""

    @property
    def vendor(self) -> str:
        return "aruba_os"

    @property
    def fact_type(self) -> str:
        return "arp_table"

    def parse(self, raw_output: str, device_hostname: str) -> NetworkFacts:
        """Parse Aruba 'show arp' output.

        Example output:
        Protocol  Address          Age (min)  Hardware Addr   Type   Interface
        Internet  192.168.1.1             -   0000.0c07.ac01  ARPA   Vlan1
        Internet  192.168.1.100          15   aabb.ccdd.eeff  ARPA   Vlan1
        Internet  10.0.0.2               23   1122.3344.5566  ARPA   FastEthernet 0/1
        """
        macs: list[MACModel] = []
        endpoints: list[EndpointModel] = []

        now = datetime.now(timezone.utc)

        for line in raw_output.strip().splitlines():
            # Skip header and empty lines
            if line.startswith("Protocol") or not line.strip():
                continue

            parts = line.split()
            if len(parts) < 6:
                continue

            protocol = parts[0]
            if protocol.lower() != "internet":
                continue

            ip_addr = parts[1]
            # parts[2] = age, parts[3] = MAC, parts[4] = type
            mac_addr = parts[3]
            interface_name = " ".join(parts[5:])  # Interface may have spaces

            # Skip incomplete entries
            if mac_addr.lower() in ("incomplete", "-", "n/a"):
                continue

            # Convert Cisco-style MAC (aabb.ccdd.eeff) to standard format
            mac_raw = mac_addr.replace(".", "")
            if len(mac_raw) == 12:
                mac_formatted = ":".join([mac_raw[i:i+2].upper() for i in range(0, 12, 2)])
            else:
                # Already in standard format or unknown format
                mac_formatted = mac_addr.upper()

            # Add MAC entry
            macs.append(
                MACModel(
                    address=mac_formatted,
                    interface_name=interface_name,
                    device_hostname=device_hostname,
                )
            )

            # Add endpoint (IP-MAC binding)
            endpoints.append(
                EndpointModel(
                    mac_address=mac_formatted,
                    ip_address=ip_addr,
                    last_seen=now,
                )
            )

        return NetworkFacts(macs=macs, endpoints=endpoints)


@register
class ArubaLLDPParser(BaseParser):
    """Parses 'show lldp neighbors detail' output."""

    @property
    def vendor(self) -> str:
        return "aruba_os"

    @property
    def fact_type(self) -> str:
        return "neighbors"

    def parse(self, raw_output: str, device_hostname: str) -> NetworkFacts:
        """Parse Aruba LLDP neighbors output.

        Example output:
        Local Interface: FastEthernet 0/1
        Chassis id: 0018.0fee.8ec0
        Port id: Gi0/1
        Port Description: GigabitEthernet0/1
        System Name: switch-02
        System Description: Cisco IOS Software...
        ...
        """
        # Note: LLDP neighbor parsing would populate a NeighborModel
        # which is not in the current schema. For now, we return empty facts.
        # This can be extended when neighbor models are added.

        # Placeholder for future neighbor model implementation
        return NetworkFacts()
