# Import parser modules to trigger registration with the parser registry.
from network_discovery.parsers.cisco_ios import arp, interfaces, stubs  # noqa: F401
