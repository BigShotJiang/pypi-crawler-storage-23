"""Cisco IOS ARP table parser.

Parses output from:
  - show ip arp
"""

from __future__ import annotations

from datetime import datetime, timezone

from network_discovery.normalization.models import (
    EndpointModel,
    IPAddressModel,
    MACModel,
    NetworkFacts,
)
from network_discovery.parsers.base import BaseParser
from network_discovery.parsers.registry import register


@register
class CiscoARPParser(BaseParser):
    """Parses 'show ip arp' output."""

    @property
    def vendor(self) -> str:
        return "cisco_ios"

    @property
    def fact_type(self) -> str:
        return "arp_table"

    def parse(self, raw_output: str, device_hostname: str) -> NetworkFacts:
        macs: list[MACModel] = []
        ip_addresses: list[IPAddressModel] = []
        endpoints: list[EndpointModel] = []

        now = datetime.now(timezone.utc)

        for line in raw_output.strip().splitlines():
            # Skip header and incomplete entries
            if line.startswith("Protocol") or not line.strip():
                continue

            # Typical format:
            # Internet  192.168.1.1     0   aabb.ccdd.eeff  ARPA   GigabitEthernet0/1
            parts = line.split()
            if len(parts) < 6:
                continue

            protocol = parts[0]
            if protocol.lower() != "internet":
                continue

            ip_addr = parts[1]
            # parts[2] = age (minutes), parts[3] = MAC, parts[4] = type, parts[5] = interface
            mac_addr = parts[3]
            interface_name = parts[5]

            # Skip incomplete entries (MAC shown as "Incomplete" or "-")
            if mac_addr.lower() in ("incomplete", "-"):
                continue

            macs.append(
                MACModel(
                    address=mac_addr,
                    interface_name=interface_name,
                    device_hostname=device_hostname,
                )
            )

            ip_addresses.append(
                IPAddressModel(
                    address=ip_addr,
                    prefix_length=0,  # Not available from ARP output
                    version=4,
                    interface_name=interface_name,
                    device_hostname=device_hostname,
                )
            )

            endpoints.append(
                EndpointModel(
                    mac_address=mac_addr,
                    ip_address=ip_addr,
                    last_seen=now,
                )
            )

        return NetworkFacts(
            macs=macs,
            ip_addresses=ip_addresses,
            endpoints=endpoints,
        )
