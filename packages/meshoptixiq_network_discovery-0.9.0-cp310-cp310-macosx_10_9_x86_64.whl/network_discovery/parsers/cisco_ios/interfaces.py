"""Cisco IOS interface parsers.

Parses output from:
  - show ip interface brief
  - show interfaces
"""

from __future__ import annotations

import re

from network_discovery.normalization.models import InterfaceModel, IPAddressModel, NetworkFacts
from network_discovery.parsers.base import BaseParser
from network_discovery.parsers.registry import register


@register
class CiscoInterfaceBriefParser(BaseParser):
    """Parses 'show ip interface brief' output."""

    @property
    def vendor(self) -> str:
        return "cisco_ios"

    @property
    def fact_type(self) -> str:
        return "interfaces"

    def parse(self, raw_output: str, device_hostname: str) -> NetworkFacts:
        interfaces: list[InterfaceModel] = []
        ip_addresses: list[IPAddressModel] = []

        for line in raw_output.strip().splitlines():
            # Skip header line
            if line.startswith("Interface") or not line.strip():
                continue

            parts = line.split()
            if len(parts) < 6:
                continue

            iface_name = parts[0]
            ip_addr = parts[1]
            # parts[2] = OK?  parts[3] = Method  parts[4] = Status  parts[5] = Protocol
            admin_status = parts[4].lower()
            oper_status = parts[5].lower()

            interfaces.append(
                InterfaceModel(
                    device_hostname=device_hostname,
                    name=iface_name,
                    admin_status=admin_status,
                    oper_status=oper_status,
                )
            )

            if ip_addr != "unassigned":
                ip_addresses.append(
                    IPAddressModel(
                        address=ip_addr,
                        prefix_length=0,  # Not available from brief output
                        version=4,
                        interface_name=iface_name,
                        device_hostname=device_hostname,
                    )
                )

        return NetworkFacts(interfaces=interfaces, ip_addresses=ip_addresses)


@register
class CiscoInterfaceDetailParser(BaseParser):
    """Parses 'show interfaces' output for detailed interface info."""

    @property
    def vendor(self) -> str:
        return "cisco_ios"

    @property
    def fact_type(self) -> str:
        return "interface_details"

    def parse(self, raw_output: str, device_hostname: str) -> NetworkFacts:
        interfaces: list[InterfaceModel] = []

        # Split output into per-interface blocks
        blocks = re.split(r"^(\S+) is ", raw_output, flags=re.MULTILINE)

        # blocks[0] is empty or preamble, then alternating: iface_name, rest_of_block
        i = 1
        while i < len(blocks) - 1:
            iface_name = blocks[i].strip()
            block_text = blocks[i + 1]
            i += 2

            admin_status = "up"
            oper_status = "up"

            # First line contains admin status: "up, line protocol is up"
            first_line = block_text.split("\n")[0]
            if "administratively down" in first_line:
                admin_status = "down"
            elif "down" in first_line.split(",")[0]:
                admin_status = "down"

            if "line protocol is down" in first_line:
                oper_status = "down"

            # Extract MAC (Hardware address / bia)
            mac_address = None
            mac_match = re.search(r"address is ([0-9a-fA-F.]+)", block_text)
            if mac_match:
                mac_address = mac_match.group(1)

            # Extract MTU
            mtu = None
            mtu_match = re.search(r"MTU (\d+) bytes", block_text)
            if mtu_match:
                mtu = int(mtu_match.group(1))

            # Extract speed (BW)
            speed = None
            speed_match = re.search(r"BW (\d+ \w+)", block_text)
            if speed_match:
                speed = speed_match.group(1)

            # Extract description
            description = None
            desc_match = re.search(r"Description: (.+)", block_text)
            if desc_match:
                description = desc_match.group(1).strip()

            interfaces.append(
                InterfaceModel(
                    device_hostname=device_hostname,
                    name=iface_name,
                    admin_status=admin_status,
                    oper_status=oper_status,
                    mac_address=mac_address,
                    mtu=mtu,
                    speed=speed,
                    description=description,
                )
            )

        return NetworkFacts(interfaces=interfaces)
