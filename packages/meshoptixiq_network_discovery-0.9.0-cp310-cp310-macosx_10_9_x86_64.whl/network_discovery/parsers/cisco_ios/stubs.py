"""Cisco IOS parsers for CDP neighbors, VLANs, MAC table, and device info.

Parses output from:
  - show cdp neighbors detail
  - show vlan brief
  - show mac address-table
  - show version
"""

from __future__ import annotations

import logging
import re
from datetime import datetime, timezone

from network_discovery.normalization.models import (
    DeviceModel,
    MACModel,
    NetworkFacts,
    VLANModel,
)
from network_discovery.parsers.base import BaseParser
from network_discovery.parsers.registry import register

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# show cdp neighbors detail
# ---------------------------------------------------------------------------
@register
class CiscoCDPParser(BaseParser):
    """Parses 'show cdp neighbors detail' output into device facts."""

    @property
    def vendor(self) -> str:
        return "cisco_ios"

    @property
    def fact_type(self) -> str:
        return "neighbors"

    def parse(self, raw_output: str, device_hostname: str) -> NetworkFacts:
        """Parse CDP neighbour blocks.

        Each neighbour block starts with a separator line of dashes and
        contains fields such as:
          Device ID: <hostname>
          Platform: <platform>, Capabilities: ...
          Interface: <local_intf>, Port ID (outgoing port): <remote_intf>
        """
        devices: list[DeviceModel] = []
        now = datetime.now(timezone.utc)

        # Split on the separator lines
        blocks = re.split(r"-{10,}", raw_output)

        for block in blocks:
            if not block.strip():
                continue

            device_id_m = re.search(r"Device ID:\s*(\S+)", block)
            platform_m = re.search(r"Platform:\s*(.+?)(?:,|$)", block, re.MULTILINE)

            if not device_id_m:
                continue

            neighbor_hostname = device_id_m.group(1).split(".")[0]  # strip domain
            model = platform_m.group(1).strip() if platform_m else None

            devices.append(
                DeviceModel(
                    hostname=neighbor_hostname,
                    vendor="cisco_ios",
                    model=model,
                    collected_at=now,
                )
            )

        if devices:
            logger.info(
                "CiscoCDPParser found %d neighbour(s) on %s",
                len(devices),
                device_hostname,
            )

        return NetworkFacts(devices=devices)


# ---------------------------------------------------------------------------
# show vlan brief
# ---------------------------------------------------------------------------
@register
class CiscoVLANParser(BaseParser):
    """Parses 'show vlan brief' output."""

    @property
    def vendor(self) -> str:
        return "cisco_ios"

    @property
    def fact_type(self) -> str:
        return "vlans"

    def parse(self, raw_output: str, device_hostname: str) -> NetworkFacts:
        """Parse lines like:

        VLAN Name                             Status    Ports
        ---- -------------------------------- --------- ------
        1    default                          active    Gi0/1, Gi0/2
        10   MGMT                             active    Gi0/3
        """
        vlans: list[VLANModel] = []
        header_seen = False

        for line in raw_output.strip().splitlines():
            stripped = line.strip()
            if not stripped:
                continue

            # Detect header / separator
            if stripped.startswith("VLAN") and "Name" in stripped:
                header_seen = True
                continue
            if stripped.startswith("----"):
                header_seen = True
                continue

            if not header_seen:
                continue

            # Parse: VLAN_ID  NAME  STATUS  [PORTS...]
            m = re.match(r"^(\d+)\s+(\S+)\s+\S+", stripped)
            if not m:
                continue

            vlan_id = int(m.group(1))
            name = m.group(2)

            if vlan_id < 1 or vlan_id > 4094:
                continue

            vlans.append(
                VLANModel(
                    device_hostname=device_hostname,
                    vlan_id=vlan_id,
                    name=name,
                )
            )

        if vlans:
            logger.info(
                "CiscoVLANParser found %d VLAN(s) on %s",
                len(vlans),
                device_hostname,
            )

        return NetworkFacts(vlans=vlans)


# ---------------------------------------------------------------------------
# show mac address-table
# ---------------------------------------------------------------------------
@register
class CiscoMACTableParser(BaseParser):
    """Parses 'show mac address-table' output."""

    @property
    def vendor(self) -> str:
        return "cisco_ios"

    @property
    def fact_type(self) -> str:
        return "mac_table"

    def parse(self, raw_output: str, device_hostname: str) -> NetworkFacts:
        """Parse lines like:

          Vlan    Mac Address       Type        Ports
          ----    -----------       --------    -----
             1    aabb.ccdd.0001    DYNAMIC     Gi0/1
            10    aabb.ccdd.0002    STATIC      Gi0/2

        Also handles the format with * prefix and ``All`` in Vlan column.
        """
        macs: list[MACModel] = []

        for line in raw_output.strip().splitlines():
            stripped = line.strip().lstrip("*").strip()
            if not stripped:
                continue

            # Match: optional-star VLAN  MAC  TYPE  PORT
            m = re.match(
                r"^(\d+|All)\s+"
                r"([0-9a-fA-F]{4}\.[0-9a-fA-F]{4}\.[0-9a-fA-F]{4})\s+"
                r"(\S+)\s+"
                r"(\S+)",
                stripped,
            )
            if not m:
                continue

            vlan_raw, mac_addr, _mac_type, port = m.groups()
            vlan_id = int(vlan_raw) if vlan_raw.isdigit() else None

            macs.append(
                MACModel(
                    address=mac_addr,
                    interface_name=port,
                    device_hostname=device_hostname,
                    vlan_id=vlan_id,
                )
            )

        if macs:
            logger.info(
                "CiscoMACTableParser found %d MAC(s) on %s",
                len(macs),
                device_hostname,
            )

        return NetworkFacts(macs=macs)


# ---------------------------------------------------------------------------
# show version
# ---------------------------------------------------------------------------
@register
class CiscoDeviceInfoParser(BaseParser):
    """Parses 'show version' output for device metadata."""

    @property
    def vendor(self) -> str:
        return "cisco_ios"

    @property
    def fact_type(self) -> str:
        return "device_info"

    def parse(self, raw_output: str, device_hostname: str) -> NetworkFacts:
        """Extract key fields from 'show version':

        - IOS version string
        - Hardware model
        - Serial number
        - Hostname (from the uptime banner)
        """
        now = datetime.now(timezone.utc)

        # IOS Version
        ver_m = re.search(
            r"(?:Cisco IOS.*?Version|IOS.*Software.*Version)\s+(\S+)", raw_output
        )
        os_version = ver_m.group(1).rstrip(",") if ver_m else None

        # Model / platform
        model = None
        model_m = re.search(
            r"(?:cisco|Cisco)\s+([\w\-]+)\s+.*?(?:processor|bytes of memory)",
            raw_output,
        )
        if model_m:
            model = model_m.group(1)

        # Serial number
        serial = None
        serial_m = re.search(
            r"(?:Processor board ID|System serial number)\s+(\S+)", raw_output
        )
        if serial_m:
            serial = serial_m.group(1)

        # Hostname from banner (optional, fall back to device_hostname)
        host_m = re.search(r"^(\S+)\s+uptime is", raw_output, re.MULTILINE)
        hostname = host_m.group(1) if host_m else device_hostname

        device = DeviceModel(
            hostname=hostname,
            vendor="cisco_ios",
            model=model,
            serial=serial,
            os_version=os_version,
            collected_at=now,
        )

        logger.info(
            "CiscoDeviceInfoParser: %s model=%s serial=%s ver=%s",
            hostname,
            model,
            serial,
            os_version,
        )

        return NetworkFacts(devices=[device])
