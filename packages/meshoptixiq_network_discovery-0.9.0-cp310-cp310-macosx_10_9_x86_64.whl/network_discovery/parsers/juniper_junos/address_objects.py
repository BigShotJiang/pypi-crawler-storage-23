"""Juniper SRX JunOS address book parser.

Parses output from:
  - show configuration security address-book | display set

Example output format:
  set security address-book global address HOST-10 10.0.0.1/32
  set security address-book global address NET-192 192.168.0.0/24
  set security address-book global address RANGE-1 range-address 10.0.0.1 to 10.0.0.10
  set security address-book global address FQDN-1 dns-name example.com
  set security address-book global address-set GROUP-1 address HOST-10
  set security address-book global address-set GROUP-1 address NET-192
"""

from __future__ import annotations

import re
from typing import Literal

from network_discovery.normalization.models import AddressObjectModel, NetworkFacts
from network_discovery.parsers.base import BaseParser
from network_discovery.parsers.registry import register

# Individual address: set security address-book <book> address <name> <value>
_ADDR_LINE = re.compile(
    r"set security address-book \S+ address (\S+)\s+(.*)", re.IGNORECASE
)
# Address group member: set security address-book <book> address-set <name> address <member>
_GROUP_LINE = re.compile(
    r"set security address-book \S+ address-set (\S+) address (\S+)", re.IGNORECASE
)
_RANGE = re.compile(r"range-address\s+(\S+)\s+to\s+(\S+)", re.IGNORECASE)
_DNS = re.compile(r"dns-name\s+(\S+)", re.IGNORECASE)


@register
class JunosAddressObjectsParser(BaseParser):
    """Parses 'show configuration security address-book | display set' output."""

    @property
    def vendor(self) -> str:
        return "juniper_junos"

    @property
    def fact_type(self) -> str:
        return "address_objects"

    def parse(self, raw_output: str, device_hostname: str) -> NetworkFacts:
        objects: list[AddressObjectModel] = []
        # Track group members to build group value strings
        groups: dict[str, list[str]] = {}

        for line in raw_output.splitlines():
            line = line.strip()
            if not line:
                continue

            # Group member line (check before address line since regex is more specific)
            gm = _GROUP_LINE.match(line)
            if gm:
                group_name = gm.group(1)
                member = gm.group(2)
                groups.setdefault(group_name, []).append(member)
                continue

            # Individual address line
            am = _ADDR_LINE.match(line)
            if am:
                name = am.group(1)
                value_str = am.group(2).strip()

                obj_type: Literal["host", "network", "range", "fqdn", "group"]
                value: str

                rm = _RANGE.match(value_str)
                dm = _DNS.match(value_str)

                if rm:
                    obj_type = "range"
                    value = f"{rm.group(1)}-{rm.group(2)}"
                elif dm:
                    obj_type = "fqdn"
                    value = dm.group(1)
                elif "/" in value_str:
                    # CIDR — host (/32) or network
                    prefix = int(value_str.split("/")[1])
                    obj_type = "host" if prefix == 32 else "network"
                    value = value_str
                else:
                    # Plain IP without prefix — treat as host
                    obj_type = "host"
                    value = value_str

                objects.append(AddressObjectModel(
                    device_hostname=device_hostname,
                    name=name,
                    type=obj_type,
                    value=value,
                    vendor="juniper_junos",
                ))

        # Emit group objects
        for group_name, members in groups.items():
            objects.append(AddressObjectModel(
                device_hostname=device_hostname,
                name=group_name,
                type="group",
                value=",".join(members),
                vendor="juniper_junos",
            ))

        return NetworkFacts(address_objects=objects)
