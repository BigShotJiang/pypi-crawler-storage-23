"""Juniper JunOS device_info parser.

Parses output from 'show version' to extract device metadata.
"""

from __future__ import annotations

import logging
import re
from datetime import datetime, timezone

from network_discovery.normalization.models import DeviceModel, NetworkFacts
from network_discovery.parsers.base import BaseParser
from network_discovery.parsers.registry import register

logger = logging.getLogger(__name__)


@register
class JuniperDeviceInfoParser(BaseParser):
    """Parses 'show version' output for Juniper JunOS device metadata."""

    @property
    def vendor(self) -> str:
        return "juniper_junos"

    @property
    def fact_type(self) -> str:
        return "device_info"

    def parse(self, raw_output: str, device_hostname: str) -> NetworkFacts:
        now = datetime.now(timezone.utc)

        # OS version — e.g. "Junos: 21.2R3-S2.3" or "JUNOS Base OS boot [21.4R1.12]"
        os_version = None
        ver_m = re.search(r"Junos:\s+([\d.A-Za-z\-]+)", raw_output)
        if ver_m:
            os_version = ver_m.group(1)
        else:
            ver_m2 = re.search(r"JUNOS\s+[\w\s]+\[(\S+)\]", raw_output)
            if ver_m2:
                os_version = ver_m2.group(1)

        # Model — e.g. "Model: ex4300-48t"
        model = None
        model_m = re.search(r"Model:\s+(\S+)", raw_output, re.IGNORECASE)
        if model_m:
            model = model_m.group(1)

        # Serial — first occurrence of "Chassis  <serial>" block
        serial = None
        serial_m = re.search(r"^Chassis\s+(\S+)", raw_output, re.MULTILINE)
        if serial_m:
            serial = serial_m.group(1)

        # Hostname — e.g. "Hostname: core-sw-01"
        hostname = device_hostname
        host_m = re.search(r"Hostname:\s+(\S+)", raw_output, re.IGNORECASE)
        if host_m:
            hostname = host_m.group(1)

        device = DeviceModel(
            hostname=hostname,
            vendor="juniper_junos",
            model=model,
            serial=serial,
            os_version=os_version,
            collected_at=now,
        )

        logger.info(
            "JuniperDeviceInfoParser: %s model=%s serial=%s ver=%s",
            hostname, model, serial, os_version,
        )

        return NetworkFacts(devices=[device])
