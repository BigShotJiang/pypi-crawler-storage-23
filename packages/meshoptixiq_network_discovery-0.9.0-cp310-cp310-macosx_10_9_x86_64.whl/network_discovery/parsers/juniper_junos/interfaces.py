"""Juniper JunOS interface parsers."""

from __future__ import annotations

from ipaddress import ip_interface

from network_discovery.normalization.models import InterfaceModel, IPAddressModel, NetworkFacts
from network_discovery.parsers.base import BaseParser
from network_discovery.parsers.registry import register


@register
class JunosInterfaceTerseParser(BaseParser):
    """Parses 'show interfaces terse' output."""

    @property
    def vendor(self) -> str:
        return "juniper_junos"

    @property
    def fact_type(self) -> str:
        return "interfaces"

    def parse(self, raw_output: str, device_hostname: str) -> NetworkFacts:
        interfaces: list[InterfaceModel] = []
        ip_addresses: list[IPAddressModel] = []

        current_interface = None

        # Regex to match lines.
        # Interface name can be indented if it's a logical unit following physical,
        # but 'terse' usually lists them explicitly or omits if same as prev line (rare in granular output, but possible).
        # Standard terse:
        # Interface               Admin Link Proto    Local                 Remote
        # ge-0/0/0                up    up
        # ge-0/0/0.0              up    up   inet     10.0.0.1/24

        for line in raw_output.splitlines():
            line = line.strip()
            if not line or line.startswith("Interface"):
                continue

            parts = line.split()

            # Cases:
            # 1. Full line: ge-0/0/0.0 up up inet 1.2.3.4/24
            # 2. Continuation:        inet     1.2.3.5/24 (if secondary IP) - though terse usually aligns fields
            # 3. Physical only: ge-0/0/0 up up

            # If line starts with admin status (up/down), it might be a continuation of previous interface?
            # In 'terse', usually the first column is populated or empty.

            if len(parts) < 2:
                continue

            first_col = parts[0]

            # Check if first col looks like an interface name (has non-alpha or is known type)
            # OR if it is "up"/"down" (unlikely for first col).

            if first_col in ["up", "down"]:
                # Continuation line?
                # Junos terse output usually aligns columns.
                # If using split(), specific formatting is lost.
                # Let's assume standard behavior:
                # If 0th element is 'up'/'down', it might be Proto if indentation happened, but split() eats whitespace.
                # Actually, in 'terse', if interface name is omitted, it's a secondary IP on same interface.
                # But 'terse' *usually* repeats expected columns or keeps alignment.
                # Let's rely on detection.
                pass
            else:
                 current_interface = first_col

            # Mapping based on position is tricky with optional columns.
            # Best guess:
            # If "inet" is present, it's an IP line.

            if "inet" in parts:
                idx = parts.index("inet")
                # Next part should be IP/CIDR
                if idx + 1 < len(parts):
                    ip_str = parts[idx + 1]
                    try:
                        # Handle 10.0.0.1/24
                        # Also handle "10.0.0.1 --> 10.0.0.2" (ptp)
                        if "-->" in parts:
                            # Local is before arrow
                            arrow_idx = parts.index("-->")
                            if arrow_idx > 0:
                                ip_str = parts[arrow_idx - 1]

                        ip_iface = ip_interface(ip_str)
                        ip_addresses.append(
                            IPAddressModel(
                                address=str(ip_iface.ip),
                                prefix_length=ip_iface.network.prefixlen,
                                version=4,
                                interface_name=current_interface,
                                device_hostname=device_hostname,
                            )
                        )
                    except ValueError:
                        pass

            # interface status extraction
            # Standard: Name Admin Link ...
            # If current_interface was just set, parts[1] is Admin, parts[2] is Link
            if first_col == current_interface and len(parts) >= 3:
                admin = parts[1]
                oper = parts[2]

                # Only add interface model if we haven't processed this interface name yet?
                # Or just add it and allow dedup in normalization?
                # Normalization usually merges.
                # But 'terse' lists physical (ge-0/0/0) and logical (ge-0/0/0.0) as separate lines.
                # We want both.

                interfaces.append(
                    InterfaceModel(
                        device_hostname=device_hostname,
                        name=current_interface,
                        admin_status=admin,
                        oper_status=oper
                    )
                )

        return NetworkFacts(interfaces=interfaces, ip_addresses=ip_addresses)
