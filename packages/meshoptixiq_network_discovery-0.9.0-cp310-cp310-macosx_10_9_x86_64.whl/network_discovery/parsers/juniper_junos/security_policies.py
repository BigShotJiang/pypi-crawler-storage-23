"""Juniper SRX JunOS security policy parser.

Parses output from:
  - show security policies detail

Example output format:
  Default policy: deny-all

  Policy: allow-web, State: enabled, Index: 4, Scope Policy: 0, Sequence number: 1
    From zone: trust, To zone: untrust
    Source addresses:
      any-ipv4
    Destination addresses:
      any-ipv4
    Application: junos-http
    Action: permit
      Timeout: 0
    Session log: at-close

  Policy: deny-all, State: enabled, Index: 5, Scope Policy: 0, Sequence number: 2
    From zone: trust, To zone: untrust
    Source addresses:
      any-ipv4
    Destination addresses:
      any-ipv4
    Application: any
    Action: deny
"""

from __future__ import annotations

import re
from datetime import datetime, timezone

from network_discovery.normalization.models import FirewallRuleModel, NetworkFacts
from network_discovery.parsers.base import BaseParser
from network_discovery.parsers.registry import register

_POLICY_HEADER = re.compile(r"^\s*Policy:\s+(\S+),.*?Sequence number:\s+(\d+)", re.IGNORECASE)
_ZONE_PAIR = re.compile(r"From zone:\s+(\S+),\s+To zone:\s+(\S+)", re.IGNORECASE)
_STATE = re.compile(r"State:\s+(\w+)", re.IGNORECASE)
_ACTION = re.compile(r"^\s*Action:\s+(\w+)", re.IGNORECASE)
_SESSION_LOG = re.compile(r"Session log:", re.IGNORECASE)
_APPLICATION = re.compile(r"^\s*Application:\s+(.+)", re.IGNORECASE)


@register
class JunosSecurityPoliciesParser(BaseParser):
    """Parses 'show security policies detail' output."""

    @property
    def vendor(self) -> str:
        return "juniper_junos"

    @property
    def fact_type(self) -> str:
        return "security_policies"

    def parse(self, raw_output: str, device_hostname: str) -> NetworkFacts:
        rules: list[FirewallRuleModel] = []
        now = datetime.now(timezone.utc)

        current: dict = {}
        src_section = False
        dst_section = False

        def finalize():
            if not current.get("name"):
                return
            raw_action = current.get("action", "deny").lower()
            action_map = {
                "permit": "allow", "allow": "allow",
                "deny": "deny", "reject": "reject", "drop": "drop",
            }
            action = action_map.get(raw_action, "deny")

            enabled = current.get("state", "enabled").lower() == "enabled"

            rules.append(FirewallRuleModel(
                device_hostname=device_hostname,
                rule_id=current["name"],
                rule_name=current["name"],
                rule_order=current.get("seq", len(rules) + 1),
                action=action,
                source_zones=current.get("from_zones", []),
                destination_zones=current.get("to_zones", []),
                source_addresses=current.get("src_addrs", []),
                destination_addresses=current.get("dst_addrs", []),
                services=current.get("applications", []),
                protocols=[],
                destination_ports=[],
                enabled=enabled,
                log_enabled=current.get("log_enabled", False),
                vendor="juniper_junos",
                collected_at=now,
            ))

        for line in raw_output.splitlines():
            # Policy header
            m = _POLICY_HEADER.match(line)
            if m:
                finalize()
                current = {
                    "name": m.group(1).rstrip(","),
                    "seq": int(m.group(2)),
                    "src_addrs": [],
                    "dst_addrs": [],
                    "applications": [],
                    "from_zones": [],
                    "to_zones": [],
                }
                # Extract state from same line
                sm = _STATE.search(line)
                if sm:
                    current["state"] = sm.group(1)
                src_section = False
                dst_section = False
                continue

            if not current.get("name"):
                continue

            # Zone pair
            zm = _ZONE_PAIR.search(line)
            if zm:
                current["from_zones"] = [zm.group(1)]
                current["to_zones"] = [zm.group(2)]
                src_section = False
                dst_section = False
                continue

            # Section headers
            stripped = line.strip()
            if stripped == "Source addresses:":
                src_section = True
                dst_section = False
                continue
            if stripped == "Destination addresses:":
                src_section = False
                dst_section = True
                continue

            # Application line
            am = _APPLICATION.match(line)
            if am:
                src_section = False
                dst_section = False
                app = am.group(1).strip()
                current["applications"].append(app)
                continue

            # Action line
            acm = _ACTION.match(line)
            if acm:
                src_section = False
                dst_section = False
                current["action"] = acm.group(1)
                continue

            # Session log
            if _SESSION_LOG.search(line):
                current["log_enabled"] = True
                continue

            # Address items (indented, non-empty, no colon)
            if stripped and ":" not in stripped:
                if src_section:
                    current["src_addrs"].append(stripped)
                elif dst_section:
                    current["dst_addrs"].append(stripped)

        finalize()
        return NetworkFacts(firewall_rules=rules)
