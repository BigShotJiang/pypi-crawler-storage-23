"""Fortinet FortiGate security policy parser.

Parses output from:
  - show firewall policy

FortiOS config syntax uses edit/next blocks with set directives:

  config firewall policy
      edit 1
          set name "allow-web"
          set srcintf "internal"
          set dstintf "wan1"
          set srcaddr "all"
          set dstaddr "all"
          set action accept
          set schedule "always"
          set service "HTTPS" "HTTP"
          set logtraffic all
          set status enable
      next
      edit 2
          set name "deny-all"
          set srcintf "internal"
          set dstintf "wan1"
          set srcaddr "all"
          set dstaddr "all"
          set action deny
          set status enable
      next
  end
"""

from __future__ import annotations

import re
from datetime import datetime, timezone

from network_discovery.normalization.models import FirewallRuleModel, NetworkFacts
from network_discovery.parsers.base import BaseParser
from network_discovery.parsers.registry import register

_EDIT = re.compile(r"^\s*edit\s+(\d+)")
_NEXT = re.compile(r"^\s*next\b")
_SET = re.compile(r'^\s*set\s+(\S+)\s+(.*)')


def _parse_set_list(value_str: str) -> list[str]:
    """Parse FortiOS quoted-space list: '"val1" "val2"' → ['val1', 'val2']."""
    return re.findall(r'"([^"]+)"|(\S+)', value_str.replace('"', ' '))  # type: ignore[return-value]


def _parse_values(value_str: str) -> list[str]:
    """Extract values from FortiOS set line: may be quoted or unquoted tokens."""
    tokens = re.findall(r'"([^"]+)"|(\S+)', value_str)
    return [a or b for a, b in tokens]


@register
class FortinetSecurityPoliciesParser(BaseParser):
    """Parses 'show firewall policy' output."""

    @property
    def vendor(self) -> str:
        return "fortinet"

    @property
    def fact_type(self) -> str:
        return "security_policies"

    def parse(self, raw_output: str, device_hostname: str) -> NetworkFacts:
        rules: list[FirewallRuleModel] = []
        now = datetime.now(timezone.utc)

        current: dict = {}

        def finalize():
            if not current.get("rule_id"):
                return
            raw_action = current.get("action", "deny").lower()
            action_map = {"accept": "allow", "allow": "allow", "deny": "deny", "drop": "drop"}
            action = action_map.get(raw_action, "deny")

            status = current.get("status", "enable").lower()
            enabled = status != "disable"

            log_val = current.get("logtraffic", "disable").lower()
            log_enabled = log_val in ("all", "utm", "enable")

            rules.append(FirewallRuleModel(
                device_hostname=device_hostname,
                rule_id=current["rule_id"],
                rule_name=current.get("name"),
                rule_order=current["rule_order"],
                action=action,
                source_zones=current.get("srcintf", ["any"]),
                destination_zones=current.get("dstintf", ["any"]),
                source_addresses=current.get("srcaddr", ["any"]),
                destination_addresses=current.get("dstaddr", ["any"]),
                services=current.get("service", ["any"]),
                protocols=[],
                destination_ports=[],
                enabled=enabled,
                log_enabled=log_enabled,
                vendor="fortinet",
                collected_at=now,
            ))

        rule_order = 0
        for line in raw_output.splitlines():
            em = _EDIT.match(line)
            if em:
                finalize()
                rule_order += 1
                current = {"rule_id": em.group(1), "rule_order": rule_order}
                continue

            if _NEXT.match(line):
                finalize()
                current = {}
                continue

            if not current.get("rule_id"):
                continue

            sm = _SET.match(line)
            if sm:
                key = sm.group(1).lower()
                val_str = sm.group(2).strip().strip('"')
                values = _parse_values(sm.group(2))

                if key in ("srcintf", "dstintf", "srcaddr", "dstaddr", "service"):
                    current[key] = values if values else [val_str]
                else:
                    current[key] = val_str

        finalize()
        return NetworkFacts(firewall_rules=rules)
