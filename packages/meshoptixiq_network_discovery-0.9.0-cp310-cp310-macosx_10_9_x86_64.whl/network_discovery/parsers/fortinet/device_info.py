"""Fortinet FortiGate device_info parser.

Parses output from 'get system status' to extract device metadata.
"""

from __future__ import annotations

import logging
import re
from datetime import datetime, timezone

from network_discovery.normalization.models import DeviceModel, NetworkFacts
from network_discovery.parsers.base import BaseParser
from network_discovery.parsers.registry import register

logger = logging.getLogger(__name__)


@register
class FortinetDeviceInfoParser(BaseParser):
    """Parses 'get system status' output for Fortinet FortiGate device metadata."""

    @property
    def vendor(self) -> str:
        return "fortinet"

    @property
    def fact_type(self) -> str:
        return "device_info"

    def parse(self, raw_output: str, device_hostname: str) -> NetworkFacts:
        now = datetime.now(timezone.utc)

        # OS version — line with "Version:" e.g.
        #   "Version: FortiGate-100F v7.2.5,build1517,230101 (GA)"
        os_version = None
        ver_m = re.search(r"Version:\s+\S+\s+v([\d.]+)", raw_output, re.IGNORECASE)
        if ver_m:
            os_version = ver_m.group(1)

        # Model — e.g. "Platform Full Name: FortiGate-100F" or "Platform Type: FG100F"
        model = None
        model_m = re.search(r"Platform Full Name:\s+(.+)", raw_output, re.IGNORECASE)
        if model_m:
            model = model_m.group(1).strip()
        else:
            model_m2 = re.search(r"Platform Type:\s+(\S+)", raw_output, re.IGNORECASE)
            if model_m2:
                model = model_m2.group(1)

        # Serial — e.g. "Serial-Number: FGT1H0XXXXXXXXX"
        serial = None
        serial_m = re.search(r"Serial-Number:\s+(\S+)", raw_output, re.IGNORECASE)
        if serial_m:
            serial = serial_m.group(1)

        # Hostname — e.g. "Hostname: fw-dc-01"
        hostname = device_hostname
        host_m = re.search(r"Hostname:\s+(\S+)", raw_output, re.IGNORECASE)
        if host_m:
            hostname = host_m.group(1)

        device = DeviceModel(
            hostname=hostname,
            vendor="fortinet",
            model=model,
            serial=serial,
            os_version=os_version,
            collected_at=now,
        )

        logger.info(
            "FortinetDeviceInfoParser: %s model=%s serial=%s ver=%s",
            hostname, model, serial, os_version,
        )

        return NetworkFacts(devices=[device])
