"""Fortinet FortiGate parser module.

Imports all parser submodules to trigger @register decorators.
"""

from . import (
    address_objects,  # noqa: F401
    device_info,  # noqa: F401
    security_policies,  # noqa: F401
)
