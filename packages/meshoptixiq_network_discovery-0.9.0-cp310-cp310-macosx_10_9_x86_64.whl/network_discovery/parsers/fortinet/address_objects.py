"""Fortinet FortiGate address object parser.

Parses output from:
  - show firewall address
  - show firewall addrgrp

FortiOS config syntax:
  config firewall address
      edit "HOST-10"
          set type ipmask
          set subnet 10.0.0.1 255.255.255.255
      next
      edit "NET-192"
          set type ipmask
          set subnet 192.168.0.0 255.255.255.0
      next
      edit "RANGE-1"
          set type iprange
          set start-ip 10.0.0.1
          set end-ip 10.0.0.10
      next
      edit "FQDN-1"
          set type fqdn
          set fqdn "example.com"
      next
  end

  config firewall addrgrp
      edit "GROUP-1"
          set member "HOST-10" "NET-192"
      next
  end
"""

from __future__ import annotations

import re
from ipaddress import IPv4Network
from typing import Literal

from network_discovery.normalization.models import AddressObjectModel, NetworkFacts
from network_discovery.parsers.base import BaseParser
from network_discovery.parsers.registry import register

_EDIT = re.compile(r'^\s*edit\s+"?([^"]+)"?\s*$')
_NEXT = re.compile(r"^\s*next\b")
_SET = re.compile(r'^\s*set\s+(\S+)\s+(.*)')


def _parse_values(value_str: str) -> list[str]:
    tokens = re.findall(r'"([^"]+)"|(\S+)', value_str)
    return [a or b for a, b in tokens]


def _netmask_to_cidr(ip: str, mask: str) -> str:
    try:
        net = IPv4Network(f"{ip}/{mask}", strict=False)
        return str(net)
    except ValueError:
        return f"{ip}/{mask}"


@register
class FortinetAddressObjectsParser(BaseParser):
    """Parses 'show firewall address' and 'show firewall addrgrp' output."""

    @property
    def vendor(self) -> str:
        return "fortinet"

    @property
    def fact_type(self) -> str:
        return "address_objects"

    def parse(self, raw_output: str, device_hostname: str) -> NetworkFacts:
        objects: list[AddressObjectModel] = []
        current: dict = {}
        is_addrgrp = False

        def finalize():
            if not current.get("name"):
                return
            obj = self._build_object(current, device_hostname, is_addrgrp)
            if obj is not None:
                objects.append(obj)

        for line in raw_output.splitlines():
            # Detect section type
            if "config firewall addrgrp" in line:
                is_addrgrp = True
                continue
            if "config firewall address" in line and "addrgrp" not in line:
                is_addrgrp = False
                continue

            em = _EDIT.match(line)
            if em:
                finalize()
                current = {"name": em.group(1)}
                continue

            if _NEXT.match(line):
                finalize()
                current = {}
                continue

            if not current.get("name"):
                continue

            sm = _SET.match(line)
            if sm:
                key = sm.group(1).lower()
                current[key] = sm.group(2).strip()

        finalize()
        return NetworkFacts(address_objects=objects)

    def _build_object(
        self, block: dict, device_hostname: str, is_group: bool
    ) -> AddressObjectModel | None:
        name = block["name"]
        obj_type: Literal["host", "network", "range", "fqdn", "group"]
        value: str

        if is_group:
            obj_type = "group"
            raw_members = block.get("member", "")
            members = _parse_values(raw_members)
            value = ",".join(members)
        else:
            addr_type = block.get("type", "ipmask").lower()
            if addr_type in ("ipmask", "interface-subnet"):
                subnet_val = block.get("subnet", "")
                parts = subnet_val.split()
                if len(parts) == 2:
                    value = _netmask_to_cidr(parts[0], parts[1])
                else:
                    value = subnet_val
                # Determine host vs network
                try:
                    net = IPv4Network(value, strict=False)
                    obj_type = "host" if net.prefixlen == 32 else "network"
                except ValueError:
                    obj_type = "network"
            elif addr_type == "iprange":
                start = block.get("start-ip", "")
                end = block.get("end-ip", "")
                obj_type = "range"
                value = f"{start}-{end}"
            elif addr_type == "fqdn":
                obj_type = "fqdn"
                value = block.get("fqdn", "").strip('"')
            else:
                obj_type = "network"
                value = block.get("subnet", block.get("fqdn", "unknown"))

        return AddressObjectModel(
            device_hostname=device_hostname,
            name=name,
            type=obj_type,
            value=value,
            vendor="fortinet",
        )
