"""Palo Alto PAN-OS security policy parser.

Parses output from:
  - show running security-policy

PAN-OS SSH text output format:
  <rule-name> {
    from <zone>;
    to <zone>;
    source <addr>;
    destination <addr>;
    service <svc>;
    application <app>;
    action <allow|deny|drop>;
    log-start yes|no;
    log-end yes|no;
    disabled yes|no;
  }
"""

from __future__ import annotations

import re
from datetime import datetime, timezone

from network_discovery.normalization.models import FirewallRuleModel, NetworkFacts
from network_discovery.parsers.base import BaseParser
from network_discovery.parsers.registry import register

# Matches a rule header: optional leading whitespace, then rule-name {
_RULE_HEADER = re.compile(r"^\s*(\S+)\s*\{")
_RULE_END = re.compile(r"^\s*\}")
_KV_LINE = re.compile(r"^\s*(\S+)\s+(.+?);?\s*$")


@register
class PaloAltoSecurityPoliciesParser(BaseParser):
    """Parses 'show running security-policy' output."""

    @property
    def vendor(self) -> str:
        return "paloalto_panos"

    @property
    def fact_type(self) -> str:
        return "security_policies"

    def parse(self, raw_output: str, device_hostname: str) -> NetworkFacts:
        rules: list[FirewallRuleModel] = []
        now = datetime.now(timezone.utc)

        current_name: str | None = None
        current_block: dict[str, list[str]] = {}
        rule_order = 0
        depth = 0

        for line in raw_output.splitlines():
            # Track nesting depth to handle nested blocks (address/service objects inside rules)
            open_braces = line.count("{")
            close_braces = line.count("}")

            if current_name is None:
                m = _RULE_HEADER.match(line)
                if m:
                    current_name = m.group(1)
                    current_block = {}
                    depth = 1
            else:
                depth += open_braces - close_braces

                if depth <= 0:
                    # End of rule block — finalize
                    rule = self._build_rule(
                        current_name, current_block, rule_order, device_hostname, now
                    )
                    if rule is not None:
                        rules.append(rule)
                        rule_order += 1
                    current_name = None
                    current_block = {}
                    depth = 0
                elif depth == 1:
                    # We're inside the top-level rule block (not nested)
                    m = _KV_LINE.match(line)
                    if m:
                        key = m.group(1).lower().rstrip(";")
                        # Strip trailing semicolon from value too
                        val = m.group(2).rstrip(";").strip()
                        current_block.setdefault(key, []).append(val)

        # Handle unclosed final block
        if current_name and current_block:
            rule = self._build_rule(
                current_name, current_block, rule_order, device_hostname, now
            )
            if rule is not None:
                rules.append(rule)

        return NetworkFacts(firewall_rules=rules)

    def _build_rule(
        self,
        name: str,
        block: dict[str, list[str]],
        order: int,
        device_hostname: str,
        now: datetime,
    ) -> FirewallRuleModel | None:
        raw_action = " ".join(block.get("action", ["allow"])).lower()
        action_map = {"allow": "allow", "deny": "deny", "drop": "drop", "reject": "reject"}
        action = action_map.get(raw_action, "deny")

        # Disabled flag
        disabled_vals = block.get("disabled", [])
        enabled = not any(v.lower() == "yes" for v in disabled_vals)

        # Logging: either log-end or log-start yes
        log_end = block.get("log-end", [])
        log_start = block.get("log-start", [])
        log_enabled = any(v.lower() == "yes" for v in log_end + log_start)

        return FirewallRuleModel(
            device_hostname=device_hostname,
            rule_id=name,
            rule_name=name,
            rule_order=order + 1,
            action=action,
            source_zones=self._flatten(block.get("from", ["any"])),
            destination_zones=self._flatten(block.get("to", ["any"])),
            source_addresses=self._flatten(block.get("source", ["any"])),
            destination_addresses=self._flatten(block.get("destination", ["any"])),
            services=self._flatten(block.get("service", ["any"])),
            protocols=[],
            destination_ports=[],
            enabled=enabled,
            log_enabled=log_enabled,
            vendor="paloalto_panos",
            collected_at=now,
        )

    def _flatten(self, values: list[str]) -> list[str]:
        """Split space-separated tokens within each value string."""
        result = []
        for v in values:
            result.extend(v.split())
        return result
