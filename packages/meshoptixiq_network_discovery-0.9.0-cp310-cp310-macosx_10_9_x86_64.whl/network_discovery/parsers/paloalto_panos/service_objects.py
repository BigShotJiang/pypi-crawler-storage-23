"""Palo Alto PAN-OS service object parser.

Parses output from:
  - show running service

PAN-OS SSH text format:
  <name> {
    protocol {
      tcp {
        port 443;
      }
    }
  }
  <group-name> {
    members [ svc1 svc2 ];
  }
"""

from __future__ import annotations

import re

from network_discovery.normalization.models import NetworkFacts, ServiceObjectModel
from network_discovery.parsers.base import BaseParser
from network_discovery.parsers.registry import register

_OBJ_HEADER = re.compile(r"^\s*(\S+)\s*\{")
_KV_LINE = re.compile(r"^\s*(\S+)\s+(.+?);?\s*$")
_MEMBERS_GROUP = re.compile(r"\[\s*(.*?)\s*\]")


@register
class PaloAltoServiceObjectsParser(BaseParser):
    """Parses 'show running service' output."""

    @property
    def vendor(self) -> str:
        return "paloalto_panos"

    @property
    def fact_type(self) -> str:
        return "service_objects"

    def parse(self, raw_output: str, device_hostname: str) -> NetworkFacts:
        objects: list[ServiceObjectModel] = []

        current_name: str | None = None
        current_lines: list[str] = []
        depth = 0

        for line in raw_output.splitlines():
            open_braces = line.count("{")
            close_braces = line.count("}")

            if current_name is None:
                m = _OBJ_HEADER.match(line)
                if m:
                    current_name = m.group(1)
                    current_lines = [line]
                    depth = 1
            else:
                depth += open_braces - close_braces
                current_lines.append(line)

                if depth <= 0:
                    obj = self._build_service(current_name, current_lines, device_hostname)
                    if obj is not None:
                        objects.append(obj)
                    current_name = None
                    current_lines = []
                    depth = 0

        return NetworkFacts(service_objects=objects)

    def _build_service(
        self, name: str, lines: list[str], device_hostname: str
    ) -> ServiceObjectModel | None:
        full_text = "\n".join(lines)

        # Group object: members [ svc1 svc2 ]
        if "members" in full_text and "[" in full_text:
            m = _MEMBERS_GROUP.search(full_text)
            members = m.group(1) if m else ""
            return ServiceObjectModel(
                device_hostname=device_hostname,
                name=name,
                protocol="group",
                dest_ports=members,
                vendor="paloalto_panos",
            )

        # Protocol-based service object
        protocol = "tcp"
        for proto in ("tcp", "udp", "icmp", "sctp"):
            if proto in full_text.lower():
                protocol = proto
                break

        # Extract port value
        port_match = re.search(r"\bport\s+([^;}\s]+)", full_text)
        dest_ports = port_match.group(1) if port_match else "any"

        return ServiceObjectModel(
            device_hostname=device_hostname,
            name=name,
            protocol=protocol,
            dest_ports=dest_ports,
            vendor="paloalto_panos",
        )
