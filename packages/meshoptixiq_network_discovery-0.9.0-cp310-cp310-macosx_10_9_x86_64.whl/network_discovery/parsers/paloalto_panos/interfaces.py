"""Palo Alto PAN-OS interface parser.

Parses output from:
  - show interface all

Note: Palo Alto uses security zones instead of VLANs, and has unique
output format with key-value pairs separated by dashes.
"""

from __future__ import annotations

from ipaddress import ip_interface

from network_discovery.normalization.models import InterfaceModel, IPAddressModel, NetworkFacts
from network_discovery.parsers.base import BaseParser
from network_discovery.parsers.registry import register


@register
class PaloAltoInterfaceParser(BaseParser):
    """Parses 'show interface all' output."""

    @property
    def vendor(self) -> str:
        return "paloalto_panos"

    @property
    def fact_type(self) -> str:
        return "interfaces"

    def parse(self, raw_output: str, device_hostname: str) -> NetworkFacts:
        """Parse Palo Alto 'show interface all' output.

        Example output (key-value pairs with dashes as separators):
        -----------------------------------------------------------------------
        Name     : ethernet1/1
        Zone     : trust
        Fwd      : vr:default vsys:vsys1
        Vsys     : 1
        Tag      : 0
        IP       : 192.168.1.1/24
        MAC      : 00:1a:2b:3c:4d:5e
        Link     : up
        State    : up
        Speed    : 1000
        Duplex   : full
        -----------------------------------------------------------------------
        """
        interfaces: list[InterfaceModel] = []
        ip_addresses: list[IPAddressModel] = []

        current_interface: dict[str, str] = {}

        for line in raw_output.splitlines():
            line = line.strip()

            # Separator lines indicate end of interface block
            if line.startswith("---"):
                if current_interface.get("name"):
                    # Create interface model
                    zone = current_interface.get("zone", "N/A")
                    mac = current_interface.get("mac")
                    # Skip N/A MAC addresses (loopback interfaces, etc.)
                    if mac and mac.upper() == "N/A":
                        mac = None

                    interfaces.append(
                        InterfaceModel(
                            device_hostname=device_hostname,
                            name=current_interface["name"],
                            admin_status=current_interface.get("state", "").lower(),
                            oper_status=current_interface.get("link", "").lower(),
                            speed=current_interface.get("speed"),
                            mac_address=mac,
                            description=f"Zone: {zone}",  # Store zone in description
                        )
                    )

                    # Extract IP if present
                    ip_str = current_interface.get("ip")
                    if ip_str and ip_str != "N/A" and "/" in ip_str:
                        try:
                            ip_iface = ip_interface(ip_str)
                            ip_addresses.append(
                                IPAddressModel(
                                    address=str(ip_iface.ip),
                                    prefix_length=ip_iface.network.prefixlen,
                                    version=4 if ip_iface.version == 4 else 6,
                                    interface_name=current_interface["name"],
                                    device_hostname=device_hostname,
                                )
                            )
                        except ValueError:
                            pass

                # Reset for next interface
                current_interface = {}
                continue

            # Skip empty lines
            if not line:
                continue

            # Parse key-value pairs (format: "Key : value")
            if ":" in line:
                key, value = line.split(":", 1)
                key = key.strip().lower()
                value = value.strip()

                # Store in current interface dict
                current_interface[key] = value

        # Handle last interface (if no trailing separator)
        if current_interface.get("name"):
            zone = current_interface.get("zone", "N/A")
            mac = current_interface.get("mac")
            # Skip N/A MAC addresses (loopback interfaces, etc.)
            if mac and mac.upper() == "N/A":
                mac = None

            interfaces.append(
                InterfaceModel(
                    device_hostname=device_hostname,
                    name=current_interface["name"],
                    admin_status=current_interface.get("state", "").lower(),
                    oper_status=current_interface.get("link", "").lower(),
                    speed=current_interface.get("speed"),
                    mac_address=mac,
                    description=f"Zone: {zone}",
                )
            )

            ip_str = current_interface.get("ip")
            if ip_str and ip_str != "N/A" and "/" in ip_str:
                try:
                    ip_iface = ip_interface(ip_str)
                    ip_addresses.append(
                        IPAddressModel(
                            address=str(ip_iface.ip),
                            prefix_length=ip_iface.network.prefixlen,
                            version=4 if ip_iface.version == 4 else 6,
                            interface_name=current_interface["name"],
                            device_hostname=device_hostname,
                        )
                    )
                except ValueError:
                    pass

        return NetworkFacts(interfaces=interfaces, ip_addresses=ip_addresses)
