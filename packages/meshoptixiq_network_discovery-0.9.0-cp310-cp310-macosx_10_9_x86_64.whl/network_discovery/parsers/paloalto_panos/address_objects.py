"""Palo Alto PAN-OS address object parser.

Parses output from:
  - show running address

PAN-OS SSH text format for address objects:
  <name> {
    ip-netmask 10.0.0.0/24;
    description "some desc";
  }
  <name> {
    fqdn example.com;
  }
  <name> {
    ip-range 10.0.0.1-10.0.0.10;
  }
  <group-name> {
    static [ addr1 addr2 ];
  }
"""

from __future__ import annotations

import re
from typing import Literal

from network_discovery.normalization.models import AddressObjectModel, NetworkFacts
from network_discovery.parsers.base import BaseParser
from network_discovery.parsers.registry import register

_OBJ_HEADER = re.compile(r"^\s*(\S+)\s*\{")
_KV_LINE = re.compile(r"^\s*(\S+)\s+(.+?);?\s*$")
# Static group members: static [ addr1 addr2 ... ];
_STATIC_GROUP = re.compile(r"\[\s*(.*?)\s*\]")


@register
class PaloAltoAddressObjectsParser(BaseParser):
    """Parses 'show running address' output."""

    @property
    def vendor(self) -> str:
        return "paloalto_panos"

    @property
    def fact_type(self) -> str:
        return "address_objects"

    def parse(self, raw_output: str, device_hostname: str) -> NetworkFacts:
        objects: list[AddressObjectModel] = []

        current_name: str | None = None
        current_block: dict[str, str] = {}
        depth = 0

        for line in raw_output.splitlines():
            open_braces = line.count("{")
            close_braces = line.count("}")

            if current_name is None:
                m = _OBJ_HEADER.match(line)
                if m:
                    current_name = m.group(1)
                    current_block = {}
                    depth = 1
            else:
                depth += open_braces - close_braces

                if depth <= 0:
                    obj = self._build_object(current_name, current_block, device_hostname)
                    if obj is not None:
                        objects.append(obj)
                    current_name = None
                    current_block = {}
                    depth = 0
                elif depth == 1:
                    # Capture the full line for static group parsing
                    if "static" in line and "[" in line:
                        current_block["static"] = line
                    else:
                        m = _KV_LINE.match(line)
                        if m:
                            key = m.group(1).lower().rstrip(";")
                            val = m.group(2).rstrip(";").strip()
                            current_block[key] = val

        if current_name and current_block:
            obj = self._build_object(current_name, current_block, device_hostname)
            if obj is not None:
                objects.append(obj)

        return NetworkFacts(address_objects=objects)

    def _build_object(
        self, name: str, block: dict[str, str], device_hostname: str
    ) -> AddressObjectModel | None:
        obj_type: Literal["host", "network", "range", "fqdn", "group"]
        value: str

        if "ip-netmask" in block:
            raw = block["ip-netmask"]
            if "/" in raw:
                prefix = int(raw.split("/")[1])
                obj_type = "host" if prefix == 32 else "network"
            else:
                obj_type = "host"
            value = raw
        elif "ip-range" in block:
            obj_type = "range"
            value = block["ip-range"]
        elif "fqdn" in block:
            obj_type = "fqdn"
            value = block["fqdn"]
        elif "static" in block:
            obj_type = "group"
            m = _STATIC_GROUP.search(block["static"])
            value = m.group(1) if m else ""
        else:
            return None

        return AddressObjectModel(
            device_hostname=device_hostname,
            name=name,
            type=obj_type,
            value=value,
            vendor="paloalto_panos",
        )
