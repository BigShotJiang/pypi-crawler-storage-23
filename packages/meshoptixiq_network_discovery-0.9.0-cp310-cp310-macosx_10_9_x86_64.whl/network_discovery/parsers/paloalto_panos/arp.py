"""Palo Alto PAN-OS ARP parser.

Parses output from:
  - show arp all
"""

from __future__ import annotations

from datetime import datetime, timezone

from network_discovery.normalization.models import EndpointModel, MACModel, NetworkFacts
from network_discovery.parsers.base import BaseParser
from network_discovery.parsers.registry import register


@register
class PaloAltoARPParser(BaseParser):
    """Parses 'show arp all' output."""

    @property
    def vendor(self) -> str:
        return "paloalto_panos"

    @property
    def fact_type(self) -> str:
        return "arp_table"

    def parse(self, raw_output: str, device_hostname: str) -> NetworkFacts:
        """Parse Palo Alto 'show arp all' output.

        Example output:
        interface  ip address      hw address         port status ttl
        --------------------------------------------------------------------------
        ethernet1/1 192.168.1.100   aa:bb:cc:dd:ee:ff  n/a  c      1796
        ethernet1/1 192.168.1.101   11:22:33:44:55:66  n/a  c      1723
        ethernet1/2 10.0.0.2        ab:cd:ef:12:34:56  n/a  c      892
        """
        endpoints: list[EndpointModel] = []
        macs: list[MACModel] = []

        now = datetime.now(timezone.utc)

        for line in raw_output.splitlines():
            line = line.strip()

            # Skip headers, separators, and empty lines
            if not line or line.startswith("interface") or line.startswith("---"):
                continue

            parts = line.split()
            if len(parts) < 3:
                continue

            interface_name = parts[0]
            ip_address = parts[1]
            mac_address = parts[2]

            # Skip incomplete entries
            if mac_address.lower() in ("incomplete", "-", "n/a"):
                continue

            # Normalize MAC address format (Palo Alto uses colon format already)
            mac_formatted = mac_address.upper()

            # Add MAC entry
            macs.append(
                MACModel(
                    address=mac_formatted,
                    interface_name=interface_name,
                    device_hostname=device_hostname,
                )
            )

            # Add endpoint (IP-MAC binding)
            endpoints.append(
                EndpointModel(
                    mac_address=mac_formatted,
                    ip_address=ip_address,
                    last_seen=now,
                )
            )

        return NetworkFacts(macs=macs, endpoints=endpoints)
