"""Palo Alto PAN-OS device info parser.

Parses output from:
  - show system info
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone

from network_discovery.normalization.models import DeviceModel, NetworkFacts
from network_discovery.parsers.base import BaseParser
from network_discovery.parsers.registry import register

logger = logging.getLogger(__name__)


@register
class PaloAltoDeviceInfoParser(BaseParser):
    """Parses 'show system info' output for device metadata."""

    @property
    def vendor(self) -> str:
        return "paloalto_panos"

    @property
    def fact_type(self) -> str:
        return "device_info"

    def parse(self, raw_output: str, device_hostname: str) -> NetworkFacts:
        """Extract key fields from 'show system info'.

        Example output (key: value pairs):
        hostname: PA-5220-Lab
        ip-address: 192.168.1.254
        public-ip-address: unknown
        netmask: 255.255.255.0
        default-gateway: 192.168.1.1
        is-dhcp: no
        ipv6-address: unknown
        ipv6-link-local-address: fe80::1a:2bff:fe3c:4d5e/64
        ipv6-default-gateway:
        mac-address: 00:1a:2b:3c:4d:5e
        time: Mon Jan 15 14:23:45 2024
        uptime: 42 days, 13:25:17
        devicename: PA-5220-Lab
        family: 5200
        model: PA-5220
        serial: 012345678901
        vm-mac-base:
        vm-mac-count:
        vm-uuid:
        vm-cpuid:
        vm-license:
        vm-mode:
        cloud-mode: non-cloud
        sw-version: 10.1.6
        global-protect-client-package-version: 0.0.0
        device-dictionary-version: 90-389
        ...
        """
        now = datetime.now(timezone.utc)

        device_data = {}

        # Parse key-value pairs
        for line in raw_output.splitlines():
            line = line.strip()
            if ":" in line:
                key, value = line.split(":", 1)
                key = key.strip()
                value = value.strip()
                device_data[key] = value

        # Extract relevant fields
        hostname = device_data.get("hostname") or device_data.get("devicename") or device_hostname
        model = device_data.get("model")
        serial = device_data.get("serial")
        os_version = device_data.get("sw-version")

        devices = [
            DeviceModel(
                hostname=hostname,
                vendor="paloalto",
                model=model,
                serial=serial,
                os_version=os_version,
                collected_at=now,
            )
        ]

        logger.info(
            "PaloAltoDeviceInfoParser extracted: hostname=%s, model=%s, version=%s",
            hostname,
            model,
            os_version,
        )

        return NetworkFacts(devices=devices)
