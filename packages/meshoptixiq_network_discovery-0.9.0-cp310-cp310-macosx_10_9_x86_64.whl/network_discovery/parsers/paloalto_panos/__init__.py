"""Palo Alto PAN-OS parser module.

Imports all parser submodules to trigger @register decorators.
"""

# Import all parser modules to trigger registration
from . import (
    address_objects,  # noqa: F401
    arp,  # noqa: F401
    interfaces,  # noqa: F401
    security_policies,  # noqa: F401
    service_objects,  # noqa: F401
    stubs,  # noqa: F401
)
