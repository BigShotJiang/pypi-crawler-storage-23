"""Check Point Gaia OS parsers."""

from network_discovery.parsers.checkpoint_gaia import security_policies  # noqa: F401
