"""Check Point Gaia OS security policy parser.

Parses output from:
  - show rule-base

IMPORTANT — REST API is the recommended collection method:
  Check Point Gaia's SSH CLI (Clish) has limited policy export capability.
  For production deployments, use the Management API on the Check Point
  Management Server (SmartAPI / mgmt_cli):

    mgmt_cli show access-rulebase name "Network" offset 0 limit 500 \\
        --format json --port 443 -r true

  This SSH parser handles the ``show rule-base`` Clish command output,
  which is available as a best-effort fallback when the Management API
  is not accessible. The output format varies across Gaia versions (R80+):

    Policy: Network_Policy
      1  accept   ANY             ANY             ssh             Track: Log
      2  accept   10.0.0.0/8      DMZ_SERVERS     http,https      Track: Log
      3  drop     ANY             ANY             ANY             Track: -

  Each rule line contains:
    <order>  <action>  <source>  <destination>  <service>  [Track: <log>]

Limitations of SSH-based collection:
  - No negated sources/destinations
  - No time-based rules
  - No application/URL filtering rules
  - No rule names or UIDs
  - Object names (not resolved CIDRs) in source/destination columns
  - Policy package name is captured but zone information is not available
"""

from __future__ import annotations

import re
from datetime import datetime, timezone

from network_discovery.normalization.models import FirewallRuleModel, NetworkFacts
from network_discovery.parsers.base import BaseParser
from network_discovery.parsers.registry import register

# Policy header: "Policy: <name>"
_POLICY_HEADER = re.compile(r"^\s*Policy:\s+(\S+)", re.IGNORECASE)

# Rule line: <number>  <action>  <source>  <destination>  <service>  [Track: <level>]
# Columns are separated by two or more spaces (tab-aligned output)
_RULE_LINE = re.compile(
    r"^\s*(\d+)\s+"            # rule order number
    r"(accept|drop|reject)\s+" # action
    r"(\S+)\s+"                # source (object name or CIDR or ANY)
    r"(\S+)\s+"                # destination (object name or CIDR or ANY)
    r"(\S+)"                   # service (comma-separated object names or ANY)
    r"(?:\s+Track:\s*(\S+))?", # optional logging track level
    re.IGNORECASE,
)

_ACTION_MAP = {
    "accept": "allow",
    "drop": "drop",
    "reject": "reject",
}


@register
class CheckPointGaiaSecurityPoliciesParser(BaseParser):
    """Parses 'show rule-base' output from Check Point Gaia (best-effort SSH).

    For production environments, the Management Server REST API is strongly
    recommended over SSH-based collection. See module docstring.
    """

    @property
    def vendor(self) -> str:
        return "checkpoint_gaia"

    @property
    def fact_type(self) -> str:
        return "security_policies"

    def parse(self, raw_output: str, device_hostname: str) -> NetworkFacts:
        rules: list[FirewallRuleModel] = []
        now = datetime.now(timezone.utc)

        policy_name: str = "unknown"

        for line in raw_output.splitlines():
            # Detect policy package name
            ph = _POLICY_HEADER.match(line)
            if ph:
                policy_name = ph.group(1)
                continue

            # Match a rule line
            rm = _RULE_LINE.match(line)
            if not rm:
                continue

            order = int(rm.group(1))
            raw_action = rm.group(2).lower()
            source = rm.group(3)
            destination = rm.group(4)
            service = rm.group(5)
            track = (rm.group(6) or "-").lower()

            action = _ACTION_MAP.get(raw_action, "deny")

            # Normalise "any" casing
            src_addrs = ["any"] if source.lower() == "any" else [source]
            dst_addrs = ["any"] if destination.lower() == "any" else [destination]

            # Services may be comma-separated object names
            services = [s.strip() for s in service.split(",") if s.strip()]

            log_enabled = track not in ("-", "none", "")

            rules.append(FirewallRuleModel(
                device_hostname=device_hostname,
                rule_id=f"{policy_name}:{order}",
                rule_name=f"rule-{order}",
                rule_order=order,
                action=action,
                source_zones=[],
                destination_zones=[],
                source_addresses=src_addrs,
                destination_addresses=dst_addrs,
                services=services,
                protocols=[],
                destination_ports=[],
                enabled=True,
                log_enabled=log_enabled,
                comments=f"Policy: {policy_name}",
                vendor="checkpoint_gaia",
                collected_at=now,
            ))

        return NetworkFacts(firewall_rules=rules)
