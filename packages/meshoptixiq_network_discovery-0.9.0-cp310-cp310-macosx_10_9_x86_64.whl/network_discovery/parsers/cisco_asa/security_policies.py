"""Cisco ASA security policy (ACL) parser.

Parses output from:
  - show access-list

Each access-list entry (ACE) is one line:
  access-list OUTSIDE_IN extended permit tcp any host 10.1.1.1 eq 443
  access-list OUTSIDE_IN extended deny ip any any
  access-list OUTSIDE_IN extended permit udp 192.168.0.0 255.255.255.0 any eq 53
  access-list OUTSIDE_IN line 3 extended permit object-group SVC_WEB any host 10.0.0.1

Remark lines:
  access-list OUTSIDE_IN remark Allow web traffic

Hit count lines (filtered out):
  access-list OUTSIDE_IN line 3 extended permit ... (hitcnt=10) 0xaabbccdd
"""

from __future__ import annotations

import re
from datetime import datetime, timezone

from network_discovery.normalization.models import FirewallRuleModel, NetworkFacts
from network_discovery.parsers.base import BaseParser
from network_discovery.parsers.registry import register

# Match the core ACE structure
_ACE_LINE = re.compile(
    r"access-list\s+(\S+)"          # ACL name
    r"(?:\s+line\s+\d+)?"           # optional line number
    r"\s+extended"
    r"\s+(permit|deny)"             # action
    r"\s+(.*?)(?:\s+\(hitcnt=\d+\).*)?$",  # rest of rule (strip hitcnt)
    re.IGNORECASE,
)
_REMARK = re.compile(r"access-list\s+\S+\s+remark\s+", re.IGNORECASE)
_PROTO_RE = re.compile(
    r"^(tcp|udp|icmp|ip|object-group\s+\S+|object\s+\S+)\s+", re.IGNORECASE
)
_PORT_EQ = re.compile(r"\beq\s+(\S+)", re.IGNORECASE)
_PORT_RANGE = re.compile(r"\brange\s+(\S+)\s+(\S+)", re.IGNORECASE)

_ACTION_MAP = {"permit": "allow", "deny": "deny"}


def _extract_protocol(rest: str) -> tuple[str, str]:
    """Extract protocol from ACE body, return (protocol, remainder)."""
    m = _PROTO_RE.match(rest)
    if m:
        proto = m.group(1).lower()
        # Normalize object-group references
        if proto.startswith("object"):
            proto = proto.split()[-1]  # keep group name for reference
        return proto, rest[m.end():]
    return "ip", rest


def _extract_port(token_str: str) -> str | None:
    eq_m = _PORT_EQ.search(token_str)
    if eq_m:
        return eq_m.group(1)
    rng_m = _PORT_RANGE.search(token_str)
    if rng_m:
        return f"{rng_m.group(1)}-{rng_m.group(2)}"
    return None


@register
class CiscoAsaSecurityPoliciesParser(BaseParser):
    """Parses 'show access-list' output."""

    @property
    def vendor(self) -> str:
        return "cisco_asa"

    @property
    def fact_type(self) -> str:
        return "security_policies"

    def parse(self, raw_output: str, device_hostname: str) -> NetworkFacts:
        rules: list[FirewallRuleModel] = []
        now = datetime.now(timezone.utc)

        # Track per-ACL order counters
        acl_order: dict[str, int] = {}

        for line in raw_output.splitlines():
            line = line.strip()
            if not line or _REMARK.match(line):
                continue

            m = _ACE_LINE.match(line)
            if not m:
                continue

            acl_name = m.group(1)
            raw_action = m.group(2).lower()
            rest = (m.group(3) or "").strip()
            # Strip trailing hitcnt if regex didn't catch it
            rest = re.sub(r"\s*\(hitcnt=\d+\).*$", "", rest).strip()

            acl_order[acl_name] = acl_order.get(acl_name, 0) + 1
            order = acl_order[acl_name]

            action = _ACTION_MAP.get(raw_action, "deny")
            protocol, body = _extract_protocol(rest)

            # Extract destination port from the full body
            dst_port = _extract_port(body)
            dst_ports = [dst_port] if dst_port else []

            # Source and destination are the remaining address tokens
            # (we store the raw token string; object names are kept as-is)
            addr_tokens = re.sub(r"\beq\s+\S+|\brange\s+\S+\s+\S+|\blt\s+\S+|\bgt\s+\S+", "", body).split()
            # First half of tokens = source, second half = destination (rough heuristic)
            mid = len(addr_tokens) // 2
            src_addrs = [" ".join(addr_tokens[:mid])] if addr_tokens[:mid] else ["any"]
            dst_addrs = [" ".join(addr_tokens[mid:])] if addr_tokens[mid:] else ["any"]

            rules.append(FirewallRuleModel(
                device_hostname=device_hostname,
                rule_id=f"{acl_name}:{order}",
                rule_name=acl_name,
                rule_order=order,
                action=action,
                source_zones=[],
                destination_zones=[],
                source_addresses=[a.strip() for a in src_addrs if a.strip()],
                destination_addresses=[a.strip() for a in dst_addrs if a.strip()],
                services=[],
                protocols=[protocol] if protocol not in ("ip", "") else [],
                destination_ports=dst_ports,
                enabled=True,
                log_enabled=False,
                vendor="cisco_asa",
                collected_at=now,
            ))

        return NetworkFacts(firewall_rules=rules)
