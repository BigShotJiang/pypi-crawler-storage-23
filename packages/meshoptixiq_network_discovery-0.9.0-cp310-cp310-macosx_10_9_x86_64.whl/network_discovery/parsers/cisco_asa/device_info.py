"""Cisco ASA device_info parser.

Parses output from 'show version' to extract device metadata.
"""

from __future__ import annotations

import logging
import re
from datetime import datetime, timezone

from network_discovery.normalization.models import DeviceModel, NetworkFacts
from network_discovery.parsers.base import BaseParser
from network_discovery.parsers.registry import register

logger = logging.getLogger(__name__)


@register
class CiscoASADeviceInfoParser(BaseParser):
    """Parses 'show version' output for Cisco ASA device metadata."""

    @property
    def vendor(self) -> str:
        return "cisco_asa"

    @property
    def fact_type(self) -> str:
        return "device_info"

    def parse(self, raw_output: str, device_hostname: str) -> NetworkFacts:
        now = datetime.now(timezone.utc)

        # OS version — e.g. "Cisco Adaptive Security Appliance Software Version 9.18(2)"
        os_version = None
        ver_m = re.search(
            r"Cisco Adaptive Security Appliance.*?Version\s+(\S+)",
            raw_output,
        )
        if ver_m:
            os_version = ver_m.group(1).rstrip(",")

        # Model — e.g. "Hardware:   ASA5525, 8192 MB RAM" or "ASA5525-X,"
        model = None
        hw_m = re.search(r"Hardware:\s+(\S+)", raw_output, re.IGNORECASE)
        if hw_m:
            model = hw_m.group(1).rstrip(",")
        else:
            model_m = re.search(r"\bASA\s+([\w\-]+),", raw_output)
            if model_m:
                model = "ASA" + model_m.group(1)

        # Serial — e.g. "Serial Number: JAD12345A6B"
        serial = None
        serial_m = re.search(r"Serial Number:\s+(\S+)", raw_output, re.IGNORECASE)
        if serial_m:
            serial = serial_m.group(1)

        # Hostname from uptime banner — e.g. "asa-fw-01 up 3 days 12 hours"
        hostname = device_hostname
        host_m = re.search(r"^\s*(\S+)\s+up\s+", raw_output, re.MULTILINE)
        if host_m:
            hostname = host_m.group(1)

        device = DeviceModel(
            hostname=hostname,
            vendor="cisco_asa",
            model=model,
            serial=serial,
            os_version=os_version,
            collected_at=now,
        )

        logger.info(
            "CiscoASADeviceInfoParser: %s model=%s serial=%s ver=%s",
            hostname, model, serial, os_version,
        )

        return NetworkFacts(devices=[device])
