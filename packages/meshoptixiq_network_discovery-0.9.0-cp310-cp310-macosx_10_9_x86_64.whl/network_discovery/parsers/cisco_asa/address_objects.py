"""Cisco ASA address/service object-group parser.

Parses output from:
  - show running-config object-group

Example output:
  object-group network WEB_SERVERS
   network-object host 10.1.1.1
   network-object 192.168.0.0 255.255.255.0
   network-object 10.0.0.0 255.0.0.0

  object-group service SVC_WEB tcp
   port-object eq 80
   port-object eq 443
   port-object range 8080 8090

  object-group network GROUP_NESTED
   group-object WEB_SERVERS
"""

from __future__ import annotations

import re
from ipaddress import IPv4Network
from typing import Literal

from network_discovery.normalization.models import AddressObjectModel, NetworkFacts
from network_discovery.parsers.base import BaseParser
from network_discovery.parsers.registry import register

_OBJ_GROUP_HEADER = re.compile(
    r"^object-group\s+(network|service|icmp-type|protocol)\s+(\S+)(?:\s+(\S+))?",
    re.IGNORECASE,
)
_NET_OBJ = re.compile(r"^\s+network-object\s+(.+)", re.IGNORECASE)
_PORT_OBJ = re.compile(r"^\s+port-object\s+(.+)", re.IGNORECASE)
_GROUP_OBJ = re.compile(r"^\s+group-object\s+(\S+)", re.IGNORECASE)
_HOST = re.compile(r"^host\s+(\S+)", re.IGNORECASE)
_RANGE = re.compile(r"^range\s+(\S+)\s+(\S+)", re.IGNORECASE)


def _netmask_to_cidr(ip: str, mask: str) -> str:
    try:
        net = IPv4Network(f"{ip}/{mask}", strict=False)
        return str(net)
    except ValueError:
        return f"{ip}/{mask}"


@register
class CiscoAsaAddressObjectsParser(BaseParser):
    """Parses 'show running-config object-group' output."""

    @property
    def vendor(self) -> str:
        return "cisco_asa"

    @property
    def fact_type(self) -> str:
        return "address_objects"

    def parse(self, raw_output: str, device_hostname: str) -> NetworkFacts:
        objects: list[AddressObjectModel] = []
        current: dict = {}

        def finalize():
            if not current.get("name"):
                return
            obj = self._build_object(current, device_hostname)
            if obj is not None:
                objects.append(obj)

        for line in raw_output.splitlines():
            hm = _OBJ_GROUP_HEADER.match(line)
            if hm:
                finalize()
                current = {
                    "group_type": hm.group(1).lower(),
                    "name": hm.group(2),
                    "protocol": hm.group(3),  # optional: tcp, udp, etc.
                    "members": [],
                }
                continue

            if not current.get("name"):
                continue

            nm = _NET_OBJ.match(line)
            if nm:
                current["members"].append(("net", nm.group(1).strip()))
                continue

            pm = _PORT_OBJ.match(line)
            if pm:
                current["members"].append(("port", pm.group(1).strip()))
                continue

            gm = _GROUP_OBJ.match(line)
            if gm:
                current["members"].append(("group", gm.group(1)))
                continue

        finalize()
        return NetworkFacts(address_objects=objects)

    def _build_object(self, block: dict, device_hostname: str) -> AddressObjectModel | None:
        name = block["name"]
        group_type = block.get("group_type", "network")
        members = block.get("members", [])

        if group_type == "network":
            if not members:
                return None
            if len(members) == 1 and members[0][0] in ("net", "group"):
                kind, val = members[0]
                if kind == "group":
                    obj_type: Literal["host", "network", "range", "fqdn", "group"] = "group"
                    value = val
                else:
                    obj_type, value = self._classify_net(val)
            else:
                # Multiple members → group
                obj_type = "group"
                value = ",".join(self._format_member(k, v) for k, v in members)
        elif group_type == "service":
            obj_type = "group"
            value = ",".join(self._format_member(k, v) for k, v in members)
        else:
            return None

        return AddressObjectModel(
            device_hostname=device_hostname,
            name=name,
            type=obj_type,
            value=value,
            vendor="cisco_asa",
        )

    def _classify_net(self, val: str) -> tuple[Literal["host", "network", "range", "fqdn", "group"], str]:
        hm = _HOST.match(val)
        if hm:
            return "host", hm.group(1)

        rm = _RANGE.match(val)
        if rm:
            return "range", f"{rm.group(1)}-{rm.group(2)}"

        parts = val.split()
        if len(parts) == 2:
            cidr = _netmask_to_cidr(parts[0], parts[1])
            try:
                net = IPv4Network(cidr, strict=False)
                obj_type = "host" if net.prefixlen == 32 else "network"
            except ValueError:
                obj_type = "network"
            return obj_type, cidr

        return "network", val

    def _format_member(self, kind: str, val: str) -> str:
        if kind == "net":
            hm = _HOST.match(val)
            if hm:
                return hm.group(1)
            rm = _RANGE.match(val)
            if rm:
                return f"{rm.group(1)}-{rm.group(2)}"
            parts = val.split()
            if len(parts) == 2:
                return _netmask_to_cidr(parts[0], parts[1])
        return val
