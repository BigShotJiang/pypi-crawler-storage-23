"""Abstract base class for vendor-specific CLI output parsers.

All vendor parsers must inherit from BaseParser and implement the
parse() method, returning canonical NetworkFacts.
"""

from __future__ import annotations

from abc import ABC, abstractmethod

from network_discovery.normalization.models import NetworkFacts


class BaseParser(ABC):
    """Base class for all vendor CLI output parsers."""

    @property
    @abstractmethod
    def vendor(self) -> str:
        """Vendor identifier (e.g., 'cisco_ios')."""
        ...

    @property
    @abstractmethod
    def fact_type(self) -> str:
        """Fact type this parser handles (e.g., 'interfaces', 'arp_table')."""
        ...

    @abstractmethod
    def parse(self, raw_output: str, device_hostname: str) -> NetworkFacts:
        """Parse raw CLI output into canonical NetworkFacts.

        Args:
            raw_output: Raw text output from CLI command.
            device_hostname: Hostname of the device this output came from.

        Returns:
            NetworkFacts containing parsed entities.
        """
        ...
