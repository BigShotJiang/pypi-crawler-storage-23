"""Arista EOS ARP and LLDP parsers."""

from __future__ import annotations

from network_discovery.normalization.models import (
    EndpointModel,
    MACModel,
    NetworkFacts,
)
from network_discovery.parsers.base import BaseParser
from network_discovery.parsers.registry import register


@register
class AristaARPParser(BaseParser):
    """Parses 'show ip arp' output."""

    @property
    def vendor(self) -> str:
        return "arista_eos"

    @property
    def fact_type(self) -> str:
        return "arp_table"

    def parse(self, raw_output: str, device_hostname: str) -> NetworkFacts:
        endpoints: list[EndpointModel] = []
        macs: list[MACModel] = []

        # Example:
        # Address         Age       Hardware Addr   Interface
        # 10.0.0.2        0:00:00   0011.2233.4455  Ethernet1

        for line in raw_output.splitlines():
            if "Address" in line and "Hardware" in line:
                continue

            parts = line.split()
            if len(parts) >= 4:
                ip_addr = parts[0]
                mac_addr = parts[2]
                iface = parts[3]

                if "Incomplete" in mac_addr:
                    continue

                endpoints.append(
                    EndpointModel(
                        mac_address=mac_addr,
                        ip_address=ip_addr,
                        device_hostname=device_hostname,
                        interface_name=iface
                    )
                )
                macs.append(
                    MACModel(
                        address=mac_addr,
                        device_hostname=device_hostname,
                        interface_name=iface
                    )
                )

        return NetworkFacts(endpoints=endpoints, macs=macs)


@register
class AristaLLDPParser(BaseParser):
    """Parses 'show lldp neighbors detail' output."""

    @property
    def vendor(self) -> str:
        return "arista_eos"

    @property
    def fact_type(self) -> str:
        return "neighbors"

    def parse(self, raw_output: str, device_hostname: str) -> NetworkFacts:
        # Implementing basic LLDP parsing stub
        return NetworkFacts()
