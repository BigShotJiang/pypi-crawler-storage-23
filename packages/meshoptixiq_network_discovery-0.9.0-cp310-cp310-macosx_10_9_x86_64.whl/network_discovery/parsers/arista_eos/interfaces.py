"""Arista EOS interface parsers."""

from __future__ import annotations

from ipaddress import ip_interface

from network_discovery.normalization.models import InterfaceModel, IPAddressModel, NetworkFacts
from network_discovery.parsers.base import BaseParser
from network_discovery.parsers.registry import register


@register
class AristaInterfaceBriefParser(BaseParser):
    """Parses 'show ip interface brief' output."""

    @property
    def vendor(self) -> str:
        return "arista_eos"

    @property
    def fact_type(self) -> str:
        return "interfaces"

    def parse(self, raw_output: str, device_hostname: str) -> NetworkFacts:
        interfaces: list[InterfaceModel] = []
        ip_addresses: list[IPAddressModel] = []

        # Example:
        # Interface              IP Address      Status      Protocol
        # Ethernet1              10.0.0.1/24     up          up
        # Management1            192.168.0.2/24  up          up

        for line in raw_output.splitlines():
            line = line.strip()
            if not line or line.startswith("Interface"):
                continue

            parts = line.split()
            if len(parts) < 4:
                continue

            iface_name = parts[0]
            ip_str = parts[1]
            status = parts[2].lower()
            proto = parts[3].lower()

            interfaces.append(
                InterfaceModel(
                    device_hostname=device_hostname,
                    name=iface_name,
                    admin_status=status,  # Status usually maps to Admin/Physical
                    oper_status=proto     # Protocol usually maps to Oper/Link
                )
            )

            if ip_str and ip_str != "unassigned":
                try:
                    ip_iface = ip_interface(ip_str)
                    ip_addresses.append(
                        IPAddressModel(
                            address=str(ip_iface.ip),
                            prefix_length=ip_iface.network.prefixlen,
                            version=4,
                            interface_name=iface_name,
                            device_hostname=device_hostname,
                        )
                    )
                except ValueError:
                    pass

        return NetworkFacts(interfaces=interfaces, ip_addresses=ip_addresses)
