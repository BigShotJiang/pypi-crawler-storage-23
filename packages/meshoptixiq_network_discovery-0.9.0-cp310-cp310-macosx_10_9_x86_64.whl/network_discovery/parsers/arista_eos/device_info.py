"""Arista EOS device_info parser.

Parses output from 'show version' to extract device metadata.
"""

from __future__ import annotations

import logging
import re
from datetime import datetime, timezone

from network_discovery.normalization.models import DeviceModel, NetworkFacts
from network_discovery.parsers.base import BaseParser
from network_discovery.parsers.registry import register

logger = logging.getLogger(__name__)


@register
class AristaDeviceInfoParser(BaseParser):
    """Parses 'show version' output for Arista EOS device metadata."""

    @property
    def vendor(self) -> str:
        return "arista_eos"

    @property
    def fact_type(self) -> str:
        return "device_info"

    def parse(self, raw_output: str, device_hostname: str) -> NetworkFacts:
        now = datetime.now(timezone.utc)

        # OS version — e.g. "EOS version: 4.29.2F" or "Software image version: 4.29.2F"
        os_version = None
        ver_m = re.search(r"EOS version:\s+(\S+)", raw_output, re.IGNORECASE)
        if ver_m:
            os_version = ver_m.group(1)
        else:
            ver_m2 = re.search(r"Software image version:\s+(\S+)", raw_output, re.IGNORECASE)
            if ver_m2:
                os_version = ver_m2.group(1)

        # Model — e.g. "System type: DCS-7050TX-64" or first "Arista DCS-XXXX" match
        model = None
        model_m = re.search(r"System type:\s+(.+)", raw_output, re.IGNORECASE)
        if model_m:
            model = model_m.group(1).strip()
        else:
            model_m2 = re.search(r"Arista\s+([\w\-]+)", raw_output)
            if model_m2:
                model = model_m2.group(1)

        # Serial — e.g. "Serial Number: JPE12345678" or "Serial number: ..."
        serial = None
        serial_m = re.search(r"Serial [Nn]umber:\s+(\S+)", raw_output)
        if serial_m:
            serial = serial_m.group(1)

        # Hostname — e.g. "Hostname: spine-01"
        hostname = device_hostname
        host_m = re.search(r"Hostname:\s+(\S+)", raw_output, re.IGNORECASE)
        if host_m:
            hostname = host_m.group(1)

        device = DeviceModel(
            hostname=hostname,
            vendor="arista_eos",
            model=model,
            serial=serial,
            os_version=os_version,
            collected_at=now,
        )

        logger.info(
            "AristaDeviceInfoParser: %s model=%s serial=%s ver=%s",
            hostname, model, serial, os_version,
        )

        return NetworkFacts(devices=[device])
