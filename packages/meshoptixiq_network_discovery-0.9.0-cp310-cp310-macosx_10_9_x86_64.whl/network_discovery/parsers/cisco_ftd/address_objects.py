"""Cisco FTD address object parser.

Parses output from:
  - show running-config object-group

FTD/LINA exposes object-groups in ASA-compatible format:

  object-group network CORP_NETWORKS
   network-object 10.0.0.0 255.0.0.0
   network-object host 192.168.1.1
   group-object OTHER_GROUP

  object-group service WEB_SERVICES tcp
   port-object eq 80
   port-object eq 443
   port-object range 8080 8090
"""

from __future__ import annotations

import re
from datetime import datetime, timezone

from network_discovery.normalization.models import AddressObjectModel, NetworkFacts
from network_discovery.parsers.base import BaseParser
from network_discovery.parsers.registry import register

_GROUP_HEADER = re.compile(r"^object-group\s+(network|service|protocol|icmp-type)\s+(\S+)", re.IGNORECASE)
_NETWORK_OBJ = re.compile(r"^\s+network-object\s+(host\s+\S+|\S+\s+\S+)", re.IGNORECASE)
_GROUP_OBJ = re.compile(r"^\s+group-object\s+(\S+)", re.IGNORECASE)


@register
class CiscoFTDAddressObjectsParser(BaseParser):
    """Parses 'show running-config object-group' from Cisco FTD."""

    @property
    def vendor(self) -> str:
        return "cisco_ftd"

    @property
    def fact_type(self) -> str:
        return "address_objects"

    def parse(self, raw_output: str, device_hostname: str) -> NetworkFacts:
        objects: list[AddressObjectModel] = []
        datetime.now(timezone.utc)

        current_name: str | None = None
        current_type: str | None = None
        members: list[str] = []

        def _flush() -> None:
            if current_name and current_type == "network" and members:
                obj_type = "group" if len(members) > 1 else (
                    "host" if members[0].startswith("host ") else "network"
                )
                objects.append(AddressObjectModel(
                    device_hostname=device_hostname,
                    name=current_name,
                    type=obj_type,
                    value=",".join(members),
                    vendor="cisco_ftd",
                ))

        for line in raw_output.splitlines():
            header = _GROUP_HEADER.match(line)
            if header:
                _flush()
                current_type = header.group(1).lower()
                current_name = header.group(2)
                members = []
                continue

            if current_name and current_type == "network":
                net_m = _NETWORK_OBJ.match(line)
                if net_m:
                    members.append(net_m.group(1).strip())
                    continue
                grp_m = _GROUP_OBJ.match(line)
                if grp_m:
                    members.append(grp_m.group(1))
                    continue

        _flush()
        return NetworkFacts(address_objects=objects)
