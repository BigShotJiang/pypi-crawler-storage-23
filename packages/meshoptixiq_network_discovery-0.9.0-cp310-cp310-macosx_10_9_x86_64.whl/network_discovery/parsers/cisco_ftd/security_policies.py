"""Cisco Firepower Threat Defense (FTD) security policy parser.

Parses output from:
  - show access-list

FTD's LINA (data-plane) engine exposes access-lists in ASA-compatible format
via the diagnostic CLI, making the SSH output structurally identical to ASA:

  access-list CSM_FW_ACL_ extended permit tcp any host 10.1.1.1 eq 443
  access-list CSM_FW_ACL_ extended deny ip any any
  access-list CSM_FW_ACL_ line 3 extended permit object-group SVC_WEB any host 10.0.0.1 (hitcnt=5) 0x...

FTD-specific considerations:
- FMC auto-generates ACL names such as ``CSM_FW_ACL_`` (the active policy),
  ``PREROUTING_<id>`` (prefilter), and ``FMC_INLINE_*`` (identity rules).
- Prefilter and identity ACLs are ingested unchanged alongside standard rules.
- Full FTD access control policies (including URL filtering, intrusion rules,
  and identity-aware policies) require the FMC REST API — this parser handles
  the compiled LINA ACL representation only.

NOTE: For complete FTD policy visibility, use the Firepower Management Center
REST API (``/api/fmc_config/v1/domain/{domainUUID}/policy/accesspolicies``).
"""

from __future__ import annotations

import re
from datetime import datetime, timezone

from network_discovery.normalization.models import FirewallRuleModel, NetworkFacts
from network_discovery.parsers.base import BaseParser
from network_discovery.parsers.registry import register

# Matches extended ACE lines (same pattern as ASA)
_ACE_LINE = re.compile(
    r"access-list\s+(\S+)"          # ACL name (e.g. CSM_FW_ACL_, PREROUTING_1)
    r"(?:\s+line\s+\d+)?"           # optional line number
    r"\s+extended"
    r"\s+(permit|deny)"             # action
    r"\s+(.*?)(?:\s+\(hitcnt=\d+\).*)?$",
    re.IGNORECASE,
)
_REMARK = re.compile(r"access-list\s+\S+\s+remark\s+", re.IGNORECASE)
_PROTO_RE = re.compile(
    r"^(tcp|udp|icmp|icmp6|ip|sctp|object-group\s+\S+|object\s+\S+)\s+",
    re.IGNORECASE,
)
_PORT_EQ = re.compile(r"\beq\s+(\S+)", re.IGNORECASE)
_PORT_RANGE = re.compile(r"\brange\s+(\S+)\s+(\S+)", re.IGNORECASE)

_ACTION_MAP = {"permit": "allow", "deny": "deny"}


def _extract_protocol(rest: str) -> tuple[str, str]:
    m = _PROTO_RE.match(rest)
    if m:
        proto = m.group(1).lower()
        if proto.startswith("object"):
            proto = proto.split()[-1]
        return proto, rest[m.end():]
    return "ip", rest


def _extract_port(body: str) -> str | None:
    eq_m = _PORT_EQ.search(body)
    if eq_m:
        return eq_m.group(1)
    rng_m = _PORT_RANGE.search(body)
    if rng_m:
        return f"{rng_m.group(1)}-{rng_m.group(2)}"
    return None


@register
class CiscoFTDSecurityPoliciesParser(BaseParser):
    """Parses 'show access-list' output from Cisco FTD (LINA / ASA-compatible format)."""

    @property
    def vendor(self) -> str:
        return "cisco_ftd"

    @property
    def fact_type(self) -> str:
        return "security_policies"

    def parse(self, raw_output: str, device_hostname: str) -> NetworkFacts:
        rules: list[FirewallRuleModel] = []
        now = datetime.now(timezone.utc)
        acl_order: dict[str, int] = {}

        for line in raw_output.splitlines():
            line = line.strip()
            if not line or _REMARK.match(line):
                continue

            m = _ACE_LINE.match(line)
            if not m:
                continue

            acl_name = m.group(1)
            raw_action = m.group(2).lower()
            rest = (m.group(3) or "").strip()
            rest = re.sub(r"\s*\(hitcnt=\d+\).*$", "", rest).strip()

            acl_order[acl_name] = acl_order.get(acl_name, 0) + 1
            order = acl_order[acl_name]

            action = _ACTION_MAP.get(raw_action, "deny")
            protocol, body = _extract_protocol(rest)

            dst_port = _extract_port(body)
            dst_ports = [dst_port] if dst_port else []

            addr_tokens = re.sub(
                r"\beq\s+\S+|\brange\s+\S+\s+\S+|\blt\s+\S+|\bgt\s+\S+", "", body
            ).split()
            mid = len(addr_tokens) // 2
            src_addrs = [" ".join(addr_tokens[:mid])] if addr_tokens[:mid] else ["any"]
            dst_addrs = [" ".join(addr_tokens[mid:])] if addr_tokens[mid:] else ["any"]

            rules.append(FirewallRuleModel(
                device_hostname=device_hostname,
                rule_id=f"{acl_name}:{order}",
                rule_name=acl_name,
                rule_order=order,
                action=action,
                source_zones=[],
                destination_zones=[],
                source_addresses=[a.strip() for a in src_addrs if a.strip()],
                destination_addresses=[a.strip() for a in dst_addrs if a.strip()],
                services=[],
                protocols=[protocol] if protocol not in ("ip", "") else [],
                destination_ports=dst_ports,
                enabled=True,
                log_enabled=False,
                vendor="cisco_ftd",
                collected_at=now,
            ))

        return NetworkFacts(firewall_rules=rules)
