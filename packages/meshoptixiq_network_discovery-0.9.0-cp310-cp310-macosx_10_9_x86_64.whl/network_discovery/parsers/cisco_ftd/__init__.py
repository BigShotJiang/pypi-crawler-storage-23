"""Cisco Firepower Threat Defense (FTD) parsers."""

from network_discovery.parsers.cisco_ftd import address_objects, security_policies  # noqa: F401
