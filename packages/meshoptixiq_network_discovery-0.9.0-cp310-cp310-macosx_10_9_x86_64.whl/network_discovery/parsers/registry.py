"""Parser registry for dispatching raw output to vendor-specific parsers.

Maps (vendor, fact_type) tuples to parser instances. Parsers register
themselves via register() or the convenience decorator.
"""

from __future__ import annotations

import logging

from network_discovery.normalization.models import NetworkFacts
from network_discovery.parsers.base import BaseParser

logger = logging.getLogger(__name__)

_registry: dict[tuple[str, str], BaseParser] = {}


def register(parser_class: type[BaseParser]) -> type[BaseParser]:
    """Register a parser class. Can be used as a decorator.

    Usage:
        @register
        class CiscoInterfaceParser(BaseParser):
            ...
    """
    instance = parser_class()
    key = (instance.vendor, instance.fact_type)

    if key in _registry:
        logger.warning("Overwriting parser for %s", key)

    _registry[key] = instance
    logger.debug("Registered parser: %s", key)
    return parser_class


def get_parser(vendor: str, fact_type: str) -> BaseParser | None:
    """Look up a parser by vendor and fact type."""
    return _registry.get((vendor, fact_type))


def list_parsers() -> list[tuple[str, str]]:
    """Return all registered (vendor, fact_type) keys."""
    return list(_registry.keys())


def parse_raw_output(
    vendor: str,
    fact_type: str,
    raw_output: str,
    device_hostname: str,
) -> NetworkFacts | None:
    """Dispatch raw output to the appropriate parser.

    Returns None if no parser is registered for the given vendor/fact_type.
    """

    parser = get_parser(vendor, fact_type)
    if parser is None:
        logger.warning("No parser registered for (%s, %s)", vendor, fact_type)
        return None

    return parser.parse(raw_output, device_hostname)
