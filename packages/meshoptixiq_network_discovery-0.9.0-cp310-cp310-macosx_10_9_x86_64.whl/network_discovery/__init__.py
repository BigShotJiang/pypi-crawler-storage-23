"""MeshOptixIQ Network Discovery — vendor-agnostic network graph builder."""

from network_discovery._version import __version__

__all__ = ["__version__"]
