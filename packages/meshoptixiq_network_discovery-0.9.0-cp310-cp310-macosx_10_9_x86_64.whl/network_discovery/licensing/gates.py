"""Plan-based feature gate enforcement.

This module is compiled with Cython (Apache 2.0) to prevent easy inspection
of plan tier logic and feature flag definitions.  The compiled .so file is what
ships in the Docker image; the .py source is not included in the distribution.

Usage::

    from network_discovery.licensing.gates import check_feature, PLAN_FEATURES

    check_feature(plan="starter", feature="api_access")  # raises FeatureNotAvailableError
    check_feature(plan="pro", feature="api_access")      # returns True
"""

from __future__ import annotations

import os
from typing import Any

# ---------------------------------------------------------------------------
# Feature matrix — what each plan tier unlocks
# ---------------------------------------------------------------------------
PLAN_FEATURES: dict[str, dict[str, Any]] = {
    "community": {
        "max_devices": 1,
        "max_network_devices": 1,
        "api_access": False,
        "advanced_queries": False,
        "custom_parsers": False,
        "postgres_backend": False,
        "data_export": False,
        "support_level": "community",
        "web_ui": True,
        "mcp_server": False,
        "firewall_queries": False,
        "whatif_simulation": False,
        "redis_clustering": False,
        "rbac": False,
        "netbox_sync": False,
        "audit_logging": False,
        "oidc_sso": False,
        "soar_webhooks": False,
    },
    "starter": {
        "max_devices": 100,
        "max_network_devices": 100,
        "api_access": False,
        "advanced_queries": False,
        "custom_parsers": False,
        "postgres_backend": False,
        "data_export": False,
        "support_level": "email",
        "web_ui": True,
        "mcp_server": False,
        "firewall_queries": False,
        "whatif_simulation": False,
        "redis_clustering": False,
        "rbac": False,
        "netbox_sync": False,
        "audit_logging": False,
        "oidc_sso": False,
        "soar_webhooks": False,
    },
    "pro": {
        "max_devices": 750,
        "max_network_devices": 750,
        "api_access": True,
        "advanced_queries": True,
        "custom_parsers": False,
        "postgres_backend": True,
        "data_export": True,
        "support_level": "priority_email",
        "web_ui": True,
        "mcp_server": True,
        "firewall_queries": True,
        "whatif_simulation": True,
        "redis_clustering": True,
        "rbac": True,
        "netbox_sync": True,
        "audit_logging": True,
        "oidc_sso": False,
        "soar_webhooks": False,
    },
    "enterprise": {
        "max_devices": -1,
        "max_network_devices": -1,
        "api_access": True,
        "advanced_queries": True,
        "custom_parsers": True,
        "postgres_backend": True,
        "data_export": True,
        "support_level": "dedicated",
        "web_ui": True,
        "custom_integrations": True,
        "mcp_server": True,
        "firewall_queries": True,
        "whatif_simulation": True,
        "redis_clustering": True,
        "rbac": True,
        "netbox_sync": True,
        "audit_logging": True,
        "oidc_sso": True,
        "soar_webhooks": True,
    },
}

_DEFAULT_PLAN = "community"


class FeatureNotAvailableError(Exception):
    """Raised when the current license plan does not include the requested feature."""

    def __init__(self, feature: str, plan: str, required_plan: str) -> None:
        self.feature = feature
        self.plan = plan
        self.required_plan = required_plan
        super().__init__(
            f"Feature '{feature}' is not available on the '{plan}' plan. "
            f"Upgrade to '{required_plan}' or higher."
        )


def get_features(plan: str | None) -> dict[str, Any]:
    """Return the feature dict for *plan*, defaulting to starter."""
    return dict(PLAN_FEATURES.get(plan or _DEFAULT_PLAN, PLAN_FEATURES[_DEFAULT_PLAN]))


def check_feature(plan: str | None, feature: str) -> bool:
    """Return True if *feature* is enabled for *plan*.

    Raises :class:`FeatureNotAvailableError` if the feature requires a higher tier.
    """
    if os.environ.get("MESHOPTIXIQ_DEMO_MODE"):
        return True  # demo mode — all features unlocked

    resolved = plan or _DEFAULT_PLAN
    features = PLAN_FEATURES.get(resolved, PLAN_FEATURES[_DEFAULT_PLAN])
    value = features.get(feature)

    if value is False or value == 0:
        # Determine the minimum plan that enables this feature
        required = _min_plan_for(feature)
        raise FeatureNotAvailableError(feature=feature, plan=resolved, required_plan=required)

    return True


def check_device_limit(plan: str | None, current_device_count: int) -> bool:
    """Return True if *current_device_count* is within the plan's device limit.

    Returns False (does not raise) so callers can emit a custom message.
    -1 means unlimited (enterprise).
    """
    resolved = plan or _DEFAULT_PLAN
    features = PLAN_FEATURES.get(resolved, PLAN_FEATURES[_DEFAULT_PLAN])
    max_devices: int = features.get("max_devices", 1)
    if max_devices == -1:
        return True
    return current_device_count <= max_devices


def check_network_device_limit(plan: str | None, network_device_count: int) -> bool:
    """Return True if *network_device_count* is within the plan's scan limit."""
    resolved = plan or _DEFAULT_PLAN
    features = PLAN_FEATURES.get(resolved, PLAN_FEATURES[_DEFAULT_PLAN])
    max_nd: int = features.get("max_network_devices", 50)
    if max_nd == -1:
        return True
    return network_device_count <= max_nd


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------
_PLAN_ORDER = ["community", "starter", "pro", "enterprise"]


def _min_plan_for(feature: str) -> str:
    """Return the lowest plan that enables *feature*."""
    for plan in _PLAN_ORDER:
        value = PLAN_FEATURES[plan].get(feature)
        if value is not False and value != 0:
            return plan
    return "enterprise"
