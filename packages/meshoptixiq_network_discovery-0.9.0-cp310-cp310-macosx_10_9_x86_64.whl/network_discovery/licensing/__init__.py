try:
    from .verifier import (
        LicenseDeviceMismatchError,
        LicenseError,
        LicenseExpiredError,
        LicenseInvalidError,
        LicenseSignatureError,
        LicenseVerifier,
    )
except ImportError:
    # The Cython-compiled .so may be built from an older source that does not
    # export all exception classes at module level.  Import what we can, and
    # define minimal stubs for the rest so that dependent packages (gates.py,
    # tests) can still import successfully.
    from .verifier import LicenseVerifier  # type: ignore[no-redef]

    class LicenseError(Exception):  # type: ignore[no-redef]
        pass

    class LicenseExpiredError(LicenseError):  # type: ignore[no-redef]
        pass

    class LicenseInvalidError(LicenseError):  # type: ignore[no-redef]
        pass

    class LicenseDeviceMismatchError(LicenseError):  # type: ignore[no-redef]
        pass

    class LicenseSignatureError(LicenseError):  # type: ignore[no-redef]
        pass


__all__ = [
    "LicenseDeviceMismatchError",
    "LicenseError",
    "LicenseExpiredError",
    "LicenseInvalidError",
    "LicenseSignatureError",
    "LicenseVerifier",
]
