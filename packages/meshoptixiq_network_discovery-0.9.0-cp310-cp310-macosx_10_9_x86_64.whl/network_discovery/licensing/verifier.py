import base64
import hashlib
import hmac
import json
import logging
import os
import pathlib
import platform
import subprocess
import time
import uuid

import requests
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding

from ..monitoring.metrics import MetricsCollector, RequestMetrics

logger = logging.getLogger(__name__)

# Global metrics collector (can be accessed for testing)
_metrics = MetricsCollector()

# Constants
LICENSE_API_URL = os.environ.get(
    "MESHOPTIXIQ_LICENSE_API_URL", "https://api.meshoptixiq.com/license/validate"
)
LICENSE_FILE_PATH = os.path.expanduser("~/.meshoptixiq/license.key")
STATE_FILE_PATH = os.path.expanduser("~/.meshoptixiq/license.state")
GRACE_PERIOD_SECONDS = 72 * 3600  # 72 hours

# RSA Public Key for signature verification
# Generated on 2026-02-12 - matches private key in backend
SERVER_PUBLIC_KEY_PEM = """-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAogUhWQS3rtFTiwV43gLU
pFUtqjaVybnBx/P0+1sJzjcl99gwktrgRFJuFNcg9lMa9x7i6V3X4b0rl8DSh0Bi
Modj+dXm0QRsBQLdtZlzvogpHqp1dsvXOe1VXwye8I7Fl7wflHJ0NXNtl2lDy4i3
yw7FQUR6Pm+NYQCY9hFfozywBZHi/lj+/GRi7lp9pyyUK4KoFZZRfHkYZXl28h2g
WbIiR1wf0b7rovsphVBexljl4wdB7HAI3Dm7rkQ5z1Cyw7T0iNFBkXjKobmhr/XP
MrTB8Uepr/tOh/E7HgibErtXOsRKWoWYMgQ6JkPQBdBzlYHy1o6PMFblUf10KiKC
NwIDAQAB
-----END PUBLIC KEY-----"""


# Custom Exceptions
class LicenseError(Exception):
    """Base exception for licensing errors."""

    pass


class LicenseExpiredError(LicenseError):
    """License has expired."""

    pass


class LicenseInvalidError(LicenseError):
    """License key is invalid or revoked."""

    pass


class LicenseDeviceMismatchError(LicenseError):
    """Device fingerprint doesn't match registered device."""

    pass


class LicenseSignatureError(LicenseError):
    """Server response signature verification failed."""

    pass


class LicenseVerifier:
    def _check_integrity(self) -> None:
        """Check for common tampering patterns. Logs warnings; never raises."""
        # 1. Debugger detection (Linux)
        if platform.system() == "Linux":
            try:
                for line in pathlib.Path("/proc/self/status").read_text().splitlines():
                    if line.startswith("TracerPid:"):
                        if int(line.split(":")[1].strip()) != 0:
                            logger.warning(
                                "A debugger is attached to this process. "
                                "License verification results may be unreliable."
                            )
                        break
            except Exception:
                pass

        # 2. LD_PRELOAD hooking
        if os.environ.get("LD_PRELOAD"):
            logger.warning(
                "LD_PRELOAD is set (%s). This may interfere with license "
                "verification. Unset LD_PRELOAD in production deployments.",
                os.environ["LD_PRELOAD"],
            )

        # 3. Tampered constants
        if GRACE_PERIOD_SECONDS > 7 * 24 * 3600:  # > 7 days is suspicious
            logger.warning(
                "GRACE_PERIOD_SECONDS has been altered to an unusually large "
                "value (%d). Expected 259200 (72 hours).",
                GRACE_PERIOD_SECONDS,
            )

        # 4. Loaded from Python source instead of compiled .so
        try:
            if __file__ and __file__.endswith(".py"):
                logger.warning(
                    "Licensing module loaded from Python source (%s) rather than "
                    "the compiled extension. Run setup_licensing.py build_ext "
                    "--inplace for production use.",
                    __file__,
                )
        except Exception:
            pass

    def __init__(self):
        self._check_integrity()
        self.license_key = self._load_license_key()
        self.state = self._load_state()

    def _load_license_key(self) -> str | None:
        """Load license key from file or environment variable."""
        try:
            if os.path.exists(LICENSE_FILE_PATH):
                with open(LICENSE_FILE_PATH) as f:
                    return f.read().strip()
        except Exception:
            pass
        return os.environ.get("MESHOPTIXIQ_LICENSE_KEY")

    def _get_encryption_key(self) -> bytes:
        """Generate machine-specific encryption key for state file."""
        machine_id = str(uuid.getnode())  # MAC address-based
        secret = "meshoptixiq-state-encryption-v1"
        combined = f"{machine_id}:{secret}".encode()
        key_material = hashlib.sha256(combined).digest()
        return base64.urlsafe_b64encode(key_material)

    def _load_state(self) -> dict:
        """Load and decrypt state file."""
        try:
            if os.path.exists(STATE_FILE_PATH):
                cipher = Fernet(self._get_encryption_key())
                with open(STATE_FILE_PATH, "rb") as f:
                    encrypted = f.read()
                plaintext = cipher.decrypt(encrypted)
                return json.loads(plaintext)
        except Exception as e:
            logger.debug("Failed to load state file (resetting): %s", e)
            pass
        return {
            "last_check": 0,
            "grace_period_start": None,
            "features": {},
            "plan": None,
        }

    def _save_state(self) -> None:
        """Save encrypted state file."""
        try:
            cipher = Fernet(self._get_encryption_key())
            plaintext = json.dumps(self.state).encode()
            encrypted = cipher.encrypt(plaintext)

            os.makedirs(os.path.dirname(STATE_FILE_PATH), exist_ok=True)
            with open(STATE_FILE_PATH, "wb") as f:
                f.write(encrypted)
        except Exception as e:
            logger.warning("Failed to save state file: %s", e)

    def _get_container_id(self) -> str:
        """Extract container ID from cgroup if running in Docker/Kubernetes."""
        try:
            with open("/proc/self/cgroup") as f:
                cgroup = f.read()
                if "docker" in cgroup or "kubepods" in cgroup:
                    for line in cgroup.split("\n"):
                        if "docker" in line or "kubepods" in line:
                            parts = line.split("/")
                            if parts:
                                return parts[-1].strip()[:12]
        except Exception:
            pass
        return ""

    def _get_machine_id(self) -> str:
        """Read the persistent machine ID written at OS install time.
        Linux: /etc/machine-id (systemd). macOS: ioreg IOPlatformUUID.
        Returns empty string if unavailable."""
        if platform.system() == "Linux":
            try:
                return pathlib.Path("/etc/machine-id").read_text().strip()
            except OSError:
                return ""
        if platform.system() == "Darwin":
            try:
                out = subprocess.check_output(
                    ["ioreg", "-d2", "-c", "IOPlatformExpertDevice"],
                    timeout=3, stderr=subprocess.DEVNULL, text=True,
                )
                for line in out.splitlines():
                    if "IOPlatformUUID" in line:
                        return line.split('"')[-2]
            except Exception:
                return ""
        return ""

    def _get_cpu_model(self) -> str:
        """Return a normalised CPU model string (stable hardware property).
        Linux: first 'model name' from /proc/cpuinfo. macOS: sysctl."""
        if platform.system() == "Linux":
            try:
                for line in pathlib.Path("/proc/cpuinfo").read_text().splitlines():
                    if line.startswith("model name"):
                        return line.split(":", 1)[1].strip()
            except OSError:
                pass
        if platform.system() == "Darwin":
            try:
                return subprocess.check_output(
                    ["sysctl", "-n", "machdep.cpu.brand_string"],
                    timeout=3, stderr=subprocess.DEVNULL, text=True,
                ).strip()
            except Exception:
                pass
        return ""

    def _detect_vm(self) -> tuple[bool, str]:
        """Detect whether running inside a VM/hypervisor via DMI/SMBIOS.
        Returns (is_vm, vendor_hint). Does NOT block — used only for warning."""
        vm_keywords = {
            "vmware": "VMware", "virtualbox": "VirtualBox", "vbox": "VirtualBox",
            "qemu": "QEMU/KVM", "kvm": "QEMU/KVM",
            "microsoft corporation": "Hyper-V", "amazon": "AWS EC2",
            "google": "Google Cloud", "xen": "Xen", "bochs": "BOCHS",
            "innotek": "VirtualBox",
        }
        for dmi_path in (
            "/sys/class/dmi/id/sys_vendor",
            "/sys/class/dmi/id/product_name",
            "/sys/class/dmi/id/board_vendor",
        ):
            try:
                val = pathlib.Path(dmi_path).read_text().strip().lower()
                for key, label in vm_keywords.items():
                    if key in val:
                        return True, label
            except OSError:
                pass
        return False, ""

    def _generate_device_fingerprint(self) -> str:
        """Generate unique hardware fingerprint for this device."""
        components: list[str] = []

        # Stable OS-install-time ID (most reliable anchor)
        machine_id = self._get_machine_id()
        if machine_id:
            components.append(f"mid:{machine_id}")

        # Hardware MAC address (volatile in VMs but still useful)
        components.append(f"mac:{uuid.getnode()}")

        # CPU model string (stable hardware property)
        cpu = self._get_cpu_model()
        if cpu:
            components.append(f"cpu:{cpu}")

        # Architecture + OS (existing)
        components.append(platform.machine())
        components.append(platform.system())

        # Container identity (existing cgroup logic + hardened checks)
        container_id = self._get_container_id()
        if container_id:
            components.append(f"container:{container_id}")
        elif os.path.exists("/.dockerenv"):
            components.append("container:docker")
        elif os.environ.get("KUBERNETES_SERVICE_HOST"):
            components.append("container:kubernetes")

        return hashlib.sha256(":".join(components).encode()).hexdigest()

    def _sign_request(self, license_key: str) -> dict:
        """Sign validation request to prevent tampering and replay attacks."""
        timestamp = int(time.time())
        nonce = os.urandom(16).hex()
        device_fingerprint = self._generate_device_fingerprint()

        message = f"{license_key}:{timestamp}:{nonce}:{device_fingerprint}"
        signature = hmac.new(
            license_key.encode(), message.encode(), hashlib.sha256
        ).hexdigest()

        return {
            "license_key": license_key,
            "timestamp": timestamp,
            "nonce": nonce,
            "device_fingerprint": device_fingerprint,
            "signature": signature,
        }

    def _verify_response_signature(self, response_data: dict) -> bool:
        """Verify server response is signed by legitimate backend."""
        signature_b64 = response_data.get("signature")
        payload = response_data.get("payload")

        if not signature_b64 or not payload:
            logger.warning("Response missing signature or payload")
            return False

        try:
            # Load public key
            public_key = serialization.load_pem_public_key(
                SERVER_PUBLIC_KEY_PEM.encode()
            )

            # Verify signature
            public_key.verify(
                base64.b64decode(signature_b64),
                payload.encode(),
                padding.PSS(
                    mgf=padding.MGF1(hashes.SHA256()),
                    salt_length=padding.PSS.MAX_LENGTH,
                ),
                hashes.SHA256(),
            )
            return True
        except Exception as e:
            logger.error("Signature verification failed: %s", e)
            return False

    def verify(self) -> bool:
        """
        Verifies the license.
        Returns: True if valid (or in grace period), False if expired/invalid.
        Raises: LicenseError subclasses for specific error conditions.
        """
        if not self.license_key:
            raise LicenseInvalidError(
                "No license key found. Please set MESHOPTIXIQ_LICENSE_KEY "
                "or create ~/.meshoptixiq/license.key"
            )

        # Check if we need to contact the server (every 24h)
        now = time.time()
        is_vm, vm_vendor = self._detect_vm()
        if is_vm:
            logger.warning(
                "Running inside a virtual machine (%s). Device fingerprint may change "
                "on VM migration or snapshot restore. Contact hello@meshoptixiq.com "
                "if you encounter device mismatch errors after a migration.",
                vm_vendor,
            )
        last_check = self.state.get("last_check", 0)

        if now - last_check < 86400:
            # Within 24h cache window
            if self.state.get("grace_period_start"):
                # In grace period, try to reconnect
                return self._check_server(now)
            # Valid cached state
            return True

        return self._check_server(now)

    def _check_server(self, now: float) -> bool:
        """Contact license server for validation."""
        metrics = RequestMetrics(
            endpoint=LICENSE_API_URL,
            method="POST",
            start_time=time.time()
        )

        try:
            # Sign the request
            request_data = self._sign_request(self.license_key)

            response = requests.post(
                LICENSE_API_URL, json=request_data, timeout=5
            )

            metrics.end_time = time.time()
            metrics.status_code = response.status_code
            _metrics.record_request(metrics)
            _metrics.license.server_checks += 1
            _metrics.license.response_times.append(metrics.duration_ms)

            if response.status_code == 200:
                data = response.json()

                # Verify response signature
                if not self._verify_response_signature(data):
                    raise LicenseSignatureError(
                        "Server response signature verification failed"
                    )

                # Parse the payload
                try:
                    payload_data = json.loads(data["payload"])
                except (json.JSONDecodeError, KeyError) as e:
                    raise LicenseSignatureError(f"Invalid response payload: {e}")

                if payload_data.get("valid"):
                    # Success! Update state
                    self.state["last_check"] = now
                    self.state["grace_period_start"] = None
                    self.state["features"] = payload_data.get("features", {})
                    self.state["plan"] = payload_data.get("plan")
                    self.state["expiration"] = payload_data.get("expiration")
                    self._save_state()
                    return True
                else:
                    reason = payload_data.get("reason", "Unknown")
                    if "expired" in reason.lower():
                        raise LicenseExpiredError(f"License has expired: {reason}")
                    elif "device" in reason.lower():
                        raise LicenseDeviceMismatchError(
                            f"Device mismatch: {reason}"
                        )
                    else:
                        raise LicenseInvalidError(f"License invalid: {reason}")

            elif response.status_code == 403:
                try:
                    error_body = response.json()
                    error_msg = error_body.get("error", "License denied by server")
                except Exception:
                    error_msg = "License denied by server"
                raise LicenseInvalidError(f"License invalid: {error_msg}")
            elif response.status_code == 409:
                raise LicenseDeviceMismatchError(
                    "Device limit exceeded for this license"
                )
            elif response.status_code == 429:
                logger.warning("Rate limit exceeded, entering grace period")
                return self._handle_grace_period(now)
            else:
                # Server error, fall through to grace period
                raise Exception(f"Server returned {response.status_code}")

        except (LicenseError):
            # Re-raise license-specific errors
            metrics.end_time = time.time()
            metrics.error = str(LicenseError)
            _metrics.record_request(metrics)
            _metrics.license.failures.append(str(LicenseError))
            raise
        except Exception as e:
            # Server unreachable or other error
            logger.warning("Could not contact licensing server: %s", e)
            metrics.end_time = time.time()
            metrics.error = str(e)
            _metrics.record_request(metrics)
            _metrics.license.failures.append(str(e))
            return self._handle_grace_period(now)

    def _handle_grace_period(self, now: float) -> bool:
        """Handle grace period when server is unreachable."""
        if not self.state.get("grace_period_start"):
            self.state["grace_period_start"] = now
            self._save_state()
            _metrics.license.grace_period_activations += 1
            logger.warning("Entering 72-hour grace period.")
            return True

        grace_start = self.state["grace_period_start"]
        elapsed = now - grace_start

        if elapsed > GRACE_PERIOD_SECONDS:
            raise LicenseError(
                "Grace period expired. Cannot verify license. "
                "Please check your network connection."
            )

        remaining = (GRACE_PERIOD_SECONDS - elapsed) / 3600
        logger.info("Running in grace period. %.1f hours remaining.", remaining)
        return True

    def get_features(self) -> dict:
        """
        Get feature flags for the current license.
        Returns cached features from last successful validation.
        """
        return self.state.get("features", {})

    def get_plan(self) -> str | None:
        """Get the current license plan (starter, pro, enterprise)."""
        return self.state.get("plan")

    def get_expiration(self) -> str | None:
        """Get the license expiration date (YYYY-MM-DD format)."""
        return self.state.get("expiration")

    def get_metrics(self) -> MetricsCollector:
        """Get metrics collector for testing/monitoring."""
        return _metrics

    def reset_metrics(self):
        """Reset metrics (for testing)."""
        global _metrics
        _metrics = MetricsCollector()
