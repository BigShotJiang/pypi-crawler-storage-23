#    path_tools.py
#        Tools for scrutiny path manipulation
#
#   - License : MIT - See LICENSE file
#   - Project : Scrutiny Debugger (github.com/scrutinydebugger/scrutiny-main)
#
#    Copyright (c) 2025 Scrutiny Debugger

__all__ = ['make_segments', 'join_segments', 'is_subpath', 'is_rpv_path', 'count_segments']

import re
from scrutiny.tools.typing import *


def make_segments(path: str) -> List[str]:
    """Splits a path string into an list of string segments"""
    pieces = path.split('/')
    return [segment for segment in pieces if segment]


def count_segments(path: str) -> int:
    return len(make_segments(path))


def join_segments(segments: List[str]) -> str:
    """Joins a list of string segments into a path string"""
    return '/' + '/'.join([segment for segment in segments if segment])


def is_subpath(subpath: str, path: str) -> bool:
    subpath_segments = make_segments(subpath)
    path_segments = make_segments(path)
    if len(subpath_segments) > len(path_segments):
        return False
    if len(subpath_segments) == 0:
        return False

    for i in range(len(subpath_segments)):
        if subpath_segments[i] != path_segments[i]:
            return False
    return True


def is_rpv_path(path: str) -> bool:
    """Returns True if the given tree-like path is the path of a Runtime Published Value"""
    return (re.match(r'^\/?rpv\/x\d+\/?$', path, re.IGNORECASE) is not None)
