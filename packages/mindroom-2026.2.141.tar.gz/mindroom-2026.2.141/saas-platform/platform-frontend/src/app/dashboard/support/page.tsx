export default function SupportPage() {
  return (
    <div className="p-6">
      <h1 className="text-xl font-semibold mb-2">Support</h1>
      <p className="text-sm text-gray-500">This page is coming soon.</p>
    </div>
  );
}
