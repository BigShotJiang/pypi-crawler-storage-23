use std::io;
use std::io::Write;

use borrowme::borrowme;

use crate::analyse::{Analyze, StatType};
use crate::utils::{SetOptionOnce as _, parse_string, parse_varint};
use crate::v01::column::ColumnType;
use crate::v01::{
    Column, DictionaryType, EncodedIdValue, EncodedPropValue, EncodedSharedDictProp,
    EncodedStrProp, EncodedStructChild, Geometry, Id, OwnedId, Property, Stream, StreamType,
};
use crate::{Decodable as _, MltError, MltRefResult, utils};

/// Representation of a feature table layer encoded as MLT tag `0x01`
#[cfg(not(fuzzing))]
#[borrowme]
#[derive(Debug, PartialEq)]
#[cfg_attr(
    all(not(test), feature = "arbitrary"),
    owned_attr(derive(arbitrary::Arbitrary))
)]
pub struct Layer01<'a> {
    pub name: &'a str,
    pub extent: u32,
    pub id: Id<'a>,
    pub geometry: Geometry<'a>,
    pub properties: Vec<Property<'a>>,
}

/// FIXME: fuzzing is only adding layer_order but this borrowme does not codegen correctly in this case
#[cfg(fuzzing)]
#[borrowme]
#[derive(Debug, PartialEq)]
pub struct Layer01<'a> {
    pub name: &'a str,
    pub extent: u32,
    pub id: Id<'a>,
    pub geometry: Geometry<'a>,
    pub properties: Vec<Property<'a>>,
    pub layer_order: Vec<LayerOrdering>,
}

impl Analyze for Layer01<'_> {
    fn collect_statistic(&self, stat: StatType) -> usize {
        match stat {
            StatType::DecodedMetaSize => self.name.len() + size_of::<u32>(),
            StatType::DecodedDataSize => {
                self.id.collect_statistic(stat)
                    + self.geometry.collect_statistic(stat)
                    + self.properties.collect_statistic(stat)
            }
            StatType::FeatureCount => self.geometry.collect_statistic(stat),
        }
    }

    fn for_each_stream(&self, cb: &mut dyn FnMut(&Stream<'_>)) {
        self.id.for_each_stream(cb);
        self.geometry.for_each_stream(cb);
        self.properties.for_each_stream(cb);
    }
}

impl Layer01<'_> {
    /// Parse `v01::Layer` metadata
    pub fn parse(input: &[u8]) -> Result<Layer01<'_>, MltError> {
        use EncodedPropValue as EncVal;

        let (input, layer_name) = parse_string(input)?;
        let (input, extent) = parse_varint::<u32>(input)?;
        let (input, column_count) = parse_varint::<usize>(input)?;

        // Each column requires at least 1 byte (column type)
        if input.len() < column_count {
            return Err(MltError::BufferUnderflow(column_count, input.len()));
        }

        // !!!!!!!
        // WARNING: make sure to never use `let (input, ...)` after this point: input var is reused
        let (mut input, (col_info, prop_count)) = parse_columns_meta(input, column_count)?;
        #[cfg(fuzzing)]
        let layer_order = col_info
            .iter()
            .map(|column| column.typ)
            .map(LayerOrdering::from)
            .collect();

        let mut properties = Vec::with_capacity(prop_count);
        let mut id_stream: Option<Id> = None;
        let mut geometry: Option<Geometry> = None;

        for column in col_info {
            let opt;
            let value;
            let enc_val;
            let name = column.name.unwrap_or("");

            match column.typ {
                ColumnType::Id | ColumnType::OptId => {
                    (input, opt) = parse_optional(column.typ, input)?;
                    (input, value) = Stream::parse(input)?;
                    id_stream.set_once(Id::new_encoded(opt, EncodedIdValue::Id32(value)))?;
                }
                ColumnType::LongId | ColumnType::OptLongId => {
                    (input, opt) = parse_optional(column.typ, input)?;
                    (input, value) = Stream::parse(input)?;
                    id_stream.set_once(Id::new_encoded(opt, EncodedIdValue::Id64(value)))?;
                }
                ColumnType::Geometry => {
                    input = parse_geometry_column(input, &mut geometry)?;
                }
                ColumnType::Bool | ColumnType::OptBool => {
                    (input, opt) = parse_optional(column.typ, input)?;
                    (input, value) = Stream::parse_bool(input)?;
                    properties.push(Property::new_encoded(name, EncVal::Bool(opt, value)));
                }
                ColumnType::I8 | ColumnType::OptI8 => {
                    (input, opt) = parse_optional(column.typ, input)?;
                    (input, value) = Stream::parse(input)?;
                    properties.push(Property::new_encoded(name, EncVal::I8(opt, value)));
                }
                ColumnType::U8 | ColumnType::OptU8 => {
                    (input, opt) = parse_optional(column.typ, input)?;
                    (input, value) = Stream::parse(input)?;
                    properties.push(Property::new_encoded(name, EncVal::U8(opt, value)));
                }
                ColumnType::I32 | ColumnType::OptI32 => {
                    (input, opt) = parse_optional(column.typ, input)?;
                    (input, value) = Stream::parse(input)?;
                    properties.push(Property::new_encoded(name, EncVal::I32(opt, value)));
                }
                ColumnType::U32 | ColumnType::OptU32 => {
                    (input, opt) = parse_optional(column.typ, input)?;
                    (input, value) = Stream::parse(input)?;
                    properties.push(Property::new_encoded(name, EncVal::U32(opt, value)));
                }
                ColumnType::I64 | ColumnType::OptI64 => {
                    (input, opt) = parse_optional(column.typ, input)?;
                    (input, value) = Stream::parse(input)?;
                    properties.push(Property::new_encoded(name, EncVal::I64(opt, value)));
                }
                ColumnType::U64 | ColumnType::OptU64 => {
                    (input, opt) = parse_optional(column.typ, input)?;
                    (input, value) = Stream::parse(input)?;
                    properties.push(Property::new_encoded(name, EncVal::U64(opt, value)));
                }
                ColumnType::F32 | ColumnType::OptF32 => {
                    (input, opt) = parse_optional(column.typ, input)?;
                    (input, value) = Stream::parse(input)?;
                    properties.push(Property::new_encoded(name, EncVal::F32(opt, value)));
                }
                ColumnType::F64 | ColumnType::OptF64 => {
                    (input, opt) = parse_optional(column.typ, input)?;
                    (input, value) = Stream::parse(input)?;
                    properties.push(Property::new_encoded(name, EncVal::F64(opt, value)));
                }
                ColumnType::Str | ColumnType::OptStr => {
                    (input, enc_val) = parse_str_column(input, column.typ)?;
                    properties.push(Property::new_encoded(name, enc_val));
                }
                ColumnType::SharedDict => {
                    (input, enc_val) = parse_shared_dict_column(input, &column)?;
                    properties.push(Property::new_encoded(name, enc_val));
                }
            }
        }
        if input.is_empty() {
            Ok(Layer01 {
                name: layer_name,
                extent,
                id: id_stream.unwrap_or_default(),
                geometry: geometry.ok_or(MltError::MissingGeometry)?,
                properties,
                #[cfg(fuzzing)]
                layer_order,
            })
        } else {
            Err(MltError::TrailingLayerData(input.len()))
        }
    }

    pub fn decode_all(&mut self) -> Result<(), MltError> {
        self.id.materialize()?;
        self.geometry.materialize()?;
        let old_props = std::mem::take(&mut self.properties);
        for prop in old_props {
            self.properties.extend(prop.decode_expand()?);
        }
        Ok(())
    }
}

fn parse_struct_children<'a>(
    mut input: &'a [u8],
    column: &Column<'a>,
) -> MltRefResult<'a, Vec<EncodedStructChild<'a>>> {
    let mut children = Vec::with_capacity(column.children.len());
    for child in &column.children {
        let (inp, sc) = parse_varint::<usize>(input)?;
        let (inp, child_optional) = parse_optional(child.typ, inp)?;
        let optional_stream_count = usize::from(child_optional.is_some());
        if let Some(data_count) = sc.checked_sub(optional_stream_count)
            && data_count != 1
        {
            return Err(MltError::UnexpectedStructChildCount(data_count));
        }
        let (inp, child_data) = Stream::parse(inp)?;
        children.push(EncodedStructChild {
            name: child.name.unwrap_or(""),
            typ: child.typ,
            optional: child_optional,
            data: child_data,
        });
        input = inp;
    }
    Ok((input, children))
}

fn parse_optional(typ: ColumnType, input: &[u8]) -> MltRefResult<'_, Option<Stream<'_>>> {
    if typ.is_optional() {
        let (input, optional) = Stream::parse_bool(input)?;
        Ok((input, Some(optional)))
    } else {
        Ok((input, None))
    }
}

fn parse_geometry_column<'a>(
    input: &'a [u8],
    geometry: &mut Option<Geometry<'a>>,
) -> Result<&'a [u8], MltError> {
    let (input, stream_count) = parse_varint::<usize>(input)?;
    if stream_count == 0 {
        return Err(MltError::GeometryWithoutStreams);
    }
    // Each stream requires at least 1 byte (physical stream type)
    if input.len() < stream_count {
        return Err(MltError::BufferUnderflow(stream_count, input.len()));
    }
    // metadata
    let (input, value) = Stream::parse(input)?;
    // geometry items
    let (input, value_vec) = Stream::parse_multiple(input, stream_count - 1)?;
    geometry.set_once(Geometry::new_encoded(value, value_vec))?;
    Ok(input)
}

fn parse_str_column(mut input: &[u8], typ: ColumnType) -> MltRefResult<'_, EncodedPropValue<'_>> {
    let mut stream_count;
    let opt;
    (input, stream_count) = parse_varint::<usize>(input)?;
    (input, opt) = parse_optional(typ, input)?;
    if opt.is_some() {
        if stream_count == 0 {
            return Err(MltError::UnsupportedStringStreamCount(stream_count));
        }
        stream_count -= 1;
    }
    let mut str_streams = [None, None, None, None, None];
    if stream_count > str_streams.len() {
        return Err(MltError::UnsupportedStringStreamCount(stream_count));
    }
    for slot in str_streams.iter_mut().take(stream_count) {
        let stream;
        (input, stream) = Stream::parse(input)?;
        *slot = Some(stream);
    }
    let encoding = match str_streams {
        [Some(s1), Some(s2), None, None, None] => EncodedStrProp::plain(s1, s2)?,
        [Some(s1), Some(s2), Some(s3), None, None] => EncodedStrProp::dictionary(s1, s2, s3)?,
        [Some(s1), Some(s2), Some(s3), Some(s4), None] => {
            EncodedStrProp::fsst_plain(s1, s2, s3, s4)?
        }
        [Some(s1), Some(s2), Some(s3), Some(s4), Some(s5)] => {
            EncodedStrProp::fsst_dictionary(s1, s2, s3, s4, s5)?
        }
        _ => Err(MltError::UnsupportedStringStreamCount(stream_count))?,
    };
    Ok((input, EncodedPropValue::Str(opt, encoding)))
}

fn parse_shared_dict_column<'a>(
    mut input: &'a [u8],
    column: &Column<'a>,
) -> MltRefResult<'a, EncodedPropValue<'a>> {
    // Read header streams until we hit the dictionary DATA(Single|Shared) stream.
    let stream_count;
    (input, stream_count) = parse_varint::<usize>(input)?;
    let mut dict_streams = [None, None, None, None, None];
    let mut streams_taken = 0;
    while streams_taken < stream_count {
        let stream;
        (input, stream) = Stream::parse(input)?;
        let is_last = matches!(
            stream.meta.stream_type,
            StreamType::Data(DictionaryType::Single | DictionaryType::Shared)
        );
        dict_streams[streams_taken] = Some(stream);
        streams_taken += 1;
        if is_last {
            break;
        } else if streams_taken >= dict_streams.len() {
            return Err(MltError::UnsupportedStringStreamCount(streams_taken + 1));
        }
    }
    let children;
    (input, children) = parse_struct_children(input, column)?;
    let shared_dict = match dict_streams {
        [Some(s1), Some(s2), None, None, None] => EncodedSharedDictProp::plain(s1, s2, children)?,
        [Some(s1), Some(s2), Some(s3), None, None] => {
            EncodedSharedDictProp::dictionary(s1, s2, s3, children)?
        }
        [Some(s1), Some(s2), Some(s3), Some(s4), None] => {
            EncodedSharedDictProp::fsst_plain(s1, s2, s3, s4, children)?
        }
        [Some(s1), Some(s2), Some(s3), Some(s4), Some(s5)] => {
            EncodedSharedDictProp::fsst_dictionary(s1, s2, s3, s4, s5, children)?
        }
        _ => Err(MltError::StructSharedDictRequiresStreams(streams_taken))?,
    };
    Ok((input, EncodedPropValue::SharedDict(shared_dict)))
}

fn parse_columns_meta(
    mut input: &'_ [u8],
    column_count: usize,
) -> MltRefResult<'_, (Vec<Column<'_>>, usize)> {
    use crate::v01::column::ColumnType::{Geometry, Id, LongId, OptId, OptLongId, SharedDict};

    let mut col_info = Vec::with_capacity(column_count);
    let mut geometries = 0;
    let mut ids = 0;
    for _ in 0..column_count {
        let mut typ;
        (input, typ) = Column::parse(input)?;
        match typ.typ {
            Geometry => geometries += 1,
            Id | OptId | LongId | OptLongId => ids += 1,
            SharedDict => {
                // Yes, we need to parse children right here, otherwise this messes up the next column
                let child_column_count;
                (input, child_column_count) = parse_varint::<usize>(input)?;

                // Each column requires at least 1 byte (ColumnType without name)
                if input.len() < child_column_count {
                    return Err(MltError::BufferUnderflow(child_column_count, input.len()));
                }
                let mut children = Vec::with_capacity(child_column_count);
                for _ in 0..child_column_count {
                    let child;
                    (input, child) = Column::parse(input)?;
                    children.push(child);
                }
                typ.children = children;
            }
            _ => {}
        }
        col_info.push(typ);
    }
    if geometries > 1 {
        return Err(MltError::MultipleGeometryColumns);
    }
    if ids > 1 {
        return Err(MltError::MultipleIdColumns);
    }

    Ok((input, (col_info, column_count - geometries - ids)))
}

impl OwnedLayer01 {
    /// Write Layer's binary representation to a Write stream without allocating a Vec
    pub fn write_to<W: Write>(&self, writer: &mut W) -> io::Result<()> {
        use integer_encoding::VarIntWriter as _;
        use utils::BinarySerializer as _;

        writer.write_string(&self.name)?;
        writer.write_varint(u64::from(self.extent))?;

        // write size
        let has_id = !matches!(self.id, OwnedId::None);
        let id_columns_count = u64::from(has_id);
        let geometry_column_count = 1;
        let property_column_count = u64::try_from(self.properties.len()).map_err(MltError::from)?;
        let column_count = property_column_count + id_columns_count + geometry_column_count;
        writer.write_varint(column_count)?;

        let map_error_to_io = |e: MltError| match e {
            MltError::Io(e) => e,
            e => io::Error::other(e),
        };
        self.write_columns_meta_to(writer)
            .map_err(map_error_to_io)?;
        self.write_columns_to(writer).map_err(map_error_to_io)?;
        Ok(())
    }

    #[cfg(not(fuzzing))]
    fn write_columns_meta_to<W: Write>(&self, writer: &mut W) -> Result<(), MltError> {
        self.id.write_columns_meta_to(writer)?;
        self.geometry.write_columns_meta_to(writer)?;
        for prop in &self.properties {
            prop.write_columns_meta_to(writer)?;
        }
        Ok(())
    }
    #[cfg(fuzzing)]
    fn write_columns_meta_to<W: Write>(&self, writer: &mut W) -> Result<(), MltError> {
        let props = &mut self.properties.iter();
        for ord in &self.layer_order {
            match ord {
                LayerOrdering::Id => self.id.write_columns_meta_to(writer)?,
                LayerOrdering::Geometry => self.geometry.write_columns_meta_to(writer)?,
                LayerOrdering::Property => {
                    let prop = props.next().expect(
                        "the number of layer order elements must match the number of properties",
                    );
                    prop.write_columns_meta_to(writer)?;
                }
            }
        }
        Ok(())
    }
    #[cfg(not(fuzzing))]
    fn write_columns_to<W: Write>(&self, writer: &mut W) -> Result<(), MltError> {
        self.id.write_to(writer)?;
        self.geometry.write_to(writer)?;
        for prop in &self.properties {
            prop.write_to(writer)?;
        }
        Ok(())
    }
    #[cfg(fuzzing)]
    fn write_columns_to<W: Write>(&self, writer: &mut W) -> Result<(), MltError> {
        let props = &mut self.properties.iter();
        for ord in &self.layer_order {
            match ord {
                LayerOrdering::Id => self.id.write_to(writer)?,
                LayerOrdering::Geometry => self.geometry.write_to(writer)?,
                LayerOrdering::Property => {
                    let prop = props.next().expect(
                        "the number of layer order elements must match the number of properties",
                    );
                    prop.write_to(writer)?;
                }
            }
        }
        Ok(())
    }
}

#[cfg(fuzzing)]
/// To make sure we serialize out in the same order as the original file, we need to store the order in which we parsed the columns
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum LayerOrdering {
    Id,
    Geometry,
    Property,
}

#[cfg(fuzzing)]
impl From<ColumnType> for LayerOrdering {
    fn from(typ: ColumnType) -> Self {
        use ColumnType::*;
        match typ {
            OptId | Id | LongId | OptLongId => Self::Id,
            Bool | OptBool | I8 | OptI8 | U8 | OptU8 | I32 | OptI32 | U32 | OptU32 | I64
            | OptI64 | U64 | OptU64 | F32 | OptF32 | F64 | OptF64 | Str | OptStr | SharedDict => {
                Self::Property
            }
            Geometry => Self::Geometry,
        }
    }
}
