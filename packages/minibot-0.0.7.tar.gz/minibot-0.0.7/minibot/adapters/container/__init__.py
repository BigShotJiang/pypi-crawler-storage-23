"""Adapter container helpers."""

from minibot.adapters.container.app_container import AppContainer

__all__ = ["AppContainer"]
