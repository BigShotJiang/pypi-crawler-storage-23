"""
LLM Router - Smart LLM routing with TIBET provenance

Route queries to the right model automatically, track everything.

Example:
    from llm_router import LLMRouter

    llm = LLMRouter()
    response = llm.generate("Hello!")

    # With model selection
    response = llm.generate("Complex question", model="qwen2.5:32b")

    # With TIBET tracking
    from tibet_core import Provider
    tibet = Provider(actor="my_app")
    llm = LLMRouter(tibet=tibet)
    response = llm.generate("Tracked query")

Credits:
    - Jasper van de Meent
    - R. AI (Root AI)
"""

from .core import LLMRouter
from .router import ModelRouter, ModelConfig, ModelCapability
from .client import OllamaClient

__version__ = "0.1.0"
__author__ = "Humotica AI Lab"
__all__ = ["LLMRouter", "ModelRouter", "ModelConfig", "ModelCapability", "OllamaClient"]
