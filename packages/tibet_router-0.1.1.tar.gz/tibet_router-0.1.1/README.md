# tibet-router - DEPRECATED

## This package has been renamed to `tibet-llm-router`

```bash
pip install tibet-llm-router
```

The name `tibet-router` is reserved for future TIBET token routing functionality (like jis-router routes RABEL messages).

## Migration

Simply replace:
```bash
pip uninstall tibet-router
pip install tibet-llm-router
```

Your code remains the same - `from llm_router import LLMRouter` still works.

## New Package

- **PyPI:** https://pypi.org/project/tibet-llm-router/
- **Docs:** https://humotica.com/docs/tibet-llm-router

---

**One Love, One fAmIly**

Built by Humotica AI Lab
