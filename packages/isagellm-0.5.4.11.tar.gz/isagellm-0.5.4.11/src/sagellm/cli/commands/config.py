"""Config command - Manage sageLLM configuration."""

from __future__ import annotations

import click

from ..utils.config import DEFAULT_CONFIG, init_default_config
from ..utils.console import get_console


@click.command()
@click.argument("action", type=click.Choice(["show", "reset", "path"]), default="show")
def config(action: str) -> None:
    """Manage sageLLM configuration.

    \b
    Actions:
      show   Display current configuration (default)
      reset  Reset to default configuration
      path   Show config file path
    """
    init_default_config()
    console = get_console()

    if action == "show":
        console.print(f"\n📄 [bold]Configuration:[/bold] {DEFAULT_CONFIG}\n")
        if DEFAULT_CONFIG.exists():
            from rich.syntax import Syntax

            content = DEFAULT_CONFIG.read_text()
            syntax = Syntax(content, "yaml", theme="monokai", line_numbers=True)
            console.print(syntax)
        else:
            console.print(
                "[yellow]No config file found. Run 'sage-llm config reset' to create.[/yellow]"
            )

    elif action == "reset":
        DEFAULT_CONFIG.unlink(missing_ok=True)
        init_default_config()
        console.print("[green]✅ Config reset to defaults[/green]")

    elif action == "path":
        console.print(str(DEFAULT_CONFIG))
