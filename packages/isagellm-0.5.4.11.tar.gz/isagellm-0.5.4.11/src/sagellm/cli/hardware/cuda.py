"""CUDA hardware detection."""


def check_cuda_available() -> tuple[bool, str]:
    """Check if CUDA is available after installation."""
    try:
        import torch

        if torch.cuda.is_available():
            device_name = torch.cuda.get_device_name(0)
            return True, f"✅ CUDA ready: {device_name}"
        return False, "❌ CUDA not detected (check NVIDIA drivers)"
    except Exception as e:
        return False, f"❌ Error: {e}"
