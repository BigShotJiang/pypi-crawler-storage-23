"""Ascend NPU hardware detection."""


def check_ascend_available() -> tuple[bool, str]:
    """Check if Ascend NPU is available."""
    try:
        import torch_npu

        if torch_npu.npu.is_available():
            return True, "✅ Ascend NPU ready"
        return False, "❌ Ascend NPU not detected"
    except ImportError:
        return False, "❌ torch_npu not installed"
    except Exception as e:
        return False, f"❌ Error: {e}"
