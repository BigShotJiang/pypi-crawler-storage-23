INCEPTION_MODELS = {
    "mercury-2": {
        "id": "mercury-2",
        "name": "mercury-2",
        "api_base": "https://api.inceptionlabs.ai/v1",
        "api_key_env_var": "INCEPTION_API_KEY",
        "api_spec": "openai",
        "input_cost": 0.25,
        "cached_input_cost": 0.025,
        "output_cost": 0.75,
        "supports_json": True,
        "reasoning_model": True,
    },
}
