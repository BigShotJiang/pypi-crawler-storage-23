"""Local CLI config persistence for SDK credentials."""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Optional


def get_default_config_path() -> Path:
    home = Path.home()
    return home / ".sentry_logger" / "config.json"


def ensure_parent(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)


def load_local_config(path: Optional[str] = None) -> dict[str, Any]:
    config_path = Path(path) if path else get_default_config_path()
    if not config_path.exists():
        return {}
    try:
        with config_path.open("r", encoding="utf-8") as f:
            payload = json.load(f)
        return payload if isinstance(payload, dict) else {}
    except Exception:
        return {}


def save_local_config(payload: dict[str, Any], path: Optional[str] = None) -> Path:
    config_path = Path(path) if path else get_default_config_path()
    ensure_parent(config_path)
    with config_path.open("w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)
    return config_path


DEFAULT_DSN = "https://api.sentrylabs.live"


def resolve_api_key(explicit_key: Optional[str] = None) -> Optional[str]:
    if explicit_key:
        return explicit_key
    env_key = os.environ.get("SENTRY_API_KEY")
    if env_key:
        return env_key
    cfg = load_local_config()
    return cfg.get("api_key")


def resolve_dsn(explicit_dsn: Optional[str] = None) -> str:
    if explicit_dsn:
        return explicit_dsn.rstrip("/")
    env_dsn = os.environ.get("SENTRY_INGEST_URL")
    if env_dsn:
        return env_dsn.rstrip("/")
    cfg = load_local_config()
    if cfg.get("dsn"):
        return str(cfg["dsn"]).rstrip("/")
    return DEFAULT_DSN
