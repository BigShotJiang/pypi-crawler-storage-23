"""
Sentry Logger SDK - Push logs from your Python app to the Sentry dashboard.
"""
from __future__ import annotations

from typing import Optional

from .handler import SentryLogHandler, capture_print_statements, capture_unhandled_exceptions
from .config import SentryLoggerConfig
from .local_config import load_local_config, resolve_dsn, resolve_api_key

__all__ = ["SentryLogHandler", "SentryLoggerConfig", "init"]


def init(
    api_key: Optional[str] = None,
    dsn: Optional[str] = None,
    batch_size: int = 50,
    flush_interval_seconds: float = 5.0,
    redirect_print: bool = True,
    capture_exceptions: bool = True,
) -> SentryLogHandler:
    """
    Initialize Sentry Logger and attach it to the root Python logger.

    One call at the top of main.py is all you need — you do NOT have to change
    any other file or add logging.xxx() calls anywhere:

    - Every ``logging.*`` call in every module is captured automatically.
    - Every uvicorn/gunicorn request line is captured (they use Python logging).
    - Every ``print()`` statement is captured (redirect_print=True by default).
    - Every unhandled exception is logged as CRITICAL (capture_exceptions=True).

    Args:
        api_key:   Your Sentry API key. If omitted, reads from the local config
                   file written by ``sentry-logger init`` (~/.sentry_logger/config.json).
        dsn:       Backend base URL. If omitted, uses the production endpoint or
                   the value saved by the CLI. Override with SENTRY_INGEST_URL env var.
        batch_size: Logs to buffer before flushing (default 50).
        flush_interval_seconds: Seconds between automatic flushes (default 5).
        redirect_print: Route print()/stdout/stderr through logging so they are
                        captured automatically (default True).
        capture_exceptions: Log unhandled exceptions as CRITICAL before the
                            process exits (default True).

    Returns:
        SentryLogHandler — attach to specific loggers if needed.

    Example (zero-change integration):
        >>> from sentry_logger import init
        >>> init()   # drop this at the top of main.py — nothing else to change
    """
    import logging

    resolved_dsn = resolve_dsn(dsn)
    api_key = resolve_api_key(api_key)

    if not api_key:
        import sys
        print(
            "[sentry-logger] No API key found — monitoring is disabled.\n"
            "  Run `sentry-logger init --app-name <your-app>` to link this app,\n"
            "  or set the SENTRY_API_KEY environment variable.",
            file=sys.stderr,
        )
        # Return a no-op so the app continues running without monitoring
        import logging
        return logging.NullHandler()  # type: ignore[return-value]

    # Also pick up dsn from local config if not overridden
    if not dsn:
        from .local_config import load_local_config as _load
        cfg = _load()
        if cfg.get("dsn"):
            resolved_dsn = str(cfg["dsn"]).rstrip("/")

    config = SentryLoggerConfig(
        api_key=api_key,
        batch_size=batch_size,
        flush_interval_seconds=flush_interval_seconds,
        _backend_url=resolved_dsn,
    )
    handler = SentryLogHandler(config)
    logging.getLogger().addHandler(handler)
    logging.getLogger().setLevel(logging.INFO)

    if redirect_print:
        capture_print_statements()

    if capture_exceptions:
        capture_unhandled_exceptions()

    return handler
