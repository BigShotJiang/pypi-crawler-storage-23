"""Configuration for Sentry Logger SDK."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class SentryLoggerConfig:
    api_key: str
    batch_size: int = 50
    flush_interval_seconds: float = 5.0

    # Internal - URL is set via environment variable or resolved from local config
    _backend_url: Optional[str] = field(default=None, repr=False)

    def __post_init__(self):
        if not self._backend_url:
            self._backend_url = os.environ.get(
                "SENTRY_INGEST_URL",
                "https://api.sentrylabs.live",
            )
        self._backend_url = self._backend_url.rstrip("/")
        self.ingest_url = f"{self._backend_url}/ingest"
