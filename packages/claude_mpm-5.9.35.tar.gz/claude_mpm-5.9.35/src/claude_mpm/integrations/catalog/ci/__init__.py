"""CI validation package for integration catalog."""
