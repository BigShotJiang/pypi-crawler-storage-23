"""Phaxor — DC Motor Engine (Python port)"""
import math

def solve_dc_motor(inputs: dict) -> dict | None:
    """DC Motor/Generator Calculator."""
    v = float(inputs.get('voltage', 0))
    ia = float(inputs.get('current', 0))
    ra = float(inputs.get('resistance', 0))
    n = float(inputs.get('speed', 0))
    mode = inputs.get('mode', 'motor')

    if v <= 0 or ia <= 0:
        return None

    eb = 0.0
    p_in = 0.0
    p_out = 0.0

    if mode == 'motor':
        # Eb = V - IaRa
        eb = v - (ia * ra)
        p_in = v * ia
        p_out = eb * ia
    else:
        # Generator: Eg = V + IaRa
        eb = v + (ia * ra)
        p_in = eb * ia
        p_out = v * ia

    cu_loss = ia * ia * ra
    efficiency = (p_out / p_in * 100) if p_in > 0 else 0

    # Torque
    power_for_torque = p_out if mode == 'motor' else p_in
    w = (2 * math.pi * n) / 60
    t = power_for_torque / w if w > 0 else 0

    hp = p_out / 746.0

    return {
        'Eb': float(f"{eb:.2f}"),
        'P_in': float(f"{p_in:.2f}"),
        'P_out': float(f"{p_out:.2f}"),
        'efficiency': float(f"{efficiency:.2f}"),
        'cuLoss': float(f"{cu_loss:.2f}"),
        'T': float(f"{t:.2f}"),
        'HP': float(f"{hp:.2f}")
    }
