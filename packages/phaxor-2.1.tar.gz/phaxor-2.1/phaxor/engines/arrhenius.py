"""Phaxor — Arrhenius Engine (Python port)"""
import math

R_GAS = 8.314

def solve_arrhenius(inputs: dict) -> dict | None:
    """Arrhenius Equation Calculator."""
    a = float(inputs.get('A', 0))
    ea = float(inputs.get('Ea', 0))
    t1 = float(inputs.get('T1', 0))
    t2 = float(inputs.get('T2', 0))

    if a <= 0 or ea <= 0 or t1 <= 0:
        return None

    k1 = a * math.exp(-ea / (R_GAS * t1))
    k2 = a * math.exp(-ea / (R_GAS * t2)) if t2 > 0 else 0
    ratio = k2 / k1 if (k2 > 0 and k1 > 0) else 0

    slope = -ea / R_GAS
    half_life = math.log(2) / k1 if k1 > 0 else 0

    plot_data = []
    t_min = max(200, t1 - 200)
    t_max = max(t2 + 200, t1 + 200) if t2 > 0 else t1 + 400
    step = (t_max - t_min) / 50

    curr_t = t_min
    while curr_t <= t_max:
        if curr_t > 0:
            k_val = a * math.exp(-ea / (R_GAS * curr_t))
            plot_data.append({
                'invT': float(f"{1000/curr_t:.4f}"),
                'lnk': float(f"{math.log(k_val):.3f}"),
                'T': int(curr_t)
            })
        curr_t += step

    return {
        'k1': k1,
        'k2': k2,
        'ratio': float(f"{ratio:.2f}"),
        'slope': float(f"{slope:.2f}"),
        'halfLife1st': half_life,
        'plotData': plot_data
    }
