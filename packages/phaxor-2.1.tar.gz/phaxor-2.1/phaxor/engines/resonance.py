"""Phaxor — Resonance Engine (Python port)"""
import math

def solve_resonance(inputs: dict) -> dict | None:
    """RLC Resonance Calculator."""
    r = float(inputs.get('R', 10))
    l_mh = float(inputs.get('L', 1))
    c_uf = float(inputs.get('C', 10))
    c_type = inputs.get('circuitType', 'series')

    r = max(0.0001, r)
    l = l_mh / 1000.0
    c = c_uf * 1e-6

    if l <= 0 or c <= 0:
        return None

    f_res = 1 / (2 * math.pi * math.sqrt(l * c))
    omega_res = 2 * math.pi * f_res
    xl_res = omega_res * l
    xc_res = 1 / (omega_res * c)

    q = 0.0
    if c_type == 'series':
        q = xl_res / r
    else:
        q = r / xl_res
    
    bw = f_res / q if q > 0 else 0
    f_low = max(0.0, f_res - bw / 2)
    f_high = f_res + bw / 2

    z_res = 0.0
    if c_type == 'series':
        z_res = r
    else:
        z_res = l / (r * c)

    zeta = 0.0
    if c_type == 'series':
        zeta = r / (2 * math.sqrt(l / c))
    else:
        # Parallel zeta = 1 / (2R * sqrt(C/L))
        zeta = 1 / (2 * r * math.sqrt(c / l))

    if zeta < 1:
        damping_type = 'Underdamped'
    elif abs(zeta - 1) < 0.001:
        damping_type = 'Critically Damped'
    else:
        damping_type = 'Overdamped'

    return {
        'fRes': float(f"{f_res:.2f}"),
        'omegaRes': float(f"{omega_res:.2f}"),
        'XL_res': float(f"{xl_res:.2f}"),
        'XC_res': float(f"{xc_res:.2f}"),
        'Zres': float(f"{z_res:.2f}"),
        'Q': float(f"{q:.2f}"),
        'BW': float(f"{bw:.2f}"),
        'fLow': float(f"{f_low:.2f}"),
        'fHigh': float(f"{f_high:.2f}"),
        'zeta': float(f"{zeta:.4f}"),
        'dampingType': damping_type
    }
