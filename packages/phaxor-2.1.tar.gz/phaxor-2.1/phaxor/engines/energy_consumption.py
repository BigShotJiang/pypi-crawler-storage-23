"""Phaxor — Energy Consumption Engine (Python port)"""

def solve_energy_consumption(inputs: dict) -> dict | None:
    """Energy Consumption Calculator."""
    appliances = inputs.get('appliances', [])
    rate = float(inputs.get('ratePerUnit', 0))
    days = float(inputs.get('daysPerMonth', 30))

    if not appliances:
        return None

    processed_items = []
    total_daily_kwh = 0.0

    for a in appliances:
        watt = float(a.get('watt', 0))
        hrs = float(a.get('hrs', 0))
        qty = float(a.get('qty', 1))
        
        daily_kwh = (watt * hrs * qty) / 1000.0
        monthly_kwh = daily_kwh * days
        monthly_cost = monthly_kwh * rate
        
        processed_items.append({
            'id': a.get('id'),
            'dailyKWh': float(f"{daily_kwh:.3f}"),
            'monthlyKWh': float(f"{monthly_kwh:.2f}"),
            'monthlyCost': float(f"{monthly_cost:.2f}")
        })
        total_daily_kwh += daily_kwh

    total_monthly_kwh = sum(i['monthlyKWh'] for i in processed_items)
    total_yearly_kwh = total_monthly_kwh * 12
    total_monthly_cost = total_monthly_kwh * rate
    total_yearly_cost = total_yearly_kwh * rate
    co2 = total_yearly_kwh * 0.82

    return {
        'items': processed_items,
        'totalDailyKWh': float(f"{total_daily_kwh:.2f}"),
        'totalMonthlyKWh': float(f"{total_monthly_kwh:.2f}"),
        'totalYearlyKWh': int(round(total_yearly_kwh)),
        'totalMonthlyCost': int(round(total_monthly_cost)),
        'totalYearlyCost': int(round(total_yearly_cost)),
        'co2YearlyKg': int(round(co2))
    }
