"""Phaxor — Electrical Efficiency Engine (Python port)"""
import math

def solve_electrical_efficiency(inputs: dict) -> dict | None:
    """Electrical Efficiency Calculator."""
    p_in = float(inputs.get('inputPower', 0))
    p_out_input = float(inputs.get('outputPower', 0))
    cu = float(inputs.get('copperLoss', 0))
    fe = float(inputs.get('ironLoss', 0))
    mech = float(inputs.get('mechLoss', 0))
    stray = float(inputs.get('strayLoss', 0))

    if p_in <= 0:
        return None

    cu = max(0.0, cu)
    fe = max(0.0, fe)
    mech = max(0.0, mech)
    stray = max(0.0, stray)

    total_loss = cu + fe + mech + stray
    calc_p_out = p_in - total_loss

    # Use outputPower if provided > 0, else calculated
    if p_out_input > 0:
        p_out = p_out_input
    else:
        p_out = calc_p_out

    efficiency = (p_out / p_in) * 100

    # Max efficiency load estimate (relative to current Cu loss being full load)
    # UI logic: sqrt(Fe / Cu) * 100
    if fe > 0 and cu > 0:
        max_eff_load = math.sqrt(fe / cu) * 100
    else:
        max_eff_load = 0.0

    rating = 'Below Standard'
    if efficiency > 95:
        rating = 'IE4 Super Premium'
    elif efficiency > 92:
        rating = 'IE3 Premium'
    elif efficiency > 88:
        rating = 'IE2 High'
    elif efficiency > 80:
        rating = 'IE1 Standard'

    return {
        'efficiency': float(f"{efficiency:.2f}"),
        'totalLoss': float(f"{total_loss:.2f}"),
        'inputPower': float(f"{p_in:.2f}"),
        'outputPower': float(f"{p_out:.2f}"),
        'maxEffLoad': float(f"{max_eff_load:.2f}"),
        'rating': rating
    }
