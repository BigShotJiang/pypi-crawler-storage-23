import math

def solve_earth_pressure(inputs):
    try:
        theory = inputs.get('theory', 'rankine')
        type = inputs.get('type', 'active')
        phiV = float(inputs.get('phi', 0))
        cV = float(inputs.get('c', 0))
        gammaV = float(inputs.get('gamma', 0))
        Hv = float(inputs.get('H', 0))
        qV = float(inputs.get('surcharge', 0))
        deltaV = float(inputs.get('delta', 0))
        betaV = float(inputs.get('beta', 0))
        alphaV = float(inputs.get('alpha', 90))

        if Hv == 0 or gammaV == 0:
            return {'error': 'Invalid input parameters'}

        phiRad = math.radians(phiV)
        betaRad = math.radians(betaV)
        deltaRad = math.radians(deltaV)

        K = 0

        if type == 'at-rest':
            K = 1 - math.sin(phiRad)
        elif theory == 'rankine':
            if type == 'active':
                if betaV == 0:
                    K = math.tan(math.radians(45 - phiV/2))**2
                else:
                    cosBeta = math.cos(betaRad)
                    cosPhi = math.cos(phiRad)
                    sqrtTerm = math.sqrt(cosBeta**2 - cosPhi**2)
                    K = cosBeta * (cosBeta - sqrtTerm) / (cosBeta + sqrtTerm)
            else:
                 K = math.tan(math.radians(45 + phiV/2))**2
        else:
            # Coulomb
            alphaRad = math.radians(alphaV)
            if type == 'active':
                num = math.sin(alphaRad + phiRad)**2
                
                sqrtNumer = math.sin(phiRad + deltaRad) * math.sin(phiRad - betaRad)
                sqrtDenom = math.sin(alphaRad - deltaRad) * math.sin(alphaRad + betaRad)
                
                ratio = 0
                if sqrtDenom != 0: ratio = sqrtNumer / sqrtDenom
                if ratio < 0: ratio = 0
                
                term = 1 + math.sqrt(ratio)
                denom = (math.sin(alphaRad)**2) * math.sin(alphaRad - deltaRad) * (term**2)
                
                K = num / denom if denom > 0 else 0.33
            else:
                num = math.sin(alphaRad - phiRad)**2
                
                sqrtNumer = math.sin(phiRad + deltaRad) * math.sin(phiRad + betaRad)
                sqrtDenom = math.sin(alphaRad + deltaRad) * math.sin(alphaRad + betaRad)
                
                ratio = 0
                if sqrtDenom != 0: ratio = sqrtNumer / sqrtDenom
                if ratio < 0: ratio = 0
                
                term = 1 - math.sqrt(ratio)
                denom = (math.sin(alphaRad)**2) * math.sin(alphaRad + deltaRad) * (term**2)
                
                K = num / denom if denom > 0 else 3.0

        # Cohesion
        cohesionTerm = -2 * cV * math.sqrt(K) if type == 'active' else 2 * cV * math.sqrt(K)

        pTop = K * qV + (cohesionTerm if type != 'passive' else 0)
        pBot = K * (gammaV * Hv + qV) + cohesionTerm

        Psurcharge = K * qV * Hv
        Psoil = 0.5 * K * gammaV * Hv * Hv
        Pcohesion = cohesionTerm * Hv
        Ptotal = Psurcharge + Psoil + Pcohesion

        Mcalc = Psurcharge * Hv / 2 + Psoil * Hv / 3 + Pcohesion * Hv / 2
        la = Mcalc / Ptotal if Ptotal != 0 else Hv / 3
        Mot = abs(Ptotal) * la

        return {
            'result': {
                'K': K,
                'pTop': abs(pTop),
                'pBot': abs(pBot),
                'Ptotal': abs(Ptotal),
                'la': abs(la),
                'Mot': Mot,
                'Psurcharge': abs(Psurcharge),
                'Psoil': abs(Psoil),
                'Pcohesion': Pcohesion,
                'pTopRaw': pTop,
                'pBotRaw': pBot
            }
        }
    except Exception as e:
        return {'error': str(e)}
