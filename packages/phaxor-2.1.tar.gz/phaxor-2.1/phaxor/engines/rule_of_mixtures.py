"""Phaxor — Rule of Mixtures Engine (Python port)"""
import math

def solve_rule_of_mixtures(inputs: dict) -> dict | None:
    """Rule of Mixtures Calculator."""
    ef = float(inputs.get('Ef', 0))
    em = float(inputs.get('Em', 0))
    vf = float(inputs.get('Vf', 0))
    rho_f = float(inputs.get('rhoF', 0))
    rho_m = float(inputs.get('rhoM', 0))
    sig_f = float(inputs.get('sigF', 0))
    sig_m = float(inputs.get('sigM', 0))

    if ef <= 0 or em <= 0 or not (0 <= vf <= 1):
        return None

    vm = 1.0 - vf

    # Voigt
    e1 = ef * vf + em * vm
    # Reuss
    e2 = 1.0 / (vf / ef + vm / em)
    # Halpin-Tsai (xi=2)
    xi = 2.0
    eta = ((ef / em) - 1) / ((ef / em) + xi)
    e2_ht = em * (1 + xi * eta * vf) / (1 - eta * vf)

    rho_c = rho_f * vf + rho_m * vm
    sig_c = sig_f * vf + sig_m * vm
    
    spec_e = e1 / rho_c if rho_c > 0 else 0
    spec_sig = sig_c / rho_c if rho_c > 0 else 0

    return {
        'E1': float(f"{e1:.2f}"),
        'E2': float(f"{e2:.2f}"),
        'E2_HT': float(f"{e2_ht:.2f}"),
        'rhoC': float(f"{rho_c:.3f}"),
        'sigC': float(f"{sig_c:.0f}"),
        'specE': float(f"{spec_e:.2f}"),
        'specSig': float(f"{spec_sig:.2f}")
    }
