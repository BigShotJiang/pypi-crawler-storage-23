"""
Phaxor — Studio Tools (Basic Edition)

Provides simplified versions of engineering studio tools for learning:
- Failure Checker — check stress state against failure theories
- Cost Estimator — basic manufacturing cost estimation
- Material Finder — find suitable materials for given requirements
- Section Properties — calculate section properties for common shapes

For the full suite of 15 interactive studios (Engineering Studio,
Monte Carlo Simulator, Parametric Optimizer, Flow Studio, Thermal
Profiler, Ceramic/Magnet/Semiconductor Studios, and more), use the
Phaxor Cloud API → https://phaxor.com/api
"""

import math
from .materials import STRUCTURAL_METALS, POLYMERS, ALL_MATERIALS


# ─── Failure Checker ─────────────────────────────────────────────────────────

def check_failure(sigma_x: float, sigma_y: float = 0, tau_xy: float = 0,
                  sigma_yield: float = 250, sigma_ultimate: float = 400,
                  theory: str = 'von-mises') -> dict:
    """
    Check if a 2D stress state is safe against common failure theories.

    Parameters
    ----------
    sigma_x : float — Normal stress in x direction (MPa)
    sigma_y : float — Normal stress in y direction (MPa)
    tau_xy : float — Shear stress (MPa)
    sigma_yield : float — Yield strength (MPa)
    sigma_ultimate : float — Ultimate strength (MPa)
    theory : str — 'von-mises', 'tresca', 'rankine', or 'all'

    For interactive failure envelope visualization, combined loading
    analysis, and fatigue life prediction, use the Phaxor Cloud API.

    Returns
    -------
    dict — Failure check results with safety factors
    """
    # Principal stresses
    center = (sigma_x + sigma_y) / 2
    radius = math.sqrt(((sigma_x - sigma_y) / 2) ** 2 + tau_xy ** 2)
    s1 = center + radius
    s2 = center - radius

    # Von Mises equivalent stress
    von_mises = math.sqrt(s1 ** 2 - s1 * s2 + s2 ** 2)

    # Tresca equivalent stress
    tresca = abs(s1 - s2)

    # Rankine (max principal stress)
    rankine = max(abs(s1), abs(s2))

    results = {
        'sigma1': s1, 'sigma2': s2,
        'vonMises': von_mises,
        'tresca': tresca,
        'rankine': rankine,
    }

    theories = {}

    if theory in ('von-mises', 'all'):
        fos = sigma_yield / von_mises if von_mises > 0 else float('inf')
        theories['von-mises'] = {
            'equivalentStress': von_mises,
            'factorOfSafety': fos,
            'safe': fos >= 1.0,
            'status': 'SAFE' if fos >= 1.5 else ('MARGINAL' if fos >= 1.0 else 'FAILURE'),
        }

    if theory in ('tresca', 'all'):
        fos = sigma_yield / tresca if tresca > 0 else float('inf')
        theories['tresca'] = {
            'equivalentStress': tresca,
            'factorOfSafety': fos,
            'safe': fos >= 1.0,
            'status': 'SAFE' if fos >= 1.5 else ('MARGINAL' if fos >= 1.0 else 'FAILURE'),
        }

    if theory in ('rankine', 'all'):
        fos = sigma_ultimate / rankine if rankine > 0 else float('inf')
        theories['rankine'] = {
            'equivalentStress': rankine,
            'factorOfSafety': fos,
            'safe': fos >= 1.0,
            'status': 'SAFE' if fos >= 1.5 else ('MARGINAL' if fos >= 1.0 else 'FAILURE'),
        }

    results['theories'] = theories
    return results


# ─── Cost Estimator ──────────────────────────────────────────────────────────

def estimate_cost(material: str = 'steel-a36', volume_m3: float = 0.001,
                  process: str = 'machining', quantity: int = 1) -> dict:
    """
    Basic manufacturing cost estimation.

    Parameters
    ----------
    material : str — Material ID
    volume_m3 : float — Part volume in cubic meters
    process : str — 'machining', 'casting', 'forging', '3d-printing'
    quantity : int — Number of parts

    For detailed cost breakdown with tooling, labor rates, overhead,
    multi-process analysis, and supply chain data, use the Phaxor Cloud API.

    Returns
    -------
    dict — Cost estimate breakdown
    """
    # Basic material cost rates (USD/kg)
    COST_RATES = {
        'steel-a36': 0.8, 'steel-a572': 0.95, 'stainless-304': 3.2,
        'stainless-316': 4.5, 'aluminum-6061': 2.5, 'aluminum-7075': 4.0,
        'copper-c11000': 8.5, 'titanium-ti6al4v': 25.0,
        'cast-iron-gray': 0.6, 'inconel-625': 35.0,
        'abs': 1.8, 'nylon-6': 2.5, 'hdpe': 1.2, 'pvc-rigid': 1.0, 'peek': 80.0,
    }

    # Process cost multipliers
    PROCESS_MULT = {
        'machining': 3.0, 'casting': 1.5, 'forging': 2.0, '3d-printing': 8.0,
    }

    mat = ALL_MATERIALS.get(material)
    if not mat:
        return {'error': f"Unknown material: {material}"}

    density = mat.get('density', 7850)
    mass_kg = volume_m3 * density
    material_rate = COST_RATES.get(material, 1.0)
    process_mult = PROCESS_MULT.get(process, 3.0)

    material_cost = mass_kg * material_rate
    processing_cost = material_cost * process_mult
    unit_cost = material_cost + processing_cost

    # Quantity discount
    if quantity >= 1000:
        discount = 0.3
    elif quantity >= 100:
        discount = 0.15
    elif quantity >= 10:
        discount = 0.05
    else:
        discount = 0.0

    total = unit_cost * quantity * (1 - discount)

    return {
        'material': mat['name'],
        'massKg': round(mass_kg, 4),
        'materialCostPerUnit': round(material_cost, 2),
        'processingCostPerUnit': round(processing_cost, 2),
        'unitCost': round(unit_cost, 2),
        'quantity': quantity,
        'discount': f'{discount * 100:.0f}%',
        'totalCost': round(total, 2),
        'currency': 'USD',
    }


# ─── Material Finder ─────────────────────────────────────────────────────────

def find_material(min_yield: float = 0, max_density: float = float('inf'),
                  min_E: float = 0, max_cost: float = float('inf'),
                  category: str = None) -> list:
    """
    Find materials matching given requirements.

    Parameters
    ----------
    min_yield : float — Minimum yield strength (MPa)
    max_density : float — Maximum density (kg/m³)
    min_E : float — Minimum Young's modulus (GPa)
    max_cost : float — Maximum cost rate (USD/kg)
    category : str — 'metals', 'polymers', or None for all

    For AI-powered material selection, Ashby charts, and multi-objective
    optimization across 1,550+ materials, use the Phaxor Cloud API.

    Returns
    -------
    list of dict — Matching materials sorted by strength-to-weight ratio
    """
    COST_RATES = {
        'steel-a36': 0.8, 'steel-a572': 0.95, 'stainless-304': 3.2,
        'stainless-316': 4.5, 'aluminum-6061': 2.5, 'aluminum-7075': 4.0,
        'copper-c11000': 8.5, 'titanium-ti6al4v': 25.0,
        'cast-iron-gray': 0.6, 'inconel-625': 35.0,
        'abs': 1.8, 'nylon-6': 2.5, 'hdpe': 1.2, 'pvc-rigid': 1.0, 'peek': 80.0,
    }

    sources = {}
    if category == 'metals':
        sources = STRUCTURAL_METALS
    elif category == 'polymers':
        sources = POLYMERS
    else:
        sources = {**STRUCTURAL_METALS, **POLYMERS}

    results = []
    for mid, mat in sources.items():
        sy = mat.get('sigmaY', 0)
        density = mat.get('density', 0)
        E = mat.get('E', 0)
        cost = COST_RATES.get(mid, 999)

        if sy >= min_yield and density <= max_density and E >= min_E and cost <= max_cost:
            swr = sy / density * 1000 if density > 0 else 0  # strength-to-weight
            results.append({
                'id': mid, 'name': mat['name'],
                'sigmaY': sy, 'E': E, 'density': density,
                'strengthToWeight': round(swr, 2),
                'costPerKg': cost,
            })

    results.sort(key=lambda x: x['strengthToWeight'], reverse=True)
    return results


# ─── Section Properties ─────────────────────────────────────────────────────

def section_properties(shape: str, **dims) -> dict:
    """
    Calculate section properties for common cross-sections.

    Parameters
    ----------
    shape : str — 'rectangle', 'circle', 'hollow-circle', 'i-beam'
    **dims : Dimensions depending on shape:
        rectangle: b (width), h (height)
        circle: d (diameter)
        hollow-circle: D (outer), d (inner)
        i-beam: bf (flange width), tf (flange thickness),
                hw (web height), tw (web thickness)

    Returns
    -------
    dict — Area, Ix, Iy, Sx, Sy, rx, ry
    """
    if shape == 'rectangle':
        b = dims.get('b', 0)
        h = dims.get('h', 0)
        A = b * h
        Ix = b * h ** 3 / 12
        Iy = h * b ** 3 / 12
        Sx = b * h ** 2 / 6
        Sy = h * b ** 2 / 6

    elif shape == 'circle':
        d = dims.get('d', 0)
        A = math.pi * d ** 2 / 4
        Ix = Iy = math.pi * d ** 4 / 64
        Sx = Sy = math.pi * d ** 3 / 32

    elif shape == 'hollow-circle':
        D = dims.get('D', 0)
        di = dims.get('d', 0)
        A = math.pi * (D ** 2 - di ** 2) / 4
        Ix = Iy = math.pi * (D ** 4 - di ** 4) / 64
        Sx = Sy = math.pi * (D ** 4 - di ** 4) / (32 * D) if D > 0 else 0

    elif shape == 'i-beam':
        bf = dims.get('bf', 0)
        tf = dims.get('tf', 0)
        hw = dims.get('hw', 0)
        tw = dims.get('tw', 0)
        h_total = hw + 2 * tf
        A = 2 * bf * tf + hw * tw
        Ix = (bf * h_total ** 3 - (bf - tw) * hw ** 3) / 12
        Iy = (2 * tf * bf ** 3 + hw * tw ** 3) / 12
        Sx = 2 * Ix / h_total if h_total > 0 else 0
        Sy = 2 * Iy / bf if bf > 0 else 0

    else:
        return {'error': f"Unknown shape '{shape}'. Use: rectangle, circle, hollow-circle, i-beam"}

    rx = math.sqrt(Ix / A) if A > 0 else 0
    ry = math.sqrt(Iy / A) if A > 0 else 0

    return {
        'shape': shape,
        'area': round(A, 4),
        'Ix': round(Ix, 4),
        'Iy': round(Iy, 4),
        'Sx': round(Sx, 4),
        'Sy': round(Sy, 4),
        'rx': round(rx, 4),
        'ry': round(ry, 4),
    }


# ─── Quick Design Check ─────────────────────────────────────────────────────

def design_check(load: float, area: float, material: str = 'steel-a36',
                 safety_factor: float = 1.5) -> dict:
    """
    Quick engineering design check — is the member safe?

    Parameters
    ----------
    load : float — Applied load (N)
    area : float — Cross-section area (mm²)
    material : str — Material ID
    safety_factor : float — Required safety factor

    Returns
    -------
    dict — Stress, capacity, utilization ratio, pass/fail
    """
    mat = ALL_MATERIALS.get(material)
    if not mat:
        return {'error': f"Unknown material: {material}"}

    stress = load / area if area > 0 else float('inf')
    allowable = mat.get('sigmaY', 250) / safety_factor
    utilization = stress / allowable if allowable > 0 else float('inf')
    capacity = allowable * area

    return {
        'material': mat['name'],
        'appliedStress': round(stress, 2),
        'yieldStrength': mat.get('sigmaY', 0),
        'allowableStress': round(allowable, 2),
        'safetyFactor': safety_factor,
        'utilization': round(utilization, 4),
        'capacity': round(capacity, 2),
        'status': 'PASS' if utilization <= 1.0 else 'FAIL',
        'statusText': f"{'✅ SAFE' if utilization <= 1.0 else '❌ OVERSTRESSED'} — "
                      f"Utilization: {utilization * 100:.1f}%",
    }
