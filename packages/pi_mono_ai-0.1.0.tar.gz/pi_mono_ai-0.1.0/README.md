# pi-ai

Part of [pi-mono-py](https://github.com/your-repo/pi-mono-py).

## Installation

```bash
pip install pi-ai
```

## License

MIT
