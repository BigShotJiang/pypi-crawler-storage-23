# About

"Biased" is a Python package that contains various reusable components, helpers, and utilities 
which I would like to use in any Python project.
