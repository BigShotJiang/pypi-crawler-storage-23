# `/ctx:brainstorm` Snippets

- **Design System Feature** – Focus on `modes/Super_Saiyan.md` + `agents/security-auditor` when accessibility/security are explicit goals.
- **Infrastructure Spike** – Pair brainstorm with `/dev:implement` once high-level strategy is picked; log hypotheses in Task view immediately.

Use these snippets as optional follow-ups after the main skill runs.
