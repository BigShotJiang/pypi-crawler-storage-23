# `/ctx:execute-plan` Checklist

- [ ] Tasks synced in Task view (`T`)
- [ ] Modes/Rules toggled as per plan
- [ ] Verification steps logged (tests, Supersaiyan review)
- [ ] Status update posted after each stream
- [ ] Retrospective note captured in plan doc
