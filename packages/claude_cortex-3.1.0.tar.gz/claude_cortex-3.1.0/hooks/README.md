# Hooks Documentation Moved

This README was relocated to reduce automatic context scanning. Full content now lives at `docs/reference/moved-readmes/hooks.md`.

Hook registration lives in `hooks/hooks.json` (use `${CLAUDE_PLUGIN_ROOT}` for paths).
