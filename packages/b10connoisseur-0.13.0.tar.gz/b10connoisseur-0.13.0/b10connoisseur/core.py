import glob
import os
import re
import socket
import struct
import subprocess
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path


# ---------------------------------------------------------------------------
# Report infrastructure
# ---------------------------------------------------------------------------

SEP = "=" * 78
findings: list[dict] = []


def heading(title: str) -> None:
    print(f"\n{SEP}")
    print(f"  {title}")
    print(SEP)


def finding(severity: str, category: str, title: str, detail: str) -> None:
    findings.append(
        {"severity": severity, "category": category, "title": title, "detail": detail}
    )
    print(f"\n  [{severity}] {title}")
    print(f"  Category: {category}")
    # Truncate very long details for readability
    if len(detail) > 1000:
        detail = detail[:1000] + "\n  ... (truncated)"
    print(f"  Detail:   {detail}")
    print("  ---")


def read_file(path: str, max_bytes: int = 8192) -> str | None:
    try:
        return Path(path).read_text(errors="replace")[:max_bytes]
    except (OSError, PermissionError):
        return None


def run_cmd(cmd: list[str] | str, timeout: int = 10, shell: bool = False) -> str | None:
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            shell=shell,
        )
        out = result.stdout.strip()
        return out if out else None
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return None


def can_reach(host: str, port: int, timeout: float = 3.0) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except (OSError, socket.timeout):
        return False


def resolve_host(hostname: str) -> str | None:
    try:
        return socket.gethostbyname(hostname)
    except socket.gaierror:
        return None


def http_get(url: str, headers: dict | None = None, timeout: float = 3.0) -> tuple[int, str]:
    """Minimal HTTP GET using urllib to avoid external deps."""
    import urllib.request
    import urllib.error

    req = urllib.request.Request(url, headers=headers or {})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read(4096).decode("utf-8", errors="replace")
            return resp.status, body
    except urllib.error.HTTPError as e:
        return e.code, ""
    except Exception:
        return 0, ""


def http_put(url: str, headers: dict | None = None, timeout: float = 3.0) -> tuple[int, str]:
    """Minimal HTTP PUT."""
    import urllib.request
    import urllib.error

    req = urllib.request.Request(url, data=b"", headers=headers or {}, method="PUT")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read(4096).decode("utf-8", errors="replace")
            return resp.status, body
    except urllib.error.HTTPError as e:
        return e.code, ""
    except Exception:
        return 0, ""


# ---------------------------------------------------------------------------
# 1. Identity & Context
# ---------------------------------------------------------------------------

def check_identity():
    heading("1. IDENTITY & CONTEXT")

    uid = os.getuid()
    gid = os.getgid()
    user = os.environ.get("USER", run_cmd(["whoami"]) or "unknown")
    groups = run_cmd(["id"]) or "unknown"

    print(f"  User: {user}  UID: {uid}  GID: {gid}")
    print(f"  Groups: {groups}")

    if uid == 0:
        finding("HIGH", "Identity", "Running as root (UID 0)",
                "Build runs as root. Combined with other findings this may enable escapes.")
    else:
        finding("INFO", "Identity", f"Running as UID {uid}", "Non-root, good.")

    # Passwordless sudo
    sudo_check = run_cmd(["sudo", "-n", "-l"], timeout=5)
    if sudo_check and not re.search(r"not allowed|password|sorry", sudo_check, re.I):
        finding("CRITICAL", "Identity", "Passwordless sudo available", sudo_check)


# ---------------------------------------------------------------------------
# 2. Environment Variables
# ---------------------------------------------------------------------------

def check_env():
    heading("2. ENVIRONMENT VARIABLES")

    print("  --- Full environment ---")
    for k in sorted(os.environ):
        print(f"  {k}={os.environ[k]}")
    print()

    sensitive_re = re.compile(
        r"TOKEN|SECRET|KEY|PASSWORD|CREDENTIAL|AUTH|AWS_|GOOGLE_|AZURE_|KUBE|"
        r"API_KEY|PRIVATE|CERT|DATABASE|DB_|REDIS|MONGO|MYSQL|POSTGRES|"
        r"REGISTRY|DOCKER_|BUILDKIT|GIT_TOKEN|NPM_TOKEN|GITHUB_|GITLAB_|CI_|ARTIFACTORY",
        re.I,
    )

    leaked = {k: v for k, v in os.environ.items() if sensitive_re.search(k)}
    if leaked:
        detail = "\n".join(f"    {k}={v}" for k, v in leaked.items())
        finding("HIGH", "Env Leak", "Sensitive-looking env vars found", detail)
    else:
        finding("INFO", "Env Leak", "No obviously sensitive env vars", "Pattern scan clean.")

    bk_vars = {k: v for k, v in os.environ.items() if re.search(r"BUILDKIT|MOBY|DOCKER_BUILDKIT", k, re.I)}
    if bk_vars:
        detail = "\n".join(f"    {k}={v}" for k, v in bk_vars.items())
        finding("MEDIUM", "Env Leak", "BuildKit metadata exposed", detail)


# ---------------------------------------------------------------------------
# 3. Filesystem Reconnaissance
# ---------------------------------------------------------------------------

def check_filesystem():
    heading("3. FILESYSTEM RECONNAISSANCE")

    # 3a. Mounts
    print("  --- Mount points ---")
    mounts = read_file("/proc/mounts")
    if mounts:
        print(mounts)
    else:
        mount_out = run_cmd(["mount"])
        print(mount_out or "  Cannot enumerate mounts")
    print()

    # Container runtime sockets
    for sock_path in [
        "/var/run/docker.sock",
        "/run/docker.sock",
        "/var/run/containerd/containerd.sock",
    ]:
        if os.path.exists(sock_path):
            finding("CRITICAL", "Filesystem", f"Container runtime socket found: {sock_path}",
                    "Can escape to host, spawn privileged containers, access other builds.")

    # BuildKit state directories
    for bk_path in ["/var/lib/buildkit", "/run/buildkit"]:
        if os.path.isdir(bk_path):
            try:
                contents = run_cmd(["ls", "-la", bk_path])
            except Exception:
                contents = "could not list"
            finding("HIGH", "Filesystem", f"BuildKit state directory accessible: {bk_path}",
                    f"May contain layers/cache from other tenant builds.\n{contents}")

    for bk_glob in glob.glob("/tmp/buildkit*"):
        if os.path.isdir(bk_glob):
            finding("HIGH", "Filesystem", f"BuildKit temp directory: {bk_glob}",
                    "Potential cache or scratch data from BuildKit.")

    # Service account token
    sa_path = "/var/run/secrets/kubernetes.io/serviceaccount"
    if os.path.isdir(sa_path):
        token = read_file(f"{sa_path}/token")
        prefix = (token[:40] + "...") if token else "unreadable"
        finding("CRITICAL", "Filesystem", "Kubernetes service account token mounted",
                f"Path: {sa_path}  Token prefix: {prefix}")
    else:
        finding("INFO", "Filesystem", "No K8s service account token at default path", "Good.")

    # Cloud / K8s credential paths
    cloud_paths = [
        "/var/run/secrets/eks.amazonaws.com",
        "/var/run/secrets/google",
        "/etc/kubernetes",
        "/root/.kube",
        "/root/.aws",
        "/root/.config/gcloud",
    ]
    # Also check home dirs
    for home in glob.glob("/home/*"):
        cloud_paths.extend([f"{home}/.kube", f"{home}/.aws", f"{home}/.config/gcloud"])

    for cp in cloud_paths:
        if os.path.exists(cp):
            contents = run_cmd(["ls", "-laR", cp])
            finding("CRITICAL", "Filesystem", f"Cloud/K8s credential path exists: {cp}",
                    (contents or "exists but could not list")[:500])

    # 3b. World-writable directories
    print("\n  --- World-writable directories (outside /tmp, /proc, /sys) ---")
    ww = run_cmd(
        "find / -maxdepth 4 -type d -writable "
        "! -path '/tmp*' ! -path '/proc*' ! -path '/sys*' ! -path '/dev*' "
        "2>/dev/null | head -30",
        shell=True,
        timeout=15,
    )
    if ww:
        print(ww)

    # 3c. SUID/SGID binaries
    print("\n  --- SUID/SGID binaries ---")
    suid = run_cmd(
        r"find / -maxdepth 5 \( -perm -4000 -o -perm -2000 \) -type f 2>/dev/null | head -20",
        shell=True,
        timeout=15,
    )
    if suid:
        finding("MEDIUM", "Filesystem", "SUID/SGID binaries found", suid)
        print(suid)
    else:
        print("  None found")

    # 3d. /proc exploration
    print("\n  --- /proc exploration ---")
    cmdline = read_file("/proc/1/cmdline")
    if cmdline:
        print(f"  PID 1 cmdline: {cmdline.replace(chr(0), ' ')}")

    cgroup = read_file("/proc/1/cgroup")
    if cgroup:
        print(f"  PID 1 cgroups: {cgroup.strip()}")

    # Visible PIDs
    try:
        pids = [p for p in os.listdir("/proc") if p.isdigit()]
        print(f"  Visible PIDs: {len(pids)}")
        if len(pids) > 10:
            ps_out = run_cmd(["ps", "auxww"]) or "\n".join(pids[:30])
            finding("MEDIUM", "Filesystem", f"Many processes visible ({len(pids)} PIDs)",
                    f"Other build or host processes may be visible.\n{ps_out[:500]}")
    except OSError:
        pass

    # /proc/self/mountinfo — host path leaks
    print("\n  --- /proc/self/mountinfo (host path leak) ---")
    mountinfo = read_file("/proc/self/mountinfo")
    if mountinfo:
        lines = mountinfo.strip().split("\n")[:30]
        for line in lines:
            print(f"  {line}")
        host_paths = re.findall(r"/var/lib/\S+", mountinfo)
        if host_paths:
            finding("MEDIUM", "Filesystem", "Host paths leaked via mountinfo",
                    "\n".join(host_paths[:10]))


# ---------------------------------------------------------------------------
# 4. Capabilities & Security Profile
# ---------------------------------------------------------------------------

# Map of capability bit positions to names (covers the most security-relevant ones)
CAP_NAMES = {
    0: "CAP_CHOWN", 1: "CAP_DAC_OVERRIDE", 2: "CAP_DAC_READ_SEARCH",
    3: "CAP_FOWNER", 5: "CAP_KILL", 6: "CAP_SETGID", 7: "CAP_SETUID",
    8: "CAP_SETPCAP", 10: "CAP_NET_BIND_SERVICE", 12: "CAP_NET_ADMIN",
    13: "CAP_NET_RAW", 14: "CAP_IPC_LOCK", 16: "CAP_SYS_MODULE",
    17: "CAP_SYS_RAWIO", 18: "CAP_SYS_CHROOT", 19: "CAP_SYS_PTRACE",
    21: "CAP_SYS_ADMIN", 22: "CAP_SYS_BOOT", 23: "CAP_SYS_NICE",
    25: "CAP_SYS_TIME", 29: "CAP_AUDIT_WRITE", 37: "CAP_BPF",
    38: "CAP_PERFMON", 39: "CAP_CHECKPOINT_RESTORE",
}

DANGEROUS_CAPS = {
    "CAP_SYS_ADMIN", "CAP_SYS_PTRACE", "CAP_NET_ADMIN", "CAP_NET_RAW",
    "CAP_SYS_MODULE", "CAP_SYS_RAWIO", "CAP_DAC_OVERRIDE", "CAP_SYS_BOOT",
    "CAP_BPF", "CAP_PERFMON", "CAP_DAC_READ_SEARCH",
}


def decode_caps(hex_str: str) -> list[str]:
    """Decode a hex capability bitmask into capability names."""
    value = int(hex_str, 16)
    active = []
    for bit, name in sorted(CAP_NAMES.items()):
        if (value >> bit) & 1:
            active.append(name)
    return active


def check_capabilities():
    heading("4. CAPABILITIES & SECURITY PROFILE")

    status = read_file("/proc/self/status")
    if status:
        print("  --- /proc/self/status capability lines ---")
        for line in status.split("\n"):
            if line.lower().startswith("cap"):
                print(f"  {line}")

    # Decode CapEff
    cap_eff_match = re.search(r"CapEff:\s*([0-9a-fA-F]+)", status or "")
    if cap_eff_match:
        cap_hex = cap_eff_match.group(1)
        active_caps = decode_caps(cap_hex)
        dangerous = [c for c in active_caps if c in DANGEROUS_CAPS]

        print(f"\n  --- Decoded effective capabilities (CapEff={cap_hex}) ---")
        for c in active_caps:
            marker = " [DANGEROUS]" if c in DANGEROUS_CAPS else ""
            print(f"    {c}{marker}")

        if dangerous:
            finding("HIGH", "Capabilities", f"Dangerous capabilities active: {', '.join(dangerous)}",
                    f"CapEff={cap_hex}. These can enable escape or cross-tenant attacks.")
        else:
            finding("INFO", "Capabilities", f"CapEff={cap_hex}", "No obviously dangerous caps detected.")

    # capsh
    capsh = run_cmd(["capsh", "--print"])
    if capsh:
        print(f"\n  --- capsh --print ---\n{capsh}")

    # Seccomp
    seccomp_match = re.search(r"Seccomp:\s*(\d)", status or "")
    if seccomp_match:
        mode = seccomp_match.group(1)
        labels = {"0": "DISABLED", "1": "strict mode", "2": "filter mode (BPF)"}
        label = labels.get(mode, f"unknown ({mode})")
        severity = "MEDIUM" if mode == "0" else "INFO"
        finding(severity, "Seccomp", f"Seccomp {label}",
                "No syscall filtering in place." if mode == "0" else "Filtering active.")

    # LSM
    print("\n  --- LSM profile ---")
    lsm = read_file("/proc/self/attr/current")
    print(f"  {lsm.strip() if lsm else 'No LSM profile readable'}")
    se = run_cmd(["getenforce"])
    print(f"  SELinux: {se or 'not available'}")


# ---------------------------------------------------------------------------
# 5. Namespace & Cgroup Isolation
# ---------------------------------------------------------------------------

def check_namespaces():
    heading("5. NAMESPACE & CGROUP ISOLATION")

    print("  --- Namespace IDs ---")
    ns_out = run_cmd(["ls", "-la", "/proc/self/ns/"])
    if ns_out:
        print(ns_out)

    cmdline = read_file("/proc/1/cmdline")
    if cmdline:
        print(f"\n  PID 1 cmdline: {cmdline.replace(chr(0), ' ')}")
    print(f"  Hostname: {socket.gethostname()}")

    # User namespace check
    uid_map = read_file("/proc/self/uid_map")
    if uid_map:
        print(f"\n  uid_map: {uid_map.strip()}")
        if re.search(r"0\s+0\s+4294967295", uid_map):
            finding("MEDIUM", "Namespace", "Running in init user namespace",
                    "Not rootless BuildKit. UID 0 maps directly to host UID 0.")

    # Cgroup hierarchy
    print("\n  --- Cgroup hierarchy ---")
    cg = read_file("/proc/self/cgroup")
    if cg:
        print(cg)

    # Sibling cgroup enumeration
    for cg_root in ["/sys/fs/cgroup/cpu", "/sys/fs/cgroup/memory", "/sys/fs/cgroup"]:
        if os.path.isdir(cg_root) and os.access(cg_root, os.R_OK):
            siblings = run_cmd(
                f"find {cg_root} -maxdepth 3 -type d 2>/dev/null | "
                f"grep -v '^{cg_root}$' | head -20",
                shell=True,
                timeout=10,
            )
            if siblings:
                finding("MEDIUM", "Namespace", "Can enumerate sibling cgroups",
                        f"May reveal other concurrent builds.\n{siblings[:500]}")
            break


# ---------------------------------------------------------------------------
# 6. Network Reconnaissance
# ---------------------------------------------------------------------------

def get_default_gateway() -> str | None:
    """Parse /proc/net/route for the default gateway."""
    route_data = read_file("/proc/net/route")
    if route_data:
        for line in route_data.strip().split("\n")[1:]:
            fields = line.split()
            if len(fields) >= 3 and fields[1] == "00000000":
                gw_hex = fields[2]
                gw_bytes = struct.pack("<I", int(gw_hex, 16))
                return socket.inet_ntoa(gw_bytes)
    # Fallback to `ip route`
    ip_out = run_cmd(["ip", "route"])
    if ip_out:
        m = re.search(r"default via (\S+)", ip_out)
        if m:
            return m.group(1)
    return None


def check_network():
    heading("6. NETWORK RECONNAISSANCE")

    # Interfaces
    print("  --- Network interfaces ---")
    ifaces = run_cmd(["ip", "addr"]) or run_cmd(["ifconfig"]) or "Cannot enumerate interfaces"
    print(ifaces)

    # Routes
    print("\n  --- Routing table ---")
    routes = run_cmd(["ip", "route"]) or run_cmd(["route", "-n"]) or "Cannot read routes"
    print(routes)

    # DNS
    print("\n  --- DNS config ---")
    resolv = read_file("/etc/resolv.conf")
    print(resolv or "  Cannot read resolv.conf")

    # ARP
    print("\n  --- ARP table ---")
    arp = run_cmd(["ip", "neigh"]) or run_cmd(["arp", "-an"]) or "Cannot read ARP"
    print(arp)

    # 6a. DNS-based discovery
    print("\n  --- DNS discovery ---")
    dns_targets = [
        "kubernetes", "kubernetes.default", "kubernetes.default.svc",
        "kube-dns.kube-system.svc.cluster.local",
        "metadata", "metadata.google.internal",
        "buildkit", "buildkitd", "registry", "docker",
    ]
    for svc in dns_targets:
        resolved = resolve_host(svc)
        if resolved:
            finding("MEDIUM", "Network", f"DNS resolves: {svc}", f"{svc} -> {resolved}")

    # SRV records
    for srv in ["_https._tcp.kubernetes.default.svc", "_http._tcp.kubernetes.default.svc"]:
        srv_result = run_cmd(["dig", "SRV", srv, "+short"], timeout=5)
        if srv_result:
            print(f"  SRV {srv} -> {srv_result}")

    # 6b. Cloud IMDS probing
    print("\n  --- Cloud metadata probing ---")
    imds_targets = [
        ("AWS IMDSv1",  "http://169.254.169.254/latest/meta-data/", {}),
        ("GCP",         "http://169.254.169.254/computeMetadata/v1/", {"Metadata-Flavor": "Google"}),
        ("Azure",       "http://169.254.169.254/metadata/instance?api-version=2021-02-01", {"Metadata": "true"}),
        ("Alibaba",     "http://100.100.100.200/latest/meta-data/", {}),
        ("ECS Task",    "http://169.254.170.2/v2/credentials", {}),
    ]

    for label, url, headers in imds_targets:
        status, body = http_get(url, headers=headers, timeout=3)
        if status == 200:
            finding("CRITICAL", "Network", f"Cloud metadata accessible: {label} (HTTP {status})",
                    f"URL: {url}\nSample: {body[:300]}")

    # AWS IMDSv2
    token_status, token = http_put(
        "http://169.254.169.254/latest/api/token",
        headers={"X-aws-ec2-metadata-token-ttl-seconds": "60"},
        timeout=3,
    )
    if token_status == 200 and token:
        v2_status, v2_body = http_get(
            "http://169.254.169.254/latest/meta-data/",
            headers={"X-aws-ec2-metadata-token": token},
            timeout=3,
        )
        if v2_status == 200:
            finding("CRITICAL", "Network", "AWS IMDSv2 reachable",
                    f"Token obtained. Metadata: {v2_body[:300]}")

    # 6c. Kubelet API
    print("\n  --- Kubelet API probing ---")
    gateway = get_default_gateway()
    if gateway:
        print(f"  Default gateway: {gateway}")
        for port in [10250, 10255, 10248]:
            if can_reach(gateway, port):
                # Try to hit /pods
                status, body = http_get(f"https://{gateway}:{port}/pods", timeout=3)
                finding("CRITICAL", "Network", f"Kubelet port {port} reachable on gateway {gateway}",
                        f"HTTP {status}. Response sample: {body[:300]}")

    # K8s API server
    k8s_ip = resolve_host("kubernetes.default")
    if k8s_ip:
        for port in [443, 6443, 8443]:
            if can_reach(k8s_ip, port):
                status, body = http_get(f"https://{k8s_ip}:{port}/version", timeout=3)
                finding("HIGH", "Network", f"K8s API server reachable at {k8s_ip}:{port}",
                        f"HTTP {status}. Response: {body[:300]}")

    # 6d. Local subnet service scan
    print("\n  --- Local subnet service scan ---")
    if gateway:
        subnet_prefix = ".".join(gateway.split(".")[:3]) + "."
        scan_ports = [2379, 2380, 5432, 3306, 6379, 8080, 8443, 9090, 9093, 9200, 27017, 4194]
        scan_offsets = [1, 2, 3, 10, 100]
        for port in scan_ports:
            for offset in scan_offsets:
                target = f"{subnet_prefix}{offset}"
                if can_reach(target, port):
                    finding("HIGH", "Network", f"Service reachable: {target}:{port}",
                            f"Port {port} often = etcd/postgres/mysql/redis/prometheus/elasticsearch")


# ---------------------------------------------------------------------------
# 7. Kernel & Host Information
# ---------------------------------------------------------------------------

def check_kernel():
    heading("7. KERNEL & HOST INFORMATION")

    uname = run_cmd(["uname", "-a"]) or "unknown"
    kver = run_cmd(["uname", "-r"]) or "unknown"
    print(f"  Kernel: {uname}")
    print(f"  Kernel version: {kver}")

    finding("LOW", "Kernel", f"Kernel version: {kver}",
            "Check for known container escape CVEs "
            "(e.g., CVE-2022-0185, CVE-2022-0847 Dirty Pipe, CVE-2024-1086, CVE-2024-21626).")

    print("\n  --- /etc/os-release ---")
    os_release = read_file("/etc/os-release")
    print(os_release or "  Not available")

    core_pattern = read_file("/proc/sys/kernel/core_pattern")
    if core_pattern:
        print(f"\n  Core pattern: {core_pattern.strip()}")

    print("\n  --- Loaded kernel modules (first 20) ---")
    modules = read_file("/proc/modules")
    if modules:
        for line in modules.strip().split("\n")[:20]:
            print(f"  {line}")
    else:
        print("  Cannot read modules")


# ---------------------------------------------------------------------------
# 8. Persistence & Cross-Tenant Attack Vectors
# ---------------------------------------------------------------------------

def check_persistence():
    heading("8. PERSISTENCE & CROSS-TENANT ATTACK VECTORS")

    print("  Checking for persistence and cross-build contamination vectors...")

    # 8a. BuildKit cache/layer store
    cache_paths = [
        "/var/lib/buildkit/runc-overlayfs",
        "/var/lib/buildkit/containerd",
        "/var/lib/buildkit",
        "/var/lib/docker/overlay2",
        "/var/lib/containerd",
    ]
    for cp in cache_paths:
        if os.path.isdir(cp):
            dir_count = run_cmd(f"find {cp} -maxdepth 3 -type d 2>/dev/null | wc -l",
                                shell=True, timeout=10)
            finding("CRITICAL", "Persistence",
                    f"Build layer storage accessible: {cp} ({dir_count or '?'} dirs)",
                    "If writable, can poison layers that end up in other tenant images.")

    # 8b. Shared temp dirs
    print("\n  --- Checking shared temp dirs for cross-build leakage ---")
    for tmp in ["/tmp", "/var/tmp", "/dev/shm"]:
        if os.path.isdir(tmp):
            try:
                items = os.listdir(tmp)
                if items:
                    listing = run_cmd(["ls", "-la", tmp])
                    finding("MEDIUM", "Persistence",
                            f"Pre-existing files in {tmp} ({len(items)} items)",
                            f"Could be artifacts from prior builds (cross-tenant leak).\n{(listing or '')[:400]}")
            except OSError:
                pass

    # 8c. /dev/shm writable
    if os.path.isdir("/dev/shm") and os.access("/dev/shm", os.W_OK):
        finding("MEDIUM", "Persistence", "/dev/shm is writable",
                "If shared across builds, can be used for cross-build data exfil or signaling.")

    # 8d. Writable system paths (supply chain poisoning)
    poison_globs = [
        "/usr/local/lib/python*/dist-packages",
        "/usr/lib/python*/dist-packages",
        "/usr/local/lib/node_modules",
        "/usr/share/ca-certificates",
        "/etc/ssl/certs",
        "/usr/local/bin",
    ]
    for pattern in poison_globs:
        for p in glob.glob(pattern):
            if os.path.isdir(p) and os.access(p, os.W_OK):
                finding("HIGH", "Persistence", f"Writable system path: {p}",
                        "A malicious RUN step could plant a backdoored library or CA cert "
                        "that persists in the image layer and affects downstream builds.")

    # 8e. Outbound connectivity
    print("\n  --- Outbound connectivity test ---")
    for host, port in [("1.1.1.1", 53), ("8.8.8.8", 53), ("1.1.1.1", 443)]:
        if can_reach(host, port):
            finding("LOW", "Network", f"Outbound to {host}:{port} allowed",
                    "Egress possible. A malicious build can exfiltrate data or download payloads.")

    # 8f. Git config / credential helpers
    git_config = run_cmd(["git", "config", "--list", "--global"])
    git_sys = run_cmd(["git", "config", "--list", "--system"])
    combined = "\n".join(filter(None, [git_config, git_sys]))
    if combined:
        finding("MEDIUM", "Persistence", "Git config present", combined)

    git_cred = run_cmd(["git", "config", "--get", "credential.helper"])
    if git_cred:
        finding("HIGH", "Persistence", f"Git credential helper configured: {git_cred}",
                "May contain or cache tokens for repository access.")

    # 8g. Writable BuildKit/Docker config
    for fe_path in ["/etc/buildkit", "/etc/docker"]:
        if os.path.isdir(fe_path) and os.access(fe_path, os.W_OK):
            finding("CRITICAL", "Persistence", f"Writable BuildKit/Docker config: {fe_path}",
                    "Could inject custom frontend or daemon config affecting all future builds.")


# ---------------------------------------------------------------------------
# 9. BuildKit-Specific Checks
# ---------------------------------------------------------------------------

def check_buildkit():
    heading("9. BUILDKIT-SPECIFIC CHECKS")

    for binary in ["buildctl", "buildkitd"]:
        bin_path = run_cmd(["which", binary])
        if bin_path:
            version = run_cmd([bin_path, "--version"]) or "unknown"
            finding("MEDIUM", "BuildKit", f"{binary} found at {bin_path}",
                    f"Version: {version}")

    for sock in ["/run/buildkit/buildkitd.sock", "/var/run/buildkit/buildkitd.sock"]:
        if os.path.exists(sock):
            finding("CRITICAL", "BuildKit", f"BuildKit daemon socket accessible: {sock}",
                    "Can use buildctl to list/inspect other builds, access cache, manipulate outputs.")

    pid1_cmd = read_file("/proc/1/cmdline")
    if pid1_cmd and re.search(r"buildkit|runc|executor", pid1_cmd, re.I):
        finding("INFO", "BuildKit", "PID 1 suggests BuildKit executor",
                pid1_cmd.replace("\x00", " "))


# ---------------------------------------------------------------------------
# 10. Additional Creative Checks
# ---------------------------------------------------------------------------

def check_creative():
    heading("10. ADDITIONAL CREATIVE CHECKS")

    # 10a. OverlayFS upper directories
    mountinfo = read_file("/proc/self/mountinfo")
    if mountinfo:
        overlays = [l for l in mountinfo.split("\n") if "overlay" in l]
        if overlays:
            print("  OverlayFS mounts:")
            for o in overlays:
                print(f"    {o}")
            upper_dirs = re.findall(r"upperdir=([^,\s]+)", mountinfo)
            for ud in upper_dirs[:5]:
                if os.path.isdir(ud) and os.access(ud, os.W_OK):
                    finding("HIGH", "Filesystem", f"Writable OverlayFS upperdir: {ud}",
                            "Writing here modifies the layer directly. Could tamper with build output.")

    # 10b. /proc/sysrq-trigger
    if os.access("/proc/sysrq-trigger", os.W_OK):
        finding("CRITICAL", "Kernel", "/proc/sysrq-trigger is writable",
                "Can crash/reboot the host node (DoS all tenants).")

    # 10c. /proc/kcore
    if os.access("/proc/kcore", os.R_OK):
        finding("CRITICAL", "Kernel", "/proc/kcore is readable",
                "Full host physical memory is readable. Can extract any secret from any process.")

    # 10d. Device nodes
    print("\n  --- Accessible device nodes ---")
    dev_out = run_cmd(["ls", "-la", "/dev/"])
    if dev_out:
        for line in dev_out.split("\n")[:30]:
            print(f"  {line}")

    for dev in ["/dev/sda", "/dev/sda1", "/dev/vda", "/dev/nvme0n1", "/dev/xvda"]:
        if os.access(dev, os.R_OK):
            finding("CRITICAL", "Filesystem", f"Raw block device readable: {dev}",
                    "Can read host filesystem directly, extract secrets, modify host OS.")

    # 10e. BPF filesystem
    if os.path.isdir("/sys/fs/bpf") and os.access("/sys/fs/bpf", os.W_OK):
        finding("HIGH", "Kernel", "BPF filesystem writable",
                "Can load eBPF programs to sniff network traffic or hijack syscalls.")

    # 10f. cgroup notify_on_release escape
    cg = read_file("/proc/self/cgroup")
    if cg:
        cg_path = cg.strip().split("\n")[0].split(":")[-1] if ":" in cg else ""
        nor_path = f"/sys/fs/cgroup{cg_path}/notify_on_release"
        if os.access(nor_path, os.W_OK):
            finding("CRITICAL", "Namespace", "cgroup notify_on_release is writable",
                    "Classic container escape vector: write release_agent to execute on host.")

    # 10g. Timing / covert channels
    if os.access("/proc/timer_list", os.R_OK):
        finding("LOW", "Kernel", "/proc/timer_list readable",
                "High-resolution timing data. Possible side-channel attacks.")

    # 10h. /proc/[other-pid]/environ — can we read other processes' env?
    try:
        for pid_entry in os.listdir("/proc"):
            if pid_entry.isdigit() and pid_entry != str(os.getpid()) and pid_entry != "1":
                env_path = f"/proc/{pid_entry}/environ"
                env_data = read_file(env_path)
                if env_data:
                    finding("HIGH", "Filesystem",
                            f"Can read /proc/{pid_entry}/environ",
                            f"Cross-process env leak. Content: {env_data[:300]}")
                    break  # One example is enough to prove the point
    except OSError:
        pass

    # 10i. nsenter available? (can switch namespaces)
    nsenter_path = run_cmd(["which", "nsenter"])
    if nsenter_path:
        finding("MEDIUM", "Filesystem", f"nsenter available at {nsenter_path}",
                "If combined with CAP_SYS_ADMIN or CAP_SYS_PTRACE, can enter other namespaces.")

    # 10j. Check for leftover Docker/BuildKit auth
    for auth_path in [
        "/root/.docker/config.json",
        "/home/*/.docker/config.json",
        "/kaniko/.docker/config.json",
    ]:
        for match in glob.glob(auth_path):
            content = read_file(match)
            finding("CRITICAL", "Persistence", f"Docker auth config found: {match}",
                    f"May contain registry credentials.\n{(content or '')[:300]}")


# ---------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------

def print_summary():
    heading("SUMMARY")

    counts = Counter(f["severity"] for f in findings)
    order = ["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"]

    print(f"\n  Total findings: {len(findings)}")
    for sev in order:
        print(f"    {sev:10s}: {counts.get(sev, 0)}")

    print("\n  --- All findings ---")
    for f in findings:
        print(f"    [{f['severity']}] [{f['category']}] {f['title']}")

    print(f"\n{SEP}")
    print("  END OF REPORT")
    print(SEP)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def run_recon():
    import io

    # Tee all output to both stdout and /app/report.txt
    original_stdout = sys.stdout
    capture = io.StringIO()

    class TeeWriter:
        def __init__(self, *writers):
            self.writers = writers
        def write(self, s):
            for w in self.writers:
                w.write(s)
        def flush(self):
            for w in self.writers:
                w.flush()

    sys.stdout = TeeWriter(original_stdout, capture)

    print(SEP)
    print("  BUILD-TIME SECURITY RECONNAISSANCE REPORT")
    print(f"  Generated: {datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')}")
    print(f"  Hostname:  {socket.gethostname()}")
    print(f"  Python:    {sys.version}")
    print(SEP)

    check_identity()
    check_env()
    check_filesystem()
    check_capabilities()
    check_namespaces()
    check_network()
    check_kernel()
    check_persistence()
    check_buildkit()
    check_creative()
    print_summary()

    sys.stdout = original_stdout

    # Save report to /app/report.txt
    try:
        os.makedirs("/data", exist_ok=True)
        Path("/data/report.txt").write_text(capture.getvalue())
        print(f"\n  Report saved to /data/report.txt")
    except Exception as e:
        print(f"\n  ERROR saving report: {e}")

def custom_function():
    print("hello")
