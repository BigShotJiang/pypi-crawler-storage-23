"""Kyber error exception."""


class KyberError(Exception):
    """Kyber error exception - raised when invalid input is provided."""
    pass
