# HistoricalPriceSeriesModel

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**instance_type** | **String** |  | 
**region** | **String** |  | 
**timestamps** | **Vec<String>** |  | 
**spot_prices** | **Vec<String>** |  | 
**reserved_prices** | **Vec<String>** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


