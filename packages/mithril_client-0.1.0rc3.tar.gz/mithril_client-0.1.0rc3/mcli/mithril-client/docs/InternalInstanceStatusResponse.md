# InternalInstanceStatusResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**instance_fid** | **String** |  | 
**instance_status** | **InstanceStatus** |  (enum: STATUS_NEW, STATUS_CONFIRMED, STATUS_SCHEDULED, STATUS_INITIALIZING, STATUS_STARTING, STATUS_RUNNING, STATUS_STOPPING, STATUS_STOPPED, STATUS_TERMINATED, STATUS_RELOCATING, STATUS_PREEMPTING, STATUS_PREEMPTED, STATUS_REPLACED, STATUS_PAUSED, STATUS_ERROR) | 
**instance_name** | **String** |  | 
**bid_fid** | Option<**String**> |  | [optional]
**bid_status** | Option<**BidStatus**> |  (enum: Open, Allocated, Preempting, Terminated, Paused, Relocating) | [optional]
**end_time** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


