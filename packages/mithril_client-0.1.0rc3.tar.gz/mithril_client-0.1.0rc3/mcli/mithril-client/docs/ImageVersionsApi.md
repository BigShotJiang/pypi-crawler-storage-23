# \ImageVersionsApi

All URIs are relative to *https://api.mithril.ai*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_image_versions_v2_image_versions_get**](ImageVersionsApi.md#get_image_versions_v2_image_versions_get) | **GET** /v2/image-versions | Get Image Versions
[**get_mcc_image_versions_v2_mcc_image_versions_get**](ImageVersionsApi.md#get_mcc_image_versions_v2_mcc_image_versions_get) | **GET** /v2/mcc-image-versions | Get Mcc Image Versions



## get_image_versions_v2_image_versions_get

> Vec<models::ImageVersionModel> get_image_versions_v2_image_versions_get()
Get Image Versions

Get all available image versions; the stable image version is the default unless otherwise specified.

### Parameters

This endpoint does not need any parameter.

### Return type

[**Vec<models::ImageVersionModel>**](ImageVersionModel.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## get_mcc_image_versions_v2_mcc_image_versions_get

> Vec<models::ImageVersionModel> get_mcc_image_versions_v2_mcc_image_versions_get(region)
Get Mcc Image Versions

Get MCC (CPU) image versions available for a region. These are CPU-only images used for Kubernetes cluster control planes.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**region** | **String** |  | [required] |

### Return type

[**Vec<models::ImageVersionModel>**](ImageVersionModel.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

