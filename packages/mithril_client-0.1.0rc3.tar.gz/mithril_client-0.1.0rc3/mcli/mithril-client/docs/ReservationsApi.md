# \ReservationsApi

All URIs are relative to *https://api.mithril.ai*

Method | HTTP request | Description
------------- | ------------- | -------------
[**create_reservation_v2_reservation_post**](ReservationsApi.md#create_reservation_v2_reservation_post) | **POST** /v2/reservation | Create Reservation
[**extend_reservation_v2_reservation_reservation_fid_extend_post**](ReservationsApi.md#extend_reservation_v2_reservation_reservation_fid_extend_post) | **POST** /v2/reservation/{reservation_fid}/extend | Extend Reservation
[**get_availability_v2_reservation_availability_get**](ReservationsApi.md#get_availability_v2_reservation_availability_get) | **GET** /v2/reservation/availability | Get Availability
[**get_extension_availability_v2_reservation_reservation_fid_extension_availability_get**](ReservationsApi.md#get_extension_availability_v2_reservation_reservation_fid_extension_availability_get) | **GET** /v2/reservation/{reservation_fid}/extension-availability | Get Extension Availability
[**get_reservations_v2_reservation_get**](ReservationsApi.md#get_reservations_v2_reservation_get) | **GET** /v2/reservation | Get Reservations
[**update_reservation_v2_reservation_reservation_fid_patch**](ReservationsApi.md#update_reservation_v2_reservation_reservation_fid_patch) | **PATCH** /v2/reservation/{reservation_fid} | Update Reservation



## create_reservation_v2_reservation_post

> models::ReservationModel create_reservation_v2_reservation_post(create_reservation_request)
Create Reservation

Create a new reservation.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**create_reservation_request** | [**CreateReservationRequest**](CreateReservationRequest.md) |  | [required] |

### Return type

[**models::ReservationModel**](ReservationModel.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## extend_reservation_v2_reservation_reservation_fid_extend_post

> models::ReservationModel extend_reservation_v2_reservation_reservation_fid_extend_post(reservation_fid, extend_reservation_request)
Extend Reservation

Extend a reservation to the requested time.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**reservation_fid** | **String** |  | [required] |
**extend_reservation_request** | [**ExtendReservationRequest**](ExtendReservationRequest.md) |  | [required] |

### Return type

[**models::ReservationModel**](ReservationModel.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## get_availability_v2_reservation_availability_get

> Vec<models::AvailabilitySlotModel> get_availability_v2_reservation_availability_get(project, instance_type, region, mode, earliest_start_time, latest_end_time, start_time, end_time, quantity)
Get Availability

Get availability information for reservations.  This endpoint supports three different modes for querying availability:  ## Mode: latest_end_time (default) Get the latest possible end time for a reservation given a start time and quantity.  **Required parameters:** - `start_time`: Desired start time for the reservation - `quantity`: Number of instances needed - `project`: Project FID - `instance_type`: Instance type FID - `region`: Region name  **Returns:** Latest possible end time and availability status  **Example:** ``` GET /reservation/availability?     start_time=2024-01-01T00:00:00Z&     quantity=4&     project=proj_01h8x2k9m3n4p5q6r7s8t9u0v&     instance_type=it_01h8x2k9m3n4p5q6r7s8t9u0v&     region=us-central1-a ```  ## Mode: slots Get all available slots in a time range.  **Required parameters:** - `earliest_start_time`: Start of the time range to search - `latest_end_time`: End of the time range to search - `project`: Project FID - `instance_type`: Instance type FID - `region`: Region name  **Returns:** List of available time slots with quantities  **Example:** ``` GET /reservation/availability?     mode=slots&     earliest_start_time=2024-01-01T00:00:00Z&     latest_end_time=2024-01-02T00:00:00Z&     project=proj_01h8x2k9m3n4p5q6r7s8t9u0v&     instance_type=it_01h8x2k9m3n4p5q6r7s8t9u0v&     region=us-central1-a ```  ## Mode: check Check if a specific time slot is available for reservation.  **Required parameters:** - `start_time`: Start of the desired time slot - `end_time`: End of the desired time slot - `quantity`: Number of instances needed - `project`: Project FID - `instance_type`: Instance type FID - `region`: Region name  **Returns:** Boolean indicating if the slot is available  **Example:** ``` GET /reservation/availability?     mode=check&     start_time=2024-01-01T00:00:00Z&     end_time=2024-01-01T12:00:00Z&     quantity=4&     project=proj_01h8x2k9m3n4p5q6r7s8t9u0v&     instance_type=it_01h8x2k9m3n4p5q6r7s8t9u0v&     region=us-central1-a ```  ## Common Parameters All modes require these parameters: - `project`: Project FID - `instance_type`: Instance type FID - `region`: Region name  ## Authentication Requires authentication and user must be a member of the specified project.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**project** | **String** |  | [required] |
**instance_type** | **String** |  | [required] |
**region** | **String** |  | [required] |
**mode** | Option<**String**> |  |  |[default to latest_end_time]
**earliest_start_time** | Option<**String**> |  |  |
**latest_end_time** | Option<**String**> |  |  |
**start_time** | Option<**String**> |  |  |
**end_time** | Option<**String**> |  |  |
**quantity** | Option<**i32**> |  |  |

### Return type

[**Vec<models::AvailabilitySlotModel>**](AvailabilitySlotModel.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## get_extension_availability_v2_reservation_reservation_fid_extension_availability_get

> models::ExtensionAvailabilityResponse get_extension_availability_v2_reservation_reservation_fid_extension_availability_get(reservation_fid)
Get Extension Availability

Get extension availability for a reservation

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**reservation_fid** | **String** |  | [required] |

### Return type

[**models::ExtensionAvailabilityResponse**](ExtensionAvailabilityResponse.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## get_reservations_v2_reservation_get

> models::GetReservationsResponse get_reservations_v2_reservation_get(project, next_cursor, sort_by, sort_dir, instance_type, region, status, limit)
Get Reservations

Get all reservations for a project

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**project** | **String** |  | [required] |
**next_cursor** | Option<[**serde_json::Value**](SerdeJson__Value.md)> |  |  |
**sort_by** | Option<**String**> |  |  |
**sort_dir** | Option<[**models::SortDirection**](Models__SortDirection.md)> |  |  |
**instance_type** | Option<**String**> |  |  |
**region** | Option<**String**> |  |  |
**status** | Option<**String**> |  |  |
**limit** | Option<**i32**> |  |  |

### Return type

[**models::GetReservationsResponse**](GetReservationsResponse.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## update_reservation_v2_reservation_reservation_fid_patch

> models::ReservationModel update_reservation_v2_reservation_reservation_fid_patch(reservation_fid, update_reservation_request)
Update Reservation

Update a reservation's pause/resume status and/or volumes

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**reservation_fid** | **String** |  | [required] |
**update_reservation_request** | [**UpdateReservationRequest**](UpdateReservationRequest.md) |  | [required] |

### Return type

[**models::ReservationModel**](ReservationModel.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

