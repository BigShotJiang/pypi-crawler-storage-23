# \GrantsApi

All URIs are relative to *https://api.mithril.ai*

Method | HTTP request | Description
------------- | ------------- | -------------
[**create_grant_v2_grants_post**](GrantsApi.md#create_grant_v2_grants_post) | **POST** /v2/grants | Create Grant
[**delete_grant_v2_grants_grant_fid_delete**](GrantsApi.md#delete_grant_v2_grants_grant_fid_delete) | **DELETE** /v2/grants/{grant_fid} | Delete Grant
[**list_grants_v2_grants_get**](GrantsApi.md#list_grants_v2_grants_get) | **GET** /v2/grants | List Grants
[**resell_grant_v2_grants_grant_fid_resell_post**](GrantsApi.md#resell_grant_v2_grants_grant_fid_resell_post) | **POST** /v2/grants/{grant_fid}/resell | Resell Grant



## create_grant_v2_grants_post

> serde_json::Value create_grant_v2_grants_post(body)
Create Grant

Create a new grant. Only admins can create grants.  Grants provide capacity entitlements with buy-back pricing: - unit_price: Price per unit of capacity - early_termination_buyback_price: Price paid back for early termination - flexible_usage_buyback_price: Price paid back for unused flexible capacity

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**body** | Option<**serde_json::Value**> |  | [required] |

### Return type

[**serde_json::Value**](serde_json::Value.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## delete_grant_v2_grants_grant_fid_delete

> delete_grant_v2_grants_grant_fid_delete(grant_fid)
Delete Grant

Delete (soft-delete) a grant. Only admins can delete grants.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**grant_fid** | **String** |  | [required] |

### Return type

 (empty response body)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## list_grants_v2_grants_get

> Vec<serde_json::Value> list_grants_v2_grants_get(kinds, cluster, show_expired)
List Grants

List grants for the user's organization.  Args:     cluster: Filter by cluster ID.     kinds: Filter by grant kinds.     show_expired: Include expired/deleted grants (default False).

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**kinds** | Option<[**Vec<models::GrantKind>**](Models__GrantKind.md)> |  |  |
**cluster** | Option<**String**> |  |  |
**show_expired** | Option<**bool**> |  |  |[default to false]

### Return type

[**Vec<serde_json::Value>**](serde_json::Value.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## resell_grant_v2_grants_grant_fid_resell_post

> serde_json::Value resell_grant_v2_grants_grant_fid_resell_post(grant_fid, resell_grant_request)
Resell Grant

Resell (reduce) a grant's quantity. Only admins can resell grants.  The new quantity must be less than the current quantity. This is used to return unused capacity from grants.  Implementation: - Creates a NEW grant with the reduced quantity - The new grant starts now and ends at the same time as the old grant - The old grant is soft-deleted (deleted_at = new grant's starts_at) - This preserves the remaining duration while reducing capacity

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**grant_fid** | **String** |  | [required] |
**resell_grant_request** | [**ResellGrantRequest**](ResellGrantRequest.md) |  | [required] |

### Return type

[**serde_json::Value**](serde_json::Value.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

