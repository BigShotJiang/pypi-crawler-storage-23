# \ApiKeysApi

All URIs are relative to *https://api.mithril.ai*

Method | HTTP request | Description
------------- | ------------- | -------------
[**create_api_key_v2_api_keys_post**](ApiKeysApi.md#create_api_key_v2_api_keys_post) | **POST** /v2/api-keys | Create Api Key
[**get_api_keys_v2_api_keys_get**](ApiKeysApi.md#get_api_keys_v2_api_keys_get) | **GET** /v2/api-keys | Get Api Keys
[**revoke_api_key_v2_api_keys_key_fid_delete**](ApiKeysApi.md#revoke_api_key_v2_api_keys_key_fid_delete) | **DELETE** /v2/api-keys/{key_fid} | Revoke Api Key



## create_api_key_v2_api_keys_post

> models::CreateApiKeyResponse create_api_key_v2_api_keys_post(create_api_key_request)
Create Api Key

Create a new API key

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**create_api_key_request** | [**CreateApiKeyRequest**](CreateApiKeyRequest.md) |  | [required] |

### Return type

[**models::CreateApiKeyResponse**](CreateApiKeyResponse.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## get_api_keys_v2_api_keys_get

> Vec<models::ApiKeyModel> get_api_keys_v2_api_keys_get()
Get Api Keys

Get all API keys registered to the user

### Parameters

This endpoint does not need any parameter.

### Return type

[**Vec<models::ApiKeyModel>**](ApiKeyModel.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## revoke_api_key_v2_api_keys_key_fid_delete

> revoke_api_key_v2_api_keys_key_fid_delete(key_fid)
Revoke Api Key

Revoke an API key

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**key_fid** | **String** |  | [required] |

### Return type

 (empty response body)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

