# \DefaultApi

All URIs are relative to *https://api.mithril.ai*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_internal_instance_status_v2_internal_status_get**](DefaultApi.md#get_internal_instance_status_v2_internal_status_get) | **GET** /v2/internal/status | Get Internal Instance Status



## get_internal_instance_status_v2_internal_status_get

> models::InternalInstanceStatusResponse get_internal_instance_status_v2_internal_status_get(instance_fid, bid_fid)
Get Internal Instance Status

Combined polling endpoint for mithril-authenticated VMs.  Returns instance status, bid status, and end_time in a single request. Uses lightweight DB queries and cached authentication.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**instance_fid** | **String** |  | [required] |
**bid_fid** | Option<**String**> |  |  |

### Return type

[**models::InternalInstanceStatusResponse**](InternalInstanceStatusResponse.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

