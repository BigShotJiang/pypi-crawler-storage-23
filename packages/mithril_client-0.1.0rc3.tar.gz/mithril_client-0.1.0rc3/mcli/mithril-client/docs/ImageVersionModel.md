# ImageVersionModel

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**image_version_fid** | **String** |  | 
**image_version_name** | **String** |  | 
**os** | **String** |  | 
**kernel** | **String** |  | 
**stable** | **bool** |  | 
**supported_regions** | **Vec<String>** |  | 
**deactivated_at** | Option<**String**> |  | [optional]
**nvidia_driver** | Option<**String**> |  | [optional]
**cuda** | Option<**String**> |  | [optional]
**cuda_toolkit** | Option<**String**> |  | [optional]
**nvidia_container_toolkit** | Option<**String**> |  | [optional]
**packages** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


