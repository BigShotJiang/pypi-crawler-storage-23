# HistoricalPricePointModel

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**spot_instance_price** | **String** | Spot price per hour in dollars | 
**reserved_instance_price** | **String** | Reserved price per hour in dollars | 
**timestamp** | **String** | Timestamp when this price was recorded | 
**instance_type** | **String** | Instance type FID | 
**region** | **String** | Region name | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


