# LifecycleScriptModel

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fid** | **String** |  | 
**name** | **String** |  | 
**description** | **String** |  | 
**content_url** | **String** |  | 
**project** | **String** |  | 
**created_at** | **String** |  | 
**created_by** | **String** |  | 
**last_modified_at** | **String** |  | 
**last_modified_by** | **String** |  | 
**scope** | [**models::LifecycleScriptScope**](LifecycleScriptScope.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


