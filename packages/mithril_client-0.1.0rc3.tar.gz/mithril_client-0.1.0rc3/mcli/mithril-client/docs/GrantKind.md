# GrantKind

## Enum Variants

| Name | Value |
|---- | -----|
| MaxGpus | max_gpus |
| MaxInstances | max_instances |


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


