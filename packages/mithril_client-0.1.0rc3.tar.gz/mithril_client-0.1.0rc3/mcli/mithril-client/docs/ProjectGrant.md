# ProjectGrant

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**project_id** | **String** |  | 
**cluster** | **String** |  | 
**kind** | [**models::GrantKind**](GrantKind.md) |  | 
**quantity** | **i32** |  | 
**starts_at** | **String** |  | 
**ends_at** | **String** |  | 
**unit_price** | [**models::UnitPrice**](UnitPrice.md) |  | 
**early_termination_buyback_price** | [**models::EarlyTerminationBuybackPrice**](EarlyTerminationBuybackPrice.md) |  | 
**flexible_usage_buyback_price** | [**models::FlexibleUsageBuybackPrice**](FlexibleUsageBuybackPrice.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


