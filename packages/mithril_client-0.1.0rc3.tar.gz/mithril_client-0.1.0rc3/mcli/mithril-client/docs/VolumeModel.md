# VolumeModel

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fid** | **String** |  | 
**name** | **String** |  | 
**region** | **String** |  | 
**created_at** | **String** |  | 
**capacity_gb** | **i32** |  | 
**project** | **String** |  | 
**interface** | **Interface** |  (enum: Block, File) | 
**bids** | **Vec<String>** |  | 
**reservations** | **Vec<String>** |  | 
**attachments** | **std::collections::HashMap<String, String>** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


