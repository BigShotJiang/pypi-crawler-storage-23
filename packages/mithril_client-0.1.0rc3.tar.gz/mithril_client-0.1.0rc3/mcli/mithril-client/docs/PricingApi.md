# \PricingApi

All URIs are relative to *https://api.mithril.ai*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_current_prices_v2_v2_pricing_current_get**](PricingApi.md#get_current_prices_v2_v2_pricing_current_get) | **GET** /v2/pricing/current | Get Current Prices V2
[**get_historical_prices_v2_v2_pricing_history_get**](PricingApi.md#get_historical_prices_v2_v2_pricing_history_get) | **GET** /v2/pricing/history | Get Historical Prices V2



## get_current_prices_v2_v2_pricing_current_get

> models::CurrentPricesResponse get_current_prices_v2_v2_pricing_current_get(instance_type, region, instance_quantity)
Get Current Prices V2

Get current pricing information for an instance type.  Returns the current spot price, reserved price, and minimum price for a given instance type, optionally filtered by region.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**instance_type** | **String** |  | [required] |
**region** | Option<**String**> |  |  |
**instance_quantity** | Option<**i32**> |  |  |[default to 1]

### Return type

[**models::CurrentPricesResponse**](CurrentPricesResponse.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## get_historical_prices_v2_v2_pricing_history_get

> models::HistoricalPricesResponseModel get_historical_prices_v2_v2_pricing_history_get(instance_types, region, num_samples, start_time, end_time)
Get Historical Prices V2

Get historical pricing information for instance types.  Returns historical spot and reserved prices over time for instance types, optionally filtered by specific instance type and region.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**instance_types** | Option<**String**> |  |  |
**region** | Option<**String**> |  |  |
**num_samples** | Option<**i32**> |  |  |[default to 100]
**start_time** | Option<**String**> |  |  |
**end_time** | Option<**String**> |  |  |

### Return type

[**models::HistoricalPricesResponseModel**](HistoricalPricesResponseModel.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

