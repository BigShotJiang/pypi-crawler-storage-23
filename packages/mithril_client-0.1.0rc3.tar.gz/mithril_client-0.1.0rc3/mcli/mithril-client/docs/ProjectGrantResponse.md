# ProjectGrantResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fid** | **String** |  | 
**project_id** | **String** |  | 
**cluster** | **String** |  | 
**kind** | [**models::GrantKind**](GrantKind.md) |  | 
**quantity** | **i32** |  | 
**starts_at** | **String** |  | 
**ends_at** | **String** |  | 
**unit_price** | **String** |  | 
**early_termination_buyback_price** | **String** |  | 
**flexible_usage_buyback_price** | **String** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


