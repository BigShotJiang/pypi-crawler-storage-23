# CreatedSshKeyModel

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fid** | **String** |  | 
**name** | **String** |  | 
**project** | **String** |  | 
**public_key** | **String** |  | 
**created_at** | **String** |  | 
**required** | **bool** |  | 
**private_key** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


