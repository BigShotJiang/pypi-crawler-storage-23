# LaunchSpecificationModel

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**volumes** | **Vec<String>** | List of volume FIDs | 
**ssh_keys** | **Vec<String>** | List of SSH key FIDs | 
**startup_script** | Option<**String**> |  | [optional]
**kubernetes_cluster** | Option<**String**> |  | [optional]
**image_version** | Option<**String**> |  | [optional]
**memory_gb** | Option<**i32**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


