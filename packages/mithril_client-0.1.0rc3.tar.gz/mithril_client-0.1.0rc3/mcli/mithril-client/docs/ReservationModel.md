# ReservationModel

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fid** | **String** |  | 
**name** | **String** |  | 
**project** | **String** |  | 
**created_by** | **String** |  | 
**created_at** | **String** |  | 
**deactivated_at** | Option<**String**> |  | [optional]
**instance_quantity** | **i32** |  | 
**instance_type** | **String** |  | 
**region** | Option<**String**> |  | [optional]
**instances** | **Vec<String>** |  | 
**launch_specification** | [**models::LaunchSpecificationModel**](LaunchSpecificationModel.md) |  | 
**status** | **Status** |  (enum: Pending, Active, Paused, Canceled, Ended) | 
**start_time** | **String** |  | 
**end_time** | **String** |  | 
**total_price** | **String** |  | 
**unit_price** | **String** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


