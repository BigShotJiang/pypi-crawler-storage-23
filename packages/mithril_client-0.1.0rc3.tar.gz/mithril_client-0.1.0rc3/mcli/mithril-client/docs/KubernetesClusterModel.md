# KubernetesClusterModel

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fid** | **String** |  | 
**project** | **String** |  | 
**name** | **String** |  | 
**region** | **String** |  | 
**created_at** | **String** |  | 
**kube_host** | Option<**String**> |  | [optional]
**ssh_keys** | **Vec<String>** |  | 
**instances** | **Vec<String>** |  | 
**join_command** | Option<**String**> |  | [optional]
**status** | **Status** |  (enum: Pending, Available, Terminated) | 
**deleted_at** | Option<**String**> |  | [optional]
**k8s_version** | **String** |  | 
**user_fid** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


