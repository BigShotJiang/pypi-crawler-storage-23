# AvailabilitySlotModel

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**start_time** | **String** |  | 
**end_time** | **String** |  | 
**quantity** | **i32** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


