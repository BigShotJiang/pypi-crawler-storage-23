# BidHistoryResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bid_fid** | **String** |  | 
**events** | [**Vec<models::BidHistoryEventModel>**](BidHistoryEventModel.md) | List of historical events for this bid, ordered by timestamp | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


