# \LifecycleScriptsApi

All URIs are relative to *https://api.mithril.ai*

Method | HTTP request | Description
------------- | ------------- | -------------
[**create_lifecycle_script_v2_lifecycle_scripts_post**](LifecycleScriptsApi.md#create_lifecycle_script_v2_lifecycle_scripts_post) | **POST** /v2/lifecycle-scripts | Create Lifecycle Script
[**delete_lifecycle_script_v2_lifecycle_scripts_ls_fid_delete**](LifecycleScriptsApi.md#delete_lifecycle_script_v2_lifecycle_scripts_ls_fid_delete) | **DELETE** /v2/lifecycle-scripts/{ls_fid} | Delete Lifecycle Script
[**get_lifecycle_script_content_v2_lifecycle_scripts_ls_fid_content_get**](LifecycleScriptsApi.md#get_lifecycle_script_content_v2_lifecycle_scripts_ls_fid_content_get) | **GET** /v2/lifecycle-scripts/{ls_fid}/content | Get Lifecycle Script Content
[**list_lifecycle_scripts_v2_lifecycle_scripts_get**](LifecycleScriptsApi.md#list_lifecycle_scripts_v2_lifecycle_scripts_get) | **GET** /v2/lifecycle-scripts | List Lifecycle Scripts
[**update_lifecycle_script_v2_lifecycle_scripts_ls_fid_patch**](LifecycleScriptsApi.md#update_lifecycle_script_v2_lifecycle_scripts_ls_fid_patch) | **PATCH** /v2/lifecycle-scripts/{ls_fid} | Update Lifecycle Script



## create_lifecycle_script_v2_lifecycle_scripts_post

> models::LifecycleScriptModel create_lifecycle_script_v2_lifecycle_scripts_post(create_lifecycle_script_request)
Create Lifecycle Script

Create a new lifecycle script

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**create_lifecycle_script_request** | [**CreateLifecycleScriptRequest**](CreateLifecycleScriptRequest.md) |  | [required] |

### Return type

[**models::LifecycleScriptModel**](LifecycleScriptModel.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## delete_lifecycle_script_v2_lifecycle_scripts_ls_fid_delete

> delete_lifecycle_script_v2_lifecycle_scripts_ls_fid_delete(ls_fid)
Delete Lifecycle Script

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**ls_fid** | **String** |  | [required] |

### Return type

 (empty response body)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## get_lifecycle_script_content_v2_lifecycle_scripts_ls_fid_content_get

> serde_json::Value get_lifecycle_script_content_v2_lifecycle_scripts_ls_fid_content_get(ls_fid)
Get Lifecycle Script Content

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**ls_fid** | **String** |  | [required] |

### Return type

[**serde_json::Value**](serde_json::Value.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## list_lifecycle_scripts_v2_lifecycle_scripts_get

> models::ListLifecycleScriptsResponse list_lifecycle_scripts_v2_lifecycle_scripts_get(project, next_cursor, sort_by, sort_dir, limit)
List Lifecycle Scripts

Get all lifecycle scripts visible to user in a project

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**project** | **String** |  | [required] |
**next_cursor** | Option<[**serde_json::Value**](SerdeJson__Value.md)> |  |  |
**sort_by** | Option<**String**> |  |  |
**sort_dir** | Option<[**models::SortDirection**](Models__SortDirection.md)> |  |  |
**limit** | Option<**i32**> |  |  |

### Return type

[**models::ListLifecycleScriptsResponse**](ListLifecycleScriptsResponse.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## update_lifecycle_script_v2_lifecycle_scripts_ls_fid_patch

> models::LifecycleScriptModel update_lifecycle_script_v2_lifecycle_scripts_ls_fid_patch(ls_fid, update_lifecycle_script_request)
Update Lifecycle Script

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**ls_fid** | **String** |  | [required] |
**update_lifecycle_script_request** | [**UpdateLifecycleScriptRequest**](UpdateLifecycleScriptRequest.md) |  | [required] |

### Return type

[**models::LifecycleScriptModel**](LifecycleScriptModel.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

