# HistoricalPricesResponseModel

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**series** | [**Vec<models::HistoricalPriceSeriesModel>**](HistoricalPriceSeriesModel.md) |  | 
**complete** | Option<**bool**> |  | [optional][default to true]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


