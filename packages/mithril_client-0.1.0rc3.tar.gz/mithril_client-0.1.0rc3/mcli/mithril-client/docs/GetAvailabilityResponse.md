# GetAvailabilityResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mode** | **String** |  | 
**slots** | Option<[**Vec<models::AvailabilitySlotModel>**](AvailabilitySlotModel.md)> |  | [optional]
**latest_end_time** | Option<**String**> |  | [optional]
**available** | Option<**bool**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


