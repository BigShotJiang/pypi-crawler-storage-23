# InstanceStatusResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fid** | **String** |  | 
**name** | **String** |  | 
**bid** | Option<**String**> |  | [optional]
**reservation** | Option<**String**> |  | [optional]
**status** | **Status** |  (enum: STATUS_NEW, STATUS_CONFIRMED, STATUS_SCHEDULED, STATUS_INITIALIZING, STATUS_STARTING, STATUS_RUNNING, STATUS_STOPPING, STATUS_STOPPED, STATUS_TERMINATED, STATUS_RELOCATING, STATUS_PREEMPTING, STATUS_PREEMPTED, STATUS_REPLACED, STATUS_PAUSED, STATUS_ERROR) | 
**end_time** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


