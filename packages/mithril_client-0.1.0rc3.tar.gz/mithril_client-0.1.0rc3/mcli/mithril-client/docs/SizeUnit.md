# SizeUnit

## Enum Variants

| Name | Value |
|---- | -----|
| B | b |
| Kb | kb |
| Mb | mb |
| Gb | gb |
| Tb | tb |
| Pb | pb |
| Eb | eb |
| Gib | gib |
| Tib | tib |
| Pib | pib |


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


