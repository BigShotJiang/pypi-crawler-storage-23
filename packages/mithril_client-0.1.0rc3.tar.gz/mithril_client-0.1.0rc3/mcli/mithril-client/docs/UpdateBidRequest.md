# UpdateBidRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**limit_price** | Option<**String**> |  | [optional]
**paused** | Option<**bool**> |  | [optional]
**volumes** | Option<**Vec<String>**> |  | [optional]
**memory_gb** | Option<**i32**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


