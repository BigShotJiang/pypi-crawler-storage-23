# CreateReservationRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**project** | **String** |  | 
**instance_type** | **String** |  | 
**region** | **String** |  | 
**start_time** | **String** |  | 
**end_time** | **String** |  | 
**instance_quantity** | **i32** |  | 
**name** | **String** |  | 
**launch_specification** | [**models::LaunchSpecificationModel**](LaunchSpecificationModel.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


