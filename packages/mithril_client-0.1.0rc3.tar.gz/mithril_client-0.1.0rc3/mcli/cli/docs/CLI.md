# Command-Line Help for `ml`

This document contains the help content for the `ml` command-line program.

**Command Overview:**

* [`ml`↴](#ml)
* [`ml setup`↴](#ml-setup)
* [`ml ssh`↴](#ml-ssh)
* [`ml instance`↴](#ml-instance)
* [`ml instance list`↴](#ml-instance-list)
* [`ml instance create`↴](#ml-instance-create)
* [`ml instance delete`↴](#ml-instance-delete)
* [`ml instance info`↴](#ml-instance-info)
* [`ml instance list-types`↴](#ml-instance-list-types)
* [`ml instance ssh`↴](#ml-instance-ssh)
* [`ml k8s`↴](#ml-k8s)
* [`ml k8s list`↴](#ml-k8s-list)
* [`ml k8s info`↴](#ml-k8s-info)
* [`ml k8s ssh`↴](#ml-k8s-ssh)
* [`ml k8s update-kubeconfig`↴](#ml-k8s-update-kubeconfig)

## `ml`

Mithril CLI

**Usage:** `ml [ARGS]... [COMMAND]`

###### **Subcommands:**

* `setup` — Configure CLI with API key and default project.

This interactive command creates or updates the config file at:
  ${XDG_CONFIG_HOME:-~/.config}/mithril/config.yaml

ENVIRONMENT VARIABLES (override config file):
    MITHRIL_API_KEY    API key
    MITHRIL_PROJECT    Project FID
    MITHRIL_PROFILE    Profile name (default: current_profile)
    MITHRIL_API_URL    API endpoint (default: https://api.mithril.ai)

  Priority: env vars > config file > defaults.
  When MITHRIL_API_KEY and MITHRIL_PROJECT are set, no config file is needed.

PROFILES:
  The config file supports multiple named profiles. Run 'ml setup' again
  to create additional profiles or switch between them. Use MITHRIL_PROFILE
  to select a profile without changing the config file.

API KEY:
  Get your API key at: https://app.mithril.ai/account/api-keys

EXAMPLES:
  Interactive setup (creates config file):
    ml setup

  Check setup status (non-interactive):
    ml setup --check

  non-interactive usage (no setup needed):
    export MITHRIL_API_KEY=your-key
    export MITHRIL_PROJECT=proj_xxx
    ml instance list

  Use a specific profile:
    MITHRIL_PROFILE=staging ml instance list
* `ssh` — SSH into an instance by spot bid name, or interactively select an instance
* `instance` — Manage compute instances (spot bids)
* `k8s` — Manage Kubernetes clusters

###### **Arguments:**

* `<ARGS>` — Pass-through arguments for delegation to flow CLI



## `ml setup`

Configure CLI with API key and default project.

This interactive command creates or updates the config file at:
  ${XDG_CONFIG_HOME:-~/.config}/mithril/config.yaml

ENVIRONMENT VARIABLES (override config file):
    MITHRIL_API_KEY    API key
    MITHRIL_PROJECT    Project FID
    MITHRIL_PROFILE    Profile name (default: current_profile)
    MITHRIL_API_URL    API endpoint (default: https://api.mithril.ai)

  Priority: env vars > config file > defaults.
  When MITHRIL_API_KEY and MITHRIL_PROJECT are set, no config file is needed.

PROFILES:
  The config file supports multiple named profiles. Run 'ml setup' again
  to create additional profiles or switch between them. Use MITHRIL_PROFILE
  to select a profile without changing the config file.

API KEY:
  Get your API key at: https://app.mithril.ai/account/api-keys

EXAMPLES:
  Interactive setup (creates config file):
    ml setup

  Check setup status (non-interactive):
    ml setup --check

  non-interactive usage (no setup needed):
    export MITHRIL_API_KEY=your-key
    export MITHRIL_PROJECT=proj_xxx
    ml instance list

  Use a specific profile:
    MITHRIL_PROFILE=staging ml instance list

**Usage:** `ml setup [OPTIONS]`

###### **Options:**

* `--check` — Check setup status without modifying configuration



## `ml ssh`

SSH into an instance by spot bid name, or interactively select an instance

**Usage:** `ml ssh [OPTIONS] [BID_NAME] [COMMAND]...`

###### **Arguments:**

* `<BID_NAME>` — Spot bid name to connect to (if not provided, shows interactive picker)
* `<COMMAND>` — Command to run on the remote instance (if not provided, starts interactive shell)

###### **Options:**

* `--node <NODE>` — Node index for multi-instance tasks (remote commands default to all nodes; interactive default is 0)
* `--show` — Show the raw SSH command instead of executing it
* `--no-wait` — Don't wait for instance to become available (fail immediately if not running)



## `ml instance`

Manage compute instances (spot bids)

**Usage:** `ml instance <COMMAND>`

###### **Subcommands:**

* `list` — List instances/bids
* `create` — Create a new instance/bid
* `delete` — Delete (cancel) an instance/bid
* `info` — Show detailed info about an instance/bid
* `list-types` — List available instance types
* `ssh` — SSH into an instance by spot bid name, or interactively select an instance



## `ml instance list`

List instances/bids

**Usage:** `ml instance list [OPTIONS]`

###### **Options:**

* `--all` — Show all bids (default: active only)
* `-s`, `--state <STATE>` — Filter by status

  Possible values: `allocated`, `pending`, `open`, `starting`, `running`, `paused`, `preempting`, `completed`, `failed`, `cancelled`

* `--limit <LIMIT>` — Maximum number of bids to show
* `--json` — Output JSON for automation



## `ml instance create`

Create a new instance/bid

**Usage:** `ml instance create [OPTIONS] --instance-type <INSTANCE_TYPE> --region <REGION> --max-price-per-hour <MAX_PRICE_PER_HOUR>`

###### **Options:**

* `-i`, `--instance-type <INSTANCE_TYPE>` — GPU instance type (e.g., a100, 8xa100, h100)
* `-r`, `--region <REGION>` — Region (e.g., us-west1-b)
* `-n`, `--name <NAME>` — Bid name (default: auto-generated)
* `-m`, `--max-price-per-hour <MAX_PRICE_PER_HOUR>` — Maximum hourly price in USD (e.g., 8.0 or $8.0)
* `-N`, `--num-instances <NUM_INSTANCES>` — Number of instances in the bid

  Default value: `1`
* `-p`, `--project <PROJECT>` — Project name (skip interactive selection)
* `--k8s <K8S>` — Attach to Kubernetes cluster (name)
* `--wait` — Wait for instances to start running
* `-d`, `--dry-run` — Validate configuration without submitting
* `-w`, `--watch` — Watch instance progress interactively
* `--json` — Output JSON for automation



## `ml instance delete`

Delete (cancel) an instance/bid

**Usage:** `ml instance delete [OPTIONS] [BID_NAME]`

###### **Arguments:**

* `<BID_NAME>` — Bid name or FID (interactive if omitted)

###### **Options:**

* `-y`, `--yes` — Skip confirmation prompt
* `--all` — Cancel all active bids
* `-n`, `--name-pattern <NAME_PATTERN>` — Cancel bids matching wildcard pattern (e.g., 'dev-*')



## `ml instance info`

Show detailed info about an instance/bid

**Usage:** `ml instance info [OPTIONS] [BID_NAME]`

###### **Arguments:**

* `<BID_NAME>` — Bid name or FID (interactive if omitted)

###### **Options:**

* `--json` — Output JSON for automation



## `ml instance list-types`

List available instance types

**Usage:** `ml instance list-types [OPTIONS]`

###### **Options:**

* `-r`, `--region <REGION>` — Filter by region
* `-v`, `--verbose` — Show detailed GPU/memory info
* `--json` — Output JSON for automation



## `ml instance ssh`

SSH into an instance by spot bid name, or interactively select an instance

**Usage:** `ml instance ssh [OPTIONS] [BID_NAME] [COMMAND]...`

###### **Arguments:**

* `<BID_NAME>` — Spot bid name to connect to (if not provided, shows interactive picker)
* `<COMMAND>` — Command to run on the remote instance (if not provided, starts interactive shell)

###### **Options:**

* `--node <NODE>` — Node index for multi-instance tasks (remote commands default to all nodes; interactive default is 0)
* `--show` — Show the raw SSH command instead of executing it
* `--no-wait` — Don't wait for instance to become available (fail immediately if not running)



## `ml k8s`

Manage Kubernetes clusters

**Usage:** `ml k8s <COMMAND>`

###### **Subcommands:**

* `list` — List Kubernetes clusters
* `info` — Show detailed information about a Kubernetes cluster
* `ssh` — SSH into Kubernetes cluster control node
* `update-kubeconfig` — Fetch k8s cluster credentials and update local kubeconfig



## `ml k8s list`

List Kubernetes clusters

**Usage:** `ml k8s list [OPTIONS]`

###### **Options:**

* `--all` — Show all clusters including terminated
* `--json` — Output JSON for automation



## `ml k8s info`

Show detailed information about a Kubernetes cluster

**Usage:** `ml k8s info [OPTIONS] [CLUSTER]`

###### **Arguments:**

* `<CLUSTER>` — Cluster name or FID (interactive if omitted)

###### **Options:**

* `--json` — Output JSON for automation



## `ml k8s ssh`

SSH into Kubernetes cluster control node

**Usage:** `ml k8s ssh [OPTIONS] [CLUSTER] [COMMAND]...`

###### **Arguments:**

* `<CLUSTER>` — Cluster name or FID (interactive if omitted)
* `<COMMAND>` — Command to run on the remote host

###### **Options:**

* `--show` — Show the raw SSH command instead of executing it
* `-i`, `--identity <IDENTITY>` — Path to SSH identity file (auto-detected if omitted)



## `ml k8s update-kubeconfig`

Fetch k8s cluster credentials and update local kubeconfig

**Usage:** `ml k8s update-kubeconfig [OPTIONS] [CLUSTER]`

###### **Arguments:**

* `<CLUSTER>` — Cluster name or FID (interactive if omitted)

###### **Options:**

* `-i`, `--identity <IDENTITY>` — Path to SSH identity file (auto-detected if omitted)
* `-y`, `--yes` — Skip confirmation prompt
* `--no-backup` — Skip creating backup of existing kubeconfig
* `--skip-validation` — Skip validation with kubectl



<hr/>

<small><i>
    This document was generated automatically by
    <a href="https://crates.io/crates/clap-markdown"><code>clap-markdown</code></a>.
</i></small>
