use std::fs;
use std::path::Path;

#[path = "src/cli.rs"]
mod cli;

use cli::Cli;

fn main() {
    let docs_dir = Path::new("docs");

    if !docs_dir.exists() {
        fs::create_dir(docs_dir).expect("Failed to create docs directory");
    }

    let markdown = clap_markdown::help_markdown_command(&Cli::build_command());

    fs::write(docs_dir.join("CLI.md"), markdown).expect("Failed to write CLI.md");

    println!("cargo:rerun-if-changed=src/cli.rs");
}
