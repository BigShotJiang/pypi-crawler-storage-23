# Detach Mode

Launch without streaming logs — job runs in background.

## CLI

```bash
ml launch task.yaml -c my-cluster --detach-run
# or
ml launch task.yaml -c my-cluster -d
```

## SDK

```python
sky.launch(
    task=task,
    cluster_name='my-cluster',
    detach_run=True,
)
```

## Behavior

- Launch returns immediately after job starts
- Logs are not streamed to terminal
- Job continues running in background

## When to use

- Long-running jobs
- Running multiple launches
- CI/CD pipelines
- When you'll check logs later

## View logs later

```bash
ml logs my-cluster JOB_ID
```

## Check job status

```bash
ml queue my-cluster
```

## Default behavior (attached)

Without `-d`, launch:
1. Waits for cluster provisioning
2. Streams job logs to terminal
3. Exits when job completes
