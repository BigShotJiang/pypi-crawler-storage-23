# File Mounts

Mount remote storage and volumes in your tasks.

## Remote storage (S3, GCS)

```yaml
file_mounts:
  /data: s3://my-bucket/training-data
  /models: gs://my-bucket/models
```

Data is synced to the specified path on the cluster.

## Mithril volumes

Mount persistent volumes by name:

```yaml
volumes:
  /data: my-data-volume
```

Volume must exist in Mithril. CLI auto-syncs to SkyPilot.

## Ephemeral volumes

Create temporary storage that's deleted with the cluster:

```yaml
volumes:
  /scratch:
    type: ephemeral
    size: 100GB
```

## Combined example

```yaml
file_mounts:
  /datasets: s3://my-bucket/datasets

volumes:
  /data: my-persistent-volume
  /scratch:
    type: ephemeral
    size: 500GB
```

## workdir

Sync your local directory:

```yaml
workdir: .
```

Files sync to `~/sky_workdir/` on the cluster.

## Volume sync behavior

Before launch, CLI automatically:
1. Checks volumes in SkyPilot
2. Fetches missing volumes from Mithril API
3. Registers them with SkyPilot

No manual steps needed.

## See also

- [06-volumes/](../../06-volumes/) — volume management details
