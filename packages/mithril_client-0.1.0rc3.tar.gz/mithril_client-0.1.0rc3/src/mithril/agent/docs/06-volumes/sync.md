# Volume Sync

How CLI syncs Mithril volumes to SkyPilot.

## Automatic sync

When you run `ml launch` with volumes:

1. CLI reads volume names from task YAML
2. Checks if volumes exist in SkyPilot
3. Fetches missing volumes from Mithril API
4. Registers them with SkyPilot
5. Proceeds with launch

No manual steps needed — just reference volumes by name:

```yaml
volumes:
  /data: my-volume
```

## Troubleshooting

### Volume not found

```
Error: Volume 'my-volume' not found
```

Check if volume exists:

```bash
ml sky volumes ls
```

If missing, create it — see `persistent.md`.

### Region mismatch

Ensure task's `resources.infra` region matches the volume's region (specified in `--infra` when created).
