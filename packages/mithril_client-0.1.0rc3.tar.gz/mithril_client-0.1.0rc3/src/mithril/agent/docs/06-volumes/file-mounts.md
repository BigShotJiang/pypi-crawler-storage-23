# File Mounts

Mount cloud storage (S3, GCS) to instance paths.

## Syntax

```yaml
file_mounts:
  /remote/path: s3://bucket/prefix
  /another/path: gs://bucket/prefix
```

## Examples

### S3

```yaml
file_mounts:
  /data: s3://my-bucket/datasets/imagenet
```

### GCS

```yaml
file_mounts:
  /data: gs://my-bucket/datasets
```

### Local directory

```yaml
file_mounts:
  /code: ./src
```

Syncs local `./src` to `/code` on instance.

## Difference from volumes

| File mounts | Volumes |
|-------------|---------|
| Cloud storage (S3/GCS) | Mithril storage |
| Copied at launch | Mounted filesystem |
| Read-only typical | Read-write |
| Any region | Must match instance region |

## Combined usage

```yaml
file_mounts:
  /datasets: s3://bucket/data    # Input from S3

volumes:
  /output: my-output-volume      # Output to Mithril volume

run: |
  python train.py --data /datasets --output /output
```

## Credentials

Cloud credentials must be configured for S3/GCS access.

