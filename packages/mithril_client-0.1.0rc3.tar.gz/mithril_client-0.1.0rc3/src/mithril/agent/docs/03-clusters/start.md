# Start

Start a stopped cluster.

## Usage

```bash
ml start my-cluster
```

## Behavior

- Restarts stopped VMs
- Preserves disk state
- Resumes from where you left off

## Options

| Flag | Description |
|------|-------------|
| `-i, --idle-minutes-to-autostop` | Set autostop timer |
| `--retry-until-up` | Retry if resources unavailable |
| `-y, --yes` | Skip confirmation |

## Example

```bash
# Stop cluster
ml stop my-cluster

# ... later ...

# Restart
ml start my-cluster

# Continue work
ml exec my-cluster 'python continue_training.py'
```

## If start fails

Resources may not be available. Options:
1. Wait and retry
2. Use `--retry-until-up`
3. Down and relaunch in different region

