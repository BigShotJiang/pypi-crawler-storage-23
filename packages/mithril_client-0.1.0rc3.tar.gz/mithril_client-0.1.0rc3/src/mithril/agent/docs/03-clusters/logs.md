# Logs

View job logs from a cluster.

## Usage

```bash
ml logs my-cluster JOB_ID
```

## Stream logs (follow)

```bash
ml logs my-cluster JOB_ID --follow
```

## Get job ID

From launch output or:

```bash
ml queue my-cluster
```

## Latest job

```bash
ml logs my-cluster
```

Without job ID, shows latest job logs.

## Options

| Flag | Description |
|------|-------------|
| `--follow, -f` | Stream logs in real-time |
| `--tail N` | Show last N lines |

## Example

```bash
# Launch detached
ml launch task.yaml -c my-cluster -d

# Check queue
ml queue my-cluster
# Output: Job 1 RUNNING ...

# View logs
ml logs my-cluster 1 --follow
```

