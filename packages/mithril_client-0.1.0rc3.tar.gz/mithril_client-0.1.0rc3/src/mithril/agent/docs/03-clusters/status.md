# Status

View running clusters and jobs.

## Usage

```bash
ml status
```

## Output

Shows:
- Cluster name
- Status (UP, STOPPED, etc.)
- Resources (GPUs, region)
- Autostop configuration
- Running jobs

## Example output

```
NAME         STATUS  RESOURCES           REGION      AUTOSTOP
my-cluster   UP      8x B200             us-central5-a  30 min
dev-cluster  STOPPED 4x A100             us-east1    -
```

## Filter by cluster

```bash
ml status my-cluster
```

## Refresh

```bash
ml status --refresh
```

Forces status refresh from cloud.

## JSON output

```bash
ml status --json
```

## Cluster states

| State | Description |
|-------|-------------|
| UP | Running and accessible |
| STOPPED | Paused, can restart |
| INIT | Being provisioned |
| ERROR | Failed state |

