# Queue

View job queue for a cluster.

## Usage

```bash
ml queue my-cluster
```

## Output

Shows all jobs:
- Job ID
- Status
- Start time
- Command/task name

## Example output

```
JOB_ID  STATUS     STARTED              COMMAND
1       SUCCEEDED  2024-01-15 10:30:00  python train.py
2       RUNNING    2024-01-15 11:00:00  python eval.py
3       PENDING    -                    python test.py
```

## Job states

| State | Description |
|-------|-------------|
| PENDING | Queued, waiting to run |
| RUNNING | Currently executing |
| SUCCEEDED | Completed successfully |
| FAILED | Exited with error |
| CANCELLED | Cancelled by user |

## Cancel job

```bash
ml cancel my-cluster JOB_ID
```

## Skip finished jobs

```bash
ml queue my-cluster --skip-finished
```

