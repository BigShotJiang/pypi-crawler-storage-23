# Down

Terminate and delete a cluster.

## Usage

```bash
ml down my-cluster
```

## Behavior

- Terminates all VMs
- Deletes cluster resources
- Stops all billing
- Cannot be undone

## Down multiple

```bash
ml down cluster1 cluster2
```

## Down all

```bash
ml down -a
```

## Skip confirmation

```bash
ml down my-cluster -y
```

## Purge (force delete)

```bash
ml down my-cluster -p
```

Removes from database even if cloud deletion fails.

## Auto-down after job

```bash
ml launch task.yaml -c my-cluster --down
```

Cluster automatically deleted when job completes.

## Check before down

```bash
ml status my-cluster
ml queue my-cluster
```

Ensure no important jobs running.

