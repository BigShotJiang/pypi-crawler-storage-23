# Stop

Stop a running cluster (preserves state).

## Usage

```bash
ml stop my-cluster
```

## Behavior

- VMs are stopped (not deleted)
- Disk state preserved
- Can restart with `ml start`
- Stops billing for compute

## Stop multiple

```bash
ml stop cluster1 cluster2
```

## Stop all

```bash
ml stop -a
```

## Skip confirmation

```bash
ml stop my-cluster -y
```

## When to stop vs down

| Use `stop` | Use `down` |
|------------|------------|
| Pause temporarily | Done with cluster |
| Resume later | Delete everything |
| Keep disk state | Free all resources |
| Reduce costs | Maximum cleanup |

## Restart stopped cluster

```bash
ml start my-cluster
```

