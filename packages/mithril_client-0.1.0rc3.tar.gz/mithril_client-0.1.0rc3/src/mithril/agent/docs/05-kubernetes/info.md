# K8s Info

Show detailed Kubernetes cluster information.

## Usage

```bash
ml k8s info my-cluster
```

## Interactive mode

```bash
ml k8s info
```

Shows picker if name omitted.

## Options

| Flag | Description |
|------|-------------|
| `--json` | JSON output |

## Output includes

- Cluster name and ID
- Status
- Region
- Kubernetes version
- Control plane endpoint
- Node count
- Attached instances

## Example output

```
Name:           my-k8s-cluster
Status:         running
Region:         us-central5-a
K8s Version:    1.28.5
Endpoint:       https://10.0.0.1:6443
Nodes:          4

Attached Instances:
  - gpu-node-1 (running, b200)
  - gpu-node-2 (running, b200)
```

## JSON for scripting

```bash
ml k8s info my-cluster --json | jq '.endpoint'
```

