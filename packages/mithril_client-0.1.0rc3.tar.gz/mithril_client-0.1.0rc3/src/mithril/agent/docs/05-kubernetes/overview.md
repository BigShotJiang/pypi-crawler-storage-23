# Kubernetes Overview

Manage Kubernetes clusters on Mithril infrastructure.

## Commands

| Command | Description |
|---------|-------------|
| `ml k8s list` | List clusters |
| `ml k8s info` | Cluster details |
| `ml k8s ssh` | SSH to control node |
| `ml k8s update-kubeconfig` | Fetch credentials |

## Workflow

1. Create K8s cluster (via console or API)
2. Attach instances as nodes
3. Update local kubeconfig
4. Use kubectl normally

## Attach instances to K8s

```bash
ml instance create \
  -i b200 \
  -r us-central5-a \
  -m 8.0 \
  --k8s my-k8s-cluster
```

## Access cluster

```bash
# Fetch credentials
ml k8s update-kubeconfig my-k8s-cluster

# Use kubectl
kubectl get nodes
kubectl get pods
```

## Use cases

- Kubernetes-based ML pipelines
- Multi-tenant GPU sharing
- Container orchestration
- Custom schedulers (e.g., Volcano, Kueue)

