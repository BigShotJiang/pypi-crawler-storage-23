# Instance Delete

Cancel an instance or spot bid.

## Usage

```bash
ml instance delete my-instance
```

## Interactive mode

```bash
ml instance delete
```

Shows picker if name omitted.

## Options

| Flag | Description |
|------|-------------|
| `-y, --yes` | Skip confirmation |
| `--all` | Cancel all active bids |
| `-n, --name-pattern` | Pattern match (wildcards) |

## Examples

### Single instance

```bash
ml instance delete my-instance
```

### Skip confirmation

```bash
ml instance delete my-instance -y
```

### Delete all

```bash
ml instance delete --all
```

### Pattern match

```bash
ml instance delete -n 'dev-*'
ml instance delete -n 'training-*'
```

## Behavior

- Running instances are terminated
- Pending bids are cancelled
- Cannot be undone

## Check before delete

```bash
ml instance info my-instance
```

