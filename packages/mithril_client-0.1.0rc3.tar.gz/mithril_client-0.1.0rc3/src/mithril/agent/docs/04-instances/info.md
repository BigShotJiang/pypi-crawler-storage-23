# Instance Info

Show detailed information about an instance.

## Usage

```bash
ml instance info my-instance
```

## Interactive mode

```bash
ml instance info
```

Shows picker if name omitted.

## Options

| Flag | Description |
|------|-------------|
| `--json` | JSON output |

## Output includes

- Instance name and ID
- Status
- Instance type
- Region
- Price (current and max)
- Creation time
- IP addresses (if running)
- SSH connection info
- Kubernetes cluster (if attached)

## Example output

```
Name:         my-instance
Status:       running
Type:         b200
Region:       us-central5-a
Max Price:    $8.00/hr
Created:      2024-01-15 10:30:00

IPs:
  Public:     34.123.45.67
  Private:    10.0.0.5

SSH:          ssh user@34.123.45.67
```

## JSON for scripting

```bash
ml instance info my-instance --json | jq '.status'
```

