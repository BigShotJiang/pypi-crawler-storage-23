# Instance Create

Create a new spot bid for compute instances.

## Usage

```bash
ml instance create \
  --instance-type b200 \
  --region us-central5-a \
  --max-price-per-hour 8.0
```

## Required flags

| Flag | Description |
|------|-------------|
| `-i, --instance-type` | GPU type (e.g., `b200`, `8xa100`) |
| `-r, --region` | Region (e.g., `us-central5-a`) |
| `-m, --max-price-per-hour` | Max hourly price in USD |

## Optional flags

| Flag | Description |
|------|-------------|
| `-n, --name` | Bid name (auto-generated if omitted) |
| `-N, --num-instances` | Number of instances (default: 1) |
| `-p, --project` | Project (skip interactive selection) |
| `--k8s` | Attach to Kubernetes cluster |
| `--wait` | Wait for instances to start |
| `-w, --watch` | Watch progress interactively |
| `-d, --dry-run` | Validate without submitting |
| `--json` | JSON output |

## Examples

### Basic

```bash
ml instance create -i b200 -r us-central5-a -m 8.0
```

### Named with multiple instances

```bash
ml instance create \
  -i 8xa100 \
  -r us-east1 \
  -m 25.0 \
  -n my-training-nodes \
  -N 4
```

### Attach to Kubernetes

```bash
ml instance create \
  -i b200 \
  -r us-central5-a \
  -m 8.0 \
  --k8s my-k8s-cluster
```

### Wait for running

```bash
ml instance create -i b200 -r us-central5-a -m 8.0 --wait
```

## Price format

```bash
-m 8.0      # $8.00/hour/instance
-m $8.0     # Also valid
-m 8        # $8.00/hour/instance
```

→ [Limit Price](../concepts/spot-bid.md) — how the spot auction, pricing strategy, and preemption work
