# Instances Overview

Instances are compute resources managed via Mithril's spot marketplace.

## Difference from clusters

| Clusters (`ml launch`) | Instances (`ml instance`) |
|------------------------|---------------------------|
| SkyPilot-managed | Mithril API-managed |
| Task-oriented | Infrastructure-oriented |
| Auto-provisioned | Manual spot bidding |
| Ephemeral by design | Can attach to K8s |

## Commands

| Command | Description |
|---------|-------------|
| `ml instance list` | List instances/bids |
| `ml instance create` | Create spot bid |
| `ml instance delete` | Cancel bid |
| `ml instance info` | Show details |
| `ml instance list-types` | Available GPU types |
| `ml instance ssh` | SSH into instance |

## Spot marketplace

All instances are allocated through [spot bidding](../concepts/spot-bid.md) — a blind second-price auction. Set your limit price with `-m` when creating an instance.

## Use cases

- Kubernetes node pools
- Long-running workloads
- Direct VM access
- Cost-optimized compute

