"""Mithril CLI."""

from __future__ import annotations

from mithril.cli.main import cli, main

__all__ = ["cli", "main"]
