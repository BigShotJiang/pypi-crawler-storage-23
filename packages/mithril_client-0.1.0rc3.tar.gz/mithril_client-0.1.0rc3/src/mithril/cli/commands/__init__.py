"""CLI commands package.

Do not re-export command objects from this package (e.g. `from .launch import launch`).

Why: doing so binds `mithril.cli.commands.launch` to the exported object, which can
shadow the `mithril.cli.commands.launch` *module* and break code/tests that import the
module to access helpers. This is common in CLIs because command objects are often
defined at import time, and it's common to name the command the same as the module
(e.g. `launch.py` exporting `launch`), making re-exports especially tempting.

Prefer importing from the submodule:
    from mithril.cli.commands.launch import launch  # ✓
Avoid:
    from mithril.cli.commands import launch         # ✗
"""
