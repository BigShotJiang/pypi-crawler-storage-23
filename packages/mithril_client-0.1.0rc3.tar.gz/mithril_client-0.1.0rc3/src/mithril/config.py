"""Mithril configuration management.

Delegates to the Rust implementation for config loading.
"""

from __future__ import annotations

from dataclasses import dataclass

from mithril._mcli import MithrilConfig as RustConfig
from mithril._mcli import load_config as rust_load_config

DEFAULT_API_URL = "https://api.mithril.ai"


class ConfigError(Exception):
    """Raised when configuration is missing or invalid."""


@dataclass(frozen=True, slots=True)
class Config:
    """Resolved configuration for Mithril operations."""

    api_key: str
    project_id: str
    api_url: str


def load_config() -> Config:
    """Load and validate configuration from environment and config file.

    Returns:
        Validated Config object.

    Raises:
        ConfigError: If required configuration (api_key, project_id) is missing.
    """
    try:
        rust_cfg: RustConfig = rust_load_config()
        return Config(
            api_key=rust_cfg.api_key,
            project_id=rust_cfg.project_id,
            api_url=rust_cfg.api_url,
        )
    except RuntimeError as e:
        # Convert Rust RuntimeError to Python ConfigError
        raise ConfigError(str(e)) from e
