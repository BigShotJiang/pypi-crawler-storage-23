from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from typing_extensions import Self

from ..models.kubernetes_cluster_model_status import KubernetesClusterModelStatus
from ..types import UNSET, Unset

T = TypeVar("T", bound="KubernetesClusterModel")


@_attrs_define
class KubernetesClusterModel:
    """
    Attributes:
        fid (str):
        project (str):
        name (str):
        region (str):
        created_at (str):
        ssh_keys (list[str]):
        instances (list[str]):
        status (KubernetesClusterModelStatus):
        k8s_version (str):
        kube_host (None | str | Unset):
        join_command (None | str | Unset):
        deleted_at (None | str | Unset):
        user_fid (None | str | Unset):
    """

    fid: str
    project: str
    name: str
    region: str
    created_at: str
    ssh_keys: list[str]
    instances: list[str]
    status: KubernetesClusterModelStatus
    k8s_version: str
    kube_host: None | str | Unset = UNSET
    join_command: None | str | Unset = UNSET
    deleted_at: None | str | Unset = UNSET
    user_fid: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        fid = self.fid

        project = self.project

        name = self.name

        region = self.region

        created_at = self.created_at

        ssh_keys = self.ssh_keys

        instances = self.instances

        status = self.status.value

        k8s_version = self.k8s_version

        kube_host: None | str | Unset
        if isinstance(self.kube_host, Unset):
            kube_host = UNSET
        else:
            kube_host = self.kube_host

        join_command: None | str | Unset
        if isinstance(self.join_command, Unset):
            join_command = UNSET
        else:
            join_command = self.join_command

        deleted_at: None | str | Unset
        if isinstance(self.deleted_at, Unset):
            deleted_at = UNSET
        else:
            deleted_at = self.deleted_at

        user_fid: None | str | Unset
        if isinstance(self.user_fid, Unset):
            user_fid = UNSET
        else:
            user_fid = self.user_fid

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "fid": fid,
                "project": project,
                "name": name,
                "region": region,
                "created_at": created_at,
                "ssh_keys": ssh_keys,
                "instances": instances,
                "status": status,
                "k8s_version": k8s_version,
            }
        )
        if kube_host is not UNSET:
            field_dict["kube_host"] = kube_host
        if join_command is not UNSET:
            field_dict["join_command"] = join_command
        if deleted_at is not UNSET:
            field_dict["deleted_at"] = deleted_at
        if user_fid is not UNSET:
            field_dict["user_fid"] = user_fid

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        fid = d.pop("fid")

        project = d.pop("project")

        name = d.pop("name")

        region = d.pop("region")

        created_at = d.pop("created_at")

        ssh_keys = cast(list[str], d.pop("ssh_keys"))

        instances = cast(list[str], d.pop("instances"))

        status = KubernetesClusterModelStatus(d.pop("status"))

        k8s_version = d.pop("k8s_version")

        def _parse_kube_host(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        kube_host = _parse_kube_host(d.pop("kube_host", UNSET))

        def _parse_join_command(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        join_command = _parse_join_command(d.pop("join_command", UNSET))

        def _parse_deleted_at(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        deleted_at = _parse_deleted_at(d.pop("deleted_at", UNSET))

        def _parse_user_fid(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        user_fid = _parse_user_fid(d.pop("user_fid", UNSET))

        kubernetes_cluster_model = cls(
            fid=fid,
            project=project,
            name=name,
            region=region,
            created_at=created_at,
            ssh_keys=ssh_keys,
            instances=instances,
            status=status,
            k8s_version=k8s_version,
            kube_host=kube_host,
            join_command=join_command,
            deleted_at=deleted_at,
            user_fid=user_fid,
        )

        kubernetes_cluster_model.additional_properties = d
        return kubernetes_cluster_model

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
