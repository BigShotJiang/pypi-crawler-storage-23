from __future__ import annotations

from enum import Enum


class GrantKind(str, Enum):
    MAX_GPUS = "max_gpus"
    MAX_INSTANCES = "max_instances"

    def __str__(self) -> str:
        return str(self.value)
