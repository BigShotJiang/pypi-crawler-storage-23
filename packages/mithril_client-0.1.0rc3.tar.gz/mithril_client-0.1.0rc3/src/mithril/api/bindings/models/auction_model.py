from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from typing_extensions import Self

from ..types import UNSET, Unset

T = TypeVar("T", bound="AuctionModel")


@_attrs_define
class AuctionModel:
    """
    Attributes:
        fid (str):
        instance_type (str):
        region (str):
        capacity (int):
        last_instance_price (str):
        adjustable_memory (bool):
        lowest_allocated_price (None | str | Unset):
        default_image_version (None | str | Unset):
    """

    fid: str
    instance_type: str
    region: str
    capacity: int
    last_instance_price: str
    adjustable_memory: bool
    lowest_allocated_price: None | str | Unset = UNSET
    default_image_version: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        fid = self.fid

        instance_type = self.instance_type

        region = self.region

        capacity = self.capacity

        last_instance_price = self.last_instance_price

        adjustable_memory = self.adjustable_memory

        lowest_allocated_price: None | str | Unset
        if isinstance(self.lowest_allocated_price, Unset):
            lowest_allocated_price = UNSET
        else:
            lowest_allocated_price = self.lowest_allocated_price

        default_image_version: None | str | Unset
        if isinstance(self.default_image_version, Unset):
            default_image_version = UNSET
        else:
            default_image_version = self.default_image_version

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "fid": fid,
                "instance_type": instance_type,
                "region": region,
                "capacity": capacity,
                "last_instance_price": last_instance_price,
                "adjustable_memory": adjustable_memory,
            }
        )
        if lowest_allocated_price is not UNSET:
            field_dict["lowest_allocated_price"] = lowest_allocated_price
        if default_image_version is not UNSET:
            field_dict["default_image_version"] = default_image_version

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        fid = d.pop("fid")

        instance_type = d.pop("instance_type")

        region = d.pop("region")

        capacity = d.pop("capacity")

        last_instance_price = d.pop("last_instance_price")

        adjustable_memory = d.pop("adjustable_memory")

        def _parse_lowest_allocated_price(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        lowest_allocated_price = _parse_lowest_allocated_price(
            d.pop("lowest_allocated_price", UNSET)
        )

        def _parse_default_image_version(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        default_image_version = _parse_default_image_version(
            d.pop("default_image_version", UNSET)
        )

        auction_model = cls(
            fid=fid,
            instance_type=instance_type,
            region=region,
            capacity=capacity,
            last_instance_price=last_instance_price,
            adjustable_memory=adjustable_memory,
            lowest_allocated_price=lowest_allocated_price,
            default_image_version=default_image_version,
        )

        auction_model.additional_properties = d
        return auction_model

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
