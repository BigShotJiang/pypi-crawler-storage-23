from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from typing_extensions import Self

from ..models.instance_status_response_status import InstanceStatusResponseStatus
from ..types import UNSET, Unset

T = TypeVar("T", bound="InstanceStatusResponse")


@_attrs_define
class InstanceStatusResponse:
    """Response model for instance status endpoint.

    Attributes:
        fid (str):
        name (str):
        status (InstanceStatusResponseStatus):
        bid (None | str | Unset):
        reservation (None | str | Unset):
        end_time (None | str | Unset):
    """

    fid: str
    name: str
    status: InstanceStatusResponseStatus
    bid: None | str | Unset = UNSET
    reservation: None | str | Unset = UNSET
    end_time: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        fid = self.fid

        name = self.name

        status = self.status.value

        bid: None | str | Unset
        if isinstance(self.bid, Unset):
            bid = UNSET
        else:
            bid = self.bid

        reservation: None | str | Unset
        if isinstance(self.reservation, Unset):
            reservation = UNSET
        else:
            reservation = self.reservation

        end_time: None | str | Unset
        if isinstance(self.end_time, Unset):
            end_time = UNSET
        else:
            end_time = self.end_time

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "fid": fid,
                "name": name,
                "status": status,
            }
        )
        if bid is not UNSET:
            field_dict["bid"] = bid
        if reservation is not UNSET:
            field_dict["reservation"] = reservation
        if end_time is not UNSET:
            field_dict["end_time"] = end_time

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        fid = d.pop("fid")

        name = d.pop("name")

        status = InstanceStatusResponseStatus(d.pop("status"))

        def _parse_bid(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        bid = _parse_bid(d.pop("bid", UNSET))

        def _parse_reservation(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        reservation = _parse_reservation(d.pop("reservation", UNSET))

        def _parse_end_time(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        end_time = _parse_end_time(d.pop("end_time", UNSET))

        instance_status_response = cls(
            fid=fid,
            name=name,
            status=status,
            bid=bid,
            reservation=reservation,
            end_time=end_time,
        )

        instance_status_response.additional_properties = d
        return instance_status_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
