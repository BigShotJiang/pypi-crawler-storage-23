from __future__ import annotations

from enum import Enum


class SizeUnit(str, Enum):
    B = "b"
    EB = "eb"
    GB = "gb"
    GIB = "gib"
    KB = "kb"
    MB = "mb"
    PB = "pb"
    PIB = "pib"
    TB = "tb"
    TIB = "tib"

    def __str__(self) -> str:
        return str(self.value)
