from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from typing_extensions import Self

from ..models.bid_history_event_model_event_type import BidHistoryEventModelEventType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.persistent_disk_change import PersistentDiskChange


T = TypeVar("T", bound="BidHistoryEventModel")


@_attrs_define
class BidHistoryEventModel:
    """A single event in the history of a spot bid.

    Attributes:
        timestamp (str): When the event occurred
        event_type (BidHistoryEventModelEventType):
        limit_price (None | str | Unset):
        user_id (None | str | Unset):
        memory_gb (int | None | Unset):
        persistent_disk_change (PersistentDiskChange | Unset):
    """

    timestamp: str
    event_type: BidHistoryEventModelEventType
    limit_price: None | str | Unset = UNSET
    user_id: None | str | Unset = UNSET
    memory_gb: int | None | Unset = UNSET
    persistent_disk_change: PersistentDiskChange | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        timestamp = self.timestamp

        event_type = self.event_type.value

        limit_price: None | str | Unset
        if isinstance(self.limit_price, Unset):
            limit_price = UNSET
        else:
            limit_price = self.limit_price

        user_id: None | str | Unset
        if isinstance(self.user_id, Unset):
            user_id = UNSET
        else:
            user_id = self.user_id

        memory_gb: int | None | Unset
        if isinstance(self.memory_gb, Unset):
            memory_gb = UNSET
        else:
            memory_gb = self.memory_gb

        persistent_disk_change: dict[str, Any] | Unset = UNSET
        if not isinstance(self.persistent_disk_change, Unset):
            persistent_disk_change = self.persistent_disk_change.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "timestamp": timestamp,
                "event_type": event_type,
            }
        )
        if limit_price is not UNSET:
            field_dict["limit_price"] = limit_price
        if user_id is not UNSET:
            field_dict["user_id"] = user_id
        if memory_gb is not UNSET:
            field_dict["memory_gb"] = memory_gb
        if persistent_disk_change is not UNSET:
            field_dict["persistent_disk_change"] = persistent_disk_change

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        from ..models.persistent_disk_change import PersistentDiskChange

        d = dict(src_dict)
        timestamp = d.pop("timestamp")

        event_type = BidHistoryEventModelEventType(d.pop("event_type"))

        def _parse_limit_price(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        limit_price = _parse_limit_price(d.pop("limit_price", UNSET))

        def _parse_user_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        user_id = _parse_user_id(d.pop("user_id", UNSET))

        def _parse_memory_gb(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        memory_gb = _parse_memory_gb(d.pop("memory_gb", UNSET))

        _persistent_disk_change = d.pop("persistent_disk_change", UNSET)
        persistent_disk_change: PersistentDiskChange | Unset
        if isinstance(_persistent_disk_change, Unset):
            persistent_disk_change = UNSET
        else:
            persistent_disk_change = PersistentDiskChange.from_dict(
                _persistent_disk_change
            )

        bid_history_event_model = cls(
            timestamp=timestamp,
            event_type=event_type,
            limit_price=limit_price,
            user_id=user_id,
            memory_gb=memory_gb,
            persistent_disk_change=persistent_disk_change,
        )

        bid_history_event_model.additional_properties = d
        return bid_history_event_model

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
