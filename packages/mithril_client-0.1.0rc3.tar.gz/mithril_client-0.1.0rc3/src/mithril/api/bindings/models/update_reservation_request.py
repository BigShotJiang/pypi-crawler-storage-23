from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from typing_extensions import Self

from ..types import UNSET, Unset

T = TypeVar("T", bound="UpdateReservationRequest")


@_attrs_define
class UpdateReservationRequest:
    """
    Attributes:
        paused (bool | None | Unset):
        volumes (list[str] | None | Unset):
    """

    paused: bool | None | Unset = UNSET
    volumes: list[str] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        paused: bool | None | Unset
        if isinstance(self.paused, Unset):
            paused = UNSET
        else:
            paused = self.paused

        volumes: list[str] | None | Unset
        if isinstance(self.volumes, Unset):
            volumes = UNSET
        elif isinstance(self.volumes, list):
            volumes = self.volumes

        else:
            volumes = self.volumes

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if paused is not UNSET:
            field_dict["paused"] = paused
        if volumes is not UNSET:
            field_dict["volumes"] = volumes

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)

        def _parse_paused(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        paused = _parse_paused(d.pop("paused", UNSET))

        def _parse_volumes(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError
                volumes_type_0 = cast(list[str], data)

                return volumes_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        volumes = _parse_volumes(d.pop("volumes", UNSET))

        update_reservation_request = cls(
            paused=paused,
            volumes=volumes,
        )

        update_reservation_request.additional_properties = d
        return update_reservation_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
