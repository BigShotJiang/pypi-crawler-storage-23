from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from typing_extensions import Self

T = TypeVar("T", bound="HistoricalPriceSeriesModel")


@_attrs_define
class HistoricalPriceSeriesModel:
    """A single time-series of prices for one instance type in one region.

    Attributes:
        instance_type (str):
        region (str):
        timestamps (list[str]):
        spot_prices (list[str]):
        reserved_prices (list[str]):
    """

    instance_type: str
    region: str
    timestamps: list[str]
    spot_prices: list[str]
    reserved_prices: list[str]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        instance_type = self.instance_type

        region = self.region

        timestamps = self.timestamps

        spot_prices = self.spot_prices

        reserved_prices = self.reserved_prices

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "instance_type": instance_type,
                "region": region,
                "timestamps": timestamps,
                "spot_prices": spot_prices,
                "reserved_prices": reserved_prices,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        instance_type = d.pop("instance_type")

        region = d.pop("region")

        timestamps = cast(list[str], d.pop("timestamps"))

        spot_prices = cast(list[str], d.pop("spot_prices"))

        reserved_prices = cast(list[str], d.pop("reserved_prices"))

        historical_price_series_model = cls(
            instance_type=instance_type,
            region=region,
            timestamps=timestamps,
            spot_prices=spot_prices,
            reserved_prices=reserved_prices,
        )

        historical_price_series_model.additional_properties = d
        return historical_price_series_model

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
