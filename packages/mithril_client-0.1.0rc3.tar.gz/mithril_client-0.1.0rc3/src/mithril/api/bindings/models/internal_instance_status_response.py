from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from typing_extensions import Self

from ..models.internal_instance_status_response_bid_status import (
    InternalInstanceStatusResponseBidStatus,
)
from ..models.internal_instance_status_response_instance_status import (
    InternalInstanceStatusResponseInstanceStatus,
)
from ..types import UNSET, Unset

T = TypeVar("T", bound="InternalInstanceStatusResponse")


@_attrs_define
class InternalInstanceStatusResponse:
    """Response for the combined mithril polling endpoint.

    Attributes:
        instance_fid (str):
        instance_status (InternalInstanceStatusResponseInstanceStatus):
        instance_name (str):
        bid_fid (None | str | Unset):
        bid_status (InternalInstanceStatusResponseBidStatus | Unset):
        end_time (None | str | Unset):
    """

    instance_fid: str
    instance_status: InternalInstanceStatusResponseInstanceStatus
    instance_name: str
    bid_fid: None | str | Unset = UNSET
    bid_status: InternalInstanceStatusResponseBidStatus | Unset = UNSET
    end_time: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        instance_fid = self.instance_fid

        instance_status = self.instance_status.value

        instance_name = self.instance_name

        bid_fid: None | str | Unset
        if isinstance(self.bid_fid, Unset):
            bid_fid = UNSET
        else:
            bid_fid = self.bid_fid

        bid_status: str | Unset = UNSET
        if not isinstance(self.bid_status, Unset):
            bid_status = self.bid_status.value

        end_time: None | str | Unset
        if isinstance(self.end_time, Unset):
            end_time = UNSET
        else:
            end_time = self.end_time

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "instance_fid": instance_fid,
                "instance_status": instance_status,
                "instance_name": instance_name,
            }
        )
        if bid_fid is not UNSET:
            field_dict["bid_fid"] = bid_fid
        if bid_status is not UNSET:
            field_dict["bid_status"] = bid_status
        if end_time is not UNSET:
            field_dict["end_time"] = end_time

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        instance_fid = d.pop("instance_fid")

        instance_status = InternalInstanceStatusResponseInstanceStatus(
            d.pop("instance_status")
        )

        instance_name = d.pop("instance_name")

        def _parse_bid_fid(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        bid_fid = _parse_bid_fid(d.pop("bid_fid", UNSET))

        _bid_status = d.pop("bid_status", UNSET)
        bid_status: InternalInstanceStatusResponseBidStatus | Unset
        if isinstance(_bid_status, Unset):
            bid_status = UNSET
        else:
            bid_status = InternalInstanceStatusResponseBidStatus(_bid_status)

        def _parse_end_time(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        end_time = _parse_end_time(d.pop("end_time", UNSET))

        internal_instance_status_response = cls(
            instance_fid=instance_fid,
            instance_status=instance_status,
            instance_name=instance_name,
            bid_fid=bid_fid,
            bid_status=bid_status,
            end_time=end_time,
        )

        internal_instance_status_response.additional_properties = d
        return internal_instance_status_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
