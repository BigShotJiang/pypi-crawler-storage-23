from __future__ import annotations

from enum import Enum


class ReservationModelStatus(str, Enum):
    ACTIVE = "Active"
    CANCELED = "Canceled"
    ENDED = "Ended"
    PAUSED = "Paused"
    PENDING = "Pending"

    def __str__(self) -> str:
        return str(self.value)
