from __future__ import annotations

from enum import Enum


class BidHistoryEventModelEventType(str, Enum):
    ALLOCATED = "Allocated"
    LIMIT_PRICE_CHANGED = "Limit Price Changed"
    MEMORY_ADJUSTED = "Memory Adjusted"
    PAUSED = "Paused"
    PLACED = "Placed"
    PREEMPTED = "Preempted"
    RESUMED = "Resumed"
    TERMINATED = "Terminated"
    VOLUMES_ATTACHED = "Volumes Attached"
    VOLUMES_REMOVED = "Volumes Removed"

    def __str__(self) -> str:
        return str(self.value)
