from __future__ import annotations

from enum import Enum


class CreateKubernetesClusterRequestK8SVersion(str, Enum):
    VALUE_0 = "1.34"
    VALUE_1 = "1.29"

    def __str__(self) -> str:
        return str(self.value)
