from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from typing_extensions import Self

from ..types import UNSET, Unset

T = TypeVar("T", bound="LaunchSpecificationModel")


@_attrs_define
class LaunchSpecificationModel:
    """
    Attributes:
        volumes (list[str]): List of volume FIDs
        ssh_keys (list[str]): List of SSH key FIDs
        startup_script (None | str | Unset):
        kubernetes_cluster (None | str | Unset):
        image_version (None | str | Unset):
        memory_gb (int | None | Unset):
    """

    volumes: list[str]
    ssh_keys: list[str]
    startup_script: None | str | Unset = UNSET
    kubernetes_cluster: None | str | Unset = UNSET
    image_version: None | str | Unset = UNSET
    memory_gb: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        volumes = self.volumes

        ssh_keys = self.ssh_keys

        startup_script: None | str | Unset
        if isinstance(self.startup_script, Unset):
            startup_script = UNSET
        else:
            startup_script = self.startup_script

        kubernetes_cluster: None | str | Unset
        if isinstance(self.kubernetes_cluster, Unset):
            kubernetes_cluster = UNSET
        else:
            kubernetes_cluster = self.kubernetes_cluster

        image_version: None | str | Unset
        if isinstance(self.image_version, Unset):
            image_version = UNSET
        else:
            image_version = self.image_version

        memory_gb: int | None | Unset
        if isinstance(self.memory_gb, Unset):
            memory_gb = UNSET
        else:
            memory_gb = self.memory_gb

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "volumes": volumes,
                "ssh_keys": ssh_keys,
            }
        )
        if startup_script is not UNSET:
            field_dict["startup_script"] = startup_script
        if kubernetes_cluster is not UNSET:
            field_dict["kubernetes_cluster"] = kubernetes_cluster
        if image_version is not UNSET:
            field_dict["image_version"] = image_version
        if memory_gb is not UNSET:
            field_dict["memory_gb"] = memory_gb

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        volumes = cast(list[str], d.pop("volumes"))

        ssh_keys = cast(list[str], d.pop("ssh_keys"))

        def _parse_startup_script(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        startup_script = _parse_startup_script(d.pop("startup_script", UNSET))

        def _parse_kubernetes_cluster(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        kubernetes_cluster = _parse_kubernetes_cluster(
            d.pop("kubernetes_cluster", UNSET)
        )

        def _parse_image_version(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        image_version = _parse_image_version(d.pop("image_version", UNSET))

        def _parse_memory_gb(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        memory_gb = _parse_memory_gb(d.pop("memory_gb", UNSET))

        launch_specification_model = cls(
            volumes=volumes,
            ssh_keys=ssh_keys,
            startup_script=startup_script,
            kubernetes_cluster=kubernetes_cluster,
            image_version=image_version,
            memory_gb=memory_gb,
        )

        launch_specification_model.additional_properties = d
        return launch_specification_model

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
