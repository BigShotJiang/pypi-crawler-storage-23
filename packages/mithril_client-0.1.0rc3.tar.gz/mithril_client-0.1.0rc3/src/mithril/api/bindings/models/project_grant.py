from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse
from typing_extensions import Self

from ..models.grant_kind import GrantKind

T = TypeVar("T", bound="ProjectGrant")


@_attrs_define
class ProjectGrant:
    """Grant for a project.

    Attributes:
        project_id (str):
        cluster (str):
        kind (GrantKind): Types of capacity grants.
        quantity (int):
        starts_at (datetime.datetime):
        ends_at (datetime.datetime):
        unit_price (float | str):
        early_termination_buyback_price (float | str):
        flexible_usage_buyback_price (float | str):
    """

    project_id: str
    cluster: str
    kind: GrantKind
    quantity: int
    starts_at: datetime.datetime
    ends_at: datetime.datetime
    unit_price: float | str
    early_termination_buyback_price: float | str
    flexible_usage_buyback_price: float | str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        project_id = self.project_id

        cluster = self.cluster

        kind = self.kind.value

        quantity = self.quantity

        starts_at = self.starts_at.isoformat()

        ends_at = self.ends_at.isoformat()

        unit_price: float | str
        unit_price = self.unit_price

        early_termination_buyback_price: float | str
        early_termination_buyback_price = self.early_termination_buyback_price

        flexible_usage_buyback_price: float | str
        flexible_usage_buyback_price = self.flexible_usage_buyback_price

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "project_id": project_id,
                "cluster": cluster,
                "kind": kind,
                "quantity": quantity,
                "starts_at": starts_at,
                "ends_at": ends_at,
                "unit_price": unit_price,
                "early_termination_buyback_price": early_termination_buyback_price,
                "flexible_usage_buyback_price": flexible_usage_buyback_price,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        project_id = d.pop("project_id")

        cluster = d.pop("cluster")

        kind = GrantKind(d.pop("kind"))

        quantity = d.pop("quantity")

        starts_at = isoparse(d.pop("starts_at"))

        ends_at = isoparse(d.pop("ends_at"))

        def _parse_unit_price(data: object) -> float | str:
            return cast(float | str, data)

        unit_price = _parse_unit_price(d.pop("unit_price"))

        def _parse_early_termination_buyback_price(data: object) -> float | str:
            return cast(float | str, data)

        early_termination_buyback_price = _parse_early_termination_buyback_price(
            d.pop("early_termination_buyback_price")
        )

        def _parse_flexible_usage_buyback_price(data: object) -> float | str:
            return cast(float | str, data)

        flexible_usage_buyback_price = _parse_flexible_usage_buyback_price(
            d.pop("flexible_usage_buyback_price")
        )

        project_grant = cls(
            project_id=project_id,
            cluster=cluster,
            kind=kind,
            quantity=quantity,
            starts_at=starts_at,
            ends_at=ends_at,
            unit_price=unit_price,
            early_termination_buyback_price=early_termination_buyback_price,
            flexible_usage_buyback_price=flexible_usage_buyback_price,
        )

        project_grant.additional_properties = d
        return project_grant

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
