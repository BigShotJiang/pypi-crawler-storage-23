from __future__ import annotations

from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.bid_status_response import BidStatusResponse
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    bid_fid: str,
) -> dict[str, Any]:
    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/spot/bids/{bid_fid}/status".format(
            bid_fid=quote(str(bid_fid), safe="")
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> BidStatusResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = BidStatusResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[BidStatusResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    bid_fid: str,
    *,
    client: AuthenticatedClient,
) -> Response[BidStatusResponse | HTTPValidationError]:
    r"""Get Bid Status

     Get detailed status of a Spot bid.

    Returns a detailed status that includes instance-level status information.
    The status can be one of: Open, Allocated, Preempting, Terminated,
    Paused, Relocating.

    \"Relocating\" indicates that part of the order is being relocated.

    Args:
        bid_fid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BidStatusResponse | HTTPValidationError]
    """
    kwargs = _get_kwargs(
        bid_fid=bid_fid,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    bid_fid: str,
    *,
    client: AuthenticatedClient,
) -> BidStatusResponse | HTTPValidationError | None:
    r"""Get Bid Status

     Get detailed status of a Spot bid.

    Returns a detailed status that includes instance-level status information.
    The status can be one of: Open, Allocated, Preempting, Terminated,
    Paused, Relocating.

    \"Relocating\" indicates that part of the order is being relocated.

    Args:
        bid_fid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BidStatusResponse | HTTPValidationError
    """
    return sync_detailed(
        bid_fid=bid_fid,
        client=client,
    ).parsed


async def asyncio_detailed(
    bid_fid: str,
    *,
    client: AuthenticatedClient,
) -> Response[BidStatusResponse | HTTPValidationError]:
    r"""Get Bid Status

     Get detailed status of a Spot bid.

    Returns a detailed status that includes instance-level status information.
    The status can be one of: Open, Allocated, Preempting, Terminated,
    Paused, Relocating.

    \"Relocating\" indicates that part of the order is being relocated.

    Args:
        bid_fid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BidStatusResponse | HTTPValidationError]
    """
    kwargs = _get_kwargs(
        bid_fid=bid_fid,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    bid_fid: str,
    *,
    client: AuthenticatedClient,
) -> BidStatusResponse | HTTPValidationError | None:
    r"""Get Bid Status

     Get detailed status of a Spot bid.

    Returns a detailed status that includes instance-level status information.
    The status can be one of: Open, Allocated, Preempting, Terminated,
    Paused, Relocating.

    \"Relocating\" indicates that part of the order is being relocated.

    Args:
        bid_fid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BidStatusResponse | HTTPValidationError
    """
    return (
        await asyncio_detailed(
            bid_fid=bid_fid,
            client=client,
        )
    ).parsed
