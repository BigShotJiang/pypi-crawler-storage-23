from __future__ import annotations

from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.grant_kind import GrantKind
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    kinds: list[GrantKind] | Unset = UNSET,
    cluster: None | str | Unset = UNSET,
    show_expired: bool | Unset = False,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    json_kinds: list[str] | Unset = UNSET
    if not isinstance(kinds, Unset):
        json_kinds = []
        for kinds_item_data in kinds:
            kinds_item = kinds_item_data.value
            json_kinds.append(kinds_item)

    params["kinds"] = json_kinds

    json_cluster: None | str | Unset
    if isinstance(cluster, Unset):
        json_cluster = UNSET
    else:
        json_cluster = cluster
    params["cluster"] = json_cluster

    params["show_expired"] = show_expired

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/grants",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | list[Any] | None:
    if response.status_code == 200:
        response_200 = cast(list[Any], response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | list[Any]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    kinds: list[GrantKind] | Unset = UNSET,
    cluster: None | str | Unset = UNSET,
    show_expired: bool | Unset = False,
) -> Response[HTTPValidationError | list[Any]]:
    """List Grants

     List grants for the user's organization.

    Args:
        cluster: Filter by cluster ID.
        kinds: Filter by grant kinds.
        show_expired: Include expired/deleted grants (default False).

    Args:
        kinds (list[GrantKind] | Unset):
        cluster (None | str | Unset):
        show_expired (bool | Unset):  Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[Any]]
    """
    kwargs = _get_kwargs(
        kinds=kinds,
        cluster=cluster,
        show_expired=show_expired,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    kinds: list[GrantKind] | Unset = UNSET,
    cluster: None | str | Unset = UNSET,
    show_expired: bool | Unset = False,
) -> HTTPValidationError | list[Any] | None:
    """List Grants

     List grants for the user's organization.

    Args:
        cluster: Filter by cluster ID.
        kinds: Filter by grant kinds.
        show_expired: Include expired/deleted grants (default False).

    Args:
        kinds (list[GrantKind] | Unset):
        cluster (None | str | Unset):
        show_expired (bool | Unset):  Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[Any]
    """
    return sync_detailed(
        client=client,
        kinds=kinds,
        cluster=cluster,
        show_expired=show_expired,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    kinds: list[GrantKind] | Unset = UNSET,
    cluster: None | str | Unset = UNSET,
    show_expired: bool | Unset = False,
) -> Response[HTTPValidationError | list[Any]]:
    """List Grants

     List grants for the user's organization.

    Args:
        cluster: Filter by cluster ID.
        kinds: Filter by grant kinds.
        show_expired: Include expired/deleted grants (default False).

    Args:
        kinds (list[GrantKind] | Unset):
        cluster (None | str | Unset):
        show_expired (bool | Unset):  Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[Any]]
    """
    kwargs = _get_kwargs(
        kinds=kinds,
        cluster=cluster,
        show_expired=show_expired,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    kinds: list[GrantKind] | Unset = UNSET,
    cluster: None | str | Unset = UNSET,
    show_expired: bool | Unset = False,
) -> HTTPValidationError | list[Any] | None:
    """List Grants

     List grants for the user's organization.

    Args:
        cluster: Filter by cluster ID.
        kinds: Filter by grant kinds.
        show_expired: Include expired/deleted grants (default False).

    Args:
        kinds (list[GrantKind] | Unset):
        cluster (None | str | Unset):
        show_expired (bool | Unset):  Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[Any]
    """
    return (
        await asyncio_detailed(
            client=client,
            kinds=kinds,
            cluster=cluster,
            show_expired=show_expired,
        )
    ).parsed
