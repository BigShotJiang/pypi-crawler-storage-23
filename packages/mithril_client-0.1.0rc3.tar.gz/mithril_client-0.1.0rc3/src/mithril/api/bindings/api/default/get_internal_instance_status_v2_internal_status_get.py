from __future__ import annotations

from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.internal_instance_status_response import InternalInstanceStatusResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    instance_fid: str,
    bid_fid: None | str | Unset = UNSET,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    params["instance_fid"] = instance_fid

    json_bid_fid: None | str | Unset
    if isinstance(bid_fid, Unset):
        json_bid_fid = UNSET
    else:
        json_bid_fid = bid_fid
    params["bid_fid"] = json_bid_fid

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/internal/status",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | InternalInstanceStatusResponse | None:
    if response.status_code == 200:
        response_200 = InternalInstanceStatusResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | InternalInstanceStatusResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    instance_fid: str,
    bid_fid: None | str | Unset = UNSET,
) -> Response[HTTPValidationError | InternalInstanceStatusResponse]:
    """Get Internal Instance Status

     Combined polling endpoint for mithril-authenticated VMs.

    Returns instance status, bid status, and end_time in a single request.
    Uses lightweight DB queries and cached authentication.

    Args:
        instance_fid (str):
        bid_fid (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | InternalInstanceStatusResponse]
    """
    kwargs = _get_kwargs(
        instance_fid=instance_fid,
        bid_fid=bid_fid,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    instance_fid: str,
    bid_fid: None | str | Unset = UNSET,
) -> HTTPValidationError | InternalInstanceStatusResponse | None:
    """Get Internal Instance Status

     Combined polling endpoint for mithril-authenticated VMs.

    Returns instance status, bid status, and end_time in a single request.
    Uses lightweight DB queries and cached authentication.

    Args:
        instance_fid (str):
        bid_fid (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | InternalInstanceStatusResponse
    """
    return sync_detailed(
        client=client,
        instance_fid=instance_fid,
        bid_fid=bid_fid,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    instance_fid: str,
    bid_fid: None | str | Unset = UNSET,
) -> Response[HTTPValidationError | InternalInstanceStatusResponse]:
    """Get Internal Instance Status

     Combined polling endpoint for mithril-authenticated VMs.

    Returns instance status, bid status, and end_time in a single request.
    Uses lightweight DB queries and cached authentication.

    Args:
        instance_fid (str):
        bid_fid (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | InternalInstanceStatusResponse]
    """
    kwargs = _get_kwargs(
        instance_fid=instance_fid,
        bid_fid=bid_fid,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    instance_fid: str,
    bid_fid: None | str | Unset = UNSET,
) -> HTTPValidationError | InternalInstanceStatusResponse | None:
    """Get Internal Instance Status

     Combined polling endpoint for mithril-authenticated VMs.

    Returns instance status, bid status, and end_time in a single request.
    Uses lightweight DB queries and cached authentication.

    Args:
        instance_fid (str):
        bid_fid (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | InternalInstanceStatusResponse
    """
    return (
        await asyncio_detailed(
            client=client,
            instance_fid=instance_fid,
            bid_fid=bid_fid,
        )
    ).parsed
