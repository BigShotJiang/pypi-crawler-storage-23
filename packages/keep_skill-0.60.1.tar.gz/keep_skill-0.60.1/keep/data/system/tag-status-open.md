---
tags:
  category: system
  context: tag-value
---
# status: `open`

Active and unfulfilled. The initial state for commitments, requests, and offers. Work is in progress or awaiting action.

## Prompt

Default status when the outcome is not yet known. If a commitment or request is stated and no later fragment shows it was completed or cancelled, use open.
