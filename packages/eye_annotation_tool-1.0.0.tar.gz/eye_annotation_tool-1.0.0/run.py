"""Entry point script for running the eye annotation application."""

from annotation_app import run_app

if __name__ == "__main__":
    run_app()
