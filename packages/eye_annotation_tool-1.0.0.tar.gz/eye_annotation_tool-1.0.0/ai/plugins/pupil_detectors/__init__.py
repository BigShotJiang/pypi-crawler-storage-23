"""Pupil detector plugins."""
