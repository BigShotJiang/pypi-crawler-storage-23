"""Iris detector plugins."""
