"""Eyelid detector plugins."""
