"""AI detector plugins for pupil, iris, and eyelid detection."""

# This file can be left empty
# It marks the plugins directory as a Python package
