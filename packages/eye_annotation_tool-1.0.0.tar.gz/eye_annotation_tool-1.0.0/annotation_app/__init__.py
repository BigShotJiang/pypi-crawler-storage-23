"""Eye annotation application package."""

from ._version import version as __version__
from .main import run_app

__author__ = "Mohammadhossein Salari"
__email__ = "mohammadhossein.salari@gmail.com"

__all__ = ["run_app", "__version__", "__author__", "__email__"]
