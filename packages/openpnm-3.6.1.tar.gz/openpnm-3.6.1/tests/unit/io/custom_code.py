def test(target):
    return 1.0
