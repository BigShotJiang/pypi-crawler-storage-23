class ThroatNormalTest:
    def test_voronoi(self):
        pass
