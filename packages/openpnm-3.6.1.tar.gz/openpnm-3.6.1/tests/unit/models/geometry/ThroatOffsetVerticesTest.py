class ThroatOffsetVerticesTest:
    def test_voronoi(self):
        pass
