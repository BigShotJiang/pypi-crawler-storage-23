r"""
Pore Seed Models
----------------

Generates pore seeds that are spatailly correlated with their neighbors.

"""

from ._funcs import *
