r"""
Throat Cross-sectional Area Models
----------------------------------

This model contains a selection of functions for calculating
throat cross-sectional area.

"""

from ._funcs import *
