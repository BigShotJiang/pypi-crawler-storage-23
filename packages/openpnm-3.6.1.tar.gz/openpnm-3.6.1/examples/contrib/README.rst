
:orphan:

Contibuted Examples
-------------------

This folder contains code that has been contributed by a user (or developer) that is not quite ready to be included in OpenPNM permanently, but is worth including in the repository so it can be accessible via Github.  

The files in this folder are NOT included in the testing suite so they are not gauranteed to work.  Usually only a small fix is required to get them going.  It is generally encourage to include the ``openpnm.__version__`` number in the code so readers know at least which version of openpnm it was intened to work with.
