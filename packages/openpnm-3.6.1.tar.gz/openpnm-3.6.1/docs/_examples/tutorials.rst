.. _tutorials:

#########################
10 Steps to Learn OpenPNM
#########################

.. tab-set::

   .. tab-item:: Tutorials

      .. toctree::
         :maxdepth: 1
         :glob:

         ../examples/tutorials/*
