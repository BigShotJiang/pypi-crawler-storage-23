.. _examples_index:

########
Examples
########

The best way to learn OpenPNM (like anything) is to experiment.
In this page, you can find lots of examples that will help you get started.
The examples are categorized into the following categories:

.. toctree::
   :maxdepth: 2

   ../examples/getting_started
   tutorials
   applications
   reference
