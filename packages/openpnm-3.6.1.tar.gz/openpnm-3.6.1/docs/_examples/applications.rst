.. _applications:

############
Applications
############

.. tab-set::

   .. tab-item:: Applications

      .. toctree::
         :maxdepth: 1
         :glob:

         ../examples/applications/*
