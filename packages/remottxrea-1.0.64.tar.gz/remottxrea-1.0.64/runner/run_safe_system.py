# remottxrea/runner/run_safe_system.py

import asyncio

from remottxrea.runner.multi_session_runner import (
    MultiSessionRunner
)

from remottxrea.runner.safe_loop_runner import (
    SafeAsyncLooper
)

from remottxrea.circadian.scheduler import (
    CircadianScheduler
)


async def main():

    # -------------------------
    # LOAD CLIENTS
    # -------------------------
    runner = MultiSessionRunner()
    runner.load_all()

    clients = runner.clients

    # -------------------------
    # INIT SYSTEMS
    # -------------------------
    looper = SafeAsyncLooper()

    scheduler = CircadianScheduler(
        clients=clients,
        duration_hours=12
    )

    # -------------------------
    # RUN BOTH
    # -------------------------
    await asyncio.gather(

        # Circadian engine
        scheduler.run(),

        # Automation loops
        looper.run_all(clients)
    )


if __name__ == "__main__":
    asyncio.run(main())
