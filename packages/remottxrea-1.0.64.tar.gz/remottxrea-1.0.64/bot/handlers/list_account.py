from remottxrea.actions.account_overview import AccountOverview


class AccountOverviewHandler:

    def __init__(self, runner):
        self.runner = runner

    async def handle(self, message):

        msg = await message.reply_text("⏳ Inspecting accounts...")

        overview = AccountOverview(self.runner)
        table = await overview.run()

        await msg.edit_text(f"```\n{table}\n```")