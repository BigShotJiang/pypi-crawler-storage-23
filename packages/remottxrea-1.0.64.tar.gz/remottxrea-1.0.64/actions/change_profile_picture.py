from pyrogram.errors import FloodWait

from remottxrea.core.safe_executor import SafeExecutor
from remottxrea.core.delay_engine import delay_engine
from remottxrea.core.flood_handler import flood_handler
from remottxrea.core.logger import get_action_logger


class ProfilePhotoChanger:

    def __init__(self, client, session):

        self.client = client
        self.session = session
        self.log = get_action_logger(
            "profile_photo",
            session
        )

    async def _exec(self, path):

        await self.client.set_profile_photo(
            photo=path
        )

    async def upload(self, file_path):

        try:

            await delay_engine.profile_delay()

            await SafeExecutor.run(
                self._exec(file_path),
                self.session,
                "profile_photo"
            )

            self.log.info(
                f"Photo updated → {file_path}"
            )

            return True

        except FloodWait as e:

            self.log.warning(
                f"Flood {e.value}s"
            )

            await flood_handler.handle(
                e,
                self.session,
                "profile_photo"
            )

        except Exception as e:

            self.log.exception(e)

        return False
