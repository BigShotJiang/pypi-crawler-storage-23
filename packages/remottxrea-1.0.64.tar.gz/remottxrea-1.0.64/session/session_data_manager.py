# remottxrea/session/session_data_manager.py

import os
import json

from remottxrea.config.main_config import SESSIONS_DIR


class SessionDataManager:

    # ---------- PATH ----------
    def get_path(self, phone: str):

        return os.path.join(
            SESSIONS_DIR,
            f"{phone}_data.json"
        )

    # ---------- SAVE ----------
    def save(self, phone: str, data: dict):

        path = self.get_path(phone)

        with open(path, "w", encoding="utf-8") as f:
            json.dump(
                data,
                f,
                indent=4,
                ensure_ascii=False
            )

    # ---------- LOAD ----------
    def load(self, phone: str):

        path = self.get_path(phone)

        if not os.path.exists(path):
            return None

        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    # ---------- EXISTS ----------
    def exists(self, phone: str):

        return os.path.exists(
            self.get_path(phone)
        )


session_data_manager = SessionDataManager()
