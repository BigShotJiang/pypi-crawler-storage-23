# device_profile.py

import random


DEVICE_POOL = [

    {
        "device_model": "Samsung Galaxy S23",
        "system_version": "Android 14",
        "app_version": "10.5.1",
        "system_lang_code": "en",
        "lang_code": "en"
    },

    {
        "device_model": "Xiaomi 13",
        "system_version": "Android 13",
        "app_version": "10.3.2",
        "system_lang_code": "en",
        "lang_code": "en"
    },

    {
        "device_model": "Google Pixel 8",
        "system_version": "Android 14",
        "app_version": "10.6.0",
        "system_lang_code": "en",
        "lang_code": "en"
    }
]


def get_random_device():
    return random.choice(DEVICE_POOL)
