# remottxrea/config/main_config.py

import os
from typing import Iterable

from remottxrea.core.logger import get_action_logger


class Config:

    API_ID = 33059517
    API_HASH = "f7f7200dcbd0f8038bb5af206b1e5c19"
    BOT_TOKEN = "YOUR_BOT_TOKEN"
    ADMIN_IDS = [123456789]

    logger = get_action_logger(
        action="config",
        session="global"
    )

    BASE_DIR = os.path.dirname(os.path.dirname(__file__))
    SESSIONS_DIR = os.path.join(BASE_DIR, "sessions")

    RATE_LIMIT_DELAY = 2.5
    MAX_FLOOD_SLEEP = 300


# ---------- EXPORT SHORTCUTS ----------

API_ID = Config.API_ID
API_HASH = Config.API_HASH
BOT_TOKEN = Config.BOT_TOKEN
SESSIONS_DIR = Config.SESSIONS_DIR
ADMIN_IDS = Config.ADMIN_IDS
RATE_LIMIT_DELAY = Config.RATE_LIMIT_DELAY
MAX_FLOOD_SLEEP = Config.MAX_FLOOD_SLEEP

def update_bot_token(new_token: str) -> None:
    """
    Safely update BOT_TOKEN at runtime.
    Sync both Config and module-level alias.
    """

    if not isinstance(new_token, str) or not new_token.strip():
        raise ValueError("BOT_TOKEN must be a non-empty string")

    # تلگرام بات توکن‌ها معمولاً شامل ':' هستند
    if ":" not in new_token:
        raise ValueError("Invalid BOT_TOKEN format")

    Config.BOT_TOKEN = new_token.strip()

    # sync export alias
    global BOT_TOKEN
    BOT_TOKEN = Config.BOT_TOKEN
    
def update_admins(new_admins: Iterable[int]) -> None:
    """
    Merge external admin IDs into Config.ADMIN_IDS safely.
    Prevent duplicates.
    """

    unique_ids = set(Config.ADMIN_IDS)
    unique_ids.update(int(x) for x in new_admins)

    Config.ADMIN_IDS = list(unique_ids)

    # sync export alias
    global ADMIN_IDS
    ADMIN_IDS = Config.ADMIN_IDS

def update_api_credentials(api_id: int, api_hash: str) -> None:
    """
    Update API_ID and API_HASH safely.
    """

    if not isinstance(api_id, int):
        raise ValueError("API_ID must be int")

    if not isinstance(api_hash, str) or len(api_hash) < 30:
        raise ValueError("Invalid API_HASH")

    Config.API_ID = api_id
    Config.API_HASH = api_hash

    global API_ID, API_HASH
    API_ID = Config.API_ID
    API_HASH = Config.API_HASH


def is_admin(user_id: int) -> bool:
    return user_id in Config.ADMIN_IDS



os.makedirs(SESSIONS_DIR, exist_ok=True)

