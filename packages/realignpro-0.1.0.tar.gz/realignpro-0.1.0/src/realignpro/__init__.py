"""ReAlignPro package.

Command-line entry point:
  realignpro fa2maf
  realignpro maf2bed
  realignpro tsv2fig
"""

__all__ = ["__version__"]
__version__ = "0.1.0"
