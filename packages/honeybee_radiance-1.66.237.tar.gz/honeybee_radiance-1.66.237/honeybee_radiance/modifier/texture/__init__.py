"""Radiance Textures."""

from .texdata import Texdata
from .texfunc import Texfunc
