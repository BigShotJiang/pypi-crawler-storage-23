"""honeybee-radiance properties."""
