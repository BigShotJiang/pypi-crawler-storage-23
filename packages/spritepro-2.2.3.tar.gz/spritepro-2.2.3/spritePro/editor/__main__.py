from . import launch_editor


if __name__ == "__main__":
    launch_editor()
