# Cognee NetworkX Adapter

## Install

Install [`networkx-client`] in your project.

Put this line of code somewhere at the start of the execution, before cognee is initiated.

```python
import packages.graph.networkx.networkx_adapter
```

## Example
See example in `example.py` file.