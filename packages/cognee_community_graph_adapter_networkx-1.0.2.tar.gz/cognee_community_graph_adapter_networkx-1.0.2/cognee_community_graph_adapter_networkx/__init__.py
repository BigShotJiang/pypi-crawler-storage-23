from .networkx_adapter import NetworkXAdapter as NetworkXAdapter
