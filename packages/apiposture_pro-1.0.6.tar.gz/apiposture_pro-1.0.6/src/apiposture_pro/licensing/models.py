"""License data models."""

from dataclasses import dataclass
from datetime import datetime
from enum import Enum


class LicenseErrorCode(str, Enum):
    """Error codes for license validation failures."""

    NONE = "none"
    INVALID_KEY = "invalid_key"
    EXPIRED = "expired"
    MACHINE_MISMATCH = "machine_mismatch"
    REVOKED = "revoked"
    TOO_MANY_ACTIVATIONS = "too_many_activations"
    NETWORK_ERROR = "network_error"
    GRACE_PERIOD_EXPIRED = "grace_period_expired"
    INVALID_SIGNATURE = "invalid_signature"


class LicenseType(str, Enum):
    """License type determining binding behavior."""

    DEVELOPER = "developer"
    CI = "ci"


class LicenseFeature(str, Enum):
    """Individually gated license features."""

    DIFF = "diff"
    HISTORY = "history"
    RISK_SCORING = "risk_scoring"
    OWASP_RULES = "owasp_rules"
    SECRETS = "secrets"


@dataclass
class LicenseContext:
    """License information from validated JWT token."""

    license_key: str
    tier: str  # "pro", "enterprise"
    features: list[str]
    expires_at: datetime
    customer_name: str
    customer_email: str
    machine_id: str | None = None
    organization: str | None = None
    seats: int | None = None
    license_type: LicenseType = LicenseType.DEVELOPER


@dataclass
class StoredLicense:
    """License information stored locally."""

    license_key: str
    activated_at: datetime
    last_validated_at: datetime
    machine_id: str
    token: str | None = None  # JWT token returned by the activation server
    context: LicenseContext | None = None


@dataclass
class LicenseValidationResult:
    """Result of license validation with detailed error information."""

    is_valid: bool
    error_code: LicenseErrorCode = LicenseErrorCode.NONE
    error_message: str = ""
    context: LicenseContext | None = None
    is_in_grace_period: bool = False
    grace_period_days_remaining: int = 0
