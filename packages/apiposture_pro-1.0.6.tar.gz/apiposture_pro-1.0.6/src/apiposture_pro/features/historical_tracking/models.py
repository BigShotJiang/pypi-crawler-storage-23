"""Models for historical tracking."""

from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class GitInfo:
    """Git repository information."""

    commit_sha: str | None = None
    branch: str | None = None
    is_dirty: bool = False
    remote_url: str | None = None


@dataclass
class ScanRecord:
    """Record of a historical scan."""

    id: int | None = None
    project_path: str = ""
    scan_time: datetime | None = None
    total_endpoints: int = 0
    total_findings: int = 0
    critical_count: int = 0
    high_count: int = 0
    medium_count: int = 0
    low_count: int = 0
    info_count: int = 0
    risk_score: int = 0
    git_commit: str | None = None
    git_branch: str | None = None
    git_is_dirty: bool = False
    scan_duration_ms: int = 0
    findings_json: str | None = None
    tags: list[str] = field(default_factory=list)
    scanned_files_count: int = 0
    failed_files_count: int = 0

    @property
    def severity_breakdown(self) -> str:
        """Get human-readable severity breakdown."""
        parts = []
        if self.critical_count > 0:
            parts.append(f"CRITICAL: {self.critical_count}")
        if self.high_count > 0:
            parts.append(f"HIGH: {self.high_count}")
        if self.medium_count > 0:
            parts.append(f"MEDIUM: {self.medium_count}")
        if self.low_count > 0:
            parts.append(f"LOW: {self.low_count}")
        if self.info_count > 0:
            parts.append(f"INFO: {self.info_count}")
        return ", ".join(parts) if parts else "No findings"
