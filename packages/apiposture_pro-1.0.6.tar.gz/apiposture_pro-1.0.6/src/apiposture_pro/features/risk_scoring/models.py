"""Models for risk scoring."""

from dataclasses import dataclass
from enum import Enum


class RiskLevel(str, Enum):
    """Risk level classification."""

    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"
    MINIMAL = "MINIMAL"


@dataclass
class RiskScore:
    """Comprehensive risk score for a scan."""

    total_score: int  # 0-100
    risk_level: RiskLevel

    # Component scores
    findings_score: int  # 0-50 (50% weight)
    exposure_score: int  # 0-30 (30% weight)
    surface_area_score: int  # 0-20 (20% weight)

    # Metadata
    total_findings: int = 0
    critical_findings: int = 0
    high_findings: int = 0
    total_endpoints: int = 0
    public_endpoints: int = 0

    @classmethod
    def get_risk_level(cls, score: int) -> RiskLevel:
        """
        Determine risk level from score.

        Args:
            score: Total risk score (0-100)

        Returns:
            RiskLevel classification
        """
        if score >= 75:
            return RiskLevel.CRITICAL
        if score >= 50:
            return RiskLevel.HIGH
        if score >= 25:
            return RiskLevel.MEDIUM
        if score > 0:
            return RiskLevel.LOW
        return RiskLevel.MINIMAL

    @property
    def color(self) -> str:
        """Get color for display based on risk level."""
        colors = {
            RiskLevel.CRITICAL: "red",
            RiskLevel.HIGH: "red",
            RiskLevel.MEDIUM: "yellow",
            RiskLevel.LOW: "blue",
            RiskLevel.MINIMAL: "green",
        }
        return colors.get(self.risk_level, "white")

    @property
    def summary(self) -> str:
        """Get human-readable summary."""
        lines = [
            f"Risk Score: {self.total_score}/100 ({self.risk_level.value})",
            "",
            "Component Scores:",
            f"  Findings: {self.findings_score}/50",
            f"  Exposure: {self.exposure_score}/30",
            f"  Surface Area: {self.surface_area_score}/20",
            "",
            "Metrics:",
            f"  Total Findings: {self.total_findings}",
            f"  Critical/High: {self.critical_findings + self.high_findings}",
            f"  Public Endpoints: {self.public_endpoints}/{self.total_endpoints}",
        ]
        return "\n".join(lines)
