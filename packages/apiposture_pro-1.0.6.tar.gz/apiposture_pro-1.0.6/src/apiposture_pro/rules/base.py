"""Base class for Pro security rules."""

from apiposture.rules.base import SecurityRule


class ProSecurityRule(SecurityRule):
    """
    Base class for Pro-only security rules.

    Pro rules extend the free version's SecurityRule with additional
    capabilities and more sophisticated analysis.
    """

    @property
    def is_pro_rule(self) -> bool:
        """Identify this as a Pro rule."""
        return True
