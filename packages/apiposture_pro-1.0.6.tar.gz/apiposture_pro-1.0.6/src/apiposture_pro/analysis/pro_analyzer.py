"""Pro analyzer that extends the free version with additional features."""

from pathlib import Path

from apiposture.core.analysis.project_analyzer import ProjectAnalyzer
from apiposture.core.models.scan_result import ScanResult

from apiposture_pro.features.risk_scoring.calculator import RiskScoreCalculator
from apiposture_pro.rules.file_level.ap016_insecure_dependencies import (
    AP016InsecureDependencies,
)
from apiposture_pro.rules.owasp.ap009_broken_auth import AP009BrokenAuthentication
from apiposture_pro.rules.owasp.ap010_injection_vectors import AP010InjectionVectors
from apiposture_pro.rules.owasp.ap011_broken_access_control import (
    AP011BrokenAccessControl,
)
from apiposture_pro.rules.owasp.ap012_security_misconfiguration import (
    AP012SecurityMisconfiguration,
)
from apiposture_pro.rules.owasp.ap013_vulnerable_components import (
    AP013VulnerableComponents,
)
from apiposture_pro.rules.secrets.ap014_hardcoded_secrets import AP014HardcodedSecrets
from apiposture_pro.rules.secrets.ap015_api_key_exposure import AP015APIKeyExposure


class ProAnalyzer:
    """
    Pro analyzer that wraps the free version's ProjectAnalyzer
    and adds Pro features like additional rules and risk scoring.
    """

    def __init__(self) -> None:
        """Initialize Pro analyzer."""
        self.analyzer = ProjectAnalyzer()
        self.risk_calculator = RiskScoreCalculator()
        self._register_pro_rules()

    def _register_pro_rules(self) -> None:
        """Register Pro-only security rules."""
        # Add Pro rules to the analyzer's rule engine
        pro_rules = [
            AP009BrokenAuthentication(),
            AP010InjectionVectors(),
            AP011BrokenAccessControl(),
            AP012SecurityMisconfiguration(),
            AP013VulnerableComponents(),
            AP014HardcodedSecrets(),
            AP015APIKeyExposure(),
            AP016InsecureDependencies(),
        ]

        # Add Pro rules to the all_rules list.
        # Note: when no enabled_rules filter is set, _rules IS _all_rules
        # (same list object), so we only extend _all_rules to avoid duplicates.
        self.analyzer.rule_engine._all_rules.extend(pro_rules)
        if self.analyzer.rule_engine._rules is not self.analyzer.rule_engine._all_rules:
            self.analyzer.rule_engine._rules.extend(pro_rules)

    def analyze(self, project_path: Path) -> ScanResult:
        """
        Analyze a project with Pro features.

        Args:
            project_path: Path to project directory

        Returns:
            ScanResult with findings and endpoints (with risk_score attribute)
        """
        # Use free version's analyzer
        result = self.analyzer.analyze(project_path)

        # Calculate risk score
        risk_score = self.risk_calculator.calculate(result)

        # Attach risk score to result (as dynamic attribute)
        result.risk_score = risk_score.total_score
        result.risk_level = risk_score.risk_level.value
        result.risk_details = risk_score

        return result
