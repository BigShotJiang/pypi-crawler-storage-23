# My Threadpool project

## Building
`python -m build `

## Deploying
`python -m twine upload --repository testpypi dist/*`