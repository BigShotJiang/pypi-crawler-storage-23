# textanalyzer/base_analyzer.py

def count_chars(text: str) -> int:
    """统计字符总数"""
    return len(text)

def count_words(text: str) -> int:
    """统计单词数量"""
    return len(text.split())

def count_sentences(text: str) -> int:
    """简单统计句子数量"""
    return text.count('.') + text.count('!') + text.count('?')

def analyze_text(text: str) -> dict:
    """返回文本的综合统计信息"""
    return {
        'chars': count_chars(text),
        'words': count_words(text),
        'sentences': count_sentences(text)
    }
