from .base_analyzer import analyze_text, count_chars, count_words, count_sentences
from .nltk_analyzer import tokenize, word_frequency
from .plot_utils import plot_word_frequency
from .sentiment_analyzer import analyze_sentiment, get_sentiment_label  # 新增

__all__ = [
    'analyze_text', 'count_chars', 'count_words', 'count_sentences',
    'tokenize', 'word_frequency', 'plot_word_frequency',
    'analyze_sentiment', 'get_sentiment_label'  # 新增
]

__version__ = '0.2.0'  # 同步升级版本号
