# textanalyzer/plot_utils.py
import matplotlib.pyplot as plt

def plot_word_frequency(freq_dict: dict, title: str = "Word Frequency"):
    """绘制词频柱状图"""
    words = list(freq_dict.keys())
    counts = list(freq_dict.values())
    
    plt.figure(figsize=(10, 6))
    plt.bar(words, counts)
    plt.title(title)
    plt.xlabel("Words")
    plt.ylabel("Frequency")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()
