class AuthError(Exception):
    pass
