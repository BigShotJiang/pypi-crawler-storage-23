class UnexpectedArgumentError(Exception):
    pass
