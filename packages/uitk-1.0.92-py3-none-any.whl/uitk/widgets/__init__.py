# !/usr/bin/python
# coding=utf-8
"""UITK widgets subpackage.

All classes are lazy-loaded via uitk root package.
Import from uitk directly: from uitk import [ClassName]
"""

# Lazy-loaded via parent package - no explicit imports needed
