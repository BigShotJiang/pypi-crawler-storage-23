## 🎉 What's New

<!-- Describe the main highlights of this release -->

## ✨ Features

<!-- List new features added in this release -->
- 

## 🐛 Bug Fixes

<!-- List bugs that were fixed in this release -->
- 

## 📝 Documentation

<!-- List documentation improvements -->
- 

## 🔧 Improvements

<!-- List improvements and enhancements -->
- 

## ⚠️ Breaking Changes

<!-- List any breaking changes that users need to be aware of -->
- None

## 📦 Dependencies

<!-- List any dependency updates -->
- 

## 🙏 Contributors

<!-- Thank contributors to this release -->
Thank you to everyone who contributed to this release!

---

## 📚 Resources

- **Documentation:** [README.md](https://github.com/kamera-linux/vogel-model-trainer/blob/main/README.md)
- **Installation:** `pip install vogel-model-trainer`
- **Issues:** [Report a bug](https://github.com/kamera-linux/vogel-model-trainer/issues/new?template=bug_report.md)
- **Changelog:** [CHANGELOG.md](https://github.com/kamera-linux/vogel-model-trainer/blob/main/CHANGELOG.md)
