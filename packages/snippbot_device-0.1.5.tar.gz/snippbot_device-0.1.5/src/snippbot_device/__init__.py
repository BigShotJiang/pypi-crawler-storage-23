"""Snippbot Device Agent - connect any machine to Snippbot."""

__version__ = "0.1.5"
