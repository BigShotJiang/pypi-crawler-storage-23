"""WebSocket connection to the Snippbot daemon with automatic reconnection."""

from __future__ import annotations

import asyncio
import hashlib
import hmac
import json
import logging
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable, Awaitable

import websockets
import websockets.client
from websockets.exceptions import (
    ConnectionClosed,
    ConnectionClosedError,
    ConnectionClosedOK,
    InvalidStatusCode,
)

logger = logging.getLogger(__name__)

RECONNECT_DELAYS = [1, 2, 5, 10, 30, 60]
MAX_RECONNECT_ATTEMPTS = 20


class MessageType(str, Enum):
    """Message types matching the daemon's DeviceProtocol."""

    # Authentication handshake
    AUTH_CHALLENGE = "auth_challenge"
    AUTH_RESPONSE = "auth_response"
    AUTH_OK = "auth_ok"
    AUTH_FAILED = "auth_failed"

    # Capability negotiation
    CAPABILITIES_ADVERTISE = "capabilities_advertise"
    CAPABILITIES_ACK = "capabilities_ack"
    CAPABILITIES_REJECT = "capabilities_reject"

    # Tool execution
    TOOL_REQUEST = "tool_request"
    TOOL_RESULT = "tool_result"
    TOOL_PROGRESS = "tool_progress"
    TOOL_CANCEL = "tool_cancel"
    TOOL_CANCELLED = "tool_cancelled"

    # Heartbeat / keep-alive
    HEARTBEAT = "heartbeat"
    HEARTBEAT_ACK = "heartbeat_ack"

    # Connection lifecycle
    DISCONNECT = "disconnect"
    ERROR = "error"

    # Status (device-side extras)
    STATUS_REQUEST = "status_request"
    STATUS_RESPONSE = "status_response"
    SHUTDOWN = "shutdown"


@dataclass
class DeviceMessage:
    """A message exchanged between device agent and daemon.

    Matches the daemon's DeviceMessage envelope format:
    ``{type, id, device_id, payload, timestamp}``
    """

    type: MessageType
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    device_id: str | None = None
    payload: dict[str, Any] = field(default_factory=dict)
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )

    def to_json(self) -> str:
        """Serialize the message to a JSON string."""
        return json.dumps({
            "type": self.type.value if isinstance(self.type, MessageType) else self.type,
            "id": self.id,
            "device_id": self.device_id,
            "payload": self.payload,
            "timestamp": self.timestamp,
        }, default=str)

    @classmethod
    def from_json(cls, raw: str) -> DeviceMessage:
        """Deserialize a JSON string into a DeviceMessage."""
        data = json.loads(raw)
        msg_type = data.get("type", "error")
        try:
            msg_type = MessageType(msg_type)
        except ValueError:
            logger.warning("Unknown message type: %s", msg_type)
            msg_type = MessageType.ERROR
        return cls(
            type=msg_type,
            id=data.get("id", str(uuid.uuid4())),
            device_id=data.get("device_id"),
            payload=data.get("payload", {}),
            timestamp=data.get("timestamp", datetime.now(timezone.utc).isoformat()),
        )


class DeviceConnection:
    """WebSocket client that connects to the Snippbot daemon.

    Handles automatic reconnection with exponential backoff using
    the delay sequence: 1, 2, 5, 10, 30, 60 seconds.
    """

    def __init__(
        self,
        ws_url: str,
        device_id: str,
        device_token: str,
        on_message: Callable[[DeviceMessage], Awaitable[None]] | None = None,
        on_reconnect: Callable[[], Awaitable[bool]] | None = None,
    ) -> None:
        self._ws_url = ws_url
        self._device_id = device_id
        self._device_token = device_token
        self._on_message = on_message
        self._on_reconnect = on_reconnect

        self._ws: websockets.client.WebSocketClientProtocol | None = None
        self._connected = False
        self._authenticated = False
        self._should_run = False
        self._reconnect_attempt = 0
        self._receive_task: asyncio.Task[None] | None = None
        self._lock = asyncio.Lock()

    @property
    def connected(self) -> bool:
        return self._connected

    @property
    def authenticated(self) -> bool:
        return self._authenticated

    async def connect(self) -> bool:
        """Establish a WebSocket connection to the daemon.

        Returns True if the connection succeeded, False otherwise.
        Note: reconnect_attempt counter is NOT reset here — it is only
        reset after a fully successful session (auth + capabilities).
        Call reset_backoff() explicitly when the session is healthy.
        """
        try:
            logger.info("Connecting to %s ...", self._ws_url)
            self._ws = await websockets.client.connect(
                self._ws_url,
                ping_interval=20,
                ping_timeout=10,
                close_timeout=5,
                max_size=10 * 1024 * 1024,  # 10 MB max message
            )
            self._connected = True
            logger.info("WebSocket connection established")
            return True
        except (OSError, InvalidStatusCode, ConnectionRefusedError) as exc:
            logger.error("Connection failed: %s", exc)
            self._connected = False
            return False

    def reset_backoff(self) -> None:
        """Reset the reconnection backoff counter.

        Call this after a fully successful session (auth + capabilities)
        so that future disconnects start with the shortest delay.
        """
        self._reconnect_attempt = 0

    async def authenticate(self) -> bool:
        """Perform the challenge-response authentication handshake.

        Flow:
        1. Receive AUTH_CHALLENGE with nonce from daemon
        2. Compute HMAC-SHA256(nonce, token) and send AUTH_RESPONSE
        3. Receive AUTH_OK or AUTH_FAILED
        """
        if not self._ws or not self._connected:
            logger.error("Cannot authenticate: not connected")
            return False

        try:
            # Step 1: Receive auth challenge
            raw = await asyncio.wait_for(self._ws.recv(), timeout=10.0)
            challenge = DeviceMessage.from_json(raw)

            if challenge.type != MessageType.AUTH_CHALLENGE:
                logger.error(
                    "Expected auth_challenge, got %s", challenge.type.value
                )
                return False

            nonce = challenge.payload.get("nonce", "")
            if not nonce:
                logger.error("Auth challenge missing nonce")
                return False

            # Step 2: Compute HMAC and send auth response
            signature = hmac.new(
                self._device_token.encode("utf-8"),
                nonce.encode("utf-8"),
                hashlib.sha256,
            ).hexdigest()

            auth_response = DeviceMessage(
                type=MessageType.AUTH_RESPONSE,
                device_id=self._device_id,
                payload={
                    "token": self._device_token,
                    "hmac": signature,
                },
            )
            await self.send(auth_response)

            # Step 3: Receive auth result
            raw = await asyncio.wait_for(self._ws.recv(), timeout=10.0)
            result = DeviceMessage.from_json(raw)

            if result.type == MessageType.AUTH_OK:
                self._authenticated = True
                logger.info("Authentication successful")
                return True
            elif result.type == MessageType.AUTH_FAILED:
                reason = result.payload.get("reason", "unknown")
                logger.error("Authentication failed: %s", reason)
                self._authenticated = False
                return False
            else:
                logger.error(
                    "Unexpected response during auth: %s", result.type.value
                )
                return False

        except asyncio.TimeoutError:
            logger.error("Authentication timed out")
            return False

    async def send(self, message: DeviceMessage) -> bool:
        """Send a message over the WebSocket connection.

        Returns True if the message was sent, False otherwise.
        """
        if not self._ws or not self._connected:
            logger.warning("Cannot send message: not connected")
            return False

        try:
            await self._ws.send(message.to_json())
            logger.debug("Sent message: type=%s id=%s", message.type, message.id)
            return True
        except ConnectionClosed as exc:
            logger.warning("Connection closed while sending: %s", exc)
            self._connected = False
            self._authenticated = False
            return False

    async def receive(self) -> DeviceMessage | None:
        """Receive a single message from the WebSocket.

        Returns None if the connection is closed or an error occurs.
        """
        if not self._ws or not self._connected:
            return None

        try:
            raw = await self._ws.recv()
            message = DeviceMessage.from_json(raw)
            logger.debug("Received message: type=%s id=%s", message.type, message.id)
            return message
        except ConnectionClosedOK:
            logger.info("Connection closed normally")
            self._connected = False
            self._authenticated = False
            return None
        except ConnectionClosedError as exc:
            logger.warning("Connection closed with error: %s", exc)
            self._connected = False
            self._authenticated = False
            return None
        except Exception as exc:
            logger.error("Error receiving message: %s", exc)
            return None

    async def start_receive_loop(self) -> None:
        """Start the background receive loop that dispatches messages."""
        self._should_run = True

        while self._should_run:
            if not self._connected:
                reconnected = await self._reconnect()
                if not reconnected:
                    continue

            message = await self.receive()
            if message is None:
                if self._should_run:
                    await self._reconnect()
                continue

            if self._on_message:
                try:
                    await self._on_message(message)
                except Exception as exc:
                    logger.error("Error in message handler: %s", exc, exc_info=True)

    async def _reconnect(self) -> bool:
        """Attempt to reconnect with exponential backoff.

        Uses the delay sequence: 1, 2, 5, 10, 30, 60 (stays at 60 thereafter).
        Gives up after MAX_RECONNECT_ATTEMPTS consecutive failures.
        Returns True if reconnection and re-authentication succeeded.
        """
        if not self._should_run:
            return False

        if self._reconnect_attempt >= MAX_RECONNECT_ATTEMPTS:
            logger.error(
                "Giving up after %d reconnect attempts. "
                "Restart the agent to try again.",
                MAX_RECONNECT_ATTEMPTS,
            )
            self._should_run = False
            return False

        delay_index = min(self._reconnect_attempt, len(RECONNECT_DELAYS) - 1)
        delay = RECONNECT_DELAYS[delay_index]

        logger.info(
            "Reconnecting in %d seconds (attempt %d/%d)...",
            delay,
            self._reconnect_attempt + 1,
            MAX_RECONNECT_ATTEMPTS,
        )
        await asyncio.sleep(delay)
        self._reconnect_attempt += 1

        if not self._should_run:
            return False

        connected = await self.connect()
        if not connected:
            return False

        if self._device_token:
            authenticated = await self.authenticate()
            if not authenticated:
                await self.disconnect()
                return False

        # Re-advertise capabilities after reconnect
        if self._on_reconnect:
            if not await self._on_reconnect():
                await self.disconnect()
                return False

        return True

    async def disconnect(self) -> None:
        """Close the WebSocket connection gracefully."""
        self._should_run = False
        self._connected = False
        self._authenticated = False

        if self._ws:
            try:
                await self._ws.close()
                logger.info("WebSocket disconnected")
            except Exception as exc:
                logger.debug("Error during disconnect: %s", exc)
            finally:
                self._ws = None

    async def send_pair_request(
        self, pairing_code: str
    ) -> DeviceMessage | None:
        """Handle the pairing flow with challenge-response.

        Flow:
        1. Receive AUTH_CHALLENGE with nonce from daemon
        2. Send AUTH_RESPONSE with pairing_code and device_id
        3. Receive AUTH_OK or AUTH_FAILED
        """
        if not self._ws or not self._connected:
            logger.error("Cannot pair: not connected")
            return None

        try:
            # Step 1: Receive auth challenge
            raw = await asyncio.wait_for(self._ws.recv(), timeout=10.0)
            challenge = DeviceMessage.from_json(raw)

            if challenge.type != MessageType.AUTH_CHALLENGE:
                logger.error(
                    "Expected auth_challenge, got %s", challenge.type.value
                )
                return DeviceMessage(
                    type=MessageType.ERROR,
                    payload={"error": f"Expected auth_challenge, got {challenge.type.value}"},
                )

            # Step 2: Send auth response with pairing code
            auth_response = DeviceMessage(
                type=MessageType.AUTH_RESPONSE,
                device_id=self._device_id,
                payload={
                    "pairing_code": pairing_code,
                    "device_id": self._device_id,
                },
            )
            await self.send(auth_response)

            # Step 3: Receive auth result
            raw = await asyncio.wait_for(self._ws.recv(), timeout=30.0)
            return DeviceMessage.from_json(raw)

        except asyncio.TimeoutError:
            logger.error("Pairing request timed out")
            return None
