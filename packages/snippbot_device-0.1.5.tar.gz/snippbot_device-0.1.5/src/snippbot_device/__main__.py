"""Entry point for python -m snippbot_device."""

from snippbot_device.cli import main

if __name__ == "__main__":
    main()
