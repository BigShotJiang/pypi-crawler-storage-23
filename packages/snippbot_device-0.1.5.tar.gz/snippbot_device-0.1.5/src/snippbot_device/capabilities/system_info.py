"""System info capability - report OS, CPU, memory, and disk metrics via psutil."""

from __future__ import annotations

import logging
import os
import platform
import time
from typing import Any, ClassVar

import psutil

from snippbot_device.capabilities import BaseCapability, CapabilityResult

logger = logging.getLogger(__name__)


class SystemInfoCapability(BaseCapability):
    """Report operating system, CPU, memory, and disk information."""

    name: ClassVar[str] = "system_info"
    description: ClassVar[str] = "Report system metrics and hardware information"

    def is_available(self) -> bool:
        """psutil is a hard dependency so this is always available."""
        return True

    def get_metadata(self) -> dict[str, Any]:
        base = super().get_metadata()
        base["platform"] = platform.system()
        base["architecture"] = platform.machine()
        return base

    async def execute(self, action: str, params: dict[str, Any]) -> CapabilityResult:
        """Execute a system_info action.

        Supported actions:
          - "overview": full system overview
          - "cpu": CPU details
          - "memory": memory details
          - "disk": disk details
          - "network": network interface info
          - "processes": top processes by CPU/memory
        """
        handlers = {
            "overview": self._overview,
            "cpu": self._cpu,
            "memory": self._memory,
            "disk": self._disk,
            "network": self._network,
            "processes": self._processes,
        }
        handler = handlers.get(action)
        if handler is None:
            return CapabilityResult(
                success=False,
                error=f"Unknown system_info action: {action}. Available: {', '.join(handlers)}",
                exit_code=1,
            )
        try:
            return handler(params)
        except Exception as exc:
            logger.error("system_info.%s failed: %s", action, exc, exc_info=True)
            return CapabilityResult(success=False, error=str(exc), exit_code=1)

    def _overview(self, params: dict[str, Any]) -> CapabilityResult:
        """Full system overview."""
        start = time.monotonic()

        cpu_percent = psutil.cpu_percent(interval=0.5)
        mem = psutil.virtual_memory()
        disk_path = os.environ.get("SystemDrive", "C:\\") + "\\" if platform.system() == "Windows" else "/"
        disk = psutil.disk_usage(disk_path)
        boot = psutil.boot_time()

        info: dict[str, Any] = {
            "platform": platform.system(),
            "platform_release": platform.release(),
            "platform_version": platform.version(),
            "architecture": platform.machine(),
            "hostname": platform.node(),
            "python_version": platform.python_version(),
            "cpu_count_physical": psutil.cpu_count(logical=False),
            "cpu_count_logical": psutil.cpu_count(logical=True),
            "cpu_percent": cpu_percent,
            "memory_total_gb": round(mem.total / (1024 ** 3), 2),
            "memory_available_gb": round(mem.available / (1024 ** 3), 2),
            "memory_used_gb": round(mem.used / (1024 ** 3), 2),
            "memory_percent": mem.percent,
            "disk_total_gb": round(disk.total / (1024 ** 3), 2),
            "disk_used_gb": round(disk.used / (1024 ** 3), 2),
            "disk_free_gb": round(disk.free / (1024 ** 3), 2),
            "disk_percent": disk.percent,
            "boot_time": boot,
            "pid": os.getpid(),
        }

        lines = [f"{k}: {v}" for k, v in info.items()]
        return CapabilityResult(
            success=True,
            output="\n".join(lines),
            metadata=info,
            duration=time.monotonic() - start,
        )

    def _cpu(self, params: dict[str, Any]) -> CapabilityResult:
        """Detailed CPU information."""
        start = time.monotonic()

        per_cpu = psutil.cpu_percent(interval=0.5, percpu=True)
        freq = psutil.cpu_freq()
        load_1, load_5, load_15 = (0.0, 0.0, 0.0)
        try:
            load_1, load_5, load_15 = os.getloadavg()
        except (AttributeError, OSError):
            pass

        info: dict[str, Any] = {
            "physical_cores": psutil.cpu_count(logical=False),
            "logical_cores": psutil.cpu_count(logical=True),
            "overall_percent": sum(per_cpu) / len(per_cpu) if per_cpu else 0,
            "per_cpu_percent": per_cpu,
            "frequency_current_mhz": round(freq.current, 1) if freq else None,
            "frequency_max_mhz": round(freq.max, 1) if freq and freq.max else None,
            "load_1min": round(load_1, 2),
            "load_5min": round(load_5, 2),
            "load_15min": round(load_15, 2),
        }

        lines = [f"{k}: {v}" for k, v in info.items()]
        return CapabilityResult(
            success=True,
            output="\n".join(lines),
            metadata=info,
            duration=time.monotonic() - start,
        )

    def _memory(self, params: dict[str, Any]) -> CapabilityResult:
        """Detailed memory information."""
        start = time.monotonic()

        mem = psutil.virtual_memory()
        swap = psutil.swap_memory()

        info: dict[str, Any] = {
            "total_gb": round(mem.total / (1024 ** 3), 2),
            "available_gb": round(mem.available / (1024 ** 3), 2),
            "used_gb": round(mem.used / (1024 ** 3), 2),
            "percent": mem.percent,
            "swap_total_gb": round(swap.total / (1024 ** 3), 2),
            "swap_used_gb": round(swap.used / (1024 ** 3), 2),
            "swap_percent": swap.percent,
        }

        lines = [f"{k}: {v}" for k, v in info.items()]
        return CapabilityResult(
            success=True,
            output="\n".join(lines),
            metadata=info,
            duration=time.monotonic() - start,
        )

    def _disk(self, params: dict[str, Any]) -> CapabilityResult:
        """Disk usage for all mounted partitions."""
        start = time.monotonic()

        partitions_info: list[dict[str, Any]] = []
        for part in psutil.disk_partitions(all=False):
            try:
                usage = psutil.disk_usage(part.mountpoint)
                partitions_info.append({
                    "device": part.device,
                    "mountpoint": part.mountpoint,
                    "fstype": part.fstype,
                    "total_gb": round(usage.total / (1024 ** 3), 2),
                    "used_gb": round(usage.used / (1024 ** 3), 2),
                    "free_gb": round(usage.free / (1024 ** 3), 2),
                    "percent": usage.percent,
                })
            except (PermissionError, OSError):
                partitions_info.append({
                    "device": part.device,
                    "mountpoint": part.mountpoint,
                    "fstype": part.fstype,
                    "error": "permission denied",
                })

        lines: list[str] = []
        for p in partitions_info:
            if "error" in p:
                lines.append(f"{p['mountpoint']} ({p['device']}): {p['error']}")
            else:
                lines.append(
                    f"{p['mountpoint']} ({p['device']}): "
                    f"{p['used_gb']}/{p['total_gb']} GB ({p['percent']}%)"
                )

        return CapabilityResult(
            success=True,
            output="\n".join(lines),
            metadata={"partitions": partitions_info},
            duration=time.monotonic() - start,
        )

    def _network(self, params: dict[str, Any]) -> CapabilityResult:
        """Network interface information."""
        start = time.monotonic()

        addrs = psutil.net_if_addrs()
        stats = psutil.net_if_stats()
        io = psutil.net_io_counters(pernic=True)

        interfaces: list[dict[str, Any]] = []
        for name, addr_list in addrs.items():
            iface: dict[str, Any] = {"name": name, "addresses": []}
            for addr in addr_list:
                iface["addresses"].append({
                    "family": str(addr.family),
                    "address": addr.address,
                    "netmask": addr.netmask,
                })
            if name in stats:
                st = stats[name]
                iface["is_up"] = st.isup
                iface["speed_mbps"] = st.speed
                iface["mtu"] = st.mtu
            if name in io:
                io_c = io[name]
                iface["bytes_sent"] = io_c.bytes_sent
                iface["bytes_recv"] = io_c.bytes_recv
            interfaces.append(iface)

        lines: list[str] = []
        for iface in interfaces:
            status = "UP" if iface.get("is_up") else "DOWN"
            lines.append(f"{iface['name']}: {status}")
            for a in iface.get("addresses", []):
                lines.append(f"  {a['family']}: {a['address']}")

        return CapabilityResult(
            success=True,
            output="\n".join(lines),
            metadata={"interfaces": interfaces},
            duration=time.monotonic() - start,
        )

    def _processes(self, params: dict[str, Any]) -> CapabilityResult:
        """Top processes sorted by CPU or memory usage."""
        start = time.monotonic()
        sort_by = params.get("sort_by", "cpu")  # "cpu" or "memory"
        limit = min(int(params.get("limit", 10)), 50)

        procs: list[dict[str, Any]] = []
        for proc in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent", "status"]):
            try:
                info = proc.info
                procs.append({
                    "pid": info["pid"],
                    "name": info["name"],
                    "cpu_percent": info["cpu_percent"] or 0.0,
                    "memory_percent": round(info["memory_percent"] or 0.0, 2),
                    "status": info["status"],
                })
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        sort_key = "cpu_percent" if sort_by == "cpu" else "memory_percent"
        procs.sort(key=lambda p: p[sort_key], reverse=True)
        top = procs[:limit]

        lines = [f"{'PID':>7} {'CPU%':>6} {'MEM%':>6} {'STATUS':<12} NAME"]
        for p in top:
            lines.append(
                f"{p['pid']:>7} {p['cpu_percent']:>6.1f} {p['memory_percent']:>6.1f} "
                f"{p['status']:<12} {p['name']}"
            )

        return CapabilityResult(
            success=True,
            output="\n".join(lines),
            metadata={"processes": top, "sort_by": sort_by, "count": len(top)},
            duration=time.monotonic() - start,
        )
