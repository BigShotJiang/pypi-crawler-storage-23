"""Main device agent that ties together connection, executor, and config."""

from __future__ import annotations

import asyncio
import logging
import os
import platform
import shutil
import signal
import sys
import time
from pathlib import Path
from typing import Any

import psutil

from snippbot_device.config import DeviceConfig
from snippbot_device.connection import DeviceConnection, DeviceMessage, MessageType
from snippbot_device.executor import DeviceExecutor

logger = logging.getLogger(__name__)


class DeviceAgent:
    """The main Snippbot device agent.

    Connects to the Snippbot daemon over WebSocket, reports its capabilities,
    handles tool execution requests, and sends periodic heartbeats with system
    metrics.
    """

    def __init__(self, config: DeviceConfig) -> None:
        self._config = config
        self._executor = DeviceExecutor(config)
        self._connection = DeviceConnection(
            ws_url=config.ws_url,
            device_id=config.device_id,
            device_token=config.device_token,
            on_message=self._handle_message,
            on_reconnect=self._advertise_capabilities,
        )
        self._running = False
        self._heartbeat_task: asyncio.Task[None] | None = None
        self._receive_task: asyncio.Task[None] | None = None
        self._capabilities: dict[str, dict[str, Any]] = {}
        self._start_time: float = 0.0
        self._tasks_completed: int = 0
        self._tasks_failed: int = 0

    @property
    def running(self) -> bool:
        return self._running

    @property
    def capabilities(self) -> dict[str, dict[str, Any]]:
        return dict(self._capabilities)

    @property
    def uptime(self) -> float:
        if self._start_time == 0.0:
            return 0.0
        return time.time() - self._start_time

    async def start(self) -> None:
        """Start the device agent.

        1. Detect local capabilities
        2. Connect to the daemon
        3. Authenticate (challenge-response with HMAC)
        4. Advertise capabilities and wait for ACK
        5. Enter the message receive loop with heartbeats
        """
        logger.info("Starting Snippbot Device Agent: %s", self._config.device_name)
        self._running = True
        self._start_time = time.time()

        # Detect what this machine can do
        self._capabilities = self.detect_capabilities()
        logger.info("Detected capabilities: %s", list(self._capabilities.keys()))

        # Connect
        connected = await self._connection.connect()
        if not connected:
            logger.error("Failed to connect to daemon at %s", self._config.ws_url)
            self._running = False
            return

        # Authenticate (handles challenge-response automatically)
        if self._config.device_token:
            authenticated = await self._connection.authenticate()
            if not authenticated:
                logger.error("Authentication failed")
                await self._connection.disconnect()
                self._running = False
                return

        # Advertise capabilities and wait for ACK
        ack_received = await self._advertise_capabilities()
        if not ack_received:
            logger.error("Capability negotiation failed")
            await self._connection.disconnect()
            self._running = False
            return

        # Session fully established — reset reconnect backoff
        self._connection.reset_backoff()

        # Install signal handlers
        loop = asyncio.get_event_loop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                loop.add_signal_handler(sig, lambda: asyncio.ensure_future(self.stop()))
            except (NotImplementedError, RuntimeError):
                # Windows does not support add_signal_handler
                pass

        # Start heartbeat and receive loop
        self._heartbeat_task = asyncio.create_task(self._heartbeat_loop())
        self._receive_task = asyncio.create_task(self._connection.start_receive_loop())

        logger.info("Device agent is running")

        # Wait until stopped
        try:
            await asyncio.gather(self._heartbeat_task, self._receive_task)
        except asyncio.CancelledError:
            pass
        finally:
            self._running = False

    async def stop(self) -> None:
        """Gracefully shut down the device agent."""
        if not self._running:
            return

        logger.info("Stopping device agent...")
        self._running = False

        # Cancel active tool executions
        cancelled = await self._executor.cancel_all()
        if cancelled:
            logger.info("Cancelled %d active tasks", cancelled)

        # Cancel background tasks
        if self._heartbeat_task and not self._heartbeat_task.done():
            self._heartbeat_task.cancel()
        if self._receive_task and not self._receive_task.done():
            self._receive_task.cancel()

        # Disconnect
        await self._connection.disconnect()
        logger.info("Device agent stopped")

    def detect_capabilities(self) -> dict[str, dict[str, Any]]:
        """Detect what capabilities are available on this machine.

        Checks for installed tools, libraries, and hardware features.
        Returns a dict of capability_name -> metadata.
        """
        caps: dict[str, dict[str, Any]] = {}

        # bash is always available on Unix; cmd on Windows
        shell = "bash" if sys.platform != "win32" else "cmd"
        shell_path = shutil.which(shell) or shutil.which("sh")
        if shell_path:
            caps["bash"] = {
                "shell": shell,
                "path": shell_path,
                "description": "Execute shell commands",
            }

        # Python is always available (we are running it)
        caps["python"] = {
            "version": platform.python_version(),
            "path": sys.executable,
            "description": "Execute Python code",
        }

        # Filesystem operations
        caps["filesystem"] = {
            "allowed_paths": self._config.allowed_paths,
            "max_file_size_mb": 50,
            "description": "Read, write, and list filesystem entries",
        }

        # System info via psutil
        caps["system_info"] = {
            "platform": platform.system(),
            "architecture": platform.machine(),
            "description": "Report system metrics and information",
        }

        # Check for git
        git_path = shutil.which("git")
        if git_path:
            caps["git"] = {
                "path": git_path,
                "description": "Git version control operations",
            }

        # Check for docker
        docker_path = shutil.which("docker")
        if docker_path:
            caps["docker"] = {
                "path": docker_path,
                "description": "Docker container operations",
            }

        # Check for screen capture (mss + pillow)
        try:
            import mss
            import PIL
            caps["screen_capture"] = {
                "description": "Capture screenshots",
            }
        except ImportError:
            pass

        # Check for camera (opencv)
        try:
            import cv2
            caps["camera"] = {
                "description": "Camera capture",
            }
        except ImportError:
            pass

        # Check for browser automation (playwright)
        try:
            import playwright
            caps["browser"] = {
                "description": "Browser automation via Playwright",
            }
        except ImportError:
            pass

        # Check for Node.js
        node_path = shutil.which("node")
        if node_path:
            caps["node"] = {
                "path": node_path,
                "description": "Execute Node.js/JavaScript",
            }

        # Filter to only configured capabilities if explicitly set
        if self._config.capabilities:
            # Always keep system_info and filesystem as baseline
            baseline = {"system_info", "filesystem"}
            allowed = set(self._config.capabilities) | baseline
            caps = {k: v for k, v in caps.items() if k in allowed}

        return caps

    async def _advertise_capabilities(self) -> bool:
        """Send capabilities_advertise and wait for ACK from the daemon.

        Returns True if capabilities were accepted.
        """
        # Build the capabilities payload in the legacy dict format
        # that the server accepts: {tools: [...], platform, version}
        tool_names = list(self._capabilities.keys())

        message = DeviceMessage(
            type=MessageType.CAPABILITIES_ADVERTISE,
            device_id=self._config.device_id,
            payload={
                "capabilities": {
                    "tools": tool_names,
                    "platform": platform.system().lower(),
                    "version": self._get_version(),
                },
                "device_name": self._config.device_name,
                "platform": platform.system(),
                "architecture": platform.machine(),
                "python_version": platform.python_version(),
            },
        )
        sent = await self._connection.send(message)
        if not sent:
            logger.error("Failed to send capability advertisement")
            return False
        logger.debug("Capabilities advertised: %s", tool_names)

        # Wait for ACK or REJECT with a timeout matching the server's
        # CAPABILITY_TIMEOUT_S (15s) plus a small buffer.
        try:
            response = await asyncio.wait_for(
                self._connection.receive(), timeout=20.0
            )
        except asyncio.TimeoutError:
            logger.error("Timed out waiting for capability ACK from daemon")
            return False

        if response is None:
            logger.error("No response to capability advertisement")
            return False

        if response.type == MessageType.CAPABILITIES_ACK:
            accepted = response.payload.get("accepted", [])
            logger.info("Capabilities accepted: %s", accepted)
            return True
        elif response.type == MessageType.CAPABILITIES_REJECT:
            reason = response.payload.get("reason", "unknown")
            logger.error("Capabilities rejected: %s", reason)
            return False
        else:
            logger.error(
                "Unexpected response to capabilities: %s", response.type.value
            )
            return False

    def _get_version(self) -> str:
        """Get the snippbot-device package version."""
        try:
            from snippbot_device import __version__
            return __version__
        except ImportError:
            return "0.0.0"

    async def _handle_message(self, message: DeviceMessage) -> None:
        """Dispatch an incoming message from the daemon."""
        handlers = {
            MessageType.TOOL_REQUEST: self._handle_tool_request,
            MessageType.TOOL_CANCEL: self._handle_tool_cancel,
            MessageType.HEARTBEAT: self._handle_heartbeat_ping,
            MessageType.HEARTBEAT_ACK: self._handle_heartbeat_ack,
            MessageType.SHUTDOWN: self._handle_shutdown,
            MessageType.STATUS_REQUEST: self._handle_status_request,
            MessageType.DISCONNECT: self._handle_disconnect,
        }

        handler = handlers.get(message.type)
        if handler:
            await handler(message)
        else:
            logger.warning("Unhandled message type: %s", message.type)

    async def _handle_tool_request(self, message: DeviceMessage) -> None:
        """Receive and execute a tool call from the daemon, returning the result."""
        payload = message.payload
        tool_name = payload.get("tool_name", payload.get("tool", ""))
        tool_params = payload.get("tool_input", payload.get("params", {}))
        request_id = message.id

        logger.info("Executing tool request: %s (id=%s)", tool_name, request_id)

        # Check if the tool corresponds to a known capability
        capability_map = {
            "bash": "bash",
            "python": "python",
            "read_file": "filesystem",
            "write_file": "filesystem",
            "list_directory": "filesystem",
            "system_info": "system_info",
        }
        required_cap = capability_map.get(tool_name)
        if required_cap and required_cap not in self._capabilities:
            result_msg = DeviceMessage(
                type=MessageType.TOOL_RESULT,
                device_id=self._config.device_id,
                payload={
                    "request_id": request_id,
                    "success": False,
                    "error": f"Capability not available on this device: {required_cap}",
                },
            )
            await self._connection.send(result_msg)
            return

        # Execute
        result = await self._executor.execute(tool_name, tool_params)

        if result.success:
            self._tasks_completed += 1
        else:
            self._tasks_failed += 1

        # Send result back
        result_msg = DeviceMessage(
            type=MessageType.TOOL_RESULT,
            device_id=self._config.device_id,
            payload={
                "request_id": request_id,
                **result.to_dict(),
            },
        )
        await self._connection.send(result_msg)
        logger.info(
            "Tool result sent: %s success=%s duration=%.2fs",
            tool_name, result.success, result.duration,
        )

    async def _handle_tool_cancel(self, message: DeviceMessage) -> None:
        """Handle a tool cancellation request from the daemon."""
        request_id = message.payload.get("request_id", message.id)
        logger.info("Tool cancel requested: %s", request_id)
        # Send acknowledgement
        cancel_ack = DeviceMessage(
            type=MessageType.TOOL_CANCELLED,
            device_id=self._config.device_id,
            payload={"request_id": request_id},
        )
        await self._connection.send(cancel_ack)

    async def _handle_heartbeat_ping(self, message: DeviceMessage) -> None:
        """Respond to a HEARTBEAT from the daemon with a HEARTBEAT_ACK."""
        ack = DeviceMessage(
            type=MessageType.HEARTBEAT_ACK,
            device_id=self._config.device_id,
        )
        await self._connection.send(ack)

    async def _handle_heartbeat_ack(self, message: DeviceMessage) -> None:
        """Process a heartbeat acknowledgement from the daemon."""
        logger.debug("Heartbeat acknowledged by daemon")

    async def _handle_shutdown(self, message: DeviceMessage) -> None:
        """Handle a shutdown request from the daemon."""
        reason = message.payload.get("reason", "requested by daemon")
        logger.info("Shutdown requested: %s", reason)
        await self.stop()

    async def _handle_disconnect(self, message: DeviceMessage) -> None:
        """Handle a disconnect notification from the daemon."""
        reason = message.payload.get("reason", "")
        logger.info("Disconnect from daemon: %s", reason or "(no reason)")
        await self.stop()

    async def _handle_status_request(self, message: DeviceMessage) -> None:
        """Respond to a status inquiry from the daemon."""
        mem = psutil.virtual_memory()
        cpu = psutil.cpu_percent(interval=0.1)

        status_msg = DeviceMessage(
            type=MessageType.STATUS_RESPONSE,
            device_id=self._config.device_id,
            payload={
                "device_id": self._config.device_id,
                "device_name": self._config.device_name,
                "running": self._running,
                "uptime": self.uptime,
                "tasks_completed": self._tasks_completed,
                "tasks_failed": self._tasks_failed,
                "cpu_percent": cpu,
                "memory_percent": mem.percent,
                "capabilities": list(self._capabilities.keys()),
            },
        )
        await self._connection.send(status_msg)

    async def _heartbeat_loop(self) -> None:
        """Send periodic heartbeats with system metrics."""
        while self._running:
            try:
                await asyncio.sleep(self._config.heartbeat_interval)
            except asyncio.CancelledError:
                break

            if not self._running:
                break

            await self._send_heartbeat()

    async def _send_heartbeat(self) -> None:
        """Send a single heartbeat message with current system metrics."""
        try:
            mem = psutil.virtual_memory()
            cpu = psutil.cpu_percent(interval=0)

            heartbeat = DeviceMessage(
                type=MessageType.HEARTBEAT,
                device_id=self._config.device_id,
                payload={
                    "device_id": self._config.device_id,
                    "uptime": self.uptime,
                    "cpu_percent": cpu,
                    "memory_percent": mem.percent,
                    "memory_available_gb": round(mem.available / (1024 ** 3), 2),
                    "tasks_completed": self._tasks_completed,
                    "tasks_failed": self._tasks_failed,
                    "active_tasks": len(self._executor._active_processes),
                },
            )
            sent = await self._connection.send(heartbeat)
            if sent:
                logger.debug("Heartbeat sent: cpu=%.1f%% mem=%.1f%%", cpu, mem.percent)
        except Exception as exc:
            logger.warning("Failed to send heartbeat: %s", exc)
