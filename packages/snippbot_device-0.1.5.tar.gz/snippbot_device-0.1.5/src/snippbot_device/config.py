"""Device agent configuration with TOML persistence."""

from __future__ import annotations

import logging
import os
import platform
import uuid
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

DEFAULT_CONFIG_DIR = Path.home() / ".snippbot-device"
DEFAULT_CONFIG_FILE = DEFAULT_CONFIG_DIR / "config.toml"

SENSITIVE_ENV_VARS_DEFAULT = [
    "ANTHROPIC_API_KEY",
    "OPENAI_API_KEY",
    "AWS_SECRET_ACCESS_KEY",
    "AWS_SESSION_TOKEN",
    "GITHUB_TOKEN",
    "GH_TOKEN",
    "GITLAB_TOKEN",
    "DATABASE_URL",
    "DB_PASSWORD",
    "SECRET_KEY",
    "PRIVATE_KEY",
    "API_KEY",
    "API_SECRET",
    "PASSWORD",
    "CREDENTIALS",
    "SSH_PRIVATE_KEY",
    "NPM_TOKEN",
    "PYPI_TOKEN",
    "DOCKER_PASSWORD",
    "SLACK_TOKEN",
    "DISCORD_TOKEN",
]


@dataclass
class DeviceConfig:
    """Configuration for the Snippbot device agent."""

    # Connection settings
    daemon_host: str = "localhost"
    daemon_ws_port: int = 18781
    device_name: str = ""
    device_token: str = ""
    device_id: str = ""

    # Capabilities
    capabilities: list[str] = field(default_factory=lambda: [
        "bash", "filesystem", "system_info",
    ])

    # Security
    allowed_paths: list[str] = field(default_factory=lambda: [
        str(Path.home()),
    ])
    blocked_env_vars: list[str] = field(default_factory=lambda: list(SENSITIVE_ENV_VARS_DEFAULT))

    # Performance
    max_concurrent_tasks: int = 4
    heartbeat_interval: int = 30

    # Updates
    auto_update: bool = True

    def __post_init__(self) -> None:
        if not self.device_name:
            self.device_name = platform.node() or "unknown-device"
        if not self.device_id:
            self.device_id = str(uuid.uuid4())

    @classmethod
    def load(cls, path: Path | None = None) -> DeviceConfig:
        """Load configuration from a TOML file.

        If the file does not exist, returns a default configuration and
        persists it to disk so future runs use the same device_id.
        """
        config_path = path or DEFAULT_CONFIG_FILE

        if not config_path.exists():
            logger.info("No config file found at %s, using defaults", config_path)
            config = cls()
            config.save(config_path)
            return config

        logger.info("Loading config from %s", config_path)

        try:
            import tomllib
        except ImportError:
            import tomli as tomllib  # type: ignore[no-redef]

        with open(config_path, "rb") as f:
            data = tomllib.load(f)

        return cls._from_dict(data)

    @classmethod
    def _from_dict(cls, data: dict[str, Any]) -> DeviceConfig:
        """Create a DeviceConfig from a flat or sectioned dictionary."""
        flat: dict[str, Any] = {}

        # Support both flat keys and [connection] / [security] / etc. sections
        section_mappings = {
            "connection": ["daemon_host", "daemon_ws_port", "device_name", "device_token", "device_id"],
            "capabilities": ["capabilities"],
            "security": ["allowed_paths", "blocked_env_vars"],
            "performance": ["max_concurrent_tasks", "heartbeat_interval"],
            "updates": ["auto_update"],
        }

        for section, keys in section_mappings.items():
            if section in data and isinstance(data[section], dict):
                for key in keys:
                    if key in data[section]:
                        flat[key] = data[section][key]

        # Also accept flat top-level keys
        for key in (
            "daemon_host", "daemon_ws_port", "device_name", "device_token",
            "device_id", "capabilities", "allowed_paths", "blocked_env_vars",
            "max_concurrent_tasks", "heartbeat_interval", "auto_update",
        ):
            if key in data and key not in flat:
                flat[key] = data[key]

        return cls(**flat)

    def save(self, path: Path | None = None) -> None:
        """Persist configuration to a TOML file."""
        config_path = path or DEFAULT_CONFIG_FILE
        config_path.parent.mkdir(parents=True, exist_ok=True)

        lines: list[str] = []

        lines.append("[connection]")
        lines.append(f'daemon_host = "{self.daemon_host}"')
        lines.append(f"daemon_ws_port = {self.daemon_ws_port}")
        lines.append(f'device_name = "{self.device_name}"')
        lines.append(f'device_token = "{self.device_token}"')
        lines.append(f'device_id = "{self.device_id}"')
        lines.append("")

        lines.append("[capabilities]")
        cap_items = ", ".join(f'"{c}"' for c in self.capabilities)
        lines.append(f"capabilities = [{cap_items}]")
        lines.append("")

        lines.append("[security]")
        # Use single-quoted TOML literal strings for paths to avoid backslash escaping issues on Windows
        path_items = ", ".join(f"'{p}'" for p in self.allowed_paths)
        lines.append(f"allowed_paths = [{path_items}]")
        env_items = ", ".join(f'"{v}"' for v in self.blocked_env_vars)
        lines.append(f"blocked_env_vars = [{env_items}]")
        lines.append("")

        lines.append("[performance]")
        lines.append(f"max_concurrent_tasks = {self.max_concurrent_tasks}")
        lines.append(f"heartbeat_interval = {self.heartbeat_interval}")
        lines.append("")

        lines.append("[updates]")
        lines.append(f"auto_update = {'true' if self.auto_update else 'false'}")
        lines.append("")

        config_path.write_text("\n".join(lines), encoding="utf-8")
        logger.info("Config saved to %s", config_path)

        # Restrict permissions on config file (contains token)
        try:
            os.chmod(config_path, 0o600)
        except OSError:
            logger.warning("Could not set restrictive permissions on %s", config_path)

    def to_dict(self) -> dict[str, Any]:
        """Return a dictionary representation of the config."""
        return asdict(self)

    @property
    def ws_url(self) -> str:
        """Build the WebSocket URL for connecting to the daemon."""
        return f"ws://{self.daemon_host}:{self.daemon_ws_port}/device/ws"

    def is_path_allowed(self, check_path: str) -> bool:
        """Check whether a given path falls under an allowed path prefix."""
        resolved = str(Path(check_path).resolve())
        for allowed in self.allowed_paths:
            allowed_resolved = str(Path(allowed).resolve())
            if resolved == allowed_resolved or resolved.startswith(allowed_resolved + os.sep):
                return True
        return False

    def is_env_var_blocked(self, var_name: str) -> bool:
        """Return True if the environment variable should be stripped."""
        upper = var_name.upper()
        for blocked in self.blocked_env_vars:
            if blocked.upper() in upper or upper in blocked.upper():
                return True
        return False
