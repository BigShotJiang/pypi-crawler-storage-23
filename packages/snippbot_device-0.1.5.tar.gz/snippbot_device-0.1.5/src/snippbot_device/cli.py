"""Click CLI for the Snippbot device agent."""

from __future__ import annotations

import asyncio
import logging
import os
import signal
import sys
from pathlib import Path

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from snippbot_device import __version__
from snippbot_device.config import DEFAULT_CONFIG_FILE, DeviceConfig

logger = logging.getLogger(__name__)
console = Console()

PID_FILE = Path.home() / ".snippbot-device" / "agent.pid"


def setup_logging(verbose: bool) -> None:
    """Configure logging for the CLI."""
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    # Suppress noisy libraries unless verbose
    if not verbose:
        logging.getLogger("websockets").setLevel(logging.WARNING)
        logging.getLogger("asyncio").setLevel(logging.WARNING)


@click.group()
@click.version_option(version=__version__, prog_name="snippbot-device")
@click.option("--verbose", "-v", is_flag=True, help="Enable debug logging.")
@click.option(
    "--config",
    "-c",
    "config_path",
    type=click.Path(exists=False),
    default=None,
    help="Path to config file (default: ~/.snippbot-device/config.toml).",
)
@click.pass_context
def main(ctx: click.Context, verbose: bool, config_path: str | None) -> None:
    """Snippbot Device Agent - connect any machine to Snippbot."""
    setup_logging(verbose)
    ctx.ensure_object(dict)
    ctx.obj["verbose"] = verbose
    ctx.obj["config_path"] = Path(config_path) if config_path else None


@main.command()
@click.option("--host", prompt="Daemon host", default="localhost", help="Snippbot daemon hostname or IP.")
@click.option("--port", prompt="Daemon WS port", default=18781, type=int, help="Daemon WebSocket port.")
@click.option("--code", prompt="Pairing code", help="6-digit pairing code from the Snippbot UI.")
@click.option("--name", default="", help="Custom name for this device (defaults to hostname).")
@click.pass_context
def pair(ctx: click.Context, host: str, port: int, code: str, name: str) -> None:
    """Pair this device with a Snippbot daemon."""
    config_path = ctx.obj.get("config_path")
    config = DeviceConfig.load(config_path)
    config.daemon_host = host
    config.daemon_ws_port = port
    if name:
        config.device_name = name

    console.print(f"\n[bold]Pairing with daemon at {host}:{port}...[/bold]")

    async def _pair() -> bool:
        from snippbot_device.connection import DeviceConnection, MessageType

        conn = DeviceConnection(
            ws_url=config.ws_url,
            device_id=config.device_id,
            device_token="",
        )
        connected = await conn.connect()
        if not connected:
            console.print("[red]Failed to connect to daemon.[/red]")
            return False

        result = await conn.send_pair_request(code)
        await conn.disconnect()

        if result is None:
            console.print("[red]No response from daemon (timed out).[/red]")
            return False

        if result.type == MessageType.AUTH_OK:
            device_id = result.payload.get("device_id", config.device_id)
            config.device_id = device_id
            token = result.payload.get("device_token", "")
            if token:
                config.device_token = token
            config.save(config_path)
            console.print(Panel(
                f"[green]Pairing successful![/green]\n\n"
                f"Device ID: {config.device_id}\n"
                f"Device Name: {config.device_name}\n"
                f"Daemon: {host}:{port}\n\n"
                f"Config saved to: {config_path or DEFAULT_CONFIG_FILE}",
                title="Device Paired",
                border_style="green",
            ))
            return True
        elif result.type == MessageType.AUTH_FAILED:
            reason = result.payload.get("reason", "unknown")
            console.print(f"[red]Pairing failed: {reason}[/red]")
            return False
        else:
            console.print(f"[red]Unexpected response: {result.type}[/red]")
            return False

    success = asyncio.run(_pair())
    sys.exit(0 if success else 1)


@main.command()
@click.option("--foreground", "-f", is_flag=True, help="Run in the foreground (don't daemonize).")
@click.pass_context
def start(ctx: click.Context, foreground: bool) -> None:
    """Start the device agent."""
    config_path = ctx.obj.get("config_path")
    config = DeviceConfig.load(config_path)

    if not config.device_token:
        console.print("[red]Device not paired. Run 'snippbot-device pair' first.[/red]")
        sys.exit(1)

    # Check if already running
    if PID_FILE.exists():
        try:
            pid = int(PID_FILE.read_text().strip())
            import psutil
            if psutil.pid_exists(pid):
                console.print(f"[yellow]Agent already running (PID {pid}).[/yellow]")
                sys.exit(1)
            else:
                # Stale PID file
                PID_FILE.unlink(missing_ok=True)
        except (ValueError, OSError):
            PID_FILE.unlink(missing_ok=True)

    console.print(Panel(
        f"[bold]Starting Snippbot Device Agent[/bold]\n\n"
        f"Device: {config.device_name}\n"
        f"Daemon: {config.daemon_host}:{config.daemon_ws_port}\n"
        f"Mode: {'foreground' if foreground else 'background'}",
        title="Device Agent",
        border_style="blue",
    ))

    if foreground:
        _run_agent(config)
    else:
        _daemonize(config, config_path)


def _run_agent(config: DeviceConfig) -> None:
    """Run the agent in the current process."""
    # Write PID file
    PID_FILE.parent.mkdir(parents=True, exist_ok=True)
    PID_FILE.write_text(str(os.getpid()))

    try:
        from snippbot_device.agent import DeviceAgent

        agent = DeviceAgent(config)
        asyncio.run(agent.start())
    except KeyboardInterrupt:
        console.print("\n[yellow]Agent stopped by user.[/yellow]")
    finally:
        PID_FILE.unlink(missing_ok=True)


def _daemonize(config: DeviceConfig, config_path: Path | None) -> None:
    """Fork into a background process (Unix) or inform user (Windows)."""
    if sys.platform == "win32":
        console.print("[yellow]Background mode not supported on Windows. Running in foreground.[/yellow]")
        _run_agent(config)
        return

    pid = os.fork()
    if pid > 0:
        # Parent process
        console.print(f"[green]Agent started in background (PID {pid}).[/green]")
        sys.exit(0)

    # Child process: create new session
    os.setsid()
    os.umask(0o077)

    # Redirect stdio
    devnull_fd = os.open(os.devnull, os.O_RDWR)
    os.dup2(devnull_fd, 0)
    os.dup2(devnull_fd, 1)
    os.dup2(devnull_fd, 2)
    os.close(devnull_fd)

    # Set up log file instead of console
    log_file = Path.home() / ".snippbot-device" / "agent.log"
    log_file.parent.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        filename=str(log_file),
        filemode="a",
        force=True,
    )

    _run_agent(config)


@main.command()
@click.pass_context
def stop(ctx: click.Context) -> None:
    """Stop the running device agent."""
    if not PID_FILE.exists():
        console.print("[yellow]No running agent found.[/yellow]")
        sys.exit(1)

    try:
        pid = int(PID_FILE.read_text().strip())
    except (ValueError, OSError):
        console.print("[red]Invalid PID file. Removing it.[/red]")
        PID_FILE.unlink(missing_ok=True)
        sys.exit(1)

    import psutil

    if not psutil.pid_exists(pid):
        console.print(f"[yellow]Process {pid} not found. Cleaning up PID file.[/yellow]")
        PID_FILE.unlink(missing_ok=True)
        sys.exit(0)

    console.print(f"Stopping agent (PID {pid})...")
    try:
        os.kill(pid, signal.SIGTERM)
        # Wait for process to exit
        import time
        for _ in range(30):
            if not psutil.pid_exists(pid):
                break
            time.sleep(0.5)
        else:
            console.print("[yellow]Agent did not stop gracefully, sending SIGKILL...[/yellow]")
            try:
                os.kill(pid, signal.SIGKILL)
            except ProcessLookupError:
                pass

        PID_FILE.unlink(missing_ok=True)
        console.print("[green]Agent stopped.[/green]")
    except ProcessLookupError:
        console.print("[yellow]Process already exited.[/yellow]")
        PID_FILE.unlink(missing_ok=True)
    except PermissionError:
        console.print(f"[red]Permission denied. Cannot stop process {pid}.[/red]")
        sys.exit(1)


@main.command()
@click.pass_context
def status(ctx: click.Context) -> None:
    """Show the agent's current status."""
    config_path = ctx.obj.get("config_path")
    config = DeviceConfig.load(config_path)

    table = Table(title="Snippbot Device Agent Status")
    table.add_column("Property", style="bold")
    table.add_column("Value")

    table.add_row("Device Name", config.device_name)
    table.add_row("Device ID", config.device_id)
    table.add_row("Daemon", f"{config.daemon_host}:{config.daemon_ws_port}")
    table.add_row("Paired", "[green]Yes[/green]" if config.device_token else "[red]No[/red]")

    # Check running status
    running = False
    pid = None
    if PID_FILE.exists():
        try:
            pid = int(PID_FILE.read_text().strip())
            import psutil
            running = psutil.pid_exists(pid)
        except (ValueError, OSError):
            pass

    if running:
        table.add_row("Status", f"[green]Running[/green] (PID {pid})")
        try:
            import psutil
            proc = psutil.Process(pid)
            table.add_row("CPU %", f"{proc.cpu_percent(interval=0.5):.1f}%")
            mem_info = proc.memory_info()
            table.add_row("Memory", f"{mem_info.rss / 1024 / 1024:.1f} MB")
            import datetime
            create_time = datetime.datetime.fromtimestamp(proc.create_time())
            table.add_row("Started", create_time.strftime("%Y-%m-%d %H:%M:%S"))
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
    else:
        table.add_row("Status", "[red]Stopped[/red]")

    table.add_row("Config File", str(config_path or DEFAULT_CONFIG_FILE))
    table.add_row("Auto Update", "Yes" if config.auto_update else "No")

    console.print(table)

    # Show log tail if running
    if running:
        log_file = Path.home() / ".snippbot-device" / "agent.log"
        if log_file.exists():
            console.print(f"\n[dim]Log file: {log_file}[/dim]")


@main.command()
@click.pass_context
def capabilities(ctx: click.Context) -> None:
    """List detected capabilities on this machine."""
    config_path = ctx.obj.get("config_path")
    config = DeviceConfig.load(config_path)

    from snippbot_device.agent import DeviceAgent

    agent = DeviceAgent(config)
    caps = agent.detect_capabilities()

    table = Table(title="Detected Capabilities")
    table.add_column("Capability", style="bold cyan")
    table.add_column("Description")
    table.add_column("Details")

    for name, meta in sorted(caps.items()):
        description = meta.get("description", "")
        details_parts: list[str] = []
        for k, v in meta.items():
            if k != "description":
                details_parts.append(f"{k}={v}")
        details = ", ".join(details_parts) if details_parts else "-"
        table.add_row(name, description, details)

    console.print(table)

    configured = set(config.capabilities)
    detected = set(caps.keys())
    missing = configured - detected
    if missing:
        console.print(f"\n[yellow]Configured but not detected: {', '.join(sorted(missing))}[/yellow]")
