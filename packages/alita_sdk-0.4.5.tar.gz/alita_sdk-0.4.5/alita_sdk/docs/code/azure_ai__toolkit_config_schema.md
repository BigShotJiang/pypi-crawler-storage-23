# azure_ai - toolkit_config_schema

**Toolkit**: `azure_ai`
**Method**: `toolkit_config_schema`
**Source File**: `__init__.py`
**Class**: `AzureSearchToolkit`

---

## Method Implementation

```python
    def toolkit_config_schema() -> BaseModel:
        selected_tools = {x['name']: x['args_schema'].schema() for x in AzureSearchApiWrapper.model_construct().get_available_tools()}
        m = create_model(
            name,
            index_name=(str, Field(description="Azure Search index name")),
            azure_search_configuration=(
                AzureSearchConfiguration,
                Field(description="Azure Search Configuration", json_schema_extra={'configuration_types': ['azure_search']})
            ),
            api_version=(Optional[str], Field(description="API version", default=None)),
            openai_api_key=(Optional[str], Field(description="Azure OpenAI API Key", default=None, json_schema_extra={'secret': True})),
            model_name=(Optional[str], Field(description="Model name for Embeddings model", default=None)),
            selected_tools=(List[Literal[tuple(selected_tools)]], Field(default=[], json_schema_extra={'args_schemas': selected_tools})),
            __config__=ConfigDict(json_schema_extra={
                'metadata': {
                    "label": "Azure Search", "icon_url": None, "hidden": True,
                    "categories": ["other"],
                    "extra_categories": ["azure cognitive search", "vector database", "knowledge base"]
                }
            })
        )

        @check_connection_response
        def check_connection(self):
            response = requests.get(f"{self.api_base}/openai/deployments", headers={
                "api-key": self.api_key
            })
            return response

        m.check_connection = check_connection
        return m
```
