# ado_repos - update_file

**Toolkit**: `ado_repos`
**Method**: `update_file`
**Source File**: `repos_wrapper.py`
**Class**: `ReposApiWrapper`

---

## Method Implementation

```python
    def update_file(self, branch_name: str, file_path: str, update_query: str) -> str:
        """Updates a file with new content in Azure DevOps using OLD/NEW markers.

        Parameters:
            branch_name (str): The name of the branch where update the file.
            file_path (str): Path to the file for update.
            update_query(str): Contains the file contents required to be updated,
                wrapped in Git-style OLD/NEW blocks.

        Returns:
            A success or failure message
        """
        self.active_branch = branch_name if branch_name else self.base_branch

        if self.active_branch == self.base_branch:
            return (
                "You're attempting to commit directly to the "
                f"{self.base_branch} branch, which is protected. "
                "Please create a new branch and try again."
            )
        try:
            # Let edit_file handle parsing and content updates; this will call _read_file and _write_file.
            # For ADO, branch_name is used as branch; commit message is derived from file_path.
            return self.edit_file(
                file_path=file_path,
                file_query=update_query,
                branch=self.active_branch,
                commit_message=f"Update {file_path}",
            )
        except ToolException as e:
            return str(e)
        except Exception as e:
            msg = f"Unable to update file due to error:\n{str(e)}"
            logger.error(msg)
            return ToolException(msg)
```
