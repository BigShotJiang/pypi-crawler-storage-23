# aws - toolkit_config_schema

**Toolkit**: `aws`
**Method**: `toolkit_config_schema`
**Source File**: `__init__.py`
**Class**: `DeltaLakeToolkit`

---

## Method Implementation

```python
    def toolkit_config_schema() -> Type[BaseModel]:
        return DeltaLakeToolkitConfig
        return m
```
