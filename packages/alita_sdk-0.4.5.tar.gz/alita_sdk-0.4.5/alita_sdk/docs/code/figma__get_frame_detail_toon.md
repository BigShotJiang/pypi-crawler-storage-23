# figma - get_frame_detail_toon

**Toolkit**: `figma`
**Method**: `get_frame_detail_toon`
**Source File**: `api_wrapper.py`
**Class**: `FigmaApiWrapper`

---

## Method Implementation

```python
    def get_frame_detail_toon(
        self,
        file_key: str,
        frame_ids: str,
        **kwargs,
    ) -> str:
        """
        Get detailed information for specific frames in TOON format.

        Returns per-frame:
        - All text content (headings, labels, buttons, body, errors)
        - Component hierarchy
        - Inferred screen type and state
        - Position and size

        Use this to drill down into specific screens identified from file structure.
        """
        try:
            return self._get_frame_detail_toon_internal(file_key=file_key, frame_ids=frame_ids, **kwargs)
        except ToolException as e:
            raise ToolException(_handle_figma_error(e))
```
