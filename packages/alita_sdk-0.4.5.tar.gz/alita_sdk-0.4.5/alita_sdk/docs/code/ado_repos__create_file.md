# ado_repos - create_file

**Toolkit**: `ado_repos`
**Method**: `create_file`
**Source File**: `repos_wrapper.py`
**Class**: `ReposApiWrapper`

---

## Method Implementation

```python
    def create_file(self, file_path: str, file_contents: str, branch_name: str = None) -> str:
        """
        Creates a new file on the Azure DevOps repo
        Parameters:
            branch_name (str): The name of the branch where to create a file.
            file_path (str): The path of the file to be created
            file_contents (str): The content of the file to be created
        Returns:
            str: A success or failure message
        """
        self.active_branch = branch_name if branch_name else self.base_branch

        if self.active_branch == self.base_branch:
            return (
                "You're attempting to commit directly to the "
                f"{self.base_branch} branch, which is protected. "
                "Please create a new branch and try again."
            )
        try:
            # Check if file already exists
            try:
                self._client.get_item(
                    repository_id=self.repository_id,
                    project=self.project,
                    path=file_path,
                    version_descriptor=GitVersionDescriptor(
                        version=self.active_branch, version_type="branch"
                    ),
                )
                return (
                    f"File already exists at `{file_path}` "
                    f"on branch `{self.active_branch}`. You must use "
                    "`update_file` to modify it."
                )
            except Exception:
                # Expected behavior, file shouldn't exist yet
                pass

            # Get the latest commit ID of the active branch to use as oldObjectId
            branch = self._client.get_branch(
                repository_id=self.repository_id,
                project=self.project,
                name=self.active_branch,
            )
            if (
                    branch is None
                    or not hasattr(branch, "commit")
                    or not hasattr(branch.commit, "commit_id")
            ):
                return (
                    f"Branch `{self.active_branch}` does not exist or has no commits."
                )

            latest_commit_id = branch.commit.commit_id

            change = GitChange("add", file_path, file_contents).to_dict()

            ref_update = GitRefUpdate(
                name=f"refs/heads/{self.active_branch}", old_object_id=latest_commit_id
            )
            new_commit = GitCommit(comment=f"Create {file_path}", changes=[change])
            push = GitPush(commits=[new_commit], ref_updates=[ref_update])
            self._client.create_push(
                push=push, repository_id=self.repository_id, project=self.project
            )
            return f"Created file {file_path}"
        except Exception as e:
            msg = f"Unable to create file due to error:\n{str(e)}"
            logger.error(msg)
            return ToolException(msg)
```
