# aws - query_table

**Toolkit**: `aws`
**Method**: `query_table`
**Source File**: `api_wrapper.py`
**Class**: `DeltaLakeApiWrapper`

---

## Method Implementation

```python
    def query_table(self, query: Optional[str] = None, columns: Optional[List[str]] = None, filters: Optional[dict] = None) -> List[dict]:
        """
        Query Delta Lake table. Supports pandas-like filtering, column selection, and SQL-like queries (via pandas.DataFrame.query).
        Args:
            query: SQL-like query string (pandas.DataFrame.query syntax)
            columns: List of columns to select
            filters: Dict of column:value pairs for pandas-like filtering
        Returns:
            List of dicts representing rows
        """
        dt = self.delta_table
        df = dt.to_pandas()
        if filters:
            for col, val in filters.items():
                df = df[df[col] == val]
        if query:
            try:
                df = df.query(query)
            except Exception as e:
                raise ToolException(f"Error in query param: {e}")
        if columns:
            df = df[columns]
        return df.to_dict(orient="records")
```
