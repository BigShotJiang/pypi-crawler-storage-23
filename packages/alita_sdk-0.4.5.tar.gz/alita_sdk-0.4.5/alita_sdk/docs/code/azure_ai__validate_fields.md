# azure_ai - validate_fields

**Toolkit**: `azure_ai`
**Method**: `validate_fields`
**Source File**: `api_wrapper.py`
**Class**: `AzureSearchApiWrapper`

---

## Method Implementation

```python
    def validate_fields(cls, values):
        if not values.get('api_key'):
            raise ValueError("API key is required.")
        if not values.get('endpoint'):
            raise ValueError("Endpoint is required.")
        if not values.get('index_name'):
            raise ValueError("Index name is required.")
        
        cls._client = SearchClient(
            endpoint=values['endpoint'],
            index_name=values['index_name'],
            credential=AzureKeyCredential(values['api_key'])
        )
        if values.get('openai_api_key') and values.get('model_name'):
            cls._AzureOpenAIClient = AzureOpenAIEmbeddings(
                model=values['model_name'],
                api_version=values['api_version'],
                azure_endpoint=values['api_base'],
                api_key=values['openai_api_key'],
            )
        return values
```
