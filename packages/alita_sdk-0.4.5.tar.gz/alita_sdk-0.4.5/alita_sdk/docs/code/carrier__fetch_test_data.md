# carrier - fetch_test_data

**Toolkit**: `carrier`
**Method**: `fetch_test_data`
**Source File**: `api_wrapper.py`
**Class**: `CarrierAPIWrapper`

---

## Method Implementation

```python
    def fetch_test_data(self, start_time: str) -> List[Dict[str, Any]]:
        return self._client.fetch_test_data(start_time)
```
