# azure_ai - vector_search

**Toolkit**: `azure_ai`
**Method**: `vector_search`
**Source File**: `api_wrapper.py`
**Class**: `AzureSearchApiWrapper`

---

## Method Implementation

```python
    def vector_search(self, vectors: List[Dict[str, Any]], limit: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        Perform a vector search query on the Azure Search index.

        :param vectors: The vectors to search for in the Azure Search index.
        :param limit: The number of results to return.
        :return: A list of search results.
        """
        results = self._client.search(vector_queries=vectors)
        res = list(results)
        if limit is None or limit == -1:
            return res
        else:
            return res[:limit]
```
