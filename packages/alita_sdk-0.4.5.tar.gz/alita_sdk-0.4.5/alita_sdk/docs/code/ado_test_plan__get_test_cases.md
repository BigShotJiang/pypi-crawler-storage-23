# ado_test_plan - get_test_cases

**Toolkit**: `ado_test_plan`
**Method**: `get_test_cases`
**Source File**: `test_plan_wrapper.py`
**Class**: `TestPlanApiWrapper`

---

## Method Implementation

```python
    def get_test_cases(self, plan_id: int, suite_id: int, fields: Optional[List[str]] = None):
        """Get test cases from a suite in Azure DevOps with all custom fields."""
        try:
            # Get test case references from test plan client (basic info only)
            test_cases = self._client.get_test_case_list(self.project, plan_id, suite_id)
            result = []

            for test_case in test_cases:
                test_case_dict = test_case.as_dict()

                # Extract work item ID from the test case reference
                work_item_id = test_case_dict.get('work_item', {}).get('id')

                if work_item_id:
                    # Fetch full work item details (including all custom fields) using work item wrapper
                    # Note: Azure DevOps API does not allow using expand with fields parameter
                    if fields:
                        # When specific fields requested, cannot use expand
                        full_work_item = self._work_item_wrapper.get_work_item(
                            id=work_item_id,
                            fields=fields
                        )
                    else:
                        # When all fields requested, can use expand for relations
                        full_work_item = self._work_item_wrapper.get_work_item(
                            id=work_item_id,
                            expand='Relations'
                        )

                    # Add full work item details to the response
                    if isinstance(full_work_item, dict):
                        test_case_dict['work_item_full_details'] = full_work_item
                    else:
                        logger.warning(f"Failed to fetch full work item details for ID {work_item_id}")

                result.append(test_case_dict)

            return result
        except Exception as e:
            self._log_tool_event(f"Error getting test cases: {e}", 'get_test_cases')
            logger.error(f"Error getting test cases: {e}")
            return ToolException(f"Error getting test cases: {e}")
```
