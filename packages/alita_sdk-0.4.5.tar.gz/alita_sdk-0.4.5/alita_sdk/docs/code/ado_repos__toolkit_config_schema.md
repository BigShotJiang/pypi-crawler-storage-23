# ado_repos - toolkit_config_schema

**Toolkit**: `ado_repos`
**Method**: `toolkit_config_schema`
**Source File**: `__init__.py`
**Class**: `AzureDevOpsReposToolkit`

---

## Method Implementation

```python
    def toolkit_config_schema() -> BaseModel:
        selected_tools = {x['name']: x['args_schema'].schema() for x in ReposApiWrapper.model_construct().get_available_tools()}
        m = create_model(
            name,
            ado_configuration=(AdoConfiguration, Field(description="ADO configuration", default=None,
                                                       json_schema_extra={'configuration_types': ['ado']})),
            repository_id=(str, Field(description="ADO repository ID or name")),
            base_branch=(Optional[str], Field(default="main", title="Base branch", description="ADO base branch (e.g., main)")),
            active_branch=(Optional[str], Field(default="main", title="Active branch", description="ADO active branch (e.g., main)")),

            # indexer settings
            pgvector_configuration=(Optional[PgVectorConfiguration], Field(default=None, description="PgVector Configuration", json_schema_extra={'configuration_types': ['pgvector']})),
            # embedder settings
            embedding_model=(Optional[str], Field(default=None, description="Embedding configuration.", json_schema_extra={'configuration_model': 'embedding'})),

            selected_tools=(List[Literal[tuple(selected_tools)]], Field(default=[], json_schema_extra={'args_schemas': selected_tools})),
            __config__={
                'json_schema_extra': {
                    'metadata': {
                        "label": "ADO repos",
                        "icon_url": "ado-repos-icon.svg",
                        "categories": ["code repositories"],
                        "extra_categories": ["code", "repository", "version control"],
                        "sections": {
                            "auth": {
                                "required": True,
                                "subsections": [
                                    {
                                        "name": "Token",
                                        "fields": ["token"]
                                    }
                                ]
                            }
                        },
                        "configuration_group": {
                            "name": "ado",
                        }
                    }
                }
            }
        )

        @check_connection_response
        def check_connection(self):
            ado_config = self.ado_configuration
            response = requests.get(
                f'{ado_config.organization_url}/{ado_config.project}/_apis/git/repositories/{self.repository_id}?api-version=7.0',
                headers = {'Authorization': f'Bearer {ado_config.token.get_secret_value() if ado_config.token else ""}'},
                timeout=5
            )
            return response

        m.check_connection = check_connection
        return m
```
