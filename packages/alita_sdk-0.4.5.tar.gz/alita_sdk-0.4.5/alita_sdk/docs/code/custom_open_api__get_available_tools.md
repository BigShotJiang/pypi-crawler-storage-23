# custom_open_api - get_available_tools

**Toolkit**: `custom_open_api`
**Method**: `get_available_tools`
**Source File**: `api_wrapper.py`
**Class**: `OpenApiWrapper`

---

## Method Implementation

```python
    def get_available_tools(self):
        return [
            {
                "name": "invoke_rest_api_by_spec",
                "description": self.invoke_rest_api_by_spec.__doc__,
                "args_schema": create_model(
                    "InvokeRestApiBySpecModel",
                    method=(str, Field(description="The HTTP method to use")),
                    url=(str, Field(description="The URL to send the request to")),
                    headers=(Optional[str], Field(description="The headers to include in the request in JSON format", default="")),
                    fields=(Optional[str], Field(description="The query parameters to include in the request in JSON format", default="")),
                    body=(Optional[str], Field(description="The body of the request", default=""))
                ),
                "ref": self.invoke_rest_api_by_spec,
            },
            {
                "name": "get_open_api_spec",
                "description": self.get_open_api_spec.__doc__,
                "args_schema": create_model(
                    "GetOpenApiSpecModel",
                ),
                "ref": self.get_open_api_spec,
            }
        ]
```
