# ado_test_plan - get_test_case

**Toolkit**: `ado_test_plan`
**Method**: `get_test_case`
**Source File**: `test_plan_wrapper.py`
**Class**: `TestPlanApiWrapper`

---

## Method Implementation

```python
    def get_test_case(self, plan_id: int, suite_id: int, test_case_id: str, fields: Optional[List[str]] = None):
        """Get a test case from a suite in Azure DevOps with all custom fields."""
        try:
            # Get test case reference from test plan client (basic info only)
            test_cases = self._client.get_test_case(self.project, plan_id, suite_id, test_case_id)
            if not test_cases:
                return f"No test cases found per given criteria: project {self.project}, plan {plan_id}, suite {suite_id}, test case id {test_case_id}"

            test_case = test_cases[0]
            test_case_dict = test_case.as_dict()

            # Extract work item ID from the test case reference
            work_item_id = test_case_dict.get('work_item', {}).get('id')

            if work_item_id:
                # Fetch full work item details (including all custom fields) using work item wrapper
                # Note: Azure DevOps API does not allow using expand with fields parameter
                if fields:
                    # When specific fields requested, cannot use expand
                    full_work_item = self._work_item_wrapper.get_work_item(
                        id=work_item_id,
                        fields=fields
                    )
                else:
                    # When all fields requested, can use expand for relations
                    full_work_item = self._work_item_wrapper.get_work_item(
                        id=work_item_id,
                        expand='Relations'
                    )

                # Add full work item details to the response
                if isinstance(full_work_item, dict):
                    test_case_dict['work_item_full_details'] = full_work_item
                else:
                    logger.warning(f"Failed to fetch full work item details for ID {work_item_id}")

            return test_case_dict
        except Exception as e:
            logger.error(f"Error getting test case: {e}")
            return ToolException(f"Error getting test case: {e}")
```
