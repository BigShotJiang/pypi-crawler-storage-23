# carrier - calculate_all_requests

**Toolkit**: `carrier`
**Method**: `calculate_all_requests`
**Source File**: `excel_reporter.py`
**Class**: `GatlingReportParser`

---

## Method Implementation

```python
    def calculate_all_requests(self, requests: defaultdict) -> dict:
        all_entries = [entry for entries in requests.values() for entry in entries]
        return self.calculate_single_metric('Total', all_entries)
```

## Helper Methods

```python
Helper: calculate_single_metric
    def calculate_single_metric(self, name, entries):
        response_times = [d[0] for d in entries]
        ko_count = len([d for d in entries if d[1] != 'OK'])
        total_count = len(entries)
        ko_percentage = round((ko_count / total_count), 4) if total_count > 0 else 0

        if response_times:
            min_time, avg_time, p50_time, p90_time, p95_time, max_time = self.calculate_statistics(response_times)
        else:
            min_time = avg_time = p50_time = p90_time = p95_time = max_time = 0

        return {
            "request_name": name,
            "Total": total_count,
            "KO": ko_count,
            "Error%": ko_percentage,
            "min": min_time,
            "average": avg_time,
            "90Pct": p90_time,
            "95Pct": p95_time,
            "max": max_time
        }
```
