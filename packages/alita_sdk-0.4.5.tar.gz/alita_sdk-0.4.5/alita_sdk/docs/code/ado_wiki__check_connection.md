# ado_wiki - check_connection

**Toolkit**: `ado_wiki`
**Method**: `check_connection`
**Source File**: `__init__.py`
**Class**: `AzureDevOpsWikiToolkit`

---

## Method Implementation

```python
        def check_connection(self):
            ado_config = self.ado_wiki_configuration.ado_configuration if self.ado_wiki_configuration else None
            if not ado_config:
                raise ValueError("ADO wiki configuration is required")
            response = requests.get(
                f'{ado_config.organization_url}/{ado_config.project}/_apis/wiki/wikis?api-version=7.0',
                headers={'Authorization': f'Bearer {ado_config.token}'},
                timeout=5
            )
            return response
```
