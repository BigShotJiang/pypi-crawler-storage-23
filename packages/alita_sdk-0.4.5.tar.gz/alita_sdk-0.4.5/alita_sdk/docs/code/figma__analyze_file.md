# figma - analyze_file

**Toolkit**: `figma`
**Method**: `analyze_file`
**Source File**: `api_wrapper.py`
**Class**: `FigmaApiWrapper`

---

## Method Implementation

```python
    def analyze_file(
        self,
        url: Optional[str] = None,
        file_key: Optional[str] = None,
        node_id: Optional[str] = None,
        include_pages: Optional[str] = None,
        exclude_pages: Optional[str] = None,
        max_frames: int = 50,
        **kwargs,
    ) -> str:
        """
        Comprehensive Figma file analyzer with LLM-powered insights.

        Returns detailed analysis including:
        - File/page/frame structure with all content (text, buttons, components)
        - LLM-powered screen explanations with visual insights (using frame images)
        - LLM-powered user flow analysis identifying key user journeys
        - Design insights (patterns, gaps, recommendations)

        Drill-Down:
          - No node_id: Analyzes entire file (respecting include/exclude pages)
          - node_id=page_id: Focuses on specific page
          - node_id=frame_id: Returns detailed frame analysis

        For targeted analysis of specific frames (2-3 frames), use get_frame_detail_toon instead.
        """
        try:
            return self._analyze_file_internal(
                url=url,
                file_key=file_key,
                node_id=node_id,
                include_pages=include_pages,
                exclude_pages=exclude_pages,
                max_frames=max_frames,
                **kwargs,
            )
        except ToolException as e:
            raise ToolException(_handle_figma_error(e))
```
