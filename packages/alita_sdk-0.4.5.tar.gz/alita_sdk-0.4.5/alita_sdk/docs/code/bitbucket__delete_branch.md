# bitbucket - delete_branch

**Toolkit**: `bitbucket`
**Method**: `delete_branch`
**Source File**: `cloud_api_wrapper.py`
**Class**: `BitbucketCloudApi`

---

## Method Implementation

```python
    def delete_branch(self, branch_name: str) -> None:
        """
        Delete a branch from Bitbucket Cloud.
        
        Parameters:
            branch_name (str): The name of the branch to delete
        """
        # URL-encode branch name to handle special characters like forward slashes
        encoded_branch = quote(branch_name, safe='')
        self.repository.branches.delete(encoded_branch)
```
