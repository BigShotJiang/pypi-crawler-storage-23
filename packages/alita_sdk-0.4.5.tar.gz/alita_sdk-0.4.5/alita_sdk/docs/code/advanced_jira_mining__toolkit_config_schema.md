# advanced_jira_mining - toolkit_config_schema

**Toolkit**: `advanced_jira_mining`
**Method**: `toolkit_config_schema`
**Source File**: `__init__.py`
**Class**: `AdvancedJiraMiningToolkit`

---

## Method Implementation

```python
    def toolkit_config_schema() -> BaseModel:
        selected_tools = {x['name']: x['args_schema'].schema() for x in AdvancedJiraMiningWrapper.model_construct().get_available_tools()}
        return create_model(
            name,
            jira_base_url=(str, Field(default="", title="Jira URL", description="Jira URL", json_schema_extra={'toolkit_name': True})),
            confluence_base_url=(str, Field(default="", title="Confluence URL", description="Confluence URL")),
            model_type=(str, Field(default="", title="Model type", description="Model type")),
            summarization_prompt=(Optional[str], Field(default=None, title="Summarization prompt", description="Summarization prompt")),
            gaps_analysis_prompt=(Optional[str], Field(default=None, title="Gap analysis prompt", description="Gap analysis prompt")),
            jira_api_key=(Optional[SecretStr], Field(default=None, title="API key", description="JIRA API key", json_schema_extra={'secret': True})),
            jira_username=(Optional[str], Field(default=None, title="Username", description="JIRA Username")),
            jira_token=(Optional[SecretStr], Field(default=None, title="Token", description="JIRA Token", json_schema_extra={'secret': True})),
            is_jira_cloud=(bool, Field(default=True, title="Cloud", description="JIRA Cloud")),
            verify_ssl=(bool, Field(default=True, title="Verify SSL", description="Verify SSL")),
            selected_tools=(List[Literal[tuple(selected_tools)]], Field(default=[], json_schema_extra={'args_schemas': selected_tools})),
            __config__={
                'json_schema_extra':
                    {'metadata':
                         {
                             "label": "Advanced JIRA mining", "icon_url": "jira-icon.svg", "hidden": True,
                             "categories": ["project management"],
                             "extra_categories": ["jira", "confluence", "issue tracking", "agile management"],
                         }
                    }
            }
        )
```
