# carrier - parse_group_line

**Toolkit**: `carrier`
**Method**: `parse_group_line`
**Source File**: `excel_reporter.py`
**Class**: `GatlingReportParser`

---

## Method Implementation

```python
    def parse_group_line(groups, line, include_group_pauses):
        parts = line.split('\t')
        if len(parts) >= 6:
            group_name = parts[1]
            if include_group_pauses:
                response_time = int(parts[3]) - int(parts[2])
            else:
                response_time = int(parts[4])
            status = parts[5].strip()
            groups[group_name].append((response_time, status))
```
