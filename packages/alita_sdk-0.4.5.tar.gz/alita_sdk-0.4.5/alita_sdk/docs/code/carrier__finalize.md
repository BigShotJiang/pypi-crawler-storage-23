# carrier - finalize

**Toolkit**: `carrier`
**Method**: `finalize`
**Source File**: `create_ui_excel_report_tool.py`
**Class**: `LighthouseExcelReporter`

---

## Method Implementation

```python
    def finalize(self):
        """Finalize and save the Excel file."""
        if self.workbook and self.workbook.worksheets:
            self.workbook.save(self.output_file)
        else:
            raise ToolException("No worksheets were created")
```
