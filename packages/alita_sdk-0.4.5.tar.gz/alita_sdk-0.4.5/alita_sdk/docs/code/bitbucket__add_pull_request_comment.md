# bitbucket - add_pull_request_comment

**Toolkit**: `bitbucket`
**Method**: `add_pull_request_comment`
**Source File**: `cloud_api_wrapper.py`
**Class**: `BitbucketCloudApi`

---

## Method Implementation

```python
    def add_pull_request_comment(self, pr_id: str, content, inline=None) -> str:
        """
        Add a comment to a pull request. Supports multiple content types and inline comments.
        Parameters:
            pr_id (str): the pull request ID
            content (dict or str): The comment content. If str, will be used as raw text. If dict, can include 'raw', 'markup', 'html'.
            inline (dict, optional): Inline comment details. Example: {"from": 57, "to": 122, "path": "<string>"}
        Returns:
            str: The URL of the created comment
        """
        # Build the content dict for Bitbucket Cloud
        if isinstance(content, str):
            content_dict = {"raw": content}
        elif isinstance(content, dict):
            # Only include allowed keys
            content_dict = {k: v for k, v in content.items() if k in ("raw", "markup", "html")}
            if not content_dict:
                content_dict = {"raw": str(content)}
        else:
            content_dict = {"raw": str(content)}

        data = {"content": content_dict}
        if inline:
            data["inline"] = inline

        response = self.repository.pullrequests.get(pr_id).post("comments", data)
        return response['links']['html']['href']
```
