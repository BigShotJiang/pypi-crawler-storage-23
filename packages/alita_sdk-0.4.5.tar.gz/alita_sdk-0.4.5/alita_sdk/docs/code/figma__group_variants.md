# figma - group_variants

**Toolkit**: `figma`
**Method**: `group_variants`
**Source File**: `toon_tools.py`

---

## Method Implementation

```python
def group_variants(frames: List[Dict]) -> Dict[str, List[Dict]]:
    """
    Group frames that are variants of the same screen.

    Detects variants by:
    1. Same base name (with variant suffixes like _error, _hover removed)
    2. Identical names but different content (true state variants)

    Returns dict with frame data including position and inferred state:
    {"Login": [{"name": "Login", "pos": "0,105", "id": "1:100", "state": "default"}, ...]}
    """
    groups = {}

    for frame in frames:
        name = frame.get('name', '')
        base = extract_base_name(name)
        pos = frame.get('position', {})
        pos_str = f"{int(pos.get('x', 0))},{int(pos.get('y', 0))}"

        if base not in groups:
            groups[base] = []
        groups[base].append({
            'name': name,
            'pos': pos_str,
            'id': frame.get('id', ''),
            'frame': frame,  # Keep full frame data for delta computation
        })

    # Return groups that are true variants (different names OR different content)
    result = {}
    for base, variant_list in groups.items():
        if len(variant_list) > 1:
            unique_names = set(v['name'] for v in variant_list)

            # Variants if: different names OR same names but different content
            is_variant_group = (
                len(unique_names) > 1 or
                _frames_have_content_differences(variant_list)
            )

            if is_variant_group:
                # Infer state for each variant
                for v in variant_list:
                    v['state'] = _infer_variant_state(v.get('frame', v), variant_list)
                result[base] = variant_list

    return result
```
