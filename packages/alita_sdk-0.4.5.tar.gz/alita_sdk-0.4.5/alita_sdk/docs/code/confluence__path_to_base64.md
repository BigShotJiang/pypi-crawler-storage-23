# confluence - path_to_base64

**Toolkit**: `confluence`
**Method**: `path_to_base64`
**Source File**: `utils.py`

---

## Method Implementation

```python
def path_to_base64(path) -> str:
    with open(path, 'rb') as binary_file:
        return base64.b64encode(binary_file.read()).decode('utf-8')
```
