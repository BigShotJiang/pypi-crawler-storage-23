# carrier - validate_resource_type

**Toolkit**: `carrier`
**Method**: `validate_resource_type`
**Source File**: `utils.py`

---

## Method Implementation

```python
def validate_resource_type(resource_type: str) -> bool:
    """
    Validate if the resource type is supported.

    Args:
        resource_type (str): Resource type to validate

    Returns:
        bool: Whether the resource type is valid
    """
    # Define a list of supported resource types
    supported_types = [
        'deployments',
        'services',
        'configurations',
        'environments'
    ]

    return resource_type.lower() in supported_types
```
