# ado - check_connection

**Toolkit**: `ado`
**Method**: `check_connection`
**Source File**: `__init__.py`
**Class**: `AzureDevOpsWorkItemsToolkit`

---

## Method Implementation

```python
        def check_connection(self):
            ado_config = self.ado_work_item_configuration.ado_configuration if self.ado_work_item_configuration else None
            if not ado_config:
                raise ValueError("ADO work item configuration is required")
            response = requests.get(
                f'{ado_config.organization_url}/{ado_config.project}/_apis/wit/workitemtypes?api-version=7.0',
                headers={'Authorization': f'Bearer {ado_config.token}'},
                timeout=5
            )
            return response
```
