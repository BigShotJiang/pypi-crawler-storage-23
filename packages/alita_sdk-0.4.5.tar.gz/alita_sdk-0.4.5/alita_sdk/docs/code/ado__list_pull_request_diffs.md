# ado - list_pull_request_diffs

**Toolkit**: `ado`
**Method**: `list_pull_request_diffs`
**Source File**: `repos_wrapper.py`
**Class**: `ReposApiWrapper`

---

## Method Implementation

```python
    def list_pull_request_diffs(self, pull_request_id: str) -> str:
        """
        Fetches the files and their diffs included in a pull request.

        Returns:
            str: A list of files and diffs included in the pull request.
        """
        try:
            pull_request_id = int(pull_request_id)
        except Exception as e:
            return ToolException(
                f"Passed argument is not INT type: {pull_request_id}.\nError: {str(e)}"
            )

        try:
            pr_iterations = self._client.get_pull_request_iterations(
                repository_id=self.repository_id,
                project=self.project,
                pull_request_id=pull_request_id,
            )
            last_iteration_id = pr_iterations[-1].id

            changes = self._client.get_pull_request_iteration_changes(
                repository_id=self.repository_id,
                project=self.project,
                pull_request_id=pull_request_id,
                iteration_id=last_iteration_id,
            )
        except Exception as e:
            msg = f"Error during attempt to get Pull Request iterations and changes.\nError: {str(e)}"
            logger.error(msg)
            return ToolException(msg)

        data = []
        source_commit_id = pr_iterations[-1].source_ref_commit.commit_id
        target_commit_id = pr_iterations[-1].target_ref_commit.commit_id

        for change in changes.change_entries:
            path = change.additional_properties["item"]["path"]
            change_type = change.additional_properties["changeType"]

            # it should reflects VersionControlChangeType enum,
            # but the model is not accessible in azure.devops.v7_0.git.models
            if change_type == "edit":
                base_content = self.get_file_content(target_commit_id, path)
                if isinstance(base_content, ToolException):
                    msg = f"Failed to process base file content for path: {path}: {str(base_content)}"
                    logger.error(msg)
                    return msg

                target_content = self.get_file_content(source_commit_id, path)
                if isinstance(target_content, ToolException):
                    msg = f"Failed to process target file content for path: {path}: {str(target_content)}"
                    logger.error(msg)
                    return msg

                diff = generate_diff(base_content, target_content, path)
            else:
                diff = f"Change Type: {change_type}"

            data.append({"path": path, "diff": diff})

        return dumps(data)
```
