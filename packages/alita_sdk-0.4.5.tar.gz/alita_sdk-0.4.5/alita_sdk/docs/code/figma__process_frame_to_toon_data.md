# figma - process_frame_to_toon_data

**Toolkit**: `figma`
**Method**: `process_frame_to_toon_data`
**Source File**: `toon_tools.py`

---

## Method Implementation

```python
def process_frame_to_toon_data(frame_node: Dict) -> Dict:
    """
    Process a Figma frame node into TOON-ready data structure.

    Returns structured data that can be serialized to TOON format.
    """
    name = frame_node.get('name', 'Untitled')

    # Extract position and size
    bounds = frame_node.get('absoluteBoundingBox', {})
    position = {'x': bounds.get('x', 0), 'y': bounds.get('y', 0)}
    size = {'w': bounds.get('width', 0), 'h': bounds.get('height', 0)}

    # Extract text by role
    text_data = extract_text_by_role(frame_node)

    # Extract components
    components = extract_components(frame_node)

    # Extract input fields
    inputs = extract_inputs(frame_node)
    # Dedupe inputs by name
    seen_inputs = set()
    unique_inputs = []
    for inp in inputs:
        if inp['name'] not in seen_inputs:
            seen_inputs.add(inp['name'])
            unique_inputs.append(inp)

    # Build frame data with deduplication
    frame_data = {
        'id': frame_node.get('id', ''),
        'name': name,
        'position': position,
        'size': size,
        # Deduplicate and limit text fields
        'headings': dedupe_and_clean_text(text_data['headings'], max_items=5),
        'labels': dedupe_and_clean_text(text_data['labels'], max_items=15),
        'buttons': dedupe_and_clean_text(text_data['buttons'], max_items=10),
        'inputs': unique_inputs[:10],  # Limit to 10 inputs
        'body': dedupe_and_clean_text(text_data['body'], max_items=10),
        'errors': dedupe_and_clean_text(text_data['errors'], max_items=5),
        'placeholders': dedupe_and_clean_text(text_data.get('placeholders', []), max_items=5),
        'components': list(dict.fromkeys(components))[:15],  # Dedupe components too
    }

    # Infer type and state
    frame_data['type'] = infer_screen_type(frame_data)
    frame_data['state'] = infer_state_from_name(name)

    # Check if variant
    base_name = extract_base_name(name)
    if base_name != name:
        frame_data['variant_of'] = base_name

    return frame_data
```

## Helper Methods

```python
Helper: extract_components
def extract_components(node: Dict, depth: int = 0, max_depth: int = 10) -> List[str]:
    """
    Recursively extract component/instance names.
    """
    if depth > max_depth:
        return []

    components = []
    node_type = node.get('type', '').upper()

    if node_type in ['COMPONENT', 'INSTANCE', 'COMPONENT_SET']:
        name = node.get('name', '')
        if name:
            components.append(name)

    for child in node.get('children', []):
        components.extend(extract_components(child, depth + 1, max_depth))

    return components
```

```python
Helper: extract_base_name
def extract_base_name(name: str) -> str:
    """
    Extract base name for variant grouping.

    "Login_Error" -> "Login"
    "Login - Error State" -> "Login"
    "01_Login_Loading" -> "Login"
    """
    # Remove sequence prefix first
    seq_result = extract_sequence_number(name)
    if seq_result:
        name = seq_result[1]

    # Common variant suffixes to strip
    variant_patterns = [
        r'[-_\s]+(error|success|loading|empty|disabled|active|hover|pressed|selected|default|filled|focused)(\s+state)?$',
        r'[-_\s]+(v\d+|variant\s*\d*)$',
        r'[-_\s]+\d+$',  # Trailing numbers
    ]

    base = name
    for pattern in variant_patterns:
        base = re.sub(pattern, '', base, flags=re.IGNORECASE)

    return base.strip()
```
