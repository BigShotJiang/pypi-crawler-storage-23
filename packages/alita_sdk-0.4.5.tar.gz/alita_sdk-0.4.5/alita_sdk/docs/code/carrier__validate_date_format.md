# carrier - validate_date_format

**Toolkit**: `carrier`
**Method**: `validate_date_format`
**Source File**: `tickets_tool.py`
**Class**: `TicketData`

---

## Method Implementation

```python
    def validate_date_format(cls, value, info):
        if not isinstance(value, str):
            raise ValueError(f"{info.field_name} must be a string in YYYY-MM-DD format.")
        try:
            # Attempt to parse
            datetime.strptime(value, "%Y-%m-%d")
        except ValueError:
            raise ValueError(
                f"Invalid date format for {info.field_name}. Expected 'YYYY-MM-DD', got '{value}'."
            )
        return value
```
