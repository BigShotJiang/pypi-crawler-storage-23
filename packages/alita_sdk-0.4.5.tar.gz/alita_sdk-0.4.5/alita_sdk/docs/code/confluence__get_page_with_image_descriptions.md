# confluence - get_page_with_image_descriptions

**Toolkit**: `confluence`
**Method**: `get_page_with_image_descriptions`
**Source File**: `api_wrapper.py`
**Class**: `ConfluenceAPIWrapper`

---

## Method Implementation

```python
    def get_page_with_image_descriptions(self, page_id: str, prompt: Optional[str] = None, context_radius: int = 500):
        """
        Get a Confluence page and augment any images in it with textual descriptions that include
        image names and contextual information from surrounding text.

        This method will:
        1. Extract the specified page content from Confluence
        2. Detect images in the content (both attachments and embedded/linked images)
        3. Retrieve and process each image with an LLM, providing surrounding context
        4. Replace image references with the generated text descriptions

        Args:
            page_id: The Confluence page ID to retrieve
            prompt: Custom prompt for the LLM when analyzing images. If None, a default prompt will be used.
            context_radius: Number of characters to include before and after each image for context. Default is 500.

        Returns:
            The page content with image references replaced with contextual descriptions
        """
        try:
            # Get the page content
            page = self.client.get_page_by_id(page_id, expand="body.storage")
            if not page:
                return f"Page with ID {page_id} not found."

            page_title = page['title']
            page_content = page['body']['storage']['value']

            # Regular expressions to find different types of image references in Confluence markup:

            # 1. Attachment-based images - <ac:image><ri:attachment ri:filename="image.png" /></ac:image>
            attachment_image_pattern = r'<ac:image[^>]*>(?:.*?)<ri:attachment ri:filename="([^"]+)"[^>]*/>(?:.*?)</ac:image>'

            # 2. URL-based images - <ac:image><ri:url ri:value="http://example.com/image.png" /></ac:image>
            url_image_pattern = r'<ac:image[^>]*>(?:.*?)<ri:url ri:value="([^"]+)"[^>]*/>(?:.*?)</ac:image>'

            # 3. Base64 embedded images - <ac:image><ac:resource>...<ac:media-type>image/png</ac:media-type><ac:data>(base64 data)</ac:data></ac:resource></ac:image>
            base64_image_pattern = r'<ac:image[^>]*>(?:.*?)<ac:resource>(?:.*?)<ac:media-type>([^<]+)</ac:media-type>(?:.*?)<ac:data>([^<]+)</ac:data>(?:.*?)</ac:resource>(?:.*?)</ac:image>'

            # Process attachment-based images
            def process_attachment_image(match):
                """Process attachment-based image references and get contextual descriptions"""
                image_filename = match.group(1)
                full_match = match.group(0)  # The complete image reference

                logger.info(f"Processing attachment image reference: {image_filename}")

                try:
                    # Get the image attachment from the page
                    attachments = self.client.get_attachments_from_content(page_id)['results']
                    attachment = None

                    # Find the attachment that matches the filename
                    for att in attachments:
                        if att['title'] == image_filename:
                            attachment = att
                            break

                    if not attachment:
                        logger.warning(f"Could not find attachment for image: {image_filename}")
                        return f"[Image: {image_filename} - attachment not found]"

                    # Get the download URL and download the image
                    download_url = self.base_url.rstrip('/') + attachment['_links']['download']
                    logger.info(f"Downloading image from URL: {download_url}")
                    image_data = self._download_image(download_url)

                    if not image_data:
                        logger.error(f"Failed to download image from URL: {download_url}")
                        return f"[Image: {image_filename} - download failed]"

                    # Collect surrounding context
                    context_text = self._collect_context_for_image(page_content, full_match, context_radius)

                    # Process with LLM (will use cache if available)
                    description = self._process_image_with_llm(image_data, image_filename, context_text, prompt)
                    return f"[Image {image_filename} Description: {description}]"

                except Exception as e:
                    logger.error(f"Error processing attachment image {image_filename}: {str(e)}")
                    return f"[Image: {image_filename} - Error: {str(e)}]"

            # Process URL-based images
            def process_url_image(match):
                """Process URL-based image references and get contextual descriptions"""
                image_url = match.group(1)
                full_match = match.group(0)  # The complete image reference

                logger.info(f"Processing URL image reference: {image_url}")

                try:
                    # Extract image name from URL for better reference
                    image_name = image_url.split('/')[-1]

                    # Download the image
                    logger.info(f"Downloading image from URL: {image_url}")
                    image_data = self._download_image(image_url)

                    if not image_data:
                        logger.error(f"Failed to download image from URL: {image_url}")
                        return f"[Image: {image_name} - download failed]"

                    # Collect surrounding context
                    context_text = self._collect_context_for_image(page_content, full_match, context_radius)

                    # Process with LLM (will use cache if available)
                    description = self._process_image_with_llm(image_data, image_name, context_text, prompt)
                    return f"[Image {image_name} Description: {description}]"

                except Exception as e:
                    logger.error(f"Error processing URL image {image_url}: {str(e)}")
                    return f"[Image: {image_url} - Error: {str(e)}]"

            # Process base64 embedded images
            def process_base64_image(match):
                """Process base64 embedded image references and get contextual descriptions"""
                media_type = match.group(1)
                base64_data = match.group(2)
                full_match = match.group(0)  # The complete image reference

                logger.info(f"Processing base64 embedded image of type: {media_type}")

                try:
                    # Generate a name for the image based on media type
                    image_format = media_type.split('/')[-1]
                    image_name = f"embedded-image.{image_format}"

                    # Decode base64 data
                    try:
                        image_data = base64.b64decode(base64_data)
                    except Exception as e:
                        logger.error(f"Failed to decode base64 image data: {str(e)}")
                        return f"[Image: embedded {media_type} - decode failed]"

                    # Collect surrounding context
                    context_text = self._collect_context_for_image(page_content, full_match, context_radius)

                    # Process with LLM (will use cache if available)
                    description = self._process_image_with_llm(image_data, image_name, context_text, prompt)
                    return f"[Image {image_name} Description: {description}]"

                except Exception as e:
                    logger.error(f"Error processing base64 image: {str(e)}")
                    return f"[Image: embedded {media_type} - Error: {str(e)}]"

            # Replace each type of image reference with its description
            processed_content = page_content

            # 1. Process attachment-based images
            processed_content = re.sub(attachment_image_pattern, process_attachment_image, processed_content)

            # 2. Process URL-based images
            processed_content = re.sub(url_image_pattern, process_url_image, processed_content)

            # 3. Process base64 embedded images
            processed_content = re.sub(base64_image_pattern, process_base64_image, processed_content)

            # Convert HTML to markdown for easier readability
            try:
                augmented_markdown = markdownify(processed_content, heading_style="ATX")
                return f"Page '{page_title}' (ID: {page_id}) with image descriptions:\n\n{augmented_markdown}"
            except Exception as e:
                logger.warning(f"Failed to convert to markdown: {str(e)}. Returning HTML content.")
                # If markdownify fails, return the processed HTML
                return f"Page '{page_title}' (ID: {page_id}) with image descriptions:\n\n{processed_content}"

        except Exception as e:
            stacktrace = traceback.format_exc()
            logger.error(f"Error processing page with images: {stacktrace}")
            return f"Error processing page with images: {str(e)}"
```
