# carrier - get_build_status_and_justification

**Toolkit**: `carrier`
**Method**: `get_build_status_and_justification`
**Source File**: `excel_reporter.py`
**Class**: `ExcelReporter`

---

## Method Implementation

```python
    def get_build_status_and_justification(self, thresholds, report_percentile):
        justification = ""
        build_status = "SUCCESS"
        rt_threshold = self.get_response_threshold(thresholds)
        for th in thresholds:
            if th["target"] == "error_rate":
                if th["status"] == "FAILED":
                    justification = "Total error rate exceed the threshold of " + str(th["threshold"]) + "% "
                    build_status = "FAILED"
                else:
                    justification = "Total error rate doesn't exceed the threshold of " + str(th["threshold"]) + "% "
            if th["target"] == "response_time":
                if th["status"] == "FAILED":
                    if build_status == "FAILED":
                        justification += "and Response Time for some transaction(s) exceed the threshold of " + str(
                            rt_threshold / 1000) + " seconds by " + report_percentile
                    else:
                        build_status = "FAILED"
                        justification = "Response Time for some transaction(s) exceed the threshold of " + str(
                            rt_threshold / 1000) + " seconds by " + report_percentile
                    return build_status, justification
        justification += "and Response Time for all transactions doesn't exceed the threshold of " + str(
            rt_threshold / 1000) + " seconds by " + report_percentile
        return build_status, justification
```

## Helper Methods

```python
Helper: get_response_threshold
    def get_response_threshold(thresholds):
        for th in thresholds:
            if th["target"] == "response_time":
                return th["threshold"]
```
