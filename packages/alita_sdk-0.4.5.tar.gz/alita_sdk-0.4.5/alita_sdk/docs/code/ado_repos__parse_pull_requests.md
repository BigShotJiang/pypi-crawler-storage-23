# ado_repos - parse_pull_requests

**Toolkit**: `ado_repos`
**Method**: `parse_pull_requests`
**Source File**: `repos_wrapper.py`
**Class**: `ReposApiWrapper`

---

## Method Implementation

```python
    def parse_pull_requests(
            self, pull_requests: Union[GitPullRequest, List[GitPullRequest]]
    ) -> List[dict]:
        """
        Extracts title and number from each Pull Request and puts them in a dictionary
        Parameters:
            issues(List[GitPullRequest]): A list of ADO Repos  GitPullRequest objects
        Returns:
            List[dict]: A dictionary of Pull Request titles and numbers
        """
        if not isinstance(pull_requests, list):
            pull_requests = [pull_requests]

        parsed = []
        try:
            for pull_request in pull_requests:
                comment_threads: List[GitPullRequestCommentThread] = (
                    self._client.get_threads(
                        repository_id=self.repository_id,
                        pull_request_id=pull_request.pull_request_id,
                        project=self.project,
                    )
                )

                commits: List[GitCommitRef] = self._client.get_pull_request_commits(
                    repository_id=self.repository_id,
                    project=self.project,
                    pull_request_id=pull_request.pull_request_id,
                )

                commit_details = [
                    {"commit_id": commit.commit_id, "comment": commit.comment}
                    for commit in commits
                ]

                parsed.append(
                    {
                        "title": pull_request.title,
                        "pull_request_id": pull_request.pull_request_id,
                        "commits": commit_details,
                        "comments": self.parse_pull_request_comments(comment_threads),
                        "source_branch": pull_request.source_ref_name,
                        "target_branch": pull_request.target_ref_name,
                    }
                )
        except Exception as e:
            msg = f"Failed to parse pull requests. Error: {str(e)}"
            logger.error(msg)
            return ToolException(msg)

        return parsed
```

## Helper Methods

```python
Helper: parse_pull_request_comments
    def parse_pull_request_comments(
            self, comment_threads: List[GitPullRequestCommentThread]
    ) -> List[dict]:
        """
        Extracts comments from each comment thread and puts them in a dictionary.

        Parameters:
            comment_threads (List[GitPullRequestCommentThread]): A list of comment threads associated with a pull request.

        Returns:
            List[dict]: A list of dictionaries with comment details.
        """
        parsed_comments = []
        for thread in comment_threads:
            for comment in thread.comments:
                parsed_comments.append(
                    {
                        "id": comment.id,
                        "author": comment.author.display_name,
                        "content": comment.content,
                        "published_date": comment.published_date.strftime(
                            "%Y-%m-%d %H:%M:%S %Z"
                        )
                        if comment.published_date
                        else None,
                        "status": thread.status if thread.status else None,
                    }
                )
        return parsed_comments
```
