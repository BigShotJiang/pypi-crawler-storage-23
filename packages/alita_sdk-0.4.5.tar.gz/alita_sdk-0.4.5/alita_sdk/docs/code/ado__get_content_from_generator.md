# ado - get_content_from_generator

**Toolkit**: `ado`
**Method**: `get_content_from_generator`
**Source File**: `utils.py`

---

## Method Implementation

```python
def get_content_from_generator(content_generator):
    def safe_decode(chunk):
        try:
            return chunk.decode("utf-8")
        except UnicodeDecodeError:
            return chunk.decode("ascii", errors="backslashreplace")

    return "".join(safe_decode(chunk) for chunk in content_generator)
```

## Helper Methods

```python
Helper: safe_decode
    def safe_decode(chunk):
        try:
            return chunk.decode("utf-8")
        except UnicodeDecodeError:
            return chunk.decode("ascii", errors="backslashreplace")
```
