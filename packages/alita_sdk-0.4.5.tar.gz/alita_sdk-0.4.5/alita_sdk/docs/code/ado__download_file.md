# ado - download_file

**Toolkit**: `ado`
**Method**: `download_file`
**Source File**: `repos_wrapper.py`
**Class**: `ReposApiWrapper`

---

## Method Implementation

```python
    def download_file(self, path: str, branch: str = None):
        branch = branch or self.active_branch or self.base_branch
        version_descriptor = GitVersionDescriptor(
            version=branch, version_type="branch"
        )
        return b"".join(self._client.get_item_content(
            self.repository_id,
            path=path,
            project=self.project,
            download=True,
            version_descriptor=version_descriptor
        ))
```
