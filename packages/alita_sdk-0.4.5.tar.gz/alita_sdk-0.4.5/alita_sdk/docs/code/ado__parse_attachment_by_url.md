# ado - parse_attachment_by_url

**Toolkit**: `ado`
**Method**: `parse_attachment_by_url`
**Source File**: `ado_wrapper.py`
**Class**: `AzureDevOpsApiWrapper`

---

## Method Implementation

```python
    def parse_attachment_by_url(self, attachment_url, file_name=None, image_description_prompt=None):
        match = re.search(r'attachments/([\w-]+)(?:\?fileName=([^&]+))?', attachment_url)
        if match:
            attachment_id = match.group(1)
            if not file_name:
                file_name = match.group(2)
            if not file_name:
                raise ToolException("File name must be provided either in the URL or as a parameter.")
            return self.parse_attachment_by_id(attachment_id, file_name, image_description_prompt)
        raise ToolException(f"Attachment '{attachment_url}' was not found.")
```

## Helper Methods

```python
Helper: parse_attachment_by_id
    def parse_attachment_by_id(self, attachment_id, file_name, image_description_prompt):
        file_content = self.get_attachment_content(attachment_id)
        return parse_file_content(file_content=file_content, file_name=file_name,
                                            llm=self.llm, prompt=image_description_prompt)
```
