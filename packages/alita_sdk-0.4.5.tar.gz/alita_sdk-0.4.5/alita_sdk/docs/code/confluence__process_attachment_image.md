# confluence - process_attachment_image

**Toolkit**: `confluence`
**Method**: `process_attachment_image`
**Source File**: `api_wrapper.py`
**Class**: `ConfluenceAPIWrapper`

---

## Method Implementation

```python
            def process_attachment_image(match):
                """Process attachment-based image references and get contextual descriptions"""
                image_filename = match.group(1)
                full_match = match.group(0)  # The complete image reference

                logger.info(f"Processing attachment image reference: {image_filename}")

                try:
                    # Get the image attachment from the page
                    attachments = self.client.get_attachments_from_content(page_id)['results']
                    attachment = None

                    # Find the attachment that matches the filename
                    for att in attachments:
                        if att['title'] == image_filename:
                            attachment = att
                            break

                    if not attachment:
                        logger.warning(f"Could not find attachment for image: {image_filename}")
                        return f"[Image: {image_filename} - attachment not found]"

                    # Get the download URL and download the image
                    download_url = self.base_url.rstrip('/') + attachment['_links']['download']
                    logger.info(f"Downloading image from URL: {download_url}")
                    image_data = self._download_image(download_url)

                    if not image_data:
                        logger.error(f"Failed to download image from URL: {download_url}")
                        return f"[Image: {image_filename} - download failed]"

                    # Collect surrounding context
                    context_text = self._collect_context_for_image(page_content, full_match, context_radius)

                    # Process with LLM (will use cache if available)
                    description = self._process_image_with_llm(image_data, image_filename, context_text, prompt)
                    return f"[Image {image_filename} Description: {description}]"

                except Exception as e:
                    logger.error(f"Error processing attachment image {image_filename}: {str(e)}")
                    return f"[Image: {image_filename} - Error: {str(e)}]"
```
