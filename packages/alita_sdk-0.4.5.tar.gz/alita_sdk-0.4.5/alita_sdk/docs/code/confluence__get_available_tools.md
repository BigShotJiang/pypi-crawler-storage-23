# confluence - get_available_tools

**Toolkit**: `confluence`
**Method**: `get_available_tools`
**Source File**: `api_wrapper.py`
**Class**: `ConfluenceAPIWrapper`

---

## Method Implementation

```python
    def get_available_tools(self):
        return [
            {
                "name": "create_page",
                "ref": self.create_page,
                "description": self.create_page.__doc__,
                "args_schema": createPage,
            },
            {
                "name": "create_pages",
                "ref": self.create_pages,
                "description": self.create_pages.__doc__,
                "args_schema": createPages,
            },
            {
                "name": "delete_page",
                "ref": self.delete_page,
                "description": self.delete_page.__doc__,
                "args_schema": deletePage,
            },
            {
                "name": "update_page_by_id",
                "ref": self.update_page_by_id,
                "description": self.update_page_by_id.__doc__,
                "args_schema": updatePageById,
            },
            {
                "name": "update_page_by_title",
                "ref": self.update_page_by_title,
                "description": self.update_page_by_title.__doc__,
                "args_schema": updatePageByTitle,
            },
            {
                "name": "update_pages",
                "ref": self.update_pages,
                "description": self.update_pages.__doc__,
                "args_schema": updatePages,
            },
            {
                "name": "update_labels",
                "ref": self.update_labels,
                "description": self.update_labels.__doc__,
                "args_schema": updateLabels,
            },
            {
                "name": "get_page_tree",
                "ref": self.get_page_tree,
                "description": self.get_page_tree.__doc__,
                "args_schema": getPageTree,
            },
            # {
            #     "name": "page_exists",
            #     "ref": self.page_exists,
            #     "description": self.page_exists.__doc__,
            #     "args_schema": pageExists,
            # },
            {
                "name": "get_pages_with_label",
                "ref": self.get_pages_with_label,
                "description": self.get_pages_with_label.__doc__,
                "args_schema": getPagesWithLabel,
            },
            {
                "name": "list_pages_with_label",
                "ref": self.list_pages_with_label,
                "description": self.list_pages_with_label.__doc__,
                "args_schema": getPagesWithLabel,
            },
            {
                "name": "read_page_by_id",
                "ref": self.read_page_by_id,
                "description": self.read_page_by_id.__doc__,
                "args_schema": pageId,
            },
            {
                "name": "search_pages",
                "ref": self.search_pages,
                "description": self.search_pages.__doc__,
                "args_schema": searchPages,
            },
            {
                "name": "search_by_title",
                "ref": self.search_by_title,
                "description": self.search_by_title.__doc__,
                "args_schema": searchPages,
            },
            {
                "name": "site_search",
                "ref": self.site_search,
                "description": self.site_search.__doc__,
                "args_schema": siteSearch,
            },
            {
                "name": "get_page_with_image_descriptions",
                "ref": self.get_page_with_image_descriptions,
                "description": self.get_page_with_image_descriptions.__doc__,
                "args_schema": GetPageWithImageDescriptions,
            },
            {
                "name": "execute_generic_confluence",
                "description": self.execute_generic_confluence.__doc__,
                "args_schema": сonfluenceInput,
                "ref": self.execute_generic_confluence,
            },
            {
                "name": "get_page_id_by_title",
                "ref": self.get_page_id_by_title,
                "description": self.get_page_id_by_title.__doc__,
                "args_schema": getPageIdByTitleInput,
            },
            {
                "name": "get_page_attachments",
                "ref": self.get_page_attachments,
                "description": self.get_page_attachments.__doc__,
                "args_schema": GetPageAttachmentsInput,
            },
            {
                "name": "add_file_to_page",
                "ref": self.add_file_to_page,
                "description": self.add_file_to_page.__doc__,
                "args_schema": AddFileToPage,
            }
        ]
```
