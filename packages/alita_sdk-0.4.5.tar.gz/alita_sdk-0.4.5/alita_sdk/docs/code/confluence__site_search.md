# confluence - site_search

**Toolkit**: `confluence`
**Method**: `site_search`
**Source File**: `api_wrapper.py`
**Class**: `ConfluenceAPIWrapper`

---

## Method Implementation

```python
    def site_search(self, query: str):
        """Search for pages in Confluence using site search by query text."""
        content = []
        query = self._escape_cql_query(query)
        if not self.space:
            cql = f'(type=page) and (siteSearch~"{query}")'
        else:
            cql = f'(type=page and space={self.__sanitize_confluence_space()}) and (siteSearch~"{query}")'
        pages = self.client.cql(cql, start=0, limit=10).get("results", [])
        if not pages:
            return f"Unable to find anything using query {query}"
        # extract id, title, url and preview text
        for page in pages:
            page_data = {
                'page_id': page['content']['id'],
                'page_title': page['content']['title'],
                'page_url': page['content']['_links']['self']
            }
            page_data['preview'] = page['excerpt'] if page['excerpt'] else ""
            content.append(page_data)
        return '---'.join([str(page_data) for page_data in content])
```
