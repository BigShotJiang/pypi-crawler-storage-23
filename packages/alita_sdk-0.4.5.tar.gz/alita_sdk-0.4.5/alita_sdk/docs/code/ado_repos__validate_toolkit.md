# ado_repos - validate_toolkit

**Toolkit**: `ado_repos`
**Method**: `validate_toolkit`
**Source File**: `repos_wrapper.py`
**Class**: `ReposApiWrapper`

---

## Method Implementation

```python
    def validate_toolkit(cls, values):
        from langchain_core.utils import get_from_dict_or_env

        # Get ADO configuration values
        organization_url = get_from_dict_or_env(values, ["organization_url"], "ADO_ORGANIZATION_URL", default=None)
        project = get_from_dict_or_env(values, ["project"], "ADO_PROJECT", default=None)
        token = get_from_dict_or_env(values, ["token"], "ADO_TOKEN", default=None)

        # Get repository-specific values
        repository_id = get_from_dict_or_env(values, ["repository_id"], "ADO_REPOSITORY_ID", default=None)
        base_branch = get_from_dict_or_env(values, ["base_branch"], "ADO_BASE_BRANCH", default="main")
        active_branch = get_from_dict_or_env(values, ["active_branch"], "ADO_ACTIVE_BRANCH", default="main")

        if not organization_url or not project or not repository_id:
            raise ToolException(
                "Parameters: organization_url, project, and repository_id are required."
            )

        credentials = BasicAuthentication("", token)

        try:
            # Initialize ADO Git client
            ado_client = GitClient(base_url=organization_url, creds=credentials)
            # Verify access to repository
            ado_client.get_repository(repository_id, project=project)

            # Store client instance
            values["ado_client_instance"] = ado_client

            def branch_exists(branch_name):
                try:
                    branch = ado_client.get_branch(
                        repository_id=repository_id, name=branch_name, project=project
                    )
                    return branch is not None
                except Exception:
                    return False

            if base_branch:
                if not branch_exists(base_branch):
                    raise ToolException(f"The base branch '{base_branch}' does not exist.")
            if active_branch:
                if not branch_exists(active_branch):
                    raise ToolException(f"The active branch '{active_branch}' does not exist.")

        except Exception as e:
            if isinstance(e, ToolException):
                raise
            raise ToolException(f"Failed to connect to Azure DevOps: {e}")

        # Update values with configuration
        values["organization_url"] = organization_url
        values["project"] = project
        values["token"] = token
        values["repository_id"] = repository_id
        values["base_branch"] = base_branch
        values["active_branch"] = active_branch

        return super().validate_toolkit(values)
```

## Helper Methods

```python
Helper: branch_exists
            def branch_exists(branch_name):
                try:
                    branch = ado_client.get_branch(
                        repository_id=repository_id, name=branch_name, project=project
                    )
                    return branch is not None
                except Exception:
                    return False
```
