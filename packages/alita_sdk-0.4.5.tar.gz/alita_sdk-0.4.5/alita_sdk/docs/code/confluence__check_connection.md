# confluence - check_connection

**Toolkit**: `confluence`
**Method**: `check_connection`
**Source File**: `__init__.py`
**Class**: `ConfluenceToolkit`

---

## Method Implementation

```python
        def check_connection(self):
            # Normalize base URL and construct API endpoint
            normalized_url = self.base_url.rstrip('/')
            cloud = getattr(self, 'cloud', True)

            # For cloud instances, ensure /wiki is present in the API path
            # Self-hosted instances may use different paths (e.g., /confluence)
            if cloud:
                # Check if base_url already includes /wiki
                if normalized_url.endswith('/wiki'):
                    url = normalized_url + '/rest/api/space'
                else:
                    url = normalized_url + '/wiki/rest/api/space'
            else:
                # For self-hosted, append /rest/api/space directly
                url = normalized_url + '/rest/api/space'

            headers = {'Accept': 'application/json'}
            auth = None
            confluence_config = self.confluence_configuration or {}
            token = confluence_config.get('token')
            username = confluence_config.get('username')
            api_key = confluence_config.get('api_key')

            if token:
                headers['Authorization'] = f'Bearer {token}'
            elif username and api_key:
                auth = (username, api_key)
            else:
                raise ValueError('Confluence connection requires either token or username+api_key')
            response = requests.get(url, headers=headers, auth=auth, timeout=5, verify=getattr(self, 'verify_ssl', True))
            return response
```
