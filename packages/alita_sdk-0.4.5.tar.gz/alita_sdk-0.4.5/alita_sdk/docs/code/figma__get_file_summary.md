# figma - get_file_summary

**Toolkit**: `figma`
**Method**: `get_file_summary`
**Source File**: `api_wrapper.py`
**Class**: `FigmaApiWrapper`

---

## Method Implementation

```python
    def get_file_summary(
            self,
            url: Optional[str] = None,
            file_key: Optional[str] = None,
            include_node_ids: Optional[str] = None,
            exclude_node_ids: Optional[str] = None,
             **kwargs,
    ):
        """Summarizes a Figma file by loading pages and nodes via URL or file key.

        Configuration for image processing and summarization is taken from the toolkit
        configuration (see FigmaToolkit.toolkit_config_schema):

          - self.apply_images_prompt: if True, pass self.images_prompt to the image-processing step.
          - self.images_prompt: instruction string for how to treat image-based nodes.
          - self.apply_summary_prompt: if True and self.summary_prompt is set and an LLM is configured,
            return a single summarized string; otherwise return the raw list of node documents.
          - self.summary_prompt: instruction string for LLM summarization.

        Tool arguments mirror ArgsSchema.FileSummary and control only which file/pages are loaded.
        """
        # Prepare params for _base_loader without evaluating any logic here
        node_ids_include_list = None
        node_ids_exclude_list = None

        if include_node_ids:
            node_ids_include_list = [nid.strip() for nid in include_node_ids.split(',') if nid.strip()]

        if exclude_node_ids:
            node_ids_exclude_list = [nid.strip() for nid in exclude_node_ids.split(',') if nid.strip()]

        # Delegate URL and file_key handling to _base_loader
        base_docs = self._base_loader(
            urls_or_file_keys=url or file_key,
            node_ids_include=node_ids_include_list,
            node_ids_exclude=node_ids_exclude_list,
        )

        # Read prompt-related configuration from toolkit instance (set via wrapper_payload)
        apply_images_prompt = getattr(self, "apply_images_prompt", False)
        images_prompt = getattr(self, "images_prompt", None)
        apply_summary_prompt = getattr(self, "apply_summary_prompt", True)
        summary_prompt = getattr(self, "summary_prompt", None)

        # Decide whether to apply images_prompt. Expect dict with 'prompt'.
        if (
            apply_images_prompt
            and isinstance(images_prompt, dict)
            and isinstance(images_prompt.get("prompt"), str)
            and images_prompt["prompt"].strip()
        ):
            images_prompt_str = images_prompt["prompt"].strip()
        else:
            images_prompt_str = ""

        results: List[Dict] = []
        for base_doc in base_docs:
            for dep in self._process_document(
                base_doc,
                images_prompt_str,
            ):
                 results.append({
                     "page_content": dep.page_content,
                     "metadata": dep.metadata,
                 })

        # Decide whether to apply summary_prompt
        has_summary_prompt = bool(
            isinstance(summary_prompt, dict)
            and isinstance(summary_prompt.get("prompt"), str)
            and summary_prompt["prompt"].strip()
        )
        if not apply_summary_prompt or not has_summary_prompt:
            # Return raw docs when summary is disabled or no prompt provided
            self._log_tool_event("Summary prompt not provided: returning raw documents.")
            return results

        # If summary_prompt is enabled, generate an LLM-based summary over the loaded docs
        try:
            # Build a structured, ordered view of images and texts to help the LLM infer flows.
            blocks = []
            for item in results:
                metadata = item.get("metadata", {}) or {}
                node_type = str(metadata.get("type", "")).lower()
                node_id = metadata.get("node_id") or metadata.get("id", "")
                page_content = str(item.get("page_content", "")).strip()

                if not page_content:
                    continue

                if node_type == "image":
                    image_url = metadata.get("image_url", "")
                    header = f"Image ({node_id}), {image_url}".strip().rstrip(',')
                    body = page_content
                else:
                    header = f"Text ({node_id})".strip()
                    body = page_content

                block = f"{header}\n{body}\n--------------------"
                blocks.append(block)

            full_content = "\n".join(blocks) if blocks else "(no content)"
            self._log_tool_event("Invoking LLM for Figma file summary.")

            if not getattr(self, "llm", None):
                raise RuntimeError("LLM is not configured for this toolkit; cannot apply summary_prompt.")

            # Use the 'prompt' field from the summary_prompt dict as the instruction block
            summary_prompt_text = summary_prompt["prompt"].strip()
            prompt_text = f"{summary_prompt_text}\n\nCONTENT BEGIN\n{full_content}\nCONTENT END"
            llm_response = self.llm.invoke(prompt_text) if hasattr(self.llm, "invoke") else self.llm(prompt_text)

            if hasattr(llm_response, "content"):
                summary_text = str(llm_response.content)
            else:
                summary_text = str(llm_response)

            self._log_tool_event("Successfully generated LLM-based file summary.")
            return summary_text
        except Exception as e:
            logging.warning(f"Failed to apply summary_prompt in get_file_summary: {e}")
            self._log_tool_event("Falling back to raw documents due to summary_prompt failure.")
            return results
```
