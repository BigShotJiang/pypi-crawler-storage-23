# carrier - update_ui_test

**Toolkit**: `carrier`
**Method**: `update_ui_test`
**Source File**: `carrier_sdk.py`
**Class**: `CarrierClient`

---

## Method Implementation

```python
    def update_ui_test(self, test_id: str, json_body) -> Dict[str, Any]:
        """Update UI test configuration and schedule."""
        endpoint = f"api/v1/ui_performance/test/{self.credentials.project_id}/{test_id}"
        return self.request('put', endpoint, json=json_body)
```

## Helper Methods

```python
Helper: request
    def request(self, method: str, endpoint: str, **kwargs) -> Any:
        full_url = f"{self.credentials.url.rstrip('/')}/{endpoint.lstrip('/')}"
        response = self.session.request(method, full_url, **kwargs)
        try:
            response.raise_for_status()  # This will raise for 4xx/5xx
        except requests.HTTPError as http_err:
            # Log or parse potential HTML in response.text
            logger.error(f"HTTP {response.status_code} error: {response.text[:500]}")  # short snippet
            raise CarrierAPIError(f"Request to {full_url} failed with status {response.status_code}")

        # If the response is JSON, parse it. If it’s HTML or something else, handle gracefully
        try:
            return response.json()
        except json.JSONDecodeError:
            # Possibly HTML error or unexpected format
            logger.error(f"Response was not valid JSON. Body:\n{response.text[:500]}")
            raise CarrierAPIError("Server returned non-JSON response")
```
