# figma - analyze_file_with_llm

**Toolkit**: `figma`
**Method**: `analyze_file_with_llm`
**Source File**: `toon_tools.py`

---

## Method Implementation

```python
def analyze_file_with_llm(
    file_data: Dict,
    llm: Any,
    max_screens: int = 10,
) -> Optional[DesignAnalysis]:
    """
    Analyze entire Figma file using LLM with structured output.

    Args:
        file_data: Processed file data dict with pages and frames
        llm: LangChain LLM instance with structured output support
        max_screens: Maximum screens to include in analysis (for token limits)

    Returns:
        DesignAnalysis model or None if analysis fails
    """
    if not llm:
        return None

    try:
        # Serialize file to TOON format
        serializer = TOONSerializer()
        toon_output = serializer.serialize_file(file_data)

        # Truncate if too long (rough token estimate: 4 chars per token)
        max_chars = 8000  # ~2000 tokens for input
        if len(toon_output) > max_chars:
            toon_output = toon_output[:max_chars] + "\n... (truncated)"

        # Build prompt
        prompt = FILE_ANALYSIS_PROMPT.format(toon_data=toon_output)

        # Call LLM with structured output
        structured_llm = llm.with_structured_output(DesignAnalysis)
        result = structured_llm.invoke(prompt)

        return result

    except Exception as e:
        logging.warning(f"LLM file analysis failed: {e}")
        return None
```
