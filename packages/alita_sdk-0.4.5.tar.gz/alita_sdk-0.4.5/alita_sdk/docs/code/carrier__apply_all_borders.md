# carrier - apply_all_borders

**Toolkit**: `carrier`
**Method**: `apply_all_borders`
**Source File**: `lighthouse_excel_reporter.py`

---

## Method Implementation

```python
def apply_all_borders(ws):
    thin_border = Border(left=Side(style='thin'), 
                         right=Side(style='thin'), 
                         top=Side(style='thin'), 
                         bottom=Side(style='thin'))
    for row in ws.iter_rows(min_row=2, min_col=2, max_col=ws.max_column, max_row=ws.max_row):
        for cell in row:
            cell.border = thin_border
```
