# bitbucket - list_branches_in_repo

**Toolkit**: `bitbucket`
**Method**: `list_branches_in_repo`
**Source File**: `api_wrapper.py`
**Class**: `BitbucketAPIWrapper`

---

## Method Implementation

```python
    def list_branches_in_repo(self, limit: Optional[int] = 20, branch_wildcard: Optional[str] = None) -> List[str]:
        """
        Lists branches in the repository with optional limit and wildcard filtering.

        Parameters:
            limit (Optional[int]): Maximum number of branches to return
            branch_wildcard (Optional[str]): Wildcard pattern to filter branches (e.g., '*dev')

        Returns:
            List[str]: List containing names of branches
        """
        try:
            branches = self._bitbucket.list_branches()

            if branch_wildcard:
                branches = [branch for branch in branches if fnmatch.fnmatch(branch, branch_wildcard)]

            if limit is not None:
                branches = branches[:limit]

            return "Found branches: " + ", ".join(branches)
        except Exception as e:
            return f"Failed to list branches: {str(e)}"
```
