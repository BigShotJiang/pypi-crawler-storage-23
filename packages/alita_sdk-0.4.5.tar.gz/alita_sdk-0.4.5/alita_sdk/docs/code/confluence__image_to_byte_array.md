# confluence - image_to_byte_array

**Toolkit**: `confluence`
**Method**: `image_to_byte_array`
**Source File**: `utils.py`

---

## Method Implementation

```python
def image_to_byte_array(image: Image) -> bytes:
    raw_bytes = io.BytesIO()
    image.save(raw_bytes, format='PNG')
    return raw_bytes.getvalue()
```
