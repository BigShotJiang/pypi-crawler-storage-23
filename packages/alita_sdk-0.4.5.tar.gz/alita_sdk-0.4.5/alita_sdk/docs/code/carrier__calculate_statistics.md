# carrier - calculate_statistics

**Toolkit**: `carrier`
**Method**: `calculate_statistics`
**Source File**: `excel_reporter.py`
**Class**: `GatlingReportParser`

---

## Method Implementation

```python
    def calculate_statistics(response_times):
        min_time = round(min(response_times), 3)
        avg_time = round(np.mean(response_times), 3)
        p50_time = round(np.percentile(response_times, 50), 3)  # Median
        p90_time = round(np.percentile(response_times, 90), 3)
        p95_time = round(np.percentile(response_times, 95), 3)
        max_time = round(max(response_times), 3)
        return min_time, avg_time, p50_time, p90_time, p95_time, max_time
```
