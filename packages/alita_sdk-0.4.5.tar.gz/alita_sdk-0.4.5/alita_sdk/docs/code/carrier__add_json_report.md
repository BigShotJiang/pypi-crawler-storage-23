# carrier - add_json_report

**Toolkit**: `carrier`
**Method**: `add_json_report`
**Source File**: `create_ui_excel_report_tool.py`
**Class**: `LighthouseExcelReporter`

---

## Method Implementation

```python
    def add_json_report(self, json_content, worksheet_name):
        """Add a JSON report as a new worksheet."""
        try:
            # Parse JSON content
            if isinstance(json_content, str):
                data = json.loads(json_content)
            else:
                data = json_content
            
            # Process Lighthouse data similar to the reference file
            data_rows = self._process_lighthouse_data(data)
            
            if not data_rows:
                logger.warning(f"No data extracted from JSON for worksheet {worksheet_name}")
                return
            
            # Create DataFrame
            df = self.pd.DataFrame(data_rows)
            
            if df.empty:
                logger.warning(f"Empty DataFrame for worksheet {worksheet_name}")
                return
            
            # Create pivot table
            df_pivot = df.pivot_table(index="Step name", columns="Audit", values="Numeric Value", aggfunc='mean')
            df_pivot = df_pivot.fillna('')
            
            # Add worksheet
            ws = self.workbook.create_sheet(title=worksheet_name)
            
            # Write data to worksheet
            self._write_dataframe_to_worksheet(df_pivot, ws)
            
            # Apply formatting
            self._apply_formatting(ws, df_pivot)
            
            logger.info(f"Added worksheet: {worksheet_name}")
            
        except Exception as e:
            logger.error(f"Error processing JSON report for worksheet {worksheet_name}: {e}")
```
