# carrier - calculate_single_metric

**Toolkit**: `carrier`
**Method**: `calculate_single_metric`
**Source File**: `excel_reporter.py`
**Class**: `GatlingReportParser`

---

## Method Implementation

```python
    def calculate_single_metric(self, name, entries):
        response_times = [d[0] for d in entries]
        ko_count = len([d for d in entries if d[1] != 'OK'])
        total_count = len(entries)
        ko_percentage = round((ko_count / total_count), 4) if total_count > 0 else 0

        if response_times:
            min_time, avg_time, p50_time, p90_time, p95_time, max_time = self.calculate_statistics(response_times)
        else:
            min_time = avg_time = p50_time = p90_time = p95_time = max_time = 0

        return {
            "request_name": name,
            "Total": total_count,
            "KO": ko_count,
            "Error%": ko_percentage,
            "min": min_time,
            "average": avg_time,
            "90Pct": p90_time,
            "95Pct": p95_time,
            "max": max_time
        }
```

## Helper Methods

```python
Helper: calculate_statistics
    def calculate_statistics(self, df, req_name):
        df = df.sort_values(by=['timeStamp'])
        total_error_count = len(df.loc[df['success'] != True])
        total_request = df['elapsed'].size
        ok_req = total_request - total_error_count
        summary = {
            'request_name': req_name,
            'min': round(float(df['elapsed'].min()), 3),
            'max': round(float(df['elapsed'].max()), 3),
            'Total': total_request,
            'average': round(float(df['elapsed'].mean()), 3),
            'median': round(float(df['elapsed'].median()), 3),
            '90Pct': round(df['elapsed'].quantile(0.9), 3),
            '95Pct': round(df['elapsed'].quantile(0.95), 3),
            'KO': total_error_count,
            'OK': ok_req,
            'Error%': round(total_error_count / total_request, 4)
        }
        if req_name == 'Total':
            end_test = df.timeStamp.iloc[-1]
            start_test = df.timeStamp.iloc[0]

            try:
                duration = pd.to_timedelta(end_test - start_test, unit='ms')
            except TypeError as ex:
                print(ex)
                end_test = self.convert_time(end_test)
                start_test = self.convert_time(start_test)
                duration = pd.to_timedelta(end_test - start_test, unit='ms')
            throughput = round(ok_req / duration.seconds, 2)
            duration_ = str(duration).split('days')[1].split('.')[0]
            ramp_up_end = df.loc[df['allThreads'] == df.allThreads.max()].timeStamp.min()
            ramp_up = str(pd.to_timedelta(ramp_up_end - df.timeStamp.iloc[0], unit='ms')).split('days')[1].split('.')[0]
            summary['duration'] = duration_
            summary['ramp_up_period'] = ramp_up
            summary['throughput'] = throughput
            summary['error_rate'] = round(total_error_count / total_request, 4) * 100
            unique_thread_arr = df.threadName.unique()
            filter_unique_thread_arr = list(filter(lambda x: not x.startswith('parallel'), unique_thread_arr))
            summary['max_user_count'] = len(filter_unique_thread_arr)
            summary['date_start'] = datetime.fromtimestamp(int(start_test / 1000)).strftime(
                '%Y-%m-%d %H:%M:%S')
            summary['date_end'] = datetime.fromtimestamp(int(end_test / 1000)).strftime(
                '%Y-%m-%d %H:%M:%S')
        # else: why do we need it ?
        #     summary['total_response_time'] = list(df.elapsed)
        return summary
```
