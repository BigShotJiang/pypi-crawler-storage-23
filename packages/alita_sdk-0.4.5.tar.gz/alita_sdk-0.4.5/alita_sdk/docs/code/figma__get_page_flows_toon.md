# figma - get_page_flows_toon

**Toolkit**: `figma`
**Method**: `get_page_flows_toon`
**Source File**: `api_wrapper.py`
**Class**: `FigmaApiWrapper`

---

## Method Implementation

```python
    def get_page_flows_toon(
        self,
        url: Optional[str] = None,
        file_key: Optional[str] = None,
        page_id: Optional[str] = None,
        **kwargs,
    ) -> str:
        """
        Analyze a single page for user flows in TOON format.

        Returns detailed flow analysis:
        - Frame sequence detection (from naming: 01_, Step 1, etc.)
        - Screen variant grouping (Login, Login_Error, Login_Loading)
        - CTA/button destination mapping
        - Spatial ordering hints

        Use this for in-depth flow analysis of a specific page.
        Requires a PAGE ID (not a frame ID). Use get_file_structure_toon to find page IDs.
        """
        self._log_tool_event("Analyzing page flows in TOON format")

        # Parse URL
        if url:
            file_key, node_ids_from_url = self._parse_figma_url(url)
            if node_ids_from_url:
                page_id = node_ids_from_url[0]

        if not file_key:
            raise ToolException("Either url or file_key must be provided")
        if not page_id:
            raise ToolException("page_id must be provided (or include node-id in URL)")

        # Fetch node content
        self._log_tool_event(f"Fetching node {page_id} from file {file_key}")
        node_full = self._get_file_nodes(file_key, page_id)

        if not node_full:
            raise ToolException(f"Failed to retrieve node {page_id}")

        node_content = node_full.get('nodes', {}).get(page_id, {}).get('document', {})
        if not node_content:
            raise ToolException(f"Node {page_id} has no content")

        # Check if this is a page (CANVAS) or a frame
        node_type = node_content.get('type', '').upper()
        if node_type != 'CANVAS':
            # This is a frame, not a page - provide helpful error
            raise ToolException(
                f"Node {page_id} is a {node_type}, not a PAGE. "
                f"This tool requires a page ID. Use get_file_structure_toon first to find page IDs "
                f"(look for PAGE: ... #<page_id>)"
            )

        page_content = node_content

        # Process page
        page_data = process_page_to_toon_data(page_content)
        frames = page_data.get('frames', [])

        # Build detailed flow analysis
        lines = []
        lines.append(f"PAGE: {page_data.get('name', 'Untitled')} [id:{page_id}]")
        lines.append(f"  frames: {len(frames)}")
        lines.append("")

        # Sequence analysis
        sequences = detect_sequences(frames)
        if sequences:
            lines.append("SEQUENCES (by naming):")
            for seq in sequences:
                lines.append(f"  {' > '.join(seq)}")
            lines.append("")

        # Variant analysis
        variants = group_variants(frames)
        if variants:
            lines.append("VARIANTS (grouped screens):")
            for base, variant_list in variants.items():
                lines.append(f"  {base}:")
                for v in variant_list:
                    v_name = v.get('name', '')
                    v_id = v.get('id', '')
                    state = next((f.get('state', 'default') for f in frames if f.get('name') == v_name), 'default')
                    lines.append(f"    - {v_name} [{state}] #{v_id}")
            lines.append("")

        # CTA mapping
        lines.append("CTA DESTINATIONS:")
        cta_map = {}
        for frame in frames:
            frame_name = frame.get('name', '')
            for btn in frame.get('buttons', []):
                dest = infer_cta_destination(btn)
                if dest not in cta_map:
                    cta_map[dest] = []
                cta_map[dest].append(f'"{btn}" in {frame_name}')

        for dest, ctas in cta_map.items():
            lines.append(f"  > {dest}:")
            for cta in ctas[:5]:  # Limit per destination
                lines.append(f"      {cta}")
        lines.append("")

        # Spatial ordering
        lines.append("SPATIAL ORDER (canvas position):")
        sorted_frames = sorted(frames, key=lambda f: (f['position']['y'], f['position']['x']))
        for i, frame in enumerate(sorted_frames[:20], 1):
            pos = frame.get('position', {})
            lines.append(f"  {i}. {frame.get('name', '')} [{int(pos.get('x', 0))},{int(pos.get('y', 0))}]")

        # Frame details
        lines.append("")
        lines.append("FRAME DETAILS:")

        serializer = TOONSerializer()
        for frame in frames[:30]:  # Limit frames
            frame_lines = serializer.serialize_frame(frame, level=1)
            lines.extend(frame_lines)

        self._log_tool_event("Page flow analysis complete")
        return '\n'.join(lines)
```
