# advanced_jira_mining - prepare_data

**Toolkit**: `advanced_jira_mining`
**Method**: `prepare_data`
**Source File**: `data_mining_wrapper.py`
**Class**: `AdvancedJiraMiningWrapper`

---

## Method Implementation

```python
    def prepare_data(self, jira_issue_key: str) -> str:
        """ Prepare the embeddings for the specific jira issue key. They will include both Jira and Confluence info. """
        path, _ = self.__prepare_vectorstore(jira_issue_key)
        zip_file_name = f'jira_ticket_embeddings_{jira_issue_key}.zip'
        if self.__get_attachment_id(jira_issue_key, zip_file_name) is not None:
            self.__download_attachment_by_id(jira_issue_key, zip_file_name)
            return f"The vectorstore content have been obtained from Jira ticket - {jira_issue_key}. You can use it from the path - {path}"
        elif not os.path.exists(path):
            initial_confluence_docs = self.__get_confluence_documents_by_jira_ticket(jira_issue_key)
            result_confluence_docs = self.__split_the_confluence_documents(initial_confluence_docs)
            related_description_list = self.__create_ac_documents_content(jira_issue_key)
            _, vectorstore = self.__prepare_vectorstore(jira_issue_key, obtain_vectorstore=True)
            if result_confluence_docs:
                vectorstore.add_documents(result_confluence_docs)
            vectorstore.add_documents(related_description_list)
            vectorstore.persist()
            self.__zip_directory(path, zip_file_name)
            self.__attach_file_to_jira_issue(jira_issue_key, zip_file_name)
            os.remove(zip_file_name)
            return f'Successfully created embeddings for the jira ticket with following id - {jira_issue_key}'
        else:
            pass
```
