# figma - detect_user_journeys

**Toolkit**: `figma`
**Method**: `detect_user_journeys`
**Source File**: `toon_tools.py`

---

## Method Implementation

```python
def detect_user_journeys(frames: List[Dict]) -> Dict[str, List[Dict]]:
    """
    Detect user journeys by analyzing frame names and button actions.

    Returns dict of journeys with frames in order:
    {
        'authentication': [
            {'name': 'Login', 'id': '1:100', 'actions': ['authenticate', 'reset']},
            {'name': 'Forgot Password', 'id': '1:101', 'actions': ['submit_form']},
        ],
        ...
    }
    """
    journeys = {}

    for frame in frames:
        name = frame.get('name', '')
        buttons = frame.get('buttons', [])
        frame_id = frame.get('id', '')

        # Get button destinations
        actions = []
        for btn in buttons:
            btn_text = btn if isinstance(btn, str) else btn.get('text', '')
            if btn_text:
                dest = infer_cta_destination(btn_text, frame_context=name)
                if dest and not dest.startswith('do:'):
                    actions.append(dest)

        # Determine journey category
        category = infer_journey_category(name, buttons)

        if category:
            if category not in journeys:
                journeys[category] = []
            journeys[category].append({
                'name': name,
                'id': frame_id,
                'actions': list(set(actions)),  # Dedupe actions
                'state': infer_state_from_name(name),
            })

    return journeys
```

## Helper Methods

```python
Helper: infer_journey_category
def infer_journey_category(frame_name: str, buttons: List[str]) -> Optional[str]:
    """
    Infer which user journey a frame belongs to.
    """
    name_lower = frame_name.lower()
    buttons_lower = [b.lower() for b in buttons]
    all_text = name_lower + ' ' + ' '.join(buttons_lower)

    for category, keywords in JOURNEY_CATEGORIES.items():
        if any(kw in all_text for kw in keywords):
            return category
    return None
```
