# elastic - get_available_tools

**Toolkit**: `elastic`
**Method**: `get_available_tools`
**Source File**: `api_wrapper.py`
**Class**: `ELITEAElasticApiWrapper`

---

## Method Implementation

```python
    def get_available_tools(self):
        return [
            {
                "name": "search_elastic_index",
                "ref": self.search_elastic_index,
                "description": self.search_elastic_index.__doc__,
                "args_schema": create_model(
                    "SearchElasticIndexModel",
                    index=(str, Field(description="Name of the Elastic index to apply the query")),
                    query=(str, Field(description="Query to Elastic API in the form of a Query DSL"))
                ),
            }
        ]
```
