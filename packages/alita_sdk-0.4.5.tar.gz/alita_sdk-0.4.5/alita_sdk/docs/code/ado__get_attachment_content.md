# ado - get_attachment_content

**Toolkit**: `ado`
**Method**: `get_attachment_content`
**Source File**: `ado_wrapper.py`
**Class**: `AzureDevOpsApiWrapper`

---

## Method Implementation

```python
    def get_attachment_content(self, attachment_id):
        content_generator = self._client.get_attachment_content(id=attachment_id, download=True)
        return b"".join(content_generator)
```
