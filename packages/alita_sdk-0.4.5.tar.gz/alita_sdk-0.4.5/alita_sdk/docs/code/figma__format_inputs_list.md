# figma - format_inputs_list

**Toolkit**: `figma`
**Method**: `format_inputs_list`
**Source File**: `toon_tools.py`

---

## Method Implementation

```python
def format_inputs_list(inputs: List[Dict], max_inputs: int = INPUT_FORMAT_MAX_INPUTS) -> str:
    """
    Format a list of input fields in standardized TOON format.

    Args:
        inputs: List of input dicts with keys: name, type, required, value, options, placeholder
        max_inputs: Maximum inputs to include

    Returns:
        Formatted string: "Input1 (type) | Input2* (type): value | ..."
    """
    if not inputs:
        return ''

    input_strs = []
    for inp in inputs[:max_inputs]:
        formatted = format_single_input(
            label=inp.get('name', inp.get('label', 'Input')),
            input_type=inp.get('type', inp.get('input_type', 'text')),
            required=inp.get('required', False),
            value=inp.get('value', inp.get('current_value')),
            options=inp.get('options'),
            placeholder=inp.get('placeholder'),
        )
        input_strs.append(formatted)

    return ' | '.join(input_strs)
```

## Helper Methods

```python
Helper: format_single_input
def format_single_input(
    label: str,
    input_type: str,
    required: bool = False,
    value: Optional[str] = None,
    options: Optional[List[str]] = None,
    placeholder: Optional[str] = None,
) -> str:
    """
    Format a single input field in standardized TOON format.

    Standard format: Label* (type): "value" or Label* (type): [Opt1/Opt2/...]

    Args:
        label: Input label/name
        input_type: Type (text, email, slider, select, etc.)
        required: Whether field is required (adds * marker)
        value: Current value shown
        options: Options for select/radio/slider types
        placeholder: Placeholder text (fallback if no value/options)

    Returns:
        Formatted input string
    """
    req_marker = '*' if required else ''
    base_str = f"{label}{req_marker} ({input_type})"

    # Priority: value > options > placeholder
    if value and len(str(value)) < INPUT_FORMAT_MAX_VALUE_LEN:
        base_str += f': "{value}"'
    elif options:
        opts_str = '/'.join(options[:INPUT_FORMAT_MAX_OPTIONS])
        base_str += f": [{opts_str}]"
    elif placeholder and len(str(placeholder)) < INPUT_FORMAT_MAX_VALUE_LEN:
        base_str += f': "{placeholder}"'

    return base_str
```
