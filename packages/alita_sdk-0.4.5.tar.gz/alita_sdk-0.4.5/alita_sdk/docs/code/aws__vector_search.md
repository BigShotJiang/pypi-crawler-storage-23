# aws - vector_search

**Toolkit**: `aws`
**Method**: `vector_search`
**Source File**: `api_wrapper.py`
**Class**: `DeltaLakeApiWrapper`

---

## Method Implementation

```python
    def vector_search(self, embedding: List[float], k: int = 5, embedding_column: str = "embedding") -> List[dict]:
        """
        Perform a vector similarity search on the Delta Lake table.
        Args:
            embedding: Query embedding vector.
            k: Number of top results to return.
            embedding_column: Name of the column containing embeddings.
        Returns:
            List of dicts for top k most similar rows.
        """
        import numpy as np

        dt = self.delta_table
        df = dt.to_pandas()
        if embedding_column not in df.columns:
            raise ToolException(f"Embedding column '{embedding_column}' not found in table.")

        # Filter out rows with missing embeddings
        df = df[df[embedding_column].notnull()]
        if df.empty:
            return []
        # Convert embeddings to numpy arrays
        emb_matrix = np.array(df[embedding_column].tolist())
        query_vec = np.array(embedding)

        # Normalize for cosine similarity
        emb_matrix_norm = emb_matrix / np.linalg.norm(emb_matrix, axis=1, keepdims=True)
        query_vec_norm = query_vec / np.linalg.norm(query_vec)
        similarities = np.dot(emb_matrix_norm, query_vec_norm)

        # Get top k indices
        top_k_idx = np.argsort(similarities)[-k:][::-1]
        top_rows = df.iloc[top_k_idx]
        return top_rows.to_dict(orient="records")
```
