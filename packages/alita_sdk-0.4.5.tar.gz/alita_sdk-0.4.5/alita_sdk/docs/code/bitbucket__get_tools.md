# bitbucket - get_tools

**Toolkit**: `bitbucket`
**Method**: `get_tools`
**Source File**: `__init__.py`
**Class**: `AlitaBitbucketToolkit`

---

## Method Implementation

```python
    def get_tools(self):
        return self.tools
```
