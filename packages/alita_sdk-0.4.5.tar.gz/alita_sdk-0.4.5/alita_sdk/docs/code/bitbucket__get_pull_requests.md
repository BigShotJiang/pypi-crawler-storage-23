# bitbucket - get_pull_requests

**Toolkit**: `bitbucket`
**Method**: `get_pull_requests`
**Source File**: `api_wrapper.py`
**Class**: `BitbucketAPIWrapper`

---

## Method Implementation

```python
    def get_pull_requests(self) -> List[Dict[str, Any]]:
        """
        Get pull requests from the repository
        Returns:
            List[Dict[str, Any]]: List of pull requests in the repository
        """
        return self._bitbucket.get_pull_requests()
```
