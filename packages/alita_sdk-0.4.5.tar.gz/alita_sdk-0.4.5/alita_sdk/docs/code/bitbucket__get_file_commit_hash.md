# bitbucket - get_file_commit_hash

**Toolkit**: `bitbucket`
**Method**: `get_file_commit_hash`
**Source File**: `cloud_api_wrapper.py`
**Class**: `BitbucketCloudApi`

---

## Method Implementation

```python
    def get_file_commit_hash(self, file_path: str, branch: str):
        """
        Get the commit hash of a file in a specific branch.
        Parameters:
            file_path (str): The path to the file.
            branch (str): The branch name.
        Returns:
            str: The commit hash of the file.
        """
        commits = self.repository.commits.get(path=file_path, branch=branch, pagelen=1)
        if commits['values']:
            return commits['values'][0]['hash']
        return None
```
