# carrier - auto_adjust_column_width

**Toolkit**: `carrier`
**Method**: `auto_adjust_column_width`
**Source File**: `lighthouse_excel_reporter.py`

---

## Method Implementation

```python
def auto_adjust_column_width(ws):
    for col in ws.columns:
        max_length = 0
        column = col[0].column_letter  # Get the column name
        for cell in col:
            try:
                if len(str(cell.value)) > max_length:
                    max_length = len(cell.value)
            except:
                pass
        adjusted_width = (max_length + 2)
        ws.column_dimensions[column].width = adjusted_width
```
