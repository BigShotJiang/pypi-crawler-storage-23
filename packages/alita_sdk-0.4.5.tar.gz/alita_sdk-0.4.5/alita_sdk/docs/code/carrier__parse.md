# carrier - parse

**Toolkit**: `carrier`
**Method**: `parse`
**Source File**: `excel_reporter.py`
**Class**: `GatlingReportParser`

---

## Method Implementation

```python
    def parse(self) -> Dict[str, Any]:
        latest_log_file = self.log_file
        print(f"Path: {latest_log_file}")
        groups, requests, users, date_start, date_end, ramp_up_period = self.parse_log_file(latest_log_file)

        # Combine requests and groups for reporting purposes
        requests = defaultdict(list, {**requests})
        duration = self.calculate_duration(date_start, date_end)

        transactions_data = {
            "requests": {
                transaction: self.calculate_single_metric(transaction, entries)
                for transaction, entries in requests.items()
            },
            "groups": {
                group: self.calculate_single_metric(group, entries)
                for group, entries in groups.items()
            }
        }
        # Calculate total requests only from the original requests dictionary
        total_requests = self.calculate_all_requests(requests)
        transactions_data["requests"]["Total Requests"] = total_requests

        throughput = total_requests['Total'] / (duration * 60)  # Initializing a variable with the default value

        if duration > 1:
            duration = round(duration)
        if ramp_up_period > 1:
            ramp_up_period = round(ramp_up_period, 1)
            throughput = total_requests['Total'] / (duration * 60)
        if throughput > 1:
            throughput = round(throughput, 1)

        # Add any additional required summary metrics
        # Convert to Eastern Time (EST/EDT)
        from pytz import timezone
        eastern = timezone('US/Eastern')
        date_start = date_start.astimezone(eastern) if date_start else None
        date_end = date_end.astimezone(eastern) if date_end else None

        transactions_data.update({
            'max_user_count': users,
            'ramp_up_period': ramp_up_period,
            'error_rate': total_requests['Error%'],
            'date_start': date_start.strftime('%Y-%m-%d %H:%M:%S') if date_start else None,
            'date_end': date_end.strftime('%Y-%m-%d %H:%M:%S') if date_end else None,
            'throughput': throughput,
            'duration': duration,
            'think_time': self.calculated_think_time
        })
        return transactions_data
```

## Helper Methods

```python
Helper: calculate_single_metric
    def calculate_single_metric(self, name, entries):
        response_times = [d[0] for d in entries]
        ko_count = len([d for d in entries if d[1] != 'OK'])
        total_count = len(entries)
        ko_percentage = round((ko_count / total_count), 4) if total_count > 0 else 0

        if response_times:
            min_time, avg_time, p50_time, p90_time, p95_time, max_time = self.calculate_statistics(response_times)
        else:
            min_time = avg_time = p50_time = p90_time = p95_time = max_time = 0

        return {
            "request_name": name,
            "Total": total_count,
            "KO": ko_count,
            "Error%": ko_percentage,
            "min": min_time,
            "average": avg_time,
            "90Pct": p90_time,
            "95Pct": p95_time,
            "max": max_time
        }
```
