# azure_ai - check_connection

**Toolkit**: `azure_ai`
**Method**: `check_connection`
**Source File**: `__init__.py`
**Class**: `AzureSearchToolkit`

---

## Method Implementation

```python
        def check_connection(self):
            response = requests.get(f"{self.api_base}/openai/deployments", headers={
                "api-key": self.api_key
            })
            return response
```
