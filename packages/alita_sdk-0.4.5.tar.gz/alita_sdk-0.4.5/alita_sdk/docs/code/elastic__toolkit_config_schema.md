# elastic - toolkit_config_schema

**Toolkit**: `elastic`
**Method**: `toolkit_config_schema`
**Source File**: `__init__.py`
**Class**: `ElasticToolkit`

---

## Method Implementation

```python
    def toolkit_config_schema() -> BaseModel:
        selected_tools = {x['name']: x['args_schema'].schema() for x in ELITEAElasticApiWrapper.model_construct().get_available_tools()}
        return create_model(
            name,
            url=(Optional[str], Field(default=None, title="Elasticsearch URL", description="Elasticsearch URL", json_schema_extra={'toolkit_name': True})),
            api_key=(
                Optional[SecretStr],
                Field(
                    default=None,
                    title="Cluster URL",
                    description="API Key for Elasticsearch",
                    json_schema_extra={'secret': True}
                    )
                ),
            selected_tools=(List[Literal[tuple(selected_tools)]], Field(default=[], json_schema_extra={'args_schemas': selected_tools})),
            __config__=ConfigDict(json_schema_extra={'metadata': {"label": "Elasticsearch", "icon_url": None, "hidden": True}})
        )
```
