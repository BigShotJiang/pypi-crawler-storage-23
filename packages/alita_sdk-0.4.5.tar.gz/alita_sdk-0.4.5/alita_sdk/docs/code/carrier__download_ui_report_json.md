# carrier - download_ui_report_json

**Toolkit**: `carrier`
**Method**: `download_ui_report_json`
**Source File**: `api_wrapper.py`
**Class**: `CarrierAPIWrapper`

---

## Method Implementation

```python
    def download_ui_report_json(self, bucket: str, file_name: str) -> str:
        """Download UI report JSON file content."""
        endpoint = f"api/v1/artifacts/artifact/default/{self.project_id}/{bucket}/{file_name}"
        try:
            response = self._client.request('get', endpoint)
            return response
        except Exception as e:
            logger.error(f"Failed to download UI report JSON: {e}")
            return None
```
