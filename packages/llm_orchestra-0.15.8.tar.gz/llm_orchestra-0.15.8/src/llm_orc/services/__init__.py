"""Shared services for llm-orc application."""
