# tensorxx

https://packaging.python.org/en/latest/tutorials/packaging-projects/

Install Python:
```sh
apt install python3 python3-full python3-pip python3-venv
# apt install python3.8
python3 --version
```

Create virtual environment:
```sh
python3 -m venv .venv
. .venv/bin/activate
# pip install -r requirements.txt
```

---

Create pyproject.toml file with configuration metadata.

---

```sh
python -m pip install -U pip
python -m pip install -U build
python -m pip install -U twine
```

Generating distribution archives:
```sh
python -m build
```
- `.tar.gz` - source distribution
- `.whl` - built distribution

---

```sh
python -m pip install -U twine
python -m twine check dist/*
```

```sh
python3 -m twine upload dist/*
```

