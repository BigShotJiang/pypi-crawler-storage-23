from tensorxx import tensor

tensor()
