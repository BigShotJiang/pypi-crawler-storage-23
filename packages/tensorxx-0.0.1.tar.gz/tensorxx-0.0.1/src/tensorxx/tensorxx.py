def tensor():
    print("Hello, Tensor-library!")
