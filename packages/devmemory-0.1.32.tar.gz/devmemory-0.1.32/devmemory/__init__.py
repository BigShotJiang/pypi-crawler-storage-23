__version__ = "0.1.32"
__app_name__ = "devmemory"
