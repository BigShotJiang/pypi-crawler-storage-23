"""Fix bash history to share between terminals, search by prefix, and keep history forever."""

__version__ = "1.0.0"
