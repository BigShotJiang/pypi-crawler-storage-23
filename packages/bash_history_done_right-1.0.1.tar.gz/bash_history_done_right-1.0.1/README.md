# bash-history-done-right

Python package to implement https://abarry.org/bash-history-finally-done-right/

Fixes bash history to:
- Share history across terminals (union of all terminals' history in a new terminal)
- Keep each terminal's own history while it is open
- Search history by prefix with up/down arrow keys
- Keep all history forever in `~/.bash_eternal_history`

## Install

```bash
pip install bash-history-done-right
```

That's it. Your `~/.bashrc` is patched automatically (a backup is saved to `~/.bashrc.bak`). Open a new terminal to use it.

## Uninstall

```bash
bash-history-done-right uninstall
pip uninstall bash-history-done-right
```

## Re-install / customize

```bash
# Re-install (e.g. after editing .bashrc)
bash-history-done-right install

# Install without arrow-key prefix search
bash-history-done-right install --no-arrow-search

# Install without eternal history file
bash-history-done-right install --no-eternal-history
```

## Publishing to PyPI

Only upload the sdist (no wheel) so that `setup.py` runs on the user's machine:

```bash
python -m build --sdist
twine upload dist/*
```
