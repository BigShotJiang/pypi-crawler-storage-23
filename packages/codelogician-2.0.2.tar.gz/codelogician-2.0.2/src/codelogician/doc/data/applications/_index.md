----
title: Applications
description: Examples and tutorials for application of ImandraX to financial markets.
order: 5
----
