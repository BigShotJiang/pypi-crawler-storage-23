----
title: XState example - Patient Monitoring
description: XState Patient Monitoring example and IML model
order: 1
----