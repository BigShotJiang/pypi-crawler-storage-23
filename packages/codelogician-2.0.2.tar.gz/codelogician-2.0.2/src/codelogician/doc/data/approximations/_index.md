----
title: Approximations
description: A collection of approximations to difficult-to-reason about functions (e.g. `cos`)
order: 6
----