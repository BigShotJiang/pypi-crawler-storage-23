import asyncio
import logging
import sys
from typing import List, Dict
from urllib.parse import urlparse
from mcp.server.fastmcp import FastMCP
# 导入你现有的组件
from .config import BrowserConfig, CrawlConfig
from .crawler import AsyncMinimalCrawler

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s"
)
logger = logging.getLogger("CrawlerMCP")
import subprocess
from pathlib import Path


def ensure_playwright_browsers():
    """
    通用检测并自动安装浏览器环境：
    - 在安装失败时打印详细的 stderr 日志以供排查
    """

    # 1. 自动适配路径
    if sys.platform == "win32":
        base_path = Path.home() / "AppData" / "Local" / "ms-playwright"
        browser_type = "chromium"
    elif sys.platform == "darwin":
        base_path = Path.home() / "Library" / "Caches" / "ms-playwright"
        browser_type = "chromium"
    else:
        base_path = Path.home() / ".cache" / "ms-playwright"
        browser_type = "chromium-headless-shell"

    # 2. 检查逻辑
    has_browser = any(base_path.glob(f"{browser_type.replace('-', '_')}-*")) if base_path.exists() else False

    if not has_browser:
        logger.info(f"Browser {browser_type} not found. Starting one-time setup...")
        try:
            # 安装浏览器
            logger.info(f"Installing {browser_type}...")
            subprocess.run(
                [sys.executable, "-m", "playwright", "install", browser_type],
                check=True,
                capture_output=True,
                text=True  # 确保输出是字符串
            )

            # 安装依赖
            if sys.platform.startswith("linux"):
                logger.info("Updating package lists and installing dependencies...")
                # 1. 先执行系统更新，解决 'Unable to locate package' 问题
                subprocess.run(["apt-get", "update"], check=True, capture_output=True)

                try:
                    # 首先尝试 Playwright 官方 install-deps
                    logger.info("Trying playwright install-deps...")
                    subprocess.run(
                        [sys.executable, "-m", "playwright", "install-deps", browser_type],
                        check=True,
                        capture_output=True,
                        text=True
                    )
                except subprocess.CalledProcessError as dep_err:
                    # Playwright install-deps 在 Debian bookworm 上会因 t64 包名失败
                    # 回退到手动安装 bookworm 兼容包
                    logger.warning(
                        f"playwright install-deps failed (likely t64 package name mismatch): {dep_err.stderr[:300]}"
                    )
                    logger.info("Falling back to manual dependency installation for Debian bookworm...")

                    # chromium-headless-shell 在 bookworm 上的实际依赖
                    bookworm_deps = [
                        "libasound2",  # bookworm 名，trixie 改为 libasound2t64
                        "libatk-bridge2.0-0",  # bookworm 名，trixie 改为 libatk-bridge2.0-0t64
                        "libatk1.0-0",
                        "libatspi2.0-0",
                        "libcups2",
                        "libdbus-1-3",
                        "libdrm2",
                        "libgbm1",
                        "libglib2.0-0",
                        "libnss3",
                        "libx11-6",
                        "libxcb1",
                        "libxcomposite1",
                        "libxdamage1",
                        "libxext6",
                        "libxfixes3",
                        "libxkbcommon0",
                        "libxrandr2",
                        "xvfb",  # 无头模式可能需要
                    ]

                    result = subprocess.run(
                        ["apt-get", "install", "-y", "--no-install-recommends"] + bookworm_deps,
                        capture_output=True,
                        text=True
                    )
                    if result.returncode != 0:
                        # 部分包找不到时不 check=True，记录日志但继续
                        logger.warning(f"Some deps may not have installed: {result.stderr[:300]}")
                    else:
                        logger.info("Fallback dependencies installed successfully.")

            logger.info(f"Playwright {browser_type} environment is now ready.")

        except subprocess.CalledProcessError as e:
            # 关键：显式打印出 stderr，你会在这里看到真正的报错原因
            logger.error(f"Playwright setup failed with exit code {e.returncode}")
            logger.error(f"STDOUT: {e.stdout}")
            logger.error(f"STDERR: {e.stderr}")  # 这里会显示比如 "Need root privilege" 等信息
            return
        except Exception as e:
            logger.error(f"An unexpected error occurred: {e}")
            return
    else:
        logger.info(f"Found existing {browser_type} environment.")


# 在初始化之前调用
ensure_playwright_browsers()

# 初始化 FastMCP
mcp = FastMCP("WebCrawlerService")


def is_valid_url(url: str) -> bool:
    """简单校验是否为合法的 HTTP/HTTPS 网页链接"""
    try:
        result = urlparse(url)
        return all([result.scheme in ["http", "https"], result.netloc])
    except:
        return False


@mcp.tool()
async def crawl_urls(urls: List[str]) -> Dict[str, str]:
    """
    抓取指定 URL 列表的内容并返回 Markdown 格式文本。

    Args:
        urls: 需要爬取的 URL 字符串列表。
    Returns:
        Dict: 键为 URL，值为页面内容或错误提示。
    """
    # 1. 过滤非法 URL
    valid_urls = []
    results_map = {}

    for url in urls:
        if is_valid_url(url):
            valid_urls.append(url)
        else:
            results_map[url] = "thi url is not a website"

    if not valid_urls:
        return results_map

    # 2. 初始化爬虫 (针对 2核4G 强制开启 headless)
    # 建议此处保持 headless=True 以节省内存
    crawler = AsyncMinimalCrawler(BrowserConfig(headless=True))

    try:
        logger.info(f"Start crawling  {len(valid_urls)} urls...")

        # 3. 调用你现有的 arun_many 方法
        crawl_results = await crawler.arun_many(
            valid_urls,
            config=CrawlConfig()
        )

        # 4. 解析结果
        for r in crawl_results:
            if r.error:
                results_map[r.url] = f"Crawl failed: {r.error}"
            else:
                # 优先返回 markdown，如果没有则返回 content
                results_map[r.url] = r.markdown if r.markdown else "empty page"
            logger.info(r.url)
            logger.info(r.markdown)
            logger.info(len(r.markdown))

    except Exception as e:
        logger.error(f"Crawler error: {str(e)}")
        for url in valid_urls:
            if url not in results_map:
                results_map[url] = f"System error: {str(e)}"
    finally:
        # 极其重要：在 4G 内存机器上必须确保浏览器关闭
        # 如果你的 AsyncMinimalCrawler 没有自动 close，建议在这里显式处理
        pass

    return results_map


if __name__ == "__main__":
    # 使用 stdio 传输协议，方便与 Claude Desktop 等客户端集成
    mcp.run(transport="stdio")
