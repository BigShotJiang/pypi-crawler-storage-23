# referent
A python package for identifying a schema matching two disparate sets of data for column renaming/standardization or database migration
