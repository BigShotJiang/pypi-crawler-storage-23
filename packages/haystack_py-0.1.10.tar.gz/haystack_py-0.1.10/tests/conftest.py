"""Shared test fixtures for haystack-py."""
