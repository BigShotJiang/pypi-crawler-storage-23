from hs_py import __doc__


def test_package_importable() -> None:
    assert __doc__ is not None
