Encoding
========

Haystack wire format implementations for JSON, Zinc, Trio, and CSV encoding.

.. automodule:: hs_py.encoding
   :no-members:

JSON
----

Haystack JSON v3 and v4 encode/decode with optional pythonic mode.

.. automodule:: hs_py.encoding.json
   :members:

Zinc
----

Haystack Zinc text grid format encode/decode.

.. automodule:: hs_py.encoding.zinc
   :members:

Trio
----

Trio record format parser and encoder.

.. automodule:: hs_py.encoding.trio
   :members:

CSV
---

Lossy CSV grid export (encode-only).

.. automodule:: hs_py.encoding.csv
   :members:

Scanner
-------

Shared position-based Zinc value scanning helpers.

.. automodule:: hs_py.encoding.scanner
   :members:
