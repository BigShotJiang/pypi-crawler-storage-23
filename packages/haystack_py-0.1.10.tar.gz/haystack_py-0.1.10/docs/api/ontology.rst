Ontology
========

Full Project Haystack def model with taxonomy, normalization, and reflection.

.. automodule:: hs_py.ontology
   :no-members:

Defs
----

``Def`` and ``Lib`` frozen dataclasses for ontology definitions.

.. automodule:: hs_py.ontology.defs
   :members:

Namespace
---------

Namespace container with symbol resolution and lookup.

.. automodule:: hs_py.ontology.namespace
   :members:

Taxonomy
--------

Subtype tree, tag inheritance, and conjunct resolution.

.. automodule:: hs_py.ontology.taxonomy
   :members:

Normalize
---------

Normalization pipeline to compile raw defs into a resolved namespace.

.. automodule:: hs_py.ontology.normalize
   :members:

Reflect
-------

Dict-to-def reflection engine for runtime type inference.

.. automodule:: hs_py.ontology.reflect
   :members:
