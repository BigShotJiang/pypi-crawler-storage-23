"""Test suite for validate-aws-policies."""
