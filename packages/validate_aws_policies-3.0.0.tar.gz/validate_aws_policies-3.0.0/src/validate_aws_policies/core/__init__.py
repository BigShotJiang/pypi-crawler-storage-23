"""Core module for AWS policy validation.

This module contains core business logic including policy validation,
error handling, configuration management, and type definitions.
"""

__all__ = []
