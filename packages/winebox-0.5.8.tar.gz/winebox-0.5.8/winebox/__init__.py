"""WineBox - Wine Cellar Management Application."""

__version__ = "0.5.8"
