default_app_config = "%s.apps.DjangoProjectBaseLicensingConfig" % "django_project_base.licensing"
