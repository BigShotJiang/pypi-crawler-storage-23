from django.apps import AppConfig


class DemoDjangoBaseConfig(AppConfig):
    name = "example.demo_django_base"
