W0 = "w0"   # wrap_content
W1 = "w1"   # match_parent

H0 = "h0"   # wrap_content
H1 = "h1"   # match_parent

P0 = "p0"   # 0dp
P1 = "p1"   # 4dp
P2 = "p2"   # 8dp
P3 = "p3"   # 12dp
P4 = "p4"   # 16dp
P5 = "p5"   # 24dp
P6 = "p6"   # 32dp

M0 = "m0"   # 0dp
M1 = "m1"   # 4dp
M2 = "m2"   # 8dp
M3 = "m3"   # 12dp
M4 = "m4"   # 16dp
M5 = "m5"   # 24dp
M6 = "m6"   # 32dp