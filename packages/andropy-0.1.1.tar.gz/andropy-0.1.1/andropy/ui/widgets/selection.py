from andropy.ui.base import UiComponent


class UiCheckbox(UiComponent):
    """Maps to Android CheckBox."""
    _tag = "CheckBox"

    def __init__(self, text="", width=None, height=None,
                 padding=None, margin=None, checked=False,
                 center=False, center_horizontal=False, center_vertical=False):
        super().__init__(width=width, height=height, padding=padding, margin=margin,
                         center=center, center_horizontal=center_horizontal,
                         center_vertical=center_vertical)
        self.text = text
        self.checked = checked

    def _component_attrs(self) -> dict:
        return {
            "android:text": self.text,
            "android:checked": "true" if self.checked else "false",
        }


class UiSwitch(UiComponent):
    """Maps to Android Switch."""
    _tag = "Switch"

    def __init__(self, text="", width=None, height=None,
                 padding=None, margin=None, checked=False,
                 center=False, center_horizontal=False, center_vertical=False):
        super().__init__(width=width, height=height, padding=padding, margin=margin,
                         center=center, center_horizontal=center_horizontal,
                         center_vertical=center_vertical)
        self.text = text
        self.checked = checked

    def _component_attrs(self) -> dict:
        return {
            "android:text": self.text,
            "android:checked": "true" if self.checked else "false",
        }