import os
from pathlib import Path


def find_android_sdk() -> str | None:
    """Try to locate Android SDK path."""
    candidates = [
        Path.home() / "Android" / "Sdk",
        Path(os.environ.get("ANDROID_HOME", "")),
        Path(os.environ.get("ANDROID_SDK_ROOT", "")),
    ]
    for path in candidates:
        if path.exists():
            return str(path)
    return None