from andropy.core.setup import run_setup


def setup():
    """Setup Android SDK and required tools."""
    run_setup()
