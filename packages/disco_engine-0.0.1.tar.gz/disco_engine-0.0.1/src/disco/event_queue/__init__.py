from ._core import EventQueue

__all__ = ["EventQueue"]
