"""Tests for tikhub-xiaohongshu package"""
