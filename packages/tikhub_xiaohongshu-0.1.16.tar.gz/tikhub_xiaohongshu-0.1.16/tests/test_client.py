"""
TikHubClient 测试

覆盖核心功能：
1. search_notes_all - 搜索 + 自动翻页 + 详情获取
2. get_note_info - 详情获取（兜底机制）
3. get_notes - 数据提取（格式转换）
"""

import pytest
from unittest.mock import Mock, patch, MagicMock
from tikhub_xiaohongshu import TikHubClient, TikHubResponse, DataConverter


class TestTikHubResponse:
    """TikHubResponse 测试"""
    
    def test_get_notes_empty_data(self):
        """测试空数据情况"""
        response = TikHubResponse(
            code=200,
            message="OK",
            message_zh="成功",
            data=None
        )
        notes = response.get_notes()
        assert notes == []
    
    def test_get_notes_with_items(self):
        """测试正常提取笔记"""
        mock_data = {
            "data": {
                "items": [
                    {"model_type": "note", "note": {"id": "123", "title": "Test"}},
                    {"model_type": "note", "note": {"id": "456", "title": "Test2"}}
                ]
            }
        }
        response = TikHubResponse(
            code=200,
            message="OK",
            message_zh="成功",
            data=mock_data
        )
        notes = response.get_notes()
        assert len(notes) == 2
        assert notes[0]["id"] == "123"
        assert notes[1]["id"] == "456"
    
    def test_get_notes_convert_to_xhs(self):
        """测试转换为 xhs_review 格式"""
        mock_data = {
            "data": {
                "data": [{
                    "user": {"nickname": "Test User"},
                    "note_list": [{
                        "id": "123",
                        "title": "Test",
                        "desc": "Description",
                        "liked_count": 100,
                        "time": 1709568000000
                    }]
                }]
            }
        }
        response = TikHubResponse(
            code=200,
            message="OK",
            message_zh="成功",
            data=mock_data
        )
        notes = response.get_notes(convert_to_xhs=True)
        assert len(notes) == 1
        assert notes[0]["noteId"] == "123"
        assert notes[0]["userInfo"]["nickName"] == "Test User"
        assert notes[0]["likeCount"] == "100"
    
    def test_get_search_params(self):
        """测试获取翻页参数"""
        mock_data = {
            "data": {
                "search_id": "abc123",
                "search_session_id": "xyz789",
                "has_more": True
            }
        }
        response = TikHubResponse(
            code=200,
            message="OK",
            message_zh="成功",
            data=mock_data
        )
        params = response.get_search_params()
        assert params["search_id"] == "abc123"
        assert params["search_session_id"] == "xyz789"
        assert params["has_more"] == True


class TestDataConverter:
    """DataConverter 测试"""
    
    def test_convert_to_xhs_format(self):
        """测试数据转换为 xhs_review 格式"""
        raw_data = {
            "data": [{
                "user": {"id": "user123", "nickname": "Test User"},
                "note_list": [{
                    "id": "note123",
                    "title": "Test Title",
                    "desc": "Test Description",
                    "liked_count": 100,
                    "shared_count": 50,
                    "collected_count": 200,
                    "comments_count": 30,
                    "time": 1709568000000,
                    "images_list": [{"url": "http://example.com/img.jpg"}]
                }]
            }]
        }
        
        result = DataConverter.convert_to_xhs_format(raw_data, "note123")
        
        assert result["noteId"] == "note123"
        assert result["title"] == "Test Title"
        assert result["content"] == "Test Description"
        assert result["userInfo"]["userId"] == "user123"
        assert result["userInfo"]["nickName"] == "Test User"
        assert result["likeCount"] == "100"
        assert result["sharedCount"] == "50"
        assert result["collectCount"] == "200"
        assert result["commentCount"] == "30"
        assert len(result["images"]) == 1
    
    def test_convert_empty_data(self):
        """测试空数据转换"""
        result = DataConverter.convert_to_xhs_format({}, "note123")
        assert result == {}
    
    def test_convert_missing_note_list(self):
        """测试缺少 note_list 的情况"""
        raw_data = {"data": [{}]}
        result = DataConverter.convert_to_xhs_format(raw_data, "note123")
        assert result == {}


class TestTikHubClient:
    """TikHubClient 测试"""
    
    @pytest.fixture
    def client(self):
        """创建测试客户端"""
        return TikHubClient(api_key="test_key")
    
    @patch('tikhub_xiaohongshu.requests.Session')
    def test_search_notes(self, mock_session, client):
        """测试搜索笔记"""
        mock_response = Mock()
        mock_response.json.return_value = {
            "code": 200,
            "message": "OK",
            "message_zh": "成功",
            "data": {
                "items": [{"note": {"id": "123"}}]
            }
        }
        mock_session.return_value.request.return_value = mock_response
        
        result = client.search_notes(keyword="test", page=1)
        
        assert result.success == True
        assert len(result.get_notes()) == 1
    
    @patch('tikhub_xiaohongshu.requests.Session')
    def test_get_note_info_success(self, mock_session, client):
        """测试获取笔记详情成功"""
        mock_response = Mock()
        mock_response.json.return_value = {
            "code": 200,
            "message": "OK",
            "message_zh": "成功",
            "data": {
                "data": [{
                    "user": {},
                    "note_list": [{"id": "123"}]
                }]
            }
        }
        mock_session.return_value.request.return_value = mock_response
        
        result = client.get_note_info(note_id="123")
        
        assert result.success == True
    
    @patch('tikhub_xiaohongshu.requests.Session')
    def test_get_note_info_fallback(self, mock_session, client):
        """测试获取笔记详情兜底机制"""
        # 第一次调用失败，第二次成功
        mock_response_fail = Mock()
        mock_response_fail.json.return_value = {
            "code": 500,
            "message": "Error",
            "message_zh": "失败"
        }
        
        mock_response_success = Mock()
        mock_response_success.json.return_value = {
            "code": 200,
            "message": "OK",
            "message_zh": "成功",
            "data": {
                "data": [{
                    "user": {},
                    "note_list": [{"id": "123"}]
                }]
            }
        }
        
        mock_session.return_value.request.side_effect = [
            mock_response_fail,
            mock_response_success
        ]
        
        result = client.get_note_info(note_id="123")
        
        assert result.success == True
        # 验证调用了 2 次（第一次失败，第二次成功）
        assert mock_session.return_value.request.call_count == 2
    
    @patch('tikhub_xiaohongshu.requests.Session')
    def test_search_notes_all_with_details(self, mock_session, client):
        """测试搜索 + 获取详情"""
        # Mock 搜索响应
        mock_search_response = Mock()
        mock_search_response.json.return_value = {
            "code": 200,
            "message": "OK",
            "message_zh": "成功",
            "data": {
                "data": {
                    "items": [
                        {"note": {"id": "123", "title": "Note 1"}}
                    ],
                    "has_more": False
                }
            }
        }
        
        # Mock 详情响应
        mock_detail_response = Mock()
        mock_detail_response.json.return_value = {
            "code": 200,
            "message": "OK",
            "message_zh": "成功",
            "data": {
                "data": [{
                    "user": {},
                    "note_list": [{"id": "123"}]
                }]
            }
        }
        
        mock_session.return_value.request.side_effect = [
            mock_search_response,
            mock_detail_response
        ]
        
        result = client.search_notes_all(
            keyword="test",
            max_pages=1,
            fetch_details=True,
            detail_limit=1
        )
        
        assert "notes" in result
        assert "details" in result
        assert len(result["notes"]) >= 1


class TestNoteIdExtraction:
    """笔记 ID 提取测试（回归测试，防止 v0.1.14 bug）"""
    
    def test_extract_note_id_from_xhs_format(self):
        """测试从 xhs_review 格式提取 noteId"""
        note = {"noteId": "69312472000000000d03bea1"}
        note_id = note.get("noteId") or note.get("note", {}).get("id") or note.get("id")
        assert note_id == "69312472000000000d03bea1"
    
    def test_extract_note_id_from_nested_format(self):
        """测试从嵌套格式提取 note.id"""
        note = {"note": {"id": "123"}}
        note_id = note.get("noteId") or note.get("note", {}).get("id") or note.get("id")
        assert note_id == "123"
    
    def test_extract_note_id_from_flat_format(self):
        """测试从扁平格式提取 id"""
        note = {"id": "456"}
        note_id = note.get("noteId") or note.get("note", {}).get("id") or note.get("id")
        assert note_id == "456"
    
    def test_extract_note_id_priority(self):
        """测试提取优先级：noteId > note.id > id"""
        note = {
            "noteId": "priority1",
            "note": {"id": "priority2"},
            "id": "priority3"
        }
        note_id = note.get("noteId") or note.get("note", {}).get("id") or note.get("id")
        assert note_id == "priority1"


class TestSearchParams:
    """搜索参数提取测试（回归测试，防止 v0.1.14 inner_data bug）"""
    
    def test_get_search_params_from_response(self):
        """测试从响应获取翻页参数"""
        mock_data = {
            "data": {
                "search_id": "abc123",
                "search_session_id": "xyz789",
                "has_more": True
            }
        }
        response = TikHubResponse(
            code=200,
            message="OK",
            message_zh="成功",
            data=mock_data
        )
        
        # 使用 get_search_params 方法（正确方式）
        params = response.get_search_params()
        
        assert params["search_id"] == "abc123"
        assert params["search_session_id"] == "xyz789"
        assert params["has_more"] == True
    
    def test_get_search_params_empty_data(self):
        """测试空数据情况"""
        response = TikHubResponse(
            code=200,
            message="OK",
            message_zh="成功",
            data=None
        )
        params = response.get_search_params()
        assert params == {}
