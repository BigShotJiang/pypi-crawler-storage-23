cattrs.strategies package
=========================

.. automodule:: cattrs.strategies
   :members:
   :undoc-members:
   :show-inheritance:
