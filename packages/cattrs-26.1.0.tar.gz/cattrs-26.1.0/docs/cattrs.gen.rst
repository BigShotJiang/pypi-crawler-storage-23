cattrs.gen package
==================

.. automodule:: cattrs.gen
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

cattrs.gen.typeddicts module
----------------------------

.. automodule:: cattrs.gen.typeddicts
   :members:
   :undoc-members:
   :show-inheritance:
