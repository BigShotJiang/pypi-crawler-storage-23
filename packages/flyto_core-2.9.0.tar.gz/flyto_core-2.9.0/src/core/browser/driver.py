"""
Browser Driver - Playwright wrapper for browser automation
"""
import asyncio
import logging
from typing import Any, Dict, List, Optional
from pathlib import Path
from playwright.async_api import async_playwright, Browser, Page, ElementHandle

from ..constants import (
    DEFAULT_VIEWPORT_WIDTH,
    DEFAULT_VIEWPORT_HEIGHT,
    DEFAULT_BROWSER_TIMEOUT_MS,
    DEFAULT_USER_AGENT,
)


logger = logging.getLogger(__name__)


class BrowserDriver:
    """
    Playwright-based browser automation driver

    Provides high-level methods for browser control:
    - Launch and close browsers
    - Navigate to URLs
    - Click, type, wait for elements
    - Extract data from pages
    - Take screenshots
    """

    def __init__(self,
                 headless: bool = True,
                 viewport: Optional[Dict[str, int]] = None,
                 browser_type: str = 'chromium'):
        """
        Initialize browser driver

        Args:
            headless: Run browser in headless mode
            viewport: Browser viewport size (e.g., {'width': 1920, 'height': 1080})
            browser_type: Browser type ('chromium', 'firefox', 'webkit')
        """
        self.headless = headless
        self.viewport = viewport or {'width': DEFAULT_VIEWPORT_WIDTH, 'height': DEFAULT_VIEWPORT_HEIGHT}
        self.browser_type = browser_type

        # Playwright objects
        self._playwright = None
        self._browser: Optional[Browser] = None
        self._page: Optional[Page] = None
        self._context = None

    async def launch(
        self,
        proxy: Optional[str] = None,
        user_agent: Optional[str] = None,
        slow_mo: int = 0,
    ) -> Dict[str, Any]:
        """
        Launch browser instance

        Args:
            proxy: HTTP/SOCKS proxy server URL (e.g., 'http://proxy:8080')
            user_agent: Custom user agent string (overrides default)
            slow_mo: Delay between actions in milliseconds

        Returns:
            Status dictionary
        """
        try:
            logger.info(f"Launching {self.browser_type} browser (headless={self.headless})")

            self._playwright = await async_playwright().start()

            # Select browser type
            if self.browser_type == 'firefox':
                browser_launcher = self._playwright.firefox
            elif self.browser_type == 'webkit':
                browser_launcher = self._playwright.webkit
            else:
                browser_launcher = self._playwright.chromium

            # Build launch options
            launch_kwargs: Dict[str, Any] = {'headless': self.headless}
            if slow_mo > 0:
                launch_kwargs['slow_mo'] = slow_mo
            if proxy:
                launch_kwargs['proxy'] = {'server': proxy}

            # Launch browser (with fallback for desktop binary)
            if self.browser_type == 'chromium':
                self._browser = await self._launch_with_fallback(
                    browser_launcher, launch_kwargs
                )
            else:
                self._browser = await browser_launcher.launch(**launch_kwargs)

            # Create context with viewport
            context_user_agent = user_agent or DEFAULT_USER_AGENT
            self._context = await self._browser.new_context(
                viewport=self.viewport,
                user_agent=context_user_agent
            )

            # Create page
            self._page = await self._context.new_page()

            logger.info("Browser launched successfully")

            return {
                'status': 'success',
                'browser_type': self.browser_type,
                'headless': self.headless
            }

        except Exception as e:
            logger.error(f"Failed to launch browser: {str(e)}")
            raise RuntimeError(f"Browser launch failed: {str(e)}") from e

    async def goto(self,
                   url: str,
                   wait_until: str = 'domcontentloaded',
                   timeout_ms: int = DEFAULT_BROWSER_TIMEOUT_MS) -> Dict[str, Any]:
        """
        Navigate to URL

        Args:
            url: Target URL
            wait_until: When to consider navigation succeeded
                       ('load', 'domcontentloaded', 'networkidle')
            timeout_ms: Navigation timeout in milliseconds

        Returns:
            Navigation result with status and final URL
        """
        self._ensure_page()

        try:
            logger.info(f"Navigating to: {url}")

            response = await self._page.goto(
                url,
                wait_until=wait_until,
                timeout=timeout_ms
            )

            final_url = self._page.url
            status_code = response.status if response else None

            logger.info(f"Navigation completed: {final_url} (status: {status_code})")

            return {
                'status': 'success',
                'url': final_url,
                'status_code': status_code
            }

        except Exception as e:
            logger.error(f"Navigation failed: {str(e)}")
            raise RuntimeError(f"Failed to navigate to {url}: {str(e)}") from e

    async def click(self,
                    selector: str,
                    timeout_ms: int = DEFAULT_BROWSER_TIMEOUT_MS,
                    force: bool = False) -> Dict[str, Any]:
        """
        Click element by selector

        Args:
            selector: CSS selector
            timeout_ms: Timeout in milliseconds
            force: Force click even if element is not actionable

        Returns:
            Click result
        """
        self._ensure_page()

        try:
            logger.info(f"Clicking element: {selector}")

            await self._page.click(
                selector,
                timeout=timeout_ms,
                force=force
            )

            logger.info(f"Clicked: {selector}")

            return {
                'status': 'success',
                'selector': selector
            }

        except Exception as e:
            logger.error(f"Click failed: {str(e)}")
            raise RuntimeError(f"Failed to click {selector}: {str(e)}") from e

    async def type(self,
                   selector: str,
                   text: str,
                   delay_ms: int = 0,
                   timeout_ms: int = DEFAULT_BROWSER_TIMEOUT_MS) -> Dict[str, Any]:
        """
        Type text into element

        Args:
            selector: CSS selector
            text: Text to type
            delay_ms: Delay between keystrokes in milliseconds
            timeout_ms: Timeout in milliseconds

        Returns:
            Type result
        """
        self._ensure_page()

        try:
            logger.info(f"Typing into element: {selector}")

            await self._page.type(
                selector,
                text,
                delay=delay_ms,
                timeout=timeout_ms
            )

            logger.info(f"Typed text into: {selector}")

            return {
                'status': 'success',
                'selector': selector,
                'text_length': len(text)
            }

        except Exception as e:
            logger.error(f"Type failed: {str(e)}")
            raise RuntimeError(f"Failed to type into {selector}: {str(e)}") from e

    async def wait(self,
                   selector: str,
                   state: str = 'visible',
                   timeout_ms: int = DEFAULT_BROWSER_TIMEOUT_MS) -> Dict[str, Any]:
        """
        Wait for element to reach specified state

        Args:
            selector: CSS selector
            state: Element state ('attached', 'detached', 'visible', 'hidden')
            timeout_ms: Timeout in milliseconds

        Returns:
            Wait result
        """
        self._ensure_page()

        try:
            logger.info(f"Waiting for element: {selector} (state: {state})")

            await self._page.wait_for_selector(
                selector,
                state=state,
                timeout=timeout_ms
            )

            logger.info(f"Element ready: {selector}")

            return {
                'status': 'success',
                'selector': selector,
                'state': state
            }

        except Exception as e:
            logger.error(f"Wait failed: {str(e)}")
            raise RuntimeError(f"Failed to wait for {selector}: {str(e)}") from e

    async def extract(self,
                      selector: str,
                      fields: Dict[str, str],
                      multiple: bool = False) -> Dict[str, Any]:
        """
        Extract data from elements

        Args:
            selector: CSS selector for target elements
            fields: Field extraction map (field_name -> sub_selector or attribute)
                   Examples:
                   - {'title': 'h2', 'price': '.price', 'url': 'a@href'}
                   - Use '@attr' to extract attribute value
                   - Use selector alone to extract text content
            multiple: Extract from multiple elements (returns list)

        Returns:
            Extracted data
        """
        self._ensure_page()

        try:
            logger.info(f"Extracting data: {selector} (multiple={multiple})")

            if multiple:
                # Extract from multiple elements (supports CSS and XPath)
                elements = await self._query_selector_all(selector)

                results = []
                for element in elements:
                    item_data = await self._extract_from_element(element, fields)
                    results.append(item_data)

                logger.info(f"Extracted {len(results)} items")

                return {
                    'status': 'success',
                    'count': len(results),
                    'data': results
                }
            else:
                # Extract from single element (supports CSS and XPath)
                element = await self._query_selector(selector)

                if not element:
                    raise ValueError(f"Element not found: {selector}")

                data = await self._extract_from_element(element, fields)

                logger.info(f"Extracted data from: {selector}")

                return {
                    'status': 'success',
                    'data': data
                }

        except Exception as e:
            logger.error(f"Extraction failed: {str(e)}")
            raise RuntimeError(f"Failed to extract from {selector}: {str(e)}") from e

    async def _extract_from_element(self,
                                    element: ElementHandle,
                                    fields: Dict[str, str]) -> Dict[str, Any]:
        """
        Extract fields from a single element

        Args:
            element: Element handle
            fields: Field extraction map

        Returns:
            Extracted field data
        """
        result = {}

        for field_name, field_selector in fields.items():
            try:
                # Check if extracting attribute
                if '@' in field_selector:
                    parts = field_selector.split('@')
                    sub_selector = parts[0].strip() if parts[0].strip() else None
                    attr_name = parts[1].strip()

                    if sub_selector:
                        # Find sub-element first, then get attribute
                        sub_element = await element.query_selector(sub_selector)
                        if sub_element:
                            value = await sub_element.get_attribute(attr_name)
                        else:
                            value = None
                    else:
                        # Get attribute from current element
                        value = await element.get_attribute(attr_name)
                else:
                    # Extract text content
                    if field_selector:
                        # Find sub-element and get text
                        sub_element = await element.query_selector(field_selector)
                        if sub_element:
                            value = await sub_element.inner_text()
                        else:
                            value = None
                    else:
                        # Get text from current element
                        value = await element.inner_text()

                result[field_name] = value

            except Exception as e:
                logger.warning(f"Failed to extract field '{field_name}': {str(e)}")
                result[field_name] = None

        return result

    async def screenshot(self,
                        path: Optional[str] = None,
                        full_page: bool = False,
                        type: Optional[str] = None,
                        quality: Optional[int] = None) -> Dict[str, Any]:
        """
        Take screenshot

        Args:
            path: File path to save screenshot
                 If None, returns base64-encoded image
            full_page: Capture full scrollable page
            type: Image format ('png', 'jpeg', or 'webp'). Defaults to 'png'.
            quality: Image quality 0-100 (only for 'jpeg' and 'webp' formats)

        Returns:
            Screenshot result with path or base64 data
        """
        self._ensure_page()

        try:
            logger.info(f"Taking screenshot (full_page={full_page}, type={type})")

            kwargs: Dict[str, Any] = {
                'path': path,
                'full_page': full_page,
            }
            if type:
                kwargs['type'] = type
            if quality is not None and type in ('jpeg', 'webp'):
                kwargs['quality'] = quality

            screenshot_data = await self.real_page.screenshot(**kwargs)

            result = {
                'status': 'success',
                'full_page': full_page
            }

            if path:
                result['path'] = path
                logger.info(f"Screenshot saved: {path}")
            else:
                import base64
                result['base64'] = base64.b64encode(screenshot_data).decode('utf-8')
                logger.info("Screenshot captured (base64)")

            return result

        except Exception as e:
            logger.error(f"Screenshot failed: {str(e)}")
            raise RuntimeError(f"Failed to take screenshot: {str(e)}") from e

    async def evaluate(self, script: str) -> Any:
        """
        Execute JavaScript in page context

        Args:
            script: JavaScript code to execute

        Returns:
            Script return value
        """
        self._ensure_page()

        try:
            logger.info("Executing JavaScript")
            result = await self._page.evaluate(script)
            return result

        except Exception as e:
            logger.error(f"Script execution failed: {str(e)}")
            raise RuntimeError(f"Failed to execute script: {str(e)}") from e

    async def close(self) -> Dict[str, Any]:
        """
        Close browser instance

        Returns:
            Close result
        """
        try:
            logger.info("Closing browser")

            if self._page:
                # _page may be a Frame (set by browser.frame); only Page has close()
                if hasattr(self._page, 'close'):
                    await self._page.close()
                self._page = None

            if self._context:
                await self._context.close()
                self._context = None

            if self._browser:
                await self._browser.close()
                self._browser = None

            if self._playwright:
                await self._playwright.stop()
                self._playwright = None

            logger.info("Browser closed successfully")

            return {'status': 'success'}

        except Exception as e:
            logger.error(f"Close failed: {str(e)}")
            raise RuntimeError(f"Failed to close browser: {str(e)}") from e

    async def _launch_with_fallback(self, launcher, kwargs):
        """Try multiple browser sources to ensure desktop binary works."""
        # 1. Playwright bundled Chromium (dev mode or background install complete)
        try:
            return await launcher.launch(**kwargs)
        except Exception as e:
            first_error = e
            logger.warning(f"Playwright Chromium unavailable: {e}")

        # 2. System Chrome (available on ~90% of machines)
        try:
            logger.info("Trying system Chrome...")
            return await launcher.launch(channel='chrome', **kwargs)
        except Exception:
            logger.warning("System Chrome not found")

        # 3. Microsoft Edge (common on Windows)
        try:
            logger.info("Trying Microsoft Edge...")
            return await launcher.launch(channel='msedge', **kwargs)
        except Exception:
            logger.warning("Microsoft Edge not found")

        # 4. All failed
        raise RuntimeError(
            "No browser engine available. The browser is being downloaded "
            "in the background — please try again in a few minutes. "
            "Or install Google Chrome for immediate use."
        ) from first_error

    def _ensure_page(self):
        """Ensure page is available"""
        if not self._page:
            raise RuntimeError("Browser not launched. Call launch() first.")

    def _needs_locator_api(self, selector: str) -> bool:
        """
        Check if selector needs Playwright's locator API.

        Locator API is needed for:
        - XPath: starts with //, .., or xpath=
        - Text: starts with text=
        - Role: starts with role=
        - Label: starts with label=

        CSS selectors can use faster query_selector.
        """
        return (
            selector.startswith('//') or
            selector.startswith('..') or
            selector.startswith('xpath=') or
            selector.startswith('text=') or
            selector.startswith('role=') or
            selector.startswith('label=')
        )

    def _parse_modifiers(self, selector: str) -> tuple:
        """
        Parse selector modifiers like :nth=N and :near=selector.

        Supports:
        - selector:nth=0
        - selector:near=other
        - selector:nth=0:near=other

        Returns:
            (base_selector, nth_index, near_selector)
        """
        nth_index = None
        near_selector = None
        base_selector = selector

        # Parse :near= first (it comes last in the string)
        if ':near=' in base_selector:
            parts = base_selector.rsplit(':near=', 1)
            base_selector = parts[0]
            near_selector = parts[1]

        # Parse :nth=N from the remaining base
        if ':nth=' in base_selector:
            parts = base_selector.rsplit(':nth=', 1)
            base_selector = parts[0]
            try:
                nth_index = int(parts[1])
            except ValueError:
                nth_index = 0

        return base_selector, nth_index, near_selector

    def _normalize_selector(self, selector: str) -> str:
        """
        Normalize user-friendly selectors to CSS or locator format.

        Conversions:
        - placeholder=xxx → [placeholder="xxx"] (exact match)
        - name=xxx → [name="xxx"] (exact match)
        - id*=xxx → [id*="xxx"] (contains)
        - class*=xxx → [class*="xxx"] (contains)
        - id^=xxx → [id^="xxx"] (starts with)
        - id$=xxx → [id$="xxx"] (ends with)
        """
        # Fuzzy matching: attr*=, attr^=, attr$= (contains, starts, ends)
        import re
        fuzzy_match = re.match(r'^(id|class|name|placeholder|value|type|data-\w+)([*^$]?)=(.+)$', selector)
        if fuzzy_match:
            attr = fuzzy_match.group(1)
            operator = fuzzy_match.group(2) or ''  # *, ^, $, or empty for exact
            attr_value = fuzzy_match.group(3)

            # Handle quoted and unquoted values
            if not (attr_value.startswith('"') or attr_value.startswith("'")):
                attr_value = f'"{attr_value}"'

            return f'[{attr}{operator}={attr_value}]'

        return selector

    def _get_locator_selector(self, selector: str) -> str:
        """
        Convert selector to Playwright locator format.

        - //div → xpath=//div
        - ../parent → xpath=../parent
        - text=Hello → text=Hello (unchanged)
        - xpath=//div → xpath=//div (unchanged)
        - css=div → div (strip prefix for CSS)
        """
        if selector.startswith('//') or selector.startswith('..'):
            return f'xpath={selector}'
        if selector.startswith('css='):
            return selector[4:]
        return selector

    async def _query_selector(self, selector: str) -> Optional[ElementHandle]:
        """
        Query single element with CSS, XPath, text, or shortcut selectors.

        Supported formats:
        - CSS: .class, #id, div[attr=value]
        - XPath: //div[@class="x"], xpath=//div
        - Text: text=按鈕文字, text=Submit
        - Role: role=button[name="Submit"]
        - Label: label=Email (for associated input)
        - Shortcuts: placeholder=請輸入, name=email, value=送出
        - Fuzzy: id*=login, class*=btn (contains match)
        - Modifiers: selector:nth=0, selector:near=other

        Returns:
            ElementHandle or None
        """
        self._ensure_page()

        # Parse modifiers first
        base_selector, nth_index, near_selector = self._parse_modifiers(selector)

        # Normalize shortcuts like placeholder=xxx → [placeholder="xxx"]
        base_selector = self._normalize_selector(base_selector)

        # Get locator for the base selector
        if self._needs_locator_api(base_selector):
            locator_selector = self._get_locator_selector(base_selector)
            locator = self._page.locator(locator_selector)
        else:
            css_selector = base_selector[4:] if base_selector.startswith('css=') else base_selector
            locator = self._page.locator(css_selector)

        # Apply :near= modifier if present
        if near_selector:
            near_base = self._normalize_selector(near_selector)
            if self._needs_locator_api(near_base):
                near_locator = self._page.locator(self._get_locator_selector(near_base))
            else:
                near_locator = self._page.locator(near_base)
            locator = locator.near(near_locator)

        # Apply :nth= modifier or get first
        count = await locator.count()
        if count == 0:
            return None

        if nth_index is not None:
            if nth_index < count:
                return await locator.nth(nth_index).element_handle()
            return None
        else:
            return await locator.first.element_handle()

    async def _query_selector_all(self, selector: str) -> List[ElementHandle]:
        """
        Query all matching elements with CSS, XPath, text, or shortcut selectors.

        Supported formats:
        - CSS: .class, #id, div[attr=value]
        - XPath: //div[@class="x"], xpath=//div
        - Text: text=按鈕文字, text=Submit
        - Role: role=button[name="Submit"]
        - Label: label=Email (for associated input)
        - Shortcuts: placeholder=請輸入, name=email, value=送出
        - Fuzzy: id*=login, class*=btn (contains match)
        - Modifiers: selector:near=other

        Returns:
            List of ElementHandle
        """
        self._ensure_page()

        # Parse modifiers (note: :nth= doesn't make sense for _all, ignore it)
        base_selector, _, near_selector = self._parse_modifiers(selector)

        # Normalize shortcuts like placeholder=xxx → [placeholder="xxx"]
        base_selector = self._normalize_selector(base_selector)

        # Get locator for the base selector
        if self._needs_locator_api(base_selector):
            locator_selector = self._get_locator_selector(base_selector)
            locator = self._page.locator(locator_selector)
        else:
            css_selector = base_selector[4:] if base_selector.startswith('css=') else base_selector
            locator = self._page.locator(css_selector)

        # Apply :near= modifier if present
        if near_selector:
            near_base = self._normalize_selector(near_selector)
            if self._needs_locator_api(near_base):
                near_locator = self._page.locator(self._get_locator_selector(near_base))
            else:
                near_locator = self._page.locator(near_base)
            locator = locator.near(near_locator)

        # Get all matching elements
        count = await locator.count()
        elements = []
        for i in range(count):
            el = await locator.nth(i).element_handle()
            if el:
                elements.append(el)
        return elements

    async def new_page(self) -> Page:
        """
        Create a new page (or return existing if only one needed).

        Returns:
            Page instance
        """
        if not self._browser:
            raise RuntimeError("Browser not launched. Call launch() first.")

        # If no page exists, create one
        if not self._page:
            self._page = await self._context.new_page()

        return self._page

    @property
    def page(self) -> Page:
        """Get current page instance"""
        self._ensure_page()
        return self._page

    @property
    def real_page(self):
        """Get the actual Page object, even when inside a frame context.
        Use this for Page-only APIs: screenshot, pdf, keyboard, mouse,
        route, on/off events, expect_download, context."""
        if self._page is not None and hasattr(self._page, 'page'):
            return self._page.page  # Frame.page returns the owning Page
        return self._page

    @property
    def browser(self) -> Browser:
        """Get browser instance"""
        if not self._browser:
            raise RuntimeError("Browser not launched. Call launch() first.")
        return self._browser
