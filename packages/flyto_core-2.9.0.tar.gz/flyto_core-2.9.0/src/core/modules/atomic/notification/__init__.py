"""
Notification Modules
Send and receive notifications via various platforms.
"""
from .send import notify_send

__all__ = ['notify_send']
