"""
DNS Operation Modules
Perform DNS lookups and record queries
"""

from .lookup import dns_lookup

__all__ = ['dns_lookup']
