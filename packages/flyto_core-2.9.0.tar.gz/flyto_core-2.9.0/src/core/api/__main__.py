"""Allow running as: python -m core.api"""

from .server import main

if __name__ == "__main__":
    main()
