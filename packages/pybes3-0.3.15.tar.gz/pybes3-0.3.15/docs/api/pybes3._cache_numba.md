!!! warning "Rare Help for Users"
    There is **rare help** for users in this page. `pybes3._cache_numba.md` defines internal functions and never exposed to users.

---
::: pybes3._cache_numba.cache_auto_clear
---
::: pybes3._cache_numba.check_numba_cache
---
::: pybes3._cache_numba.clear_numba_cache
---
