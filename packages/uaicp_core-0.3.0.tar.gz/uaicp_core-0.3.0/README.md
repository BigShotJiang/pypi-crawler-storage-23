# UAICP Core

Universal Agentic Interoperability Control Protocol — Core Types and Interfaces for Python

Version: 0.3.0
