docs = [
    {
        "path": "../docs/rangin/power",
    },
    {
        "path": "../docs/rangin/power/v1.md",
    },
]
