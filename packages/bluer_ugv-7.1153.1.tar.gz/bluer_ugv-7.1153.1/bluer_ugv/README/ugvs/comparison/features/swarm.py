from bluer_ugv.README.ugvs.comparison.features.classes import Feature


class SwarmFeature(Feature):
    nickname = "swarm"
    long_name = "فعالیت گروهی "

    comparison_as_str = {}
