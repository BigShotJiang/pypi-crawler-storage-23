from bluer_objects.README.items import ImageItems

from bluer_ugv.README.swallow.consts import swallow_assets2

docs = [
    {
        "path": "../docs/swallow/digital/design/testing.md",
        "items": ImageItems(
            {
                f"{swallow_assets2}/20251201_172535~2_1.gif": "",
                f"{swallow_assets2}/20251203_112604.jpg": "",
            }
        ),
    },
]
