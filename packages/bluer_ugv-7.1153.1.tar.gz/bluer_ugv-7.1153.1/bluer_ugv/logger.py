from bluer_options.logger import get_logger
from bluer_ugv import ICON

logger = get_logger(ICON)
