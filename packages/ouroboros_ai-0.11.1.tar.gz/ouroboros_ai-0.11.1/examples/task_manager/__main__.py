"""Entry point for running the task manager as a module."""

from .cli import main

if __name__ == "__main__":
    main()
