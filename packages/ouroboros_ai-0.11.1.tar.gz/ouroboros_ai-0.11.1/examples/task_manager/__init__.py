"""Task Manager CLI Application.

A simple task management CLI that supports CRUD operations.
"""

__version__ = "0.1.0"
