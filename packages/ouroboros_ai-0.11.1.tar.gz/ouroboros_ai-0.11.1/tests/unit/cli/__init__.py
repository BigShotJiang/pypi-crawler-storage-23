"""Unit tests for Ouroboros CLI module."""
