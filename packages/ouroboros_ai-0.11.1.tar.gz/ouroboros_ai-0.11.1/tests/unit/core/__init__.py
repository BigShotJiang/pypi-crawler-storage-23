"""Unit tests for ouroboros.core module."""
