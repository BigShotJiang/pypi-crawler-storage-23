"""Unit tests for the evaluation module."""
