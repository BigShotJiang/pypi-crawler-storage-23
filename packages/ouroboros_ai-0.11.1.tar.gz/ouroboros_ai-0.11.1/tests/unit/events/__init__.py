"""Unit tests for ouroboros.events module."""
