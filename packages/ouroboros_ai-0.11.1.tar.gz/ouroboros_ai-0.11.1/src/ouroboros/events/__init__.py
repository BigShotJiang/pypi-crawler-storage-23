"""Ouroboros events module - event definitions for event sourcing."""

from ouroboros.events.base import BaseEvent

__all__ = ["BaseEvent"]
