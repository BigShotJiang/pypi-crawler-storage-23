class CaseError(Exception):
    pass


class CLIFormatError(Exception):
    pass
