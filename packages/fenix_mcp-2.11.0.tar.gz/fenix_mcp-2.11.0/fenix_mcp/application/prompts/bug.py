# SPDX-License-Identifier: MIT
"""Fenix Bug prompt - create a bug report from conversation context."""

from __future__ import annotations

from typing import Any, Dict, List

from fenix_mcp.application.prompt_base import (
    Prompt,
    PromptArgument,
    PromptMessage,
    PromptResult,
)


class FenixBugPrompt(Prompt):
    """Prompt to create a bug report from conversation context."""

    name = "bug"
    description = "Create a bug report from conversation context"
    arguments: List[PromptArgument] = []

    def get_messages(self, arguments: Dict[str, Any]) -> PromptResult:
        instruction = """Create a bug report in Fenix based on our conversation.

**Instructions:**
1. Analyze the conversation to identify the bug being discussed
2. Use `mcp__fenix__knowledge` with `action: work_create` and:
   - work_type: "bug"
   - work_title: A clear, descriptive title for the bug
   - work_description: Include:
     - **Problem**: What's happening
     - **Expected**: What should happen
     - **Steps to reproduce**: If discussed
     - **Context**: Any relevant details from our conversation
   - work_category: Choose appropriate (backend, frontend, etc.)
   - work_priority: Set based on severity discussed (default: medium)
   - work_tags: Add relevant tags like "bug", area affected, etc.
3. Confirm with the bug key (e.g., PROJ-123)"""

        return PromptResult(
            description="Create bug report from conversation",
            messages=[PromptMessage(role="user", text=instruction)],
        )
