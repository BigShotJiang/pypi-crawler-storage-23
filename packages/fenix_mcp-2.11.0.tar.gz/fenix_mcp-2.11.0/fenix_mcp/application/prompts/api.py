# SPDX-License-Identifier: MIT
"""Fenix API prompt - search API catalog."""

from __future__ import annotations

from typing import Any, Dict, List

from fenix_mcp.application.prompt_base import (
    Prompt,
    PromptArgument,
    PromptMessage,
    PromptResult,
)


class FenixApiPrompt(Prompt):
    """Prompt to search the API catalog."""

    name = "api"
    description = "Search the API catalog for endpoints and documentation"
    arguments: List[PromptArgument] = [
        PromptArgument(
            name="query",
            description="What API or endpoint are you looking for?",
            required=False,
        ),
    ]

    def get_messages(self, arguments: Dict[str, Any]) -> PromptResult:
        query = arguments.get("query", "")

        if query:
            instruction = f"""Search the API catalog for "{query}".

**Instructions:**
1. Use `mcp__fenix__knowledge` with `action: api_catalog_search` and `query: "{query}"`
2. Present the matching APIs with:
   - API name and description
   - Base URL
   - Available endpoints (if returned)
3. If there are multiple results, list them all
4. If I need more details about a specific API, use `action: api_catalog_get` with the ID"""

            return PromptResult(
                description=f"Search API catalog for: {query}",
                messages=[PromptMessage(role="user", text=instruction)],
            )

        # No query - list all APIs
        instruction = """List all available APIs in the catalog.

**Instructions:**
1. Use `mcp__fenix__knowledge` with `action: api_catalog_list`
2. Present all APIs in a clear format:
   - API name
   - Description
   - Number of endpoints (if available)
3. Group by category if applicable
4. Mention I can search for specific APIs with /fenix:api "query\""""

        return PromptResult(
            description="List all APIs in catalog",
            messages=[PromptMessage(role="user", text=instruction)],
        )
