# SPDX-License-Identifier: MIT
"""Prompt implementations for Fenix MCP server."""

from __future__ import annotations

from typing import List

from fenix_mcp.application.prompt_base import Prompt
from fenix_mcp.application.prompts.api import FenixApiPrompt
from fenix_mcp.application.prompts.bug import FenixBugPrompt
from fenix_mcp.application.prompts.docs import FenixDocsPrompt
from fenix_mcp.application.prompts.docs_create import FenixDocsCreatePrompt
from fenix_mcp.application.prompts.docs_search import FenixDocsSearchPrompt
from fenix_mcp.application.prompts.feature import FenixFeaturePrompt
from fenix_mcp.application.prompts.memory import FenixMemoryPrompt
from fenix_mcp.application.prompts.mine import FenixMinePrompt
from fenix_mcp.application.prompts.rules import FenixRulesPrompt
from fenix_mcp.application.prompts.task import FenixTaskPrompt
from fenix_mcp.application.prompts.todo import FenixTodoPrompt
from fenix_mcp.application.prompts.todo_add import FenixTodoAddPrompt


def build_prompts() -> List[Prompt]:
    """Build and return all available prompts."""
    return [
        # API
        FenixApiPrompt(),
        # Work Items
        FenixBugPrompt(),
        FenixFeaturePrompt(),
        FenixMinePrompt(),
        FenixTaskPrompt(),
        # Documentation
        FenixDocsPrompt(),
        FenixDocsCreatePrompt(),
        FenixDocsSearchPrompt(),
        # Memory
        FenixMemoryPrompt(),
        # Rules
        FenixRulesPrompt(),
        # TODOs
        FenixTodoPrompt(),
        FenixTodoAddPrompt(),
    ]


__all__ = [
    "build_prompts",
    "FenixApiPrompt",
    "FenixBugPrompt",
    "FenixDocsPrompt",
    "FenixDocsCreatePrompt",
    "FenixDocsSearchPrompt",
    "FenixFeaturePrompt",
    "FenixMemoryPrompt",
    "FenixMinePrompt",
    "FenixRulesPrompt",
    "FenixTaskPrompt",
    "FenixTodoPrompt",
    "FenixTodoAddPrompt",
]
