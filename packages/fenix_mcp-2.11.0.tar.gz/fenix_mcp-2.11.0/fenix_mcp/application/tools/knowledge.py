# SPDX-License-Identifier: MIT
"""Knowledge tool implementation updated for the expanded Fênix API."""

from __future__ import annotations

from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import Field

from fenix_mcp.application.presenters import text
from fenix_mcp.application.tool_base import (
    MERMAID_HINT,
    CategoryStr,
    DateTimeStr,
    DescriptionStr,
    EmojiStr,
    LanguageStr,
    MarkdownStr,
    TagStr,
    TitleStr,
    Tool,
    ToolRequest,
    UUIDStr,
    VersionStr,
    sanitize_null,
    sanitize_null_list,
)
from fenix_mcp.domain.knowledge import KnowledgeService, _format_date
from fenix_mcp.infrastructure.context import AppContext


class KnowledgeAction(str, Enum):
    def __new__(cls, value: str, description: str):
        obj = str.__new__(cls, value)
        obj._value_ = value
        obj.description = description
        return obj

    # Work items
    WORK_CREATE = (
        "work_create",
        "Creates a work item with title, status and optional links. Use parent_key (e.g., DVPT-0001) to set parent.",
    )
    WORK_LIST = (
        "work_list",
        "Lists work items with status, priority and context filters.",
    )
    WORK_GET = (
        "work_get",
        "Gets full details of a work item by ID or key (e.g., DVPT-0001).",
    )
    WORK_UPDATE = (
        "work_update",
        "Updates allowed fields of an existing work item (title, description, priority, story_points, tags, due_date).",
    )
    WORK_CHILDREN = (
        "work_children",
        "Lists child work items of a parent item by ID or key (e.g., DVPT-0001).",
    )
    WORK_ASSIGN_TO_ME = (
        "work_assign_to_me",
        "Assigns a work item to the current user.",
    )
    WORK_STATUS_NEXT = (
        "work_status_next",
        "Advances to the next visible workflow status. Skips statuses not mapped to board columns.",
    )
    WORK_STATUS_DONE = (
        "work_status_done",
        "Moves directly to the done/completed status.",
    )
    WORK_MINE = (
        "work_mine",
        "START HERE for 'my tasks' or 'what am I working on'. Lists work items assigned to current user. Excludes done/cancelled. Supports limit and offset.",
    )
    WORK_BULK_CREATE = (
        "work_bulk_create",
        "Creates multiple work items atomically with hierarchy. Use temp_id as temporary identifier and parent_temp_id to reference parent in the same batch, or parent_key to reference an existing work item (e.g., TEMA-0056). Cannot use both parent_temp_id and parent_key on the same item. Example: [{temp_id:'epic-1', title:'My Epic', item_type:'epic', work_category:'backend'}, {temp_id:'task-1', parent_temp_id:'epic-1', title:'My Task', item_type:'task', work_category:'backend'}] or [{temp_id:'task-1', parent_key:'TEMA-0056', title:'My Task', item_type:'task', work_category:'backend'}]",
    )

    # Boards
    BOARD_LIST = ("board_list", "Lists available boards with optional filters.")
    BOARD_FAVORITES = ("board_favorites", "Lists boards marked as favorites.")
    BOARD_GET = ("board_get", "Gets board details by ID.")
    BOARD_COLUMNS = ("board_columns", "Lists columns configured for a board.")

    # Sprints
    SPRINT_LIST = ("sprint_list", "Lists available sprints with optional filters.")
    SPRINT_ACTIVE = ("sprint_active", "Gets the active sprint for a team.")
    SPRINT_GET = ("sprint_get", "Gets sprint details by ID.")
    SPRINT_WORK_ITEMS = (
        "sprint_work_items",
        "Lists work items linked to a sprint.",
    )

    # Rules
    RULE_CREATE = (
        "rule_create",
        "Creates a new rule. REQUIRED: rule_scope (personal|team|organization|marketplace), rule_name, rule_content, rule_category (frontend|backend|mobile|fullstack|devops|infrastructure|architecture|code_review|testing|security|documentation|performance|other). Optional: rule_description, rule_slug. If scope=team, rule_team_id is also required.",
    )
    RULE_LIST = (
        "rule_list",
        "Lists rules accessible to the current user. Optional filters: rule_scope, query, limit, offset.",
    )
    RULE_GET = (
        "rule_get",
        "Gets full details of a rule. REQUIRED: rule_id (or id).",
    )
    RULE_UPDATE = (
        "rule_update",
        "Updates an existing rule. REQUIRED: rule_id (or id). Optional: rule_name, rule_description, rule_content, rule_is_active, rule_category.",
    )
    RULE_DELETE = (
        "rule_delete",
        "Deletes a rule. REQUIRED: rule_id (or id).",
    )
    RULE_MARKETPLACE = (
        "rule_marketplace",
        "Lists public marketplace rules. Optional filters: query, limit, offset.",
    )
    RULE_FORK = (
        "rule_fork",
        "Forks a rule to a new scope. REQUIRED: rule_id (or id), rule_scope (personal|team|organization). Optional: rule_name, rule_team_id (required if scope=team).",
    )
    RULE_EXPORT = (
        "rule_export",
        "Exports a rule to a specific format. REQUIRED: rule_id (or id), rule_export_format (cursor|claude|copilot|windsurf).",
    )

    # Documentation - Navigation workflow: doc_full_tree -> doc_children -> doc_get
    DOC_CREATE = (
        "doc_create",
        "Creates a documentation item. Requires doc_emoji for page, api_doc, and guide types.",
    )
    DOC_LIST = (
        "doc_list",
        "Lists documentation items. Use doc_full_tree for hierarchical view.",
    )
    DOC_GET = (
        "doc_get",
        "Reads document content by ID. PREREQUISITE: Get the ID from doc_full_tree first. Do NOT guess IDs.",
    )
    DOC_UPDATE = ("doc_update", "Updates a documentation item.")
    DOC_DELETE = ("doc_delete", "Removes a documentation item.")
    DOC_ROOTS = (
        "doc_roots",
        "Lists root folders. Use doc_children to navigate inside.",
    )
    DOC_RECENT = ("doc_recent", "Lists recently accessed documents.")
    DOC_ANALYTICS = ("doc_analytics", "Returns document analytics.")
    DOC_CHILDREN = (
        "doc_children",
        "Lists child documents of a folder by ID. Use this to navigate into folders.",
    )
    DOC_TREE = ("doc_tree", "Retrieves tree starting from a specific document.")
    DOC_FULL_TREE = (
        "doc_full_tree",
        "START HERE when looking for documentation. Returns complete folder structure with IDs. You NEED the ID from this to use doc_get. Workflow: 1) doc_full_tree to see all docs with IDs, 2) doc_get(id) to read content.",
    )
    DOC_MOVE = ("doc_move", "Moves a document to another parent.")
    DOC_PUBLISH = ("doc_publish", "Changes publication status of a document.")
    DOC_VERSION = ("doc_version", "Generates or retrieves a document version.")
    DOC_DUPLICATE = ("doc_duplicate", "Duplicates an existing document.")

    # API Catalog
    API_CATALOG_SEARCH = (
        "api_catalog_search",
        "Semantic search to find APIs by natural language query (e.g., 'API de usuários').",
    )
    API_CATALOG_LIST = (
        "api_catalog_list",
        "Lists API specifications with optional filters (status, tags).",
    )
    API_CATALOG_GET = (
        "api_catalog_get",
        "Gets full details of an API including all endpoints and environments.",
    )

    # Team switching
    SWITCH_ACTIVE_TEAM = (
        "switch_active_team",
        "Switches the active team for this session. REQUIRED: id (team UUID). All subsequent operations will use this team. Use this when the user has multiple teams and chooses which one to work with.",
    )

    HELP = ("knowledge_help", "Shows available actions and their uses.")

    @classmethod
    def choices(cls) -> List[str]:
        return [member.value for member in cls]

    @classmethod
    def formatted_help(cls) -> str:
        lines = [
            "| **Action** | **Description** |",
            "| --- | --- |",
        ]
        for member in cls:
            lines.append(f"| `{member.value}` | {member.description} |")
        return "\n".join(lines)


ACTION_FIELD_DESCRIPTION = """Knowledge action grouped by category:

**WORK ITEMS** (tasks, bugs, features):
- `work_mine`: YOUR assigned tasks (START HERE for "my tasks")
- `work_list`: List with filters (status, priority, type)
- `work_get`: Get details by ID or key (use work_key for "FENIX-123")
- `work_create`: Create new (requires: work_title, work_category)
- `work_update`: Update fields (title, description, priority, story_points, tags, due_date)
- `work_bulk_create`: Create multiple with hierarchy
- `work_children`: Child items of a parent
- `work_assign_to_me`: Assign item to yourself
- `work_status_next`: Advance to next visible workflow status
- `work_status_done`: Move directly to done/completed status

**DOCUMENTATION**:
- `doc_full_tree`: Complete tree (START HERE to find docs and get IDs)
- `doc_get`: Read content (needs ID from doc_full_tree)
- `doc_children`: Folder contents
- `doc_create`: Create new doc (requires: doc_title, doc_emoji for non-folders)
- `doc_update`: Update doc
- `doc_delete`: Remove doc
- `doc_roots`: Root folders
- `doc_recent`: Recently accessed
- `doc_tree`: Tree from specific doc
- `doc_move`: Move to another parent
- `doc_publish`: Change publication status
- `doc_version`: Create/get version
- `doc_duplicate`: Duplicate doc
- `doc_analytics`: Doc metrics

**SPRINTS**:
- `sprint_active`: Current sprint (START HERE)
- `sprint_list`: All sprints
- `sprint_get`: Sprint details
- `sprint_work_items`: Items in sprint

**BOARDS**:
- `board_list`: All boards
- `board_get`: Board details
- `board_favorites`: Favorite boards
- `board_columns`: Board columns

**RULES** (coding standards):
- `rule_list`: Team rules
- `rule_get`: Rule content
- `rule_create`: Create rule (requires: rule_scope, rule_name, rule_content, rule_category)
- `rule_update`: Update rule
- `rule_delete`: Remove rule
- `rule_export`: Export for IDE (cursor, claude, copilot, windsurf)
- `rule_marketplace`: Public rules
- `rule_fork`: Fork a rule

**API CATALOG**:
- `api_catalog_search`: Semantic search for APIs (natural language)
- `api_catalog_list`: List all APIs
- `api_catalog_get`: API details with endpoints

`knowledge_help`: Show all actions with descriptions
"""


_ALLOWED_DOC_TYPES = {
    "folder",
    "page",
    "api_doc",
    "guide",
}

_ALLOWED_WORK_ITEM_TYPES = {
    "epic",
    "feature",
    "story",
    "bug",
    "hotfix",
    "task",
    "spike",
    "subtask",
}


class KnowledgeRequest(ToolRequest):
    action: KnowledgeAction = Field(description=ACTION_FIELD_DESCRIPTION)
    id: Optional[UUIDStr] = Field(
        default=None, description="Primary resource ID (UUID)."
    )
    limit: int = Field(default=20, ge=1, le=100, description="Result limit.")
    offset: int = Field(
        default=0, ge=0, description="Pagination offset (when supported)."
    )
    board_id: Optional[UUIDStr] = Field(
        default=None, description="Associated board ID (UUID)."
    )
    sprint_id: Optional[UUIDStr] = Field(
        default=None, description="Associated sprint ID (UUID)."
    )
    epic_id: Optional[UUIDStr] = Field(
        default=None, description="Associated epic ID (UUID)."
    )
    query: Optional[str] = Field(default=None, description="Filter/search term.")
    return_content: Optional[bool] = Field(
        default=None, description="Return full content."
    )
    return_description: Optional[bool] = Field(
        default=None, description="Return full description."
    )
    return_metadata: Optional[bool] = Field(
        default=None, description="Return full metadata."
    )

    # Work item fields
    work_key: Optional[str] = Field(
        default=None,
        description="Work item key (e.g., DVPT-0001). Use this instead of id for work_get and work_children.",
    )
    work_title: Optional[TitleStr] = Field(default=None, description="Work item title.")
    work_description: Optional[MarkdownStr] = Field(
        default=None, description=f"Work item description (Markdown).{MERMAID_HINT}"
    )
    work_type: Optional[str] = Field(
        default="task",
        description="Work item type. Values: epic, feature, story, bug, hotfix, task, spike, subtask.",
    )
    work_status: Optional[str] = Field(
        default=None,
        description="Work item status ID (UUID of TeamStatus).",
    )
    work_priority: Optional[str] = Field(
        default=None,
        description="Work item priority (critical, high, medium, low).",
    )
    work_category: Optional[str] = Field(
        default=None,
        description="Work item category/discipline. REQUIRED for work_create. Values: backend, frontend, mobile, fullstack, devops, infra, platform, sre, database, security, data, analytics, ai_ml, qa, automation, design, research, product, project, agile, support, operations, documentation, training, architecture, planning, development.",
    )
    story_points: Optional[int] = Field(
        default=None, ge=0, le=100, description="Story points (0-100)."
    )
    assignee_id: Optional[UUIDStr] = Field(
        default=None, description="Assignee ID (UUID)."
    )
    parent_id: Optional[UUIDStr] = Field(
        default=None,
        description="Parent item ID (UUID). Prefer using parent_key instead.",
    )
    parent_key: Optional[str] = Field(
        default=None,
        description="Parent item key (e.g., DVPT-0001). Use this to set the parent of a work item.",
    )
    work_due_date: Optional[DateTimeStr] = Field(
        default=None, description="Work item due date (ISO 8601)."
    )
    work_tags: Optional[List[TagStr]] = Field(
        default=None, description="Work item tags."
    )
    work_item_ids: Optional[List[UUIDStr]] = Field(
        default=None,
        description="List of work item IDs for batch operations (UUIDs).",
    )
    work_items: Optional[List[Dict[str, Any]]] = Field(
        default=None,
        description=(
            "List of work items for bulk create (max 50). Each item requires: "
            "temp_id (your temporary ID like 'epic-1', 'task-a'), title, item_type, work_category. "
            "Use parent_temp_id to set parent from same batch (e.g., parent_temp_id:'epic-1'), "
            "OR parent_key to set parent from existing work item (e.g., parent_key:'TEMA-0056'). "
            "Cannot use both parent_temp_id and parent_key on the same item. "
            "Optional: description, priority (low/medium/high/critical), story_points, tags, due_date. "
            'Example: [{"temp_id":"e1", "title":"Epic", "item_type":"epic", "work_category":"backend"}, '
            '{"temp_id":"t1", "parent_temp_id":"e1", "title":"Task", "item_type":"task", "work_category":"backend"}]'
        ),
    )

    # Documentation fields
    doc_title: Optional[TitleStr] = Field(
        default=None, description="Documentation title."
    )
    doc_description: Optional[DescriptionStr] = Field(
        default=None, description="Documentation description."
    )
    doc_content: Optional[MarkdownStr] = Field(
        default=None, description=f"Documentation content (Markdown).{MERMAID_HINT}"
    )
    doc_status: Optional[str] = Field(
        default=None,
        description="Documentation status (draft, review, published, archived).",
    )
    doc_type: Optional[str] = Field(
        default=None,
        description="Documentation type. Values: folder, page, api_doc, guide.",
    )
    doc_language: Optional[LanguageStr] = Field(
        default=None, description="Documentation language (e.g.: pt, en, pt-BR)."
    )
    doc_parent_id: Optional[UUIDStr] = Field(
        default=None, description="Parent document ID (UUID)."
    )
    doc_owner_id: Optional[UUIDStr] = Field(
        default=None, description="Owner ID (UUID)."
    )
    doc_reviewer_id: Optional[UUIDStr] = Field(
        default=None, description="Reviewer ID (UUID)."
    )
    doc_version: Optional[VersionStr] = Field(
        default=None, description="Document version (e.g.: 1.0, 2.1.3)."
    )
    doc_category: Optional[CategoryStr] = Field(default=None, description="Category.")
    doc_tags: Optional[List[TagStr]] = Field(default=None, description="Tags.")
    doc_position: Optional[int] = Field(
        default=None, ge=0, description="Desired position when moving documents."
    )
    doc_emoji: Optional[EmojiStr] = Field(
        default=None,
        description="Emoji displayed with the document. REQUIRED for page, api_doc, and guide types (not required for folder).",
    )
    doc_emote: Optional[EmojiStr] = Field(
        default=None, description="Alias for emoji, kept for compatibility."
    )
    doc_keywords: Optional[List[TagStr]] = Field(
        default=None, description="Keywords for search."
    )
    doc_is_public: Optional[bool] = Field(
        default=None, description="Whether the document is public."
    )

    # Rule fields
    rule_id: Optional[UUIDStr] = Field(default=None, description="Rule ID (UUID).")
    rule_scope: Optional[str] = Field(
        default=None,
        description="Rule scope. Values: personal, team, organization, marketplace.",
    )
    rule_name: Optional[TitleStr] = Field(default=None, description="Rule name.")
    rule_slug: Optional[str] = Field(
        default=None, description="Rule slug (auto-generated if not provided)."
    )
    rule_description: Optional[DescriptionStr] = Field(
        default=None, description="Rule description."
    )
    rule_content: Optional[MarkdownStr] = Field(
        default=None, description=f"Rule content (Markdown).{MERMAID_HINT}"
    )
    rule_team_id: Optional[UUIDStr] = Field(
        default=None, description="Team ID for team-scoped rules (UUID)."
    )
    rule_export_format: Optional[str] = Field(
        default=None,
        description="Export format. Values: cursor, claude, copilot, windsurf.",
    )
    rule_is_active: Optional[bool] = Field(
        default=None, description="Whether the rule is active."
    )
    rule_category: Optional[str] = Field(
        default=None,
        description="Rule category. REQUIRED for rule_create. Values: frontend, backend, mobile, fullstack, devops, infrastructure, architecture, code_review, testing, security, documentation, performance, other.",
    )

    # API Catalog fields
    api_spec_id: Optional[UUIDStr] = Field(
        default=None,
        description="API specification ID (UUID). Can also use 'id' field instead.",
    )


class KnowledgeTool(Tool):
    name = "knowledge"
    description = """Fenix knowledge base - use this tool when user asks about:

WORK ITEMS (tasks, bugs, features):
- "what are my tasks?" -> action: work_mine
- "show task FENIX-123" -> action: work_get, work_key: "FENIX-123"
- "create a task" -> action: work_create (requires: work_title, work_category)
- "move task to next status" -> action: work_status_next
- "mark task as done" -> action: work_status_done

DOCUMENTATION:
- "find docs about X" -> action: doc_full_tree (START HERE to get IDs)
- "read the architecture doc" -> action: doc_get (needs ID from doc_full_tree)

SPRINTS:
- "current sprint?" -> action: sprint_active
- "sprint items?" -> action: sprint_work_items

RULES (coding standards):
- "team coding standards?" -> action: rule_list
- "export rules for cursor" -> action: rule_export

API CATALOG:
- "find user API" -> action: api_catalog_search
- "list all APIs" -> action: api_catalog_list

TEAM SWITCHING (multi-team users):
- "switch to team X" -> action: switch_active_team, id: "<team_uuid>"

IMPORTANT WORKFLOWS:
1. For MY tasks: Always use work_mine first
2. For docs: Always use doc_full_tree first to get IDs, then doc_get
3. For work item by key: Use work_key parameter (e.g., "FENIX-123")
"""
    request_model = KnowledgeRequest

    def __init__(self, context: AppContext):
        self._context = context
        self._service = KnowledgeService(context.api_client, context.logger)

    async def run(self, payload: KnowledgeRequest, context: AppContext):
        action = payload.action
        if action is KnowledgeAction.HELP:
            return await self._handle_help()
        if action is KnowledgeAction.SWITCH_ACTIVE_TEAM:
            return await self._handle_switch_team(payload)
        if action.value.startswith("work_"):
            return await self._run_work(payload)
        if action.value.startswith("board_"):
            return await self._run_board(payload)
        if action.value.startswith("sprint_"):
            return await self._run_sprint(payload)
        if action.value.startswith("rule_"):
            return await self._run_rule(payload)
        if action.value.startswith("doc_"):
            return await self._run_doc(payload)
        if action.value.startswith("api_catalog_"):
            return await self._run_api_catalog(payload)
        return text(
            "❌ Invalid action for knowledge.\n\nChoose one of the values:\n"
            + "\n".join(f"- `{value}`" for value in KnowledgeAction.choices())
        )

    # ------------------------------------------------------------------
    # Work items
    # ------------------------------------------------------------------
    async def _run_work(self, payload: KnowledgeRequest):
        action = payload.action
        if action is KnowledgeAction.WORK_CREATE:
            if not payload.work_title:
                return text("❌ Provide work_title to create the item.")
            if not payload.work_category:
                return text(
                    "❌ Provide work_category to create the item. Values: backend, frontend, mobile, fullstack, devops, infra, platform, sre, database, security, data, analytics, ai_ml, qa, automation, design, research, product, project, agile, support, operations, documentation, training, architecture, planning, development."
                )

            # Validate work_type
            if payload.work_type and payload.work_type not in _ALLOWED_WORK_ITEM_TYPES:
                allowed_types = ", ".join(sorted(_ALLOWED_WORK_ITEM_TYPES))
                return text(
                    f"❌ Invalid work_type: '{payload.work_type}'\n\n"
                    f"Valid types are: {allowed_types}"
                )

            # Resolve parent_key to parent_id if provided
            parent_id = payload.parent_id
            if payload.parent_key and not parent_id:
                parent_work = await self._service.work_get_by_key(payload.parent_key)
                parent_id = parent_work.get("id")

            work = await self._service.work_create(
                {
                    "title": payload.work_title,
                    "description": payload.work_description,
                    "item_type": payload.work_type,
                    "status_id": payload.work_status,
                    "priority": payload.work_priority,
                    "work_category": payload.work_category,
                    "story_points": payload.story_points,
                    "assignee_id": payload.assignee_id,
                    "sprint_id": payload.sprint_id,
                    "parent_id": parent_id,
                    "due_date": payload.work_due_date,
                    "tags": payload.work_tags,
                }
            )
            return text(_format_work(work, header="✅ Work item created"))

        if action is KnowledgeAction.WORK_LIST:
            # Validate work_type if provided
            if payload.work_type and payload.work_type not in _ALLOWED_WORK_ITEM_TYPES:
                allowed_types = ", ".join(sorted(_ALLOWED_WORK_ITEM_TYPES))
                return text(
                    f"❌ Invalid work_type: '{payload.work_type}'\n\n"
                    f"Valid types are: {allowed_types}"
                )

            items = await self._service.work_list(
                limit=payload.limit,
                offset=payload.offset,
                priority=payload.work_priority,
                type=payload.work_type,
                assignee=payload.assignee_id,
                sprint=payload.sprint_id,
            )
            if not items:
                return text("🎯 No work items found.")
            body = "\n\n".join(_format_work(item) for item in items)
            return text(f"🎯 **Work items ({len(items)}):**\n\n{body}")

        if action is KnowledgeAction.WORK_GET:
            # Support both id and work_key
            if payload.work_key:
                work = await self._service.work_get_by_key(payload.work_key)
            elif payload.id:
                work = await self._service.work_get(payload.id)
            else:
                return text("❌ Provide id or work_key to get the work item.")
            return text(
                _format_work(work, header="🎯 Work item details", show_description=True)
            )

        if action is KnowledgeAction.WORK_UPDATE:
            # Resolve work_key to id if needed
            work_id = payload.id
            if payload.work_key and not work_id:
                work_item = await self._service.work_get_by_key(payload.work_key)
                work_id = work_item.get("id")
            if not work_id:
                return text("❌ Provide id or work_key to update the work item.")

            # Only allow safe fields to be updated via MCP
            # Excluded: item_type, status_id, assignee_id, sprint_id, parent_id, work_category
            work = await self._service.work_update(
                work_id,
                {
                    "title": payload.work_title,
                    "description": payload.work_description,
                    "priority": payload.work_priority,
                    "story_points": payload.story_points,
                    "due_date": payload.work_due_date,
                    "tags": payload.work_tags,
                },
            )
            return text(_format_work(work, header="✅ Work item updated"))

        if action is KnowledgeAction.WORK_ASSIGN_TO_ME:
            # Resolve work_key to id if needed
            work_id = payload.id
            if payload.work_key and not work_id:
                work_item = await self._service.work_get_by_key(payload.work_key)
                work_id = work_item.get("id")
            if not work_id:
                return text("❌ Provide id or work_key to assign the work item.")
            work = await self._service.work_assign_to_me(work_id)
            return text(_format_work(work, header="✅ Work item assigned to you"))

        if action is KnowledgeAction.WORK_STATUS_NEXT:
            work_id = payload.id
            if payload.work_key and not work_id:
                work_item = await self._service.work_get_by_key(payload.work_key)
                work_id = work_item.get("id")
            if not work_id:
                return text("❌ Provide id or work_key to advance status.")
            work = await self._service.work_advance_status(work_id)
            return text(_format_work(work, header="✅ Status advanced"))

        if action is KnowledgeAction.WORK_STATUS_DONE:
            work_id = payload.id
            if payload.work_key and not work_id:
                work_item = await self._service.work_get_by_key(payload.work_key)
                work_id = work_item.get("id")
            if not work_id:
                return text("❌ Provide id or work_key to complete status.")
            work = await self._service.work_complete_status(work_id)
            return text(_format_work(work, header="✅ Status completed"))

        if action is KnowledgeAction.WORK_MINE:
            items = await self._service.work_mine(
                limit=payload.limit,
                offset=payload.offset,
            )
            if not items:
                return text("🎯 No work items assigned to you.")
            body = "\n\n".join(_format_work(item) for item in items)
            return text(f"🎯 **Your work items ({len(items)}):**\n\n{body}")

        if action is KnowledgeAction.WORK_CHILDREN:
            # Support both id and work_key
            work_id = payload.id
            if payload.work_key and not work_id:
                work_item = await self._service.work_get_by_key(payload.work_key)
                work_id = work_item.get("id")
            if not work_id:
                return text("❌ Provide id or work_key to list children.")
            items = await self._service.work_children(work_id)
            if not items:
                return text("👶 No child items found.")
            body = "\n\n".join(_format_work(item) for item in items)
            return text(f"👶 **Child work items ({len(items)}):**\n\n{body}")

        if action is KnowledgeAction.WORK_BULK_CREATE:
            if not payload.work_items:
                return text(
                    "❌ Provide work_items array. Each item requires: temp_id, title, item_type, work_category. "
                    "Optional: parent_temp_id OR parent_key (not both), description, priority, story_points, tags, due_date."
                )
            if len(payload.work_items) > 50:
                return text("❌ Maximum 50 items per bulk create.")

            # Validate required fields
            for i, item in enumerate(payload.work_items):
                if not item.get("temp_id"):
                    return text(f"❌ Item {i}: missing temp_id.")
                if not item.get("title"):
                    return text(f"❌ Item {i}: missing title.")
                if not item.get("item_type"):
                    return text(f"❌ Item {i}: missing item_type.")
                if not item.get("work_category"):
                    return text(f"❌ Item {i}: missing work_category.")
                if item.get("parent_temp_id") and item.get("parent_key"):
                    return text(
                        f"❌ Item {i}: cannot have both parent_temp_id and parent_key. Use one or the other."
                    )

            items = await self._service.work_bulk_create({"items": payload.work_items})

            # Format response as hierarchical tree
            lines = [f"✅ **{len(items)} work items created**", ""]

            # Build tree structure
            items_by_id: Dict[str, Dict[str, Any]] = {}
            children_map: Dict[str, List[str]] = {}
            root_ids: List[str] = []

            for item in items:
                item_id = item.get("id", "")
                items_by_id[item_id] = item
                parent_id = item.get("parent_id")
                if parent_id and parent_id in items_by_id:
                    if parent_id not in children_map:
                        children_map[parent_id] = []
                    children_map[parent_id].append(item_id)
                else:
                    root_ids.append(item_id)

            def format_tree_node(
                item_id: str, prefix: str = "", is_last: bool = True
            ) -> List[str]:
                """Format a node and its children as tree lines."""
                node_lines: List[str] = []
                item = items_by_id.get(item_id, {})
                key = item.get("key", "")
                title = item.get("title", "Untitled")
                item_type = item.get("item_type", "unknown")

                # Determine connector
                if prefix == "":
                    connector = ""
                    child_prefix = ""
                else:
                    connector = "└── " if is_last else "├── "
                    child_prefix = prefix + ("    " if is_last else "│   ")

                node_lines.append(f"{prefix}{connector}{item_type}: {key} - {title}")

                # Process children
                child_ids = children_map.get(item_id, [])
                for i, child_id in enumerate(child_ids):
                    is_last_child = i == len(child_ids) - 1
                    node_lines.extend(
                        format_tree_node(child_id, child_prefix, is_last_child)
                    )

                return node_lines

            # Format root items and their children
            for i, root_id in enumerate(root_ids):
                lines.extend(format_tree_node(root_id))
                if i < len(root_ids) - 1:
                    lines.append("")  # Add blank line between root trees

            # Summary by type
            type_counts: Dict[str, int] = {}
            for item in items:
                item_type = item.get("item_type", "unknown")
                type_counts[item_type] = type_counts.get(item_type, 0) + 1

            lines.append("")
            lines.append("**Summary by type:**")
            for item_type, count in sorted(type_counts.items()):
                lines.append(f"- {item_type}: {count}")

            return text("\n".join(lines))

        return text(
            "❌ Unsupported work item action.\n\nChoose one of the values:\n"
            + "\n".join(
                f"- `{value}`"
                for value in KnowledgeAction.choices()
                if value.startswith("work_")
            )
        )

    # ------------------------------------------------------------------
    # Boards
    # ------------------------------------------------------------------
    async def _run_board(self, payload: KnowledgeRequest):
        action = payload.action
        if action is KnowledgeAction.BOARD_LIST:
            boards = await self._service.board_list(
                limit=payload.limit, offset=payload.offset
            )
            if not boards:
                return text("🗂️ No boards found.")
            body = "\n\n".join(_format_board(board) for board in boards)
            return text(f"🗂️ **Boards ({len(boards)}):**\n\n{body}")

        if action is KnowledgeAction.BOARD_FAVORITES:
            boards = await self._service.board_favorites()
            if not boards:
                return text("⭐ No favorite boards registered.")
            body = "\n\n".join(_format_board(board) for board in boards)
            return text(f"⭐ **Favorite boards ({len(boards)}):**\n\n{body}")

        if action is KnowledgeAction.BOARD_GET:
            if not payload.board_id:
                return text("❌ Provide board_id to get details.")
            board = await self._service.board_get(payload.board_id)
            return text(_format_board(board, header="🗂️ Board details"))

        if action is KnowledgeAction.BOARD_COLUMNS:
            if not payload.board_id:
                return text("❌ Provide board_id to list columns.")
            columns = await self._service.board_columns(payload.board_id)
            if not columns:
                return text("📊 Board has no columns registered.")
            body = "\n".join(
                f"- {col.get('name', 'Unnamed')} (ID: {col.get('id')})"
                for col in columns
            )
            return text(f"📊 **Board columns:**\n{body}")

        return text(
            "❌ Unsupported board action.\n\nChoose one of the values:\n"
            + "\n".join(
                f"- `{value}`"
                for value in KnowledgeAction.choices()
                if value.startswith("board_")
            )
        )

    # ------------------------------------------------------------------
    # Sprints
    # ------------------------------------------------------------------
    async def _run_sprint(self, payload: KnowledgeRequest):
        action = payload.action
        if action is KnowledgeAction.SPRINT_LIST:
            sprints = await self._service.sprint_list(
                limit=payload.limit, offset=payload.offset
            )
            if not sprints:
                return text("🏃 No sprints found.")
            body = "\n\n".join(_format_sprint(sprint) for sprint in sprints)
            return text(f"🏃 **Sprints ({len(sprints)}):**\n\n{body}")

        if action is KnowledgeAction.SPRINT_ACTIVE:
            try:
                sprint = await self._service.sprint_active()
            except Exception:
                sprint = {}
            if not sprint:
                return text("⏳ No active sprint at the moment.")
            return text(_format_sprint(sprint, header="⏳ Active sprint"))

        if action is KnowledgeAction.SPRINT_GET:
            if not payload.sprint_id:
                return text("❌ Provide sprint_id to get details.")
            sprint = await self._service.sprint_get(payload.sprint_id)
            return text(_format_sprint(sprint, header="🏃 Sprint details"))

        if action is KnowledgeAction.SPRINT_WORK_ITEMS:
            if not payload.sprint_id:
                return text("❌ Provide sprint_id to list items.")
            items = await self._service.sprint_work_items(payload.sprint_id)
            if not items:
                return text("🏃 No items linked to the specified sprint.")
            body = "\n\n".join(_format_work(item) for item in items)
            return text(f"🏃 **Sprint items ({len(items)}):**\n\n{body}")

        return text(
            "❌ Unsupported sprint action.\n\nChoose one of the values:\n"
            + "\n".join(
                f"- `{value}`"
                for value in KnowledgeAction.choices()
                if value.startswith("sprint_")
            )
        )

    # ------------------------------------------------------------------
    # Rules
    # ------------------------------------------------------------------
    async def _run_rule(self, payload: KnowledgeRequest):
        action = payload.action

        if action is KnowledgeAction.RULE_CREATE:
            if not payload.rule_name:
                return text("❌ Provide rule_name to create the rule.")
            if not payload.rule_content:
                return text("❌ Provide rule_content to create the rule.")
            if not payload.rule_scope:
                return text(
                    "❌ Provide rule_scope to create the rule. "
                    "Values: personal, team, organization, marketplace."
                )
            if payload.rule_scope == "team" and not payload.rule_team_id:
                return text("❌ Provide rule_team_id for team-scoped rules.")
            if not payload.rule_category:
                return text(
                    "❌ Provide rule_category to create the rule. "
                    "Values: frontend, backend, mobile, fullstack, devops, infrastructure, "
                    "architecture, code_review, testing, security, documentation, performance, other."
                )

            rule = await self._service.rule_create(
                {
                    "scope": payload.rule_scope,
                    "name": payload.rule_name,
                    "slug": sanitize_null(payload.rule_slug),
                    "description": sanitize_null(payload.rule_description),
                    "content": payload.rule_content,
                    "team_id": sanitize_null(payload.rule_team_id),
                    "category": payload.rule_category,
                }
            )
            return text(_format_rule(rule, header="✅ Rule created"))

        if action is KnowledgeAction.RULE_LIST:
            rules = await self._service.rule_list(
                limit=payload.limit,
                offset=payload.offset,
                scope=sanitize_null(payload.rule_scope),
                query=sanitize_null(payload.query),
            )
            if not rules:
                return text("📜 No rules found.")
            body = "\n\n".join(_format_rule(rule) for rule in rules)
            return text(f"📜 **Rules ({len(rules)}):**\n\n{body}")

        if action is KnowledgeAction.RULE_GET:
            rule_id = payload.rule_id or payload.id
            if not rule_id:
                return text("❌ Provide rule_id or id to get the rule.")
            rule = await self._service.rule_get(rule_id)
            return text(_format_rule(rule, header="📜 Rule details", show_content=True))

        if action is KnowledgeAction.RULE_UPDATE:
            rule_id = payload.rule_id or payload.id
            if not rule_id:
                return text("❌ Provide rule_id or id to update the rule.")
            rule = await self._service.rule_update(
                rule_id,
                {
                    "name": sanitize_null(payload.rule_name),
                    "description": sanitize_null(payload.rule_description),
                    "content": sanitize_null(payload.rule_content),
                    "is_active": payload.rule_is_active,
                    "category": sanitize_null(payload.rule_category),
                },
            )
            return text(_format_rule(rule, header="✅ Rule updated"))

        if action is KnowledgeAction.RULE_DELETE:
            rule_id = payload.rule_id or payload.id
            if not rule_id:
                return text("❌ Provide rule_id or id to delete the rule.")
            await self._service.rule_delete(rule_id)
            return text(f"🗑️ Rule {rule_id} removed.")

        if action is KnowledgeAction.RULE_MARKETPLACE:
            rules = await self._service.rule_marketplace(
                limit=payload.limit,
                offset=payload.offset,
                query=sanitize_null(payload.query),
            )
            if not rules:
                return text("🏪 No marketplace rules found.")
            body = "\n\n".join(_format_marketplace_rule(rule) for rule in rules)
            return text(f"🏪 **Marketplace Rules ({len(rules)}):**\n\n{body}")

        if action is KnowledgeAction.RULE_FORK:
            rule_id = payload.rule_id or payload.id
            if not rule_id:
                return text("❌ Provide rule_id or id to fork the rule.")
            if not payload.rule_scope:
                return text(
                    "❌ Provide rule_scope for the forked rule. "
                    "Values: personal, team, organization."
                )
            rule = await self._service.rule_fork(
                rule_id,
                {
                    "scope": payload.rule_scope,
                    "name": sanitize_null(payload.rule_name),
                    "team_id": sanitize_null(payload.rule_team_id),
                    "category": sanitize_null(payload.rule_category),
                },
            )
            return text(_format_rule(rule, header="✅ Rule forked"))

        if action is KnowledgeAction.RULE_EXPORT:
            rule_id = payload.rule_id or payload.id
            if not rule_id:
                return text("❌ Provide rule_id or id to export the rule.")
            if not payload.rule_export_format:
                return text(
                    "❌ Provide rule_export_format. "
                    "Values: cursor, claude, copilot, windsurf."
                )
            content = await self._service.rule_export(
                rule_id, payload.rule_export_format
            )
            return text(
                f"📤 **Export ({payload.rule_export_format}):**\n\n```\n{content}\n```"
            )

        return text(
            "❌ Unsupported rule action.\n\nChoose one of the values:\n"
            + "\n".join(
                f"- `{value}`"
                for value in KnowledgeAction.choices()
                if value.startswith("rule_")
            )
        )

    # ------------------------------------------------------------------
    # Documentation
    # ------------------------------------------------------------------
    async def _run_doc(self, payload: KnowledgeRequest):
        action = payload.action
        if action is KnowledgeAction.DOC_CREATE:
            if not payload.doc_title:
                return text("❌ Provide doc_title to create the documentation.")
            if payload.doc_type and payload.doc_type not in _ALLOWED_DOC_TYPES:
                allowed = ", ".join(sorted(_ALLOWED_DOC_TYPES))
                return text(
                    "❌ Invalid doc_type. Use one of the supported values: " + allowed
                )
            # Emoji is required for page, api_doc, guide (not for folder)
            doc_type = sanitize_null(payload.doc_type) or "page"
            emoji = sanitize_null(payload.doc_emoji or payload.doc_emote)
            if doc_type != "folder" and not emoji:
                return text(
                    "❌ Provide doc_emoji to create documentation. "
                    "Emoji is required for page, api_doc, and guide types."
                )
            doc = await self._service.doc_create(
                {
                    "title": payload.doc_title,
                    "description": sanitize_null(payload.doc_description),
                    "content": sanitize_null(payload.doc_content),
                    "status": sanitize_null(payload.doc_status),
                    "doc_type": sanitize_null(payload.doc_type),
                    "language": sanitize_null(payload.doc_language),
                    "parent_id": sanitize_null(payload.doc_parent_id),
                    "owner_user_id": sanitize_null(payload.doc_owner_id),
                    "reviewer_user_id": sanitize_null(payload.doc_reviewer_id),
                    "version": sanitize_null(payload.doc_version),
                    "category": sanitize_null(payload.doc_category),
                    "tags": sanitize_null_list(payload.doc_tags),
                    "emoji": sanitize_null(payload.doc_emoji or payload.doc_emote),
                    "keywords": sanitize_null_list(payload.doc_keywords),
                    "is_public": payload.doc_is_public,
                }
            )
            return text(_format_doc(doc, header="✅ Documentation created"))

        if action is KnowledgeAction.DOC_LIST:
            docs = await self._service.doc_list(
                limit=payload.limit,
                offset=payload.offset,
                returnContent=payload.return_content,
            )
            if not docs:
                return text("📄 No documentation found.")
            body = "\n\n".join(_format_doc(doc) for doc in docs)
            return text(f"📄 **Documents ({len(docs)}):**\n\n{body}")

        if action is KnowledgeAction.DOC_GET:
            if not payload.id:
                return text("❌ Provide the documentation ID.")
            doc = await self._service.doc_get(payload.id)
            return text(
                _format_doc(doc, header="📄 Documentation details", show_content=True)
            )

        if action is KnowledgeAction.DOC_UPDATE:
            if not payload.id:
                return text("❌ Provide the documentation ID.")
            if payload.doc_type and payload.doc_type not in _ALLOWED_DOC_TYPES:
                allowed = ", ".join(sorted(_ALLOWED_DOC_TYPES))
                return text(
                    "❌ Invalid doc_type. Use one of the supported values: " + allowed
                )
            doc = await self._service.doc_update(
                payload.id,
                {
                    "title": sanitize_null(payload.doc_title),
                    "description": sanitize_null(payload.doc_description),
                    "content": sanitize_null(payload.doc_content),
                    "status": sanitize_null(payload.doc_status),
                    "doc_type": sanitize_null(payload.doc_type),
                    "language": sanitize_null(payload.doc_language),
                    "parent_id": sanitize_null(payload.doc_parent_id),
                    "owner_user_id": sanitize_null(payload.doc_owner_id),
                    "reviewer_user_id": sanitize_null(payload.doc_reviewer_id),
                    "version": sanitize_null(payload.doc_version),
                    "category": sanitize_null(payload.doc_category),
                    "tags": sanitize_null_list(payload.doc_tags),
                    "emoji": sanitize_null(payload.doc_emoji or payload.doc_emote),
                    "keywords": sanitize_null_list(payload.doc_keywords),
                    "is_public": payload.doc_is_public,
                },
            )
            return text(_format_doc(doc, header="✅ Documentation updated"))

        if action is KnowledgeAction.DOC_DELETE:
            if not payload.id:
                return text("❌ Provide the documentation ID.")
            await self._service.doc_delete(payload.id)
            return text(f"🗑️ Documentation {payload.id} removed.")

        if action is KnowledgeAction.DOC_ROOTS:
            docs = await self._service.doc_roots()
            if not docs:
                return text("📚 No roots found.")
            body = "\n".join(
                f"- {doc.get('title', 'Untitled')} (ID: {doc.get('id')})"
                for doc in docs
            )
            return text(f"📚 **Documentation roots:**\n{body}")

        if action is KnowledgeAction.DOC_RECENT:
            docs = await self._service.doc_recent(
                limit=payload.limit,
            )
            if not docs:
                return text("🕒 No recent documentation found.")
            body = "\n\n".join(_format_doc(doc) for doc in docs)
            return text(f"🕒 **Recent documents ({len(docs)}):**\n\n{body}")

        if action is KnowledgeAction.DOC_ANALYTICS:
            analytics = await self._service.doc_analytics()
            return text(_format_doc_analytics(analytics))

        if action is KnowledgeAction.DOC_CHILDREN:
            if not payload.id:
                return text("❌ Provide the documentation ID.")
            docs = await self._service.doc_children(payload.id)
            if not docs:
                return text("📄 No children registered for the specified document.")
            body = "\n".join(
                f"- {doc.get('title', 'Untitled')} (ID: {doc.get('id')})"
                for doc in docs
            )
            return text(f"📄 **Children:**\n{body}")

        if action is KnowledgeAction.DOC_TREE:
            if not payload.id:
                return text("❌ Provide the documentation ID.")
            tree = await self._service.doc_tree(payload.id)
            formatted = _format_doc_tree_nested(tree)
            return text(f"🌳 **Documentation tree for {payload.id}:**\n\n{formatted}")

        if action is KnowledgeAction.DOC_FULL_TREE:
            tree = await self._service.doc_full_tree()
            formatted = _format_doc_tree_flat(tree)
            return text(f"🌳 **Full documentation tree:**\n\n{formatted}")

        if action is KnowledgeAction.DOC_MOVE:
            if not payload.id:
                return text("❌ Provide the documentation ID.")
            if payload.doc_parent_id is None and payload.doc_position is None:
                return text("❌ Provide doc_parent_id, doc_position or both to move.")
            move_payload = {
                "new_parent_id": payload.doc_parent_id,
                "new_position": payload.doc_position,
            }
            doc = await self._service.doc_move(payload.id, move_payload)
            return text(_format_doc(doc, header="📦 Documentation moved"))

        if action is KnowledgeAction.DOC_PUBLISH:
            if not payload.id:
                return text("❌ Provide the documentation ID.")
            result = await self._service.doc_publish(payload.id)
            return text(f"🗞️ Document published: {result}")

        if action is KnowledgeAction.DOC_VERSION:
            if not payload.id:
                return text("❌ Provide the documentation ID.")
            if not payload.doc_version:
                return text(
                    "❌ Provide doc_version with the version number/identifier."
                )
            version_payload = {
                "title": payload.doc_title or f"Version {payload.doc_version}",
                "version": payload.doc_version,
                "content": payload.doc_content,
            }
            doc = await self._service.doc_version(payload.id, version_payload)
            return text(_format_doc(doc, header="🗞️ New version created"))

        if action is KnowledgeAction.DOC_DUPLICATE:
            if not payload.id:
                return text("❌ Provide the documentation ID.")
            if not payload.doc_title:
                return text("❌ Provide doc_title to name the copy.")
            doc = await self._service.doc_duplicate(
                payload.id,
                {
                    "title": payload.doc_title,
                },
            )
            return text(_format_doc(doc, header="🗂️ Document duplicated"))

        return text(
            "❌ Unsupported documentation action.\n\nChoose one of the values:\n"
            + "\n".join(
                f"- `{value}`"
                for value in KnowledgeAction.choices()
                if value.startswith("doc_")
            )
        )

    # ------------------------------------------------------------------
    # API Catalog
    # ------------------------------------------------------------------
    async def _run_api_catalog(self, payload: KnowledgeRequest):
        action = payload.action

        if action is KnowledgeAction.API_CATALOG_SEARCH:
            query = sanitize_null(payload.query)
            if not query:
                return text("❌ Provide query to search APIs.")

            result = await self._service.api_catalog_search(
                query=query,
                limit=payload.limit,
            )

            data = result.get("data", [])
            if not data:
                return text(
                    f"🔍 No APIs found for: **{query}**\n\n"
                    "Try a different search term or use `api_catalog_list` to see all APIs."
                )

            body = "\n\n".join(_format_api_search_result(api) for api in data)
            total = len(data)

            return text(f"🔍 **APIs found for '{query}'** ({total} results)\n\n{body}")

        if action is KnowledgeAction.API_CATALOG_LIST:
            apis = await self._service.api_catalog_list(
                limit=payload.limit,
                offset=payload.offset,
            )

            if not apis:
                return text("📚 No APIs found in the catalog.")

            body = "\n\n".join(_format_api_item(api) for api in apis)
            return text(f"📚 **API Catalog ({len(apis)} APIs)**\n\n{body}")

        if action is KnowledgeAction.API_CATALOG_GET:
            spec_id = payload.api_spec_id or payload.id
            if not spec_id:
                return text("❌ Provide api_spec_id or id to get the API details.")

            api = await self._service.api_catalog_get(spec_id)
            return text(_format_api_detail(api))

        return text(
            "❌ Unsupported API Catalog action.\n\nChoose one of the values:\n"
            + "\n".join(
                f"- `{value}`"
                for value in KnowledgeAction.choices()
                if value.startswith("api_catalog_")
            )
        )

    async def _handle_switch_team(self, payload: KnowledgeRequest):
        team_id = payload.id
        if not team_id:
            return text("❌ Provide `id` with the team UUID to switch to.")

        # Call backend to validate membership and invalidate cache
        try:
            result = await self._service._call(
                self._service.api.switch_team, str(team_id)
            )
        except Exception as exc:
            return text(f"❌ Could not switch team: {exc}")

        team_name = (result or {}).get("team", {}).get("name", "Unknown")

        # Update context
        self._context.active_team_id = str(team_id)
        self._context.active_team_name = team_name
        self._context.api_client.set_active_team(str(team_id))

        return text(
            f"✅ Active team switched to **{team_name}** (`{team_id}`).\n\n"
            "All subsequent operations (work items, docs, boards, sprints, rules) "
            "will be created in this team."
        )

    async def _handle_help(self):
        workflow_guide = """
## 📖 How to find and read a document

1. **doc_full_tree** → See complete folder structure with IDs
2. **doc_children(id)** → List contents of a specific folder
3. **doc_get(id)** → Read the document content

Example: To find "Overview" inside "Architecture" folder:
1. Call `doc_full_tree` to see all folders and documents
2. Find the folder "Architecture" and note its ID
3. Call `doc_children` with that ID to list its contents
4. Find "Overview" document and note its ID
5. Call `doc_get` with that ID to read the content

"""
        return text(
            "📚 **Available actions for knowledge**\n\n"
            + workflow_guide
            + KnowledgeAction.formatted_help()
        )


def _format_doc_tree_flat(data: Any) -> str:
    """Format a flat list of docs (with parent_id) into a visual tree."""
    items: List[Dict[str, Any]] = []
    if isinstance(data, list):
        items = data
    elif isinstance(data, dict):
        nested = data.get("data") or data.get("children") or data.get("items")
        if isinstance(nested, list):
            items = nested
        else:
            # Single root dict — treat as nested tree
            return _format_doc_tree_nested(data)

    if not items:
        return "(empty)"

    # Build parent→children map
    by_id: Dict[str, Dict[str, Any]] = {}
    children_map: Dict[Optional[str], List[str]] = {}
    for item in items:
        item_id = item.get("id", "")
        by_id[item_id] = item
        parent = item.get("parent_id")
        children_map.setdefault(parent, []).append(item_id)

    # Find roots (parent_id is None or not present in by_id)
    root_ids = [
        item_id
        for item_id, item in by_id.items()
        if item.get("parent_id") is None or item.get("parent_id") not in by_id
    ]

    lines: List[str] = []

    def _render_node(
        item_id: str, prefix: str, connector: str, child_prefix: str
    ) -> None:
        item = by_id.get(item_id, {})
        emoji = item.get("emoji") or item.get("emote") or ""
        title = item.get("title") or item.get("name") or "Untitled"
        doc_type = item.get("doc_type") or item.get("type") or ""
        iid = item.get("id", "")

        label = f"{emoji} {title}".strip()
        if doc_type:
            label += f" ({doc_type})"
        label += f" — ID: {iid}"
        lines.append(f"{prefix}{connector}{label}")

        child_ids = children_map.get(item_id, [])
        for i, cid in enumerate(child_ids):
            is_last_child = i == len(child_ids) - 1
            c = "└── " if is_last_child else "├── "
            cp = child_prefix + ("    " if is_last_child else "│   ")
            _render_node(cid, child_prefix, c, cp)

    for i, rid in enumerate(root_ids):
        _render_node(rid, "", "", "")
        if i < len(root_ids) - 1:
            lines.append("")

    return "\n".join(lines)


def _format_doc_tree_nested(data: Any) -> str:
    """Format a nested dict with 'children' arrays into a visual tree."""
    if not data:
        return "(empty)"

    # If data is a list, delegate to flat formatter
    if isinstance(data, list):
        return _format_doc_tree_flat(data)

    if not isinstance(data, dict):
        return "(empty)"

    # Unwrap if the tree is inside a 'data', 'children', or 'items' key
    # and the root dict itself has no 'title'/'id' (i.e., it's just a wrapper)
    if not data.get("id") and not data.get("title"):
        nested = data.get("data") or data.get("children") or data.get("items")
        if isinstance(nested, list):
            return _format_doc_tree_flat(nested)
        if isinstance(nested, dict):
            data = nested

    if not data.get("id") and not data.get("title"):
        return "(empty)"

    lines: List[str] = []

    def _render(
        node: Dict[str, Any], prefix: str, connector: str, child_prefix: str
    ) -> None:
        emoji = node.get("emoji") or node.get("emote") or ""
        title = node.get("title") or node.get("name") or "Untitled"
        doc_type = node.get("doc_type") or node.get("type") or ""
        iid = node.get("id", "")

        label = f"{emoji} {title}".strip()
        if doc_type:
            label += f" ({doc_type})"
        label += f" — ID: {iid}"
        lines.append(f"{prefix}{connector}{label}")

        children = node.get("children", [])
        if isinstance(children, list):
            valid = [c for c in children if isinstance(c, dict)]
            for i, child in enumerate(valid):
                is_last_child = i == len(valid) - 1
                c = "└── " if is_last_child else "├── "
                cp = child_prefix + ("    " if is_last_child else "│   ")
                _render(child, child_prefix, c, cp)

    _render(data, "", "", "")
    return "\n".join(lines)


def _extract_name_count(item: Dict[str, Any]) -> tuple:
    """Extract a (name, count) pair from a Prisma groupBy-style dict.

    Prisma groupBy returns fields like {doc_type: "page", _count: 5}
    or {author_user_id: "uuid", _count: 3}.
    """
    # Try known count keys (Prisma uses _count)
    count = None
    for key in ("_count", "count", "total", "value"):
        val = item.get(key)
        if val is not None and isinstance(val, (int, float)):
            count = val
            break
    # _count can also be a dict like {author_user_id: 3}
    raw_count = item.get("_count")
    if count is None and isinstance(raw_count, dict):
        for v in raw_count.values():
            if isinstance(v, (int, float)):
                count = v
                break

    # Try known name keys
    name = None
    for key in (
        "doc_type",
        "type",
        "name",
        "author",
        "author_user_id",
        "label",
        "title",
    ):
        val = item.get(key)
        if val is not None and isinstance(val, str) and val:
            name = val
            break

    # Fallback: first string value
    if name is None:
        for key, val in item.items():
            if key.startswith("_"):
                continue
            if isinstance(val, str) and val:
                name = val
                break

    return (name or "?", count if count is not None else "?")


def _format_doc_analytics(analytics: Dict[str, Any]) -> str:
    """Format doc analytics into a readable summary."""
    lines = ["📊 **Documentation Analytics**", ""]

    # Simple scalar fields
    simple_keys = {
        "total",
        "published",
        "drafts",
        "inReview",
        "in_review",
        "archived",
        "folders",
        "pages",
        "guides",
    }
    for key, value in analytics.items():
        if key in simple_keys and not isinstance(value, (dict, list)):
            lines.append(f"- **{key}**: {value}")

    # byType
    by_type = analytics.get("byType")
    if by_type is None:
        by_type = analytics.get("by_type")
    if isinstance(by_type, dict):
        parts = [f"{k}: {v}" for k, v in by_type.items()]
        if parts:
            lines.append(f"- **By type**: {', '.join(parts)}")
    elif isinstance(by_type, list):
        parts = []
        for item in by_type:
            if isinstance(item, dict):
                name, count = _extract_name_count(item)
                parts.append(f"{name}: {count}")
        if parts:
            lines.append(f"- **By type**: {', '.join(parts)}")

    # byAuthor
    by_author = analytics.get("byAuthor")
    if by_author is None:
        by_author = analytics.get("by_author")
    if isinstance(by_author, list):
        author_parts = []
        for item in by_author:
            if isinstance(item, dict):
                # Prisma groupBy returns {author_user_id, _count}
                # Try nested author object first, then fall back to ID
                author_obj = item.get("author")
                if isinstance(author_obj, dict):
                    name = author_obj.get("name") or author_obj.get("email") or "?"
                else:
                    uid = item.get("author_user_id") or ""
                    name = uid[:8] + "…" if len(uid) > 8 else uid or "?"
                _, count = _extract_name_count(item)
                author_parts.append(f"{name} ({count})")
        if author_parts:
            lines.append("")
            lines.append("**By author:**")
            for part in author_parts[:10]:
                lines.append(f"- {part}")
            if len(author_parts) > 10:
                lines.append(f"  ... and {len(author_parts) - 10} more")

    # recentlyUpdated
    recent = analytics.get("recentlyUpdated")
    if recent is None:
        recent = analytics.get("recently_updated")
    if isinstance(recent, list) and recent:
        lines.append("")
        lines.append("**Recently updated:**")
        for item in recent[:10]:
            if isinstance(item, dict):
                emoji = item.get("emoji") or item.get("emote") or ""
                title = item.get("title") or item.get("name") or "Untitled"
                updated = _format_date(item.get("updated_at") or item.get("updatedAt"))
                label = f"{emoji} {title}".strip()
                lines.append(f"- {label} ({updated})")
        if len(recent) > 10:
            lines.append(f"  ... and {len(recent) - 10} more")

    # Catch any remaining keys not yet handled
    handled = simple_keys | {
        "byType",
        "by_type",
        "byAuthor",
        "by_author",
        "recentlyUpdated",
        "recently_updated",
    }
    for key, value in analytics.items():
        if key not in handled and not isinstance(value, (dict, list)):
            lines.append(f"- **{key}**: {value}")

    return "\n".join(lines)


def _format_work(
    item: Dict[str, Any],
    *,
    header: Optional[str] = None,
    show_description: bool = False,
) -> str:
    lines: List[str] = []
    if header:
        lines.append(header)
        lines.append("")

    # Extract key (e.g., DVPT-0001)
    key = item.get("key", "")

    # Extract title
    title = item.get("title") or item.get("name") or "Untitled"

    # Extract type
    item_type = item.get("item_type") or item.get("type") or "unknown"

    # Extract status - prefer status object with name, fallback to status_id
    status_obj = item.get("status")
    if isinstance(status_obj, dict):
        status = status_obj.get("name", "unknown")
    else:
        status = item.get("status_id") or status_obj or "unknown"

    # Extract priority
    priority = item.get("priority") or item.get("priority_level") or "undefined"

    # Extract ID
    item_id = item.get("id", "N/A")

    # Extract assignee - check both assignee_id and assignee object
    assignee = item.get("assignee_id")
    if not assignee and item.get("assignee"):
        assignee_obj = item.get("assignee", {})
        assignee = assignee_obj.get("name") or assignee_obj.get("id")
    if not assignee:
        assignee = "N/A"

    # Format title line with key if available
    if key:
        lines.append(f"🎯 **[{key}] {title}**")
    else:
        lines.append(f"🎯 **{title}**")

    lines.extend(
        [
            f"ID: {item_id}",
            f"Type: {item_type}",
            f"Status: {status}",
            f"Priority: {priority}",
            f"Assignee: {assignee}",
        ]
    )

    # Add key as separate line if present (for easy reference)
    if key:
        lines.append(f"Key: {key}")

    if item.get("due_date") or item.get("dueDate"):
        lines.append(
            f"Due date: {_format_date(item.get('due_date') or item.get('dueDate'))}"
        )
    if item.get("tags"):
        tags = item.get("tags", [])
        if tags:
            lines.append(f"Tags: {', '.join(tags)}")

    # Show description only when explicitly requested (e.g., work_get)
    if show_description and item.get("description"):
        lines.append("")
        lines.append("**Description:**")
        lines.append(item.get("description"))

    return "\n".join(lines)


def _format_board(board: Dict[str, Any], header: Optional[str] = None) -> str:
    lines: List[str] = []
    if header:
        lines.append(header)
        lines.append("")
    lines.extend(
        [
            f"🗂️ **{board.get('name', 'Unnamed')}**",
            f"ID: {board.get('id', 'N/A')}",
            f"Team: {board.get('team_id', 'N/A')}",
            f"Columns: {len(board.get('columns', []))}",
        ]
    )
    return "\n".join(lines)


def _format_sprint(sprint: Dict[str, Any], header: Optional[str] = None) -> str:
    lines: List[str] = []
    if header:
        lines.append(header)
        lines.append("")
    lines.extend(
        [
            f"🏃 **{sprint.get('name', 'Unnamed')}**",
            f"ID: {sprint.get('id', 'N/A')}",
            f"Status: {sprint.get('status', 'N/A')}",
            f"Team: {sprint.get('team_id', 'N/A')}",
        ]
    )
    if sprint.get("start_date") or sprint.get("startDate"):
        lines.append(
            f"Start: {_format_date(sprint.get('start_date') or sprint.get('startDate'))}"
        )
    if sprint.get("end_date") or sprint.get("endDate"):
        lines.append(
            f"End: {_format_date(sprint.get('end_date') or sprint.get('endDate'))}"
        )
    return "\n".join(lines)


def _format_doc(
    doc: Dict[str, Any],
    *,
    header: Optional[str] = None,
    show_content: bool = False,
) -> str:
    lines: List[str] = []
    if header:
        lines.append(header)
        lines.append("")
    lines.extend(
        [
            f"📄 **{doc.get('title') or doc.get('name', 'Untitled')}**",
            f"ID: {doc.get('id', 'N/A')}",
            f"Status: {doc.get('status', 'N/A')}",
            f"Team: {doc.get('team_id', 'N/A')}",
        ]
    )
    if doc.get("updated_at") or doc.get("updatedAt"):
        lines.append(
            f"Updated at: {_format_date(doc.get('updated_at') or doc.get('updatedAt'))}"
        )

    # Show content only when explicitly requested (e.g., doc_get)
    if show_content and doc.get("content"):
        lines.append("")
        lines.append("**Content:**")
        lines.append(doc.get("content"))

    return "\n".join(lines)


def _format_rule(
    rule: Dict[str, Any],
    *,
    header: Optional[str] = None,
    show_content: bool = False,
) -> str:
    lines: List[str] = []
    if header:
        lines.append(header)
        lines.append("")

    name = rule.get("name", "Untitled")
    scope = rule.get("scope", "unknown")
    scope_emoji = {
        "personal": "👤",
        "team": "👥",
        "organization": "🏢",
        "marketplace": "🌍",
    }.get(scope, "📜")

    lines.extend(
        [
            f"{scope_emoji} **{name}**",
            f"ID: {rule.get('id', 'N/A')}",
            f"Scope: {scope}",
            f"Version: {rule.get('version', '1.0')}",
        ]
    )

    if rule.get("description"):
        lines.append(f"Description: {rule.get('description')}")

    # Author info
    author = rule.get("author")
    if isinstance(author, dict):
        lines.append(f"Author: {author.get('name', 'Unknown')}")

    # Forked from info
    forked_from = rule.get("forked_from")
    if isinstance(forked_from, dict):
        forked_author = forked_from.get("author", {})
        author_name = (
            forked_author.get("name", "Unknown")
            if isinstance(forked_author, dict)
            else "Unknown"
        )
        lines.append(
            f"Forked from: {forked_from.get('name', 'Unknown')} by {author_name}"
        )

    if rule.get("is_active") is False:
        lines.append("Status: Inactive")

    if rule.get("updated_at") or rule.get("updatedAt"):
        lines.append(
            f"Updated: {_format_date(rule.get('updated_at') or rule.get('updatedAt'))}"
        )

    # Show content only when explicitly requested
    if show_content and rule.get("content"):
        lines.append("")
        lines.append("**Content:**")
        lines.append(rule.get("content"))

    return "\n".join(lines)


def _format_marketplace_rule(rule: Dict[str, Any]) -> str:
    """Format a marketplace rule with download/rating info."""
    lines: List[str] = []

    name = rule.get("name", "Untitled")
    downloads = rule.get("downloads", 0)
    rating = rule.get("rating")

    lines.append(f"🌍 **{name}**")
    lines.append(f"ID: {rule.get('id', 'N/A')}")

    if rule.get("description"):
        lines.append(f"Description: {rule.get('description')}")

    # Author info
    author = rule.get("author")
    if isinstance(author, dict):
        lines.append(f"Author: {author.get('name', 'Unknown')}")

    # Stats
    stats_parts = [f"⬇️ {downloads}"]
    if rating is not None:
        stats_parts.append(f"⭐ {float(rating):.1f}")
    lines.append(" | ".join(stats_parts))

    return "\n".join(lines)


def _format_api_search_result(api: Dict[str, Any]) -> str:
    """Format an API search result with similarity and matched endpoint."""
    lines: List[str] = []

    title = api.get("title", "Untitled API")
    slug = api.get("slug", "")
    similarity = api.get("similarity")

    # Title with similarity
    if similarity is not None:
        pct = float(similarity) * 100
        lines.append(f"🔗 **{title}** ({pct:.0f}% match)")
    else:
        lines.append(f"🔗 **{title}**")

    lines.append(f"Slug: {slug}")

    # Status
    status = api.get("lifecycle_status", "unknown")
    lines.append(f"Status: {status}")

    # Description (truncated)
    desc = api.get("description")
    if desc:
        truncated = desc[:150] + "..." if len(desc) > 150 else desc
        lines.append(f"Description: {truncated}")

    # Team info
    team = api.get("team")
    if isinstance(team, dict):
        lines.append(f"Team: {team.get('name', 'Unknown')}")

    # Matched endpoint (for semantic search)
    matched = api.get("matchedEndpoint")
    if matched:
        method = matched.get("method", "").upper()
        path = matched.get("path", "")
        summary = matched.get("summary", "")
        lines.append(f"Best match: **{method} {path}**")
        if summary:
            lines.append(f"  └─ {summary}")

    # Current version
    version = api.get("current_version")
    if isinstance(version, dict):
        lines.append(f"Version: {version.get('version', 'N/A')}")

    return "\n".join(lines)


def _format_api_item(api: Dict[str, Any]) -> str:
    """Format an API item for listing."""
    lines: List[str] = []

    title = api.get("title", "Untitled API")
    slug = api.get("slug", "")
    status = api.get("lifecycle_status", "unknown")

    lines.append(f"📦 **{title}**")
    lines.append(f"ID: {api.get('id', 'N/A')}")
    lines.append(f"Slug: {slug}")
    lines.append(f"Status: {status}")

    # Tags
    tags = api.get("tags", [])
    if tags:
        lines.append(f"Tags: {', '.join(tags)}")

    # Team
    team = api.get("team")
    if isinstance(team, dict):
        lines.append(f"Team: {team.get('name', 'Unknown')}")

    # Version
    version = api.get("current_version")
    if isinstance(version, dict):
        lines.append(f"Version: {version.get('version', 'N/A')}")

    return "\n".join(lines)


def _format_api_detail(api: Dict[str, Any]) -> str:
    """Format detailed API specification view."""
    lines: List[str] = []

    title = api.get("title", "Untitled API")
    slug = api.get("slug", "")

    lines.append(f"📚 **{title}**")
    lines.append("")
    lines.append(f"ID: {api.get('id', 'N/A')}")
    lines.append(f"Slug: {slug}")
    lines.append(f"Status: {api.get('lifecycle_status', 'unknown')}")

    # Description
    desc = api.get("description")
    if desc:
        lines.append("")
        lines.append("**Description:**")
        lines.append(desc)

    # Tags
    tags = api.get("tags", [])
    if tags:
        lines.append("")
        lines.append(f"Tags: {', '.join(tags)}")

    # Team
    team = api.get("team")
    if isinstance(team, dict):
        lines.append(f"Team: {team.get('name', 'Unknown')}")

    # Current version
    version = api.get("current_version")
    if isinstance(version, dict):
        lines.append("")
        lines.append("**Current Version:**")
        lines.append(f"- Version: {version.get('version', 'N/A')}")
        lines.append(f"- OpenAPI: {version.get('openapi_version', 'N/A')}")

        # Endpoints from current version
        endpoints = version.get("endpoint_embeddings", [])
        if endpoints:
            lines.append(f"- Endpoints: {len(endpoints)}")
            lines.append("")
            lines.append("**Endpoints:**")
            for ep in endpoints[:10]:  # Limit to 10
                method = ep.get("method", "").upper()
                path = ep.get("path", "")
                summary = ep.get("summary", "")
                if summary:
                    lines.append(f"- **{method}** {path} - {summary}")
                else:
                    lines.append(f"- **{method}** {path}")
            if len(endpoints) > 10:
                lines.append(f"  ... and {len(endpoints) - 10} more endpoints")

    # Environments
    environments = api.get("environments", [])
    if environments:
        lines.append("")
        lines.append("**Environments:**")
        for env in environments:
            name = env.get("name", "Unnamed")
            url = env.get("base_url", "")
            lines.append(f"- {name}: {url}")

    # Permissions
    permissions = api.get("permissions", {})
    if permissions:
        lines.append("")
        lines.append("**Your Permissions:**")
        if permissions.get("canEdit"):
            lines.append("- ✅ Edit")
        if permissions.get("canDelete"):
            lines.append("- ✅ Delete")
        if permissions.get("canPublish"):
            lines.append("- ✅ Publish")
        if permissions.get("canManageVersions"):
            lines.append("- ✅ Manage Versions")

    return "\n".join(lines)


__all__ = ["KnowledgeTool", "KnowledgeAction"]
