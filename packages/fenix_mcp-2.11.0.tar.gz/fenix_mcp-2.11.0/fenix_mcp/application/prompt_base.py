# SPDX-License-Identifier: MIT
"""Base abstractions for MCP prompts."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class PromptArgument:
    """Defines an argument that a prompt accepts."""

    name: str
    description: str
    required: bool = False


@dataclass
class PromptMessage:
    """A single message in a prompt response."""

    role: str  # "user" or "assistant"
    text: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "role": self.role,
            "content": {"type": "text", "text": self.text},
        }


@dataclass
class PromptResult:
    """Result returned by prompts/get."""

    messages: List[PromptMessage] = field(default_factory=list)
    description: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        result: Dict[str, Any] = {
            "messages": [m.to_dict() for m in self.messages],
        }
        if self.description:
            result["description"] = self.description
        return result


class Prompt(ABC):
    """Interface implemented by all prompts."""

    name: str
    description: str
    arguments: List[PromptArgument] = []

    def schema(self) -> Dict[str, Any]:
        """Return JSON schema describing the prompt."""
        result: Dict[str, Any] = {
            "name": self.name,
            "description": self.description,
        }
        if self.arguments:
            result["arguments"] = [
                {
                    "name": arg.name,
                    "description": arg.description,
                    "required": arg.required,
                }
                for arg in self.arguments
            ]
        return result

    @abstractmethod
    def get_messages(self, arguments: Dict[str, Any]) -> PromptResult:
        """Generate prompt messages based on provided arguments."""
