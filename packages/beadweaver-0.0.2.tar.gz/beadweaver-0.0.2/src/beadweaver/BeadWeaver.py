"""

Bead weaver visualizes and edits small molecule topologies.

"""
# Standard Library
from pathlib import Path, PurePath

# Third Party Imports
import numpy as np
import matplotlib.pyplot as plt
import networkx as nx
import MDAnalysis as mda
from .bw_parser import BeadWeaverParser

class BondLength(mda.core.topologyattrs.AtomAttr):
    attrname = 'bondlengths'
    singular = 'bondlength'
    
class BondForce(mda.core.topologyattrs.AtomAttr):
    attrname = 'bondforces'
    singular = 'bondforce'
    
class ExternalBondLength(mda.core.topologyattrs.AtomAttr):
    attrname = 'Extbondlengths'
    singular = 'Extbondlength'
    
class ExternalBondForces(mda.core.topologyattrs.AtomAttr):
    attrname = 'Extbondforces'
    singular = 'Extbondforce'
  
class AngleValues(mda.core.topologyattrs.AtomAttr):
    attrname = 'anglevalues'
    singular = 'anglevalue'    
    
class AngleForce(mda.core.topologyattrs.AtomAttr):
    attrname = 'angleforces'
    singular = 'angleforce'
    
class ExternalAngleValues(mda.core.topologyattrs.AtomAttr):
    attrname = 'Extanglevalues'
    singular = 'Extanglevalue'    
    
class ExternalAngleForce(mda.core.topologyattrs.AtomAttr):
    attrname = 'Extangleforces'
    singular = 'Extangleforce'
    
class BeadWeaver:
    def __init__(
        self, bead_string, Structure_name, param_path=Path("itp_elements.dat")
    ):
        self.beadString = bead_string
        self.paramLibrary = {}
        if not isinstance(param_path, list):
            param_path=[param_path]
        for single_path in param_path:
            lib = BeadWeaverParser()
            if not isinstance(single_path, PurePath):
                single_path=Path(single_path)
            if single_path.suffix == ".dat":
                lib.extract_topology_parameters(single_path)
                self.paramLibrary.update(lib.parameter_library)
            elif single_path.suffix == ".itp":
                lib.itp_parser(single_path)
                self.paramLibrary.update(lib.itp_dict)
            else:
                raise ValueError("File must be a beadweaver .dat file or a .itp file")
        self.string_def = BeadWeaverParser.process_string(bead_string)
        self.Sturcture_name = Structure_name
        self.bead_info = None
        self.internal_bonds = None
        self.external_bonds = None
        self.internal_angles = None
        self.external_angles = None
        self.constraints = None

    def _extract_molecule_info(self, key):
        """
        Retrives the parameter information from a single structure.

        Parameters
        ----------
        key : str
            the name of the molecule whose information needs to be retrieved.

        Returns
        -------
        list
            contains all of the molecules bead types, Bead names, Charges and Masses.

        """

        param_key = key.split()[1]
        bead_type = self.paramLibrary[param_key]["BeadType"]
        bead = self.paramLibrary[param_key]["Bead"]
        charge = self.paramLibrary[param_key]["Charge"]
        mass = self.paramLibrary[param_key]["Mass"]
        return [bead_type, bead, charge, mass]

    def _bead_counter(self, all_structure_bead):
        """
        Counts bead names.

        Parameters
        ----------
        bead_data : list
            contains all of the bead types for each bead

        Returns
        -------
        atom_bead : list
            list of beads counted

        """

        head_counter = {"S": 0, "A": 0, "O": 0}
        atom_bead = []
        for elem in all_structure_bead:
            if elem in head_counter:
                head_counter[elem] += 1
                atom_bead.append(f"{elem}{head_counter[elem]:02d}")
            else:
                atom_bead.append(f"{elem}")
        return atom_bead

    def get_structure_info(self, bead_num=0):
        """
        Gets the parameter information for each bead within the entire structure.

        Parameters
        ----------
        bead_num : int, optional
            Total number of beads before the first bead in molecule. The default is 0.

        Returns
        -------
        None.

        """

        all_structure_bead_type = []
        all_structure_bead = []
        all_structure_charge = []
        all_structure_mass = []

        for key in self.string_def:
            beadtype, bead, charge, mass = self._extract_molecule_info(key)
            all_structure_bead_type.extend(beadtype)
            all_structure_bead.extend(bead)
            all_structure_charge.extend(charge)
            all_structure_mass.extend(mass)
            bead_num += len(beadtype)

        all_structure_bead = self._bead_counter(all_structure_bead)

        structure = mda.Universe.empty(n_atoms=bead_num)
        structure.add_TopologyAttr("type", all_structure_bead_type)
        structure.add_TopologyAttr("name", all_structure_bead)
        structure.add_TopologyAttr("resid", [1])
        structure.add_TopologyAttr("resnum", [1])
        structure.add_TopologyAttr("charge", all_structure_charge)
        structure.add_TopologyAttr("mass", all_structure_mass)
        self.bead_info = structure
        print(f"Atoms were added to the universe: {self.bead_info.atoms}")

    def _extract_molecule_bond_info(self, key, bead_num=0):
        """

        Extract internal bond topology from paramLibrary

        Parameters
        ----------
        key : str
            The molecule name to pass to the parameter dictionary.
        topology_parameters : dict
            All molecule parameters.
        bead_num : int, optional
            Total number of beads before the first bead in molecule. The default is 0.

        Returns
        -------
        internal_bond: list
            list containing tuples of the internal bonds between beads

        """

        internal_bond = []
        param_key = key.split()[1]
        if len(self.paramLibrary[param_key]["BeadType"]) > 1:
            internal_bond_con = self.paramLibrary[param_key]["BondCon"]
            for bc in internal_bond_con:
                connect = bc.split("-")
                bonds = (
                    int(connect[0]) + bead_num,
                    int(connect[1]) + bead_num,
                )
                internal_bond.append(bonds)
            internal_bond_length = list(
                map(float, self.paramLibrary[param_key]["BondNum"])
            )
            internal_bond_fc = list(
                map(float, self.paramLibrary[param_key]["BondFC"])
            )
            return [internal_bond, internal_bond_length, internal_bond_fc]
        else:
            return ["", "", ""]
        
    def _extract_molecule_constraint_info(self, key, bead_num=0):
        """

        Extract internal constraint topology from paramLibrary

        Parameters
        ----------
        key : str
            The molecule name to pass to the parameter dictionary.
        topology_parameters : dict
            All molecule parameters.
        bead_num : int, optional
            Total number of beads before the first bead in molecule. The default is 0.

        Returns
        -------
        internal_bond: list
            list containing tuples of the internal bonds between beads

        """

        internal_cons = []
        param_key = key.split()[1]
        if len(self.paramLibrary[param_key]["BeadType"]) > 1:
            internal_cons_con = self.paramLibrary[param_key]["ConsCon"]
            for bc in internal_cons_con:
                connect = bc.split("-")
                bonds = (
                    int(connect[0]) + bead_num,
                    int(connect[1]) + bead_num,
                )
                internal_cons.append(bonds)
            internal_cons_length = list(
                map(float, self.paramLibrary[param_key]["ConsNum"])
            )
            internal_cons_fc = list(
                map(float, self.paramLibrary[param_key]["ConsFC"])
            )
            return [internal_cons, internal_cons_length, internal_cons_fc]
        else:
            return ["", "", ""]


    def _extract_molecule_angle_info(self, key, bead_num=0):
        """

        Extract internal angle topology from topology and parameters dict.

        Parameters
        ----------
        key : str
            The molecule name to pass to the parameter dictionary.
        topology_parameters : dict
            All molecule parameters.
        bead_num : int, optional
            Total number of beads before the first bead in molecule. The default is 0.

        Returns
        -------
        internal_angle: list
            list containing tuples of the internal angles between beads

        """

        internal_angle = []
        param_key = key.split()[1]
        if self.paramLibrary[param_key]["AngleCon"] != [0]:
            internal_angle_con = self.paramLibrary[param_key]["AngleCon"]
            for ac in internal_angle_con:
                connect = ac.split("-")
                angles = (
                    int(connect[0]) + bead_num,
                    int(connect[1]) + bead_num,
                    int(connect[2]) + bead_num,
                )
                internal_angle.append(angles)
            internal_angle_value = list(
                map(float, self.paramLibrary[param_key]["AngleNum"])
            )
            internal_angle_fc = list(
                map(float, self.paramLibrary[param_key]["AngleFC"])
            )
            return [internal_angle, internal_angle_value, internal_angle_fc]
        else:
            return ["", "", ""]

    def _MDA_format(self, topology_tuples):
        """
        Convert BeadWeavers counting convention for its topology into MDA counting convention.

        Parameters
        ----------
        topology_tuples : list
            list containing structure topology.

        Returns
        -------
        list
            list containg tuples in MDA format.

        """

        result = []
        for t in topology_tuples:
            new_values = []
            for x in t:
                new_values.append(x - 1)
            new_tuple = tuple(new_values)
            result.append(new_tuple)
        return tuple(result)

    def _assign_top_to_param(self, topology, length_params, force_params):
        """
        Create dict with toplogy as key and parameters as value.

        Parameters
        ----------
        topology : list
            bond or angle tuple
        length_params : list
            eq. length parameters
        force_params : list
            force constant parameters

        Returns
        -------
        param_dict : dict
            Dict containing topology as key and parameters as value

        """

        param_dict = {}

        for i in range(len(topology)):
            tup = tuple(topology[i])
            params = []
            params.append(length_params[i])
            if force_params != []:
                params.append(force_params[i])
            param_dict[tup] = params

        return param_dict

    def get_internal_info(self, internal, bead_num=0):
        """
        Generates the internal topology and parameters or the new strucure.

        Parameters
        ----------
        internal : list
            Allows users to generated exclusivley internal bonds or angles
        bead_num : int, optional
            Total number of beads before the first bead in molecule. The default is 0.

        Returns
        -------
        None.

        """

        internal_bond = []
        internal_bond_length = []
        internal_bond_fc = []

        internal_angle = []
        internal_angle_value = []
        internal_angle_fc = []
        
        internal_cons = []
        internal_cons_length = []
        internal_cons_fc = []

        for key in self.string_def:
            if "internalbond" in internal:
                (
                    molecule_bond,
                    molecule_length,
                    molecule_force,
                ) = self._extract_molecule_bond_info(key, bead_num)
                internal_bond.extend(molecule_bond)
                internal_bond_length.extend(molecule_length)
                internal_bond_fc.extend(molecule_force)
            if "constraint" in internal:
                (
                    molecule_cons,
                    molecule_cons_length,
                    molecule_cons_force,
                ) = self._extract_molecule_constraint_info(key, bead_num)
                internal_cons.extend(molecule_cons)
                internal_cons_length.extend(molecule_cons_length)
                internal_cons_fc.extend(molecule_cons_force)
            if "internalangle" in internal:
                (
                    molecule_angles,
                    molecule_angle_val,
                    molecule_angle_force,
                ) = self._extract_molecule_angle_info(key, bead_num)
                if molecule_angles == "":
                    pass
                else:
                    internal_angle.extend(molecule_angles)
                internal_angle_value.extend(molecule_angle_val)
                internal_angle_fc.extend(molecule_angle_force)

            bead_num += self.paramLibrary[key.split()[1]]["BeadNum"]

        int_bonds_param_dict = self._assign_top_to_param(
            internal_bond, internal_bond_length, internal_bond_fc
        )

        self.internal_bonds = {
            "int_bonds_param_dict": int_bonds_param_dict,
            "internal_bond": internal_bond,
            "internal_bond_length": internal_bond_length,
            "internal_bond_fc": internal_bond_fc,
        }

        int_angle_param_dict = self._assign_top_to_param(
            internal_angle, internal_angle_value, internal_angle_fc
        )

        self.internal_angles = {
            "int_angle_param_dict": int_angle_param_dict,
            "internal_angle": internal_angle,
            "internal_angle_value": internal_angle_value,
            "internal_angle_fc": internal_angle_fc,
        }
        
        int_cons_param_dict = self._assign_top_to_param(
            internal_cons, internal_cons_length, internal_cons_fc
        )
        self.constraints = {
            "int_constraints_param_dict": int_cons_param_dict,
            "internal_constraint": internal_cons,
            "internal_constraint_length": internal_cons_length,
            "internal_constraint_fc": internal_cons_fc,
        }

        internal_bond, internal_angle = self._MDA_format(
            internal_bond
        ), self._MDA_format(internal_angle)

        if "internalbond" in internal and "internalangle" in internal:
            self.bead_info.add_TopologyAttr("bonds", np.array(internal_bond))
            self.bead_info.add_TopologyAttr(
                "bondlengths", np.array(internal_bond_length)
            )
            self.bead_info.add_TopologyAttr(
                "bondforces", np.array(internal_bond_fc)
            )
            self.bead_info.add_TopologyAttr("angles", np.array(internal_angle))
            self.bead_info.add_TopologyAttr(
                "anglevalues", np.array(internal_angle_value)
            )
            self.bead_info.add_TopologyAttr(
                "angleforces", np.array(internal_angle_fc)
            )
            print(
                f"Internal angles and bonds were added to the universe: {self.bead_info.bonds} {self.bead_info.angles}"
            )
        elif "internalbond" in internal:
            self.bead_info.add_TopologyAttr("bonds", internal_bond)
            print(
                f"Internal bonds were added to the universe: {self.bead_info.atoms.bonds}"
            )
        elif "internalangle" in internal:
            self.bead_info.add_TopologyAttr("angles", internal_angle)
            print(
                f"Internal angles were added to the universe: {self.bead_info.angles}"
            )

    def _format_internal_bond(self, key, value, bead_num=0):
        """
        Determines the bonding structure of the internal bonds

        Parameters
        ----------
        key : str
            The molecule name to pass to the parameter dictionary.
        value : list
            External bond connection between molecules.
        topology_parameters : dict
            All molecule parameters.
        bead_num : int, optional
            Total number of beads before the first bead in molecule. The default is 0.

        Returns
        -------
        new_data: list
            nested list of formatted internal bonds and external bonds.

        """
        param_key = key.split()[1]
        if len(self.paramLibrary[param_key]["BeadType"]) > 1:
            bond_con = self.paramLibrary[param_key]["BondCon"]
            bond_num = self.paramLibrary[param_key]["BondNum"]
            bond_fc = self.paramLibrary[param_key]["BondFC"]
            temp_list = []
            for bc, bn, bf in zip(bond_con, bond_num, bond_fc):
                connect = bc.split("-")
                informat = [
                    int(connect[0]) + bead_num,
                    int(connect[1]) + bead_num,
                    bn,
                    bf,
                ]
                temp_list.append(informat)
            if value[0].isdigit():
                value = [int(value[0]) + bead_num, int(value[1]) + bead_num]
                new_data = value, temp_list
            else:
                splitval = value[0].split("(")
                value = [
                    f"{splitval[0]} {splitval[1]} {int(splitval[2])+bead_num}",
                    int(value[1]) + bead_num,
                ]
                new_data = value, temp_list
        else:
            if value[0].isdigit():
                value = [int(value[0]) + bead_num, int(value[1]) + bead_num]
                new_data = [value]
            else:
                splitval = value[0].split("(")
                value = [
                    f"{splitval[0]} {splitval[1]} {int(splitval[2])+bead_num}",
                    int(value[1]) + bead_num,
                ]
                new_data = [value]
        return new_data

    def _bond_list(self, key, value, bead_num=0):
        """
        Bonds for individual ring structures and single beads are defined

        Parameters
        ----------
        key : str
            The molecule name to pass to the parameter dictionary.
        value : list
            External bond connection between molecules.
        bead_num : int, optional
            Total number of beads before the first bead in molecule. The default is 0.

        Returns
        -------
        list
            list for the defined bonds

        """

        bond_list = []
        param_key = key.split()[1]
        if len(self.paramLibrary[param_key]["BeadType"]) > 1:
            bond_con = self.paramLibrary[param_key]["BondCon"]
            for bc in bond_con:
                connect = bc.split("-")
                bonds = (
                    int(connect[0]) + bead_num,
                    int(connect[1]) + bead_num,
                )
                bond_list.append(bonds)
            return bond_list
        else:
            return "single bead"

    def _get_external_bond_info(self, bond_dict):
        """
        Connects external bonds and writes them in a accesible list format

        Parameters
        ----------
        bonddict : dict
            External and internal bond information.
        bondlen : float, optional
            Default external bond length. The default is .470.
        bondfc : float, optional
            Default external bond force. The default is 1250.

        Returns
        -------
        externalbondlist : list
            external bonding structure.

        """

        externalbondlist = []
        tempbondlist = []
        for i in range(len(bond_dict.keys()) - 1):
            if i != None:
                bdg1 = bond_dict[i + 1][0]
                bdg2 = bond_dict[i + 2][0]
                if " " in str(bdg2[0]):
                    i1, i2, i3 = bdg2[0].split()
                    if len(bond_dict[int(i2)]) > 1:
                        for arr in bond_dict[int(i2)][1]:
                            if arr[0] not in tempbondlist:
                                tempbondlist.append(int(arr[0]))
                            if arr[1] not in tempbondlist:
                                tempbondlist.append(int(arr[1]))
                    elif isinstance(bond_dict[int(i2)][0][0], str):
                        tempbondlist.append(
                            int(bond_dict[int(i2)][0][0].split()[-1])
                        )
                    else:
                        tempbondlist.append(bond_dict[int(i2)][0][0])
                    tempbondlist.sort()
                    external_bd = (tempbondlist[int(i1) - 1], int(i3))
                    externalbondlist.append(external_bd)
                    tempbondlist = []
                elif bdg1[1] != 0:
                    external_bd = (bdg1[1], bdg2[0])
                    externalbondlist.append(external_bd)
        return externalbondlist

    def _get_external_angle_info(
        self, bond_data, external_bond_dict, angle=150, anglefc=1250
    ):
        """
        Creates possible external angles

        Parameters
        ----------
        bond_data : list
            Bonds definitions for individual ring structures and single beads
        external_bond_dict : dict
            Dictionary containg all external bonds
        angle : float, optional
            Default external angle value. The default is 150.
        anglefc : float, optional
            Default external angle force. The default is 1250.

        Returns
        -------
        external_angle_list : list
            Possible extarnal angles.

        """

        external_data = []
        external_angle_list = []
        for external in range(len(external_bond_dict["external bonds"])):
            external_data.append(
                [
                    external_bond_dict["external bonds"][external][0],
                    external_bond_dict["external bonds"][external][1],
                ]
            )

        for bond_ext in range(len(external_data)):
            for ring in range(len(bond_data)):
                if bond_data[ring] != "single bead":
                    beadcount = len(bond_data[ring])
                    for bond_int in range(beadcount):
                        current_bond = bond_data[ring][bond_int]
                        if external_data[bond_ext][0] in current_bond:
                            external_angle_list.append(
                                (
                                    external_data[bond_ext][1],
                                    current_bond[0],
                                    current_bond[1],
                                )
                            )
                        elif external_data[bond_ext][1] in current_bond:
                            external_angle_list.append(
                                (
                                    external_data[bond_ext][0],
                                    current_bond[0],
                                    current_bond[1],
                                )
                            )
                if bond_data[ring] == "single bead":
                    pass

        return external_angle_list

    def get_external_info(
        self,
        external,
        bead_num=0,
        bondlen=0.470,
        bondfc=1250,
        angle=180,
        anglefc=1250,
    ):
        """
        External bond and angle topology is made

        Parameters
        ----------
        external : list
            Allows users to generated exclusivley internal bonds or angles
        bead_num : int, optional
            Total number of beads before the first bead in molecule. The default is 0.
        bondlen : float, optional
            Default external bond length. The default bond length is .470.
        bondfc : float, optional
            Default external bond force. The default bond force constant is 1250.
        angle : float, optional
            Default external angle value. The default angle value is 180.
        anglefc : float, optional
            Default external angle force. The default angle force constant is 1250.

        Returns
        -------
        None.

        """

        bond_dict = {}
        external_bond_dict = {}
        external_angle_dict = {}
        bond_data = []
        external_bond_length = []
        external_bond_fc = []
        external_angle_value = []
        external_angle_fc = []

        for key, value in self.string_def.items():
            if "externalbond" in external:
                bond_dict[int(key.split()[0])] = self._format_internal_bond(
                    key, value, bead_num
                )
                external_bond_dict[
                    "external bonds"
                ] = self._get_external_bond_info(bond_dict)
                bond_data.append(self._bond_list(key, value, bead_num))
            if "externalangle" in external:
                external_angle_dict[
                    "external angle"
                ] = self._get_external_angle_info(
                    bond_data, external_bond_dict
                )

            bead_num += len(self.paramLibrary[key.split()[1]]["BeadType"])
            eb, ea = (
                external_bond_dict["external bonds"],
                external_angle_dict["external angle"],
            )

        external_bond, external_angle = eb, ea

        for b in external_bond:
            external_bond_length.append(bondlen)
            external_bond_fc.append(bondfc)

        for a in external_angle:
            external_angle_value.append(angle)
            external_angle_fc.append(anglefc)
        ex_bonds_param_dict = self._assign_top_to_param(
            external_bond, external_bond_length, external_bond_fc
        )

        self.external_bonds = {
            "ex_bonds_param_dict": ex_bonds_param_dict,
            "external_bond": external_bond,
            "external_bond_length": external_bond_length,
            "external_bond_fc": external_bond_fc,
        }

        ex_angle_param_dict = self._assign_top_to_param(
            external_angle, external_angle_value, external_angle_fc
        )

        self.external_angles = {
            "ex_angle_param_dict": ex_angle_param_dict,
            "external_angle": external_angle,
            "external_angle_value": external_angle_value,
            "external_angle_fc": external_angle_fc,
        }

        external_bond, external_angle = self._MDA_format(
            external_bond
        ), self._MDA_format(external_angle)

        if "externalbond" in external and "externalangle" in external:
            self.bead_info.add_bonds(external_bond)
            self.bead_info.add_angles(external_angle)
            self.bead_info.add_TopologyAttr(
                "Extbondlengths", np.array(external_bond_length)
            )
            self.bead_info.add_TopologyAttr(
                "Extbondforces", np.array(external_bond_fc)
            )
            self.bead_info.add_TopologyAttr(
                "Extanglevalues", np.array(external_angle_value)
            )
            self.bead_info.add_TopologyAttr(
                "Extangleforces", np.array(external_angle_fc)
            )
            print(
                f"External angles and bonds were added to the universe: {self.bead_info.bonds} {self.bead_info.angles}"
            )
        elif "externalbond" in external:
            self.bead_info.add_TopologyAttr("bonds", external_bond)
            print(
                f"Internal bonds were added to the universe: {self.bead_info.atoms.bonds}"
            )
        elif "externalangle" in external:
            self.bead_info.add_TopologyAttr("angles", external_angle)
            print(
                f"Internal angles were added to the universe: {self.bead_info.angles}"
            )

    def _sort_bonds(self, bonds):
        """
        Bonds are sorted when adding or deleting bonds

        Parameters
        ----------
        bonds : list
            List of tuple containg bonds

        Returns
        -------
        sorted_bonds : list
            List of tuple containg bonds sorted least to greatest

        """

        sorted_bonds = []
        for i in range(len(bonds)):
            sorted_bonds.append(sorted(bonds[i]))
        return sorted_bonds

    def add_bonds(self, added_bonds):
        """
        Users will input bonds that will be added from the structure
        BeadWeavers attributes and the MDA universe will update

        Parameters
        ----------
        added_bonds : list
            List of tuple containg bonds

        Returns
        -------
        None.

        """

        added_bonds = self._sort_bonds(added_bonds)

        revised_bonds_MDA = []
        revised_bonds = []

        for i in range(len(added_bonds)):
            b1, b2 = added_bonds[i]
            revised_bonds_MDA.append((b1 - 1, b2 - 1))
            revised_bonds.append((b1, b2))
            self.external_bonds["ex_bonds_param_dict"][(b1, b2)] = [
                0.470,
                1250,
            ]

        self.bead_info.add_bonds(revised_bonds_MDA)

        for bond in revised_bonds:
            self.external_bonds["ex_bonds_param_dict"][bond] = [0.470, 1250]
            self.external_bonds["external_bond_length"].append(0.470)
            self.external_bonds["external_bond_fc"].append(1250)

        self.external_bonds["external_bond"].extend(revised_bonds)

    def delete_bonds(self, deleted_bonds):
        """
        Users will input bonds that will be deleted from the structure
        BeadWeavers attributes and the MDA universe will update

        Parameters
        ----------
        deleted_bonds : list
            List of tuple containg bonds

        Returns
        -------
        None.

        """

        deleted_bonds = self._sort_bonds(deleted_bonds)

        int_bond = []
        ex_bond = []
        revised_bonds_MDA = []
        revised_bonds = []
        new_int_bond_dict = {}
        new_ex_bond_dict = {}

        for i in range(len(deleted_bonds)):
            b1, b2 = deleted_bonds[i]
            revised_bonds_MDA.append((b1 - 1, b2 - 1))
            revised_bonds.append((b1, b2))

        self.bead_info.delete_bonds(revised_bonds_MDA)

        for bond in self.internal_bonds["internal_bond"]:
            if bond not in revised_bonds:
                int_bond.append(bond)

        for bond in self.external_bonds["external_bond"]:
            if bond not in revised_bonds:
                ex_bond.append(bond)

        for key, value in self.internal_bonds["int_bonds_param_dict"].items():
            if key not in revised_bonds:
                new_int_bond_dict[key] = value

        for key, value in self.external_bonds["ex_bonds_param_dict"].items():
            if key not in revised_bonds:
                new_ex_bond_dict[key] = value

        self.internal_bonds["internal_bond"] = int_bond
        self.external_bonds["external_bond"] = ex_bond
        self.internal_bonds["int_bonds_param_dict"] = new_int_bond_dict
        self.external_bonds["ex_bonds_param_dict"] = new_ex_bond_dict

    def visualize_structure(self):
        """
        A 2-D visual of the BeadWeaver structure is created

        Returns
        -------
        None.

        """

        bonds = (
            self.internal_bonds["internal_bond"],
            self.external_bonds["external_bond"],
            self.constraints["internal_constraint"]
        )

        G = nx.Graph()
        for bond_list in bonds:
            G.add_edges_from(bond_list)

        pos = nx.kamada_kawai_layout(G)

        nx.draw_networkx_nodes(G, pos, node_color="yellow", node_size=10)

        nx.draw_networkx_labels(
            G, pos, font_color="black", font_size=2, font_weight="bold"
        )

        nx.draw_networkx_edges(G, pos, width=0.25)

        edge_labels = nx.get_edge_attributes(G, "length")
        nx.draw_networkx_edge_labels(
            G, pos, edge_labels=edge_labels, font_size=1, font_color="black"
        )
        plt.margins(0.0001)
        plt.axis("off")

        plt.savefig("visualize_strucutre.pdf", format="PDF")
        plt.show()

    def write_itp(self, folderpath=Path.cwd()):
        """
        Itp file is written from BeadWeaver Class

        Returns
        -------
        None.

        """

        itp_file = Path(folderpath).joinpath(self.Sturcture_name + ".itp")

        with open(itp_file, "w") as itp_file:
            itp_file.write(
                f"[ moleculetype ]\n;molecule name  nrexcl\n{self.Sturcture_name}           1\n\n"
            )

            itp_file.write("[ atoms ]\n")
            itp_file.write(
                ";  num   beadtype  resnr   resnm  bead  chrg#     charge    mass\n"
            )
            index = 0
            for i in range(len(self.bead_info.atoms.types)):
                index += 1
                itp_file.write(
                    f"{index:>6}{self.bead_info.atoms.types[i]:>11}{'1':>7}{self.Sturcture_name:>7}{self.bead_info.atoms.names[i]:>7}{index:>7}{self.bead_info.atoms.charges[i]:>11}\n"
                )

            itp_file.write("\n[ bonds ]\n")
            itp_file.write(";atm1  atm2  type  equilibrium  force const  \n")
            for key, value in self.internal_bonds[
                "int_bonds_param_dict"
            ].items():
                b1, b2 = key
                bl, bfc = value
                itp_file.write(
                    f"{b1:>5}{b2:>6}{'1':>6}{bl:>13.5f}{bfc:>13.5f};\n"
                )

            itp_file.write("\n[ angles ]\n")
            itp_file.write(
                ";atm1  atm2  atm3  type  equilibrium  force const  \n"
            )
            for key, value in self.internal_angles[
                "int_angle_param_dict"
            ].items():
                b1, b2, b3 = key
                av, afc = value
                itp_file.write(
                    f"{b1:>5}{b2:>6}{b3:>6}{'2':>6}{av:>13.5f}{afc:>13.5f};\n"
                )

    def write_external_angles(self, folderpath=Path.cwd()):
        """
        Possible external angles are defined with default angle parameters
        A file is written from BeadWeaver Class

        Returns
        -------
        None.

        """

        txt_file = Path(folderpath).joinpath(self.Sturcture_name + "_possible_external_angles.txt")

        with open(txt_file, "w") as file:
            file.write("\n;[ external angles ]\n")
            file.write(";atm1  atm2  atm3  type  equilibrium  force const  \n")
            for key, value in self.external_angles[
                "ex_angle_param_dict"
            ].items():
                b1, b2, b3 = key
                av, afc = value
                file.write(
                    f"{b1:>5}{b2:>6}{b3:>6}{'2':>6}{av:>13.5f}{afc:>13.5f};\n"
                )
                
if __name__=='__main__':
    parameter_list = ["itp_elements.dat",
                      "Martini_3/martini_v3.0.0_small_molecules_v1.itp",
                      "Martini_3/martini_v3.0.0_phospholipids_v1.itp"]
    BW = BeadWeaver("0<DYPG>3-4<DYPG>0", "XXXX", param_path=parameter_list)
    BW.get_structure_info()
    BW.get_internal_info(["internalbond","internalangle","constraint"])
    BW.get_external_info(["externalbond","externalangle"])
    BW.visualize_structure()
