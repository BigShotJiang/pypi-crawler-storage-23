#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Dec 20 12:55:20 2024

@author: jje63
"""
# Standard Library
import sys
import glob
import tkinter as tk
from tkinter import ttk
from tkinter import simpledialog, filedialog
from pathlib import Path, PurePath

# Third Party Imports
import networkx as nx
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import axes3d, Axes3D
import numpy as np
from matplotlib.widgets import Button, CheckButtons
from .BeadWeaver import BeadWeaver
from .bw_parser import BeadWeaverParser

selected_points = []

class BWGUI(BeadWeaver):
    
    def __init__(self, bead_string, Structure_name, param_path="itp_elements.dat"):
        super(BWGUI, self).__init__(bead_string, Structure_name, param_path=param_path)
        self.fig = None
        self.axes = None
        self.plot = None
        self.colors = None
        self.select_list = []
        self.edgelist = []
        self.get_structure_info()
        self.annotation = []
        self.option = None
        self.nodelist = None
        self.labels = []
        self.visibility = [False]
        self.graph = nx.Graph()
        
        
        self.get_internal_info(["internalbond","internalangle"])
        self.get_external_info(["externalbond","externalangle"])
        
        self.data = self.internal_bonds['internal_bond'] + self.external_bonds['external_bond']
        
    def _format_axes(self, ax):
        """
        Visualization of 3 dimensional axis with labels 

        Parameters
        ----------
        ax : cls
            Matplolib axes object.

        Returns
        -------
        None.

        """
        ax.grid(False)
        for dim in (ax.xaxis, ax.yaxis, ax.zaxis):
            dim.set_ticks([])
            ax.set_xlabel("x")
            ax.set_ylabel("y")
            ax.set_zlabel("z")

    def create3dvis(self):
        """
        Creates a 3D visual representation of molecules topology

        """
        
        if self.fig == None:
            self.fig = plt.figure(figsize=(12,8))
            self.axes = self.fig.add_subplot(111, projection='3d')
            self.axes.set_title("Bead Weaver", loc="center", fontsize=14, fontweight="bold")
            self._format_axes(self.axes)
            
            deletebond = self.fig.add_axes([0.05, 0.05, 0.1, 0.075])
            addbond = self.fig.add_axes([0.15, 0.05, 0.1, 0.075])
            library = self.fig.add_axes([0.3, 0.05, 0.1, 0.075])
            getselect = self.fig.add_axes([0.6, 0.05, 0.1, 0.075])
            delsel = self.fig.add_axes([0.70, 0.05, 0.1, 0.075])
            addsel = self.fig.add_axes([0.45, 0.05, 0.15, 0.075])
            checkbutttons = self.fig.add_axes([0.80, 0.05, 0.1, 0.075])
            WriteITP = self.fig.add_axes([0.05, 0.5, 0.1, 0.075])
            
            selectbox = self.fig.canvas.mpl_connect('pick_event', self.mouse_event)
            selectcolor = self.fig.canvas.mpl_connect('pick_event', self.on_pick)
            
            write_itp = Button(WriteITP, 'Write ITP')
            write_itp.on_clicked(self.write_itp_and_angles)

            add_bond = Button(addbond, 'Add Bond')
            add_bond.on_clicked(self.add_bonds_buttton)

            delete_bond = Button(deletebond, 'Delete Bond')
            delete_bond.on_clicked(self.delete_bonds_buttton)

            bnext = Button(getselect, 'Select')
            bnext.on_clicked(self.on_button)
            
            delete = Button(delsel, 'Delete Molecule')
            delete.on_clicked(self.delete_button)
            
            add = Button(addsel, 'New Molecule')
            add.on_clicked(self.add_button)
            
            check = CheckButtons(checkbutttons, ["Labels"], self.visibility)
            check.on_clicked(self.showall)

            lib = Button(library, 'Library')
            lib.on_clicked(self.on_select)

            annotation_cid = self.fig.canvas.mpl_connect('motion_notify_event', self.update_annotate_on_rotate)
            label_cid = self.fig.canvas.mpl_connect('motion_notify_event', self.update_label_on_rotate)


        G = self.graph
        if self.data != []:
            G.add_edges_from(self.data)
            pos = nx.spring_layout(G, dim=3, seed=779)
            node_xyz = np.array([pos[v] for v in sorted(G)])
            edge_xyz = np.array([(pos[u], pos[v]) for u, v in G.edges()])
            self.nodelist = sorted(G)
            self.colors = ['blue'] * len(node_xyz)
            self.annotation = [""]* len(node_xyz)
            self.plot = self.axes.scatter(*node_xyz.T, s=300,c=self.colors, ec="w", picker=True,)
            for vizedge in edge_xyz:
                self.edgelist.append(self.axes.plot(*vizedge.T, color="tab:gray"))
            self.axes.set_title("Bead Weaver", loc="center", fontsize=14, fontweight="bold")
        else:
            self.colors = ['blue']
            self.annotation = [""]
            self.nodelist = [1]
            self.plot = self.axes.scatter(0,0,0, s=300,c=self.colors, ec="w", picker=True,)
            self.axes.set_title("Bead Weaver", loc="center", fontsize=14, fontweight="bold")
        self.fig.canvas.draw()
        plt.show()

    def write_itp_and_angles(self, event):
        """
        Writes the ITP file for current molecules.

        """
        folderpath = self._dialogbox3()
        self.write_itp(folderpath)
        self.write_external_angles(folderpath)
        

    def showall(self, label):
        """
        Shows the labels for all of the beads of a molecule.

        Parameters
        ----------
        label : List
            list of label descriptions or "Label" which denotes the initial state.

        Returns
        -------
        None.

        """
        if self.visibility[0] == False:
            self.visibility[0] = True
            for i in range(len(self.nodelist)):
                x_pos = self.plot.get_offsets()[i][0] 
                y_pos = self.plot.get_offsets()[i][1]
                self.labels.append(self.axes.annotate(
                    text=f"{self.bead_info.atoms[i].name}",
                    xy=(x_pos, y_pos),
                    bbox={'boxstyle': 'round', 'fc': 'w'}
                )
            )
            self.fig.canvas.draw_idle()
        else:
            self.visibility[0] = False
            for ann in self.axes.texts:
                ann.remove()
            self.fig.canvas.draw_idle()
        
    def on_pick(self, event):
        """
        Colors the bead red or blue when clicking on a bead.

        """
        mouseevent = event.mouseevent
        artist = event.artist
        if artist == self.plot:
            ind = event.ind[0]
            self.colors[ind] = 'red' if self.colors[ind] == 'blue' else 'blue'
            if ind in self.select_list:
                self.select_list.remove(ind)
            else:
                self.select_list.append(ind)
            self.plot._facecolor3d = self.colors
            self.plot.set_facecolors(self.colors)
            self.fig.canvas.draw_idle()
            
    def mouse_event(self, event):
        """
        Shows bead information when clicking on a specific bead.
        """
        if event.artist == self.plot:
            ind = event.ind[0]
            if self.colors[ind] == 'blue':
                ann = self.axes.annotate(
                    text = '',
                    xy=(0,0),
                    xytext=(15,15),
                    textcoords='offset points',
                    bbox={'boxstyle': 'round', 'fc': 'w'},
                    arrowprops={'arrowstyle':'->'}
                    )
                self.annotation[ind] = ann
                x_pos = self.plot.get_offsets()[ind][0] #X position of selected point
                y_pos = self.plot.get_offsets()[ind][1]
                self.annotation[ind].xy=(x_pos,y_pos)
                self.annotation[ind].set_text(f"Name:{self.Sturcture_name}, BN:{self.bead_info.atoms[ind].name}, BT:{self.bead_info.atoms[ind].type}, BI:{ind},")
                self.annotation[ind].set_visible(True)
            else:
                self.annotation[ind].remove()
                self.annotation[ind] = ""
           
            
    def _dialogbox(self):
        """
        Creates a dialog box for a new molecule name

        """
        root = tk.Tk()
        root.withdraw()  
        user_input = simpledialog.askstring("Input", "Name Molecule:", parent=root)
        if user_input:
            print("User entered:", user_input)
            return user_input
        else:
            print("User cancelled or entered nothing.")
        root.destroy()
        
    def _dialogbox2(self):
        """
        Creates a dialog box to load a new string of molecules.

        """
        root = tk.Tk()
        root.withdraw() 
        user_input = simpledialog.askstring("Input", "Name:", parent=root)
        user_input2 = simpledialog.askstring("Input", "Parameter String:", parent=root)
        if user_input:
            print("Name:", user_input)
            print("Parameter String:", user_input2)
            return [user_input, user_input2]
        else:
            print("User cancelled or entered nothing.")
        root.destroy()

    def _dialogbox3(self):
        """
        Creates a dialog box to load get a folder path for writing an ITP to.

        """
        root = tk.Tk()
        root.withdraw() 
    
        folder_path = filedialog.askdirectory(
            title="Select a Folder",
            initialdir="/",
        )
        if folder_path:
            return folder_path
        root.mainloop()
        
    def _dialogbox4(self):
        """
        Creates a dialog box to get ITP files.

        """
        print("yes")
        root = tk.Tk()
        root.withdraw()
        filetypes = (
            ('ITP files', '*.itp'),
            ('beadweaver data files', '*.dat')
            )
    
        filepath = filedialog.askopenfilename(
            title="Select a file",
            initialdir="/",
            filetypes=filetypes
        )
        if filepath:
            return filepath
        root.mainloop()
        
    def add_to_library(self):
        single_path = self._dialogbox4()
        lib = BeadWeaverParser()
        if not isinstance(single_path, PurePath):
            single_path=Path(single_path)
        if single_path.suffix == ".dat":
            lib.extract_topology_parameters(single_path)
            self.paramLibrary.update(lib.parameter_library)
        elif single_path.suffix == ".itp":
            lib.itp_parser(single_path)
            self.paramLibrary.update(lib.itp_dict)
        else:
            raise ValueError("File must be a beadweaver .dat file or a .itp file")

    def on_select(self, event):
        """
        Creates the combobox for selecting the a molecule to load from the library.

        """
        OPTIONS = list(self.paramLibrary)
        root = tk.Tk()
        def get_combobox_value():
            selected_option = combobox.get()
            self._reset_molecule(selected_option)
            root.destroy()
        

        root.geometry('400x200')
        root.title("Molecule Library")

        combo_var = tk.StringVar(root)
        combo_font = ("Helvetica", 16)
        combo_var.set(OPTIONS[0])
    
        combobox = ttk.Combobox(root, textvariable=combo_var, values=OPTIONS, state="readonly", width=30, font=combo_font) 
        combobox.pack(pady=20)

        button = ttk.Button(root, text="Select", command=get_combobox_value)
        button.pack()
        
        button2 = ttk.Button(root, text="Add to library", command=lambda: self.add_to_library())
        button2.pack()
       
        combobox.bind("<<ComboboxSelected>>", lambda event: get_combobox_value())
        root.mainloop()

    def _reset_molecule(self, Name):
        """
        Resets the class to original values.

        Parameters
        ----------
        Name : Str
            Name of molecule replacing previous molecule.

        Returns
        -------
        None.

        """
    
        if self.plot:
            self.plot.remove()
            for edge in self.edgelist:
                edge[0].remove()
            plt.draw()
            self.fig = self.fig
            self.axes = self.axes
            self.graph = nx.Graph()
        else:
            self.fig = self.fig
            self.axes = self.axes
            self.graph = nx.Graph()
        
        self.axes.clear()
        self._format_axes(self.axes)
        self.plot = None
        self.colors = None
        self.select_list = []
        self.edgelist = []
        self.annotation = []
        self.option = None
        self.nodelist = None
        self.labels = []
        self.visibility = [False]
        
        self.Sturcture_name = Name
        self.beadString = f"0<{Name}>0"
        self.paramLibrary = self.paramLibrary
        self.string_def = BeadWeaverParser.process_string(self.beadString)
        self.bead_info = None
        self.internal_bonds = None
        self.external_bonds = None
        self.internal_angles = None
        self.external_angles = None
        self.coordinates = None
        
        self.get_structure_info()
        self.get_internal_info(["internalbond","internalangle"])
        self.get_external_info(["externalbond","externalangle"])
        self.data = self.internal_bonds['internal_bond'] + self.external_bonds['external_bond']
        self.create3dvis()
        
    def on_button(self, event):
        """
        Selecting part of a molecule to make a new molecule.

        """
        templis = []
        templis2 = []
        Beadnum = len(self.select_list)
        beadtype = []
        bead = []
        charge = []
        mass = []
        bondcon = []
        bondnum = []
        bondfc = []
        anglecon = []
        anglenum = []
        anglefc = []
        
        for num in self.select_list:
            beadtype.append(self.bead_info.atoms[num].type)
            bead.append(self.bead_info.atoms[num].name)
            charge.append(int(self.bead_info.atoms[num].charge))
            mass.append(int(self.bead_info.atoms[num].mass))
        if len(self.select_list) > 1:
            for i in range(len(self.select_list)):
                sel1 = self.select_list[i]
                for j in range(len(self.select_list)):
                    if self.select_list[i] == self.select_list[j]:
                        pass
                    else:
                        sel2 = self.select_list[j]
                        templis.append((sel1+1,sel2+1))
                        for k in range(len(self.select_list)):
                            if self.select_list[j] == self.select_list[k]:
                                pass
                            else:
                                sel3 = self.select_list[k]
                                templis2.append((sel1+1,sel2+1,sel3+1))
        numtable = self.subtracttable()
        for bond in templis:
            if bond in self.internal_bonds['int_bonds_param_dict'].keys():
                blen, bfc = self.internal_bonds['int_bonds_param_dict'][bond]
                bc = f'{bond[0]-numtable[bond[0]]}-{bond[1]-numtable[bond[1]]}'
                bondcon.append(bc)
                bondnum.append(blen)
                bondfc.append(bfc)
            
            if bond in self.external_bonds['ex_bonds_param_dict'].keys():
                blen, bfc = self.external_bonds['ex_bonds_param_dict'][bond]
                bc = f'{bond[0]-numtable[bond[0]]}-{bond[1]-numtable[bond[1]]}'
                bondcon.append(bc)
                bondnum.append(blen)
                bondfc.append(bfc)
        
        for angle in templis2:
            if angle in self.internal_angles['int_angle_param_dict'].keys():
                alen, afc = self.internal_angles['int_angle_param_dict'][angle]
                ac = f'{angle[0]-numtable[angle[0]]}-{angle[1]-numtable[angle[1]]}-{angle[2]-numtable[angle[2]]}'
                anglecon.append(ac)
                anglenum.append(alen)
                anglefc.append(afc)
            
            if angle in self.external_angles['ex_angle_param_dict'].keys():
                alen, afc = self.external_angles['ex_angle_param_dict'][angle]
                ac = f'{angle[0]-numtable[angle[0]]}-{angle[1]-numtable[angle[1]]}-{angle[2]-numtable[angle[2]]}'
                anglecon.append(ac)
                anglenum.append(alen)
                anglefc.append(afc)
        molecule_name = self._dialogbox()
        
        if molecule_name not in self.paramLibrary.keys():
            
            self.paramLibrary[molecule_name] = {
                'BeadNum': Beadnum,
                'BeadType': beadtype,
                'Bead': bead,
                'Charge': charge,
                'Mass': mass,
                'BondCon': bondcon,
                'BondNum': bondnum,
                'BondFC': bondfc,
                'AngleCon': anglecon,
                'AngleNum': anglenum,
                'AngleFC': anglefc
                }
        else:
            print("Name of molecule already choosen, please select again")
    def subtracttable(self):
        """
        Corrects numbering when making a new molecule from existing molecule.

        Returns
        -------
        table : dict
            dictionary of molecule names with new numbering.

        """
        table = {}
        sortlist = sorted(self.select_list)
        length = len(self.select_list)
        for i in range(length):
            if sortlist[i] <= length:
                table[sortlist[i]+1] = 0
            else:
                subnum = sortlist[i] - i
                table[sortlist[i]+1] = sortlist[i] - (subnum - 1)
        return table
    
    def delete_button(self, event):
        """
        Deletes the current molecule.

        """
        self.plot.remove()
        for edge in self.edgelist:
            edge[0].remove()
        plt.draw()

        #self.fig = self.fig
        #self.axes = self.axes
        self.axes.clear()
        self._format_axes(self.axes)
        self.plot = None
        self.colors = None
        self.select_list = []
        self.edgelist = []
        self.annotation = []
        self.option = None
        self.nodelist = None
        self.labels = []
        self.visibility = [False]
        
        self.Sturcture_name = None
        self.beadString = None
        self.paramLibrary = self.paramLibrary
        self.string_def = None
        self.bead_info = None
        self.internal_bonds = None
        self.external_bonds = None
        self.internal_angles = None
        self.external_angles = None
        self.coordinates = None
            
    def add_button(self, event):
        """
        Adds a molecule.

        """
        Name, Param_string = self._dialogbox2()
        
        self.fig = self.fig
        self.axes = self.axes
        self.plot = None
        self.colors = None
        
        self.Sturcture_name = Name
        self.beadString = Param_string
        self.paramLibrary = self.paramLibrary
        self.string_def = BeadWeaverParser.process_string(self.beadString)
        self.select_list = []
        self.edgelist = []
        self.bead_info = None
        self.internal_bonds = None
        self.external_bonds = None
        self.internal_angles = None
        self.external_angles = None
        self.coordinates = None
        
        self.get_structure_info()
        self.get_internal_info(["internalbond","internalangle"])
        self.get_external_info(["externalbond","externalangle"])
        self.data = self.internal_bonds['internal_bond'] + self.external_bonds['external_bond']

        self.create3dvis()
        
    def delete_bonds_buttton(self, event):
        """
        Deletes bonds between two beads.

        """
        if len(self.select_list) != 2:
            raise ValueError("Exactly 2 beads must be selected")
        bonds = (int(self.select_list[0])+1,int(self.select_list[1])+1)
        
        if any(set(t) == set(bonds) for t in self.data):
            self.delete_bonds([bonds])
            self.select_list = []
            self.data = self.internal_bonds['internal_bond'] + self.external_bonds['external_bond']
            self.plot.remove()
            for edge in self.edgelist:
                edge[0].remove()
            plt.draw()
            self.graph = nx.Graph()
            self.edgelist = []
            for ann in self.annotation:
                if ann != "":
                    ann.remove()
            self.create3dvis()
        else:
            raise ValueError("Beads are not bonded")

    def add_bonds_buttton(self, event):
        """
        Adds bonds between two beads.

        """
        if len(self.select_list) != 2:
            raise ValueError("Exactly 2 beads must be selected")
        bonds = (int(self.select_list[0])+1,int(self.select_list[1])+1)
        
        if any(set(t) == set(bonds) for t in self.data):
            raise ValueError("Beads are already bonded")
        else:
            self.add_bonds([bonds])
            self.select_list = []
            self.data = self.internal_bonds['internal_bond'] + self.external_bonds['external_bond']
            self.plot.remove()
            for edge in self.edgelist:
                edge[0].remove()
            plt.draw()
            self.graph = nx.Graph()
            self.edgelist = []
            for ann in self.annotation:
                if ann != "":
                    ann.remove()
            self.create3dvis()

    def update_annotate_on_rotate(self, event):
        for ind,label in enumerate(self.annotation):
            x_pos = self.plot.get_offsets()[ind][0] 
            y_pos = self.plot.get_offsets()[ind][1]
            if label != '' and label.xy != (x_pos, y_pos):
                label.xy = (x_pos, y_pos)
                label.xyann = (-20, 20)
                label.arrow_patch.set_positions((x_pos,y_pos),(x_pos-1, y_pos-1))
                label.arrow_patch.set_color('black')

    def update_label_on_rotate(self, event):
        if self.visibility[0]:
            for ind,label in enumerate(self.labels):
                x_pos = self.plot.get_offsets()[ind][0] 
                y_pos = self.plot.get_offsets()[ind][1]
                if label.xy != (x_pos, y_pos):
                    label.set_position((x_pos, y_pos))


def launch_GUI():
    """
    Launches the GUI with Martini 3 parameters.

    """
    script_dir = Path(__file__).resolve().parent
    element_path = script_dir.joinpath("itp_elements.dat")
    Martini3_path = script_dir.joinpath("Martini_3")
    l = list(Martini3_path.glob("martini*"))
    l.append(element_path)
    Test = BWGUI("1<KDO>2-3<KDO>4", "XXXX",param_path=l)
    Test.create3dvis()
            

                    
if __name__ == "__main__":
    
    arg1 = sys.argv[0]
    
    if len(sys.argv) > 0:
        print("System will use the defult parameters")
        l = glob.glob("Martini_3/martini*")
        l.append("itp_elements.dat")
        Test = BWGUI("1<KDO>2-3<KDO>4", "XXXX",param_path=l)
        Test.create3dvis()
    else:
        arguments = l + arg1
        Test = BWGUI("1<KDO>2-3<KDO>4", "XXXX",param_path=arguments)
        Test.create3dvis()



