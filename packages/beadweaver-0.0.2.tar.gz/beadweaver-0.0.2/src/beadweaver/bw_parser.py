#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Parser for Bead Weaver

@author: Jahmal Ennis
"""
import re
from ast import literal_eval
from pathlib import Path

BW_HEADERS = [
    "Type",
    "BeadNum",
    "BeadType",
    "Bead",
    "Charge",
    "Mass",
    "BondCon",
    "BondNum",
    "BondFC",
    "AngleCon",
    "AngleNum",
    "AngleFC",
    "ConsCon",
    "ConsNum",
    "ConsFC",
    "DihedralCon",
    "DiRefAngle",
    "DiAngleFC",
]

ITP_HEADERS = [
     "moleculetype"
    ,"atoms"
    ,"bonds"
    ,"constraints"
    ,"angles"
    ,"dihedrals"
    ,"exclusions"
    ,"virtual_sitesn"
    ]

class BeadWeaverParser:
    """
    A class for parsing itp and beadweaver files.
    """

    def __init__(self):
        self.parameter_library = {}
        self.itp_dict = {}

    def process_string(string):
        """Process the string attribute of the Structure object.

        Parameters
        ----------
        string : str
            string defining new structure's external connections

        Returns
        -------
        element_dict : dict
            Dictionary of structure elements and connections.
        """
        string_format = re.compile("^([0-9\\(]+<[0-9a-zA-Z]+>[0-9\\(]+-*)+$") 
        assert re.match(string_format, string), "string is not formatted as 'bond#<molecule name>bond#-bond#<molecule name>bond#' or 'bond#(bond molecule#(bond#<molecule name>bond#-bond#<letters>bond#'"
        param_arr = re.split(r"[<>]", string)
        regular_bond_pattern = "[0-9]+-[0-9]+" 
        inter_connected_bond_pattern = r"\d+\(\d+\(\d+"
        element_dict = {}
        for i in range(1, len(param_arr),2):
            resname = param_arr[i]
            if re.match(regular_bond_pattern, param_arr[i-1]) or re.match(inter_connected_bond_pattern, param_arr[i-1]):
                inconnect = re.split("-",param_arr[i-1])[-1]
            else:
                inconnect = '0'
            if re.match(regular_bond_pattern, param_arr[i+1]) or re.match(inter_connected_bond_pattern, param_arr[i+1]):
                outconnect = re.split("-",param_arr[i+1])[0]
            else:
                outconnect = '1'
            element_dict[str(int((i + 1)/2)) + " " + resname] = [inconnect, outconnect]
        return element_dict
    
    def extract_topology_parameters(self, filepath):
        """
        Parses topology elements and restructures them in a usable format

        Parameters
        ----------
        topology : str
            path to topology file.

        Returns
        -------
        Parameter_dict : dict
            dictionary containing all information for each molecule.

        """

        f = open(filepath, "r")
        dictkey = ""
        for line in f:
            if re.match(";", line) or line.split() == []:
                continue
            elif line.strip()[0] == "[":
                dictkey = line.strip().strip("[]").strip(" ")
                self.parameter_library[dictkey] = {}

            elif line.strip("\t").strip("\n").split(":")[0] in BW_HEADERS:
                dict_setup = line.strip("\t").strip("\n").split(":")
                assert len(dict_setup) == 2, "Check parameter definitions"
                key = dict_setup[0]
                val = literal_eval(dict_setup[1])
                self.parameter_library[dictkey][key] = val
            else:
                continue
    
    def itp_parser(self, filepath):
        """
        Parses itp information and turns it into bead weaver readable dictionary

        Parameters
        ----------
        filepath : str
            path to itp file.

        Returns
        -------
        None.

        """
        header_format = re.compile("\\[\\s*[a-zA-Z0-5_]*\\s*\\]")
        header2_format = re.compile("\\[[a-zA-Z0-5_]*\\]")
        information_switch = ""
        bead_num = 0
        molecule_name = None
        with open(filepath, 'r') as file:
            itp_lines = file.readlines()
        
        for line in itp_lines:
            if line.startswith(";")  or line.startswith("#") or line.split()==[]:
                continue
            elif re.match(header_format, line) or re.match(header2_format, line):
                header = line.replace("[","").replace("]","").strip()
                information_switch = header
            elif information_switch == "moleculetype":
                if molecule_name != None:
                    self.itp_dict[molecule_name]["BeadNum"] = len(self.itp_dict[molecule_name]["BeadType"])
                molecule_name = self.info_parse_type(information_switch, line.split(), bead_num, molecule_name)
    
                self.itp_dict[molecule_name]={
                     "BeadNum": 0,
                     "BeadType": [],
                     "Bead": [],
                     "Charge":[],
                     "Mass":[],
                     "BondCon":[],
                     "BondNum":[],
                     "BondFC":[],
                     "ConsCon":[],
                     "ConsNum":[],
                     "ConsFC":[],
                     "AngleCon":[],
                     "AngleNum":[],
                     "AngleFC":[],
                     "DihedralCon":[],
                     "DihedralNum":[],
                     "DihedralFC":[]
                    }
            else:
                bead_num += 1
                self.info_parse_type(information_switch, line.split(), bead_num, molecule_name)
                
                    
    def info_parse_type(self, information_switch, line_info, bead_num, molecule_name):
        """
        Switch to choose how to parse itp sections

        Parameters
        ----------
        information_switch : str
            Switch for what itp information will be written.
        line_info : lists
            list seperated set of parameters.
        bead_num : int
            Counter for the number of beads in a strcture.
        molecule_name : str
            Name of the molecule.

        Returns
        -------
        NONE.

        """
        if information_switch == ITP_HEADERS[0]:
            return line_info[0]
        elif information_switch == ITP_HEADERS[1]:
            if len(line_info) == 6:
                info = [line_info[1], line_info[4], 0, 72]
            if len(line_info) == 7:
                info = [line_info[1], line_info[4], line_info[6], 72]
            if len(line_info) == 8:
                info = [line_info[1], line_info[4], line_info[6], line_info[7]]
            
            self.itp_dict[molecule_name]["BeadType"].append(info[0])
            self.itp_dict[molecule_name]["Bead"].append(info[1])
            self.itp_dict[molecule_name]["Charge"].append(info[2])
            self.itp_dict[molecule_name]["Mass"].append(info[3])   
        elif information_switch == ITP_HEADERS[2]:
            info = [f"{line_info[0]}-{line_info[1]}", line_info[3], line_info[4]]
            self.itp_dict[molecule_name]["BondCon"].append(info[0])
            self.itp_dict[molecule_name]["BondNum"].append(info[1])
            self.itp_dict[molecule_name]["BondFC"].append(info[2])
            
        elif information_switch == ITP_HEADERS[3]:
            info = [f"{line_info[0]}-{line_info[1]}", line_info[3]]
            self.itp_dict[molecule_name]["ConsCon"].append(info[0])
            self.itp_dict[molecule_name]["ConsNum"].append(info[1])
        elif information_switch == ITP_HEADERS[4]:
            info = [f"{line_info[0]}-{line_info[1]}-{line_info[2]}", line_info[4], line_info[5]]
            self.itp_dict[molecule_name]["AngleCon"].append(info[0])
            self.itp_dict[molecule_name]["AngleNum"].append(info[1])
            self.itp_dict[molecule_name]["AngleFC"].append(info[2])
            
        elif information_switch == ITP_HEADERS[5]:
            info = [f"{line_info[0]}-{line_info[1]}-{line_info[2]}-{line_info[3]}", line_info[5], line_info[6]]
            self.itp_dict[molecule_name]["DihedralCon"].append(info[0])
            self.itp_dict[molecule_name]["DihedralNum"].append(info[1])
            self.itp_dict[molecule_name]["DihedralFC"].append(info[2])
        elif information_switch == ITP_HEADERS[6]:
            return line_info
        elif information_switch == ITP_HEADERS[7]:
            return line_info
        else: 
            return None
        
        
            
            
if __name__=='__main__':
    l = BeadWeaverParser.process_string("0<GLC>3-2<GLC>1-3(1(2<GLC>1")
    print(l)
