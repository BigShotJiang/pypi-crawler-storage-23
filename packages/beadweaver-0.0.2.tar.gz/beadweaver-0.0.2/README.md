# BeadWeaver
Beadweaver is a software for manipulating itps of coarse-grained biological molecules.

## Quick start
### Create a virtual environment
`python -m venv beadweaver`

`source beadweaver/bin/activate`

### Install beadweaver package
`cd BeadWeaver`

`pip install .` (This will not be editable)

or 

`pip install -e .` (This will be editable and will make adjustments anytime the github is changed)

### Activate Beadweaver GUI
`BWGUI`

![Bead weaver GUI](./docs/_build/html/_images/BWGUI2.png)

## GUI Button Functions

`Delete Bond`: Click on two beads, then click the `delete button` to remove the bond between molecules.

`Add Bond`: Click on two beads, then click the `add bond` button to remove the bond between molecules.

`Library`: The library is a drop-down menu of molecules that Beadweaver can access. You can select the molecule of interest, and that molecule will be loaded.

`Select`: First, select the beads from the current structure by clicking them. Then click the select button. A menu will appear; type in the name of the new structure. That new structure can be used in `New Molecule` and will be added to the `Library`.

`New Molecule`: Allows the user to insert a new molecule into the GUI using a string format. First, click `Delete Molecule`, then click `New Molecule`. Enter the name of the new molecule and click OK. A second command box will appear; enter the new molecule string.

**Format**: `bond#<molecule name>bond#-bond#<molecule name>bond#` or `bond#(bond molecule#(bond#<molecule name>bond#-bond#<letters>bond#`

**Example**: `0<KDO>1-2<KDO>0` or `0<KDO>1-2<KDO>1-1(1(3<KDO>0`

`Labels`: toggles on and off all labels

![Bead weaver GUI](./docs/_build/html/_images/BWGUI1.png)
