"""Prompt templates for intelligence advisory agents."""
