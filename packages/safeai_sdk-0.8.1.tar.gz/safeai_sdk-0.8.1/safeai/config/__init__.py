"""Configuration loading and models."""
