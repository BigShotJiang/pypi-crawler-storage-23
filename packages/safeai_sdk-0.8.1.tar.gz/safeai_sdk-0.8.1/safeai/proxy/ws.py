"""WebSocket hooks placeholder for proxy mode."""


def register_websocket_routes(app) -> None:
    """Attach websocket routes to app (placeholder)."""
    return None
