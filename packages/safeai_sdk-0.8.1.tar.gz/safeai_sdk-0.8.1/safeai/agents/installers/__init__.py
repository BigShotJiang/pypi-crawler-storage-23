"""Per-agent hook installers for SafeAI."""

from __future__ import annotations
