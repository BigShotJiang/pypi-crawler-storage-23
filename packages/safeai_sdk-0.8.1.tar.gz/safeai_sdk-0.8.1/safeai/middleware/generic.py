"""Generic callable wrapper middleware."""

from safeai.middleware.base import BaseMiddleware


class GenericMiddleware(BaseMiddleware):
    pass
