"""Allow running as `python -m tepilora_mcp`."""

from .server import main

main()
