"""MCP Prompts — pre-built prompt templates for common workflows."""

from __future__ import annotations

from ..server import mcp  # noqa: F401 — will be used when prompts are added
