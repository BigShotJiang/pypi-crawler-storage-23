"""Tepilora MCP Server - Financial data tools for AI assistants."""

try:
    from Tepilora.version import __version__ as __version__
except ImportError:
    __version__ = "0.0.0"

from .server import mcp, main

__all__ = ["mcp", "main", "__version__"]
