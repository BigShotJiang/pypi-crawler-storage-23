from fastai.tabular.all import *

# Helper to force fastai imports.
# fastai is doing library setup during star imports. These are required for correct library functioning.
# Local star imports are not possible in-place, so separate helper packages is created
# see autogluon.common.utils.try_import.try_import_fastai() for usage
