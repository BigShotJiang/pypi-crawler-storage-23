# Model architecture modules for MitraModel 
