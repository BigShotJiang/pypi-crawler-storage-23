# proprioceptive-cradle

Behavioral adapter generation for language models via fiber-bundle probes.

## What It Does

The Cradle trains lightweight probes on your model's hidden states to measure 9 behavioral dimensions, then generates a LoRA adapter that shifts behavior toward a target profile.

**All computation happens on your GPU. No data leaves your machine.**

## Quick Start

```bash
pip install proprioceptive-cradle
```

### Behavioral Scan
```bash
cradle scan --model mistralai/Mistral-7B-Instruct-v0.3
```

Produces a report card showing probe separation ratios for:
- **Enhancement:** depth, specificity, calibration, focus, coherence
- **Suppression:** repetition, hedging, sycophancy, verbosity

### Generate Adapter
```bash
cradle generate --model mistralai/Mistral-7B-Instruct-v0.3 --preset professional
```

### Python API
```python
from cradle import scan, generate

report = scan("mistral")
adapter_path = generate("mistral", preset="professional")
```

## Validated Models

| Model | Architecture | Hidden Dim | Layers | Probe Layers |
|-------|-------------|-----------|--------|-------------|
| Falcon-Mamba 7B | Mamba SSM | 4096 | 64 | [16, 32, 48] |
| LLaMA 3.1 8B | Transformer | 4096 | 32 | [8, 16, 24] |
| Mistral 7B | Transformer | 4096 | 32 | [8, 16, 24] |
| Qwen 2.5 7B | Transformer | 3584 | 28 | [7, 14, 21] |
| Qwen 2.5 32B | Transformer | 5120 | 64 | [16, 32, 48] |
| Qwen 2.5 3B | Transformer | 2048 | 36 | [9, 18, 27] |

## Presets

- **professional**: High depth/specificity, low sycophancy/hedging
- **creative**: Relaxed calibration, higher verbosity tolerance
- **cautious**: Maximum calibration, moderate hedging allowed
- **direct**: Maximum specificity/focus, minimal everything else

## Requirements

- Python 3.9+
- CUDA GPU with 8GB+ VRAM (16GB+ recommended)
- PyTorch 2.0+

## Author

Logan Matthew Napolitano — Proprioceptive AI
