"""
CF-HoT Probe Architecture — Contrastive Fiber, Heads-of-Tails

This is the exact architecture that produced 999× separation ratios
across Falcon-Mamba 7B, Mistral 7B, and Qwen models.

Architecture:
    FiberProjection: hidden_dim → fiber_dim (16) via learned layer-weighted aggregation
    ProbeHead: fiber_dim (16) → 1 via 3-layer MLP

Author: Logan Matthew Napolitano / Proprioceptive AI
"""

from typing import List

import torch
import torch.nn as nn
import torch.nn.functional as F


class FiberProjection(nn.Module):
    """Project hidden states from multiple layers into fiber space.

    Takes hidden states from 3 probe layers, projects each to fiber_dim,
    then aggregates with learned softmax weights.

    This is the geometric core of the probe — it finds the 16-dimensional
    behavioral subspace where behaviors are linearly separable.
    """

    def __init__(self, hidden_dim: int = 4096, fiber_dim: int = 16,
                 n_layers: int = 3, use_bias: bool = False):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.fiber_dim = fiber_dim
        self.n_layers = n_layers

        self.projections = nn.ModuleList([
            nn.Linear(hidden_dim, fiber_dim, bias=use_bias)
            for _ in range(n_layers)
        ])
        self.layer_weights = nn.Parameter(torch.ones(n_layers) / n_layers)

    def forward(self, hidden_states_list: List[torch.Tensor]) -> torch.Tensor:
        """
        Args:
            hidden_states_list: List of [batch, seq_len, hidden_dim] or [batch, hidden_dim] tensors
        Returns:
            Aggregated fiber representation, same shape but last dim = fiber_dim
        """
        fibers = [proj(h.float()) for proj, h in zip(self.projections, hidden_states_list)]
        weights = F.softmax(self.layer_weights, dim=0)
        return sum(w * f for w, f in zip(weights, fibers))


class ProbeHead(nn.Module):
    """Classify behavioral patterns from fiber representation.

    3-layer MLP: fiber_dim → hidden → hidden → 1, with GELU activation.
    Output is sigmoid-squashed to [0, 1].
    """

    def __init__(self, fiber_dim: int = 16, hidden_dim: int = 64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(fiber_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, 1),
        )

    def forward(self, fiber: torch.Tensor) -> torch.Tensor:
        return torch.sigmoid(self.net(fiber))


class CognitiveProbe(nn.Module):
    """Complete probe: FiberProjection + ProbeHead.

    Usage:
        probe = CognitiveProbe(hidden_dim=4096, n_layers=3)
        score = probe(hidden_states_list)  # → [batch, 1] or [batch, seq, 1]
    """

    def __init__(self, hidden_dim: int = 4096, fiber_dim: int = 16,
                 head_hidden: int = 64, n_layers: int = 3):
        super().__init__()
        self.fiber_projection = FiberProjection(hidden_dim, fiber_dim, n_layers)
        self.head = ProbeHead(fiber_dim, head_hidden)

    def forward(self, hidden_states_list: List[torch.Tensor]) -> torch.Tensor:
        fiber = self.fiber_projection(hidden_states_list)
        return self.head(fiber)
