"""
Core Cradle Operations — scan() and generate()

scan():  Train probes on model, produce behavioral report card
generate(): Train probes + optimize LoRA adapter to hit target profile

These use the exact training loops that produced 999× separation ratios.

Author: Logan Matthew Napolitano / Proprioceptive AI
"""

import json
import os
import random
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

from .configs import ModelConfig, detect_model_config, resolve_model
from .data import (
    ALL_DIMS,
    ENHANCEMENT_DIMS,
    ENHANCEMENT_GENERATORS,
    SUPPRESSION_DIMS,
    get_suppression_label_fn,
)
from .probes import CognitiveProbe, FiberProjection, ProbeHead


# ═══════════════════════════════════════════════════════════════════════════════
# SEPARATION METRIC
# ═══════════════════════════════════════════════════════════════════════════════

def compute_separation(pos_scores: List[float], neg_scores: List[float]) -> float:
    """Compute separation ratio: mean(positive) / mean(negative).

    This is the exact metric used in all validation experiments.
    999× means positive examples score 999 times higher than negative ones.
    """
    if not pos_scores or not neg_scores:
        return 0.0
    pos_mean = sum(pos_scores) / len(pos_scores)
    neg_mean = sum(neg_scores) / len(neg_scores)
    return pos_mean / max(neg_mean, 0.001)


# ═══════════════════════════════════════════════════════════════════════════════
# ENHANCEMENT PROBE TRAINING (per-sequence, last-token)
# ═══════════════════════════════════════════════════════════════════════════════

def train_enhancement_probe(
    probe_name: str,
    model,
    tokenizer,
    config: ModelConfig,
    device: torch.device,
    steps: Optional[int] = None,
    verbose: bool = True,
) -> Tuple[FiberProjection, ProbeHead, float]:
    """Train a per-sequence enhancement probe. Returns (fiber, head, best_separation)."""

    gen_fn = ENHANCEMENT_GENERATORS[probe_name]
    steps = steps or config.enhancement_steps

    if verbose:
        print(f"\n  Training {probe_name} probe ({steps} steps)...")

    samples = gen_fn(3000)
    tokenized = []
    for s in samples:
        enc = tokenizer(
            s["text"],
            max_length=config.max_seq_length,
            truncation=True,
            padding="max_length",
            return_tensors="pt",
        )
        tokenized.append({
            "input_ids": enc["input_ids"].squeeze(0),
            "attention_mask": enc["attention_mask"].squeeze(0),
            "label": torch.tensor([s["label"]], dtype=torch.float),
        })

    fiber = FiberProjection(config.hidden_dim, config.fiber_dim, len(config.probe_layers)).to(device)
    head = ProbeHead(config.fiber_dim, config.head_hidden).to(device)
    optimizer = torch.optim.AdamW(
        list(fiber.parameters()) + list(head.parameters()),
        lr=config.enhancement_lr,
    )

    best_sep = 0.0
    fiber.train()
    head.train()
    step = 0
    bs = config.batch_size

    while step < steps:
        random.shuffle(tokenized)
        for i in range(0, len(tokenized) - bs, bs):
            if step >= steps:
                break

            batch_ids = torch.stack([tokenized[i + j]["input_ids"] for j in range(bs)]).to(device)
            batch_mask = torch.stack([tokenized[i + j]["attention_mask"] for j in range(bs)]).to(device)
            batch_labels = torch.stack([tokenized[i + j]["label"] for j in range(bs)]).to(device)

            with torch.no_grad():
                out = model(
                    input_ids=batch_ids,
                    attention_mask=batch_mask,
                    output_hidden_states=True,
                    return_dict=True,
                )
                hs = [out.hidden_states[l][:, -1, :] for l in config.probe_layers]

            pred = head(fiber(hs))
            loss = F.binary_cross_entropy(pred, batch_labels)

            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(
                list(fiber.parameters()) + list(head.parameters()), 1.0
            )
            optimizer.step()
            step += 1

            # Evaluate every 500 steps
            if step % 500 == 0:
                fiber.eval()
                head.eval()
                pos_scores, neg_scores = [], []
                with torch.no_grad():
                    for j in range(0, min(500, len(tokenized)), bs):
                        actual_bs = min(bs, len(tokenized) - j)
                        eval_ids = torch.stack(
                            [tokenized[j + k]["input_ids"] for k in range(actual_bs)]
                        ).to(device)
                        eval_mask = torch.stack(
                            [tokenized[j + k]["attention_mask"] for k in range(actual_bs)]
                        ).to(device)
                        eval_labels = [tokenized[j + k]["label"].item() for k in range(actual_bs)]
                        try:
                            eval_out = model(
                                input_ids=eval_ids,
                                attention_mask=eval_mask,
                                output_hidden_states=True,
                                return_dict=True,
                            )
                            eval_hs = [eval_out.hidden_states[l][:, -1, :] for l in config.probe_layers]
                            scores = head(fiber(eval_hs)).squeeze(-1).cpu().tolist()
                            if not isinstance(scores, list):
                                scores = [scores]
                            for score, label in zip(scores, eval_labels):
                                (pos_scores if label > 0.5 else neg_scores).append(float(score))
                        except Exception:
                            continue

                sep = compute_separation(pos_scores, neg_scores)
                if sep > best_sep:
                    best_sep = sep
                if verbose:
                    print(f"    Step {step:5d} | Loss: {loss.item():.4f} | Sep: {sep:.1f}×")
                fiber.train()
                head.train()

    if verbose:
        print(f"    ✓ {probe_name}: {best_sep:.1f}× separation")

    return fiber, head, best_sep


# ═══════════════════════════════════════════════════════════════════════════════
# SUPPRESSION PROBE TRAINING (per-token, all positions)
# ═══════════════════════════════════════════════════════════════════════════════

def _get_diverse_texts(tokenizer, config: ModelConfig, n: int = 2000) -> List[Dict]:
    """Load wikitext or generate synthetic diverse text for suppression training."""
    tokenized = []

    try:
        from datasets import load_dataset
        ds = load_dataset("wikitext", "wikitext-2-raw-v1", split="train")
        texts = [ex["text"] for ex in ds if len(ex["text"].strip()) > 100][:n]
    except Exception:
        # Fallback: synthetic diverse text
        prompts = [
            "The history of computing begins with",
            "In modern philosophy, the question of",
            "Climate science has shown that",
            "The economics of global trade involves",
            "Quantum mechanics describes how",
            "The evolution of language reflects",
            "Machine learning algorithms can",
            "The structure of DNA reveals",
            "Political theory suggests that",
            "The psychology of decision making",
            "In classical literature, themes of",
            "The biology of cellular processes",
        ]
        texts = []
        for _ in range(n):
            texts.append(
                random.choice(prompts) + " " +
                " ".join(random.choices(
                    ["the", "and", "of", "to", "in", "is", "that", "for", "it",
                     "with", "as", "was", "on", "are", "by", "this", "be", "from",
                     "or", "an", "which", "but", "not", "have", "had", "has"],
                    k=random.randint(50, 200),
                ))
            )

    for text in texts:
        enc = tokenizer(
            text,
            max_length=config.max_seq_length,
            truncation=True,
            padding="max_length",
            return_tensors="pt",
        )
        tokenized.append({
            "input_ids": enc["input_ids"].squeeze(0),
            "attention_mask": enc["attention_mask"].squeeze(0),
        })

    return tokenized


def train_suppression_probe(
    probe_name: str,
    model,
    tokenizer,
    config: ModelConfig,
    device: torch.device,
    steps: Optional[int] = None,
    verbose: bool = True,
) -> Tuple[FiberProjection, ProbeHead, float]:
    """Train a per-token suppression probe. Returns (fiber, head, best_separation)."""

    label_fn = get_suppression_label_fn(probe_name, tokenizer)
    steps = steps or config.suppression_steps

    if verbose:
        print(f"\n  Training {probe_name} probe ({steps} steps, per-token)...")

    tokenized = _get_diverse_texts(tokenizer, config)
    if verbose:
        print(f"    {len(tokenized)} text samples loaded")

    fiber = FiberProjection(config.hidden_dim, config.fiber_dim, len(config.probe_layers)).to(device)
    head = ProbeHead(config.fiber_dim, config.head_hidden).to(device)
    optimizer = torch.optim.AdamW(
        list(fiber.parameters()) + list(head.parameters()),
        lr=config.suppression_lr,
    )

    best_sep = 0.0
    fiber.train()
    head.train()
    step = 0
    bs = config.batch_size

    while step < steps:
        random.shuffle(tokenized)
        for i in range(0, len(tokenized) - bs, bs):
            if step >= steps:
                break

            batch_ids = torch.stack([tokenized[i + j]["input_ids"] for j in range(bs)]).to(device)
            batch_mask = torch.stack([tokenized[i + j]["attention_mask"] for j in range(bs)]).to(device)

            # Compute per-token labels
            labels = label_fn(batch_ids, tokenizer)

            with torch.no_grad():
                out = model(
                    input_ids=batch_ids,
                    attention_mask=batch_mask,
                    output_hidden_states=True,
                    return_dict=True,
                )
                # ALL token positions, not just last
                hs = [out.hidden_states[l] for l in config.probe_layers]

            B, S, D = hs[0].shape
            hs_flat = [h.reshape(B * S, D) for h in hs]
            pred = head(fiber(hs_flat)).reshape(B, S)

            # Masked BCE loss
            mask = batch_mask.float()
            bce = F.binary_cross_entropy(pred, labels, reduction="none")
            loss = (bce * mask).sum() / mask.sum()

            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(
                list(fiber.parameters()) + list(head.parameters()), 1.0
            )
            optimizer.step()
            step += 1

            if step % 500 == 0:
                fiber.eval()
                head.eval()
                with torch.no_grad():
                    pos_mask = (labels > 0.5) & (mask > 0.5)
                    neg_mask = (labels < 0.5) & (mask > 0.5)
                    pos_mean = pred[pos_mask].mean().item() if pos_mask.any() else 0
                    neg_mean = pred[neg_mask].mean().item() if neg_mask.any() else 0.001
                    sep = pos_mean / max(neg_mean, 0.001)

                if sep > best_sep:
                    best_sep = sep
                if verbose:
                    pt = int(pos_mask.sum().item())
                    print(f"    Step {step:5d} | Loss: {loss.item():.4f} | Sep: {sep:.1f}× | +tokens: {pt}")
                fiber.train()
                head.train()

    if verbose:
        print(f"    ✓ {probe_name}: {best_sep:.1f}× separation")

    return fiber, head, best_sep


# ═══════════════════════════════════════════════════════════════════════════════
# PUBLIC API: scan()
# ═══════════════════════════════════════════════════════════════════════════════

def scan(
    model_name_or_path: str,
    dims: Optional[List[str]] = None,
    steps: Optional[int] = None,
    verbose: bool = True,
) -> Dict[str, Dict]:
    """Run behavioral scan on a model. Returns report card.

    Args:
        model_name_or_path: HuggingFace model ID, local path, or alias (e.g. "mamba")
        dims: Which behavioral dimensions to probe (default: all 9)
        steps: Override training steps per probe
        verbose: Print progress

    Returns:
        Dict mapping dimension name to {"score": float, "separation": float, "status": str}
    """
    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig

    dims = dims or ALL_DIMS

    # Resolve model config
    config = resolve_model(model_name_or_path)
    model_id = config.model_id if config else model_name_or_path

    if verbose:
        from rich.console import Console
        console = Console()
        console.print(f"\n[bold]CRADLE SCAN[/bold]")
        console.print(f"  Model: {model_id}")
        if config and config.verified_separations:
            console.print(f"  Status: [green]Validated model[/green]")
        elif config:
            console.print(f"  Status: [yellow]Known architecture, unvalidated[/yellow]")
        else:
            console.print(f"  Status: [red]Unknown model — results may vary[/red]")

    # Load model
    if verbose:
        print(f"\n  Loading model...")

    tokenizer = AutoTokenizer.from_pretrained(model_id, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    model = AutoModelForCausalLM.from_pretrained(
        model_id,
        quantization_config=BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_compute_dtype=torch.float16,
            bnb_4bit_use_double_quant=True,
            bnb_4bit_quant_type="nf4",
        ),
        device_map="auto",
        trust_remote_code=True,
    )
    model.eval()

    # Auto-detect config if not in registry
    if config is None:
        config = detect_model_config(model)
        if config is None:
            raise RuntimeError(
                f"Cannot determine architecture for {model_id}. "
                "Please use a validated model or file a request."
            )

    device = next(model.parameters()).device

    if verbose:
        print(f"  Architecture: {config.architecture} ({config.hidden_dim}d, {config.n_layers}L)")
        print(f"  Probe layers: {config.probe_layers}")
        print(f"  Probing {len(dims)} dimensions: {', '.join(dims)}\n")

    # Train probes
    results = {}
    for dim in dims:
        if dim in ENHANCEMENT_DIMS:
            fiber, head, sep = train_enhancement_probe(
                dim, model, tokenizer, config, device, steps=steps, verbose=verbose
            )
        elif dim in SUPPRESSION_DIMS:
            fiber, head, sep = train_suppression_probe(
                dim, model, tokenizer, config, device, steps=steps, verbose=verbose
            )
        else:
            if verbose:
                print(f"  [skip] Unknown dimension: {dim}")
            continue

        # Determine status
        if sep > 100:
            status = "excellent"
        elif sep > 10:
            status = "good"
        elif sep > 2:
            status = "weak"
        else:
            status = "failed"

        results[dim] = {
            "separation": round(sep, 2),
            "status": status,
        }

    # Print report
    if verbose:
        _print_scan_report(results, config)

    return results


def _print_scan_report(results: Dict, config: ModelConfig):
    """Pretty-print behavioral report card."""
    try:
        from rich.console import Console
        from rich.table import Table

        console = Console()
        table = Table(title=f"Behavioral Report — {config.model_id}")
        table.add_column("Dimension", style="cyan")
        table.add_column("Separation", justify="right")
        table.add_column("Status", justify="center")

        for dim, info in results.items():
            sep = info["separation"]
            status = info["status"]
            if status == "excellent":
                style = "[bold green]✓ excellent[/bold green]"
            elif status == "good":
                style = "[green]✓ good[/green]"
            elif status == "weak":
                style = "[yellow]⚠ weak[/yellow]"
            else:
                style = "[red]✗ failed[/red]"
            table.add_row(dim, f"{sep:.1f}×", style)

        console.print()
        console.print(table)
        console.print()
    except ImportError:
        print("\n  BEHAVIORAL REPORT")
        print("  " + "─" * 50)
        for dim, info in results.items():
            print(f"  {dim:<15} {info['separation']:>8.1f}× {info['status']}")
        print("  " + "─" * 50)


# ═══════════════════════════════════════════════════════════════════════════════
# PUBLIC API: generate()
# ═══════════════════════════════════════════════════════════════════════════════

# Presets — target scores for each behavioral dimension
PRESETS = {
    "professional": {
        "depth": 0.90, "specificity": 0.90, "calibration": 0.85,
        "coherence": 0.95, "focus": 0.90,
        "sycophancy": 0.05, "hedging": 0.10, "verbosity": 0.10, "repetition": 0.02,
    },
    "creative": {
        "depth": 0.85, "specificity": 0.60, "calibration": 0.40,
        "coherence": 0.80, "focus": 0.70,
        "sycophancy": 0.10, "hedging": 0.05, "verbosity": 0.30, "repetition": 0.02,
    },
    "cautious": {
        "depth": 0.70, "specificity": 0.80, "calibration": 0.95,
        "coherence": 0.95, "focus": 0.85,
        "sycophancy": 0.05, "hedging": 0.60, "verbosity": 0.20, "repetition": 0.02,
    },
    "direct": {
        "depth": 0.80, "specificity": 0.95, "calibration": 0.80,
        "coherence": 0.90, "focus": 0.95,
        "sycophancy": 0.02, "hedging": 0.02, "verbosity": 0.05, "repetition": 0.01,
    },
}


def generate(
    model_name_or_path: str,
    preset: Optional[str] = None,
    targets: Optional[Dict[str, float]] = None,
    output_dir: str = "./adapters",
    probe_steps: Optional[int] = None,
    adapter_steps: int = 200,
    verbose: bool = True,
) -> str:
    """Generate a behavioral LoRA adapter.

    1. Train probes on the model (scan phase)
    2. Optimize LoRA weights to minimize distance to target profile
    3. Save adapter files

    Args:
        model_name_or_path: Model to adapt
        preset: Named profile ("professional", "creative", "cautious", "direct")
        targets: Custom target dict {dim: target_score}
        output_dir: Where to save adapter
        probe_steps: Override probe training steps
        adapter_steps: LoRA optimization steps
        verbose: Print progress

    Returns:
        Path to saved adapter directory
    """
    from peft import LoraConfig, get_peft_model, TaskType
    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig

    if preset and preset in PRESETS:
        target_profile = PRESETS[preset]
    elif targets:
        target_profile = targets
    else:
        target_profile = PRESETS["professional"]
        preset = "professional"

    # Resolve config
    config = resolve_model(model_name_or_path)
    model_id = config.model_id if config else model_name_or_path

    if verbose:
        print(f"\n{'='*60}")
        print(f"  CRADLE ADAPTER GENERATION")
        print(f"  Model: {model_id}")
        print(f"  Preset: {preset or 'custom'}")
        print(f"{'='*60}")

    # Load model
    tokenizer = AutoTokenizer.from_pretrained(model_id, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    model = AutoModelForCausalLM.from_pretrained(
        model_id,
        quantization_config=BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_compute_dtype=torch.float16,
            bnb_4bit_use_double_quant=True,
            bnb_4bit_quant_type="nf4",
        ),
        device_map="auto",
        trust_remote_code=True,
    )
    model.eval()

    if config is None:
        config = detect_model_config(model)
    device = next(model.parameters()).device

    # Phase 1: Train probes
    if verbose:
        print(f"\n  Phase 1: Training behavioral probes...")

    trained_probes = {}
    separations = {}
    dims_to_train = [d for d in target_profile.keys() if d in ALL_DIMS]

    for dim in dims_to_train:
        if dim in ENHANCEMENT_DIMS:
            fiber, head, sep = train_enhancement_probe(
                dim, model, tokenizer, config, device,
                steps=probe_steps, verbose=verbose,
            )
        else:
            fiber, head, sep = train_suppression_probe(
                dim, model, tokenizer, config, device,
                steps=probe_steps, verbose=verbose,
            )
        trained_probes[dim] = (fiber, head)
        separations[dim] = sep

    # Phase 2: Apply LoRA and optimize
    if verbose:
        print(f"\n  Phase 2: Optimizing LoRA adapter ({adapter_steps} steps)...")

    lora_config = LoraConfig(
        task_type=TaskType.CAUSAL_LM,
        r=config.lora_r,
        lora_alpha=config.lora_alpha,
        target_modules=config.lora_target_modules,
        lora_dropout=config.lora_dropout,
    )

    peft_model = get_peft_model(model, lora_config)
    peft_model.print_trainable_parameters()

    lora_optimizer = torch.optim.AdamW(
        [p for p in peft_model.parameters() if p.requires_grad],
        lr=1e-4,
    )

    # Generate calibration prompts for optimization
    cal_prompts = [
        "Explain how neural networks learn.",
        "What are the pros and cons of remote work?",
        "How does the immune system fight infections?",
        "What causes economic recessions?",
        "Describe the process of photosynthesis.",
        "What are the ethical implications of AI?",
        "How does encryption protect data?",
        "What factors influence climate change?",
    ]

    for opt_step in range(adapter_steps):
        prompt = random.choice(cal_prompts)
        inputs = tokenizer(
            prompt,
            max_length=config.max_seq_length,
            truncation=True,
            padding="max_length",
            return_tensors="pt",
        ).to(device)

        # Forward through LoRA-adapted model
        outputs = peft_model(
            **inputs,
            output_hidden_states=True,
            return_dict=True,
        )

        # Compute probe-alignment loss (PA loss)
        total_loss = torch.tensor(0.0, device=device, requires_grad=True)

        for dim, (fiber, head) in trained_probes.items():
            fiber.eval()
            head.eval()
            target = target_profile[dim]

            if dim in ENHANCEMENT_DIMS:
                hs = [outputs.hidden_states[l][:, -1, :] for l in config.probe_layers]
            else:
                hs = [outputs.hidden_states[l] for l in config.probe_layers]
                B, S, D = hs[0].shape
                hs = [h.reshape(B * S, D) for h in hs]

            pred = head(fiber(hs))

            if dim in SUPPRESSION_DIMS:
                pred = pred.mean()  # Average over tokens

            # Loss: push probe reading toward target
            pa_loss = (pred.squeeze() - target) ** 2
            total_loss = total_loss + pa_loss

        lora_optimizer.zero_grad()
        total_loss.backward()
        lora_optimizer.step()

        if verbose and (opt_step + 1) % 50 == 0:
            print(f"    Adapter step {opt_step + 1}/{adapter_steps} | PA Loss: {total_loss.item():.4f}")

    # Save adapter
    model_short = model_id.split("/")[-1].lower().replace("-", "_")
    preset_name = preset or "custom"
    adapter_name = f"{model_short}-{preset_name}-v1"
    adapter_path = os.path.join(output_dir, adapter_name)
    os.makedirs(adapter_path, exist_ok=True)

    peft_model.save_pretrained(adapter_path)
    tokenizer.save_pretrained(adapter_path)

    # Save metadata
    meta = {
        "model_id": model_id,
        "architecture": config.architecture,
        "preset": preset_name,
        "targets": target_profile,
        "separations": {k: round(v, 2) for k, v in separations.items()},
        "probe_layers": config.probe_layers,
        "lora_r": config.lora_r,
        "lora_alpha": config.lora_alpha,
        "adapter_steps": adapter_steps,
        "version": "0.2.0",
        "timestamp": datetime.now().isoformat(),
    }
    with open(os.path.join(adapter_path, "cradle_meta.json"), "w") as f:
        json.dump(meta, f, indent=2)

    if verbose:
        print(f"\n  ✓ Adapter saved: {adapter_path}")
        print(f"  Load with: model = PeftModel.from_pretrained(base_model, '{adapter_path}')")

    return adapter_path
