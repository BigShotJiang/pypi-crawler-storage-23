"""
Training Data Generators & Per-Token Labeling Functions

Two types of probes, two types of data:

ENHANCEMENT probes (per-sequence label):
    depth, specificity, calibration, focus, coherence
    Label = 0 (good behavior) or 1 (bad behavior) for the whole response
    Uses contrastive pairs: good response vs bad response to same question

SUPPRESSION probes (per-token label):
    repetition, hedging, sycophancy, verbosity
    Label = per-token float [0,1] marking which tokens exhibit the behavior
    Trained on diverse text (wikitext) with automatic labeling functions

Author: Logan Matthew Napolitano / Proprioceptive AI
"""

import random
from typing import Callable, Dict, List, Tuple

import torch


# ═══════════════════════════════════════════════════════════════════════════════
# PATTERN LISTS (validated across Mamba, Mistral, Qwen)
# ═══════════════════════════════════════════════════════════════════════════════

HEDGE_PATTERNS = [
    "i think", "maybe", "perhaps", "possibly", "probably", "might", "could be",
    "it seems", "apparently", "generally", "usually", "often", "sometimes",
    "in my opinion", "i believe", "i feel", "somewhat", "relatively",
    "to some extent", "more or less", "kind of", "sort of", "arguably",
    "it appears", "presumably", "supposedly", "allegedly", "reportedly",
]

SYCOPHANCY_PATTERNS = [
    "great question", "excellent point", "you're right", "absolutely",
    "i agree", "that's correct", "good thinking", "well said", "exactly",
    "you're absolutely right", "that's a great", "wonderful", "fantastic",
    "brilliant", "perfect", "i couldn't agree more", "you make a great point",
]


# ═══════════════════════════════════════════════════════════════════════════════
# ENHANCEMENT DATA GENERATORS (per-sequence)
# ═══════════════════════════════════════════════════════════════════════════════

def gen_depth(n: int = 3000) -> List[Dict]:
    """Generate depth probe training data.
    label=1: shallow reasoning. label=0: deep chain-of-thought."""
    samples = []
    shallow = [
        ("What causes rain?", "Water falls from clouds."),
        ("How does gravity work?", "Things fall down."),
        ("Why is the sky blue?", "It just is that way."),
        ("Explain photosynthesis.", "Plants make food from sun."),
        ("What is democracy?", "People vote for leaders."),
        ("How do computers work?", "They process information."),
        ("Why do we sleep?", "Bodies need rest."),
        ("What causes earthquakes?", "The ground shakes."),
        ("How does the internet work?", "Data goes through wires."),
        ("What is DNA?", "It's the building blocks of life."),
        ("How do planes fly?", "Wings make them go up."),
        ("What is inflation?", "Prices go up over time."),
    ]
    deep = [
        ("What causes rain?",
         "Rain forms through the water cycle. First, the sun heats water in oceans "
         "causing evaporation. This water vapor rises and cools, condensing into clouds. "
         "When droplets become heavy enough, they fall as precipitation. This process is "
         "driven by solar energy and Earth's geography."),
        ("How does gravity work?",
         "Gravity is explained by Einstein's general relativity. Mass curves the fabric "
         "of spacetime, and objects follow geodesics through this curved space. The more "
         "massive an object, the more it curves spacetime around it, which we perceive as "
         "gravitational attraction."),
        ("Why is the sky blue?",
         "The sky appears blue due to Rayleigh scattering. When sunlight enters Earth's "
         "atmosphere, it collides with gas molecules. Blue light has a shorter wavelength, "
         "so it scatters more than other colors. This scattered blue light reaches our eyes "
         "from all directions, making the sky appear blue."),
        ("Explain photosynthesis.",
         "Photosynthesis converts light energy to chemical energy through two stages. In the "
         "light reactions, chlorophyll absorbs photons to split water molecules, producing ATP "
         "and NADPH. In the Calvin cycle, these molecules fix CO2 into glucose through a series "
         "of enzyme-catalyzed reactions."),
        ("What is democracy?",
         "Democracy is a system of governance where power derives from the consent of the "
         "governed. It operates through representative institutions, separation of powers, "
         "and protected individual rights. Different implementations include parliamentary, "
         "presidential, and direct democratic systems."),
        ("How do computers work?",
         "Computers operate through layers of abstraction. At the hardware level, transistors "
         "switch between on/off states representing binary digits. These are organized into logic "
         "gates that perform operations. The CPU fetches, decodes, and executes instructions from "
         "memory in a cycle."),
    ]
    for _ in range(n):
        if random.random() < 0.5:
            q, a = random.choice(shallow)
            samples.append({"text": f"{q}\n{a}", "label": 1})
        else:
            q, a = random.choice(deep)
            samples.append({"text": f"{q}\n{a}", "label": 0})
    return samples


def gen_specificity(n: int = 3000) -> List[Dict]:
    """Generate specificity probe training data.
    label=1: vague/generic. label=0: specific/concrete."""
    samples = []
    vague = [
        ("Best programming language?",
         "There are many good options depending on various factors and things you want to do."),
        ("How to lose weight?",
         "You should do different things and generally eat better and exercise somewhat more."),
        ("Career advice?",
         "It depends on many things. Think about stuff you like and various options."),
        ("How to learn faster?",
         "Try different methods and do things that work for you generally."),
        ("Best investment?",
         "There are various options depending on things like your situation."),
        ("How to fix a bug?",
         "You need to look at different parts and try various approaches until something works."),
        ("How to cook well?",
         "Practice with different recipes and use good ingredients and proper techniques."),
        ("How to be productive?",
         "Organize your time better and focus on important things and avoid distractions."),
    ]
    specific = [
        ("Best programming language?",
         "For web development, I recommend JavaScript with React. It has 97.6% browser support, "
         "18M+ npm packages, and average salary of $112k. For beginners, Python offers cleaner "
         "syntax and is used by 48% of developers."),
        ("How to lose weight?",
         "Create a 500 calorie daily deficit through diet. Eat 0.8-1g protein per pound bodyweight. "
         "Do 150 minutes moderate cardio weekly plus 2 strength sessions. Track intake with "
         "MyFitnessPal. Expect 1-2 lbs loss per week."),
        ("Career advice?",
         "In tech, data science roles pay $120k median with 22% growth. Required skills: Python, "
         "SQL, statistics. Start with Google Data Analytics Certificate (6 months, $39/month). "
         "Build portfolio on Kaggle."),
        ("Best investment?",
         "For long-term passive investing, VTSAX (Vanguard Total Stock Market) has returned 10.5% "
         "annually since 1992 with a 0.04% expense ratio. Dollar-cost average $500/month minimum."),
        ("How to fix a bug?",
         "Use a debugger to set breakpoints at the suspected function. Check the stack trace for "
         "the exact line number. Add assert statements to validate preconditions. Run git bisect "
         "to find the commit that introduced the regression."),
    ]
    for _ in range(n):
        if random.random() < 0.5:
            q, a = random.choice(vague)
            samples.append({"text": f"{q}\n{a}", "label": 1})
        else:
            q, a = random.choice(specific)
            samples.append({"text": f"{q}\n{a}", "label": 0})
    return samples


def gen_calibration(n: int = 3000) -> List[Dict]:
    """Generate calibration probe training data.
    label=1: overconfident. label=0: well-calibrated."""
    samples = []
    questions = [
        "Will AI replace jobs?", "Will this stock go up?", "Will it rain tomorrow?",
        "Will this idea succeed?", "Is this treatment effective?", "Will prices go up?",
        "Will the team win?", "Is this technology safe?", "Will the economy recover?",
        "Can we reverse climate change?", "Will this startup succeed?", "Is this diet healthy?",
    ]
    overconfident = [
        "Absolutely, this will definitely happen without any doubt whatsoever.",
        "This is 100% guaranteed to occur. There is no chance it won't happen.",
        "I can tell you with complete certainty that this will work perfectly.",
        "There is absolutely zero chance this will fail. It's a sure thing.",
        "Without any shadow of a doubt, this is guaranteed to succeed.",
        "I am completely certain. This is an absolute fact with no uncertainty.",
    ]
    calibrated = [
        "This is uncertain and depends on multiple factors. Based on available evidence, I'd estimate "
        "roughly 40-60% probability, but there's significant uncertainty in this estimate.",
        "I can't predict this with high confidence. Historical patterns suggest it's possible but "
        "not guaranteed. There are arguments on both sides worth considering.",
        "The evidence is mixed on this. Some indicators suggest yes, others suggest no. I'd recommend "
        "considering multiple scenarios rather than assuming any single outcome.",
        "This involves substantial uncertainty. While there are reasons for optimism, there are also "
        "significant risk factors. A balanced view would acknowledge both possibilities.",
        "I don't have enough information to give a confident answer. What I can say is that experts "
        "disagree on this, which suggests the true answer isn't obvious.",
        "The honest answer is that nobody knows for sure. There are credible arguments pointing in "
        "different directions, and the outcome likely depends on factors that are hard to predict.",
    ]
    for _ in range(n):
        q = random.choice(questions)
        if random.random() < 0.5:
            samples.append({"text": f"{q}\n{random.choice(overconfident)}", "label": 1})
        else:
            samples.append({"text": f"{q}\n{random.choice(calibrated)}", "label": 0})
    return samples


def gen_focus(n: int = 3000) -> List[Dict]:
    """Generate focus probe training data.
    label=1: topic drift. label=0: on-topic."""
    samples = []
    questions = [
        "How do I fix a memory leak in Python?", "What's the capital of France?",
        "How do I center a div in CSS?", "Explain TCP/IP.", "What is photosynthesis?",
        "How does a compiler work?", "What causes inflation?", "How do vaccines work?",
        "What is machine learning?", "How does encryption work?", "Explain relativity.",
        "What is DNA replication?",
    ]
    drifting = [
        "That's a good question. Speaking of which, this reminds me of something totally different. "
        "Did you know that the average person walks 100,000 miles in their lifetime? Fascinating! "
        "By the way, I love hiking. Oh right, your question...",
        "Sure, let me answer that. But first, have you heard about the new movie coming out? It's "
        "amazing! Also, I had the best coffee today. Anyway, what were we talking about? Oh yes, "
        "let me try to answer...",
        "Great question! This makes me think of my favorite book. Have you read any good books "
        "lately? Reading is so important. Also, the weather has been great recently. But back to "
        "your question, sort of...",
        "I'll answer that in a moment. First, did you know that octopi have three hearts? That's "
        "incredible! Also, speaking of animals, my neighbor has the cutest dog. Anyway, your "
        "question was about something, right?",
    ]
    focused = [
        "To directly answer your question: here is a clear, step-by-step explanation. First, you "
        "need to understand the core concept. Second, apply it to your specific situation. Third, "
        "verify the results match your expectations.",
        "The answer involves several key aspects, all directly related to what you asked. The "
        "primary mechanism works as follows: the input is processed through a series of well-defined "
        "stages, each producing a specific output that feeds into the next stage.",
        "Let me address this directly and comprehensively. The fundamental principle at work here "
        "is straightforward once broken down. The process begins with initialization, proceeds "
        "through transformation, and concludes with output generation.",
        "Here's a focused explanation. The core idea is that the system operates through a defined "
        "pipeline. Step one handles input processing. Step two performs the main computation. Step "
        "three validates the output.",
    ]
    for _ in range(n):
        q = random.choice(questions)
        if random.random() < 0.5:
            samples.append({"text": f"{q}\n{random.choice(drifting)}", "label": 1})
        else:
            samples.append({"text": f"{q}\n{random.choice(focused)}", "label": 0})
    return samples


def gen_coherence(n: int = 3000) -> List[Dict]:
    """Generate coherence probe training data.
    label=1: self-contradictory. label=0: logically consistent."""
    samples = []
    topics = [
        "exercise", "coffee", "saving money", "reading", "coding", "sleep",
        "meditation", "education", "social media", "remote work", "AI", "diet",
    ]
    contradictory = [
        "{topic} is extremely beneficial for everyone. However, {topic} is actually harmful and "
        "should be avoided. It helps tremendously but also causes serious problems. In conclusion, "
        "{topic} is both the best and worst thing you can do.",
        "The evidence clearly shows that {topic} is essential. But actually, research proves "
        "{topic} is unnecessary. Studies confirm its benefits while simultaneously demonstrating "
        "its dangers. It's both proven effective and proven ineffective.",
        "Everyone should embrace {topic} immediately. On the other hand, nobody should ever do "
        "{topic}. The advantages are overwhelming, yet the disadvantages completely outweigh them. "
        "It works perfectly and doesn't work at all.",
        "{topic} has been proven to improve outcomes by 50%. However, {topic} has been shown to "
        "worsen outcomes by 50%. The positive results are undeniable, as are the negative results. "
        "Both conclusions are simultaneously true.",
    ]
    coherent = [
        "{topic} has both benefits and limitations that depend on context. Research suggests "
        "moderate engagement provides clear advantages, including improved outcomes in several "
        "measurable areas. However, excessive engagement can lead to diminishing returns. "
        "Therefore, a balanced approach is recommended.",
        "The evidence on {topic} is nuanced but largely consistent. Multiple studies show positive "
        "effects when implemented properly, particularly in terms of long-term outcomes. Some "
        "concerns exist about specific edge cases, but these can be mitigated with proper planning.",
        "When examining {topic}, several key factors emerge. First, the underlying mechanism is "
        "well-understood scientifically. Second, practical implementations have shown consistent "
        "positive results across diverse populations. Third, potential downsides are limited and "
        "manageable.",
        "A careful analysis of {topic} reveals consistent patterns. The primary benefit stems from "
        "its effect on foundational processes. Secondary benefits include improved efficiency and "
        "reduced costs. While some limitations exist, they are predictable and can be addressed.",
    ]
    for _ in range(n):
        topic = random.choice(topics)
        if random.random() < 0.5:
            t = random.choice(contradictory).format(topic=topic)
            samples.append({"text": f"Is {topic} good?\n{t}", "label": 1})
        else:
            t = random.choice(coherent).format(topic=topic)
            samples.append({"text": f"Is {topic} good?\n{t}", "label": 0})
    return samples


# Lookup table
ENHANCEMENT_GENERATORS = {
    "depth": gen_depth,
    "specificity": gen_specificity,
    "calibration": gen_calibration,
    "focus": gen_focus,
    "coherence": gen_coherence,
}


# ═══════════════════════════════════════════════════════════════════════════════
# SUPPRESSION PER-TOKEN LABELING FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

def compute_repetition_labels(input_ids: torch.Tensor, window: int = 32) -> torch.Tensor:
    """Per-token: label=1 if token appeared in preceding window.

    This catches n-gram repetition at the token level. A token that repeats
    within a 32-token window is flagged. The probe learns to detect the
    hidden-state signature of repetitive generation.
    """
    B, S = input_ids.shape
    labels = torch.zeros(B, S, device=input_ids.device)
    for offset in range(1, min(window + 1, S)):
        if offset < S:
            matches = (input_ids[:, offset:] == input_ids[:, :-offset]).float()
            labels[:, offset:] = torch.maximum(labels[:, offset:], matches)
    return labels


def compute_pattern_labels(input_ids: torch.Tensor, tokenizer,
                           patterns: List[str]) -> torch.Tensor:
    """Per-token: label=1 for tokens that are part of a matching pattern.

    Decodes the token IDs to text, finds pattern matches, then maps character
    positions back to token positions. This is the exact labeling used for
    hedging and sycophancy probes.
    """
    B, S = input_ids.shape
    labels = torch.zeros(B, S, device=input_ids.device)
    for b in range(B):
        text = tokenizer.decode(input_ids[b], skip_special_tokens=True).lower()
        tokens = tokenizer.convert_ids_to_tokens(input_ids[b])
        for pattern in patterns:
            start = 0
            while True:
                idx = text.find(pattern, start)
                if idx == -1:
                    break
                # Map character position to token position
                current_char = 0
                token_pos = 0
                for t_idx, token in enumerate(tokens):
                    token_text = tokenizer.convert_tokens_to_string([token])
                    if current_char + len(token_text) > idx:
                        token_pos = t_idx
                        break
                    current_char += len(token_text)
                pattern_tokens = len(tokenizer.encode(pattern, add_special_tokens=False))
                for t in range(token_pos, min(token_pos + pattern_tokens + 1, S)):
                    labels[b, t] = 1.0
                start = idx + len(pattern)
    return labels


def compute_verbosity_labels(input_ids: torch.Tensor,
                             threshold: int = 50) -> torch.Tensor:
    """Per-token: increasing label after threshold position.

    Tokens beyond position 50 get linearly increasing labels from 0.3 to 1.0.
    The probe learns that later tokens in overly long responses are verbose.
    """
    B, S = input_ids.shape
    labels = torch.zeros(B, S, device=input_ids.device)
    for b in range(B):
        if S > threshold:
            labels[b, threshold:] = torch.linspace(
                0.3, 1.0, S - threshold, device=input_ids.device
            )
    return labels


def get_suppression_label_fn(behavior: str, tokenizer) -> Callable:
    """Return the labeling function for a suppression behavior."""
    if behavior == "repetition":
        return lambda ids, tok: compute_repetition_labels(ids, 32)
    elif behavior == "hedging":
        return lambda ids, tok: compute_pattern_labels(ids, tok, HEDGE_PATTERNS)
    elif behavior == "sycophancy":
        return lambda ids, tok: compute_pattern_labels(ids, tok, SYCOPHANCY_PATTERNS)
    elif behavior == "verbosity":
        return lambda ids, tok: compute_verbosity_labels(ids)
    else:
        raise ValueError(f"Unknown suppression behavior: {behavior}")


# ═══════════════════════════════════════════════════════════════════════════════
# ALL BEHAVIORAL DIMENSIONS
# ═══════════════════════════════════════════════════════════════════════════════

ENHANCEMENT_DIMS = ["depth", "specificity", "calibration", "focus", "coherence"]
SUPPRESSION_DIMS = ["repetition", "hedging", "sycophancy", "verbosity"]
ALL_DIMS = ENHANCEMENT_DIMS + SUPPRESSION_DIMS
