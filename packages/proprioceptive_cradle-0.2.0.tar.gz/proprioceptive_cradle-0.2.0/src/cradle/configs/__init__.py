"""
Validated model configurations.

Each config contains the exact parameters that produced verified separation ratios.
Models NOT in this registry will be refused or warned.

Author: Logan Matthew Napolitano / Proprioceptive AI
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass
class ModelConfig:
    """Validated configuration for a specific model architecture."""
    model_id: str
    architecture: str
    hidden_dim: int
    n_layers: int
    probe_layers: List[int]
    fiber_dim: int = 16
    head_hidden: int = 64
    # Training hyperparams that produced verified results
    enhancement_lr: float = 5e-5
    suppression_lr: float = 5e-5
    enhancement_steps: int = 2500
    suppression_steps: int = 2500
    batch_size: int = 2
    max_seq_length: int = 256
    # LoRA config for adapter generation
    lora_r: int = 16
    lora_alpha: int = 32
    lora_target_modules: List[str] = field(default_factory=lambda: ["q_proj", "v_proj"])
    lora_dropout: float = 0.05
    # Verified results
    verified_separations: Dict[str, float] = field(default_factory=dict)


# ═══════════════════════════════════════════════════════════════════════════════
# VALIDATED MODEL REGISTRY
# Only models with verified probe results are included.
# ═══════════════════════════════════════════════════════════════════════════════

VALIDATED_MODELS: Dict[str, ModelConfig] = {

    # ── Falcon-Mamba 7B ──────────────────────────────────────────────────────
    "tiiuae/falcon-mamba-7b-instruct": ModelConfig(
        model_id="tiiuae/falcon-mamba-7b-instruct",
        architecture="mamba",
        hidden_dim=4096,
        n_layers=64,
        probe_layers=[16, 32, 48],
        lora_target_modules=["in_proj", "out_proj"],  # Mamba uses different projections
        verified_separations={
            "depth": 999.34,
            "specificity": 999.17,
        },
    ),

    # ── LLaMA 3.1 8B ────────────────────────────────────────────────────────
    "meta-llama/Llama-3.1-8B-Instruct": ModelConfig(
        model_id="meta-llama/Llama-3.1-8B-Instruct",
        architecture="llama",
        hidden_dim=4096,
        n_layers=32,
        probe_layers=[8, 16, 24],
        lora_target_modules=["q_proj", "v_proj"],
        verified_separations={},
    ),

    # ── Mistral 7B ───────────────────────────────────────────────────────────
    "mistralai/Mistral-7B-Instruct-v0.3": ModelConfig(
        model_id="mistralai/Mistral-7B-Instruct-v0.3",
        architecture="mistral",
        hidden_dim=4096,
        n_layers=32,
        probe_layers=[8, 16, 24],
        lora_target_modules=["q_proj", "v_proj"],
        verified_separations={
            "depth": 999.6,
            "specificity": 999.7,
            "calibration": 999.4,
            "focus": 999.6,
            "coherence": 999.7,
        },
    ),

    # ── Qwen 2.5 7B ─────────────────────────────────────────────────────────
    "Qwen/Qwen2.5-7B-Instruct": ModelConfig(
        model_id="Qwen/Qwen2.5-7B-Instruct",
        architecture="qwen",
        hidden_dim=3584,
        n_layers=28,
        probe_layers=[7, 14, 21],
        lora_target_modules=["q_proj", "v_proj"],
        verified_separations={},
    ),

    # ── Qwen 2.5 32B ───────────────────────────────────────────────────────
    "Qwen/Qwen2.5-32B-Instruct": ModelConfig(
        model_id="Qwen/Qwen2.5-32B-Instruct",
        architecture="qwen",
        hidden_dim=5120,
        n_layers=64,
        probe_layers=[16, 32, 48],
        lora_target_modules=["q_proj", "v_proj"],
        verified_separations={},
    ),

    # ── Qwen 2.5 3B (validated via qwen_multihead_CLEAN) ────────────────────
    "Qwen/Qwen2.5-3B-Instruct": ModelConfig(
        model_id="Qwen/Qwen2.5-3B-Instruct",
        architecture="qwen",
        hidden_dim=2048,
        n_layers=36,
        probe_layers=[9, 18, 27],
        lora_target_modules=["q_proj", "v_proj"],
        verified_separations={},
    ),
}

# Alias mapping for common shorthand
MODEL_ALIASES: Dict[str, str] = {
    "mamba": "tiiuae/falcon-mamba-7b-instruct",
    "mamba-7b": "tiiuae/falcon-mamba-7b-instruct",
    "falcon-mamba": "tiiuae/falcon-mamba-7b-instruct",
    "llama": "meta-llama/Llama-3.1-8B-Instruct",
    "llama-8b": "meta-llama/Llama-3.1-8B-Instruct",
    "llama-3.1": "meta-llama/Llama-3.1-8B-Instruct",
    "mistral": "mistralai/Mistral-7B-Instruct-v0.3",
    "mistral-7b": "mistralai/Mistral-7B-Instruct-v0.3",
    "qwen": "Qwen/Qwen2.5-7B-Instruct",
    "qwen-7b": "Qwen/Qwen2.5-7B-Instruct",
    "qwen-32b": "Qwen/Qwen2.5-32B-Instruct",
    "qwen-3b": "Qwen/Qwen2.5-3B-Instruct",
}


def resolve_model(model_name: str) -> Optional[ModelConfig]:
    """Look up a model config by ID or alias. Returns None if not validated."""
    # Direct match
    if model_name in VALIDATED_MODELS:
        return VALIDATED_MODELS[model_name]
    # Alias match
    if model_name.lower() in MODEL_ALIASES:
        return VALIDATED_MODELS[MODEL_ALIASES[model_name.lower()]]
    # Partial match (e.g. user passes a local path containing the model name)
    for model_id, config in VALIDATED_MODELS.items():
        if model_id.split("/")[-1].lower() in model_name.lower():
            return config
    return None


def detect_model_config(model) -> Optional[ModelConfig]:
    """Auto-detect config from a loaded transformers model."""
    hidden_dim = getattr(model.config, "hidden_size", None)
    n_layers = getattr(model.config, "num_hidden_layers", None)
    model_type = getattr(model.config, "model_type", "").lower()

    if hidden_dim is None or n_layers is None:
        return None

    # Match by architecture signature
    for config in VALIDATED_MODELS.values():
        if config.hidden_dim == hidden_dim and config.n_layers == n_layers:
            return config

    # Build a best-guess config for unknown models
    probe_layers = [n_layers // 4, n_layers // 2, (3 * n_layers) // 4]

    # Determine LoRA targets based on model type
    if "mamba" in model_type:
        lora_targets = ["in_proj", "out_proj"]
    else:
        lora_targets = ["q_proj", "v_proj"]

    return ModelConfig(
        model_id=f"unknown/{model_type}-{hidden_dim}d-{n_layers}L",
        architecture=model_type or "unknown",
        hidden_dim=hidden_dim,
        n_layers=n_layers,
        probe_layers=probe_layers,
        lora_target_modules=lora_targets,
        verified_separations={},
    )
