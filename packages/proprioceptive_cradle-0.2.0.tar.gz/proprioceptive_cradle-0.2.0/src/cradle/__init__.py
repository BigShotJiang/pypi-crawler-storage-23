"""
proprioceptive-cradle — Behavioral adapter generation for language models

Usage:
    from cradle import scan, generate

    # Behavioral report card
    report = scan("mistralai/Mistral-7B-Instruct-v0.3")

    # Generate adapter
    adapter_path = generate("mistralai/Mistral-7B-Instruct-v0.3", preset="professional")

CLI:
    cradle scan --model mistral
    cradle generate --model mistral --preset professional
    cradle presets
    cradle models

Author: Logan Matthew Napolitano / Proprioceptive AI
Version: 0.2.0
"""

__version__ = "0.2.0"

from .core import scan, generate, PRESETS
from .probes import FiberProjection, ProbeHead, CognitiveProbe
from .configs import (
    ModelConfig,
    VALIDATED_MODELS,
    MODEL_ALIASES,
    resolve_model,
    detect_model_config,
)
from .data import (
    ALL_DIMS,
    ENHANCEMENT_DIMS,
    SUPPRESSION_DIMS,
    HEDGE_PATTERNS,
    SYCOPHANCY_PATTERNS,
)

__all__ = [
    # Core API
    "scan",
    "generate",
    "PRESETS",
    # Probe architecture
    "FiberProjection",
    "ProbeHead",
    "CognitiveProbe",
    # Model configs
    "ModelConfig",
    "VALIDATED_MODELS",
    "MODEL_ALIASES",
    "resolve_model",
    "detect_model_config",
    # Data
    "ALL_DIMS",
    "ENHANCEMENT_DIMS",
    "SUPPRESSION_DIMS",
    "HEDGE_PATTERNS",
    "SYCOPHANCY_PATTERNS",
]
