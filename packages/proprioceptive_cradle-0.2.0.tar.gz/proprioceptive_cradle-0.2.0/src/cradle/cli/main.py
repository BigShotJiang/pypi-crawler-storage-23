"""
Cradle CLI — Command line interface for behavioral scanning and adapter generation.

Commands:
    cradle scan --model <path>                  Behavioral report card
    cradle generate --model <path> --preset X   Generate adapter
    cradle presets                               List available profiles
    cradle models                                List validated models

Author: Logan Matthew Napolitano / Proprioceptive AI
"""

import click


@click.group()
@click.version_option(version="0.2.0", prog_name="cradle")
def cli():
    """The Cradle — Behavioral adapter generation for language models."""
    pass


@cli.command()
@click.option("--model", "-m", required=True, help="Model name, HF ID, or local path")
@click.option("--dims", "-d", default=None, help="Comma-separated dimensions (default: all)")
@click.option("--steps", "-s", default=None, type=int, help="Training steps per probe")
@click.option("--quiet", "-q", is_flag=True, help="Suppress progress output")
def scan(model, dims, steps, quiet):
    """Run behavioral scan and produce report card."""
    from ..core import scan as run_scan

    dim_list = dims.split(",") if dims else None
    run_scan(model, dims=dim_list, steps=steps, verbose=not quiet)


@cli.command()
@click.option("--model", "-m", required=True, help="Model name, HF ID, or local path")
@click.option("--preset", "-p", default="professional",
              type=click.Choice(["professional", "creative", "cautious", "direct"]),
              help="Behavioral profile preset")
@click.option("--output", "-o", default="./adapters", help="Output directory")
@click.option("--probe-steps", default=None, type=int, help="Probe training steps")
@click.option("--adapter-steps", default=200, type=int, help="LoRA optimization steps")
@click.option("--quiet", "-q", is_flag=True, help="Suppress progress output")
# Custom target overrides
@click.option("--depth", type=float, default=None)
@click.option("--specificity", type=float, default=None)
@click.option("--calibration", type=float, default=None)
@click.option("--focus", type=float, default=None)
@click.option("--coherence", type=float, default=None)
@click.option("--sycophancy", type=float, default=None)
@click.option("--hedging", type=float, default=None)
@click.option("--verbosity", type=float, default=None)
@click.option("--repetition", type=float, default=None)
def generate(model, preset, output, probe_steps, adapter_steps, quiet,
             depth, specificity, calibration, focus, coherence,
             sycophancy, hedging, verbosity, repetition):
    """Generate a behavioral LoRA adapter."""
    from ..core import PRESETS, generate as run_generate

    # Build custom targets if any flags set
    custom = {}
    for name, val in [("depth", depth), ("specificity", specificity),
                      ("calibration", calibration), ("focus", focus),
                      ("coherence", coherence), ("sycophancy", sycophancy),
                      ("hedging", hedging), ("verbosity", verbosity),
                      ("repetition", repetition)]:
        if val is not None:
            custom[name] = val

    targets = None
    if custom:
        # Start from preset, override with custom
        targets = dict(PRESETS.get(preset, PRESETS["professional"]))
        targets.update(custom)

    run_generate(
        model,
        preset=preset if not custom else None,
        targets=targets,
        output_dir=output,
        probe_steps=probe_steps,
        adapter_steps=adapter_steps,
        verbose=not quiet,
    )


@cli.command()
def presets():
    """List available behavioral presets."""
    from ..core import PRESETS

    click.echo("\nAvailable Presets:\n")
    for name, targets in PRESETS.items():
        click.echo(f"  {name}")
        enhancement = {k: v for k, v in targets.items()
                      if k in ["depth", "specificity", "calibration", "focus", "coherence"]}
        suppression = {k: v for k, v in targets.items()
                      if k in ["sycophancy", "hedging", "verbosity", "repetition"]}
        click.echo(f"    Enhancement: {enhancement}")
        click.echo(f"    Suppression: {suppression}")
        click.echo()


@cli.command()
def models():
    """List validated models."""
    from ..configs import VALIDATED_MODELS, MODEL_ALIASES

    click.echo("\nValidated Models:\n")
    for model_id, config in VALIDATED_MODELS.items():
        aliases = [a for a, mid in MODEL_ALIASES.items() if mid == model_id]
        alias_str = f" (aliases: {', '.join(aliases)})" if aliases else ""
        click.echo(f"  {model_id}{alias_str}")
        click.echo(f"    Architecture: {config.architecture}")
        click.echo(f"    Dims: {config.hidden_dim}d, {config.n_layers}L")
        click.echo(f"    Probe layers: {config.probe_layers}")
        if config.verified_separations:
            seps = ", ".join(f"{k}: {v}×" for k, v in config.verified_separations.items())
            click.echo(f"    Verified: {seps}")
        click.echo()


if __name__ == "__main__":
    cli()
