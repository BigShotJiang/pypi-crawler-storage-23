"""HAL debugging and utility tools."""

