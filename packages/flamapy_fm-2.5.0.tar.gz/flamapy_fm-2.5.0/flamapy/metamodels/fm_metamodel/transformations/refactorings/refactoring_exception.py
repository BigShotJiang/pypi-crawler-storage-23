from flamapy.core.exceptions import FlamaException


class RefactoringException(FlamaException):
    pass
