# fm_metamodel

This repo host the feature model concrete classes


## Install for development

```
pip install -e .
```
