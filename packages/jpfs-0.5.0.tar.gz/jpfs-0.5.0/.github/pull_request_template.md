## 概要

<!-- 変更内容を簡潔に説明 -->

## 変更点

-

## テスト

- [ ] `uv run pytest` パス
- [ ] `uv run mypy src/japan_fiscal_simulator` パス
- [ ] `uv run ruff check src tests` パス
