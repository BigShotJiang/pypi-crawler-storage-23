"""CLI"""

from japan_fiscal_simulator.cli.main import app

__all__ = ["app"]
