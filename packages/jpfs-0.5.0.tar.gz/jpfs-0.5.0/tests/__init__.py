"""Tests for japan-fiscal package"""
