"""Installation registry for Pongogo.

Tracks all Pongogo installations on the machine so upgrade sync
can propagate updated seed content to every project.

Stored at ~/.pongogo/installations.db (machine-wide, not per-project).

Epic #304: Post-Upgrade Seed Sync
Task #666: Installation Registry
"""

from datetime import UTC, datetime
from pathlib import Path

from mcp_server.database.connection import get_connection

SCHEMA_VERSION = 1


def get_installations_db_path() -> Path:
    """Get path to the machine-wide installations database.

    Creates ~/.pongogo/ directory if needed.

    Returns:
        Path to ~/.pongogo/installations.db
    """
    home_pongogo = Path.home() / ".pongogo"
    home_pongogo.mkdir(parents=True, exist_ok=True)
    return home_pongogo / "installations.db"


def ensure_installations_schema(db_path: Path) -> None:
    """Create the installations table if it doesn't exist.

    Uses PRAGMA user_version for schema versioning.

    Args:
        db_path: Path to the installations database.
    """
    with get_connection(db_path) as conn:
        current = conn.execute("PRAGMA user_version").fetchone()[0]
        if current < SCHEMA_VERSION:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS installations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    project_root TEXT NOT NULL UNIQUE,
                    installed_at TEXT NOT NULL,
                    last_synced_at TEXT,
                    pongogo_version TEXT,
                    install_method TEXT
                )
            """)
            conn.execute(f"PRAGMA user_version = {SCHEMA_VERSION}")


def register_installation(
    project_root: Path | str,
    version: str,
    install_method: str,
    db_path: Path | None = None,
) -> None:
    """Register or update a Pongogo installation.

    Args:
        project_root: Absolute path to the project root.
        version: Pongogo version string.
        install_method: How Pongogo was installed (pip, homebrew, docker).
        db_path: Override database path (for testing). Defaults to ~/.pongogo/installations.db.
    """
    if db_path is None:
        db_path = get_installations_db_path()
    ensure_installations_schema(db_path)

    now = datetime.now(UTC).isoformat()
    project_root_str = str(Path(project_root).resolve())

    with get_connection(db_path) as conn:
        conn.execute(
            """
            INSERT INTO installations (project_root, installed_at, last_synced_at, pongogo_version, install_method)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(project_root) DO UPDATE SET
                last_synced_at = excluded.last_synced_at,
                pongogo_version = excluded.pongogo_version,
                install_method = excluded.install_method
            """,
            (project_root_str, now, now, version, install_method),
        )


def deregister_installation(
    project_root: Path | str,
    db_path: Path | None = None,
) -> bool:
    """Remove a Pongogo installation from the registry.

    Args:
        project_root: Absolute path to the project root.
        db_path: Override database path (for testing).

    Returns:
        True if a row was deleted, False if not found.
    """
    if db_path is None:
        db_path = get_installations_db_path()
    ensure_installations_schema(db_path)

    project_root_str = str(Path(project_root).resolve())

    with get_connection(db_path) as conn:
        cursor = conn.execute(
            "DELETE FROM installations WHERE project_root = ?",
            (project_root_str,),
        )
        return cursor.rowcount > 0


def list_installations(db_path: Path | None = None) -> list[dict]:
    """List all registered Pongogo installations.

    Args:
        db_path: Override database path (for testing).

    Returns:
        List of installation dicts.
    """
    if db_path is None:
        db_path = get_installations_db_path()
    ensure_installations_schema(db_path)

    with get_connection(db_path, readonly=True) as conn:
        rows = conn.execute(
            "SELECT project_root, installed_at, last_synced_at, pongogo_version, install_method "
            "FROM installations ORDER BY installed_at"
        ).fetchall()
        return [dict(row) for row in rows]


def prune_stale_installations(db_path: Path | None = None) -> int:
    """Remove installations where .pongogo/ no longer exists.

    Args:
        db_path: Override database path (for testing).

    Returns:
        Number of pruned entries.
    """
    if db_path is None:
        db_path = get_installations_db_path()
    ensure_installations_schema(db_path)

    installations = list_installations(db_path)
    pruned = 0

    for inst in installations:
        project_root = Path(inst["project_root"])
        pongogo_dir = project_root / ".pongogo"
        if not pongogo_dir.exists():
            with get_connection(db_path) as conn:
                conn.execute(
                    "DELETE FROM installations WHERE project_root = ?",
                    (str(project_root),),
                )
            pruned += 1

    return pruned
