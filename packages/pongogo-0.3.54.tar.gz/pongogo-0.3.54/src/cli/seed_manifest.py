"""Seed manifest generation and management.

Tracks which instruction and command files were seeded during `pongogo init`,
along with content hashes, so future upgrades can detect user modifications
and avoid overwriting customized files.

Epic #304: Post-Upgrade Seed Sync
Task #664: Seed Manifest Generation
"""

import hashlib
import json
from datetime import UTC, datetime
from pathlib import Path

from mcp_server.database.connection import atomic_json_write

MANIFEST_FILENAME = "seed_manifest.json"


def compute_file_hash(file_path: Path) -> str:
    """Compute SHA-256 hash of a file's contents.

    Args:
        file_path: Path to the file to hash.

    Returns:
        Hash string prefixed with 'sha256:' for clarity.
    """
    h = hashlib.sha256()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return f"sha256:{h.hexdigest()}"


def generate_seed_manifest(
    seeded_files: list[tuple[str, Path]],
    version: str,
) -> dict:
    """Generate a manifest from seeded files.

    Args:
        seeded_files: List of (relative_key, dest_path) tuples.
            relative_key is e.g. 'instructions/safety_prevention/foo.md'
            or 'commands/pongogo-status.md'.
        version: Pongogo version that produced the seed.

    Returns:
        Manifest dict with pongogo_version, created_at, and files mapping.
    """
    files = {}
    for relative_key, dest_path in seeded_files:
        if dest_path.exists():
            files[relative_key] = {
                "hash": compute_file_hash(dest_path),
                "size": dest_path.stat().st_size,
            }

    return {
        "pongogo_version": version,
        "created_at": datetime.now(UTC).isoformat(),
        "files": files,
    }


def write_seed_manifest(pongogo_dir: Path, manifest: dict) -> None:
    """Write seed manifest atomically.

    Args:
        pongogo_dir: Path to .pongogo/ directory.
        manifest: Manifest dict to write.
    """
    atomic_json_write(pongogo_dir / MANIFEST_FILENAME, manifest)


def read_seed_manifest(pongogo_dir: Path) -> dict | None:
    """Read seed manifest if it exists.

    Args:
        pongogo_dir: Path to .pongogo/ directory.

    Returns:
        Parsed manifest dict, or None if no manifest exists (backward compat).
    """
    manifest_path = pongogo_dir / MANIFEST_FILENAME
    if not manifest_path.exists():
        return None
    try:
        return json.loads(manifest_path.read_text())
    except (json.JSONDecodeError, ValueError):
        return None
