"""Pongogo CLI - Bootstrap and manage Pongogo in your repository."""

import os


def _get_version() -> str:
    """Get version from env var, package metadata, or fallback to dev."""
    # Docker builds set this env var
    if env_version := os.environ.get("PONGOGO_VERSION"):
        return env_version

    # pip installs: read from package metadata
    try:
        from importlib.metadata import version

        return version("pongogo")
    except Exception:
        pass

    # Local development fallback
    return "0.1.0-dev"


__version__ = _get_version()


def get_channel() -> str:
    """Get the release channel from PONGOGO_IMAGE env var.

    Beta promotion re-tags images without rebuilding, so PONGOGO_VERSION
    still contains the alpha version. The channel is derived from PONGOGO_IMAGE.

    Returns:
        Channel name: 'alpha', 'beta', 'stable', or 'dev'
    """
    image = os.environ.get("PONGOGO_IMAGE", "")
    if ":beta" in image:
        return "beta"
    elif ":stable" in image:
        return "stable"
    elif ":alpha" in image or "-alpha." in __version__:
        return "alpha"
    elif __version__ == "0.1.0-dev":
        return "dev"
    else:
        return "stable"  # Assume stable for version-only releases


def get_display_version() -> str:
    """Get version string for display in clean format.

    Example outputs:
    - "v0.2.0-build.93 (alpha)" (alpha channel)
    - "v0.2.0-build.93 (beta)" (beta channel, version says alpha internally)
    - "v0.2.0" (stable release - clean, no channel suffix)
    - "0.1.0-dev" (local development)
    """
    import re

    # Dev version - show as-is
    if __version__ == "0.1.0-dev":
        return __version__

    # Stable version: pure semver (no pre-release suffix) - show clean version only
    if re.match(r"^\d+\.\d+\.\d+$", __version__):
        return f"v{__version__}"

    # Pre-release: show build number and channel
    match = re.match(r"^(\d+\.\d+\.\d+)-(?:alpha|beta)\.(\d+)$", __version__)
    if match:
        base_version = match.group(1)
        build_number = match.group(2)
        channel = get_channel()
        return f"v{base_version}-build.{build_number} ({channel})"

    # Fallback for unexpected formats
    return __version__
