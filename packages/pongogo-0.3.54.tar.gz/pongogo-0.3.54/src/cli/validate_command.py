"""Pongogo validate command - run validation suite for troubleshooting.

This command is only available in beta/alpha builds, not stable.
It runs the same validation script used in CI for perfect parity.
"""

import os
import subprocess
import sys
from pathlib import Path

import typer

from .console import console, print_error, print_success, print_warning


def get_bundled_script_path() -> Path | None:
    """Get the path to the bundled validation script.

    Returns:
        Path to the script if it exists, None otherwise.
    """
    # Script is bundled at /app/scripts/ in beta/alpha Docker images
    bundled_path = Path("/app/scripts/run-beta-validation-vm.sh")
    if bundled_path.exists():
        return bundled_path

    # For local development, check relative to this file
    dev_path = (
        Path(__file__).parent.parent.parent / "scripts" / "run-beta-validation-vm.sh"
    )
    if dev_path.exists():
        return dev_path

    return None


def validate_command(
    full: bool = typer.Option(
        False,
        "--full",
        "-f",
        help="Run full validation suite (same as CI) with debug artifact generation",
    ),
    quick: bool = typer.Option(
        False,
        "--quick",
        "-q",
        help="Run quick validation (core tests only, no Claude integration tests)",
    ),
    output: Path = typer.Option(
        None,
        "--output",
        "-o",
        help="Output directory for artifacts (default: ~/results)",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Show detailed test output",
    ),
) -> None:
    """Run Pongogo validation suite for troubleshooting.

    This command runs the same validation script used in CI, ensuring
    perfect parity between local and CI test results.

    \b
    Examples:
      pongogo validate --full          Full validation with debug artifact
      pongogo validate --quick         Quick validation (core tests only)
      pongogo validate -f -o ./debug   Full validation, output to ./debug/

    \b
    The debug artifact includes:
      - test-results.json     Per-test PASS/FAIL with timing
      - test-logs/            stdout/stderr for each test
      - database-analysis.json Database health (not raw data)
      - configs/              .mcp.json, config.yaml, etc.
      - environment.txt       System info, versions, permissions

    Share the generated .tar.gz file for troubleshooting support.

    NOTE: This command is only available in beta/alpha builds.
    """
    # Check channel - this command shouldn't exist in stable builds
    # but double-check at runtime for safety
    channel = os.environ.get("PONGOGO_CHANNEL", "stable")
    if channel == "stable":
        print_error("The validate command is only available in beta/alpha builds.")
        console.print("\nTo use this command, install from the beta channel:")
        console.print(
            "  [#5a9ae8]curl -fsSL https://get.pongogo.com/beta/install-beta.sh | bash[/#5a9ae8]"
        )
        raise typer.Exit(1)

    # Find the bundled script
    script_path = get_bundled_script_path()
    if script_path is None:
        print_error("Validation script not found.")
        console.print("\nThis may indicate a corrupted installation.")
        console.print("Try reinstalling: [#5a9ae8]pongogo upgrade[/#5a9ae8]")
        raise typer.Exit(1)

    # Build command arguments
    cmd = [str(script_path)]

    # Add channel (use current channel from environment)
    cmd.append(channel)

    # Full mode generates artifact
    if full:
        cmd.append("--generate-artifact")

    # Output directory
    if output:
        cmd.extend(["--output", str(output.resolve())])

    # Verbose mode
    if verbose:
        cmd.append("--verbose")

    console.print(f"\n[bold]Running Pongogo {channel} validation...[/bold]\n")

    if full:
        console.print("[dim]Full validation mode - generating debug artifact[/dim]")
    elif quick:
        console.print("[dim]Quick validation mode - core tests only[/dim]")

    console.print("")

    # Run the script
    try:
        result = subprocess.run(
            cmd,
            cwd=Path.cwd(),
            # Pass through stdin/stdout/stderr for interactive output
            stdin=sys.stdin,
            stdout=sys.stdout,
            stderr=sys.stderr,
        )

        if result.returncode == 0:
            console.print("")
            print_success("Validation completed successfully")
        else:
            console.print("")
            print_error(f"Validation failed with exit code {result.returncode}")
            raise typer.Exit(result.returncode)

    except FileNotFoundError:
        print_error(f"Could not execute script: {script_path}")
        console.print("\nEnsure bash is available in your PATH.")
        raise typer.Exit(1)
    except KeyboardInterrupt:
        print_warning("\nValidation interrupted by user")
        raise typer.Exit(130)
