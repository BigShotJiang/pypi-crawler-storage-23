"""Pongogo debug command — collects diagnostic data into a single report.

Consolidates ~8 separate diagnostic commands into one invocation.
Output is markdown (human-readable) or JSON (machine-readable).
"""

import json
import platform
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

import typer

from .console import console

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _redact_secrets(text: str) -> str:
    """Replace potential API keys/tokens with [REDACTED]."""
    # Common patterns: ghp_*, sk-*, key-*, Bearer tokens, long hex strings
    text = re.sub(
        r'(ghp_|sk-|key-|token["\s:=]+)[A-Za-z0-9_-]{10,}', r"\1[REDACTED]", text
    )
    text = re.sub(r"Bearer\s+[A-Za-z0-9._-]{20,}", "Bearer [REDACTED]", text)
    return text


def _read_json_file(path: Path) -> dict | None:
    """Read and parse a JSON file, returning None on failure."""
    try:
        return json.loads(path.read_text())
    except (FileNotFoundError, json.JSONDecodeError, PermissionError):
        return None


def _which_entry_points() -> dict[str, str | None]:
    """Check which for all pongogo entry points."""
    names = [
        "pongogo",
        "pongogo-stop-hook",
        "pongogo-route",
        "pongogo-compliance-check",
        "pongogo-pretooluse-check",
    ]
    return {name: shutil.which(name) for name in names}


def _tail_lines(path: Path, n: int = 5) -> list[str]:
    """Return last *n* lines of a file, or empty list."""
    try:
        lines = path.read_text().splitlines()
        return lines[-n:]
    except (FileNotFoundError, PermissionError):
        return []


# ---------------------------------------------------------------------------
# Section collectors — each returns a dict
# ---------------------------------------------------------------------------


def _collect_install_env() -> dict[str, Any]:
    """Section 1: Install & Environment."""
    data: dict[str, Any] = {}

    # Install method + version
    try:
        from mcp_server.upgrade import (
            detect_install_method,
            get_current_version,
        )

        method = detect_install_method()
        data["install_method"] = method.value
        data["version"] = get_current_version()
    except Exception as exc:
        data["install_method"] = "unknown"
        data["version"] = "unknown"
        data["install_detect_error"] = str(exc)

    # Display version
    try:
        from . import get_display_version

        data["display_version"] = get_display_version()
    except Exception:
        data["display_version"] = data.get("version", "unknown")

    data["python_version"] = platform.python_version()
    data["python_path"] = sys.executable
    data["os"] = platform.system()
    data["arch"] = platform.machine()

    # Entry points
    data["entry_points"] = _which_entry_points()

    return data


def _collect_hooks() -> dict[str, Any]:
    """Section 2: Hook Configuration."""
    data: dict[str, Any] = {}

    # Local hooks
    local_settings_path = Path(".claude/settings.local.json")
    local_settings = _read_json_file(local_settings_path)
    if local_settings is not None:
        hooks_section = local_settings.get("hooks", {})
        data["local_hooks"] = _redact_secrets(json.dumps(hooks_section, indent=2))

        # Detect Docker references in hooks
        hooks_str = json.dumps(hooks_section)
        data["has_docker_refs"] = "docker" in hooks_str.lower()

        # Detect duplicate hook commands
        commands = []
        for event_hooks in hooks_section.values():
            if isinstance(event_hooks, list):
                for group in event_hooks:
                    if isinstance(group, dict):
                        for hook in group.get("hooks", []):
                            if isinstance(hook, dict) and "command" in hook:
                                commands.append(hook["command"])
        data["duplicate_hooks"] = len(commands) != len(set(commands))
    else:
        data["local_hooks"] = None
        data["local_hooks_error"] = "File not found or invalid JSON"

    # Global hooks
    global_claude = Path.home() / ".claude.json"
    global_data = _read_json_file(global_claude)
    if global_data is not None:
        global_hooks = global_data.get("hooks", {})
        data["global_hooks"] = _redact_secrets(json.dumps(global_hooks, indent=2))
    else:
        data["global_hooks"] = None

    return data


def _collect_mcp() -> dict[str, Any]:
    """Section 3: MCP Configuration."""
    data: dict[str, Any] = {}

    mcp_path = Path(".mcp.json")
    mcp_data = _read_json_file(mcp_path)
    if mcp_data is not None:
        servers = mcp_data.get("mcpServers", {})
        pk = servers.get("pongogo-knowledge")
        if pk is not None:
            data["configured"] = True
            data["command"] = pk.get("command", "unknown")
            data["args"] = pk.get("args", [])
        else:
            data["configured"] = False
            data["error"] = "pongogo-knowledge entry missing from .mcp.json"
    else:
        data["configured"] = False
        data["error"] = ".mcp.json not found or invalid"

    # Health check — try importing and calling
    if data.get("configured"):
        try:
            from mcp_server.health import get_health_status

            health = get_health_status()
            data["health"] = (
                health if isinstance(health, dict) else {"raw": str(health)}
            )
        except Exception as exc:
            data["health"] = {"error": str(exc)}

    return data


def _collect_state_files() -> dict[str, Any]:
    """Section 4: State Files."""
    data: dict[str, Any] = {}

    # MCP state
    state_path = Path(".pongogo-mcp-state.json")
    state_data = _read_json_file(state_path)
    data["mcp_state"] = state_data if state_data is not None else "not found"

    # Database
    db_path = Path(".pongogo/pongogo.db")
    if db_path.exists():
        try:
            size = db_path.stat().st_size
            data["database"] = {"exists": True, "size_bytes": size}
        except OSError:
            data["database"] = {"exists": True, "size_bytes": "unknown"}
    else:
        data["database"] = {"exists": False}

    # Logs
    logs_dir = Path(".pongogo/logs")
    if logs_dir.is_dir():
        log_files: dict[str, list[str]] = {}
        try:
            for log_file in sorted(logs_dir.iterdir()):
                if log_file.is_file():
                    log_files[log_file.name] = _tail_lines(log_file, 5)
        except PermissionError:
            pass
        data["logs"] = log_files
    else:
        data["logs"] = "no logs directory"

    return data


def _collect_shell_env() -> dict[str, Any]:
    """Section 5: Shell Environment."""
    data: dict[str, Any] = {}

    # Check if `which pongogo` resolves to a Docker-era bash wrapper
    pongogo_path = shutil.which("pongogo")
    data["pongogo_path"] = pongogo_path
    if pongogo_path:
        try:
            content = Path(pongogo_path).read_text()
            data["pongogo_is_bash_wrapper"] = (
                content.startswith("#!/bin/bash") or "docker" in content.lower()
            )
        except (PermissionError, OSError):
            data["pongogo_is_bash_wrapper"] = None

    # Scan shell rc files for pongogo/docker references
    docker_refs: dict[str, list[str]] = {}
    for rc_name in [".zshrc", ".bashrc", ".bash_profile"]:
        rc_path = Path.home() / rc_name
        if rc_path.exists():
            try:
                lines = rc_path.read_text().splitlines()
                matches = [
                    line.strip()
                    for line in lines
                    if "pongogo" in line.lower() or "docker" in line.lower()
                ]
                if matches:
                    docker_refs[rc_name] = matches
            except (PermissionError, OSError):
                pass
    data["shell_rc_refs"] = docker_refs if docker_refs else "none"

    return data


def _collect_timing() -> dict[str, Any]:
    """Section 6 (optional): Hook Timing."""
    data: dict[str, Any] = {}

    for cmd_name in ["pongogo-stop-hook", "pongogo-route"]:
        cmd_path = shutil.which(cmd_name)
        if cmd_path:
            try:
                start = time.monotonic()
                result = subprocess.run(
                    [cmd_path, "--help"],
                    capture_output=True,
                    text=True,
                    timeout=10,
                )
                elapsed_ms = round((time.monotonic() - start) * 1000)
                data[cmd_name] = {
                    "elapsed_ms": elapsed_ms,
                    "exit_code": result.returncode,
                }
            except (subprocess.TimeoutExpired, FileNotFoundError, OSError) as exc:
                data[cmd_name] = {"error": str(exc)}
        else:
            data[cmd_name] = {"error": "not found in PATH"}

    return data


# ---------------------------------------------------------------------------
# Output formatters
# ---------------------------------------------------------------------------


def _status_icon(ok: bool, warn: bool = False) -> str:
    if warn:
        return "\u26a0\ufe0f"  # ⚠️
    return "\u2705" if ok else "\u274c"  # ✅ / ❌


def _format_markdown(report: dict[str, Any]) -> str:
    """Render the report dict as a markdown string."""
    lines: list[str] = []

    lines.append("# Pongogo Debug Report")
    lines.append("")
    lines.append(
        "> **Privacy**: This report contains system info, file paths, version numbers,"
    )
    lines.append(
        "> and configuration structure. It does NOT include file contents, personal data,"
    )
    lines.append("> or API keys (all secrets are redacted).")
    lines.append("")

    # Section 1: Install & Environment
    env = report.get("install_env", {})
    lines.append("## Install & Environment")
    lines.append("")
    lines.append(f"- **Install method**: {env.get('install_method', 'unknown')}")
    lines.append(
        f"- **Version**: {env.get('display_version', env.get('version', 'unknown'))}"
    )
    lines.append(
        f"- **Python**: {env.get('python_version', '?')} ({env.get('python_path', '?')})"
    )
    lines.append(f"- **OS**: {env.get('os', '?')} / {env.get('arch', '?')}")

    ep = env.get("entry_points", {})
    lines.append("")
    lines.append("### Entry Points")
    lines.append("")
    for name, path in ep.items():
        icon = _status_icon(path is not None)
        lines.append(f"- {icon} `{name}`: {path or 'not found'}")

    # Section 2: Hooks
    hooks = report.get("hooks", {})
    lines.append("")
    lines.append("## Hook Configuration")
    lines.append("")
    if hooks.get("local_hooks") is not None:
        has_docker = hooks.get("has_docker_refs", False)
        has_dupes = hooks.get("duplicate_hooks", False)
        if has_docker:
            lines.append(
                f"{_status_icon(False, warn=True)} Docker references found in hooks"
            )
        if has_dupes:
            lines.append(
                f"{_status_icon(False, warn=True)} Duplicate hook commands detected"
            )
        if not has_docker and not has_dupes:
            lines.append(f"{_status_icon(True)} Local hooks look clean")
        lines.append("")
        lines.append("<details><summary>Local hooks</summary>")
        lines.append("")
        lines.append("```json")
        lines.append(hooks["local_hooks"])
        lines.append("```")
        lines.append("</details>")
    else:
        lines.append(f"{_status_icon(False)} Local settings not found")

    if hooks.get("global_hooks") is not None:
        lines.append("")
        lines.append("<details><summary>Global hooks</summary>")
        lines.append("")
        lines.append("```json")
        lines.append(hooks["global_hooks"])
        lines.append("```")
        lines.append("</details>")

    # Section 3: MCP
    mcp = report.get("mcp", {})
    lines.append("")
    lines.append("## MCP Configuration")
    lines.append("")
    if mcp.get("configured"):
        lines.append(f"{_status_icon(True)} pongogo-knowledge configured")
        lines.append(f"- **Command**: `{mcp.get('command', '?')}`")
        health = mcp.get("health", {})
        if isinstance(health, dict) and "error" not in health:
            overall = health.get("overall", "unknown")
            is_healthy = overall == "healthy"
            lines.append(f"- **Health**: {_status_icon(is_healthy)} {overall}")
        elif isinstance(health, dict):
            lines.append(
                f"- **Health**: {_status_icon(False)} {health.get('error', 'check failed')}"
            )
    else:
        lines.append(f"{_status_icon(False)} {mcp.get('error', 'not configured')}")

    # Section 4: State Files
    state = report.get("state_files", {})
    lines.append("")
    lines.append("## State Files")
    lines.append("")

    mcp_state = state.get("mcp_state")
    if isinstance(mcp_state, dict):
        mode = mcp_state.get("mode", "unknown")
        lines.append(f"- **MCP state**: mode={mode}")
    else:
        lines.append(f"- **MCP state**: {mcp_state}")

    db_info = state.get("database", {})
    if db_info.get("exists"):
        lines.append(
            f"- **Database**: {_status_icon(True)} {db_info.get('size_bytes', '?')} bytes"
        )
    else:
        lines.append(f"- **Database**: {_status_icon(False)} not found")

    logs = state.get("logs")
    if isinstance(logs, dict) and logs:
        lines.append("")
        lines.append("### Recent Logs")
        for fname, tail in logs.items():
            lines.append(f"\n**{fname}** (last 5 lines):")
            lines.append("```")
            for line in tail:
                lines.append(line)
            lines.append("```")
    elif logs == "no logs directory":
        lines.append("- **Logs**: no logs directory")

    # Section 5: Shell Environment
    shell = report.get("shell_env", {})
    lines.append("")
    lines.append("## Shell Environment")
    lines.append("")
    lines.append(f"- **pongogo path**: {shell.get('pongogo_path', 'not found')}")
    if shell.get("pongogo_is_bash_wrapper"):
        lines.append(
            f"  {_status_icon(False, warn=True)} Appears to be a Docker-era bash wrapper"
        )

    refs = shell.get("shell_rc_refs")
    if isinstance(refs, dict) and refs:
        lines.append("")
        lines.append(
            f"{_status_icon(False, warn=True)} Shell RC files contain pongogo/docker references:"
        )
        for rc_file, matches in refs.items():
            lines.append(f"\n**{rc_file}**:")
            for m in matches:
                lines.append(f"  `{m}`")
    elif refs == "none":
        lines.append(
            f"- {_status_icon(True)} No pongogo/docker references in shell RC files"
        )

    # Section 6: Timing (optional)
    timing = report.get("timing")
    if timing:
        lines.append("")
        lines.append("## Hook Timing")
        lines.append("")
        for cmd_name, info in timing.items():
            if "error" in info:
                lines.append(f"- `{cmd_name}`: {_status_icon(False)} {info['error']}")
            else:
                ms = info.get("elapsed_ms", "?")
                lines.append(
                    f"- `{cmd_name}`: {ms}ms (exit {info.get('exit_code', '?')})"
                )

    lines.append("")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Main command
# ---------------------------------------------------------------------------


def debug_command(
    output: str | None = typer.Option(
        None,
        "--output",
        "-o",
        help="Save report to this path instead of default .pongogo/debug-report.md",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output machine-readable JSON to stdout",
    ),
    timing: bool = typer.Option(
        False,
        "--timing",
        help="Include hook timing measurements (runs subprocesses)",
    ),
) -> None:
    """Collect diagnostic data and generate a debug report.

    Gathers install info, hook configuration, MCP status, state files,
    and shell environment into a single report for support threads.
    """
    report: dict[str, Any] = {}

    report["install_env"] = _collect_install_env()
    report["hooks"] = _collect_hooks()
    report["mcp"] = _collect_mcp()
    report["state_files"] = _collect_state_files()
    report["shell_env"] = _collect_shell_env()

    if timing:
        report["timing"] = _collect_timing()

    # --- Output ---
    if json_output:
        # Use print() not console.print() — Rich adds ANSI escape codes
        # that corrupt JSON for machine consumers like jq
        print(json.dumps(report, indent=2, default=str))
        return

    md = _format_markdown(report)
    console.print(md)

    # Save to file
    dest = Path(output) if output else Path(".pongogo/debug-report.md")
    try:
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(md)
        console.print(f"\nReport saved to {dest} — share this file for support.")
    except OSError as exc:
        console.print(f"\n[yellow]Could not save report: {exc}[/yellow]")
