---
pongogo_instruction_spec: "0.0.2"
title: "Systematic Troubleshooting Methodology"
description: "Structured approach for investigating failures that identifies root causes, requires evidence-based solutions, and institutionalizes learnings to prevent recurrence"
enforcement:
  scope: session
  blocked_tools:
    - mutating
  blocked_until:
    - action_type: read_instruction
applies_to:
  - "**/*"
domains:
  - "development"
  - "quality"
  - "devops"
priority: "P1"
pongogo_version: "2026-02-25"
source: "Original"
patterns:
  - "systematic_prevention"
  - "evidence_based_diagnosis"
  - "knowledge_institutionalization"
routing:
  priority: 1
  triggers:
    keywords:
      - troubleshooting
      - debugging
      - root_cause
      - failure_investigation
      - test_failure
      - ci_failure
      - e2e_failure
      - log_analysis
      - error_diagnosis
      - flaky_test
      - build_failure
      - pipeline_failure
      - regression
      - incident
    nlp: "Investigating failures, analyzing logs, diagnosing errors, debugging CI/CD pipelines, understanding test failures, or performing root cause analysis on any system issue"
---

# Systematic Troubleshooting Methodology

**Purpose**: Provide a structured investigation process that identifies root causes (not symptoms), requires evidence to support solutions, and institutionalizes every learning so mistakes are not repeated.

**Philosophy**: Every failure is a learning opportunity. The fix is only half the work — the other half is ensuring the failure cannot recur through structural prevention.

---

## When to Apply

Use this methodology when:

- CI/CD pipeline fails (build, test, deploy)
- E2E tests fail or become flaky
- Unexpected system behavior is observed
- Production issues or regressions appear
- Multiple related failures occur in a cycle
- A previous fix didn't hold or the same class of problem recurs

---

## Quick Reference

**The Four Commitments** (before proposing any fix):

1. **Cause, not symptom** — Identify the underlying cause, not just what's visible
2. **Evidence, not assumption** — Determine what facts support a proposed solution
3. **Track what you can't prove** — If data doesn't exist to verify a fix, create the mechanism to collect it
4. **Institutionalize, don't just fix** — Log a PI, create/update an instruction file, alter code, or add a test so the mistake cannot recur

**Investigation Sequence** (do not skip steps):

```
1. Gather ALL logs from the failure cycle
2. Inventory every distinct issue found
3. Look for commonalities between issues
4. For each issue: trace to root cause
5. For each root cause: find supporting evidence
6. For each fix: determine institutionalization path
7. Execute fixes with verification
8. Confirm institutionalization is complete
```

---

## Core Principles

- **Examine the full cycle, not one failure** — Multiple failures in a run often share a common root cause. Fixing one symptom while ignoring others leads to whack-a-mole debugging.
- **Evidence over intuition** — A plausible explanation is not a confirmed root cause. Trace the causal chain through logs, code, and data before proposing a fix.
- **Absence of evidence is not evidence of absence** — If you can't find data to confirm or deny a theory, the first fix is to add the instrumentation that would provide that data.
- **Fixes without institutionalization are incomplete** — A code change that fixes the bug is necessary but insufficient. The learning must be captured so the same class of error is prevented structurally.
- **Check recent changes first** — Most failures are caused by recent changes, not by fundamental design flaws. Start with what changed.

---

## Step-by-Step Guidance

### Phase 1: Gather Evidence

1. **Collect all logs from the failure cycle**
   - CI/CD pipeline logs (all jobs, not just the failed one)
   - Application logs, stderr output, trace files
   - Test result artifacts (JSON reports, screenshots, recordings)
   - System metrics (memory, CPU, disk at time of failure)
   - Expected outcome: Complete evidence set, not cherry-picked excerpts

2. **Check recent changes that could have caused the failure**
   - Recent commits (since last successful run)
   - Configuration changes (CI/CD, environment, dependencies)
   - Instruction file changes (could affect agent behavior)
   - Infrastructure changes (container versions, base images, service updates)
   - Expected outcome: Timeline of changes correlated with failure onset

3. **Reproduce the failure (when possible)**
   - Run the failing test/pipeline locally
   - Compare local results to CI results
   - Note any environmental differences
   - Expected outcome: Confirmed reproduction or identified environment dependency

### Phase 2: Inventory and Analyze

4. **Create a complete inventory of all issues**
   - List every distinct failure, warning, or anomaly in the logs
   - Include non-fatal issues (warnings, deprecation notices, slow operations)
   - Note the sequence and timing of failures
   - Expected outcome: Numbered list of every issue observed

5. **Look for commonalities between issues**
   - Do multiple failures share a common trigger?
   - Are failures in the same subsystem or affecting the same data?
   - Is there a timing pattern (all fail after a specific step)?
   - Could one failure be causing cascading failures downstream?
   - Expected outcome: Grouped issues with identified relationships

6. **Classify each issue by BOTH type and layer**

   **By type** (what role does this issue play?):
   - **Root cause**: The actual defect that needs fixing
   - **Symptom**: A visible effect of an underlying root cause
   - **Cascade**: A failure caused by an earlier failure in the chain
   - **Coincidence**: An unrelated issue that happened to appear in the same run

   **By layer** (where does the defect live?):
   - **Product code**: The application code is broken — a real bug that affects users
   - **Test/CI infrastructure**: The test or pipeline is broken — the product works but the test doesn't prove it
   - **Both**: The product has a bug AND the test infrastructure fails to diagnose it clearly (most dangerous — the test failure masks the real problem or leads you to fix the wrong thing)

   A test failure is not automatically a product bug. A passing test is not proof the product works. Always ask: "Is the failure in the code being tested, or in the test itself, or in both?" Misclassifying the layer leads to fixing the wrong thing — patching a test when the product is broken, or changing product code when the CI pipeline has a bug.

   - Expected outcome: Each issue tagged with BOTH its type (root cause/symptom/cascade) AND its layer (product/test/both)

### Phase 2b: Assess Observability

6b. **Can you actually determine the cause from the data you have?**

    Before diagnosing, answer honestly: does the test infrastructure give you enough information to determine the cause? If not, **stop diagnosing and fix the observability gap first**.

    **Signs of insufficient observability**:
    - You're forming theories but can't prove or disprove any of them
    - You can see THAT something failed but not WHY
    - You can see one side of an interaction but not the other (e.g., server trace but no client trace)
    - Multiple plausible explanations exist and no data distinguishes between them
    - You find yourself saying "it might be X" or "it could be Y" repeatedly

    **When observability is insufficient, the fix is not to guess harder.** The fix is to add instrumentation so the NEXT failure tells you exactly what happened. This may mean:
    - Capturing the full input a component received (not just the output it produced)
    - Logging both sides of an interaction (client AND server, not just one)
    - Recording the decision path (why was this choice made, not just what choice was made)
    - Preserving stderr, debug output, and intermediate state that is currently discarded

    A test that fails without telling you why it failed is a broken test, regardless of whether the product code is also broken.

    - Expected outcome: Either "Yes, I have enough data to diagnose" (proceed to Phase 3) or "No, I need to add instrumentation first" (the instrumentation IS the fix for this iteration)

### Phase 3: Diagnose Root Causes

7. **For each root cause, trace the causal chain**
   - What specific code/configuration/state caused the failure?
   - Why did this code/configuration/state exist?
   - What change introduced it, and when?
   - Was there a test or check that should have caught it?
   - Expected outcome: Documented causal chain from trigger to visible failure

8. **Verify with evidence**
   - Can you point to a specific log line, code path, or data point?
   - Does the evidence rule out alternative explanations?
   - If you have a theory but no proof, what data would you need?
   - Expected outcome: Each diagnosis backed by cited evidence, or a plan to obtain it

### Phase 4: Fix and Institutionalize

9. **Design the fix with verification**
   - What code/configuration change addresses the root cause?
   - How will you verify the fix works? (test, CI run, manual check)
   - Does the fix introduce any risks or side effects?
   - Expected outcome: Fix with clear verification plan

10. **Determine the institutionalization path**

    For each fix, choose one or more:

    | Path | When to Use | Example |
    |------|-------------|---------|
    | **Log a PI** | Pattern observed but not yet actionable | PI entry tracking recurring flaky test class |
    | **Create/update instruction file** | Agent behavior needs to change | New troubleshooting checklist for specific subsystem |
    | **Add/modify automated test** | Regression risk exists | E2E test covering the upgrade path that was missing |
    | **Add instrumentation** | Lack of observability caused delayed diagnosis | Request tracing, structured logging, metrics |
    | **Change code structure** | Design flaw enabled the error class | Resolve paths to absolute before cd, not after |
    | **Update CI/CD pipeline** | Build/deploy process had a gap | Add validation step, fix path handling |

11. **Execute and verify**
    - Apply the fix
    - Run verification (tests, CI, manual confirmation)
    - Confirm institutionalization artifact exists (PI logged, instruction updated, test added)
    - Expected outcome: Fix verified AND learning captured

### Phase 5: Document

12. **Record the investigation**
    - What was the symptom?
    - What was the root cause?
    - What evidence confirmed the diagnosis?
    - What was the fix?
    - What was institutionalized to prevent recurrence?
    - Expected outcome: Complete record in commit message, work log, or PI entry

---

## Examples

### Example 1: CI Pipeline Failure — All Upgrade Tests Failing

**Symptom**: 4 E2E tests fail on upgrade path (schema version, missing column, connection factory, debug command).

**Investigation**:
1. Gathered all CI logs (clean install, upgrade, Docker, Homebrew)
2. Inventoried issues: 4 test failures, all in upgrade step only
3. Commonality: all failures are features that exist in v0.3.40 but not v0.3.39
4. Key observation: version banner shows `0.3.39` in upgrade run — upgrade never happened

**Root cause**: Wheel path stored as relative (`wheels/foo.whl`), but script `cd`'d to temp directory before checking `[[ -f "$UPGRADE_WHEEL" ]]`. File not found → upgrade flow skipped → tests ran against old version.

**Evidence**: Log line `Banner: 0.3.39, CLI: 0.3.39` in upgrade run (should show 0.3.40). No "Pre-Upgrade" markers in output.

**Fix**: Resolve wheel paths to absolute before any `cd`.

**Institutionalization**:
- Code fix (path resolution)
- Added migration verification tests (P-UPG-E/F/G)
- Made test 29 resilient to missing columns
- This instruction file created to prevent future symptom-chasing

### Example 2: Flaky Test — Nondeterministic Failure

**Symptom**: Test 12 passes on some runs, fails on others with identical code.

**Investigation**:
1. Added request tracing to MCP server (structured JSONL logs)
2. Compared passing vs failing trace data
3. Found: server starts, loads instructions, reaches ready — server is healthy
4. Found: in failing runs, zero tool calls received despite server being ready

**Root cause**: Not yet confirmed. Claude `--print` mode client behavior is nondeterministic.

**Evidence gap**: Need to distinguish between "server didn't receive call" vs "client didn't send call". Current tracing only covers server side.

**Institutionalization**:
- Added server-side request tracing (collect data for future diagnosis)
- Added retry-with-warmup (mitigate while investigating)
- Logged as known nondeterministic issue (not treated as blocking)
- Plan: add client-side timing data when Claude CLI supports it

### Example 3: Agent Misdiagnosis — Jumped to Conclusion

**Symptom**: Agent attributed test failures to "sqlite3/WAL issues" without checking whether the upgrade actually occurred.

**Investigation**: Reviewing agent's diagnostic approach showed it:
- Checked product code (database.py, health_check.py, connection.py) — all correct
- Did NOT check whether the upgrade E2E flow was actually executing
- Did NOT compare version numbers in the CI output

**Root cause**: No troubleshooting methodology was in place. Agent followed intuition (the handoff mentioned sqlite3 issues) rather than systematically examining logs.

**Institutionalization**: This instruction file — ensures future agents follow evidence-based investigation rather than assumption-based diagnosis.

---

## Validation Checklist

Before marking a troubleshooting investigation complete:

- [ ] All logs from the failure cycle were examined (not just the first failure)
- [ ] Every distinct issue was inventoried and classified (root cause / symptom / cascade / coincidence)
- [ ] Commonalities between issues were identified
- [ ] Each root cause has cited evidence (log line, code path, data point)
- [ ] Each fix has a verification plan and has been verified
- [ ] Each learning has an institutionalization path (PI, instruction, test, code, CI)
- [ ] Institutionalization artifacts actually exist (not just planned)
- [ ] Investigation is documented (commit message, work log, or PI entry)

---

## Common Pitfalls

### Pitfall 1: Fixing the First Symptom and Stopping

- **Problem**: First visible failure is fixed, but underlying cause produces more failures later
- **Why it happens**: Urgency bias — fix the red test, move on
- **Solution**: Inventory ALL issues before fixing ANY. Look for common root causes across multiple symptoms.

### Pitfall 2: Confirmation Bias in Diagnosis

- **Problem**: Agent finds evidence supporting its initial theory and stops looking
- **Why it happens**: Anchoring on the first plausible explanation
- **Solution**: Explicitly check for alternative explanations. Ask "what evidence would disprove this theory?"

### Pitfall 3: Fixing Without Institutionalizing

- **Problem**: Bug is fixed but no structural prevention added. Same class of error recurs.
- **Why it happens**: Fixing feels complete. Institutionalization feels like extra work.
- **Solution**: Treat institutionalization as part of the fix, not a follow-up. A fix without a PI, test, or instruction update is incomplete.

### Pitfall 4: Assuming the Problem is Where It Appears

- **Problem**: Error message points to system A, but root cause is in system B
- **Why it happens**: Taking error messages at face value without tracing upstream
- **Solution**: Trace the causal chain backwards. "Test 28 says branch_name missing" → "Was schema migration supposed to add it?" → "Did the migration run?" → "Did the upgrade even happen?"

### Pitfall 5: Not Checking Recent Changes

- **Problem**: Deep architectural investigation when a recent commit caused the issue
- **Why it happens**: Over-thinking when under-checking
- **Solution**: Always check `git log`, work log entries, and CI config changes BEFORE deep investigation. Most failures trace to recent changes.

---

## Edge Cases

### Edge Case 1: Nondeterministic (Flaky) Failures

**When**: Same code passes sometimes, fails sometimes
**Approach**:
- Add structured tracing/logging to collect data across multiple runs
- Compare passing vs failing traces for differences
- Don't treat as blocking unless failure rate is high
- Document known nondeterminism and mitigations (retries, warmup)
- Create mechanism to track flakiness rate over time

### Edge Case 2: Environment-Specific Failures

**When**: Fails in CI but passes locally (or vice versa)
**Approach**:
- Catalog environment differences (OS, Python version, available tools, network, disk)
- Check for path assumptions (absolute vs relative, platform-specific separators)
- Check for timing assumptions (CI runners are slower, different timeouts needed)
- Check for state assumptions (CI starts clean, local may have cached state)

### Edge Case 3: Cascading Failures Obscuring Root Cause

**When**: One failure causes 5+ downstream failures, making logs noisy
**Approach**:
- Sort failures chronologically (first failure is most likely root cause)
- Look for the earliest timestamp in error logs
- Fix the earliest failure first, then re-run to see which downstream failures resolve
- Remaining failures after first fix are separate root causes

---

## Related Instructions

- **See also**: [ci_cd_pipelines.instructions.md](../devops/ci_cd_pipelines.instructions.md) — Pipeline-specific patterns and configuration
- **See also**: [debugging_log_locations.instructions.md](../devops/debugging_log_locations.instructions.md) — Where to find logs in different environments

---

**Success Criteria**: Investigation identifies root causes (not symptoms), every diagnosis is backed by evidence, and every fix includes an institutionalization artifact that prevents recurrence.

**Confidence Check**: Can you cite the specific log line, code path, or data point that confirms your diagnosis? If not, you're still guessing — go back to Phase 1.
