---
description: Conversational onboarding tutorial with persistent progress
---

# Pongogo Tutorial

Conversational 6-step onboarding that learns how you work and configures Pongogo to match. Each interactive step produces a real artifact in your project.

## Usage

```
/pongogo-tutorial           # Resume from where you left off
/pongogo-tutorial reset     # Start over (clears progress)
```

## Execution

**IMPORTANT: This is a conversational tutorial. Ask one question at a time, listen to the user's answer, act on it, then move to the next step. Do NOT present all steps at once.**

### Core Behavior Rules

**Bail-out**: The user can leave the tutorial at any point. If they change the subject, say something unrelated, or say "I'm done" / "let's stop" / "skip the rest":
- Do NOT push them to continue
- Say: "No problem — you can pick up where you left off anytime with `/pongogo-tutorial`."
- Stop the tutorial flow and respond to whatever they actually want

**Skip**: The user can say "no", "skip", "next", or "pass" to any individual question. When they do:
- Call `complete_tutorial_step` for that step with evidence="Skipped by user"
- Move immediately to the next step
- Do NOT ask why or try to persuade them

**Resume**: The tutorial always picks up at the next incomplete step. Whether invoked via `/pongogo-tutorial`, the nudge instruction, or a backoff re-prompt — always call `get_tutorial_progress` first and start from `next_step`.

### Step 1: Check Progress

Call the `get_tutorial_progress` MCP tool to get current state.

### Step 2: First-Time Welcome (if completed_count is 0)

If the user has never started the tutorial:

```
Hey! I'm going to ask you a few quick questions so Pongogo can learn how you
like to work. Everything you tell me gets turned into real configuration —
instruction files, preferences, and guidance that Pongogo will use going forward.

You can skip any question or bail out anytime — just pick up where you left
off later with /pongogo-tutorial.

Ready? Let's start by learning about your project.
```

**Wait for the user to acknowledge before proceeding.** If they decline or change subject, respect that.

### Step 3: Returning User (if completed_count > 0 but not all complete)

Show progress and pick up at the next step:

```
## Pongogo Tutorial

**Progress**: [completed_count]/6 steps complete

[Show checkmarks for completed steps, empty for incomplete]

Let's pick up where we left off.
```

Then present the next incomplete step.

### Step 4: All Complete

If all 6 steps are done, show the completion message (see bottom).

---

## Step Walkthroughs

### Step 1: Learn About the Project (learn_project)

**Goal**: Understand the project context and capture the user's best practices.

**Action**: Scan the repo to understand what the user is building. Look at:
- Root directory files (package.json, Cargo.toml, pyproject.toml, go.mod, etc.)
- README if it exists
- Directory structure (src/, lib/, app/, etc.)
- Any existing CI/CD configuration

**Then present one of two scenarios**:

**If the repo is empty or brand new**:
```
Looks like you're starting fresh! Before you dive in — are there any best
practices you want to make sure are followed, or common pitfalls you want
to avoid?

For example: "Always write tests first", "Never commit directly to main",
"Use conventional commits", or anything else that matters to you.

(Say "skip" to move on)
```

**If the repo has existing code**:
```
I can see you're building [describe what you found — e.g., "a Python API
using FastAPI with a React frontend"]. Nice!

Are there any best practices you want to make sure are followed, or common
pitfalls you want to avoid?

(Say "skip" to move on)
```

**If user responds with practices**: Call `log_user_guidance` with their response (guidance_type="explicit"). Then explain:

```
Got it — I've recorded that. Pongogo ensures agents work the way you like.
And don't be afraid to give feedback anytime — just tell me what you'd prefer
differently, and I'll learn from it.
```

**If user says skip/no/pass**: That's fine. Move on.

Call `complete_tutorial_step` with step_id="learn_project" and evidence summarizing what happened.

---

### Step 2: Project Kickoff Process (kickoff_process)

**Goal**: Learn how the user starts new work, and configure commencement instructions.

```
When you're kicking off new work — whether it's a feature, a bug fix, or a
refactor — are there steps you like to follow?

For example, some people always create a branch first, others start with a
design doc, some want tests written before code. What's your process?

(Say "skip" to move on)
```

**If user responds**: Take their input and create a custom instruction file at `.pongogo/instructions/custom/kickoff_process.instructions.md`. Call `reindex_knowledge_base` and explain:

```
Done — Pongogo will help make sure those steps are followed when you start
new work. You can always edit this later at:
.pongogo/instructions/custom/kickoff_process.instructions.md
```

Then add the decision capture mention:
```
Also — if you ever want to make sure a key decision is remembered and
institutionalized, just ask.
```

**If user says skip/no/pass**: Move on.

Call `complete_tutorial_step` with step_id="kickoff_process" and evidence noting what happened.

---

### Step 3: Task Completion Process (completion_process)

**Goal**: Learn how the user finishes work, and configure closure instructions.

```
What about when a task is done? Is there a process you like to follow —
code review, testing checklist, documentation update, anything like that?

(Say "skip" to move on)
```

**If user responds**: Create a custom instruction file at `.pongogo/instructions/custom/completion_process.instructions.md`. Call `reindex_knowledge_base` and explain:

```
Pongogo will make sure tasks follow your closure process. Editable at:
.pongogo/instructions/custom/completion_process.instructions.md
```

Then add the PR mention:
```
By the way — Pongogo can also help when you're putting together a pull
request. It'll make sure the description is thorough and quality checks
are covered.
```

**If user says skip/no/pass**: Move on.

Call `complete_tutorial_step` with step_id="completion_process" and evidence noting what happened.

---

### Step 4: Work Logging (work_logging)

**Goal**: Explain work logging and wiki integration.

```
One of the things Pongogo is great at is helping build actionable institutional
knowledge. Here's a tip: ask for work to be logged when you finish any task —
from a small issue to a major milestone.
```

**Check for wiki directory**:
- If `wiki/` exists: "Your work log entries will go into the wiki as structured pages."
- If no wiki: "Pongogo will create and manage a wiki/ folder for your work log entries."

```
Pongogo tracks and manages these entries, so you build a living record of what
was done and why. Just say "log this work" or use /pongogo-add-work-log-entry
when you're done with something.
```

Call `complete_tutorial_step` with step_id="work_logging" and evidence="Explained work logging and wiki integration".

---

### Step 5: Root Cause Analysis (rca_capability)

**Goal**: Explain RCA capability.

```
Sometimes things don't go as planned. When something goes wrong — a deployment
fails, a bug slips through, a process breaks down — just ask Pongogo to help
with a root cause analysis.

It'll walk you through a structured investigation and help prevent the same
mistake from happening again, regardless of the size. You can say "let's do
an RCA" or use /pongogo-perform-rca.
```

Call `complete_tutorial_step` with step_id="rca_capability" and evidence="Explained RCA capability".

---

### Step 6: Retrospectives (retro_capability)

**Goal**: Explain retrospective capability.

```
Regardless of how things go, it's always helpful to look back. Just ask
Pongogo to help run a retro, and it'll help ensure you and your agent are
collaborating well and continue to improve the way you work.

Say "let's do a retro" or use /pongogo-conduct-retro after finishing a chunk
of work.
```

Call `complete_tutorial_step` with step_id="retro_capability" and evidence="Explained retrospective capability".

---

## Congratulations Message

When all 6 steps are complete:

```
## You're all set!

Pongogo now knows how you like to work:

1. Your project context and best practices — recorded as guidance
2. Your kickoff process — built into an instruction file
3. Your completion process — built into an instruction file

And you know about the tools at your disposal:
4. Work logging — builds institutional knowledge
5. Root cause analysis — prevents repeated mistakes
6. Retrospectives — continuous improvement

Pongogo runs in the background automatically. As you work, relevant guidance
appears without you needing to do anything. And whenever you give feedback,
Pongogo learns from it.

Happy building!
```

## Reset

If the user passes `reset` as an argument:

1. Explain that this will clear all tutorial progress
2. Ask for confirmation
3. If confirmed, execute SQL: `DELETE FROM tutorial_progress` (via a direct database operation)
4. Confirm reset and show Step 1