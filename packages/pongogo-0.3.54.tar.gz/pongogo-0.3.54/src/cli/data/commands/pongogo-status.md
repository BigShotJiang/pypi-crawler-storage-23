---
description: Show current state and server health
---

# Pongogo MCP Server Status

Quick health check for Pongogo knowledge routing.

## Instructions

**NOTE**: Do NOT pre-check for MCP tool availability. Simply attempt to call the MCP tools
and report any errors that occur. The tools may be available even if not visible in the
tools list (e.g., in --print mode).

Execute silently and display only the formatted output below.

### Checks to Perform

**IMPORTANT: Run ALL MCP tool calls SEQUENTIALLY (one at a time). Do NOT parallelize them.**
MCP calls can fail transiently, and parallel failures cause sibling cancellation (all calls lost).

1. Read `.pongogo-mcp-state.json` for mode
2. Call `get_health_status` MCP tool first — it returns comprehensive health in one call
   - Use `events.status` for Event Logging status
   - Use `database.status` for database health
   - Use `config.status` for configuration health
3. Call `get_routing_info` MCP tool to get engine version, preceptor version, and instruction count
   - **If `get_routing_info` fails**: Fall back to engine version from step 4's `route_instructions` response
   - Show the engine version you have; do NOT show ❌ for Engine/Preceptor/Instructions if you have the data from another source
4. Call `route_instructions` with any test query - only need to know if it returns > 0 results
   - The response often includes engine version — use as fallback for step 3
5. **Event Logging**: Prefer the `events` field from `get_health_status` (step 2).
   Only call `get_routing_event_stats` if `get_health_status` is unavailable.
   - Active ✅: status is "active" and last_event is recent
   - Stale ⚠️: status is "active" but last_event is older than 1 hour
   - Empty ⚠️: status is "empty" — database exists but no events yet (normal on fresh install)
   - Failed ❌: status is "missing", or tool call fails
   - Do NOT use Bash/sqlite3 to query the database directly — use the MCP tool

### Output Format

```
## Pongogo Status

**Mode**: [ENABLED ✅ | DISABLED ⭕ | SIMULATE 🧪]
**Engine**: [engine version from get_routing_info]
**Preceptor**: [preceptor_version from get_routing_info]
**Instructions**: [instruction_count from get_routing_info]
**Routing**: [Working ✅ | Failed ❌]
**Event Logging**: [Active ✅ | Empty ⚠️ | Stale ⚠️ | Failed ❌]
```

If all pass, add:
```
All systems operational.
```

If any fail, show the ❌ status and the relevant fix:

- MCP tool call failed: Check that the MCP server is running and configured in `.mcp.json`
- Routing failed (0 results): Restart Claude Code, or run `pongogo init --force` to reinitialize
- Event Logging stale/failed: Run `/mcp` to reconnect, then verify with `/pongogo-status`

### Commands Reference

Show only if user asks or if troubleshooting:
- `/pongogo-diagnose` - Deep diagnostics
- `/pongogo-tips-and-tricks` - Onboarding guide
- `/pongogo-upgrade` - Update to latest version
