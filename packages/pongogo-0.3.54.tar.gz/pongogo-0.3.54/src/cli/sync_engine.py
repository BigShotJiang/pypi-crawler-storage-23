"""Content sync engine for post-upgrade seeded file management.

Given an old seed manifest and the current seed, computes which files to
overwrite, create, or delete, then updates the manifest on disk.

Epic #304: Post-Upgrade Seed Sync
Task #665: Content Sync Engine
"""

from __future__ import annotations

import contextlib
import logging
from dataclasses import dataclass, field
from pathlib import Path

from mcp_server.upgrade import get_current_version

from .config import load_config
from .installations import (
    list_installations,
    prune_stale_installations,
    register_installation,
)
from .instructions import (
    copy_instructions,
    copy_manifest,
    copy_slash_commands,
    get_enabled_categories,
    get_package_instructions_dir,
    load_manifest,
)
from .seed_manifest import (
    compute_file_hash,
    generate_seed_manifest,
    read_seed_manifest,
    write_seed_manifest,
)

logger = logging.getLogger(__name__)


@dataclass
class SyncResult:
    """Outcome of a seeded-content sync operation."""

    files_updated: list[str] = field(default_factory=list)
    files_created: list[str] = field(default_factory=list)
    files_removed: list[str] = field(default_factory=list)
    files_skipped: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    old_version: str | None = None
    new_version: str = ""


def _resolve_dest_path(project_root: Path, key: str) -> Path:
    """Map a manifest key to an absolute destination path.

    Keys use the format:
      instructions/category/file.md  -> .pongogo/instructions/category/file.md
      commands/file.md               -> .claude/commands/file.md
    """
    if key.startswith("instructions/"):
        return project_root / ".pongogo" / key
    if key.startswith("commands/"):
        suffix = key[len("commands/") :]
        return project_root / ".claude" / "commands" / suffix
    return project_root / key


def sync_seeded_content(
    project_root: Path,
    force: bool = False,
) -> SyncResult:
    """Synchronise seeded instruction and command files after an upgrade.

    1. Reads the old manifest (may be None on first sync).
    2. Copies all current seed files (always overwrites).
    3. Deletes files removed from the seed (unless user-modified and not force).
    4. Writes a fresh manifest.

    Args:
        project_root: Absolute path to the project root directory.
        force: If True, delete user-modified files that were removed from seed.

    Returns:
        SyncResult describing what changed.
    """
    result = SyncResult()

    pongogo_dir = project_root / ".pongogo"
    config_path = pongogo_dir / "config.yaml"

    # --- guard: config must exist (pongogo init must have run) ---
    if not config_path.exists():
        result.errors.append(
            f"Config not found at {config_path}. Run 'pongogo init' first."
        )
        return result

    # --- load config + seed metadata ---
    config = load_config(config_path)
    old_manifest = read_seed_manifest(pongogo_dir)
    result.old_version = old_manifest["pongogo_version"] if old_manifest else None

    version = get_current_version()
    result.new_version = version

    old_files: dict[str, dict] = old_manifest.get("files", {}) if old_manifest else {}
    old_keys = set(old_files.keys())

    # --- copy seed files (overwrites existing) ---
    source_dir = get_package_instructions_dir()
    pkg_manifest = load_manifest(source_dir)
    enabled = get_enabled_categories(pkg_manifest, config.get("categories", {}))

    instructions_dest = pongogo_dir / "instructions"
    _, instruction_pairs = copy_instructions(
        source_dir, instructions_dest, pkg_manifest, enabled
    )
    copy_manifest(source_dir, instructions_dest)

    commands_dest = project_root / ".claude" / "commands"
    _, command_pairs = copy_slash_commands(commands_dest)

    # --- classify each copied file ---
    all_pairs = instruction_pairs + command_pairs
    new_keys: set[str] = set()
    for key, _path in all_pairs:
        new_keys.add(key)
        if key in old_keys:
            result.files_updated.append(key)
        else:
            result.files_created.append(key)

    # --- handle removals (keys in old but not in new seed) ---
    removed_keys = old_keys - new_keys
    for key in sorted(removed_keys):
        dest = _resolve_dest_path(project_root, key)
        if not dest.exists():
            # Already gone on disk — nothing to do, not an error
            continue

        should_delete = force
        if not force:
            old_hash = old_files[key].get("hash", "")
            try:
                current_hash = compute_file_hash(dest)
            except OSError as exc:
                result.errors.append(f"Cannot read {key} for hash check: {exc}")
                continue
            should_delete = current_hash == old_hash

        if should_delete:
            try:
                dest.unlink()
                result.files_removed.append(key)
            except OSError as exc:
                result.errors.append(f"Failed to delete {key}: {exc}")
        else:
            result.files_skipped.append(key)

    # --- remove orphaned pongogo-* commands not in current seed ---
    # Handles pre-manifest leftovers: commands installed by older versions
    # that were removed from the seed before the manifest system existed.
    # Only targets pongogo-* prefixed files to avoid touching user commands.
    seeded_cmd_names = {
        key.split("/")[-1] for key in new_keys if key.startswith("commands/")
    }
    if commands_dest.exists():
        for cmd_file in sorted(commands_dest.glob("pongogo-*.md")):
            if cmd_file.name not in seeded_cmd_names:
                key = f"commands/{cmd_file.name}"
                if key in removed_keys:
                    continue  # already handled by manifest-based removal
                try:
                    cmd_file.unlink()
                    result.files_removed.append(f"{key} (orphan)")
                except OSError as exc:
                    result.errors.append(
                        f"Failed to delete orphan {cmd_file.name}: {exc}"
                    )

    # --- write new manifest ---
    new_manifest = generate_seed_manifest(all_pairs, version)
    write_seed_manifest(pongogo_dir, new_manifest)

    logger.info(
        "Sync complete: %d updated, %d created, %d removed, %d skipped, %d errors",
        len(result.files_updated),
        len(result.files_created),
        len(result.files_removed),
        len(result.files_skipped),
        len(result.errors),
    )
    return result


@dataclass
class PropagationResult:
    """Outcome of propagating sync to all registered installations."""

    total_installations: int = 0
    synced: int = 0
    pruned: int = 0
    failed: int = 0
    skipped: int = 0
    details: list[dict] = field(default_factory=list)


def propagate_sync_to_installations(
    current_project: Path,
    force: bool = False,
    db_path: Path | None = None,
) -> PropagationResult:
    """Propagate seeded content sync to all registered installations.

    After upgrading, the current project is already synced by the caller.
    This function syncs all other registered installations, pruning stale
    entries first.

    Args:
        current_project: Path of the project that was already synced.
        force: If True, force-sync (delete user-modified removed files).
        db_path: Override installations DB path (for testing).

    Returns:
        PropagationResult describing what happened across all installations.
    """
    result = PropagationResult()
    current_resolved = str(current_project.resolve())

    # Prune stale installations first
    try:
        result.pruned = prune_stale_installations(db_path)
        if result.pruned > 0:
            logger.info("Pruned %d stale installation(s)", result.pruned)
    except Exception as exc:
        logger.debug("Failed to prune stale installations: %s", exc)

    # List remaining installations
    try:
        installations = list_installations(db_path)
    except Exception as exc:
        logger.debug("Failed to list installations: %s", exc)
        return result

    result.total_installations = len(installations)

    for inst in installations:
        project_root = inst["project_root"]

        # Skip the current project — it's already synced by the caller
        if project_root == current_resolved:
            result.skipped += 1
            result.details.append(
                {"project": project_root, "status": "skipped", "reason": "current"}
            )
            continue

        # Sync this installation (failures don't block others — AC #5)
        try:
            sync_result = sync_seeded_content(Path(project_root), force=force)
            result.synced += 1

            # Refresh last_synced_at on success
            with contextlib.suppress(Exception):
                register_installation(
                    project_root=project_root,
                    version=get_current_version(),
                    install_method=inst.get("install_method", "unknown"),
                    db_path=db_path,
                )

            total_changes = (
                len(sync_result.files_updated)
                + len(sync_result.files_created)
                + len(sync_result.files_removed)
            )
            result.details.append(
                {
                    "project": project_root,
                    "status": "synced",
                    "changes": total_changes,
                }
            )
        except Exception as exc:
            result.failed += 1
            result.details.append(
                {"project": project_root, "status": "failed", "error": str(exc)}
            )
            logger.debug("Sync failed for %s: %s", project_root, exc)

    logger.info(
        "Propagation complete: %d synced, %d skipped, %d failed, %d pruned (of %d total)",
        result.synced,
        result.skipped,
        result.failed,
        result.pruned,
        result.total_installations,
    )
    return result
