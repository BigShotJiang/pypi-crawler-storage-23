"""Docker container lifecycle management for Pongogo daemon containers.

Provides functions to create, start, stop, and inspect named daemon containers.
Each project gets a persistent container instead of ephemeral docker-run instances,
eliminating container sprawl and SQLite contention.
"""

import hashlib
import os
import re
import subprocess
from datetime import UTC, datetime
from pathlib import Path

CONTAINER_PREFIX = "pongogo-"
LABEL_MANAGED = "com.pongogo.managed"
LABEL_PROJECT_PATH = "com.pongogo.project-path"
LABEL_VERSION = "com.pongogo.version"
LABEL_CREATED_AT = "com.pongogo.created-at"


def slugify_container_name(project_root: Path) -> str:
    """Convert a project root path into a valid Docker container name suffix.

    Takes the basename of the project root, lowercases it, replaces
    non-alphanumeric characters with hyphens, strips leading/trailing
    hyphens, and truncates to 40 characters.

    Args:
        project_root: Absolute path to the project root.

    Returns:
        A sanitized string suitable as a container name suffix.
    """
    name = project_root.name.lower()
    name = re.sub(r"[^a-z0-9]+", "-", name)
    name = name.strip("-")
    name = name[:40]
    return name


def get_container_name(project_root: Path) -> str:
    """Resolve the container name for a project, with collision detection.

    Uses slugify_container_name to derive a base name, then checks if an
    existing container with that name belongs to a different project (via
    the com.pongogo.project-path label). If a collision is detected, appends
    a 4-character hash of the absolute path.

    Args:
        project_root: Absolute path to the project root.

    Returns:
        Container name prefixed with 'pongogo-'.
    """
    slug = slugify_container_name(project_root)
    base_name = f"{CONTAINER_PREFIX}{slug}"
    abs_path = str(project_root.resolve())

    if container_exists(base_name):
        existing_path = _get_container_label(base_name, LABEL_PROJECT_PATH)
        if existing_path and existing_path != abs_path:
            path_hash = hashlib.sha256(abs_path.encode()).hexdigest()[:4]
            return f"{base_name}-{path_hash}"

    return base_name


def container_exists(name: str) -> bool:
    """Check if a Docker container exists (running or stopped).

    Args:
        name: Container name.

    Returns:
        True if the container exists.
    """
    try:
        result = subprocess.run(
            ["docker", "container", "inspect", name],
            capture_output=True,
            timeout=10,
        )
        return result.returncode == 0
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return False


def container_is_running(name: str) -> bool:
    """Check if a Docker container is currently running.

    Args:
        name: Container name.

    Returns:
        True if the container exists and is running.
    """
    try:
        result = subprocess.run(
            ["docker", "inspect", "--format", "{{.State.Running}}", name],
            capture_output=True,
            text=True,
            timeout=10,
        )
        return result.returncode == 0 and result.stdout.strip() == "true"
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return False


def build_labels(project_root: Path, image: str) -> dict[str, str]:
    """Build Docker labels for a Pongogo daemon container.

    Args:
        project_root: Absolute path to the project root.
        image: Docker image name used for this container.

    Returns:
        Dictionary of label key-value pairs.
    """
    version = os.environ.get("PONGOGO_VERSION", "unknown")
    return {
        LABEL_MANAGED: "true",
        LABEL_PROJECT_PATH: str(project_root.resolve()),
        LABEL_VERSION: version,
        LABEL_CREATED_AT: datetime.now(UTC).isoformat(),
    }


def start_daemon(
    name: str,
    project_root: Path,
    pongogo_path: str,
    image: str,
    uid: int,
    gid: int,
    labels: dict[str, str],
) -> bool:
    """Start a persistent daemon container for the project.

    If a stopped container with the same name exists, it is removed first.
    The daemon runs ``sleep infinity`` as its command; actual work happens
    via ``docker exec``.

    Args:
        name: Container name.
        project_root: Absolute path to the project root.
        pongogo_path: Host path to the .pongogo directory (for volume mount).
        image: Docker image to use.
        uid: User ID for --user flag.
        gid: Group ID for --user flag.
        labels: Docker labels to apply.

    Returns:
        True if the daemon was started successfully.
    """
    # Remove stopped container with same name if it exists
    if container_exists(name) and not container_is_running(name):
        subprocess.run(
            ["docker", "rm", name],
            capture_output=True,
            timeout=10,
        )

    # If already running, nothing to do
    if container_is_running(name):
        return True

    cmd = [
        "docker",
        "run",
        "-d",
        "--name",
        name,
        "--restart",
        "unless-stopped",
        "--user",
        f"{uid}:{gid}",
        "-v",
        f"{pongogo_path}:/project/.pongogo:z",
        "-e",
        f"PONGOGO_IMAGE={image}",
        "-e",
        "PONGOGO_PROJECT_ROOT=/project",
        "-e",
        "PONGOGO_KNOWLEDGE_PATH=/project/.pongogo/instructions",
    ]

    for key, value in labels.items():
        cmd.extend(["--label", f"{key}={value}"])

    cmd.extend([image, "sleep", "infinity"])

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=30,
        )
        return result.returncode == 0
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return False


def stop_daemon(name: str) -> bool:
    """Stop and remove a daemon container.

    Args:
        name: Container name.

    Returns:
        True if the container was stopped and removed (or didn't exist).
    """
    if not container_exists(name):
        return True

    try:
        subprocess.run(
            ["docker", "stop", name],
            capture_output=True,
            timeout=30,
        )
        subprocess.run(
            ["docker", "rm", name],
            capture_output=True,
            timeout=10,
        )
        return True
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return False


def _get_container_label(name: str, label: str) -> str | None:
    """Get a specific label value from a container.

    Args:
        name: Container name.
        label: Label key to retrieve.

    Returns:
        Label value, or None if not found.
    """
    try:
        result = subprocess.run(
            [
                "docker",
                "inspect",
                "--format",
                f'{{{{index .Config.Labels "{label}"}}}}',
                name,
            ],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode == 0:
            value = result.stdout.strip()
            return value if value else None
        return None
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return None
