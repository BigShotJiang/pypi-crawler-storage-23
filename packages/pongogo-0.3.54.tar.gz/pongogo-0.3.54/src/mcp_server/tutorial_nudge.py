"""Tutorial auto-trigger nudge system (Issue #674).

Detects when to prompt users about the onboarding tutorial and returns
a structured nudge dict for injection into route_instructions() responses.

Nudge types:
- first_run: Brand new user, no tutorial progress at all
- post_upgrade: Successful upgrade occurred after last tutorial activity
- contextual: Routed categories match an incomplete tutorial step

Session backoff: Only one nudge per MCP server session (process lifetime).
"""

import logging
import sqlite3
import uuid
from pathlib import Path

from .database.connection import get_connection

logger = logging.getLogger(__name__)

# Session ID: one UUID per MCP server process lifetime.
# MCP server is long-lived per Claude Code session, so this gives
# exactly one nudge opportunity per session.
_SESSION_ID = str(uuid.uuid4())

# Canonical step definitions for the first-user tutorial.
# Moved here from server.py to avoid circular imports; server.py imports from here.
TUTORIAL_STEPS = [
    {
        "step_id": "learn_project",
        "step_number": 1,
        "title": "Learn About the Project",
        "description": "Scan the repo, ask about best practices and pitfalls, log as PI.",
    },
    {
        "step_id": "kickoff_process",
        "step_number": 2,
        "title": "Project Kickoff Process",
        "description": "Ask how the user starts new work, modify commencement instructions.",
    },
    {
        "step_id": "completion_process",
        "step_number": 3,
        "title": "Task Completion Process",
        "description": "Ask how the user finishes work, modify closure instructions. Mention PR support.",
    },
    {
        "step_id": "work_logging",
        "step_number": 4,
        "title": "Work Logging",
        "description": "Explain work logging and wiki integration.",
    },
    {
        "step_id": "rca_capability",
        "step_number": 5,
        "title": "Root Cause Analysis",
        "description": "Explain RCA capability for when things go wrong.",
    },
    {
        "step_id": "retro_capability",
        "step_number": 6,
        "title": "Retrospectives",
        "description": "Explain retrospective capability for continuous improvement.",
    },
]

# Maps tutorial step_ids to instruction categories they relate to.
# Used for contextual nudges: if routing returns instructions from a category
# that matches an incomplete step, we nudge about that specific step.
STEP_CATEGORY_MAP: dict[str, list[str]] = {
    "learn_project": ["architecture", "development"],
    "kickoff_process": ["project_management", "github"],
    "completion_process": ["project_management", "github", "quality"],
    "work_logging": ["learning", "documentation"],
    "rca_capability": ["quality", "safety_prevention", "learning"],
    "retro_capability": ["learning"],
}


def get_user_tutorial_db_path() -> Path:
    """Get path to user-level tutorial database.

    Returns ~/.pongogo/pongogo.db — the user-scoped database that persists
    across projects. Tutorial state is user-level, not project-level.
    """
    return Path.home() / ".pongogo" / "pongogo.db"


def _ensure_user_tutorial_tables(conn: sqlite3.Connection) -> None:
    """Create tutorial tables if they don't exist in the user-level DB.

    Creates both tutorial_progress (step completions) and tutorial_nudge_log
    (session-level nudge tracking) tables.
    """
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS tutorial_progress (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            step_id TEXT NOT NULL UNIQUE,
            step_title TEXT,
            completed_at TEXT,
            evidence TEXT,
            session_id TEXT
        );

        CREATE TABLE IF NOT EXISTS tutorial_nudge_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT NOT NULL,
            nudge_type TEXT NOT NULL,
            nudge_timestamp TEXT NOT NULL,
            pongogo_version TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_nudge_log_session
            ON tutorial_nudge_log(session_id);
        """
    )


def _find_relevant_step(
    routed_categories: list[str],
    completed_ids: set[str],
) -> dict | None:
    """Find the first incomplete tutorial step matching a routed category.

    Args:
        routed_categories: Categories from the current routing response.
        completed_ids: Set of step_ids already completed.

    Returns:
        Step definition dict if a relevant incomplete step is found, else None.
    """
    routed_set = set(routed_categories)
    for step in TUTORIAL_STEPS:
        sid = str(step["step_id"])
        if sid in completed_ids:
            continue
        step_categories = STEP_CATEGORY_MAP.get(sid, [])
        if routed_set & set(step_categories):
            return step
    return None


def _check_upgrade_since(
    last_tutorial_at: str | None,
    project_root: Path | None,
) -> bool:
    """Check if a successful upgrade occurred after the last tutorial activity.

    Queries the project-level upgrade_history table for successful upgrades
    after the given timestamp.

    Args:
        last_tutorial_at: ISO timestamp of last tutorial completion, or None.
        project_root: Project root for locating the project database.

    Returns:
        True if an upgrade occurred after last_tutorial_at.
    """
    if not last_tutorial_at or not project_root:
        return False

    project_db = project_root / ".pongogo" / "pongogo.db"
    if not project_db.exists():
        return False

    try:
        with get_connection(project_db, readonly=True) as conn:
            row = conn.execute(
                """SELECT COUNT(*) as cnt FROM upgrade_history
                   WHERE upgrade_succeeded = 1
                   AND timestamp > ?""",
                (last_tutorial_at,),
            ).fetchone()
            return bool(row and row["cnt"] > 0)
    except Exception:
        return False


def check_tutorial_nudge(
    routed_categories: list[str],
    pongogo_version: str,
    project_root: Path | None = None,
) -> dict | None:
    """Determine whether to nudge the user about the onboarding tutorial.

    Detection logic:
    1. Open user-level DB at ~/.pongogo/pongogo.db
    2. Query tutorial_progress for completed steps
    3. If all 6 complete -> None (never nudge)
    4. If already nudged this session -> None (session backoff)
    5. If no tutorial_progress rows at all -> "first_run" nudge
    6. If upgrade after last completion -> "post_upgrade" nudge
    7. If routed categories match incomplete step -> "contextual" nudge
    8. Otherwise -> None

    Args:
        routed_categories: Categories from the current routing response.
        pongogo_version: Current Pongogo version string.
        project_root: Project root for upgrade history checks.

    Returns:
        Nudge dict with type/message/steps info, or None if no nudge warranted.
    """
    try:
        db_path = get_user_tutorial_db_path()
        db_path.parent.mkdir(parents=True, exist_ok=True)

        with get_connection(db_path) as conn:
            _ensure_user_tutorial_tables(conn)

            # 1. Query completed steps
            rows = conn.execute(
                "SELECT step_id, completed_at FROM tutorial_progress WHERE completed_at IS NOT NULL"
            ).fetchall()
            completed_ids = {row["step_id"] for row in rows}
            completed_count = len(completed_ids)

            # 2. All complete -> never nudge
            if completed_count >= len(TUTORIAL_STEPS):
                return None

            # 3. Session backoff: already nudged this session?
            nudge_row = conn.execute(
                "SELECT id FROM tutorial_nudge_log WHERE session_id = ? LIMIT 1",
                (_SESSION_ID,),
            ).fetchone()
            if nudge_row:
                return None

            # Determine nudge type
            nudge_type: str | None = None
            relevant_step: dict | None = None

            if completed_count == 0:
                # 4. Brand new user
                nudge_type = "first_run"
            else:
                # 5. Check for post-upgrade nudge
                last_completed = max(
                    (row["completed_at"] for row in rows), default=None
                )
                if _check_upgrade_since(last_completed, project_root):
                    nudge_type = "post_upgrade"

            # 6. Contextual nudge (if no higher-priority nudge found)
            if nudge_type is None and routed_categories:
                relevant_step = _find_relevant_step(routed_categories, completed_ids)
                if relevant_step:
                    nudge_type = "contextual"

            # 7. No nudge warranted
            if nudge_type is None:
                return None

            # Record the nudge to enforce session backoff
            from datetime import datetime
            from zoneinfo import ZoneInfo

            now = datetime.now(ZoneInfo("UTC")).isoformat()
            conn.execute(
                """INSERT INTO tutorial_nudge_log
                   (session_id, nudge_type, nudge_timestamp, pongogo_version)
                   VALUES (?, ?, ?, ?)""",
                (_SESSION_ID, nudge_type, now, pongogo_version),
            )

            # Find next incomplete step
            next_step = None
            for step in TUTORIAL_STEPS:
                if step["step_id"] not in completed_ids:
                    next_step = {
                        "step_id": step["step_id"],
                        "step_number": step["step_number"],
                        "title": step["title"],
                    }
                    break

            incomplete_count = len(TUTORIAL_STEPS) - completed_count

            # Build message based on nudge type
            if nudge_type == "first_run":
                message = (
                    "New user detected — tutorial available. "
                    "Run /pongogo-tutorial for a guided tour of Pongogo's capabilities."
                )
            elif nudge_type == "post_upgrade":
                message = (
                    "Pongogo was recently upgraded. "
                    f"You have {incomplete_count} tutorial step(s) remaining. "
                    "Run /pongogo-tutorial to continue."
                )
            else:  # contextual
                step_title = relevant_step["title"] if relevant_step else "next step"
                message = (
                    f"This topic relates to tutorial step: {step_title}. "
                    "Run /pongogo-tutorial to learn more."
                )

            result: dict = {
                "nudge_type": nudge_type,
                "directive": "Call `get_tutorial_progress()` MCP tool to see onboarding status",
                "message": message,
                "incomplete_steps": incomplete_count,
                "next_step": next_step,
                "version": pongogo_version,
            }
            if nudge_type == "contextual" and relevant_step:
                result["relevant_step"] = {
                    "step_id": relevant_step["step_id"],
                    "step_number": relevant_step["step_number"],
                    "title": relevant_step["title"],
                }

            logger.info(
                f"Issue #674: Tutorial nudge triggered ({nudge_type}) "
                f"for session {_SESSION_ID[:8]}..."
            )
            return result

    except Exception as e:
        logger.warning(f"Issue #674: Tutorial nudge check failed: {e}")
        return None
