"""
PI System Database - Schema and Connection Management

Provides SQLite database for PI metadata, evidence, and relationships.
"""

import os
import sqlite3
from contextlib import contextmanager
from pathlib import Path

from mcp_server.database.connection import get_connection


def _get_default_db_path() -> Path:
    """
    Get default PI database path with container-aware resolution.

    Resolution order:
    1. PONGOGO_PROJECT_ROOT env var → /project/.pongogo/potential_improvements.db
    2. Fall back to legacy path (relative to this file)

    This is critical for containerized deployments where:
    - Container filesystem is at /app (read-only for package code)
    - Project state is mounted at /project/.pongogo (writable)
    """
    project_root = os.environ.get("PONGOGO_PROJECT_ROOT")
    if project_root:
        return Path(project_root) / ".pongogo" / "potential_improvements.db"
    # Legacy fallback for non-containerized development
    return (
        Path(__file__).parent.parent.parent.parent
        / ".pongogo"
        / "potential_improvements.db"
    )


# Default database location (computed at import time)
DEFAULT_DB_PATH = _get_default_db_path()


class PIDatabase:
    """SQLite database for Potential Improvements system."""

    SCHEMA_VERSION = 3  # v3: Added pi_type and context columns (Task #330)

    # Tables only - split from indexes for migration compatibility
    SCHEMA_TABLES = """
    -- Schema version tracking
    CREATE TABLE IF NOT EXISTS schema_info (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
    );

    -- Core PI metadata
    CREATE TABLE IF NOT EXISTS potential_improvements (
        id TEXT PRIMARY KEY,                    -- PI-001, PI-002, etc.
        title TEXT NOT NULL,
        summary TEXT,
        status TEXT NOT NULL DEFAULT 'CANDIDATE',
        confidence TEXT NOT NULL DEFAULT 'LOW',
        classification TEXT,                     -- CORRECTIVE, EXPLORATORY
        classification_reason TEXT,              -- Why this classification was chosen
        classification_model TEXT,               -- Which model made the classification
        classification_date TEXT,                -- When classification was made
        pi_type TEXT DEFAULT 'improvement',      -- improvement, glossary_candidate, faq_candidate (Task #330)
        context TEXT,                            -- Optional context/category for the candidate
        cluster TEXT,                            -- Domain cluster
        identified_date TEXT,
        last_updated TEXT,
        occurrence_count INTEGER DEFAULT 1,
        source_task TEXT,                        -- Task that identified this PI
        file_path TEXT,                          -- Path to detailed markdown file
        archived INTEGER DEFAULT 0              -- Soft delete flag
    );

    -- Evidence accumulation (each occurrence)
    CREATE TABLE IF NOT EXISTS pi_evidence (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        pi_id TEXT NOT NULL,
        date TEXT NOT NULL,
        source TEXT NOT NULL,                    -- Task #123, RCA-2025-11-15, etc.
        description TEXT,
        FOREIGN KEY (pi_id) REFERENCES potential_improvements(id) ON DELETE CASCADE
    );

    -- N-to-N relationships between PIs
    CREATE TABLE IF NOT EXISTS pi_relationships (
        pi_id_1 TEXT NOT NULL,
        pi_id_2 TEXT NOT NULL,
        relationship_type TEXT NOT NULL,         -- OVERLAPS, SUPERSEDES, BLOCKS, RELATED, DUPLICATE
        notes TEXT,
        discovered_date TEXT,
        PRIMARY KEY (pi_id_1, pi_id_2, relationship_type),
        FOREIGN KEY (pi_id_1) REFERENCES potential_improvements(id) ON DELETE CASCADE,
        FOREIGN KEY (pi_id_2) REFERENCES potential_improvements(id) ON DELETE CASCADE
    );

    -- Implementation tracking
    CREATE TABLE IF NOT EXISTS pi_implementations (
        pi_id TEXT PRIMARY KEY,
        implementation_date TEXT,
        implementation_type TEXT,                -- PATTERN_LIBRARY, INSTRUCTION_FILE, PROCESS_DOC, CODE
        location TEXT,                           -- Where implemented (file path, wiki page, etc.)
        notes TEXT,
        FOREIGN KEY (pi_id) REFERENCES potential_improvements(id) ON DELETE CASCADE
    );
    """

    # Indexes - created after migration to ensure columns exist
    SCHEMA_INDEXES = """
    CREATE INDEX IF NOT EXISTS idx_pi_status ON potential_improvements(status);
    CREATE INDEX IF NOT EXISTS idx_pi_confidence ON potential_improvements(confidence);
    CREATE INDEX IF NOT EXISTS idx_pi_classification ON potential_improvements(classification);
    CREATE INDEX IF NOT EXISTS idx_pi_type ON potential_improvements(pi_type);
    CREATE INDEX IF NOT EXISTS idx_pi_cluster ON potential_improvements(cluster);
    CREATE INDEX IF NOT EXISTS idx_pi_archived ON potential_improvements(archived);
    CREATE INDEX IF NOT EXISTS idx_evidence_pi_id ON pi_evidence(pi_id);
    CREATE INDEX IF NOT EXISTS idx_evidence_date ON pi_evidence(date);
    CREATE INDEX IF NOT EXISTS idx_relationships_type ON pi_relationships(relationship_type);
    """

    # Combined for backwards compatibility
    SCHEMA = SCHEMA_TABLES + SCHEMA_INDEXES

    # Migration for v2 -> v3
    MIGRATION_V3 = """
    -- Add pi_type column (Task #330)
    ALTER TABLE potential_improvements ADD COLUMN pi_type TEXT DEFAULT 'improvement';

    -- Add context column (Task #330)
    ALTER TABLE potential_improvements ADD COLUMN context TEXT;

    -- Create index for pi_type
    CREATE INDEX IF NOT EXISTS idx_pi_type ON potential_improvements(pi_type);
    """

    def __init__(self, db_path: Path | None = None):
        """
        Initialize database connection.

        Args:
            db_path: Path to SQLite database file. Defaults to .pongogo/potential_improvements.db
        """
        self.db_path = db_path or DEFAULT_DB_PATH
        self._ensure_db_exists()

    def _ensure_db_exists(self):
        """Create database and schema if they don't exist, run migrations if needed."""
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        with self.connection() as conn:
            # Fast-path: skip if PRAGMA user_version is current
            current_uv = conn.execute("PRAGMA user_version").fetchone()[0]
            if current_uv >= 1:
                return

            # Run base schema first (tables only, indexes later)
            conn.executescript(self.SCHEMA_TABLES)
            # Check current version and migrate if needed
            current_version = self._get_schema_version_raw(conn)
            if current_version < 3:
                self._migrate_to_v3(conn)
            # Now create indexes (after migration ensures columns exist)
            conn.executescript(self.SCHEMA_INDEXES)
            # Set schema version
            conn.execute(
                "INSERT OR REPLACE INTO schema_info (key, value) VALUES (?, ?)",
                ("schema_version", str(self.SCHEMA_VERSION)),
            )
            conn.execute("PRAGMA user_version = 1")

    def _get_schema_version_raw(self, conn) -> int:
        """Get current schema version using existing connection."""
        try:
            cursor = conn.execute(
                "SELECT value FROM schema_info WHERE key = ?", ("schema_version",)
            )
            result = cursor.fetchone()
            return int(result["value"]) if result else 0
        except Exception:
            return 0

    def _migrate_to_v3(self, conn):
        """Migrate from v2 to v3: Add pi_type and context columns."""
        # Check if columns already exist (in case of partial migration)
        cursor = conn.execute("PRAGMA table_info(potential_improvements)")
        existing_columns = {row["name"] for row in cursor.fetchall()}

        if "pi_type" not in existing_columns:
            conn.execute(
                "ALTER TABLE potential_improvements ADD COLUMN pi_type TEXT DEFAULT 'improvement'"
            )
        if "context" not in existing_columns:
            conn.execute("ALTER TABLE potential_improvements ADD COLUMN context TEXT")

        # Create index if not exists
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_pi_type ON potential_improvements(pi_type)"
        )

    @contextmanager
    def connection(self):
        """
        Context manager for database connections.

        Delegates to the unified connection factory which handles WAL,
        timeout, foreign_keys, commit/rollback, and close.

        Yields:
            sqlite3.Connection with row_factory set to sqlite3.Row
        """
        with get_connection(self.db_path) as conn:
            yield conn

    def execute(self, sql: str, params: tuple = ()) -> list:
        """Execute SQL and return all results."""
        with self.connection() as conn:
            cursor = conn.execute(sql, params)
            return cursor.fetchall()

    def execute_one(self, sql: str, params: tuple = ()) -> sqlite3.Row | None:
        """Execute SQL and return first result."""
        with self.connection() as conn:
            cursor = conn.execute(sql, params)
            return cursor.fetchone()

    def execute_many(self, sql: str, params_list: list) -> int:
        """Execute SQL for multiple parameter sets, return rows affected."""
        with self.connection() as conn:
            cursor = conn.executemany(sql, params_list)
            return cursor.rowcount

    def get_schema_version(self) -> int:
        """Get current schema version."""
        result = self.execute_one(
            "SELECT value FROM schema_info WHERE key = ?", ("schema_version",)
        )
        return int(result["value"]) if result else 0

    def table_exists(self, table_name: str) -> bool:
        """Check if a table exists."""
        result = self.execute_one(
            "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
            (table_name,),
        )
        return result is not None

    def count(self, table_name: str, where: str = "", params: tuple = ()) -> int:
        """Count rows in a table with optional WHERE clause."""
        sql = f"SELECT COUNT(*) as cnt FROM {table_name}"
        if where:
            sql += f" WHERE {where}"
        result = self.execute_one(sql, params)
        return result["cnt"] if result else 0

    def reset(self):
        """Reset database (drop and recreate all tables). USE WITH CAUTION."""
        with self.connection() as conn:
            conn.executescript("""
                DROP TABLE IF EXISTS pi_implementations;
                DROP TABLE IF EXISTS pi_relationships;
                DROP TABLE IF EXISTS pi_evidence;
                DROP TABLE IF EXISTS potential_improvements;
                DROP TABLE IF EXISTS schema_info;
            """)
            conn.execute("PRAGMA user_version = 0")
        self._ensure_db_exists()
