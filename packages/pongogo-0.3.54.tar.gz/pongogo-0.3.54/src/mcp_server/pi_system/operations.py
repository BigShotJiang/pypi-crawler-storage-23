"""
PI System Operations - CRUD and management operations.
"""

from datetime import datetime
from pathlib import Path

from .database import PIDatabase
from .models import (
    ImplementationType,
    PIClassification,
    PIConfidence,
    PIEvidence,
    PIImplementation,
    PIRelationship,
    PIStatus,
    PIType,
    PotentialImprovement,
    RelationshipType,
)
from .queries import PIQueries


class PISystem:
    """
    Main interface for PI System operations.

    Provides CRUD operations, gardening queries, and file sync capabilities.
    """

    def __init__(self, db_path: Path | None = None):
        """
        Initialize PI System.

        Args:
            db_path: Path to SQLite database. Defaults to .pongogo/potential_improvements.db
        """
        self.db = PIDatabase(db_path)
        self.queries = PIQueries(self.db)

    # =========================================================================
    # PI CRUD Operations
    # =========================================================================

    def create_pi(
        self,
        pi_id: str,
        title: str,
        summary: str | None = None,
        status: PIStatus = PIStatus.CANDIDATE,
        confidence: PIConfidence = PIConfidence.LOW,
        classification: PIClassification | None = None,
        pi_type: PIType = PIType.IMPROVEMENT,
        context: str | None = None,
        cluster: str | None = None,
        source_task: str | None = None,
        file_path: str | None = None,
        identified_date: str | None = None,
    ) -> PotentialImprovement:
        """
        Create a new Potential Improvement or Candidate.

        Args:
            pi_id: Unique identifier (e.g., "PI-001")
            title: Short descriptive title
            summary: Brief summary of the improvement
            status: Initial status (default: CANDIDATE)
            confidence: Confidence level (default: LOW)
            classification: CORRECTIVE or EXPLORATORY
            pi_type: Type of candidate (improvement, glossary_candidate, faq_candidate)
            context: Optional context/category for the candidate
            cluster: Domain cluster name
            source_task: Task that identified this PI
            file_path: Path to detailed markdown file
            identified_date: Date identified (default: today)

        Returns:
            Created PotentialImprovement
        """
        now = datetime.now().strftime("%Y-%m-%d")
        pi = PotentialImprovement(
            id=pi_id,
            title=title,
            summary=summary,
            status=status,
            confidence=confidence,
            classification=classification,
            pi_type=pi_type,
            context=context,
            cluster=cluster,
            identified_date=identified_date or now,
            last_updated=now,
            source_task=source_task,
            file_path=file_path,
        )

        data = pi.to_dict()
        columns = ", ".join(data.keys())
        placeholders = ", ".join(["?" for _ in data])
        sql = f"INSERT INTO potential_improvements ({columns}) VALUES ({placeholders})"

        self.db.execute(sql, tuple(data.values()))
        return pi

    def update_pi(
        self,
        pi_id: str,
        title: str | None = None,
        summary: str | None = None,
        status: PIStatus | None = None,
        confidence: PIConfidence | None = None,
        classification: PIClassification | None = None,
        cluster: str | None = None,
        occurrence_count: int | None = None,
    ) -> PotentialImprovement | None:
        """
        Update an existing PI.

        Args:
            pi_id: PI to update
            **kwargs: Fields to update

        Returns:
            Updated PotentialImprovement or None if not found
        """
        updates = []
        params = []

        if title is not None:
            updates.append("title = ?")
            params.append(title)
        if summary is not None:
            updates.append("summary = ?")
            params.append(summary)
        if status is not None:
            updates.append("status = ?")
            params.append(status.value if isinstance(status, PIStatus) else status)
        if confidence is not None:
            updates.append("confidence = ?")
            params.append(
                confidence.value if isinstance(confidence, PIConfidence) else confidence
            )
        if classification is not None:
            updates.append("classification = ?")
            params.append(
                classification.value
                if isinstance(classification, PIClassification)
                else classification
            )
        if cluster is not None:
            updates.append("cluster = ?")
            params.append(cluster)
        if occurrence_count is not None:
            updates.append("occurrence_count = ?")
            params.append(occurrence_count)

        if not updates:
            return self.queries.get_by_id(pi_id)

        updates.append("last_updated = ?")
        params.append(datetime.now().strftime("%Y-%m-%d"))
        params.append(pi_id)

        sql = f"UPDATE potential_improvements SET {', '.join(updates)} WHERE id = ?"
        self.db.execute(sql, tuple(params))

        return self.queries.get_by_id(pi_id)

    def archive_pi(self, pi_id: str) -> bool:
        """Archive a PI (soft delete)."""
        self.db.execute(
            "UPDATE potential_improvements SET archived = 1, last_updated = ? WHERE id = ?",
            (datetime.now().strftime("%Y-%m-%d"), pi_id),
        )
        return True

    def delete_pi(self, pi_id: str) -> bool:
        """Permanently delete a PI and all related records."""
        self.db.execute("DELETE FROM potential_improvements WHERE id = ?", (pi_id,))
        return True

    # =========================================================================
    # Evidence Operations
    # =========================================================================

    def add_evidence(
        self,
        pi_id: str,
        source: str,
        description: str | None = None,
        date: str | None = None,
    ) -> PIEvidence:
        """
        Add evidence/occurrence to a PI.

        Also increments occurrence_count and may update confidence.

        Args:
            pi_id: PI to add evidence to
            source: Source of evidence (e.g., "Task #123", "RCA-2025-11-15")
            description: Description of the occurrence
            date: Date of occurrence (default: today)

        Returns:
            Created PIEvidence
        """
        evidence = PIEvidence(
            pi_id=pi_id,
            date=date or datetime.now().strftime("%Y-%m-%d"),
            source=source,
            description=description,
        )

        data = evidence.to_dict()
        columns = ", ".join(data.keys())
        placeholders = ", ".join(["?" for _ in data])
        sql = f"INSERT INTO pi_evidence ({columns}) VALUES ({placeholders})"
        self.db.execute(sql, tuple(data.values()))

        # Update occurrence count and potentially confidence
        pi = self.queries.get_by_id(pi_id)
        if pi:
            new_count = pi.occurrence_count + 1
            new_confidence = self._calculate_confidence(new_count)
            self.update_pi(pi_id, occurrence_count=new_count, confidence=new_confidence)

        return evidence

    def _calculate_confidence(self, occurrence_count: int) -> PIConfidence:
        """Calculate confidence level from occurrence count."""
        if occurrence_count >= 5:
            return PIConfidence.HIGH
        elif occurrence_count >= 3:
            return PIConfidence.MEDIUM
        return PIConfidence.LOW

    # =========================================================================
    # Relationship Operations
    # =========================================================================

    def add_relationship(
        self,
        pi_id_1: str,
        pi_id_2: str,
        relationship_type: RelationshipType,
        notes: str | None = None,
    ) -> PIRelationship:
        """
        Add a relationship between two PIs.

        Args:
            pi_id_1: First PI
            pi_id_2: Second PI
            relationship_type: Type of relationship
            notes: Additional notes

        Returns:
            Created PIRelationship
        """
        relationship = PIRelationship(
            pi_id_1=pi_id_1,
            pi_id_2=pi_id_2,
            relationship_type=relationship_type,
            notes=notes,
            discovered_date=datetime.now().strftime("%Y-%m-%d"),
        )

        data = relationship.to_dict()
        columns = ", ".join(data.keys())
        placeholders = ", ".join(["?" for _ in data])
        sql = f"INSERT OR REPLACE INTO pi_relationships ({columns}) VALUES ({placeholders})"
        self.db.execute(sql, tuple(data.values()))

        return relationship

    def remove_relationship(
        self,
        pi_id_1: str,
        pi_id_2: str,
        relationship_type: RelationshipType,
    ) -> bool:
        """Remove a relationship between two PIs."""
        self.db.execute(
            "DELETE FROM pi_relationships WHERE pi_id_1 = ? AND pi_id_2 = ? AND relationship_type = ?",
            (pi_id_1, pi_id_2, relationship_type.value),
        )
        return True

    # =========================================================================
    # Implementation Operations
    # =========================================================================

    def mark_implemented(
        self,
        pi_id: str,
        implementation_type: ImplementationType,
        location: str,
        notes: str | None = None,
    ) -> PIImplementation:
        """
        Mark a PI as implemented.

        Args:
            pi_id: PI to mark
            implementation_type: Type of implementation
            location: Where implemented (file path, wiki page, etc.)
            notes: Additional notes

        Returns:
            Created PIImplementation
        """
        impl = PIImplementation(
            pi_id=pi_id,
            implementation_date=datetime.now().strftime("%Y-%m-%d"),
            implementation_type=implementation_type,
            location=location,
            notes=notes,
        )

        data = impl.to_dict()
        columns = ", ".join(data.keys())
        placeholders = ", ".join(["?" for _ in data])
        sql = f"INSERT OR REPLACE INTO pi_implementations ({columns}) VALUES ({placeholders})"
        self.db.execute(sql, tuple(data.values()))

        # Update status
        self.update_pi(pi_id, status=PIStatus.IMPLEMENTED)

        return impl

    # =========================================================================
    # Note: No bulk operations by design
    # =========================================================================
    # Agent-first design principle: Agents should iterate through items
    # individually, making deliberate decisions for each. Bulk operations
    # bypass the careful consideration that foundational data requires.
    # See PI-064 (Active Enforcement Architecture) for rationale.

    # =========================================================================
    # Convenience Methods
    # =========================================================================

    def get_next_pi_id(self) -> str:
        """Get the next available PI ID."""
        row = self.db.execute_one("""
            SELECT id FROM potential_improvements
            ORDER BY CAST(SUBSTR(id, 4) AS INTEGER) DESC
            LIMIT 1
        """)
        if row:
            current_num = int(row["id"].split("-")[1])
            return f"PI-{current_num + 1:03d}"
        return "PI-001"

    def update_status(
        self,
        pi_id: str,
        new_status: PIStatus,
        new_confidence: PIConfidence | None = None,
    ) -> PotentialImprovement | None:
        """Convenience method to update status and optionally confidence."""
        return self.update_pi(pi_id, status=new_status, confidence=new_confidence)

    def classify(
        self,
        pi_id: str,
        classification: PIClassification,
        reason: str,
        model: str = "claude-opus-4-5-20251101",
    ) -> PotentialImprovement | None:
        """
        Classify a PI with reasoning.

        This is the primary method for classification - captures the reasoning
        and model information for auditability and future multi-model comparison.

        Args:
            pi_id: PI to classify
            classification: CORRECTIVE or EXPLORATORY
            reason: Why this classification was chosen (required for auditability)
            model: Which model made the classification

        Returns:
            Updated PotentialImprovement
        """
        now = datetime.now().strftime("%Y-%m-%d")
        classification_value = (
            classification.value
            if isinstance(classification, PIClassification)
            else classification
        )

        self.db.execute(
            """
            UPDATE potential_improvements
            SET classification = ?,
                classification_reason = ?,
                classification_model = ?,
                classification_date = ?,
                last_updated = ?
            WHERE id = ?
        """,
            (classification_value, reason, model, now, now, pi_id),
        )

        return self.queries.get_by_id(pi_id)

    def update_classification(
        self,
        pi_id: str,
        classification: PIClassification,
    ) -> PotentialImprovement | None:
        """
        DEPRECATED: Use classify() instead which captures reasoning.

        This method exists for backwards compatibility but should not be used
        for new classifications.
        """
        return self.update_pi(pi_id, classification=classification)

    # =========================================================================
    # Query Delegation
    # =========================================================================

    def get_all(self, include_archived: bool = False) -> list[PotentialImprovement]:
        """Get all PIs."""
        return self.queries.get_all(include_archived)

    def get_by_id(self, pi_id: str) -> PotentialImprovement | None:
        """Get a PI by ID."""
        return self.queries.get_by_id(pi_id)

    def find_stale(self, days: int = 90) -> list[PotentialImprovement]:
        """Find stale PIs."""
        return self.queries.find_stale(days)

    def find_duplicates(self) -> list[PIRelationship]:
        """Find duplicate relationships."""
        return self.queries.find_duplicates()

    def find_ready_for_implementation(self) -> list[PotentialImprovement]:
        """Find PIs ready for implementation."""
        return self.queries.find_ready_for_implementation()

    def find_unclassified(self) -> list[PotentialImprovement]:
        """Find unclassified PIs."""
        return self.queries.find_unclassified()

    def get_stats(self) -> dict:
        """Get statistics."""
        return self.queries.get_stats()

    def get_clusters(self) -> list[str]:
        """Get all clusters."""
        return self.queries.get_clusters()

    def get_relationships(self, pi_id: str) -> list[PIRelationship]:
        """Get relationships for a PI."""
        return self.queries.get_relationships(pi_id)

    def get_evidence(self, pi_id: str) -> list[PIEvidence]:
        """Get evidence for a PI."""
        return self.queries.get_evidence(pi_id)

    # =========================================================================
    # Candidate-Specific Methods (Task #330)
    # =========================================================================

    def create_glossary_candidate(
        self,
        term: str,
        context: str | None = None,
        source_task: str | None = None,
    ) -> PotentialImprovement:
        """
        Create a glossary candidate for a term that needs definition.

        Args:
            term: The term that needs a glossary entry
            context: Context where the term appears (e.g., "routing engine naming")
            source_task: Task where term was encountered

        Returns:
            Created glossary candidate
        """
        pi_id = self.get_next_pi_id()
        return self.create_pi(
            pi_id=pi_id,
            title=term,
            summary=f"Term needing definition: {term}",
            pi_type=PIType.GLOSSARY_CANDIDATE,
            context=context,
            source_task=source_task,
        )

    def create_faq_candidate(
        self,
        question: str,
        answer: str | None = None,
        context: str | None = None,
        source_task: str | None = None,
    ) -> PotentialImprovement:
        """
        Create an FAQ candidate for a question asked repeatedly.

        Args:
            question: The question that keeps coming up
            answer: Optional answer to include
            context: Context category (e.g., "authentication", "deployment")
            source_task: Task where question was encountered

        Returns:
            Created FAQ candidate
        """
        pi_id = self.get_next_pi_id()
        summary = question
        if answer:
            summary = f"Q: {question}\nA: {answer}"
        return self.create_pi(
            pi_id=pi_id,
            title=question,
            summary=summary,
            pi_type=PIType.FAQ_CANDIDATE,
            context=context,
            source_task=source_task,
        )

    def get_by_type(
        self, pi_type: PIType, include_archived: bool = False
    ) -> list[PotentialImprovement]:
        """
        Get all PIs of a specific type.

        Args:
            pi_type: Type to filter by
            include_archived: Include archived PIs

        Returns:
            List of PotentialImprovement matching type
        """
        where = "pi_type = ?"
        params = [pi_type.value if isinstance(pi_type, PIType) else pi_type]
        if not include_archived:
            where += " AND archived = 0"
        rows = self.db.execute(
            f"SELECT * FROM potential_improvements WHERE {where} ORDER BY identified_date DESC",
            tuple(params),
        )
        return [PotentialImprovement.from_row(row) for row in rows]

    def get_glossary_candidates(
        self, include_archived: bool = False
    ) -> list[PotentialImprovement]:
        """Get all glossary candidates."""
        return self.get_by_type(PIType.GLOSSARY_CANDIDATE, include_archived)

    def get_faq_candidates(
        self, include_archived: bool = False
    ) -> list[PotentialImprovement]:
        """Get all FAQ candidates."""
        return self.get_by_type(PIType.FAQ_CANDIDATE, include_archived)

    def get_improvements(
        self, include_archived: bool = False
    ) -> list[PotentialImprovement]:
        """Get all improvement PIs (original type)."""
        return self.get_by_type(PIType.IMPROVEMENT, include_archived)

    def get_user_guidance(
        self, include_archived: bool = False
    ) -> list[PotentialImprovement]:
        """Get all user guidance entries."""
        return self.get_by_type(PIType.USER_GUIDANCE, include_archived)

    # =========================================================================
    # User Guidance Methods (Issue #390)
    # =========================================================================

    def create_user_guidance(
        self,
        content: str,
        guidance_type: str,  # "explicit" | "implicit"
        context: str | None = None,
        source_task: str | None = None,
    ) -> PotentialImprovement:
        """
        Create a user guidance entry for automatic knowledge capture.

        Implements Issue #390: User guidance capture via PI system.
        Called automatically when user provides behavioral guidance.

        Args:
            content: The guidance/rule/feedback from user
            guidance_type: "explicit" for direct rules, "implicit" for soft feedback
            context: Optional context about when/why this was given
            source_task: Task where guidance was encountered

        Returns:
            Created user guidance PI
        """
        # Check for existing similar guidance to increment
        existing = self._find_similar_guidance(content)
        if existing:
            # Increment occurrence count
            self.add_evidence(
                existing.id,
                source=source_task or "user_session",
                description=f"Repeated guidance: {content[:100]}...",
            )
            updated = self.queries.get_by_id(existing.id)
            if updated is None:
                return existing  # Fallback: return the version we already have
            return updated

        # Create new guidance entry
        pi_id = self.get_next_pi_id()
        return self.create_pi(
            pi_id=pi_id,
            title=f"[{guidance_type.upper()}] {content[:80]}{'...' if len(content) > 80 else ''}",
            summary=content,
            pi_type=PIType.USER_GUIDANCE,
            context=context or guidance_type,
            source_task=source_task,
            classification=PIClassification.CORRECTIVE
            if guidance_type == "explicit"
            else PIClassification.EXPLORATORY,
        )

    def _find_similar_guidance(
        self, content: str, threshold: float = 0.8
    ) -> PotentialImprovement | None:
        """
        Find existing guidance that is similar to the given content.

        Uses simple word overlap for now; can be enhanced with embeddings later.

        Args:
            content: New guidance content
            threshold: Similarity threshold (0-1)

        Returns:
            Existing PI if similar, None otherwise
        """
        content_words = set(content.lower().split())
        for pi in self.get_user_guidance():
            if pi.summary:
                existing_words = set(pi.summary.lower().split())
                overlap = len(content_words & existing_words) / max(
                    len(content_words | existing_words), 1
                )
                if overlap >= threshold:
                    return pi
        return None

    def promote_guidance_to_instruction(
        self,
        pi_id: str,
        instruction_filename: str,
        category: str = "custom",
    ) -> dict:
        """
        Promote validated user guidance to an instruction file.

        Called when:
        - occurrence_count >= 3 (automatic threshold)
        - User explicitly confirms promotion

        Creates file in .pongogo/instructions/custom/ or knowledge/instructions/

        Args:
            pi_id: PI to promote
            instruction_filename: Name for the instruction file (without .md)
            category: Category subdirectory (default: "custom")

        Returns:
            Dictionary with created file path and PI status
        """
        pi = self.queries.get_by_id(pi_id)
        if not pi:
            return {"success": False, "error": f"PI {pi_id} not found"}

        if pi.pi_type != PIType.USER_GUIDANCE:
            return {"success": False, "error": f"PI {pi_id} is not user guidance"}

        # Determine instruction path
        # Use .pongogo/instructions for user-specific, knowledge/instructions for project-wide
        base_path = Path(".pongogo/instructions") / category
        base_path.mkdir(parents=True, exist_ok=True)

        filename = f"{instruction_filename}.instructions.md"
        file_path = base_path / filename

        # Guardrail: reject writes into seeded paths (Task #667, AC #8)
        # Files tracked in the seed manifest would be silently overwritten
        # on the next upgrade, so we block promotion into those paths.
        # Reads manifest directly (json+Path) to avoid deferred-import issues.
        manifest_key = f"instructions/{category}/{filename}"
        try:
            import json

            manifest_path = Path(".pongogo") / "seed_manifest.json"
            if manifest_path.exists():
                manifest = json.loads(manifest_path.read_text())
                if manifest_key in manifest.get("files", {}):
                    return {
                        "success": False,
                        "error": (
                            f"Cannot promote to '{manifest_key}': this path is managed "
                            f"by the Pongogo seed and would be overwritten on next upgrade. "
                            f"Use a different category (e.g., 'custom') instead."
                        ),
                    }
        except Exception:
            pass  # Fail-open: if manifest can't be read, allow the write

        # Generate instruction content
        content = self._generate_instruction_content(pi)
        file_path.write_text(content)

        # Mark as implemented
        self.mark_implemented(
            pi_id,
            implementation_type=ImplementationType.INSTRUCTION_FILE,
            location=str(file_path),
            notes="Promoted from user guidance",
        )

        return {
            "success": True,
            "file_path": str(file_path),
            "pi_id": pi_id,
            "status": "IMPLEMENTED",
        }

    def _generate_instruction_content(self, pi: PotentialImprovement) -> str:
        """Generate instruction file content from PI."""
        now = datetime.now().strftime("%Y-%m-%d")
        guidance_type = pi.context or "explicit"

        return f"""---
title: "{pi.title}"
description: "User guidance captured and promoted to instruction"
applies_to:
  - "**/*"
domains:
  - "user_guidance"
priority: "P2"
pongogo_version: "{now}"
source: "{pi.source_task or 'User guidance'}"
routing:
  priority: 2
  triggers:
    keywords: []
    nlp: "{pi.summary[:100] if pi.summary else ''}"
---

# {pi.title}

**Purpose**: {pi.summary or 'User-defined rule'}

**Origin**: Captured from user guidance ({guidance_type})
**Occurrences**: {pi.occurrence_count}
**Promoted**: {now}
**PI Reference**: {pi.id}

---

## Rule

{pi.summary}

---

## When to Apply

Apply this rule when the context matches the original guidance scenario.

---

**Note**: This instruction was automatically generated from user guidance.
"""

    def find_at_threshold(
        self, pi_type: PIType | None = None, threshold: int = 3
    ) -> list[PotentialImprovement]:
        """
        Find PIs at or above occurrence threshold.

        Args:
            pi_type: Optional type to filter by
            threshold: Minimum occurrence count (default: 3)

        Returns:
            List of PIs at threshold, ready for action
        """
        where = "occurrence_count >= ? AND archived = 0 AND status != 'IMPLEMENTED'"
        params = [threshold]
        if pi_type:
            where += " AND pi_type = ?"
            params.append(pi_type.value if isinstance(pi_type, PIType) else pi_type)
        rows = self.db.execute(
            f"SELECT * FROM potential_improvements WHERE {where} ORDER BY occurrence_count DESC",
            tuple(params),
        )
        return [PotentialImprovement.from_row(row) for row in rows]

    def get_stats_by_type(self) -> dict:
        """
        Get statistics broken down by PI type.

        Returns:
            Dictionary with stats per type
        """
        stats = {}
        for pi_type in PIType:
            rows = self.db.execute(
                """SELECT
                    COUNT(*) as total,
                    SUM(CASE WHEN occurrence_count >= 3 THEN 1 ELSE 0 END) as at_threshold,
                    SUM(CASE WHEN status = 'IMPLEMENTED' THEN 1 ELSE 0 END) as implemented
                FROM potential_improvements
                WHERE pi_type = ? AND archived = 0""",
                (pi_type.value,),
            )
            row = rows[0] if rows else None
            stats[pi_type.value] = {
                "total": row["total"] if row else 0,
                "at_threshold": row["at_threshold"] if row else 0,
                "implemented": row["implemented"] if row else 0,
            }
        return stats
