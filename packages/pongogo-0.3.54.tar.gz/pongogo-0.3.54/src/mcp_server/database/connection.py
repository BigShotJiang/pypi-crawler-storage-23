"""
Unified connection factory for all Pongogo SQLite databases.

Provides consistent connection configuration (WAL, timeout, foreign keys,
row_factory), automatic commit/rollback, retry with backoff for lock
contention, and atomic JSON state file writes.

Epic #638: Concurrent Session Scaling
Task #639: Wave 1 — Runtime Abstraction Layer
"""

import json
import os
import sqlite3
import tempfile
import time
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import TypeVar

T = TypeVar("T")


@contextmanager
def get_connection(
    db_path: Path | str,
    *,
    timeout: float = 10.0,
    readonly: bool = False,
) -> Iterator[sqlite3.Connection]:
    """Context manager for SQLite connections with consistent configuration.

    Configures WAL journal mode, foreign keys, row_factory, and handles
    commit/rollback/close lifecycle automatically.

    Args:
        db_path: Path to the SQLite database file.
        timeout: Connection timeout in seconds (default 10.0).
        readonly: If True, skip WAL mode and auto-commit.

    Yields:
        Configured sqlite3.Connection.
    """
    conn = sqlite3.connect(str(db_path), timeout=timeout)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    if not readonly:
        conn.execute("PRAGMA journal_mode = WAL")
    try:
        yield conn
        if not readonly:
            conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def execute_with_retry(
    db_path: Path | str,
    operation: Callable[[sqlite3.Connection], T],
    *,
    max_retries: int = 3,
    base_delay: float = 0.05,
) -> T:
    """Execute a database operation with retry on lock contention.

    Opens a new connection per attempt via get_connection(). On
    "database is locked" errors, retries with exponential backoff.

    Args:
        db_path: Path to the SQLite database file.
        operation: Callable taking a Connection, returning a value.
        max_retries: Maximum number of attempts (default 3).
        base_delay: Base delay in seconds for backoff (default 0.05).

    Returns:
        The return value of operation().

    Raises:
        sqlite3.OperationalError: After exhausting retries or on non-lock errors.
    """
    for attempt in range(max_retries):
        try:
            with get_connection(db_path) as conn:
                return operation(conn)
        except sqlite3.OperationalError as e:
            if "database is locked" in str(e) and attempt < max_retries - 1:
                time.sleep(base_delay * (2**attempt))
                continue
            raise
    # Unreachable: loop always returns or raises, but mypy needs this
    raise sqlite3.OperationalError("max retries exhausted")


def atomic_json_write(path: Path | str, data: dict, indent: int = 2) -> None:
    """Write JSON data to a file atomically via rename.

    Writes to a temporary file in the same directory, then atomically
    replaces the target. Prevents partial/corrupt reads on crash.

    Args:
        path: Target file path.
        data: Dictionary to serialize as JSON.
        indent: JSON indentation (default 2).
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        mode="w", dir=path.parent, delete=False, suffix=".json"
    ) as tmp:
        json.dump(data, tmp, indent=indent)
        tmp.write("\n")
        tmp_path = tmp.name
    os.replace(tmp_path, path)
