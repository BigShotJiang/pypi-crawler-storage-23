"""Execution context detection for branch-aware database operations.

Provides lightweight git branch detection for use by compliance hooks
and the registration layer. Prevents cross-branch compliance pollution
when multiple Claude Code sessions run on different branches.

Also provides worktree detection for shared database access across
linked git worktrees.

Task #640: Wave 2 — Execution Context Propagation
Task #641: Wave 3 — Platform Enablement
Epic #638: Concurrent Session Scaling
"""

import logging
import os
import subprocess
from pathlib import Path

logger = logging.getLogger(__name__)


def get_main_worktree_root(cwd: Path | str | None = None) -> Path | None:
    """Detect if running in a linked git worktree and return main worktree root.

    Uses `git rev-parse --git-common-dir`:
    - Returns ".git" in main worktree (relative)
    - Returns "/path/to/main/.git" in linked worktree (absolute)

    Args:
        cwd: Working directory for git command. Defaults to Path.cwd().

    Returns:
        Main worktree root path, or None if not in a linked worktree.
    """
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--git-common-dir"],
            capture_output=True,
            text=True,
            timeout=5,
            cwd=str(cwd or Path.cwd()),
        )
        if result.returncode != 0:
            return None

        git_common_dir = result.stdout.strip()
        # ".git" means we're in the main worktree (not a linked worktree)
        if git_common_dir == ".git":
            return None

        # Absolute path like "/path/to/main/.git" means linked worktree
        common_path = Path(git_common_dir)
        if common_path.is_absolute() and common_path.name == ".git":
            return common_path.parent

        return None
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return None


def get_data_root(cwd: Path | str | None = None) -> Path:
    """Get the root directory for shared Pongogo data (databases, logs).

    In linked worktrees: returns main worktree root (shared databases).
    In main worktree or non-worktree: returns project root (cwd or env var).

    This differs from get_project_root() which returns the LOCAL worktree
    root — used for instruction paths (each branch loads its own instructions).

    Args:
        cwd: Working directory context. Defaults to Path.cwd().

    Returns:
        Path to the data root directory.
    """
    # PONGOGO_PROJECT_ROOT env var takes precedence (Docker container)
    project_root = os.environ.get("PONGOGO_PROJECT_ROOT")
    if project_root:
        return Path(project_root)

    # Check if we're in a linked worktree
    main_root = get_main_worktree_root(cwd=cwd)
    if main_root is not None:
        return main_root

    # Default: use cwd (same as get_project_root behavior)
    return Path(cwd) if cwd else Path.cwd()


def get_current_branch(cwd: Path | str | None = None) -> str | None:
    """Detect the current git branch.

    Args:
        cwd: Working directory for git command. Defaults to Path.cwd().

    Returns:
        Branch name string, or None if not in a git repo or on detached HEAD.
    """
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True,
            text=True,
            timeout=5,
            cwd=str(cwd or Path.cwd()),
        )
        if result.returncode == 0:
            branch = result.stdout.strip()
            # "HEAD" means detached HEAD state
            return branch if branch != "HEAD" else None
        return None
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return None
