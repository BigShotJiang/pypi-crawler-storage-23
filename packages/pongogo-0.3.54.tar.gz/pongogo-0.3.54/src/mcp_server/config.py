"""
Pongogo Knowledge Server Configuration

Configuration loading with environment variable support and sensible defaults.
Implements Task #213: Add engine selection configuration support.

Environment Variables:
    PONGOGO_CONFIG_PATH: Path to config file (default: pongogo-config.yaml in server dir)
    PONGOGO_KNOWLEDGE_PATH: Override knowledge base path from config

Configuration Schema:
    routing:
        engine: str - Engine version (e.g., "durian-0.5")
        limit_default: int - Default routing limit (default: 5)
        features: dict - Feature flags for engine (e.g., {"violation_detection": True})
    knowledge:
        path: str - Path to knowledge/instructions directory
    server:
        log_level: str - Logging level (default: "INFO")
"""

import logging
import os
from pathlib import Path
from typing import Any

import yaml

logger = logging.getLogger(__name__)


class ConfigurationError(Exception):
    """Raised when configuration is invalid or cannot be loaded."""

    pass


# Default configuration values
DEFAULT_CONFIG: dict[str, Any] = {
    "routing": {
        "engine": None,  # Use registered default engine
        "limit_default": 5,
        "features": {},  # No feature overrides
    },
    "knowledge": {
        "path": None,  # Use default path relative to server
    },
    "server": {
        "log_level": "INFO",
    },
}


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    """
    Deep merge override dict into base dict.

    Args:
        base: Base dictionary (defaults)
        override: Override dictionary (user config)

    Returns:
        Merged dictionary with override values taking precedence
    """
    result = base.copy()
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def _resolve_path(path: str | None, base_dir: Path) -> Path | None:
    """
    Resolve a path, making relative paths absolute from base_dir.

    Args:
        path: Path string (absolute or relative) or None
        base_dir: Base directory for relative path resolution

    Returns:
        Resolved absolute Path or None if path was None
    """
    if path is None:
        return None

    path_obj = Path(path)
    if path_obj.is_absolute():
        return path_obj
    return (base_dir / path_obj).resolve()


def load_config(
    config_path: str | None = None, server_dir: Path | None = None
) -> dict[str, Any]:
    """
    Load configuration from YAML file with environment variable overrides.

    Configuration Loading Order (later overrides earlier):
    1. Default values (DEFAULT_CONFIG)
    2. Config file (from PONGOGO_CONFIG_PATH or config_path parameter)
    3. Environment variable overrides (PONGOGO_KNOWLEDGE_PATH)

    Args:
        config_path: Explicit config file path (overrides PONGOGO_CONFIG_PATH)
        server_dir: Server directory for relative path resolution

    Returns:
        Merged configuration dictionary

    Raises:
        ConfigurationError: If config file exists but is invalid YAML

    Examples:
        # Load with defaults (no config file required)
        config = load_config()

        # Load from specific file
        config = load_config("/path/to/pongogo-config.yaml")

        # Load with environment variable
        os.environ["PONGOGO_CONFIG_PATH"] = "/path/to/config.yaml"
        config = load_config()
    """
    # Determine server directory for path resolution
    if server_dir is None:
        server_dir = Path(__file__).parent

    # Start with defaults
    config = DEFAULT_CONFIG.copy()

    # Determine config file path
    file_path = config_path or os.environ.get("PONGOGO_CONFIG_PATH")

    if file_path:
        # Explicit config path - must exist and be valid
        resolved_path = _resolve_path(file_path, server_dir)
        if resolved_path and resolved_path.exists():
            try:
                with open(resolved_path) as f:
                    file_config = yaml.safe_load(f) or {}
                config = _deep_merge(config, file_config)
                logger.info(f"Loaded configuration from: {resolved_path}")
            except yaml.YAMLError as e:
                raise ConfigurationError(f"Invalid YAML in config file: {e}")
            except OSError as e:
                raise ConfigurationError(f"Cannot read config file: {e}")
        else:
            # Explicit path provided but file doesn't exist
            logger.warning(f"Config file not found (using defaults): {file_path}")
    else:
        # Check for default config file (optional)
        default_config_path = server_dir / "pongogo-config.yaml"
        if default_config_path.exists():
            try:
                with open(default_config_path) as f:
                    file_config = yaml.safe_load(f) or {}
                config = _deep_merge(config, file_config)
                logger.info(f"Loaded configuration from: {default_config_path}")
            except yaml.YAMLError as e:
                logger.warning(f"Invalid YAML in default config (ignoring): {e}")
            except OSError as e:
                logger.warning(f"Cannot read default config (ignoring): {e}")
        else:
            logger.debug("No config file found, using defaults")

    # Apply environment variable overrides
    knowledge_path_override = os.environ.get("PONGOGO_KNOWLEDGE_PATH")
    if knowledge_path_override:
        if "knowledge" not in config:
            config["knowledge"] = {}
        config["knowledge"]["path"] = knowledge_path_override
        logger.info(f"Knowledge path override from env: {knowledge_path_override}")

    # Resolve knowledge path
    if config.get("knowledge", {}).get("path"):
        resolved = _resolve_path(config["knowledge"]["path"], server_dir)
        config["knowledge"]["path"] = str(resolved) if resolved else None

    return config


def get_knowledge_path(config: dict[str, Any], server_dir: Path | None = None) -> Path:
    """
    Get knowledge base path from config or default.

    Resolution order:
    1. Config/env override (Docker sets PONGOGO_KNOWLEDGE_PATH)
    2. Project-local .pongogo/instructions (native mode — cwd is project root)
    3. Package default (development fallback)

    Args:
        config: Configuration dictionary from load_config()
        server_dir: Server directory for default path calculation

    Returns:
        Path to knowledge/instructions directory
    """
    if server_dir is None:
        server_dir = Path(__file__).parent

    # 1. Config/env override (Docker sets PONGOGO_KNOWLEDGE_PATH)
    path_str = config.get("knowledge", {}).get("path")
    if path_str:
        return Path(path_str)

    # 2. Project-local instructions (native mode — cwd is project root)
    project_root = get_project_root()
    local_path = project_root / ".pongogo" / "instructions"
    if local_path.exists():
        return local_path

    # 3. Package default (development fallback)
    return (server_dir.parent / "knowledge" / "instructions").resolve()


def get_routing_config(config: dict[str, Any]) -> dict[str, Any]:
    """
    Extract routing configuration for create_router() factory.

    Args:
        config: Configuration dictionary from load_config()

    Returns:
        Dictionary suitable for passing to create_router()
        Only includes 'engine' key if explicitly specified in config.
    """
    routing = config.get("routing", {})
    result = {
        "routing": {
            "features": routing.get("features", {}),
        }
    }
    # Only include engine if explicitly specified (not None)
    # This allows create_router() to use its registered default
    engine = routing.get("engine")
    if engine is not None:
        result["routing"]["engine"] = engine
    return result


def get_project_root() -> Path:
    """
    Get the project root directory where .pongogo/ is located.

    Resolution order:
    1. PONGOGO_KNOWLEDGE_PATH env var → parent.parent (.pongogo/instructions → project/)
    2. PONGOGO_PROJECT_ROOT env var (explicit override)
    3. Fallback to current working directory

    This is critical for containerized deployments where:
    - WORKDIR is /app (package location)
    - Volume mount is /project/.pongogo (user's config)
    - These are different paths!

    Returns:
        Path to project root (directory containing .pongogo/)
    """
    # Check explicit project root override
    explicit_root = os.environ.get("PONGOGO_PROJECT_ROOT")
    if explicit_root:
        return Path(explicit_root)

    # Derive from knowledge path (most common case)
    # Knowledge path is .pongogo/instructions, so parent.parent = project root
    knowledge_path = os.environ.get("PONGOGO_KNOWLEDGE_PATH")
    if knowledge_path:
        # /project/.pongogo/instructions → /project
        return Path(knowledge_path).parent.parent

    # Fallback to cwd (development mode)
    return Path.cwd()


def get_bundled_instructions_path() -> Path | None:
    """
    Get path to package-bundled instructions (seeded + core).

    Bundled instructions include:
    - _pongogo_core/ : Protected, always available
    - Other categories: Seeded defaults, can be overridden by user instructions

    Returns:
        Path to bundled instructions directory, or None if not found
    """
    # Check 1: Editable install / Docker mode
    # config.py at src/mcp_server/config.py → 3 levels up = project root → instructions/
    package_root = Path(__file__).parent.parent.parent
    bundled_path = package_root / "instructions"
    if bundled_path.exists():
        logger.debug(f"Bundled instructions path (editable): {bundled_path}")
        return bundled_path

    # Check 2: Wheel install mode (pip, Homebrew)
    # config.py at site-packages/mcp_server/config.py
    # Instructions at site-packages/cli/data/instructions/ (from wheel force-include)
    site_packages = Path(__file__).parent.parent
    bundled_path = site_packages / "cli" / "data" / "instructions"
    if bundled_path.exists():
        logger.debug(f"Bundled instructions path (wheel): {bundled_path}")
        return bundled_path

    logger.warning(
        f"Bundled instructions path not found: "
        f"tried {package_root / 'instructions'} and {site_packages / 'cli' / 'data' / 'instructions'}"
    )
    return None


# Alias for backward compatibility
def get_core_instructions_path() -> Path | None:
    """Deprecated: Use get_bundled_instructions_path() instead."""
    return get_bundled_instructions_path()
