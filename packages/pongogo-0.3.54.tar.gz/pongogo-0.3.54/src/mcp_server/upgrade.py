"""Pongogo upgrade functionality.

Provides upgrade instructions and version checking for Docker installations.
Used by the upgrade_pongogo and check_for_updates MCP tools.

Note: The MCP server runs INSIDE a Docker container, so it cannot execute
docker commands. Instead, we return instructions for the user to run on
their host machine.
"""

import json
import logging
import os
import re
import shutil
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from enum import Enum
from pathlib import Path

logger = logging.getLogger(__name__)


def get_display_version() -> str:
    """Get version string for display in clean format.

    Uses PONGOGO_IMAGE env var to detect channel, formats version
    in user-friendly format.

    Example outputs:
    - "v0.2.0-build.93 (beta)" (beta channel)
    - "v0.2.0-build.93 (alpha)" (alpha channel)
    - "v0.2.0" (stable release - clean, no channel suffix)
    - "0.1.0-dev" (local development)
    """
    version = get_current_version()

    # Dev version - show as-is
    if version == "0.1.0-dev":
        return version

    # Stable version: pure semver (no pre-release suffix) - show clean version only
    if re.match(r"^\d+\.\d+\.\d+$", version):
        return f"v{version}"

    # Pre-release: show build number and channel
    match = re.match(r"^v?(\d+\.\d+\.\d+)-(?:alpha|beta)\.(\d+)$", version)
    if match:
        base_version = match.group(1)
        build_number = match.group(2)
        channel = _get_channel()
        return f"v{base_version}-build.{build_number} ({channel})"

    # Fallback for unexpected formats
    return version


def _get_channel() -> str:
    """Detect release channel from PONGOGO_IMAGE env var.

    Returns:
        Channel name: 'alpha', 'beta', 'stable', or 'dev'
    """
    image = os.environ.get("PONGOGO_IMAGE", "")
    version = os.environ.get("PONGOGO_VERSION", "")

    if ":beta" in image:
        return "beta"
    elif ":stable" in image:
        return "stable"
    elif ":alpha" in image or "-alpha." in version:
        return "alpha"
    elif version == "0.1.0-dev":
        return "dev"
    else:
        return "stable"  # Assume stable for version-only releases


# Cache for version check results (1 hour TTL)
_version_cache: dict = {"latest": None, "timestamp": 0}
VERSION_CACHE_TTL = 3600  # 1 hour in seconds

# GitHub releases API endpoint
GITHUB_RELEASES_URL = "https://api.github.com/repos/pongogo/pongogo/releases/latest"


class InstallMethod(Enum):
    """Installation method for Pongogo."""

    DOCKER = "docker"
    PIP = "pip"
    HOMEBREW = "homebrew"
    UNKNOWN = "unknown"


@dataclass
class UpgradeResult:
    """Result of an upgrade operation."""

    success: bool
    method: InstallMethod
    message: str
    current_version: str | None = None
    upgrade_command: str | None = None


@dataclass
class VersionCheckResult:
    """Result of a version check operation."""

    current_version: str
    latest_version: str | None
    update_available: bool
    check_failed: bool = False
    error_message: str | None = None
    upgrade_command: str | None = None


def detect_install_method() -> InstallMethod:
    """Detect how Pongogo was installed.

    Detection order:
    1. Docker container markers (/.dockerenv, /proc/1/cgroup)
    2. Homebrew (executable path contains Cellar or homebrew)
    3. pip (default for non-Docker, non-Homebrew)

    Returns:
        InstallMethod indicating docker, homebrew, or pip.
    """

    # Check for Docker container markers
    if Path("/.dockerenv").exists():
        return InstallMethod.DOCKER

    try:
        with open("/proc/1/cgroup") as f:
            if "docker" in f.read():
                return InstallMethod.DOCKER
    except (FileNotFoundError, PermissionError):
        pass

    # Check for Homebrew install (executable in Cellar or homebrew prefix)
    pongogo_path = shutil.which("pongogo")
    if pongogo_path and ("Cellar" in pongogo_path or "homebrew" in pongogo_path):
        return InstallMethod.HOMEBREW

    # Default: pip install
    return InstallMethod.PIP


def get_current_version() -> str:
    """Get currently installed Pongogo version.

    Version detection order:
    1. PONGOGO_VERSION environment variable (set in Docker images)
    2. Package metadata via importlib.metadata (pip installs)

    Returns:
        Version string (e.g., "0.3.25", "vbeta-20260102-abc123")
    """
    # Docker images set PONGOGO_VERSION during build
    env_version = os.environ.get("PONGOGO_VERSION")
    if env_version:
        return env_version

    try:
        from importlib.metadata import version

        return version("pongogo")
    except Exception:
        return "unknown"


def _get_docker_image_tag() -> str:
    """Get the Docker image tag for the current installation.

    Detects channel from PONGOGO_IMAGE env var, falling back to stable.

    Returns:
        Full docker image reference (e.g., "pongogo.azurecr.io/pongogo:beta")
    """
    # PONGOGO_IMAGE is set by the wrapper script to indicate channel
    image = os.environ.get("PONGOGO_IMAGE", "")

    if image:
        # Use the exact image from env var
        return image

    # Fallback to stable if not set
    return "pongogo.azurecr.io/pongogo:stable"


def upgrade() -> UpgradeResult:
    """Get upgrade instructions for Pongogo.

    Since the MCP server runs inside a Docker container, we cannot execute
    docker commands from within. Instead, we return instructions for the
    user to run on their host machine.

    Returns:
        UpgradeResult with instructions for upgrading.
    """
    current = get_current_version()
    method = detect_install_method()

    if method == InstallMethod.DOCKER:
        # Inside Docker - provide instructions for host
        # Use current channel (beta/stable) from PONGOGO_IMAGE
        image = _get_docker_image_tag()
        return UpgradeResult(
            success=True,
            method=InstallMethod.DOCKER,
            message=(
                "To upgrade Pongogo, run in your terminal:\n\n"
                f"  docker pull {image}\n\n"
                "Then restart Claude Code to use the new version."
            ),
            current_version=current,
            upgrade_command=f"docker pull {image}",
        )
    elif method == InstallMethod.HOMEBREW:
        return UpgradeResult(
            success=True,
            method=InstallMethod.HOMEBREW,
            message=(
                "To upgrade Pongogo, run:\n\n"
                "  brew upgrade pongogo\n\n"
                "Then restart Claude Code to use the new version."
            ),
            current_version=current,
            upgrade_command="brew upgrade pongogo",
        )
    elif method == InstallMethod.PIP:
        return UpgradeResult(
            success=True,
            method=InstallMethod.PIP,
            message=(
                "To upgrade Pongogo, run:\n\n"
                "  pip install --upgrade pongogo\n\n"
                "Then restart Claude Code to use the new version."
            ),
            current_version=current,
            upgrade_command="pip install --upgrade pongogo",
        )
    else:
        return UpgradeResult(
            success=False,
            method=InstallMethod.UNKNOWN,
            message="Could not detect installation method",
            current_version=current,
        )


def _normalize_version(version: str) -> str:
    """Normalize version string for comparison.

    Handles formats like:
    - "0.1.17"
    - "v0.1.17"
    - "vbeta-20260102-abc123"

    Returns:
        Normalized version string (strips leading 'v').
    """
    if version.startswith("v"):
        return version[1:]
    return version


def _parse_semver(version: str) -> tuple[int, int, int] | None:
    """Parse semantic version string into tuple.

    Args:
        version: Version string like "0.1.17" or "1.2.3"

    Returns:
        Tuple of (major, minor, patch) or None if not semver.
    """
    normalized = _normalize_version(version)
    match = re.match(r"^(\d+)\.(\d+)\.(\d+)", normalized)
    if match:
        return int(match.group(1)), int(match.group(2)), int(match.group(3))
    return None


def _is_newer_version(current: str, latest: str) -> bool:
    """Check if latest version is newer than current.

    Args:
        current: Current version string
        latest: Latest version string

    Returns:
        True if latest is newer than current.
    """
    current_parts = _parse_semver(current)
    latest_parts = _parse_semver(latest)

    if current_parts is None or latest_parts is None:
        # Can't compare non-semver versions, assume no update
        return False

    return latest_parts > current_parts


def fetch_latest_version() -> str | None:
    """Fetch latest version from GitHub releases API.

    Uses caching to avoid rate limiting (1 hour TTL).

    Returns:
        Latest version string or None if fetch failed.
    """
    global _version_cache

    # Check cache
    now = time.time()
    if (
        _version_cache["latest"]
        and (now - _version_cache["timestamp"]) < VERSION_CACHE_TTL
    ):
        logger.debug("Using cached version info")
        return _version_cache["latest"]

    try:
        request = urllib.request.Request(
            GITHUB_RELEASES_URL,
            headers={
                "Accept": "application/vnd.github.v3+json",
                "User-Agent": "pongogo-server",
            },
        )

        with urllib.request.urlopen(request, timeout=5) as response:
            data = json.loads(response.read().decode("utf-8"))
            tag_name = data.get("tag_name")

            if tag_name:
                # Update cache
                _version_cache["latest"] = tag_name
                _version_cache["timestamp"] = now
                logger.debug(f"Fetched latest version: {tag_name}")
                return tag_name

    except urllib.error.URLError as e:
        logger.debug(f"Failed to fetch latest version (network): {e}")
    except json.JSONDecodeError as e:
        logger.debug(f"Failed to parse releases response: {e}")
    except Exception as e:
        logger.debug(f"Unexpected error fetching version: {e}")

    return None


def _is_beta_channel() -> bool:
    """Check if running on beta channel.

    Beta channel is detected by:
    - PONGOGO_IMAGE containing ":beta"
    - PONGOGO_VERSION starting with "vbeta-" or "beta"
    """
    image = os.environ.get("PONGOGO_IMAGE", "")
    version = os.environ.get("PONGOGO_VERSION", "")

    return ":beta" in image or version.startswith("vbeta-") or version == "beta"


def _is_alpha_channel() -> bool:
    """Check if running on alpha channel.

    Alpha channel is detected by:
    - PONGOGO_IMAGE containing ":alpha"
    - PONGOGO_VERSION containing "-alpha." (e.g., "0.2.0-alpha.33")
    """
    image = os.environ.get("PONGOGO_IMAGE", "")
    version = os.environ.get("PONGOGO_VERSION", "")

    return ":alpha" in image or "-alpha." in version


def check_for_updates() -> VersionCheckResult:
    """Check if a newer version of Pongogo is available.

    For stable channel: Fetches current version and compares against latest
    GitHub release. Uses caching to avoid rate limiting.

    For beta channel: Returns guidance that beta updates via `pongogo upgrade`
    (Docker digest comparison), since beta builds don't have GitHub releases.

    Returns:
        VersionCheckResult with version comparison info.
    """
    current = get_current_version()
    method = detect_install_method()

    # Determine upgrade command based on install method
    # Use channel-aware image for Docker
    if method == InstallMethod.DOCKER:
        image = _get_docker_image_tag()
        upgrade_cmd = f"docker pull {image}"
    elif method == InstallMethod.HOMEBREW:
        upgrade_cmd = "brew upgrade pongogo"
    elif method == InstallMethod.PIP:
        upgrade_cmd = "pip install --upgrade pongogo"
    else:
        upgrade_cmd = None

    # Beta channel doesn't have GitHub releases - guide user to docker pull
    if _is_beta_channel():
        return VersionCheckResult(
            current_version=current,
            latest_version="(beta channel - no version check)",
            update_available=False,
            check_failed=False,
            error_message=None,
            upgrade_command=upgrade_cmd,
        )

    # Alpha channel - same approach, updates come via docker pull
    if _is_alpha_channel():
        return VersionCheckResult(
            current_version=current,
            latest_version="(alpha channel - no version check)",
            update_available=False,
            check_failed=False,
            error_message=None,
            upgrade_command=upgrade_cmd,
        )

    # Fetch latest version from GitHub releases (stable only)
    latest = fetch_latest_version()

    if latest is None:
        return VersionCheckResult(
            current_version=current,
            latest_version=None,
            update_available=False,
            check_failed=True,
            error_message="Could not fetch latest version (offline or rate limited)",
            upgrade_command=upgrade_cmd,
        )

    update_available = _is_newer_version(current, latest)

    return VersionCheckResult(
        current_version=current,
        latest_version=latest,
        update_available=update_available,
        check_failed=False,
        upgrade_command=upgrade_cmd if update_available else None,
    )
