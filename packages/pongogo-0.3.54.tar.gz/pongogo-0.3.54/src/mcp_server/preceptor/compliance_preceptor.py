"""
Compliance preceptor — bridges routing results to compliance tracking.

THE missing glue layer:
    Router.route() → procedural_warning with instruction IDs + content
        ↓
    Preceptor.process_routing_result() → parses COMPLIANCE GATE blocks
        → registers ComplianceRule objects as guidance_fulfillment rows
        ↓
    PostToolUse hook queries guidance_fulfillment → FINDS REQUIREMENTS
        ↓
    Stop hook audits → carries unfulfilled forward

Platform-agnostic: no Claude Code or hook-specific imports.

Epic #545: Hook-Based Compliance Enforcement
"""

import logging
from dataclasses import dataclass, field
from pathlib import Path

from ..compliance.models import ComplianceSpec
from ..compliance.spec_engine import ComplianceSpecEngine
from .registration import ComplianceRegistrar

logger = logging.getLogger(__name__)


@dataclass
class ComplianceContext:
    """Result of preceptor processing a routing result."""

    registered_count: int = 0
    specs: list[ComplianceSpec] = field(default_factory=list)
    had_procedural: bool = False
    registration_ids: list[int] = field(default_factory=list)
    enforcement_suppressed: bool = False


class CompliancePreceptor:
    """Bridge routing results to compliance tracking.

    For each procedural instruction in a routing result:
    1. Find instruction content from routing_result['instructions']
    2. Parse through ComplianceSpecEngine
    3. Register resulting rules via ComplianceRegistrar
    """

    def __init__(self, db_path: Path):
        self._spec_engine = ComplianceSpecEngine()
        self._registrar = ComplianceRegistrar(db_path)

    def process_routing_result(
        self,
        routing_result: dict,
        session_id: str,
        routing_event_id: int | None = None,
        execution_context: str | None = None,
        branch: str | None = None,
    ) -> ComplianceContext:
        """Process a routing result and register any compliance requirements.

        Args:
            routing_result: Full dict returned by router.route().
            session_id: Session identifier for scoping requirements.
            routing_event_id: Optional routing_events.id for FK linkage.
            execution_context: Agent execution context (e.g. "plan" for plan mode).
                When "plan", specs are parsed but enforcement registration is skipped.
            branch: Git branch name for cross-branch isolation (Task #640).

        Returns:
            ComplianceContext with registration results.
        """
        procedural_warning = routing_result.get("procedural_warning")
        if not procedural_warning:
            return ComplianceContext()

        instructions_list = routing_result.get("instructions", [])
        # Build lookups: instruction id → content, instruction id → metadata
        content_by_id = {
            inst.get("id", ""): inst.get("content", "") for inst in instructions_list
        }
        metadata_by_id = {
            inst.get("id", ""): inst.get("metadata", {}) for inst in instructions_list
        }

        all_specs: list[ComplianceSpec] = []
        all_ids: list[int] = []

        for proc_inst in procedural_warning.get("instructions", []):
            inst_id = proc_inst.get("id", "")
            detection_method = proc_inst.get("detection_method", "")
            referenced_doc = proc_inst.get("referenced_doc")

            content = content_by_id.get(inst_id, "")
            metadata = metadata_by_id.get(inst_id, {})

            procedural_info = {
                "is_procedural": True,
                "detection_method": detection_method,
                "referenced_doc": referenced_doc,
            }

            spec = self._spec_engine.parse_from_routing_result(
                instruction_id=inst_id,
                content=content,
                procedural_info=procedural_info,
                metadata=metadata,
            )

            if spec.has_rules:
                all_specs.append(spec)
                if execution_context == "plan":
                    logger.info(
                        f"ENFORCEMENT_SUPPRESSED: plan mode, skipping registration "
                        f"for {inst_id} ({len(spec.rules)} rules)"
                    )
                else:
                    ids = self._registrar.register_requirements(
                        spec=spec,
                        session_id=session_id,
                        routing_event_id=routing_event_id,
                        branch=branch,
                    )
                    all_ids.extend(ids)

        return ComplianceContext(
            registered_count=len(all_ids),
            specs=all_specs,
            had_procedural=True,
            registration_ids=all_ids,
            enforcement_suppressed=(execution_context == "plan"),
        )
