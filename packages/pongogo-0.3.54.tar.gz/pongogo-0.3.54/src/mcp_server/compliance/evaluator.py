"""
Compliance evaluator for matching tool calls against requirements.

Evaluates whether a given tool call satisfies a pending compliance
requirement.

Platform-agnostic: no Claude Code or hook-specific imports.

Epic #545: Hook-Based Compliance Enforcement
"""

import logging
from pathlib import PurePosixPath

from .models import ComplianceRule, FulfillmentResult, RuleType

logger = logging.getLogger(__name__)


class ComplianceEvaluator:
    """Evaluate tool calls against compliance requirements.

    Usage:
        evaluator = ComplianceEvaluator()
        result = evaluator.evaluate(
            tool_name="Read",
            tool_input={"file_path": "/path/to/checklist.md"},
            rule=some_compliance_rule,
        )
        if result.fulfilled:
            print("Requirement satisfied!")
    """

    def evaluate(
        self,
        tool_name: str,
        tool_input: dict,
        rule: ComplianceRule,
        tool_output: str | None = None,
    ) -> FulfillmentResult:
        """Evaluate a tool call against a compliance requirement.

        Args:
            tool_name: Name of the tool that was called (e.g., "Read", "Bash")
            tool_input: Input parameters passed to the tool
            rule: The compliance rule to evaluate against
            tool_output: Optional output from the tool call

        Returns:
            FulfillmentResult indicating if the requirement is fulfilled
        """
        if rule.rule_type == RuleType.READ_FILE:
            return self._evaluate_read_file(tool_name, tool_input, rule)
        elif rule.rule_type == RuleType.READ_INSTRUCTION:
            return self._evaluate_read_instruction(tool_name, tool_input, rule)
        elif rule.rule_type == RuleType.PROCESS_CHECKLIST:
            return self._evaluate_read_file(tool_name, tool_input, rule)
        elif rule.rule_type == RuleType.STEP_CITATION:
            # Step citation is verified by response content, not tool calls
            return FulfillmentResult(
                fulfilled=False, reason="Step citation requires response analysis"
            )
        elif rule.rule_type == RuleType.APPROVAL_REQUIRED:
            return FulfillmentResult(
                fulfilled=False, reason="Approval not yet verified"
            )
        elif rule.rule_type == RuleType.CALL_MCP_TOOL:
            return self._evaluate_mcp_tool_call(tool_name, tool_input, rule)

        return FulfillmentResult(
            fulfilled=False, reason=f"Unknown rule type: {rule.rule_type}"
        )

    def _evaluate_read_file(
        self, tool_name: str, tool_input: dict, rule: ComplianceRule
    ) -> FulfillmentResult:
        """Evaluate if a tool call satisfies a READ_FILE requirement."""
        if tool_name != "Read":
            return FulfillmentResult(fulfilled=False, reason="Not a Read tool call")

        file_path = tool_input.get("file_path", "")
        if not file_path:
            return FulfillmentResult(
                fulfilled=False, reason="No file_path in tool input"
            )

        if not rule.referenced_file:
            return FulfillmentResult(
                fulfilled=False, reason="Rule has no referenced file"
            )

        if self._paths_match(file_path, rule.referenced_file):
            return FulfillmentResult(
                fulfilled=True,
                reason=f"Read tool call on {file_path} satisfies requirement",
            )

        return FulfillmentResult(
            fulfilled=False,
            reason=f"Read target {file_path} does not match required {rule.referenced_file}",
        )

    def _evaluate_read_instruction(
        self, tool_name: str, tool_input: dict, rule: ComplianceRule
    ) -> FulfillmentResult:
        """Evaluate if a tool call satisfies a READ_INSTRUCTION requirement."""
        if tool_name != "Read":
            return FulfillmentResult(fulfilled=False, reason="Not a Read tool call")

        file_path = tool_input.get("file_path", "")
        if not file_path:
            return FulfillmentResult(
                fulfilled=False, reason="No file_path in tool input"
            )

        # The instruction ID format is "category/name" (e.g., "project_management/issue_closure")
        # The file would be at .pongogo/instructions/category/name.instructions.md
        instruction_id = rule.source_instruction_id

        # Check if the read file matches the instruction file
        if self._is_instruction_file_read(file_path, instruction_id):
            return FulfillmentResult(
                fulfilled=True,
                reason="Read tool call on instruction file satisfies requirement",
            )

        return FulfillmentResult(
            fulfilled=False,
            partial=True,
            reason=f"Read target {file_path} does not match instruction {instruction_id}",
        )

    def _paths_match(self, actual_path: str, required_path: str) -> bool:
        """Check if two file paths refer to the same file.

        Handles absolute vs relative paths by comparing suffixes.
        """
        actual = PurePosixPath(actual_path)
        required = PurePosixPath(required_path)

        # Exact match
        if str(actual) == str(required):
            return True

        # Check if one is a suffix of the other (handles absolute vs relative)
        actual_parts = actual.parts
        required_parts = required.parts

        # Required path is typically relative, actual is absolute
        if len(required_parts) <= len(actual_parts):
            return actual_parts[-len(required_parts) :] == required_parts

        return False

    def _evaluate_mcp_tool_call(
        self, tool_name: str, tool_input: dict, rule: ComplianceRule
    ) -> FulfillmentResult:
        """Evaluate if a tool call satisfies a CALL_MCP_TOOL requirement."""
        if not rule.required_tool:
            return FulfillmentResult(
                fulfilled=False, reason="Rule has no required_tool"
            )

        # Match if tool_name equals or contains the required tool name
        # e.g., "log_user_guidance" matches "mcp__pongogo-knowledge__log_user_guidance"
        tool_matched = (
            tool_name == rule.required_tool or rule.required_tool in tool_name
        )

        if not tool_matched:
            return FulfillmentResult(
                fulfilled=False,
                reason=f"Tool {tool_name} does not match required {rule.required_tool}",
            )

        # Validate required arguments if specified
        if rule.required_args:
            for key, value in rule.required_args.items():
                actual = tool_input.get(key)
                if actual != value:
                    return FulfillmentResult(
                        fulfilled=False,
                        partial=True,
                        reason=f"Required arg {key}={value} not matched (got {actual})",
                    )

        return FulfillmentResult(
            fulfilled=True,
            reason=f"MCP tool call {tool_name} satisfies {rule.required_tool} requirement",
        )

    def _is_instruction_file_read(self, file_path: str, instruction_id: str) -> bool:
        """Check if a file path corresponds to reading the instruction file."""
        # instruction_id is like "project_management/issue_closure"
        # file path would end with .pongogo/instructions/project_management/issue_closure.instructions.md
        expected_suffix = f".pongogo/instructions/{instruction_id}.instructions.md"
        return file_path.endswith(expected_suffix) or expected_suffix in file_path
