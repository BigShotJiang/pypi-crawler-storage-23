"""
Platform-agnostic compliance enforcement for procedural instructions.

This module provides the core compliance logic that is independent of any
specific platform (Claude Code, VS Code, CLI, etc.). It parses procedural
instructions into declarative compliance rules and evaluates tool calls
against pending requirements.

Epic #545: Hook-Based Compliance Enforcement

Architecture:
    spec_engine.py  - Parse COMPLIANCE GATE blocks into ComplianceRule objects
    evaluator.py    - Evaluate tool calls against compliance requirements
    models.py       - Data models for compliance rules and fulfillment state
"""

from .evaluator import ComplianceEvaluator
from .models import (
    ComplianceRule,
    ComplianceSpec,
    FulfillmentResult,
    RuleType,
)
from .spec_engine import ComplianceSpecEngine

__all__ = [
    "ComplianceEvaluator",
    "ComplianceRule",
    "ComplianceSpec",
    "ComplianceSpecEngine",
    "FulfillmentResult",
    "RuleType",
]
