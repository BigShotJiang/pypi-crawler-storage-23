"""Shared structured logging utilities for Pongogo hooks.

Provides JSONL (JSON Lines) logging alongside traditional text logging.
JSONL enables machine-parseable analysis of hook behavior; text logs
remain as a diagnostic failsafe for grep/tail workflows.

Task #641: Wave 3 — Platform Enablement
Epic #638: Concurrent Session Scaling
"""

import json
import logging
import sys
import traceback
from datetime import UTC, datetime
from pathlib import Path


class JSONLHandler(logging.Handler):
    """Logging handler that writes one JSON object per line.

    Each line contains: ts, level, hook, session_id, branch, msg,
    and optionally exc_info for exceptions.
    """

    def __init__(
        self,
        filepath: Path,
        hook_name: str,
        session_id: str = "",
        branch: str = "",
    ):
        super().__init__()
        self.filepath = Path(filepath)
        self.hook_name = hook_name
        self.session_id = session_id
        self.branch = branch

    def emit(self, record: logging.LogRecord) -> None:
        try:
            entry = {
                "ts": datetime.now(UTC).isoformat(),
                "level": record.levelname,
                "hook": self.hook_name,
                "session_id": self.session_id,
                "branch": self.branch,
                "msg": self.format(record),
            }

            if record.exc_info and record.exc_info[1] is not None:
                entry["exc_info"] = traceback.format_exception(*record.exc_info)

            with open(self.filepath, "a") as f:
                f.write(json.dumps(entry) + "\n")
        except Exception:
            # Never let logging crash a hook
            pass


def setup_dual_logging(
    log_dir: Path,
    hook_name: str,
    session_id: str = "",
    branch: str = "",
) -> Path:
    """Configure both text (.log) and structured (.jsonl) handlers.

    Sets up logging with:
    - Text handler: traditional log file for grep/tail diagnostics
    - JSONL handler: structured log for machine parsing and analysis

    Args:
        log_dir: Directory for log files (created if missing)
        hook_name: Hook identifier used in filenames and JSONL entries
        session_id: Session ID for JSONL correlation
        branch: Git branch name for JSONL correlation

    Returns:
        Path to the log directory (after ensuring it exists)
    """
    try:
        log_dir.mkdir(parents=True, exist_ok=True)
    except (PermissionError, OSError):
        # Fall back to /tmp if primary location fails
        log_dir = Path("/tmp/pongogo-logs")
        try:
            log_dir.mkdir(parents=True, exist_ok=True)
        except (PermissionError, OSError):
            # Last resort: stderr only
            logging.basicConfig(
                stream=sys.stderr,
                level=logging.WARNING,
                format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
            )
            return log_dir

    # Text log handler
    text_file = log_dir / f"{hook_name}.log"
    text_handler = logging.FileHandler(text_file)
    text_handler.setLevel(logging.INFO)
    text_handler.setFormatter(
        logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s")
    )

    # JSONL handler
    jsonl_file = log_dir / f"{hook_name}.jsonl"
    jsonl_handler = JSONLHandler(
        filepath=jsonl_file,
        hook_name=hook_name,
        session_id=session_id,
        branch=branch,
    )
    jsonl_handler.setLevel(logging.INFO)

    # Configure root logger (hooks use logging.getLogger(__name__))
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.DEBUG)
    root_logger.addHandler(text_handler)
    root_logger.addHandler(jsonl_handler)

    return log_dir
