"""
Claude Code Hooks for Pongogo Routing

This module contains Claude Code hooks that integrate with the Pongogo routing system:

- claude_code_adapter.py: UserPromptSubmit hook that routes every message through
  Pongogo and injects context into Claude conversations.

- stop_response_capture_hook.py: Stop hook that captures agent responses and
  correlates them with routing events for evaluation and learning.

- posttooluse_compliance_hook.py: PostToolUse hook that tracks compliance
  requirement fulfillment after each tool call (Epic #545).

- pretooluse_compliance_hook.py: PreToolUse hook that BLOCKS tool execution when
  pending compliance requirements exist. This is the enforcement layer that
  "traps" the LLM until compliance is demonstrated (Epic #545).

These hooks are configured in ~/.claude/settings.json and run automatically
on every Claude Code interaction.

Configuration:
    {
      "hooks": {
        "UserPromptSubmit": [{
          "hooks": [{"type": "command", "command": "/path/to/claude_code_adapter.py"}]
        }],
        "Stop": [{
          "hooks": [{"type": "command", "command": "/path/to/stop_response_capture_hook.py"}]
        }],
        "PostToolUse": [{
          "matcher": "Read",
          "hooks": [{"type": "command", "command": "/path/to/posttooluse_compliance_hook.py"}]
        }],
        "PreToolUse": [{
          "matcher": "mcp__github__close_issue",
          "hooks": [{"type": "command", "command": "/path/to/pretooluse_compliance_hook.py"}]
        }, {
          "matcher": "mcp__github__update_issue",
          "hooks": [{"type": "command", "command": "/path/to/pretooluse_compliance_hook.py"}]
        }]
      }
    }
"""
