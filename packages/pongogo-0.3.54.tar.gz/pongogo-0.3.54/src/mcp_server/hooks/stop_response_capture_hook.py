#!/usr/bin/env python3
"""
Stop Hook for Agent Response Capture

Captures agent responses after Claude Code finishes responding.
Correlates responses with routing events using message hash matching.

Architecture:
    Agent Response Complete → Stop Hook → This Script →
        [Read Transcript] → [Extract User/Assistant Pairs] →
        [Hash Match] → [Update routing_events] → Exit

Usage:
    Configured in ~/.claude/settings.json as Stop hook:
    {
      "hooks": {
        "Stop": [{
          "hooks": [{"type": "command", "command": "/path/to/stop_response_capture_hook.py"}]
        }]
      }
    }

Input:
    Receives JSON via stdin with:
    - session_id: Current session identifier
    - transcript_path: Path to conversation JSONL file
    - permission_mode: Permission settings
    - hook_event_name: "Stop"
    - stop_hook_active: Whether continuing from previous Stop

Output:
    Prints nothing (silent operation)
    Updates routing_events table with agent_response

Exit Codes:
    0: Success (responses captured or nothing to capture)
    1: Error (logged, but doesn't block)

Task: #283 - Capture Agent Responses in Routing Events
"""

import hashlib
import json
import logging
import sqlite3
import sys
import time
from datetime import datetime
from pathlib import Path

# Ensure mcp_server package is importable when run as standalone hook script.
# This hook is invoked directly by Claude Code (not through the adapter),
# so src/ must be on sys.path for `from mcp_server...` imports to work.
_src_path = str(Path(__file__).parent.parent.parent)
if _src_path not in sys.path:
    sys.path.insert(0, _src_path)

from mcp_server.database.connection import get_connection

# Configure logging to file (not stdout)
# Lazy initialization to avoid side effects at import time (CI test environments)
_log_initialized = False
_log_dir: Path | None = None
logger = logging.getLogger(__name__)


def _get_log_dir() -> Path:
    """Get the appropriate log directory, worktree-aware."""
    import os

    try:
        from mcp_server.database.context import get_data_root

        return get_data_root() / ".pongogo" / "logs"
    except ImportError:
        project_root = os.environ.get("PONGOGO_PROJECT_ROOT")
        if project_root:
            return Path(project_root) / ".pongogo" / "logs"
        return Path.home() / ".claude" / "logs"


def _ensure_log_dir(session_id: str = "", branch: str = ""):
    """Ensure log directory exists and configure dual logging. Called lazily on first use."""
    global _log_initialized, _log_dir
    if _log_initialized:
        return

    _log_dir = _get_log_dir()

    try:
        from mcp_server.hooks.logging_utils import setup_dual_logging

        _log_dir = setup_dual_logging(
            log_dir=_log_dir,
            hook_name="stop-response-capture",
            session_id=session_id,
            branch=branch,
        )
    except ImportError:
        try:
            _log_dir.mkdir(parents=True, exist_ok=True)
            logging.basicConfig(
                filename=_log_dir / "stop-response-capture.log",
                level=logging.INFO,
                format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
            )
        except (PermissionError, OSError):
            _log_dir = Path("/tmp/pongogo-logs")
            logging.basicConfig(
                stream=sys.stderr,
                level=logging.WARNING,
                format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
            )

    _log_initialized = True


def _get_early_log_file() -> Path:
    """Get the early log file path, ensuring log dir is initialized."""
    _ensure_log_dir()
    return (_log_dir or Path("/tmp/pongogo-logs")) / "hook-invocations.log"


def write_early_log(session_id: str, event_type: str, details: str = ""):
    """Write to early log file with minimal dependencies."""
    try:
        early_log_file = _get_early_log_file()
        timestamp = datetime.now().isoformat()
        entry = f"{timestamp} | {event_type} | session={session_id} | {details}\n"
        with open(early_log_file, "a") as f:
            f.write(entry)
    except Exception:
        pass


def estimate_token_count(text: str) -> int:
    """Estimate token count using ~4 chars per token approximation."""
    if not text:
        return 0
    return max(1, len(text) // 4)


def load_state_file() -> dict:
    """
    Load Pongogo state from .pongogo-mcp-state.json.

    Returns:
        State dictionary or empty dict if file doesn't exist/invalid
    """
    state_file = Path.cwd() / ".pongogo-mcp-state.json"

    # Search parent directories if not found
    if not state_file.exists():
        for parent in Path.cwd().parents:
            candidate = parent / ".pongogo-mcp-state.json"
            if candidate.exists():
                state_file = candidate
                break

    if not state_file.exists():
        logger.debug("State file not found")
        return {}

    try:
        with open(state_file) as f:
            return json.load(f)
    except Exception as e:
        logger.error(f"Error loading state file: {e}")
        return {}


def get_db_path(state: dict, project_root: Path) -> Path:
    """
    Get database path based on log_comment parameter.

    Uses get_data_root() to resolve the correct data directory, which
    handles linked git worktrees by pointing to the main worktree root.

    Database location (unified schema v3.0.0):
        .pongogo/pongogo.db          (production)
        .pongogo/pongogo-test.db     (testing)
        .pongogo/pongogo-learning.db (learning/eval)
    """
    from mcp_server.database.context import get_data_root

    VALID_LOG_COMMENTS = {"", "testing", "learning"}
    log_comment = state.get("log_comment", "")

    if log_comment not in VALID_LOG_COMMENTS:
        log_comment = ""  # Default to production

    # Worktree-aware data root (resolves to main worktree for shared databases)
    data_root = get_data_root(cwd=project_root)
    pongogo_dir = data_root / ".pongogo"

    if log_comment == "testing":
        return pongogo_dir / "pongogo-test.db"
    elif log_comment == "learning":
        return pongogo_dir / "pongogo-learning.db"
    else:
        return pongogo_dir / "pongogo.db"


def find_project_root(cwd: str) -> Path:
    """Find project root by looking for .pongogo-mcp-state.json."""
    project_root = Path(cwd) if cwd else Path.cwd()

    while project_root != project_root.parent:
        if (project_root / ".pongogo-mcp-state.json").exists():
            return project_root
        project_root = project_root.parent

    return Path.cwd()


def read_transcript(transcript_path: str) -> list[dict]:
    """
    Read conversation transcript from JSONL file.

    Args:
        transcript_path: Path to transcript JSONL file

    Returns:
        List of message dictionaries
    """
    messages: list[dict[str, str]] = []

    if not transcript_path:
        return messages

    try:
        with open(transcript_path) as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        messages.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
    except Exception as e:
        logger.error(f"Error reading transcript: {e}")

    return messages


def extract_message_content(message: dict) -> str:
    """
    Extract text content from a transcript message.

    Handles various message formats in Claude Code transcripts.
    """
    msg = message.get("message", {})
    content = msg.get("content", "")

    # Content can be string or list of content blocks
    if isinstance(content, str):
        return content
    elif isinstance(content, list):
        # Extract text from content blocks
        text_parts = []
        for block in content:
            if isinstance(block, str):
                text_parts.append(block)
            elif isinstance(block, dict):
                if block.get("type") == "text":
                    text_parts.append(block.get("text", ""))
        return "\n".join(text_parts)

    return str(content)


def is_real_user_message(message: dict) -> bool:
    """
    Check if a message is a real user prompt (not a tool_result).

    Claude Code transcripts contain both:
    - Real user messages (role=user, content is string or text blocks)
    - Tool results (role=user, content has type=tool_result blocks)

    We only want to pair real user messages with assistant responses.

    Args:
        message: Transcript message dict

    Returns:
        True if this is a real user message, False if tool_result
    """
    msg = message.get("message", {})
    content = msg.get("content", "")

    # String content is always a real user message
    if isinstance(content, str):
        return True

    # List content - check for tool_result blocks
    if isinstance(content, list):
        for block in content:
            if isinstance(block, dict):
                block_type = block.get("type", "")
                # tool_result blocks are not real user messages
                if block_type == "tool_result":
                    return False
                # text blocks ARE real user messages
                if block_type == "text" and block.get("text", "").strip():
                    return True
        # If we only found empty blocks or unknown types, not a real message
        return False

    return False


def extract_user_assistant_pairs(messages: list[dict]) -> list[tuple[dict, str, dict]]:
    """
    Extract user→assistant response pairs from transcript.

    Returns list of (user_message, combined_response_text, last_assistant_msg) tuples.

    Claude Code transcripts have multiple assistant messages per turn:
    - tool_use blocks (no text)
    - thinking blocks (no visible text)
    - text blocks (actual response)

    We combine ALL text content from assistant messages in a turn.

    IMPORTANT: Filters out tool_result messages (role=user but type=tool_result).
    Only real user prompts are paired with assistant responses.
    """
    pairs = []

    # First pass: find indices of real user messages
    user_indices = []
    for i, msg in enumerate(messages):
        role = msg.get("message", {}).get("role", "")
        if role == "user" and is_real_user_message(msg):
            user_indices.append(i)

    # For each user message, collect assistant responses until next user message
    for idx, user_idx in enumerate(user_indices):
        user_msg = messages[user_idx]

        # Find end boundary (next real user message or end of transcript)
        if idx + 1 < len(user_indices):
            end_idx = user_indices[idx + 1]
        else:
            end_idx = len(messages)

        # Collect all assistant text content in this range
        response_parts = []
        last_assistant_msg = None

        for msg in messages[user_idx + 1 : end_idx]:
            role = msg.get("message", {}).get("role", "")
            if role == "assistant":
                last_assistant_msg = msg
                text = extract_message_content(msg)
                if text.strip():
                    response_parts.append(text)

        # Only create pair if we found assistant response with text
        if response_parts and last_assistant_msg:
            combined_response = "\n".join(response_parts)
            pairs.append((user_msg, combined_response, last_assistant_msg))

    return pairs


def hash_message(content: str) -> str:
    """Generate SHA256 hash of message content."""
    return hashlib.sha256(content.encode()).hexdigest()


def ensure_schema_columns(db_path: Path) -> bool:
    """
    Verify routing_events table exists and has required columns.

    Schema migrations are now handled centrally by PongogoDatabase._run_migrations()
    (Task #639). This function only checks that the database is accessible.

    Returns True if schema is ready, False if database missing.
    """
    if not db_path.exists():
        logger.warning(f"Database not found: {db_path}")
        return False

    try:
        with get_connection(db_path, readonly=True) as conn:
            conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='routing_events'"
            )
        return True
    except Exception as e:
        logger.error(f"Schema check failed: {e}")
        return False


def update_routing_event_with_response(
    db_path: Path,
    session_id: str,
    user_hash: str,
    assistant_content: str,
    correlation_method: str,
    was_interrupted: bool = False,
) -> int | None:
    """
    Update routing_events row with agent response.

    Args:
        db_path: Path to SQLite database
        session_id: Session identifier
        user_hash: SHA256 hash of user message
        assistant_content: Full assistant response text
        correlation_method: How the match was made ('hash_match', 'session_latest')
        was_interrupted: True if response was cut off by user interrupt

    Returns:
        Updated event_id if successful, None otherwise
    """
    try:
        with get_connection(db_path) as conn:
            # Find matching routing event by session_id + message_hash
            # Only update if agent_response is NULL (not already captured)
            result = conn.execute(
                """
                SELECT id FROM routing_events
                WHERE session_id = ?
                AND message_hash = ?
                AND agent_response IS NULL
                ORDER BY timestamp DESC
                LIMIT 1
            """,
                (session_id, user_hash),
            ).fetchone()

            if not result:
                logger.debug(
                    f"No matching routing event found for hash {user_hash[:16]}..."
                )
                return None

            event_id = result[0]
            response_tokens = estimate_token_count(assistant_content)

            # Set exclusion fields if interrupted
            exclude_from_eval = 1 if was_interrupted else 0
            exclude_reason = "response_interrupted" if was_interrupted else None

            # Update with response
            conn.execute(
                """
                UPDATE routing_events
                SET agent_response = ?,
                    agent_response_tokens = ?,
                    response_captured_at = ?,
                    response_correlation_method = ?,
                    exclude_from_eval = CASE WHEN ? = 1 THEN 1 ELSE exclude_from_eval END,
                    exclude_reason = CASE WHEN exclude_reason IS NULL AND ? IS NOT NULL THEN ? ELSE exclude_reason END
                WHERE id = ?
            """,
                (
                    assistant_content,
                    response_tokens,
                    datetime.now().isoformat(),
                    correlation_method,
                    exclude_from_eval,
                    exclude_reason,
                    exclude_reason,
                    event_id,
                ),
            )

        if was_interrupted:
            logger.info(
                f"Updated event {event_id} with INTERRUPTED response ({response_tokens} tokens) - marked for exclusion"
            )
        else:
            logger.info(
                f"Updated event {event_id} with response ({response_tokens} tokens)"
            )
        return event_id

    except Exception as e:
        logger.error(f"Error updating routing event: {e}")
        return None


def detect_interrupted_response(messages: list[dict], assistant_msg: dict) -> bool:
    """
    Detect if an assistant response was interrupted by a new user message.

    When a user sends a new message while Claude is responding:
    - Claude stops responding
    - The new message appears in the transcript AFTER the partial response
    - Stop hook fires

    We detect this by checking if there's a real user message (not tool_result)
    after this assistant message in the transcript.

    Args:
        messages: Full list of transcript messages
        assistant_msg: The assistant message to check

    Returns:
        True if response was interrupted, False otherwise
    """
    # Find index of this assistant message
    assistant_idx = None
    for i, msg in enumerate(messages):
        if msg is assistant_msg:
            assistant_idx = i
            break

    if assistant_idx is None:
        return False

    # Check if there's a real user message after this assistant message
    for msg in messages[assistant_idx + 1 :]:
        role = msg.get("message", {}).get("role", "")
        if role == "user" and is_real_user_message(msg):
            # Found a real user message after the assistant response
            # This indicates an interrupt
            return True

    return False


def audit_compliance_requirements(
    db_path: Path, session_id: str, branch: str | None = None
) -> dict:
    """
    Audit unfulfilled compliance requirements at end of turn.

    Marks unfulfilled requirements as 'carried_forward' so they persist
    to the next turn via the UserPromptSubmit compliance memory system.

    Branch filtering (Task #640): When branch is provided, only audits rows
    matching the current branch OR rows with NULL branch (backward compat).

    Epic #545: Hook-Based Compliance Enforcement
    Task #548: Stop Hook Compliance Audit

    Args:
        db_path: Path to Pongogo database
        session_id: Current session identifier
        branch: Git branch name for cross-branch isolation (Task #640)

    Returns:
        Dict with audit results: pending_count, carried_count, fulfilled_count
    """
    result = {"pending_count": 0, "carried_count": 0, "fulfilled_count": 0}

    try:
        with get_connection(db_path) as conn:
            # Count fulfilled requirements (for metrics), branch-filtered
            fulfilled_rows = conn.execute(
                """
                SELECT COUNT(*) as cnt FROM guidance_fulfillment
                WHERE session_id = ?
                AND (branch = ? OR branch IS NULL)
                AND fulfillment_status = 'fulfilled'
                """,
                (session_id, branch),
            ).fetchone()
            result["fulfilled_count"] = fulfilled_rows["cnt"] if fulfilled_rows else 0

            # Find unfulfilled requirements (pending or in_progress), branch-filtered
            pending_rows = conn.execute(
                """
                SELECT id, action_type, guidance_content, fulfillment_status
                FROM guidance_fulfillment
                WHERE session_id = ?
                AND (branch = ? OR branch IS NULL)
                AND fulfillment_status IN ('pending', 'in_progress')
                """,
                (session_id, branch),
            ).fetchall()

            result["pending_count"] = len(pending_rows)

            if pending_rows:
                # Mark unfulfilled as carried_forward
                for row in pending_rows:
                    # Get current carry count from evidence field (format: "carry_count:N")
                    existing_evidence = ""
                    evidence_row = conn.execute(
                        "SELECT fulfillment_evidence FROM guidance_fulfillment WHERE id = ?",
                        (row["id"],),
                    ).fetchone()
                    if evidence_row and evidence_row["fulfillment_evidence"]:
                        existing_evidence = evidence_row["fulfillment_evidence"]

                    # Parse and increment carry count
                    carry_count = 1
                    if existing_evidence.startswith("carry_count:"):
                        try:
                            carry_count = int(existing_evidence.split(":")[1]) + 1
                        except (ValueError, IndexError):
                            carry_count = 1

                    conn.execute(
                        """
                        UPDATE guidance_fulfillment
                        SET fulfillment_status = 'carried_forward',
                            fulfillment_evidence = ?
                        WHERE id = ?
                        """,
                        (f"carry_count:{carry_count}", row["id"]),
                    )
                    result["carried_count"] += 1

                logger.info(
                    f"Compliance audit: {result['carried_count']} requirements carried forward, "
                    f"{result['fulfilled_count']} fulfilled, session={session_id}"
                )

    except sqlite3.Error as e:
        logger.error(f"Compliance audit database error: {e}")

    return result


def capture_responses_from_transcript(
    transcript_path: str, session_id: str, db_path: Path
) -> int:
    """
    Capture all uncaptured responses from transcript.

    Reconstructs user→assistant pairs and updates routing_events.
    This handles edge cases like rapid-fire messages and missed Stop hooks.

    Also detects interrupted responses (user sent new message while Claude
    was responding) and marks them for exclusion from evaluation.

    Returns:
        Number of responses captured
    """
    messages = read_transcript(transcript_path)
    if not messages:
        logger.debug("No messages in transcript")
        return 0

    pairs = extract_user_assistant_pairs(messages)
    if not pairs:
        logger.debug("No user→assistant pairs found")
        return 0

    captured_count = 0

    for user_msg, combined_response, last_assistant_msg in pairs:
        user_content = extract_message_content(user_msg)

        if not user_content or not combined_response:
            continue

        user_hash = hash_message(user_content)

        # Detect if this response was interrupted
        # (check if there's a real user message after the last assistant message)
        was_interrupted = detect_interrupted_response(messages, last_assistant_msg)

        event_id = update_routing_event_with_response(
            db_path=db_path,
            session_id=session_id,
            user_hash=user_hash,
            assistant_content=combined_response,
            correlation_method="hash_match",
            was_interrupted=was_interrupted,
        )

        if event_id:
            captured_count += 1

    return captured_count


def main():
    """
    Main entry point for Stop hook.

    Reads transcript, extracts responses, updates routing_events.
    """
    session_id = "unknown"

    try:
        start_time = time.time()

        # Read input from stdin
        input_data = json.load(sys.stdin)

        session_id = input_data.get("session_id", "unknown")
        transcript_path = input_data.get("transcript_path", "")
        hook_event = input_data.get("hook_event_name", "")

        # Initialize dual logging with session context
        _ensure_log_dir(session_id=session_id)

        # Early log
        write_early_log(session_id, "STOP_HOOK_START", f"event={hook_event}")

        logger.info(
            f"Stop hook triggered: session={session_id}, transcript={transcript_path}"
        )

        # Verify this is actually a Stop event
        if hook_event != "Stop":
            logger.warning(f"Unexpected hook event: {hook_event}")
            sys.exit(0)

        # Load state to determine DB path
        state = load_state_file()

        # Check if Pongogo is disabled
        mode = state.get("mode", "enabled")
        if mode == "disabled":
            logger.info("Pongogo disabled, skipping response capture")
            sys.exit(0)

        # Find project root and DB path
        project_root = find_project_root("")
        db_path = get_db_path(state, project_root)

        logger.info(f"Using database: {db_path}")

        # Ensure schema has required columns
        if not ensure_schema_columns(db_path):
            logger.error("Schema migration failed, skipping response capture")
            write_early_log(session_id, "STOP_HOOK_ERROR", "schema_migration_failed")
            sys.exit(0)

        # Capture responses from transcript
        captured_count = capture_responses_from_transcript(
            transcript_path=transcript_path, session_id=session_id, db_path=db_path
        )

        # Detect branch for cross-branch isolation (Task #640)
        from mcp_server.database.context import get_current_branch

        branch = get_current_branch()

        # Epic #545: Compliance audit — mark unfulfilled requirements as carried_forward
        compliance_audit = audit_compliance_requirements(
            db_path, session_id, branch=branch
        )

        elapsed_ms = (time.time() - start_time) * 1000

        logger.info(
            f"Stop hook complete: captured={captured_count}, "
            f"compliance_audit={compliance_audit}, "
            f"session={session_id}, latency={elapsed_ms:.1f}ms"
        )

        write_early_log(session_id, "STOP_HOOK_END", f"captured={captured_count}")
        sys.exit(0)

    except Exception as e:
        _ensure_log_dir(session_id=session_id)
        logger.error(f"Error in Stop hook: {e}", exc_info=True)
        write_early_log(session_id, "STOP_HOOK_ERROR", str(e)[:100])
        sys.exit(0)  # Don't block on error


if __name__ == "__main__":
    main()
