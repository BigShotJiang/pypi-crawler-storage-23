# FROZEN VERSION - DO NOT MODIFY
# Version: durian-0.6.2
# Frozen by: freeze_engine.py (Task #231)
# To make changes, update pongogo_router.py and create a new frozen version.

"""
Super Pongogo Router & Eval (durian-0.6.2)

Combined routing engine and evaluation harness for Super Pongogo development.
This is the canonical script for internal development - merges router.py + unified_eval.py.

External distributions use a separate pongogo_router.py without eval.

Key Features:
- Full routing engine with all IMP features (IMP-002 through IMP-013)
- Integrated 5-dimension evaluation using router detection methods
- Per-engine evaluation with IMP flag isolation
- CLI support for both routing and eval modes

Usage:
    # Routing mode
    python super_pongogo_router_and_eval.py route "how do I close an issue?"

    # Eval mode - single engine
    python super_pongogo_router_and_eval.py eval --engine durian-0.6.1

    # Eval mode - all engines with comparison table
    python super_pongogo_router_and_eval.py eval --all-engines

    # Eval mode - baseline progression table (versions with IMPs and deltas)
    python super_pongogo_router_and_eval.py eval --baseline-table

    # Eval mode - list available engines
    python super_pongogo_router_and_eval.py eval --list-engines

    # Feature isolation test
    python super_pongogo_router_and_eval.py eval --engine durian-0.6.1 --disable friction_boost

References:
    - Task #475: Unified Eval Architecture
    - Task #464: Query-Relevance -> Query-Adherence -> LLM Adherence to Routing rename
    - Spike #188: Routing Engine Architecture
    - wiki/Eval.md, wiki/Eval-Coverage-Matrix.md
"""

import fnmatch
import json
import logging
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ..database.connection import get_connection
from ..instruction_handler import InstructionHandler
from ..routing_engine import FeatureSpec, RoutingEngine, register_engine

logger = logging.getLogger(__name__)

# =============================================================================
# ROUTING ENGINE CONSTANTS (from router.py)
# =============================================================================

# Single source of truth for this engine's version
DURIAN_VERSION = "durian-0.6.2"

# Version progression for baseline table generation
# Maps each frozen version to its IMP features and introduction order

# IMP-to-dimension mapping for baseline table

# IMP-003: Simple approval patterns that should suppress routing
APPROVAL_PATTERNS = {
    "yes",
    "ok",
    "okay",
    "sure",
    "go ahead",
    "please continue",
    "continue",
    "sounds good",
    "perfect",
    "great",
    "excellent",
    "good",
    "fine",
    "nice",
    "thanks",
    "thank you",
    "ty",
    "approved",
    "confirmed",
    "correct",
    "yes please",
    "yes, please",
    "please do",
    "yes, please do",
    "go for it",
    "do it",
    "proceed",
    "that works",
    "that's fine",
    "that's good",
    "looks good",
    "lgtm",
    "ship it",
    "merge it",
    "all good",
    "no problem",
    "no worries",
    "np",
    "yep",
    "yup",
    "yeah",
    "uh huh",
    "mm hmm",
    "absolutely",
    "definitely",
    "certainly",
    "of course",
    "right",
    "exactly",
    "precisely",
    "agreed",
    "understood",
    "got it",
    "will do",
}

APPROVAL_WORDS = {
    "yes",
    "ok",
    "okay",
    "sure",
    "good",
    "great",
    "fine",
    "nice",
    "perfect",
    "excellent",
    "thanks",
    "approved",
    "continue",
    "proceed",
    "agreed",
    "correct",
    "right",
    "yep",
    "yeah",
}

# IMP-003 refinement: Conservative commencement phrases
COMMENCEMENT_PHRASES = [
    "let's continue",
    "let's proceed",
    "let's resume",
    "let's go ahead",
    "let's get started",
    "let's begin",
    "let's start",
    "please continue",
    "please proceed",
    "please resume",
    "please go ahead",
    "yes, let's continue",
    "yes, let's proceed",
    "yes, let's resume",
    "yes, let's begin",
    "yes, let's start",
    "yes, please continue",
    "yes, please proceed",
    "go ahead",
    "go ahead and continue",
    "go ahead and proceed",
    "continue with",
    "proceed with",
]

# IMP-002: Violation words that should trigger compliance routing
VIOLATION_WORDS = {
    "unacceptable",
    "wrong",
    "incorrect",
    "mistake",
    "frustrated",
    "frustrating",
    "annoying",
    "annoyed",
    "disappointed",
    "violation",
    "violate",
    "breach",
    "sloppy",
    "careless",
    "shortcuts",
}
EMPHASIS_VIOLATION_WORDS = {"no", "stop", "bad"}
VIOLATION_BOOST_CATEGORIES = {"trust_execution", "safety_prevention"}
VIOLATION_CATEGORY_BOOST = 20
FOUNDATIONAL_SCORE = 1000

# IMP-010: Procedural instruction detection
PROCEDURAL_CONTENT_PATTERNS = [
    r"compliance\s*gate",
    r"step\s*\d+[:\s]",
    r"phase\s*\d+[:\s]",
    r"\[\s*\]\s+.*(?:\n.*)*",
    r"mandatory.*steps?",
    r"must.*read.*before",
    r"12-step|13-step|6-step",
]
PROCEDURAL_KEYWORDS = {
    "checklist",
    "step-by-step",
    "workflow",
    "process",
    "procedure",
    "systematic",
    "mandatory",
    "compliance",
    "12-step",
    "13-step",
    "verification",
    "validation checklist",
    "approval gate",
}
PROCEDURAL_WARNING_THRESHOLD = 50
COMPILED_PROCEDURAL_PATTERNS = [
    re.compile(p, re.IGNORECASE) for p in PROCEDURAL_CONTENT_PATTERNS
]

# IMP-009: Commencement look-back boost
COMMENCEMENT_LOOKBACK_BOOST = 15

# IMP-007: Co-occurring instruction bundles
INSTRUCTION_BUNDLES = {
    "trust_execution/development_workflow_essentials": [
        ("trust_execution/trust_based_task_execution", 12, 0.55),
    ],
    "trust_execution/trust_based_task_execution": [
        ("trust_execution/development_workflow_essentials", 12, 0.55),
    ],
    "batch_processing_patterns": [
        ("safety_prevention/systematic_prevention_framework", 10, 0.61),
        ("safety_prevention/validation_first_execution", 8, 0.56),
    ],
    "docker_compose_patterns": [
        ("infrastructure/container_management", 15, 0.89),
    ],
    "infrastructure/container_management": [
        ("docker_compose_patterns", 15, 0.89),
        ("mcp_deployment_architecture", 12, 1.00),
    ],
    "mcp_deployment_architecture": [
        ("infrastructure/container_management", 12, 1.00),
    ],
    "github/issue_status_done": [
        ("project_management/issue_closure", 10, 0.62),
    ],
}
BUNDLE_BOOST_BASE = 10

# IMP-008: Semantic flag patterns
SEMANTIC_FLAG_PATTERNS = {
    "corrective": {
        "patterns": [
            r"\bno\b",
            r"\bstop\b",
            r"\bwrong\b",
            r"\bincorrect\b",
            r"\bunacceptable\b",
            r"\bmistake\b",
            r"\berror\b",
            r"\bdon\'t\b",
            r"\bfail\b",
            r"\bbug\b",
        ],
        "boost_categories": ["trust_execution", "learning", "safety_prevention"],
        "boost_amount": 8,
    },
    "directive": {
        "patterns": [
            r"\bplease\s+\w+",
            r"\bshould\b",
            r"\bmust\b",
            r"\bneed\s+to\b",
            r"\bensure\b",
            r"\balways\b",
            r"\bnever\b",
            r"\brequire\b",
        ],
        "boost_categories": [
            "agentic_workflows",
            "safety_prevention",
            "project_management",
        ],
        "boost_amount": 5,
    },
    "compliance": {
        "patterns": [
            r"\bfollow\b",
            r"\badhere\b",
            r"\bcomplian",
            r"\bstandard\b",
            r"\bpolicy\b",
            r"\bprocess\b",
            r"\bworkflow\b",
            r"\bguideline\b",
        ],
        "boost_categories": [
            "safety_prevention",
            "agentic_workflows",
            "trust_execution",
        ],
        "boost_amount": 8,
    },
    "technical": {
        "patterns": [
            r"\bgit\b",
            r"\bgithub\b",
            r"\bdocker\b",
            r"\bcontainer\b",
            r"\bmcp\b",
            r"\bserver\b",
            r"\bapi\b",
            r"\bdatabase\b",
            r"\bdb\b",
        ],
        "boost_categories": ["infrastructure", "github_integration", "devops"],
        "boost_amount": 6,
    },
    "meta": {
        "patterns": [
            r"\bissue\b",
            r"\btask\b",
            r"\bepic\b",
            r"\bsprint\b",
            r"\bmilestone\b",
            r"\bproject\b",
            r"\bstatus\b",
            r"\bclose\b",
            r"\bboard\b",
        ],
        "boost_categories": ["github_integration", "project_management"],
        "boost_amount": 6,
    },
}
COMPILED_SEMANTIC_FLAGS = {
    flag_name: {
        "regex": re.compile("|".join(config["patterns"]), re.IGNORECASE),
        "boost_categories": config["boost_categories"],
        "boost_amount": config["boost_amount"],
    }
    for flag_name, config in SEMANTIC_FLAG_PATTERNS.items()
}

# IMP-011: Friction patterns (durian-0.6.3 expansion based on GT v4 analysis)
FRICTION_PATTERNS = {
    "correction": [
        # Original patterns
        r"not\s+good\s+enough",
        r"cutting\s+corners",
        r"against\s+our\s+(goal|broader)",
        r"please\s+remember",
        r"we'?ve\s+been\s+over\s+this",
        r"you\s+(should|need\s+to)\s+undo",
        r"you'?re\s+again",
        r"you\s+had\s+put.*wrong",
        r"that'?s?\s+not\s+(right|correct|what)",
        r"it\s+was\s+meant\s+to\s+be",
        r"you'?re\s+overcomplicating",
        r"don'?t\s+overcomplicate",
        r"i'?m\s+not\s+sure\s+(that\s+)?you\s+did",
        r"you\s+did\s+it\s+(in\s+)?reverse",
        r"you\s+did\s+it\s+wrong",
        r"is\s+not\s+the\s+priority",
        r"focusing\s+on.*is\s+not",
        r"don'?t\s+focus\s+on",
        # New patterns from GT v4 analysis
        r"without\s+(asking|checking\s+in)",
        r"started\s+a?\s*task\s+without",
        r"process\s+(violation|issue)",
        r"that\s+defeats",
        r"you'?re\s+skipping",
        r"you\s+skipped",
        r"you'?re\s+all\s+over\s+the\s+place",
        r"expressly\s+forbidden",
        r"isn'?t\s+acceptable",
        r"not\s+acceptable",
        r"we\s+need\s+to\s+(pause|remove|change)",
        r"you\s+(seem\s+to\s+have\s+)?failed\s+in",
        r"did\s+you\s+actually",
        r"why\s+wasn'?t",
        r"why\s+weren'?t",
        r"this\s+should\s+be\s+(removed|clear)",
        r"we'?ve\s+been\s+through\s+this",
        r"that\s+is\s+also\s+a\s+process\s+violation",
        r"hold\s+on[,.]?\s+you'?re",
    ],
    "retry": [
        # Original patterns
        r"since\s+i'?ve?\s+(exited|re-?entered)",
        r"cleared\s+the\s+context",
        r"context\s+window\s+(reset|cleared)",
        r"let'?s\s+try\s+again",
        r"let'?s\s+retry",
        # New patterns from GT v4 analysis
        r"i\s+got\s+this\s+error",
        r"got\s+an?\s+error",
        r"fresh\s+install",
        r"just\s+did\s+a\s+fresh",
    ],
    "rejection": [
        r"^no!+",
        r"\bno!{2,}",
        r"\bunacceptable\b",
        r"completely\s+unacceptable",
        r"this\s+is\s+completely",
        r"(lost|losing)\s+confidence",
        r"consider\s+this\s+a\s+failure",
        r"this\s+is\s+a\s+failure",
        r"this\s+has\s+failed",
        r"\brevert\b",
        r"start\s+(again|over)",
        r"delete\s+all",
        r"fully\s+delete",
        r"undo\s+(everything|all)",
    ],
}
COMPILED_FRICTION_PATTERNS = {
    friction_type: re.compile("|".join(patterns), re.IGNORECASE)
    for friction_type, patterns in FRICTION_PATTERNS.items()
}
FRICTION_BOOST_AMOUNT = 20
FRICTION_BOOST_CATEGORIES = [
    "trust_execution",
    "learning",
    "safety_prevention",
    "development_standards",
]

# IMP-016: Boundary detection patterns (conversation start vs continuation)
# Based on GT v4 analysis of 56 BOUNDARY vs 444 CONTINUATION events
BOUNDARY_PATTERNS = {
    "new_work": [
        # Explicit new work initiation
        r"^let'?s\s+start\s+with",
        r"^let'?s\s+work\s+on",
        r"^let'?s\s+begin",
        r"^let'?s\s+tackle",
        r"^let'?s\s+focus\s+on",
        r"please\s+take\s+(the\s+)?(task|issue|epic)\s+through",
        r"take\s+it\s+through\s+(closure|commencement)",
        r"^we\s+should\s+explore",
        r"^i\s+want\s+to\s+explore",
        # Task-specific initiation (from GT v4 analysis)
        r"^let'?s\s+make\s+a\s+task",
        r"^let'?s\s+move\s+it\s+into",
        r"^let'?s\s+do\s+the\s+manual",
        r"^let'?s\s+now\s+return\s+to",
        r"^let'?s\s+take\s+a\s+look",
        r"^let'?s\s+take\s+(issue|task)",
        r"^let'?s\s+get\s+back\s+to",
        r"^proceed\s+with\s+(scoping|implementing)",
        r"^we\s+need\s+to\s+tackle",
        r"please\s+finish\s+taking\s+(issue|task)",
        r"please\s+look\s+into\s+this\s+issue",
        # Task/issue references at conversation start
        r"^(task|issue|epic|spike)\s*#?\d+",
    ],
    "context_switch": [
        # Explicit context switches (more specific patterns)
        r"^switching\s+gears",
        r"^one\s+unrelated\s+question",
        r"^now\s+that\s+all\s+of\s+our\s+work",
        r"^next,?\s+please\s+investigate",
        r"^we\s+next\s+need\s+to\s+outline",
        # New topic introductions
        r"^with\s+pongogo,?\s+we\s+should",
        r"^as\s+a\s+task\s+for",
    ],
    "question_topic": [
        # Questions that start new topics (more specific)
        r"^where\s+in\s+the\s+wiki",
        r"^has\s+the\s+wiki\s+on",
        r"^what\s+is\s+the\s+manifest",
        r"^what\s+is\s+our\s+current",
        r"^can\s+you\s+(list\s+the\s+remaining|define\s+what)",
        r"^is\s+there\s+(a\s+way\s+to\s+streamline|other\s+work\s+from)",
        r"^what\s+tasks\s+remain",
        r"^do\s+we\s+currently\s+have",
        r"^how\s+is\s+our\s+support",
        r"^is\s+our\s+.*set\s+up\s+correctly",
        r"^it\s+looks\s+like\s+\d+\s+and\s+\d+\s+may",  # issue comparison
    ],
    "context_import": [
        # Importing external context
        r"^i\s+saved\s+(all\s+)?(the\s+)?.*info",
        r"^below\s+is",
        r"from\s+our\s+last\s+conversation",
        r"from\s+the\s+last\s+session",
        r"let'?s\s+use\s+this\s+to\s+start",
        r"^here'?s?\s+(the\s+)?context",
        r"^here\s+is\s+the\s+context",
    ],
    "fresh_start": [
        # Explicit fresh start / error reports
        r"fresh\s+start",
        r"new\s+session",
        r"new\s+conversation",
        r"^let'?s\s+ignore\s+this\s+resumption",
        r"starting\s+fresh",
        r"clean\s+slate",
        r"^i\s+got\s+this\s+error.*direnv",  # Context reset after env reload
        r"^i\s+just\s+did\s+a\s+fresh\s+install",
    ],
    "urgent": [
        # Urgent new topic
        r"^we\s+need\s+to\s+solve\s+this\s+now",
        r"^i\s+want\s+to\s+do\s+proactive\s+detection\s+now",
        r"^we\s+need\s+to\s+create\s+a\s+new\s+issue\s+in\s+github",
    ],
}
COMPILED_BOUNDARY_PATTERNS = {
    boundary_type: re.compile("|".join(patterns), re.IGNORECASE | re.MULTILINE)
    for boundary_type, patterns in BOUNDARY_PATTERNS.items()
}

# IMP-012: Mistake type patterns
MISTAKE_PATTERNS = {
    "incomplete_implementation": [
        r"not\s+good\s+enough",
        r"thoroughly\s+analyze\s+all",
        r"guessing\s+is\s+against",
        r"cutting\s+corners",
        r"goal\s+of\s+completeness",
        r"circumvent.*directive",
        r"abbreviated\s+manner",
        r"lost\s+confidence",
        r"gotten\s+off\s+task",
        r"isn'?t\s+an?\s+accurate\s+reflection",
        r"ongoing\s+problem",
        r"not\s+following\s+the\s+process",
        r"revert.*start\s+again",
        r"(6th|fifth|fourth|third)\s+time.*stop\s+you",
    ],
    "premature_action": [
        r"no,?\s+you\s+may\s+not",
        r"please\s+first\s+show",
        r"let'?s\s+determine",
        r"shouldn'?t\s+consider\s+it\s+correct",
        r"did\s+you\s+verify.*first",
        r"before\s+you\s+(do|proceed|continue)",
    ],
    "github_api_misuse": [
        r"don'?t\s+see\s+any\s+changes\s+to\s+the\s+project\s*board",
        r"not\s+in\s+the\s+right\s+place",
        r"serious\s+mistakes.*project\s*board",
        r"should\s+never\s+have\s+been\s+created",
        r"project\s*board.*wrong",
    ],
    "closure_checklist_skip": [
        r"complete\s+this\s+entire\s+checklist",
        r"confirm\s+the\s+status\s+of\s+every",
        r"missing\s+a\s+major\s+procedural\s+gate",
        r"checklist.*not\s+(being\s+)?used",
    ],
    "commencement_checklist_skip": [
        r"did\s+you\s+verify\s+the\s+status\s+of\s+issues?",
        r"check\s+prerequisites?\s+first",
        r"before\s+starting\s+work",
    ],
    "over_engineering": [
        r"overcomplicat(ing|e)",
        r"don'?t\s+overcomplicate",
        r"already\s+(did|done|broke\s+out)",
        r"too\s+complex",
    ],
    "wrong_file_location": [
        r"not\s+the\s+right\s+(place|location|directory)",
        r"should\s+be\s+stored\s+outside",
        r"wrong\s+(place|location|directory)",
        r"moved\s+(them|it)\s+to\s+the\s+correct",
    ],
    "misunderstanding_architecture": [
        r"why\s+are\s+they\s+competing",
        r"became\s+confused",
        r"misunderstand.*architecture",
        r"that'?s\s+not\s+how.*works",
    ],
}
MISTAKE_INSTRUCTION_MAP = {
    "incomplete_implementation": [
        "architecture_principles.instructions.md",
        "development_workflow.instructions.md",
    ],
    "premature_action": [
        "issue_closure.instructions.md",
        "issue_status_in_progress.instructions.md",
    ],
    "github_api_misuse": [
        "github_project_status_workflow.instructions.md",
        "github_essentials.instructions.md",
    ],
    "closure_checklist_skip": ["issue_closure.instructions.md"],
    "commencement_checklist_skip": [
        "issue_status_in_progress.instructions.md",
        "issue_commencement.instructions.md",
    ],
    "over_engineering": ["architecture_principles.instructions.md"],
    "wrong_file_location": [
        "documentation_placement.instructions.md",
        "repository_organization.instructions.md",
    ],
    "misunderstanding_architecture": [
        "mcp_deployment_architecture.instructions.md",
        "architecture_principles.instructions.md",
    ],
}
COMPILED_MISTAKE_PATTERNS = {
    mistake_type: re.compile("|".join(patterns), re.IGNORECASE)
    for mistake_type, patterns in MISTAKE_PATTERNS.items()
}
OUTCOME_BOOST_AMOUNT = 5

# IMP-013: User guidance detection patterns
EXPLICIT_GUIDANCE_TRIGGERS = {
    r"from\s+now\s+on",
    r"going\s+forward",
    r"please\s+always",
    r"always\s+(?:do|ensure|make|use|check|verify)",
    r"never\s+(?:do|use|commit|skip|forget)",
    r"never\s+without\s+(?:first|asking|checking)",
    r"(?:my\s+)?rule\s*(?:is)?:",
    r"the\s+rule\s+is",
    r"follow\s+this\s+rule",
    r"here'?s?\s+(?:a\s+)?rule",
    r"i\s+want\s+you\s+to\s+(?:always|never)",
    r"you\s+should\s+(?:always|never)",
    r"you\s+must\s+(?:always|never)",
    r"make\s+sure\s+(?:to\s+)?(?:always|never)",
    r"remember\s+to\s+(?:always|never)?",
    r"don'?t\s+forget\s+to",
    r"my\s+preference\s+is",
    r"i\s+(?:always\s+)?prefer\s+(?:that|to|when)",
}
IMPLICIT_GUIDANCE_TRIGGERS = {
    r"that\s+was\s+frustrating",
    r"that\s+was\s+annoying",
    r"that\s+was\s+(?:not\s+)?(?:great|good|helpful)",
    r"i\s+didn'?t\s+like",
    r"i\s+don'?t\s+like\s+when",
    r"please\s+don'?t\s+(?:do\s+that|repeat)",
    r"i\s+wish\s+you\s+would",
    r"it\s+would\s+be\s+(?:better|nice|good)\s+if",
    r"next\s+time",
    r"maybe\s+next\s+time",
    r"in\s+the\s+past",
    r"you\s+should\s+have",
    r"you\s+could\s+have",
    r"why\s+didn'?t\s+you",
    r"i\s+expected\s+you\s+to",
    r"that'?s\s+not\s+(?:right|correct|what\s+i)",
    r"i'?d\s+rather",
    r"i\s+like\s+(?:it\s+)?when",
    r"i\s+(?:usually|typically|normally)\s+(?:prefer|want|like)",
    r"(?:more|less)\s+(?:verbose|detailed|concise)",
    r"(?:keep\s+it|be)\s+(?:brief|short|concise)",
    r"don'?t\s+(?:be\s+so|over)",
    r"(?:too\s+)?(?:much|many)\s+(?:detail|explanation)",
}
COMPILED_EXPLICIT_GUIDANCE = re.compile(
    "|".join(f"({p})" for p in EXPLICIT_GUIDANCE_TRIGGERS), re.IGNORECASE
)
COMPILED_IMPLICIT_GUIDANCE = re.compile(
    "|".join(f"({p})" for p in IMPLICIT_GUIDANCE_TRIGGERS), re.IGNORECASE
)

# Default feature configuration (all improvements enabled)
DEFAULT_FEATURES = {
    "violation_detection": True,  # IMP-002: Detect violations, boost compliance
    "approval_suppression": True,  # IMP-003: Suppress routing on simple approvals
    "foundational": True,  # Include foundational instructions always
    "commencement_lookback": True,  # IMP-009: Boost previous routing on commencement
    "instruction_bundles": True,  # IMP-007: Boost co-occurring instruction pairs
    "semantic_flags": True,  # IMP-008: Boost categories based on semantic flags
    "procedural_warning": True,  # IMP-010: Warn when procedural instructions routed
    "iteration_aware": True,  # IMP-011: Detect friction patterns
    "friction_boost": True,  # IMP-011: Boost trust/learning when friction detected
    "outcome_aware": True,  # IMP-012: Detect mistake types
    "outcome_boost": True,  # IMP-012: Boost preventive instructions
    "guidance_detection": True,  # IMP-013: Detect user guidance for capture
    "boundary_detection": True,  # Detect conversation boundaries
    "lifecycle_keywords": True,  # IMP-014: Boost closure/commencement checklists (Task #477)
    "additional_friction": True,  # IMP-015: Extended friction patterns (Task #477)
    "violation_checklist": True,  # IMP-016: Boost checklists on violations (Task #477)
}

# =============================================================================
# EVAL CONSTANTS
# =============================================================================

# Ground truth database paths
REPO_ROOT = Path(__file__).parent.parent
GT_V4_DB = REPO_ROOT / "experiments" / "ground_truth_v4_2026_01" / "ground_truth_v4.db"
GT_V3_DB = (
    REPO_ROOT
    / "experiments"
    / "query_relevance_eval_2025_12"
    / "query_relevance_ground_truth_v3.0.db"
)

# Eval dimension weights (Issue #477, Task #478)
# Note: LLM Adherence excluded - static across versions, requires A/B testing (Task #478)
# Note: Outcome excluded - no PREVENTED events until preceptor (Task #271)
EVAL_WEIGHTS = {
    "iteration": 0.50,  # Primary algorithm signal (friction detection F1)
    "guidance": 0.25,  # User guidance detection accuracy
    "boundary": 0.25,  # Conversation boundary detection F1
    # Excluded dimensions:
    # 'llm_adherence': N/A    # Static - requires A/B testing infrastructure (Task #478)
    # 'outcome': N/A          # No PREVENTED events until preceptor (Task #271)
}

# Available engines for evaluation

# =============================================================================
# EVAL DATACLASSES
# =============================================================================


@dataclass
# =============================================================================
# ROUTING ENGINE CLASS
# =============================================================================

@register_engine(DURIAN_VERSION)
class DurianRouter062(RoutingEngine):
    """
    Rule-based routing engine using NLP + taxonomy + context + globs.

    This is the durian-0.6.2-dev implementation with all IMP features.
    """

    def __init__(
        self,
        instruction_handler: InstructionHandler,
        features: dict[str, bool] | None = None,
    ):
        """
        Initialize router with instruction handler and optional feature flags.

        Args:
            instruction_handler: Handler for instruction files
            features: Optional dict overriding DEFAULT_FEATURES
        """
        self.instruction_handler = instruction_handler
        self.features = {**DEFAULT_FEATURES, **(features or {})}
        logger.debug(f"Initialized {DURIAN_VERSION} with features: {self.features}")

    @property
    def version(self) -> str:
        """Return engine version string."""
        return DURIAN_VERSION

    @property
    def description(self) -> str:
        """Return human-readable description of routing approach."""
        return "Rule-based routing with NLP + taxonomy + context + globs + IMP features"

    @staticmethod
    def get_available_features() -> list[FeatureSpec]:
        """Return list of available feature specifications."""
        return [
            FeatureSpec(
                name="violation_detection",
                description="IMP-002: Detect violation signals and boost compliance routing",
                default=True,
                category="scoring",
            ),
            FeatureSpec(
                name="approval_suppression",
                description="IMP-003: Suppress routing on simple approval messages",
                default=True,
                category="routing",
            ),
            FeatureSpec(
                name="foundational",
                description="Include foundational instructions with every routing result",
                default=True,
                category="routing",
            ),
            FeatureSpec(
                name="commencement_lookback",
                description="IMP-009: Boost previous routing results on commencement messages",
                default=True,
                category="scoring",
            ),
            FeatureSpec(
                name="instruction_bundles",
                description="IMP-007: Boost co-occurring instruction pairs based on ground truth analysis",
                default=True,
                category="scoring",
            ),
            FeatureSpec(
                name="semantic_flags",
                description="IMP-008: Boost categories based on message semantic flags (corrective, directive, etc.)",
                default=True,
                category="scoring",
            ),
            FeatureSpec(
                name="procedural_warning",
                description="IMP-010: Warn when procedural instructions are routed (requires Read before execute)",
                default=True,
                category="compliance",
            ),
            FeatureSpec(
                name="iteration_aware",
                description="IMP-011: Detect friction (correction/retry/rejection) using Spike #278 patterns",
                default=True,
                category="scoring",
            ),
            FeatureSpec(
                name="friction_boost",
                description="IMP-011: Boost trust/learning/safety categories when friction detected",
                default=True,
                category="scoring",
            ),
            FeatureSpec(
                name="outcome_aware",
                description="IMP-012: Detect mistake types (incomplete_implementation, premature_action, etc.) using Spike #284 patterns",
                default=True,
                category="scoring",
            ),
            FeatureSpec(
                name="outcome_boost",
                description="IMP-012: Boost specific preventive instructions when mistake type detected",
                default=True,
                category="scoring",
            ),
            FeatureSpec(
                name="guidance_detection",
                description="IMP-013: Detect user guidance (rules, preferences, feedback) for knowledge capture (Task #390)",
                default=True,
                category="detection",
            ),
            FeatureSpec(
                name="boundary_detection",
                description="IMP-016: Detect conversation boundaries (new topic vs continuation) for context inheritance",
                default=True,
                category="detection",
            ),
        ]

    def route(self, message: str, context: dict | None = None, limit: int = 5) -> dict:
        """
        Route message to relevant instruction files.

        Args:
            message: User message or query
            context: Optional context dictionary
            limit: Maximum number of instructions to return

        Returns:
            Dictionary with instructions, count, and routing_analysis
        """
        try:
            # IMP-003: Early exit for simple approval messages
            if self.features.get("approval_suppression", True):
                should_suppress, suppression_reason, commencement_detected = (
                    self._is_simple_approval(message)
                )
                if should_suppress:
                    return {
                        "instructions": [],
                        "count": 0,
                        "routing_analysis": {
                            "suppressed": True,
                            "reason": f"IMP-003: {suppression_reason}",
                            "commencement_detected": False,
                            "message_preview": message[:50]
                            if len(message) > 50
                            else message,
                        },
                    }
                elif commencement_detected:
                    logger.info(
                        f"IMP-003: Commencement pattern overrode approval suppression: {message[:50]}"
                    )
            else:
                commencement_detected = False

            commencement_override = (
                commencement_detected
                if self.features.get("approval_suppression", True)
                else None
            )

            # Parse message and context
            keywords = self._extract_keywords(message)
            intent = self._extract_intent(message)

            # IMP-002: Detect violations
            if self.features.get("violation_detection", True):
                violation_info = self._detect_violations(message)
            else:
                violation_info = {"detected": False, "signals": [], "boost_amount": 0}

            # IMP-008: Detect semantic flags
            if self.features.get("semantic_flags", True):
                semantic_flags_info = self._detect_semantic_flags(message)
            else:
                semantic_flags_info = {
                    "detected": False,
                    "flags": [],
                    "category_boosts": {},
                }

            # IMP-011: Detect friction
            if self.features.get("iteration_aware", True):
                friction_info = self._detect_friction(message)
            else:
                friction_info = {
                    "detected": False,
                    "friction_type": None,
                    "signals": [],
                    "category_boosts": {},
                }

            # IMP-012: Detect mistake types
            if self.features.get("outcome_aware", True):
                mistake_info = self._detect_mistake_type(message)
            else:
                mistake_info = {
                    "detected": False,
                    "mistake_type": None,
                    "signals": [],
                    "instruction_boosts": [],
                }

            # IMP-013: Detect user guidance
            if self.features.get("guidance_detection", True):
                guidance_info = self._detect_user_guidance(message)
            else:
                guidance_info = {
                    "detected": False,
                    "guidance_type": None,
                    "signals": [],
                    "content": None,
                }

            # IMP-016: Detect conversation boundary
            if self.features.get("boundary_detection", True):
                boundary_info = self._detect_boundary(message)
            else:
                boundary_info = {
                    "is_boundary": False,
                    "boundary_type": None,
                    "signals": [],
                    "confidence": "low",
                }

            context = context or {}
            files = context.get("files", [])
            directories = context.get("directories", [])
            branch = context.get("branch", "")
            language = context.get("language", "")

            # IMP-009: Commencement look-back
            previous_routing_ids = set()
            lookback_info = None
            if commencement_detected and self.features.get(
                "commencement_lookback", True
            ):
                lookback_result = self._get_previous_routing(context)
                if lookback_result and lookback_result.get("instructions"):
                    previous_routing_ids = set(lookback_result["instructions"])
                    lookback_info = {
                        "enabled": True,
                        "found": True,
                        "instruction_count": len(previous_routing_ids),
                        "boost_amount": COMMENCEMENT_LOOKBACK_BOOST,
                    }
                    logger.info(
                        f"IMP-009: Will boost {len(previous_routing_ids)} instructions from previous routing"
                    )
                else:
                    lookback_info = {"enabled": True, "found": False}
            elif commencement_detected:
                lookback_info = {"enabled": False, "reason": "feature_disabled"}

            # Score all instructions
            scored_instructions = []
            analysis = {
                "keywords_extracted": keywords,
                "intent_detected": intent,
                "context_used": context,
                "features": self.features,
                "violation_detection": violation_info
                if violation_info["detected"]
                else None,
                "semantic_flags": semantic_flags_info
                if semantic_flags_info["detected"]
                else None,
                "friction_detection": friction_info
                if friction_info["detected"]
                else None,
                "mistake_detection": mistake_info if mistake_info["detected"] else None,
                "guidance_detection": guidance_info
                if guidance_info["detected"]
                else None,
                "boundary_detection": boundary_info
                if boundary_info["is_boundary"]
                else None,
                "commencement_override": commencement_override,
                "commencement_lookback": lookback_info,
                "scoring_breakdown": [],
            }

            for instruction in self.instruction_handler.instructions.values():
                score, score_breakdown = self._score_instruction(
                    instruction=instruction,
                    message=message,
                    keywords=keywords,
                    intent=intent,
                    files=files,
                    directories=directories,
                    branch=branch,
                    language=language,
                    violation_info=violation_info,
                    semantic_flags_info=semantic_flags_info,
                )

                # IMP-009: Apply commencement look-back boost
                if previous_routing_ids:
                    inst_id_normalized = self._normalize_instruction_id(instruction)
                    if inst_id_normalized in previous_routing_ids:
                        score += COMMENCEMENT_LOOKBACK_BOOST
                        score_breakdown["commencement_lookback"] = (
                            COMMENCEMENT_LOOKBACK_BOOST
                        )
                        logger.debug(
                            f"IMP-009: Boosted {instruction.id} by {COMMENCEMENT_LOOKBACK_BOOST}"
                        )

                # IMP-011: Apply friction boost
                if friction_info["detected"] and self.features.get(
                    "friction_boost", True
                ):
                    for inst_category in instruction.categories:
                        if inst_category in FRICTION_BOOST_CATEGORIES:
                            score += FRICTION_BOOST_AMOUNT
                            score_breakdown["friction_boost"] = {
                                "category": inst_category,
                                "boost": FRICTION_BOOST_AMOUNT,
                                "friction_type": friction_info.get("friction_type"),
                            }
                            logger.debug(
                                f"IMP-011: Friction boost for {instruction.id} by {FRICTION_BOOST_AMOUNT}"
                            )
                            break

                # IMP-012: Apply outcome boost
                if mistake_info["detected"] and self.features.get(
                    "outcome_boost", True
                ):
                    inst_filename = (
                        instruction.file_path.name
                        if hasattr(instruction, "file_path")
                        else ""
                    )
                    for preventive_inst in mistake_info.get("instruction_boosts", []):
                        if (
                            preventive_inst in inst_filename
                            or inst_filename in preventive_inst
                        ):
                            score += OUTCOME_BOOST_AMOUNT
                            score_breakdown["outcome_boost"] = {
                                "instruction": preventive_inst,
                                "boost": OUTCOME_BOOST_AMOUNT,
                                "mistake_type": mistake_info.get("mistake_type"),
                            }
                            logger.debug(
                                f"IMP-012: Outcome boost for {instruction.id} by {OUTCOME_BOOST_AMOUNT}"
                            )
                            break

                if score > 0:
                    result = instruction.to_dict()
                    result["routing_score"] = score
                    result["score_breakdown"] = score_breakdown
                    scored_instructions.append(result)
                    analysis["scoring_breakdown"].append(
                        {
                            "instruction_id": instruction.id,
                            "score": score,
                            "breakdown": score_breakdown,
                        }
                    )

            # IMP-007: Apply bundle boost
            bundle_boost_info = None
            if self.features.get("instruction_bundles", True):
                bundle_boost_info = self._apply_bundle_boost(scored_instructions)
                if bundle_boost_info.get("applied"):
                    analysis["bundle_boost"] = bundle_boost_info
                    logger.debug(f"IMP-007: Applied bundle boosts: {bundle_boost_info}")

            # Sort by score descending
            scored_instructions.sort(key=lambda x: x["routing_score"], reverse=True)

            # Get foundational instructions
            if self.features.get("foundational", True):
                foundational = self._get_foundational_instructions()
                foundational_ids = {inst.get("id") for inst in foundational}
                query_specific = [
                    inst
                    for inst in scored_instructions[:limit]
                    if inst.get("id") not in foundational_ids
                ]
                combined = foundational + query_specific
                analysis["foundational_count"] = len(foundational)
                analysis["foundational_ids"] = list(foundational_ids)
                analysis["query_specific_count"] = len(query_specific)
            else:
                combined = scored_instructions[:limit]
                analysis["foundational_count"] = 0
                analysis["foundational_ids"] = []
                analysis["foundational_disabled"] = True
                analysis["query_specific_count"] = len(combined)

            # IMP-010: Check for procedural instructions
            procedural_warning = None
            if self.features.get("procedural_warning", True):
                procedural_instructions = []
                for inst in combined:
                    inst_id = inst.get("id", "")
                    original_inst = self.instruction_handler.instructions.get(inst_id)
                    if original_inst:
                        procedural_info = self._is_procedural_instruction(original_inst)
                        if procedural_info["is_procedural"]:
                            score = inst.get("routing_score", 0)
                            if score >= PROCEDURAL_WARNING_THRESHOLD or inst.get(
                                "score_breakdown", {}
                            ).get("foundational"):
                                procedural_instructions.append(
                                    {
                                        "id": inst_id,
                                        "score": score,
                                        "detection_method": procedural_info[
                                            "detection_method"
                                        ],
                                        "referenced_doc": procedural_info[
                                            "referenced_doc"
                                        ],
                                    }
                                )

                if procedural_instructions:
                    warning_parts = [
                        "PROCEDURAL INSTRUCTION(S) ROUTED - READ BEFORE EXECUTING:"
                    ]
                    for proc_inst in procedural_instructions:
                        if proc_inst["referenced_doc"]:
                            warning_parts.append(
                                f"  - {proc_inst['id']}: Read `{proc_inst['referenced_doc']}` first"
                            )
                        else:
                            warning_parts.append(
                                f"  - {proc_inst['id']}: Read instruction file before executing"
                            )
                    procedural_warning = {
                        "warning": "\n".join(warning_parts),
                        "instructions": procedural_instructions,
                        "count": len(procedural_instructions),
                        "enforcement": "Read tool call required before action (Task #200 RCA)",
                    }
                    analysis["procedural_warning"] = procedural_warning
                    logger.info(
                        f"IMP-010: Procedural warning generated for {len(procedural_instructions)} instruction(s)"
                    )

            return {
                "instructions": combined,
                "count": len(combined),
                "routing_analysis": analysis,
                "procedural_warning": procedural_warning,
            }

        except Exception as e:
            logger.error(f"Error routing message: {e}", exc_info=True)
            return {
                "instructions": [],
                "count": 0,
                "routing_analysis": {"error": str(e)},
            }

    # =========================================================================
    # Detection Methods (Used by both routing and eval)
    # =========================================================================

    def _detect_violations(self, message: str) -> dict[str, Any]:
        """IMP-002: Detect violation signals in message."""
        signals = []
        message_lower = message.lower()

        words = re.findall(r"\b\w+\b", message_lower)
        violation_matches = set(words) & VIOLATION_WORDS
        if violation_matches:
            signals.append(f"violation_words:{','.join(violation_matches)}")

        for word in EMPHASIS_VIOLATION_WORDS:
            if re.search(rf"\b{word.upper()}\b", message):
                signals.append(f"emphasized_{word.upper()}")
            elif re.search(rf"\b{word}\s*!", message_lower):
                signals.append(f"exclaimed_{word}")
            elif re.search(rf"(?:^|[.!?]\s*){word}[,\s]", message_lower):
                signals.append(f"sentence_start_{word}")

        exclaim_count = message.count("!")
        if exclaim_count >= 3:
            signals.append(f"exclamation_density:{exclaim_count}")

        caps_words = [
            w for w in message.split() if w.isupper() and len(w) > 2 and w.isalpha()
        ]
        if len(caps_words) >= 2:
            signals.append(f"caps_emphasis:{','.join(caps_words[:3])}")

        boost_amount = VIOLATION_CATEGORY_BOOST * len(signals) if signals else 0

        return {
            "detected": len(signals) > 0,
            "signals": signals,
            "boost_amount": boost_amount,
        }

    def _is_simple_approval(self, message: str) -> tuple:
        """IMP-003: Detect if message is a simple approval."""
        message_clean = message.strip().lower()
        message_normalized = re.sub(r"[.!?,]+$", "", message_clean)

        for phrase in COMMENCEMENT_PHRASES:
            if message_clean.startswith(phrase) or f" {phrase}" in message_clean:
                logger.debug(
                    f"IMP-003: Commencement phrase detected, NOT suppressing: {message_clean}"
                )
                return (False, "commencement_phrase_detected", True)

        if message_normalized in APPROVAL_PATTERNS:
            logger.debug(
                f"IMP-003: Suppressing routing for approval pattern: {message_clean}"
            )
            return (True, "exact_approval_match", False)

        words = message_clean.split()
        if len(words) <= 3:
            if any(word.rstrip(".,!?") in APPROVAL_WORDS for word in words):
                logger.debug(
                    f"IMP-003: Suppressing routing for short approval: {message_clean}"
                )
                return (True, "short_approval_message", False)

        if len(words) <= 5:
            approval_count = sum(
                1 for word in words if word.rstrip(".,!?") in APPROVAL_WORDS
            )
            if approval_count >= len(words) / 2:
                logger.debug(
                    f"IMP-003: Suppressing routing for approval-dominated message: {message_clean}"
                )
                return (True, "approval_dominated_message", False)

        return (False, "not_approval", False)

    def _detect_semantic_flags(self, message: str) -> dict[str, Any]:
        """IMP-008: Detect semantic flags for category boosting."""
        flags = []
        category_boosts = {}

        for flag_name, config in COMPILED_SEMANTIC_FLAGS.items():
            if config["regex"].search(message):
                flags.append(flag_name)
                for category in config["boost_categories"]:
                    if category not in category_boosts:
                        category_boosts[category] = 0
                    category_boosts[category] += config["boost_amount"]

        if flags:
            logger.debug(
                f"IMP-008: Semantic flags detected: {flags}, category boosts: {category_boosts}"
            )

        return {
            "detected": len(flags) > 0,
            "flags": flags,
            "category_boosts": category_boosts,
        }

    def _detect_friction(self, message: str) -> dict[str, Any]:
        """IMP-011: Detect friction (correction/retry/rejection)."""
        signals = []
        friction_type = None

        for ftype in ["rejection", "retry", "correction"]:
            pattern = COMPILED_FRICTION_PATTERNS[ftype]
            match = pattern.search(message)
            if match:
                signals.append(f"{ftype}:{match.group()[:20]}")
                if friction_type is None:
                    friction_type = ftype

        if signals:
            logger.debug(
                f"IMP-011: Friction detected: type={friction_type}, signals={signals}"
            )

        category_boosts = {}
        if friction_type:
            for category in FRICTION_BOOST_CATEGORIES:
                category_boosts[category] = FRICTION_BOOST_AMOUNT

        return {
            "detected": len(signals) > 0,
            "friction_type": friction_type,
            "signals": signals,
            "category_boosts": category_boosts,
        }

    def _detect_mistake_type(self, message: str) -> dict[str, Any]:
        """IMP-012: Detect mistake types for targeted instruction boosting."""
        signals = []
        mistake_type = None
        instruction_boosts = []

        for mtype, pattern in COMPILED_MISTAKE_PATTERNS.items():
            match = pattern.search(message)
            if match:
                signals.append(f"{mtype}:{match.group()[:30]}")
                if mistake_type is None:
                    mistake_type = mtype
                    instruction_boosts = MISTAKE_INSTRUCTION_MAP.get(mtype, [])

        if signals:
            logger.debug(
                f"IMP-012: Mistake type detected: type={mistake_type}, signals={signals}, boosts={instruction_boosts}"
            )

        return {
            "detected": len(signals) > 0,
            "mistake_type": mistake_type,
            "signals": signals,
            "instruction_boosts": instruction_boosts,
        }

    def _detect_user_guidance(self, message: str) -> dict[str, Any]:
        """IMP-013: Detect user guidance (rules, preferences, feedback)."""
        signals = []
        guidance_type = None
        matched_content = None

        explicit_match = COMPILED_EXPLICIT_GUIDANCE.search(message)
        if explicit_match:
            matched_content = explicit_match.group()
            signals.append(f"explicit:{matched_content[:30]}")
            guidance_type = "explicit"
            logger.debug(f"IMP-013: Explicit guidance detected: {matched_content[:50]}")

        implicit_match = COMPILED_IMPLICIT_GUIDANCE.search(message)
        if implicit_match:
            implicit_content = implicit_match.group()
            signals.append(f"implicit:{implicit_content[:30]}")
            if guidance_type is None:
                guidance_type = "implicit"
                matched_content = implicit_content
            logger.debug(
                f"IMP-013: Implicit guidance detected: {implicit_content[:50]}"
            )

        if signals:
            logger.info(
                f"IMP-013: User guidance detected: type={guidance_type}, signals={len(signals)}"
            )

        return {
            "detected": len(signals) > 0,
            "guidance_type": guidance_type,
            "signals": signals,
            "content": matched_content,
        }

    def _detect_boundary(self, message: str) -> dict[str, Any]:
        """IMP-016: Detect conversation boundary (new topic vs continuation).

        Returns:
            dict with:
                - is_boundary: True if message starts new conversation
                - boundary_type: 'new_work', 'context_import', 'fresh_start', or None
                - signals: List of matched patterns
                - confidence: 'high' if explicit signal, 'low' if inferred
        """
        signals = []
        boundary_type = None

        for btype, compiled_pattern in COMPILED_BOUNDARY_PATTERNS.items():
            match = compiled_pattern.search(message)
            if match:
                matched_text = match.group()
                signals.append(f"{btype}:{matched_text[:30]}")
                if boundary_type is None:
                    boundary_type = btype
                logger.debug(
                    f"IMP-016: Boundary pattern matched: {btype}={matched_text[:50]}"
                )

        is_boundary = len(signals) > 0
        confidence = "high" if is_boundary else "low"

        if is_boundary:
            logger.info(
                f"IMP-016: Conversation boundary detected: type={boundary_type}, signals={len(signals)}"
            )

        return {
            "is_boundary": is_boundary,
            "boundary_type": boundary_type,
            "signals": signals,
            "confidence": confidence,
        }

    # =========================================================================
    # Helper Methods
    # =========================================================================

    def _get_foundational_instructions(self) -> list[dict]:
        """Return instructions marked as foundational."""
        foundational = []
        for instruction in self.instruction_handler.instructions.values():
            metadata = instruction.metadata or {}
            if metadata.get("foundational", False):
                result = instruction.to_dict()
                result["routing_score"] = FOUNDATIONAL_SCORE
                result["score_breakdown"] = {"foundational": True}
                foundational.append(result)
                logger.debug(f"Foundational instruction: {instruction.id}")
        return foundational

    def _get_previous_routing(self, context: dict | None = None) -> dict | None:
        """IMP-009: Get previous routing result for look-back."""
        if context and "previous_routing" in context:
            logger.debug("IMP-009: Using explicit previous_routing from context")
            return context["previous_routing"]

        db_paths = [
            Path.cwd() / ".pongogo" / "pongogo.db",
            Path.cwd().parent / ".pongogo" / "pongogo.db",
        ]

        for db_path in db_paths:
            if db_path.exists():
                try:
                    with get_connection(db_path, readonly=True) as conn:
                        row = conn.execute("""
                            SELECT routed_instructions, routing_scores
                            FROM routing_events
                            WHERE instruction_count > 0
                            ORDER BY timestamp DESC
                            LIMIT 1 OFFSET 1
                        """).fetchone()

                    if row and row[0]:
                        try:
                            instruction_ids = json.loads(row[0]) if row[0] else []
                        except json.JSONDecodeError:
                            instruction_ids = row[0].split(",") if row[0] else []
                        logger.debug(
                            f"IMP-009: Found previous routing with {len(instruction_ids)} instructions"
                        )
                        return {"instructions": instruction_ids}
                except Exception as e:
                    logger.warning(f"IMP-009: Error querying pongogo DB: {e}")
                    continue

        logger.debug("IMP-009: No previous routing found")
        return None

    def _normalize_instruction_id(self, instruction) -> str:
        """IMP-009: Normalize instruction ID to category/name format."""
        inst_id = instruction.id
        if inst_id.endswith(".instructions"):
            inst_id = inst_id[: -len(".instructions")]

        categories = instruction.categories or []
        if categories:
            return f"{categories[0]}/{inst_id}"
        else:
            return inst_id

    def _extract_keywords(self, message: str) -> list[str]:
        """Extract keywords from message."""
        message_lower = message.lower()
        message_clean = re.sub(r"[^\w\s]", " ", message_lower)
        words = message_clean.split()

        stop_words = {
            "the",
            "a",
            "an",
            "and",
            "or",
            "but",
            "in",
            "on",
            "at",
            "to",
            "for",
            "of",
            "with",
            "by",
            "from",
            "as",
            "is",
            "was",
            "are",
            "were",
            "be",
            "been",
            "being",
            "have",
            "has",
            "had",
            "do",
            "does",
            "did",
            "will",
            "would",
            "should",
            "could",
            "may",
            "might",
            "must",
            "can",
            "this",
            "that",
            "these",
            "those",
            "i",
            "you",
            "he",
            "she",
            "it",
            "we",
            "they",
        }

        keywords = [w for w in words if w not in stop_words and len(w) > 2]

        # IMP-013: Generate underscore-joined n-grams
        ngram_keywords = []
        for n in range(2, min(4, len(keywords) + 1)):
            for i in range(len(keywords) - n + 1):
                ngram = "_".join(keywords[i : i + n])
                ngram_keywords.append(ngram)

        return keywords + ngram_keywords

    def _extract_intent(self, message: str) -> str:
        """Extract intent from message."""
        message_lower = message.lower()

        if any(word in message_lower for word in ["how do i", "how to", "how can"]):
            return "how-to"
        elif any(word in message_lower for word in ["what is", "what are", "explain"]):
            return "explanation"
        elif any(word in message_lower for word in ["create", "add", "make", "build"]):
            return "creation"
        elif any(
            word in message_lower
            for word in ["fix", "debug", "error", "issue", "problem"]
        ):
            return "troubleshooting"
        elif any(word in message_lower for word in ["test", "validate", "check"]):
            return "validation"
        elif any(
            word in message_lower for word in ["document", "write docs", "readme"]
        ):
            return "documentation"

        return "general"

    def _score_instruction(
        self,
        instruction,
        message: str,
        keywords: list[str],
        intent: str,
        files: list[str],
        directories: list[str],
        branch: str,
        language: str,
        violation_info: dict | None = None,
        semantic_flags_info: dict | None = None,
    ) -> tuple:
        """Score instruction relevance using multiple signals."""
        score = 0
        breakdown = {}

        # IMP-002: Apply violation boost
        if violation_info and violation_info.get("detected"):
            for category in instruction.categories:
                if category in VIOLATION_BOOST_CATEGORIES:
                    score += violation_info["boost_amount"]
                    breakdown["violation_boost"] = {
                        "category": category,
                        "boost": violation_info["boost_amount"],
                        "signals": violation_info["signals"],
                    }
                    break

        # IMP-008: Apply semantic flag boost
        if semantic_flags_info and semantic_flags_info.get("detected"):
            category_boosts = semantic_flags_info.get("category_boosts", {})
            for category in instruction.categories:
                if category in category_boosts:
                    boost = category_boosts[category]
                    score += boost
                    if "semantic_flag_boost" not in breakdown:
                        breakdown["semantic_flag_boost"] = []
                    breakdown["semantic_flag_boost"].append(
                        {
                            "category": category,
                            "boost": boost,
                            "flags": semantic_flags_info.get("flags", []),
                        }
                    )

        # Keyword matching (+10 per keyword match)
        keyword_matches = []
        for keyword in keywords:
            if keyword in instruction.id.lower():
                score += 10
                keyword_matches.append(f"id:{keyword}")
            if keyword in instruction.description.lower():
                score += 8
                keyword_matches.append(f"description:{keyword}")
            for tag in instruction.tags:
                if keyword in tag.lower():
                    score += 5
                    keyword_matches.append(f"tag:{tag}")
            routing = instruction.routing or {}
            triggers = routing.get("triggers", {})
            meta_keywords = triggers.get("keywords", [])
            for meta_keyword in meta_keywords:
                meta_keyword_lower = meta_keyword.lower()
                if "_" in meta_keyword_lower:
                    if keyword == meta_keyword_lower:
                        score += 15
                        keyword_matches.append(f"metadata_keyword_exact:{meta_keyword}")
                else:
                    if keyword in meta_keyword_lower:
                        score += 10
                        keyword_matches.append(f"metadata_keyword:{meta_keyword}")

        if keyword_matches:
            breakdown["keyword_matches"] = keyword_matches

        # Category matching (+5 per category)
        category_matches = []
        for category in instruction.categories:
            if any(keyword in category.lower() for keyword in keywords):
                score += 5
                category_matches.append(category)
        if category_matches:
            breakdown["category_matches"] = category_matches

        # NLP trigger matching (+8)
        routing = instruction.routing or {}
        triggers = routing.get("triggers", {})
        nlp_trigger = triggers.get("nlp", "")
        if nlp_trigger:
            nlp_keywords = self._extract_keywords(nlp_trigger)
            overlap = set(keywords) & set(nlp_keywords)
            if overlap:
                score += 8 * len(overlap)
                breakdown["nlp_trigger_match"] = list(overlap)

        # Glob/path matching (+7 per file match)
        glob_matches = []
        apply_to = routing.get("applyTo", {})
        globs = apply_to.get("globs", [])
        for file_path in files:
            for glob_pattern in globs:
                if fnmatch.fnmatch(file_path, glob_pattern):
                    score += 7
                    glob_matches.append(f"{file_path} matches {glob_pattern}")
        if glob_matches:
            breakdown["glob_matches"] = glob_matches

        # Contextual matching (+5)
        contextual_matches = []
        contextual = routing.get("contextual", {})
        file_patterns = contextual.get("files", [])
        for file_path in files:
            for pattern in file_patterns:
                if fnmatch.fnmatch(file_path, pattern):
                    score += 5
                    contextual_matches.append(f"file_context:{file_path}")
        branch_patterns = contextual.get("branches", [])
        for pattern in branch_patterns:
            if fnmatch.fnmatch(branch, pattern):
                score += 5
                contextual_matches.append(f"branch_context:{branch}")
        if contextual_matches:
            breakdown["contextual_matches"] = contextual_matches

        # Tag matching (+3 per tag)
        tag_matches = []
        for tag in instruction.tags:
            if any(keyword in tag.lower() for keyword in keywords):
                score += 3
                tag_matches.append(tag)
        if tag_matches:
            breakdown["tag_matches"] = tag_matches

        breakdown["total_score"] = score
        return score, breakdown

    def _is_procedural_instruction(self, instruction) -> dict[str, Any]:
        """IMP-010: Detect if instruction is procedural."""
        metadata = instruction.metadata or {}

        if metadata.get("procedural", False):
            return {
                "is_procedural": True,
                "detection_method": "metadata_flag",
                "referenced_doc": None,
            }

        content = instruction.content or ""
        content_lower = content.lower()

        if "compliance gate" in content_lower or "compliance_gate" in content_lower:
            referenced_doc = None
            doc_match = re.search(r'[Rr]ead\s+[`"\']?([^`"\']+\.md)[`"\']?', content)
            if doc_match:
                referenced_doc = doc_match.group(1)
            return {
                "is_procedural": True,
                "detection_method": "compliance_gate",
                "referenced_doc": referenced_doc,
            }

        for pattern in COMPILED_PROCEDURAL_PATTERNS:
            if pattern.search(content):
                return {
                    "is_procedural": True,
                    "detection_method": "content_pattern",
                    "referenced_doc": None,
                }

        description_lower = instruction.description.lower()
        for keyword in PROCEDURAL_KEYWORDS:
            if keyword in description_lower:
                return {
                    "is_procedural": True,
                    "detection_method": f"keyword:{keyword}",
                    "referenced_doc": None,
                }

        return {
            "is_procedural": False,
            "detection_method": None,
            "referenced_doc": None,
        }

    def _apply_bundle_boost(self, scored_instructions: list[dict]) -> dict[str, Any]:
        """IMP-007: Apply bundle boost for co-occurring instruction pairs."""
        boosts_applied = []

        instruction_ids = set()
        for inst in scored_instructions:
            inst_id = inst.get("id", "")
            categories = inst.get("categories", [])
            if categories and "/" not in inst_id:
                normalized_id = f"{categories[0]}/{inst_id}"
            else:
                normalized_id = inst_id
            instruction_ids.add(normalized_id)
            if normalized_id.endswith(".instructions"):
                instruction_ids.add(normalized_id[: -len(".instructions")])

        for inst in scored_instructions:
            inst_id = inst.get("id", "")
            categories = inst.get("categories", [])

            ids_to_check = [inst_id]
            if categories:
                ids_to_check.append(f"{categories[0]}/{inst_id}")
            if inst_id.endswith(".instructions"):
                ids_to_check.append(inst_id[: -len(".instructions")])
                if categories:
                    ids_to_check.append(
                        f"{categories[0]}/{inst_id[:-len('.instructions')]}"
                    )

            for id_format in ids_to_check:
                if id_format in INSTRUCTION_BUNDLES:
                    bundle_partners = INSTRUCTION_BUNDLES[id_format]
                    for partner_id, boost_amount, co_occurrence_rate in bundle_partners:
                        if partner_id in instruction_ids:
                            for partner_inst in scored_instructions:
                                p_id = partner_inst.get("id", "")
                                p_categories = partner_inst.get("categories", [])
                                p_normalized = (
                                    f"{p_categories[0]}/{p_id}"
                                    if p_categories
                                    else p_id
                                )

                                if partner_id in (p_id, p_normalized):
                                    partner_inst["routing_score"] += boost_amount
                                    if "score_breakdown" not in partner_inst:
                                        partner_inst["score_breakdown"] = {}
                                    partner_inst["score_breakdown"]["bundle_boost"] = {
                                        "from": id_format,
                                        "boost": boost_amount,
                                        "co_occurrence_rate": co_occurrence_rate,
                                    }
                                    boosts_applied.append(
                                        {
                                            "trigger": id_format,
                                            "boosted": partner_id,
                                            "amount": boost_amount,
                                        }
                                    )
                                    break
                    break

        return {
            "applied": len(boosts_applied) > 0,
            "boosts": boosts_applied,
            "total_boosts": len(boosts_applied),
        }


# =============================================================================
