#!/usr/bin/env python3
"""
Extract instructions from seed/instructions.jsonl to markdown files.

Converts JSONL entries to individual markdown files for the Docker image.
"""

import argparse
import json
import sys
from pathlib import Path


def extract_instructions(
    jsonl_path: Path, output_dir: Path, verbose: bool = False
) -> int:
    """
    Extract instructions from JSONL to markdown files.

    Args:
        jsonl_path: Path to instructions.jsonl
        output_dir: Output directory for markdown files

    Returns:
        Number of files extracted
    """
    if not jsonl_path.exists():
        print(f"Error: {jsonl_path} not found", file=sys.stderr)
        return 0

    # Create output directory structure
    output_dir.mkdir(parents=True, exist_ok=True)

    count = 0
    categories = set()

    with open(jsonl_path) as f:
        for line in f:
            if not line.strip():
                continue

            entry = json.loads(line)

            # Get path from entry
            rel_path = entry.get("path", "")
            if not rel_path:
                print(
                    f"Warning: Entry missing path: {entry.get('id', 'unknown')}",
                    file=sys.stderr,
                )
                continue

            # Create category directory if needed
            file_path = output_dir / rel_path
            file_path.parent.mkdir(parents=True, exist_ok=True)

            # Write content
            content = entry.get("content", "")
            if not content:
                print(f"Warning: Entry missing content: {rel_path}", file=sys.stderr)
                continue

            with open(file_path, "w") as out:
                out.write(content)

            count += 1
            categories.add(entry.get("category", "unknown"))

            if verbose:
                print(f"  Extracted: {rel_path}")

    return count, categories


def main():
    parser = argparse.ArgumentParser(
        description="Extract instructions.jsonl to markdown files"
    )
    parser.add_argument(
        "jsonl_path",
        type=Path,
        nargs="?",
        default=Path("seed/instructions.jsonl"),
        help="Path to instructions.jsonl (default: seed/instructions.jsonl)",
    )
    parser.add_argument(
        "output_dir",
        type=Path,
        nargs="?",
        default=Path("build/instructions"),
        help="Output directory (default: build/instructions)",
    )
    parser.add_argument(
        "-v", "--verbose", action="store_true", help="Print each file as extracted"
    )
    args = parser.parse_args()

    print(f"Extracting {args.jsonl_path} → {args.output_dir}/")

    count, categories = extract_instructions(
        args.jsonl_path, args.output_dir, args.verbose
    )

    if count > 0:
        print(
            f"Extracted {count} instruction files across {len(categories)} categories"
        )
        return 0
    else:
        print("No files extracted", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
