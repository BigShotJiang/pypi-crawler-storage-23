#!/usr/bin/env python3
"""
Extract lexicon from seed/lexicon.jsonl to SQLite database.

Converts JSONL entries to a SQLite database for fast routing queries.
"""

import argparse
import json
import sqlite3
import sys
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS lexicon_entries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    entry_id TEXT UNIQUE NOT NULL,
    pattern TEXT NOT NULL,
    pattern_flags INTEGER DEFAULT 2,
    lexicon_type TEXT NOT NULL CHECK (lexicon_type IN ('guidance', 'friction', 'hedging')),
    category TEXT NOT NULL,
    sub_type TEXT,
    base_confidence REAL DEFAULT 0.75,
    positive_pattern TEXT,
    positive_weight REAL DEFAULT 0.0,
    negative_pattern TEXT,
    negative_weight REAL DEFAULT 0.0,
    disambiguation_threshold REAL DEFAULT 0.5,
    fallback_type TEXT DEFAULT 'none' CHECK (fallback_type IN ('none', 'implicit')),
    source TEXT DEFAULT 'system',
    notes TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
    enabled INTEGER DEFAULT 1
);

CREATE INDEX IF NOT EXISTS idx_lexicon_type ON lexicon_entries(lexicon_type);
CREATE INDEX IF NOT EXISTS idx_lexicon_category ON lexicon_entries(category);
CREATE INDEX IF NOT EXISTS idx_lexicon_enabled ON lexicon_entries(enabled);

CREATE TABLE IF NOT EXISTS schema_version (
    version INTEGER PRIMARY KEY,
    applied_at TEXT DEFAULT CURRENT_TIMESTAMP
);

INSERT OR IGNORE INTO schema_version (version) VALUES (1);
"""


def extract_lexicon(jsonl_path: Path, db_path: Path, verbose: bool = False) -> int:
    """
    Extract lexicon from JSONL to SQLite database.

    Args:
        jsonl_path: Path to lexicon.jsonl
        db_path: Output SQLite database path

    Returns:
        Number of entries extracted
    """
    if not jsonl_path.exists():
        print(f"Error: {jsonl_path} not found", file=sys.stderr)
        return 0

    # Create output directory if needed
    db_path.parent.mkdir(parents=True, exist_ok=True)

    # Remove existing database
    if db_path.exists():
        db_path.unlink()

    # Create database and schema
    conn = sqlite3.connect(db_path)
    conn.executescript(SCHEMA)

    count = 0
    type_counts = {"guidance": 0, "friction": 0, "hedging": 0}

    with open(jsonl_path) as f:
        for line in f:
            if not line.strip():
                continue

            entry = json.loads(line)

            # Insert entry
            conn.execute(
                """
                INSERT INTO lexicon_entries (
                    entry_id, pattern, pattern_flags, lexicon_type, category,
                    sub_type, base_confidence, positive_pattern, positive_weight,
                    negative_pattern, negative_weight, disambiguation_threshold,
                    fallback_type, source, notes, enabled
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
            """,
                (
                    entry.get("entry_id"),
                    entry.get("pattern"),
                    entry.get("pattern_flags", 2),
                    entry.get("lexicon_type"),
                    entry.get("category"),
                    entry.get("sub_type"),
                    entry.get("base_confidence", 0.75),
                    entry.get("positive_pattern"),
                    entry.get("positive_weight", 0.0),
                    entry.get("negative_pattern"),
                    entry.get("negative_weight", 0.0),
                    entry.get("disambiguation_threshold", 0.5),
                    entry.get("fallback_type", "none"),
                    entry.get("source", "system"),
                    entry.get("notes"),
                ),
            )

            count += 1
            lexicon_type = entry.get("lexicon_type", "unknown")
            if lexicon_type in type_counts:
                type_counts[lexicon_type] += 1

            if verbose:
                print(f"  Added: {entry.get('entry_id')}")

    conn.commit()
    conn.close()

    return count, type_counts


def main():
    parser = argparse.ArgumentParser(
        description="Extract lexicon.jsonl to SQLite database"
    )
    parser.add_argument(
        "jsonl_path",
        type=Path,
        nargs="?",
        default=Path("seed/lexicon.jsonl"),
        help="Path to lexicon.jsonl (default: seed/lexicon.jsonl)",
    )
    parser.add_argument(
        "db_path",
        type=Path,
        nargs="?",
        default=Path("build/src/mcp_server/lexicon.db"),
        help="Output database path (default: build/src/mcp_server/lexicon.db)",
    )
    parser.add_argument(
        "-v", "--verbose", action="store_true", help="Print each entry as extracted"
    )
    args = parser.parse_args()

    print(f"Extracting {args.jsonl_path} → {args.db_path}")

    count, type_counts = extract_lexicon(args.jsonl_path, args.db_path, args.verbose)

    if count > 0:
        print(f"Extracted {count} lexicon entries")
        print(
            f"  guidance: {type_counts['guidance']}, friction: {type_counts['friction']}, hedging: {type_counts['hedging']}"
        )
        return 0
    else:
        print("No entries extracted", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
