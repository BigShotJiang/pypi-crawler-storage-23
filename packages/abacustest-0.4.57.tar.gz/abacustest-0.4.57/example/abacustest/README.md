1. Fill in config in job.json
2. Run command `abacustest submit -j job.json`
3. After finish the running, the results can be found in 'result' folder (that is definded by save_path)
4. Run command `abacustest outresult -r result/metrics.json` to printout the results
