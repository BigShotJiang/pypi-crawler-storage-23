from .tracker import track_emissions, EmissionsTracker

__version__ = "0.1.5"
