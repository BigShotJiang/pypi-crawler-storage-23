from __future__ import annotations

from .element import Element


class Spacer(Element):
    focusable = False
