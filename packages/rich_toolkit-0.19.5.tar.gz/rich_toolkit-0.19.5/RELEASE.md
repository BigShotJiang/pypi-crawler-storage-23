---
release type: patch
---

Add `**metadata` support to the `progress()` method, aligning it with the other
`RichToolkit` methods (`print`, `input`, `confirm`, `ask`) that already accept
and forward metadata to the underlying components.
