# hledger-textual

[![PyPI](https://img.shields.io/pypi/v/hledger-textual?label=PyPI&color=blue)](https://pypi.org/project/hledger-textual/)
[![GitHub Release](https://img.shields.io/github/v/release/thesmokinator/hledger-textual?label=GitHub&color=blue)](https://github.com/thesmokinator/hledger-textual/releases)

A terminal user interface for managing [hledger](https://hledger.org) journal transactions. View, create, edit, and delete transactions from your terminal.

Built with [Textual](https://textual.textualize.io) and Python.

![hledger-textual summary](https://raw.githubusercontent.com/thesmokinator/hledger-textual/main/screenshots/001.png)

<table>
  <tr>
    <td><img src="https://raw.githubusercontent.com/thesmokinator/hledger-textual/main/screenshots/002.png" alt="Transactions" width="300"/></td>
    <td><img src="https://raw.githubusercontent.com/thesmokinator/hledger-textual/main/screenshots/003.png" alt="Transaction form" width="300"/></td>
    <td><img src="https://raw.githubusercontent.com/thesmokinator/hledger-textual/main/screenshots/004.png" alt="Recurring" width="300"/></td>
  </tr>
  <tr>
    <td><img src="https://raw.githubusercontent.com/thesmokinator/hledger-textual/main/screenshots/005.png" alt="Budget" width="300"/></td>
    <td><img src="https://raw.githubusercontent.com/thesmokinator/hledger-textual/main/screenshots/006.png" alt="Reports" width="300"/></td>
    <td><img src="https://raw.githubusercontent.com/thesmokinator/hledger-textual/main/screenshots/008.png" alt="Accounts" width="300"/></td>
  </tr>
</table>

## Stack

- **Python 3.12+**
- **Textual** - TUI framework
- **hledger** - plain-text accounting (must be installed separately)
- **uv** - package manager (no `requirements.txt` needed, dependencies are in `pyproject.toml`)
- **pytest** - testing

## Requirements

- Python 3.12+
- [hledger](https://hledger.org/install.html) installed and available in `PATH`

## Installation

```bash
# With pipx
pipx install hledger-textual

# With uv
uv tool install hledger-textual
```

## Usage

```bash
hledger-textual -f path/to/your.journal
```
rrr
The journal file is resolved in this order:

1. `-f` / `--file` CLI argument
2. `LEDGER_FILE` environment variable
3. `~/.config/hledger-textual/config.toml` (`journal_file` key)
4. `~/.hledger.journal`

## Documentation

See the [Wiki](https://github.com/thesmokinator/hledger-textual/wiki) for the full documentation: feature overview, configuration, investment tracking, and per-tab reference.

## Development

```bash
git clone https://github.com/thesmokinator/hledger-textual.git
cd hledger-textual
uv sync
```

### Testing

```bash
# Run all tests
uv run pytest

# Run with verbose output
uv run pytest -v

# Run with coverage report
uv run pytest --cov=hledger_textual --cov-report=term-missing
```
