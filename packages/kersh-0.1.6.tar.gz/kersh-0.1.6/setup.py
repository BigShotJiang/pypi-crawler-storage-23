from setuptools import setup, find_packages

setup(
    name='kersh',
    version='0.1.6',
    packages=find_packages(),
    install_requires=[
        'Pillow>=9.0.0',
    ],
    entry_points={
        'console_scripts': [
            'kersh=kersh.cli:main',
        ],
    },
    author="mohamed rabie",
    description="تم تعبئة الكرش بنجاح",
    python_requires='>=3.6',
    include_package_data=True,
)
