# Kersh

A Python library to convert images to clean, readable ASCII art with smooth terminal animations.

## Installation

```bash
pip install kersh
```

## Quick Start (Python Library)

The easiest way to use Kersh is with the `display` function, which handles conversion and printing automatically.

```python
from kersh import display

# Display an image with default settings
display("assets/original_kersh.jpg")
```

## Advanced Usage

For more control, you can customize width, styles, and animation speed.

```python
from kersh import display, GRADIENT_DETAILED

display(
    "assets/original_kersh.jpg", 
    width=120,            # High detail
    delay=0.02,           # Fast animation
    sharpness=2.5,        # Ultra sharp
    gradient=GRADIENT_DETAILED, # Use complex character set
    dither=True           # Enable high-quality dithering
)
```

### Manual Control

If you want to get the string first and print it later (or save it):

```python
from kersh import convert_image, print_art

# 1. Convert to string
art_string = convert_image("logo.png", width=80)

# ... do something else ...

# 2. Print with animation
print_art(art_string, delay=0.05, typewriter=True)
```

## CLI Usage

You can also use Kersh from the command line:

```bash
python -m kersh image.jpg --width 100
```
