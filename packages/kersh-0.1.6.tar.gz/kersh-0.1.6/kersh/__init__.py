__version__ = '0.1.2'

from .core import convert_image, print_art, display, GRADIENT_DEFAULT, GRADIENT_DETAILED, GRADIENT_BLOCK
