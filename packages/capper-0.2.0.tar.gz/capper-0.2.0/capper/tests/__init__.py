"""Capper test suite."""
