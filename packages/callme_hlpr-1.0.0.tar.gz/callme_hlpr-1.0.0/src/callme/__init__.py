"""
CallMe — AI agent that controls your computer via Telegram.

Quick start:
    callme init    # one-time setup wizard
    callme run     # start the agent
    callme stop    # stop it
    callme status  # check status
    callme doctor  # diagnose issues
"""
__version__ = "1.0.0"
__all__ = ["__version__"]
