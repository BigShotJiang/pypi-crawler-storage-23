"""Run data storage: CRUD on run metadata, attributes, trace info, and contexts."""

from __future__ import annotations

import time
from typing import TYPE_CHECKING, Any

from matyan_backend.fdb_types import transactional

from . import entities
from .encoding import decode_value, encode_value
from .fdb_client import get_directories
from .indexes import deindex_hparams, deindex_run, index_hparams, index_run, update_index_field
from .tree import _LEAF_SENTINEL, tree_get, tree_keys, tree_set

if TYPE_CHECKING:
    from matyan_backend.fdb_types import DirectorySubspace, Transaction

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _runs_dir() -> DirectorySubspace:
    return get_directories().runs


def _now() -> float:
    return time.time()


# ---------------------------------------------------------------------------
# Create / Get / Update / Delete
# ---------------------------------------------------------------------------


@transactional
def create_run(
    tr: Transaction,
    run_hash: str,
    *,
    name: str | None = None,
    experiment_id: str | None = None,
    description: str | None = None,
) -> dict:
    rd = _runs_dir()
    now = _now()
    meta = {
        "name": name or f"Run: {run_hash}",
        "description": description or "",
        "created_at": now,
        "updated_at": now,
        "finalized_at": None,
        "is_archived": False,
        "active": True,
        "experiment_id": experiment_id,
        "client_start_ts": None,
        "duration": None,
    }
    tree_set(tr, rd, (run_hash, "meta"), meta)

    exp_name: str | None = None
    if experiment_id:
        exp = entities.get_experiment(tr, experiment_id)
        if exp:
            exp_name = exp.get("name")

    index_run(
        tr,
        run_hash,
        is_archived=False,
        active=True,
        created_at=now,
        experiment_name=exp_name,
    )
    return {"hash": run_hash, **meta}


@transactional
def resume_run(tr: Transaction, run_hash: str) -> dict | None:
    """Re-activate an existing run without overwriting its metadata.

    Returns the updated run dict, or ``None`` if the run does not exist
    (caller should fall back to ``create_run``).
    """
    rd = _runs_dir()
    meta = tree_get(tr, rd, (run_hash, "meta"))
    if meta is None:
        return None

    update_run_meta(tr, run_hash, active=True, finalized_at=None)
    meta["active"] = True
    meta["finalized_at"] = None
    return {"hash": run_hash, **meta}


@transactional
def get_run(tr: Transaction, run_hash: str) -> dict | None:
    rd = _runs_dir()
    meta = tree_get(tr, rd, (run_hash, "meta"))
    if meta is None:
        return None
    return {"hash": run_hash, **meta}


@transactional
def get_run_meta(tr: Transaction, run_hash: str) -> dict:
    rd = _runs_dir()
    meta = tree_get(tr, rd, (run_hash, "meta"))
    return meta or {}


_INDEXED_META_FIELDS = {"is_archived": "archived", "active": "active"}


@transactional
def update_run_meta(tr: Transaction, run_hash: str, **fields: Any) -> None:  # noqa: ANN401
    rd = _runs_dir()

    for meta_key, idx_field in _INDEXED_META_FIELDS.items():
        if meta_key in fields:
            raw_old = tr[rd.pack((run_hash, "meta", meta_key, _LEAF_SENTINEL))]
            old_val = decode_value(raw_old) if raw_old.present() else None
            new_val = fields[meta_key]
            if old_val != new_val:
                update_index_field(tr, run_hash, idx_field, old_val, new_val)

    fields["updated_at"] = _now()
    for key, val in fields.items():
        tr[rd.pack((run_hash, "meta", key, _LEAF_SENTINEL))] = encode_value(val)


@transactional
def delete_run(tr: Transaction, run_hash: str) -> None:
    deindex_run(tr, run_hash)
    rd = _runs_dir()
    r = rd.range((run_hash,))
    del tr[r.start : r.stop]


@transactional
def list_run_hashes(tr: Transaction) -> list[str]:
    rd = _runs_dir()
    return [str(k) for k in tree_keys(tr, rd, ())]


# ---------------------------------------------------------------------------
# Attributes (nested user data — hparams etc.)
# ---------------------------------------------------------------------------


@transactional
def get_run_attrs(tr: Transaction, run_hash: str, path: tuple = ()) -> Any:  # noqa: ANN401
    rd = _runs_dir()
    full_path = (run_hash, "attrs", *path)
    return tree_get(tr, rd, full_path)


@transactional
def get_run_artifacts(tr: Transaction, run_hash: str) -> list[dict]:
    """Return raw file-artifact metadata stored under ``__blobs__``.

    Excludes custom-object blobs (images, audio) which are stored under
    ``seq/`` prefixed paths by the client's ``_upload_blob_if_needed``.
    Each entry has ``name``, ``path``, ``s3_key``, and ``content_type``.
    """
    rd = _runs_dir()
    blobs = tree_get(tr, rd, (run_hash, "attrs", "__blobs__"))
    if not isinstance(blobs, dict):
        return []
    result: list[dict] = []
    for artifact_path, meta in blobs.items():
        if not isinstance(meta, dict):
            continue
        if artifact_path.startswith("seq/"):
            continue
        result.append(
            {
                "name": artifact_path.rsplit("/", 1)[-1] if "/" in artifact_path else artifact_path,
                "path": artifact_path,
                "s3_key": meta.get("s3_key", ""),
                "content_type": meta.get("content_type", "application/octet-stream"),
            },
        )
    return result


@transactional
def set_run_attrs(tr: Transaction, run_hash: str, path: tuple, value: Any) -> None:  # noqa: ANN401
    rd = _runs_dir()
    full_path = (run_hash, "attrs", *path)
    tree_set(tr, rd, full_path, value)
    tr[rd.pack((run_hash, "meta", "updated_at", _LEAF_SENTINEL))] = encode_value(_now())

    if path == ("hparams",) and isinstance(value, dict):
        deindex_hparams(tr, run_hash)
        index_hparams(tr, run_hash, value)
    elif len(path) >= 1 and path[0] == "hparams":
        hparams = tree_get(tr, rd, (run_hash, "attrs", "hparams"))
        if isinstance(hparams, dict):
            deindex_hparams(tr, run_hash)
            index_hparams(tr, run_hash, hparams)


# ---------------------------------------------------------------------------
# Traces metadata
# ---------------------------------------------------------------------------


@transactional
def set_trace_info(
    tr: Transaction,
    run_hash: str,
    ctx_id: int,
    name: str,
    *,
    dtype: str,
    last: Any = None,  # noqa: ANN401
    last_step: int | None = None,
) -> None:
    rd = _runs_dir()
    base = (run_hash, "traces", ctx_id, name)
    tr[rd.pack((*base, "dtype"))] = encode_value(dtype)
    if last is not None:
        tr[rd.pack((*base, "last"))] = encode_value(last)
    if last_step is not None:
        tr[rd.pack((*base, "last_step"))] = encode_value(last_step)


@transactional
def get_run_traces_info(tr: Transaction, run_hash: str) -> list[dict]:
    rd = _runs_dir()
    r = rd.range((run_hash, "traces"))
    traces: dict[tuple[int, str], dict] = {}

    for kv in tr.get_range(r.start, r.stop):
        full_key = rd.unpack(kv.key)
        ctx_id = full_key[2]
        metric_name = full_key[3]
        field = full_key[4]
        ident = (ctx_id, metric_name)
        if ident not in traces:
            traces[ident] = {"name": metric_name, "context_id": ctx_id}
        traces[ident][field] = decode_value(kv.value)

    return list(traces.values())


# ---------------------------------------------------------------------------
# Contexts
# ---------------------------------------------------------------------------


@transactional
def set_context(tr: Transaction, run_hash: str, ctx_id: int, context: dict) -> None:
    rd = _runs_dir()
    tr[rd.pack((run_hash, "contexts", ctx_id))] = encode_value(context)


@transactional
def get_context(tr: Transaction, run_hash: str, ctx_id: int) -> dict | None:
    rd = _runs_dir()
    raw = tr[rd.pack((run_hash, "contexts", ctx_id))]
    if raw.present():
        return decode_value(raw)
    return None


@transactional
def get_all_contexts(tr: Transaction, run_hash: str) -> dict[int, dict]:
    rd = _runs_dir()
    r = rd.range((run_hash, "contexts"))
    result: dict[int, dict] = {}
    for kv in tr.get_range(r.start, r.stop):
        ctx_id = rd.unpack(kv.key)[2]
        result[ctx_id] = decode_value(kv.value)
    return result


# ---------------------------------------------------------------------------
# Run ↔ Tag associations (stored in runs_dir for co-location)
# ---------------------------------------------------------------------------


@transactional
def add_tag_to_run(tr: Transaction, run_hash: str, tag_uuid: str) -> None:
    rd = _runs_dir()
    tr[rd.pack((run_hash, "tags", tag_uuid))] = encode_value(True)


@transactional
def remove_tag_from_run(tr: Transaction, run_hash: str, tag_uuid: str) -> None:
    rd = _runs_dir()
    del tr[rd.pack((run_hash, "tags", tag_uuid))]


@transactional
def get_run_tag_uuids(tr: Transaction, run_hash: str) -> list[str]:
    rd = _runs_dir()
    r = rd.range((run_hash, "tags"))
    return [rd.unpack(kv.key)[2] for kv in tr.get_range(r.start, r.stop)]


@transactional
def set_run_experiment(tr: Transaction, run_hash: str, experiment_id: str | None) -> None:
    rd = _runs_dir()
    tr[rd.pack((run_hash, "meta", "experiment_id", _LEAF_SENTINEL))] = encode_value(experiment_id)
    tr[rd.pack((run_hash, "meta", "updated_at", _LEAF_SENTINEL))] = encode_value(_now())


@transactional
def list_runs_meta(tr: Transaction) -> list[dict]:
    """Return metadata dicts for all runs (used by project-level aggregations)."""
    hashes = list_run_hashes(tr)
    results: list[dict] = []
    for h in hashes:
        meta = get_run_meta(tr, h)
        if meta:
            meta["hash"] = h
            results.append(meta)
    return results
