from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env")

    server_url: str = "http://localhost:53800"

    # FoundationDB
    fdb_cluster_file: str = "fdb.cluster"
    fdb_api_version: int = 730

    # S3 (RustFS in dev, AWS S3 in prod)
    s3_endpoint: str = "http://localhost:9000"
    s3_access_key: str = "rustfsadmin"
    s3_secret_key: str = "rustfsadmin"  # noqa: S105
    s3_bucket: str = "matyan-artifacts"

    # Blob URI encryption key (Fernet URL-safe base64-encoded 32 bytes)
    blob_uri_secret: str = "Juw5-cLlemQI2jAWvceOUB3_CrVfBmI99YIzkpGUXR4="  # noqa: S105

    # Kafka
    kafka_bootstrap_servers: str = "localhost:9092"
    kafka_data_ingestion_topic: str = "data-ingestion"
    kafka_control_events_topic: str = "control-events"

    # CORS
    cors_origins: tuple[str, ...] = (
        "http://localhost:3000",
        "http://localhost:8000",
        "http://localhost:8080",
        "http://127.0.0.1:8000",
        "http://localhost:53800",
        "http://127.0.0.1:53800",
    )


SETTINGS = Settings()
