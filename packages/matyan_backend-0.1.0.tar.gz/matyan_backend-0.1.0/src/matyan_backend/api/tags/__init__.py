from ._main import tags_router

__all__ = ["tags_router"]
