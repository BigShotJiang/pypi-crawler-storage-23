from __future__ import annotations

from fastapi import APIRouter, HTTPException

from matyan_backend.deps import FdbDb  # noqa: TC001
from matyan_backend.storage import entities

from .pydantic_models import DashboardCreateIn, DashboardOut, DashboardUpdateIn

dashboards_router = APIRouter()


def _dash_to_out(d: dict, db: object | None = None) -> dict:
    app_type: str | None = None
    app_id = d.get("app_id")
    if app_id and db is not None:
        app = entities.get_dashboard_app(db, app_id)
        if app:
            app_type = app.get("type")
    return {
        "id": d["id"],
        "name": d.get("name", ""),
        "description": d.get("description"),
        "app_id": app_id,
        "app_type": app_type,
        "updated_at": d.get("updated_at"),
        "created_at": d.get("created_at"),
    }


@dashboards_router.get("/", response_model=list[DashboardOut])
async def get_dashboards_api(db: FdbDb) -> list[dict]:
    dashboards = entities.list_dashboards(db)
    return [_dash_to_out(d, db) for d in dashboards if not d.get("is_archived")]


@dashboards_router.post("/", response_model=DashboardOut, status_code=201)
async def create_dashboard_api(body: DashboardCreateIn, db: FdbDb) -> dict:
    d = entities.create_dashboard(
        db,
        body.name,
        description=body.description,
        app_id=str(body.app_id) if body.app_id else None,
    )
    return _dash_to_out(d, db)


@dashboards_router.get("/{dashboard_id}/", response_model=DashboardOut)
async def get_dashboard_api(dashboard_id: str, db: FdbDb) -> dict:
    d = entities.get_dashboard(db, dashboard_id)
    if not d:
        raise HTTPException(status_code=404)
    return _dash_to_out(d, db)


@dashboards_router.put("/{dashboard_id}/", response_model=DashboardOut)
async def update_dashboard_api(dashboard_id: str, body: DashboardUpdateIn, db: FdbDb) -> dict:
    d = entities.get_dashboard(db, dashboard_id)
    if not d:
        raise HTTPException(status_code=404)
    updates = {}
    if body.name is not None:
        updates["name"] = body.name
    if body.description is not None:
        updates["description"] = body.description
    if updates:
        entities.update_dashboard(db, dashboard_id, **updates)
    updated = entities.get_dashboard(db, dashboard_id)
    if not updated:
        raise HTTPException(status_code=404)
    return _dash_to_out(updated, db)


@dashboards_router.delete("/{dashboard_id}/", status_code=204, response_model=None)
async def delete_dashboard_api(dashboard_id: str, db: FdbDb) -> None:
    d = entities.get_dashboard(db, dashboard_id)
    if not d:
        raise HTTPException(status_code=404)
    entities.update_dashboard(db, dashboard_id, is_archived=True)
