from __future__ import annotations

from typing import Annotated, Literal

from fastapi import APIRouter, Header

from matyan_backend.deps import FdbDb  # noqa: TC001
from matyan_backend.storage import project as project_store

from ._pydantic_models import (
    ProjectActivityApiResponse,
    ProjectApiResponse,
    ProjectParamsOut,
    ProjectPinnedSequencesApiIn,
    ProjectPinnedSequencesApiResponse,
)

rest_router_projects = APIRouter(prefix="/projects")


@rest_router_projects.get("/", response_model=ProjectApiResponse)
async def get_project_api(db: FdbDb) -> dict:
    return project_store.get_project_info(db)


@rest_router_projects.get("/activity/", response_model=ProjectActivityApiResponse)
async def get_project_activity_api(
    db: FdbDb,
    x_timezone_offset: Annotated[int, Header()] = 0,
) -> dict:
    return project_store.get_project_activity(db, tz_offset=x_timezone_offset)


@rest_router_projects.get(
    "/params/",
    response_model=ProjectParamsOut,
    response_model_exclude_none=True,
)
async def get_project_params_api(
    db: FdbDb,
    sequence: tuple[str, ...] = (),
    exclude_params: bool = False,
) -> dict:
    result = project_store.get_project_params(db, sequence_types=sequence)
    if exclude_params:
        result.pop("params", None)
    return result


@rest_router_projects.get("/pinned-sequences/", response_model=ProjectPinnedSequencesApiResponse)
async def get_pinned_sequences_api(db: FdbDb) -> dict[str, list]:
    seqs = project_store.get_pinned_sequences(db)
    return {"sequences": seqs}


@rest_router_projects.post("/pinned-sequences/", response_model=ProjectPinnedSequencesApiResponse)
async def update_pinned_sequences_api(body: ProjectPinnedSequencesApiIn, db: FdbDb) -> dict[str, list]:
    raw = [s.model_dump() for s in body.sequences]
    saved = project_store.set_pinned_sequences(db, raw)
    return {"sequences": saved}


@rest_router_projects.get("/status/")
async def get_project_status_api() -> Literal["up-to-date"]:
    return "up-to-date"
