"""
Highflame Policy Schemas - Service-specific Cedar schemas and context metadata.

Schemas are bundled as package data and loaded using importlib.resources. The schema
files are copied from schemas/ to packages/python/highflame_policy/_schemas/ during
codegen (see Makefile). This ensures the package is self-contained and works correctly
when installed from PyPI.
"""

from importlib.resources import files

# Import service-specific context keys
from .overwatch_context import OverwatchContextKey
from .palisade_context import PalisadeContextKey

# =============================================================================
# OVERWATCH (GUARDIAN) SCHEMA
# =============================================================================

# Load Overwatch Cedar schema
overwatch_schema = (
    files('highflame_policy._schemas.overwatch')
    .joinpath('schema.cedarschema')
    .read_text(encoding='utf-8')
)

# Load Overwatch context metadata (for UI)
overwatch_context = (
    files('highflame_policy._schemas.overwatch')
    .joinpath('context.json')
    .read_text(encoding='utf-8')
)

# =============================================================================
# PALISADE SCHEMA
# =============================================================================

# Load Palisade Cedar schema
palisade_schema = (
    files('highflame_policy._schemas.palisade')
    .joinpath('schema.cedarschema')
    .read_text(encoding='utf-8')
)

# Load Palisade context metadata (for UI)
palisade_context = (
    files('highflame_policy._schemas.palisade')
    .joinpath('context.json')
    .read_text(encoding='utf-8')
)

# Export all schemas
__all__ = [
    'overwatch_schema',
    'overwatch_context',
    'palisade_schema',
    'palisade_context',
    'OverwatchContextKey',
    'PalisadeContextKey',
]
