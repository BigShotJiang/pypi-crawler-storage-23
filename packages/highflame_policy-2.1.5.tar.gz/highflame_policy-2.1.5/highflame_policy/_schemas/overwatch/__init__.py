"""Overwatch schema and template data files."""
