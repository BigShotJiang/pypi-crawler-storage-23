"""
Kaalavidya — Panchanga Test

Runs panchanga calculation for known dates and prints results
for manual verification against Drik Panchang / JyotishApp.

Test cases:
  1. Dec 3, 1998, Vijayawada — user's reference date
  2. Today's date, Vijayawada — easy to cross-check online
"""

import sys
import os

# Add parent directory to path so we can import kaalavidya
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from kaalavidya import Panchanga


def test_vijayawada_1998():
    """December 3, 1998 — Vijayawada, Andhra Pradesh."""
    print("=" * 60)
    print("TEST: December 3, 1998 — Vijayawada, AP")
    print("=" * 60)

    p = Panchanga(
        year=1998, month=12, day=3,
        latitude=16.5062, longitude=80.648,
        timezone="Asia/Kolkata",
        city="Vijayawada",
    )
    result = p.compute()
    print(result.summary())
    print()


def test_vijayawada_1998_telugu():
    """Same date, in Telugu."""
    print("=" * 60)
    print("TEST: December 3, 1998 — Vijayawada (Telugu)")
    print("=" * 60)

    p = Panchanga(
        year=1998, month=12, day=3,
        latitude=16.5062, longitude=80.648,
        timezone="Asia/Kolkata",
        city="Vijayawada",
        lang="te",
    )
    result = p.compute()
    print(result.summary())
    print()


def test_today_vijayawada():
    """Today's date — for cross-checking with Drik Panchang."""
    from datetime import date
    today = date.today()

    print("=" * 60)
    print(f"TEST: {today.strftime('%B %d, %Y')} — Vijayawada, AP")
    print("=" * 60)

    p = Panchanga(
        year=today.year, month=today.month, day=today.day,
        latitude=16.5062, longitude=80.648,
        timezone="Asia/Kolkata",
        city="Vijayawada",
    )
    result = p.compute()
    print(result.summary())
    print()


def test_maudhya():
    """
    Test Guru/Shukra Maudhya (combustion) detection.

    Known combustion:
      - Shukra Maudhya ~Mar 2025 (Venus near Sun in Pisces/Aries)
      - Guru Maudhya ~June 2025 (Jupiter near Sun in Taurus/Gemini)
    We also check a date where neither is combust as a negative test.
    """
    print("=" * 60)
    print("TEST: Maudhya (Combustion) Detection")
    print("=" * 60)

    # Date when Shukra should be combust (~March 22, 2025)
    print("\n--- Mar 22, 2025 (expect Shukra Maudhya) ---")
    p = Panchanga(
        year=2025, month=3, day=22,
        latitude=16.5062, longitude=80.648,
        timezone="Asia/Kolkata", city="Vijayawada",
    )
    result = p.compute()
    for m in result.maudhya:
        status = "⚠ COMBUST" if m.is_combust else "  Not combust"
        retro = " (R)" if m.is_retrograde else ""
        period = ""
        if m.period_start and m.period_end:
            period = f"  Period: {m.period_start} → {m.period_end}"
        print(f"  {m.planet:<20s} {status}  sep={m.separation_deg:.1f}° limit={m.combustion_limit:.0f}°{retro}{period}")

    # Date when Guru should be combust (~June 10, 2025)
    print("\n--- Jun 10, 2025 (expect Guru Maudhya) ---")
    p2 = Panchanga(
        year=2025, month=6, day=10,
        latitude=16.5062, longitude=80.648,
        timezone="Asia/Kolkata", city="Vijayawada",
    )
    result2 = p2.compute()
    for m in result2.maudhya:
        status = "⚠ COMBUST" if m.is_combust else "  Not combust"
        retro = " (R)" if m.is_retrograde else ""
        period = ""
        if m.period_start and m.period_end:
            period = f"  Period: {m.period_start} → {m.period_end}"
        print(f"  {m.planet:<20s} {status}  sep={m.separation_deg:.1f}° limit={m.combustion_limit:.0f}°{retro}{period}")

    # Dec 3, 1998 — our benchmark date
    print("\n--- Dec 3, 1998 (benchmark date) ---")
    p3 = Panchanga(
        year=1998, month=12, day=3,
        latitude=16.5062, longitude=80.648,
        timezone="Asia/Kolkata", city="Vijayawada",
    )
    result3 = p3.compute()
    for m in result3.maudhya:
        status = "⚠ COMBUST" if m.is_combust else "  Not combust"
        retro = " (R)" if m.is_retrograde else ""
        period = ""
        if m.period_start and m.period_end:
            period = f"  Period: {m.period_start} → {m.period_end}"
        print(f"  {m.planet:<20s} {status}  sep={m.separation_deg:.1f}° limit={m.combustion_limit:.0f}°{retro}{period}")
    print()


if __name__ == "__main__":
    test_vijayawada_1998()
    test_vijayawada_1998_telugu()
    test_today_vijayawada()
    test_maudhya()
