"""
Kaalavidya (कालविद्या) — The Science of Time

A Python library for accurate Indian Panchanga calculations.
Computes tithi, nakshatra, yoga, karana, lagna, and more
using Swiss Ephemeris (Drik) or Surya Siddhanta (Siddhantic).

Usage:
    from kaalavidya import Panchanga

    # Drik (modern, default)
    p = Panchanga(year=1998, month=12, day=3, latitude=16.5062, longitude=80.648)
    print(p.compute().summary())

    # Side-by-side comparison with Surya Siddhanta
    p = Panchanga(..., method="both")
    print(p.compute().summary())
"""

from kaalavidya.panchanga import Panchanga
from kaalavidya.chart import compute_sunrise_chart, compute_orrery_data, SunriseChart, GrahaPosition
from kaalavidya.grahana import find_eclipses_in_year
from kaalavidya.models import MaudhyaInfo, MasaInfo, EclipseInfo, DailyPanchanga
from kaalavidya.surya_siddhanta import compute_full_ss_panchanga
from kaalavidya.chandra import (
    compute_tithi, compute_nakshatra, compute_yoga, compute_karana,
    compute_moon_rashi, compute_sun_rashi, compute_masa,
    compute_maudhya, compute_tarabalam, compute_chandrabalam,
)
from kaalavidya.surya import (
    compute_sun_times, compute_rahu_kala, compute_yamagandam,
    compute_gulika_kala, compute_brahma_muhurta, compute_abhijit_muhurta,
    compute_durmuhurta, compute_varjyam, compute_amrit_kalam,
    compute_dina_muhurtas, compute_ratri_muhurtas, compute_hora_table,
    compute_moonrise_moonset,
)
from kaalavidya.lagna import compute_lagna_table
from kaalavidya.sankalpa import generate_sankalpa, is_indian_location

__version__ = "0.2.2"
__all__ = [
    # ── Full Panchanga ──
    "Panchanga",
    "DailyPanchanga",
    # ── Individual Computations (pick what you need) ──
    "compute_tithi",
    "compute_nakshatra",
    "compute_yoga",
    "compute_karana",
    "compute_moon_rashi",
    "compute_sun_rashi",
    "compute_masa",
    "compute_maudhya",
    "compute_tarabalam",
    "compute_chandrabalam",
    # ── Sun & Time ──
    "compute_sun_times",
    "compute_rahu_kala",
    "compute_yamagandam",
    "compute_gulika_kala",
    "compute_brahma_muhurta",
    "compute_abhijit_muhurta",
    "compute_durmuhurta",
    "compute_varjyam",
    "compute_amrit_kalam",
    "compute_dina_muhurtas",
    "compute_ratri_muhurtas",
    "compute_hora_table",
    "compute_moonrise_moonset",
    # ── Lagna ──
    "compute_lagna_table",
    # ── Chart & Orrery ──
    "compute_sunrise_chart",
    "compute_orrery_data",
    "SunriseChart",
    "GrahaPosition",
    # ── Eclipses ──
    "find_eclipses_in_year",
    # ── Surya Siddhanta ──
    "compute_full_ss_panchanga",
    # ── Sankalpa ──
    "generate_sankalpa",
    "is_indian_location",
    # ── Data Models ──
    "MaudhyaInfo",
    "MasaInfo",
    "EclipseInfo",
]
