"""Typed interfaces shared across the Azure discovery tool."""

from .errors import (
    AzureClientError,
    InvalidTargetError,
    VisualizationError,
)
from .models import (
    AzureDiscoveryRequest,
    AzureDiscoveryResponse,
    AzureEnvironment,
    AzureEnvironmentConfig,
    ComplianceControl,
    ComplianceMapping,
    DiscoveryFilter,
    DiscoveryMergeMetrics,
    DiscoveryMetrics,
    DiscoveryPhaseMetrics,
    PolicyControlEvidence,
    PolicyInitiativeInfo,
    PolicyStateEvidence,
    ResourceNode,
    ResourceRelationship,
    ScaleControlConfig,
    VisualizationOptions,
    VisualizationResponse,
)

__all__ = [
    "AzureClientError",
    "InvalidTargetError",
    "VisualizationError",
    "AzureDiscoveryRequest",
    "AzureDiscoveryResponse",
    "AzureEnvironment",
    "AzureEnvironmentConfig",
    "DiscoveryFilter",
    "DiscoveryMergeMetrics",
    "DiscoveryMetrics",
    "DiscoveryPhaseMetrics",
    "ResourceNode",
    "ResourceRelationship",
    "VisualizationOptions",
    "VisualizationResponse",
]
