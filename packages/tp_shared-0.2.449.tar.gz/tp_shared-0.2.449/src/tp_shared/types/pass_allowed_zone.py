from enum import Enum, StrEnum
from typing import Any

from pydantic import GetCoreSchemaHandler
from pydantic_core import CoreSchema, core_schema


class PassAllowedZone(str, Enum):
    MKAD = "МКАД"
    SK = "СК"
    TTK = "ТТК"
    MO = "МО"

    @classmethod
    def _missing_(cls, value: str):
        if value.lower() == "московская область":
            return cls.MO
        elif value.lower() == "садовое кольцо":
            return cls.SK
        return None

    @classmethod
    def __get_pydantic_core_schema__(
        cls, source_type: Any, handler: GetCoreSchemaHandler
    ) -> CoreSchema:
        return core_schema.no_info_plain_validator_function(
            cls._pydantic_validate,
            serialization=core_schema.to_string_ser_schema(),
        )

    @classmethod
    def _pydantic_validate(cls, value: Any) -> "PassAllowedZone":
        if isinstance(value, cls):
            return value
        try:
            return cls(value)
        except ValueError:
            raise ValueError(f"{value!r} is not a valid {cls.__name__}")


class PassAllowedZoneEn(StrEnum):
    MO = "MO"
    MKAD = "MKAD"
    TTK = "TTK"
    SK = "SK"
    NoZone = "NoZone"
