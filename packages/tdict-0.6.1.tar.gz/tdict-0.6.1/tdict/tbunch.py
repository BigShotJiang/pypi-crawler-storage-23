from .bunch import Bunch
from .tmap import Tmap

class Tbunch(Tmap, Bunch):
    pass
