A tree of `Mapping`s.
