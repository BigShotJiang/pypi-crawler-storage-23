"""
Airflow 3.0+ Example DAGs

This directory contains example DAGs specifically for Airflow 3.0+.
These DAGs use native Airflow 3.0 syntax without compatibility layers.

For Airflow 2.x examples, see the ../airflow2/ directory.
"""
