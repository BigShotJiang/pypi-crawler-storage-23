"""
Airflow 2.x Example DAGs

This directory contains example DAGs for Airflow 2.x.
These DAGs use compatibility layers to work across multiple Airflow 2.x versions.

For Airflow 3.0+ examples, see the ../airflow3/ directory.
"""
