#!/bin/bash
echo "Script executed successfully"
exit 0
