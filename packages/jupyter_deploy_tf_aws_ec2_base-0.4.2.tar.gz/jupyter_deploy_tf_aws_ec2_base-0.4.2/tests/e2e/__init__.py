"""End-to-end tests for jupyter-deploy-tf-aws-ec2-base template."""
