"""AWS EC2 Terraform preset for Jupyter deployment using your own domain.

Relies on traefik for proxy, letsencrypt to generate the TLS certificate
and external oauth provider.
"""

__version__ = "0.4.2"
