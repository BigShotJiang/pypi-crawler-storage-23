"""GitLab CI Optimizer - Analyze and optimize GitLab CI configurations."""

__version__ = "0.1.0"
