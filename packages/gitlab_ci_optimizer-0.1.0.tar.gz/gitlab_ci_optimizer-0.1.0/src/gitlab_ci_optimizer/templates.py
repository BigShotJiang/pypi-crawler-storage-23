"""Template generator for GitLab CI pipelines."""

from typing import Dict, Any


TEMPLATES = {
    "node": {
        "image": "node:20",
        "stages": ["install", "test", "build", "deploy"],
        "variables": {
            "NPM_CONFIG_CACHE": "$CI_PROJECT_DIR/.npm",
        },
        "cache": {
            "key": "$CI_COMMIT_REF_SLUG",
            "paths": ["node_modules/", ".npm/"],
        },
    },
    "python": {
        "image": "python:3.11",
        "stages": ["install", "test", "build", "deploy"],
        "variables": {
            "PIP_CACHE_DIR": "$CI_PROJECT_DIR/.cache/pip",
        },
        "cache": {
            "key": "$CI_COMMIT_REF_SLUG",
            "paths": [".cache/pip/", "venv/"],
        },
    },
    "docker": {
        "image": "docker:24",
        "services": ["docker:24-dind"],
        "stages": ["build", "test", "deploy"],
        "variables": {
            "DOCKER_TLS_CERTDIR": "/certs",
        },
    },
    "go": {
        "image": "golang:1.21",
        "stages": ["install", "test", "build", "deploy"],
        "variables": {
            "GOPATH": "$CI_PROJECT_DIR/.go",
        },
        "cache": {
            "key": "$CI_COMMIT_REF_SLUG",
            "paths": [".go/pkg/mod/"],
        },
    },
    "rust": {
        "image": "rust:1.75",
        "stages": ["build", "test", "deploy"],
        "cache": {
            "key": "$CI_COMMIT_REF_SLUG",
            "paths": ["target/"],
        },
    },
    "java": {
        "image": "eclipse-temurin:17",
        "stages": ["build", "test", "deploy"],
        "cache": {
            "key": "$CI_COMMIT_REF_SLUG",
            "paths": [".m2/repository/", "target/"],
        },
    },
}

JOB_TEMPLATES = {
    "node": {
        "install": {
            "script": ["npm ci --cache .npm --prefer-offline"],
            "cache": {"key": "$CI_COMMIT_REF_SLUG", "paths": ["node_modules/"], "policy": "pull-push"},
        },
        "test": {
            "script": ["npm test"],
            "artifacts": {"paths": ["coverage/"], "expire_in": "1 week"},
            "needs": ["install"],
        },
        "build": {
            "script": ["npm run build"],
            "artifacts": {"paths": ["dist/"], "expire_in": "1 week"},
            "needs": ["test"],
        },
    },
    "python": {
        "install": {
            "script": ["python -m venv venv", ". venv/bin/activate", "pip install -r requirements.txt"],
            "cache": {"key": "$CI_COMMIT_REF_SLUG", "paths": [".cache/pip/", "venv/"], "policy": "pull-push"},
        },
        "test": {
            "script": ["pytest --cov=src --cov-report=xml"],
            "artifacts": {"paths": ["coverage/", "*.xml"], "expire_in": "1 week"},
            "needs": ["install"],
        },
        "build": {
            "script": ["python -m build"],
            "artifacts": {"paths": ["dist/"], "expire_in": "1 week"},
            "needs": ["test"],
        },
    },
    "docker": {
        "build": {
            "script": ["docker build -t $IMAGE_TAG ."],
            "services": ["docker:24-dind"],
        },
        "test": {
            "script": ["docker run $IMAGE_TAG test"],
            "needs": ["build"],
        },
        "deploy": {
            "script": ["docker push $IMAGE_TAG"],
            "needs": ["test"],
        },
    },
    "go": {
        "install": {
            "script": ["go mod download"],
            "cache": {"key": "$CI_COMMIT_REF_SLUG", "paths": [".go/pkg/mod/"], "policy": "pull-push"},
        },
        "test": {
            "script": ["go test -v ./..."],
            "artifacts": {"paths": ["coverage.txt"], "expire_in": "1 week"},
            "needs": ["install"],
        },
        "build": {
            "script": ["go build -o app ."],
            "artifacts": {"paths": ["app"], "expire_in": "1 week"},
            "needs": ["test"],
        },
    },
    "rust": {
        "build": {
            "script": ["cargo build --release"],
            "cache": {"key": "$CI_COMMIT_REF_SLUG", "paths": ["target/"], "policy": "pull-push"},
        },
        "test": {
            "script": ["cargo test"],
            "needs": ["build"],
        },
    },
    "java": {
        "build": {
            "script": ["./mvnw package -DskipTests"],
            "cache": {"key": "$CI_COMMIT_REF_SLUG", "paths": [".m2/repository/"], "policy": "pull-push"},
        },
        "test": {
            "script": ["./mvnw test"],
            "artifacts": {"paths": ["target/surefire-reports/"], "expire_in": "1 week"},
            "needs": ["build"],
        },
    },
}


def generate_template(lang: str, verbose: bool = False) -> str:
    """Generate a GitLab CI pipeline template.
    
    Args:
        lang: Language/framework (node, python, docker, go, rust, java)
        verbose: Include verbose output in template
        
    Returns:
        YAML string for .gitlab-ci.yml
    """
    import yaml
    
    if lang not in TEMPLATES:
        raise ValueError(f"Unknown template: {lang}. Available: {', '.join(TEMPLATES.keys())}")
    
    config = TEMPLATES[lang].copy()
    jobs = {}
    
    if lang in JOB_TEMPLATES:
        for job_name, job_config in JOB_TEMPLATES[lang].items():
            jobs[job_name] = job_config.copy()
    
    config.update(jobs)
    
    output = yaml.dump(config, default_flow_style=False, sort_keys=False, allow_unicode=True)
    
    header = f"""# GitLab CI Pipeline Template - {lang.upper()}
# Generated by gitlab-ci-optimizer
# Customize as needed for your project

"""
    
    return header + output
