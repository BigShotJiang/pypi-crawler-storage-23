"""Analyzer for GitLab CI optimization opportunities."""

from typing import Any, Dict, List


class GitLabCIAnalyzer:
    """Analyzer for detecting GitLab CI optimization opportunities."""
    
    def __init__(self, config: Dict[str, Any], verbose: bool = False):
        self.config = config
        self.verbose = verbose
        self.issues: List[Dict[str, Any]] = []
    
    def analyze(self) -> List[Dict[str, Any]]:
        """Run all analyzers and return issues."""
        self._check_duplicate_scripts()
        self._check_missing_cache()
        self._check_missing_artifacts()
        self._check_parallel_jobs()
        self._check_insecure_images()
        self._check_job_dependencies()
        self._check_redundant_stages()
        self._check_large_artifacts()
        
        return self.issues
    
    def _add_issue(self, severity: str, message: str, line: int = 0, job: str = ""):
        """Add an issue to the list."""
        issue = {
            "severity": severity,
            "message": message,
        }
        if line:
            issue["line"] = line
        if job:
            issue["job"] = job
        self.issues.append(issue)
    
    def _check_duplicate_scripts(self):
        """Check for duplicate script commands that could be shared."""
        jobs = self._get_jobs()
        script_sets = {}
        
        for job_name, job_config in jobs.items():
            script = job_config.get("script", [])
            if isinstance(script, list):
                script_tuple = tuple(script)
                if script_tuple in script_sets:
                    self._add_issue(
                        "warning",
                        f"Duplicate script found in job '{job_name}' (same as '{script_sets[script_tuple]}'). Consider using 'extends'.",
                        job=job_name
                    )
                else:
                    script_sets[script_tuple] = job_name
    
    def _check_missing_cache(self):
        """Check for jobs that could benefit from caching."""
        jobs = self._get_jobs()
        cache_keywords = ["npm", "yarn", "pip", "bundle", "go mod", "cargo", "gradle", "maven"]
        
        for job_name, job_config in jobs.items():
            script = job_config.get("script", [])
            if isinstance(script, str):
                script = [script]
            
            has_dep_install = any(
                any(kw in str(cmd).lower() for kw in cache_keywords) 
                for cmd in script
            )
            
            has_cache = "cache" in job_config
            
            if has_dep_install and not has_cache:
                self._add_issue(
                    "info",
                    f"Job '{job_name}' installs dependencies but has no cache. Add caching to speed up pipeline.",
                    job=job_name
                )
    
    def _check_missing_artifacts(self):
        """Check for jobs that should pass artifacts."""
        jobs = self._get_jobs()
        stages = self.config.get("stages", ["build", "test", "deploy"])
        
        build_jobs = [j for j, c in jobs.items() if "build" in j.lower()]
        test_jobs = [j for j, c in jobs.items() if "test" in j.lower()]
        
        for test_job in test_jobs:
            test_config = jobs[test_job]
            if "dependencies" not in test_config and "needs" not in test_config:
                has_artifact_job = any(
                    "artifacts" in jobs[bj] for bj in build_jobs
                )
                if has_artifact_job:
                    self._add_issue(
                        "warning",
                        f"Job '{test_job}' may need 'dependencies' to receive build artifacts from previous jobs.",
                        job=test_job
                    )
    
    def _check_parallel_jobs(self):
        """Check for jobs that could run in parallel."""
        jobs = self._get_jobs()
        
        for job_name, job_config in jobs.items():
            stage = job_config.get("stage", "test")
            if stage not in ("build", "test"):
                continue
            
            deps = job_config.get("needs", [])
            if isinstance(deps, list) and len(deps) > 2:
                self._add_issue(
                    "info",
                    f"Job '{job_name}' has {len(deps)} dependencies. Consider splitting into parallel jobs.",
                    job=job_name
                )
    
    def _check_insecure_images(self):
        """Check for potentially insecure or slow images."""
        jobs = self._get_jobs()
        
        for job_name, job_config in jobs.items():
            image = job_config.get("image", "")
            
            if not image:
                self._add_issue(
                    "info",
                    f"Job '{job_name}' has no explicit image. Consider specifying one for consistency.",
                    job=job_name
                )
            elif ":latest" in image:
                self._add_issue(
                    "warning",
                    f"Job '{job_name}' uses ':latest' tag. Pin a specific version for reproducibility.",
                    job=job_name
                )
    
    def _check_job_dependencies(self):
        """Check for unnecessary job dependencies."""
        jobs = self._get_jobs()
        
        for job_name, job_config in jobs.items():
            if "needs" in job_config and "stage" in job_config:
                self._add_issue(
                    "info",
                    f"Job '{job_name}' uses both 'needs' and 'stage'. 'needs' (DAG) is recommended for better control.",
                    job=job_name
                )
    
    def _check_redundant_stages(self):
        """Check for redundant or missing stages."""
        stages = self.config.get("stages", [])
        
        if len(stages) == 1:
            self._add_issue(
                "info",
                "Only one stage defined. Consider using 'needs' for DAG-based parallelization."
            )
        
        if "deploy" in stages:
            deploy_jobs = [j for j in self._get_jobs().keys() if "deploy" in j.lower()]
            if not deploy_jobs:
                self._add_issue(
                    "warning",
                    "Deploy stage defined but no deploy jobs found."
                )
    
    def _check_large_artifacts(self):
        """Check for potentially large artifacts."""
        jobs = self._get_jobs()
        
        for job_name, job_config in jobs.items():
            artifacts = job_config.get("artifacts", {})
            if isinstance(artifacts, dict):
                paths = artifacts.get("paths", [])
                if any(p in ["*", "**", "node_modules", "vendor"] for p in paths):
                    self._add_issue(
                        "warning",
                        f"Job '{job_name}' has broad artifact paths. Consider specifying exact paths to reduce size.",
                        job=job_name
                    )
                
                expire_in = artifacts.get("expire_in")
                if not expire_in:
                    self._add_issue(
                        "info",
                        f"Job '{job_name}' has artifacts without expiration. Consider setting 'expire_in' to save storage.",
                        job=job_name
                    )
    
    def _get_jobs(self) -> Dict[str, Dict[str, Any]]:
        """Get all jobs from config."""
        jobs = {}
        reserved_keys = {"stages", "variables", "workflow", "image", "services", 
                         "before_script", "after_script", "cache", "artifacts",
                         "default", "include", "trigger", "rules"}
        
        for key, value in self.config.items():
            if key not in reserved_keys and isinstance(value, dict):
                jobs[key] = value
        
        return jobs


def analyze_pipeline(config: Dict[str, Any], verbose: bool = False) -> List[Dict[str, Any]]:
    """Analyze a GitLab CI configuration for optimization opportunities.
    
    Args:
        config: Parsed GitLab CI configuration
        verbose: Enable verbose output
        
    Returns:
        List of issues found
    """
    analyzer = GitLabCIAnalyzer(config, verbose=verbose)
    return analyzer.analyze()
