"""Parser for GitLab CI configuration files."""

import yaml
from pathlib import Path
from typing import Any, Dict, Optional


class GitLabCIParser:
    """Parser for .gitlab-ci.yml files."""
    
    def __init__(self, content: str):
        self.content = content
        self.data: Optional[Dict[str, Any]] = None
        self.errors: list = []
    
    def parse(self) -> Dict[str, Any]:
        """Parse YAML content."""
        try:
            self.data = yaml.safe_load(self.content)
            if self.data is None:
                self.data = {}
            return self.data
        except yaml.YAMLError as e:
            self.errors.append(f"YAML parsing error: {e}")
            raise ValueError(f"Invalid YAML: {e}")
    
    def validate(self) -> list:
        """Validate GitLab CI syntax."""
        errors = []
        
        if not self.data:
            return errors
        
        if not isinstance(self.data, dict):
            errors.append("Root element must be a dictionary")
            return errors
        
        for key, value in self.data.items():
            if key in ("stages", "variables", "workflow"):
                continue
            
            if not isinstance(value, dict):
                errors.append(f"Job '{key}' must be a dictionary")
                continue
            
            if "script" not in value and "extends" not in value:
                continue
        
        return errors
    
    def get_jobs(self) -> Dict[str, Dict[str, Any]]:
        """Extract all jobs from configuration."""
        if not self.data:
            return {}
        
        jobs = {}
        for key, value in self.data.items():
            if key not in ("stages", "variables", "workflow", "image", "services", "before_script", "after_script"):
                if isinstance(value, dict):
                    jobs[key] = value
        return jobs
    
    def get_stages(self) -> list:
        """Extract stages."""
        return self.data.get("stages", ["build", "test", "deploy"])
    
    def get_variables(self) -> dict:
        """Extract global variables."""
        return self.data.get("variables", {})


def parse_gitlab_ci(file_path: str) -> Dict[str, Any]:
    """Parse a .gitlab-ci.yml file.
    
    Args:
        file_path: Path to .gitlab-ci.yml file
        
    Returns:
        Parsed configuration dictionary
    """
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")
    
    content = path.read_text()
    parser = GitLabCIParser(content)
    config = parser.parse()
    
    errors = parser.validate()
    if errors:
        raise ValueError(f"Validation errors: {', '.join(errors)}")
    
    config["_parser_errors"] = parser.errors
    config["_file_path"] = str(path)
    
    return config
