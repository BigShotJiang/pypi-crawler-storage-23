"""Optimizer for GitLab CI configurations."""

import copy
from typing import Any, Dict, List


def optimize_pipeline(config: Dict[str, Any], issues: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Generate an optimized version of the GitLab CI configuration.
    
    Args:
        config: Original configuration
        issues: List of issues from analyzer
        
    Returns:
        Optimized configuration
    """
    optimized = copy.deepcopy(config)
    
    for key in ("_parser_errors", "_file_path"):
        optimized.pop(key, None)
    
    jobs = _get_jobs(optimized)
    
    _add_caching(jobs)
    _optimize_artifacts(jobs)
    _add_dag_dependencies(optimized, jobs)
    
    return optimized


def _get_jobs(config: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    """Extract jobs from config."""
    jobs = {}
    reserved = {"stages", "variables", "workflow", "image", "services",
                "before_script", "after_script", "cache", "artifacts", "default",
                "_parser_errors", "_file_path"}
    
    for key, value in config.items():
        if key not in reserved and isinstance(value, dict):
            jobs[key] = value
    
    return jobs


def _add_caching(jobs: Dict[str, Dict[str, Any]]):
    """Add caching to jobs that install dependencies."""
    cache_keywords = {
        "node": ("node_modules", "package-lock.json"),
        "npm": ("node_modules", "package-lock.json"),
        "yarn": ("node_modules", "yarn.lock"),
        "pip": (".cache/pip", "requirements.txt"),
        "bundle": (".bundle", "Gemfile.lock"),
        "go mod": ("$GOPATH/pkg/mod", "go.sum"),
        "cargo": ("target", "Cargo.lock"),
    }
    
    for job_name, job_config in jobs.items():
        if "cache" in job_config:
            continue
        
        script = job_config.get("script", [])
        if isinstance(script, str):
            script = [script]
        
        script_str = " ".join(script).lower()
        
        for lang, (path, lock_file) in cache_keywords.items():
            if lang in script_str:
                job_config["cache"] = {
                    "key": f"${{{{ {job_name}-cache }}}}",
                    "paths": [path],
                    "policy": "pull-push"
                }
                break


def _optimize_artifacts(jobs: Dict[str, Dict[str, Any]]):
    """Optimize artifact configuration."""
    for job_name, job_config in jobs.items():
        artifacts = job_config.get("artifacts", {})
        
        if not isinstance(artifacts, dict):
            continue
        
        if "expire_in" not in artifacts:
            artifacts["expire_in"] = "1 week"
        
        paths = artifacts.get("paths", [])
        if isinstance(paths, list) and len(paths) == 1 and paths[0] in ["*", "**"]:
            if "build" in job_name.lower():
                artifacts["paths"] = ["dist/", "build/", "target/"]
            elif "test" in job_name.lower():
                artifacts["paths"] = ["test-results/", "coverage/"]


def _add_dag_dependencies(config: Dict[str, Any], jobs: Dict[str, Dict[str, Any]]):
    """Add DAG dependencies using 'needs' for better parallelization."""
    stages = config.get("stages", ["build", "test", "deploy"])
    
    if "needs" in config or "workflow" in config:
        return
    
    stage_jobs = {}
    for job_name, job_config in jobs.items():
        stage = job_config.get("stage", "test")
        if stage not in stage_jobs:
            stage_jobs[stage] = []
        stage_jobs[stage].append(job_name)
    
    for i, stage in enumerate(stages[1:], 1):
        if stage not in stage_jobs:
            continue
        
        prev_stage = stages[i - 1]
        if prev_stage not in stage_jobs:
            continue
        
        prev_jobs = stage_jobs[prev_stage]
        
        for job_name in stage_jobs[stage]:
            if "needs" not in jobs[job_name]:
                jobs[job_name]["needs"] = prev_jobs
