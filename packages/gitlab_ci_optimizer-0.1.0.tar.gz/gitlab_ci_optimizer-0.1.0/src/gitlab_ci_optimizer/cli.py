"""CLI interface for GitLab CI Optimizer."""

import sys
from pathlib import Path

import click

from gitlab_ci_optimizer import __version__
from gitlab_ci_optimizer.parser import parse_gitlab_ci
from gitlab_ci_optimizer.analyzer import analyze_pipeline
from gitlab_ci_optimizer.optimizer import optimize_pipeline
from gitlab_ci_optimizer.templates import generate_template


@click.group()
@click.version_option(version=__version__)
def main():
    """GitLab CI Optimizer - Analyze and optimize GitLab CI configurations."""
    pass


@main.command()
@click.argument("file", type=click.Path(exists=True))
@click.option("-o", "--output", type=click.Path(), help="Output file path")
@click.option("-f", "--format", "output_format", type=click.Choice(["json", "yaml", "text"]), default="text", help="Output format")
@click.option("-v", "--verbose", is_flag=True, help="Verbose output")
def analyze(file, output, output_format, verbose):
    """Analyze a .gitlab-ci.yml file."""
    try:
        config = parse_gitlab_ci(file)
        issues = analyze_pipeline(config, verbose=verbose)
        
        if output_format == "json":
            import json
            result = {"issues": issues, "file": file}
            output_data = json.dumps(result, indent=2)
        elif output_format == "yaml":
            import yaml
            output_data = yaml.dump({"issues": issues, "file": file}, default_flow_style=False)
        else:
            lines = [f"Analysis of: {file}", "=" * 50]
            if not issues:
                lines.append("No issues found!")
            else:
                for issue in issues:
                    severity = issue.get("severity", "info").upper()
                    msg = issue.get("message", "")
                    line = issue.get("line", "?")
                    lines.append(f"[{severity}] Line {line}: {msg}")
            output_data = "\n".join(lines)
        
        if output:
            Path(output).write_text(output_data)
            click.echo(f"Results written to: {output}")
        else:
            click.echo(output_data)
            
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@main.command()
@click.argument("file", type=click.Path(exists=True))
@click.option("-o", "--output", type=click.Path(), help="Output file path")
@click.option("-v", "--verbose", is_flag=True, help="Verbose output")
def optimize(file, output, verbose):
    """Generate optimized version of .gitlab-ci.yml."""
    try:
        config = parse_gitlab_ci(file)
        issues = analyze_pipeline(config, verbose=verbose)
        optimized = optimize_pipeline(config, issues)
        
        import yaml
        output_data = yaml.dump(optimized, default_flow_style=False, sort_keys=False)
        
        if output:
            Path(output).write_text(output_data)
            click.echo(f"Optimized config written to: {output}")
        else:
            click.echo(output_data)
            
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@main.command()
@click.argument("type", type=click.Choice(["node", "python", "docker", "go", "rust", "java"]))
@click.option("-o", "--output", type=click.Path(), help="Output file path")
@click.option("-v", "--verbose", is_flag=True, help="Verbose output")
def template(type, output, verbose):
    """Generate pipeline template."""
    try:
        template_content = generate_template(type, verbose=verbose)
        
        if output:
            Path(output).write_text(template_content)
            click.echo(f"Template written to: {output}")
        else:
            click.echo(template_content)
            
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
