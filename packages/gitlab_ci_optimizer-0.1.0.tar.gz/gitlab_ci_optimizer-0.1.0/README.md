# GitLab CI Optimizer

Analyze and optimize your GitLab CI/CD pipeline configurations.

## Installation

```bash
pip install gitlab-ci-optimizer
```

## Usage

### Analyze a pipeline

```bash
gitlab-ci-optimizer analyze .gitlab-ci.yml
```

### Generate optimized configuration

```bash
gitlab-ci-optimizer optimize .gitlab-ci.yml -o .gitlab-ci-optimized.yml
```

### Generate a template

```bash
# Node.js
gitlab-ci-optimizer template node -o .gitlab-ci.yml

# Python
gitlab-ci-optimizer template python -o .gitlab-ci.yml

# Docker
gitlab-ci-optimizer template docker -o .gitlab-ci.yml

# Go
gitlab-ci-optimizer template go -o .gitlab-ci.yml
```

## Options

- `-o, --output` - Output file path
- `-f, --format` - Output format (json, yaml, text) for analyze command
- `-v, --verbose` - Verbose output

## Features

- Parse and validate `.gitlab-ci.yml` files
- Detect optimization opportunities (caching, parallelization, artifacts)
- Generate optimized pipeline configurations
- Support for Node.js, Python, Docker, Go, Rust, and Java templates
