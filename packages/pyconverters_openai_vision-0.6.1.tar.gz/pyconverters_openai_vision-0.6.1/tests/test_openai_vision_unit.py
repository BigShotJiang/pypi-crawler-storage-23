"""Unit tests covering previously untested behaviour in openai_vision and openai_utils."""

from io import BytesIO
from types import SimpleNamespace
from unittest.mock import patch

import pytest
from pydantic import BaseModel
from pymultirole_plugins.v1.schema import Sentence
from starlette.datastructures import Headers, UploadFile

from pyconverters_openai_vision.openai_utils import all_filter, apollo_filter, gpt_filter
from pyconverters_openai_vision.openai_vision import (
    DeepInfraOpenAIVisionConverter,
    DeepInfraOpenAIVisionParameters,
    DeepInfraOpenAIVisionProcessor,
    DeepInfraOpenAIVisionProcessorParameters,
    OpenAIVisionBaseParameters,
    OpenAIVisionConverter,
    OpenAIVisionConverterBase,
    OpenAIVisionModel,
    OpenAIVisionParameters,
    OpenAIVisionProcessor,
    OpenAIVisionProcessorBase,
    OpenAIVisionProcessorBaseParameters,
    OpenAIVisionProcessorParameters,
    TemplateLanguage,
    get_template,
    guess_kind,
    regex_sub_preserve_spans,
    render_template,
)


# ---------------------------------------------------------------------------
# TemplateLanguage enum
# ---------------------------------------------------------------------------
class TestTemplateLanguage:
    def test_values(self):
        assert TemplateLanguage.none == "none"
        assert TemplateLanguage.string == "string"
        assert TemplateLanguage.jinja2 == "jinja2"


# ---------------------------------------------------------------------------
# get_template / render_template
# ---------------------------------------------------------------------------
class TestGetTemplate:
    def test_plain_text_returns_none_language(self):
        lang, templ = get_template("Describe this image")
        assert lang == TemplateLanguage.none
        assert templ == "Describe this image"

    def test_empty_string_returns_none_language(self):
        lang, templ = get_template("")
        assert lang == TemplateLanguage.none
        assert templ == ""

    def test_none_returns_none_language(self):
        lang, templ = get_template(None)
        assert lang == TemplateLanguage.none
        assert templ is None

    def test_dollar_sign_returns_string_template(self):
        lang, templ = get_template("Hello $name")
        assert lang == TemplateLanguage.string

    def test_jinja2_returns_jinja2_template(self):
        lang, templ = get_template("Hello {{ doc.text }}")
        assert lang == TemplateLanguage.jinja2


class TestRenderTemplate:
    def test_render_plain(self):
        result = render_template(TemplateLanguage.none, "plain prompt", None, None)
        assert result == "plain prompt"

    def test_render_string_template(self):
        lang, templ = get_template("Document: $text")
        doc = SimpleNamespace(text="hello world", title="test")
        result = render_template(lang, templ, doc, None)
        assert result == "Document: hello world"

    def test_render_string_template_missing_key(self):
        lang, templ = get_template("Document: $missing_key")
        doc = SimpleNamespace(text="hello")
        result = render_template(lang, templ, doc, None)
        assert "$missing_key" in result

    def test_render_jinja2_template(self):
        lang, templ = get_template("{{ doc.text|upper }}")
        doc = SimpleNamespace(text="hello world")
        result = render_template(lang, templ, doc, None)
        assert result == "HELLO WORLD"

    def test_render_jinja2_with_params(self):
        lang, templ = get_template("{{ parameters.prompt }}")
        doc = SimpleNamespace(text="")
        params = SimpleNamespace(prompt="my prompt")
        result = render_template(lang, templ, doc, params)
        assert result == "my prompt"


# ---------------------------------------------------------------------------
# guess_kind
# ---------------------------------------------------------------------------
class TestGuessKind:
    def test_valid_image_data_uri(self):
        kind = guess_kind("data:image/png;base64,iVBORw0KGgo=")
        assert kind is not None

    def test_non_image_returns_none(self):
        kind = guess_kind("just some text without data uri")
        assert kind is None

    def test_non_image_data_uri_returns_none(self):
        kind = guess_kind("data:application/pdf;base64,abc123")
        assert kind is None


# ---------------------------------------------------------------------------
# Filters (openai_utils)
# ---------------------------------------------------------------------------
class TestFilters:
    def test_gpt_filter_accepts_gpt4(self):
        assert gpt_filter("gpt-4o") is True
        assert gpt_filter("gpt-4o-mini") is True
        assert gpt_filter("gpt-4.1") is True

    def test_gpt_filter_rejects_instruct(self):
        assert gpt_filter("gpt-3.5-turbo-instruct") is False

    def test_gpt_filter_rejects_non_gpt(self):
        assert gpt_filter("claude-3") is False

    def test_all_filter_accepts_anything(self):
        assert all_filter("anything") is True
        assert all_filter("") is True

    def test_apollo_filter_rejects_embed(self):
        assert apollo_filter("text-embedding-ada") is False

    def test_apollo_filter_rejects_tts(self):
        assert apollo_filter("tts-1") is False

    def test_apollo_filter_rejects_mock(self):
        assert apollo_filter("mock-model") is False

    def test_apollo_filter_accepts_normal(self):
        assert apollo_filter("gpt-4o") is True


# ---------------------------------------------------------------------------
# OpenAIVisionModel enum
# ---------------------------------------------------------------------------
class TestOpenAIVisionModel:
    def test_model_values(self):
        assert OpenAIVisionModel.gpt_4o_mini == "gpt-4o-mini"
        assert OpenAIVisionModel.gpt_4_1 == "gpt-4.1"
        assert OpenAIVisionModel.gpt_5 == "gpt-5"


# ---------------------------------------------------------------------------
# Parameter model defaults
# ---------------------------------------------------------------------------
class TestParameterDefaults:
    def test_base_parameters_defaults(self):
        params = OpenAIVisionBaseParameters()
        assert params.max_tokens == 16384
        assert params.temperature == 0.1
        assert params.top_p == 1
        assert params.n == 1
        assert params.best_of == 1
        assert params.presence_penalty == 0.0
        assert params.frequency_penalty == 0.0
        assert params.prompt == "If the attached file is an image: describe the image."
        assert params.system_prompt is None
        assert params.base_url is None
        assert params.model_str is None

    def test_processor_base_parameters_defaults(self):
        params = OpenAIVisionProcessorBaseParameters()
        assert params.replace_refs_altTexts_by_descriptions is True
        assert params.prompt == "Generate a textual description of the image"
        assert params.max_tokens == 16384


# ---------------------------------------------------------------------------
# get_model() for all classes
# ---------------------------------------------------------------------------
class TestGetModel:
    def test_converter_base_get_model(self):
        assert OpenAIVisionConverterBase.get_model() == OpenAIVisionBaseParameters

    def test_converter_get_model(self):
        assert OpenAIVisionConverter.get_model() == OpenAIVisionParameters

    def test_deepinfra_converter_get_model(self):
        assert DeepInfraOpenAIVisionConverter.get_model() == DeepInfraOpenAIVisionParameters

    def test_processor_base_get_model(self):
        assert OpenAIVisionProcessorBase.get_model() == OpenAIVisionProcessorBaseParameters

    def test_processor_get_model(self):
        assert OpenAIVisionProcessor.get_model() == OpenAIVisionProcessorParameters

    def test_deepinfra_processor_get_model(self):
        assert DeepInfraOpenAIVisionProcessor.get_model() == DeepInfraOpenAIVisionProcessorParameters

    def test_all_get_model_return_basemodel_subclass(self):
        for cls in [
            OpenAIVisionConverterBase,
            OpenAIVisionConverter,
            DeepInfraOpenAIVisionConverter,
            OpenAIVisionProcessorBase,
            OpenAIVisionProcessor,
            DeepInfraOpenAIVisionProcessor,
        ]:
            model = cls.get_model()
            assert issubclass(model, BaseModel), f"{cls.__name__}.get_model() should return a BaseModel subclass"


# ---------------------------------------------------------------------------
# regex_sub_preserve_spans
# ---------------------------------------------------------------------------
class TestRegexSubPreserveSpans:
    def test_no_matches_returns_original(self):
        text = "hello world"
        spans = [Sentence(start=0, end=5)]
        new_text, new_spans = regex_sub_preserve_spans(text, r"NOMATCH", lambda _m: "", spans)
        assert new_text == "hello world"
        assert len(new_spans) == 1
        assert new_spans[0].start == 0
        assert new_spans[0].end == 5

    def test_replacement_adjusts_spans(self):
        text = "AB123CD"
        spans = [Sentence(start=5, end=6)]  # "C"
        new_text, new_spans = regex_sub_preserve_spans(text, r"123", lambda _m: "X", spans)
        assert new_text == "ABXCD"
        assert len(new_spans) == 1
        assert new_spans[0].start == 3
        assert new_spans[0].end == 4
        assert new_text[new_spans[0].start : new_spans[0].end] == "C"

    def test_none_spans_returns_none(self):
        text = "hello 123 world"
        new_text, new_spans = regex_sub_preserve_spans(text, r"123", lambda _m: "X", None)
        assert new_text == "hello X world"
        assert new_spans is None

    def test_span_out_of_char_map_is_skipped(self):
        text = "AB"
        spans = [Sentence(start=99, end=100)]
        new_text, new_spans = regex_sub_preserve_spans(text, r"NOMATCH", lambda _m: "", spans)
        assert new_text == "AB"
        assert len(new_spans) == 0

    def test_image_link_replacement(self):
        text = "Before ![img1](url1) after"
        # span for "Before" (0-5) and " afte" (20-25), avoiding len(text) boundary
        spans = [Sentence(start=0, end=5), Sentence(start=20, end=25)]

        def replace_link(m):
            return f"{m.group(0)}\nDescription of image\n"

        new_text, new_spans = regex_sub_preserve_spans(text, r"!\[([^]]+)\]\(([^)]+)\)", replace_link, spans)
        assert "Description of image" in new_text
        assert "Before" in new_text
        assert "after" in new_text
        assert len(new_spans) == 2


# ---------------------------------------------------------------------------
# compute_result – markdown code-block stripping (converter)
# ---------------------------------------------------------------------------
class TestConverterComputeResult:
    def _make_response(self, content):
        choice = SimpleNamespace(message=SimpleNamespace(content=content))
        return SimpleNamespace(choices=[choice])

    @patch("pyconverters_openai_vision.openai_vision.openai_chat_completion")
    def test_plain_text(self, mock_chat):
        mock_chat.return_value = self._make_response("Hello world")
        converter = OpenAIVisionConverterBase()
        result = converter.compute_result(None, model="test")
        assert result == "Hello world"

    @patch("pyconverters_openai_vision.openai_vision.openai_chat_completion")
    def test_markdown_code_block(self, mock_chat):
        mock_chat.return_value = self._make_response("```markdown\n# Title\nContent\n```")
        converter = OpenAIVisionConverterBase()
        result = converter.compute_result(None, model="test")
        assert "# Title" in result
        assert "Content" in result
        assert "```" not in result

    @patch("pyconverters_openai_vision.openai_vision.openai_chat_completion")
    def test_json_code_block(self, mock_chat):
        mock_chat.return_value = self._make_response('```json\n{"key": "value"}\n```')
        converter = OpenAIVisionConverterBase()
        result = converter.compute_result(None, model="test")
        assert '{"key": "value"}' in result

    @patch("pyconverters_openai_vision.openai_vision.openai_chat_completion")
    def test_generic_code_block_fallback(self, mock_chat):
        mock_chat.return_value = self._make_response("```\nsome code\n```")
        converter = OpenAIVisionConverterBase()
        result = converter.compute_result(None, model="test")
        assert "some code" in result

    @patch("pyconverters_openai_vision.openai_vision.openai_chat_completion")
    def test_no_content_returns_none(self, mock_chat):
        choice = SimpleNamespace(message=SimpleNamespace(content=None))
        mock_chat.return_value = SimpleNamespace(choices=[choice])
        converter = OpenAIVisionConverterBase()
        result = converter.compute_result(None, model="test")
        assert result is None

    @patch("pyconverters_openai_vision.openai_vision.openai_chat_completion")
    def test_multiple_choices(self, mock_chat):
        choice1 = SimpleNamespace(message=SimpleNamespace(content="part1"))
        choice2 = SimpleNamespace(message=SimpleNamespace(content="part2"))
        mock_chat.return_value = SimpleNamespace(choices=[choice1, choice2])
        converter = OpenAIVisionConverterBase()
        result = converter.compute_result(None, model="test")
        assert result == "part1\npart2"


# ---------------------------------------------------------------------------
# compute_result – processor (catches exceptions)
# ---------------------------------------------------------------------------
class TestProcessorComputeResult:
    @patch("pyconverters_openai_vision.openai_vision.openai_chat_completion")
    def test_exception_returns_none(self, mock_chat):
        mock_chat.side_effect = Exception("API error")
        processor = OpenAIVisionProcessorBase()
        result = processor.compute_result(None, model="test")
        assert result is None


# ---------------------------------------------------------------------------
# compute_args – converter
# ---------------------------------------------------------------------------
class TestConverterComputeArgs:
    def test_compute_args_builds_correct_kwargs(self):
        converter = OpenAIVisionConverterBase()
        params = OpenAIVisionBaseParameters(
            model_str="gpt-4o",
            prompt="Describe this",
            system_prompt="You are helpful",
            max_tokens=100,
            temperature=0.5,
        )
        # 1x1 red PNG pixel
        png_bytes = (
            b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01"
            b"\x00\x00\x00\x01\x08\x02\x00\x00\x00\x90wS\xde\x00"
            b"\x00\x00\x0cIDATx\x9cc\xf8\x0f\x00\x00\x01\x01\x00"
            b"\x05\x18\xd8N\x00\x00\x00\x00IEND\xaeB`\x82"
        )
        source = UploadFile(
            file=BytesIO(png_bytes),
            filename="test.png",
            headers=Headers({"content-type": "image/png"}),
        )
        kind = SimpleNamespace(mime="image/png")
        kwargs = converter.compute_args(params, source, kind)
        assert kwargs["model"] == "gpt-4o"
        assert kwargs["max_tokens"] == 100
        assert kwargs["temperature"] == 0.5
        assert len(kwargs["messages"]) == 2  # system + user
        assert kwargs["messages"][0]["role"] == "system"
        assert kwargs["messages"][1]["role"] == "user"

    def test_compute_args_no_system_prompt(self):
        converter = OpenAIVisionConverterBase()
        params = OpenAIVisionBaseParameters(model_str="gpt-4o")
        png_bytes = (
            b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01"
            b"\x00\x00\x00\x01\x08\x02\x00\x00\x00\x90wS\xde\x00"
            b"\x00\x00\x0cIDATx\x9cc\xf8\x0f\x00\x00\x01\x01\x00"
            b"\x05\x18\xd8N\x00\x00\x00\x00IEND\xaeB`\x82"
        )
        source = UploadFile(
            file=BytesIO(png_bytes),
            filename="test.png",
            headers=Headers({"content-type": "image/png"}),
        )
        kind = SimpleNamespace(mime="image/png")
        kwargs = converter.compute_args(params, source, kind)
        assert len(kwargs["messages"]) == 1  # user only
        assert kwargs["messages"][0]["role"] == "user"


# ---------------------------------------------------------------------------
# compute_args – processor
# ---------------------------------------------------------------------------
class TestProcessorComputeArgs:
    def test_compute_args_uses_custom_prompt(self):
        processor = OpenAIVisionProcessorBase()
        params = OpenAIVisionProcessorBaseParameters(model_str="gpt-4o")
        kind = SimpleNamespace(mime="image/png")
        kwargs = processor.compute_args(params, "data:image/png;base64,abc", kind, prompt="custom", system_prompt=None)
        user_msg = kwargs["messages"][0]
        assert user_msg["content"][0]["text"] == "custom"

    def test_compute_args_defaults_to_params_prompt(self):
        processor = OpenAIVisionProcessorBase()
        params = OpenAIVisionProcessorBaseParameters(model_str="gpt-4o", prompt="my prompt")
        kind = SimpleNamespace(mime="image/png")
        kwargs = processor.compute_args(params, "data:image/png;base64,abc", kind)
        user_msg = kwargs["messages"][0]
        assert user_msg["content"][0]["text"] == "my prompt"


# ---------------------------------------------------------------------------
# convert – with mocked API
# ---------------------------------------------------------------------------
class TestConverterConvert:
    @patch("pyconverters_openai_vision.openai_vision.openai_chat_completion")
    @patch("pyconverters_openai_vision.openai_vision.filetype")
    def test_convert_image_success(self, mock_filetype, mock_chat):
        mock_filetype.guess.return_value = SimpleNamespace(mime="image/png")
        choice = SimpleNamespace(message=SimpleNamespace(content="A beautiful image"))
        mock_chat.return_value = SimpleNamespace(choices=[choice])

        converter = OpenAIVisionConverterBase()
        converter.PREFIX = ""
        params = OpenAIVisionBaseParameters(model_str="gpt-4o")
        png_bytes = b"\x89PNG\r\n\x1a\nfakedata"
        source = UploadFile(
            file=BytesIO(png_bytes),
            filename="test.png",
            headers=Headers({"content-type": "image/png"}),
        )
        docs = converter.convert(source, params)
        assert len(docs) == 1
        assert docs[0].text == "A beautiful image"
        assert docs[0].identifier == "test.png"

    @patch("pyconverters_openai_vision.openai_vision.filetype")
    def test_convert_non_image_raises(self, mock_filetype):
        mock_filetype.guess.return_value = SimpleNamespace(mime="application/pdf")
        converter = OpenAIVisionConverterBase()
        params = OpenAIVisionBaseParameters(model_str="gpt-4o")
        source = UploadFile(
            file=BytesIO(b"not an image"),
            filename="test.pdf",
            headers=Headers({"content-type": "application/pdf"}),
        )
        with pytest.raises(TypeError, match="Conversion of file test.pdf failed"):
            converter.convert(source, params)
