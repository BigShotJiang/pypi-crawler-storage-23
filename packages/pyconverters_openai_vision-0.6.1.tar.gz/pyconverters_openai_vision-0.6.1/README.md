## Requirements

- Python 3.12+
- [uv](https://docs.astral.sh/uv/) as the package manager
- Pydantic v2 for the data parts.

## Installation
```
uv sync
```

## Running tests
```
uv run pytest
```

## Linting
```
uv run ruff check .
uv run ruff format --check .
```

## Build and publish the Python Package to PyPI
- Increment the version of your package in the `__init__.py` file:
```
"""OpenAIVision converter"""

__version__ = 'x.y.z'
```
- Build and publish
```
uv build
uv publish
```
