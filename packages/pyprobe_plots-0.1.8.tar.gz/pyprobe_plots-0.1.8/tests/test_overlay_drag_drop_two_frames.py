"""
Automated GUI test for drag-drop overlay verification with two frames.

Tests that:
1. A waveform probe (signal_i) is created at line 70
2. An overlay (received_symbols) is added with instance 2
3. For each iteration, signal_i values from the script match the exported plot data

Uses the --overlay CLI argument to programmatically create overlays
without requiring GUI mouse interaction.
"""

import json
import os
import subprocess
import sys
import tempfile
import unittest
from typing import Dict, List


def run_pyprobe_with_overlay(
    script_path: str,
    probe_spec: str,
    overlay_spec: str,
    timeout: int = 4,
) -> Dict:
    """
    Run pyprobe with a probe and an overlay, return captured PLOT_DATA.

    Args:
        script_path: Absolute path to the script
        probe_spec: Probe spec like "70:signal_i:1"
        overlay_spec: Overlay spec like "signal_i:75:received_symbols:2"
        timeout: Maximum seconds to wait

    Returns:
        dict with PLOT_DATA for the probed symbol
    """
    python_exe = sys.executable

    cmd = [
        python_exe, "-m", "pyprobe",
        "--auto-run",
        "--auto-quit-timeout", str(timeout),
        "--loglevel", "WARNING",
        "--probe", probe_spec,
        "--overlay", overlay_spec,
        script_path,
    ]

    env = os.environ.copy()

    with tempfile.TemporaryFile(mode='w+') as tmp_out:
        result = subprocess.run(
            cmd,
            stdout=tmp_out,
            stderr=tmp_out,
            text=True,
            env=env,
            timeout=timeout + 2,
        )

        tmp_out.seek(0)
        output = tmp_out.read()

    if result.returncode != 0:
        raise RuntimeError(f"PyProbe failed with code {result.returncode}:\n{output}")

    # Parse PLOT_DATA lines from output (each is a single line of JSON)
    for line in output.splitlines():
        if not line.startswith('PLOT_DATA:'):
            continue
        json_str = line[len('PLOT_DATA:'):]
        try:
            data = json.loads(json_str)
            if 'curves' in data:
                return data
        except json.JSONDecodeError:
            continue

    # Fallback: return first parseable PLOT_DATA if none had curves
    for line in output.splitlines():
        if not line.startswith('PLOT_DATA:'):
            continue
        json_str = line[len('PLOT_DATA:'):]
        try:
            return json.loads(json_str)
        except json.JSONDecodeError:
            continue

    return {}


class TestOverlayDragDropTwoFrames(unittest.TestCase):
    """Verify overlay with two frames captures correct data for each iteration."""

    @classmethod
    def setUpClass(cls):
        """Verify we're running from repo root."""
        cls.repo_root = os.getcwd()
        if not os.path.exists(os.path.join(cls.repo_root, 'pyprobe', '__main__.py')):
            raise RuntimeError("Run tests from repo root")

    def test_signal_i_values_match_expected(self):
        """
        Verify that signal_i values from the plot match the expected values from script.

        The script writes expected values to /tmp/dsp_demo_two_frames_expected.json.
        We compare the last frame's signal_i values with the plot data.
        """
        script = os.path.join(self.repo_root, 'regression', 'dsp_demo_two_frames.py')

        # Probe signal_i at line 74 (assignment in main())
        # Overlay received_symbols at line 84, instance 2
        plot_data = run_pyprobe_with_overlay(
            script,
            probe_spec="74:signal_i:1",
            overlay_spec="signal_i:84:received_symbols:2",
            timeout=4,
        )

        self.assertIn('curves', plot_data,
                      f"No 'curves' key in PLOT_DATA. Got keys: {list(plot_data.keys())}. "
                      f"Full data: {plot_data}")

        # Get primary curve (signal_i)
        curves = plot_data['curves']
        primary_curves = [c for c in curves if not c.get('is_overlay', False)]
        self.assertEqual(len(primary_curves), 1,
                        f"Expected 1 primary curve, got {len(primary_curves)}")

        plot_signal_i = primary_curves[0].get('y', [])

        # Load expected values from JSON file
        expected_file = '/tmp/dsp_demo_two_frames_expected.json'
        self.assertTrue(os.path.exists(expected_file),
                       f"Expected file not found: {expected_file}")

        with open(expected_file, 'r') as f:
            expected_data = json.load(f)

        # The plot should show the last frame's data (waveform replaces on each update)
        last_frame = expected_data[-1]
        expected_signal_i = last_frame['signal_i']

        # Verify lengths match
        self.assertEqual(len(plot_signal_i), len(expected_signal_i),
                        f"Length mismatch: plot has {len(plot_signal_i)}, "
                        f"expected {len(expected_signal_i)}")

        # Verify values match (allowing small floating point tolerance)
        for i, (plot_val, expected_val) in enumerate(zip(plot_signal_i, expected_signal_i)):
            self.assertAlmostEqual(
                plot_val, expected_val, places=6,
                msg=f"Value mismatch at index {i}: plot={plot_val}, expected={expected_val}"
            )

    def test_overlay_curves_match_expected(self):
        """
        Verify that overlay curves (received_symbols real/imag) match expected values.
        """
        script = os.path.join(self.repo_root, 'regression', 'dsp_demo_two_frames.py')

        plot_data = run_pyprobe_with_overlay(
            script,
            probe_spec="74:signal_i:1",
            overlay_spec="signal_i:84:received_symbols:2",
            timeout=15,
        )

        if 'curves' not in plot_data:
            self.skipTest("No curves data available")

        curves = plot_data['curves']
        overlay_curves = [c for c in curves if c.get('is_overlay', False)]

        # Should have 2 overlay curves (real and imag parts of complex)
        self.assertEqual(len(overlay_curves), 2,
                        f"Expected 2 overlay curves, got {len(overlay_curves)}. "
                        f"Names: {[c.get('name') for c in overlay_curves]}")

        # Load expected values
        expected_file = '/tmp/dsp_demo_two_frames_expected.json'
        if not os.path.exists(expected_file):
            self.skipTest("Expected file not found")

        with open(expected_file, 'r') as f:
            expected_data = json.load(f)

        last_frame = expected_data[-1]
        # The overlay captures received_symbols before the -1-1j offset is applied
        expected_real = last_frame['received_symbols_pre_offset_real']
        expected_imag = last_frame['received_symbols_pre_offset_imag']

        # Find real and imag overlay curves
        real_curve = None
        imag_curve = None
        for c in overlay_curves:
            name = c.get('name', '').lower()
            if 'real' in name:
                real_curve = c
            elif 'imag' in name:
                imag_curve = c

        self.assertIsNotNone(real_curve, "No 'real' overlay curve found")
        self.assertIsNotNone(imag_curve, "No 'imag' overlay curve found")

        # Verify real overlay values
        plot_real = real_curve.get('y', [])
        self.assertEqual(len(plot_real), len(expected_real),
                        f"Real overlay length mismatch: {len(plot_real)} vs {len(expected_real)}")

        for i, (plot_val, expected_val) in enumerate(zip(plot_real, expected_real)):
            self.assertAlmostEqual(
                plot_val, expected_val, places=6,
                msg=f"Real overlay mismatch at index {i}: plot={plot_val}, expected={expected_val}"
            )

        # Verify imag overlay values
        plot_imag = imag_curve.get('y', [])
        self.assertEqual(len(plot_imag), len(expected_imag),
                        f"Imag overlay length mismatch: {len(plot_imag)} vs {len(expected_imag)}")

        for i, (plot_val, expected_val) in enumerate(zip(plot_imag, expected_imag)):
            self.assertAlmostEqual(
                plot_val, expected_val, places=6,
                msg=f"Imag overlay mismatch at index {i}: plot={plot_val}, expected={expected_val}"
            )

    def test_two_frames_captured(self):
        """
        Verify that both frames are processed (script runs to completion).
        """
        script = os.path.join(self.repo_root, 'regression', 'dsp_demo_two_frames.py')

        plot_data = run_pyprobe_with_overlay(
            script,
            probe_spec="74:signal_i:1",
            overlay_spec="signal_i:84:received_symbols:2",
            timeout=15,
        )

        # Load expected data to verify both frames were processed
        expected_file = '/tmp/dsp_demo_two_frames_expected.json'
        self.assertTrue(os.path.exists(expected_file),
                       "Expected file not created - script may not have completed")

        with open(expected_file, 'r') as f:
            expected_data = json.load(f)

        self.assertEqual(len(expected_data), 2,
                        f"Expected 2 frames in expected data, got {len(expected_data)}")

        # Verify each frame has the required data
        for i, frame in enumerate(expected_data):
            self.assertIn('signal_i', frame, f"Frame {i} missing signal_i")
            self.assertIn('received_symbols_real', frame, f"Frame {i} missing received_symbols_real")
            self.assertIn('received_symbols_imag', frame, f"Frame {i} missing received_symbols_imag")
            self.assertEqual(len(frame['signal_i']), 64,
                           f"Frame {i} signal_i should have 64 points")


if __name__ == "__main__":
    unittest.main()
