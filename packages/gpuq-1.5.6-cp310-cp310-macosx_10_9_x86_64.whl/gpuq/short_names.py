short_names = {
    "NVIDIA GeForce RTX 2070 SUPER": "rtx-2070-super",
    "AMD Instinct MI300X": "mi300x",
}
