version = '1.5.6'
repo = 'https://github.com/makora-ai/gpuq'
commit = '51e4b39d4f7a2a836a503f0b749e6d7d505e5605'
has_repo = True
