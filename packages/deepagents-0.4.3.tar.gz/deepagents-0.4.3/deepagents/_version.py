"""Version information for `deepagents` (SDK)."""

__version__ = "0.4.3"
