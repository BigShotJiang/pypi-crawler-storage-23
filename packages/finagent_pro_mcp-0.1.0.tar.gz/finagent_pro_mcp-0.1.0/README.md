# FinAgent Pro

Pro financial analysis MCP server for any MCP-compatible AI app (Claude, ChatGPT, Cursor, Copilot, and more).

Everything in FinAgent (free) plus SEC filing analysis and stock screening.

## Tools

| Tool | Description |
|------|-------------|
| `financial_data` | Stock quotes, income statements, balance sheets, cash flow, analyst estimates, insider trades, key ratios |
| `market_news` | Financial news, analyst reactions, market sentiment |
| `sec_filings` | SEC 10-K, 10-Q, 8-K filing reader with section extraction |
| `stock_screener` | Screen stocks by P/E, market cap, revenue growth, sector, and more |

## Quick Start

### Install

```bash
pip install finagent-pro
```

### Add to your MCP config

```json
{
  "mcpServers": {
    "finagent-pro": {
      "command": "finagent-pro",
      "env": {
        "FINAGENT_LICENSE_KEY": "your-key-here"
      }
    }
  }
}
```

### Run as HTTP server

```bash
finagent-pro --http --port 8080
```

## Examples

Ask your AI assistant:

- "What's NVIDIA's current stock price and P/E ratio?"
- "Show me Apple's last 4 quarters of revenue"
- "Who's been buying or selling TSLA stock lately?"
- "What are analysts saying about AMZN?"
- "Pull the risk factors from Meta's latest 10-K"
- "Find me tech stocks with P/E under 20 and revenue growth over 10%"

## Get a License Key

Get your FinAgent Pro key at [mcp-marketplace.io/server/finagent-pro](https://mcp-marketplace.io/server/finagent-pro).

## Data Sources

- **Market data:** Yahoo Finance (free, real-time)
- **SEC filings:** SEC EDGAR (free, official government data)
- **News:** Yahoo Finance news feed (free)
