# FinAgent Pro

## Tagline
Pro financial analysis with SEC filings and stock screening for any AI assistant.

## Description
FinAgent Pro is the complete financial analysis MCP server. It includes everything in FinAgent (free) — stock quotes, financials, news — plus SEC filing analysis and multi-criteria stock screening. Read 10-K risk factors, extract financial statement sections from EDGAR filings, and screen 70+ stocks by P/E, market cap, revenue growth, sector, and more. Works with Claude, ChatGPT, Cursor, Copilot, and any MCP-compatible app.

## Setup Requirements
- `FINAGENT_LICENSE_KEY` (required): Your FinAgent Pro license key. Get one at https://mcp-marketplace.io/server/finagent-pro
- `FINAGENT_CONTACT_EMAIL` (optional): Email for SEC EDGAR API User-Agent header. Recommended by SEC for rate-limit courtesy.

## Category
Finance

## Features
- Everything in FinAgent (free): stock quotes, financials, ratios, analyst estimates, insider trades, market news
- SEC EDGAR filing reader: 10-K, 10-Q, 8-K, DEF-14A with section extraction
- Extract specific 10-K sections: business overview, risk factors, MD&A, financial statements
- Stock screener across 70+ liquid tickers by sector, P/E, market cap, revenue growth, dividend yield
- Sortable and filterable results with configurable limits
- File-based caching for fast repeat queries and SEC rate-limit compliance

## Getting Started
- "What's NVIDIA's current stock price and P/E ratio?"
- "Pull the risk factors from Meta's latest 10-K"
- "Find me tech stocks with P/E under 20 and revenue growth over 10%"
- "What sections are available in Apple's most recent 10-K?"
- Tool: financial_data — Stock quotes, financials, ratios, analyst estimates, insider trades
- Tool: market_news — Search financial news by keyword or ticker
- Tool: sec_filings — Read and extract sections from SEC EDGAR filings
- Tool: stock_screener — Screen stocks by financial criteria across a curated universe

## Tags
finance, stocks, SEC, EDGAR, filings, 10-K, stock screener, market data, news, quotes, financial statements, analyst estimates, insider trades, ratios, yahoo finance

## Documentation URL
https://mcp-marketplace.io/server/finagent-pro

## Health Check URL
N/A — runs locally via stdio
