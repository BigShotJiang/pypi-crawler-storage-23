"""Tests for NewsService — hits real yfinance API."""

import pytest

from finagent_pro.services.news import NewsService


@pytest.fixture(scope="module")
def svc():
    return NewsService()


class TestGetNewsForTicker:
    def test_get_news_for_ticker(self, svc):
        result = svc.get_news(ticker="AAPL")
        assert isinstance(result, list)
        if len(result) > 0:
            article = result[0]
            assert "title" in article
            assert "source" in article
            assert "link" in article
            assert "published" in article


class TestGetNewsWithQuery:
    def test_get_news_with_query(self, svc):
        result = svc.get_news(query="earnings report")
        assert isinstance(result, list)


class TestGetNewsNoArgs:
    def test_get_news_no_args(self, svc):
        result = svc.get_news()
        assert result == []
