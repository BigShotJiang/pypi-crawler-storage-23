"""FinAgent Pro — Financial analysis MCP server with SEC filings and stock screening."""
