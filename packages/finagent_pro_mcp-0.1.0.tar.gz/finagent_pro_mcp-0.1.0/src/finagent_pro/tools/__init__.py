"""FinAgent Pro MCP tools."""
