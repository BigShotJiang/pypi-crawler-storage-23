"""sec_filings tool — premium SEC EDGAR filing access with license gating."""

from __future__ import annotations

import json

from finagent_pro.license import require_license
from finagent_pro.services.sec_edgar import SECEdgarService

_service = SECEdgarService()


def sec_filings(
    ticker: str,
    filing_type: str = "10-K",
    section: str | None = None,
    date_range: str | None = None,
) -> str:
    """Retrieve SEC filing data for a company.

    PRO FEATURE — requires a FinAgent Pro license key.
    """
    gate = require_license("sec_filings")
    if gate is not None:
        return gate

    try:
        result = _service.get_filing_section(
            ticker=ticker,
            filing_type=filing_type,
            section=section,
            date_range=date_range,
        )
    except Exception as exc:
        return json.dumps({"error": "service_error", "message": str(exc)})

    return json.dumps(result, default=str)
