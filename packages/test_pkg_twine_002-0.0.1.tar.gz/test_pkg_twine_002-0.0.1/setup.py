"""
Empty setup.py for test-pkg-twine-002
"""
from setuptools import setup

setup(
    name="test-pkg-twine-002",
    version="0.0.1",
    description="Empty placeholder package - reserved name",
    author="Package Protector",
    author_email="protector@example.com",
    py_modules=[],
)
