"""Version information for VassaAI SDK."""

__version__ = "0.1.3"
