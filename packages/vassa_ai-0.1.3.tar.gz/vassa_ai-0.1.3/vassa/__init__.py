"""
VassaAI Python SDK

A Python client library for the VassaAI multi-LLM consultation system.
"""

from vassa._version import __version__
from vassa.client import Client
from vassa.async_client import AsyncClient
from vassa.models import (
    CouncilResponse,
    CouncilUpdate,
    Conversation,
    Message,
    UsageStats,
    ModelResponse,
    ModelRanking,
    AggregateRanking,
    ChairmanSynthesis,
)
from vassa.exceptions import (
    VassaAIError,
    AuthenticationError,
    RateLimitError,
    ValidationError,
    NotFoundError,
    ConnectionError,
    APIError,
)
from vassa import auth

__all__ = [
    "__version__",
    "Client",
    "AsyncClient",
    "CouncilResponse",
    "CouncilUpdate",
    "Conversation",
    "Message",
    "UsageStats",
    "ModelResponse",
    "ModelRanking",
    "AggregateRanking",
    "ChairmanSynthesis",
    "VassaAIError",
    "AuthenticationError",
    "RateLimitError",
    "ValidationError",
    "NotFoundError",
    "ConnectionError",
    "APIError",
    "auth",
]
