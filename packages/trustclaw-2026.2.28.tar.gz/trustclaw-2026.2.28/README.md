# TrustClaw — Secure Remote Agent Execution with Audit Logging & Sandboxing

[![PyPI](https://img.shields.io/pypi/v/trustclaw.svg)](https://pypi.org/project/trustclaw/) [![Python](https://img.shields.io/pypi/pyversions/trustclaw.svg)](https://pypi.org/project/trustclaw/) [![license](https://img.shields.io/pypi/l/trustclaw.svg)](https://github.com/commandoperator/cmdop-sdk-python/blob/main/LICENSE)

![CMDOP Architecture](https://cmdop.com/images/architecture/vs-personal-agent.png)

TrustClaw delivers secure remote execution in Python, offering a robust audit log agent and sandboxed AI commands. Implement command allowlist Python to restrict actions. Unlike HashiCorp Vault, AWS SSM, osquery, and Teleport, TrustClaw focuses on lightweight, auditable remote agent command execution with strong sandboxing.

## Features

- Enforce command allowlist Python for strict control over executable commands.
- Provide secure remote execution Python, isolating agents from the host system.
- Generate a detailed audit log agent, capturing all command executions with timestamps.
- Sandbox AI commands, mitigating risks associated with untrusted code.
- Integrate easily into existing Python projects for immediate security benefits.

## Use Cases

- Allowlist safe commands to prevent destructive actions
- Audit every command with automatic timestamped logging
- Run AI agents in safe mode with injection protection

## Installation

```bash
pip install trustclaw
```

## Quick Start

```python
from trustclaw import TrustClaw

client = TrustClaw.remote(api_key="cmdop_live_xxx")

client.allow_commands(["ls", "cat", "git", "pip"])

client.exec("ls -la /var/www")
client.exec("git status")

result = client.safe_agent("Summarize recent log errors")
print(result)

print(client.audit_log)
```

## Links

- [CMDOP Homepage](https://cmdop.com)
- [Documentation](https://cmdop.com/docs/sdk/python/)
- [trustclaw on PyPI](https://pypi.org/project/trustclaw/)
- [GitHub](https://github.com/commandoperator/cmdop-sdk-python)
