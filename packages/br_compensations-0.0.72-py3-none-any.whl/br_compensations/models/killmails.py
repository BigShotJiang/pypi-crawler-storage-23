from django.db import models
from allianceauth.eveonline.models import EveCharacter
from eveuniverse.models import EveSolarSystem
from .battlereport import BattleReport
from django.utils.translation import gettext_lazy as _

class KillCompensation(models.Model):
    '''
        Таблица для хранения киллмэйлов, дополнительных данных и статуса компенсации
    '''
    STATUS_NEW = "N"
    STATUS_COMPLETE = "C"
    STATUS_REJECT = "R"
    STATUS_CHOICES = [
        (STATUS_NEW, _("Новый")),
        (STATUS_COMPLETE,_("Компенсирован")),
        (STATUS_REJECT,_("Отклонен"))
    ]
    
    TYPE_CTA = 'C'
    TYPE_HOMEDEF = 'H'
    TYPE_OTHER = 'O'
    ACTIVITY_TYPE = [
        (TYPE_CTA, _('Call To Arms')),
        (TYPE_HOMEDEF,_('Home defence')),
        (TYPE_OTHER, _('Other'))
    ]

    killmail_id = models.PositiveBigIntegerField(unique=True)
    hash = models.CharField(max_length=255,null=True)
    character_id = models.PositiveIntegerField()
    character_name = models.TextField(max_length=255,null=True,blank=True)
    alliance_id = models.PositiveIntegerField(null=True,blank=True)
    alliance_name = models.TextField(max_length=255,null=True,blank=True)
    corporation_id = models.PositiveIntegerField(null=True,blank=True)
    corporation_name = models.TextField(max_length=255,null=True,blank=True)
    loss_value = models.PositiveBigIntegerField()
    timestamp = models.DateTimeField(auto_now=False)
    activity_type = models.CharField(choices= ACTIVITY_TYPE,max_length=10, default=TYPE_CTA)
    
    # Используем существующие модели AllianceAuth
    ship_type = models.PositiveBigIntegerField(null=False)
    ship_name = models.TextField(null=False,blank=True)
    system = models.PositiveBigIntegerField(null=False)
    system_name = models.TextField(null=True,blank=True)
    
    status = models.CharField(
        max_length=1, 
        choices=STATUS_CHOICES, 
        default=STATUS_NEW,
        db_index=True
    )
    created_at = models.DateTimeField(auto_now_add=True)
    comment = models.TextField(blank=True)
    source = models.ForeignKey('BattleReport', on_delete=models.DO_NOTHING,null=True,blank=True) # type: ignore
    
    
    class Meta:
        ordering = ['-timestamp']
        indexes = [
            models.Index(fields=['status', 'timestamp']),
        ]

    def __str__(self):
        return f"Kill #{self.killmail_id} {self.character_name} {self.alliance_name} {self.system_name} {self.get_activity_type_display()} {self.get_status_display()}"
    def SolarSystem(self):
        return EveSolarSystem.objects.get(id=self.system)
    def EveCharacter(self):
        return EveCharacter.objects.get(id=self.character_id)
    def SourceType(self):
        return dict(BattleReport.REPORT_TYPE)[self.source.report_type] if self.source is not None else 'N/A'