from django.db import models
from django.utils.translation import gettext_lazy as _

class Settings(models.Model):
    '''
        Таблица для хранения настроек
    '''
    last_evetools_update = models.DateTimeField(null=True,blank=True)