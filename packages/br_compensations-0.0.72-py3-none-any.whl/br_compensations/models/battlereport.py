from django.db import models
from django.utils.translation import gettext_lazy as _

class BattleReport(models.Model):
    '''
        Таблица для хранения ссылок на киллмэйлы и баттл репорыт. Также содержит статус обработки.
    '''
    BATTLEREPORT = 'br'
    KILLMAIL = 'kill'
    REPORT_TYPE=[
        (BATTLEREPORT,_('Battle report')),
        (KILLMAIL,_('Kill Mail'))
    ]
    PROCESS_NEW = 'N'
    PROCESS_PROCESSING = 'P'
    PROCESS_COMPLETE = 'C'
    PROCESS_FAILED = 'F'
    PROCESS_REINITIALIZE = 'R'
    PROCESS_STATUS = [
        (PROCESS_NEW, _('New')),
        (PROCESS_PROCESSING,_('Process')),
        (PROCESS_COMPLETE,_('Complete')),
        (PROCESS_FAILED,_('Failed')),
        (PROCESS_REINITIALIZE,_('Reinitialize'))
    ]
    
    source_id = models.PositiveIntegerField(null=True,default=None)
    report_id = models.AutoField(primary_key=True)
    link = models.TextField(max_length=255,null=False)
    added_at = models.DateTimeField(auto_now=True)
    comment = models.TextField(null=True,blank=True)
    updatedAt = models.DateTimeField(null=True,blank=True)
    status = models.CharField(choices=PROCESS_STATUS, max_length=10, default=PROCESS_NEW)
    report_type = models.CharField(choices=REPORT_TYPE, max_length=8, default=BATTLEREPORT)
    
    class Meta:
        indexes = [
            models.Index(fields=['report_id'])
        ]
    def __str__(self):
        return f"Report link {self.link} ({self.get_report_type_display()}) { self.get_status_display()}"
    def uid(self)->str:
        '''
            id ссылки
        '''
        return   self.link.split("/")[-2] if self.link.endswith('/') else self.link.split("/")[-1]