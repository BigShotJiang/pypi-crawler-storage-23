from dataclasses import dataclass
from typing import Optional

@dataclass
class Victim:
    char: int
    corp: int
    ally: int
    ship: int
    char_name: str = None
    corp_name: str = None
    ally_name: str = None
    lossValue: float = 0.0
    ship_name: str = None
    
    def __post_init__(self):
        """Преобразуем строки в числа, если нужно"""
        if isinstance(self.char, str):
            self.char = int(self.char)
        if isinstance(self.corp, str):
            self.corp = int(self.corp)
        if isinstance(self.ally, str):
            self.ally = int(self.ally)
        if isinstance(self.lossValue, str):
            self.lossValue = float(self.lossValue)
        if isinstance(self.ship, str):
            self.ship = float(self.ship)

@dataclass
class Killmail:
    id: int
    system: int
    hash: str
    time: int
    system_name: str = None
    victim: Victim = None
    _id: Optional[int] = None
    
    def __post_init__(self):
        """Преобразуем строки в числа, если нужно"""
        if isinstance(self.id, str):
            self.id = int(self.id)
        if isinstance(self.system, str):
            self.system = int(self.system)
        if isinstance(self.time, str):
            self.time = int(self.time)
        if self._id and isinstance(self._id, str):
            self._id = int(self._id)