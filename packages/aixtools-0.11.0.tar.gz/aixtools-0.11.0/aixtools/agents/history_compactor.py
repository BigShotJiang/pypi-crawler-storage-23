"""
History compaction service for managing conversation context window.

This module provides functionality to manually compact/summarize conversation history
when triggered by the COMPACT_KEYWORD keyword in a user message. This allows users to
explicitly request compaction when they want to continue the conversation with a
summarized context.
"""

import json
from collections.abc import Awaitable, Callable, Sequence
from dataclasses import asdict

import tiktoken
from pydantic import BaseModel, model_validator
from pydantic_ai import Agent
from pydantic_ai.messages import (
    BuiltinToolCallPart,
    BuiltinToolReturnPart,
    FilePart,
    ModelMessage,
    ModelRequest,
    RetryPromptPart,
    SystemPromptPart,
    TextPart,
    ThinkingPart,
    ToolCallPart,
    ToolReturnPart,
    UserPromptPart,
)
from pydantic_ai.models import Model
from pydantic_ai.tools import RunContext

from aixtools.logging.logging_config import get_logger
from aixtools.utils.config import (
    BEDROCK_MODEL_NAME,
    HISTORY_COMPACTION_DEFAULT_MAX_TOKENS,
)

logger = get_logger(__name__)

# Maximum characters to show in tool result previews
TOOL_RESULT_PREVIEW_LENGTH = 200

# Maximum tokens to send to summarizer model (leave room for prompt + output)
SUMMARIZER_INPUT_MAX_TOKENS = 180_000

COMPACT_KEYWORD = "/compact"

# Headroom to reserve from model's context window for system prompt, MCP tools, and response generation
CONTEXT_WINDOW_HEADROOM = 50_000


def resolve_model_context_window() -> int:
    """Determine appropriate max_tokens for history compaction.

    Returns threshold for MESSAGE HISTORY only (not total model usage).
    Subtracts headroom from large context windows to leave room for:
    - System prompt
    - MCP tool definitions
    - Response generation

    Returns:
        int: max_tokens for message history compaction
    """
    normalized = (BEDROCK_MODEL_NAME or "").lower()

    # The following logic determines the context window size based on the model name.
    # Claude models (Opus, Sonnet 4+) support 1M context windows.
    # For these large context models, subtract headroom for system prompt, tools, and response.
    # It uses substring matching with explicit priority: if both 'opus' and 'sonnet' are present,
    # 'opus' takes precedence because it appears first in the mapping below.
    model_context_mapping: tuple[tuple[str, int], ...] = (
        ("opus", 1_000_000),
        ("sonnet", 1_000_000),
    )

    # Default to configured value for unknown models
    max_tokens = HISTORY_COMPACTION_DEFAULT_MAX_TOKENS

    # Check if this is a known large-context model
    for keyword, context_window in model_context_mapping:
        if keyword in normalized:
            # For large context windows, subtract headroom for system prompt, tools, and response
            max_tokens = context_window - CONTEXT_WINDOW_HEADROOM
            break

    return max_tokens


class CompactionError(Exception):
    """Raised when history compaction fails."""


class CompactionConfig(BaseModel):
    """Configuration for history compaction."""

    max_tokens: int

    @model_validator(mode="before")
    @classmethod
    def set_default_tokens(cls, values: dict) -> dict:
        """
        Populate default max_tokens at instance creation time.
        This avoids calling resolve_model_context_window at import time.
        """
        if "max_tokens" not in values:
            values["max_tokens"] = resolve_model_context_window()
        return values


class CompactionResult(BaseModel):
    """Result of a history compaction operation."""

    original_messages: int
    compacted_messages: int
    original_tokens: int
    compacted_tokens: int
    summary: str


SUMMARIZATION_REQUEST_PROMPT = """Summarize the following conversation concisely, preserving key information,
decisions made, and important context that would be needed to continue the conversation. List key files that
were read, modified, or created. Focus on facts and outcomes rather than the back-and-forth dialogue.
Avoid adding a markdown header.

Conversation:
{conversation}

Summary:"""

SUMMARY_WRAPPED = """This session is being continued from a previous conversation that was compacted. \
If a task was in progress, continue from where it left off. You can re-read any files mentioned above \
if you need their current contents. Do not ask the user to repeat information that should be in the summary.

The conversation is summarized below:

{summary}


"""


class HistoryCompactor:
    """
    Manages conversation history compaction for pydantic-ai agents.

    Provides manual compaction triggered by the presence of the COMPACT_KEYWORD keyword
    in the last message.
    """

    # Tokenizer for counting tokens - class attribute loaded once when class is defined
    _tokenizer = tiktoken.get_encoding("cl100k_base")

    def __init__(
        self,
        model: Model,
        config: CompactionConfig | None = None,
        on_compaction: Callable[[CompactionResult], Awaitable[None]] | None = None,
    ):
        """Initialize the HistoryCompactor.

        Args:
            config: Compaction configuration
            model: Model to use for summarization
            on_compaction: Optional async callback called when compaction occurs
        """
        self.config = config or CompactionConfig()
        self.model = model
        self.on_compaction = on_compaction

        logger.info("Created compactor with config: %s", self.config)

    def _extract_compact_info(self, messages: list[ModelMessage]) -> tuple[bool, str | None]:
        """Check if the last ModelRequest contains the COMPACT_KEYWORD and extract any extra prompt.

        Args:
            messages: The message history to check

        Returns:
            A tuple of (has_keyword, extra_prompt) where:
            - has_keyword: True if the last ModelRequest starts with COMPACT_KEYWORD
            - extra_prompt: Any text following the COMPACT_KEYWORD, or None
        """
        if not messages:
            return False, None

        # Find the last ModelRequest (user message) in the history
        last_request = None
        for message in reversed(messages):
            if isinstance(message, ModelRequest):
                last_request = message
                break

        if last_request is None:
            return False, None

        # Check each part of the last ModelRequest for the compact keyword
        keyword = COMPACT_KEYWORD.strip().lower()
        keyword_len = len(keyword)
        for part in last_request.parts:
            if isinstance(part, (TextPart, UserPromptPart)):
                content = part.content
                if isinstance(content, str):
                    stripped = content.strip()
                    if stripped.lower().startswith(keyword):
                        # Extract any text after the keyword
                        extra_prompt = stripped[keyword_len:].strip()
                        return True, extra_prompt if extra_prompt else None
                elif isinstance(content, Sequence):
                    for item in content:
                        if isinstance(item, str):
                            stripped = item.strip()
                            if stripped.lower().startswith(keyword):
                                extra_prompt = stripped[keyword_len:].strip()
                                return True, extra_prompt if extra_prompt else None
        return False, None

    def _extract_text_for_summary(self, part) -> str:
        """Extract readable text from a message part for summarization.

        Produces abbreviated, human-readable format suitable for LLM summarization:
        - TextPart, UserPromptPart, SystemPromptPart, ThinkingPart: extract content directly
        - ToolCallPart, BuiltinToolCallPart: format as [Tool call: name(args)] with truncation
        - ToolReturnPart, BuiltinToolReturnPart: format as [Tool result (name): content] with truncation
        - RetryPromptPart: format as [Retry (tool_name): content] with truncation
        - FilePart: preserve file path if available
        """
        result = None

        if isinstance(part, (TextPart, UserPromptPart, SystemPromptPart, ThinkingPart)):
            content = part.content
            if isinstance(content, str):
                result = content
            elif isinstance(content, Sequence):
                result = " ".join(str(item) for item in content if isinstance(item, str))
        elif isinstance(part, (ToolCallPart, BuiltinToolCallPart)):
            args_str = str(part.args)
            if len(args_str) > TOOL_RESULT_PREVIEW_LENGTH:
                args_str = args_str[:TOOL_RESULT_PREVIEW_LENGTH] + "..."
            result = f"[Tool call: {part.tool_name}({args_str})]"
        elif isinstance(part, (ToolReturnPart, BuiltinToolReturnPart)):
            content = part.content
            content_str = content if isinstance(content, str) else str(content)
            if len(content_str) > TOOL_RESULT_PREVIEW_LENGTH:
                content_str = content_str[:TOOL_RESULT_PREVIEW_LENGTH] + "..."
            result = f"[Tool result ({part.tool_name}): {content_str}]"
        elif isinstance(part, RetryPromptPart):
            content = part.content
            content_str = content if isinstance(content, str) else str(content)
            if len(content_str) > TOOL_RESULT_PREVIEW_LENGTH:
                content_str = content_str[:TOOL_RESULT_PREVIEW_LENGTH] + "..."
            result = f"[Retry ({part.tool_name}): {content_str}]"
        elif isinstance(part, FilePart):
            file_id = part.id or "unknown"
            file_size = len(part.content) if part.content else 0
            result = f"[File ({file_id}): {file_size} bytes]"

        return result if result is not None else str(part)

    def _extract_message_for_summary(self, message: ModelMessage) -> str:
        """Extract readable text from a message for summarization."""
        texts = [self._extract_text_for_summary(part) for part in message.parts]
        return " ".join(texts)

    @classmethod
    def _serialize_part_for_tokens(cls, part) -> str:
        """Serialize a message part for accurate token counting.

        Uses JSON serialization to match actual API payload size.
        """
        try:
            return json.dumps(asdict(part), default=str)
        except (TypeError, ValueError):
            return str(part)

    @classmethod
    def _serialize_message_for_tokens(cls, message: ModelMessage) -> str:
        """Serialize a message for accurate token counting."""
        parts_json = [cls._serialize_part_for_tokens(part) for part in message.parts]
        return " ".join(parts_json)

    @classmethod
    def _count_text_tokens(cls, text: str) -> int:
        """Count tokens in a text string using tiktoken."""
        return len(cls._tokenizer.encode(text))

    @classmethod
    def count_tokens(cls, messages: list[ModelMessage]) -> int:
        """Count the tokens in a list of messages using tiktoken.

        Uses JSON serialization for accurate token estimation matching API payload.
        This is a class method and can be called without creating an instance.
        """
        if not messages:
            return 0

        total_tokens = 0
        for message in messages:
            text = cls._serialize_message_for_tokens(message)
            total_tokens += cls._count_text_tokens(text)

        return total_tokens

    async def compact(self, messages: list[ModelMessage]) -> list[ModelMessage]:
        """Compact the message history by summarizing all messages.

        Compaction is only triggered when the last message contains the COMPACT_KEYWORD keyword.
        Any text following the keyword is used as an extra prompt/instruction for the summarizer.
        Replaces the entire message history with a single summary message.

        Note: We count actual message history tokens, not model usage which includes
        system prompt + tool descriptions that we can't compact.
        """
        token_count = self.count_tokens(messages)
        total_messages = len(messages)

        # Check for compact keyword and extract any extra prompt
        has_keyword, extra_prompt = self._extract_compact_info(messages)
        if not has_keyword:
            logger.debug("No COMPACT_KEYWORD found, skipping compaction")
            return messages

        if extra_prompt:
            logger.info(
                "Manual compaction triggered with extra prompt: %d messages, %d tokens, prompt='%s'",
                total_messages,
                token_count,
                extra_prompt[:50] + "..." if len(extra_prompt) > 50 else extra_prompt,
            )
        else:
            logger.info("Manual compaction triggered: %d messages, %d tokens", total_messages, token_count)

        # Summarize all messages with optional extra prompt
        summary = await self._summarize_messages(messages, extra_prompt=extra_prompt)
        summary_content = SUMMARY_WRAPPED.format(summary=summary)
        messages_after_summary = [ModelRequest(parts=[SystemPromptPart(content=summary_content)])]
        token_count_after_summary = self.count_tokens(messages_after_summary)
        logger.info(
            "Compaction complete: %d -> %d messages, %d -> %d tokens",
            total_messages,
            len(messages_after_summary),
            token_count,
            token_count_after_summary,
        )

        # Call the compaction callback if set
        if self.on_compaction:
            result = CompactionResult(
                original_messages=total_messages,
                compacted_messages=len(messages_after_summary),
                original_tokens=token_count,
                compacted_tokens=token_count_after_summary,
                summary=summary_content,
            )
            await self.on_compaction(result)
        return messages_after_summary

    async def _summarize_messages(self, messages: list[ModelMessage], extra_prompt: str | None = None) -> str:
        """Summarize a list of messages into a text summary.

        Args:
            messages: The messages to summarize
            extra_prompt: Optional extra instructions to include in the summarization request
        """
        text_parts = []
        for msg in messages:
            role = "User" if isinstance(msg, ModelRequest) else "Assistant"
            content = self._extract_message_for_summary(msg)
            text_parts.append(f"{role}: {content}")

        conversation_text = "\n".join(text_parts)

        # Call the summarizer with optional extra prompt
        summary = await self._call_summarizer(conversation_text, extra_prompt=extra_prompt)
        return summary

    async def _call_summarizer(self, text: str, extra_prompt: str | None = None) -> str:
        """Call the model to generate a summary of the conversation.

        Args:
            text: The conversation text to summarize
            extra_prompt: Optional extra instructions to guide the summarization
        """
        # Check input text is not too long for the summarizer model
        text_tokens = self._count_text_tokens(text)
        if text_tokens > SUMMARIZER_INPUT_MAX_TOKENS:
            raise CompactionError(
                f"Conversation too long for summarization ({text_tokens} tokens > {SUMMARIZER_INPUT_MAX_TOKENS} limit)"
            )

        summarizer = Agent(
            model=self.model,
            output_type=str,
        )
        prompt = SUMMARIZATION_REQUEST_PROMPT.format(conversation=text)

        # Append extra prompt if provided
        if extra_prompt:
            prompt += f"\n\nAdditional instructions: {extra_prompt}"

        result = await summarizer.run(prompt)
        return result.output

    def create_history_processor(self) -> Callable[[list[ModelMessage]], Awaitable[list[ModelMessage]]]:
        """Create a pydantic-ai compatible history processor."""

        async def processor(messages: list[ModelMessage]) -> list[ModelMessage]:
            return await self.compact(messages)

        return processor

    def create_pydantic_ai_history_processor(
        self,
    ) -> Callable[[RunContext, list[ModelMessage]], Awaitable[list[ModelMessage]]]:
        """Create a context-aware history processor that uses RunContext for accurate token counting."""
        logger.info("Creating context-aware processor (max=%s)", self.config.max_tokens)

        async def processor(_ctx: RunContext, messages: list[ModelMessage]) -> list[ModelMessage]:
            return await self.compact(messages)

        return processor
