"""Registry for managing loaded skills per user session."""

from pathlib import Path, PurePosixPath

from podkit import SessionProxy, get_docker_session
from podkit.constants import DEFAULT_CPU_LIMIT, DEFAULT_MEMORY_LIMIT
from podkit.core.models import ContainerConfig, Mount
from pydantic import BaseModel, ConfigDict, Field

from aixtools.context import SessionIdTuple
from aixtools.logging.logging_config import get_logger
from aixtools.server import get_session_id_tuple
from aixtools.skills.config import DEFAULT_SKILL_SANDBOX_IMAGE, DEFAULT_SKILL_SANDBOX_NETWORK
from aixtools.skills.manifest import SkillValidationError
from aixtools.skills.model import ActivateSkillResult, Skill, SkillException, SkillResult, SkillSummary
from aixtools.skills.parser import SKILL_FILE_NAME, parse_skill_md
from aixtools.utils.config import DATA_DIR, HOST_DATA_DIR

logger = get_logger(__name__)
SKILLS_WORKSPACE_DIR = "skills"
METADATA_SANDBOX_IMAGE = "sandbox_image"
METADATA_SANDBOX_RAM_LIMIT = "sandbox_ram_limit"
METADATA_SANDBOX_CPU_LIMIT = "sandbox_cpu_limit"
SKILL_CONTAINER_PATH = PurePosixPath("/skills")
SANDBOX_LIFETIME_SECONDS = 30 * 60


class _SkillRecord(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    skill: Skill = Field(description="Parsed skill definition")
    source_path: Path = Field(description="Path to the skill source")
    is_activated: bool = Field(default=False, description="Whether the skill has been activated")
    source_path_host: Path | None = Field(default=None, description="Path to the skill source host")
    session_proxy: SessionProxy | None = Field(default=None, description="Skill session proxy to sandbox")


class SkillRegistry:
    """Registry for managing skills loaded from SKILL.md files."""

    def __init__(self, skills_folder: Path | str | None = None, skills_folder_host: Path | str | None = None):
        self._skill_records: dict[str, _SkillRecord] = {}
        if skills_folder:
            self.load_skills_from_folder(
                folder=Path(skills_folder),
                folder_host=Path(skills_folder_host) if skills_folder_host else None,
            )

    def activate_skill(self, skill_name: str) -> ActivateSkillResult:
        """Activate a skill by loading its definition and returning instructions.

        Note: Containers are created lazily when skill_exec is first called.
        """
        record = self._skill_records.get(skill_name)
        if not record:
            return ActivateSkillResult(success=False, message=f"Skill '{skill_name}' not found.")
        logger.info("Activated skill: %s", skill_name)
        record.is_activated = True
        return ActivateSkillResult(
            success=True,
            skill=SkillResult(**record.skill.model_dump(exclude={"metadata"})),
        )

    def get_session_proxy(self, skill_name: str) -> SessionProxy:
        """Get session proxy for skill's container in current session."""
        return self._get_skill_record(skill_name).session_proxy

    def get_skill_source_path(self, skill_name: str) -> Path | None:
        """Get the source path for a skill."""
        return self._get_skill_record(skill_name).source_path

    def ensure_sandbox(self, skill_name: str) -> SessionProxy:
        """Ensure sandbox container exists for this skill and session, creating if needed.

        Raises:
            Exception: If skill not found or container creation fails
        """
        record = self._get_skill_record(skill_name)
        if record.session_proxy:
            logger.info("Reusing existing sandbox for skill: %s", skill_name)
            return record.session_proxy

        (user_id, session_id) = get_session_id_tuple()
        session_proxy = _start_sandbox((user_id, session_id), record)
        record.session_proxy = session_proxy
        cpu_limit = record.skill.metadata.get(METADATA_SANDBOX_CPU_LIMIT)
        ram_limit = record.skill.metadata.get(METADATA_SANDBOX_RAM_LIMIT)
        logger.info(
            "Started sandbox for skill: %s, user: %s, session: %s, image: %s(cpu: %s, ram: %s)",
            skill_name,
            user_id,
            session_id,
            record.skill.metadata.get(METADATA_SANDBOX_IMAGE, DEFAULT_SKILL_SANDBOX_IMAGE),
            cpu_limit if cpu_limit else "default",
            ram_limit if ram_limit else "default",
        )

        return session_proxy

    def get_skill(self, name: str) -> Skill:
        """Get a skill by its name."""
        return self._get_skill_record(name).skill

    def list_skills(self) -> list[SkillSummary]:
        """Return list of available skills with name and description."""
        return [
            SkillSummary(name=record.skill.name, description=record.skill.description)
            for record in self._skill_records.values()
        ]

    def load_skill(self, path: Path, host_path: Path | None = None):
        """Load a skill compatible with anthropic skills specs: https://agentskills.io/specification"""
        try:
            parsed = parse_skill_md(path)
            skill = Skill(
                name=parsed.name,
                description=parsed.description,
                instructions=parsed.instructions,
                metadata=parsed.metadata,
            )
            self._skill_records[skill.name] = _SkillRecord(
                skill=skill,
                source_path=path,
                source_path_host=host_path,
            )
            logger.info("Loaded skill: %s from %s", skill.name, path)
        except SkillValidationError as e:
            logger.error("Failed to load skill from %s: %s", path, e)
        except Exception as e:
            logger.exception("Unexpected error while loading skill from %s: %s", path, e)

    def _get_skill_record(self, skill_name: str) -> _SkillRecord:
        """Get the skill record by name."""
        record = self._skill_records.get(skill_name)
        if not record:
            raise SkillException(f"Skill '{skill_name}' not found.")
        return record

    def load_skills_from_folder(self, folder: Path, folder_host: Path | None = None):
        """Load all skills from a folder containing skill subdirectories.

        This method can be called multiple times to load skills from different sources.
        Skills loaded later will override skills with the same name from earlier loads,
        enabling priority-based skill resolution (e.g., user skills overriding system skills).

        Args:
            folder: Path to the folder containing skill subdirectories
            folder_host: Host path for the folder (for Docker volume mounting). If None,
                        the folder path is used directly.

        Raises:
            SkillException: If folder doesn't exist or is not a directory
        """
        if not folder.exists():
            logger.error("Skills folder does not exist: %s", folder)
            raise SkillException("Skills folder does not exist")

        if not folder.is_dir():
            raise SkillException("Skill path is not a directory")

        for skill_dir in folder.iterdir():
            if not skill_dir.is_dir():
                continue
            if not (skill_dir / SKILL_FILE_NAME).exists():
                logger.warning(f"{SKILL_FILE_NAME} does not exist: %s", skill_dir)
                continue

            skill_host_dir = _to_host_path(
                skill_source=skill_dir,
                skills_dir_base=folder,
                skills_dir_host=folder_host,
            )
            self.load_skill(skill_dir, skill_host_dir)


def _start_sandbox(ctx: SessionIdTuple, record: _SkillRecord) -> SessionProxy:
    """Start sandbox container for the skill if sandbox_image is configured."""
    sandbox_image = record.skill.metadata.get(METADATA_SANDBOX_IMAGE)
    if not sandbox_image:
        sandbox_image = DEFAULT_SKILL_SANDBOX_IMAGE
        logger.info("No sandbox image specified for skill '%s', using default image", record.skill.name)
    user_id, session_id = ctx
    cpu_limit = record.skill.metadata.get(METADATA_SANDBOX_CPU_LIMIT)
    ram_limit = record.skill.metadata.get(METADATA_SANDBOX_RAM_LIMIT)
    config = ContainerConfig(
        image=sandbox_image,
        container_lifetime_seconds=SANDBOX_LIFETIME_SECONDS,
        volumes=[
            Mount(
                source=record.source_path_host or record.source_path,
                target=SKILL_CONTAINER_PATH / record.skill.name,
                read_only=True,
            ),
        ],
        memory_limit=ram_limit if ram_limit else DEFAULT_MEMORY_LIMIT,
        networks=[DEFAULT_SKILL_SANDBOX_NETWORK],
        cpu_limit=cpu_limit if cpu_limit else DEFAULT_CPU_LIMIT,
        auto_remove=True,
    )

    return get_docker_session(
        user_id=user_id,
        session_id=session_id,
        workspace=DATA_DIR,
        workspace_host=HOST_DATA_DIR,
        config=config,
        container_prefix=f"podkit-skill_{sandbox_image}",
    )


def build_registry_from_sources(
    sources: list[tuple[Path | None, Path | None]],
) -> SkillRegistry:
    """Build a SkillRegistry from multiple folder sources.

    Sources are loaded in order - later sources override earlier ones.
    This enables priority-based skill resolution (e.g., user skills overriding system skills).

    Args:
        sources: List of (folder, folder_host) tuples. None values are skipped.

    Returns:
        SkillRegistry with all skills loaded from the provided sources.
    """
    registry = SkillRegistry()
    for folder, folder_host in sources:
        if folder and folder.exists():
            try:
                registry.load_skills_from_folder(folder=folder, folder_host=folder_host)
            except Exception as e:
                logger.warning("Failed to load skills from %s: %s", folder, e)
    return registry


def _to_host_path(*, skill_source: Path, skills_dir_base: Path, skills_dir_host: Path) -> Path | None:
    """Convert skill source path to host path based on base and host skills directories."""
    if not skills_dir_host:
        return None

    try:
        relative_path = skill_source.relative_to(skills_dir_base)
        return skills_dir_host / relative_path
    except ValueError as e:
        raise SkillException(
            f"Cannot determine host path for skill source {skill_source} not under base {skills_dir_base}"
        ) from e
