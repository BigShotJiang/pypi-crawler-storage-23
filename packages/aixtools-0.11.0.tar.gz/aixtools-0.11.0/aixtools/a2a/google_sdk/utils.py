"""Utilities for handling A2A SDK agent cards and connections."""

import httpx
from a2a.client import A2ACardResolver
from a2a.types import AgentCard
from a2a.utils import AGENT_CARD_WELL_KNOWN_PATH, PREV_AGENT_CARD_WELL_KNOWN_PATH

from aixtools.context import (
    DEFAULT_SESSION_ID,
    DEFAULT_USER_ID,
    SessionIdTuple,
    session_id_var,
    user_id_var,
)
from aixtools.logging.logging_config import get_logger

logger = get_logger(__name__)


class AgentCardLoadFailedError(Exception):
    """Exception raised when loading an agent card fails."""


async def get_agent_card(client: httpx.AsyncClient, address: str) -> AgentCard:
    """Retrieve the agent card from the given agent address."""
    warnings = []
    for card_path in [AGENT_CARD_WELL_KNOWN_PATH, PREV_AGENT_CARD_WELL_KNOWN_PATH]:
        try:
            card_resolver = A2ACardResolver(client, address, card_path)
            card = await card_resolver.get_agent_card()
            card.url = address
            return card
        except Exception as e:
            warnings.append(f"Error retrieving agent card from {address} at path {card_path}: {e}")

    for warning in warnings:
        logger.warning(warning)
    raise AgentCardLoadFailedError(f"Failed to load agent card from {address}")


def card2description(card: AgentCard) -> str:
    """Convert agent card to a description string."""
    descr = f"{card.name}: {card.description}\n"
    for skill in card.skills:
        descr += f"\t - {skill.name}: {skill.description}\n"
    return descr


def get_session_id_tuple() -> SessionIdTuple:
    """Get the current session ID tuple."""
    user_id = user_id_var.get() or DEFAULT_USER_ID
    session_id = session_id_var.get() or DEFAULT_SESSION_ID
    return user_id, session_id
