"""Configuration constants for the google_sdk a2a modules."""

DEFAULT_FUNCTION_TOOLS_MAX_RETRIES = 3
DEFAULT_A2A_TIMEOUT = 60.0
