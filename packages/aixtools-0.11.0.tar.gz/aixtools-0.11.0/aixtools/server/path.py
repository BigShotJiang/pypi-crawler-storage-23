"""
Workspace path handling for user sessions.

Note on "host" terminology in this module:
    Throughout this file, "host" refers to the environment where the backend or MCP service
    process runs. This could be the actual host machine or a Docker container (e.g., the
    backend container or MCP service container). It is distinct from the "sandbox container"
    which is an isolated container where user code executes.
"""

import posixpath
from pathlib import Path, PurePosixPath
from typing import Literal

from ..context import SessionIdTuple
from ..utils.config import DATA_DIR
from .utils import get_session_id_tuple

WorkspaceType = Literal["session", "user"]

WORKSPACES_ROOT_DIR = (DATA_DIR / "workspaces").resolve()  # Path in the backend/MCP service process
CONTAINER_WORKSPACE_PATH = PurePosixPath("/workspace")  # Path inside the sandbox container for workspace
CONTAINER_USER_HOME_PATH = PurePosixPath("/user-home")  # Path inside the sandbox container for user home
USER_HOME_DIR_NAME = "_home"  # Directory name for user home under user's workspace root
PRIVATE_DATA_DIR = (
    WORKSPACES_ROOT_DIR / "_private-data"
).resolve()  # Root dir for the .private_data files used to mark conversations as private


def get_workspace_path(
    session_id_tuple: SessionIdTuple | None = None,
    workspace_type: WorkspaceType = "session",
) -> Path:
    """
    Get the workspace path (as available in the backend or MCP service process).

    For session workspace, returns path in the format:
        <DATA_DIR>/workspaces/<user_id>/<session_id>

    For user home, returns path in the format:
        <DATA_DIR>/workspaces/<user_id>/_home

    where `DATA_DIR` should come from the environment variables.

    Example workspace paths:
        Session: /data/workspaces/foo-user/bar-session
        User home: /data/workspaces/foo-user/_home

    If `session_id_tuple` is None, the current FastMCP request HTTP headers are used
    to get the user and session IDs.

    Args:
        session_id_tuple: Tuple of (user_id, session_id) or None.
        workspace_type: "session" (default) for session-scoped workspace,
                       "user" for persistent user home.

    Returns: The workspace path as a Path object.

    Raises:
        ValueError: If workspace_type is not "session" or "user".
    """
    if workspace_type not in ("session", "user"):
        raise ValueError(f"Invalid workspace_type: '{workspace_type}'. Must be 'session' or 'user'.")

    user_id, session_id = session_id_tuple if session_id_tuple is not None else get_session_id_tuple()
    user_id = user_id.lower()

    if workspace_type == "user":
        return WORKSPACES_ROOT_DIR / user_id / USER_HOME_DIR_NAME

    return WORKSPACES_ROOT_DIR / user_id / session_id


def get_private_data_path(session_id_tuple: SessionIdTuple | None = None) -> Path:
    """
    Returns the path to the private data file for a given conversation:

        <DATA_DIR>/private-data/.private_data-<user_id>-<session_id>

    where `DATA_DIR` should come from the environment variables

    If `session_id_tuple` is None, the current FastMCP request HTTP headers are used
    to get the user and session IDs.

    Args:
        session_id_tuple: Tuple of (user_id, session_id) or None.

    Returns: The path to the private data file for the given context.
    """
    user_id, session_id = session_id_tuple if session_id_tuple is not None else get_session_id_tuple()
    user_id = user_id.lower()  # to handle tuple passed directly
    return PRIVATE_DATA_DIR / user_id / f"{session_id}.json"


def get_workspace_path_sandbox(workspace_type: WorkspaceType = "session") -> PurePosixPath:
    """
    Get the workspace path in the sandbox container.

    We return PurePosixPath to ensure compatibility with Linux containers.

    The paths inside the sandbox cannot be resolved (because they don't exist
    on the host), so we use PurePosixPath instead of Path. Also Path could be
    a WindowsPath on Windows hosts, which would be incorrect for Linux containers.

    Args:
        workspace_type: "session" (default) for session-scoped workspace,
                       "user" for persistent user home.

    Returns: The workspace path as a PurePosixPath object.

    Raises:
        ValueError: If workspace_type is not "session" or "user".
    """
    if workspace_type == "user":
        return CONTAINER_USER_HOME_PATH
    if workspace_type == "session":
        return CONTAINER_WORKSPACE_PATH
    raise ValueError(f"Invalid workspace_type: '{workspace_type}'. Must be 'session' or 'user'.")


# Convenience functions for common workspace types
def get_session_workspace_path_sandbox() -> PurePosixPath:
    """Get the session workspace path in the sandbox container."""
    return get_workspace_path_sandbox(workspace_type="session")


def get_user_home_path_sandbox() -> PurePosixPath:
    """Get the user home path in the sandbox container."""
    return get_workspace_path_sandbox(workspace_type="user")


def path_normalize(p: PurePosixPath) -> PurePosixPath:
    """
    Normalize a PurePosixPath (remove redundant separators and up-level references).
    """
    return PurePosixPath(posixpath.normpath(p.as_posix()))


def path_chroot(path: Path, old_root: Path, new_root: Path) -> Path:
    """
    Change the root of a given path from old_root to new_root.
    If the path is not absolute (e.g. 'my_file.txt', './my_file.txt', 'my_dir/file.txt')
    we treat it as relative to the 'new_root'
    """
    if not Path(path).is_absolute():
        new_path = Path(new_root / path).resolve()
        new_root = Path(new_root).resolve()
        if not new_path.is_relative_to(new_root):
            raise ValueError(f"Path must not escape the workspace root: '{path}'")
        return Path(new_path)
    # Otherwise, we treat it as absolute and change the root
    return new_root / Path(path).relative_to(old_root)


def _detect_workspace_type_from_container_path(path: PurePosixPath) -> WorkspaceType | None:
    """
    Detect workspace type from container path prefix.

    The path is normalized first to prevent traversal attacks like
    /user-home/../workspace/ being detected as user home.

    Returns:
        "session" if path starts with /workspace
        "user" if path starts with /user-home
        None if path doesn't match any known workspace prefix
    """
    # Normalize path first to resolve .. and prevent traversal attacks
    normalized = path_normalize(path)

    if normalized.is_relative_to(CONTAINER_USER_HOME_PATH):
        return "user"
    if normalized.is_relative_to(CONTAINER_WORKSPACE_PATH):
        return "session"
    return None


def container_to_host_path(path: PurePosixPath, *, session_id_tuple: SessionIdTuple | None = None) -> Path:
    """
    Convert a path in a sandbox container to a host path.

    Auto-detects workspace type:
    - /workspace/... → session workspace
    - /user-home/... → user home
    - Relative paths → session workspace (backward compatible)

    Args:
        path: Path inside the container (must be under /workspace or /user-home).
        session_id_tuple: Tuple of (user_id, session_id) or None.

    Returns:
        Path to the file on the host.

    Raises:
        ValueError: If the path is not a subdirectory of a known workspace path or escapes the workspace root.
    """
    # Relative paths are treated as relative to the session workspace (backward compatible)
    if not PurePosixPath(path).is_absolute():
        new_root = get_workspace_path(session_id_tuple, workspace_type="session")
        # Resolve paths to prevent escaping the workspace root
        new_path = Path(new_root / path).resolve()
        if not new_path.is_relative_to(new_root):
            raise ValueError(f"Path must not escape the workspace root: '{path}'")
        return new_path

    # Normalize path to resolve .. and prevent traversal attacks
    normalized_path = path_normalize(path)

    # Auto-detect workspace type from normalized path prefix
    workspace_type = _detect_workspace_type_from_container_path(normalized_path)

    if workspace_type is None:
        raise ValueError(
            f"Container path must be a subdir of '{CONTAINER_WORKSPACE_PATH}' or "
            f"'{CONTAINER_USER_HOME_PATH}', got '{path}' instead"
        )

    old_root = get_workspace_path_sandbox(workspace_type)
    new_root = get_workspace_path(session_id_tuple, workspace_type=workspace_type)

    try:
        relative = normalized_path.relative_to(old_root)
        host_path = (new_root / relative).resolve()
        # Verify the final path is still within the workspace root (defense in depth)
        if not host_path.is_relative_to(new_root):
            raise ValueError(f"Path must not escape the workspace root: '{path}'")
        return host_path
    except ValueError as e:
        raise ValueError(f"Container path must be a subdir of '{old_root}', got '{path}' instead") from e


def host_to_container_path(path: Path, *, session_id_tuple: SessionIdTuple | None = None) -> PurePosixPath:
    """
    Convert a host path to a path in a sandbox container.
    Paths inside the sandbox MUST be PurePosixPath (i.e. we use Linux containers).

    Auto-detects workspace type based on which root the path is under:
    - Session workspace root → /workspace/...
    - User home root → /user-home/...
    - Relative paths → /workspace/... (backward compatible)

    Args:
        path: Path on the host.
        session_id_tuple: Tuple of (user_id, session_id) or None.

    Returns:
        Path inside the sandbox container.

    Raises:
        ValueError: If the path is not under a known workspace root or escapes the workspace.
    """
    session_root = get_workspace_path(session_id_tuple, workspace_type="session")
    user_root = get_workspace_path(session_id_tuple, workspace_type="user")

    # Relative paths are treated as relative to the session workspace (backward compatible)
    if not Path(path).is_absolute():
        new_root = get_workspace_path_sandbox(workspace_type="session")
        # Normalize paths to prevent escaping the workspace root (we cannot resolve PurePosixPaths)
        new_path = path_normalize(new_root / path)
        if not new_path.is_relative_to(new_root):
            raise ValueError(f"Path must not escape the workspace root: '{path}'")
        return new_path

    # Resolve the path to handle any symlinks or relative components
    resolved_path = Path(path).resolve()

    # Try user home first (more specific path check)
    try:
        relative = resolved_path.relative_to(user_root)
        return get_workspace_path_sandbox(workspace_type="user") / relative
    except ValueError:
        pass

    # Try session workspace
    try:
        relative = resolved_path.relative_to(session_root)
        return get_workspace_path_sandbox(workspace_type="session") / relative
    except ValueError:
        pass

    raise ValueError(f"Host path must be a subdir of '{session_root}' or '{user_root}', got '{path}' instead")
