.. _libdoc_tensor_random_distributions:

Distributions
=============

.. automodule:: pytensor.tensor.random.basic
   :members:
   :special-members: __call__
