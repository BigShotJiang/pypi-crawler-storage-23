(libdoc_xtenor_type)=

# `xtensor.type` -- Types and Variables

## XTensorVariable creation functions

```{eval-rst}
.. automodule:: pytensor.xtensor.type
   :members: xtensor, xtensor_constant, as_xtensor

```

## XTensor Type and Variable classes

```{eval-rst}
.. automodule:: pytensor.xtensor.type
   :members: XTensorType, XTensorVariable, XTensorConstant
```


