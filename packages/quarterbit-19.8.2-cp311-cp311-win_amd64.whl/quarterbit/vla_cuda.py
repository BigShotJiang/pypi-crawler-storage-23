"""
VLA CUDA Quantization

Clouthier Simulation Labs
"""

import torch
import os
import ctypes
from typing import Tuple, Optional

# Global state for kernel loading
_CUDA_LIB = None
_KERNEL_LOADED = False
_KERNEL_AVAILABLE = False

def _get_lib_path():
    """Get path to pre-compiled VLA quantization library."""
    # Check in package lib directory
    pkg_dir = os.path.dirname(os.path.abspath(__file__))
    lib_dir = os.path.join(pkg_dir, 'lib')

    if os.name == 'nt':  # Windows
        lib_name = 'vla_quant.dll'
    else:  # Linux
        lib_name = 'libvla_quant.so'

    lib_path = os.path.join(lib_dir, lib_name)
    if os.path.exists(lib_path):
        return lib_path

    return None

def _try_load_kernel():
    """Attempt to load the pre-compiled CUDA kernel."""
    global _CUDA_LIB, _KERNEL_LOADED, _KERNEL_AVAILABLE

    if _KERNEL_LOADED:
        return _KERNEL_AVAILABLE

    _KERNEL_LOADED = True

    # First try pre-compiled library
    lib_path = _get_lib_path()
    if lib_path:
        try:
            _CUDA_LIB = ctypes.CDLL(lib_path)

            # Set up function signatures
            _CUDA_LIB.vla_quantize_gpu.argtypes = [
                ctypes.c_void_p,  # weight_ptr
                ctypes.c_void_p,  # int4_packed_ptr
                ctypes.c_void_p,  # int4_scale_ptr
                ctypes.c_void_p,  # error_packed_ptr
                ctypes.c_void_p,  # error_scale_ptr
                ctypes.c_int,     # rows
                ctypes.c_int,     # cols
                ctypes.c_void_p,  # stream (NULL for default)
            ]
            _CUDA_LIB.vla_quantize_gpu.restype = None

            _KERNEL_AVAILABLE = True
            return True
        except Exception as e:
            print(f"VLA CUDA kernel load failed: {e}")
            _CUDA_LIB = None

    # No pre-compiled library found
    print(f"VLA CUDA kernel not available: pre-compiled library not found at {lib_path}")
    return False

def has_cuda_kernel() -> bool:
    """Check if VLA CUDA kernel is available."""
    return _try_load_kernel()

def vla_quantize_gpu(weight: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """
    GPU-accelerated VLA quantization: FP32 -> INT4 + INT2 error.

    Args:
        weight: FP32 tensor [rows, cols] on CUDA

    Returns:
        int4_packed: uint8 tensor [rows, cols//2]
        int4_scale: float tensor [rows]
        error_packed: uint8 tensor [rows, (cols+3)//4]
        error_scale: float tensor [rows]
    """
    if not has_cuda_kernel():
        raise RuntimeError("VLA CUDA kernel not available")

    if not weight.is_cuda:
        raise ValueError("Weight must be on CUDA device")

    # Ensure contiguous FP32
    weight = weight.contiguous().float()

    rows, cols = weight.shape

    # Allocate output tensors
    int4_packed = torch.empty((rows, cols // 2), dtype=torch.uint8, device=weight.device)
    int4_scale = torch.empty(rows, dtype=torch.float32, device=weight.device)
    error_packed = torch.empty((rows, (cols + 3) // 4), dtype=torch.uint8, device=weight.device)
    error_scale = torch.empty(rows, dtype=torch.float32, device=weight.device)

    # Call CUDA kernel
    _CUDA_LIB.vla_quantize_gpu(
        ctypes.c_void_p(weight.data_ptr()),
        ctypes.c_void_p(int4_packed.data_ptr()),
        ctypes.c_void_p(int4_scale.data_ptr()),
        ctypes.c_void_p(error_packed.data_ptr()),
        ctypes.c_void_p(error_scale.data_ptr()),
        ctypes.c_int(rows),
        ctypes.c_int(cols),
        ctypes.c_void_p(0),  # Default stream
    )

    # Sync to ensure completion
    torch.cuda.synchronize()

    # Flatten packed tensors to 1D (expected by VLATrainableLinear._dequantize)
    return int4_packed.flatten(), int4_scale, error_packed.flatten(), error_scale


# Python fallback implementation
def vla_quantize_cpu(weight: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """
    CPU/Python VLA quantization fallback.
    Slower but works without pre-compiled CUDA kernel.
    """
    weight = weight.float()
    rows, cols = weight.shape
    device = weight.device

    # INT4 quantization
    # Scale per row: max_abs / 7
    row_max = weight.abs().max(dim=1, keepdim=True).values
    int4_scale = (row_max.squeeze() / 7.0) + 1e-10

    # Quantize to [-7, 7]
    weight_scaled = weight / int4_scale.unsqueeze(1)
    weight_q = weight_scaled.round().clamp(-7, 7).to(torch.int8)

    # Compute error
    weight_reconstructed = weight_q.float() * int4_scale.unsqueeze(1)
    error = weight - weight_reconstructed

    # Error scale
    error_max = error.abs().max(dim=1, keepdim=True).values
    error_scale = (error_max.squeeze() / 1.0) + 1e-10

    # Quantize error to [-1, 1] (INT2)
    error_scaled = error / error_scale.unsqueeze(1)
    error_q = error_scaled.round().clamp(-1, 1).to(torch.int8)

    # Pack INT4: 2 values per byte
    weight_q_shifted = (weight_q + 8).to(torch.uint8)  # [0, 15]
    weight_flat = weight_q_shifted.view(rows, -1)

    # Ensure even columns
    if cols % 2 != 0:
        weight_flat = torch.nn.functional.pad(weight_flat, (0, 1))

    high = weight_flat[:, 0::2]
    low = weight_flat[:, 1::2]
    int4_packed = (high << 4) | low

    # Pack INT2: 4 values per byte
    error_q_shifted = (error_q + 2).to(torch.uint8)  # [0, 3]
    error_flat = error_q_shifted.view(rows, -1)

    # Pad to multiple of 4
    pad_cols = (4 - (cols % 4)) % 4
    if pad_cols > 0:
        error_flat = torch.nn.functional.pad(error_flat, (0, pad_cols))

    e0 = error_flat[:, 0::4]
    e1 = error_flat[:, 1::4]
    e2 = error_flat[:, 2::4]
    e3 = error_flat[:, 3::4]
    error_packed = (e0 << 6) | (e1 << 4) | (e2 << 2) | e3

    return int4_packed, int4_scale, error_packed, error_scale


def vla_quantize(weight: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """
    VLA quantization with automatic GPU/CPU selection.
    Uses GPU kernel if available, falls back to CPU.
    """
    if weight.is_cuda and has_cuda_kernel():
        return vla_quantize_gpu(weight)
    else:
        return vla_quantize_cpu(weight)
