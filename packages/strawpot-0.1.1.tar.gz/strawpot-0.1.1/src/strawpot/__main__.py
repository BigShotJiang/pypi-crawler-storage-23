"""Allow running as `python -m strawpot`."""

from strawpot.cli import cli

cli()
