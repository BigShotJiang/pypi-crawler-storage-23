#!/usr/bin/env python3
"""
Aqwel-Aion - Command Line Interface
===================================

Entry point for running Aion library functionality from the shell. Exposes
subcommands for chat, embeddings, evaluation, prompt templates, file watching,
and Git operations (status, log, diff, etc.). Uses argparse for parsing;
help text and defaults are defined per subcommand. The Git subcommands
require the optional aion.git module; if it is not importable, Git-related
options are still defined but may report that Git is unavailable at runtime.

Author: Aksel Aghajanyan
Developed by: Aqwel AI Team
License: Apache-2.0
Copyright: 2025 Aqwel AI
"""

import subprocess
import argparse
import sys

try:
    from . import git
    GIT_AVAILABLE = True
except ImportError:
    GIT_AVAILABLE = False


def run_command(command):
    """
    Execute a shell command and return its standard output as a stripped string.
    Uses subprocess with shell=True, capture_output=True, and text=True.
    """
    result = subprocess.run(command, shell=True, capture_output=True, text=True)
    return result.stdout.strip()


def run_help():
    """
    Build the same parser structure as main() and return its --help output as a string.
    Used when the CLI help text is needed programmatically (e.g. from another module).
    """
    from io import StringIO

    parser = argparse.ArgumentParser(description="Aion CLI")
    subparsers = parser.add_subparsers(dest="command")

    subparsers.add_parser("chat", help="Start Aion Chat CLI")
    subparsers.add_parser("embed", help="Embed a text/code file")

    eval_parser = subparsers.add_parser("eval", help="Evaluate prediction accuracy")
    eval_parser.add_argument("preds", type=str, help="Predictions file")
    eval_parser.add_argument("answers", type=str, help="Answers file")

    prompt_parser = subparsers.add_parser("prompt", help="Show a prompt template")
    prompt_parser.add_argument("--type", choices=["system", "user"], default="user")

    watch_parser = subparsers.add_parser("watch", help="Watch a file for changes and embed")
    watch_parser.add_argument("filepath", type=str, help="File to watch for changes")

    git_parser = subparsers.add_parser("git", help="Git repository operations")
    git_subparsers = git_parser.add_subparsers(dest="git_command", help="Git commands")

    git_status_parser = git_subparsers.add_parser("status", help="Show repository status")
    git_status_parser.add_argument("--path", default=".", help="Repository path (default: current directory)")

    git_log_parser = git_subparsers.add_parser("log", help="Show commit history")
    git_log_parser.add_argument("--path", default=".", help="Repository path (default: current directory)")
    git_log_parser.add_argument("--limit", type=int, default=10, help="Maximum number of commits to show")

    git_branches_parser = git_subparsers.add_parser("branches", help="List all branches")
    git_branches_parser.add_argument("--path", default=".", help="Repository path (default: current directory)")

    git_diff_parser = git_subparsers.add_parser("diff", help="Show diff output")
    git_diff_parser.add_argument("--path", default=".", help="Repository path (default: current directory)")
    git_diff_parser.add_argument("--commit", help="Commit hash to diff against")

    help_io = StringIO()
    sys.stdout = help_io
    parser.print_help()
    sys.stdout = sys.__stdout__
    return help_io.getvalue()


def git_status_command(repo_path="."):
    """
    Print repository status for the given path: branch, working tree state,
    staged files, and untracked files. Requires GIT_AVAILABLE; otherwise prints
    an installation message.
    """
    if not GIT_AVAILABLE:
        print("Git integration not available. Install GitPython with: pip install gitpython")
        return

    status = git.get_git_status(repo_path)
    if "error" in status:
        print(status["error"])
        return

    print(f"Repository: {status['repo_path']}")
    print(f"Branch: {status['current_branch']}")
    print(f"Working directory: {'Clean' if status['working_dir_clean'] else 'Dirty'}")

    if status["staged_files"]:
        print(f"Staged files ({len(status['staged_files'])}):")
        for file in status["staged_files"]:
            print(f"   + {file}")

    if status["untracked_files"]:
        print(f"Untracked files ({len(status['untracked_files'])}):")
        for file in status["untracked_files"]:
            print(f"   ? {file}")


def git_log_command(repo_path=".", limit=10):
    """
    Print recent commit history for the repository at repo_path, limited to
    limit entries. Requires GIT_AVAILABLE; otherwise prints an installation message.
    """
    if not GIT_AVAILABLE:
        print("Git integration not available. Install GitPython with: pip install gitpython")
        return

    commits = git.get_recent_commits(repo_path, limit)
    if not commits or "error" in commits[0]:
        print("No commits found or error occurred")
        return

    print(f"Recent commits (showing {len(commits)}):")
    print("-" * 80)
    for commit in commits:
        print(f"{commit['hash']} - {commit['message']}")
        print(f"   {commit['author']} | {commit['date']} | {commit['files_changed']} files")
        print()


def git_branches_command(repo_path="."):
    """
    List all branches for the repository at repo_path, with the active branch
    marked. Requires GIT_AVAILABLE; otherwise prints an installation message.
    """
    if not GIT_AVAILABLE:
        print("Git integration not available. Install GitPython with: pip install gitpython")
        return

    branches = git.list_branches(repo_path)
    if not branches or "error" in branches[0]:
        print("No branches found or error occurred")
        return

    print("Branches:")
    print("-" * 40)
    for branch in branches:
        active_marker = "*" if branch["is_active"] else " "
        print(f"{active_marker} {branch['name']}")
        print(f"   Last commit: {branch['last_commit']} ({branch['last_commit_date']})")
        print()


def git_diff_command(repo_path=".", commit_hash=None):
    """
    Print diff for the working directory or for a specific commit. Requires
    GIT_AVAILABLE; otherwise prints an installation message.
    """
    if not GIT_AVAILABLE:
        print("Git integration not available. Install GitPython with: pip install gitpython")
        return

    if commit_hash:
        diff_output = git.GitManager(repo_path).get_diff(commit_hash)
    else:
        diff_output = git.GitManager(repo_path).get_diff()

    if diff_output:
        print("Diff output:")
        print("=" * 80)
        print(diff_output)
    else:
        print("No changes to show.")


def main():
    """
    Parse command-line arguments and dispatch to the appropriate subcommand.
    Prints help when no command is given or when a subcommand is unknown.
    """
    parser = argparse.ArgumentParser(
        description="Aqwel-Aion - AI utilities and research library CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  aion git status                 Show repository status
  aion git log --limit 5          Show last 5 commits
  aion git branches              List all branches
  aion git diff                   Show working directory changes
  aion git diff --commit abc123  Show diff for specific commit
        """,
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    subparsers.add_parser("chat", help="Start Aion Chat CLI")
    subparsers.add_parser("embed", help="Embed a text/code file")

    eval_parser = subparsers.add_parser("eval", help="Evaluate prediction accuracy")
    eval_parser.add_argument("preds", type=str, help="Predictions file")
    eval_parser.add_argument("answers", type=str, help="Answers file")

    prompt_parser = subparsers.add_parser("prompt", help="Show a prompt template")
    prompt_parser.add_argument("--type", choices=["system", "user"], default="user")

    watch_parser = subparsers.add_parser("watch", help="Watch a file for changes and embed")
    watch_parser.add_argument("filepath", type=str, help="File to watch for changes")

    git_parser = subparsers.add_parser("git", help="Git repository operations")
    git_subparsers = git_parser.add_subparsers(dest="git_command", help="Git commands")

    git_status_parser = git_subparsers.add_parser("status", help="Show repository status")
    git_status_parser.add_argument("--path", default=".", help="Repository path (default: current directory)")
    git_status_parser.set_defaults(func=git_status_command)

    git_log_parser = git_subparsers.add_parser("log", help="Show commit history")
    git_log_parser.add_argument("--path", default=".", help="Repository path (default: current directory)")
    git_log_parser.add_argument("--limit", type=int, default=10, help="Maximum number of commits to show")
    git_log_parser.set_defaults(func=git_log_command)

    git_branches_parser = git_subparsers.add_parser("branches", help="List all branches")
    git_branches_parser.add_argument("--path", default=".", help="Repository path (default: current directory)")
    git_branches_parser.set_defaults(func=git_branches_command)

    git_diff_parser = git_subparsers.add_parser("diff", help="Show diff output")
    git_diff_parser.add_argument("--path", default=".", help="Repository path (default: current directory)")
    git_diff_parser.add_argument("--commit", help="Commit hash to diff against")
    git_diff_parser.set_defaults(func=git_diff_command)

    args = parser.parse_args()

    if args.command == "git" and hasattr(args, "git_command"):
        if args.git_command == "status":
            git_status_command(args.path)
        elif args.git_command == "log":
            git_log_command(args.path, args.limit)
        elif args.git_command == "branches":
            git_branches_command(args.path)
        elif args.git_command == "diff":
            git_diff_command(args.path, args.commit)
        else:
            git_parser.print_help()
    elif args.command == "git":
        git_parser.print_help()
    else:
        parser.print_help()
