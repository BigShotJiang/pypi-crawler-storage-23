"""Custom exceptions for the Krystal Cloud SDK."""

from __future__ import annotations


class KrystalAPIError(Exception):
    """Base exception for Krystal Cloud API errors."""

    def __init__(self, message: str, status_code: int | None = None, response: dict | None = None) -> None:
        self.status_code = status_code
        self.response = response
        super().__init__(message)


class AuthError(KrystalAPIError):
    """Raised on 401 Unauthorized."""


class InsufficientCreditsError(KrystalAPIError):
    """Raised on 402 Payment Required."""
