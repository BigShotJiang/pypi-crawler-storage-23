# krystal-cloud

Python SDK for the [Krystal Cloud API](https://cloud-api.krystal.app).

## Installation

```bash
pip install krystal-cloud
```

## Quick Start

```python
from krystal_cloud import KrystalCloud

client = KrystalCloud(api_key="your-api-key")

# Get supported chains
chains = client.get_chains()

# Get wallet balances
balances = client.get_balances("0xYourWallet", chain_ids=[1, 137])

# Get pools on Ethereum
pools = client.get_pools(chain_id=1, limit=10, sort_by="tvl")

# Get pool detail
pool = client.get_pool(1, "0xPoolAddress")

# Get positions
positions = client.get_positions("0xYourWallet", chain_ids=[1])

# Get strategies
strategies = client.get_strategies("0xYourWallet")
```

## Async Usage

```python
import asyncio
from krystal_cloud import AsyncKrystalCloud

async def main():
    async with AsyncKrystalCloud(api_key="your-api-key") as client:
        chains = await client.get_chains()
        balances = await client.get_balances("0xYourWallet")

asyncio.run(main())
```

## Error Handling

```python
from krystal_cloud import KrystalCloud, AuthError, InsufficientCreditsError, KrystalAPIError

client = KrystalCloud(api_key="your-api-key")

try:
    data = client.get_chains()
except AuthError:
    print("Invalid API key")
except InsufficientCreditsError:
    print("Need more credits")
except KrystalAPIError as e:
    print(f"API error {e.status_code}: {e}")
```

## API Methods

| Method | Description |
|--------|-------------|
| `get_balances(wallet, ...)` | Wallet token balances |
| `get_chains()` | Supported chains |
| `get_chain(chain_id)` | Chain stats |
| `get_pools(...)` | Pool list with filters |
| `get_pool(chain_id, pool_address)` | Pool detail |
| `get_pool_historical(chain_id, pool_address)` | Pool historical data |
| `get_pool_ticks(chain_id, pool_address)` | Pool ticks |
| `get_pool_transactions(chain_id, pool_address)` | Pool transactions |
| `get_positions(wallet, ...)` | User positions |
| `get_position(chain_id, position_id)` | Position detail |
| `get_position_performance(chain_id, position_id)` | Position performance |
| `get_position_transactions(chain_id, position_id)` | Position transactions |
| `get_protocols()` | Supported protocols |
| `get_strategies(wallet, ...)` | Strategies by wallet |
| `get_strategy_positions(strategy_id)` | Strategy positions |

## License

MIT
