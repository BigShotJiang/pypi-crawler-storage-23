## DateTime format strings
# Hourly-aligned datetime format (e.g., "2024-01-15-14")
DEFAULT_HOUR_FMT = "%Y-%m-%d-%H"

# Daily-aligned datetime format (e.g., "2024-01-15")
DEFAULT_DAY_FMT = "%Y-%m-%d"
