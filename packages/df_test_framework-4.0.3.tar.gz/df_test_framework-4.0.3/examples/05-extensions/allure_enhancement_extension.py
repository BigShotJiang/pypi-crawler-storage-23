"""
Allure 报告增强扩展示例

演示如何创建 Allure 报告增强扩展,自动添加环境信息、框架版本等到报告中。

功能:
- 自动添加环境信息
- 添加框架版本信息
- 脱敏敏感配置
- 添加自定义标签

运行:
    python examples/05-extensions/allure_enhancement_extension.py
"""

from __future__ import annotations

import os
import platform
from datetime import datetime
from typing import TYPE_CHECKING

from pydantic import Field

from df_test_framework import Bootstrap, FrameworkSettings, hookimpl

if TYPE_CHECKING:
    from df_test_framework.bootstrap.runtime import RuntimeContext


class Settings(FrameworkSettings):
    """示例配置"""

    api_base_url: str = Field(default="https://jsonplaceholder.typicode.com")


class AllureEnhancementExtension:
    """
    Allure 报告增强扩展

    功能:
    - 自动收集并添加环境信息到 Allure 报告
    - 脱敏敏感配置(数据库连接字符串、API 密钥等)
    - 添加框架版本、Python 版本、操作系统等信息
    - 添加测试运行时间戳

    使用:
        runtime = (
            Bootstrap()
            .with_settings(Settings)
            .with_plugin(AllureEnhancementExtension())
            .build()
            .run()
        )
    """

    def __init__(self, add_system_info: bool = True):
        """
        初始化扩展

        Args:
            add_system_info: 是否添加系统信息(Python版本、OS等)
        """
        self.add_system_info = add_system_info

    @hookimpl
    def df_post_bootstrap(self, runtime: RuntimeContext):
        """Bootstrap 后添加环境信息到 Allure 报告"""
        self._add_environment_info(runtime)
        runtime.logger.info("✅ Allure 报告增强扩展已启动")

    def _add_environment_info(self, runtime: RuntimeContext):
        """添加环境信息"""
        logger = runtime.logger
        settings = runtime.settings

        # 准备环境信息
        env_info = {}

        # 1. 测试环境
        env_info["Environment"] = getattr(settings, "environment", "unknown")

        # 2. API 配置
        if hasattr(settings, "http") and hasattr(settings.http, "base_url"):
            env_info["API Base URL"] = settings.http.base_url

        # 3. 数据库配置(脱敏)
        if hasattr(settings, "database"):
            db_url = getattr(settings.database, "url", None)
            if db_url:
                env_info["Database"] = self._mask_connection_string(db_url)

        # 4. Redis 配置
        if hasattr(settings, "redis"):
            redis_host = getattr(settings.redis, "host", None)
            redis_port = getattr(settings.redis, "port", None)
            if redis_host and redis_port:
                env_info["Redis"] = f"{redis_host}:{redis_port}"

        # 5. 框架版本
        try:
            import df_test_framework

            env_info["Framework Version"] = df_test_framework.__version__
        except Exception:
            env_info["Framework Version"] = "unknown"

        # 6. 系统信息
        if self.add_system_info:
            import sys

            env_info["Python Version"] = sys.version.split()[0]
            env_info["Platform"] = platform.platform()
            env_info["OS"] = f"{platform.system()} {platform.release()}"

        # 7. 运行时间
        env_info["Test Run Time"] = datetime.now().strftime("%Y-%m-% d %H:%M:%S")

        # 8. 写入环境信息文件(Allure 格式)
        self._write_allure_environment(env_info, logger)

    def _mask_connection_string(self, conn_str: str) -> str:
        """
        脱敏连接字符串

        将数据库连接字符串中的敏感信息(用户名、密码)进行脱敏处理。

        Args:
            conn_str: 原始连接字符串

        Returns:
            脱敏后的连接字符串

        示例:
            输入: mysql+pymysql://user:pass@localhost:3306/db
            输出: mysql+pymysql://***:***@localhost:3306/db
        """
        if not conn_str:
            return "N/A"

        # 处理格式: scheme://user:password@host:port/database
        if "://" in conn_str and "@" in conn_str:
            parts = conn_str.split("@")
            if len(parts) == 2:
                scheme_part = parts[0].split("://")
                if len(scheme_part) == 2:
                    scheme = scheme_part[0]
                    return f"{scheme}://***@{parts[1]}"

        # 无法解析则返回部分脱敏
        return "***"

    def _write_allure_environment(self, env_info: dict, logger):
        """
        写入 Allure 环境信息文件

        Allure 通过读取 allure-results/environment.properties 文件来显示环境信息。

        Args:
            env_info: 环境信息字典
            logger: 日志记录器
        """
        # 确定 Allure 结果目录
        allure_dir = os.getenv("ALLURE_RESULTS_DIR", "allure-results")

        # 创建目录(如果不存在)
        os.makedirs(allure_dir, exist_ok=True)

        # 写入 environment.properties 文件
        env_file = os.path.join(allure_dir, "environment.properties")

        try:
            with open(env_file, "w", encoding="utf-8") as f:
                for key, value in env_info.items():
                    # 替换键中的空格为点号(Allure 推荐格式)
                    key_formatted = key.replace(" ", ".")
                    f.write(f"{key_formatted}={value}\n")

            logger.info(f"Allure 环境信息已写入: {env_file}")
            logger.debug(f"环境信息: {env_info}")

        except Exception as e:
            logger.warning(f"写入 Allure 环境信息失败: {e}")


def example_basic():
    """示例 1: 基础用法"""
    print("\n" + "=" * 60)
    print("示例 1: 基础 Allure 增强扩展")
    print("=" * 60)

    # 创建扩展
    allure_ext = AllureEnhancementExtension()

    # 启动框架
    app = Bootstrap().with_settings(Settings).with_plugin(allure_ext).build()

    runtime = app.run()

    print("\n✅ 扩展已启动")
    print("Allure 环境信息已写入到: allure-results/environment.properties")

    # 查看生成的文件
    env_file = "allure-results/environment.properties"
    if os.path.exists(env_file):
        print("\n生成的环境信息:")
        print("-" * 60)
        with open(env_file, encoding="utf-8") as f:
            print(f.read())
    else:
        print("环境信息文件未生成")

    runtime.close()


def example_without_system_info():
    """示例 2: 禁用系统信息"""
    print("\n" + "=" * 60)
    print("示例 2: 禁用系统信息收集")
    print("=" * 60)

    # 创建扩展(禁用系统信息)
    allure_ext = AllureEnhancementExtension(add_system_info=False)

    # 启动框架
    app = Bootstrap().with_settings(Settings).with_plugin(allure_ext).build()

    runtime = app.run()

    print("\n✅ 扩展已启动(不包含系统信息)")

    runtime.close()


def example_with_custom_config():
    """示例 3: 使用自定义配置"""
    print("\n" + "=" * 60)
    print("示例 3: 使用自定义配置")
    print("=" * 60)

    class CustomSettings(FrameworkSettings):
        """自定义配置"""

        environment: str = Field(default="production")

        class HTTPConfig:
            """HTTP 配置"""

            base_url: str = "https://api.example.com"
            timeout: int = 30

        class DatabaseConfig:
            """数据库配置"""

            url: str = "mysql+pymysql://admin:secret@db.example.com:3306/prod_db"

        class RedisConfig:
            """Redis 配置"""

            host: str = "redis.example.com"
            port: int = 6379

        http: HTTPConfig = HTTPConfig()
        database: DatabaseConfig = DatabaseConfig()
        redis: RedisConfig = RedisConfig()

    # 创建扩展
    allure_ext = AllureEnhancementExtension()

    # 启动框架
    app = Bootstrap().with_settings(CustomSettings).with_plugin(allure_ext).build()

    runtime = app.run()

    print("\n✅ 使用自定义配置启动完成")

    # 查看生成的文件
    env_file = "allure-results/environment.properties"
    if os.path.exists(env_file):
        print("\n生成的环境信息:")
        print("-" * 60)
        with open(env_file, encoding="utf-8") as f:
            content = f.read()
            print(content)

            # 验证脱敏
            if "***" in content:
                print("\n✅ 数据库密码已脱敏")

    runtime.close()


def cleanup():
    """清理测试文件"""
    import shutil

    if os.path.exists("allure-results"):
        shutil.rmtree("allure-results")
        print("\n🧹 清理测试文件完成")


if __name__ == "__main__":
    print("\n" + "🎯 Allure 报告增强扩展示例")
    print("=" * 60)

    # 运行所有示例
    example_basic()
    example_without_system_info()
    example_with_custom_config()

    print("\n" + "=" * 60)
    print("✅ 所有示例执行完成!")
    print("=" * 60)

    print("\n💡 提示:")
    print("  - 环境信息已写入 allure-results/environment.properties")
    print("  - 运行 pytest 并生成 Allure 报告即可看到环境信息")
    print("  - 命令: pytest --alluredir=allure-results")
    print("  - 查看报告: allure serve allure-results")

    # 清理
    cleanup()
