"""
消息队列监控扩展示例

演示如何创建消息队列监控扩展,监控消息发送/接收性能、失败率等指标。

功能:
- 监控消息发送性能
- 监控消息接收性能
- 统计失败率
- 生成监控报告

运行:
    python examples/05-extensions/mq_monitor_extension.py
"""

from __future__ import annotations

import time
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime
from typing import TYPE_CHECKING

from pydantic import Field

from df_test_framework import Bootstrap, FrameworkSettings, SingletonProvider, hookimpl

if TYPE_CHECKING:
    from df_test_framework.bootstrap.runtime import RuntimeContext


class Settings(FrameworkSettings):
    """示例配置"""

    api_base_url: str = Field(default="https://jsonplaceholder.typicode.com")


@dataclass
class MessageMetrics:
    """消息指标"""

    total_sent: int = 0  # 发送总数
    total_received: int = 0  # 接收总数
    failed_sent: int = 0  # 发送失败数
    failed_received: int = 0  # 接收失败数
    total_send_time: float = 0.0  # 发送总耗时
    total_receive_time: float = 0.0  # 接收总耗时
    min_send_time: float = float("inf")  # 最小发送耗时
    max_send_time: float = 0.0  # 最大发送耗时
    min_receive_time: float = float("inf")  # 最小接收耗时
    max_receive_time: float = 0.0  # 最大接收耗时

    def avg_send_time(self) -> float:
        """平均发送耗时"""
        if self.total_sent == 0:
            return 0.0
        return self.total_send_time / self.total_sent

    def avg_receive_time(self) -> float:
        """平均接收耗时"""
        if self.total_received == 0:
            return 0.0
        return self.total_receive_time / self.total_received

    def send_success_rate(self) -> float:
        """发送成功率"""
        if self.total_sent == 0:
            return 0.0
        return (self.total_sent - self.failed_sent) / self.total_sent * 100

    def receive_success_rate(self) -> float:
        """接收成功率"""
        if self.total_received == 0:
            return 0.0
        return (self.total_received - self.failed_received) / self.total_received * 100


class MockMessageQueue:
    """模拟消息队列(用于演示)"""

    def __init__(self, logger):
        self.logger = logger
        self.messages = []

    def send(self, topic: str, message: str):
        """发送消息"""
        # 模拟发送耗时
        time.sleep(0.01)

        self.messages.append({"topic": topic, "message": message, "timestamp": time.time()})
        self.logger.debug(f"消息已发送到 {topic}: {message}")

    def receive(self, topic: str, timeout: float = 1.0) -> str | None:
        """接收消息"""
        # 模拟接收耗时
        time.sleep(0.02)

        # 简单模拟:返回第一条消息
        for msg in self.messages:
            if msg["topic"] == topic:
                self.logger.debug(f"从 {topic} 接收消息: {msg['message']}")
                return msg["message"]

        return None


class MQMonitor:
    """
    消息队列监控器

    监控消息队列的发送和接收性能,统计成功率、耗时等指标。
    """

    def __init__(self, slow_threshold_ms: float = 100):
        """
        初始化监控器

        Args:
            slow_threshold_ms: 慢消息阈值(毫秒),超过此值的消息会被记录为慢消息
        """
        self.slow_threshold_ms = slow_threshold_ms
        self.metrics_by_topic: dict[str, MessageMetrics] = defaultdict(MessageMetrics)
        self.slow_messages: list[dict] = []

    def record_send(
        self, topic: str, duration_ms: float, success: bool, message_size: int = 0
    ):
        """
        记录发送指标

        Args:
            topic: 主题名称
            duration_ms: 发送耗时(毫秒)
            success: 是否成功
            message_size: 消息大小(字节)
        """
        metrics = self.metrics_by_topic[topic]

        metrics.total_sent += 1

        if not success:
            metrics.failed_sent += 1
            return

        # 记录耗时
        duration_sec = duration_ms / 1000
        metrics.total_send_time += duration_sec
        metrics.min_send_time = min(metrics.min_send_time, duration_sec)
        metrics.max_send_time = max(metrics.max_send_time, duration_sec)

        # 检查是否为慢消息
        if duration_ms > self.slow_threshold_ms:
            self.slow_messages.append(
                {
                    "type": "send",
                    "topic": topic,
                    "duration_ms": duration_ms,
                    "message_size": message_size,
                    "timestamp": datetime.now(),
                }
            )

    def record_receive(self, topic: str, duration_ms: float, success: bool):
        """
        记录接收指标

        Args:
            topic: 主题名称
            duration_ms: 接收耗时(毫秒)
            success: 是否成功
        """
        metrics = self.metrics_by_topic[topic]

        metrics.total_received += 1

        if not success:
            metrics.failed_received += 1
            return

        # 记录耗时
        duration_sec = duration_ms / 1000
        metrics.total_receive_time += duration_sec
        metrics.min_receive_time = min(metrics.min_receive_time, duration_sec)
        metrics.max_receive_time = max(metrics.max_receive_time, duration_sec)

        # 检查是否为慢消息
        if duration_ms > self.slow_threshold_ms:
            self.slow_messages.append(
                {
                    "type": "receive",
                    "topic": topic,
                    "duration_ms": duration_ms,
                    "timestamp": datetime.now(),
                }
            )

    def print_report(self):
        """打印监控报告"""
        print("\n" + "=" * 80)
        print("📊 消息队列监控报告")
        print("=" * 80)

        if not self.metrics_by_topic:
            print("暂无监控数据")
            return

        # 按主题打印统计
        for topic, metrics in self.metrics_by_topic.items():
            print(f"\n📌 主题: {topic}")
            print("-" * 80)

            # 发送统计
            print("发送统计:")
            print(f"  总发送: {metrics.total_sent} 条")
            print(f"  发送失败: {metrics.failed_sent} 条")
            print(f"  发送成功率: {metrics.send_success_rate():.2f}%")

            if metrics.total_sent > metrics.failed_sent:
                print(f"  平均耗时: {metrics.avg_send_time():.3f}s")
                print(f"  最小耗时: {metrics.min_send_time:.3f}s")
                print(f"  最大耗时: {metrics.max_send_time:.3f}s")

            # 接收统计
            print("\n接收统计:")
            print(f"  总接收: {metrics.total_received} 条")
            print(f"  接收失败: {metrics.failed_received} 条")
            print(f"  接收成功率: {metrics.receive_success_rate():.2f}%")

            if metrics.total_received > metrics.failed_received:
                print(f"  平均耗时: {metrics.avg_receive_time():.3f}s")
                print(f"  最小耗时: {metrics.min_receive_time:.3f}s")
                print(f"  最大耗时: {metrics.max_receive_time:.3f}s")

        # 打印慢消息
        if self.slow_messages:
            print(f"\n⚠️ 慢消息警告 (阈值: {self.slow_threshold_ms}ms)")
            print("-" * 80)
            for msg in self.slow_messages:
                print(
                    f"  [{msg['type'].upper()}] {msg['topic']}: "
                    f"{msg['duration_ms']:.2f}ms @ "
                    f"{msg['timestamp'].strftime('%H:%M:%S')}"
                )


class MQMonitoringExtension:
    """
    消息队列监控扩展

    功能:
    - 监控消息发送和接收性能
    - 统计成功率和失败率
    - 检测慢消息
    - 生成监控报告

    使用:
        runtime = (
            Bootstrap()
            .with_settings(Settings)
            .with_plugin(MQMonitoringExtension(slow_threshold_ms=100))
            .build()
            .run()
        )
    """

    def __init__(self, slow_threshold_ms: float = 100):
        """
        初始化扩展

        Args:
            slow_threshold_ms: 慢消息阈值(毫秒)
        """
        self.slow_threshold_ms = slow_threshold_ms

    @hookimpl
    def df_providers(self, settings, logger):
        """注册 MQ 监控器和模拟队列"""
        return {
            "mq_monitor": SingletonProvider(
                lambda rt: MQMonitor(self.slow_threshold_ms)
            ),
            "message_queue": SingletonProvider(lambda rt: MockMessageQueue(rt.logger)),
        }

    @hookimpl
    def df_post_bootstrap(self, runtime: RuntimeContext):
        """Bootstrap 后初始化监控"""
        monitor = runtime.get("mq_monitor")
        mq = runtime.get("message_queue")

        runtime.logger.info(
            f"✅ 消息队列监控已启动 (慢消息阈值: {self.slow_threshold_ms}ms)"
        )

        # 包装消息队列方法
        self._wrap_mq_client(mq, monitor, runtime.logger)

    def _wrap_mq_client(self, mq: MockMessageQueue, monitor: MQMonitor, logger):
        """包装消息队列客户端,添加监控"""
        original_send = mq.send
        original_receive = mq.receive

        def monitored_send(topic: str, message: str):
            """监控的发送方法"""
            start_time = time.time()
            success = True

            try:
                result = original_send(topic, message)
                return result
            except Exception as e:
                success = False
                logger.error(f"消息发送失败: {topic} - {e}")
                raise
            finally:
                duration_ms = (time.time() - start_time) * 1000
                message_size = len(message.encode("utf-8"))
                monitor.record_send(topic, duration_ms, success, message_size)

        def monitored_receive(topic: str, timeout: float = 1.0):
            """监控的接收方法"""
            start_time = time.time()
            success = True

            try:
                result = original_receive(topic, timeout)
                if result is None:
                    success = False
                return result
            except Exception as e:
                success = False
                logger.error(f"消息接收失败: {topic} - {e}")
                raise
            finally:
                duration_ms = (time.time() - start_time) * 1000
                monitor.record_receive(topic, duration_ms, success)

        mq.send = monitored_send
        mq.receive = monitored_receive


def example_basic():
    """示例 1: 基础监控"""
    print("\n" + "=" * 60)
    print("示例 1: 基础消息队列监控")
    print("=" * 60)

    # 创建扩展
    mq_ext = MQMonitoringExtension(slow_threshold_ms=50)

    # 启动框架
    app = Bootstrap().with_settings(Settings).with_plugin(mq_ext).build()

    runtime = app.run()

    # 获取监控器和消息队列
    monitor = runtime.get("mq_monitor")
    mq = runtime.get("message_queue")

    print("\n发送和接收消息...")

    # 发送消息
    mq.send("user.created", "User 123 created")
    mq.send("user.created", "User 456 created")
    mq.send("order.placed", "Order 789 placed")

    # 接收消息
    mq.receive("user.created")
    mq.receive("order.placed")

    # 打印报告
    monitor.print_report()

    runtime.close()


def example_slow_messages():
    """示例 2: 检测慢消息"""
    print("\n" + "=" * 60)
    print("示例 2: 检测慢消息")
    print("=" * 60)

    # 设置较低的阈值
    mq_ext = MQMonitoringExtension(slow_threshold_ms=5)

    app = Bootstrap().with_settings(Settings).with_plugin(mq_ext).build()

    runtime = app.run()

    monitor = runtime.get("mq_monitor")
    mq = runtime.get("message_queue")

    print("\n发送消息(会触发慢消息警告)...")

    # 发送多条消息
    for i in range(5):
        mq.send("notifications", f"Notification {i}")

    # 打印报告
    monitor.print_report()

    runtime.close()


def example_high_volume():
    """示例 3: 高并发场景"""
    print("\n" + "=" * 60)
    print("示例 3: 高并发消息监控")
    print("=" * 60)

    mq_ext = MQMonitoringExtension(slow_threshold_ms=50)

    app = Bootstrap().with_settings(Settings).with_plugin(mq_ext).build()

    runtime = app.run()

    monitor = runtime.get("mq_monitor")
    mq = runtime.get("message_queue")

    print("\n模拟高并发场景...")

    # 发送大量消息
    topics = ["user.events", "order.events", "payment.events"]

    for topic in topics:
        for i in range(10):
            mq.send(topic, f"Event {i} on {topic}")

    # 接收部分消息
    for topic in topics:
        for _ in range(5):
            mq.receive(topic)

    # 打印报告
    monitor.print_report()

    runtime.close()


if __name__ == "__main__":
    print("\n" + "🎯 消息队列监控扩展示例")
    print("=" * 60)

    # 运行所有示例
    example_basic()
    example_slow_messages()
    example_high_volume()

    print("\n" + "=" * 60)
    print("✅ 所有示例执行完成!")
    print("=" * 60)

    print("\n💡 提示:")
    print("  - 监控器会自动跟踪所有消息发送和接收")
    print("  - 慢消息会被单独记录和警告")
    print("  - 可以根据主题查看详细统计")
    print("  - 适用于 Kafka、RabbitMQ、RocketMQ 等消息队列")
