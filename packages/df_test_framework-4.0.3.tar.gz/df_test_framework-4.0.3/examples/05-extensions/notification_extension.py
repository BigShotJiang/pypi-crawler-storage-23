"""
通知扩展示例

演示如何创建通知扩展,在测试会话开始/结束时发送通知到各种平台(钉钉、企业微信、Slack 等)。

功能:
- 测试会话开始通知
- 测试会话结束通知(包含统计信息)
- 支持多种通知渠道
- 通知模板定制

运行:
    python examples/05-extensions/notification_extension.py
"""

from __future__ import annotations

import json
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import TYPE_CHECKING

from pydantic import Field

from df_test_framework import Bootstrap, FrameworkSettings, hookimpl

if TYPE_CHECKING:
    pass


class Settings(FrameworkSettings):
    """示例配置"""

    api_base_url: str = Field(default="https://jsonplaceholder.typicode.com")


class NotificationType(str, Enum):
    """通知类型"""

    SESSION_START = "session_start"  # 会话开始
    SESSION_FINISH = "session_finish"  # 会话结束
    TEST_FAILED = "test_failed"  # 测试失败


@dataclass
class NotificationMessage:
    """通知消息"""

    type: NotificationType  # 通知类型
    title: str  # 标题
    content: str  # 内容
    timestamp: datetime  # 时间戳
    metadata: dict | None = None  # 元数据


class NotificationChannel(ABC):
    """通知渠道抽象基类"""

    @abstractmethod
    def send(self, message: NotificationMessage) -> bool:
        """
        发送通知

        Args:
            message: 通知消息

        Returns:
            是否发送成功
        """
        pass

    @abstractmethod
    def test_connection(self) -> bool:
        """
        测试连接

        Returns:
            连接是否正常
        """
        pass


class DingTalkChannel(NotificationChannel):
    """
    钉钉通知渠道

    使用钉钉机器人 Webhook 发送通知。
    """

    def __init__(self, webhook_url: str, secret: str | None = None):
        """
        初始化钉钉渠道

        Args:
            webhook_url: 钉钉机器人 Webhook URL
            secret: 钉钉机器人密钥(可选)
        """
        self.webhook_url = webhook_url
        self.secret = secret

    def send(self, message: NotificationMessage) -> bool:
        """发送钉钉通知"""
        # 构造钉钉消息格式
        payload = {
            "msgtype": "markdown",
            "markdown": {
                "title": message.title,
                "text": self._format_markdown(message),
            },
        }

        print("\n[钉钉] 发送通知:")
        print(f"  标题: {message.title}")
        print(f"  内容: {message.content[:50]}...")
        print(f"  Payload: {json.dumps(payload, ensure_ascii=False, indent=2)}")

        # 实际项目中这里使用 requests 发送
        # response = requests.post(self.webhook_url, json=payload)
        # return response.status_code == 200

        return True  # 模拟发送成功

    def test_connection(self) -> bool:
        """测试钉钉连接"""
        print("[钉钉] 测试连接...")
        return True

    def _format_markdown(self, message: NotificationMessage) -> str:
        """格式化为 Markdown"""
        emoji_map = {
            NotificationType.SESSION_START: "🚀",
            NotificationType.SESSION_FINISH: "✅",
            NotificationType.TEST_FAILED: "❌",
        }

        emoji = emoji_map.get(message.type, "📢")

        md = f"## {emoji} {message.title}\n\n"
        md += f"{message.content}\n\n"
        md += f"**时间**: {message.timestamp.strftime('%Y-%m-%d %H:%M:%S')}\n"

        if message.metadata:
            md += "\n---\n\n**详细信息**:\n"
            for key, value in message.metadata.items():
                md += f"- {key}: {value}\n"

        return md


class WeChatWorkChannel(NotificationChannel):
    """
    企业微信通知渠道

    使用企业微信群机器人发送通知。
    """

    def __init__(self, webhook_url: str):
        """
        初始化企业微信渠道

        Args:
            webhook_url: 企业微信机器人 Webhook URL
        """
        self.webhook_url = webhook_url

    def send(self, message: NotificationMessage) -> bool:
        """发送企业微信通知"""
        payload = {
            "msgtype": "markdown",
            "markdown": {
                "content": self._format_markdown(message),
            },
        }

        print("\n[企业微信] 发送通知:")
        print(f"  标题: {message.title}")
        print(f"  内容: {message.content[:50]}...")
        print(f"  Payload: {json.dumps(payload, ensure_ascii=False, indent=2)}")

        return True  # 模拟发送成功

    def test_connection(self) -> bool:
        """测试企业微信连接"""
        print("[企业微信] 测试连接...")
        return True

    def _format_markdown(self, message: NotificationMessage) -> str:
        """格式化为 Markdown"""
        md = f"**{message.title}**\n"
        md += f"{message.content}\n"
        md += f"时间: {message.timestamp.strftime('%Y-%m-%d %H:%M:%S')}\n"
        return md


class SlackChannel(NotificationChannel):
    """
    Slack 通知渠道

    使用 Slack Incoming Webhook 发送通知。
    """

    def __init__(self, webhook_url: str):
        """
        初始化 Slack 渠道

        Args:
            webhook_url: Slack Webhook URL
        """
        self.webhook_url = webhook_url

    def send(self, message: NotificationMessage) -> bool:
        """发送 Slack 通知"""
        payload = {
            "text": message.title,
            "blocks": [
                {"type": "header", "text": {"type": "plain_text", "text": message.title}},
                {"type": "section", "text": {"type": "mrkdwn", "text": message.content}},
            ],
        }

        print("\n[Slack] 发送通知:")
        print(f"  标题: {message.title}")
        print(f"  内容: {message.content[:50]}...")
        print(f"  Payload: {json.dumps(payload, ensure_ascii=False, indent=2)}")

        return True  # 模拟发送成功

    def test_connection(self) -> bool:
        """测试 Slack 连接"""
        print("[Slack] 测试连接...")
        return True


class ConsoleChannel(NotificationChannel):
    """
    控制台通知渠道(用于测试)

    仅在控制台打印通知,不发送到外部平台。
    """

    def send(self, message: NotificationMessage) -> bool:
        """打印通知到控制台"""
        print("\n" + "=" * 80)
        print(f"📢 {message.title}")
        print("=" * 80)
        print(message.content)
        print(f"\n时间: {message.timestamp.strftime('%Y-%m-%d %H:%M:%S')}")

        if message.metadata:
            print("\n详细信息:")
            for key, value in message.metadata.items():
                print(f"  {key}: {value}")

        print("=" * 80)
        return True

    def test_connection(self) -> bool:
        """测试连接"""
        return True


class NotificationExtension:
    """
    通知扩展

    功能:
    - 在测试会话开始时发送通知
    - 在测试会话结束时发送通知(包含测试结果统计)
    - 支持多种通知渠道(钉钉、企业微信、Slack)
    - 自定义通知模板

    使用:
        channels = [
            DingTalkChannel(webhook_url="https://oapi.dingtalk.com/..."),
            WeChatWorkChannel(webhook_url="https://qyapi.weixin.qq.com/..."),
        ]

        runtime = (
            Bootstrap()
            .with_settings(Settings)
            .with_plugin(NotificationExtension(channels))
            .build()
            .run()
        )
    """

    def __init__(
        self,
        channels: list[NotificationChannel],
        notify_on_start: bool = True,
        notify_on_finish: bool = True,
        project_name: str = "DF Test Framework",
    ):
        """
        初始化通知扩展

        Args:
            channels: 通知渠道列表
            notify_on_start: 是否在会话开始时通知
            notify_on_finish: 是否在会话结束时通知
            project_name: 项目名称
        """
        self.channels = channels
        self.notify_on_start = notify_on_start
        self.notify_on_finish = notify_on_finish
        self.project_name = project_name
        self.session_start_time: datetime | None = None

    @hookimpl
    def df_session_start(self, session):
        """会话开始时发送通知"""
        if not self.notify_on_start:
            return

        self.session_start_time = datetime.now()

        # 构造通知消息
        message = NotificationMessage(
            type=NotificationType.SESSION_START,
            title=f"{self.project_name} - 测试会话开始",
            content=self._format_session_start_message(session),
            timestamp=self.session_start_time,
            metadata=self._extract_session_metadata(session),
        )

        # 发送到所有渠道
        self._send_to_all_channels(message)

    @hookimpl
    def df_session_finish(self, session, exitstatus: int):
        """会话结束时发送通知"""
        if not self.notify_on_finish:
            return

        finish_time = datetime.now()

        # 计算耗时
        duration = "未知"
        if self.session_start_time:
            elapsed = finish_time - self.session_start_time
            duration = str(elapsed).split(".")[0]  # 去掉微秒

        # 构造通知消息
        message = NotificationMessage(
            type=NotificationType.SESSION_FINISH,
            title=f"{self.project_name} - 测试会话结束",
            content=self._format_session_finish_message(session, exitstatus, duration),
            timestamp=finish_time,
            metadata={
                "exit_status": exitstatus,
                "duration": duration,
                "status": "成功" if exitstatus == 0 else "失败",
            },
        )

        # 发送到所有渠道
        self._send_to_all_channels(message)

    def _format_session_start_message(self, session) -> str:
        """格式化会话开始消息"""
        test_count = len(session.items) if hasattr(session, "items") else "未知"

        content = f"""
测试会话已开始

**测试数量**: {test_count}
**项目路径**: {session.config.rootdir if hasattr(session, 'config') else '未知'}
"""
        return content.strip()

    def _format_session_finish_message(
        self, session, exitstatus: int, duration: str
    ) -> str:
        """格式化会话结束消息"""
        status_emoji = "✅" if exitstatus == 0 else "❌"
        status_text = "成功" if exitstatus == 0 else "失败"

        # 尝试获取测试统计(实际项目中可以从 session 获取)
        content = f"""
测试会话已结束 {status_emoji}

**状态**: {status_text}
**退出码**: {exitstatus}
**耗时**: {duration}
**测试数量**: {len(session.items) if hasattr(session, 'items') else '未知'}
"""
        return content.strip()

    def _extract_session_metadata(self, session) -> dict:
        """提取会话元数据"""
        return {
            "test_count": len(session.items) if hasattr(session, "items") else 0,
            "root_dir": str(session.config.rootdir) if hasattr(session, "config") else "unknown",
        }

    def _send_to_all_channels(self, message: NotificationMessage):
        """发送到所有渠道"""
        for channel in self.channels:
            try:
                success = channel.send(message)
                if not success:
                    print(f"⚠️ 通知发送失败: {channel.__class__.__name__}")
            except Exception as e:
                print(f"❌ 通知发送异常: {channel.__class__.__name__} - {e}")


def example_console_notification():
    """示例 1: 控制台通知"""
    print("\n" + "=" * 60)
    print("示例 1: 控制台通知")
    print("=" * 60)

    # 创建控制台通知渠道
    channels = [ConsoleChannel()]

    # 创建扩展
    notif_ext = NotificationExtension(channels, project_name="示例项目")

    # 启动框架
    app = Bootstrap().with_settings(Settings).with_plugin(notif_ext).build()

    runtime = app.run()

    # 模拟测试会话
    class MockSession:
        """模拟 pytest session"""

        class Config:
            rootdir = "/path/to/project"

        config = Config()
        items = ["test1", "test2", "test3"]  # 模拟测试项

    mock_session = MockSession()

    # 触发会话开始通知
    notif_ext.df_session_start(mock_session)

    # 模拟测试执行
    print("\n执行测试...")
    import time

    time.sleep(1)

    # 触发会话结束通知
    notif_ext.df_session_finish(mock_session, exitstatus=0)

    runtime.close()


def example_multiple_channels():
    """示例 2: 多渠道通知"""
    print("\n" + "=" * 60)
    print("示例 2: 多渠道通知(钉钉 + 企业微信 + Slack)")
    print("=" * 60)

    # 创建多个通知渠道
    channels = [
        DingTalkChannel(webhook_url="https://oapi.dingtalk.com/robot/send?access_token=xxx"),
        WeChatWorkChannel(webhook_url="https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=xxx"),
        SlackChannel(webhook_url="https://hooks.slack.com/services/xxx/yyy/zzz"),
    ]

    # 创建扩展
    notif_ext = NotificationExtension(channels, project_name="电商平台测试")

    app = Bootstrap().with_settings(Settings).with_plugin(notif_ext).build()

    runtime = app.run()

    # 模拟测试会话
    class MockSession:
        class Config:
            rootdir = "/path/to/ecommerce-tests"

        config = Config()
        items = [f"test_{i}" for i in range(50)]  # 模拟 50 个测试

    mock_session = MockSession()

    # 触发通知
    notif_ext.df_session_start(mock_session)

    print("\n执行测试...")
    import time

    time.sleep(1)

    notif_ext.df_session_finish(mock_session, exitstatus=0)

    runtime.close()


def example_conditional_notification():
    """示例 3: 条件通知(仅失败时通知)"""
    print("\n" + "=" * 60)
    print("示例 3: 条件通知(仅会话结束时通知)")
    print("=" * 60)

    channels = [ConsoleChannel()]

    # 创建扩展(禁用开始通知)
    notif_ext = NotificationExtension(
        channels, notify_on_start=False, notify_on_finish=True, project_name="API 测试"
    )

    app = Bootstrap().with_settings(Settings).with_plugin(notif_ext).build()

    runtime = app.run()

    class MockSession:
        class Config:
            rootdir = "/path/to/api-tests"

        config = Config()
        items = [f"test_{i}" for i in range(10)]

    mock_session = MockSession()

    # 会话开始不会发送通知
    notif_ext.df_session_start(mock_session)

    # 会话结束发送通知
    notif_ext.df_session_finish(mock_session, exitstatus=1)  # 模拟失败

    runtime.close()


if __name__ == "__main__":
    print("\n" + "🎯 通知扩展示例")
    print("=" * 60)

    # 运行所有示例
    example_console_notification()
    example_multiple_channels()
    example_conditional_notification()

    print("\n" + "=" * 60)
    print("✅ 所有示例执行完成!")
    print("=" * 60)

    print("\n💡 提示:")
    print("  - 支持钉钉、企业微信、Slack 等多种通知渠道")
    print("  - 可以自定义通知模板和内容")
    print("  - 可以配置仅在特定条件下发送通知")
    print("  - 实际使用时需要配置真实的 Webhook URL")
