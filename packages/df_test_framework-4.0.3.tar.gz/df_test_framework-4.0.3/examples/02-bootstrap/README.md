# Bootstrap初始化示例

本目录包含DF Test Framework的Bootstrap初始化示例。

## 📋 示例列表

### 1. 最小化启动 (`minimal_bootstrap.py`)
演示最简单的框架启动方式。

**功能展示**:
- 最小化配置
- 快速启动
- 获取Runtime

**运行**:
```bash
python examples/02-bootstrap/minimal_bootstrap.py
```

### 2. 自定义配置 (`custom_settings.py`)
演示如何自定义框架配置。

**功能展示**:
- 自定义配置类
- 环境变量加载
- 多环境配置

**运行**:
```bash
python examples/02-bootstrap/custom_settings.py
```

### 3. 自定义Provider (`custom_providers.py`)
演示如何注册自定义资源提供者。

**功能展示**:
- 自定义Provider
- 依赖注入
- 单例模式

**运行**:
```bash
python examples/02-bootstrap/custom_providers.py
```

### 4. 集成扩展 (`with_extensions.py`)
演示如何加载和使用扩展插件。

**功能展示**:
- 加载内置扩展
- 自定义扩展
- Hook机制

**运行**:
```bash
python examples/02-bootstrap/with_extensions.py
```

## 🎯 学习路径

1. 从最小化启动开始了解基础用法
2. 学习自定义配置来适配项目需求
3. 掌握Provider模式实现依赖注入
4. 最后学习扩展系统实现功能增强

## 📚 相关文档

- [用户指南 - 配置管理](../../docs/user-guide/configuration.md)
- [架构设计 - Bootstrap](../../docs/architecture/overview.md)

---

**返回**: [示例首页](../README.md)
