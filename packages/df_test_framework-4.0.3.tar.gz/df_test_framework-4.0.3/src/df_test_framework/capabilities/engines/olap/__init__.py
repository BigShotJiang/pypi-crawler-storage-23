"""OLAP分析引擎客户端

支持多种OLAP引擎实现（ClickHouse、Druid等）
"""

# 预留：未来实现

__all__ = []
