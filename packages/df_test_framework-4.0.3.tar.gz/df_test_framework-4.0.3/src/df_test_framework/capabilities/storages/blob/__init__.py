"""Blob存储客户端

支持多种Blob存储实现（Azure Blob等）
"""

# 预留：未来实现

__all__ = []
