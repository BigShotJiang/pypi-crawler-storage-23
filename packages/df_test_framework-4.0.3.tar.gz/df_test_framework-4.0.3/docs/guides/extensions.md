# 扩展系统使用指南

> **适用版本**: v3.0.0+ (v4.0.0 完全兼容)
> **最后更新**: 2026-01-20
>
> 本指南介绍如何使用 DF Test Framework 的扩展系统来扩展框架功能。

## 📋 目录

- [什么是扩展系统](#什么是扩展系统)
- [快速开始](#快速开始)
- [核心概念](#核心概念)
- [可用的 Hook 点](#可用的-hook-点)
- [开发自定义扩展](#开发自定义扩展)
- [常见使用场景](#常见使用场景)
- [最佳实践](#最佳实践)
- [调试与测试](#调试与测试)
- [常见问题](#常见问题)

---

## 什么是扩展系统

扩展系统基于 [pluggy](https://pluggy.readthedocs.io/) 实现,提供了一种**非侵入式**的方式来扩展框架功能。

### 核心优势

✅ **非侵入式** - 无需修改框架源代码
✅ **声明式** - 使用装饰器声明扩展点
✅ **可组合** - 多个扩展可以协同工作
✅ **易测试** - 扩展可以独立测试
✅ **灵活** - 14 个 Hook 点覆盖框架生命周期

### 适用场景

- 🔌 集成第三方服务(消息队列、对象存储、监控系统)
- 📊 收集性能指标和生成报告
- 🔒 添加自定义认证和授权机制
- 🚦 环境验证和健康检查
- 📝 增强日志和报告
- 🎯 自定义测试数据生成

---

## 快速开始

### 5 分钟上手

#### 步骤 1: 创建扩展类

```python
from df_test_framework import hookimpl

class MyFirstExtension:
    """我的第一个扩展"""

    @hookimpl
    def df_post_bootstrap(self, runtime):
        """在框架启动后执行"""
        runtime.logger.info("🎉 扩展已启动!")
```

#### 步骤 2: 注册扩展

```python
from df_test_framework import Bootstrap

runtime = (
    Bootstrap()
    .with_settings(MySettings)
    .with_plugin(MyFirstExtension())  # 注册扩展
    .build()
    .run()
)

# 输出: 🎉 扩展已启动!
```

就这么简单!你的第一个扩展已经运行了。

---

### 实用示例:API 性能监控

```python
from df_test_framework import hookimpl
import time

class APIPerformanceMonitor:
    """监控 API 请求性能"""

    def __init__(self, threshold_ms: float = 1000):
        self.threshold_ms = threshold_ms
        self.slow_requests = []

    @hookimpl
    def df_post_bootstrap(self, runtime):
        """在框架启动后注册监控"""
        http = runtime.http_client()
        original_request = http.request

        def monitored_request(method, url, **kwargs):
            start_time = time.time()
            response = original_request(method, url, **kwargs)
            duration_ms = (time.time() - start_time) * 1000

            if duration_ms > self.threshold_ms:
                self.slow_requests.append({
                    "method": method,
                    "url": url,
                    "duration_ms": duration_ms
                })
                runtime.logger.warning(
                    f"⚠️ 慢请求: {method} {url} - {duration_ms:.0f}ms"
                )

            return response

        http.request = monitored_request
        runtime.logger.info(f"API 性能监控已启动 (阈值: {self.threshold_ms}ms)")

# 使用
runtime = (
    Bootstrap()
    .with_settings(MySettings)
    .with_plugin(APIPerformanceMonitor(threshold_ms=500))
    .build()
    .run()
)
```

---

## 核心概念

### Hook Specification (规范)

框架定义的扩展点,使用 `@hookspec` 装饰器标记:

```python
# 框架内部定义(你不需要写这部分)
@hookspec
def df_post_bootstrap(self, runtime: RuntimeContext) -> None:
    """框架启动后的扩展点"""
```

### Hook Implementation (实现)

扩展对 Hook 的具体实现,使用 `@hookimpl` 装饰器标记:

```python
# 你的扩展代码
@hookimpl
def df_post_bootstrap(self, runtime):
    """实现框架启动后的逻辑"""
    runtime.logger.info("扩展已初始化")
```

### 执行流程

```
Bootstrap 启动
    ↓
调用 df_config_sources Hook → 加载额外配置
    ↓
调用 df_providers Hook → 注册自定义服务
    ↓
创建 RuntimeContext
    ↓
调用 df_post_bootstrap Hook → 执行初始化逻辑
    ↓
框架就绪
```

---

## 可用的 Hook 点

框架提供了 14 个 Hook 点,覆盖配置、启动、中间件、事件和测试生命周期。

### 1. 配置相关 Hook

#### df_config_sources

**时机**: 配置加载前
**用途**: 添加自定义配置源

```python
@hookimpl
def df_config_sources(self, settings_cls):
    """从远程配置中心加载配置"""
    return [RemoteConfigSource("https://config.example.com")]
```

**使用场景**:
- 从配置中心加载配置(Consul、etcd、Nacos)
- 从数据库加载配置
- 从云服务加载配置(AWS SSM、Azure Key Vault)

#### df_config_loaded

**时机**: 配置加载完成后
**用途**: 验证或修改配置

```python
@hookimpl
def df_config_loaded(self, settings):
    """验证配置完整性"""
    if not settings.http.base_url:
        raise ValueError("base_url 未配置")
```

---

### 2. 启动相关 Hook

#### df_providers

**时机**: Provider 注册阶段
**用途**: 注册自定义服务

```python
@hookimpl
def df_providers(self, settings, logger):
    """注册 Kafka 客户端"""
    return {
        "kafka": SingletonProvider(
            lambda rt: KafkaClient(settings.kafka_servers, logger)
        )
    }
```

**使用场景**:
- 注册消息队列客户端(Kafka、RabbitMQ)
- 注册对象存储客户端(MinIO、S3)
- 注册缓存客户端(Memcached)
- 注册业务工具类

#### df_pre_bootstrap

**时机**: Bootstrap 开始前
**用途**: 预处理逻辑

```python
@hookimpl
def df_pre_bootstrap(self, bootstrap):
    """Bootstrap 前的准备工作"""
    print("正在准备启动框架...")
```

#### df_post_bootstrap

**时机**: Runtime 创建后
**用途**: 初始化、验证、预热

```python
@hookimpl
def df_post_bootstrap(self, runtime):
    """预热缓存"""
    redis = runtime.redis()
    redis.set("app:version", "1.0.0")
    runtime.logger.info("缓存预热完成")
```

**使用场景**:
- 环境验证
- 数据库 Schema 初始化
- 缓存预热
- 发送启动通知

---

### 3. 中间件相关 Hook

#### df_http_middlewares

**时机**: HTTP 客户端初始化时
**用途**: 添加 HTTP 中间件

```python
@hookimpl
def df_http_middlewares(self, settings):
    """添加自定义认证中间件"""
    return [CustomAuthMiddleware(settings.api_key)]
```

#### df_db_middlewares

**时机**: 数据库初始化时
**用途**: 添加数据库中间件

```python
@hookimpl
def df_db_middlewares(self, settings):
    """添加 SQL 日志中间件"""
    return [SQLLoggingMiddleware()]
```

#### df_mq_middlewares

**时机**: 消息队列初始化时
**用途**: 添加消息队列中间件

```python
@hookimpl
def df_mq_middlewares(self, settings):
    """添加消息序列化中间件"""
    return [MessageSerializerMiddleware()]
```

---

### 4. 事件和遥测 Hook

#### df_event_handlers

**时机**: 事件总线初始化后
**用途**: 注册事件处理器

```python
@hookimpl
def df_event_handlers(self, event_bus):
    """注册自定义事件处理器"""
    event_bus.subscribe("http.request.completed", self.on_request_completed)
    return []

def on_request_completed(self, event):
    print(f"请求完成: {event.method} {event.url}")
```

#### df_telemetry_exporters

**时机**: 遥测系统初始化时
**用途**: 添加遥测导出器

```python
@hookimpl
def df_telemetry_exporters(self, settings):
    """导出指标到 Prometheus"""
    return [PrometheusExporter(settings.prometheus_port)]
```

---

### 5. 测试生命周期 Hook

#### df_test_setup

**时机**: 每个测试开始前
**用途**: 测试前置处理

```python
@hookimpl
def df_test_setup(self, request, runtime):
    """每个测试开始前清理数据"""
    runtime.logger.info(f"开始测试: {request.node.name}")
    runtime.database().execute("TRUNCATE TABLE test_data")
```

#### df_test_teardown

**时机**: 每个测试结束后
**用途**: 测试后置处理

```python
@hookimpl
def df_test_teardown(self, request, runtime, outcome):
    """测试结束后截图(如果失败)"""
    if outcome == "failed":
        runtime.browser().screenshot(f"{request.node.name}.png")
```

#### df_session_start

**时机**: pytest 会话开始时
**用途**: 会话级初始化

```python
@hookimpl
def df_session_start(self, session):
    """测试会话开始通知"""
    send_notification("测试会话开始")
```

#### df_session_finish

**时机**: pytest 会话结束时
**用途**: 会话级清理和报告

```python
@hookimpl
def df_session_finish(self, session, exitstatus):
    """生成测试报告"""
    generate_report(session, exitstatus)
    send_notification(f"测试会话结束, 状态: {exitstatus}")
```

---

## 开发自定义扩展

### 完整扩展模板

```python
from df_test_framework import hookimpl, SingletonProvider
from typing import Optional
import logging

class MyExtensionConfig:
    """扩展配置"""
    def __init__(
        self,
        enabled: bool = True,
        threshold: int = 100,
        log_level: str = "INFO"
    ):
        self.enabled = enabled
        self.threshold = threshold
        self.log_level = log_level


class MyExtension:
    """
    我的自定义扩展

    功能:
    - 功能描述 1
    - 功能描述 2

    使用:
        config = MyExtensionConfig(threshold=200)
        runtime = (
            Bootstrap()
            .with_settings(MySettings)
            .with_plugin(MyExtension(config))
            .build()
            .run()
        )
    """

    def __init__(self, config: Optional[MyExtensionConfig] = None):
        self.config = config or MyExtensionConfig()
        self.logger = logging.getLogger(__name__)

    @hookimpl
    def df_config_sources(self, settings_cls):
        """添加自定义配置源"""
        if not self.config.enabled:
            return []
        return [MyConfigSource()]

    @hookimpl
    def df_providers(self, settings, logger):
        """注册自定义 Provider"""
        if not self.config.enabled:
            return {}

        return {
            "my_service": SingletonProvider(
                lambda rt: MyService(rt.settings, rt.logger, self.config)
            )
        }

    @hookimpl
    def df_post_bootstrap(self, runtime):
        """初始化扩展"""
        if not self.config.enabled:
            runtime.logger.info("MyExtension 已禁用")
            return

        runtime.logger.info(
            f"MyExtension 已启动 (threshold={self.config.threshold})"
        )

        # 执行初始化逻辑
        my_service = runtime.get("my_service")
        my_service.initialize()


class MyService:
    """自定义服务"""

    def __init__(self, settings, logger, config):
        self.settings = settings
        self.logger = logger
        self.config = config
        self.initialized = False

    def initialize(self):
        """初始化服务"""
        self.logger.info("MyService 正在初始化...")
        # 初始化逻辑
        self.initialized = True
        self.logger.info("MyService 初始化完成")
```

---

## 常见使用场景

### 场景 1: 集成消息队列

```python
from df_test_framework import hookimpl, SingletonProvider
from kafka import KafkaProducer
import json

class KafkaExtension:
    """Kafka 集成扩展"""

    @hookimpl
    def df_providers(self, settings, logger):
        """注册 Kafka Producer"""
        return {
            "kafka_producer": SingletonProvider(
                lambda rt: KafkaProducer(
                    bootstrap_servers=rt.settings.kafka_servers,
                    value_serializer=lambda v: json.dumps(v).encode('utf-8')
                )
            )
        }

    @hookimpl
    def df_post_bootstrap(self, runtime):
        """验证 Kafka 连接"""
        producer = runtime.get("kafka_producer")
        runtime.logger.info(f"Kafka Producer 已连接")

# 在测试中使用
def test_send_message(runtime):
    kafka = runtime.get("kafka_producer")
    kafka.send("test-topic", {"message": "Hello Kafka"})
```

---

### 场景 2: 环境健康检查

```python
from df_test_framework import hookimpl
import sys

class HealthCheckExtension:
    """环境健康检查扩展"""

    @hookimpl
    def df_post_bootstrap(self, runtime):
        """执行健康检查"""
        logger = runtime.logger
        all_passed = True

        # 检查 HTTP 服务
        try:
            http = runtime.http_client()
            response = http.get("/health")
            if response.status_code == 200:
                logger.info("✅ HTTP 服务健康")
            else:
                logger.error(f"❌ HTTP 服务异常: {response.status_code}")
                all_passed = False
        except Exception as e:
            logger.error(f"❌ HTTP 服务不可达: {e}")
            all_passed = False

        # 检查数据库
        try:
            db = runtime.database()
            db.execute("SELECT 1")
            logger.info("✅ 数据库连接正常")
        except Exception as e:
            logger.error(f"❌ 数据库连接失败: {e}")
            all_passed = False

        # 检查 Redis
        try:
            redis = runtime.redis()
            redis.ping()
            logger.info("✅ Redis 连接正常")
        except Exception as e:
            logger.warning(f"⚠️ Redis 连接失败: {e}")

        if not all_passed:
            logger.error("=" * 60)
            logger.error("环境健康检查失败,请检查配置")
            logger.error("=" * 60)
            sys.exit(1)
```

---

### 场景 3: 性能分析与报告

```python
from df_test_framework import hookimpl
import time
from collections import defaultdict

class PerformanceProfiler:
    """性能分析扩展"""

    def __init__(self):
        self.api_stats = defaultdict(lambda: {
            "count": 0,
            "total_time": 0,
            "min_time": float('inf'),
            "max_time": 0
        })

    @hookimpl
    def df_post_bootstrap(self, runtime):
        """注册性能监控"""
        http = runtime.http_client()
        original_request = http.request

        def profiled_request(method, url, **kwargs):
            start_time = time.time()
            response = original_request(method, url, **kwargs)
            duration = time.time() - start_time

            # 记录统计
            key = f"{method} {url}"
            stats = self.api_stats[key]
            stats["count"] += 1
            stats["total_time"] += duration
            stats["min_time"] = min(stats["min_time"], duration)
            stats["max_time"] = max(stats["max_time"], duration)

            return response

        http.request = profiled_request

        # 注册退出时打印报告
        import atexit
        atexit.register(lambda: self.print_report(runtime.logger))

    def print_report(self, logger):
        """打印性能报告"""
        logger.info("\n" + "=" * 80)
        logger.info("性能分析报告")
        logger.info("=" * 80)

        for endpoint, stats in sorted(
            self.api_stats.items(),
            key=lambda x: x[1]["total_time"],
            reverse=True
        ):
            avg_time = stats["total_time"] / stats["count"]
            logger.info(
                f"{endpoint}:\n"
                f"  调用次数: {stats['count']}\n"
                f"  总耗时: {stats['total_time']:.3f}s\n"
                f"  平均耗时: {avg_time:.3f}s\n"
                f"  最小耗时: {stats['min_time']:.3f}s\n"
                f"  最大耗时: {stats['max_time']:.3f}s"
            )
```

---

### 场景 4: 测试数据自动清理

```python
from df_test_framework import hookimpl

class DataCleanupExtension:
    """测试数据自动清理扩展"""

    def __init__(self, tables: list[str]):
        self.tables = tables

    @hookimpl
    def df_test_setup(self, request, runtime):
        """每个测试前清理数据"""
        db = runtime.database()
        logger = runtime.logger

        logger.info(f"清理测试数据: {request.node.name}")

        for table in self.tables:
            try:
                db.execute(f"TRUNCATE TABLE {table}")
                logger.debug(f"  ✓ 清理表: {table}")
            except Exception as e:
                logger.warning(f"  ✗ 清理表失败 {table}: {e}")

# 使用
runtime = (
    Bootstrap()
    .with_settings(MySettings)
    .with_plugin(DataCleanupExtension(
        tables=["users", "orders", "products"]
    ))
    .build()
    .run()
)
```

---

## 最佳实践

### 1. 扩展命名规范

```python
# ✅ 好的命名 - 清晰描述功能
class KafkaIntegrationExtension:
    pass

class PerformanceMonitoringExtension:
    pass

class DatabaseHealthCheckExtension:
    pass

# ❌ 避免的命名 - 不清晰
class Extension1:
    pass

class MyPlugin:
    pass

class Helper:
    pass
```

---

### 2. 单一职责原则

每个扩展应该专注于一个功能:

```python
# ✅ 好的设计 - 每个扩展专注一个功能
class APIMonitoringExtension:
    """只负责 API 监控"""
    pass

class CacheWarmupExtension:
    """只负责缓存预热"""
    pass

# ❌ 避免 - 一个扩展做太多事情
class SuperExtension:
    """监控、预热、验证、通知...所有功能"""
    pass
```

---

### 3. 优雅的错误处理

```python
class RobustExtension:
    @hookimpl
    def df_post_bootstrap(self, runtime):
        logger = runtime.logger

        try:
            self._initialize(runtime)
        except Exception as e:
            logger.error(f"扩展初始化失败: {e}")

            # 根据严重性决定是否抛出
            if self.is_critical:
                raise  # 关键扩展失败应该终止
            else:
                logger.warning("扩展初始化失败,将继续运行")
```

---

### 4. 支持配置

使用 Pydantic 定义扩展配置:

```python
from pydantic import BaseModel, Field

class MonitoringConfig(BaseModel):
    enabled: bool = Field(default=True, description="是否启用监控")
    threshold_ms: int = Field(default=1000, description="慢请求阈值(毫秒)")
    report_interval: int = Field(default=60, description="报告间隔(秒)")

class MonitoringExtension:
    def __init__(self, config: MonitoringConfig = None):
        self.config = config or MonitoringConfig()

    @hookimpl
    def df_post_bootstrap(self, runtime):
        if not self.config.enabled:
            return

        runtime.logger.info(
            f"监控已启用: threshold={self.config.threshold_ms}ms"
        )
```

---

### 5. 资源清理

```python
class ResourceAwareExtension:
    def __init__(self):
        self.resources = []

    @hookimpl
    def df_post_bootstrap(self, runtime):
        # 创建资源
        resource = ExternalService()
        self.resources.append(resource)

        # 注册清理函数
        import atexit
        atexit.register(self.cleanup)

    def cleanup(self):
        """清理资源"""
        for resource in self.resources:
            try:
                resource.close()
            except Exception:
                pass
```

---

### 6. 避免阻塞操作

```python
# ❌ 避免 - 阻塞框架启动
class BadExtension:
    @hookimpl
    def df_post_bootstrap(self, runtime):
        time.sleep(30)  # 阻塞启动

# ✅ 好的做法 - 使用后台线程
class GoodExtension:
    @hookimpl
    def df_post_bootstrap(self, runtime):
        import threading

        def background_task():
            time.sleep(30)
            # 执行耗时操作

        thread = threading.Thread(target=background_task, daemon=True)
        thread.start()
```

---

## 调试与测试

### 调试扩展

启用详细日志:

```python
import logging

# 设置日志级别
logging.basicConfig(level=logging.DEBUG)

# 或者在 settings 中配置
class MySettings(FrameworkSettings):
    class LoggingConfig(BaseModel):
        level: str = "DEBUG"
```

查看 Hook 调用:

```python
class DebugExtension:
    @hookimpl
    def df_post_bootstrap(self, runtime):
        print(f"✅ df_post_bootstrap 被调用")
        print(f"   Runtime: {runtime}")
        print(f"   Settings: {runtime.settings}")
```

---

### 测试扩展

#### 单元测试 Hook 方法

```python
import pytest
from my_extension import MyExtension

def test_config_sources():
    """测试配置源 Hook"""
    ext = MyExtension()
    sources = ext.df_config_sources(MySettings)

    assert sources is not None
    assert len(sources) > 0

def test_providers():
    """测试 Provider Hook"""
    ext = MyExtension()
    providers = ext.df_providers(MySettings(), logging.getLogger())

    assert "my_service" in providers
```

#### 集成测试

```python
def test_extension_integration():
    """完整集成测试"""
    runtime = (
        Bootstrap()
        .with_settings(MySettings)
        .with_plugin(MyExtension())
        .build()
        .run()
    )

    # 验证 Provider 已注册
    my_service = runtime.get("my_service")
    assert my_service is not None

    # 验证服务已初始化
    assert my_service.initialized is True

    runtime.close()
```

---

## 常见问题

### Q1: Hook 没有被调用?

**检查清单**:
1. ✅ 是否使用了 `@hookimpl` 装饰器
2. ✅ Hook 方法名是否正确(如 `df_post_bootstrap`)
3. ✅ 是否使用 `with_plugin()` 注册了扩展
4. ✅ 扩展中是否有提前 return 的逻辑

```python
# ❌ 错误 - 缺少装饰器
class BadExtension:
    def df_post_bootstrap(self, runtime):  # 缺少 @hookimpl
        pass

# ✅ 正确
class GoodExtension:
    @hookimpl
    def df_post_bootstrap(self, runtime):
        pass
```

---

### Q2: 如何在扩展间共享数据?

使用 Runtime Context:

```python
class ExtensionA:
    @hookimpl
    def df_post_bootstrap(self, runtime):
        # 存储数据
        runtime.set_metadata("shared_data", {"key": "value"})

class ExtensionB:
    @hookimpl
    def df_post_bootstrap(self, runtime):
        # 读取数据
        data = runtime.get_metadata("shared_data")
        print(data)  # {"key": "value"}
```

---

### Q3: Hook 执行顺序?

多个扩展实现同一个 Hook 时,按注册顺序执行:

```python
runtime = (
    Bootstrap()
    .with_settings(MySettings)
    .with_plugin(ExtensionA())  # 先执行
    .with_plugin(ExtensionB())  # 后执行
    .build()
    .run()
)
```

---

### Q4: 如何禁用某个扩展?

方式 1: 配置控制

```python
class MyExtension:
    def __init__(self, enabled: bool = True):
        self.enabled = enabled

    @hookimpl
    def df_post_bootstrap(self, runtime):
        if not self.enabled:
            return
        # 扩展逻辑

# 使用
runtime = Bootstrap().with_plugin(MyExtension(enabled=False)).build().run()
```

方式 2: 环境变量控制

```python
import os

class MyExtension:
    @hookimpl
    def df_post_bootstrap(self, runtime):
        if os.getenv("DISABLE_MY_EXTENSION") == "true":
            return
        # 扩展逻辑
```

---

### Q5: 扩展抛出异常会怎样?

默认情况下,扩展异常会中断框架启动。建议在扩展内部捕获异常:

```python
class SafeExtension:
    @hookimpl
    def df_post_bootstrap(self, runtime):
        try:
            risky_operation()
        except Exception as e:
            runtime.logger.error(f"扩展执行失败: {e}")
            # 决定是否重新抛出
            if self.is_critical:
                raise
```

---

## 相关资源

### 文档

- 📖 [扩展点架构详解](../architecture/extension-points.md) - 深入理解扩展系统设计
- 📚 [Extensions API 参考](../api-reference/extensions.md) - 完整 API 文档
- 🎯 [扩展示例代码](../../examples/05-extensions/) - 实用示例集合

### 外部资源

- 🔌 [pluggy 官方文档](https://pluggy.readthedocs.io/) - 扩展系统底层框架
- 🐍 [Python Packaging Guide](https://packaging.python.org/) - 打包发布扩展

---

## 总结

扩展系统是 DF Test Framework 最强大的特性之一,掌握扩展开发将极大提升测试框架的灵活性和可扩展性。

**关键要点**:
- ✅ 使用 `@hookimpl` 装饰器实现 Hook
- ✅ 14 个 Hook 点覆盖完整生命周期
- ✅ 遵循单一职责原则
- ✅ 优雅处理错误
- ✅ 支持配置和禁用

**下一步**:
1. 查看 [扩展示例](../../examples/05-extensions/) 了解更多实战案例
2. 阅读 [API 文档](../api-reference/extensions.md) 了解所有 Hook 详情
3. 开始编写你的第一个扩展!

---

**返回**: [使用指南首页](README.md) | [文档首页](../README.md)