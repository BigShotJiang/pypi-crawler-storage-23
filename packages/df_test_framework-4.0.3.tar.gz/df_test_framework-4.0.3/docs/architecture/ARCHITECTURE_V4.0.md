# DF Test Framework v4.0 架构总览

> **版本**: v4.0.0
> **更新时间**: 2026-01-16
> **架构类型**: 五层架构 + 事件驱动 + 依赖注入

---

## 📋 核心架构理念

DF Test Framework v4.0 采用**清晰分层、职责单一、依赖倒置**的架构设计，通过五层架构实现高内聚低耦合，确保框架的可扩展性和可维护性。

### 设计原则

1. **分层隔离**: 每层职责明确，高层可依赖低层，反之不行
2. **依赖倒置**: 核心层定义抽象，上层依赖抽象而非实现
3. **事件驱动**: 通过 EventBus 解耦组件间通信
4. **异步优先**: v4.0.0 全面支持异步，性能提升 2-30 倍
5. **向后兼容**: 同步 API 完全保留，平滑升级

---

## 🏗️ 五层架构

```
Layer 4 ─── bootstrap/          # 引导层：Bootstrap、Providers、Runtime
Layer 3 ─── testing/ + cli/     # 门面层：Fixtures、CLI 工具、脚手架
Layer 2 ─── capabilities/       # 能力层：HTTP/UI/DB/MQ/Storage
Layer 1 ─── infrastructure/     # 基础设施：config/logging/events/plugins
Layer 0 ─── core/               # 核心层：纯抽象（无依赖）
横切 ───── plugins/             # 插件：MonitoringPlugin、AllurePlugin
```

### 依赖规则

- ✅ **向下依赖**: Layer 4 可依赖 0-3，Layer 3 可依赖 0-2，以此类推
- ❌ **禁止向上依赖**: Layer 0 不依赖任何层，Layer 1 只能依赖 Layer 0
- ✅ **横切独立**: Plugins 可依赖所有层，提供跨层能力增强

---

## 📦 各层职责

### Layer 0: Core 核心层

**职责**: 定义纯抽象和协议，无第三方依赖

**包含**:
- `protocols/` - 客户端、事件、插件、仓库等协议定义
- `middleware/` - 中间件基类和链式调用机制
- `context/` - 执行上下文和传播机制
- `events/` - 事件类型定义（HTTP/DB/测试事件）
- `models/` - 基础数据模型（BaseRequest/BaseResponse）
- `exceptions.py` - 异常体系
- `types.py` - 类型定义和枚举

**设计理念**: 纯抽象，为上层提供契约

---

### Layer 1: Infrastructure 基础设施层

**职责**: 提供配置、日志、事件、插件等基础能力

**包含**:
- `config/` - Pydantic 配置模型 + YAML 分层配置
- `logging/` - structlog + OpenTelemetry 集成
- `events/` - EventBus 发布-订阅实现
- `telemetry/` - OpenTelemetry 追踪集成
- `plugins/` - Pluggy 插件系统
- `sanitize/` - 敏感信息脱敏服务
- `resilience/` - 熔断器等容错机制
- `metrics/` - 性能指标收集

**设计理念**: 横向支撑，为所有层提供基础服务

---

### Layer 2: Capabilities 能力层

**职责**: 与外部系统交互的具体实现

**包含**:
- `clients/` - HTTP/GraphQL/gRPC 客户端
  - `http/` - **AsyncHttpClient** (v4.0+) / HttpClient (v2.0+)
  - `graphql/` - GraphQL 查询执行
  - `grpc/` - gRPC 服务调用
- `databases/` - 数据库访问
  - **AsyncDatabase** (v4.0+) / Database (v2.0+)
  - Repository 模式、Unit of Work 模式
- `drivers/` - UI 自动化驱动
  - **AsyncAppActions** (v4.0+) / AppActions (v3.0+)
  - **AsyncBasePage** (v4.0+) / BasePage (v3.0+)
  - BaseComponent 组件模式
- `messengers/` - 消息队列（Kafka/RabbitMQ/RocketMQ）
- `storages/` - 对象存储（LocalFile/S3/OSS）
- `engines/` - 数据处理引擎（预留）

**设计理念**: 能力聚合，每个模块解决一类外部交互问题

---

### Layer 3: Testing + CLI 门面层

**职责**: 为测试开发提供便捷的工具和接口

**包含**:

**testing/** - 测试支持
- `fixtures/` - Pytest Fixtures（async_http_client, async_database, etc.）
- `decorators/` - 类和方法装饰器（@api_class, @actions_class）
- `data/` - 测试数据管理
  - `builders/` - Builder 模式
  - `factories/` - Factory 模式（v3.31+）
  - `generators/` - 随机数据生成
  - `loaders/` - YAML/JSON/CSV 加载
- `assertions/` - 断言工具（SchemaValidator, 匹配器）
- `mocking/` - Mock 工具
- `debugging/` - 调试工具（ConsoleDebugObserver）
- `reporting/` - Allure 报告集成

**cli/** - 命令行工具
- `commands/` - df-test 命令集（init, gen, env）
- `templates/` - 项目和代码模板

**设计理念**: 简化使用，提供最佳实践

---

### Layer 4: Bootstrap 引导层

**职责**: 框架初始化、依赖注入、运行时组装

**包含**:
- `bootstrap.py` - Bootstrap 初始化器
- `providers.py` - Provider 依赖注入
- `runtime.py` - RuntimeContext 运行时管理

**设计理念**: 特权层，可依赖所有层，负责组装整个框架

---

### 横切关注点: Plugins 插件

**职责**: 跨层级的功能增强

**包含**:
- `builtin/monitoring/` - MonitoringPlugin（性能监控）
- `builtin/reporting/` - AllurePlugin（报告生成）

**设计理念**: 通过 Pluggy Hooks 实现可插拔的功能增强

---

## 🚀 v4.0.0 重大变更

### 1. 全面异步化

**核心异步组件**:
- ✅ **AsyncHttpClient** - 基于 httpx.AsyncClient
  - 性能提升：并发 100 请求从 30 秒 → 1 秒（**30 倍**）
  - 支持 HTTP/2、连接池、并发控制
  - 完全兼容中间件系统

- ✅ **AsyncDatabase** - 基于 SQLAlchemy 2.0 AsyncEngine
  - 性能提升：数据库操作 **5-10 倍**
  - 支持 MySQL (aiomysql), PostgreSQL (asyncpg), SQLite (aiosqlite)
  - async with 上下文管理器

- ✅ **AsyncRedis** - 基于 redis.asyncio
  - 性能提升：缓存操作 **5-10 倍**
  - 完整的异步操作支持

- ✅ **AsyncAppActions + AsyncBasePage** - 基于 playwright.async_api
  - 性能提升：UI 测试 **2-3 倍**
  - 更好的资源管理

**向后兼容策略**:
- ✅ 同步 API 完全保留（HttpClient, Database, AppActions）
- ✅ Fixtures 同时提供同步和异步版本
- ✅ 升级路径：渐进式迁移，无需一次性重写

### 2. 架构优化

- ✅ **Layer 4 Bootstrap 引导层** (v3.16)
  - 解决依赖违规问题
  - 清晰的初始化流程

- ✅ **中间件系统统一** (v3.14-v3.16)
  - 移除 Interceptor，统一为 Middleware
  - 洋葱模型，支持请求/响应拦截

- ✅ **事件系统重构** (v3.17)
  - correlation_id 关联追踪
  - 测试隔离（ContextVar）
  - AllureObserver 自动集成

### 3. 可观测性增强

- ✅ **OpenTelemetry 深度集成**
  - trace_id/span_id 自动注入
  - W3C TraceContext 传播
  - Jaeger/Zipkin/Tempo 支持

- ✅ **Structured Logging** (v3.38)
  - structlog 集成
  - 自动上下文注入

- ✅ **统一脱敏服务** (v3.40)
  - 日志、Console、Allure 统一脱敏
  - partial/full/hash 三种策略

---

## 🔄 数据流

### HTTP 请求流程

```
测试用例
  ↓
@api_class 装饰器加载
  ↓
BaseAPI.request()
  ↓
中间件链（洋葱模型）
  ├─ SignatureMiddleware (签名)
  ├─ BearerTokenMiddleware (认证)
  ├─ RetryMiddleware (重试)
  ├─ LoggingMiddleware (日志)
  └─ HttpTelemetryMiddleware (追踪)
  ↓
AsyncHttpClient.request()
  ↓
httpx.AsyncClient
  ↓
EventBus 发布 HttpRequestStartEvent
  ↓
外部 API
  ↓
EventBus 发布 HttpRequestEndEvent
  ↓
AllureObserver 自动记录
  ↓
返回 Response
```

### UI 测试流程

```
测试用例
  ↓
@actions_class 装饰器加载
  ↓
AsyncAppActions.goto()
  ↓
EventBus 发布 WebNavigationStartEvent
  ↓
playwright.async_api.Page
  ↓
EventBus 发布 WebNavigationEndEvent
  ↓
AllureObserver 自动截图
  ↓
测试继续
```

---

## 📊 性能对比

| 场景 | 同步版本 | 异步版本 | 提升 |
|------|---------|---------|------|
| **100 并发 HTTP 请求** | 30 秒 | 1 秒 | **30x** |
| **数据库批量查询** | 10 秒 | 1.5 秒 | **6-7x** |
| **Redis 批量操作** | 5 秒 | 0.8 秒 | **6x** |
| **UI 自动化测试** | 120 秒 | 50 秒 | **2.4x** |

---

## 🎯 架构优势

### 1. 清晰的职责划分
- 每层职责明确，易于理解和维护
- 新功能开发时快速定位应该放在哪一层

### 2. 良好的可扩展性
- 通过协议定义实现依赖倒置
- Pluggy 插件系统支持第三方扩展
- EventBus 支持松耦合的功能增强

### 3. 高性能
- 异步优先设计，充分利用 Python 3.12+ asyncio
- 连接池、并发控制等优化
- 性能提升 2-30 倍

### 4. 完整的可观测性
- OpenTelemetry 追踪
- Structured Logging
- EventBus 事件流
- Allure 报告自动集成

### 5. 向后兼容
- 同步 API 完全保留
- 渐进式升级路径
- 降低迁移成本

---

## 📚 进一步阅读

- **[五层架构详解](./五层架构详解.md)** - 每层的详细说明
- **[中间件系统设计](./MIDDLEWARE_V3.14_DESIGN.md)** - 洋葱模型实现
- **[可观测性架构](./observability-architecture.md)** - EventBus + OpenTelemetry
- **[插件系统](./PLUGIN_SYSTEM_V3.37.md)** - Pluggy 集成
- **[测试执行生命周期](./TEST_EXECUTION_LIFECYCLE.md)** - 从初始化到报告生成

---

**版本历史**:
- v4.0.0 (2026-01-16): 全面异步化
- v3.17.0 (2025-12-05): 事件系统重构
- v3.16.0 (2025-12-03): Layer 4 Bootstrap 引导层
- v3.14.0 (2025-11-28): 中间件系统统一

**归档文档**: [架构历史版本](./archive/versions/)
