# df-test-framework v3.6.2 架构说明

## 📐 测试数据清理控制机制架构

### 设计原则

**核心功能在框架层，业务逻辑在项目层**

| 层级 | 职责 | 示例 |
|------|------|------|
| **框架层** | 提供核心测试能力和通用机制 | db_transaction fixture，数据清理控制 |
| **项目层** | 实现业务相关的测试逻辑 | 业务特定的 fixtures、测试用例 |

### 架构决策

#### 为什么在框架层实现？

1. **统一行为** ✅
   - 所有使用框架的测试项目自动获得一致的数据清理机制
   - 避免每个项目重复实现相同的逻辑

2. **简化维护** ✅
   - 功能升级只需更新框架版本
   - 不需要修改每个测试项目的代码

3. **最佳实践** ✅
   - 框架提供经过验证的最佳实践
   - 减少项目层面的实现错误

4. **可扩展性** ✅
   - 项目可以通过覆盖 fixture 实现自定义行为
   - 保持灵活性的同时提供良好的默认行为

#### 架构分层

```
┌─────────────────────────────────────────────────────────┐
│                    测试项目层                            │
│  ┌───────────────────────────────────────────────────┐  │
│  │  tests/conftest.py                                │  │
│  │  - 导入框架 pytest 插件                           │  │
│  │  - 注册业务相关标记（smoke, master, h5 等）      │  │
│  │  - 定义业务特定 fixtures（api, repository）      │  │
│  │  - 可选：覆盖框架 fixtures                       │  │
│  └───────────────────────────────────────────────────┘  │
│                         ↓ 使用                           │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│                  测试框架核心层                          │
│  ┌───────────────────────────────────────────────────┐  │
│  │  df_test_framework/testing/fixtures/core.py       │  │
│  │  ✅ db_transaction fixture                        │  │
│  │  ✅ --keep-test-data 命令行选项                   │  │
│  │  ✅ keep_data 标记注册                            │  │
│  │  ✅ 数据清理控制逻辑                              │  │
│  │  ✅ runtime, http_client, database fixtures       │  │
│  └───────────────────────────────────────────────────┘  │
│                         ↓ 依赖                           │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│                  测试框架基础层                          │
│  ┌───────────────────────────────────────────────────┐  │
│  │  df_test_framework/infrastructure/                │  │
│  │  - Bootstrap（应用启动）                          │  │
│  │  - RuntimeContext（运行时上下文）                 │  │
│  │  - Database（数据库连接）                         │  │
│  │  - HttpClient（HTTP客户端）                       │  │
│  │  - ObservabilityLogger（可观测性）                │  │
│  └───────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────┘
```

### 关键组件

#### 1. pytest_addoption

**位置**: `df_test_framework/testing/fixtures/core.py:70-101`

**职责**: 注册框架级别的命令行选项

```python
def pytest_addoption(parser: pytest.Parser) -> None:
    # 框架配置相关
    parser.addoption("--df-settings-class", ...)
    parser.addoption("--df-plugin", ...)

    # v3.6.2: 数据清理控制
    parser.addoption(
        "--keep-test-data",
        action="store_true",
        default=False,
        help="保留测试数据到数据库（不自动回滚）"
    )
```

#### 2. pytest_configure

**位置**: `df_test_framework/testing/fixtures/core.py:104-123`

**职责**:
- 初始化框架运行时环境
- 注册框架级别的 pytest 标记

```python
def pytest_configure(config: pytest.Config) -> None:
    # 初始化框架
    bootstrap = Bootstrap().with_settings(settings_cls)
    _runtime_context = bootstrap.build().run()

    # v3.6.2: 注册 keep_data 标记
    config.addinivalue_line(
        "markers",
        "keep_data: 保留测试数据到数据库（不自动回滚）"
    )
```

#### 3. db_transaction fixture

**位置**: `df_test_framework/testing/fixtures/core.py:251-361`

**职责**: 提供事务隔离的数据库连接，支持灵活的数据清理控制

```python
@pytest.fixture
def db_transaction(database, request):
    """v3.6.2 增强：支持可配置的数据清理控制"""
    session = database.session_factory()

    # 优先级：标记 > 参数 > 环境变量 > 默认
    keep_data = (
        request.node.get_closest_marker("keep_data")
        or request.config.option.keep_test_data
        or os.getenv("KEEP_TEST_DATA") in ["1", "true", "yes"]
    )

    try:
        yield session
        session.commit() if keep_data else session.rollback()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()
```

### 测试项目如何使用

#### 1. 最简配置

```python
# tests/conftest.py

# 导入框架 pytest 插件
pytest_plugins = ["df_test_framework.testing.fixtures.core"]

# 使用框架提供的 fixtures
def test_example(db_transaction):
    # 自动回滚
    pass
```

#### 2. 添加业务标记

```python
# tests/conftest.py

pytest_plugins = ["df_test_framework.testing.fixtures.core"]

def pytest_configure(config):
    """注册业务相关标记"""
    config.addinivalue_line("markers", "smoke: 冒烟测试")
    config.addinivalue_line("markers", "master: Master系统测试")
```

#### 3. 定义业务 fixtures

```python
# tests/conftest.py

pytest_plugins = ["df_test_framework.testing.fixtures.core"]

@pytest.fixture
def master_card_api(http_client):
    """业务特定的 API fixture"""
    from gift_card_test.apis import MasterCardAPI
    return MasterCardAPI(http_client)
```

#### 4. 覆盖框架 fixtures（可选）

```python
# tests/conftest.py

pytest_plugins = ["df_test_framework.testing.fixtures.core"]

@pytest.fixture
def db_transaction(database, request):
    """自定义实现，覆盖框架提供的 fixture"""
    # 完全自定义的实现
    pass
```

### 配置优先级

```
项目级 fixture 覆盖
    ↓
框架级 fixture（core.py）
    ↓
pytest 默认 fixture
```

### 扩展性设计

#### 1. Fixture 继承和覆盖

测试项目可以：
- ✅ 使用框架提供的 fixtures
- ✅ 覆盖框架 fixtures 实现自定义行为
- ✅ 扩展框架 fixtures 添加新功能

#### 2. 插件机制

框架支持通过插件扩展功能：
```bash
pytest --df-plugin=my_plugin tests/
```

#### 3. 配置化

框架行为可通过多种方式配置：
- 命令行参数
- 环境变量
- pytest.ini
- Settings 类

### 最佳实践

#### ✅ 推荐做法

1. **使用框架提供的核心 fixtures**
   ```python
   def test_example(db_transaction, http_client):
       # 直接使用，零配置
       pass
   ```

2. **在项目层添加业务 fixtures**
   ```python
   @pytest.fixture
   def order_service(http_client, database):
       return OrderService(http_client, database)
   ```

3. **保持项目 conftest.py 简洁**
   - 只添加业务相关的 fixtures
   - 只注册业务相关的标记
   - 不重复实现框架已提供的功能

#### ❌ 避免的做法

1. **不要在项目层重复实现框架功能**
   ```python
   # ❌ 错误：重复实现 db_transaction
   @pytest.fixture
   def db_transaction(runtime, request):
       # 100行的实现...
   ```

2. **不要硬编码配置**
   ```python
   # ❌ 错误：硬编码
   ALWAYS_KEEP_DATA = True

   # ✅ 正确：使用配置
   keep_data = request.config.option.keep_test_data
   ```

3. **不要绕过框架机制**
   ```python
   # ❌ 错误：直接操作 session.commit()
   db_transaction.commit()  # 绕过了自动回滚机制

   # ✅ 正确：使用标记
   @pytest.mark.keep_data
   def test_example(db_transaction):
       pass
   ```

### 版本兼容性

| 版本 | db_transaction 行为 | 控制选项 |
|------|-------------------|---------|
| v3.5.0 | 测试成功时提交 | 无 |
| v3.6.1 | 需要项目手动实现 | 项目层实现 |
| v3.6.2 | 默认回滚，可配置 | 框架层实现 |

### 升级指南

#### 从 v3.5.0 升级到 v3.6.2

1. **更新框架版本**
   ```bash
   uv pip install df-test-framework==3.6.2
   ```

2. **移除项目中的重复实现**
   ```python
   # tests/conftest.py

   # ❌ 删除这些（框架已提供）
   # def pytest_addoption(parser):
   #     parser.addoption("--keep-test-data", ...)
   #
   # @pytest.fixture
   # def db_transaction(runtime, request):
   #     ...
   ```

3. **确保导入框架插件**
   ```python
   # tests/conftest.py
   pytest_plugins = ["df_test_framework.testing.fixtures.core"]
   ```

4. **验证功能**
   ```bash
   pytest tests/ -v
   # 应看到: ✅ 测试数据已回滚（自动清理）
   ```

### 常见问题

**Q: 为什么我的项目还需要 conftest.py？**

A: 项目层的 conftest.py 用于：
- 导入框架 pytest 插件
- 注册业务相关的标记
- 定义业务特定的 fixtures
- 不应该重复实现框架已有的功能

**Q: 如何在项目中自定义 db_transaction 行为？**

A: 直接在项目的 conftest.py 中定义同名 fixture：
```python
@pytest.fixture
def db_transaction(database, request):
    # 自定义实现会覆盖框架的实现
    pass
```

**Q: 框架更新后，现有测试需要修改吗？**

A: 大多数情况下不需要。框架保持向后兼容，只有默认行为变更：
- v3.5.0: 测试成功时提交（不安全）
- v3.6.2: 默认回滚（更安全）

如需保留数据，使用 `@pytest.mark.keep_data` 标记。

---

**版本**: v3.6.2
**更新时间**: 2025-11-24
**维护者**: DF QA Team
