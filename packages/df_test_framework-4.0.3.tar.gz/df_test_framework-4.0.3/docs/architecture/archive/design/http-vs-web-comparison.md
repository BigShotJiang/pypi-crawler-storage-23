# HTTP vs Web 架构对比分析

> **版本**: v3.43.0
> **最后更新**: 2026-01-08
> **状态**: ✅ 已纠正错误建议

---

## 目录

- [架构对比](#架构对比)
- [常见误解澄清](#常见误解澄清)
- [真实差异分析](#真实差异分析)
- [架构设计原则](#架构设计原则)
- [总结](#总结)

---

## 架构对比

### HTTP 客户端架构

```
capabilities/clients/http/
├── core/                    # 核心抽象（Request, Response）
├── middleware/              # 中间件（洋葱模型）
└── rest/                    # REST 协议层
    ├── protocols.py         # RestClientProtocol 接口
    ├── factory.py           # RestClientFactory 工厂
    └── httpx/               # httpx 实现层
        ├── client.py        # HttpClient（框架内实现）
        └── async_client.py  # AsyncHttpClient
```

**特点**:
- ✅ 有工厂模式：`RestClientFactory`
- ✅ 框架内实现：`HttpClient` 直接在框架内
- ✅ 配置驱动：`HTTPConfig` + Provider 单例
- 📝 协议层：`rest/graphql/grpc` 表示**通信协议类型**
- 📁 目录深度：`clients/http/rest/httpx/` 四层结构

**为什么需要协议层？**

HTTP 通信支持多种协议标准：
```
clients/http/
├── rest/         # REST API 协议（当前）
│   └── httpx/    # httpx 实现
├── graphql/      # GraphQL 协议（已存在）
│   └── gql/      # gql 实现
└── grpc/         # gRPC 协议（已存在）
    └── grpcio/   # grpcio 实现
```

每种协议有不同的：
- 通信方式（请求/响应格式）
- 数据序列化（JSON / Protobuf / GraphQL）
- 传输机制（HTTP/1.1 / HTTP/2 / HTTP/3）

---

### Web 驱动架构

```
capabilities/drivers/web/
├── protocols.py             # WebDriverProtocol 接口
├── factory.py               # WebDriverFactory 工厂
├── playwright/              # Playwright 实现层
│   ├── browser.py           # BrowserManager（框架内实现）
│   ├── page.py              # BasePage
│   └── component.py         # BaseComponent
└── selenium/                # Selenium 实现层（预留）
    └── driver.py
```

**特点**:
- ✅ 有工厂模式：`WebDriverFactory`
- ✅ 框架内实现：`BrowserManager` 直接在框架内
- ✅ 配置驱动：`WebConfig` + Provider 单例
- 📁 目录深度：`drivers/web/playwright/` 三层结构
- ⚠️ **无协议层**：`web` 直接是自动化类型，不是协议

**为什么不需要协议层？**

`drivers/` 的组织逻辑是**UI 自动化类型**：
```
drivers/
├── web/          # 浏览器自动化（类型）
│   ├── playwright/   # 实现方式1
│   └── selenium/     # 实现方式2
├── mobile/       # 移动应用自动化（类型）- 预留
│   └── appium/       # 实现方式
└── desktop/      # 桌面应用自动化（类型）- 预留
    └── pywinauto/    # 实现方式
```

关键区别：
- `web` / `mobile` / `desktop` 是**自动化目标类型**，不是通信协议
- `playwright` / `selenium` 是**实现工具**，不是协议标准

---

## 常见误解澄清

### ❌ 误解 1: HTTP 客户端封装在框架内，Web 驱动不是

**真相**: 两者都在框架内实现 ✅

| 组件 | 位置 | 说明 |
|------|------|------|
| HttpClient | `http/rest/httpx/client.py` | 框架内封装 httpx |
| BrowserManager | `web/playwright/browser.py` | 框架内封装 playwright |

**结论**: 封装方式**完全一致**，都是框架内实现的适配器类。

---

### ❌ 误解 2: Web 使用了 Factory，HTTP 不是

**真相**: 两者都有工厂模式 ✅

| 工厂类 | 位置 | 说明 |
|--------|------|------|
| RestClientFactory | `http/rest/factory.py` | HTTP 工厂 |
| WebDriverFactory | `web/factory.py` | Web 工厂 |

**工厂实现对比**:

```python
# RestClientFactory
RestClientFactory.create(client_type="httpx", config=HTTPConfig())
RestClientFactory.create_httpx(config)
RestClientFactory.create_requests(config)  # 预留

# WebDriverFactory
WebDriverFactory.create(driver_type="playwright", browser="chromium")
WebDriverFactory.create_playwright(browser="firefox")
WebDriverFactory.create_selenium(browser="chrome")  # 预留
```

**结论**: 工厂模式**完全一致**，都支持多种实现切换。

---

## 真实差异分析

### 唯一真实差异: 目录层级深度

| 维度 | HTTP Clients | Web Drivers |
|------|--------------|-------------|
| **组织逻辑** | 通信协议类型 | UI 自动化类型 |
| **协议层** | `rest/` `graphql/` `grpc/` | ❌ 无协议层 |
| **实现层** | `httpx/` `requests/` | `playwright/` `selenium/` |
| **目录深度** | 4层 (`clients/http/rest/httpx/`) | 3层 (`drivers/web/playwright/`) |

### 为什么深度不同？

#### HTTP Clients: 四层架构

```
Layer 1: clients/         ← 能力大类（客户端）
Layer 2: http/            ← 传输协议（HTTP 通信）
Layer 3: rest/            ← 应用协议（REST/GraphQL/gRPC）
Layer 4: httpx/           ← 实现工具（httpx/requests）
```

**原因**: HTTP 通信有多层协议栈：
- 传输层协议：HTTP/1.1、HTTP/2、HTTP/3
- 应用层协议：REST、GraphQL、gRPC、SOAP
- 实现工具：httpx、requests、aiohttp

#### Web Drivers: 三层架构

```
Layer 1: drivers/         ← 能力大类（驱动）
Layer 2: web/             ← 自动化类型（浏览器/移动/桌面）
Layer 3: playwright/      ← 实现工具（playwright/selenium）
```

**原因**: UI 自动化没有协议层概念：
- `web` / `mobile` / `desktop` 是目标类型，不是协议
- `playwright` / `selenium` 直接是实现工具
- 没有中间的"协议标准层"

---

## 架构设计原则

### 原则 1: 按业务逻辑分层，而非强行对齐

**错误做法** ❌：为了对齐目录深度，强行引入 `web/browser/` 层

```
drivers/web/
└── browser/          # ❌ 不必要的层级
    ├── playwright/
    └── selenium/
```

**问题**:
- `browser` 层没有实际意义（`web` 已经表示浏览器）
- 与 `mobile`、`desktop` 平级关系被打破
- 违反 YAGNI 原则（You Aren't Gonna Need It）

**正确做法** ✅：保持当前架构

```
drivers/
├── web/          # 浏览器自动化（类型）
│   ├── playwright/
│   └── selenium/
├── mobile/       # 移动端自动化（类型）
└── desktop/      # 桌面应用自动化（类型）
```

---

### 原则 2: 架构一致性 ≠ 目录深度一致

**一致性的真正含义**:
- ✅ 设计模式一致（都有 Factory、Protocol、配置驱动）
- ✅ 职责划分一致（都是能力层实现）
- ✅ 使用方式一致（都通过 RuntimeContext 获取）
- ❌ 目录深度一致（不同业务逻辑，深度自然不同）

**类比**:
```
food/
├── fruit/          # 2层（水果没有子分类）
│   ├── apple/
│   └── banana/
└── meat/           # 3层（肉类有畜肉/禽肉分类）
    ├── pork/       # 畜肉
    │   └── bacon/
    └── chicken/    # 禽肉
        └── wing/
```

`fruit` 和 `meat` 深度不同，但这是**业务逻辑决定的**，不是架构问题。

---

### 原则 3: 预留扩展空间，而非过度设计

**当前架构已预留扩展**:

```
drivers/
├── web/          # ✅ 已实现
│   ├── playwright/   # ✅ 已实现
│   └── selenium/     # 📋 预留
├── mobile/       # 📋 预留
│   └── appium/
└── desktop/      # 📋 预留
    └── pywinauto/
```

**未来扩展场景**:
- 新增 `drivers/api/` 用于 API 测试工具（Postman、Insomnia）？
  - ❌ 不合适，API 测试属于 `clients/`，不是 `drivers/`
- 新增 `web/puppeteer/` 新实现？
  - ✅ 合适，与 `playwright/` 平级
- 新增 `mobile/xcuitest/` iOS 测试？
  - ✅ 合适，与 `appium/` 平级

---

## ~~之前的错误建议~~（已废弃）

### ~~方案 A：Web 引入协议层~~（❌ 错误）

~~**调整后的目录结构**~~：

```
drivers/web/
└── browser/          # ❌ 不必要的协议层
    ├── playwright/
    └── selenium/
```

**为什么错误？**
1. ❌ `web` 和 `mobile`、`desktop` 应该平级，不应该有中间层
2. ❌ `browser` 层没有实际意义（`web` 已经表示浏览器自动化）
3. ❌ 违反 YAGNI 原则（没有实际需求）
4. ❌ 破坏性变更：所有导入路径都需要修改

**正确理解**:
- `clients/http/rest/` 的 `rest` 是**通信协议**（REST API 标准）
- `drivers/web/` 的 `web` 是**自动化类型**（浏览器 UI）
- 两者不是同一层次的概念，不需要强行对齐

---

## 事件系统架构对比（v3.44.0）

### 统一的事件驱动架构

HTTP 和 Web UI 使用**完全一致**的事件驱动架构：

```
┌─────────────────────────────────────────────────────────────────┐
│                     test_runtime fixture                         │
│  1. 创建测试专用 EventBus                                        │
│  2. 注入到 RuntimeContext.event_bus                              │
│  3. set_test_event_bus(test_event_bus) - 向后兼容               │
├─────────────────────────────────────────────────────────────────┤
│                     allure fixture (autouse)                     │
│  1. 获取 test_event_bus (通过 get_event_bus())                  │
│  2. 订阅所有事件（HTTP + Web UI + Database + ...）              │
├─────────────────────────────────────────────────────────────────┤
│  HTTP                           │  Web UI                        │
│  HttpEventPublisherMiddleware   │  BrowserManager                │
│  ↓ runtime.event_bus           │  ↓ runtime.event_bus           │
│  ↓ 发布 HttpRequestStartEvent  │  ↓ 注册 page.on() 监听器       │
│  ↓ 发布 HttpRequestEndEvent    │  ↓ 发布 WebBrowserEvent        │
├─────────────────────────────────────────────────────────────────┤
│                     AllureObserver                               │
│  handle_http_request_*_event() │  handle_web_browser_event()    │
└─────────────────────────────────────────────────────────────────┘
```

### 事件系统对比

| 维度 | HTTP | Web UI | 一致性 |
|------|------|--------|--------|
| **EventBus 来源** | `runtime.event_bus` | `runtime.event_bus` | ✅ 完全一致 |
| **RuntimeContext** | 使用 test_runtime | 使用 test_runtime | ✅ 完全一致 |
| **事件发布位置** | HttpEventPublisherMiddleware | BrowserManager._setup_event_listeners() | ✅ 理念一致 |
| **测试隔离** | 每个测试独立 EventBus | 每个测试独立 EventBus | ✅ 完全一致 |
| **Allure 订阅** | allure fixture 自动订阅 | allure fixture 自动订阅 | ✅ 完全一致 |
| **事件类型** | HttpRequestStartEvent/EndEvent | WebBrowserEvent | ✅ 各自领域事件 |

### 关键设计决策

1. **EventBus 集成到 RuntimeContext**
   - `RuntimeContext.event_bus` 字段存储 EventBus
   - `test_runtime` fixture（function 级别）创建测试专用 EventBus
   - `runtime` fixture（session 级别）不包含 EventBus
   - 显式依赖注入，架构清晰

2. **事件注册位置**
   - HTTP: 在 HttpEventPublisherMiddleware 中（中间件链最内层）
   - Web: 在 BrowserManager._setup_event_listeners() 中（由 page fixture 调用）

3. **配置应用位置**
   - HTTP: HttpClient 构造函数
   - Web: context fixture（应用 viewport/timeout/视频录制）

4. **向后兼容**
   - 保留 `get_event_bus()` 全局函数
   - 保留 `set_test_event_bus()` 全局函数
   - BrowserManager 优先使用 `runtime.event_bus`，回退到 `get_event_bus()`

### 事件类型

**HTTP 事件**:
- `HttpRequestStartEvent` - 请求开始
- `HttpRequestEndEvent` - 请求结束
- `HttpRequestErrorEvent` - 请求错误

**Web UI 事件**:
- `WebBrowserEvent` - 浏览器事件（page.load, network.request, console 等）
- `UIErrorEvent` - UI 错误事件（pageerror, crash）

---

## 总结

### 问题澄清

| 问题 | 状态 | 结论 |
|------|------|------|
| 封装方式不一致 | ❌ 误解 | 两者都在框架内实现 |
| 工厂模式不一致 | ❌ 误解 | 两者都有工厂模式 |
| 目录层级不一致 | ✅ 正常差异 | 业务逻辑不同，深度自然不同 |

### 当前架构评估

| 维度 | HTTP Clients | Web Drivers | 评价 |
|------|--------------|-------------|------|
| **设计模式** | Factory + Protocol + Provider | Factory + Protocol + Provider | ✅ 一致 |
| **配置驱动** | HTTPConfig + RuntimeContext | WebConfig + RuntimeContext | ✅ 一致 |
| **封装方式** | 框架内封装 httpx | 框架内封装 playwright | ✅ 一致 |
| **目录深度** | 4层 | 3层 | ✅ 符合业务逻辑 |
| **扩展性** | 支持多协议（REST/GraphQL/gRPC） | 支持多实现（Playwright/Selenium） | ✅ 都预留扩展 |
| **事件系统** | runtime.event_bus + Middleware | runtime.event_bus + BrowserManager | ✅ 一致 |

### 核心结论

**架构设计正确性** ✅：
1. ✅ HTTP 需要协议层（REST/GraphQL/gRPC 是不同通信协议）
2. ✅ Web 不需要协议层（web/mobile/desktop 是自动化类型，不是协议）
3. ✅ 目录深度差异是**业务逻辑决定的**，不是架构问题
4. ✅ 真正的一致性体现在**设计模式、配置驱动、使用方式**，而非目录深度

**架构演进建议**:
- ✅ 保持当前架构不变
- ✅ 文档中明确说明 HTTP vs Web 的组织逻辑差异
- ✅ 未来扩展时遵循相同原则：
  - `clients/` 按通信协议分层
  - `drivers/` 按自动化类型分层

---

## 附录：完整目录结构对比

### HTTP Clients（按协议分层）

```
capabilities/clients/
└── http/                    # HTTP 通信
    ├── core/                # 核心抽象
    ├── middleware/          # 中间件
    ├── rest/                # REST 协议 ← 协议层
    │   ├── protocols.py
    │   ├── factory.py
    │   ├── httpx/           # httpx 实现 ← 实现层
    │   │   └── client.py
    │   └── requests/        # requests 实现（预留）
    ├── graphql/             # GraphQL 协议 ← 协议层
    │   └── gql/             # gql 实现 ← 实现层
    └── grpc/                # gRPC 协议 ← 协议层
        └── grpcio/          # grpcio 实现 ← 实现层
```

### Web Drivers（按类型分层）

```
capabilities/drivers/
├── web/                     # 浏览器自动化 ← 类型层
│   ├── protocols.py
│   ├── factory.py
│   ├── playwright/          # Playwright 实现 ← 实现层
│   │   ├── browser.py
│   │   ├── page.py
│   │   └── component.py
│   └── selenium/            # Selenium 实现（预留）
├── mobile/                  # 移动端自动化 ← 类型层（预留）
│   └── appium/              # Appium 实现 ← 实现层
└── desktop/                 # 桌面应用自动化 ← 类型层（预留）
    └── pywinauto/           # PyWinAuto 实现 ← 实现层
```

### 关键差异总结

| 维度 | HTTP Clients | Web Drivers |
|------|--------------|-------------|
| **中间层含义** | 通信协议（REST/GraphQL/gRPC） | 自动化类型（web/mobile/desktop） |
| **中间层必要性** | ✅ 必要（协议标准不同） | ✅ 必要（目标平台不同） |
| **叶子层含义** | 实现工具（httpx/requests） | 实现工具（playwright/selenium） |
| **目录深度** | 4层 | 3层 |
| **深度差异原因** | 多了一层协议标准 | 类型层直接对应目标平台 |

---

**文档维护者**: DF Test Framework Team
**最后更新**: 2026-01-12
**版本**: v3.44.0
