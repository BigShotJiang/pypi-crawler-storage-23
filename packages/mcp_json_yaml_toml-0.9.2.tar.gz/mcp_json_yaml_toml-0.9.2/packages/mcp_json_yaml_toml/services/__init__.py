"""Service modules extracted from server.py."""
