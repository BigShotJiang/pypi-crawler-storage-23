"""Pydantic response models for MCP tool returns."""
