"""Test that tomlkit preserves comments and formatting."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

import pytest

from mcp_json_yaml_toml import server

if TYPE_CHECKING:
    from collections.abc import Callable
    from pathlib import Path

# FastMCP 3.x: decorators return the original function directly (no .fn needed).
# At runtime these are callable; cast to satisfy mypy's FunctionTool type.
data_fn = cast("Callable[..., Any]", server.data)


@pytest.mark.integration
def test_toml_preserves_comments(tmp_path: Path) -> None:
    """Test that SET operation preserves comments in TOML files."""
    # Create a TOML file with comments
    test_file = tmp_path / "config.toml"
    test_file.write_text("""# Database configuration
[database]
host = "localhost"  # Production host
port = 5432

# Application settings
[app]
name = "myapp"
""")

    # Add a new key
    result = data_fn(
        file_path=str(test_file),
        operation="set",
        key_path="database.username",
        value='"admin"',
    )

    # Should succeed
    assert result["success"] is True

    # Read the file and verify comments are preserved
    modified_content = test_file.read_text()
    assert "# Database configuration" in modified_content
    assert "# Production host" in modified_content
    assert "# Application settings" in modified_content
    assert "username" in modified_content
    assert "admin" in modified_content


@pytest.mark.integration
def test_toml_delete_preserves_comments(tmp_path: Path) -> None:
    """Test that DELETE operation preserves comments in TOML files."""
    test_file = tmp_path / "config.toml"
    test_file.write_text("""# Database configuration
[database]
host = "localhost"
port = 5432  # Default PostgreSQL port
username = "admin"
""")

    # Delete a key
    result = data_fn(
        file_path=str(test_file), operation="delete", key_path="database.username"
    )

    # Should succeed
    assert result["success"] is True

    # Read the file and verify comments are preserved
    modified_content = test_file.read_text()
    assert "# Database configuration" in modified_content
    assert "# Default PostgreSQL port" in modified_content
    assert "username" not in modified_content
