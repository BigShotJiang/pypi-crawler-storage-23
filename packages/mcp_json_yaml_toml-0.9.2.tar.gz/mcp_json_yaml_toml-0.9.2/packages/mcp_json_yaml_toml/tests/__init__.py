"""Tests for mcp_json_yaml_toml package."""
