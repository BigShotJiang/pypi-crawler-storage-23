"""Format detection, parsing, and value handling modules."""
