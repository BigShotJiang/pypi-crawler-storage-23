How to write a processor?
#########################

(under construction)
