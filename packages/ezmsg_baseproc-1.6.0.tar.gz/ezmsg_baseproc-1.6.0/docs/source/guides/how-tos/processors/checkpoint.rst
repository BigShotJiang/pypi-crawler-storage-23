How to checkpoint and restore processor state?
##############################################

(under construction)
