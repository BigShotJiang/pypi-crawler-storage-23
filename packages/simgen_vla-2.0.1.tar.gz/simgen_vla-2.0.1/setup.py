"""
SimGen VLA - TRUE ZERO ERROR GPU Computation
=============================================
Universal lossless arithmetic for PyTorch.
Linux + Triton for development, cubins for production.
"""

from setuptools import setup, find_packages

NAME = "simgen-vla"
VERSION = "2.0.1"
DESCRIPTION = "SimGen VLA: TRUE ZERO ERROR GPU computation. Every calculation. Zero error."

setup(
    name=NAME,
    version=VERSION,
    description=DESCRIPTION,
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Clouthier Simulation Labs",
    author_email="kyle@simgen.dev",
    url="https://simgen.dev",
    packages=find_packages(exclude=["tests", "tests.*", "archive", "archive.*"]),
    package_data={
        "simgen": [
            "*.py",
            "cubin/*.cubin",
            "cubin/*.json",
        ]
    },
    install_requires=[
        "torch>=2.0",
    ],
    extras_require={
        "triton": ["triton>=3.0"],
        "dev": ["triton>=3.0", "pytest", "mpmath"],
    },
    python_requires=">=3.10",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "Operating System :: POSIX :: Linux",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Scientific/Engineering",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
)
