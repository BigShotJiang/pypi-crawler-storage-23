#!/usr/bin/env python3
"""
VLA Adam vs AdamW on GPT-2 + WikiText-2
========================================
Compares TRUE VLA Adam optimizer against PyTorch AdamW.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
import time
import math

# Try to import VLA
try:
    from simgen import vla
    HAS_VLA = True
    print(f"SimGen VLA v{vla.__version__} loaded")
except ImportError:
    HAS_VLA = False
    print("SimGen VLA not available")

# Simple GPT-2 style model
class GPT2Block(nn.Module):
    def __init__(self, d_model, n_heads, dropout=0.1):
        super().__init__()
        self.ln1 = nn.LayerNorm(d_model)
        self.attn = nn.MultiheadAttention(d_model, n_heads, dropout=dropout, batch_first=True)
        self.ln2 = nn.LayerNorm(d_model)
        self.mlp = nn.Sequential(
            nn.Linear(d_model, 4 * d_model),
            nn.GELU(),
            nn.Linear(4 * d_model, d_model),
            nn.Dropout(dropout),
        )

    def forward(self, x, mask=None):
        x = x + self.attn(self.ln1(x), self.ln1(x), self.ln1(x), attn_mask=mask, need_weights=False)[0]
        x = x + self.mlp(self.ln2(x))
        return x

class GPT2(nn.Module):
    def __init__(self, vocab_size=50257, d_model=256, n_heads=4, n_layers=4, max_seq=256, dropout=0.1):
        super().__init__()
        self.d_model = d_model
        self.tok_emb = nn.Embedding(vocab_size, d_model)
        self.pos_emb = nn.Embedding(max_seq, d_model)
        self.drop = nn.Dropout(dropout)
        self.blocks = nn.ModuleList([GPT2Block(d_model, n_heads, dropout) for _ in range(n_layers)])
        self.ln_f = nn.LayerNorm(d_model)
        self.head = nn.Linear(d_model, vocab_size, bias=False)

        # Weight tying
        self.head.weight = self.tok_emb.weight

        # Causal mask
        self.register_buffer("mask", torch.triu(torch.ones(max_seq, max_seq), diagonal=1).bool())

    def forward(self, x):
        B, T = x.shape
        pos = torch.arange(T, device=x.device).unsqueeze(0)
        x = self.drop(self.tok_emb(x) + self.pos_emb(pos))

        mask = self.mask[:T, :T]
        for block in self.blocks:
            x = block(x, mask)

        x = self.ln_f(x)
        return self.head(x)

def get_wikitext2():
    """Load WikiText-2 dataset."""
    try:
        from datasets import load_dataset
        ds = load_dataset("wikitext", "wikitext-2-raw-v1", split="train")
        text = "\n".join([t for t in ds["text"] if t.strip()])
        return text
    except:
        # Fallback: generate random text
        print("WikiText-2 not available, using random data")
        return None

def tokenize_simple(text, vocab_size=50257):
    """Simple byte-level tokenization."""
    tokens = [ord(c) % vocab_size for c in text]
    return torch.tensor(tokens, dtype=torch.long)

class TextDataset(torch.utils.data.Dataset):
    def __init__(self, tokens, seq_len):
        self.tokens = tokens
        self.seq_len = seq_len

    def __len__(self):
        return (len(self.tokens) - 1) // self.seq_len

    def __getitem__(self, idx):
        start = idx * self.seq_len
        x = self.tokens[start:start + self.seq_len]
        y = self.tokens[start + 1:start + self.seq_len + 1]
        return x, y

class VLAAdam:
    """Wrapper for VLA Adam that matches PyTorch optimizer interface."""

    def __init__(self, params, lr=1e-3, betas=(0.9, 0.999), eps=1e-8, weight_decay=0.01):
        self.params = list(params)
        self.lr = lr
        self.beta1, self.beta2 = betas
        self.eps = eps
        self.weight_decay = weight_decay
        self.step_count = 0

        # Initialize state
        self.exp_avg = [torch.zeros_like(p) for p in self.params]
        self.exp_avg_sq = [torch.zeros_like(p) for p in self.params]

    def zero_grad(self):
        for p in self.params:
            if p.grad is not None:
                p.grad.zero_()

    def step(self):
        self.step_count += 1
        with torch.no_grad():
            for i, p in enumerate(self.params):
                if p.grad is None:
                    continue

                # VLA AdamW step
                p_new, self.exp_avg[i], self.exp_avg_sq[i] = vla.adamw_step(
                    p, p.grad, self.exp_avg[i], self.exp_avg_sq[i],
                    step=self.step_count,
                    lr=self.lr,
                    beta1=self.beta1,
                    beta2=self.beta2,
                    eps=self.eps,
                    weight_decay=self.weight_decay
                )
                p.copy_(p_new.float())

def train_epoch(model, loader, optimizer, device, use_vla_loss=False):
    model.train()
    total_loss = 0
    total_tokens = 0

    for x, y in loader:
        x, y = x.to(device), y.to(device)

        optimizer.zero_grad()
        logits = model(x)

        # Loss computation
        loss = F.cross_entropy(logits.view(-1, logits.size(-1)), y.view(-1))

        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()

        total_loss += loss.item() * y.numel()
        total_tokens += y.numel()

    return total_loss / total_tokens

def evaluate(model, loader, device):
    model.eval()
    total_loss = 0
    total_tokens = 0

    with torch.no_grad():
        for x, y in loader:
            x, y = x.to(device), y.to(device)
            logits = model(x)
            loss = F.cross_entropy(logits.view(-1, logits.size(-1)), y.view(-1))
            total_loss += loss.item() * y.numel()
            total_tokens += y.numel()

    avg_loss = total_loss / total_tokens
    return avg_loss, math.exp(avg_loss)

def main():
    print("="*60)
    print("VLA Adam vs AdamW on GPT-2 + WikiText-2")
    print("="*60)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}")

    # Config
    VOCAB_SIZE = 256  # Byte-level
    D_MODEL = 256
    N_HEADS = 4
    N_LAYERS = 4
    SEQ_LEN = 128
    BATCH_SIZE = 16
    EPOCHS = 3
    LR = 3e-4

    # Load data
    text = get_wikitext2()
    if text is None:
        # Generate synthetic data
        text = "".join([chr(i % 256) for i in range(100000)])

    tokens = tokenize_simple(text, VOCAB_SIZE)
    n_train = int(len(tokens) * 0.9)
    train_tokens = tokens[:n_train]
    val_tokens = tokens[n_train:]

    train_ds = TextDataset(train_tokens, SEQ_LEN)
    val_ds = TextDataset(val_tokens, SEQ_LEN)

    train_loader = DataLoader(train_ds, batch_size=BATCH_SIZE, shuffle=True, drop_last=True)
    val_loader = DataLoader(val_ds, batch_size=BATCH_SIZE, drop_last=True)

    print(f"\nData: {len(train_tokens):,} train tokens, {len(val_tokens):,} val tokens")
    print(f"Model: {N_LAYERS} layers, {D_MODEL} dim, {N_HEADS} heads")
    print(f"Training: {EPOCHS} epochs, batch={BATCH_SIZE}, seq={SEQ_LEN}, lr={LR}")

    results = {}

    # ========== Train with AdamW ==========
    print("\n" + "="*60)
    print("Training with PyTorch AdamW")
    print("="*60)

    torch.manual_seed(42)
    model_adamw = GPT2(VOCAB_SIZE, D_MODEL, N_HEADS, N_LAYERS, SEQ_LEN).to(device)
    opt_adamw = torch.optim.AdamW(model_adamw.parameters(), lr=LR, weight_decay=0.01)

    n_params = sum(p.numel() for p in model_adamw.parameters())
    print(f"Parameters: {n_params:,}")

    adamw_losses = []
    adamw_ppls = []
    t0 = time.time()

    for epoch in range(1, EPOCHS + 1):
        train_loss = train_epoch(model_adamw, train_loader, opt_adamw, device)
        val_loss, val_ppl = evaluate(model_adamw, val_loader, device)
        adamw_losses.append(val_loss)
        adamw_ppls.append(val_ppl)
        print(f"  Epoch {epoch}: train_loss={train_loss:.4f}, val_loss={val_loss:.4f}, val_ppl={val_ppl:.2f}")

    adamw_time = time.time() - t0
    results["adamw"] = {"losses": adamw_losses, "ppls": adamw_ppls, "time": adamw_time}

    # ========== Train with VLA Adam ==========
    if HAS_VLA:
        print("\n" + "="*60)
        print("Training with TRUE VLA AdamW")
        print("="*60)

        torch.manual_seed(42)
        model_vla = GPT2(VOCAB_SIZE, D_MODEL, N_HEADS, N_LAYERS, SEQ_LEN).to(device)
        opt_vla = VLAAdam(model_vla.parameters(), lr=LR, weight_decay=0.01)

        vla_losses = []
        vla_ppls = []
        t0 = time.time()

        for epoch in range(1, EPOCHS + 1):
            train_loss = train_epoch(model_vla, train_loader, opt_vla, device)
            val_loss, val_ppl = evaluate(model_vla, val_loader, device)
            vla_losses.append(val_loss)
            vla_ppls.append(val_ppl)
            print(f"  Epoch {epoch}: train_loss={train_loss:.4f}, val_loss={val_loss:.4f}, val_ppl={val_ppl:.2f}")

        vla_time = time.time() - t0
        results["vla"] = {"losses": vla_losses, "ppls": vla_ppls, "time": vla_time}

    # ========== Summary ==========
    print("\n" + "="*60)
    print("RESULTS SUMMARY")
    print("="*60)

    print(f"\nAdamW:")
    print(f"  Final PPL: {results['adamw']['ppls'][-1]:.2f}")
    print(f"  Time: {results['adamw']['time']:.1f}s")

    if HAS_VLA:
        print(f"\nVLA AdamW:")
        print(f"  Final PPL: {results['vla']['ppls'][-1]:.2f}")
        print(f"  Time: {results['vla']['time']:.1f}s")

        ppl_diff = results['adamw']['ppls'][-1] - results['vla']['ppls'][-1]
        if ppl_diff > 0:
            print(f"\n✓ VLA AdamW is BETTER by {ppl_diff:.2f} PPL")
        elif ppl_diff < 0:
            print(f"\n✗ AdamW is better by {-ppl_diff:.2f} PPL")
        else:
            print(f"\n= Same performance")

        speedup = results['adamw']['time'] / results['vla']['time']
        print(f"  Speed ratio: {speedup:.2f}x")

if __name__ == "__main__":
    main()
