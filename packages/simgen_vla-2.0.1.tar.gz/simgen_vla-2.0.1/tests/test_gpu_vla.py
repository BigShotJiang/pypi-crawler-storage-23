"""
ALL-GPU VLA EXACT ARITHMETIC TEST
100% on GPU, no CPU in hot path
"""
import torch
import triton
import triton.language as tl

# ============================================
# ALL-GPU VLA EXACT REDUCTION
# ============================================

@triton.jit
def _vla_sum_exact_kernel(
    x_ptr, out_ptr,
    n: int,
    BLOCK: tl.constexpr,
):
    """ALL-GPU exact sum using 4-limb TwoSum cascade."""
    pid = tl.program_id(0)

    # 4 limbs in registers (FP64 for precision)
    limb0 = tl.zeros((), dtype=tl.float64)
    limb1 = tl.zeros((), dtype=tl.float64)
    limb2 = tl.zeros((), dtype=tl.float64)
    limb3 = tl.zeros((), dtype=tl.float64)

    # Process elements in this block
    base = pid * BLOCK
    for offset in range(BLOCK):
        idx = base + offset
        if idx < n:
            val = tl.load(x_ptr + idx).to(tl.float64)

            # TwoSum cascade through limbs
            # limb0 + val
            s0 = limb0 + val
            a0 = s0 - val
            e0 = (limb0 - a0) + (val - (s0 - a0))
            limb0 = s0

            # limb1 + e0
            s1 = limb1 + e0
            a1 = s1 - e0
            e1 = (limb1 - a1) + (e0 - (s1 - a1))
            limb1 = s1

            # limb2 + e1
            s2 = limb2 + e1
            a2 = s2 - e1
            e2 = (limb2 - a2) + (e1 - (s2 - a2))
            limb2 = s2

            # limb3 + e2 (last limb absorbs remainder)
            limb3 = limb3 + e2

    # Store 4 limbs per block
    tl.store(out_ptr + pid * 4 + 0, limb0)
    tl.store(out_ptr + pid * 4 + 1, limb1)
    tl.store(out_ptr + pid * 4 + 2, limb2)
    tl.store(out_ptr + pid * 4 + 3, limb3)


@triton.jit
def _vla_reduce_limbs_kernel(
    limbs_ptr, out_ptr,
    n_blocks: int,
):
    """Reduce block limbs to final 4 limbs - ALL ON GPU."""
    # Final 4 limbs (FP64)
    limb0 = tl.zeros((), dtype=tl.float64)
    limb1 = tl.zeros((), dtype=tl.float64)
    limb2 = tl.zeros((), dtype=tl.float64)
    limb3 = tl.zeros((), dtype=tl.float64)

    # Merge all block limbs
    for b in range(n_blocks):
        for i in range(4):
            val = tl.load(limbs_ptr + b * 4 + i)

            # TwoSum cascade
            s0 = limb0 + val
            a0 = s0 - val
            e0 = (limb0 - a0) + (val - (s0 - a0))
            limb0 = s0

            s1 = limb1 + e0
            a1 = s1 - e0
            e1 = (limb1 - a1) + (e0 - (s1 - a1))
            limb1 = s1

            s2 = limb2 + e1
            a2 = s2 - e1
            e2 = (limb2 - a2) + (e1 - (s2 - a2))
            limb2 = s2

            limb3 = limb3 + e2

    # Store final result
    tl.store(out_ptr + 0, limb0)
    tl.store(out_ptr + 1, limb1)
    tl.store(out_ptr + 2, limb2)
    tl.store(out_ptr + 3, limb3)


def vla_sum_gpu_exact(x):
    """100% GPU exact sum - no CPU in hot path."""
    n = x.numel()
    BLOCK = 256
    n_blocks = triton.cdiv(n, BLOCK)

    # Per-block limbs (4 per block)
    block_limbs = torch.zeros(n_blocks * 4, device=x.device, dtype=torch.float64)

    # Phase 1: Per-block exact sum
    _vla_sum_exact_kernel[(n_blocks,)](x.flatten(), block_limbs, n, BLOCK=BLOCK)

    # Phase 2: Reduce blocks to final limbs (ALL GPU)
    final_limbs = torch.zeros(4, device=x.device, dtype=torch.float64)
    _vla_reduce_limbs_kernel[(1,)](block_limbs, final_limbs, n_blocks)

    # Return sum of limbs (this addition is on GPU too)
    return final_limbs.sum()


if __name__ == "__main__":
    print('ALL-GPU VLA EXACT SUM TEST')
    print('='*60)

    # Test 1: Catastrophic cancellation
    x = torch.tensor([1e16, 1.0, -1e16], device='cuda', dtype=torch.float32)
    result = vla_sum_gpu_exact(x)
    print(f'Test 1: 1e16 + 1 - 1e16')
    print(f'  GPU VLA: {result.item()}')
    print(f'  EXACT:   {result.item() == 1.0}')

    # Test 2: Many values
    torch.manual_seed(42)
    x = torch.randn(100000, device='cuda', dtype=torch.float32)
    gpu_result = vla_sum_gpu_exact(x).item()
    fp64_result = x.double().sum().item()
    print(f'\nTest 2: 100K random values')
    print(f'  GPU VLA: {gpu_result}')
    print(f'  FP64:    {fp64_result}')
    print(f'  Match:   {gpu_result == fp64_result}')

    # Test 3: Verify against CPU VLA
    from simgen.vla import VLAAccumulator
    acc = VLAAccumulator()
    for v in x.cpu().numpy():
        acc.add(float(v))
    cpu_vla = acc.result()
    print(f'\nTest 3: GPU vs CPU VLA')
    print(f'  GPU VLA: {gpu_result}')
    print(f'  CPU VLA: {cpu_vla}')
    print(f'  Match:   {gpu_result == cpu_vla}')

    print('\n' + '='*60)
    if result.item() == 1.0:
        print('SUCCESS: ALL-GPU VLA IS ERROR-FREE!')
    else:
        print('NEEDS WORK')
