"""
Test: If we keep everything in FP64, are gradients truly exact?
"""
import torch
import sys
sys.path.insert(0, 'C:/SimGen')

device = 'cuda'
print(f"Device: {torch.cuda.get_device_name()}")

from simgen import vla

print("\n" + "="*60)
print("VLA with FP64 Throughout - Zero Error Gradients?")
print("="*60)

torch.manual_seed(42)

# Create FP64 tensors directly
A = torch.randn(64, 64, device=device, dtype=torch.float64, requires_grad=True)
B = torch.randn(64, 64, device=device, dtype=torch.float64, requires_grad=True)

# Ground truth: direct FP64 (what we compare against)
A_gt = A.detach().clone().requires_grad_(True)
B_gt = B.detach().clone().requires_grad_(True)
C_gt = torch.matmul(A_gt, B_gt)
loss_gt = C_gt.sum()
loss_gt.backward()
grad_A_gt = A_gt.grad.clone()
grad_B_gt = B_gt.grad.clone()

# VLA with FP64 input -> should be exact
A_vla = A.detach().clone().requires_grad_(True)
B_vla = B.detach().clone().requires_grad_(True)
C_vla = vla.matmul(A_vla, B_vla)  # VLA matmul

# Manual backward with VLA
# grad_A = grad_output @ B.T
# grad_B = A.T @ grad_output
grad_output = torch.ones_like(C_vla)  # d(sum)/dC = 1
grad_A_vla = vla.matmul(grad_output, B_vla.t())
grad_B_vla = vla.matmul(A_vla.t(), grad_output)

vla_err_A = (grad_A_vla - grad_A_gt).abs().max().item()
vla_err_B = (grad_B_vla - grad_B_gt).abs().max().item()

print(f"\nGround truth (torch.matmul FP64):")
print(f"  grad_A: computed")
print(f"  grad_B: computed")

print(f"\nVLA gradients (manual backward with vla.matmul):")
print(f"  grad_A error: {vla_err_A:.2e}")
print(f"  grad_B error: {vla_err_B:.2e}")

if vla_err_A == 0 and vla_err_B == 0:
    print("\n" + "="*60)
    print("✓ TRULY ZERO ERROR GRADIENTS!")
    print("="*60)
    print("\nVLA computes gradients with ZERO numerical error when:")
    print("  1. Input is FP64 (or kept in FP64 throughout)")
    print("  2. No conversion back to FP32")
    print("\nFor training, use FP64 tensors or accept ~6x improvement with FP32")
else:
    print(f"\nStill has error: {max(vla_err_A, vla_err_B):.2e}")
