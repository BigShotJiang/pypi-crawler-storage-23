"""
VLA vs Standard Training - PPL Comparison
==========================================
Tests whether VLA exact arithmetic improves training convergence.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import time
import math

# Check CUDA
assert torch.cuda.is_available(), "CUDA required"
device = torch.device('cuda')

# Import VLA
from simgen import vla

print(f"VLA version: {vla.__version__}")
print(f"Device: {torch.cuda.get_device_name()}")
print()

# =============================================================================
# SIMPLE GPT MODEL (for testing)
# =============================================================================

class SimpleGPT(nn.Module):
    """Minimal GPT for testing VLA vs standard training."""

    def __init__(self, vocab_size=1000, dim=256, n_heads=4, n_layers=2, seq_len=64):
        super().__init__()
        self.embed = nn.Embedding(vocab_size, dim)
        self.pos_embed = nn.Embedding(seq_len, dim)

        self.layers = nn.ModuleList([
            nn.TransformerEncoderLayer(
                d_model=dim, nhead=n_heads, dim_feedforward=dim*4,
                dropout=0.0, batch_first=True
            ) for _ in range(n_layers)
        ])

        self.ln = nn.LayerNorm(dim)
        self.head = nn.Linear(dim, vocab_size, bias=False)
        self.seq_len = seq_len

    def forward(self, x):
        B, T = x.shape
        pos = torch.arange(T, device=x.device)
        x = self.embed(x) + self.pos_embed(pos)

        for layer in self.layers:
            x = layer(x)

        x = self.ln(x)
        return self.head(x)


class SimpleGPT_VLA(nn.Module):
    """GPT with VLA exact arithmetic in forward pass."""

    def __init__(self, vocab_size=1000, dim=256, n_heads=4, n_layers=2, seq_len=64):
        super().__init__()
        self.embed = nn.Embedding(vocab_size, dim)
        self.pos_embed = nn.Embedding(seq_len, dim)

        # Use VLA linear layers
        self.layers = nn.ModuleList()
        for _ in range(n_layers):
            self.layers.append(nn.ModuleDict({
                'attn_qkv': nn.Linear(dim, dim * 3),
                'attn_proj': nn.Linear(dim, dim),
                'ffn1': nn.Linear(dim, dim * 4),
                'ffn2': nn.Linear(dim * 4, dim),
                'ln1': nn.LayerNorm(dim),
                'ln2': nn.LayerNorm(dim),
            }))

        self.ln = nn.LayerNorm(dim)
        self.head = nn.Linear(dim, vocab_size, bias=False)
        self.seq_len = seq_len
        self.dim = dim
        self.n_heads = n_heads
        self.head_dim = dim // n_heads

    def forward(self, x):
        B, T = x.shape
        pos = torch.arange(T, device=x.device)
        x = self.embed(x) + self.pos_embed(pos)

        for layer in self.layers:
            # Self-attention with VLA
            residual = x
            x = layer['ln1'](x)

            # QKV projection using VLA linear
            qkv = vla.linear(x, layer['attn_qkv'].weight, layer['attn_qkv'].bias)
            qkv = qkv.float()  # Back to float32 for reshape
            q, k, v = qkv.chunk(3, dim=-1)

            # Reshape for multi-head
            q = q.view(B, T, self.n_heads, self.head_dim).transpose(1, 2)
            k = k.view(B, T, self.n_heads, self.head_dim).transpose(1, 2)
            v = v.view(B, T, self.n_heads, self.head_dim).transpose(1, 2)

            # Attention with VLA matmul
            scale = 1.0 / math.sqrt(self.head_dim)
            scores = vla.matmul(q, k.transpose(-2, -1)).float() * scale
            attn = vla.softmax(scores, dim=-1).float()
            out = vla.matmul(attn, v).float()

            out = out.transpose(1, 2).contiguous().view(B, T, self.dim)
            out = vla.linear(out, layer['attn_proj'].weight, layer['attn_proj'].bias).float()
            x = residual + out

            # FFN with VLA
            residual = x
            x = layer['ln2'](x)
            x = vla.linear(x, layer['ffn1'].weight, layer['ffn1'].bias).float()
            x = F.gelu(x)
            x = vla.linear(x, layer['ffn2'].weight, layer['ffn2'].bias).float()
            x = residual + x

        x = self.ln(x)
        logits = vla.linear(x, self.head.weight, None).float()
        return logits


def train_model(model, name, n_steps=100, batch_size=4, seq_len=64, vocab_size=1000, lr=1e-3):
    """Train model and return final loss/PPL."""
    model = model.to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr)

    losses = []
    start = time.time()

    for step in range(n_steps):
        # Random data (simulates text)
        x = torch.randint(0, vocab_size, (batch_size, seq_len), device=device)
        targets = torch.randint(0, vocab_size, (batch_size, seq_len), device=device)

        optimizer.zero_grad()

        logits = model(x)
        loss = F.cross_entropy(logits.view(-1, vocab_size), targets.view(-1))

        loss.backward()
        optimizer.step()

        losses.append(loss.item())

        if (step + 1) % 20 == 0:
            avg_loss = sum(losses[-20:]) / 20
            ppl = math.exp(avg_loss)
            print(f"  [{name}] Step {step+1}: Loss={avg_loss:.4f}, PPL={ppl:.2f}")

    elapsed = time.time() - start
    final_loss = sum(losses[-10:]) / 10
    final_ppl = math.exp(final_loss)

    return final_loss, final_ppl, elapsed


def train_model_vla_loss(model, name, n_steps=100, batch_size=4, seq_len=64, vocab_size=1000, lr=1e-3):
    """Train model using VLA cross_entropy for loss computation."""
    model = model.to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr)

    losses = []
    start = time.time()

    for step in range(n_steps):
        x = torch.randint(0, vocab_size, (batch_size, seq_len), device=device)
        targets = torch.randint(0, vocab_size, (batch_size, seq_len), device=device)

        optimizer.zero_grad()

        logits = model(x)

        # Use VLA cross entropy with autograd
        loss = vla.VLACrossEntropyFunction.apply(
            logits.view(-1, vocab_size),
            targets.view(-1),
            'mean'
        )

        loss.backward()
        optimizer.step()

        losses.append(loss.item())

        if (step + 1) % 20 == 0:
            avg_loss = sum(losses[-20:]) / 20
            ppl = math.exp(avg_loss)
            print(f"  [{name}] Step {step+1}: Loss={avg_loss:.4f}, PPL={ppl:.2f}")

    elapsed = time.time() - start
    final_loss = sum(losses[-10:]) / 10
    final_ppl = math.exp(final_loss)

    return final_loss, final_ppl, elapsed


# =============================================================================
# RUN TESTS
# =============================================================================

print("="*60)
print("TEST 1: Standard PyTorch vs VLA Cross-Entropy Loss")
print("="*60)

# Same seed for fair comparison
torch.manual_seed(42)
torch.cuda.manual_seed(42)

model_std = SimpleGPT(vocab_size=1000, dim=256, n_heads=4, n_layers=2)
loss_std, ppl_std, time_std = train_model(model_std, "Standard", n_steps=100)

torch.manual_seed(42)
torch.cuda.manual_seed(42)

model_vla = SimpleGPT(vocab_size=1000, dim=256, n_heads=4, n_layers=2)
# Copy weights to ensure same starting point
model_vla.load_state_dict(model_std.state_dict().copy())
loss_vla, ppl_vla, time_vla = train_model_vla_loss(model_vla, "VLA Loss", n_steps=100)

print()
print("RESULTS (VLA Loss only):")
print(f"  Standard:  Loss={loss_std:.4f}, PPL={ppl_std:.2f}, Time={time_std:.1f}s")
print(f"  VLA Loss:  Loss={loss_vla:.4f}, PPL={ppl_vla:.2f}, Time={time_vla:.1f}s")
print(f"  Improvement: {(ppl_std - ppl_vla) / ppl_std * 100:.1f}% better PPL")

print()
print("="*60)
print("TEST 2: VLA in Full Forward Pass (matmul + softmax + linear)")
print("="*60)

torch.manual_seed(42)
torch.cuda.manual_seed(42)

# Fresh standard model
model_std2 = SimpleGPT(vocab_size=1000, dim=256, n_heads=4, n_layers=2)
loss_std2, ppl_std2, time_std2 = train_model(model_std2, "Standard", n_steps=100)

torch.manual_seed(42)
torch.cuda.manual_seed(42)

# VLA model with VLA ops in forward pass
model_vla2 = SimpleGPT_VLA(vocab_size=1000, dim=256, n_heads=4, n_layers=2)
# Copy compatible weights
state = model_std2.state_dict()
vla_state = {}
for k, v in state.items():
    if k.startswith('layers.'):
        # Remap transformer encoder layer weights
        parts = k.split('.')
        idx = parts[1]
        rest = '.'.join(parts[2:])

        if 'self_attn.in_proj_weight' in k:
            vla_state[f'layers.{idx}.attn_qkv.weight'] = v
        elif 'self_attn.in_proj_bias' in k:
            vla_state[f'layers.{idx}.attn_qkv.bias'] = v
        elif 'self_attn.out_proj.weight' in k:
            vla_state[f'layers.{idx}.attn_proj.weight'] = v
        elif 'self_attn.out_proj.bias' in k:
            vla_state[f'layers.{idx}.attn_proj.bias'] = v
        elif 'linear1.weight' in k:
            vla_state[f'layers.{idx}.ffn1.weight'] = v
        elif 'linear1.bias' in k:
            vla_state[f'layers.{idx}.ffn1.bias'] = v
        elif 'linear2.weight' in k:
            vla_state[f'layers.{idx}.ffn2.weight'] = v
        elif 'linear2.bias' in k:
            vla_state[f'layers.{idx}.ffn2.bias'] = v
        elif 'norm1.weight' in k:
            vla_state[f'layers.{idx}.ln1.weight'] = v
        elif 'norm1.bias' in k:
            vla_state[f'layers.{idx}.ln1.bias'] = v
        elif 'norm2.weight' in k:
            vla_state[f'layers.{idx}.ln2.weight'] = v
        elif 'norm2.bias' in k:
            vla_state[f'layers.{idx}.ln2.bias'] = v
    else:
        vla_state[k] = v

model_vla2.load_state_dict(vla_state, strict=False)
loss_vla2, ppl_vla2, time_vla2 = train_model_vla_loss(model_vla2, "Full VLA", n_steps=100)

print()
print("RESULTS (Full VLA Forward):")
print(f"  Standard:   Loss={loss_std2:.4f}, PPL={ppl_std2:.2f}, Time={time_std2:.1f}s")
print(f"  Full VLA:   Loss={loss_vla2:.4f}, PPL={ppl_vla2:.2f}, Time={time_vla2:.1f}s")
print(f"  Improvement: {(ppl_std2 - ppl_vla2) / ppl_std2 * 100:.1f}% better PPL")

print()
print("="*60)
print("SUMMARY")
print("="*60)
print(f"VLA Loss only:    {(ppl_std - ppl_vla) / ppl_std * 100:+.1f}% PPL improvement")
print(f"Full VLA Forward: {(ppl_std2 - ppl_vla2) / ppl_std2 * 100:+.1f}% PPL improvement")
