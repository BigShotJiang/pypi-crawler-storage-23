"""Debug 2-limb multi-block reduction."""
import torch
import triton
import triton.language as tl
import sys
sys.path.insert(0, '/mnt/c/SimGen')

# Clear Triton cache
import shutil
import os
cache_dir = os.path.expanduser("~/.triton/cache")
if os.path.exists(cache_dir):
    shutil.rmtree(cache_dir)
    print("Cleared Triton cache")

# Re-import to get fresh kernels
from simgen import vla
from simgen.vla import sum as vla_sum

# Test data
x = torch.tensor([1e16] + [1.0] * 10000 + [-1e16], dtype=torch.float32, device='cuda')
print(f"Input: [1e16] + [1.0]*10000 + [-1e16]")
print(f"Total elements: {len(x)}")
print(f"Expected sum: 10000.0")

# Run VLA sum
result = vla_sum(x)
print(f"VLA result: {result.item()}")
print(f"Difference: {10000.0 - result.item()}")

# Let's also manually check the block computation
BLOCK = 256
n = len(x)
n_blocks = (n + BLOCK - 1) // BLOCK
print(f"\nBlock analysis:")
print(f"  BLOCK size: {BLOCK}")
print(f"  n_blocks: {n_blocks}")

# Count ones in each range
for b in range(min(3, n_blocks)):
    start = b * BLOCK
    end = min(start + BLOCK, n)
    ones_count = sum(1 for i in range(start, end) if x[i].item() == 1.0)
    print(f"  Block {b}: indices {start}-{end-1}, ones_count={ones_count}")

print(f"  ...")
for b in range(max(0, n_blocks-2), n_blocks):
    start = b * BLOCK
    end = min(start + BLOCK, n)
    ones_count = sum(1 for i in range(start, end) if x[i].item() == 1.0)
    print(f"  Block {b}: indices {start}-{end-1}, ones_count={ones_count}")

# Manual sum for comparison
manual_sum = sum(x.tolist())
print(f"\nManual Python sum: {manual_sum}")

# NumPy sum
import numpy as np
np_sum = np.sum(x.cpu().numpy())
print(f"NumPy sum: {np_sum}")

# Double precision Python
hi = 0.0
lo = 0.0
for v in x.tolist():
    new_hi = hi + v
    lo = lo + (v - (new_hi - hi))
    hi = new_hi
print(f"Python 2-limb: {hi + lo}")
