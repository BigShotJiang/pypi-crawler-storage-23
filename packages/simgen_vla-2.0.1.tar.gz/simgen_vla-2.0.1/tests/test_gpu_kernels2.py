"""
VLA GPU Kernels Test - Part 2 (more operations)
"""
import torch
import sys
sys.path.insert(0, 'C:/SimGen')

device = 'cuda'
print(f"Device: {torch.cuda.get_device_name()}")

from simgen import vla

def test_kernel(name, vla_fn, torch_fn, inputs, description):
    """Test a kernel and report accuracy."""
    print(f"\n{'='*60}")
    print(f"KERNEL: {name}")
    print(f"USE: {description}")
    print(f"{'='*60}")

    try:
        # Ground truth (FP64)
        inputs_fp64 = tuple(x.double() if isinstance(x, torch.Tensor) else x for x in inputs)
        gt = torch_fn(*inputs_fp64)

        # Standard FP32
        inputs_fp32 = tuple(x.float() if isinstance(x, torch.Tensor) else x for x in inputs)
        std_result = torch_fn(*inputs_fp32)

        # VLA
        vla_result = vla_fn(*inputs_fp32)

        # Compute errors
        if gt.numel() == 1:
            gt_val = gt.item()
            std_err = abs(std_result.item() - gt_val)
            vla_err = abs(vla_result.item() - gt_val)
        else:
            std_err = (std_result.double() - gt).abs().max().item()
            vla_err = (vla_result.double() - gt).abs().max().item()

        print(f"  Standard FP32 error: {std_err:.2e}")
        print(f"  VLA error:           {vla_err:.2e}")

        if std_err > 0 and vla_err > 0:
            print(f"  VLA improvement:     {std_err/vla_err:.0f}x more accurate")
        elif vla_err == 0:
            print(f"  VLA improvement:     EXACT (zero error)")

        status = "PASS" if vla_err <= std_err else "FAIL"
        print(f"  Result: {status}")
        return status == "PASS"
    except Exception as e:
        print(f"  ERROR: {e}")
        return False

results = {}

# =============================================================================
# ARITHMETIC OPERATIONS
# =============================================================================

print("\n" + "#"*60)
print("# ARITHMETIC OPERATIONS")
print("#"*60)

x = torch.randn(100_000, device=device)
y = torch.randn(100_000, device=device)
x_pos = torch.rand(100_000, device=device) + 0.1

# Division
results['div'] = test_kernel(
    "vla.div", vla.div, torch.div, (x, y + 0.1,),  # Avoid div by zero
    "Division (ratios, normalization)"
)

# Reciprocal
results['reciprocal'] = test_kernel(
    "vla.reciprocal", vla.reciprocal, torch.reciprocal, (x_pos,),
    "Reciprocal 1/x (inverse, normalization)"
)

# Power
results['pow'] = test_kernel(
    "vla.pow", lambda x, p: vla.pow(x, p), lambda x, p: torch.pow(x, p), (x_pos, 2.5),
    "Power x^n (physics, scaling laws)"
)

# Absolute value
results['abs'] = test_kernel(
    "vla.abs", vla.vla_abs, torch.abs, (x,),
    "Absolute value (magnitudes, errors)"
)

# =============================================================================
# MORE TRANSCENDENTALS
# =============================================================================

print("\n" + "#"*60)
print("# MORE TRANSCENDENTALS")
print("#"*60)

# rsqrt (inverse square root)
results['rsqrt'] = test_kernel(
    "vla.rsqrt", vla.rsqrt, torch.rsqrt, (x_pos,),
    "Inverse sqrt 1/sqrt(x) (normalization, physics)"
)

# sinh
results['sinh'] = test_kernel(
    "vla.sinh", vla.sinh, torch.sinh, (x * 0.5,),  # Scale to avoid overflow
    "Hyperbolic sine (catenary, special functions)"
)

# cosh
results['cosh'] = test_kernel(
    "vla.cosh", vla.cosh, torch.cosh, (x * 0.5,),
    "Hyperbolic cosine (catenary, special functions)"
)

# sigmoid
results['sigmoid'] = test_kernel(
    "vla.sigmoid", vla.sigmoid, torch.sigmoid, (x,),
    "Sigmoid 1/(1+e^-x) (probability, logistics)"
)

# =============================================================================
# CUMULATIVE OPERATIONS
# =============================================================================

print("\n" + "#"*60)
print("# CUMULATIVE OPERATIONS")
print("#"*60)

x_small = torch.randn(10000, device=device)

# Cumulative sum
results['cumsum'] = test_kernel(
    "vla.cumsum", lambda x: vla.cumsum(x, dim=0), lambda x: torch.cumsum(x, dim=0), (x_small,),
    "Cumulative sum (running totals, integration)"
)

# Cumulative product
x_near_one = torch.rand(1000, device=device) * 0.1 + 0.95  # Near 1 to avoid explosion
results['cumprod'] = test_kernel(
    "vla.cumprod", lambda x: vla.cumprod(x, dim=0), lambda x: torch.cumprod(x, dim=0), (x_near_one,),
    "Cumulative product (compound growth, probability chains)"
)

# Product
results['prod'] = test_kernel(
    "vla.prod", vla.prod, torch.prod, (x_near_one,),
    "Product of all elements (determinants, probability)"
)

# =============================================================================
# SPECIAL FUNCTIONS
# =============================================================================

print("\n" + "#"*60)
print("# SPECIAL FUNCTIONS")
print("#"*60)

# Clamp
results['clamp'] = test_kernel(
    "vla.clamp", lambda x: vla.clamp(x, -0.5, 0.5), lambda x: torch.clamp(x, -0.5, 0.5), (x,),
    "Clamp to range (saturation, bounds checking)"
)

# =============================================================================
# SUMMARY
# =============================================================================

print("\n" + "="*60)
print("SUMMARY - GPU COMPUTE KERNELS (Part 2)")
print("="*60)

passed = sum(1 for v in results.values() if v)
total = len(results)

for name, result in results.items():
    status = "PASS" if result else "FAIL"
    print(f"  {name}: {status}")

print(f"\n  Total: {passed}/{total} passed")
