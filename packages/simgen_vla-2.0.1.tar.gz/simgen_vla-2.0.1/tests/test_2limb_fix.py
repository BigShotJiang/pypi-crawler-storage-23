"""Test 2-limb fix for multi-block reduction."""
import torch
import sys
sys.path.insert(0, '/mnt/c/SimGen')
from simgen.vla import sum as vla_sum

# Test 1: Multi-block sum that was failing
print("Test 1: Multi-block cancellation")
x = torch.tensor([1e16] + [1.0] * 10000 + [-1e16], dtype=torch.float32, device='cuda')
result = vla_sum(x)
print(f"  Result: {result.item()}")
print(f"  Expected: 10000.0")
print(f"  Status: {'PASS' if abs(result.item() - 10000.0) < 1e-6 else 'FAIL'}")

# Test 2: Single block (should still work)
print("\nTest 2: Single block cancellation")
x2 = torch.tensor([1e16] + [1.0] * 100 + [-1e16], dtype=torch.float32, device='cuda')
result2 = vla_sum(x2)
print(f"  Result: {result2.item()}")
print(f"  Expected: 100.0")
print(f"  Status: {'PASS' if abs(result2.item() - 100.0) < 1e-6 else 'FAIL'}")

# Test 3: Many small values
print("\nTest 3: Sum of 0.1 x 10000 (naive FP64 gets wrong)")
x3 = torch.tensor([0.1] * 10000, dtype=torch.float32, device='cuda')
result3 = vla_sum(x3)
print(f"  VLA result: {result3.item()}")
print(f"  Naive sum: {sum([0.1] * 10000)}")
print(f"  Expected: 1000.0")
print(f"  VLA error: {abs(result3.item() - 1000.0)}")

# Test 4: Extreme cancellation
print("\nTest 4: Extreme cancellation")
x4 = torch.tensor([1e15, -1e15, 1e14, -1e14, 1.0], dtype=torch.float32, device='cuda')
result4 = vla_sum(x4)
print(f"  Result: {result4.item()}")
print(f"  Expected: 1.0")
print(f"  Status: {'PASS' if abs(result4.item() - 1.0) < 1e-6 else 'FAIL'}")

print("\n" + "="*50)
print("2-limb optimization test complete")
