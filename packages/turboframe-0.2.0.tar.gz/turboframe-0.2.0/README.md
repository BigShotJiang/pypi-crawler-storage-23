# TurboFrame

A fast, parallel DataFrame library built on PyArrow. Optimized for Delta Lake reads and parallel GroupBy on Microsoft Fabric notebooks.

## Install

```bash
# Core (parquet, csv, json)
pip install turboframe

# With Delta Lake support
pip install turboframe[delta]

# Everything
pip install turboframe[all]
```

## Quick Start

```python
from turboframe import TurboFrame

# From ANY source
tf = TurboFrame({"region": ["E","W","E"], "sales": [100,200,150]})
tf = TurboFrame(my_pandas_df)
tf = TurboFrame(my_spark_df)
tf = TurboFrame.read_csv("data.csv")
tf = TurboFrame.read_delta("/lakehouse/default/Tables/sales")
tf = TurboFrame.read_parquet("data.parquet")
tf = TurboFrame.read_excel("report.xlsx")
tf = TurboFrame.read_sql("SELECT * FROM sales", connection)

# Filter + GroupBy + Sort
result = (
    tf.filter("sales > 100")
      .groupby("region")
      .agg({"sales": "sum"})
      .sort("sales_sum", ascending=False)
)
result.show()
```

## Supported Aggregations

sum, mean, min, max, count, std, var, median, nunique

## License

MIT
