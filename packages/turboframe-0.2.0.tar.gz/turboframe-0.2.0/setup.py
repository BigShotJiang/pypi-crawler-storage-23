from setuptools import setup, find_packages

setup(
    name="turboframe",
    version="0.2.0",
    description="Fast parallel DataFrame library built on PyArrow, optimized for Delta Lake on Fabric",
    packages=find_packages(),
    python_requires=">=3.9",
    install_requires=[
        "pyarrow>=12.0.0",
        "numpy>=1.24.0",
    ],
    extras_require={
        "delta": ["deltalake>=0.15.0"],
        "polars": ["polars>=0.20.0"],
        "full": ["deltalake>=0.15.0", "polars>=0.20.0", "pandas>=2.0.0"],
    },
)
