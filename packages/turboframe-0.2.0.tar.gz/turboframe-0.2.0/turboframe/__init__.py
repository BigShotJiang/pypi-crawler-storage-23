"""
TurboFrame - A fast parallel DataFrame library built on PyArrow.
"""

try:
    from turboframe.core import TurboFrame
    from turboframe.parallel import ParallelEngine
except ImportError:
    from .core import TurboFrame
    from .parallel import ParallelEngine

__version__ = "0.2.0"
__all__ = ["TurboFrame", "ParallelEngine"]
