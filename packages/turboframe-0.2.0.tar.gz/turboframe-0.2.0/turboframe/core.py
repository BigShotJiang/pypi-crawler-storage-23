"""
TurboFrame Core - The main DataFrame class.
Wraps PyArrow Table with a fluent API and parallel execution.
"""

import time
import warnings
from typing import List, Dict, Optional, Union, Callable, Any

import pyarrow as pa
import pyarrow.compute as pc
import pyarrow.parquet as pq

try:
    from turboframe.parallel import ParallelEngine
except ImportError:
    from .parallel import ParallelEngine


class GroupByResult:
    """Holds groupby state until .agg() is called."""

    def __init__(self, frame: "TurboFrame", key_columns: List[str]):
        self._frame = frame
        self._key_columns = key_columns

    def agg(self, agg_specs: Dict[str, str]) -> "TurboFrame":
        """
        Execute parallel aggregation.

        Args:
            agg_specs: {"column": "sum|mean|min|max|count|std|var|median|nunique"}

        Returns:
            TurboFrame with aggregated results.

        Example:
            tf.groupby("region").agg({"sales": "sum", "quantity": "mean"})
        """
        engine = self._frame._engine
        result_table = engine.parallel_groupby(
            self._frame._table, self._key_columns, agg_specs
        )
        return TurboFrame._from_table(result_table, engine=engine)

    def count(self) -> "TurboFrame":
        """Shorthand: count rows per group."""
        first_non_key = [
            c for c in self._frame.columns if c not in self._key_columns
        ]
        col = first_non_key[0] if first_non_key else self._key_columns[0]
        return self.agg({col: "count"})

    def sum(self, columns: Optional[List[str]] = None) -> "TurboFrame":
        """Shorthand: sum specified columns per group."""
        cols = columns or [
            c for c in self._frame.columns if c not in self._key_columns
        ]
        return self.agg({c: "sum" for c in cols})


class TurboFrame:
    """
    A fast, parallel DataFrame built on PyArrow.

    Key design principles:
    - Zero-copy where possible (Arrow columnar format)
    - Parallel groupby via hash partitioning
    - Lazy-ish: filters push down, reads are optimized
    - Compatible: easy conversion to/from pandas, Spark, Polars
    """

    def __init__(
        self,
        data: Union[pa.Table, dict, "pd.DataFrame", None] = None,
        engine: Optional[ParallelEngine] = None,
        max_workers: Optional[int] = None,
    ):
        self._engine = engine or ParallelEngine(max_workers=max_workers)

        if data is None:
            self._table = pa.table({})
        elif isinstance(data, pa.Table):
            self._table = data
        elif isinstance(data, dict):
            self._table = pa.table(data)
        else:
            # Assume pandas DataFrame
            self._table = pa.Table.from_pandas(data)

    @classmethod
    def _from_table(
        cls, table: pa.Table, engine: Optional[ParallelEngine] = None
    ) -> "TurboFrame":
        """Internal: create TurboFrame from existing Arrow table."""
        tf = cls.__new__(cls)
        tf._table = table
        tf._engine = engine or ParallelEngine()
        return tf

    # ══════════════════════════════════════════════════════════════════
    # DATA READERS
    # ══════════════════════════════════════════════════════════════════

    @classmethod
    def read_delta(
        cls,
        path: str,
        columns: Optional[List[str]] = None,
        filters: Optional[List] = None,
        row_limit: Optional[int] = None,
        version: Optional[int] = None,
        storage_options: Optional[Dict[str, str]] = None,
        max_workers: Optional[int] = None,
    ) -> "TurboFrame":
        """
        Read a Delta table into TurboFrame. Uses deltalake (Rust-based) for speed.

        FAST PATH: Delta (Parquet) -> Arrow (zero-copy) -> TurboFrame

        Args:
            path: Local path or cloud path (abfss://, s3://, gs://)
            columns: Only read these columns (column pruning = huge speedup)
            filters: Predicate pushdown filters. Skips entire Parquet row groups
                that don't match, so the data never even gets loaded into memory.
                Format: list of tuples (column, operator, value)
                Operators: "=", "!=", ">", ">=", "<", "<=", "in", "not in"

                Examples:
                    filters=[("amount", ">", 1000)]
                    filters=[("region", "=", "East")]
                    filters=[("status", "in", ["active", "pending"])]
                    filters=[("amount", ">", 1000), ("region", "=", "East")]

                You can also use nested lists for OR conditions:
                    filters=[
                        [("region", "=", "East"), ("amount", ">", 500)],   # AND
                        [("region", "=", "West"), ("amount", ">", 1000)],  # OR with above
                    ]

            row_limit: Maximum number of rows to read. Use this to prevent
                out-of-memory errors on huge tables. Reads only the first N rows
                after applying filters.
                Example: row_limit=1_000_000 reads max 1M rows.

            version: Read a specific Delta version (time travel)
            storage_options: Cloud credentials dict.
                For Fabric/ABFSS: usually auto-detected from notebook context.
            max_workers: Override CPU core count for parallelism.

        Example:
            # Read everything
            tf = TurboFrame.read_delta("/Tables/sales")

            # Column pruning only
            tf = TurboFrame.read_delta("/Tables/sales", columns=["region", "amount"])

            # Filter at read time (fastest - skips row groups)
            tf = TurboFrame.read_delta(
                "/Tables/sales",
                columns=["region", "amount", "status"],
                filters=[("amount", ">", 1000), ("status", "=", "active")]
            )

            # OR conditions
            tf = TurboFrame.read_delta(
                "/Tables/sales",
                filters=[
                    [("region", "=", "East"), ("amount", ">", 500)],
                    [("region", "=", "West"), ("amount", ">", 1000)],
                ]
            )

            # Limit rows (prevent OOM on huge tables)
            tf = TurboFrame.read_delta(
                "/Tables/sales",
                columns=["region", "amount"],
                filters=[("amount", ">", 1000)],
                row_limit=500_000
            )

            # Time travel
            tf = TurboFrame.read_delta("/Tables/sales", version=5)
        """
        try:
            from deltalake import DeltaTable
        except ImportError:
            raise ImportError(
                "Install deltalake: pip install deltalake\n"
                "On Fabric notebooks: %pip install deltalake"
            )

        t0 = time.perf_counter()

        # Build DeltaTable handle
        dt_kwargs = {}
        if storage_options:
            dt_kwargs["storage_options"] = storage_options
        if version is not None:
            dt_kwargs["version"] = version

        dt = DeltaTable(path, **dt_kwargs)

        # Build read kwargs with predicate pushdown
        read_kwargs = {}
        if columns:
            read_kwargs["columns"] = columns
        if filters:
            # Convert simple tuple list to pyarrow dataset filter format
            # deltalake's to_pyarrow_dataset() supports DNF (disjunctive normal form)
            read_kwargs["filters"] = filters

        # FAST PATH: Use pyarrow dataset with predicate pushdown
        # This pushes filters down to the Parquet reader so entire row groups
        # that don't match the predicate are SKIPPED (never read from disk/cloud)
        if filters:
            ds = dt.to_pyarrow_dataset()
            arrow_table = ds.to_table(
                columns=columns,
                filter=cls._build_arrow_filter(filters)
            )
        else:
            arrow_table = dt.to_pyarrow_table(columns=columns)

        # Apply row limit to prevent OOM on huge tables
        if row_limit and len(arrow_table) > row_limit:
            arrow_table = arrow_table.slice(0, row_limit)

        elapsed = time.perf_counter() - t0
        rows = len(arrow_table)
        cols = len(arrow_table.schema)
        parts = []
        if filters:
            parts.append(f"{len(filters) if isinstance(filters, list) else 0} filter(s)")
        if row_limit:
            parts.append(f"limit={row_limit:,}")
        extra = f" ({', '.join(parts)})" if parts else ""
        print(f"[TurboFrame] Read {rows:,} rows x {cols} cols in {elapsed:.2f}s from delta{extra}")

        return cls(data=arrow_table, max_workers=max_workers)

    @staticmethod
    def _build_arrow_filter(filters):
        """
        Convert user-friendly filter tuples to PyArrow dataset expressions.

        Supports:
            Simple AND: [("col", ">", 10), ("col2", "=", "x")]
            OR of ANDs: [[("col", ">", 10)], [("col2", "=", "x")]]
        """
        import pyarrow.dataset as ds

        op_map = {
            "=": "__eq__", "==": "__eq__",
            "!=": "__ne__",
            ">": "__gt__",
            ">=": "__ge__",
            "<": "__lt__",
            "<=": "__le__",
        }

        def _make_expr(col, op, val):
            field = ds.field(col)
            if op in ("in", "not in"):
                expr = field.isin(val)
                return ~expr if op == "not in" else expr
            method = op_map.get(op)
            if not method:
                raise ValueError(
                    f"Unknown filter operator: '{op}'. "
                    f"Supported: =, ==, !=, >, >=, <, <=, in, not in"
                )
            return getattr(field, method)(val)

        def _and_group(group):
            exprs = [_make_expr(col, op, val) for col, op, val in group]
            result = exprs[0]
            for e in exprs[1:]:
                result = result & e
            return result

        # Detect format: list of tuples (AND) vs list of lists (OR of ANDs)
        if not filters:
            return None

        if isinstance(filters[0], tuple):
            # Simple AND: [("col", ">", 10), ("col2", "=", "x")]
            return _and_group(filters)
        elif isinstance(filters[0], list):
            # OR of ANDs: [[("col", ">", 10)], [("col2", "=", "x")]]
            or_groups = [_and_group(group) for group in filters]
            result = or_groups[0]
            for g in or_groups[1:]:
                result = result | g
            return result
        else:
            raise ValueError(
                "filters must be list of tuples or list of lists of tuples"
            )

    @classmethod
    def read_delta_batched(
        cls,
        path: str,
        batch_fn,
        columns: Optional[List[str]] = None,
        filters: Optional[List] = None,
        batch_size: int = 100_000,
        version: Optional[int] = None,
        storage_options: Optional[Dict[str, str]] = None,
        max_workers: Optional[int] = None,
    ):
        """
        Read a huge Delta table in batches and process each batch.
        Never loads the full table into memory.

        Args:
            path: Delta table path
            batch_fn: Function that processes each TurboFrame batch.
                Receives a TurboFrame, should return a TurboFrame or None.
            columns: Column pruning
            filters: Predicate pushdown filters
            batch_size: Rows per batch (default 100K)
            version: Delta version
            storage_options: Cloud credentials

        Example:
            # Process 50M row table without OOM
            results = TurboFrame.read_delta_batched(
                "/Tables/huge_table",
                batch_fn=lambda batch: batch.groupby("region").agg({"amount": "sum"}),
                columns=["region", "amount"],
                filters=[("status", "=", "active")],
                batch_size=200_000
            )

            # results is a TurboFrame with all batch results combined
            # Do a final aggregation to merge partial results
            final = results.groupby("region").agg({"amount_sum": "sum"})
        """
        try:
            from deltalake import DeltaTable
        except ImportError:
            raise ImportError("pip install deltalake")

        import time
        t0 = time.perf_counter()

        dt_kwargs = {}
        if storage_options:
            dt_kwargs["storage_options"] = storage_options
        if version is not None:
            dt_kwargs["version"] = version

        dt = DeltaTable(path, **dt_kwargs)
        ds = dt.to_pyarrow_dataset()

        # Build scanner with filters
        scanner_kwargs = {}
        if columns:
            scanner_kwargs["columns"] = columns
        if filters:
            scanner_kwargs["filter"] = cls._build_arrow_filter(filters)

        scanner = ds.scanner(batch_size=batch_size, **scanner_kwargs)

        partial_results = []
        total_rows = 0
        batch_count = 0

        for record_batch in scanner.to_batches():
            batch_table = pa.Table.from_batches([record_batch])
            total_rows += len(batch_table)
            batch_count += 1

            tf_batch = cls(data=batch_table, max_workers=max_workers)
            result = batch_fn(tf_batch)

            if result is not None:
                if isinstance(result, TurboFrame):
                    partial_results.append(result._table)
                elif isinstance(result, pa.Table):
                    partial_results.append(result)

        elapsed = time.perf_counter() - t0
        print(f"[TurboFrame] Processed {total_rows:,} rows in {batch_count} batches in {elapsed:.2f}s")

        if partial_results:
            merged = pa.concat_tables(partial_results)
            return cls(data=merged, max_workers=max_workers)
        else:
            return cls(data=None, max_workers=max_workers)

    @classmethod
    def read_parquet(
        cls,
        path: str,
        columns: Optional[List[str]] = None,
        max_workers: Optional[int] = None,
    ) -> "TurboFrame":
        """Read Parquet file(s) into TurboFrame."""
        t0 = time.perf_counter()
        table = pq.read_table(path, columns=columns)
        elapsed = time.perf_counter() - t0
        print(f"[TurboFrame] Read {len(table):,} rows in {elapsed:.2f}s from parquet")
        return cls(data=table, max_workers=max_workers)

    @classmethod
    def from_pandas(cls, df, max_workers: Optional[int] = None) -> "TurboFrame":
        """Convert pandas DataFrame to TurboFrame."""
        return cls(data=df, max_workers=max_workers)

    @classmethod
    def from_spark(cls, spark_df, max_workers: Optional[int] = None) -> "TurboFrame":
        """
        Convert Spark DataFrame to TurboFrame.
        Collects to driver — use for datasets that fit in driver memory.
        """
        pandas_df = spark_df.toPandas()
        return cls(data=pandas_df, max_workers=max_workers)

    @classmethod
    def from_dict(cls, data: dict, max_workers: Optional[int] = None) -> "TurboFrame":
        """Create TurboFrame from a dictionary of columns."""
        return cls(data=data, max_workers=max_workers)

    # ══════════════════════════════════════════════════════════════════
    # PROPERTIES
    # ══════════════════════════════════════════════════════════════════

    @property
    def shape(self) -> tuple:
        return (len(self._table), len(self._table.schema))

    @property
    def columns(self) -> List[str]:
        return self._table.column_names

    @property
    def dtypes(self) -> Dict[str, pa.DataType]:
        return {f.name: f.type for f in self._table.schema}

    @property
    def schema(self) -> pa.Schema:
        return self._table.schema

    @property
    def arrow_table(self) -> pa.Table:
        """Access the underlying PyArrow table directly."""
        return self._table

    def __len__(self) -> int:
        return len(self._table)

    def __repr__(self) -> str:
        rows, cols = self.shape
        return f"TurboFrame({rows:,} rows × {cols} cols, workers={self._engine.max_workers})"

    # ══════════════════════════════════════════════════════════════════
    # COLUMN OPERATIONS
    # ══════════════════════════════════════════════════════════════════

    def select(self, columns: List[str]) -> "TurboFrame":
        """Select specific columns (column pruning)."""
        table = self._table.select(columns)
        return TurboFrame._from_table(table, engine=self._engine)

    def drop(self, columns: Union[str, List[str]]) -> "TurboFrame":
        """Drop columns."""
        if isinstance(columns, str):
            columns = [columns]
        keep = [c for c in self.columns if c not in columns]
        return self.select(keep)

    def rename(self, mapping: Dict[str, str]) -> "TurboFrame":
        """Rename columns: {"old_name": "new_name"}."""
        new_names = [mapping.get(c, c) for c in self.columns]
        table = self._table.rename_columns(new_names)
        return TurboFrame._from_table(table, engine=self._engine)

    def with_column(self, name: str, values) -> "TurboFrame":
        """Add or replace a column."""
        if isinstance(values, (list, tuple)):
            arr = pa.array(values)
        elif isinstance(values, pa.Array):
            arr = values
        elif isinstance(values, pa.ChunkedArray):
            arr = values
        else:
            # Scalar — broadcast
            arr = pa.array([values] * len(self))

        if name in self.columns:
            idx = self.columns.index(name)
            table = self._table.set_column(idx, name, arr)
        else:
            table = self._table.append_column(name, arr)
        return TurboFrame._from_table(table, engine=self._engine)

    # ══════════════════════════════════════════════════════════════════
    # FILTERING
    # ══════════════════════════════════════════════════════════════════

    def filter(self, expression: str) -> "TurboFrame":
        """
        Filter rows using a simple expression string.

        Supported: >, <, >=, <=, ==, !=
        Examples:
            tf.filter("amount > 1000")
            tf.filter("region == 'East'")
            tf.filter("quantity != 0")
        """
        col_name, op, value = self._parse_filter_expr(expression)

        col_data = self._table.column(col_name)

        # Type-cast the value
        if pa.types.is_integer(col_data.type):
            val = int(value)
        elif pa.types.is_floating(col_data.type):
            val = float(value)
        elif pa.types.is_string(col_data.type) or pa.types.is_large_string(col_data.type):
            val = value.strip("'\"")
        else:
            val = value.strip("'\"")

        ops = {
            ">": pc.greater,
            "<": pc.less,
            ">=": pc.greater_equal,
            "<=": pc.less_equal,
            "==": pc.equal,
            "!=": pc.not_equal,
        }

        mask = ops[op](col_data, val)
        filtered = pc.filter(self._table, mask)
        return TurboFrame._from_table(filtered, engine=self._engine)

    def filter_arrow(self, mask: pa.Array) -> "TurboFrame":
        """Filter using a pre-computed boolean Arrow array."""
        filtered = pc.filter(self._table, mask)
        return TurboFrame._from_table(filtered, engine=self._engine)

    def filter_parallel(self, predicate_fn: Callable) -> "TurboFrame":
        """
        Filter with a custom function, executed in parallel across chunks.
        predicate_fn takes a pa.Table chunk and returns a boolean pa.Array.
        """
        result = self._engine.parallel_filter(self._table, predicate_fn)
        return TurboFrame._from_table(result, engine=self._engine)

    @staticmethod
    def _parse_filter_expr(expr: str):
        """Parse 'column op value' expressions."""
        for op in [">=", "<=", "!=", "==", ">", "<"]:
            if op in expr:
                parts = expr.split(op, 1)
                return parts[0].strip(), op, parts[1].strip()
        raise ValueError(f"Cannot parse filter expression: {expr}")

    # ══════════════════════════════════════════════════════════════════
    # SORTING
    # ══════════════════════════════════════════════════════════════════

    def sort(
        self, by: Union[str, List[str]], ascending: Union[bool, List[bool]] = True
    ) -> "TurboFrame":
        """Sort by one or more columns."""
        if isinstance(by, str):
            by = [by]
        if isinstance(ascending, bool):
            ascending = [ascending] * len(by)

        sort_keys = [
            (col, "ascending" if asc else "descending")
            for col, asc in zip(by, ascending)
        ]
        indices = pc.sort_indices(self._table, sort_keys=sort_keys)
        sorted_table = self._table.take(indices)
        return TurboFrame._from_table(sorted_table, engine=self._engine)

    # ══════════════════════════════════════════════════════════════════
    # GROUPBY
    # ══════════════════════════════════════════════════════════════════

    def groupby(self, keys: Union[str, List[str]]) -> GroupByResult:
        """
        Parallel GroupBy. Returns a GroupByResult, call .agg() to execute.

        How it works internally:
        1. Hash-partition the data across N CPU cores by key
        2. Each core aggregates its partition independently
        3. Results are concatenated (no merge needed — hash guarantees no overlap)

        Example:
            result = tf.groupby("region").agg({"sales": "sum", "qty": "mean"})
            result = tf.groupby(["region", "year"]).agg({"sales": "sum"})
        """
        if isinstance(keys, str):
            keys = [keys]
        return GroupByResult(self, keys)

    # ══════════════════════════════════════════════════════════════════
    # HEAD / TAIL / SAMPLE
    # ══════════════════════════════════════════════════════════════════

    def head(self, n: int = 5) -> "TurboFrame":
        return TurboFrame._from_table(self._table.slice(0, n), engine=self._engine)

    def tail(self, n: int = 5) -> "TurboFrame":
        start = max(0, len(self) - n)
        return TurboFrame._from_table(self._table.slice(start), engine=self._engine)

    def sample(self, n: int = 5, seed: Optional[int] = None) -> "TurboFrame":
        import numpy as np
        rng = np.random.default_rng(seed)
        indices = rng.choice(len(self), size=min(n, len(self)), replace=False)
        indices_sorted = pa.array(sorted(indices))
        return TurboFrame._from_table(
            self._table.take(indices_sorted), engine=self._engine
        )

    # ══════════════════════════════════════════════════════════════════
    # JOINS
    # ══════════════════════════════════════════════════════════════════

    def join(
        self,
        other: "TurboFrame",
        on: str,
        how: str = "inner",
    ) -> "TurboFrame":
        """
        Join two TurboFrames.
        how: "inner", "left", "right", "full outer"
        """
        # Map friendly names to PyArrow's join types
        join_map = {
            "inner": "inner",
            "left": "left outer",
            "right": "right outer",
            "outer": "full outer",
            "full": "full outer",
            "left outer": "left outer",
            "right outer": "right outer",
            "full outer": "full outer",
        }
        join_type = join_map.get(how, how)

        result = self._table.join(other._table, keys=on, join_type=join_type)
        return TurboFrame._from_table(result, engine=self._engine)

    # ══════════════════════════════════════════════════════════════════
    # COMPUTE / TRANSFORM
    # ══════════════════════════════════════════════════════════════════

    def apply_parallel(self, func: Callable) -> "TurboFrame":
        """
        Apply a transformation function in parallel across row chunks.
        func: takes a pa.Table → returns a pa.Table
        """
        result = self._engine.parallel_apply(self._table, func)
        return TurboFrame._from_table(result, engine=self._engine)

    # ══════════════════════════════════════════════════════════════════
    # CONVERSIONS
    # ══════════════════════════════════════════════════════════════════

    def to_pandas(self):
        """Convert to pandas DataFrame. Zero-copy where possible."""
        return self._table.to_pandas(self_destruct=False)

    def to_polars(self):
        """Convert to Polars DataFrame."""
        try:
            import polars as pl
            return pl.from_arrow(self._table)
        except ImportError:
            raise ImportError("Install polars: pip install polars")

    def to_spark(self, spark_session):
        """Convert to Spark DataFrame."""
        pdf = self.to_pandas()
        return spark_session.createDataFrame(pdf)

    def to_arrow(self) -> pa.Table:
        """Return the underlying PyArrow table."""
        return self._table

    def to_dict(self) -> Dict[str, list]:
        """Convert to Python dict of lists."""
        return {col: self._table.column(col).to_pylist() for col in self.columns}

    def to_parquet(self, path: str, compression: str = "snappy"):
        """Write to Parquet file."""
        pq.write_table(self._table, path, compression=compression)
        print(f"[TurboFrame] Wrote {len(self):,} rows to {path}")

    def to_delta(self, path: str, mode: str = "overwrite", storage_options: Optional[Dict] = None):
        """Write back to Delta table."""
        try:
            from deltalake import write_deltalake
        except ImportError:
            raise ImportError("Install deltalake: pip install deltalake")

        kwargs = {}
        if storage_options:
            kwargs["storage_options"] = storage_options

        write_deltalake(path, self._table, mode=mode, **kwargs)
        print(f"[TurboFrame] Wrote {len(self):,} rows to delta: {path}")

    # ══════════════════════════════════════════════════════════════════
    # DISPLAY
    # ══════════════════════════════════════════════════════════════════

    def show(self, n: int = 10):
        """Pretty-print first N rows."""
        sub = self._table.slice(0, min(n, len(self)))
        print(sub.to_pandas().to_string(index=False))

    def describe(self) -> Dict[str, Dict[str, Any]]:
        """Basic statistics for numeric columns."""
        stats = {}
        for col_name in self.columns:
            col = self._table.column(col_name)
            if pa.types.is_integer(col.type) or pa.types.is_floating(col.type):
                stats[col_name] = {
                    "count": pc.count(col).as_py(),
                    "mean": pc.mean(col).as_py(),
                    "min": pc.min(col).as_py(),
                    "max": pc.max(col).as_py(),
                    "std": pc.stddev(col).as_py(),
                    "null_count": col.null_count,
                }
        return stats

    # ══════════════════════════════════════════════════════════════════
    # UTILITY
    # ══════════════════════════════════════════════════════════════════

    def unique(self, column: str) -> list:
        """Get unique values of a column."""
        return pc.unique(self._table.column(column)).to_pylist()

    def value_counts(self, column: str) -> "TurboFrame":
        """Count occurrences of each value in a column."""
        result = pc.value_counts(self._table.column(column))
        # Convert StructArray to table
        values = [x["values"].as_py() for x in result]
        counts = [x["counts"].as_py() for x in result]
        table = pa.table({column: values, "count": counts})
        return TurboFrame._from_table(table, engine=self._engine)

    def is_empty(self) -> bool:
        return len(self) == 0

    def count_nulls(self) -> Dict[str, int]:
        """Count nulls per column."""
        return {col: self._table.column(col).null_count for col in self.columns}

    def drop_nulls(self, columns: Optional[List[str]] = None) -> "TurboFrame":
        """Drop rows with nulls in specified columns (or all)."""
        table = self._table.drop_null()
        return TurboFrame._from_table(table, engine=self._engine)

    def __del__(self):
        """Clean up parallel engine on garbage collection."""
        try:
            self._engine.shutdown()
        except Exception:
            pass