from _typeshed import Incomplete
from dataclasses import dataclass
from typing import Any

RESERVED_MODULE_NAMES: Incomplete
DEFAULT_EXAMPLE_PLACEHOLDER: str
KWARGS_ANY_PARAMS: str
RESERVED_CUSTOM_PARAM_NAMES: Incomplete

@dataclass(frozen=True)
class CustomToolFieldSpec:
    """Projected field metadata for a custom tool schema property."""
    schema_key: str
    param_name: str
    type_hint: str
    required: bool

@dataclass(frozen=True)
class CustomToolRuntimeParamSpec:
    """Runtime signature metadata for inspect.Signature reconstruction."""
    name: str
    kind: str
    annotation_expr: str
    has_default: bool = ...
    default_expr: str | None = ...

@dataclass(frozen=True)
class CustomToolSignatureProjection:
    """Canonical custom-tool signature projection derived from JSON schema."""
    field_specs: list[CustomToolFieldSpec]
    canonical_params: str
    runtime_params: list[CustomToolRuntimeParamSpec]
    schema_to_param: dict[str, str]
    param_to_schema: dict[str, str]

def sanitize_module_name(name: str) -> str:
    """Sanitize server name for use as Python module name.

    Args:
        name: Original server name.

    Returns:
        Valid Python module name (lowercase, underscored).
    """
def sanitize_module_name_with_reserved(name: str) -> str:
    """Sanitize server name, avoiding reserved module names.

    If the sanitized name collides with a reserved name (e.g., ptc_helper),
    appends '_mcp' suffix to avoid collision.

    Args:
        name: Original server name.

    Returns:
        Valid Python module name that does not collide with reserved names.
    """
def sanitize_function_name(name: str) -> str:
    """Sanitize tool name for use as Python function name.

    Args:
        name: Original tool name.

    Returns:
        Valid Python function name (lowercase, underscored).
    """
def sanitize_param_name(name: str) -> str:
    """Sanitize parameter name for use as Python parameter.

    Args:
        name: Original parameter name (e.g., userId, user-id).

    Returns:
        Valid Python parameter name (lowercase, underscored).
    """
def is_valid_identifier(name: str) -> bool:
    """Check if a string is a valid Python identifier and not a keyword.

    Args:
        name: Candidate identifier.

    Returns:
        True if name is a valid identifier and not a keyword.
    """
def json_type_to_python(json_type: str | list) -> str:
    '''Convert JSON schema type to Python type hint.

    Handles union types (list form) by converting each type and joining with |.
    For example, ["string", "null"] -> "str | None".

    Edge cases handled:
    - Empty list returns "Any"
    - Duplicate types are deduplicated while preserving order
    - "null" is normalized to end of union (e.g., ["null", "string"] -> "str | None")
    - Unknown types map to "Any" (deduplicated if multiple)

    Args:
        json_type: JSON schema type (string or list of strings for union types).

    Returns:
        Python type hint string.
    '''
def schema_to_params(schema: dict[str, Any]) -> str:
    """Convert JSON schema to Python function parameters.

    Args:
        schema: JSON schema for tool input.

    Returns:
        Function parameter string.
    """
def project_custom_tool_signature(schema: dict[str, Any]) -> CustomToolSignatureProjection:
    """Project schema into a canonical custom-tool signature contract.

    This helper is custom-tool specific and intentionally independent from
    `schema_to_params(...)` so MCP behavior remains unchanged.

    Args:
        schema: JSON schema for custom tool input.

    Returns:
        Canonical projection for rendering and runtime introspection.

    Raises:
        ValueError: If parameter sanitization causes collisions.
    """
def example_value_from_schema(prop_schema: dict[str, Any], default_placeholder: str = ...) -> str:
    """Return an example value for a schema property.

    Prefers schema-provided examples, defaults, or enums, and falls back
    to type-based placeholders.

    Args:
        prop_schema: Property schema from JSON schema.
        default_placeholder: Placeholder value to use for unknown types.

    Returns:
        Example value as a Python literal string.
    """
