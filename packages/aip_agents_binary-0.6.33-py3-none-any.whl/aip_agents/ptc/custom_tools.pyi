from _typeshed import Incomplete
from aip_agents.ptc.exceptions import PTCError as PTCError
from aip_agents.ptc.naming import is_valid_identifier as is_valid_identifier, project_custom_tool_signature as project_custom_tool_signature, sanitize_function_name as sanitize_function_name
from aip_agents.utils.logger import get_logger as get_logger
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal, TypedDict

logger: Incomplete

class PTCPackageToolDef(TypedDict, total=False):
    '''Definition for a package-based tool.

    Required fields:
        name: Tool name (used for imports and config lookup).
        kind: Must be "package".
        import_path: Dotted import path (e.g., "aip_agents.tools.time_tool").
        class_name: Class name to import (e.g., "TimeTool").

    Optional fields:
        package_path: Path to source directory to bundle.
            If omitted, the tool must already be available in sandbox (e.g., from site-packages).
        description: Tool description (derived from tool object at construction time).
        input_schema: JSON schema for tool input (derived from tool object at construction time).
    '''
    name: str
    kind: Literal['package']
    import_path: str
    class_name: str
    package_path: str
    description: str
    input_schema: dict

class PTCFileToolDef(TypedDict, total=False):
    '''Definition for a single-file tool.

    Required fields:
        name: Tool name (used for imports and config lookup).
        kind: Must be "file".
        file_path: Path to the Python file containing the tool.
        class_name: Class name to import from the file.

    Optional fields:
        description: Tool description (derived from tool object at construction time).
        input_schema: JSON schema for tool input (derived from tool object at construction time).
    '''
    name: str
    kind: Literal['file']
    file_path: str
    class_name: str
    description: str
    input_schema: dict
PTCToolDef = PTCPackageToolDef | PTCFileToolDef

class PTCCustomToolValidationError(PTCError):
    """Error raised when custom tool configuration is invalid."""

@dataclass
class PTCCustomToolConfig:
    '''Configuration for custom LangChain tools in PTC sandbox.

    This config controls which user-defined LangChain tools are available
    in the sandbox for use by PTC code.

    Attributes:
        enabled: Whether custom tools are enabled.
        bundle_roots: List of allowed root directories for bundling tool sources.
            Paths outside these roots will cause validation errors.
        requirements: List of pip requirements to install in sandbox.
        tools: List of tool definitions (package or file tools).

    Example:
        >>> config = PTCCustomToolConfig(
        ...     enabled=True,
        ...     bundle_roots=["/app/tools"],
        ...     requirements=["pydantic>=2.0"],
        ...     tools=[
        ...         {
        ...             "name": "time_tool",
        ...             "kind": "package",
        ...             "import_path": "aip_agents.tools.time_tool",
        ...             "class_name": "TimeTool",
        ...         },
        ...     ],
        ... )
    '''
    enabled: bool = ...
    bundle_roots: list[str] = field(default_factory=list)
    requirements: list[str] = field(default_factory=list)
    tools: list[PTCToolDef] = field(default_factory=list)

def validate_tool_def(tool: PTCToolDef) -> None:
    """Validate a tool definition has required fields.

    Args:
        tool: Tool definition to validate.

    Raises:
        PTCCustomToolValidationError: If tool definition is invalid.
    """
def validate_path_within_bundle_roots(path: str | Path, bundle_roots: list[str], tool_name: str) -> None:
    """Validate that a path is within one of the bundle roots.

    Args:
        path: Path to validate.
        bundle_roots: List of allowed root directories.
        tool_name: Tool name for error messages.

    Raises:
        PTCCustomToolValidationError: If path is outside all bundle roots.
    """
def detect_relative_imports(file_path: str | Path) -> list[str]:
    """Detect relative imports in a Python file using AST.

    Args:
        file_path: Path to the Python file to scan.

    Returns:
        List of relative import statements found.

    Raises:
        PTCCustomToolValidationError: If file cannot be read or parsed.
    """
def check_name_collisions(tools: list[PTCToolDef]) -> None:
    """Check for tool name collisions after sanitization.

    Args:
        tools: List of tool definitions.

    Raises:
        PTCCustomToolValidationError: If two tools sanitize to the same name.
    """
def validate_custom_tool_config(config: PTCCustomToolConfig) -> None:
    """Validate the complete custom tool configuration.

    This runs all validation checks:
    - Tool definitions have required fields
    - Input schemas have valid parameter names (no collisions/reserved names)
    - Paths are within bundle roots
    - File tools don't use relative imports
    - No name collisions

    Args:
        config: Custom tool configuration to validate.

    Raises:
        PTCCustomToolValidationError: If configuration is invalid.
    """
def extract_tool_metadata(tool: object) -> dict:
    '''Extract metadata from a LangChain BaseTool instance.

    Extracts name, description, and input_schema from the tool object.
    This is called at agent construction time to populate tool definitions.

    Args:
        tool: A LangChain BaseTool instance (or compatible object).

    Returns:
        Dict with keys:
        - name: str (tool name)
        - description: str (tool description, empty if not available)
        - input_schema: dict (JSON schema, empty object schema if not available)

    Note:
        If schema inference fails, returns an empty object schema
        ({"type": "object", "properties": {}}) so prompt/index output
        falls back to tool(**kwargs).
    '''
def enrich_tool_def_with_metadata(tool_def: PTCToolDef, tool: object) -> PTCToolDef:
    """Enrich a tool definition with metadata extracted from the tool object.

    Always derives description and input_schema from the tool object, overwriting
    any user-supplied values. This ensures the tool object is the source of truth.
    Called at agent construction time.

    Args:
        tool_def: The tool definition to enrich.
        tool: The LangChain BaseTool instance.

    Returns:
        The tool definition with description and input_schema populated from the tool object.

    Raises:
        PTCCustomToolValidationError: If tool name in metadata does not match tool_def name.
    """
