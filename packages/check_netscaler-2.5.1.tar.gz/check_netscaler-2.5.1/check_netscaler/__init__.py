"""
check_netscaler - Nagios/Icinga monitoring plugin for Citrix NetScaler ADC

A monitoring plugin for Citrix NetScaler Application Delivery Controllers
using the NITRO REST API.
"""

__version__ = "2.5.1"
__author__ = "slauger"
__license__ = "MIT"
