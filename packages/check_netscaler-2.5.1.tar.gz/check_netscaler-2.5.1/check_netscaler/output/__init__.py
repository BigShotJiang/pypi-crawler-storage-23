"""Output formatters for monitoring systems"""
