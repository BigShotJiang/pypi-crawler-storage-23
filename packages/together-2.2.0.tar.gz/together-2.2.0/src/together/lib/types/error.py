from ..._exceptions import TogetherError


class DownloadError(TogetherError):
    pass


class FileTypeError(TogetherError):
    pass
