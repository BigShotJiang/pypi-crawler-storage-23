# Manually added to minimize breaking changes from V1
from together.types import DedicatedEndpoint as DedicatedEndpoint

ListEndpoint = DedicatedEndpoint
