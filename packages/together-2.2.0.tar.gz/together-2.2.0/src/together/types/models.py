# Manually added to minimize breaking changes from V1
from together.types import ModelObject as ModelObject
