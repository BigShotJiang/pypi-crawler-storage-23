from cube_agent.main import cli as main

__all__ = ["main"]
