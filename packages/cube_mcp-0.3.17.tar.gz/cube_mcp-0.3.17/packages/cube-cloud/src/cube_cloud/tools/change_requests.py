"""Change request management tools."""

from __future__ import annotations

from cube_common.apollo_client import ApolloClient, ApolloError
from cube_common import apollo_queries as Q

from cube_cloud.tools.environments import _resolve_environment


async def list_change_requests(
    client: ApolloClient,
    environment: str | None = None,
    status: str | None = None,
    page_size: int = 10,
) -> str:
    page_size = min(max(page_size, 1), 50)

    if environment:
        env_info = await _resolve_environment(client, environment)
        env_id = env_info["id"]
        env_name = env_info.get("name", environment)
        data = await client.graphql(
            Q.LIST_CHANGE_REQUESTS_BY_ENV, {"envId": env_id, "pageSize": page_size}
        )
        crs = (
            data.get("apollo", {})
            .get("environmentById", {})
            .get("changeRequests", {})
            .get("changeRequests", [])
        )
        header = f"Change Requests: {env_name}"
    else:
        data = await client.graphql(
            Q.LIST_CHANGE_REQUESTS, {"pageSize": page_size}
        )
        crs = (
            data.get("apollo", {})
            .get("changeRequests", {})
            .get("changeRequests", [])
        )
        header = "Change Requests"

    if status:
        status_upper = status.upper()
        crs = [cr for cr in crs if cr.get("requestStatus", "") == status_upper]

    if not crs:
        suffix = f" with status {status}" if status else ""
        return f"No change requests found{suffix}."

    lines = [f"{header} ({len(crs)})", "=" * 60]
    for cr in crs:
        rid = cr.get("rid", "?")
        title = cr.get("title", "(no title)")
        cr_status = cr.get("requestStatus", "?")
        created = cr.get("createdAt", "")
        env = cr.get("environment", {})
        env_name_str = env.get("name", "") if env else ""

        lines.append(f"  {cr_status}: {title}")
        lines.append(f"    RID:     {rid}")
        if env_name_str:
            lines.append(f"    Env:     {env_name_str}")
        if created:
            lines.append(f"    Created: {created}")

    return "\n".join(lines)


async def review_change_request(
    client: ApolloClient,
    rid: str,
    action: str,
    comment: str | None = None,
) -> str:
    action_lower = action.lower()

    if action_lower == "approve":
        data = await client.graphql(
            Q.APPROVE_CHANGE_REQUEST, {"rid": rid, "comment": comment}
        )
        result = data.get("apollo", {}).get("approveChangeRequest", {})
    elif action_lower == "reject":
        if not comment:
            return "Error: comment is required when rejecting a change request."
        data = await client.graphql(
            Q.REJECT_CHANGE_REQUEST, {"rid": rid, "comment": comment}
        )
        result = data.get("apollo", {}).get("rejectChangeRequest", {})
    elif action_lower == "cancel":
        data = await client.graphql(Q.CANCEL_CHANGE_REQUEST, {"rid": rid})
        result = data.get("apollo", {}).get("cancelChangeRequest", {})
    else:
        return f"Error: unknown action '{action}'. Use 'approve', 'reject', or 'cancel'."

    new_status = result.get("requestStatus", "?")
    return f"Change request {action_lower}d.\n  RID:    {rid}\n  Status: {new_status}"
