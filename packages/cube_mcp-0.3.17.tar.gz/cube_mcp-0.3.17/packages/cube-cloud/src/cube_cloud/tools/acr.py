"""ACR token and Apollo publish tools."""

from __future__ import annotations

import logging

import yaml

from cube_common.apollo_client import ApolloClient, ApolloError
from cube_common.apollo_queries import (
    CREATE_PRODUCT,
    CREATE_PRODUCT_RELEASE_FROM_MANIFEST,
    LIST_PRODUCTS,
)

logger = logging.getLogger(__name__)


async def acr_get_token(client: ApolloClient) -> str:
    """Get a raw ACR OAuth2 token. Returns the full token for agent use."""
    token = await client.get_token()
    return token


def _extract_product_id(manifest_yaml: str) -> tuple[str, str | None]:
    """Extract product_id from a manifest, supporting both formats.

    Returns (product_id, error_message). error_message is None on success.

    Supported formats:
    1. Standard: product-id.maven-coordinate = "group:name:version"
    2. Extensions-only: extensions.helm-chart.* or extensions.helm-chart-operator.*
       (auto-constructs product-id from chart info)
    """
    try:
        manifest = yaml.safe_load(manifest_yaml)
    except yaml.YAMLError as e:
        return "", f"Error: invalid YAML in manifest: {e}"

    if not isinstance(manifest, dict):
        return "", f"Error: manifest must be a YAML mapping (got {type(manifest).__name__})"

    # Format 1: standard product-id section
    product_id_section = manifest.get("product-id")
    if product_id_section and isinstance(product_id_section, dict):
        maven_coordinate = product_id_section.get("maven-coordinate")
        if maven_coordinate:
            coord = str(maven_coordinate).strip('"').strip("'")
            parts = coord.split(":")
            if len(parts) >= 2:
                return f"{parts[0]}:{parts[1]}", None

    # Format 2: extensions-only — try to extract from helm-chart or helm-chart-operator
    extensions = manifest.get("extensions", {})
    if isinstance(extensions, dict):
        # Check helm-chart-operator.products
        hco = extensions.get("helm-chart-operator", {})
        if isinstance(hco, dict):
            products = hco.get("products", {})
            if isinstance(products, dict) and products:
                product_id = next(iter(products))
                return product_id, None

        # Check helm-chart section
        hc = extensions.get("helm-chart", {})
        if isinstance(hc, dict):
            oci_url = hc.get("oci-url", "")
            version = hc.get("version", "")
            if oci_url and version:
                # Try to extract group:name from oci-url path
                parts = str(oci_url).rstrip("/").split("/")
                if len(parts) >= 2:
                    group = parts[-2]
                    name = parts[-1].split(":")[0]  # strip :version tag if present
                    return f"{group}:{name}", None

    return "", (
        "Error: cannot extract product ID from manifest. "
        "Manifest must have either a 'product-id.maven-coordinate' field "
        "or an 'extensions.helm-chart-operator.products' section."
    )


async def _all_product_ids(client: ApolloClient) -> set[str]:
    """Fetch all product IDs with pagination."""
    product_ids: set[str] = set()
    page_token: str | None = None

    while True:
        variables: dict = {"pageSize": 200}
        if page_token:
            variables["pageToken"] = page_token
        data = await client.graphql(LIST_PRODUCTS, variables)
        page_data = data.get("apollo", {}).get("products", {})
        for p in page_data.get("products", []):
            product_ids.add(p.get("productId", ""))
        page_token = page_data.get("nextPageToken")
        if not page_token:
            break

    return product_ids


async def apollo_publish_manifest(client: ApolloClient, manifest_yaml: str) -> str:
    """Publish a manifest to Apollo via GraphQL.

    1. Parse the product_id (group:name) from the manifest's maven-coordinate.
    2. If the product doesn't exist yet, create it.
    3. Publish the release using the manifest YAML.

    Supports both standard manifests (with product-id section) and
    extensions-only manifests (helm-chart-operator format).
    """
    # --- extract product_id from manifest ---
    product_id, err = _extract_product_id(manifest_yaml)
    if err:
        return err

    # --- ensure product exists ---
    existing = await _all_product_ids(client)
    created = False
    if product_id not in existing:
        try:
            await client.graphql(CREATE_PRODUCT, {"productId": product_id})
            created = True
            logger.info("Created new Apollo product: %s", product_id)
        except ApolloError as e:
            return f"Error creating product '{product_id}': {e}"

    # --- publish release ---
    try:
        data = await client.graphql(
            CREATE_PRODUCT_RELEASE_FROM_MANIFEST,
            {"productReleaseManifest": manifest_yaml},
        )
    except ApolloError as e:
        return f"Error publishing manifest for '{product_id}': {e}"

    release = data.get("apollo", {}).get("createProductReleaseFromManifestV2", {})
    version = release.get("version", "?")

    if created:
        return f"Created product '{product_id}' and published release {version}."
    return f"Published release {version} for product '{product_id}'."
