"""Product and release channel management tools."""

from __future__ import annotations

from cube_common.apollo_client import ApolloClient, ApolloError
from cube_common import apollo_queries as Q


async def list_products(
    client: ApolloClient, search: str | None = None, page_size: int = 50
) -> str:
    page_size = min(max(page_size, 1), 200)
    products: list[dict] = []
    page_token: str | None = None

    # Paginate through all results to ensure search doesn't miss products
    while True:
        variables: dict = {"pageSize": page_size}
        if page_token:
            variables["pageToken"] = page_token

        data = await client.graphql(Q.LIST_PRODUCTS, variables)
        page_data = data.get("apollo", {}).get("products", {})
        products.extend(page_data.get("products", []))

        page_token = page_data.get("nextPageToken")
        if not page_token:
            break

    if search:
        search_lower = search.lower()
        products = [
            p for p in products if search_lower in p.get("productId", "").lower()
        ]

    if not products:
        suffix = f' matching "{search}"' if search else ""
        return f"No products found{suffix}."

    lines = [f"Apollo Products ({len(products)})", "=" * 60]
    for p in sorted(products, key=lambda x: x.get("productId", "")):
        pid = p.get("productId", "?")
        labels = p.get("labels", [])
        lines.append(f"  {pid}")
        for lbl in labels:
            lines.append(f"    {lbl['labelId']}: {lbl['labelValue']}")
    return "\n".join(lines)


async def compare_product_versions(
    client: ApolloClient, product_id: str, environments: str
) -> str:
    from cube_cloud.tools.environments import _resolve_environment

    env_names = [e.strip() for e in environments.split(",") if e.strip()]
    if not env_names:
        return "Error: no environments specified."

    lines = [f"Product Version Comparison: {product_id}", "=" * 60]

    for env_name in env_names:
        try:
            env_info = await _resolve_environment(client, env_name)
        except ApolloError as e:
            lines.append(f"  {env_name}: {e}")
            continue

        data = await client.graphql(Q.ENTITY_BY_NAME, {"id": env_info["id"]})
        entities = (
            data.get("apollo", {})
            .get("environmentById", {})
            .get("entities", {})
            .get("entities", [])
        )

        matched = [
            e for e in entities
            if e.get("product", {}).get("productId", "") == product_id
        ]

        if not matched:
            lines.append(f"  {env_info.get('name', env_name)}: not installed")
        else:
            for e in matched:
                ename = e.get("entityLocator", {}).get("entityName", "?")
                # Use entity health data if available
                lines.append(f"  {env_info.get('name', env_name)}: entity={ename}")

    return "\n".join(lines)


async def get_product_releases(
    client: ApolloClient, product_id: str, page_size: int = 10
) -> str:
    page_size = min(max(page_size, 1), 50)
    data = await client.graphql(
        Q.GET_PRODUCT_RELEASES, {"product": product_id, "pageSize": page_size}
    )
    releases = (
        data.get("apollo", {}).get("productReleases", {}).get("productReleases", [])
    )

    if not releases:
        return f"No releases found for product: {product_id}"

    lines = [f"Releases for {product_id} ({len(releases)})", "=" * 60]
    for r in releases:
        version = r.get("version", "?")
        rid = r.get("rid", "")
        channels = [
            ch.get("releaseChannelName", "?")
            for ch in r.get("releaseChannels", [])
        ]
        ch_str = ", ".join(channels) if channels else "(no channels)"
        lines.append(f"  {version}")
        lines.append(f"    RID:      {rid}")
        lines.append(f"    Channels: {ch_str}")

    return "\n".join(lines)


async def list_release_channels(
    client: ApolloClient,
    search: str | None = None,
    include_env_specific: bool = False,
) -> str:
    data = await client.graphql(Q.LIST_RELEASE_CHANNELS)
    channels = (
        data.get("apollo", {})
        .get("releaseChannels", {})
        .get("releaseChannels", [])
    )

    if not include_env_specific:
        channels = [
            ch for ch in channels
            if ch.get("type", "") != "ENVIRONMENT_SPECIFIC"
        ]

    if search:
        search_lower = search.lower()
        channels = [
            ch for ch in channels
            if search_lower in ch.get("name", "").lower()
        ]

    if not channels:
        suffix = f' matching "{search}"' if search else ""
        return f"No release channels found{suffix}."

    lines = [f"Release Channels ({len(channels)})", "=" * 60]
    for ch in sorted(channels, key=lambda x: x.get("name", "")):
        name = ch.get("name", "?")
        rid = ch.get("rid", "")
        desc = ch.get("description", "")
        ch_type = ch.get("type", "")
        lines.append(f"  {name}")
        lines.append(f"    RID:  {rid}")
        if desc:
            lines.append(f"    Desc: {desc}")
        if ch_type:
            lines.append(f"    Type: {ch_type}")

    return "\n".join(lines)


async def add_product_to_release_channel(
    client: ApolloClient,
    product_id: str,
    version: str,
    channels: str,
    rationale: str | None = None,
) -> str:
    # First, find the release RID for this version
    try:
        data = await client.graphql(
            Q.GET_PRODUCT_RELEASES, {"product": product_id, "pageSize": 50}
        )
    except ApolloError as e:
        return f"Error fetching releases for {product_id}: {e}"

    releases = (
        data.get("apollo", {}).get("productReleases", {}).get("productReleases", [])
    )

    release = None
    for r in releases:
        if r.get("version") == version:
            release = r
            break

    if not release:
        available = [r.get("version", "?") for r in releases[:10]]
        return (
            f"Version {version} not found for {product_id}.\n"
            f"Available versions: {', '.join(available) if available else 'none'}"
        )

    release_rid = release["rid"]
    channel_names = [c.strip() for c in channels.split(",") if c.strip()]

    lines = [f"Adding {product_id}:{version} to release channels", "=" * 50]
    for ch_name in channel_names:
        try:
            result = await client.graphql(Q.ADD_TO_RELEASE_CHANNEL, {
                "releaseRid": release_rid,
                "channelName": ch_name,
                "rationale": rationale or "Promoted via cube-mcp",
            })
            updated = result.get("apollo", {}).get("addProductReleaseToReleaseChannel", {})
            new_channels = [
                c.get("releaseChannelName", "?")
                for c in updated.get("releaseChannels", [])
            ]
            lines.append(f"  OK   {ch_name}")
            lines.append(f"       Now in: {', '.join(new_channels)}")
        except ApolloError as e:
            lines.append(f"  FAIL {ch_name}: {e}")

    return "\n".join(lines)


async def remove_product_from_release_channel(
    client: ApolloClient,
    product_id: str,
    version: str,
    channels: str,
    rationale: str | None = None,
) -> str:
    try:
        data = await client.graphql(
            Q.GET_PRODUCT_RELEASES, {"product": product_id, "pageSize": 50}
        )
    except ApolloError as e:
        return f"Error fetching releases for {product_id}: {e}"

    releases = (
        data.get("apollo", {}).get("productReleases", {}).get("productReleases", [])
    )

    release = None
    for r in releases:
        if r.get("version") == version:
            release = r
            break

    if not release:
        return f"Version {version} not found for {product_id}."

    release_rid = release["rid"]
    channel_names = [c.strip() for c in channels.split(",") if c.strip()]

    lines = [f"Removing {product_id}:{version} from release channels", "=" * 50]
    for ch_name in channel_names:
        try:
            result = await client.graphql(Q.REMOVE_FROM_RELEASE_CHANNEL, {
                "releaseRid": release_rid,
                "channelName": ch_name,
                "rationale": rationale or "Demoted via cube-mcp",
            })
            updated = result.get("apollo", {}).get("removeProductReleaseFromReleaseChannel", {})
            remaining = [
                c.get("releaseChannelName", "?")
                for c in updated.get("releaseChannels", [])
            ]
            lines.append(f"  OK   {ch_name}")
            lines.append(f"       Remaining: {', '.join(remaining) if remaining else '(none)'}")
        except ApolloError as e:
            lines.append(f"  FAIL {ch_name}: {e}")

    return "\n".join(lines)


async def set_label_on_product(
    client: ApolloClient, product_id: str, label_id: str, label_value: str
) -> str:
    data = await client.graphql(Q.SET_LABEL, {
        "productId": product_id,
        "labelId": label_id,
        "labelValue": label_value,
    })
    product = data.get("apollo", {}).get("setLabelOnProduct", {})
    labels = product.get("labels", [])
    label_strs = [f"{l['labelId']}={l['labelValue']}" for l in labels]
    return (
        f"Label set on {product_id}: {label_id}={label_value}\n"
        f"All labels: {', '.join(label_strs) if label_strs else '(none)'}"
    )


async def remove_label_from_product(
    client: ApolloClient, product_id: str, label_id: str
) -> str:
    data = await client.graphql(Q.REMOVE_LABEL, {
        "productId": product_id,
        "labelId": label_id,
    })
    product = data.get("apollo", {}).get("removeLabelFromProduct", {})
    labels = product.get("labels", [])
    label_strs = [f"{l['labelId']}={l['labelValue']}" for l in labels]
    return (
        f"Label removed from {product_id}: {label_id}\n"
        f"Remaining labels: {', '.join(label_strs) if label_strs else '(none)'}"
    )
