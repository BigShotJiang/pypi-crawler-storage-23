<p align="center">
  <img src="docs/assets/logo.png" alt="Redneck">
</p>

<hr>

Redneck is a small, plugin-driven, declarative modpack builder, allowing you to declare a mod with a few lines of YAML code.