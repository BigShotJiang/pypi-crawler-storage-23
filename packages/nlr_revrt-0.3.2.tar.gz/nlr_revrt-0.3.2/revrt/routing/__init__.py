"""reVRt routing logic"""
