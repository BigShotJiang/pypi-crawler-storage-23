from __future__ import annotations

from pydantic import BaseModel, Field, HttpUrl, field_validator


class XrayConfig(BaseModel):
    url: HttpUrl
    project: str = Field(min_length=1, max_length=128)
    token: str = Field(min_length=8)
    tenant_id: str = Field(min_length=1, max_length=128)
    application_id: str = Field(min_length=1, max_length=128)
    timeout: float = Field(default=10.0, ge=1.0, le=60.0)
    retries: int = Field(default=2, ge=0, le=5)

    @field_validator("project")
    @classmethod
    def validate_project(cls, value: str) -> str:
        allowed = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_.")
        if not set(value).issubset(allowed):
            raise ValueError("project contains unsupported characters")
        return value
