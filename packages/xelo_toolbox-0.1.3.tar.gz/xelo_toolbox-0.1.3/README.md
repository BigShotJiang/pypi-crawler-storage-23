# Xelo Toolbox

[![PyPI version](https://img.shields.io/pypi/v/xelo-toolbox)](https://pypi.org/project/xelo-toolbox/)
[![Python](https://img.shields.io/pypi/pyversions/xelo-toolbox)](https://pypi.org/project/xelo-toolbox/)
[![License](https://img.shields.io/badge/license-Apache--2.0-blue)](./LICENSE)

Xelo Toolbox is an open-source CLI for AI SBOM analysis and security scanning.
It consumes AI-BOM JSON files produced by [Xelo](https://nuguard.ai) and provides vulnerability scanning, reporting, and governance integrations for AI systems.

## Why Xelo Toolbox

- **AI component discovery** — scans local paths or GitHub repos; detects agents, models, datastores, guardrails, prompts, and more.
- **Vulnerability scanning** — structural AI-risk rules (VLA-001–009) + OSV CVE lookup + Grype container scanning.
- **Reporting** — human-readable Markdown, SARIF 2.1.0 for GitHub Code Scanning, and CycloneDX 1.6 JSON exports.
- **License enforcement** — deny-list check across all AI nodes and package dependencies.
- **Integrations** — JFrog Xray ingestion.

---

## Installation

```bash
pip install xelo-toolbox
```

---

## Quickstart

```bash
# Scan a local project (offline, structural rules only)
xelo-toolbox vuln scan --path /path/to/my-ai-app

# Scan a GitHub repo with full CVE scanning
xelo-toolbox vuln scan --repo https://github.com/org/repo --provider all

# Generate a Markdown SBOM report
xelo-toolbox markdown export --repo https://github.com/org/repo

# Generate SARIF for GitHub Code Scanning
xelo-toolbox sarif export --sbom sbom.json --provider all --output findings.sarif.json
```

---

## CLI Commands

| Command | Description |
|---|---|
| `xelo-toolbox deps analyze` | Analyze AI component types and package dependency groups |
| `xelo-toolbox vuln scan` | Structural VLA-xxx rules + OSV CVE lookup + Grype |
| `xelo-toolbox license check` | Enforce deny-list license policy across nodes and deps |
| `xelo-toolbox markdown export` | Export SBOM as a human-readable Markdown report |
| `xelo-toolbox sarif export` | Export vulnerability findings as SARIF 2.1.0 |
| `xelo-toolbox cyclonedx export` | Export CycloneDX 1.6 JSON BOM (optionally with VEX) |
| `xelo-toolbox xray submit` | Submit SBOM payload to JFrog Xray |

Run `xelo-toolbox --help` or `xelo-toolbox <command> --help` for all flags.

---

## Documentation

Full end-user documentation lives in [`./docs/`](./docs/):

| Guide | Description |
|---|---|
| [Getting Started](./docs/getting-started.md) | Install, first scan, LLM enrichment, quickstart examples |
| [CLI Reference](./docs/cli.md) | Every command, flag, and output field |
| [Developer Guide](./docs/developer.md) | Architecture, plugin system, testing, contributing |
| [Troubleshooting](./docs/troubleshooting.md) | Common errors and how to fix them |

---

## Development

```bash
git clone https://github.com/NuGuardAI/Xelo-toolbox.git
cd Xelo-toolbox
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"

ruff check src tests   # lint
mypy src               # type check
pytest                 # tests
```

---

## Project Docs

- [Contributing](./CONTRIBUTING.md)
- [Security Policy](./SECURITY.md)
- [Support](./SUPPORT.md)
- [Governance](./GOVERNANCE.md)
- [Roadmap](./ROADMAP.md)
- [Code of Conduct](./CODE_OF_CONDUCT.md)
- [Packaging and PyPI](./PACKAGING.md)
- [Release Runbook](./RELEASE.md)
- [Changelog](./CHANGELOG.md)

---

## License

Apache-2.0. See [LICENSE](./LICENSE).
