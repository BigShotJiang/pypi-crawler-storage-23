from pydantic import ValidationError

from xelo_toolbox.integration_contracts import XrayConfig
from xelo_toolbox.plugins.xray import XrayPlugin


SAMPLE_SBOM = {
    "schema_version": "1.1.0",
    "generated_at": "2026-02-22T00:00:00Z",
    "target": "sample",
    "nodes": [
        {
            "name": "datastore:sql:patients",
            "component_type": "DATASTORE",
            "confidence": 0.95,
            "metadata": {"extras": {"data_classification": ["PHI", "PII"]}},
        }
    ],
    "edges": [],
    "evidence": [],
    "deps": [
        {"name": "openai", "version": "1.0.0", "group": "ai"},
    ],
    "summary": {
        "data_classification": ["PHI", "PII"],
        "classified_tables": ["patients"],
    },
}

# ── XrayConfig tests (unchanged) ──────────────────────────────────────────

def test_xray_payload_contains_project_and_metadata() -> None:
    cfg = XrayConfig(
        url="https://xray.example.com",
        project="my-project",
        token="abcdefgh123456",
        tenant_id="tenant-1",
        application_id="app-1",
    )
    payload = XrayPlugin._build_payload(SAMPLE_SBOM, cfg)
    assert payload["projectKey"] == "my-project"
    assert payload["metadata"]["tenant_id"] == "tenant-1"
    assert payload["metadata"]["tool"] == "xray_submit"


def test_invalid_project_name_rejected() -> None:
    try:
        XrayConfig(
            url="https://xray.example.com",
            project="project with spaces",
            token="abcdefgh123456",
            tenant_id="tenant-1",
            application_id="app-1",
        )
        raise AssertionError("Expected validation error")
    except ValidationError:
        pass
