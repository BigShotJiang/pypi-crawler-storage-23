from xelo_toolbox.core import Toolbox


SAMPLE = {
    "schema_version": "1.1.0",
    "generated_at": "2026-02-22T00:00:00Z",
    "generator": "vela",
    "target": "sample",
    "nodes": [],
    "edges": [],
    "evidence": [],
    "deps": [],
    "summary": {},
}

SAMPLE_WITH_DATASTORE = {
    **SAMPLE,
    "nodes": [
        {
            "id": "00000000-0000-0000-0000-000000000001",
            "name": "patients",
            "component_type": "DATASTORE",
            "confidence": 0.95,
            "metadata": {
                "extras": {
                    "data_classification": ["PHI", "PII"],
                    "classified_fields": {
                        "name": ["PII"],
                        "medical_record_number": ["PHI", "PII"],
                    },
                    "source": "sql_schema",
                }
            },
        }
    ],
}


def test_cyclonedx_export_generates_payload() -> None:
    result = Toolbox().run("cyclonedx_export", SAMPLE, {})
    assert result.status == "ok"
    assert result.details["bomFormat"] == "CycloneDX"


def test_cyclonedx_export_includes_datastore_component() -> None:
    result = Toolbox().run("cyclonedx_export", SAMPLE_WITH_DATASTORE, {})
    assert result.status == "ok"
    components = result.details.get("components", [])
    assert any(c.get("name") == "patients" for c in components)


def test_cyclonedx_export_datastore_has_data_classification_property() -> None:
    result = Toolbox().run("cyclonedx_export", SAMPLE_WITH_DATASTORE, {})
    components = result.details.get("components", [])
    patients = next((c for c in components if c.get("name") == "patients"), None)
    assert patients is not None, "patients component not found in CycloneDX output"
    prop_names = {p["name"] for p in patients.get("properties", [])}
    assert "vela:data_classification" in prop_names


def test_cyclonedx_export_datastore_has_classified_fields_property() -> None:
    result = Toolbox().run("cyclonedx_export", SAMPLE_WITH_DATASTORE, {})
    components = result.details.get("components", [])
    patients = next((c for c in components if c.get("name") == "patients"), None)
    assert patients is not None
    prop_names = {p["name"] for p in patients.get("properties", [])}
    assert "vela:classified_fields" in prop_names
