from xelo_toolbox.core import Toolbox

SAMPLE = {
    "schema_version": "1.1.0",
    "generated_at": "2026-02-22T00:00:00Z",
    "generator": "vela",
    "target": "patient-portal",
    "nodes": [
        {
            "name": "gpt-4",
            "component_type": "MODEL",
            "confidence": 0.9,
            "metadata": {"extras": {"provider": "openai"}},
        },
    ],
    "edges": [],
    "evidence": [],
    "deps": [
        {"name": "openai", "version_spec": "1.0.0", "group": "ai"},
    ],
    "summary": {
        "data_classification": ["PHI"],
        "classified_tables": ["patients"],
    },
}

_VR = {"provider": "vela-rules"}  # offline, no network


def _sarif(result: object) -> dict:  # type: ignore[return]
    return result.details  # type: ignore[union-attr]


def _run(result: object) -> dict:  # type: ignore[return]
    return _sarif(result)["runs"][0]


# ── Structure ─────────────────────────────────────────────────────────────────

def test_sarif_export_structure() -> None:
    sarif = _sarif(Toolbox().run("sarif_export", SAMPLE, _VR))
    assert "version" in sarif
    assert "runs" in sarif
    run = sarif["runs"][0]
    assert "tool" in run
    assert "driver" in run["tool"]
    assert "results" in run


def test_sarif_export_schema_and_version() -> None:
    sarif = _sarif(Toolbox().run("sarif_export", SAMPLE, _VR))
    assert sarif["version"] == "2.1.0"
    assert "sarif-schema-2.1.0" in sarif["$schema"]


def test_sarif_export_tool_driver_fields() -> None:
    driver = _run(Toolbox().run("sarif_export", SAMPLE, _VR))["tool"]["driver"]
    assert driver["name"] == "xelo-toolbox"
    assert "version" in driver
    assert "informationUri" in driver


# ── Findings presence ─────────────────────────────────────────────────────────

def test_sarif_export_produces_results_for_phi_sbom() -> None:
    results = _run(Toolbox().run("sarif_export", SAMPLE, _VR))["results"]
    assert len(results) > 0


def test_sarif_export_no_findings_on_clean_sbom() -> None:
    clean = {**SAMPLE, "nodes": [], "summary": {}}
    result = Toolbox().run("sarif_export", clean, _VR)
    assert result.status == "ok"
    assert _run(result)["results"] == []


# ── Severity → level mapping ──────────────────────────────────────────────────

def test_sarif_export_critical_maps_to_error() -> None:
    sbom = {
        **SAMPLE,
        "nodes": [{"name": "gpt-4", "component_type": "MODEL", "metadata": {"extras": {}}}],
        "summary": {},
    }
    results = _run(Toolbox().run("sarif_export", sbom, _VR))["results"]
    # VLA-001 is CRITICAL
    vla001 = next((r for r in results if r["ruleId"] == "VLA-001"), None)
    assert vla001 is not None
    assert vla001["level"] == "error"


def test_sarif_export_medium_maps_to_warning() -> None:
    # VLA-007 (MEDIUM) fires when a PROMPT has injection_risk_score > 0.3
    sbom = {
        **SAMPLE,
        "nodes": [
            {
                "name": "user-prompt",
                "component_type": "PROMPT",
                "metadata": {
                    "extras": {
                        "injection_risk_score": 0.8,
                        "is_template": True,
                        "template_variables": ["user_input"],
                    }
                },
            }
        ],
        "summary": {},
        "deps": [],
    }
    result = Toolbox().run("sarif_export", sbom, _VR)
    results = _run(result)["results"]
    vla007 = next((r for r in results if r["ruleId"] == "VLA-007"), None)
    assert vla007 is not None
    assert vla007["level"] == "warning"


# ── Rule deduplication ────────────────────────────────────────────────────────

def test_sarif_export_rules_deduplicated() -> None:
    result = Toolbox().run("sarif_export", SAMPLE, _VR)
    rules = _run(result)["tool"]["driver"]["rules"]
    rule_ids = [r["id"] for r in rules]
    assert len(rule_ids) == len(set(rule_ids)), "duplicate rule IDs found"


def test_sarif_export_rules_match_results() -> None:
    result = Toolbox().run("sarif_export", SAMPLE, _VR)
    run     = _run(result)
    rule_ids   = {r["id"] for r in run["tool"]["driver"]["rules"]}
    result_ids = {r["ruleId"] for r in run["results"]}
    assert result_ids.issubset(rule_ids)


# ── Status propagation ────────────────────────────────────────────────────────

def test_sarif_export_status_warning_for_structural_findings() -> None:
    result = Toolbox().run("sarif_export", SAMPLE, _VR)
    assert result.status == "warning"


def test_sarif_export_status_ok_for_clean_sbom() -> None:
    clean = {**SAMPLE, "nodes": [], "summary": {}}
    result = Toolbox().run("sarif_export", clean, _VR)
    assert result.status == "ok"


def test_sarif_export_status_failed_on_confirmed_cve() -> None:
    import unittest.mock as mock

    sbom = {
        **SAMPLE,
        "deps": [{"name": "lodash", "version_spec": "4.17.20",
                  "purl": "pkg:npm/lodash@4.17.20", "group": "runtime"}],
        "nodes": [], "summary": {},
    }
    _batch  = {"results": [{"vulns": [{"id": "GHSA-fake-HIGH"}]}]}
    _detail = {
        "id": "GHSA-fake-HIGH",
        "summary": "High severity vuln",
        "database_specific": {"severity": "HIGH"},
        "affected": [],
    }
    with (
        mock.patch("xelo_toolbox.osv_client._post_json", return_value=_batch),
        mock.patch("xelo_toolbox.osv_client._get_json",  return_value=_detail),
    ):
        result = Toolbox().run("sarif_export", sbom, {"provider": "osv"})
    assert result.status == "failed"


# ── Result shape ──────────────────────────────────────────────────────────────

def test_sarif_export_result_has_required_fields() -> None:
    sbom = {
        **SAMPLE,
        "nodes": [{"name": "gpt-4", "component_type": "MODEL", "metadata": {"extras": {}}}],
        "summary": {},
    }
    results = _run(Toolbox().run("sarif_export", sbom, _VR))["results"]
    assert results
    r = results[0]
    assert "ruleId" in r
    assert "level" in r
    assert "message" in r
    assert "locations" in r


def test_sarif_export_artifact_uri_uses_sbom_target() -> None:
    sbom = {
        **SAMPLE,
        "target": "my-app",
        "nodes": [{"name": "gpt-4", "component_type": "MODEL", "metadata": {"extras": {}}}],
        "summary": {},
    }
    results = _run(Toolbox().run("sarif_export", sbom, _VR))["results"]
    assert results
    uri = results[0]["locations"][0]["physicalLocation"]["artifactLocation"]["uri"]
    assert uri == "my-app"
