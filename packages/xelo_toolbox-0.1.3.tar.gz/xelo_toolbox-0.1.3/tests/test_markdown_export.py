from xelo_toolbox.core import Toolbox

SAMPLE = {
    "schema_version": "1.1.0",
    "generated_at": "2026-02-22T00:00:00Z",
    "generator": "vela",
    "target": "patient-portal",
    "nodes": [
        {
            "name": "gpt-4",
            "component_type": "MODEL",
            "confidence": 0.9,
            "metadata": {"extras": {"provider": "openai"}},
        },
        {
            "name": "datastore:sql:patients",
            "component_type": "DATASTORE",
            "confidence": 0.95,
            "metadata": {"extras": {"data_classification": ["PHI", "PII"]}},
        },
    ],
    "edges": [],
    "evidence": [],
    "deps": [
        {"name": "openai",    "version_spec": "1.0.0", "group": "ai",      "license": "MIT"},
        {"name": "langchain", "version_spec": "0.2.0", "group": "ai"},
        {"name": "requests",  "version_spec": "2.31.0", "group": "general"},
    ],
    "summary": {
        "use_case": "Patient portal API",
        "frameworks": ["langchain"],
        "data_classification": ["PHI", "PII"],
        "classified_tables": ["patients"],
        "node_counts": {"MODEL": 1, "DATASTORE": 1},
        "modalities": ["TEXT", "VOICE"],
    },
}


def _md(result: object) -> str:  # type: ignore[return]
    return result.details["markdown"]  # type: ignore[union-attr]


def test_markdown_export_runs() -> None:
    result = Toolbox().run("markdown_export", SAMPLE, {})
    assert result.status == "ok"
    assert "markdown" in result.details


def test_markdown_export_contains_target() -> None:
    md = _md(Toolbox().run("markdown_export", SAMPLE, {}))
    assert "patient-portal" in md


def test_markdown_export_contains_generated_at() -> None:
    md = _md(Toolbox().run("markdown_export", SAMPLE, {}))
    assert "2026-02-22" in md


def test_markdown_export_contains_nodes_section() -> None:
    md = _md(Toolbox().run("markdown_export", SAMPLE, {}))
    assert "## AI Components" in md
    assert "gpt-4" in md
    assert "MODEL" in md


def test_markdown_export_contains_deps_section() -> None:
    md = _md(Toolbox().run("markdown_export", SAMPLE, {}))
    assert "## Dependencies" in md
    assert "openai" in md
    assert "langchain" in md


def test_markdown_export_confidence_formatted_as_percent() -> None:
    md = _md(Toolbox().run("markdown_export", SAMPLE, {}))
    assert "90%" in md   # confidence 0.9
    assert "95%" in md   # confidence 0.95


def test_markdown_export_summary_fields() -> None:
    md = _md(Toolbox().run("markdown_export", SAMPLE, {}))
    assert "PHI" in md
    assert "Patient portal API" in md
    assert "langchain" in md
    assert "VOICE" in md


def test_markdown_export_node_type_breakdown() -> None:
    md = _md(Toolbox().run("markdown_export", SAMPLE, {}))
    assert "## Node Type Breakdown" in md
    assert "DATASTORE" in md


def test_markdown_export_empty_sbom() -> None:
    empty = {"target": "empty", "nodes": [], "deps": [], "summary": {}}
    result = Toolbox().run("markdown_export", empty, {})
    assert result.status == "ok"
    md = result.details["markdown"]
    assert "empty" in md
    assert "## AI Components" not in md
    assert "## Dependencies" not in md


def test_markdown_export_message_contains_counts() -> None:
    result = Toolbox().run("markdown_export", SAMPLE, {})
    assert "2 node(s)" in result.message
    assert "3 dep(s)" in result.message


def test_markdown_export_escapes_pipe_in_name() -> None:
    sbom = {
        **SAMPLE,
        "nodes": [
            {"name": "name|with|pipes", "component_type": "MODEL", "confidence": 0.8}
        ],
        "deps": [],
    }
    md = _md(Toolbox().run("markdown_export", sbom, {}))
    assert "name\\|with\\|pipes" in md


def test_markdown_export_no_breakdown_when_node_counts_absent() -> None:
    sbom = {**SAMPLE, "summary": {}}
    md = _md(Toolbox().run("markdown_export", sbom, {}))
    assert "## Node Type Breakdown" not in md
