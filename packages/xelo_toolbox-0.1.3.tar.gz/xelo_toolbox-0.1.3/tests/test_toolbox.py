from xelo_toolbox.core import Toolbox

SAMPLE = {
    "schema_version": "1.1.0",
    "generated_at": "2026-02-22T00:00:00Z",
    "generator": "vela",
    "target": "sample",
    "nodes": [
        {
            "name": "model:main.py",
            "component_type": "MODEL",
            "confidence": 0.9,
            "metadata": {"extras": {"license": "MIT"}},
        },
        {
            "name": "datastore:sql:patients",
            "component_type": "DATASTORE",
            "confidence": 0.95,
            "metadata": {
                "extras": {
                    "data_classification": ["PHI", "PII"],
                    "classified_fields": {"name": ["PII"], "medical_record_number": ["PHI", "PII"]},
                    "table_name": "patients",
                }
            },
        },
    ],
    "edges": [],
    "evidence": [],
    "deps": [
        {"name": "openai", "version": "1.0.0", "group": "ai"},
        {"name": "langchain", "version": "0.2.0", "group": "ai"},
        {"name": "requests", "version": "2.31.0", "group": "general"},
    ],
    "summary": {
        "use_case": "Patient portal API",
        "frameworks": ["langchain"],
        "data_classification": ["PHI", "PII"],
        "classified_tables": ["patients", "patient_history"],
        "node_counts": {"MODEL": 1, "DATASTORE": 1},
    },
}


# ---------------------------------------------------------------------------
# Dependency analysis
# ---------------------------------------------------------------------------

def test_dependency_analyzer_runs() -> None:
    result = Toolbox().run("dependency_analyze", SAMPLE, {})
    assert result.status == "ok"


def test_dependency_analyzer_counts_ai_nodes() -> None:
    result = Toolbox().run("dependency_analyze", SAMPLE, {})
    assert result.details["total_ai_nodes"] == 2


def test_dependency_analyzer_counts_package_deps() -> None:
    result = Toolbox().run("dependency_analyze", SAMPLE, {})
    assert result.details["total_package_deps"] == 3


def test_dependency_analyzer_breaks_down_dep_groups() -> None:
    result = Toolbox().run("dependency_analyze", SAMPLE, {})
    groups = result.details["package_dep_groups"]
    assert groups["ai"] == 2
    assert groups["general"] == 1


def test_dependency_analyzer_surfaces_node_counts_from_summary() -> None:
    result = Toolbox().run("dependency_analyze", SAMPLE, {})
    assert result.details["node_counts"] == {"MODEL": 1, "DATASTORE": 1}


def test_dependency_analyzer_empty_deps() -> None:
    sbom = {**SAMPLE, "deps": []}
    result = Toolbox().run("dependency_analyze", sbom, {})
    assert result.details["total_package_deps"] == 0
    assert result.details["package_dep_groups"] == {}


# ---------------------------------------------------------------------------
# License check
# ---------------------------------------------------------------------------

def test_license_checker_passes_when_no_violation() -> None:
    result = Toolbox().run("license_check", SAMPLE, {"deny": ["GPL-3.0"]})
    assert result.status == "ok"


def test_license_checker_fails_on_node_violation() -> None:
    sbom = {
        **SAMPLE,
        "nodes": [{"name": "foo", "component_type": "MODEL", "metadata": {"extras": {"license": "GPL-3.0"}}}],
    }
    result = Toolbox().run("license_check", sbom, {"deny": ["GPL-3.0"]})
    assert result.status == "failed"
    assert any(v["name"] == "foo" for v in result.details["violations"])


def test_license_checker_reports_counts() -> None:
    result = Toolbox().run("license_check", SAMPLE, {"deny": []})
    assert result.details["nodes_checked"] == 2
    assert result.details["deps_checked"] == 3


def test_license_checker_catches_dep_violation() -> None:
    sbom = {
        **SAMPLE,
        "deps": [{"name": "bad-lib", "version": "1.0.0", "group": "ai", "license": "GPL-3.0"}],
    }
    result = Toolbox().run("license_check", sbom, {"deny": ["GPL-3.0"]})
    assert result.status == "failed"
    viol = result.details["violations"]
    assert any(v["source"] == "dep" and v["name"] == "bad-lib" for v in viol)


# ---------------------------------------------------------------------------
# Vulnerability scan
# ---------------------------------------------------------------------------

def _finding_ids(result: object) -> set:
    return {f["rule_id"] for f in result.details["findings"]}  # type: ignore[union-attr]


_VR = {"provider": "vela-rules"}  # structural-only, no network


def test_vuln_scan_returns_findings_structure() -> None:
    result = Toolbox().run("vuln_scan", SAMPLE, _VR)
    assert "findings" in result.details
    assert "summary" in result.details
    assert isinstance(result.details["findings"], list)


def test_vuln_scan_structural_findings_produce_warning_not_failed() -> None:
    """Structural heuristics are advisory — they should produce warning, not failed."""
    sbom = {
        **SAMPLE,
        "nodes": [
            {"name": "gpt-4", "component_type": "MODEL",
             "metadata": {"extras": {"provider": "openai"}}},
            {"name": "datastore:sql:patients", "component_type": "DATASTORE",
             "metadata": {"extras": {"data_classification": ["PHI", "PII"]}}},
        ],
        "summary": {"data_classification": ["PHI", "PII"], "classified_tables": ["patients"]},
    }
    result = Toolbox().run("vuln_scan", sbom, _VR)
    assert result.status == "warning"          # structural → warning
    assert "VLA-001" in _finding_ids(result)   # no guardrails
    assert "VLA-002" in _finding_ids(result)   # PHI to external LLM


def test_vuln_scan_osv_high_produces_failed() -> None:
    """A confirmed HIGH CVE from OSV must flip status to failed."""
    import unittest.mock as mock
    sbom = {
        **SAMPLE,
        "deps": [{"name": "lodash", "version_spec": "4.17.20",
                  "purl": "pkg:npm/lodash@4.17.20", "group": "runtime",
                  "source_file": "package.json"}],
    }
    _batch = {"results": [{"vulns": [{"id": "GHSA-fake-HIGH", "modified": "2024-01-01T00:00:00Z"}]}]}
    _detail = {
        "id": "GHSA-fake-HIGH", "aliases": ["CVE-2024-9999"],
        "summary": "High severity vuln in lodash",
        "database_specific": {"severity": "HIGH"}, "affected": [],
    }
    with (
        mock.patch("xelo_toolbox.osv_client._post_json", return_value=_batch),
        mock.patch("xelo_toolbox.osv_client._get_json", return_value=_detail),
    ):
        result = Toolbox().run("vuln_scan", sbom, {"provider": "osv"})
    assert result.status == "failed"
    assert result.details["osv_ran"] is True


def test_vuln_scan_default_provider_is_all() -> None:
    """Default provider must run OSV so osv_ran is always True."""
    import unittest.mock as mock
    # SAMPLE deps have no purls → OSV skips network but osv_ran must still be True
    with mock.patch("xelo_toolbox.osv_client._post_json", return_value={"results": []}):
        result = Toolbox().run("vuln_scan", SAMPLE, {})
    assert result.details["osv_ran"] is True
    assert result.details["provider"] == "all"


def test_vuln_scan_vla001_no_guardrails() -> None:
    sbom = {
        **SAMPLE,
        "nodes": [{"name": "gpt-4", "component_type": "MODEL", "metadata": {"extras": {}}}],
        "summary": {},
    }
    result = Toolbox().run("vuln_scan", sbom, _VR)
    assert "VLA-001" in _finding_ids(result)


def test_vuln_scan_vla001_suppressed_when_guardrail_present() -> None:
    sbom = {
        **SAMPLE,
        "nodes": [
            {"name": "gpt-4", "component_type": "MODEL", "metadata": {"extras": {}}},
            {"name": "shield", "component_type": "GUARDRAIL", "metadata": {"extras": {}}},
        ],
        "summary": {},
    }
    result = Toolbox().run("vuln_scan", sbom, _VR)
    assert "VLA-001" not in _finding_ids(result)


def test_vuln_scan_vla002_phi_to_external_llm() -> None:
    sbom = {
        **SAMPLE,
        "nodes": [{"name": "claude-3", "component_type": "MODEL",
                   "metadata": {"extras": {"provider": "anthropic"}}}],
        "summary": {"data_classification": ["PHI"], "classified_tables": ["patients"]},
    }
    result = Toolbox().run("vuln_scan", sbom, _VR)
    assert "VLA-002" in _finding_ids(result)


def test_vuln_scan_vla004_privilege_no_guardrail() -> None:
    sbom = {
        **SAMPLE,
        "nodes": [{"name": "admin-tool", "component_type": "PRIVILEGE", "metadata": {"extras": {}}}],
        "summary": {},
    }
    result = Toolbox().run("vuln_scan", sbom, _VR)
    assert "VLA-004" in _finding_ids(result)


def test_vuln_scan_vla005_voice_with_phi() -> None:
    sbom = {
        **SAMPLE,
        "nodes": [{"name": "gemini", "component_type": "MODEL", "metadata": {"extras": {}}}],
        "summary": {"data_classification": ["PHI"], "classified_tables": ["patients"],
                    "modalities": ["VOICE", "TEXT"]},
    }
    result = Toolbox().run("vuln_scan", sbom, _VR)
    assert "VLA-005" in _finding_ids(result)


def test_vuln_scan_no_findings_on_clean_sbom() -> None:
    sbom = {**SAMPLE, "nodes": [], "summary": {"data_classification": [], "classified_tables": []}}
    result = Toolbox().run("vuln_scan", sbom, _VR)
    assert result.details["summary"]["total"] == 0
    assert result.status == "ok"


def test_vuln_scan_summary_counts_by_severity() -> None:
    result = Toolbox().run("vuln_scan", SAMPLE, _VR)
    s = result.details["summary"]
    assert "critical" in s and "high" in s and "medium" in s and "low" in s


def test_vuln_scan_vla001_policy_node_not_treated_as_guardrail() -> None:
    """POLICY was removed from ComponentType in schema 1.1.0; it must not suppress VLA-001."""
    sbom = {
        **SAMPLE,
        "nodes": [
            {"name": "gpt-4", "component_type": "MODEL", "metadata": {"extras": {}}},
            {"name": "policy-node", "component_type": "POLICY", "metadata": {"extras": {}}},
        ],
        "summary": {},
    }
    result = Toolbox().run("vuln_scan", sbom, _VR)
    assert "VLA-001" in _finding_ids(result)


def test_dependency_analyzer_counts_new_schema_types() -> None:
    """FRAMEWORK, TOOL, API_ENDPOINT, DEPLOYMENT are valid types in schema 1.1.0."""
    sbom = {
        **SAMPLE,
        "nodes": [
            {"name": "langchain", "component_type": "FRAMEWORK", "confidence": 0.9},
            {"name": "search-tool", "component_type": "TOOL", "confidence": 0.8},
            {"name": "/chat", "component_type": "API_ENDPOINT", "confidence": 1.0},
            {"name": "lambda-fn", "component_type": "DEPLOYMENT", "confidence": 0.7},
        ],
        "summary": {},
    }
    result = Toolbox().run("dependency_analyze", sbom, {})
    counts = result.details["ai_component_counts"]
    assert counts["FRAMEWORK"] == 1
    assert counts["TOOL"] == 1
    assert counts["API_ENDPOINT"] == 1
    assert counts["DEPLOYMENT"] == 1
