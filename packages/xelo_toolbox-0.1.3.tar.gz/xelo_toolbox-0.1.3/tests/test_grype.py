"""Tests for the Grype client and Grype-backed vulnerability scan.

All tests mock subprocess calls so they run without grype installed.
"""
from __future__ import annotations

import json
import subprocess
import unittest.mock as mock
from typing import Any


from xelo_toolbox.core import Toolbox
from xelo_toolbox.grype_client import (
    _match_to_finding,
    query_grype_sbom,
    query_grype_images,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

_SBOM: dict[str, Any] = {
    "schema_version": "1.1.0",
    "generated_at":   "2026-02-24T00:00:00Z",
    "target":         "sample",
    "nodes":          [],
    "edges":          [],
    "evidence":       [],
    "deps": [
        {"name": "lodash", "version_spec": "4.17.20",
         "purl": "pkg:npm/lodash@4.17.20", "group": "runtime",
         "source_file": "package.json"},
    ],
    "summary": {"data_classification": [], "classified_tables": []},
}

_CONTAINER_NODES: list[dict[str, Any]] = [
    {
        "name": "python:3.12-slim",
        "component_type": "CONTAINER_IMAGE",
        "metadata": {
            "base_image":  "python:3.12-slim",
            "image_name":  "python",
            "image_tag":   "3.12-slim",
            "registry":    "docker.io",
        },
    }
]

_GRYPE_MATCH: dict[str, Any] = {
    "vulnerability": {
        "id":          "GHSA-fake-grype-0001",
        "severity":    "High",
        "description": "Prototype pollution in lodash",
        "dataSource":  "https://github.com/advisories/GHSA-fake-grype-0001",
        "fix":         {"versions": ["4.17.21"], "state": "fixed"},
    },
    "relatedVulnerabilities": [{"id": "CVE-2024-88888"}],
    "artifact": {
        "name":    "lodash",
        "version": "4.17.20",
        "type":    "npm",
        "purl":    "pkg:npm/lodash@4.17.20",
    },
}

_GRYPE_OUTPUT: dict[str, Any] = {
    "matches": [_GRYPE_MATCH],
    "source":  {"type": "sbom"},
    "distro":  {},
}


# ---------------------------------------------------------------------------
# Unit tests for grype_client helpers
# ---------------------------------------------------------------------------

class TestMatchToFinding:
    def test_extracts_advisory_id(self) -> None:
        f = _match_to_finding(_GRYPE_MATCH, "sbom")
        assert f["advisory_id"] == "GHSA-fake-grype-0001"

    def test_severity_normalized_to_upper(self) -> None:
        f = _match_to_finding(_GRYPE_MATCH, "sbom")
        assert f["severity"] == "HIGH"

    def test_extracts_cve_aliases(self) -> None:
        f = _match_to_finding(_GRYPE_MATCH, "sbom")
        assert "CVE-2024-88888" in f["cve_ids"]

    def test_dep_name_and_version(self) -> None:
        f = _match_to_finding(_GRYPE_MATCH, "sbom")
        assert f["dep_name"] == "lodash"
        assert f["dep_version"] == "4.17.20"

    def test_fix_version_in_affected(self) -> None:
        f = _match_to_finding(_GRYPE_MATCH, "sbom")
        assert "<4.17.21" in f["affected_versions"]

    def test_source_is_grype(self) -> None:
        f = _match_to_finding(_GRYPE_MATCH, "sbom")
        assert f["source"] == "grype"

    def test_scan_target_recorded(self) -> None:
        f = _match_to_finding(_GRYPE_MATCH, "python:3.12-slim")
        assert f["scan_target"] == "python:3.12-slim"

    def test_negligible_maps_to_low(self) -> None:
        match = dict(_GRYPE_MATCH)
        match["vulnerability"] = {**_GRYPE_MATCH["vulnerability"], "severity": "Negligible"}
        f = _match_to_finding(match, "sbom")
        assert f["severity"] == "LOW"

    def test_unknown_severity_fallback(self) -> None:
        match = dict(_GRYPE_MATCH)
        match["vulnerability"] = {**_GRYPE_MATCH["vulnerability"], "severity": "Banana"}
        f = _match_to_finding(match, "sbom")
        assert f["severity"] == "UNKNOWN"


# ---------------------------------------------------------------------------
# query_grype_sbom — mocked subprocess
# ---------------------------------------------------------------------------

class TestQueryGrypeSbom:
    def _mock_run(self, output: dict[str, Any]):
        """Return a mock that simulates a successful grype subprocess call."""
        proc = mock.MagicMock()
        proc.returncode = 0
        proc.stdout = json.dumps(output).encode()
        proc.stderr = b""
        return proc

    def test_returns_findings_when_grype_finds_vulns(self) -> None:
        with (
            mock.patch("xelo_toolbox.grype_client._grype_path", return_value="/usr/bin/grype"),
            mock.patch("subprocess.run", return_value=self._mock_run(_GRYPE_OUTPUT)),
        ):
            results = query_grype_sbom(_SBOM)
        assert len(results) == 1
        assert results[0]["advisory_id"] == "GHSA-fake-grype-0001"

    def test_returns_empty_when_grype_not_installed(self) -> None:
        with mock.patch("xelo_toolbox.grype_client._grype_path", return_value=None):
            assert query_grype_sbom(_SBOM) == []

    def test_returns_empty_on_subprocess_error(self) -> None:
        with (
            mock.patch("xelo_toolbox.grype_client._grype_path", return_value="/usr/bin/grype"),
            mock.patch("subprocess.run", side_effect=OSError("exec failed")),
        ):
            assert query_grype_sbom(_SBOM) == []

    def test_returns_empty_on_timeout(self) -> None:
        with (
            mock.patch("xelo_toolbox.grype_client._grype_path", return_value="/usr/bin/grype"),
            mock.patch("subprocess.run",
                       side_effect=subprocess.TimeoutExpired(cmd="grype", timeout=60)),
        ):
            assert query_grype_sbom(_SBOM) == []

    def test_returns_empty_on_bad_json(self) -> None:
        proc = mock.MagicMock()
        proc.returncode = 0
        proc.stdout = b"not json"
        proc.stderr = b""
        with (
            mock.patch("xelo_toolbox.grype_client._grype_path", return_value="/usr/bin/grype"),
            mock.patch("subprocess.run", return_value=proc),
        ):
            assert query_grype_sbom(_SBOM) == []

    def test_empty_matches_returns_empty(self) -> None:
        with (
            mock.patch("xelo_toolbox.grype_client._grype_path", return_value="/usr/bin/grype"),
            mock.patch("subprocess.run",
                       return_value=self._mock_run({"matches": [], "source": {}})),
        ):
            assert query_grype_sbom(_SBOM) == []


# ---------------------------------------------------------------------------
# query_grype_images — container image scanning
# ---------------------------------------------------------------------------

class TestQueryGrypeImages:
    def _mock_run(self, output: dict[str, Any]):
        proc = mock.MagicMock()
        proc.returncode = 0
        proc.stdout = json.dumps(output).encode()
        proc.stderr = b""
        return proc

    def test_scans_container_nodes(self) -> None:
        with (
            mock.patch("xelo_toolbox.grype_client._grype_path", return_value="/usr/bin/grype"),
            mock.patch("subprocess.run",
                       return_value=self._mock_run(_GRYPE_OUTPUT)),
        ):
            results = query_grype_images(_CONTAINER_NODES)
        assert len(results) == 1
        assert results[0]["scan_target"] == "python:3.12-slim"

    def test_empty_when_no_container_nodes(self) -> None:
        with mock.patch("xelo_toolbox.grype_client._grype_path", return_value="/usr/bin/grype"):
            assert query_grype_images([]) == []

    def test_empty_when_grype_not_installed(self) -> None:
        with mock.patch("xelo_toolbox.grype_client._grype_path", return_value=None):
            assert query_grype_images(_CONTAINER_NODES) == []

    def test_uses_base_image_from_metadata(self) -> None:
        """Should call grype with the base_image reference."""
        calls: list[str] = []

        def fake_run(cmd, **_):
            calls.append(cmd[1])  # second arg is the target
            proc = mock.MagicMock()
            proc.returncode = 0
            proc.stdout = json.dumps({"matches": []}).encode()
            proc.stderr = b""
            return proc

        with (
            mock.patch("xelo_toolbox.grype_client._grype_path", return_value="/usr/bin/grype"),
            mock.patch("subprocess.run", side_effect=fake_run),
        ):
            query_grype_images(_CONTAINER_NODES)

        assert any("python:3.12-slim" in c for c in calls)

    def test_deduplicates_identical_image_refs(self) -> None:
        """Two nodes with the same base_image should only produce one grype call."""
        dupe_nodes = _CONTAINER_NODES * 2
        call_count = 0

        def fake_run(cmd, **_):
            nonlocal call_count
            call_count += 1
            proc = mock.MagicMock()
            proc.returncode = 0
            proc.stdout = json.dumps({"matches": []}).encode()
            proc.stderr = b""
            return proc

        with (
            mock.patch("xelo_toolbox.grype_client._grype_path", return_value="/usr/bin/grype"),
            mock.patch("subprocess.run", side_effect=fake_run),
        ):
            query_grype_images(dupe_nodes)

        assert call_count == 1


# ---------------------------------------------------------------------------
# VulnerabilityScannerPlugin with Grype provider
# ---------------------------------------------------------------------------

_GR = {"provider": "grype"}


class TestVulnScanGrypeProvider:
    def _mock_grype(self, findings=None):
        return mock.patch(
            "xelo_toolbox.grype_client.query_grype_sbom",
            return_value=findings or [],
        )

    def test_grype_ran_flag_false_for_vela_rules(self) -> None:
        result = Toolbox().run("vuln_scan", _SBOM, {"provider": "vela-rules"})
        assert result.details["grype_ran"] is False

    def test_grype_ran_flag_true_for_grype_provider(self) -> None:
        with (
            mock.patch("xelo_toolbox.grype_client._grype_path", return_value=None),
        ):
            result = Toolbox().run("vuln_scan", _SBOM, _GR)
        assert result.details["grype_ran"] is True

    def test_grype_high_produces_failed_status(self) -> None:
        grype_result = [{
            "dep_name": "lodash", "dep_version": "4.17.20",
            "purl": "pkg:npm/lodash@4.17.20",
            "advisory_id": "GHSA-fake-grype-0001",
            "cve_ids": ["CVE-2024-88888"],
            "summary": "Prototype pollution",
            "severity": "HIGH",
            "affected_versions": "<4.17.21",
            "url": "https://osv.dev/vulnerability/GHSA-fake-grype-0001",
            "source": "grype",
            "scan_target": "sbom",
        }]
        with (
            mock.patch("xelo_toolbox.grype_client._grype_path", return_value="/usr/bin/grype"),
            mock.patch("xelo_toolbox.grype_client.query_grype_sbom", return_value=grype_result),
            mock.patch("xelo_toolbox.grype_client.query_grype_images", return_value=[]),
        ):
            result = Toolbox().run("vuln_scan", _SBOM, _GR)
        assert result.status == "failed"

    def test_grype_findings_have_source_grype(self) -> None:
        grype_result = [{
            "dep_name": "express", "dep_version": "4.18.0",
            "purl": "pkg:npm/express@4.18.0",
            "advisory_id": "GHSA-fake-grype-0002",
            "cve_ids": [],
            "summary": "ReDoS",
            "severity": "MEDIUM",
            "affected_versions": "<4.18.3",
            "url": "https://osv.dev/vulnerability/GHSA-fake-grype-0002",
            "source": "grype",
            "scan_target": "sbom",
        }]
        with (
            mock.patch("xelo_toolbox.grype_client._grype_path", return_value="/usr/bin/grype"),
            mock.patch("xelo_toolbox.grype_client.query_grype_sbom", return_value=grype_result),
            mock.patch("xelo_toolbox.grype_client.query_grype_images", return_value=[]),
        ):
            result = Toolbox().run("vuln_scan", _SBOM, _GR)

        grype_findings = [f for f in result.details["findings"] if f.get("source") == "grype"]
        assert len(grype_findings) == 1

    def test_grype_network_failure_does_not_crash(self) -> None:
        with (
            mock.patch("xelo_toolbox.grype_client._grype_path", return_value="/usr/bin/grype"),
            mock.patch("xelo_toolbox.grype_client.query_grype_sbom", return_value=[]),
            mock.patch("xelo_toolbox.grype_client.query_grype_images", return_value=[]),
        ):
            result = Toolbox().run("vuln_scan", _SBOM, _GR)
        assert result.details["grype_ran"] is True

    def test_grype_ran_flag_in_all_provider(self) -> None:
        """provider=all must set both osv_ran and grype_ran to True."""
        with (
            mock.patch("xelo_toolbox.osv_client._post_json",
                       return_value={"results": [{"vulns": []}]}),
            mock.patch("xelo_toolbox.grype_client._grype_path", return_value=None),
        ):
            result = Toolbox().run("vuln_scan", _SBOM, {"provider": "all"})
        assert result.details["osv_ran"] is True
        assert result.details["grype_ran"] is True

    def test_container_image_nodes_trigger_image_scan(self) -> None:
        """CONTAINER_IMAGE nodes in the SBOM should cause image scanning."""
        sbom_with_containers = {
            **_SBOM,
            "nodes": _CONTAINER_NODES,
        }
        image_scan_called = False

        def fake_image_scan(nodes, **_):
            nonlocal image_scan_called
            image_scan_called = True
            return []

        with (
            mock.patch("xelo_toolbox.grype_client._grype_path", return_value="/usr/bin/grype"),
            mock.patch("xelo_toolbox.grype_client.query_grype_sbom", return_value=[]),
            mock.patch("xelo_toolbox.grype_client.query_grype_images",
                       side_effect=fake_image_scan),
        ):
            Toolbox().run("vuln_scan", sbom_with_containers, _GR)

        assert image_scan_called
