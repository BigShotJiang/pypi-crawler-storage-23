"""Tests for the OSV client and OSV-backed vuln scan / CycloneDX export."""
from __future__ import annotations

import unittest.mock as mock
from typing import Any


from xelo_toolbox.core import Toolbox
from xelo_toolbox.osv_client import (
    _severity_from_detail,
    _cve_aliases,
    _affected_versions,
    query_osv,
)

# ---------------------------------------------------------------------------
# Helper fixtures
# ---------------------------------------------------------------------------

_DEPS_WITH_PURLS = [
    {"name": "lodash", "version_spec": "4.17.20",
     "purl": "pkg:npm/lodash@4.17.20", "group": "runtime", "source_file": "package.json"},
    {"name": "express", "version_spec": "4.18.2",
     "purl": "pkg:npm/express@4.18.2", "group": "runtime", "source_file": "package.json"},
]

_OSV_VULN_DETAIL = {
    "id": "GHSA-fake-0001-1234",
    "aliases": ["CVE-2024-99999"],
    "summary": "Prototype pollution in lodash",
    "severity": [{"type": "CVSS_V3",
                  "score": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H"}],
    "database_specific": {"severity": "CRITICAL"},
    "affected": [{"package": {"name": "lodash", "ecosystem": "npm"},
                  "ranges": [{"type": "SEMVER",
                               "events": [{"introduced": "0.0.0"},
                                          {"fixed": "4.17.21"}]}]}],
}

_OSV_VULN_DETAIL_MODERATE = {
    "id": "GHSA-fake-0002-5678",
    "aliases": [],
    "summary": "ReDoS in express",
    "severity": [{"type": "CVSS_V3",
                  "score": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:N/A:L"}],
    "database_specific": {"severity": "MODERATE"},
    "affected": [{"package": {"name": "express", "ecosystem": "npm"},
                  "ranges": [{"type": "SEMVER",
                               "events": [{"introduced": "4.0.0"},
                                          {"fixed": "4.18.3"}]}]}],
}

_BATCH_RESPONSE = {
    "results": [
        {"vulns": [{"id": "GHSA-fake-0001-1234", "modified": "2024-01-01T00:00:00Z"}]},
        {"vulns": [{"id": "GHSA-fake-0002-5678", "modified": "2024-01-01T00:00:00Z"}]},
    ]
}


# ---------------------------------------------------------------------------
# Unit tests for osv_client helpers
# ---------------------------------------------------------------------------

class TestSeverityFromDetail:
    def test_critical_from_database_specific(self) -> None:
        assert _severity_from_detail({"database_specific": {"severity": "CRITICAL"}}) == "CRITICAL"

    def test_moderate_maps_to_medium(self) -> None:
        assert _severity_from_detail({"database_specific": {"severity": "MODERATE"}}) == "MEDIUM"

    def test_high_from_database_specific(self) -> None:
        assert _severity_from_detail({"database_specific": {"severity": "high"}}) == "HIGH"

    def test_falls_back_to_cvss_vector(self) -> None:
        detail = {
            "severity": [{"type": "CVSS_V3",
                           "score": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H"}],
        }
        assert _severity_from_detail(detail) == "CRITICAL"

    def test_medium_from_cvss_partial_impact(self) -> None:
        detail = {
            "severity": [{"type": "CVSS_V3",
                           "score": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:N/A:L"}],
        }
        result = _severity_from_detail(detail)
        assert result in ("MEDIUM", "LOW")

    def test_unknown_when_no_data(self) -> None:
        assert _severity_from_detail({}) == "UNKNOWN"


class TestCveAliases:
    def test_extracts_cve(self) -> None:
        assert _cve_aliases({"aliases": ["CVE-2024-1234", "GHSA-xxxx"]}) == ["CVE-2024-1234"]

    def test_empty_when_no_cve(self) -> None:
        assert _cve_aliases({"aliases": ["GHSA-xxxx"]}) == []

    def test_empty_aliases(self) -> None:
        assert _cve_aliases({}) == []


class TestAffectedVersions:
    def test_introduced_and_fixed(self) -> None:
        detail = {"affected": [{"ranges": [{"type": "SEMVER",
                                             "events": [{"introduced": "1.0.0"},
                                                        {"fixed": "1.2.0"}]}]}]}
        result = _affected_versions(detail)
        assert ">=1.0.0" in result
        assert "<1.2.0" in result

    def test_no_ranges(self) -> None:
        assert _affected_versions({}) == "see advisory"


# ---------------------------------------------------------------------------
# Integration: query_osv with mocked HTTP
# ---------------------------------------------------------------------------

def _make_post_side_effect(batch_resp: dict[str, Any]) -> Any:
    def side_effect(url: str, body: dict[str, Any], timeout: float = 15.0) -> dict[str, Any]:
        return batch_resp
    return side_effect


def _make_get_side_effect(*details: dict[str, Any]) -> Any:
    detail_iter = iter(details)
    def side_effect(url: str, timeout: float = 15.0) -> dict[str, Any]:
        return next(detail_iter)
    return side_effect


class TestQueryOsv:
    def test_returns_findings_for_vulnerable_deps(self) -> None:
        with (
            mock.patch("xelo_toolbox.osv_client._post_json",
                       side_effect=_make_post_side_effect(_BATCH_RESPONSE)),
            mock.patch("xelo_toolbox.osv_client._get_json",
                       side_effect=_make_get_side_effect(
                           _OSV_VULN_DETAIL, _OSV_VULN_DETAIL_MODERATE)),
        ):
            results = query_osv(_DEPS_WITH_PURLS)

        assert len(results) == 2
        crit = next(r for r in results if r["advisory_id"] == "GHSA-fake-0001-1234")
        assert crit["severity"] == "CRITICAL"
        assert crit["dep_name"] == "lodash"
        assert "CVE-2024-99999" in crit["cve_ids"]
        assert "osv.dev" in crit["url"]

    def test_empty_when_no_vulns(self) -> None:
        with mock.patch("xelo_toolbox.osv_client._post_json",
                        return_value={"results": [{"vulns": []}, {"vulns": []}]}):
            assert query_osv(_DEPS_WITH_PURLS) == []

    def test_graceful_on_network_error(self) -> None:
        with mock.patch("xelo_toolbox.osv_client._post_json",
                        side_effect=OSError("connection refused")):
            assert query_osv(_DEPS_WITH_PURLS) == []

    def test_graceful_on_detail_fetch_error(self) -> None:
        with (
            mock.patch("xelo_toolbox.osv_client._post_json",
                       side_effect=_make_post_side_effect(_BATCH_RESPONSE)),
            mock.patch("xelo_toolbox.osv_client._get_json",
                       side_effect=OSError("timeout")),
        ):
            results = query_osv(_DEPS_WITH_PURLS)
        # Should still return stubs even without detail
        assert len(results) == 2

    def test_empty_when_no_purls(self) -> None:
        assert query_osv([{"name": "foo", "version_spec": "1.0.0"}]) == []


# ---------------------------------------------------------------------------
# VulnerabilityScannerPlugin with OSV provider
# ---------------------------------------------------------------------------

_SBOM_WITH_DEPS: dict[str, Any] = {
    "schema_version": "1.1.0",
    "generated_at": "2026-02-24T00:00:00Z",
    "target": "sample",
    "nodes": [],
    "edges": [],
    "evidence": [],
    "deps": _DEPS_WITH_PURLS,
    "summary": {"data_classification": [], "classified_tables": []},
}


class TestVulnScanOsvProvider:
    def test_osv_ran_flag_false_for_vela_rules_provider(self) -> None:
        result = Toolbox().run("vuln_scan", _SBOM_WITH_DEPS, {"provider": "vela-rules"})
        assert result.details["osv_ran"] is False

    def test_osv_ran_flag_true_for_osv_provider(self) -> None:
        with (
            mock.patch("xelo_toolbox.osv_client._post_json",
                       return_value={"results": [{"vulns": []}, {"vulns": []}]}),
        ):
            result = Toolbox().run("vuln_scan", _SBOM_WITH_DEPS, {"provider": "osv"})
        assert result.details["osv_ran"] is True

    def test_dep_advisories_reported_in_summary(self) -> None:
        with (
            mock.patch("xelo_toolbox.osv_client._post_json",
                       side_effect=_make_post_side_effect(_BATCH_RESPONSE)),
            mock.patch("xelo_toolbox.osv_client._get_json",
                       side_effect=_make_get_side_effect(
                           _OSV_VULN_DETAIL, _OSV_VULN_DETAIL_MODERATE)),
        ):
            result = Toolbox().run("vuln_scan", _SBOM_WITH_DEPS, {"provider": "osv"})

        assert result.details["summary"]["dep_advisories"] == 2
        advisory_ids = {f["rule_id"] for f in result.details["findings"]}
        assert "GHSA-fake-0001-1234" in advisory_ids

    def test_dep_findings_have_source_osv(self) -> None:
        with (
            mock.patch("xelo_toolbox.osv_client._post_json",
                       side_effect=_make_post_side_effect(_BATCH_RESPONSE)),
            mock.patch("xelo_toolbox.osv_client._get_json",
                       side_effect=_make_get_side_effect(
                           _OSV_VULN_DETAIL, _OSV_VULN_DETAIL_MODERATE)),
        ):
            result = Toolbox().run("vuln_scan", _SBOM_WITH_DEPS, {"provider": "osv"})

        osv_findings = [f for f in result.details["findings"] if f.get("source") == "osv"]
        assert len(osv_findings) == 2

    def test_osv_network_failure_does_not_crash_scan(self) -> None:
        with mock.patch("xelo_toolbox.osv_client._post_json",
                        side_effect=OSError("network unreachable")):
            result = Toolbox().run("vuln_scan", _SBOM_WITH_DEPS, {"provider": "osv"})
        assert result.details["osv_ran"] is True
        assert result.details["summary"]["dep_advisories"] == 0


# ---------------------------------------------------------------------------
# CycloneDX export with include_vulnerabilities
# ---------------------------------------------------------------------------

class TestCycloneDxVex:
    def test_no_vulnerabilities_key_by_default(self) -> None:
        result = Toolbox().run("cyclonedx_export", _SBOM_WITH_DEPS, {})
        assert "vulnerabilities" not in result.details

    def test_vulnerabilities_key_present_with_flag(self) -> None:
        with (
            mock.patch("xelo_toolbox.osv_client._post_json",
                       side_effect=_make_post_side_effect(_BATCH_RESPONSE)),
            mock.patch("xelo_toolbox.osv_client._get_json",
                       side_effect=_make_get_side_effect(
                           _OSV_VULN_DETAIL, _OSV_VULN_DETAIL_MODERATE)),
        ):
            result = Toolbox().run("cyclonedx_export", _SBOM_WITH_DEPS, {
                "include_vulnerabilities": True, "provider": "osv",
            })

        assert "vulnerabilities" in result.details
        vuln_ids = {v["id"] for v in result.details["vulnerabilities"]}
        assert "GHSA-fake-0001-1234" in vuln_ids

    def test_vex_entry_has_required_fields(self) -> None:
        with (
            mock.patch("xelo_toolbox.osv_client._post_json",
                       side_effect=_make_post_side_effect(
                           {"results": [{"vulns": [{"id": "GHSA-fake-0001-1234",
                                                     "modified": "2024-01-01T00:00:00Z"}]},
                                        {"vulns": []}]})),
            mock.patch("xelo_toolbox.osv_client._get_json",
                       return_value=_OSV_VULN_DETAIL),
        ):
            result = Toolbox().run("cyclonedx_export", _SBOM_WITH_DEPS, {
                "include_vulnerabilities": True, "provider": "osv",
            })

        vuln = result.details["vulnerabilities"][0]
        assert "id" in vuln
        assert "source" in vuln
        assert "ratings" in vuln
        assert "affects" in vuln
        assert "recommendation" in vuln
