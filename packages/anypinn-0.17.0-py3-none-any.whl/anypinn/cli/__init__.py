"""CLI for anypinn."""

from anypinn.cli.app import app

__all__ = ["app"]
