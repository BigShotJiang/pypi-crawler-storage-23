from django.db import models
from allianceauth.eveonline.models import EveCharacter
from eveuniverse.models import EveSolarSystem



# Create your models here.
class FilterEntity(models.Model):
    '''
        Таблица для хранения данных фильтров киллмэйлов
    '''
    ALLIANCE = 'alliance'
    CORPORATION = 'corporation'
    CHARACTER = 'character'
    ENTITY_TYPE_CHOICE = [
        (ALLIANCE,'Alliance'),
        (CORPORATION,'Corporation'),
        (CHARACTER,'Character')
    ]
    
    entity_type = models.CharField(max_length=20, choices=ENTITY_TYPE_CHOICE)
    entity_id = models.IntegerField(
        name='entity_id',
        null=False,
        blank=False,
        unique=True
    )
    added_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        indexes = [
            models.Index(fields=['entity_type']),
        ]
        unique_together = [('entity_type', 'entity_id')]
    def __str__(self):
        if self.entity_type == self.ALLIANCE:
            return f"Alliance: {self.entity_id}"
        elif self.entity_type == self.CORPORATION:
            return f"Corporation: {self.entity_id}"
        return f"Character: {self.entity_id}"
    
class KillCompensation(models.Model):
    '''
        Таблица для хранения киллмэйлов, дополнительных данных и статуса компенсации
    '''
    STATUS_NEW = "N"
    STATUS_COMPLETE = "C"
    STATUS_REJECT = "R"
    STATUS_CHOICES = [
        (STATUS_NEW,"Новый"),
        (STATUS_COMPLETE,"Компенсирован"),
        (STATUS_REJECT,"Отклонен")
    ]
    
    TYPE_CTA = 'C'
    TYPE_HOMEDEF = 'H'
    TYPE_OTHER = 'O'
    ACTIVITY_TYPE = [
        (TYPE_CTA,'Call To Arms'),
        (TYPE_HOMEDEF,'Home defence'),
        (TYPE_OTHER, 'Other')
    ]

    killmail_id = models.PositiveBigIntegerField(unique=True)
    hash = models.CharField(max_length=255,null=True)
    character_id = models.PositiveIntegerField()
    character_name = models.TextField(max_length=255,null=True,blank=True)
    alliance_id = models.PositiveIntegerField(null=True,blank=True)
    alliance_name = models.TextField(max_length=255,null=True,blank=True)
    corporation_id = models.PositiveIntegerField(null=True,blank=True)
    corporation_name = models.TextField(max_length=255,null=True,blank=True)
    loss_value = models.PositiveBigIntegerField()
    timestamp = models.DateTimeField(auto_now=False)
    activity_type = models.CharField(choices= ACTIVITY_TYPE,max_length=10, default=TYPE_CTA)
    
    # Используем существующие модели AllianceAuth
    ship_type = models.PositiveBigIntegerField(null=False)
    ship_name = models.TextField(null=False,blank=True)
    system = models.PositiveBigIntegerField(null=False)
    system_name = models.TextField(null=True,blank=True)
    
    status = models.CharField(
        max_length=1, 
        choices=STATUS_CHOICES, 
        default=STATUS_NEW,
        db_index=True
    )
    created_at = models.DateTimeField(auto_now_add=True)
    comment = models.TextField(blank=True)
    
    
    
    class Meta:
        ordering = ['-timestamp']
        indexes = [
            models.Index(fields=['status', 'timestamp']),
        ]

    def __str__(self):
        return f"Kill #{self.killmail_id} {self.character_name} {self.alliance_name} {self.system_name} {self.get_activity_type_display()} {self.get_status_display()}"
    def SolarSystem(self):
        return EveSolarSystem.objects.get(id=self.system)
    def EveCharacter(self):
        return EveCharacter.objects.get(id=self.character_id)
    
class BattleReport(models.Model):
    '''
        Таблица для хранения ссылок на киллмэйлы и баттл репорыт. Также содержит статус обработки.
    '''
    BATTLEREPORT = 'br'
    KILLMAIL = 'kill'
    REPORT_TYPE=[
        (BATTLEREPORT,'Battle report'),
        (KILLMAIL,'Kill Mail')
    ]
    PROCESS_NEW = 'N'
    PROCESS_PROCESSING = 'P'
    PROCESS_COMPLETE = 'C'
    PROCESS_FAILED = 'F'
    PROCESS_REINITIALIZE = 'R'
    PROCESS_STATUS = [
        (PROCESS_NEW, 'New'),
        (PROCESS_PROCESSING,'Process'),
        (PROCESS_COMPLETE,'Complete'),
        (PROCESS_FAILED,'Failed'),
        (PROCESS_REINITIALIZE,'Reinitialize')
    ]
    
    source_id = models.PositiveIntegerField(null=True,default=None)
    report_id = models.AutoField(primary_key=True)
    link = models.TextField(max_length=255,null=False)
    added_at = models.DateTimeField(auto_now=True)
    comment = models.TextField(null=True,blank=True)
    updatedAt = models.DateTimeField(null=True,blank=True)
    status = models.CharField(choices=PROCESS_STATUS, max_length=10, default=PROCESS_NEW)
    report_type = models.CharField(choices=REPORT_TYPE, max_length=8, default=BATTLEREPORT)
    
    class Meta:
        indexes = [
            models.Index(fields=['report_id'])
        ]
    def __str__(self):
        return f"Report link {self.link} ({self.get_report_type_display()}) { self.get_status_display()}"
    def uid(self)->str:
        '''
            id ссылки
        '''
        return   self.link.split("/")[-2] if self.link.endswith('/') else self.link.split("/")[-1]
    
    
class CharMailParse(models.Model):
    '''
        Таблица для хранения списка персонажей, чью почту будет обрабатывать автомат и искать киллмеэлы
    '''
    character_id = models.PositiveBigIntegerField(null=False)
    lastmail_id = models.PositiveBigIntegerField(null=True,blank=True)
    updated_at = models.DateTimeField(null=True,blank=True)
    
    class Meta:
        indexes = [
            models.Index(fields=['character_id'])
        ]