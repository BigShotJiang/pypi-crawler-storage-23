# SPDX-FileCopyrightText: 2026 Laurent Modolo <laurent.modolo@cnrs.fr>, Lauryn Trouillot <lauryn.trouillot@ens-lyon.fr>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

# This is the main script of the programm that parse the command line argument
# and execute the function from classifier.py

import logging
import os

import matplotlib.pyplot as plt
import numpy as np
import rich_click as click

from . import classifier, find_parameters, read_bam, sample_size, write_bam


@click.command()
@click.option(
    "--bam_input",
    "-i",
    help="Path to the BAM file. Uses less memory if it's sorted",
    required=True,
)
@click.option(
    "--outdir",
    "-o",
    help="Path to the directory where the outputs will be stored",
    required=True,
)
@click.option(
    "--n_pairs",
    help="Number of pairs used to define the classifier parameters",
    required=True,
    type=int,
)
@click.option(
    "--means",
    "-M",
    help="A list of expected means (space-separated, e.g. '110 150 250 300')",
    required=True,
    type=str,
)
@click.option(
    "--verbose",
    "-v",
    help="Increase verbosity level, accumulate v to increase verbosity levels",
    count=True,
)
@click.option(
    "--min_length",
    "--min",
    help="Filtering reads inferior to min",
    required=True,
    type=int,
)
@click.option(
    "--max_length",
    "--max",
    help="Filtering reads superior to max",
    required=True,
    type=int,
)
def main(
    bam_input: str,
    outdir: str,
    n_pairs: int,
    means: str,
    min_length: int,
    max_length: int,
    verbose: int,
):
    """mnase_classifier segments paired-end sequencing data from MNase
    experiments into distinct groups based on insert size distributions.

    It estimates parameters for a Gaussian mixture model, classifies read
    pairs, and writes grouped BAM files for downstream chromatin analysis.

    To limit the use of computer resources, a bam sorted by name is strongly
    recommended.

    Parameters
    ----------
    bam_input : str
        Path to the input file
    outdir : str
        Path to the output directory
    n_pairs : int
        Number of pairs reads for `sample_size` function
    means : str
        A list of expected means (space-separated, e.g. '110 150 250 300')
    min_length : int
        Minimum read length filter
    max_length : int
        Maximum read length filter
    verbose : int
        Verbosity level (0=WARNING, 1=INFO, 2+=DEBUG)
    """
    if verbose == 0:
        level = logging.WARNING
    elif verbose == 1:
        level = logging.INFO
    else:
        level = logging.DEBUG

    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%H:%M:%S",
    )

    # Stop displaying matplotlib errors
    logging.getLogger("matplotlib").setLevel(logging.WARNING)
    logging.getLogger("matplotlib.font_manager").setLevel(logging.WARNING)

    print("Hello from mnase-classifier!")

    os.makedirs(outdir, exist_ok=True)

    means_np = np.array([int(x) for x in means.split()], dtype=np.int32)
    size_np = sample_size(bam_input, n_pairs, min_length, max_length)
    proportions, standard_deviations = find_parameters(size_np, means_np, max_length)

    # Plot sample distribution
    plt.title("Sample size distribution")
    plt.xlabel("Reads length")
    plt.ylabel("Count")
    plt.hist(size_np, bins=200)
    plt.savefig(f"{outdir}/sample_distribution.png")
    plt.close()

    # If one group dominates, we recalculate the parameters on the entire data set.
    if (proportions == 1.0).any():
        logger.warning(
            "For one of the averages, the proportion is close to or equal to 1, so the entire data set is sampled."
        )
        size_np = read_bam(bam_input, None, min_length, max_length)

        proportions, standard_deviations = find_parameters(
            size_np, means_np, max_length
        )
        all_size_np = size_np
    else:
        all_size_np = read_bam(bam_input, None, min_length, max_length)

    plt.title("All size distribution")
    plt.xlabel("Reads length")
    plt.ylabel("Count")
    plt.hist(all_size_np, bins=200)
    plt.savefig(f"{outdir}/all_distribution.png")
    plt.close()

    classification_group = classifier(
        all_size_np, means_np, standard_deviations, proportions
    )
    write_bam(classification_group, means_np, outdir, bam_input)


if __name__ == "__main__":
    main()
