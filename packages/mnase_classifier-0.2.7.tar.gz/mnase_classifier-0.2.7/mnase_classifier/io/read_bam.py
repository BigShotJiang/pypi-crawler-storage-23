# SPDX-FileCopyrightText: 2026 Laurent Modolo <laurent.modolo@cnrs.fr>, Lauryn Trouillot <lauryn.trouillot@ens-lyon.fr>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

# read bam in two mode:
# the first mode read N pairs of reads to get a sample of read pairs size
# distribution as an array
# the second mode read the entierty of the bam file
# for both mode we use an intermediate read_pair function that yield the next
# pair of reads (the only function used of the second mode)

import logging
import numpy as np
import pysam

logger = logging.getLogger(__name__)


def read_pair(bam_file_path: str):
    """Yield paired reads from a BAM file

    This generator iterates through a BAM file and yields pairs of reads.

    Parameters
    ----------
    bam_file_path : str
        Path to the input BAM file

    Yields
    ------
    tuple
        Pair of ``pysam.AlignedSegment`` objects (read1, read2)
    """
    logger.info("Opening BAM file: %s", bam_file_path)
    try:
        with pysam.AlignmentFile(bam_file_path, "rb") as bamfile:
            pair_dict = {}
            n_reads = 0
            n_pairs = 0
            for read in bamfile:
                n_reads += 1

                if read.query_name not in pair_dict:
                    pair_dict[read.query_name] = read
                else:
                    n_pairs += 1
                    yield (pair_dict[read.query_name], read)
            logger.info(
                "Finished reading BAM file: %d reads, %d pairs",
                n_reads,
                n_pairs,
            )
    except ValueError as e:
        if "Firing event 10" in str(e):
            return

        logger.exception("Unexpected error while reading BAM file")
        raise e


def read_bam(
    bam_file_path: str, n_pairs: int | None, min_length: int, max_length: int
) -> np.typing.NDArray[np.int32]:
    """Return an array of insert sizes extracted from a BAM file

    This function iterates over read pairs produced by :func:`read_pair` and
    computes the absolute template length (insert size) for each pair.
    If ``n_pairs`` is provided, only the first ``n_pairs`` pairs are processed;
    otherwise the entire BAM is processed.

    Parameters
    ----------
    bam_file_path : str
        Path to the input BAM file
    n_pairs : int, optional
        Number of read pairs to read. If ``None``, process the full file (default: None)

    Returns
    -------
    numpy.ndarray
        1D array of absolute insert sizes (integers)
    """
    logger.debug(
        "Reading insert sizes from %s (n_pairs=%s)",
        bam_file_path,
        n_pairs if n_pairs else "all",
    )
    size_array = []
    filtered_value = 0
    for i, (r1, r2) in enumerate(read_pair(bam_file_path)):
        if min_length <= r1.template_length < max_length:
            size_array.append(abs(r1.template_length))
            filtered_value += 1
        else:
            size_array.append(np.nan)
        if n_pairs is not None and filtered_value >= n_pairs:
            logger.debug(
                "Reached requested %d pairs, stopping", filtered_value
            )
            break
    return np.array(size_array, dtype=np.float64)


def sample_size(
    bam_file_path: str, n_pairs: int, min_length: int, max_length: int
) -> np.typing.NDArray[np.float64]:
    """Return an array of insert sizes extracted from a BAM file

    This function iterates over the read pairs produced by :func:`read_pair`
    and calculates the absolute length of the template (insertion size) for
    each pair. The first ``n_pairs`` pairs are processed.

    Parameters
    ----------
    bam_file_path : str
        Path to the input BAM file
    n_pairs : int
        Number of read pairs to read

    Returns
    -------
    numpy.ndarray
        1D array of absolute insert sizes (integers)
    """
    logger.info("Sampling %d pairs from %s", n_pairs, bam_file_path)
    return read_bam(bam_file_path, n_pairs, min_length, max_length)
