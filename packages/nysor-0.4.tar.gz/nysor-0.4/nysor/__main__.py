# Copyright 2025-2026 Facundo Batista
# Licensed under the Apache v2 License
# For further info, check https://github.com/facundobatista/nysor

"""Init file to allow project's execution as a module."""

import sys

from nysor import main

sys.exit(main.start())
