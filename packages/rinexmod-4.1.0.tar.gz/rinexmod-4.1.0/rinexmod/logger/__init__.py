#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on 26/06/2025 19:15:22

@author: psakic
"""

from .logger import *