#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on 26/06/2025 18:31:33

@author: psakic
"""

from .gamit_meta import *
#from .get_m3g import *
