"""Elvis LVS: Layout vs. Schematic verification for photonic circuits."""

from __future__ import annotations

__version__ = "0.1.8"

import json
import sys
import tempfile
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from klayout import rdb

from elvis._elvis import (
    cli as _cli_inner,
)
from elvis._elvis import (
    convert as _convert,
)
from elvis._elvis import (
    extract_netlist as _extract_netlist,
)
from elvis._elvis import (
    extract_ports as _extract_ports,
)
from elvis._elvis import (
    load_schematics as _load_schematics,
)
from elvis._elvis import (
    lvs as _lvs,
)
from elvis._elvis import (
    lvs_ok as _lvs_ok,
)
from elvis._elvis import (
    simplify as _simplify,
)

DEFAULT_TOLERANCE_NM: int = 1


def _cli() -> None:
    """Entry point for the ``elvis`` console script."""
    _cli_inner(sys.argv)


def _normalize_schematic(schematic: dict[str, Any]) -> dict[str, Any]:
    """Wrap a flat schematic dict in recursive format if needed."""
    if "instances" in schematic or "connections" in schematic:
        return {"top": schematic}
    return schematic


def extract_netlist(
    gds_path: str,
    tolerance_nm: int | None = None,
) -> dict[str, Any]:
    """Extract netlist from a GDS file.

    Args:
        gds_path: Path to the GDS file.
        tolerance_nm: Port matching tolerance in nanometers
            (default: from config or 1).

    Returns:
        dict with keys: instances, nets, ports.

    """
    if tolerance_nm is None:
        tolerance_nm = DEFAULT_TOLERANCE_NM
    return json.loads(
        _extract_netlist(gds_path, format="json", tolerance_nm=tolerance_nm)
    )


def extract_ports(gds_path: str) -> dict[str, list[str]]:
    """Extract component port table from a GDS file.

    Returns a mapping of component name to list of port names,
    as parsed from the GDS cell metadata (kfactory port properties).

    Args:
        gds_path: Path to the GDS file.

    Returns:
        dict mapping component name to list of port names.

    """
    return json.loads(_extract_ports(gds_path, format="json"))


def convert(netlist: dict[str, Any]) -> dict[str, Any]:
    """Convert a GDSFactory netlist dict to elvis-netlist format.

    Accepts flat or hierarchical (recursive) netlists. Hierarchical
    instances are flattened with ``~`` separators
    (e.g. ``mzi_1~splitter``).

    Args:
        netlist: Flat netlist dict or recursive dict[str, netlist].

    Returns:
        dict with keys: instances, nets, ports.

    """
    netlist_json = json.dumps(_normalize_schematic(netlist))
    return json.loads(_convert(netlist_json))


def simplify(
    netlist: dict[str, Any],
    remove_twoports: str | list[str] = "all",
    output_format: str = "keep",
    *,
    flatten: bool = False,
) -> dict[str, Any]:
    """Simplify a netlist by removing 2-port routing instances.

    Removes 2-port instances (waveguides, bends, etc.) and collapses
    their connections so that only multi-port components remain.

    Args:
        netlist: Flat netlist dict or recursive dict[str, netlist].
        remove_twoports: Which 2-port instances to remove.
            ``"all"`` removes all 2-port instances (default).
            A list of component names (e.g. ``["straight", "bend_euler"]``)
            removes only those types.
        output_format: Netlist schema for output.
            ``"keep"`` auto-detects from input (default).
            ``"elvis"`` always outputs ExtractedNetlist format.
            ``"gdsfactory"`` or ``"gf"`` preserves Instance metadata.
        flatten: Flatten hierarchical netlist before simplification.
            No effect on already-flat netlists.

    Returns:
        Simplified netlist dict.

    """
    if isinstance(remove_twoports, str):
        remove_twoports = [remove_twoports]
    netlist_json = json.dumps(_normalize_schematic(netlist))
    return json.loads(
        _simplify(
            netlist_json,
            remove_twoports,
            output_format=output_format,
            flatten=flatten,
        )
    )


def load_schematics(*paths: str) -> dict[str, Any]:
    """Load one or more schematic files (.pic.yml) as a GDSFactory netlist dict.

    Args:
        *paths: Paths to schematic files (.pic.yml).

    Returns:
        Recursive GDSFactory netlist dict
        (mapping component names to netlists).

    """
    return json.loads(_load_schematics(list(paths)))


def lvs_ok(
    layout_path: str,
    schematic: dict[str, Any],
    tolerance_nm: int | None = None,
) -> bool:
    """Check if LVS passes between a schematic and layout.

    Convenience function that returns a boolean instead of a full report.

    Args:
        layout_path: Path to layout GDS file.
        schematic: Flat netlist dict or recursive dict[str, netlist].
        tolerance_nm: Port matching tolerance in nanometers
            (default: from config or 1).

    Returns:
        True if LVS passes (no errors), False otherwise.

    """
    schematic_json = json.dumps(_normalize_schematic(schematic))
    return _lvs_ok(layout_path, schematic_json, tolerance_nm=tolerance_nm)


def lvs_rdb(
    layout_path: str,
    schematic: dict[str, Any],
    tolerance_nm: int | None = None,
    short_layers: list[tuple[int, int]] | None = None,
    connected_layers: (list[tuple[tuple[int, int], tuple[int, int]]] | None) = None,
    equivalent_ports: list[tuple[str, list[str]]] | None = None,
    top_cell: str | None = None,
) -> rdb.ReportDatabase:
    """Run LVS comparison between a schematic and layout.

    Args:
        layout_path: Path to layout GDS file.
        schematic: Flat netlist dict or recursive dict[str, netlist].
        tolerance_nm: Port matching tolerance in nanometers
            (default: from config or 1).
        short_layers: List of (layer, datatype) tuples to check
            for shorts.
        connected_layers: List of ((l1, d1), (l2, d2)) tuples
            for cross-layer short detection.
        equivalent_ports: List of (component, [port1, port2, ...])
            tuples for port grouping.
        top_cell: Override top cell name for hierarchical schematics.

    Returns:
        klayout.rdb.ReportDatabase with LVS results.

    Raises:
        ImportError: If klayout is not installed
            (pip install elvis[klayout]).

    """
    try:
        from klayout import rdb
    except ImportError:
        msg = (
            "klayout is required for elvis.lvs_rdb(). "
            "Install it with: pip install elvis[klayout]"
        )
        raise ImportError(msg) from None

    schematic_json = json.dumps(_normalize_schematic(schematic))
    lyrdb_str = _lvs(
        layout_path,
        schematic_json,
        format="lyrdb",
        tolerance_nm=tolerance_nm,
        short_layers=short_layers,
        connected_layers=connected_layers,
        equivalent_ports=equivalent_ports,
        top_cell=top_cell,
    )
    db = rdb.ReportDatabase("")
    with tempfile.NamedTemporaryFile(suffix=".lyrdb", delete=False, mode="w") as f:
        f.write(lyrdb_str)
        tmp_path = f.name
    try:
        db.load(tmp_path)
    finally:
        Path(tmp_path).unlink()
    return db


def lvs(
    layout_path: str,
    schematic: dict[str, Any],
    tolerance_nm: int | None = None,
    short_layers: list[tuple[int, int]] | None = None,
    connected_layers: (list[tuple[tuple[int, int], tuple[int, int]]] | None) = None,
    equivalent_ports: list[tuple[str, list[str]]] | None = None,
    top_cell: str | None = None,
) -> dict[str, Any]:
    """Run LVS comparison between a schematic and layout.

    Args:
        layout_path: Path to layout GDS file.
        schematic: Flat netlist dict or recursive dict[str, netlist].
        tolerance_nm: Port matching tolerance in nanometers
            (default: from config or 1).
        short_layers: List of (layer, datatype) tuples to check
            for shorts.
        connected_layers: List of ((l1, d1), (l2, d2)) tuples
            for cross-layer short detection.
        equivalent_ports: List of (component, [port1, port2, ...])
            tuples for port grouping.
        top_cell: Override top cell name for hierarchical schematics.

    Returns:
        dict with keys: ok, error_count, instance_errors,
        net_errors, port_errors, open_errors, short_errors.

    """
    schematic_json = json.dumps(_normalize_schematic(schematic))
    return json.loads(
        _lvs(
            layout_path,
            schematic_json,
            format="json",
            tolerance_nm=tolerance_nm,
            short_layers=short_layers,
            connected_layers=connected_layers,
            equivalent_ports=equivalent_ports,
            top_cell=top_cell,
        )
    )
