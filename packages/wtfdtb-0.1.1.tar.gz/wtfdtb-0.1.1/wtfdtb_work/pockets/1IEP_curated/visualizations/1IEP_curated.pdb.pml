
        from pymol import cmd,stored
        
        set depth_cue, 1
        set fog_start, 0.4
        
        set_color b_col, [36,36,85]
        set_color t_col, [10,10,10]
        set bg_rgb_bottom, b_col
        set bg_rgb_top, t_col      
        set bg_gradient
        
        set  spec_power  =  200
        set  spec_refl   =  0
        
        load "data/1IEP_curated.pdb", protein
        create ligands, protein and organic
        select xlig, protein and organic
        delete xlig
        
        hide everything, all
        
        color white, elem c
        color bluewhite, protein
        #show_as cartoon, protein
        show surface, protein
        #set transparency, 0.15
        
        show sticks, ligands
        set stick_color, magenta
        
        
        
        
        # SAS points
 
        load "data/1IEP_curated.pdb_points.pdb.gz", points
        hide nonbonded, points
        show nb_spheres, points
        set sphere_scale, 0.2, points
        cmd.spectrum("b", "green_red", selection="points", minimum=0, maximum=0.7)
        
        
        stored.list=[]
        cmd.iterate("(resn STP)","stored.list.append(resi)")    # read info about residues STP
        lastSTP=stored.list[-1] # get the index of the last residue
        hide lines, resn STP
        
        cmd.select("rest", "resn STP and resi 0")
        
        for my_index in range(1,int(lastSTP)+1): cmd.select("pocket"+str(my_index), "resn STP and resi "+str(my_index))
        for my_index in range(1,int(lastSTP)+1): cmd.show("spheres","pocket"+str(my_index))
        for my_index in range(1,int(lastSTP)+1): cmd.set("sphere_scale","0.4","pocket"+str(my_index))
        for my_index in range(1,int(lastSTP)+1): cmd.set("sphere_transparency","0.1","pocket"+str(my_index))
        
        
        
        set_color pcol1 = [0.361,0.576,0.902]
select surf_pocket1, protein and id [2539,2540,2541,2548,2542,2567,2569,2552,2551,2555,2563,1119,1047,2203,1046,1048,1601,1649,447,464,466,467,2111,1205,2525,1202,1590,1593,1646,1726,2383,1487,1499,2384,728,1488,506,505,750,754,756,757,758,1063,1222,1062,1064,1220,1250,1015,1008,1012,1013,1117,1061,1115,405,407,419,420,462,465,406,1519,1521,1517,461,2382,1531,1132,1534,1551,1564,1565,1583,1584,2246,2238,2219,2236,1725] 
set surface_color,  pcol1, surf_pocket1 
set_color pcol2 = [0.278,0.380,0.702]
select surf_pocket2, protein and id [5150,5152,5151,7252,7254,7255,6269,6275,7068,6249,6268,7067,6221,5146,5147,5148,5149,5441,5443,7246,7249,5191,5090,5092,5091,6204,6206,6202,6205,6219,6236,5413,6184,5411,5412,6172,5190,5435,5439,6216,6197,5750,5907,5908,6173,6132,5749,6135,7237,5700,7236,5104,5105,5106,6250,5139,6286,6334,6331] 
set surface_color,  pcol2, surf_pocket2 
set_color pcol3 = [0.361,0.408,0.902]
select surf_pocket3, protein and id [6931,7224,7233,7237,7238,7239,7240,5698,5700,7236,5697,5890,7210,6921,6923,5750,5907,5935,5748,5905,5886,6885,6888,6904,5804,5732,6796,6795,5731,5733,5746,5802,5800,5817,5939,7225] 
set surface_color,  pcol3, surf_pocket3 
set_color pcol4 = [0.310,0.278,0.702]
select surf_pocket4, protein and id [2580,2581,2583,2621,2563,891,892,893,2554,2555,935,936,2648,460,490,757,758,813,792,812,775,889,952,933,934,888,946,947,1012,1013,1014,479,485,493,2611] 
set surface_color,  pcol4, surf_pocket4 
set_color pcol5 = [0.482,0.361,0.902]
select surf_pocket5, protein and id [2278,2289,2238,2255,2277,2256,2281,2282,2284,2257,2610,2611,2816,2804,2807,2259,3173,2733,2606,2622,2842,2913,2935,3223,2948,2939,2940,2861,2844,3161,3091,3093,3159,2580,2581,2583,2587,2621,893,2623,2554,2555] 
set surface_color,  pcol5, surf_pocket5 
set_color pcol6 = [0.439,0.278,0.702]
select surf_pocket6, protein and id [3372,3368,3369,3859,3875,3294,3873,3874,3925,3926,4334,3839,3371,3854,1842,1844,1845,1887,1889,1902,1903,1906,1908,1909,3401,3355,1963] 
set surface_color,  pcol6, surf_pocket6 
set_color pcol7 = [0.651,0.361,0.902]
select surf_pocket7, protein and id [8053,8040,6572,8054,6570,6571,6587,6527,6530,6529,7983,9019,6588,6591,6593,6648,8559,8560,8610,8611,7979,8057,8086,6574,8056,8537,8538,8539] 
set surface_color,  pcol7, surf_pocket7 
set_color pcol8 = [0.573,0.278,0.702]
select surf_pocket8, protein and id [7237,7238,7239,7240,5698,5699,5700,7236,5697,5624,5619,5621,6941,6942,6944,7529,7546,7267,7272,7291,7266,7501,7527,7296,7306,7492,6967,6969,6966,5443,7308,7310] 
set surface_color,  pcol8, surf_pocket8 
set_color pcol9 = [0.820,0.361,0.902]
select surf_pocket9, protein and id [7386,7387,7396,7400,8126,8127,6315,6387,6314,8139,7579,7580,7388,7389,7606,7607,7019,7021,8026,7352] 
set surface_color,  pcol9, surf_pocket9 
set_color pcol10 = [0.702,0.278,0.698]
select surf_pocket10, protein and id [2667,2715,2666,1630,2332,1702,448,1601,1648,1649,464,466,1595,444,443,2331,2594,1600] 
set surface_color,  pcol10, surf_pocket10 
set_color pcol11 = [0.902,0.361,0.812]
select surf_pocket11, protein and id [2894,2701,2711,3441,3442,3454,2921,2922,2713,1630,3341,1629,2667,2715,2895,3451] 
set surface_color,  pcol11, surf_pocket11 
set_color pcol12 = [0.702,0.278,0.565]
select surf_pocket12, protein and id [1927,1929,4400,4402,1988,1194,2034,2035,1175,4396,1975,4294,4295,4351,4354,4397,4426] 
set surface_color,  pcol12, surf_pocket12 
set_color pcol13 = [0.902,0.361,0.643]
select surf_pocket13, protein and id [6669,6719,6720,5879,6657,6660,8979,9036,9081,8980,5847,5860,6612,6673,9083,9086,9082,9084,6614,6616] 
set surface_color,  pcol13, surf_pocket13 
set_color pcol14 = [0.702,0.278,0.435]
select surf_pocket14, protein and id [1327,1325,200,1344,102,141,1083,138,969,1036,970,973,1032,1033,1081] 
set surface_color,  pcol14, surf_pocket14 
set_color pcol15 = [0.902,0.361,0.475]
select surf_pocket15, protein and id [3002,3001,2990,3005,2775,2839,2840,2842,2876,2940] 
set surface_color,  pcol15, surf_pocket15 
set_color pcol16 = [0.702,0.278,0.302]
select surf_pocket16, protein and id [5138,6286,6332,6333,6334,7350,6315,7017,6285,7016,7278,7352,7279,6280,5151] 
set surface_color,  pcol16, surf_pocket16 
set_color pcol17 = [0.902,0.416,0.361]
select surf_pocket17, protein and id [4822,4825,5768,5658,4883,6010,6012,5721,5654,5655,5657] 
set surface_color,  pcol17, surf_pocket17 
set_color pcol18 = [0.702,0.388,0.278]
select surf_pocket18, protein and id [1568,1569,1570,1571,1572,2415,2434,2435,2448,1662,1664,2454,2456,1806,1807] 
set surface_color,  pcol18, surf_pocket18 
set_color pcol19 = [0.902,0.584,0.361]
select surf_pocket19, protein and id [6254,6256,6257,6345,6347,6405,6406,6418,6419,6422,6433,6490,6491,6492,7144,6255] 
set surface_color,  pcol19, surf_pocket19 
set_color pcol20 = [0.702,0.522,0.278]
select surf_pocket20, protein and id [4833,4879,4895,4908,4698,4913,5957,4855,5271,5314,5338] 
set surface_color,  pcol20, surf_pocket20 
set_color pcol21 = [0.902,0.753,0.361]
select surf_pocket21, protein and id [524,525,526,326,492,778,327,329,1433,1393,1394] 
set surface_color,  pcol21, surf_pocket21 
set_color pcol22 = [0.702,0.651,0.278]
select surf_pocket22, protein and id [7307,7309,7310,7333,5170,5174,5460,5175,7305,5478,5575] 
set surface_color,  pcol22, surf_pocket22 
set_color pcol23 = [0.878,0.902,0.361]
select surf_pocket23, protein and id [7891,8157,8455,8456,8458,8745,8746,8747,8748,8749,8750,8451] 
set surface_color,  pcol23, surf_pocket23 
   
        
        deselect
        
        orient
        