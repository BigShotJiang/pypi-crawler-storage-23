import os
import logging
import pytest
import pandas as pd
import shutil
from pathlib import Path
from wtfdtb.pipeline import run_pipeline

# Set up environment for tests
home = os.path.expanduser("~")
os.environ["PRANK_HOME"] = f"{home}/.local/share/p2rank/p2rank_2.4.2"
os.environ["PATH"] = f"{home}/.local/bin:" + os.environ.get("PATH", "")

logging.basicConfig(level=logging.INFO)

def test_pipeline_imatinib_1iep(tmp_path):
    """Integration test: Imatinib vs ABL kinase (1IEP)."""
    work_dir = tmp_path / "wtfdtb_work_strong"
    work_dir.mkdir()
    
    # Imatinib (Gleevec) SMILES - known strong binder to ABL kinase
    imatinib_path = tmp_path / "imatinib.smi"
    imatinib_path.write_text("CC1=C(C=C(C=C1)NC(=O)C2=CC=C(C=C2)CN3CCN(CC3)C)NC4=NC=CC(=N4)C5=CC=CC=N5 imatinib\n")
    
    # Use existing PDB file from cache to avoid download (which fails without internet)
    cache_pdb = Path("wtfdtb_work/raw_pdbs/1IEP.pdb")
    targets_dir = tmp_path / "targets"
    targets_dir.mkdir()
    if cache_pdb.exists():
        shutil.copy(cache_pdb, targets_dir / "1IEP.pdb")
        targets_path = targets_dir
    else:
        # Fallback if cache doesn't exist (e.g. in other environments)
        targets_path = tmp_path / "strong_targets.txt"
        targets_path.write_text("1IEP\n")

    output_csv = tmp_path / "strong_results.csv"

    print(f"[*] Starting validation run: Imatinib vs {targets_path} (ABL Kinase)")

    run_pipeline(
        ligand_path=imatinib_path,
        targets_path=targets_path,
        output_csv=output_csv,
        work_dir=work_dir,
        ph=7.4,
        box_size=30,
        cnn_model="default",
        cnn_score_threshold=0.5,
        min_interactions=1,
        workers=1,
        exhaustiveness=4,
        verbosity=1
    )

    assert output_csv.exists()
    df = pd.read_csv(output_csv)
    assert len(df) > 0
    # Imatinib vs 1IEP should have very strong affinity
    # Use a slightly more relaxed threshold just in case of low exhaustiveness
    assert df["vina_affinity"].min() < -7.0
