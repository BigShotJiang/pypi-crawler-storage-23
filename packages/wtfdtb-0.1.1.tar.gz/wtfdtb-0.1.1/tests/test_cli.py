import os
import subprocess
import pytest
import pandas as pd
import shutil
from pathlib import Path

# Set up environment
home = os.path.expanduser("~")
os.environ["PRANK_HOME"] = f"{home}/.local/share/p2rank/p2rank_2.4.2"
os.environ["PATH"] = f"{home}/.local/bin:" + os.environ.get("PATH", "")

def test_cli_screen_imatinib(tmp_path):
    """Integration test via CLI: Imatinib vs 1IEP."""
    work_dir = tmp_path / "final_verification"
    work_dir.mkdir()

    lig_path = work_dir / "imatinib.smi"
    lig_path.write_text("Cc1ccc(cc1Nc2nccc(n2)c3cccnc3)Nc4ccc(cc4)CN5CCN(CC5)C imatinib\n")

    # Use existing PDB file from cache
    cache_pdb = Path("wtfdtb_work/raw_pdbs/1IEP.pdb")
    targets_dir = tmp_path / "targets"
    targets_dir.mkdir()
    if cache_pdb.exists():
        shutil.copy(cache_pdb, targets_dir / "1IEP.pdb")
        targets_input = str(targets_dir)
    else:
        # Fallback
        targets_file = work_dir / "targets.txt"
        targets_file.write_text("1IEP\n")
        targets_input = str(targets_file)

    output_csv = tmp_path / "final_results.csv"

    # Run pipeline via CLI
    cmd = [
        ".venv/bin/python", "-m", "wtfdtb.cli", "screen",
        "--ligand", str(lig_path),
        "--targets", targets_input,
        "--output", str(output_csv),
        "--workers", "1",
        "--exhaustiveness", "4",
        "--box-size", "18",
        "--verbosity", "1"
    ]

    print(f"Executing: {' '.join(cmd)}")
    result = subprocess.run(cmd, capture_output=True, text=True)
    
    # Check if successful
    if result.returncode != 0:
        print(result.stdout)
        print(result.stderr)
    
    assert result.returncode == 0
    assert output_csv.exists()
    
    df = pd.read_csv(output_csv)
    assert len(df) > 0
    assert "vina_affinity" in df.columns
