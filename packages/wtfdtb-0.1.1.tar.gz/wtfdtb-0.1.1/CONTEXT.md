# WTFDTB — High-Throughput Inverse Virtual Screening

## Current Status: STABLE (v0.1.0-alpha)
The pipeline is fully functional end-to-end. It successfully docks a single ligand against multiple protein structures in parallel, profiles the non-covalent interactions of the docked poses, and ranks the results based on empirical physics and neural network confidence.

## Core Pipeline Architecture

### Phase 1: Ligand Preparation (`ligand_prep.py`)
- **Input**: User provides a `.smi`, `.sdf`, `.mol`, or `.mol2` file.
- **Processing**:
  - `Dimorphite-DL` determines the dominant protonation states at the target pH (default 7.4).
  - `RDKit` generates 3D conformers using ETKDGv3 and minimizes them using the MMFF94 forcefield.
  - `Meeko` assigns Gasteiger charges, defines the torsion tree, and exports to `PDBQT`.

### Phase 2: Receptor Curation (`receptor_curation.py`)
- **Input**: A directory of `.pdb` files, or a text file containing RCSB PDB IDs.
- **Processing**: 
  - `pdb-tools` removes crystallographic waters and HETATM records.
  - `PDBFixer` models any missing heavy atoms or loops in the protein chain (rejecting chains with missing gaps > 50 contiguous residues).
  - `PDB2PQR` (with `PROPKA`) computationally assigns the protonation state of each residue at the target pH.

### Phase 3: Pocket Detection (`pocket_detection.py`)
- **Input**: The curated, protonated `.pdb` receptors.
- **Processing**:
  - `P2Rank` (a random forest ML tool) sweeps the protein surface and predicts the center coordinates (X,Y,Z) of all druggable binding cavities without any template bias.

### Phase 4: Molecular Docking (`docking.py`)
- **Input**: Ligand PDBQT, Receptor PDB, and Pocket Centers.
- **Processing**:
  - `GNINA` (a fork of AutoDock Vina) performs molecular docking in a 25Å cubic box around each pocket center.
  - GNINA's built-in Convolutional Neural Network (CNN) scores and ranks the generated poses.
  - Generates 9 output poses per pocket as an SDF file containing `CNNscore`, `CNNaffinity`, and `Vina affinity` properties.

### Phase 5: Post-Docking Analysis (`post_dock.py`)
- **Input**: Docked SDFs from GNINA and the protonated receptor PDB.
- **Processing**:
  - Drops generated poses with a CNN probability score below the specified threshold.
  - `ProLIF` builds an interaction fingerprint for each pose (counting Hydrogen bonds, Hydrophobic contacts, pi-stacking, and salt bridges).
  - Drops poses with 0 biologically relevant interactions (`total_interactions`).
  - **Ranking Logic**: Sorts all remaining poses primarily by Vina empirical affinity (kcal/mol, ascending order), breaking ties with GNINA's CNN affinity (pKd, descending order).
  - Exports the final sorted results to the output CSV.

## Key Design Patterns
- **Parallelization**: Phases 2 and 4 use basic Python `concurrent.futures.ProcessPoolExecutor` to drastically speed up execution across multiple protein targets and pockets.
- **Defensive Parsing**: RDKit and ProLIF have strict valence requirements. The post-docking analysis employs defensive string manipulation to repair GNINA's non-standard SDF headers (`_fix_gnina_mol_block`) and intentionally bypasses RDKit's hydrogen valence exceptions to permit unhindered interaction profiling.

## Debugging: Pipeline Hang Issue on Local Devices (Current Task)
- **Issue**: When running the pipeline locally on a device (e.g., 16GB RAM laptop, Linux/WSL), it stalls completely without an error after finishing Phase 2 (Receptor Curation) but before starting Phase 3 (Pocket Detection). 
- **Symptoms**: The last line printed in the terminal is `[INFO] wtfdtb.receptor | 1IEP: protonated at pH 7.4 -> wtfdtb_work/raw_pdbs/1IEP_curated.pdb`. The expected next line is `[2/5] 1/1 receptors passed`, but the pipeline hangs indefinitely.
- **Potential Causes**: 
  - `ProcessPoolExecutor` in `_curate_all()` (`src/wtfdtb/pipeline.py`) is deadlocking or failing to shut down its worker processes cleanly. 
  - An underlying subprocess spawned by `pdb2pqr` or `propka` might be leaving open threads or file descriptors, preventing the worker process from terminating and returning context to the main executor.
- **Goal for Gemini CLI**: Debug `_curate_all()` and `curate_receptor()` to track down and fix the root cause of this hang (perhaps by switching to `ThreadPoolExecutor` if it's I/O bound, or adding explicit process isolation/timeouts) so the tool remains fully downloadable and usable locally on ordinary hardware.
