#!/bin/bash
export PRANK_HOME=~/.local/share/p2rank/p2rank_2.4.2
export PATH=~/.local/bin:$PATH
export PYTHONUNBUFFERED=1
date
.venv/bin/python -m wtfdtb.cli screen --ligand final_verification/imatinib.smi --targets final_verification/targets.txt --output final_results.csv --workers 8 --exhaustiveness 16 --box-size 18 --verbosity 1
date
