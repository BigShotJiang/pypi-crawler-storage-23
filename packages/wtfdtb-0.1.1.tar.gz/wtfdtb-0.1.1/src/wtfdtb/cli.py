"""CLI entry point for wtfdtb — inverse virtual screening pipeline."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Annotated

import typer

from wtfdtb import __version__


@dataclass(frozen=True)
class PipelineConfig:
    """All the settings needed to run a screening job."""

    ligand: Path
    targets: Path
    output: Path
    ph: float
    box_size: int
    cnn_model: str
    cnn_score_threshold: float
    min_interactions: int
    workers: int
    exhaustiveness: int
    verbosity: int
    work_dir: Path | None = None


# -- input checks --


def _validate_ligand(value: Path) -> Path:
    if not value.exists():
        raise typer.BadParameter(f"Ligand file not found: {value}")
    suffix = value.suffix.lower()
    if suffix not in (".sdf", ".mol", ".mol2", ".smi", ".smiles"):
        raise typer.BadParameter(
            f"Unsupported ligand format '{suffix}'. Accepted: .sdf, .mol, .mol2, .smi, .smiles"
        )
    return value


def _validate_targets(value: Path) -> Path:
    if not value.exists():
        raise typer.BadParameter(f"Targets path not found: {value}")
    return value


def _validate_ph(value: float) -> float:
    if not 0.0 <= value <= 14.0:
        raise typer.BadParameter(f"pH must be between 0.0 and 14.0, got {value}")
    return value


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(f"wtfdtb {__version__}")
        raise typer.Exit()


app = typer.Typer(
    name="wtfdtb",
    help="High-Throughput Inverse Virtual Screening (Target Fishing). "
    "Dock a single ligand against a library of protein targets using "
    "GNINA CNN-rescored docking.",
    no_args_is_help=True,
)


@app.callback()
def _global(
    version: bool | None = typer.Option(  # noqa: UP007
        None,
        "--version",
        "-v",
        help="Show version and exit.",
        callback=_version_callback,
        is_eager=True,
    ),
) -> None:
    """WTFDTB — High-Throughput Inverse Virtual Screening."""


def _check_dependencies_interactively() -> None:
    """Check if GNINA/P2Rank are available; if not, prompt user to install."""
    from wtfdtb.docking import find_gnina
    from wtfdtb.pocket_detection import find_prank_executable

    missing = []
    try:
        find_gnina()
    except RuntimeError:
        missing.append("GNINA")

    try:
        find_prank_executable()
    except RuntimeError:
        missing.append("P2Rank")

    if missing:
        typer.echo(f"[*] Missing external dependencies: {', '.join(missing)}")
        confirm = typer.confirm("Would you like to run 'wtfdtb install' now?", default=True)
        if confirm:
            from wtfdtb import installer

            installer.run_install()
        else:
            typer.echo("[!] Pipeline cannot run without these tools. Exiting.")
            raise typer.Exit(code=1)


@app.command()
def screen(
    ligand: Annotated[
        Path,
        typer.Option(
            "--ligand",
            "-l",
            help="Path to the input ligand file (.sdf, .mol, .mol2, .smi).",
            exists=False,  # custom validation gives a nicer error
        ),
    ],
    targets: Annotated[
        Path,
        typer.Option(
            "--targets",
            "-t",
            help="Path to the protein target library. "
            "Either a directory of .pdb files or a text file listing PDB IDs (one per line).",
        ),
    ],
    output: Annotated[
        Path,
        typer.Option(
            "--output",
            "-o",
            help="Path for the output CSV with ranked docking results.",
        ),
    ] = Path("results.csv"),
    ph: Annotated[
        float,
        typer.Option(
            "--ph",
            help="Physiological pH for ligand and receptor protonation.",
        ),
    ] = 7.4,
    box_size: Annotated[
        int,
        typer.Option(
            "--box-size",
            help="Side length (angstrom) of the cubic docking search box.",
        ),
    ] = 25,
    cnn_model: Annotated[
        str,
        typer.Option(
            "--cnn-model",
            help="GNINA CNN model for rescoring. 'default' is an ensemble; "
            "advanced users can specify 'dense' or a path to custom weights.",
        ),
    ] = "default",
    cnn_score_threshold: Annotated[
        float,
        typer.Option(
            "--cnn-score-threshold",
            help="Minimum CNNscore (0-1) to accept a pose. "
            "Poses below this are discarded before ranking by CNNaffinity.",
        ),
    ] = 0.5,
    min_interactions: Annotated[
        int,
        typer.Option(
            "--min-interactions",
            help="Minimum protein-ligand interactions (H-bond, hydrophobic, "
            "pi-stacking, salt bridge) to keep a pose. 0 disables filtering.",
        ),
    ] = 1,
    workers: Annotated[
        int,
        typer.Option(
            "--workers",
            "-w",
            help="Parallel workers for receptor curation and docking.",
        ),
    ] = os.cpu_count() or 4,
    exhaustiveness: Annotated[
        int,
        typer.Option(
            "--exhaustiveness",
            help="GNINA search exhaustiveness (higher = slower, more thorough).",
        ),
    ] = 8,
    verbosity: Annotated[
        int,
        typer.Option(
            "--verbosity",
            help="Logging verbosity: 0 = quiet, 1 = normal, 2 = debug.",
        ),
    ] = 1,
) -> None:
    """Dock a single ligand against a library of protein targets.

    Runs the full inverse virtual screening pipeline:
    ligand prep -> receptor curation -> pocket detection ->
    GNINA docking -> interaction profiling & ranked CSV.
    """
    _check_dependencies_interactively()
    ligand = _validate_ligand(ligand)
    targets = _validate_targets(targets)
    ph = _validate_ph(ph)

    config = PipelineConfig(
        ligand=ligand,
        targets=targets,
        output=output,
        ph=ph,
        box_size=box_size,
        cnn_model=cnn_model,
        cnn_score_threshold=cnn_score_threshold,
        min_interactions=min_interactions,
        workers=workers,
        exhaustiveness=exhaustiveness,
        verbosity=verbosity,
    )

    from wtfdtb import pipeline

    pipeline.run(config)


@app.command()
def install() -> None:
    """Download and configure external dependencies (GNINA, P2Rank).

    This command automatically fetches the pre-compiled Linux binaries for
    GNINA and P2Rank required by the pipeline, and places them in ~/.local/
    so they are available on the user's PATH without manual setup.
    """
    from wtfdtb import installer

    installer.run_install()


if __name__ == "__main__":
    app()
