"""Phase 4: GNINA docking with CNN rescoring.

Shells out to gnina for each receptor+pocket, parses the output SDF
for CNNscore/CNNaffinity, supports parallel execution.
"""

from __future__ import annotations

import logging
import shutil
import subprocess
import tempfile
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path

log = logging.getLogger("wtfdtb.docking")


@dataclass
class DockingResult:
    """Single docked pose with scores."""

    pdb_id: str
    pocket_name: str
    pose_rank: int
    cnn_score: float
    cnn_affinity: float
    vina_affinity: float
    pose_sdf: str


def find_gnina() -> str:
    """Find gnina on PATH or in default install location."""
    # 1. System PATH
    found = shutil.which("gnina")
    if found:
        return found

    # 2. Default installer location
    default_install = Path.home() / ".local" / "bin" / "gnina"
    if default_install.exists():
        return str(default_install)

    raise RuntimeError("gnina not found — install via 'wtfdtb install' or 'conda install -c conda-forge gnina'")


def dock_single(
    receptor_pdb: Path,
    ligand_pdbqt: str,
    center: tuple[float, float, float],
    box_size: int,
    pdb_id: str,
    pocket_name: str,
    exhaustiveness: int = 8,
    cnn_model: str = "default",
    num_modes: int = 9,
) -> list[DockingResult]:
    """Dock one ligand into one pocket via GNINA."""
    gnina = find_gnina()

    with tempfile.NamedTemporaryFile(suffix=".pdbqt", mode="w", delete=False) as lig_tmp:
        lig_tmp.write(ligand_pdbqt)
        lig_path = Path(lig_tmp.name)

    with tempfile.NamedTemporaryFile(suffix=".sdf", delete=False) as out_tmp:
        out_path = Path(out_tmp.name)

    cx, cy, cz = center
    cmd = [
        gnina,
        "-r",
        str(receptor_pdb),
        "-l",
        str(lig_path),
        "-o",
        str(out_path),
        "--center_x",
        str(cx),
        "--center_y",
        str(cy),
        "--center_z",
        str(cz),
        "--size_x",
        str(box_size),
        "--size_y",
        str(box_size),
        "--size_z",
        str(box_size),
        "--exhaustiveness",
        str(exhaustiveness),
        "--num_modes",
        str(num_modes),
        "--cpu",
        "1",
        "--cnn_scoring",
        "rescore",
    ]
    if cnn_model != "default":
        cmd.extend(["--cnn", cnn_model])

    log.debug("gnina: %s", " ".join(cmd))
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=1800)
    lig_path.unlink(missing_ok=True)

    if r.returncode != 0:
        log.error(
            "gnina failed for %s/%s: %s", pdb_id, pocket_name, r.stderr[-300:] if r.stderr else "?"
        )
        out_path.unlink(missing_ok=True)
        return []

    poses = _parse_gnina_sdf(out_path, pdb_id, pocket_name)
    out_path.unlink(missing_ok=True)
    return poses


def dock_parallel(tasks: list[dict], workers: int = 4) -> list[DockingResult]:
    """Run dock_single across multiple receptor/pocket combos in parallel."""
    all_results: list[DockingResult] = []
    with ProcessPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(dock_single, **t): t for t in tasks}
        for fut in as_completed(futures):
            t = futures[fut]
            try:
                all_results.extend(fut.result())
            except Exception as exc:
                log.error(
                    "Docking %s/%s crashed: %s",
                    t.get("pdb_id", "?"),
                    t.get("pocket_name", "?"),
                    exc,
                )
    return all_results


def _parse_gnina_sdf(sdf_path: Path, pdb_id: str, pocket_name: str) -> list[DockingResult]:
    """Extract CNNscore/CNNaffinity/minimizedAffinity from GNINA's SDF output."""
    if not sdf_path.exists() or sdf_path.stat().st_size == 0:
        return []

    blocks = sdf_path.read_text().split("$$$$")
    results = []
    for i, block in enumerate(blocks):
        block = block.strip()
        if not block:
            continue
        results.append(
            DockingResult(
                pdb_id=pdb_id,
                pocket_name=pocket_name,
                pose_rank=i + 1,
                cnn_score=_sdf_prop(block, "CNNscore"),
                cnn_affinity=_sdf_prop(block, "CNNaffinity"),
                vina_affinity=_sdf_prop(block, "minimizedAffinity"),
                pose_sdf=block,
            )
        )
    log.info("%s/%s: %d poses", pdb_id, pocket_name, len(results))
    return results


def _sdf_prop(block: str, name: str) -> float:
    """Pull a numeric property from an SDF block.

    GNINA uses variable whitespace in tags ('>  <name>' vs '> <name>'),
    so we search with a regex.
    """
    import re

    match = re.search(rf">\s+<{name}>\s*\n(.+)", block)
    if not match:
        return 0.0
    try:
        return float(match.group(1).strip())
    except ValueError:
        return 0.0
