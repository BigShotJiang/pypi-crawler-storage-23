"""Orchestrator — runs all five pipeline phases in order."""

from __future__ import annotations

import logging
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from wtfdtb.cli import PipelineConfig

from wtfdtb.cli import PipelineConfig
from wtfdtb.docking import dock_parallel
from wtfdtb.ligand_prep import prepare_ligand
from wtfdtb.pocket_detection import detect_pockets_batch
from wtfdtb.post_dock import analyze_and_rank
from wtfdtb.receptor_curation import curate_receptor
from wtfdtb.utils import ensure_work_dir, parse_target_input, setup_logging

log = logging.getLogger("wtfdtb.pipeline")


def run_pipeline(
    ligand_path: Path,
    targets_path: Path,
    output_csv: Path = Path("results.csv"),
    ph: float = 7.4,
    box_size: int = 25,
    cnn_model: str = "default",
    cnn_score_threshold: float = 0.5,
    min_interactions: int = 1,
    workers: int = 4,
    exhaustiveness: int = 8,
    verbosity: int = 1,
    work_dir: Path | None = None,
) -> Path:
    """Convenience wrapper for run() that takes individual arguments."""
    config = PipelineConfig(
        ligand=ligand_path,
        targets=targets_path,
        output=output_csv,
        ph=ph,
        box_size=box_size,
        cnn_model=cnn_model,
        cnn_score_threshold=cnn_score_threshold,
        min_interactions=min_interactions,
        workers=workers,
        exhaustiveness=exhaustiveness,
        verbosity=verbosity,
        work_dir=work_dir,
    )
    return run(config)


def run(config: PipelineConfig) -> Path:
    """Run the full screening pipeline. Returns path to the output CSV."""
    t0 = time.time()
    setup_logging(config.verbosity)
    if config.work_dir:
        work = config.work_dir
        work.mkdir(parents=True, exist_ok=True)
    else:
        work = ensure_work_dir(config.output.parent, "wtfdtb_work")

    # phase 1 — ligand
    log.info("[1/5] Preparing ligand %s at pH %.1f", config.ligand, config.ph)
    ligand_pdbqt = prepare_ligand(config.ligand, ph=config.ph)

    # phase 2 — receptor curation (parallel)
    log.info("[2/5] Curating receptors")
    pdbs = parse_target_input(config.targets, download_dir=work / "raw_pdbs")
    curated = _curate_all(pdbs, config.ph, config.workers)
    if not curated:
        raise RuntimeError("All receptors failed curation — nothing to dock")
    log.info("[2/5] %d/%d receptors passed", len(curated), len(pdbs))

    # phase 3 — pocket detection
    log.info("[3/5] Running P2Rank")
    all_pockets = detect_pockets_batch(list(curated.values()), work / "pockets")
    # P2Rank keys by curated filename stem (e.g. "4HHB_curated"),
    # but we use original PDB IDs ("4HHB") everywhere else.
    stem_to_pid = {path.stem: pid for pid, path in curated.items()}
    has_pockets = {stem_to_pid[k]: v for k, v in all_pockets.items() if v and k in stem_to_pid}
    if not has_pockets:
        raise RuntimeError("No pockets found in any receptor")
    log.info("[3/5] Pockets in %d/%d receptors", len(has_pockets), len(curated))

    # phase 4 — docking (parallel)
    log.info(
        "[4/5] Docking (exhaustiveness=%d, workers=%d)", config.exhaustiveness, config.workers
    )
    tasks = []
    for pid, pockets in has_pockets.items():
        for pk in pockets:
            tasks.append(
                {
                    "receptor_pdb": curated[pid],
                    "ligand_pdbqt": ligand_pdbqt,
                    "center": (pk.center_x, pk.center_y, pk.center_z),
                    "box_size": config.box_size,
                    "pdb_id": pid,
                    "pocket_name": pk.name,
                    "exhaustiveness": config.exhaustiveness,
                    "cnn_model": config.cnn_model,
                }
            )
    results = dock_parallel(tasks, workers=config.workers)
    log.info("[4/5] %d poses from %d jobs", len(results), len(tasks))

    # phase 5 — filter, profile, rank
    log.info("[5/5] Post-docking analysis")
    df = analyze_and_rank(
        results,
        receptor_paths=curated,
        cnn_score_threshold=config.cnn_score_threshold,
        min_interactions=config.min_interactions,
        output_csv=config.output,
    )

    log.info("Done in %.1fs — %d hits -> %s", time.time() - t0, len(df), config.output)
    return config.output


def _curate_all(pdbs: list[Path], ph: float, workers: int) -> dict[str, Path]:
    """Curate receptors in parallel, return {pdb_id: curated_path}."""
    curated: dict[str, Path] = {}
    with ProcessPoolExecutor(max_workers=workers) as pool:
        futs = {pool.submit(curate_receptor, p, ph): p for p in pdbs}
        for f in as_completed(futs):
            p = futs[f]
            try:
                out = f.result()
                if out:
                    curated[p.stem] = out
                else:
                    log.warning("Skipped %s", p.stem)
            except Exception as exc:
                log.error("%s curation crashed: %s", p.stem, exc)
    return curated
