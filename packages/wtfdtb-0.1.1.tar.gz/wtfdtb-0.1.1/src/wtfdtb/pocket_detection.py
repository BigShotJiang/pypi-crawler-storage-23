"""Phase 3: Pocket detection via P2Rank.

Shells out to the P2Rank Java CLI, parses the predictions CSV.
Needs Java >= 11 and the P2Rank binary (PRANK_HOME or on PATH).
"""

from __future__ import annotations

import csv
import logging
import os
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path

log = logging.getLogger("wtfdtb.pocket")


@dataclass
class Pocket:
    """A predicted binding site."""

    name: str
    score: float
    probability: float
    center_x: float
    center_y: float
    center_z: float
    residue_ids: list[str]


def find_prank_executable() -> str:
    """Look for `prank` in PRANK_HOME, then common install locations, then on PATH."""
    # 1. PRANK_HOME env var
    env = os.environ.get("PRANK_HOME")
    if env:
        p = Path(env) / "prank"
        if p.exists():
            return str(p)
        if Path(env).is_file():
            return env

    # 2. Default installer locations
    fallbacks = [
        Path.home() / ".local" / "share" / "wtfdtb" / "p2rank_2.4.2" / "prank",
        Path.home() / ".local" / "share" / "p2rank" / "p2rank_2.4.2" / "prank",
    ]
    for fb in fallbacks:
        if fb.exists():
            return str(fb)

    # 3. System PATH
    found = shutil.which("prank")
    if found:
        return found

    raise RuntimeError(
        "P2Rank not found. Set PRANK_HOME or put 'prank' on PATH. "
        "https://github.com/rdk/p2rank/releases"
    )


def detect_pockets(pdb_path: Path, output_dir: Path) -> list[Pocket]:
    """Run P2Rank on one PDB, return pockets sorted by score (best first)."""
    prank = find_prank_executable()
    output_dir.mkdir(parents=True, exist_ok=True)

    cmd = [prank, "predict", "-f", str(pdb_path), "-o", str(output_dir)]
    log.info("Running: %s", " ".join(cmd))

    r = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
    if r.returncode != 0:
        log.error(
            "P2Rank failed (exit %d): %s", r.returncode, r.stderr[-500:] if r.stderr else "?"
        )
        return []

    return _parse_predictions(output_dir, pdb_path.stem)


def detect_pockets_batch(pdb_paths: list[Path], output_dir: Path) -> dict[str, list[Pocket]]:
    """Run P2Rank on a list of PDBs."""
    out: dict[str, list[Pocket]] = {}
    for pdb in pdb_paths:
        pid = pdb.stem
        pockets = detect_pockets(pdb, output_dir / pid)
        out[pid] = pockets
        if pockets:
            log.info("%s: %d pocket(s), best score %.2f", pid, len(pockets), pockets[0].score)
        else:
            log.warning("%s: no pockets found", pid)
    return out


def _parse_predictions(output_dir: Path, pdb_stem: str) -> list[Pocket]:
    """Read P2Rank's *_predictions.csv into Pocket objects."""
    pred = output_dir / f"{pdb_stem}_predictions.csv"

    if not pred.exists():
        # P2Rank sometimes nests the output
        hits = list(output_dir.rglob("*_predictions.csv"))
        if not hits:
            log.warning("No predictions CSV in %s", output_dir)
            return []
        pred = hits[0]

    pockets = []
    with open(pred, newline="") as fh:
        for row in csv.DictReader(fh):
            clean = {k.strip(): v.strip() for k, v in row.items()}
            try:
                pockets.append(
                    Pocket(
                        name=clean.get("name", f"pocket_{len(pockets) + 1}"),
                        score=float(clean.get("score", 0)),
                        probability=float(clean.get("probability", 0)),
                        center_x=float(clean.get("center_x", 0)),
                        center_y=float(clean.get("center_y", 0)),
                        center_z=float(clean.get("center_z", 0)),
                        residue_ids=clean.get("residue_ids", "").split(),
                    )
                )
            except (ValueError, KeyError) as exc:
                log.warning("Bad pocket row: %s", exc)

    return pockets
