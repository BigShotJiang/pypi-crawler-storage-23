"""Shared helpers: PDB fetching, target input parsing, logging config."""

from __future__ import annotations

import logging
import shutil
import urllib.request
from pathlib import Path

log = logging.getLogger("wtfdtb")

RCSB_URL = "https://files.rcsb.org/download/{pdb_id}.pdb"


def fetch_pdb(pdb_id: str, output_dir: Path) -> Path:
    """Download a PDB from RCSB. Returns path to the local file.

    Caches by filename — won't re-download if the file already exists.
    """
    pdb_id = pdb_id.strip().upper()
    if len(pdb_id) != 4:
        raise ValueError(f"PDB ID must be 4 characters, got '{pdb_id}'")

    output_dir.mkdir(parents=True, exist_ok=True)
    dest = output_dir / f"{pdb_id}.pdb"

    if dest.exists():
        log.info("PDB %s already cached at %s", pdb_id, dest)
        return dest

    url = RCSB_URL.format(pdb_id=pdb_id)
    log.info("Fetching %s from RCSB...", pdb_id)

    try:
        with urllib.request.urlopen(url, timeout=30) as resp, dest.open("wb") as fh:
            shutil.copyfileobj(resp, fh)
    except Exception as exc:
        dest.unlink(missing_ok=True)  # don't leave a partial file behind
        raise RuntimeError(f"Failed to download PDB {pdb_id}: {exc}") from exc

    log.info("Got %s (%d bytes)", pdb_id, dest.stat().st_size)
    return dest


def parse_target_input(targets_path: Path, download_dir: Path | None = None) -> list[Path]:
    """Turn the --targets arg into a list of local .pdb paths.

    Two modes:
      - Directory: just glob *.pdb
      - Text file: one PDB ID per line, download each from RCSB
    """
    if not targets_path.exists():
        raise FileNotFoundError(f"Targets path not found: {targets_path}")

    # directory of PDB files
    if targets_path.is_dir():
        pdbs = sorted(targets_path.glob("*.pdb"))
        if not pdbs:
            raise ValueError(f"No .pdb files in {targets_path}")
        log.info("Found %d PDB files in %s", len(pdbs), targets_path)
        return pdbs

    # text file with PDB IDs
    if download_dir is None:
        download_dir = targets_path.parent / "pdbs"

    raw = targets_path.read_text().splitlines()
    pdb_ids = [line.strip() for line in raw if line.strip() and not line.startswith("#")]

    if not pdb_ids:
        raise ValueError(f"No PDB IDs found in {targets_path}")

    log.info("Parsed %d PDB IDs from %s", len(pdb_ids), targets_path)

    pdbs: list[Path] = []
    for pid in pdb_ids:
        try:
            pdbs.append(fetch_pdb(pid, download_dir))
        except (ValueError, RuntimeError) as exc:
            log.warning("Skipping %s: %s", pid, exc)

    if not pdbs:
        raise ValueError("Couldn't obtain any PDB files from the target list.")

    return sorted(pdbs)


def setup_logging(verbosity: int = 1) -> None:
    """Configure wtfdtb logger. 0=WARNING, 1=INFO, 2=DEBUG."""
    levels = {0: logging.WARNING, 1: logging.INFO, 2: logging.DEBUG}
    level = levels.get(verbosity, logging.DEBUG)

    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter("[%(levelname)s] %(name)s | %(message)s"))

    root = logging.getLogger("wtfdtb")
    root.setLevel(level)
    root.handlers.clear()
    root.addHandler(handler)


def ensure_work_dir(base: Path, name: str = "work") -> Path:
    """Create (if needed) and return a working directory for intermediate files."""
    d = base / name
    d.mkdir(parents=True, exist_ok=True)
    return d
