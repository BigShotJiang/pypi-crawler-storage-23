"""Phase 2: Receptor curation.

Raw PDB -> gap check -> strip HETATM/water -> PDBFixer (missing atoms)
        -> PDB2PQR/PROPKA (protonate at pH) -> clean PDB for GNINA.
"""

from __future__ import annotations

import io
import logging
import tempfile
from pathlib import Path

log = logging.getLogger("wtfdtb.receptor")

MAX_CONTIGUOUS_GAP = 50  # reject if any loop gap exceeds this


def curate_receptor(pdb_path: Path, ph: float = 7.4) -> Path | None:
    """Clean, repair, and protonate a single receptor PDB.

    Returns the path to the curated file, or None if the structure
    has too many missing residues to be usable.
    """
    pdb_id = pdb_path.stem

    if _has_large_gap(pdb_path):
        log.warning("%s: skipped — gap > %d contiguous residues", pdb_id, MAX_CONTIGUOUS_GAP)
        return None

    cleaned = _strip_hetatm(pdb_path)
    log.info("%s: stripped HETATM/water", pdb_id)

    fixed = _fix_missing_atoms(cleaned, pdb_id)
    log.info("%s: repaired missing heavy atoms", pdb_id)

    out = pdb_path.parent / f"{pdb_id}_curated.pdb"
    _protonate(fixed, out, ph)
    log.info("%s: protonated at pH %.1f -> %s", pdb_id, ph, out)

    return out


def _has_large_gap(pdb_path: Path) -> bool:
    """Check REMARK 465 for contiguous missing-residue runs."""
    missing_by_chain: dict[str, list[int]] = {}
    with open(pdb_path) as fh:
        for line in fh:
            if not line.startswith("REMARK 465"):
                continue
            parts = line.split()
            if len(parts) >= 5:
                try:
                    chain, resseq = parts[3], int(parts[4])
                    missing_by_chain.setdefault(chain, []).append(resseq)
                except (ValueError, IndexError):
                    continue

    for _chain, residues in missing_by_chain.items():
        residues.sort()
        run = 1
        for i in range(1, len(residues)):
            if residues[i] == residues[i - 1] + 1:
                run += 1
                if run > MAX_CONTIGUOUS_GAP:
                    return True
            else:
                run = 1
    return False


def _strip_hetatm(pdb_path: Path) -> list[str]:
    """Drop all HETATM records (ligands, ions, HOH) via pdb-tools."""
    from pdbtools import pdb_delhetatm

    with open(pdb_path) as fh:
        lines = fh.readlines()
    return list(pdb_delhetatm.run(lines))


def _fix_missing_atoms(pdb_lines: list[str], pdb_id: str) -> Path:
    """Model missing heavy atoms with PDBFixer. Returns path to fixed PDB."""
    from openmm.app import PDBFile
    from pdbfixer import PDBFixer

    fixer = PDBFixer(pdbfile=io.StringIO("".join(pdb_lines)))
    fixer.findMissingResidues()
    fixer.findMissingAtoms()
    fixer.addMissingAtoms()

    with tempfile.NamedTemporaryFile(suffix=f"_{pdb_id}_fixed.pdb", delete=False, mode="w") as tmp:
        PDBFile.writeFile(fixer.topology, fixer.positions, tmp)
        tmp_path = Path(tmp.name)

    return tmp_path


def _protonate(input_pdb: Path, output_pdb: Path, ph: float) -> None:
    """PDB2PQR + PROPKA -> protonated PQR -> convert back to PDB."""
    from pdb2pqr import run_pdb2pqr

    with tempfile.NamedTemporaryFile(suffix=".pqr", delete=False) as f:
        pqr = Path(f.name)

    run_pdb2pqr(
        [
            "--ff=PARSE",
            f"--with-ph={ph}",
            "--titration-state-method=propka",
            "--keep-chain",
            str(input_pdb),
            str(pqr),
        ]
    )

    _pqr_to_pdb(pqr, output_pdb)
    pqr.unlink(missing_ok=True)
    input_pdb.unlink(missing_ok=True)


def _pqr_to_pdb(pqr_path: Path, pdb_path: Path) -> None:
    """Rewrite PQR as standard PDB (swap charge/radius for occupancy/bfactor)."""
    out = []
    with open(pqr_path) as fh:
        for line in fh:
            if line.startswith(("ATOM", "HETATM")):
                # PQR columns are slightly shifted; grab what we need
                rec = line[:6]
                anum = line[6:11]
                aname = line[12:16]
                rname = line[17:20]
                chain = line[21]
                rseq = line[22:26]
                x, y, z = line[30:38], line[38:46], line[46:54]
                out.append(f"{rec}{anum} {aname} {rname} {chain}{rseq}    {x}{y}{z}  1.00  0.00\n")
            elif line.startswith(("TER", "END")):
                out.append(line)
    pdb_path.write_text("".join(out))
