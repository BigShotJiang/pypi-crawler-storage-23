"""Phase 1: Ligand preparation.

SMILES/SDF -> Dimorphite-DL (protonate at pH) -> RDKit (3D embed + MMFF94)
           -> Meeko (Gasteiger charges, torsion tree) -> PDBQT string.
"""

from __future__ import annotations

import logging
from pathlib import Path

from rdkit import Chem
from rdkit.Chem import AllChem

log = logging.getLogger("wtfdtb.ligand_prep")


def prepare_ligand(input_path: Path, ph: float = 7.4) -> str:
    """Read a ligand, protonate it, embed 3D coords, and return a PDBQT string."""
    mol = _read_molecule(input_path)
    smiles = Chem.MolToSmiles(mol)
    log.info("Input molecule: %s", smiles)

    protonated_smi = _protonate(smiles, ph)
    log.info("Protonated SMILES (pH %.1f): %s", ph, protonated_smi)

    mol_3d = _embed_and_minimise(protonated_smi)
    log.info("3D coords generated and MMFF94-minimised")

    pdbqt = _to_pdbqt(mol_3d)
    log.info("PDBQT string ready (%d chars)", len(pdbqt))
    return pdbqt


def _read_molecule(path: Path) -> Chem.Mol:
    """Read a molecule from SDF, MOL, MOL2, or SMILES file."""
    suffix = path.suffix.lower()

    if suffix in (".sdf", ".mol"):
        suppl = Chem.SDMolSupplier(str(path), removeHs=False)
        for mol in suppl:
            if mol is not None:
                return mol
        raise ValueError(f"Could not read any valid molecule from {path}")

    if suffix in (".smi", ".smiles"):
        text = path.read_text().strip().splitlines()
        for line in text:
            line = line.strip()
            if line and not line.startswith("#"):
                smi = line.split()[0]  # "SMILES name" format
                mol = Chem.MolFromSmiles(smi)
                if mol is not None:
                    return mol
        raise ValueError(f"No valid SMILES found in {path}")

    if suffix == ".mol2":
        mol = Chem.MolFromMol2File(str(path), removeHs=False)
        if mol is None:
            raise ValueError(f"Could not parse MOL2 file: {path}")
        return mol

    raise ValueError(f"Unsupported file format: {suffix}")


def _protonate(smiles: str, ph: float) -> str:
    """Pick the dominant protonation state at *ph* using Dimorphite-DL.

    We use a tight pH window (+-0.2) so we get the single most likely
    microstate rather than a combinatorial explosion.
    """
    from dimorphite_dl import protonate_smiles

    margin = 0.2
    results = protonate_smiles(
        smiles_input=[smiles],
        ph_min=ph - margin,
        ph_max=ph + margin,
        precision=0.5,
        max_variants=8,
    )
    if not results:
        log.warning("Dimorphite-DL returned nothing; falling back to original SMILES")
        return smiles
    return results[0]


def _embed_and_minimise(smiles: str) -> Chem.Mol:
    """ETKDGv3 distance-geometry embedding + MMFF94 energy minimisation."""
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        raise ValueError(f"RDKit couldn't parse protonated SMILES: {smiles}")

    mol = Chem.AddHs(mol)

    params = AllChem.ETKDGv3()
    params.randomSeed = 42

    conf_id = AllChem.EmbedMolecule(mol, params)
    if conf_id < 0:
        # some molecules need random initial coords to converge
        log.warning("ETKDGv3 failed — retrying with random coordinates")
        params.useRandomCoords = True
        conf_id = AllChem.EmbedMolecule(mol, params)
        if conf_id < 0:
            raise ValueError("Could not generate 3D coordinates")

    result = AllChem.MMFFOptimizeMolecule(mol, mmffVariant="MMFF94", maxIters=2000)
    if result == -1:
        raise ValueError("MMFF94 force field setup failed for this molecule")
    if result == 1:
        log.warning("MMFF94 didn't converge in 2000 iterations (probably fine)")

    return mol


def _to_pdbqt(mol: Chem.Mol) -> str:
    """Convert a 3D RDKit mol to PDBQT via Meeko (Gasteiger charges + torsion tree)."""
    from meeko import MoleculePreparation, PDBQTWriterLegacy

    preparator = MoleculePreparation()
    mol_setups = preparator.prepare(mol)

    if not mol_setups:
        raise ValueError("Meeko couldn't prepare the molecule")

    pdbqt_string, is_ok, err_msg = PDBQTWriterLegacy.write_string(mol_setups[0])
    if not is_ok:
        raise ValueError(f"PDBQT generation failed: {err_msg}")
    return pdbqt_string
