"""Auto-installer for WTFDTB external binary dependencies on Linux."""

import os
import shutil
import stat
import tarfile
from pathlib import Path

import requests
import typer
from tqdm import tqdm

GNINA_URL = "https://github.com/gnina/gnina/releases/download/v1.0.3/gnina"
P2RANK_URL = "https://github.com/rdk/p2rank/releases/download/2.4.2/p2rank_2.4.2.tar.gz"

LOCAL_BIN = Path.home() / ".local" / "bin"
LOCAL_SHARE = Path.home() / ".local" / "share" / "wtfdtb"


def _download_file(url: str, output_path: Path, desc: str) -> None:
    """Download a file with a progress bar."""
    response = requests.get(url, stream=True)
    response.raise_for_status()
    total_size = int(response.headers.get("content-length", 0))

    output_path.parent.mkdir(parents=True, exist_ok=True)

    with (
        open(output_path, "wb") as f,
        tqdm(
            desc=desc,
            total=total_size,
            unit="iB",
            unit_scale=True,
            unit_divisor=1024,
        ) as bar,
    ):
        for data in response.iter_content(chunk_size=1024):
            size = f.write(data)
            bar.update(size)


def install_gnina() -> None:
    """Download GNINA executable and place in ~/.local/bin."""
    typer.echo("[*] Installing GNINA (Neural Network Docking)...")
    gnina_bin = LOCAL_BIN / "gnina"

    if gnina_bin.exists():
        typer.echo("    GNINA is already installed.")
        return

    _download_file(GNINA_URL, gnina_bin, "Downloading GNINA")

    # Make executable
    st = os.stat(gnina_bin)
    os.chmod(gnina_bin, st.st_mode | stat.S_IEXEC)
    typer.echo(f"[+] GNINA installed to {gnina_bin}")


def install_p2rank() -> None:
    """Download P2Rank, extract, and configure."""
    typer.echo("\n[*] Installing P2Rank (ML Pocket Detection)...")
    p2rank_dir = LOCAL_SHARE / "p2rank_2.4.2"

    if p2rank_dir.exists():
        typer.echo("    P2Rank is already installed.")
        return

    LOCAL_SHARE.mkdir(parents=True, exist_ok=True)
    tar_path = LOCAL_SHARE / "p2rank.tar.gz"

    _download_file(P2RANK_URL, tar_path, "Downloading P2Rank")

    typer.echo("    Extracting P2Rank...")
    with tarfile.open(tar_path, "r:gz") as tar:
        tar.extractall(path=LOCAL_SHARE)

    tar_path.unlink()

    typer.echo(f"[+] P2Rank installed to {p2rank_dir}")
    typer.echo("[i] Note: wtfdtb will auto-detect this location.")
    typer.echo("    (Optional) To use P2Rank from other tools, add this to your .bashrc:")
    typer.echo(f"    export PRANK_HOME={p2rank_dir}")


def _add_to_path() -> None:
    """Attempt to add ~/.local/bin to .bashrc if not already present."""
    local_bin_str = str(LOCAL_BIN)
    if local_bin_str not in os.environ.get("PATH", ""):
        bashrc = Path.home() / ".bashrc"
        if bashrc.exists():
            content = bashrc.read_text()
            line = f'export PATH="$PATH:{local_bin_str}"'
            if line not in content:
                typer.echo(f"[*] Adding {LOCAL_BIN} to your .bashrc...")
                with open(bashrc, "a") as f:
                    f.write(f"\n# Added by wtfdtb\n{line}\n")
                typer.echo("    Please run: source ~/.bashrc")


def run_install() -> None:
    """Execute the installation sequence."""
    if os.name == "nt":
        typer.echo("[-] WARNING: WTFDTB is designed for Linux/WSL.")
        typer.echo("    Proceeding with Linux binary installation anyway...")

    typer.echo("WTFDTB Auto-Installer")
    typer.echo("---------------------")

    try:
        install_gnina()
        install_p2rank()

        # Check for Java (required by P2Rank)
        if shutil.which("java") is None:
            typer.echo("\n[-] WARNING: Java (openjdk) is not installed!")
            typer.echo("    P2Rank requires Java >= 11 to run.")
            typer.echo("    Please run: sudo apt install default-jre")
        else:
            typer.echo("\n[+] Java detected.")

        _add_to_path()

        typer.echo("\n✅ Installation complete. The pipeline is ready.")
        typer.echo("Try running: wtfdtb --help")

    except Exception as e:
        typer.echo(f"\n[!] Installation failed: {e}")
        raise typer.Exit(code=1) from e
