# WTFDTB — High-Throughput Inverse Virtual Screening Pipeline

## Goal

Build a fully automated CLI (`wtfdtb`) that takes a single small-molecule ligand and docks it against a library of protein structures using a state-of-the-art ML/DL stack. Distribute via Bioconda/Conda-Forge. Target: wet-lab researchers with zero-friction installation.

## Project Type

**BACKEND** — Python 3.10+ CLI tool. No frontend, no mobile.

## Success Criteria

- `mamba install wtfdtb` installs all Python + non-Python deps (Java, GNINA)
- `wtfdtb screen --ligand aspirin.sdf --targets ./pdbs/ --output results.csv` runs end-to-end
- Output CSV ranked by CNNaffinity (after CNNscore ≥ 0.5 filter) with ProLIF interaction columns
- Receptor curation and docking both parallelized via `ProcessPoolExecutor`
- Invalid proteins (>10 missing contiguous residues) rejected with logged reason

---

## Tech Stack

| Layer | Tool | Why |
|-------|------|-----|
| CLI Framework | `typer` | Type-hinted, auto-generates `--help`, minimal boilerplate |
| Protonation (ligand) | `dimorphite_dl` | pH 7.4 microstate enumeration |
| 3D Coordinates | `RDKit` (ETKDGv3 + MMFF94) | Gold standard cheminformatics |
| PDBQT Generation | `meeko` | AutoDock ecosystem, torsion tree + Gasteiger charges |
| PDB Parsing | `biopython` | REMARK 465 header parsing for missing residues |
| PDB Cleaning | `pdb-tools` | Strip HETATM/water in-memory |
| Structure Repair | `pdbfixer` (OpenMM) | Model minor missing heavy atoms |
| Protonation (receptor) | `pdb2pqr` + PROPKA | Rigorous pKa at pH 7.4 |
| Pocket Detection | `P2Rank` (Java binary) | ML-based, no template bias |
| Docking Engine | `GNINA` (C++ binary) | CNN-rescored poses, superior to Vina |
| Interaction Fingerprints | `prolif` | Protein-ligand interaction profiling |
| Data/Output | `pandas` | CSV export, filtering, ranking |
| Parallelism | `concurrent.futures` | ProcessPoolExecutor for Phase 2 + Phase 4 |

---

## File Structure

```
WTFDTB/
├── pyproject.toml              # Package metadata, deps, entry point
├── recipe/
│   └── meta.yaml               # Bioconda/Conda-Forge recipe
├── src/
│   └── wtfdtb/
│       ├── __init__.py          # Version string
│       ├── cli.py               # Typer app, all CLI flags
│       ├── ligand_prep.py       # Phase 1: SMILES/SDF → protonated PDBQT
│       ├── receptor_curation.py # Phase 2: PDB → cleaned, protonated PDBQT
│       ├── pocket_detection.py  # Phase 3: P2Rank batch → pocket centers
│       ├── docking.py           # Phase 4: GNINA subprocess dispatch
│       ├── post_dock.py         # Phase 5: Meeko parse, ProLIF, ranking
│       ├── pipeline.py          # Orchestrator: wires Phase 1–5
│       └── utils.py             # Logging, PDB fetcher, shared helpers
├── tests/
│   └── ...                      # Per-module tests (added with each module)
└── README.md
```

---

## Task Breakdown

### Module 0: Scaffold & Packaging (This PR)
- [ ] Create directory structure above
- [ ] Write `pyproject.toml` — `[project]` metadata, `[project.scripts]` entry point `wtfdtb = "wtfdtb.cli:app"`, all Python deps
- [ ] Write `recipe/meta.yaml` — Conda recipe pinning Python deps + `openjdk` (P2Rank) + `gnina` (docking)
- [ ] Write `src/wtfdtb/__init__.py` with `__version__`
- [ ] `git init`, initial commit: `feat: scaffold project with pyproject.toml and conda recipe`
- **Verify**: `pip install -e .` succeeds; `wtfdtb --help` prints (even if no commands yet)

---

### Module 1: CLI Entry Point (`cli.py`)
- [ ] Define Typer app with `screen` command
- [ ] Flags: `--ligand` (Path), `--targets` (Path to dir or ID list), `--output` (Path, default `results.csv`), `--ph` (float, default 7.4), `--box-size` (int, default 25), `--cnn-model` (str, default `default`), `--cnn-score-threshold` (float, default 0.5), `--min-interactions` (int, default 1), `--workers` (int, default CPU count), `--exhaustiveness` (int, default 8), `--verbosity` (int)
- [ ] Input validation: ligand file exists, targets path exists, pH in range
- [ ] Commit: `feat(cli): add screen command with all pipeline flags`
- **Verify**: `wtfdtb screen --help` prints all flags with descriptions

---

### Module 2: Ligand Preparation (`ligand_prep.py`)
- [ ] `prepare_ligand(input_path: Path, ph: float) -> str` returning PDBQT string
- [ ] Step 1: Read SMILES or SDF → RDKit mol
- [ ] Step 2: Dimorphite-DL → enumerate physiological protonation at given pH
- [ ] Step 3: RDKit ETKDGv3 → 3D embed + MMFF94 minimize
- [ ] Step 4: Meeko `MoleculePreparation` → PDBQT string (Gasteiger charges, torsion tree)
- [ ] Commit: `feat(ligand): add physiological ligand preparation module`
- **Verify**: Pass aspirin SMILES → get valid PDBQT string with `BEGIN_RES`/`END_RES` blocks

---

### Module 3: Receptor Curation (`receptor_curation.py`)
- [ ] `curate_receptor(pdb_path: Path, ph: float) -> Path | None`
- [ ] Step 1: Biopython parse REMARK 465 → reject if >10 contiguous missing residues
- [ ] Step 2: pdb-tools → strip HETATM + water
- [ ] Step 3: PDBFixer → model minor missing heavy atoms
- [ ] Step 4: PDB2PQR/PROPKA → assign protonation at pH
- [ ] Step 5: Meeko → rigid receptor PDBQT
- [ ] Return `None` + log reason on rejection
- [ ] Commit: `feat(receptor): add rigorous receptor curation pipeline`
- **Verify**: Known test PDB (e.g., 1AKE) passes; PDB with large gap is rejected

---

### Module 4: Pocket Detection (`pocket_detection.py`)
- [ ] `detect_pockets(pdb_dir: Path, p2rank_bin: Path) -> dict[str, tuple[float,float,float]]`
- [ ] Compile batch input file listing all repaired PDBs
- [ ] `subprocess.run()` P2Rank once in batch mode
- [ ] Parse output CSVs → extract Center of Mass (X,Y,Z) of top-ranked pocket per protein
- [ ] Commit: `feat(pocket): add P2Rank batch pocket detection`
- **Verify**: Run on known PDB → pocket center within 5 Å of known binding site

---

### Module 5: Docking (`docking.py`)
- [ ] `dock_library(ligand_pdbqt, receptors, pockets, config) -> list[DockResult]`
- [ ] Build GNINA CLI args: `--receptor`, `--ligand`, `--cnn_scoring`, `--center_x/y/z`, `--size_x/y/z=25`, `--exhaustiveness`
- [ ] `ProcessPoolExecutor` dispatching `subprocess.run()` to GNINA binary
- [ ] Parse GNINA stdout → extract `CNNscore`, `CNNaffinity`, best pose PDBQT
- [ ] Hard filter: discard poses where `CNNscore < threshold`
- [ ] Commit: `feat(docking): add parallel GNINA docking with CNN rescoring`
- **Verify**: Dock aspirin against 2–3 test PDBs → CSV with scores populated

---

### Module 6: Post-Docking Analysis (`post_dock.py`)
- [ ] `analyze_poses(dock_results, receptors, min_interactions) -> pd.DataFrame`
- [ ] Meeko PDBQT parser → reconstruct RDKit mol from docked pose (avoid sanitization crash)
- [ ] ProLIF → compute interaction fingerprint per pose
- [ ] Track: `Num_HBonds`, `Num_Hydrophobic`, `Num_PiStacking`, `Num_SaltBridges`
- [ ] Soft filter: flag/discard poses with total interactions < `--min-interactions`
- [ ] Build DataFrame: Target, CNNscore, CNNaffinity, interaction columns
- [ ] Sort by `CNNaffinity` (ascending = stronger binding)
- [ ] Commit: `feat(postdock): add ProLIF interaction profiling and ranked output`
- **Verify**: Output CSV has correct columns, sorted order, filtered rows

---

### Module 7: Pipeline Orchestrator (`pipeline.py`)
- [ ] `run_pipeline(config: PipelineConfig) -> Path` wiring Phase 1→5
- [ ] Phase 1: Prepare ligand (single call)
- [ ] Phase 2: Curate receptors (parallel ProcessPoolExecutor)
- [ ] Phase 3: Detect pockets (single P2Rank batch call)
- [ ] Phase 4: Dock library (parallel ProcessPoolExecutor)
- [ ] Phase 5: Analyze and export CSV
- [ ] Progress logging at each phase boundary
- [ ] Commit: `feat(pipeline): wire all phases into orchestrator`
- **Verify**: End-to-end run with 2–3 test PDBs produces valid CSV

---

### Module 8: Utils & PDB Fetcher (`utils.py`)
- [ ] `fetch_pdb(pdb_id: str, output_dir: Path) -> Path` — download from RCSB
- [ ] `parse_target_input(targets_path: Path) -> list[Path]` — handle dir of PDBs OR text file of IDs
- [ ] Logging setup, temp directory management
- [ ] Commit: `feat(utils): add PDB fetcher and shared helpers`
- **Verify**: `fetch_pdb("1AKE", tmp)` returns valid `.pdb` file

---

## Git Commit Strategy

Each module = 1 Conventional Commit. Example history:

```
feat: scaffold project with pyproject.toml and conda recipe    ← Module 0
feat(cli): add screen command with all pipeline flags          ← Module 1
feat(utils): add PDB fetcher and shared helpers                ← Module 8*
feat(ligand): add physiological ligand preparation module      ← Module 2
feat(receptor): add rigorous receptor curation pipeline        ← Module 3
feat(pocket): add P2Rank batch pocket detection                ← Module 4
feat(docking): add parallel GNINA docking with CNN rescoring   ← Module 5
feat(postdock): add ProLIF interaction profiling and output    ← Module 6
feat(pipeline): wire all phases into orchestrator              ← Module 7
```

> *Module 8 (utils) is implemented early since Modules 2–3 depend on it.

---

## CLI Interface Summary

```bash
wtfdtb screen \
  --ligand aspirin.sdf \
  --targets ./protein_library/ \    # dir of PDBs OR text file of PDB IDs
  --output results.csv \
  --ph 7.4 \
  --box-size 25 \
  --cnn-model default \
  --cnn-score-threshold 0.5 \
  --min-interactions 1 \
  --workers 8 \
  --exhaustiveness 8
```

---

## Phase X: Verification Checklist

- [ ] `pip install -e .` → `wtfdtb screen --help` works
- [ ] End-to-end dry run with 2–3 known PDBs + aspirin
- [ ] Rejected PDB (missing loop) logged correctly
- [ ] CSV output has columns: `Target, CNNscore, CNNaffinity, Num_HBonds, Num_Hydrophobic, Num_PiStacking, Num_SaltBridges`
- [ ] CSV sorted by CNNaffinity after CNNscore filter
- [ ] Parallelism verified (receptor prep + docking use multiple cores)
- [ ] `conda build recipe/` parses without errors
