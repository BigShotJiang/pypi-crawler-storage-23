# WTFDTB Distribution Plan
**Project Type**: PYTHON CLI TOOL (with external binary dependencies)

## Overview
The goal is to distribute the `wtfdtb` inverse virtual screening CLI tool to end users in a way that minimizes installation friction, despite its heavy reliance on C++ frameworks (RDKit, OpenMM) and external standalone binaries (GNINA, P2Rank).

## Success Criteria
1. Users can install the tool with a single command (or at most two simple commands).
2. The `wtfdtb` command is automatically available on the user's `$PATH`.
3. Non-Python dependencies (GNINA, Java/P2Rank) are seamlessly acquired and configured without requiring manual compilation or path editing by the user.

## Tech Stack Options
There are three fundamental technical paths for distributing this application:

### Option A: Pure PyPI (`pip install wtfdtb`)
- **How it works:** We publish the source/wheel to Python Package Index. Users install via standard `pip`.
- **Pros:** Global visibility, the standard way Python developers expect to install tools.
- **Cons:** `pip` strictly installs Python packages. It cannot install Java, GNINA, or P2Rank. Users would have to read the README and install those binaries manually.

### Option B: Conda-Forge (`mamba install wtfdtb`)
- **How it works:** We write a strict Conda recipe (`meta.yaml`) detailing every dependency and submit it to the conda-forge community.
- **Pros:** Conda is designed specifically for this scenario (bioinformatics tools with massive binary dependencies). It can automatically install Python, RDKit, OpenMM, GNINA, and OpenJDK in one isolated environment in a single command. It "just works."
- **Cons:** Takes some time and effort to get the recipe approved by the conda-forge maintainers. 

### Option C: The Hybrid "Auto-Installer" (PyPI + Custom Command)
- **How it works:** We publish the core tool to PyPI so users can run `pip install wtfdtb`. But we also build a new CLI command (`wtfdtb install`) into the tool itself. When run, this Python script dynamically downloads the pre-compiled Linux GNINA and P2Rank binaries from GitHub over the internet, extracts them to a hidden `~/.local/` folder, and automatically configures the environment paths.
- **Pros:** Users don't have to fiddle with Conda if they don't want to. One `pip install` followed by one `wtfdtb install` gets them everything.
- **Cons:** Assumes the user is on Linux/WSL (which is our target environment) and has basic build tools available for any heavy Python wheels that need compilation.

## Task Breakdown

### Task 1: Initialize Packaging Infrastructure
- **Agent**: `orchestrator`
- **Output**: Cleaned and validated `pyproject.toml`
- **Verify**: `pip install -e .` succeeds locally.

### Task 2: Implement Hybrid Auto-Installer (Option C)
- **Agent**: `backend-specialist`
- **Output**: `src/wtfdtb/installer.py`
- **Verify**: `wtfdtb install` command successfully downloads and paths GNINA/P2Rank.

### Task 3: Finalize Conda Recipe (Option B fallback)
- **Agent**: `devops-engineer`
- **Output**: `recipe/meta.yaml`
- **Verify**: `conda build recipe/` compiles locally without missing dependencies.

### Task 4: GitHub Actions CI/CD Pipeline
- **Agent**: `devops-engineer`
- **Output**: `.github/workflows/publish.yml`
- **Verify**: Triggers on tag release, successfully builds wheel.

## Phase X: Verification
- Lint: [ ] 
- Security: [ ]
- Build: [ ]
- Cross-platform test: [ ]
