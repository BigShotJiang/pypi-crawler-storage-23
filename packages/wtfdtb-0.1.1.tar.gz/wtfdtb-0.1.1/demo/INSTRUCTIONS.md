# WTFDTB Demo Instructions

This directory contains classic examples for testing the Inverse Virtual Screening pipeline.

### 1. High-Affinity Example (Imatinib)
Imatinib (Gleevec) is a potent inhibitor of the ABL kinase.
Run this to see a strong binding result (Vina affinity should be < -10 kcal/mol):
```bash
wtfdtb screen --ligand ligand_imatinib.smi --targets targets.txt --output imatinib_results.csv
```

### 2. Common Drug Example (Aspirin)
Aspirin is a smaller molecule that binds to COX-2 (1PXX).
Run this to see how the tool handles smaller ligands:
```bash
wtfdtb screen --ligand ligand_aspirin.smi --targets targets.txt --output aspirin_results.csv
```

### What to check:
Open the output CSV files. The `rank 1` result should correctly identify the matching protein (e.g., Imatinib should rank `1IEP` at the top with a high CNNscore).
