# Project: Peapods

- Build Rust: `VIRTUAL_ENV=.venv .venv/bin/maturin develop --release`
- Paper PDFs and algorithm notes in `refs/` (gitignored) — see `refs/README.md`
