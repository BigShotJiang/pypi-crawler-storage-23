#!/usr/bin/python
# coding: utf-8
from systems_manager.mcp import systems_manager_mcp

if __name__ == "__main__":
    systems_manager_mcp()
