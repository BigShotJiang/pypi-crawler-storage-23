# This file is a part of Remoulade.
#
# Copyright (C) 2017,2018 CLEARTYPE SRL <bogdan@cleartype.io>
#
# Remoulade is free software; you can redistribute it and/or modify it
# under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or (at
# your option) any later version.
#
# Remoulade is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
# FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
# License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
import warnings

from .backend import RateLimitBackend
from .errors import RateLimitExceeded, RateLimitSpecificationError

try:
    from .middleware import RateLimitEnqueue, RateLimitProcess
except ImportError:
    warnings.warn(
        "RateLimit is not available.  Run `pip install remoulade[limits]` to add support for that middleware.",
        ImportWarning,
        stacklevel=2,
    )


__all__ = [
    "RateLimitBackend",
    "RateLimitEnqueue",
    "RateLimitExceeded",
    "RateLimitProcess",
    "RateLimitSpecificationError",
]
