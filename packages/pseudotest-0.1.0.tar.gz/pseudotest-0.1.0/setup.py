# This file is only needed for the automatic versioning in the conda recipe
import setuptools_scm
from setuptools import setup

setup(version=setuptools_scm.get_version())
