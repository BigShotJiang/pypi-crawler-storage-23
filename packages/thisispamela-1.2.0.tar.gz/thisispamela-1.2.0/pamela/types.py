"""
Typed request/response contracts for the Pamela Python SDK.

These TypedDicts mirror the backend Pydantic models from
``backend/models/b2b.py`` and ``backend/models/responses.py``.
They are the single source of truth for SDK consumers until
Stage 2 generates types from OpenAPI.
"""

from __future__ import annotations

from typing import Dict, List, Optional, Union

from typing_extensions import TypedDict

# ---------------------------------------------------------------------------
# JSON primitives
# ---------------------------------------------------------------------------

JSONPrimitive = Union[str, int, float, bool, None]
JSONValue = Union[JSONPrimitive, Dict[str, "JSONValue"], List["JSONValue"]]
JSONObject = Dict[str, JSONValue]

# ---------------------------------------------------------------------------
# Call types
# ---------------------------------------------------------------------------


class CallResponse(TypedDict, total=False):
    """Returned by ``create_call``, ``cancel_call``, ``hangup_call``."""

    id: str
    status: str
    call_session_id: str
    conversation_id: str
    created_at: str
    updated_at: str
    to: str
    from_number: str
    task: str
    message: str
    success: bool


class CallStatusResponse(TypedDict, total=False):
    """Returned by ``get_call``."""

    id: str
    status: str
    call_session_id: str
    conversation_id: str
    duration_seconds: int
    billed_minutes: int
    transcript: str
    summary: str
    created_at: str
    started_at: str
    ended_at: str
    metadata: JSONObject
    message: str
    success: bool


class CallListResponse(TypedDict, total=False):
    """Returned by ``list_calls``."""

    items: List[CallStatusResponse]
    total: int
    limit: int
    offset: int
    has_more: bool
    next_offset: Optional[int]


# ---------------------------------------------------------------------------
# Tool types
# ---------------------------------------------------------------------------


class ToolDefinition(TypedDict, total=False):
    """A registered tool definition."""

    id: str
    name: str
    description: str
    active: bool
    input_schema: JSONObject
    output_schema: JSONObject
    timeout_ms: int
    created_at: str
    updated_at: str


class ToolRegistration(TypedDict, total=False):
    """Returned by ``register_tool``."""

    success: bool
    message: str
    tool_id: str
    tool: ToolDefinition


class ToolDeleteResponse(TypedDict, total=False):
    """Returned by ``delete_tool``."""

    success: bool
    message: str
    tool_id: str


# ---------------------------------------------------------------------------
# Usage types
# ---------------------------------------------------------------------------


class UsageQuota(TypedDict, total=False):
    """Quota limits within a :class:`UsageResponse`."""

    partner_limit: Optional[int]
    project_limit: Optional[int]


class UsageResponse(TypedDict, total=False):
    """Returned by ``usage.get``."""

    partner_id: str
    project_id: Optional[str]
    period: str
    call_count: int
    api_minutes: float
    billed_minutes: int
    quota: UsageQuota


# ---------------------------------------------------------------------------
# Webhook types
# ---------------------------------------------------------------------------


class ToolWebhookParsed(TypedDict):
    """Returned by :func:`parse_tool_webhook`."""

    tool_name: str
    arguments: JSONObject
    call_id: str
    correlation_id: str
    call_session_id: Optional[str]
    partner_id: Optional[str]
    project_id: Optional[str]


class WebhookDelivery(TypedDict, total=False):
    """A webhook delivery record (for consumers tracking delivery status)."""

    id: str
    event: str
    target_url: str
    status: str
    attempts: int
    response_status: Optional[int]
    delivered_at: Optional[str]
    created_at: str
    error: Optional[str]
