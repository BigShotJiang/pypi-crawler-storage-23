"""
Pamela Enterprise Voice API SDK for Python

This SDK provides a Pythonic interface to the Pamela Enterprise Voice API,
including call management, tool registration, webhook verification, and
structured error handling.

Example:
    >>> from pamela import PamelaClient
    >>> client = PamelaClient(api_key="pk_live_your_key")
    >>> call = client.create_call(to="+1234567890", task="Schedule meeting")
    >>> print(call["id"])
"""

from pamela.client import PamelaClient, UsageClient
from pamela.exceptions import (
    AuthenticationError,
    CallError,
    PamelaError,
    RateLimitError,
    SubscriptionError,
    ValidationError,
)
from pamela.types import (
    CallListResponse,
    CallResponse,
    CallStatusResponse,
    ToolDefinition,
    ToolDeleteResponse,
    ToolRegistration,
    ToolWebhookParsed,
    UsageQuota,
    UsageResponse,
    WebhookDelivery,
)
from pamela.webhooks import (
    create_tool_handler,
    parse_tool_webhook,
    verify_webhook_signature,
)

# Alias for backward compatibility with tests
Pamela = PamelaClient

__all__ = [
    # Client
    "PamelaClient",
    "Pamela",
    "UsageClient",
    # Types
    "CallResponse",
    "CallStatusResponse",
    "CallListResponse",
    "ToolDefinition",
    "ToolRegistration",
    "ToolDeleteResponse",
    "UsageQuota",
    "UsageResponse",
    "ToolWebhookParsed",
    "WebhookDelivery",
    # Webhooks
    "verify_webhook_signature",
    "create_tool_handler",
    "parse_tool_webhook",
    # Exceptions
    "PamelaError",
    "AuthenticationError",
    "SubscriptionError",
    "RateLimitError",
    "ValidationError",
    "CallError",
]
__version__ = "1.2.0"
