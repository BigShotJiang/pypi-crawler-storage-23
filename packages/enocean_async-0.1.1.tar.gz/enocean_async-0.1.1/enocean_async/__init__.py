"""
An async implementation of the EnOcean Serial Protocol Version 3.
"""

__version__ = "0.1.1"
__date__ = "2026-02-18"
