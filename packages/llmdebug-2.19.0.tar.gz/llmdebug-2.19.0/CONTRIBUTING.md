# Contributing to llmdebug

Thanks for contributing.

## Development setup

1. Install `uv` (https://docs.astral.sh/uv/).
2. Clone the repository.
3. Install dependencies:

```bash
uv sync --extra dev
```

## Local quality checks

Run these before opening a PR:

```bash
uv run ruff check src tests
uv run pyright
uv run pytest
```

If you touch eval tooling or case metadata, also run:

```bash
uv run python -m evals.validate_cases --schema-only
```

## Coding guidelines

- Target Python 3.10+.
- Use 4-space indentation, max line length 100.
- Keep changes focused and minimal.
- Add regression tests for bug fixes and behavior changes.
- Prefer clear, typed APIs for new or changed code paths.

## Commit and PR guidelines

- Prefer Conventional Commits:
  - `feat: ...`
  - `fix: ...`
  - `perf: ...`
  - `docs: ...`
  - `test: ...`
  - `chore: ...`
- Include a concise summary of problem and solution.
- Link related issues when applicable.
- Include evidence (test output or command output) for behavior changes.

## Release notes

Releases are managed with semantic-release from commit history. Commit messages
directly affect versioning and changelog generation.
