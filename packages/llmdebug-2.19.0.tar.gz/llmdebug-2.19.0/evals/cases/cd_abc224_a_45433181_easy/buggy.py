S = input()

if S[-2] == "er":
    print("er")
else:
    print("ist")
