s = input()
print("er" if s[-2:] == "er" else "est")
