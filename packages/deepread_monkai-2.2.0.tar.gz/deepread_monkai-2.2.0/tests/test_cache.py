"""Testes para o sistema de cache do DeepRead."""

import time

import pytest

from deepread.cache import DocumentCache
from deepread.models.result import (
    DocumentMetadata,
    ProcessingMetrics,
    ProcessingResult,
    Result,
)


def _make_result(filename="test.pdf", answer="ok") -> ProcessingResult:
    return ProcessingResult(
        document=DocumentMetadata(filename=filename),
        results=[Result(question_id="q1", answer=answer, status="OK")],
        total_metrics=ProcessingMetrics(),
    )


class TestDocumentCache:
    def test_put_and_get(self):
        cache = DocumentCache(ttl_seconds=60, max_size=10)
        pr = _make_result()
        cache.put("key1", pr)
        assert cache.get("key1") is pr

    def test_miss_returns_none(self):
        cache = DocumentCache()
        assert cache.get("nonexistent") is None

    def test_ttl_expiration(self):
        cache = DocumentCache(ttl_seconds=1, max_size=10)
        pr = _make_result()
        cache.put("key1", pr)
        assert cache.get("key1") is pr
        time.sleep(1.1)
        assert cache.get("key1") is None

    def test_lru_eviction(self):
        cache = DocumentCache(ttl_seconds=60, max_size=2)
        cache.put("a", _make_result(answer="a"))
        cache.put("b", _make_result(answer="b"))
        cache.get("a")
        cache.put("c", _make_result(answer="c"))
        assert cache.get("b") is None
        assert cache.get("a") is not None
        assert cache.get("c") is not None

    def test_clear(self):
        cache = DocumentCache()
        cache.put("k", _make_result())
        assert cache.size == 1
        cache.clear()
        assert cache.size == 0
        assert cache.get("k") is None

    def test_stats(self):
        cache = DocumentCache()
        cache.put("k", _make_result())
        cache.get("k")
        cache.get("miss")
        stats = cache.stats
        assert stats["hits"] == 1
        assert stats["misses"] == 1
        assert stats["size"] == 1

    def test_hash_document(self):
        h1 = DocumentCache.hash_document(b"hello")
        h2 = DocumentCache.hash_document(b"hello")
        h3 = DocumentCache.hash_document(b"world")
        assert h1 == h2
        assert h1 != h3

    def test_build_key_deterministic(self):
        k1 = DocumentCache.build_key("hash", ["q1", "q2"], "gpt-4", True)
        k2 = DocumentCache.build_key("hash", ["q2", "q1"], "gpt-4", True)
        assert k1 == k2

    def test_build_key_varies_with_model(self):
        k1 = DocumentCache.build_key("hash", ["q1"], "gpt-4", False)
        k2 = DocumentCache.build_key("hash", ["q1"], "gpt-5", False)
        assert k1 != k2

    def test_overwrite_existing_key(self):
        cache = DocumentCache()
        pr1 = _make_result(answer="first")
        pr2 = _make_result(answer="second")
        cache.put("k", pr1)
        cache.put("k", pr2)
        assert cache.get("k").results[0].answer == "second"
        assert cache.size == 1
