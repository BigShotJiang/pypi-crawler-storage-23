"""Testes para modelos Question, Classification e PageRange."""

import pytest
from pydantic import BaseModel, Field

from deepread.models.question import Question, QuestionConfig, PageRange
from deepread.models.classification import Classification


class TestPageRange:
    def test_start_range(self):
        pr = PageRange(start=1, end=5, from_position="start")
        indices, applied = pr.get_page_indices(20)
        assert indices == [0, 1, 2, 3, 4]
        assert applied is True

    def test_end_range(self):
        pr = PageRange(start=1, end=3, from_position="end")
        indices, applied = pr.get_page_indices(10)
        assert indices == [7, 8, 9]
        assert applied is True

    def test_range_exceeds_document(self):
        pr = PageRange(start=1, end=100, from_position="start")
        indices, applied = pr.get_page_indices(5)
        assert indices == [0, 1, 2, 3, 4]
        assert applied is False

    def test_end_range_exceeds_document(self):
        pr = PageRange(start=1, end=20, from_position="end")
        indices, applied = pr.get_page_indices(5)
        assert indices == [0, 1, 2, 3, 4]
        assert applied is False


class TestQuestion:
    def test_valid_question(self):
        q = Question(
            config=QuestionConfig(id="test", name="Test"),
            user_prompt="Extraia: {texto}",
        )
        assert q.config.id == "test"

    def test_question_missing_placeholder_raises(self):
        with pytest.raises(ValueError, match="placeholder"):
            Question(
                config=QuestionConfig(id="bad", name="Bad"),
                user_prompt="Extraia dados do documento",
            )

    def test_question_with_response_model(self):
        class MyModel(BaseModel):
            value: str = Field(description="valor")

        q = Question(
            config=QuestionConfig(id="struct", name="Structured"),
            user_prompt="Extraia valor de: {texto}",
            response_model=MyModel,
        )
        assert q.response_model is MyModel

    def test_question_from_dict(self):
        data = {
            "config": {"id": "dict_q", "name": "Dict Q"},
            "user_prompt": "Texto: {texto}",
            "keywords": ["teste"],
        }
        q = Question.from_dict(data)
        assert q.config.id == "dict_q"
        assert q.keywords == ["teste"]

    def test_question_to_dict(self):
        q = Question(
            config=QuestionConfig(id="export", name="Export"),
            user_prompt="Dados: {texto}",
            keywords=["abc"],
        )
        d = q.to_dict()
        assert d["config"]["id"] == "export"
        assert d["keywords"] == ["abc"]


class TestClassification:
    def test_valid_classification(self):
        class Resultado(BaseModel):
            classificacao: str

        c = Classification(
            user_prompt="Classifique: {dados}",
            response_model=Resultado,
        )
        assert "{dados}" in c.user_prompt

    def test_classification_missing_placeholder_raises(self):
        class Resultado(BaseModel):
            classificacao: str

        with pytest.raises(ValueError, match="placeholder"):
            Classification(
                user_prompt="Classifique o documento",
                response_model=Resultado,
            )
