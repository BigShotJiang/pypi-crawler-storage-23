"""Testes para o sistema de autenticacao do DeepRead."""

import os
import pytest

from deepread.auth import validate_token
from deepread.auth.token import _generate_token
from deepread.auth.exceptions import InvalidTokenError, ExpiredTokenError


def _make_token(user="test_user", perms=None, days=1):
    perms = perms or ["read", "process", "classify"]
    return _generate_token(user, perms, expires_in_days=days)


class TestTokenValidation:
    def test_valid_token_is_accepted(self):
        auth = _make_token()
        result = validate_token(auth.token)
        assert result.user_id == "test_user"
        assert result.is_valid

    def test_valid_token_has_correct_permissions(self):
        auth = _make_token(perms=["read", "process"])
        result = validate_token(auth.token)
        assert result.has_permission("read")
        assert result.has_permission("process")
        assert not result.has_permission("classify")

    def test_empty_token_raises(self):
        with pytest.raises(InvalidTokenError):
            validate_token("")

    def test_token_without_prefix_raises(self):
        with pytest.raises(InvalidTokenError):
            validate_token("invalid_token_no_prefix")

    def test_token_with_wrong_prefix_raises(self):
        with pytest.raises(InvalidTokenError):
            validate_token("xx_some_payload.some_signature")

    def test_token_with_invalid_signature_raises(self):
        with pytest.raises(InvalidTokenError):
            validate_token("dr_eyJpbnZhbGlkIjogdHJ1ZX0=.fake_signature")

    def test_token_with_no_dot_raises(self):
        with pytest.raises(InvalidTokenError):
            validate_token("dr_nodotinpayload")

    def test_expired_token_raises(self):
        auth = _make_token(days=-1)
        with pytest.raises(ExpiredTokenError):
            validate_token(auth.token)

    def test_wildcard_permission(self):
        auth = _make_token(perms=["*"])
        result = validate_token(auth.token)
        assert result.has_permission("read")
        assert result.has_permission("anything")

    def test_token_metadata(self):
        auth = _generate_token("meta_user", metadata={"plan": "pro"})
        result = validate_token(auth.token)
        assert result.metadata == {"plan": "pro"}


class TestDeepReadInitAuth:
    def test_deepread_rejects_empty_token(self):
        from deepread import DeepRead

        with pytest.raises(InvalidTokenError):
            DeepRead(api_token="", validate_token_on_init=True)

    def test_deepread_rejects_fake_token(self):
        from deepread import DeepRead

        with pytest.raises(InvalidTokenError):
            DeepRead(api_token="dr_fake.bad_sig", validate_token_on_init=True)

    def test_deepread_accepts_valid_token_but_needs_openai_key(self):
        from deepread import DeepRead
        from deepread.exceptions import DeepReadError

        auth = _make_token()
        old_key = os.environ.pop("OPENAI_API_KEY", None)
        try:
            with pytest.raises(DeepReadError, match="OpenAI API key"):
                DeepRead(api_token=auth.token, validate_token_on_init=True)
        finally:
            if old_key:
                os.environ["OPENAI_API_KEY"] = old_key
