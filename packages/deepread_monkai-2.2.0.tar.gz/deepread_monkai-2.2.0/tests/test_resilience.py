"""Testes para retry e circuit breaker."""

import time

import pytest

from deepread.resilience import (
    CircuitBreaker,
    CircuitState,
    create_retry_decorator,
)


class TestCircuitBreaker:
    def test_initial_state_is_closed(self):
        cb = CircuitBreaker()
        assert cb.state == CircuitState.CLOSED
        assert cb.can_execute()

    def test_opens_after_threshold(self):
        cb = CircuitBreaker(failure_threshold=3, recovery_timeout=60)
        for _ in range(3):
            cb.record_failure()
        assert cb.state == CircuitState.OPEN
        assert not cb.can_execute()

    def test_stays_closed_below_threshold(self):
        cb = CircuitBreaker(failure_threshold=3)
        cb.record_failure()
        cb.record_failure()
        assert cb.state == CircuitState.CLOSED
        assert cb.can_execute()

    def test_success_resets_count(self):
        cb = CircuitBreaker(failure_threshold=3)
        cb.record_failure()
        cb.record_failure()
        cb.record_success()
        cb.record_failure()
        cb.record_failure()
        assert cb.state == CircuitState.CLOSED

    def test_half_open_after_timeout(self):
        cb = CircuitBreaker(failure_threshold=1, recovery_timeout=1)
        cb.record_failure()
        assert cb.state == CircuitState.OPEN
        time.sleep(1.1)
        assert cb.state == CircuitState.HALF_OPEN
        assert cb.can_execute()

    def test_half_open_success_closes(self):
        cb = CircuitBreaker(failure_threshold=1, recovery_timeout=1)
        cb.record_failure()
        time.sleep(1.1)
        assert cb.state == CircuitState.HALF_OPEN
        cb.record_success()
        assert cb.state == CircuitState.CLOSED

    def test_half_open_failure_reopens(self):
        cb = CircuitBreaker(failure_threshold=1, recovery_timeout=1)
        cb.record_failure()
        time.sleep(1.1)
        assert cb.state == CircuitState.HALF_OPEN
        cb.record_failure()
        assert cb.state == CircuitState.OPEN

    def test_reset(self):
        cb = CircuitBreaker(failure_threshold=1)
        cb.record_failure()
        assert cb.state == CircuitState.OPEN
        cb.reset()
        assert cb.state == CircuitState.CLOSED
        assert cb.can_execute()


class TestRetryDecorator:
    def test_noop_when_zero_retries(self):
        decorator = create_retry_decorator(max_retries=0)
        call_count = 0

        @decorator
        def fn():
            nonlocal call_count
            call_count += 1
            raise ValueError("always fails")

        with pytest.raises(ValueError):
            fn()
        assert call_count == 1

    def test_decorator_returns_callable(self):
        decorator = create_retry_decorator(max_retries=2)

        @decorator
        def fn():
            return 42

        assert fn() == 42

    def test_retries_on_retryable_exception(self):
        try:
            from openai import RateLimitError
            import httpx
        except ImportError:
            pytest.skip("openai or httpx not installed")

        call_count = 0
        decorator = create_retry_decorator(max_retries=2, min_wait=0.1, max_wait=0.2)

        @decorator
        def fn():
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                mock_response = httpx.Response(
                    status_code=429,
                    request=httpx.Request("POST", "https://api.openai.com/v1/chat/completions"),
                )
                raise RateLimitError(
                    message="rate limited",
                    response=mock_response,
                    body=None,
                )
            return "ok"

        assert fn() == "ok"
        assert call_count == 3
