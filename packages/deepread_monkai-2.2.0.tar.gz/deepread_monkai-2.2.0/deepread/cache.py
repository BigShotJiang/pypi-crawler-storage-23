# ============================================================================
# DEEPREAD CACHE - CACHING DE DOCUMENTOS
# ============================================================================
"""
Cache em memória para evitar reprocessamento de documentos idênticos.
"""

import hashlib
import logging
import threading
import time
from collections import OrderedDict
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Dict, List, Optional

if TYPE_CHECKING:
    from .models.result import ProcessingResult

logger = logging.getLogger(__name__)


@dataclass
class CacheEntry:
    result: "ProcessingResult"
    created_at: float = field(default_factory=time.time)


class DocumentCache:
    """
    Cache in-memory com TTL e evição LRU para resultados de processamento.

    Args:
        ttl_seconds: Tempo de vida de cada entrada em segundos (0 = sem expiração)
        max_size: Número máximo de entradas armazenadas
    """

    def __init__(self, ttl_seconds: int = 3600, max_size: int = 100):
        self._store: OrderedDict[str, CacheEntry] = OrderedDict()
        self._ttl = ttl_seconds
        self._max_size = max_size
        self._lock = threading.Lock()
        self._hits = 0
        self._misses = 0

    @staticmethod
    def hash_document(content: bytes) -> str:
        """Gera SHA-256 do conteúdo do documento."""
        return hashlib.sha256(content).hexdigest()

    @staticmethod
    def build_key(doc_hash: str, question_ids: List[str], model: str, classify: bool) -> str:
        """Constrói chave composta para o cache."""
        q_key = "|".join(sorted(question_ids))
        raw = f"{doc_hash}:{q_key}:{model}:{classify}"
        return hashlib.sha256(raw.encode()).hexdigest()

    def get(self, key: str) -> Optional["ProcessingResult"]:
        """Retorna resultado cacheado ou None se ausente/expirado."""
        with self._lock:
            entry = self._store.get(key)
            if entry is None:
                self._misses += 1
                return None

            if self._ttl > 0 and (time.time() - entry.created_at) > self._ttl:
                del self._store[key]
                self._misses += 1
                logger.debug("Cache entry expired: %s", key[:12])
                return None

            self._store.move_to_end(key)
            self._hits += 1
            logger.debug("Cache hit: %s", key[:12])
            return entry.result

    def put(self, key: str, result: "ProcessingResult") -> None:
        """Armazena resultado no cache com evição LRU se necessário."""
        with self._lock:
            if key in self._store:
                self._store.move_to_end(key)
                self._store[key] = CacheEntry(result=result)
                return

            if len(self._store) >= self._max_size:
                evicted_key, _ = self._store.popitem(last=False)
                logger.debug("Cache evicted (LRU): %s", evicted_key[:12])

            self._store[key] = CacheEntry(result=result)

    def clear(self) -> None:
        """Remove todas as entradas do cache."""
        with self._lock:
            self._store.clear()
            self._hits = 0
            self._misses = 0

    @property
    def size(self) -> int:
        return len(self._store)

    @property
    def stats(self) -> Dict[str, int]:
        return {"hits": self._hits, "misses": self._misses, "size": self.size}
