# ============================================================================
# DEEPREAD OCR - EXTRAÇÃO DE TEXTO COM OCR
# ============================================================================
"""
Módulo OCR usando Azure AI Vision.
"""

import io
import logging
from pathlib import Path
from typing import List, Optional, Union

import fitz

from .config import get_azure_config
from .utils import _ensure_bytes

logger = logging.getLogger(__name__)
logging.getLogger("azure.core.pipeline.policies.http_logging_policy").setLevel(logging.WARNING)


def render_page_as_image(doc: fitz.Document, page_num: int, dpi: int = 150) -> bytes:
    """Renderiza uma página como imagem PNG."""
    page = doc.load_page(page_num)
    zoom = dpi / 72
    mat = fitz.Matrix(zoom, zoom)
    pix = page.get_pixmap(matrix=mat)
    return pix.tobytes("png")


def perform_azure_ocr(image_bytes: bytes, image_format: str = "png") -> Optional[str]:
    """
    Realiza OCR usando Azure AI Vision com retry e backoff exponencial.

    Args:
        image_bytes: Bytes da imagem
        image_format: Formato da imagem

    Returns:
        Texto extraído ou None
    """
    endpoint, key = get_azure_config()

    if not key:
        logger.warning("AZURE_AI_VISION_KEY não configurada!")
        return None

    from tenacity import retry, stop_after_attempt, wait_exponential, RetryCallState

    def _log_ocr_retry(retry_state: RetryCallState) -> None:
        exc = retry_state.outcome.exception() if retry_state.outcome else None
        logger.warning(
            "OCR retry %d/3: %s",
            retry_state.attempt_number,
            type(exc).__name__ if exc else "unknown",
        )

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, max=16),
        before_sleep=_log_ocr_retry,
        reraise=True,
    )
    def _call_ocr(img_data: bytes) -> Optional[str]:
        from azure.ai.vision.imageanalysis import ImageAnalysisClient
        from azure.ai.vision.imageanalysis.models import VisualFeatures
        from azure.core.credentials import AzureKeyCredential

        client = ImageAnalysisClient(endpoint=endpoint, credential=AzureKeyCredential(key))
        result = client.analyze(
            image_data=img_data, visual_features=[VisualFeatures.READ], language="pt"
        )
        text = ""
        if result.read:
            for block in result.read.blocks:
                for line in block.lines:
                    text += line.text + "\n"
        return text.strip() if text.strip() else None

    MIN_DIM, MAX_DIM = 200, 16000

    try:
        from PIL import Image

        img = Image.open(io.BytesIO(image_bytes)).convert("RGB")
        w, h = img.size

        if min(w, h) < MIN_DIM:
            return None

        if max(w, h) > MAX_DIM:
            scale = MAX_DIM / max(w, h)
            img = img.resize((int(w * scale), int(h * scale)), Image.LANCZOS)

        fmt_map = {"jpg": "JPEG", "jpeg": "JPEG", "png": "PNG", "bmp": "BMP"}
        out_buf = io.BytesIO()
        img.save(out_buf, format=fmt_map.get(image_format.lower(), "PNG"))

        return _call_ocr(out_buf.getvalue())

    except Exception as e:
        logger.error(f"Azure OCR falhou após retries: {e}")
        return None


def load_pdf_with_ocr(
    source: Union[Path, bytes],
    use_azure: bool = True,
    filename: Optional[str] = None,
) -> List:
    """
    Carrega PDF aplicando OCR nas páginas com imagem.

    Args:
        source: Caminho do arquivo ou bytes do PDF
        use_azure: Se True, usa Azure OCR
        filename: Nome para log quando source é bytes (ignorado se source é Path)

    Returns:
        Lista de Document objects
    """
    from llama_index.core.schema import Document

    if isinstance(source, (Path, str)):
        doc = fitz.open(Path(source))
        display_name = Path(source).name
    else:
        content = _ensure_bytes(source)
        doc = fitz.open(stream=content, filetype="pdf")
        display_name = filename or "document.pdf"
    documents = []

    logger.info(f"Processando PDF com OCR: {display_name} ({doc.page_count} páginas)")

    for page_num in range(doc.page_count):
        page = doc.load_page(page_num)
        text = page.get_text().strip()

        if len(text) > 100:
            documents.append(Document(text=text, metadata={"page": page_num + 1, "source": "text"}))
            continue

        logger.info(f"Renderizando página {page_num + 1} para OCR...")
        img_bytes = render_page_as_image(doc, page_num)

        ocr_text = perform_azure_ocr(img_bytes, "png") if use_azure else ""

        final_text = f"{text}\n\n{ocr_text}".strip()

        if final_text:
            documents.append(
                Document(
                    text=final_text,
                    metadata={"page": page_num + 1, "source": "ocr" if ocr_text else "text"},
                )
            )
            logger.info(f"Página {page_num + 1}: {len(final_text)} caracteres extraídos via OCR")

    doc.close()
    return documents


def process_pdf_smart(
    source: Union[Path, bytes],
    min_chars: int = 100,
    filename: Optional[str] = None,
) -> List:
    """
    Processa PDF de forma inteligente, aplicando OCR quando necessário.

    Args:
        source: Caminho do arquivo ou bytes do PDF
        min_chars: Mínimo de caracteres para considerar página com texto
        filename: Nome para log quando source é bytes (ignorado se source é Path)

    Returns:
        Lista de Document objects
    """
    from .utils import needs_ocr, load_pdf

    if isinstance(source, (Path, str)):
        display_name = Path(source).name
    else:
        display_name = filename or "document.pdf"
    if needs_ocr(source, min_chars):
        logger.info(f"PDF {display_name} precisa de OCR")
        return load_pdf_with_ocr(source, filename=filename)
    return load_pdf(source, filename=filename or "document.pdf")
