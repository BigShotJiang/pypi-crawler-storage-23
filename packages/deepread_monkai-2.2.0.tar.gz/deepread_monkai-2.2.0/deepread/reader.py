# ============================================================================
# DEEPREAD - CLASSE PRINCIPAL
# ============================================================================
"""
Classe principal do DeepRead para extração inteligente de documentos.
"""

import asyncio
import io
import os
import socket
import logging
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from ipaddress import ip_address
from pathlib import Path
from typing import List, Optional, Dict, Any, Type, Union
from urllib.parse import urlparse

from pydantic import BaseModel
from openai import OpenAI as OpenAIClient
from openai import AzureOpenAI as AzureOpenAIClient
from openai import AsyncOpenAI as AsyncOpenAIClient
from openai import AsyncAzureOpenAI as AsyncAzureOpenAIClient

from .auth import validate_token, AuthToken
from .auth.exceptions import AuthenticationError, InvalidTokenError
from .cache import DocumentCache
from .config import DEFAULT_MODEL, MODELS, calculate_cost
from .models import (
    Question,
    QuestionConfig,
    PageRange,
    Result,
    ProcessingResult,
    DocumentMetadata,
    Classification,
)
from .models.result import ProcessingMetrics
from .resilience import CircuitBreaker, create_retry_decorator
from .utils import (
    load_pdf,
    load_pdf_lazy,
    filter_relevant_pages,
    get_document_metadata,
    extract_main_response,
)
from .ocr import process_pdf_smart
from .exceptions import DeepReadError, DocumentError, ProcessingError

logger = logging.getLogger(__name__)


def _is_safe_url(url: str) -> bool:
    """Valida se a URL nao aponta para enderecos internos (protecao SSRF)."""
    parsed = urlparse(url)
    hostname = parsed.hostname
    if not hostname:
        return False
    try:
        resolved = ip_address(socket.gethostbyname(hostname))
        return not (resolved.is_private or resolved.is_loopback or resolved.is_reserved)
    except (socket.gaierror, ValueError):
        return False


class DeepRead:
    """
    DeepRead - Biblioteca para extração inteligente de documentos PDF.

    Attributes:
        api_token: Token de autenticação do DeepRead
        openai_api_key: Chave da API OpenAI
        model: Modelo a ser utilizado

    Example:
        ```python
        from deepread import DeepRead, Question, QuestionConfig
        from pydantic import BaseModel, Field

        # Definir modelo de resposta
        class ExtractionResponse(BaseModel):
            value: str = Field(description="Valor extraído")
            confidence: float = Field(default=1.0)

        # Criar pergunta
        question = Question(
            config=QuestionConfig(id="extraction", name="Extração"),
            system_prompt="Você é um especialista em extração.",
            user_prompt="Extraia informações de: {texto}",
            keywords=["valor", "total"],
            response_model=ExtractionResponse
        )

        # Inicializar DeepRead
        dr = DeepRead(
            api_token="dr_xxx...",
            openai_api_key="sk-..."
        )

        # Adicionar pergunta
        dr.add_question(question)

        # Processar documento
        result = dr.process("documento.pdf")
        print(result.get_answer("extraction"))
        ```
    """

    MAX_FILE_SIZE_MB = 50
    MAX_PAGES = 500

    def __init__(
        self,
        api_token: str,
        openai_api_key: Optional[str] = None,
        model: str = DEFAULT_MODEL,
        validate_token_on_init: bool = True,
        auth_api_url: Optional[str] = None,
        verbose: bool = False,
        max_file_size_mb: Optional[float] = None,
        max_pages: Optional[int] = None,
        # Azure OpenAI
        provider: Optional[str] = None,
        azure_api_key: Optional[str] = None,
        azure_endpoint: Optional[str] = None,
        azure_api_version: Optional[str] = None,
        azure_deployment: Optional[str] = None,
        # Resilience
        max_retries: int = 3,
        enable_cache: bool = False,
        cache_ttl: int = 3600,
        streaming: bool = False,
        circuit_breaker: bool = False,
        circuit_breaker_threshold: int = 5,
        circuit_breaker_timeout: int = 60,
    ):
        """
        Inicializa o DeepRead.

        Args:
            api_token: Token de autenticação do DeepRead
            openai_api_key: Chave da API OpenAI (ou usa OPENAI_API_KEY env)
            model: Modelo a ser utilizado
            validate_token_on_init: Se True, valida token na inicialização
            auth_api_url: URL da API de autenticação (opcional)
            verbose: Se True, imprime logs detalhados
            max_file_size_mb: Limite de tamanho do arquivo em MB (default: 50)
            max_pages: Limite de páginas do documento (default: 500)

            # Azure OpenAI
            provider: "openai" ou "azure" (ou usa OPENAI_PROVIDER env)
            azure_api_key: Chave da API Azure (ou usa AZURE_API_KEY env)
            azure_endpoint: Endpoint Azure (ou usa AZURE_API_ENDPOINT env)
            azure_api_version: Versão da API Azure (ou usa AZURE_API_VERSION env)
            azure_deployment: Nome do deployment (ou usa AZURE_DEPLOYMENT_NAME env)

            # Resilience
            max_retries: Tentativas extras para chamadas LLM (0 = sem retry)
            enable_cache: Habilita cache de resultados por hash de documento
            cache_ttl: TTL do cache em segundos (default: 3600)
            streaming: Processa PDFs em modo lazy (uma página por vez)
            circuit_breaker: Habilita circuit breaker no batch processing
            circuit_breaker_threshold: Falhas consecutivas para abrir o circuito
            circuit_breaker_timeout: Segundos para tentar recuperação

        Raises:
            InvalidTokenError: Se o token for inválido
            AuthenticationError: Se houver erro de autenticação

        Example (OpenAI):
            ```python
            dr = DeepRead(
                api_token="dr_xxx",
                openai_api_key="sk-xxx",
                model="gpt-5.1"
            )
            ```

        Example (Azure OpenAI):
            ```python
            dr = DeepRead(
                api_token="dr_xxx",
                provider="azure",
                azure_api_key="xxx",
                azure_endpoint="https://xxx.openai.azure.com",
                azure_deployment="gpt-4o"
            )
            ```
        """
        self._api_token = api_token
        self._auth_token: Optional[AuthToken] = None
        self._auth_api_url = auth_api_url
        self._verbose = verbose
        self._max_file_size_mb = max_file_size_mb or self.MAX_FILE_SIZE_MB
        self._max_pages = max_pages or self.MAX_PAGES
        self._streaming = streaming

        # Validar token
        if validate_token_on_init:
            self._auth_token = self._validate_token()

        # Detectar provider
        self._provider = (provider or os.getenv("OPENAI_PROVIDER", "openai")).lower()

        if self._provider == "azure":
            # Azure OpenAI
            self._azure_api_key = azure_api_key or os.getenv("AZURE_API_KEY")
            self._azure_endpoint = azure_endpoint or os.getenv("AZURE_API_ENDPOINT")
            self._azure_api_version = azure_api_version or os.getenv(
                "AZURE_API_VERSION", "2024-02-15-preview"
            )
            self._azure_deployment = azure_deployment or os.getenv("AZURE_DEPLOYMENT_NAME")

            if not self._azure_api_key:
                raise DeepReadError("Azure API key não configurada. Defina AZURE_API_KEY.")
            if not self._azure_endpoint:
                raise DeepReadError("Azure endpoint não configurado. Defina AZURE_API_ENDPOINT.")
            if not self._azure_deployment:
                raise DeepReadError(
                    "Azure deployment não configurado. Defina AZURE_DEPLOYMENT_NAME."
                )

            self._openai_client = AzureOpenAIClient(
                api_key=self._azure_api_key,
                api_version=self._azure_api_version,
                azure_endpoint=self._azure_endpoint,
            )
            self._async_openai_client: Optional[
                Union[AsyncOpenAIClient, AsyncAzureOpenAIClient]
            ] = None
            self._model = self._azure_deployment

            if self._verbose:
                logger.info(f"DeepRead inicializado (Azure). Deployment: {self._azure_deployment}")
        else:
            # OpenAI padrão
            self._openai_api_key = openai_api_key or os.getenv("OPENAI_API_KEY")
            if not self._openai_api_key:
                raise DeepReadError(
                    "OpenAI API key não configurada. Defina OPENAI_API_KEY "
                    "ou passe openai_api_key."
                )

            self._openai_client = OpenAIClient(api_key=self._openai_api_key)
            self._async_openai_client = None
            self._model = model

            if self._verbose:
                logger.info(f"DeepRead inicializado (OpenAI). Modelo: {model}")

        # Resilience
        self._max_retries = max_retries
        self._retry = create_retry_decorator(max_retries=max_retries)

        # Cache
        self._cache: Optional[DocumentCache] = None
        if enable_cache:
            self._cache = DocumentCache(ttl_seconds=cache_ttl)

        # Circuit breaker
        self._circuit_breaker: Optional[CircuitBreaker] = None
        if circuit_breaker:
            self._circuit_breaker = CircuitBreaker(
                failure_threshold=circuit_breaker_threshold,
                recovery_timeout=circuit_breaker_timeout,
            )

        # Perguntas e classificação
        self._questions: Dict[str, Question] = {}
        self._classification: Optional[Classification] = None

    def _validate_token(self) -> AuthToken:
        """Valida o token de autenticação."""
        try:
            return validate_token(self._api_token)
        except (InvalidTokenError, AuthenticationError) as e:
            logger.error(f"Falha na autenticação: {e}")
            raise

    @property
    def user_id(self) -> Optional[str]:
        """Retorna o ID do usuário autenticado."""
        return self._auth_token.user_id if self._auth_token else None

    @property
    def model(self) -> str:
        """Retorna o modelo atual."""
        return self._model

    @model.setter
    def model(self, value: str):
        """Define o modelo a ser utilizado."""
        self._model = value

    @property
    def questions(self) -> List[Question]:
        """Retorna lista de perguntas configuradas."""
        return list(self._questions.values())

    # ========================================================================
    # CONFIGURAÇÃO DE PERGUNTAS
    # ========================================================================

    def add_question(self, question: Question) -> "DeepRead":
        """
        Adiciona uma pergunta para extração.

        Args:
            question: Question configurada

        Returns:
            self (para encadeamento)
        """
        self._questions[question.config.id] = question
        if self._verbose:
            logger.info(f"Pergunta adicionada: {question.config.id}")
        return self

    def add_questions(self, questions: List[Question]) -> "DeepRead":
        """
        Adiciona múltiplas perguntas.

        Args:
            questions: Lista de Questions

        Returns:
            self (para encadeamento)
        """
        for q in questions:
            self.add_question(q)
        return self

    def remove_question(self, question_id: str) -> "DeepRead":
        """Remove uma pergunta."""
        if question_id in self._questions:
            del self._questions[question_id]
        return self

    def clear_questions(self) -> "DeepRead":
        """Remove todas as perguntas."""
        self._questions.clear()
        return self

    def set_classification(self, classification: Classification) -> "DeepRead":
        """
        Configura classificação de documentos.

        Args:
            classification: Configuração de classificação

        Returns:
            self (para encadeamento)
        """
        self._classification = classification
        return self

    def clear_cache(self) -> "DeepRead":
        """Limpa o cache de documentos."""
        if self._cache:
            self._cache.clear()
        return self

    @property
    def cache_stats(self) -> Dict[str, int]:
        """Retorna estatísticas do cache."""
        if self._cache:
            return self._cache.stats
        return {"hits": 0, "misses": 0, "size": 0}

    def _get_async_client(self) -> Union[AsyncOpenAIClient, AsyncAzureOpenAIClient]:
        """Retorna o client async, criando-o lazily na primeira chamada."""
        if self._async_openai_client is None:
            if self._provider == "azure":
                self._async_openai_client = AsyncAzureOpenAIClient(
                    api_key=self._azure_api_key,
                    api_version=self._azure_api_version,
                    azure_endpoint=self._azure_endpoint,
                )
            else:
                self._async_openai_client = AsyncOpenAIClient(api_key=self._openai_api_key)
        return self._async_openai_client

    # ========================================================================
    # PROCESSAMENTO
    # ========================================================================

    def _call_llm(self, messages: list, response_model=None):
        """Chamada ao LLM com retry automático para erros transientes."""

        @self._retry
        def _inner():
            if response_model:
                return self._openai_client.beta.chat.completions.parse(
                    model=self._model,
                    messages=messages,
                    response_format=response_model,
                )
            return self._openai_client.chat.completions.create(
                model=self._model,
                messages=messages,
            )

        return _inner()

    def _execute_question(
        self,
        text: str,
        question: Question,
    ) -> Result:
        """Executa uma pergunta usando OpenAI."""
        start = time.time()

        try:
            user_prompt = question.user_prompt.format(texto=text)
            messages = [
                {"role": "system", "content": question.system_prompt},
                {"role": "user", "content": user_prompt},
            ]

            response = self._call_llm(messages, question.response_model)

            if question.response_model:
                result = response.choices[0].message.parsed
                answer = extract_main_response(result)
                raw_result = result.model_dump() if hasattr(result, "model_dump") else dict(result)
            else:
                answer = response.choices[0].message.content
                raw_result = {"response": answer}

            elapsed = time.time() - start
            prompt_tokens = response.usage.prompt_tokens
            completion_tokens = response.usage.completion_tokens
            total_tokens = response.usage.total_tokens
            cost = calculate_cost(self._model, prompt_tokens, completion_tokens)

            return Result(
                question_id=question.config.id,
                question_name=question.config.name,
                answer=answer,
                raw_result=raw_result,
                metrics=ProcessingMetrics(
                    time_seconds=round(elapsed, 2),
                    tokens=total_tokens,
                    prompt_tokens=prompt_tokens,
                    completion_tokens=completion_tokens,
                    cost_usd=round(cost, 6),
                    model=self._model,
                ),
                status="OK",
            )

        except Exception as e:
            logger.error(f"Erro ao executar pergunta {question.config.id}: {e}")
            return Result(
                question_id=question.config.id,
                question_name=question.config.name,
                answer="Erro ao processar pergunta",
                status="ERROR",
                metrics=ProcessingMetrics(time_seconds=time.time() - start),
            )

    def _classify_results(self, results: List[Result], doc_info: dict) -> Optional[Dict[str, Any]]:
        """Classifica os resultados extraídos."""
        if not self._classification:
            return None

        try:
            data = {}
            for r in results:
                data[r.question_id] = r.answer
            data["_documento"] = doc_info.get("filename", "")
            data["_tipo"] = doc_info.get("doc_type", "")

            data_formatted = "\n".join([f"- {k}: {v}" for k, v in data.items()])
            prompt_final = self._classification.user_prompt.format(dados=data_formatted)

            messages = [
                {"role": "system", "content": self._classification.system_prompt},
                {"role": "user", "content": prompt_final},
            ]

            response = self._call_llm(messages, self._classification.response_model)

            result = response.choices[0].message.parsed
            return result.model_dump() if hasattr(result, "model_dump") else dict(result)

        except Exception as e:
            logger.error(f"Erro na classificação: {e}")
            return {"error": "Erro na classificacao", "error_type": type(e).__name__}

    def _resolve_document(
        self,
        document: Union[str, Path, bytes, io.BytesIO],
        filename: Optional[str] = None,
    ) -> tuple:
        """
        Resolve o documento para bytes e metadata.
        Retorna (content_bytes, metadata, doc_metadata, display_name).
        """
        content_bytes: Optional[bytes] = None
        display_name: Optional[str] = None

        if isinstance(document, bytes):
            content_bytes = document
            display_name = filename or "document.pdf"
        elif hasattr(document, "read"):
            try:
                content_bytes = bytes(document.read())
            except Exception as e:
                raise DocumentError(f"Erro ao ler documento: {e}") from e
            display_name = filename or "document.pdf"

        if content_bytes is None and isinstance(document, str):
            s = document.strip()
            if s.lower().startswith(("http://", "https://")):
                if not _is_safe_url(s):
                    raise DocumentError("URL aponta para endereco interno ou reservado.")
                try:
                    import requests

                    resp = requests.get(s, timeout=60)
                    resp.raise_for_status()
                    content_bytes = resp.content
                except Exception as e:
                    raise DocumentError(f"Falha ao obter documento da URL: {e}") from e
                path_seg = urlparse(s).path.rstrip("/").split("/")[-1] or None
                display_name = filename or path_seg or "document.pdf"

        if content_bytes is not None:
            if not content_bytes:
                raise DocumentError("Conteúdo do documento vazio ou inválido.")
            size_mb = len(content_bytes) / (1024 * 1024)
            if size_mb > self._max_file_size_mb:
                raise DocumentError(
                    f"Documento excede o limite de {self._max_file_size_mb}MB "
                    f"({size_mb:.1f}MB)."
                )
            try:
                metadata = get_document_metadata(
                    content_bytes, filename=display_name or "document.pdf"
                )
            except Exception as e:
                raise DocumentError(f"PDF inválido ou corrompido: {e}") from e
            if metadata["num_pages"] > self._max_pages:
                raise DocumentError(
                    f"Documento excede o limite de {self._max_pages} paginas "
                    f"({metadata['num_pages']} paginas)."
                )
            doc_metadata = DocumentMetadata(
                filename=display_name or "document.pdf",
                doc_type=metadata["doc_type"],
                num_pages=metadata["num_pages"],
                size_kb=metadata["size_kb"],
            )
            return content_bytes, metadata, doc_metadata, display_name or "document.pdf"

        pdf_path = Path(document)
        if not pdf_path.exists():
            raise DocumentError(f"Documento não encontrado: {document}")
        size_mb = pdf_path.stat().st_size / (1024 * 1024)
        if size_mb > self._max_file_size_mb:
            raise DocumentError(
                f"Documento excede o limite de {self._max_file_size_mb}MB " f"({size_mb:.1f}MB)."
            )
        try:
            metadata = get_document_metadata(pdf_path)
        except Exception as e:
            raise DocumentError(f"PDF inválido ou corrompido: {e}") from e
        if metadata["num_pages"] > self._max_pages:
            raise DocumentError(
                f"Documento excede o limite de {self._max_pages} paginas "
                f"({metadata['num_pages']} paginas)."
            )
        doc_metadata = DocumentMetadata(
            filename=pdf_path.name,
            doc_type=metadata["doc_type"],
            num_pages=metadata["num_pages"],
            size_kb=metadata["size_kb"],
        )
        content_bytes = pdf_path.read_bytes()
        return content_bytes, metadata, doc_metadata, pdf_path.name

    def _load_documents(self, source: Union[bytes, Path], metadata: dict, display_name: str):
        """Carrega páginas do PDF, usando streaming ou carga completa."""
        if self._verbose:
            logger.info(f"Processando: {display_name}")

        if metadata["doc_type"] == "image":
            if self._verbose:
                logger.info("Aplicando OCR...")
            return list(process_pdf_smart(source, filename=display_name))

        if self._streaming:
            return list(load_pdf_lazy(source, filename=display_name))

        return load_pdf(source, filename=display_name)

    def process(
        self,
        document: Union[str, Path, bytes, io.BytesIO],
        questions: Optional[List[str]] = None,
        classify: bool = False,
        filename: Optional[str] = None,
    ) -> ProcessingResult:
        """
        Processa um documento PDF.

        Args:
            document: Caminho do documento PDF, URL (http/https), bytes ou BytesIO do PDF
            questions: Lista de IDs de perguntas específicas (None = todas)
            classify: Se True, classifica o documento após extração
            filename: Nome para metadata/log quando document é bytes, BytesIO ou URL (opcional)

        Returns:
            ProcessingResult com todos os resultados

        Raises:
            DocumentError: Se o documento não existir, for inválido ou URL inacessível
        """
        content_bytes, metadata, doc_metadata, display_name = self._resolve_document(
            document, filename
        )

        # Selecionar perguntas
        questions_to_run = self._select_questions(questions)

        # Cache lookup
        cache_key = None
        if self._cache:
            doc_hash = DocumentCache.hash_document(content_bytes)
            q_ids = [q.config.id for q in questions_to_run]
            cache_key = DocumentCache.build_key(doc_hash, q_ids, self._model, classify)
            cached = self._cache.get(cache_key)
            if cached is not None:
                if self._verbose:
                    logger.info(f"Cache hit para {display_name}")
                return cached

        # Carregar páginas
        documents = self._load_documents(content_bytes, metadata, display_name)

        # Processar perguntas
        results, total_time, total_tokens, total_cost = self._run_questions(
            questions_to_run, documents
        )

        # Classificação
        classification = None
        if classify and self._classification:
            classification = self._classify_results(
                results, {"filename": display_name, "doc_type": metadata["doc_type"]}
            )

        processing_result = ProcessingResult(
            document=doc_metadata,
            results=results,
            classification=classification,
            total_metrics=ProcessingMetrics(
                time_seconds=round(total_time, 2),
                tokens=total_tokens,
                cost_usd=round(total_cost, 6),
                model=self._model,
            ),
        )

        # Cache store
        if self._cache and cache_key:
            self._cache.put(cache_key, processing_result)

        return processing_result

    def _select_questions(self, question_ids: Optional[List[str]] = None) -> List[Question]:
        """Seleciona e valida as perguntas a executar."""
        if question_ids:
            questions_to_run = [
                self._questions[qid] for qid in question_ids if qid in self._questions
            ]
        else:
            questions_to_run = list(self._questions.values())

        if not questions_to_run:
            raise ProcessingError("Nenhuma pergunta configurada. Use add_question() primeiro.")
        return questions_to_run

    def _run_questions(self, questions_to_run: List[Question], documents: list) -> tuple:
        """Executa todas as perguntas sobre os documentos carregados."""
        results: List[Result] = []
        total_time = 0.0
        total_tokens = 0
        total_cost = 0.0

        for question in questions_to_run:
            docs_to_process = documents
            page_range_applied = False
            page_range_ignored = False

            if question.page_range:
                total_pages = len(documents)
                page_indices, applied = question.page_range.get_page_indices(total_pages)

                if applied:
                    docs_to_process = [documents[i] for i in page_indices if i < len(documents)]
                    page_range_applied = True
                    if self._verbose:
                        logger.info(
                            f"  {question.config.id}: Page range aplicado - "
                            f"páginas {page_indices[0]+1} a {page_indices[-1]+1}"
                        )
                else:
                    page_range_ignored = True
                    if self._verbose:
                        logger.info(
                            f"  {question.config.id}: Page range ignorado - "
                            f"documento tem apenas {total_pages} páginas"
                        )

            docs_filtered, info = filter_relevant_pages(docs_to_process, question.keywords)
            info["page_range_applied"] = page_range_applied
            info["page_range_ignored"] = page_range_ignored
            info["total"] = len(documents)

            if not docs_filtered:
                results.append(
                    Result(
                        question_id=question.config.id,
                        question_name=question.config.name,
                        answer="Sem páginas relevantes",
                        status="NO_DATA",
                        pages_used=0,
                        pages_total=info["total"],
                    )
                )
                continue

            text = "\n\n---\n\n".join([doc.text for doc in docs_filtered])
            result = self._execute_question(text, question)
            result.pages_used = len(docs_filtered)
            result.pages_total = info["total"]
            results.append(result)

            total_time += result.metrics.time_seconds
            total_tokens += result.metrics.tokens
            total_cost += result.metrics.cost_usd

            if self._verbose:
                logger.info(f"  {question.config.id}: {result.answer[:50]}...")

        return results, total_time, total_tokens, total_cost

    # ========================================================================
    # BATCH PROCESSING (com circuit breaker)
    # ========================================================================

    def process_batch(
        self,
        documents: List[Union[str, Path, bytes, io.BytesIO]],
        questions: Optional[List[str]] = None,
        classify: bool = False,
        max_workers: Optional[int] = None,
    ) -> List[ProcessingResult]:
        """
        Processa múltiplos documentos com suporte a concorrência e circuit breaker.

        Args:
            documents: Lista de caminhos, URLs, bytes ou BytesIO dos documentos
            questions: Lista de IDs de perguntas específicas
            classify: Se True, classifica os documentos
            max_workers: Número de workers paralelos (None = sequencial, 1+ = concorrente)

        Returns:
            Lista de ProcessingResult na mesma ordem dos documentos
        """
        if self._circuit_breaker:
            self._circuit_breaker.reset()

        if not max_workers or max_workers < 2:
            return self._process_batch_sequential(documents, questions, classify)

        return self._process_batch_parallel(documents, questions, classify, max_workers)

    def _make_circuit_open_result(
        self, doc: Union[str, Path, bytes, io.BytesIO]
    ) -> ProcessingResult:
        """Retorna um ProcessingResult de erro quando o circuit breaker está aberto."""
        return ProcessingResult(
            document=DocumentMetadata(filename=str(doc)[:200]),
            results=[
                Result(
                    question_id="circuit_breaker",
                    answer="Processamento interrompido: muitas falhas consecutivas",
                    status="CIRCUIT_OPEN",
                )
            ],
        )

    def _process_batch_sequential(
        self,
        documents: List[Union[str, Path, bytes, io.BytesIO]],
        questions: Optional[List[str]],
        classify: bool,
    ) -> List[ProcessingResult]:
        """Processamento sequencial com suporte a circuit breaker."""
        results = []
        for doc in documents:
            if self._circuit_breaker and not self._circuit_breaker.can_execute():
                results.append(self._make_circuit_open_result(doc))
                continue

            pr = self._process_single_safe(doc, questions, classify)
            results.append(pr)

            if self._circuit_breaker:
                has_error = any(r.status == "ERROR" for r in pr.results)
                if has_error:
                    self._circuit_breaker.record_failure()
                else:
                    self._circuit_breaker.record_success()

        return results

    def _process_batch_parallel(
        self,
        documents: List[Union[str, Path, bytes, io.BytesIO]],
        questions: Optional[List[str]],
        classify: bool,
        max_workers: int,
    ) -> List[ProcessingResult]:
        """Processamento paralelo com ThreadPoolExecutor e circuit breaker."""
        results: List[Optional[ProcessingResult]] = [None] * len(documents)

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_idx = {}
            for idx, doc in enumerate(documents):
                if self._circuit_breaker and not self._circuit_breaker.can_execute():
                    results[idx] = self._make_circuit_open_result(doc)
                    continue
                future = executor.submit(self._process_single_safe, doc, questions, classify)
                future_to_idx[future] = idx

            for future in as_completed(future_to_idx):
                idx = future_to_idx[future]
                pr = future.result()
                results[idx] = pr

                if self._circuit_breaker:
                    has_error = any(r.status == "ERROR" for r in pr.results)
                    if has_error:
                        self._circuit_breaker.record_failure()
                    else:
                        self._circuit_breaker.record_success()

        return results

    def _process_single_safe(
        self,
        doc: Union[str, Path, bytes, io.BytesIO],
        questions: Optional[List[str]],
        classify: bool,
    ) -> ProcessingResult:
        """Processa um documento capturando erros."""
        try:
            return self.process(doc, questions, classify)
        except (DocumentError, ProcessingError) as e:
            logger.error(f"Erro ao processar {doc}: {e}")
            return ProcessingResult(
                document=DocumentMetadata(filename=str(doc)),
                results=[
                    Result(
                        question_id="error",
                        answer=str(e),
                        status="ERROR",
                    )
                ],
            )

    # ========================================================================
    # ASYNC API
    # ========================================================================

    async def _call_llm_async(self, messages: list, response_model=None):
        """Chamada assíncrona ao LLM."""
        client = self._get_async_client()
        if response_model:
            return await client.beta.chat.completions.parse(
                model=self._model,
                messages=messages,
                response_format=response_model,
            )
        return await client.chat.completions.create(
            model=self._model,
            messages=messages,
        )

    async def _execute_question_async(self, text: str, question: Question) -> Result:
        """Versão assíncrona de _execute_question."""
        start = time.time()
        try:
            user_prompt = question.user_prompt.format(texto=text)
            messages = [
                {"role": "system", "content": question.system_prompt},
                {"role": "user", "content": user_prompt},
            ]

            response = await self._call_llm_async(messages, question.response_model)

            if question.response_model:
                result = response.choices[0].message.parsed
                answer = extract_main_response(result)
                raw_result = result.model_dump() if hasattr(result, "model_dump") else dict(result)
            else:
                answer = response.choices[0].message.content
                raw_result = {"response": answer}

            elapsed = time.time() - start
            prompt_tokens = response.usage.prompt_tokens
            completion_tokens = response.usage.completion_tokens
            total_tokens = response.usage.total_tokens
            cost = calculate_cost(self._model, prompt_tokens, completion_tokens)

            return Result(
                question_id=question.config.id,
                question_name=question.config.name,
                answer=answer,
                raw_result=raw_result,
                metrics=ProcessingMetrics(
                    time_seconds=round(elapsed, 2),
                    tokens=total_tokens,
                    prompt_tokens=prompt_tokens,
                    completion_tokens=completion_tokens,
                    cost_usd=round(cost, 6),
                    model=self._model,
                ),
                status="OK",
            )

        except Exception as e:
            logger.error(f"Erro ao executar pergunta async {question.config.id}: {e}")
            return Result(
                question_id=question.config.id,
                question_name=question.config.name,
                answer="Erro ao processar pergunta",
                status="ERROR",
                metrics=ProcessingMetrics(time_seconds=time.time() - start),
            )

    async def _classify_results_async(
        self, results: List[Result], doc_info: dict
    ) -> Optional[Dict[str, Any]]:
        """Versão assíncrona de _classify_results."""
        if not self._classification:
            return None
        try:
            data = {}
            for r in results:
                data[r.question_id] = r.answer
            data["_documento"] = doc_info.get("filename", "")
            data["_tipo"] = doc_info.get("doc_type", "")

            data_formatted = "\n".join([f"- {k}: {v}" for k, v in data.items()])
            prompt_final = self._classification.user_prompt.format(dados=data_formatted)

            messages = [
                {"role": "system", "content": self._classification.system_prompt},
                {"role": "user", "content": prompt_final},
            ]

            response = await self._call_llm_async(messages, self._classification.response_model)
            result = response.choices[0].message.parsed
            return result.model_dump() if hasattr(result, "model_dump") else dict(result)

        except Exception as e:
            logger.error(f"Erro na classificação async: {e}")
            return {"error": "Erro na classificacao", "error_type": type(e).__name__}

    async def _run_questions_async(
        self, questions_to_run: List[Question], documents: list
    ) -> tuple:
        """Executa todas as perguntas de forma assíncrona."""
        results: List[Result] = []
        total_time = 0.0
        total_tokens = 0
        total_cost = 0.0

        for question in questions_to_run:
            docs_to_process = documents
            page_range_applied = False
            page_range_ignored = False

            if question.page_range:
                total_pages = len(documents)
                page_indices, applied = question.page_range.get_page_indices(total_pages)
                if applied:
                    docs_to_process = [documents[i] for i in page_indices if i < len(documents)]
                    page_range_applied = True
                else:
                    page_range_ignored = True

            docs_filtered, info = filter_relevant_pages(docs_to_process, question.keywords)
            info["page_range_applied"] = page_range_applied
            info["page_range_ignored"] = page_range_ignored
            info["total"] = len(documents)

            if not docs_filtered:
                results.append(
                    Result(
                        question_id=question.config.id,
                        question_name=question.config.name,
                        answer="Sem páginas relevantes",
                        status="NO_DATA",
                        pages_used=0,
                        pages_total=info["total"],
                    )
                )
                continue

            text = "\n\n---\n\n".join([doc.text for doc in docs_filtered])
            result = await self._execute_question_async(text, question)
            result.pages_used = len(docs_filtered)
            result.pages_total = info["total"]
            results.append(result)

            total_time += result.metrics.time_seconds
            total_tokens += result.metrics.tokens
            total_cost += result.metrics.cost_usd

        return results, total_time, total_tokens, total_cost

    async def process_async(
        self,
        document: Union[str, Path, bytes, io.BytesIO],
        questions: Optional[List[str]] = None,
        classify: bool = False,
        filename: Optional[str] = None,
    ) -> ProcessingResult:
        """
        Versão assíncrona de process(). Chamadas LLM usam await.

        Args:
            document: Caminho do documento PDF, URL, bytes ou BytesIO
            questions: Lista de IDs de perguntas específicas (None = todas)
            classify: Se True, classifica o documento após extração
            filename: Nome para metadata/log (opcional)

        Returns:
            ProcessingResult com todos os resultados
        """
        content_bytes, metadata, doc_metadata, display_name = self._resolve_document(
            document, filename
        )

        questions_to_run = self._select_questions(questions)

        # Cache lookup
        cache_key = None
        if self._cache:
            doc_hash = DocumentCache.hash_document(content_bytes)
            q_ids = [q.config.id for q in questions_to_run]
            cache_key = DocumentCache.build_key(doc_hash, q_ids, self._model, classify)
            cached = self._cache.get(cache_key)
            if cached is not None:
                return cached

        documents = self._load_documents(content_bytes, metadata, display_name)

        results, total_time, total_tokens, total_cost = await self._run_questions_async(
            questions_to_run, documents
        )

        classification = None
        if classify and self._classification:
            classification = await self._classify_results_async(
                results, {"filename": display_name, "doc_type": metadata["doc_type"]}
            )

        processing_result = ProcessingResult(
            document=doc_metadata,
            results=results,
            classification=classification,
            total_metrics=ProcessingMetrics(
                time_seconds=round(total_time, 2),
                tokens=total_tokens,
                cost_usd=round(total_cost, 6),
                model=self._model,
            ),
        )

        if self._cache and cache_key:
            self._cache.put(cache_key, processing_result)

        return processing_result

    async def process_batch_async(
        self,
        documents: List[Union[str, Path, bytes, io.BytesIO]],
        questions: Optional[List[str]] = None,
        classify: bool = False,
        max_concurrency: int = 5,
    ) -> List[ProcessingResult]:
        """
        Versão assíncrona de process_batch() com controle de concorrência.

        Args:
            documents: Lista de documentos
            questions: Lista de IDs de perguntas específicas
            classify: Se True, classifica os documentos
            max_concurrency: Máximo de documentos processados em paralelo

        Returns:
            Lista de ProcessingResult na mesma ordem dos documentos
        """
        if self._circuit_breaker:
            self._circuit_breaker.reset()

        sem = asyncio.Semaphore(max_concurrency)

        async def _limited(doc):
            if self._circuit_breaker and not self._circuit_breaker.can_execute():
                return self._make_circuit_open_result(doc)

            async with sem:
                try:
                    pr = await self.process_async(doc, questions, classify)
                except (DocumentError, ProcessingError) as e:
                    logger.error(f"Erro ao processar async {doc}: {e}")
                    pr = ProcessingResult(
                        document=DocumentMetadata(filename=str(doc)),
                        results=[Result(question_id="error", answer=str(e), status="ERROR")],
                    )

                if self._circuit_breaker:
                    has_error = any(r.status == "ERROR" for r in pr.results)
                    if has_error:
                        self._circuit_breaker.record_failure()
                    else:
                        self._circuit_breaker.record_success()
                return pr

        return list(await asyncio.gather(*[_limited(d) for d in documents]))

    # ========================================================================
    # UTILITÁRIOS
    # ========================================================================

    @staticmethod
    def available_models() -> Dict[str, str]:
        """Retorna modelos disponíveis."""
        return MODELS.copy()

    @staticmethod
    def create_question(
        question_id: str,
        name: str,
        user_prompt: str,
        system_prompt: str = "Você é um especialista em extração de informações.",
        keywords: List[str] = None,
        page_range: Optional[PageRange] = None,
        response_model: Optional[Type[BaseModel]] = None,
    ) -> Question:
        """
        Método de conveniência para criar uma Question.

        Args:
            question_id: ID único da pergunta
            name: Nome descritivo
            user_prompt: Template do prompt (use {texto} como placeholder)
            system_prompt: Prompt de sistema
            keywords: Keywords para filtrar páginas
            page_range: Range de páginas (PageRange ou None para todas)
            response_model: Modelo Pydantic para structured output

        Returns:
            Question configurada

        Examples:
            ```python
            from deepread import DeepRead, PageRange

            # Pergunta nas primeiras 5 páginas
            q1 = DeepRead.create_question(
                question_id="intro",
                name="Introdução",
                user_prompt="Extraia a introdução: {texto}",
                page_range=PageRange(start=1, end=5, from_position="start")
            )

            # Pergunta nas últimas 3 páginas
            q2 = DeepRead.create_question(
                question_id="conclusao",
                name="Conclusão",
                user_prompt="Extraia a conclusão: {texto}",
                page_range=PageRange(start=1, end=3, from_position="end")
            )
            ```
        """
        return Question(
            config=QuestionConfig(id=question_id, name=name),
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            keywords=keywords or [],
            page_range=page_range,
            response_model=response_model,
        )
