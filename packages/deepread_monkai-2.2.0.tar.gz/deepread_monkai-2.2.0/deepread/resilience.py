# ============================================================================
# DEEPREAD RESILIENCE - RETRY E CIRCUIT BREAKER
# ============================================================================
"""
Mecanismos de resiliência: retry com backoff exponencial e circuit breaker.
"""

import logging
import threading
import time
from enum import Enum
from typing import Tuple, Type

from tenacity import (
    RetryCallState,
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

logger = logging.getLogger(__name__)

RETRYABLE_EXCEPTIONS: Tuple[Type[BaseException], ...] = ()

try:
    from openai import (
        APIConnectionError,
        APITimeoutError,
        InternalServerError,
        RateLimitError,
    )

    RETRYABLE_EXCEPTIONS = (
        RateLimitError,
        APITimeoutError,
        APIConnectionError,
        InternalServerError,
    )
except ImportError:
    pass


def _log_retry(retry_state: RetryCallState) -> None:
    exc = retry_state.outcome.exception() if retry_state.outcome else None
    logger.warning(
        "Retry %d/%d após erro: %s. Aguardando %.1fs...",
        retry_state.attempt_number,
        retry_state.retry_object.stop.max_attempt_number - 1,  # type: ignore[union-attr]
        type(exc).__name__ if exc else "unknown",
        retry_state.next_action.sleep if retry_state.next_action else 0,  # type: ignore[union-attr]
    )


def create_retry_decorator(max_retries: int = 3, min_wait: float = 1, max_wait: float = 16):
    """
    Cria um decorator de retry com backoff exponencial.

    Args:
        max_retries: Número máximo de tentativas extras (além da primeira)
        min_wait: Tempo mínimo de espera em segundos
        max_wait: Tempo máximo de espera em segundos
    """
    if not RETRYABLE_EXCEPTIONS or max_retries <= 0:

        def noop_decorator(fn):
            return fn

        return noop_decorator

    return retry(
        stop=stop_after_attempt(max_retries + 1),
        wait=wait_exponential(multiplier=min_wait, max=max_wait),
        retry=retry_if_exception_type(RETRYABLE_EXCEPTIONS),
        before_sleep=_log_retry,
        reraise=True,
    )


# ============================================================================
# CIRCUIT BREAKER
# ============================================================================


class CircuitState(Enum):
    CLOSED = "CLOSED"
    OPEN = "OPEN"
    HALF_OPEN = "HALF_OPEN"


class CircuitBreaker:
    """
    Circuit breaker para proteger contra falhas em cascata no batch processing.

    States:
        CLOSED  - Operação normal, contando falhas consecutivas.
        OPEN    - Bloqueado após atingir threshold. Espera recovery_timeout para testar.
        HALF_OPEN - Permite uma chamada de teste; sucesso volta a CLOSED, falha volta a OPEN.

    Args:
        failure_threshold: Número de falhas consecutivas para abrir o circuito
        recovery_timeout: Segundos para aguardar antes de tentar novamente (HALF_OPEN)
    """

    def __init__(self, failure_threshold: int = 5, recovery_timeout: int = 60):
        self._failure_threshold = failure_threshold
        self._recovery_timeout = recovery_timeout
        self._state = CircuitState.CLOSED
        self._failure_count = 0
        self._last_failure_time: float = 0
        self._lock = threading.Lock()

    @property
    def state(self) -> CircuitState:
        with self._lock:
            if self._state == CircuitState.OPEN:
                if time.time() - self._last_failure_time >= self._recovery_timeout:
                    self._state = CircuitState.HALF_OPEN
                    logger.info("Circuit breaker: OPEN -> HALF_OPEN (tentando recuperação)")
            return self._state

    def can_execute(self) -> bool:
        """Retorna True se a operação pode prosseguir."""
        current = self.state
        return current in (CircuitState.CLOSED, CircuitState.HALF_OPEN)

    def record_success(self) -> None:
        """Registra uma operação bem-sucedida."""
        with self._lock:
            if self._state == CircuitState.HALF_OPEN:
                logger.info("Circuit breaker: HALF_OPEN -> CLOSED (recuperado)")
            self._state = CircuitState.CLOSED
            self._failure_count = 0

    def record_failure(self) -> None:
        """Registra uma falha."""
        with self._lock:
            self._failure_count += 1
            self._last_failure_time = time.time()

            if self._state == CircuitState.HALF_OPEN:
                self._state = CircuitState.OPEN
                logger.warning("Circuit breaker: HALF_OPEN -> OPEN (falha na recuperação)")
            elif self._failure_count >= self._failure_threshold:
                self._state = CircuitState.OPEN
                logger.warning(
                    "Circuit breaker: CLOSED -> OPEN (%d falhas consecutivas)",
                    self._failure_count,
                )

    def reset(self) -> None:
        """Reseta o circuit breaker para o estado inicial."""
        with self._lock:
            self._state = CircuitState.CLOSED
            self._failure_count = 0
            self._last_failure_time = 0
