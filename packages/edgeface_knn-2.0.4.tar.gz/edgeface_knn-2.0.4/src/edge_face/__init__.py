"""edge_face — CPU-only real-time face recognition."""
