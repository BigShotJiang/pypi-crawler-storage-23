"""Tests for custom evaluators."""
