# Youtube Autonomous Web Resources module

The module in which we are able to generate web resources (images, animation frames, etc.) to be exported as images for the editor.

The system will start a scraper that will scrap a local (or remote) web page (which is also downloadable from a Google Drive direct link), sending parameters as query parameters in the url, and download the result resources respecting the transparencies (alphas).