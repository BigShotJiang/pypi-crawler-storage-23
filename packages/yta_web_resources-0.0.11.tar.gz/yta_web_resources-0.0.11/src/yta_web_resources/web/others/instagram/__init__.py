"""
TODO: I don't like this at all and it is not finished.
"""
from yta_web_resources import _WebResourceAnimatable


class _InstagramPopupWebResource(_WebResourceAnimatable):
    """
    *For internal use only*

    Web resource to create a quizz and download the
    different elements.
    """

    _element_id: str = 'capture'

# Instances to export here below
InstagramPopupWebResource = lambda do_use_local_url = True, do_use_gui = False: _InstagramPopupWebResource(
    local_path = 'src/yta_web_resources/web/others/instagram/index.html',
    # TODO: This is not the final url
    google_drive_direct_download_url = 'https://drive.google.com/file/d/1Eccy1rmf0wu3tFSVjEAwnzR0s8G2XtLo/view?usp=sharing',
    do_use_local_url = do_use_local_url,
    do_use_gui = do_use_gui
)