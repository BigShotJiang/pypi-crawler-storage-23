"""
The index.html file has been uploaded to 'danialcalayt >
yta_resources > otros > web_resources > quizz > images >
normal'
"""
from yta_web_resources import _WebResourceAnimatable


class _ImageCarrouselWebResource(_WebResourceAnimatable):
    """
    *For internal use only*

    Web resource to create a quizz and download the
    different elements.

    This is associated with the next file:
    - `web.quizz.images.normal.index.html`
    """

    _element_id: str = 'capture'

    # # TODO: I should limitate it to a specific width (?)
    # def get_frame(
    #     self,
    #     image_url: str,
    #     do_include_alpha: bool = True,
    #     output_filename: Union[str, None] = None
    # ):
    #     parameters = UrlParameters([
    #         UrlParameter('img', image_url)
    #     ])

    #     return self._get_frame(
    #         parameters = parameters,
    #         do_include_alpha = do_include_alpha,
    #         output_filename = output_filename
    #     )

# Instances to export here below
ImageCarrouselWebResource = lambda do_use_local_url = True, do_use_gui = False: _ImageCarrouselWebResource(
    local_path = 'src/yta_web_resources/web/images/carrousel/index.html',
    # TODO: This is not the correct link
    google_drive_direct_download_url = 'https://drive.google.com/file/d/1Eccy1rmf0wu3tFSVjEAwnzR0s8G2XtLo/view?usp=sharing',
    do_use_local_url = do_use_local_url,
    do_use_gui = do_use_gui
)