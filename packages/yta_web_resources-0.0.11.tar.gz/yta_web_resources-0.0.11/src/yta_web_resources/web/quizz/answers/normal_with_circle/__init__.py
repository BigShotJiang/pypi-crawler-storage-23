"""
The index.html file has been uploaded to 'danialcalayt >
yta_resources > otros > web_resources > quizz > answers >
normal_with_circle'
"""
from yta_web_resources import _WebResource


class _AnswerNormalWithCircleQuizzWebResource(_WebResource):
    """
    *For internal use only*

    Web resource to create a quizz and download the
    different elements.

    This is associated with the next file:
    - `web.quizz.answers.normal_with_circle.index.html`
    """

    _element_id: str = 'capture'

# Instances to export here below
AnswerNormalWithCircleQuizzWebResource = lambda do_use_local_url = True, do_use_gui = False: _AnswerNormalWithCircleQuizzWebResource(
    local_path = 'src/yta_web_resources/web/quizz/answers/normal_with_circle/index.html',
    google_drive_direct_download_url = 'https://drive.google.com/file/d/1XtFb878cCceykKn6J3bhDH5tEJVgdg58/view?usp=sharing',
    do_use_local_url = do_use_local_url,
    do_use_gui = do_use_gui
)