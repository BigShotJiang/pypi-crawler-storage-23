"""Data models for words-to-readlang.

This module defines the core data structures used throughout the library.
All parsers convert to Entry objects, and all writers consume Entry objects,
providing a stable contract between input and output formats.
"""

from dataclasses import dataclass


@dataclass
class Entry:
    """Represents a vocabulary entry in the intermediate format.

    This is the common format that all parsers produce and all writers consume.
    It decouples input formats from output formats, making the system extensible.

    Attributes:
        word: The vocabulary word or phrase (synonyms separated by ' / ')
        translation: The translation (alternatives separated by ' / ')
        example: Optional example sentence containing the word
        score: Optional practice interval in days
        date: Optional next practice date (YYYY-MM-DD format)
    """

    word: str
    translation: str
    example: str = ""
    score: str = ""
    date: str = ""

    @property
    def first_synonym(self) -> str:
        """Extract the first synonym from the word field.

        Readlang uses ' / ' to separate synonyms. This property returns
        the text before the first ' / ' separator, or the entire word
        if no separator is present.

        Returns:
            The first synonym, stripped of whitespace.

        Example:
            >>> entry = Entry(word="cat / kitty", translation="kissa")
            >>> entry.first_synonym
            'cat'
        """
        return self.word.split(" / ")[0].strip()

    def contains_word_in_example(self) -> bool:
        """Check if the example sentence contains the first synonym.

        Readlang requires that the example sentence contains the exact word
        from the first column. This method validates that requirement using
        case-insensitive matching.

        Returns:
            True if the example is non-empty and contains the first synonym
            (case-insensitive).

        Example:
            >>> entry = Entry(
            ...     word="cat",
            ...     translation="kissa",
            ...     example="The cat sat on the mat"
            ... )
            >>> entry.contains_word_in_example()
            True
            >>> entry.example = "The dog barked"
            >>> entry.contains_word_in_example()
            False
        """
        if not self.example:
            return False
        return self.first_synonym.lower() in self.example.lower()
