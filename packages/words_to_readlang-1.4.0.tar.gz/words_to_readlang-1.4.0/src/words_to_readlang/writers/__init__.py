"""Output format writers for words-to-readlang."""

from .base import Writer
from .readlang import ReadlangWriter

__all__ = ["Writer", "ReadlangWriter"]
