"""Prometheus metrics server.

Serves a /metrics endpoint on a separate port (default 7000) exposing
counts of sessions, uploads, and words in Prometheus text format.

The server runs in a daemon thread so it shuts down automatically when
the main process exits.  It queries SQLite directly (read-only) to avoid
any impact on the main application's SQLAlchemy connection pool.
"""

import os
import sqlite3
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

# Module-level reference so gunicorn.conf.py worker_exit hook can shut it down.
_server: HTTPServer | None = None


def _collect(db_path: str) -> str:
    """Run the metric queries and return a Prometheus text-format string."""
    con = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    try:
        cur = con.cursor()

        # Total sessions (all, including expired)
        (total_sessions,) = cur.execute("SELECT COUNT(*) FROM session").fetchone()

        # Active (non-expired) sessions
        (active_sessions,) = cur.execute(
            "SELECT COUNT(*) FROM session WHERE expires_at > datetime('now')"
        ).fetchone()

        # Total uploads
        (total_uploads,) = cur.execute("SELECT COUNT(*) FROM upload").fetchone()

        # Total words — sum the pre-computed entry_count on each upload row
        # so we never touch the (potentially large) entry table.
        (total_words,) = cur.execute(
            "SELECT COALESCE(SUM(entry_count), 0) FROM upload"
        ).fetchone()

        # Words per source language (same trick: sum entry_count on upload)
        words_per_lang = cur.execute(
            "SELECT source_language, COALESCE(SUM(entry_count), 0) FROM upload GROUP BY source_language"
        ).fetchall()

        # Uploads per source language
        uploads_per_lang = cur.execute(
            "SELECT source_language, COUNT(*) FROM upload GROUP BY source_language"
        ).fetchall()

    finally:
        con.close()

    lines = [
        "# HELP words_to_readlang_sessions_total Total number of sessions",
        "# TYPE words_to_readlang_sessions_total gauge",
        f"words_to_readlang_sessions_total {total_sessions}",
        "",
        "# HELP words_to_readlang_sessions_active Sessions that have not yet expired",
        "# TYPE words_to_readlang_sessions_active gauge",
        f"words_to_readlang_sessions_active {active_sessions}",
        "",
        "# HELP words_to_readlang_uploads_total Total number of uploads",
        "# TYPE words_to_readlang_uploads_total gauge",
        f"words_to_readlang_uploads_total {total_uploads}",
        "",
        "# HELP words_to_readlang_words_total Total number of vocabulary words",
        "# TYPE words_to_readlang_words_total gauge",
        f"words_to_readlang_words_total {total_words}",
        "",
        "# HELP words_to_readlang_words_by_language Vocabulary words per source language",
        "# TYPE words_to_readlang_words_by_language gauge",
    ]
    for lang, count in words_per_lang:
        lines.append(f'words_to_readlang_words_by_language{{source_language="{lang}"}} {count}')

    lines += [
        "",
        "# HELP words_to_readlang_uploads_by_language Uploads per source language",
        "# TYPE words_to_readlang_uploads_by_language gauge",
    ]
    for lang, count in uploads_per_lang:
        lines.append(f'words_to_readlang_uploads_by_language{{source_language="{lang}"}} {count}')

    lines.append("")
    return "\n".join(lines)


def _make_handler(db_path: str):
    class MetricsHandler(BaseHTTPRequestHandler):
        def do_GET(self):
            if self.path != "/metrics":
                self.send_response(404)
                self.end_headers()
                return
            try:
                body = _collect(db_path).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/plain; version=0.0.4; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            except Exception as exc:
                self.send_response(500)
                self.end_headers()
                self.wfile.write(str(exc).encode())

        def log_message(self, format, *args):  # noqa: A002
            pass  # suppress per-request access log noise

    return MetricsHandler


def start_metrics_server(db_path: str, host: str = "127.0.0.1", port: int = 7000) -> None:
    """Start the metrics HTTP server in a background daemon thread.

    Safe to call in every Gunicorn worker: SO_REUSEPORT allows multiple
    processes to bind the same port; the kernel distributes incoming
    connections across whichever workers are alive.

    The server instance is stored in the module-level ``_server`` variable so
    that the Gunicorn ``worker_exit`` hook in gunicorn.conf.py can call
    ``server.shutdown()`` before the worker process exits, allowing
    ``serve_forever()`` to return cleanly instead of blocking until SIGKILL.

    Args:
        db_path: Absolute path to the SQLite database file.
        host: Address to bind to (default: 127.0.0.1).
        port: Port to listen on (default: 7000).
    """
    global _server
    import sys

    try:
        # allow_reuse_port lets every Gunicorn worker bind the same port;
        # the kernel distributes connections across whichever workers are alive.
        HTTPServer.allow_reuse_port = True
        server = HTTPServer((host, port), _make_handler(db_path))
    except OSError as exc:
        print(f"[metrics] could not bind {host}:{port} — {exc}", file=sys.stderr)
        return

    _server = server
    thread = threading.Thread(target=server.serve_forever, daemon=True, name="metrics")
    thread.start()
    print(f"[metrics] listening on http://{host}:{port}/metrics (pid {os.getpid()})", file=sys.stderr)
