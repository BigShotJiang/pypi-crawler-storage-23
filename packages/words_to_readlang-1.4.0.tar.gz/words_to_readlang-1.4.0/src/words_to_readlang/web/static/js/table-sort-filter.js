/**
 * table-sort-filter.js
 *
 * Adds sort (click header) and per-column filter (input below header) to any
 * <table> that has data-sortable on it.
 *
 * Usage: add data-sortable to the <table> element. Each <th> that should be
 * sortable/filterable gets a data-col="<index>" attribute (0-based) and
 * optionally data-nosort or data-nofilter to opt out of one behaviour.
 *
 * Works with HTMX infinite scroll: a MutationObserver watches the <tbody> and
 * re-applies the current filter whenever new rows arrive.
 */

(function () {
    'use strict';

    function initTable(table) {
        const thead = table.tHead;
        const tbody = table.tBodies[0];
        if (!thead || !tbody) return;

        const headerRow = thead.rows[0];
        const ths = Array.from(headerRow.cells);

        // --- State ---
        let sortCol = null;       // column index currently sorted on
        let sortDir = 1;          // 1 = asc, -1 = desc
        const filters = {};       // col index → lowercase filter string

        // --- Build filter row ---
        const filterRow = document.createElement('tr');
        filterRow.className = 'table-filter-row';

        ths.forEach((th) => {
            const td = document.createElement('td');
            const col = th.dataset.col;
            const noFilter = th.hasAttribute('data-nofilter');

            if (col !== undefined && !noFilter) {
                const input = document.createElement('input');
                input.type = 'text';
                input.placeholder = '…';
                input.className = 'col-filter-input';
                input.setAttribute('aria-label', 'Filter ' + (th.textContent.trim() || col));
                input.addEventListener('keydown', (e) => {
                    if (e.key === 'Enter') e.preventDefault();
                });
                input.addEventListener('input', () => {
                    const val = input.value.toLowerCase();
                    if (val) {
                        filters[col] = val;
                    } else {
                        delete filters[col];
                    }
                    applyFilter();
                });
                td.appendChild(input);
            }
            filterRow.appendChild(td);
        });

        thead.appendChild(filterRow);

        // --- Sort indicators on <th> ---
        ths.forEach((th) => {
            const col = th.dataset.col;
            if (col === undefined || th.hasAttribute('data-nosort')) return;

            th.style.cursor = 'pointer';
            th.style.userSelect = 'none';

            const indicator = document.createElement('span');
            indicator.className = 'sort-indicator';
            indicator.textContent = ' ↕';
            indicator.style.cssText = 'font-size:0.7em; color:#9ca3af; margin-left:0.2em;';
            th.appendChild(indicator);

            th.addEventListener('click', () => {
                if (sortCol === parseInt(col)) {
                    sortDir = -sortDir;
                } else {
                    sortCol = parseInt(col);
                    sortDir = 1;
                }
                updateSortIndicators();
                sortRows();
            });
        });

        function updateSortIndicators() {
            ths.forEach((th) => {
                const ind = th.querySelector('.sort-indicator');
                if (!ind) return;
                const col = parseInt(th.dataset.col);
                if (col === sortCol) {
                    ind.textContent = sortDir === 1 ? ' ↑' : ' ↓';
                    ind.style.color = '#374151';
                } else {
                    ind.textContent = ' ↕';
                    ind.style.color = '#9ca3af';
                }
            });
        }

        function getCellText(row, colIdx) {
            const cell = row.cells[colIdx];
            return cell ? (cell.dataset.sortValue || cell.textContent).trim().toLowerCase() : '';
        }

        function sortRows() {
            if (sortCol === null) return;
            const rows = Array.from(tbody.rows);
            // Keep the infinite-scroll sentinel at the bottom
            const sentinel = rows.find(r => r.id && r.id.startsWith('load-more-'));
            const dataRows = rows.filter(r => r !== sentinel);

            dataRows.sort((a, b) => {
                const aVal = getCellText(a, sortCol);
                const bVal = getCellText(b, sortCol);
                // Try numeric comparison first
                const aNum = parseFloat(aVal);
                const bNum = parseFloat(bVal);
                if (!isNaN(aNum) && !isNaN(bNum)) {
                    return (aNum - bNum) * sortDir;
                }
                return aVal.localeCompare(bVal, undefined, { sensitivity: 'base' }) * sortDir;
            });

            // Re-append in new order
            dataRows.forEach(r => tbody.appendChild(r));
            if (sentinel) tbody.appendChild(sentinel);

            // Re-apply filter visibility
            applyFilter();
        }

        function getSentinel() {
            return tbody.querySelector('tr[id^="load-more-"]');
        }

        function applyFilter() {
            const activeFilters = Object.entries(filters);
            let visible = 0;
            let total = 0;

            Array.from(tbody.rows).forEach((row) => {
                // Always keep the sentinel visible so HTMX can keep loading pages
                if (row.id && row.id.startsWith('load-more-')) {
                    row.style.display = '';
                    return;
                }
                total++;

                let show = true;
                for (const [col, val] of activeFilters) {
                    const cellText = getCellText(row, parseInt(col)).toLowerCase();
                    if (!cellText.includes(val)) {
                        show = false;
                        break;
                    }
                }
                row.style.display = show ? '' : 'none';
                if (show) visible++;
            });

            updateRowCounter(visible, total);

            // If a filter is active and the sentinel is still in the DOM, prod
            // HTMX to load the next page — the sentinel may be in-viewport now
            // that most rows are hidden, but its revealed event already fired.
            if (activeFilters.length > 0) {
                const sentinel = getSentinel();
                if (sentinel && typeof htmx !== 'undefined') {
                    htmx.trigger(sentinel, 'revealed');
                }
            }
        }

        // --- Row counter ---
        let counterEl = table.parentElement.querySelector('.table-row-counter');
        if (!counterEl) {
            counterEl = document.createElement('div');
            counterEl.className = 'table-row-counter';
            counterEl.style.cssText = 'font-size:0.75rem; color:#9ca3af; text-align:right; padding:0.25rem 0.5rem;';
            table.parentElement.insertBefore(counterEl, table);
        }

        function updateRowCounter(visible, total) {
            if (Object.keys(filters).length === 0) {
                counterEl.textContent = total + ' rows loaded';
            } else {
                counterEl.textContent = visible + ' of ' + total + ' rows match';
            }
        }

        // Initial count
        applyFilter();

        // --- MutationObserver: re-apply filter when HTMX adds rows ---
        const observer = new MutationObserver(() => {
            applyFilter();
        });
        observer.observe(tbody, { childList: true });
    }

    // Init all tables with data-sortable on page load
    document.addEventListener('DOMContentLoaded', () => {
        document.querySelectorAll('table[data-sortable]').forEach(initTable);
    });
})();

// Sentence picker: event-delegated click handler (safe for HTMX swaps)
document.addEventListener('click', function (e) {
    const btn = e.target.closest('.sentence-pick-btn');
    if (!btn) return;
    const textarea = document.getElementById(btn.dataset.target);
    if (!textarea) return;
    textarea.value = btn.dataset.sentence;
    textarea.dispatchEvent(new Event('input', { bubbles: true }));
    const metaInput = document.getElementById(btn.dataset.metaTarget);
    if (metaInput) metaInput.value = btn.dataset.source + ':' + btn.dataset.sentenceId;
    btn.closest('.sentence-picker-list')
        ?.querySelectorAll('.sentence-pick-btn')
        .forEach(function (b) { b.classList.remove('sentence-pick-btn--active'); });
    btn.classList.add('sentence-pick-btn--active');
});
