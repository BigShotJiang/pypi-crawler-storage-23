"""Routes for fetching example sentences from Tatoeba and Leipzig."""

import json
from datetime import datetime

from flask import Blueprint, Response, current_app, g, render_template

from words_to_readlang.services.fetcher import ExampleFetcher

from ..database import db
from ..models import Entry, LeipzigCache, TatoebaCache, Upload
from ..services import ValidationService

examples_bp = Blueprint("examples", __name__)


def _lookup_all_cache(word: str, src_lang: str, target_lang: str):
    """Return all cached sentences for a word, ordered by rank.

    Tatoeba rows first (rank-ordered), Leipzig rows appended (rank-ordered).
    Returns a list of dicts with keys: example, sentence_id, license,
    author, source, source_url.
    """
    tatoeba_rows = (
        TatoebaCache.query
        .filter_by(word=word, source_language=src_lang, target_language=target_lang)
        .order_by(TatoebaCache.rank)
        .all()
    )
    leipzig_rows = (
        LeipzigCache.query
        .filter_by(word=word, source_language=src_lang)
        .order_by(LeipzigCache.rank)
        .all()
    )

    results = []
    for tc in tatoeba_rows:
        results.append({
            "example": tc.sentence_text,
            "sentence_id": tc.sentence_id,
            "license": tc.license,
            "author": tc.author,
            "source": "tatoeba",
            "source_url": None,
        })
    for lc in leipzig_rows:
        results.append({
            "example": lc.sentence_text,
            "sentence_id": lc.sentence_id,
            "license": "CC BY",
            "author": None,
            "source": "leipzig",
            "source_url": lc.source_url,
        })
    return results


def _lookup_cache(word: str, src_lang: str, target_lang: str):
    """Return the best cached sentence for a word, or None."""
    results = _lookup_all_cache(word, src_lang, target_lang)
    return results[0] if results else None


def _save_all_cache(word: str, src_lang: str, target_lang: str, results):
    """Store all fetched results in the appropriate cache tables.

    Each result is a (example, sentence_id, license_info, author_or_url, source)
    tuple. Skips entries whose sentence_id is already in the cache to avoid
    duplicates on re-fetch.
    """
    existing_tatoeba = {
        str(r.sentence_id)
        for r in TatoebaCache.query.filter_by(
            word=word, source_language=src_lang, target_language=target_lang
        ).all()
    }
    existing_leipzig = {
        r.sentence_id
        for r in LeipzigCache.query.filter_by(
            word=word, source_language=src_lang
        ).all()
    }

    tatoeba_rank = TatoebaCache.query.filter_by(
        word=word, source_language=src_lang, target_language=target_lang
    ).count()
    leipzig_rank = LeipzigCache.query.filter_by(
        word=word, source_language=src_lang
    ).count()

    for example, sentence_id, license_info, author_or_url, example_source in results:
        if example_source == "tatoeba":
            if str(sentence_id) not in existing_tatoeba:
                db.session.add(TatoebaCache(
                    word=word,
                    source_language=src_lang,
                    target_language=target_lang,
                    sentence_id=int(sentence_id),
                    sentence_text=example,
                    license=license_info,
                    author=author_or_url or "",
                    rank=tatoeba_rank,
                    created_at=datetime.utcnow(),
                ))
                tatoeba_rank += 1
        else:
            if str(sentence_id) not in existing_leipzig:
                db.session.add(LeipzigCache(
                    word=word,
                    source_language=src_lang,
                    sentence_id=str(sentence_id),
                    sentence_text=example,
                    source_url=author_or_url or "",
                    rank=leipzig_rank,
                    created_at=datetime.utcnow(),
                ))
                leipzig_rank += 1


def _save_cache(word: str, src_lang: str, target_lang: str,
                example: str, sentence_id, license_info: str,
                author, example_source: str, source_url: str = ""):
    """Store a fetched example in the appropriate cache table (single-result path)."""
    author_or_url = source_url if example_source == "leipzig" else author
    _save_all_cache(
        word, src_lang, target_lang,
        [(example, sentence_id, license_info, author_or_url, example_source)]
    )


def _apply_to_entry(entry, example, sentence_id, license_info, author, example_source, source_url=None):
    """Write fetched example fields onto an Entry."""
    entry.edited_example = example
    entry.tatoeba_attempted = True
    entry.tatoeba_result = example
    entry.tatoeba_sentence_id = int(sentence_id) if example_source == "tatoeba" else None
    entry.example_license = license_info
    entry.example_author = author
    entry.example_source = example_source
    entry.example_source_url = source_url


@examples_bp.route("/fetch/<int:entry_id>", methods=["POST"])
def fetch_example(entry_id):
    """HTMX endpoint to fetch an example for a single entry.

    Args:
        entry_id: Entry ID to fetch example for

    Returns:
        Rendered example HTML or error message
    """
    entry = Entry.query.get_or_404(entry_id)

    if entry.upload.session_id != g.session.id:
        return "Unauthorized", 403

    word = entry.current_word.split(" / ")[0].strip()
    src_lang = entry.upload.source_language
    target_lang = entry.upload.target_language

    cached_all = _lookup_all_cache(word, src_lang, target_lang)
    if cached_all:
        best = cached_all[0]
        example = best["example"]
        sentence_id = best["sentence_id"]
        license_info = best["license"]
        author = best["author"]
        example_source = best["source"]
    else:
        client = ExampleFetcher(delay=0.5, verbose=False)
        try:
            all_results = client.fetch_all_with_metadata(
                word, src_lang=src_lang, target_lang=target_lang
            )
            if all_results:
                _save_all_cache(word, src_lang, target_lang, all_results)
                db.session.flush()
                cached_all = _lookup_all_cache(word, src_lang, target_lang)
                best = cached_all[0]
                example = best["example"]
                sentence_id = best["sentence_id"]
                license_info = best["license"]
                author = best["author"]
                example_source = best["source"]
            else:
                entry.tatoeba_attempted = True
                db.session.commit()
                return '<span class="error">No example found</span>'
        except Exception as e:
            return f'<span class="error">Error: {str(e)}</span>'

    _apply_to_entry(entry, example, sentence_id, license_info, author, example_source,
                    source_url=cached_all[0]["source_url"] if cached_all else None)
    ValidationService.update_entry_validation(entry)
    db.session.commit()

    return render_template(
        "htmx/example_result.html",
        example=example,
        license=license_info,
        author=author,
        example_source=example_source,
        sentence_id=sentence_id,
        cached_sentences=cached_all,
    )


def _make_fetch_generator(entry_ids, src_lang, target_lang, app):
    """Return an SSE generator that fetches missing examples for the given entry IDs."""

    def generate():
        with app.app_context():
            total = len(entry_ids)

            if total == 0:
                yield f"data: {json.dumps({'done': True, 'message': 'No entries need examples'})}\n\n"
                return

            client = ExampleFetcher(delay=0.5, verbose=False)

            for idx, entry_id in enumerate(entry_ids, 1):
                entry = db.session.get(Entry, entry_id)
                if not entry:
                    continue

                word = entry.current_word.split(" / ")[0].strip()

                try:
                    cached_all = _lookup_all_cache(word, src_lang, target_lang)
                    if cached_all:
                        best = cached_all[0]
                        example = best["example"]
                        sentence_id = best["sentence_id"]
                        license_info = best["license"]
                        author = best["author"]
                        example_source = best["source"]
                        source_url = best["source_url"]
                    else:
                        all_results = client.fetch_all_with_metadata(
                            word,
                            src_lang=src_lang,
                            target_lang=target_lang,
                        )
                        if all_results:
                            _save_all_cache(word, src_lang, target_lang, all_results)
                            db.session.flush()
                            example, sentence_id, license_info, author_or_url, example_source = all_results[0]
                            author = author_or_url if example_source != "leipzig" else None
                            source_url = author_or_url if example_source == "leipzig" else None
                        else:
                            entry.tatoeba_attempted = True
                            db.session.commit()
                            yield f"data: {json.dumps({'current': idx, 'total': total, 'entry_id': entry.id, 'success': False, 'word': word})}\n\n"
                            continue

                    _apply_to_entry(entry, example, sentence_id, license_info, author, example_source,
                                    source_url=source_url)
                    ValidationService.update_entry_validation(entry)
                    db.session.commit()

                    yield f"data: {json.dumps({'current': idx, 'total': total, 'entry_id': entry.id, 'success': True, 'word': word, 'source': example_source})}\n\n"

                except Exception as e:
                    yield f"data: {json.dumps({'current': idx, 'total': total, 'entry_id': entry.id, 'success': False, 'word': word, 'error': str(e)})}\n\n"

            yield f"data: {json.dumps({'done': True})}\n\n"

    return generate


@examples_bp.route("/fetch-all/<int:upload_id>")
def fetch_all_missing(upload_id):
    """SSE endpoint to fetch all missing examples for an upload.

    Args:
        upload_id: Upload ID to process

    Returns:
        Server-Sent Events stream with progress updates
    """
    upload = Upload.query.get_or_404(upload_id)
    if upload.session_id != g.session.id:
        return "Unauthorized", 403

    entry_ids = [
        e.id for e in
        Entry.query.filter_by(upload_id=upload_id)
        .filter(Entry.validation_status.in_(["invalid_no_example", "invalid_word_missing"]))
        .all()
    ]

    app = current_app._get_current_object()
    generate = _make_fetch_generator(
        entry_ids, upload.source_language, upload.target_language, app
    )
    return Response(generate(), mimetype="text/event-stream")
