"""Edit routes for modifying entries."""

from flask import Blueprint, g, render_template, request

from ..database import db
from ..models import Entry, LeipzigCache, TatoebaCache, Upload
from ..services import ValidationService

edit_bp = Blueprint("edit", __name__)


@edit_bp.route("/<int:entry_id>/cancel")
def cancel_edit(entry_id):
    """Restore the original upload entry row after cancelling an edit."""
    entry = Entry.query.get_or_404(entry_id)
    if entry.upload.session_id != g.session.id:
        return "", 403
    return render_template("components/entry_row.html", entry=entry)


@edit_bp.route("/<int:entry_id>/form")
def edit_form(entry_id):
    """HTMX endpoint: inline edit form for an upload entry."""
    entry = Entry.query.get_or_404(entry_id)
    if entry.upload.session_id != g.session.id:
        return "", 403
    from ..routes.examples import _lookup_all_cache
    word = entry.current_word.split(" / ")[0].strip()
    cached_sentences = _lookup_all_cache(
        word, entry.upload.source_language, entry.upload.target_language
    )
    return render_template("htmx/edit_form.html", entry=entry, cached_sentences=cached_sentences)


@edit_bp.route("/<int:entry_id>", methods=["PUT", "POST"])
def update_entry(entry_id):
    """Save edited upload entry."""
    entry = Entry.query.get_or_404(entry_id)
    if entry.upload.session_id != g.session.id:
        return "", 403

    entry.edited_word = request.form.get("word", "").strip()
    entry.edited_translation = request.form.get("translation", "").strip()
    entry.edited_example = request.form.get("example", "").strip()

    example_source_field = request.form.get("example_source", "")
    if example_source_field and ":" in example_source_field:
        source, sentence_id = example_source_field.split(":", 1)
        if source == "tatoeba":
            row = TatoebaCache.query.filter_by(sentence_id=int(sentence_id)).first()
            if row:
                entry.example_source = "tatoeba"
                entry.tatoeba_sentence_id = row.sentence_id
                entry.example_license = row.license
                entry.example_author = row.author
                entry.example_source_url = None
        elif source == "leipzig":
            row = LeipzigCache.query.filter_by(sentence_id=sentence_id).first()
            if row:
                entry.example_source = "leipzig"
                entry.tatoeba_sentence_id = None
                entry.example_license = "CC BY"
                entry.example_author = None
                entry.example_source_url = row.source_url

    ValidationService.update_entry_validation(entry)
    db.session.commit()

    return render_template("components/entry_row.html", entry=entry)


@edit_bp.route("/<int:entry_id>", methods=["DELETE"])
def delete_entry(entry_id):
    """Delete an upload entry."""
    entry = Entry.query.get_or_404(entry_id)
    if entry.upload.session_id != g.session.id:
        return "", 403
    upload = entry.upload
    db.session.delete(entry)
    db.session.commit()
    upload.entry_count = Entry.query.filter_by(upload_id=upload.id).count()
    db.session.commit()
    return ""


@edit_bp.route("/bulk-delete", methods=["POST"])
def bulk_delete_entries():
    """Delete multiple entries at once.

    Form data:
        upload_id: The upload these entries belong to
        entry_ids: List of entry IDs to delete
    """
    upload_id = request.form.get("upload_id", type=int)
    entry_ids = request.form.getlist("entry_ids", type=int)

    if not upload_id or not entry_ids:
        return "", 400

    upload = Upload.query.get_or_404(upload_id)
    if upload.session_id != g.session.id:
        return "", 403

    entries = Entry.query.filter(
        Entry.id.in_(entry_ids),
        Entry.upload_id == upload_id,
    ).all()

    for entry in entries:
        db.session.delete(entry)

    db.session.commit()
    upload.entry_count = Entry.query.filter_by(upload_id=upload_id).count()
    db.session.commit()

    return f'<tr><td colspan="6" style="text-align:center; padding: 0.5rem; color: #6b7280;">Deleted {len(entries)} entries.</td></tr>', 200


@edit_bp.route("/delete-duplicates/<int:upload_id>", methods=["POST"])
def delete_duplicate_entries(upload_id):
    """Delete entries whose word appears in any other upload in the same session.

    An entry is considered a duplicate if its current_word (case-insensitive)
    matches an entry in a different upload belonging to the same session.
    """
    upload = Upload.query.get_or_404(upload_id)
    if upload.session_id != g.session.id:
        return "", 403

    # Collect all words from other uploads in the same session
    other_uploads = Upload.query.filter(
        Upload.session_id == g.session.id,
        Upload.id != upload_id,
    ).all()

    other_words: set[str] = set()
    for other_upload in other_uploads:
        for entry in other_upload.entries:
            word = (entry.edited_word or entry.original_word).strip().lower()
            other_words.add(word)

    if not other_words:
        return '<tr><td colspan="6" style="text-align:center; padding: 0.5rem; color: #6b7280;">No other uploads to compare against.</td></tr>', 200

    to_delete = []
    for entry in upload.entries:
        word = (entry.edited_word or entry.original_word).strip().lower()
        if word in other_words:
            to_delete.append(entry)

    count = len(to_delete)
    for entry in to_delete:
        db.session.delete(entry)

    db.session.commit()
    upload.entry_count = Entry.query.filter_by(upload_id=upload_id).count()
    db.session.commit()

    if count == 0:
        msg = "No duplicate words found in other uploads."
    else:
        msg = f"Deleted {count} duplicate entries."

    return f'<tr><td colspan="6" style="text-align:center; padding: 0.5rem; color: #6b7280;">{msg}</td></tr>', 200
