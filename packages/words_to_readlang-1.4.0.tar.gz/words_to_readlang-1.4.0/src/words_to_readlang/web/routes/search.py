"""Search routes for finding words across all uploads."""

from flask import Blueprint, g, redirect, render_template, request, url_for
from sqlalchemy import func

from ..database import db
from ..models import Entry, Upload

search_bp = Blueprint("search", __name__)


@search_bp.route("/")
def search_page():
    """Search words across all uploads in the current session."""
    if not g.session:
        return redirect(url_for("main.index"))

    q = request.args.get("q", "").strip()
    source = request.args.get("source", "").strip()
    target = request.args.get("target", "").strip()

    available_pairs = (
        db.session.query(Upload.source_language, Upload.target_language)
        .filter_by(session_id=g.session.id)
        .distinct()
        .all()
    )

    if not q:
        return render_template(
            "search.html",
            results=None,
            query="",
            source_language=source,
            target_language=target,
            available_pairs=available_pairs,
        )

    q_lower = q.lower()
    query = (
        Entry.query.join(Upload)
        .filter(
            Upload.session_id == g.session.id,
            db.or_(
                func.lower(Entry.original_word).like(f"%{q_lower}%"),
                func.lower(Entry.edited_word).like(f"%{q_lower}%"),
                func.lower(Entry.original_translation).like(f"%{q_lower}%"),
                func.lower(Entry.edited_translation).like(f"%{q_lower}%"),
            ),
        )
        .order_by(func.lower(Entry.original_word), Upload.uploaded_at)
    )

    if source and target:
        query = query.filter(
            Upload.source_language == source,
            Upload.target_language == target,
        )

    entries = query.all()

    groups: dict = {}
    for entry in entries:
        key = entry.current_word.lower()
        groups.setdefault(key, []).append(entry)

    results = [
        {
            "word": entries_list[0].current_word,
            "entries": entries_list,
            "translations_differ": len({e.current_translation for e in entries_list}) > 1,
        }
        for entries_list in groups.values()
    ]

    return render_template(
        "search.html",
        results=results,
        query=q,
        source_language=source,
        target_language=target,
        available_pairs=available_pairs,
    )
