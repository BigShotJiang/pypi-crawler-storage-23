import warnings

warnings.warn(
    "The 'unsloth-mlx' package has been renamed to 'mlx-tune'. "
    "Please switch: pip install mlx-tune\n"
    "Then update your imports: from mlx_tune import ...\n"
    "See: https://pypi.org/project/mlx-tune/",
    DeprecationWarning,
    stacklevel=2,
)

from mlx_tune import *  # noqa: F401, F403
from mlx_tune import __version__  # noqa: F401
