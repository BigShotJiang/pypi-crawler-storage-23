# unsloth-mlx has been renamed to mlx-tune

This package is deprecated. Please install **[mlx-tune](https://pypi.org/project/mlx-tune/)** instead:

```bash
pip install mlx-tune
```

Then update your imports:

```python
# Before
from unsloth_mlx import FastLanguageModel

# After
from mlx_tune import FastLanguageModel
```

Everything else stays the same — same API, same features, just a new name.

For more info, visit the **[mlx-tune GitHub repo](https://github.com/ARahim3/mlx-tune)**.
