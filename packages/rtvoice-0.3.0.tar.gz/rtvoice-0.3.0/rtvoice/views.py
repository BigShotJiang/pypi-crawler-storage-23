from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path

from pydantic import BaseModel

from rtvoice.conversation.views import ConversationTurn


class RealtimeModel(StrEnum):
    GPT_REALTIME = "gpt-realtime"
    GPT_REALTIME_MINI = "gpt-realtime-mini"


class AssistantVoice(StrEnum):
    """
    Available assistant voices for the OpenAI Realtime API.

    Each voice has distinct characteristics suited for different use-cases
    such as narration, conversational dialogue, or expressive responses.

    - alloy: Neutral and balanced, clean output suitable for general use.
    - ash: Clear and precise; described as a male baritone with a slightly
      scratchy yet upbeat quality. May have limited performance with accents.
    - ballad: Melodic and gentle; community notes suggest a male-sounding voice.
    - coral: Warm and friendly, good for approachable or empathetic tones.
    - echo: Resonant and deep, strong presence in delivery.
    - fable: Not officially documented; often perceived as narrative-like
      and expressive, fitting for storytelling contexts.
    - onyx: Not officially documented; often perceived as darker, strong,
      and confident in tone.
    - nova: Not officially documented; frequently described as bright,
      youthful, or energetic.
    - sage: Calm and thoughtful, measured pacing and a reflective quality.
    - shimmer: Bright and energetic, dynamic expression with high clarity.
    - verse: Versatile and expressive, adapts well across different contexts.
    - cedar: (Realtime-only) - no official description available yet.
    - marin: (Realtime-only) - no official description available yet.
    """

    ALLOY = "alloy"
    ASH = "ash"
    BALLAD = "ballad"
    CORAL = "coral"
    ECHO = "echo"
    FABLE = "fable"
    ONYX = "onyx"
    NOVA = "nova"
    SAGE = "sage"
    SHIMMER = "shimmer"
    VERSE = "verse"
    CEDAR = "cedar"
    MARIN = "marin"


class TranscriptionModel(StrEnum):
    WHISPER_1 = "whisper-1"


class NoiseReduction(StrEnum):
    """
    Noise reduction filter type for audio input.

    - NEAR_FIELD: Optimized for close-range audio (e.g., headset microphone)
    - FAR_FIELD: Optimized for distant audio sources (e.g., room microphone)
    """

    NEAR_FIELD = "near_field"
    FAR_FIELD = "far_field"


class SemanticEagerness(StrEnum):
    """How quickly semantic VAD decides the user has finished speaking."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    AUTO = "auto"


class SemanticVAD(BaseModel):
    """Semantic voice-activity detection.

    The model waits until it understands the speaker has finished a thought —
    more natural and fewer false cut-offs than energy-based detection.
    """

    eagerness: SemanticEagerness = SemanticEagerness.AUTO


class ServerVAD(BaseModel):
    """Energy/silence-based voice-activity detection."""

    threshold: float = 0.5
    prefix_padding_ms: int = 300
    silence_duration_ms: int = 500


TurnDetection = SemanticVAD | ServerVAD


@dataclass
class AgentError:
    """Error information from the agent."""

    type: str
    message: str
    code: str | None = None
    param: str | None = None

    def __str__(self) -> str:
        return f"[{self.type}] {self.message}"


class AgentListener:
    async def on_agent_session_connected(self) -> None:
        pass

    async def on_agent_stopped(self) -> None:
        pass

    async def on_agent_interrupted(self) -> None:
        pass

    async def on_agent_error(self, error: AgentError) -> None:
        pass

    async def on_user_transcript(self, transcript: str) -> None:
        pass

    async def on_assistant_transcript(self, transcript: str) -> None:
        pass

    async def on_user_started_speaking(self) -> None:
        pass

    async def on_user_stopped_speaking(self) -> None:
        pass

    async def on_assistant_started_responding(self) -> None:
        pass

    async def on_assistant_stopped_responding(self) -> None:
        pass


class AgentResult(BaseModel):
    turns: list[ConversationTurn]
    duration_seconds: float
    recording_path: Path | None = None
