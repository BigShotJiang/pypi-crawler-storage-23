# Dual-Repo Parallel Benchmark

- Generated at: 2026-02-22T16:02:40.865223+00:00
- Strategies: `grep+read` baseline vs `know workflow` (single daemon RPC)
- Language globs: `py, ts, tsx, js, jsx, go, rs, swift`

## /Users/sushil/Code/Github/know-cli

- know version: `0.8.3`
- Token reduction: `93.4%` | Latency ratio (know/grep): `2.0x` | Tool-call reduction: `93.8%`
- Deep call-graph available: `100.0%` | non-empty edges: `100.0%`

| Query | Grep Tokens | know Tokens | Token Savings | Grep Time (s) | know Time (s) |
|---|---:|---:|---:|---:|---:|
| configuration loading and environment variable handling | 38,589 | 4,945 | 87.2% | 0.096 | 0.119 |
| database schema and persistence layer | 46,191 | 2,981 | 93.5% | 0.038 | 0.112 |
| module dependency graph and call graph tracking | 91,125 | 3,923 | 95.7% | 0.051 | 0.115 |
| error handling and retry logic | 78,476 | 4,947 | 93.7% | 0.049 | 0.123 |

## /Users/sushil/Code/Github/farfield

- know version: `0.8.3`
- Token reduction: `94.5%` | Latency ratio (know/grep): `1.72x` | Tool-call reduction: `93.8%`
- Deep call-graph available: `75.0%` | non-empty edges: `75.0%`

| Query | Grep Tokens | know Tokens | Token Savings | Grep Time (s) | know Time (s) |
|---|---:|---:|---:|---:|---:|
| configuration loading and environment variable handling | 66,301 | 4,704 | 92.9% | 0.124 | 0.208 |
| database schema and persistence layer | 31,431 | 3,546 | 88.7% | 0.097 | 0.182 |
| module dependency graph and call graph tracking | 80,982 | 3,484 | 95.7% | 0.117 | 0.19 |
| error handling and retry logic | 105,944 | 3,907 | 96.3% | 0.12 | 0.207 |
