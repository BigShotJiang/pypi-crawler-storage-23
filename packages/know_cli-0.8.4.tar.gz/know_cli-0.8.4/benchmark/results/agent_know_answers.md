# Farfield Codebase Investigation Results

Investigation performed using `know` CLI for context retrieval.

---

## Question 1: How does the billing/subscription system work?

### Subscription Model

The subscription is represented by the `WorkspaceSubscription` SQLAlchemy model in `/Users/sushil/Code/Github/farfield/apps/api/src/features/billing/models.py` (line 24). It maps to the `workspace_subscriptions` table and tracks per-workspace Stripe subscription state.

Key fields:
- `workspace_id` (FK to `workspaces.id`, unique -- one subscription per workspace)
- `stripe_customer_id`, `stripe_subscription_id` -- Stripe identifiers
- `status` -- one of the `SubscriptionStatus` enum values: `trialing`, `active`, `past_due`, `canceled`, `unpaid` (defined at line 16 in the same file)
- `plan_name` -- defaults to `"pro"` (single plan tier currently)
- `billing_interval` -- `"month"` or `"year"`
- `seat_count` -- number of workspace members (synced to Stripe)
- `max_concurrent_sandboxes` -- defaults to `2`
- `trial_ends_at`, `current_period_end`, `cancel_at_period_end` -- billing lifecycle fields

### Billing Plan Tiers and Limits

The system currently has a single plan tier: **"pro"** (the default `plan_name`). The plan offers:
- Monthly or yearly billing intervals (configured via `settings.stripe_price_id_monthly` and `settings.stripe_price_id_yearly`)
- Per-seat pricing (quantity = member count in workspace)
- 14-day free trial (`trial_period_days: 14` in checkout session creation)
- Default of **2 concurrent sandboxes** (`max_concurrent_sandboxes` defaults to 2)

### Sandbox Limit Enforcement

Sandbox limits are enforced in `BillingService.check_cloud_access()` at `/Users/sushil/Code/Github/farfield/apps/api/src/features/billing/service.py` (line 180). This is the **central gate** for cloud execution:

1. **No subscription** -> raises `CloudReadinessError(code="no_subscription")`
2. **Trialing but expired** -> raises `CloudReadinessError(code="trial_expired")`
3. **Canceled or unpaid** -> raises `CloudReadinessError(code="subscription_inactive")`
4. **Concurrent sandbox limit** -> counts active cloud sessions via `SubscriptionRepository.count_active_cloud_sessions()` (line 128 in `repository.py`). If `active_sessions >= sub.max_concurrent_sandboxes`, raises `CloudReadinessError(code="concurrent_limit")`

The `count_active_cloud_sessions()` method counts sandboxes as active when:
- **GKE**: the `AgentPod` is still assigned (status = "assigned")
- **E2B**: no pod exists, so falls back to `cloud_status` being in `("pending", "provisioning", "cloning", "running")`

This check is called from `CloudSessionService.create_cloud_session()` in `/Users/sushil/Code/Github/farfield/apps/api/src/features/cloud_sessions/service.py` (line 222).

### Key Files and Classes

| File | Key Classes/Functions |
|---|---|
| `apps/api/src/features/billing/models.py` | `SubscriptionStatus`, `WorkspaceSubscription` |
| `apps/api/src/features/billing/service.py` | `BillingService`, `check_cloud_access()`, `create_checkout_session()`, `handle_webhook_event()`, `sync_seat_count()` |
| `apps/api/src/features/billing/repository.py` | `SubscriptionRepository`, `count_active_cloud_sessions()` |
| `apps/api/src/features/billing/router.py` | `get_billing_status()`, `create_checkout()`, `create_portal()`, `handle_webhook()` |
| `apps/api/src/features/billing/schemas.py` | `SubscriptionStatusResponse`, `CheckoutSessionRequest`, `CheckoutSessionResponse`, `PortalSessionResponse` |
| `apps/api/src/features/billing/dependencies.py` | `get_billing_service()`, `get_subscription_repository()` |
| `apps/web/src/lib/billing.ts` | `toSubscriptionState()`, `getSubscriptionStatus()`, `createCheckoutSession()` |
| `apps/web/src/hooks/use-cloud-readiness.ts` | `computeCloudReadiness()`, `applyWarnings()` |

---

## Question 2: How does the LLM provider system work?

### Provider Configuration and Selection

Providers are defined as the `ApiKeyProvider` enum in `/Users/sushil/Code/Github/farfield/apps/api/src/features/api_keys/models.py` (line 15):
- `ANTHROPIC`, `ANTHROPIC_OAUTH`, `OPENAI`, `OPENAI_OAUTH`, `GEMINI`, `VERTEX`, `OPENROUTER`, `CURSOR`

Hardcoded supported models are in `SUPPORTED_MODELS` dict in `/Users/sushil/Code/Github/farfield/apps/api/src/features/llm/models.py` (line 32):
- **Anthropic**: `claude-sonnet-4-5`, `claude-opus-4-5`, `claude-opus-4-6` (200k context)
- **OpenAI**: `gpt-5.1`, `gpt-5.1-codex` (128k context)
- **Gemini**: `gemini-3-pro-preview`, `gemini-3-flash-preview`, `gemini-2.5-flash` (1M context)
- **OpenRouter**: `x-ai/grok-code-fast-1` (131k context)

The default model is `"gemini-3-flash-preview"` (line 10).

### The `provider_discovery` Module

Located at `/Users/sushil/Code/Github/farfield/apps/api/src/features/llm/provider_discovery.py`, this module dynamically discovers available models by querying provider APIs at runtime.

Key components:
- **`DiscoveredModel`** (line 24): dataclass with `id`, `display_name`, `provider`
- **`_MODEL_DISCOVERY_PROVIDERS`** (line 31): providers that support live model listing -- Anthropic, OpenAI, Gemini, Cursor
- **`ALL_PROVIDERS`** (line 49): full list including OpenRouter (which has no live fetcher)
- **`_PROVIDER_FETCHERS`** (line 173): maps providers to fetch functions:
  - `_fetch_anthropic_models()` -- calls `api.anthropic.com/v1/models`
  - `_fetch_openai_models()` -- calls `api.openai.com/v1/models`, filters by prefixes `gpt-`, `o1-`, `o3-`, `o4-`, `chatgpt-`
  - `_fetch_gemini_models()` -- calls `generativelanguage.googleapis.com/v1beta/models`, filters to those supporting `generateContent`
  - `_fetch_cursor_models()` -- calls `api.cursor.com/v0/models`
- **Caching**: 10-minute TTL (`CACHE_TTL_SECONDS = 600`) per provider
- **Fallback**: `_fallback_models()` returns hardcoded `SUPPORTED_MODELS` entries when API keys are missing or fetches fail
- **`discover_models()`** (line 217): main entry point, fetches all providers concurrently via `asyncio.gather`, optionally filtered by `AgentToolType`
- **`TOOL_TYPE_PROVIDERS`** (line 40): maps each `AgentToolType` to which providers it can query

### Workspace-Level Model Settings

Managed by the `WorkspaceModel` SQLAlchemy model in `/Users/sushil/Code/Github/farfield/apps/api/src/features/llm/workspace_models.py` (line 43), stored in `workspace_models` table.

The workspace model registry allows admins to:
- **Disable** discovered models (`is_enabled=false`)
- **Add custom models** not returned by provider APIs
- **Override display names** and sort order

The merge logic is in `list_workspace_models()` in `/Users/sushil/Code/Github/farfield/apps/api/src/features/llm/router.py` (line 71):
1. Live discovery via `discover_models()` (primary source)
2. Load admin registry from `WorkspaceModelRepository`
3. Apply registry overrides (disable discovered models)
4. Add registry-only models (custom admin-added)
5. Return merged list

The `PROVIDER_TOOL_TYPES` dict in `workspace_models.py` (line 25) maps provider to compatible tool types:
- `anthropic` -> `claude_code`, `cursor_agent`, `openclaw`
- `openai` -> `codex_cli`, `cursor_agent`, `openclaw`
- `gemini` -> `gemini_cli`, `cursor_agent`, `openclaw`
- `openrouter` -> `cursor_agent`, `openclaw`
- `cursor` -> `cursor_agent`

### Model Instantiation

`LLMService` in `/Users/sushil/Code/Github/farfield/apps/api/src/features/llm/service.py` (line 24) creates LangChain chat model instances. `get_chat_model()` dispatches based on provider:
- **Anthropic** -> `ChatAnthropic` with optional extended thinking (`thinking_budget`)
- **Gemini** -> `ChatGoogleGenerativeAI` or `ChatVertexAI` (via `use_vertex` flag)
- **OpenAI** -> `ChatOpenAI`
- **OpenRouter** -> `ChatOpenAI` with `openrouter.ai/api/v1` base URL
- **Cursor** -> `ChatOpenAI` with `api.cursor.com/v1` base URL

### Key Files

| File | Key Classes/Functions |
|---|---|
| `apps/api/src/features/api_keys/models.py` | `ApiKeyProvider` enum |
| `apps/api/src/features/llm/models.py` | `SUPPORTED_MODELS`, `ModelInfo`, `DEFAULT_MODEL`, `get_provider_for_model()` |
| `apps/api/src/features/llm/provider_discovery.py` | `discover_models()`, `_fetch_anthropic_models()`, `_fetch_openai_models()`, `_fetch_gemini_models()`, `_fetch_cursor_models()`, `_fallback_models()` |
| `apps/api/src/features/llm/workspace_models.py` | `WorkspaceModel`, `WorkspaceModelRepository`, `PROVIDER_TOOL_TYPES` |
| `apps/api/src/features/llm/router.py` | `list_workspace_models()`, `add_workspace_model()`, `update_workspace_model()` |
| `apps/api/src/features/llm/service.py` | `LLMService`, `get_chat_model()` |
| `apps/api/src/features/agent_credentials/router.py` | `set_user_credential()`, `_validate_agent_provider()` |

---

## Question 3: How does the agent execution pipeline work?

### Flow from User Message to Agent Response

The pipeline for a CLI/API session message is handled by `send_message()` in `/Users/sushil/Code/Github/farfield/apps/api/src/features/agent/router.py` (line 285):

1. **Load session** from DB via `session_repo.get_by_public_id_and_user()`
2. **Resolve model**: use provided model or fall back to session's stored model
3. **Get API key**: look up the user's API key for the model's provider via `get_user_api_key()`
4. **Build context provider**: `build_provider_from_session()` reconstructs a `ContextProvider` (local filesystem or GitHub-backed) from session data
5. **Create tools**: `create_tools(provider)` creates LangChain tools backed by the context provider + `create_research_tools()` for web search (Tavily/Exa)
6. **Create LLM instance**: `llm_service.get_chat_model()` with streaming and extended thinking enabled
7. **Create agent**: `create_planning_agent(model, all_tools)` builds the LangGraph agent
8. **Deserialize history**: `deserialize_messages(db_session.messages)` loads prior conversation
9. **Stream response**: returns `StreamingResponse` wrapping `stream_agent_response()`

For web/thread-based conversations, `stream_thread_agent_response()` (line 336 in `streaming.py`) handles a similar flow with plan context and clarification context.

### LangGraph's Role

The core agent is built in `create_planning_agent()` at `/Users/sushil/Code/Github/farfield/apps/api/src/features/agent/graph.py` (line 52). It creates a **LangGraph `StateGraph`** with two nodes:

1. **`agent` node**: invokes the LLM with tools bound. Injects `PLANNING_SYSTEM_PROMPT` as system message, optionally enriched with clarification context and command instructions. Sanitizes messages to remove invalid tool calls.
2. **`tools` node**: `ToolNode(tools)` -- LangGraph's built-in tool execution node

Routing logic (`should_continue`):
- If the last AI message has `tool_calls` -> route to `"tools"`
- Otherwise -> route to `END`
- Edge: `tools -> agent` (loop back after tool execution)

The graph is compiled with optional `AsyncPostgresSaver` checkpointer for persistence. Recursion limit is set to 100 for complex planning with many tool calls.

State is managed via `PlanningState` (defined in `/Users/sushil/Code/Github/farfield/apps/api/src/features/agent/state.py`), which includes `messages`, `context_source`, `repo_path`, `session_id`, and `clarification_context`.

### Streaming

`stream_agent_response()` in `/Users/sushil/Code/Github/farfield/apps/api/src/features/agent/streaming.py` (line 116) uses LangGraph's multi-mode streaming (`stream_mode=["messages", "updates"]`):
- **"messages" mode**: streams LLM tokens, filtered by node name (only `agent` node text is streamed)
- **"updates" mode**: captures tool results and state updates

It emits SSE events with types: `thinking`, `token`, `tool_call`, `tool_result`, `plan_edit`, `done`, `error`.

### Tools and MCP Integration

Tools are created in `/Users/sushil/Code/Github/farfield/apps/api/src/features/agent/tools.py`:

- **`create_tools(provider)`** (line 32): creates file/code tools backed by a `ContextProvider`:
  - `read_file` -- read a file from the codebase
  - `list_directory` -- explore project structure
  - `search_code` -- regex search across codebase
  - `get_file_tree` -- project file structure tree
  - `get_dependencies` -- project dependency listing
  - `find_relevant_files` -- semantic file finding by concept

- **`create_plan_tools(plan_context)`**: creates plan-specific tools for editing plans

- **`create_research_tools(tavily_api_key, exa_api_key)`**: creates web search tools using Tavily and Exa APIs

For cloud execution (coding agents running in sandboxes), the tool types are defined by `AgentToolType` enum in `/Users/sushil/Code/Github/farfield/apps/api/src/features/coding_agents/models.py` (line 28):
- `CLAUDE_CODE`, `CURSOR_AGENT`, `CODEX_CLI`, `GEMINI_CLI`, `OPENCLAW`

These coding agents run in cloud sandboxes (GKE pods or E2B sandboxes) managed by `CloudSessionService` in `/Users/sushil/Code/Github/farfield/apps/api/src/features/cloud_sessions/service.py`. The cloud execution path (`send_cloud_message` at `cloud_sessions/router.py` line 173) forwards messages to the agent running inside the sandbox rather than executing the LangGraph pipeline directly.

The agent credentials system (`agent_credentials/`) manages per-user and per-workspace API keys for each agent tool type, with validation via `AGENT_ACCEPTED_PROVIDERS` to ensure each tool type only receives compatible provider credentials.

### Key Files

| File | Key Classes/Functions |
|---|---|
| `apps/api/src/features/agent/router.py` | `send_message()`, `create_session()`, `build_provider_from_session()` |
| `apps/api/src/features/agent/graph.py` | `create_planning_agent()`, `PLANNING_SYSTEM_PROMPT`, `PlanningState` |
| `apps/api/src/features/agent/streaming.py` | `stream_agent_response()`, `stream_thread_agent_response()` |
| `apps/api/src/features/agent/tools.py` | `create_tools()`, `create_plan_tools()`, `create_research_tools()` |
| `apps/api/src/features/agent/state.py` | `PlanningState` |
| `apps/api/src/features/agent/serialization.py` | `serialize_messages()`, `deserialize_messages()` |
| `apps/api/src/features/agent/models.py` | `AgentSession` |
| `apps/api/src/features/cloud_sessions/service.py` | `CloudSessionService`, `create_cloud_session()` |
| `apps/api/src/features/cloud_sessions/router.py` | `send_cloud_message()`, `create_cloud_session()`, `start_cloud_session()` |
| `apps/api/src/features/coding_agents/models.py` | `AgentToolType`, `CodingAgent`, `CodingAgentSession`, `CloudSession`, `AgentPod` |
| `apps/api/src/features/llm/service.py` | `LLMService.get_chat_model()` |
| `apps/api/src/features/clarification/prompt_builder.py` | `ClarificationPromptBuilder` |
