"""Constants for exec-sandbox configuration and limits."""

import enum
from dataclasses import dataclass
from typing import Final

# ============================================================================
# Guest Agent Error Types (wire format vocabulary)
# ============================================================================


class GuestErrorType(str, enum.Enum):
    """Domain-specific error types from the guest agent wire protocol.

    Maps 1:1 to Rust ErrorType enum in guest-agent/src/error.rs.
    """

    ENV_VAR = "env_var_error"
    CODE = "code_error"
    PATH = "path_error"
    PACKAGE = "package_error"
    IO = "io_error"
    TIMEOUT = "timeout_error"
    EXECUTION = "execution_error"
    REQUEST = "request_error"
    PROTOCOL = "protocol_error"
    OUTPUT_LIMIT = "output_limit_error"


# ============================================================================
# VM Memory and Resource Defaults
# ============================================================================

DEFAULT_MEMORY_MB: Final[int] = 192
"""Default guest VM memory allocation in MB.

History: 512MB → 256MB (cost optimization) → 192MB (Bun needs ~42MB RSS + kernel
overhead; 192MB provides sufficient headroom while reducing per-VM cost)."""

MIN_MEMORY_MB: Final[int] = 128
"""Minimum guest VM memory in MB.

NOTE: JavaScript (Bun) requires significantly more memory than Python.
Bun RSS ~42MB vs CPython ~19MB. At 128MB VMs (~40MB free RAM), Bun
swap-thrashes via zram causing 40s+ latency for trivial operations.
Recommended minimums: Python 128MB, JavaScript 160MB+, ideal 192MB+.
The --smol flag in guest-agent mitigates this but doesn't eliminate it.
"""

# ============================================================================
# Execution Timeouts
# ============================================================================

DEFAULT_TIMEOUT_SECONDS: Final[int] = 30
"""Default code execution timeout in seconds."""

MAX_TIMEOUT_SECONDS: Final[int] = 300
"""Maximum code execution timeout in seconds (5 minutes)."""

VM_BOOT_TIMEOUT_SECONDS: Final[int] = 45
"""VM boot timeout in seconds (guest agent ready check).

Raised from 30s to 45s (1.5x) to accommodate CI nested virtualization
overhead (AMD nested KVM: 50-90% CPU degradation per Cloud Hypervisor
issue #4827). Bare-metal boots complete in <1s; the timeout is for the
full boot + guest-agent ready sequence under worst-case contention."""

VM_BOOT_MAX_RETRIES: Final[int] = 4
"""Maximum retry attempts for VM boot failures (CPU contention resilience).

Raised from 3 to 4 to give transient overlay daemon errors (connection
refused on startup) an extra attempt to recover."""

VM_BOOT_RETRY_MIN_SECONDS: Final[float] = 0.1
"""Minimum backoff between VM boot retries (100ms base).

Raised from 20ms to 100ms — under CI CPU contention the host scheduler
needs time to reschedule the QEMU process; 20ms retries were too tight."""

VM_BOOT_RETRY_MAX_SECONDS: Final[float] = 2.0
"""Maximum backoff between VM boot retries (2s cap with jitter).

Raised from 500ms to 2s to let overlay daemon recover from transient
connection-refused errors (daemon restart takes ~100-500ms)."""


@dataclass(frozen=True, slots=True)
class RetryProfile:
    """Bundled retry parameters for VM boot.

    Pre-built profiles tune retry aggressiveness to caller context:
    - User-facing: generous retries for best success rate
    - Background: fewer retries, shorter timeouts for sacrificial VMs
    """

    max_attempts: int
    boot_timeout_seconds: int
    retry_min_seconds: float
    retry_max_seconds: float


RETRY_USER_FACING: Final[RetryProfile] = RetryProfile(
    max_attempts=VM_BOOT_MAX_RETRIES,
    boot_timeout_seconds=VM_BOOT_TIMEOUT_SECONDS,
    retry_min_seconds=VM_BOOT_RETRY_MIN_SECONDS,
    retry_max_seconds=VM_BOOT_RETRY_MAX_SECONDS,
)
"""Default retry profile for user-facing VMs (scheduler)."""

RETRY_BACKGROUND: Final[RetryProfile] = RetryProfile(
    max_attempts=2,
    boot_timeout_seconds=30,
    retry_min_seconds=VM_BOOT_RETRY_MIN_SECONDS,
    retry_max_seconds=VM_BOOT_RETRY_MAX_SECONDS,
)
"""Retry profile for background/disposable VMs (warm pool, snapshot creation, L1 saves).
Fewer retries and shorter timeout — these VMs are sacrificial."""

GUEST_CONNECT_TIMEOUT_SECONDS: Final[int] = 5
"""Timeout for connecting to guest agent."""

GUEST_REQUEST_TIMEOUT_SECONDS: Final[int] = 5
"""Default timeout for guest agent request/response (ping, etc.)."""

WARM_REPL_TIMEOUT_SECONDS: Final[int] = 120
"""Timeout for WarmReplRequest (REPL process startup in guest).

Python REPL takes 11+ seconds on HVF (Alpine CPython cold start), and under
resource contention (background save runs concurrently with user execution)
it can take 2-3x longer. 120s is generous since this is used for background
L1 saves and warm pool pre-warm — latency doesn't matter, only success."""

GUEST_RECONNECT_PROBE_TIMEOUT: Final[float] = 0.5
"""Timeout per ping probe when verifying guest is ready after reconnection.

After close()+connect(), QEMU's chardev socket accepts before the guest agent
has reopened its virtio-serial port fds. Data sent in this window is silently
dropped. A lightweight PingRequest confirms the guest is actually listening."""

GUEST_RECONNECT_PROBE_MAX_RETRIES: Final[int] = 5
"""Maximum reconnection probe attempts before raising TimeoutError."""

GUEST_RECONNECT_PROBE_DELAY: Final[float] = 0.05
"""Delay between reconnection probe retries (50ms)."""

EXECUTION_TIMEOUT_MARGIN_SECONDS: Final[int] = 8
"""Hard timeout margin above soft timeout (host watchdog protection).
Accounts for:
- Guest graceful termination grace period (5s SIGTERM→SIGKILL)
- JSON serialization, network transmission, clock skew (~2s)
- Safety buffer (~1s)
Must be >= guest-agent TERM_GRACE_PERIOD_SECONDS (5s) + overhead."""

SNAPSHOT_CREATION_MIN_MEMORY_MB: Final[int] = 384
"""Minimum guest memory for snapshot creation VMs (package installation).

Snapshot creation runs uv/bun (large binaries) inside the guest. Under TCG,
the cold-start JIT translation of uv (~30MB Rust binary) plus TLS crypto drives
RSS above 192MB, triggering zram compression which runs in emulated code (5-8x
slower). 384MB provides headroom to avoid zram thrashing during pip/npm install."""

PACKAGE_INSTALL_TIMEOUT_SECONDS: Final[int] = 300
"""Timeout for package installation in guest VM.

Sent to the guest agent via InstallPackagesRequest.timeout field.
The guest enforces this as the tokio::time::timeout for the package manager process.
Also used host-side to compute hard_timeout (+ EXECUTION_TIMEOUT_MARGIN_SECONDS)."""

PACKAGE_INSTALL_MAX_RETRIES: Final[int] = 3
"""Maximum retry attempts for transient network errors during package install."""

PACKAGE_INSTALL_RETRY_MIN_SECONDS: Final[float] = 1.0
"""Minimum backoff between package install retries (1s base).

Longer than VM boot retry (0.1s) because network issues persist longer than CPU contention."""

PACKAGE_INSTALL_RETRY_MAX_SECONDS: Final[float] = 8.0
"""Maximum backoff between package install retries (8s cap with jitter).

Longer than VM boot retry (2s) to allow transient DNS/routing issues to resolve."""

# ============================================================================
# Code Execution Limits
# ============================================================================

MAX_CODE_SIZE: Final[int] = 1024 * 1024  # 1 MiB
"""Maximum size in bytes for code input."""

MAX_PACKAGES: Final[int] = 50
"""Maximum number of packages allowed per execution."""

MAX_ENV_VARS: Final[int] = 100
"""Maximum number of environment variables allowed."""

MAX_ENV_VAR_NAME_LENGTH: Final[int] = 256
"""Maximum length for environment variable names."""

MAX_ENV_VAR_VALUE_LENGTH: Final[int] = 4096
"""Maximum length for environment variable values."""

# Control characters forbidden in env var names/values (security risk)
# Allows: tab (0x09), printable ASCII (0x20-0x7E), UTF-8 multibyte (0x80+)
# Forbids: NUL, C0 controls (except tab), DEL
ENV_VAR_FORBIDDEN_CONTROL_CHARS: Final[frozenset[int]] = frozenset(
    list(range(0x09))  # NUL, SOH, STX, ETX, EOT, ENQ, ACK, BEL, BS
    + list(range(0x0A, 0x20))  # LF, VT, FF, CR, SO through US (includes ESC at 0x1B)
    + [0x7F]  # DEL
)
"""Forbidden control characters in env var names/values (terminal escape injection prevention)."""


# ============================================================================
# File I/O
# ============================================================================

MAX_FILE_SIZE_BYTES: Final[int] = 500 * 1024 * 1024  # 500MB
"""Maximum file size for read/write operations.

With streaming zstd-compressed chunks, neither host nor guest buffers
the full file in memory (~128 KB peak).  The practical ceiling is guest
disk free space (rootfs_size + 100 MB), not RAM.
"""

MAX_FILE_PATH_LENGTH: Final[int] = 4096
"""Maximum relative file path length in bytes (POSIX PATH_MAX).

Individual filename components are limited to 255 bytes (NAME_MAX) by the
guest agent's validate_file_path(). This constant covers the full relative path.
"""

FILE_IO_TIMEOUT_SECONDS: Final[int] = 120
"""Timeout for file I/O operations in seconds."""


GUEST_SANDBOX_DIR: Final[str] = "/home/user"
"""Root directory for sandbox file operations in the guest VM."""

# ============================================================================
# Outbound Domain Filtering
# ============================================================================
# Note: dnsmasq approach was replaced by gvproxy OutboundAllow (DNS + TLS filtering)
# (see gvproxy.py start_gvproxy for rationale)

PYTHON_PACKAGE_DOMAINS: Final[list[str]] = [
    "pypi.org",
    "files.pythonhosted.org",
]
"""Default domain whitelist for Python package installation."""

NPM_PACKAGE_DOMAINS: Final[list[str]] = [
    "registry.npmjs.org",
]
"""Default domain whitelist for JavaScript/Node package installation."""

# ============================================================================
# System Limits
# ============================================================================

CONSOLE_RING_LINES: Final[int] = 500
"""In-memory ring buffer size (lines) for QEMU console output.

Kernel loglevel=7 can emit 300-600 lines before init starts.
500 keeps the diagnostic tail intact for boot failure analysis."""

QEMU_OUTPUT_MAX_BYTES: Final[int] = 2000
"""Maximum bytes to capture from QEMU stdout/stderr."""

# ============================================================================
# Disk I/O Performance Limits
# ============================================================================

DISK_BPS_LIMIT: Final[int] = 50 * 1024 * 1024  # 50 MB/s
"""Sustained disk bandwidth limit in bytes/second (prevent noisy neighbor)."""

DISK_BPS_BURST: Final[int] = 100 * 1024 * 1024  # 100 MB/s
"""Burst disk bandwidth limit in bytes/second (package downloads)."""

DISK_IOPS_LIMIT: Final[int] = 1000
"""Sustained IOPS limit (typical code execution workload)."""

DISK_IOPS_BURST: Final[int] = 2000
"""Burst IOPS limit (npm install, pip install)."""

# ============================================================================
# Kernel Version Requirements
# ============================================================================

IO_URING_MIN_KERNEL_MAJOR: Final[int] = 5
"""Minimum Linux kernel major version for io_uring support."""

IO_URING_MIN_KERNEL_MINOR: Final[int] = 1
"""Minimum Linux kernel minor version for io_uring support (5.1+)."""

# ============================================================================
# Warm VM Pool
# ============================================================================

WARM_POOL_REPLENISH_CONCURRENCY_RATIO: Final[float] = 0.5
"""Max concurrent replenish boots as ratio of pool_size (50% = 2-3 concurrent for pool_size=5)."""

WARM_POOL_TENANT_ID: Final[str] = "warm-pool"
"""Placeholder tenant ID for warm pool VMs."""

L1_SAVE_TENANT_ID: Final[str] = "l1-cache"
"""Tenant ID for sacrificial VMs created during L1 background saves."""

SCHEDULER_TENANT_ID: Final[str] = "exec-sandbox"
"""Tenant ID for user-facing VMs created by the scheduler."""

WARM_POOL_HEALTH_CHECK_INTERVAL: Final[int] = 15
"""Health check interval for warm VMs in seconds."""

WARM_POOL_HEALTH_CHECK_MAX_RETRIES: Final[int] = 3
"""Maximum retry attempts before declaring VM unhealthy (matches K8s failureThreshold)."""

WARM_POOL_HEALTH_CHECK_RETRY_MIN_SECONDS: Final[float] = 0.1
"""Minimum backoff between health check retries."""

WARM_POOL_HEALTH_CHECK_RETRY_MAX_SECONDS: Final[float] = 2.0
"""Maximum backoff between health check retries."""

# ============================================================================
# Balloon Memory Management (for warm pool memory efficiency)
# ============================================================================

BALLOON_INFLATE_TARGET_MB: Final[int] = 160
"""Target guest memory in MB when inflating balloon for idle warm pool VMs.
Inflating the balloon reduces guest memory, allowing host to reclaim.

History: 64MB caused unresponsive guests (only ~14MB headroom). 96MB still
caused freezes on kernel 6.18 where ~38MB overhead + guest-agent + Python
leaves <20MB free under pressure. 128MB caused ~20% QEMU vCPU overhead on
Bun VMs (42MB RSS) because the balloon driver couldn't reach target and kept
retrying page reclaim. 160MB provides sufficient headroom for all runtimes
(~70MB free after Bun overhead) while achieving 17% memory reduction vs 192MB."""

BALLOON_TOLERANCE_MB: Final[int] = 40
"""Tolerance in MB for balloon target polling. Allows early exit when balloon is
'close enough' to target, accounting for kernel overhead and slow CI runners."""

BALLOON_INFLATE_TIMEOUT_SECONDS: Final[float] = 5.0
"""Timeout for balloon inflate operation (reducing guest memory for idle pool)."""

BALLOON_DEFLATE_TIMEOUT_SECONDS: Final[float] = 5.0
"""Timeout for balloon deflate operation (restoring guest memory before execution)."""

# ============================================================================
# Memory Snapshot (L1 Cache)
# ============================================================================

MEMORY_SNAPSHOT_SAVE_TIMEOUT_SECONDS: Final[float] = 30.0
"""Timeout for saving VM state to file (migrate command + poll)."""

MEMORY_SNAPSHOT_RESTORE_TIMEOUT_SECONDS: Final[float] = 30.0
"""Timeout for restoring VM state from file (migrate-incoming + poll)."""

MEMORY_SNAPSHOT_QMP_TIMEOUT_SECONDS: Final[float] = 10.0
"""Timeout for individual QMP commands during migration."""

MEMORY_SNAPSHOT_POLL_INTERVAL_SECONDS: Final[float] = 0.005
"""Interval between query-migrate polls (5ms)."""

MEMORY_SNAPSHOT_MIN_QEMU_VERSION: Final[tuple[int, int, int]] = (9, 0, 0)
"""Minimum QEMU version for mapped-ram + multifd migration capabilities.
Changing capabilities requires bumping MEMORY_SNAPSHOT_FORMAT_VERSION."""

MEMORY_SNAPSHOT_FORMAT_VERSION: Final[int] = 2
"""Migration format version. Bump when changing QMP capabilities or migration
protocol to invalidate stale L1 cache entries. History:
  v1: Plain streaming format (no mapped-ram)
  v2: mapped-ram + multifd (QEMU >= 9.0)
"""

# ============================================================================
# Overlay Pool
# ============================================================================

OVERLAY_POOL_FALLBACK_SIZE: Final[int] = 5
"""Overlay pool size when host resources are unknown (psutil unavailable).

Provides a reasonable default for pre-created overlays per base image
when the admission controller cannot determine host capacity."""

OVERLAY_POOL_SIZE_RATIO: Final[float] = 0.5
"""Overlay pool size as ratio of effective max VMs (50%).

With 10 max VMs, pool will have 5 pre-created overlays per base image.
Higher ratio = more pool hits, lower ratio = less disk usage.
"""

OVERLAY_POOL_REPLENISH_BATCH_SIZE: Final[int] = 8
"""Max concurrent overlay creations during startup and replenishment.

Benchmarked on NVMe SSD (30 overlays):
- 4: 0.50s (59.8/sec) - too conservative
- 8: 0.41s (73.2/sec) - 22% faster, good balance
- 16: 0.36s (82.9/sec) - 38% faster but aggressive
- 32: 0.42s (71.7/sec) - contention kicks in

8 balances throughput vs compatibility with slower storage.
"""

OVERLAY_POOL_REPLENISH_INTERVAL_SECONDS: Final[float] = 0.5
"""Interval between replenishment checks."""

# ============================================================================
# QEMU Storage Daemon
# ============================================================================

QEMU_STORAGE_DAEMON_SOCKET_TIMEOUT_SECONDS: Final[float] = 5.0
"""Timeout for QMP socket operations."""

QEMU_STORAGE_DAEMON_STARTUP_TIMEOUT_SECONDS: Final[float] = 10.0
"""Timeout waiting for daemon to become ready."""

QEMU_STORAGE_DAEMON_JOB_TIMEOUT_SECONDS: Final[float] = 30.0
"""Timeout waiting for async blockdev-create jobs to complete."""

# ============================================================================
# Port Forwarding
# ============================================================================

MAX_EXPOSED_PORTS: Final[int] = 10
"""Maximum number of ports that can be exposed per VM."""

PORT_FORWARD_MIN_HOST_PORT: Final[int] = 1024
"""Minimum host port for port forwarding (unprivileged ports only)."""

PORT_FORWARD_BIND_HOST: Final[str] = "127.0.0.1"
"""Host address to bind forwarded ports to (localhost only for security)."""

GVPROXY_API_TIMEOUT_SECONDS: Final[float] = 5.0
"""Timeout for gvproxy HTTP API requests (port forward expose/unexpose)."""

# ============================================================================
# File Transfer Streaming
# ============================================================================

FILE_TRANSFER_CHUNK_SIZE: Final[int] = 128 * 1024  # 128KB
"""Raw chunk size for streaming file transfers (before zstd compression).

128KB balances fewer frames (halves syscalls, JSON parses, base64 en/decodes
vs 64KB) while staying within virtio queue depth (128-256 descriptors).
On-wire size after base64+JSON is ~175KB per frame.
"""

FILE_TRANSFER_ZSTD_LEVEL: Final[int] = 3
"""Zstd compression level for file transfers (1=fast, 22=max; 3=good balance)."""

# ============================================================================
# Resource Admission & Overcommit
# ============================================================================

DEFAULT_MEMORY_OVERCOMMIT_RATIO: Final[float] = 1.5
"""Host-level memory overcommit multiplier applied to the total VM pool budget.

budget = host_total * (1 - reserve_ratio) * overcommit_ratio

This stretches the pool beyond physical capacity — safe because AI agent workloads
are bursty and mostly idle (avg memory utilization 18-22%).
Not to be confused with DEFAULT_VM_MEMORY_OVERHEAD_MB which is a per-VM additive
constant for QEMU/gvproxy process memory."""

DEFAULT_CPU_OVERCOMMIT_RATIO: Final[float] = 4.0
"""Host-level CPU overcommit multiplier applied to the total VM pool budget.

budget = (host_cpus - reserve_cores) * overcommit_ratio

AI workloads average 11-17% CPU utilization, so 4x overcommit is safe.
Not to be confused with DEFAULT_VM_CPU_OVERHEAD_CORES which is a per-VM additive
constant for QEMU/gvproxy process CPU."""

DEFAULT_HOST_MEMORY_RESERVE_RATIO: Final[float] = 0.1
"""Fraction of host memory reserved for OS and non-VM processes.
Scales with host size:
- 4GB host  → 400MB reserved  → 3.6GB for VMs
- 16GB host → 1.6GB reserved  → 14.4GB for VMs
- 64GB host → 6.4GB reserved  → 57.6GB for VMs"""

DEFAULT_HOST_CPU_RESERVE_CORES: Final[float] = 0.5
"""CPU cores reserved for host processes (OS, Python scheduler, qemu-storage-daemon).
Fixed value, not a ratio — host infrastructure has roughly constant CPU consumption
regardless of host size. 0.5 cores covers typical observed usage with headroom."""

DEFAULT_VM_CPU_CORES: Final[int] = 1
"""CPU cores allocated per VM. Flows to three places:
- QEMU -smp (guest-visible vCPU count)
- cgroup cpu.max quota (host-side CPU time enforcement)
- Admission controller budget (capacity planning)"""

DEFAULT_VM_MEMORY_OVERHEAD_MB: Final[int] = 128
"""QEMU + gvproxy process memory overhead added to guest memory for admission and cgroup limits.

Covers host-side process memory beyond guest RAM (QEMU VMM + gvproxy share a
per-VM cgroup). Uses ``microvm`` (x86) / ``virt`` (ARM) machine types — minimal
device set (virtio-mmio only), comparable to Firecracker (<5 MiB VMM overhead).

Measured breakdown:
  - QEMU binary + heap + glib event loop : ~20-30 MB
  - virtio-mmio ring buffers             : ~1 MB per device
  - qcow2 block layer (L2 + refcount)    : ~5-10 MB
  - Miscellaneous (serial, monitor, etc.) : ~2-5 MB
  - QEMU subtotal (minus guest RAM)       : ~35-50 MB
  - gvproxy (Go binary, network proxy)    : ~15-30 MB
  - Combined total                        : ~50-80 MB

128 MB provides ~60% headroom above observed combined peak. If OOM-kills
are observed, bump this — but first verify with:
  ``ps -o rss= -p <qemu_pid>`` and ``ps -o rss= -p <gvproxy_pid>``."""

DEFAULT_VM_CPU_OVERHEAD_CORES: Final[float] = 0.25
"""QEMU + gvproxy CPU overhead added to guest CPU for admission and cgroup limits.

Measured breakdown:
  - QEMU main loop + event processing      : ~2-5% of a core
  - IOThread (block I/O completion)         : ~1-3% of a core
  - gvproxy (TLS termination, DNS filter)   : ~5-15% of a core under network load
  - Haltpoll idle overhead (KVM)            : ~5-10% of a core
  - Combined total                          : ~13-33% of a core

0.25 provides ~60% headroom above observed peak (matching memory margin philosophy).
Only applies when gvproxy is in the cgroup (networking enabled). Without gvproxy,
overhead is ~5-10%, but we use 0.25 uniformly for simplicity."""

DEFAULT_TCG_TB_CACHE_SIZE_MB: Final[int] = 256
"""TCG translation block cache size in MB (must match tb-size in qemu_cmd.py).

QEMU 5.0+ defaults to 1GB which causes OOM on CI runners with multiple VMs.
256MB balances cache hit rate and memory usage:
- 32MB (old default): ~15 TB flushes, slower but minimal memory
- 256MB (our choice): ~5 TB flushes, good balance for CI workloads
- 512MB: ~3 TB flushes, better perf but higher memory pressure
- 1GB (QEMU default): ~1 TB flush, best perf but OOM risk"""

RESOURCE_ADMISSION_TIMEOUT_SECONDS: Final[float] = 120.0
"""Timeout for resource admission acquire (seconds). Blocks waiting for
resources to become available, then raises VmCapacityError."""

GATE3_SELF_WAKE_INTERVAL_SECONDS: Final[float] = 10.0
"""Interval for Gate 3 self-wake timer (seconds). Periodically notifies
blocked waiters so they re-evaluate _can_admit with a fresh memory probe.
Closes the wakeup gap when external processes free memory but no local
release() triggers notify_all()."""
