# Okareo MCP Server

The Okareo MCP server exposes Okareo's evaluation capabilities as MCP tools, allowing AI coding assistants to create and manage scenarios, register models, run evaluations, and execute multi-turn simulations directly from your editor.

## Prerequisites

- An Okareo API key from [app.okareo.com](https://app.okareo.com)
- A copilot that supports MCP servers (Claude Code, Cursor, or VS Code)
- Python 3.10–3.12 (for local install modes)

---

## Quick Setup (Recommended)

The fastest way to get started. Run the setup command in your project directory:

```bash
uvx okareo-mcp-setup
```

The setup command will:
1. Prompt for your Okareo API key
2. Detect your copilot (Claude Code, Cursor)
3. Write the correct MCP server configuration into your copilot's config file

Then restart your copilot. Done.

> Already have `okareo-mcp` installed? You can also run `okareo-mcp-setup` directly.

---

## Mode 1: Developer Local Build (stdio)

For developers contributing to the okareo-mcp project. Code changes take effect on server restart without reinstalling.

### Step 1: Clone and Install

```bash
git clone https://github.com/okareo-ai/okareo-mcp-beta.git
cd okareo-mcp-beta
pip install -e .
```

### Step 2: Set Your API Key

```bash
export OKAREO_API_KEY="your-api-key"
```

### Step 3: Configure Your Copilot

#### Claude Code

Add to `.mcp.json` in your project root:

```json
{
  "mcpServers": {
    "okareo": {
      "command": "okareo-mcp",
      "env": {
        "OKAREO_API_KEY": "${OKAREO_API_KEY}"
      }
    }
  }
}
```

#### Cursor

Add to `.cursor/mcp.json`:

```json
{
  "mcpServers": {
    "okareo": {
      "command": "okareo-mcp"
    }
  }
}
```

Cursor inherits `OKAREO_API_KEY` from your shell environment.

### Step 4: Verify

Restart your copilot. The Okareo MCP tools should appear. Try asking it to list your scenarios.

**Note**: Code changes take effect immediately on server restart — no reinstall needed.

---

## Mode 2: PyPI Install (stdio)

For end users who want to use okareo-mcp without cloning the repo.

### Step 1: Set Your API Key

```bash
export OKAREO_API_KEY="your-api-key"
```

Add this to your `~/.zshrc` or `~/.bash_profile` for persistence.

### Step 2: Configure Your Copilot

#### Claude Code

Add to `.mcp.json`:

```json
{
  "mcpServers": {
    "okareo": {
      "command": "uvx",
      "args": ["okareo-mcp"],
      "env": {
        "OKAREO_API_KEY": "${OKAREO_API_KEY}"
      }
    }
  }
}
```

No pre-install needed — `uvx` handles it automatically.

#### Cursor

Add to `.cursor/mcp.json`:

```json
{
  "mcpServers": {
    "okareo": {
      "command": "uvx",
      "args": ["okareo-mcp"]
    }
  }
}
```

Cursor inherits `OKAREO_API_KEY` from your shell environment.

#### Alternative: pip install

If you don't have `uv` installed:

```bash
pip install okareo-mcp
```

Then use `"command": "okareo-mcp"` instead of `"command": "uvx"`.

### Step 3: Verify

Restart your copilot. The Okareo MCP tools should appear.

---

## Mode 3: Enterprise Docker/SSE

For organizations that need centralized deployment with a shared API key.

### Step 1: Set Your API Key

```bash
export OKAREO_API_KEY="your-org-api-key"
```

### Step 2: Start the Container

```bash
docker compose up --build
```

The server starts on `http://localhost:8000` using SSE transport.

Optional: customize the port:

```bash
PORT=9000 docker compose up --build
```

### Step 3: Configure Developer Copilots

Distribute this configuration to developers in the organization:

#### Claude Code

```json
{
  "mcpServers": {
    "okareo": {
      "url": "http://your-mcp-server:8000/sse"
    }
  }
}
```

#### Cursor

```json
{
  "mcpServers": {
    "okareo": {
      "url": "http://your-mcp-server:8000/sse"
    }
  }
}
```

### Step 4: Verify

```bash
curl -s http://localhost:8000/sse
# Should see an open SSE stream
```

---

## Configuration Reference

| Variable | Default | Description |
|----------|---------|-------------|
| `OKAREO_API_KEY` | *(required)* | Your Okareo API key |
| `OKAREO_BASE_URL` | `https://api.okareo.com` | Override for on-prem Okareo backend |
| `TRANSPORT` | `stdio` | Transport: `stdio` (local) or `sse` (Docker) |
| `PORT` | `8000` | Port for SSE transport |

---

## Available Tools

### Scenarios

| Tool | Description |
|------|-------------|
| `save_scenario` | Create a named scenario from rows of input/result data (idempotent) |
| `list_scenarios` | List all scenarios in the project with names, IDs, and row counts |
| `get_scenario` | Retrieve a scenario's metadata and all data rows by name or ID |
| `create_scenario_version` | Create a new version of an existing scenario (auto-increments version number) |
| `preview_delete_scenario` | Preview what will be deleted before removing a scenario |
| `delete_scenario` | Permanently delete a scenario and all related test data |

### Models

| Tool | Description |
|------|-------------|
| `list_available_models` | Browse available target models from the Okareo registry |
| `register_model` | Register a model for testing by selecting a target model from the registry |
| `list_models` | List all registered models in the project |
| `get_model` | Read detailed information about a registered model |
| `update_model` | Change the target model a registered model points to |
| `delete_model` | Remove a registered model and all its related test data |

### Tests & Evaluations

| Tool | Description |
|------|-------------|
| `list_checks` | List available quality checks (built-in and custom) for evaluating model outputs |
| `run_test` | Run an evaluation test against a model with specified checks and scenario |
| `list_test_runs` | List recent test runs with optional filters (model, scenario, simulation-only) |
| `get_test_run_results` | Load detailed per-row results of a test run or simulation by ID or name |

### Simulations (Multi-Turn)

| Tool | Description |
|------|-------------|
| `create_target` | Create or update a Target — prompt (foundation model) or custom endpoint (your REST API) |
| `get_target` | Retrieve a prompt target's configuration by name |
| `create_driver` | Create or update a Driver persona that simulates user behavior |
| `get_driver` | Retrieve a driver persona's configuration by name |
| `list_drivers` | List all driver personas in the project |
| `run_simulation` | Run a multi-turn conversation simulation (or rerun a previous one with overrides) |

### Documentation & Templates

| Tool | Description |
|------|-------------|
| `get_docs` | Query the Okareo documentation RAG system for conceptual or user-legible explanations |
| `get_templates` | Retrieve prompt templates for common Okareo patterns (works offline) |

---

## Troubleshooting

| Symptom | Cause | Fix |
|---------|-------|-----|
| `okareo-mcp: command not found` | Not installed or not in PATH | Run `pip install -e .` (dev) or use `uvx okareo-mcp` (user) |
| Server exits with API key error | `OKAREO_API_KEY` not set | Export it: `export OKAREO_API_KEY="..."` |
| `pip install` fails on Python 3.13+ | Okareo SDK requires Python <3.13 | Use Python 3.10–3.12 |
| Copilot can't connect (Docker) | Wrong URL | Ensure URL ends with `/sse` and port matches |
| Cursor doesn't pick up API key | Cursor launched from Dock, not terminal | Launch Cursor from terminal: `cursor .` |
