"""Okareo SDK wrapper: client initialization and project resolution."""

import os

from okareo import Okareo

# Session-level cache for project ID, keyed by okareo instance id
_project_id_cache: dict[int, str] = {}


def create_okareo_client(api_key: str, base_url: str | None = None) -> Okareo:
    """Create an Okareo client with the given API key.

    The Okareo constructor validates the key by calling GET /v0/projects.

    Args:
        api_key: Okareo API key.
        base_url: Optional base URL for the Okareo API.

    Returns:
        An authenticated Okareo client instance.

    Raises:
        TypeError: If the API key is invalid (API returns 401).
    """
    if base_url:
        return Okareo(api_key=api_key, base_path=base_url)
    return Okareo(api_key=api_key)


def get_okareo_client() -> Okareo:
    """Create an Okareo client from environment variables.

    Reads OKAREO_API_KEY and optional OKAREO_BASE_URL from the environment.

    Returns:
        An authenticated Okareo client instance.

    Raises:
        ValueError: If OKAREO_API_KEY is not set or empty.
    """
    api_key = os.environ.get("OKAREO_API_KEY", "").strip()
    if not api_key:
        raise ValueError(
            "OKAREO_API_KEY environment variable is not set. "
            "Set it to your Okareo API key to use the MCP server."
        )
    base_url = os.environ.get("OKAREO_BASE_URL")
    return create_okareo_client(api_key, base_url)


def resolve_project_id(okareo: Okareo) -> str:
    """Resolve the 'Global' project ID from the user's Okareo account.

    Caches the result per Okareo instance for the session lifetime.

    Args:
        okareo: An authenticated Okareo client.

    Returns:
        The project ID string for the 'Global' project.

    Raises:
        ValueError: If no project named 'Global' is found.
    """
    cache_key = id(okareo)
    if cache_key in _project_id_cache:
        return _project_id_cache[cache_key]

    projects = okareo.get_projects()
    for project in projects:
        if project.name == "Global":
            _project_id_cache[cache_key] = project.id
            return project.id

    raise ValueError(
        "No project named 'Global' found in your Okareo account. "
        "Verify your project setup at app.okareo.com."
    )
