class DraculaException(Exception):
    """Base exception for Dracula library."""

    pass


class InvalidAPIKeyException(DraculaException):
    """Raised when the API key is missing or invalid."""

    pass


class ChatException(DraculaException):
    """Raised when something goes wrong during a chat request."""

    pass


class ValidationException(DraculaException):
    """Raised when an invalid value is passed to a parameter."""


class PersonaException(DraculaException):
    """Raised when an invalid persona is requested."""

    pass


class ToolException(DraculaException):
    """Raised when something goes wrong with a tool."""

    pass
