from enum import Enum


class GeminiModel(Enum):
    """
    Available Google Gemini models.

    Attributes:
        FLASH: Gemini 3.0 Flash — fast and efficient, great for most use cases.
        FLASH_LITE: Gemini 2.0 Flash Lite — lightweight version of Flash.
        PRO: Gemini 3.0 Pro — most powerful model, best for complex tasks.
        FLASH_THINKING: Gemini 2.0 Flash Thinking — great for reasoning tasks.

    Example:
        >>> from dracula import Dracula, GeminiModel
        >>> ai = Dracula(api_key="your-api-key", model=GeminiModel.PRO)
    """

    FLASH = "gemini-3-flash-preview"
    FLASH_LITE = "gemini-2.0-flash-lite"
    PRO = "gemini-3-pro-preview"
    FLASH_THINKING = "gemini-2.0-flash-thinking-exp"
