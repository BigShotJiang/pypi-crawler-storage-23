# Bundled frontend assets (IIFE + CSS) for offline HTML rendering.
