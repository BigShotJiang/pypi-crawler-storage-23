"""Compatibility bridge for ``briefcase_ai.semantic_conventions``."""

from briefcase_ai._compat import _bridge_module

_bridge_module(
    __name__,
    "briefcase.semantic_conventions",
    submodules=("lakefs", "workflow", "rag", "external_data", "validation"),
)
