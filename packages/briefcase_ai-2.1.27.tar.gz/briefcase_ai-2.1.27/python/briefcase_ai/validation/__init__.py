"""Compatibility bridge for ``briefcase_ai.validation``."""

from briefcase_ai._compat import _bridge_module

_bridge_module(
    __name__,
    "briefcase.validation",
    submodules=("engine", "errors", "extractors", "resolvers", "semantic"),
)
