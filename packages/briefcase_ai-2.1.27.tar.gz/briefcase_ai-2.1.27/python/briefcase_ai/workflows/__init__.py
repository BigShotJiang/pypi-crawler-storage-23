"""Compatibility bridge for ``briefcase_ai.workflows``."""

from briefcase_ai._compat import _bridge_module

_bridge_module(__name__, "briefcase.workflows", submodules=("broker_dealer_onboarding",))
