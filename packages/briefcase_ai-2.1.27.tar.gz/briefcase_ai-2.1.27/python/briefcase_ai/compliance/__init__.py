"""Compatibility bridge for ``briefcase_ai.compliance``."""

from briefcase_ai._compat import _bridge_module

_bridge_module(__name__, "briefcase.compliance", submodules=("reports",))
