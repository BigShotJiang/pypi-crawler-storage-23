"""
RAG (Retrieval-Augmented Generation) versioning components.
"""

from briefcase.rag.embedding_pipeline import (
    VersionedEmbeddingPipeline,
    Document,
    EmbeddingBatch,
    EmbeddingManifest,
    EmbeddingRecord,
    ManifestStatus,
    InvalidationReport,
)
from briefcase.rag.retrieval import InstrumentedRetriever, RetrievalResult

__all__ = [
    "VersionedEmbeddingPipeline",
    "Document",
    "EmbeddingBatch",
    "EmbeddingManifest",
    "EmbeddingRecord",
    "ManifestStatus",
    "InvalidationReport",
    "InstrumentedRetriever",
    "RetrievalResult",
]
