"""
Briefcase integrations with external systems.

Available integrations:
  - vcs: Multi-provider VCS integration (DVC, Nessie, Pachyderm, ArtiVC, DuckLake, Iceberg, Git LFS)
  - lakefs: lakeFS integration for data versioning
  - frameworks: Framework-specific handlers (LangChain, LlamaIndex)
"""
