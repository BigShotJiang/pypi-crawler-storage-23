"""Nessie integration for Briefcase."""

from briefcase.integrations.vcs.nessie.client import NessieClient

__all__ = ["NessieClient"]
