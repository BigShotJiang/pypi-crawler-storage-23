"""ArtiVC integration for Briefcase."""

from briefcase.integrations.vcs.artivc.client import ArtiVCClient

__all__ = ["ArtiVCClient"]
