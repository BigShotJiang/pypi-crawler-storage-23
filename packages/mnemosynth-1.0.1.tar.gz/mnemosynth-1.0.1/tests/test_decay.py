"""Tests for the Ebbinghaus decay engine."""

from datetime import datetime, timezone, timedelta
from mnemosynth.core.types import MemoryNode, MemoryType
from mnemosynth.core.config import MnemosynthConfig, DecayConfig


class TestDecayEngine:
    def setup_method(self):
        from mnemosynth.engine.decay import DecayEngine
        self.config = MnemosynthConfig(data_dir="/tmp/mnemosynth_test")
        self.config.decay = DecayConfig(enabled=True, half_life_days=30, min_confidence=0.1)
        self.engine = DecayEngine(self.config)

    def test_fresh_memory_no_decay(self):
        node = MemoryNode.create(content="Fresh memory")
        decay = self.engine.compute_decay(node)
        assert decay > 0.99  # Nearly 1.0 for just-created memory

    def test_old_memory_decays(self):
        node = MemoryNode.create(content="Old memory")
        node.last_accessed = datetime.now(timezone.utc) - timedelta(days=60)
        decay = self.engine.compute_decay(node)
        assert decay < 0.5  # Should have decayed significantly

    def test_accessed_memory_decays_slower(self):
        node1 = MemoryNode.create(content="Rarely accessed")
        node1.access_count = 0
        node1.last_accessed = datetime.now(timezone.utc) - timedelta(days=30)

        node2 = MemoryNode.create(content="Frequently accessed")
        node2.access_count = 10
        node2.last_accessed = datetime.now(timezone.utc) - timedelta(days=30)

        decay1 = self.engine.compute_decay(node1)
        decay2 = self.engine.compute_decay(node2)
        assert decay2 > decay1  # More access = slower decay

    def test_disabled_decay(self):
        self.config.decay.enabled = False
        from mnemosynth.engine.decay import DecayEngine
        engine = DecayEngine(self.config)

        node = MemoryNode.create(content="Test")
        node.last_accessed = datetime.now(timezone.utc) - timedelta(days=365)
        assert engine.compute_decay(node) == 1.0

    def test_should_archive(self):
        node = MemoryNode.create(content="Very old")
        node.last_accessed = datetime.now(timezone.utc) - timedelta(days=1000)
        node.access_count = 0
        assert self.engine.should_archive(node)

    def test_final_score(self):
        node = MemoryNode.create(content="Test", confidence=0.9)
        node.corroboration_count = 2
        score = self.engine.compute_final_score(node, similarity=0.8)
        assert 0 < score <= 1.0
