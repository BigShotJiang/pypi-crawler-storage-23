"""
Tests for MNEMOSYNTH Agentic Framework Adapters.

These tests mock the Mnemosynth core to verify adapter behavior
without requiring actual framework dependencies.
"""

from __future__ import annotations

import pytest
from unittest.mock import MagicMock, patch
from dataclasses import dataclass
from datetime import datetime, timezone


# ---------------------------------------------------------------------------
# Mock MemoryNode for tests
# ---------------------------------------------------------------------------

@dataclass
class MockMemoryNode:
    id: str = "test-id-123"
    content: str = "User prefers dark mode"
    memory_type: MagicMock = None
    confidence: float = 0.85
    created_at: datetime = None
    last_accessed: datetime = None
    access_count: int = 0
    tags: list = None

    def __post_init__(self):
        if self.memory_type is None:
            self.memory_type = MagicMock()
            self.memory_type.value = "semantic"
        if self.created_at is None:
            self.created_at = datetime.now(timezone.utc)
        if self.last_accessed is None:
            self.last_accessed = datetime.now(timezone.utc)
        if self.tags is None:
            self.tags = []


def _make_mock_brain():
    """Create a mock Mnemosynth instance."""
    brain = MagicMock()

    # remember returns a MemoryNode
    brain.remember.return_value = MockMemoryNode(
        content="User prefers TypeScript and dark mode"
    )

    # recall returns a list of MemoryNodes
    brain.recall.return_value = [
        MockMemoryNode(content="User prefers dark mode", confidence=0.92),
        MockMemoryNode(content="Project uses TypeScript", confidence=0.88),
    ]

    # digest returns a string
    brain.digest.return_value = (
        "<memory_digest>"
        "<memory>User prefers dark mode</memory>"
        "</memory_digest>"
    )

    # dream returns a dict
    brain.dream.return_value = {
        "promoted": 3,
        "contradictions_resolved": 1,
        "decayed": 2,
    }

    # stats returns a dict
    brain.stats.return_value = {
        "total": 42,
        "episodic": 20,
        "semantic": 15,
        "procedural": 7,
    }

    # forget returns True
    brain.forget.return_value = True

    # db mock for MemoryBus
    brain.db = MagicMock()
    brain.db.save_memory.return_value = None

    return brain


# ===========================================================================
# CrewAI Adapter Tests
# ===========================================================================

class TestCrewAIAdapter:
    """Test the CrewAI adapter tools."""

    def test_remember_tool(self):
        from mnemosynth.adapters.crewai import MnemosynthRememberTool

        brain = _make_mock_brain()
        tool = MnemosynthRememberTool(brain=brain)

        result = tool.run("User prefers dark mode")
        assert "Stored" in result
        assert "semantic" in result
        brain.remember.assert_called_once_with("User prefers dark mode")

    def test_recall_tool(self):
        from mnemosynth.adapters.crewai import MnemosynthRecallTool

        brain = _make_mock_brain()
        tool = MnemosynthRecallTool(brain=brain)

        result = tool.run("user preferences")
        assert "dark mode" in result
        assert "TypeScript" in result
        brain.recall.assert_called_once_with("user preferences", limit=5)

    def test_recall_no_results(self):
        from mnemosynth.adapters.crewai import MnemosynthRecallTool

        brain = _make_mock_brain()
        brain.recall.return_value = []
        tool = MnemosynthRecallTool(brain=brain)

        result = tool.run("unknown topic")
        assert "No relevant memories found" in result

    def test_digest_tool(self):
        from mnemosynth.adapters.crewai import MnemosynthDigestTool

        brain = _make_mock_brain()
        tool = MnemosynthDigestTool(brain=brain)

        result = tool.run("project setup")
        assert "memory_digest" in result
        brain.digest.assert_called_once_with("project setup")

    def test_get_crewai_tools(self):
        from mnemosynth.adapters.crewai import get_crewai_tools

        brain = _make_mock_brain()
        tools = get_crewai_tools(brain=brain)

        assert len(tools) == 3
        assert tools[0].name == "mnemosynth_remember"
        assert tools[1].name == "mnemosynth_recall"
        assert tools[2].name == "mnemosynth_digest"


# ===========================================================================
# LangChain Adapter Tests
# ===========================================================================

class TestLangChainAdapter:
    """Test the LangChain adapter tools and memory class."""

    def test_get_mnemosynth_tools(self):
        from mnemosynth.adapters.langchain import get_mnemosynth_tools

        brain = _make_mock_brain()
        tools = get_mnemosynth_tools(brain=brain)

        assert len(tools) == 3
        assert callable(tools[0])
        assert callable(tools[1])
        assert callable(tools[2])

    def test_remember_tool_function(self):
        from mnemosynth.adapters.langchain import get_mnemosynth_tools

        brain = _make_mock_brain()
        tools = get_mnemosynth_tools(brain=brain)
        remember_fn = tools[0]

        result = remember_fn("User prefers Python")
        assert "Stored" in result
        brain.remember.assert_called_once()

    def test_recall_tool_function(self):
        from mnemosynth.adapters.langchain import get_mnemosynth_tools

        brain = _make_mock_brain()
        tools = get_mnemosynth_tools(brain=brain)
        recall_fn = tools[1]

        result = recall_fn("user preferences")
        assert "dark mode" in result
        brain.recall.assert_called_once()

    def test_digest_tool_function(self):
        from mnemosynth.adapters.langchain import get_mnemosynth_tools

        brain = _make_mock_brain()
        tools = get_mnemosynth_tools(brain=brain)
        digest_fn = tools[2]

        result = digest_fn("project setup")
        assert "memory_digest" in result

    def test_memory_class_load(self):
        from mnemosynth.adapters.langchain import MnemosynthMemory

        brain = _make_mock_brain()
        memory = MnemosynthMemory(brain=brain)

        variables = memory.load_memory_variables({"input": "hello"})
        assert "memory_context" in variables
        assert "memory_digest" in variables["memory_context"]

    def test_memory_class_save(self):
        from mnemosynth.adapters.langchain import MnemosynthMemory

        brain = _make_mock_brain()
        memory = MnemosynthMemory(brain=brain)

        memory.save_context(
            {"input": "What is Python?"},
            {"output": "Python is a programming language."},
        )
        brain.remember.assert_called_once()

    def test_memory_variables_property(self):
        from mnemosynth.adapters.langchain import MnemosynthMemory

        memory = MnemosynthMemory(brain=_make_mock_brain())
        assert memory.memory_variables == ["memory_context"]


# ===========================================================================
# Memory Bus Tests
# ===========================================================================

class TestMemoryBus:
    """Test the cross-agent Memory Bus."""

    def test_remember_with_namespace(self):
        from mnemosynth.adapters.memory_bus import MemoryBus

        brain = _make_mock_brain()
        # Make remember return a node with mutable tags
        node = MockMemoryNode(tags=[])
        brain.remember.return_value = node

        bus = MemoryBus(brain=brain)
        result = bus.remember("test fact", namespace="researcher")

        brain.remember.assert_called_once_with("test fact", memory_type="auto")
        assert "ns:researcher" in node.tags
        assert "researcher" in bus.get_namespaces()

    def test_recall_all_namespaces(self):
        from mnemosynth.adapters.memory_bus import MemoryBus

        brain = _make_mock_brain()
        bus = MemoryBus(brain=brain)

        results = bus.recall("user preferences", namespace="*")
        assert len(results) == 2
        brain.recall.assert_called_once()

    def test_recall_specific_namespace(self):
        from mnemosynth.adapters.memory_bus import MemoryBus

        brain = _make_mock_brain()
        # Tag one result with the namespace
        tagged_node = MockMemoryNode(
            content="Tagged memory",
            tags=["ns:coder"],
        )
        brain.recall.return_value = [
            tagged_node,
            MockMemoryNode(content="Untagged memory", tags=[]),
        ]

        bus = MemoryBus(brain=brain)
        results = bus.recall("test", namespace="coder")

        assert len(results) == 1
        assert results[0].content == "Tagged memory"

    def test_digest_all_namespaces(self):
        from mnemosynth.adapters.memory_bus import MemoryBus

        brain = _make_mock_brain()
        bus = MemoryBus(brain=brain)

        digest = bus.digest("test query", namespace="*")
        assert "memory_digest" in digest

    def test_digest_specific_namespace(self):
        from mnemosynth.adapters.memory_bus import MemoryBus

        brain = _make_mock_brain()
        tagged = MockMemoryNode(content="Scoped memory", tags=["ns:agent1"])
        brain.recall.return_value = [tagged]

        bus = MemoryBus(brain=brain)
        digest = bus.digest("test", namespace="agent1")

        assert 'namespace="agent1"' in digest
        assert "Scoped memory" in digest

    def test_get_namespaces(self):
        from mnemosynth.adapters.memory_bus import MemoryBus

        brain = _make_mock_brain()
        brain.remember.return_value = MockMemoryNode(tags=[])

        bus = MemoryBus(brain=brain)
        bus.remember("fact 1", namespace="alpha")
        bus.remember("fact 2", namespace="beta")

        namespaces = bus.get_namespaces()
        assert namespaces == ["alpha", "beta"]

    def test_create_agent_memory(self):
        from mnemosynth.adapters.memory_bus import create_agent_memory

        brain = _make_mock_brain()
        brain.remember.return_value = MockMemoryNode(tags=[])

        with patch("mnemosynth.adapters.memory_bus.Mnemosynth", return_value=brain):
            tools = create_agent_memory("researcher", brain=brain)

        assert "remember" in tools
        assert "recall" in tools
        assert "recall_all" in tools
        assert "digest" in tools
        assert "bus" in tools


# ===========================================================================
# AutoGen Adapter Tests
# ===========================================================================

class TestAutoGenAdapter:
    """Test the AutoGen adapter helpers."""

    def test_get_autogen_tools(self):
        from mnemosynth.adapters.autogen import get_autogen_tools

        brain = _make_mock_brain()
        tools = get_autogen_tools(brain=brain)

        assert len(tools) == 3
        assert callable(tools[0])
        assert callable(tools[1])
        assert callable(tools[2])

    def test_autogen_remember_tool(self):
        from mnemosynth.adapters.autogen import get_autogen_tools

        brain = _make_mock_brain()
        tools = get_autogen_tools(brain=brain)
        remember_fn = tools[0]

        result = remember_fn("test fact")
        assert "Stored" in result
        brain.remember.assert_called_once_with("test fact")

    def test_autogen_recall_tool(self):
        from mnemosynth.adapters.autogen import get_autogen_tools

        brain = _make_mock_brain()
        tools = get_autogen_tools(brain=brain)
        recall_fn = tools[1]

        result = recall_fn("test query")
        assert "dark mode" in result


# ===========================================================================
# Import Smoke Tests
# ===========================================================================

class TestAdapterImports:
    """Verify all adapter modules import cleanly without framework deps."""

    def test_import_init(self):
        import mnemosynth.adapters
        assert hasattr(mnemosynth.adapters, "__all__")

    def test_import_crewai(self):
        from mnemosynth.adapters.crewai import (
            MnemosynthRememberTool,
            MnemosynthRecallTool,
            MnemosynthDigestTool,
            get_crewai_tools,
        )

    def test_import_langchain(self):
        from mnemosynth.adapters.langchain import (
            get_mnemosynth_tools,
            MnemosynthMemory,
        )

    def test_import_autogen(self):
        from mnemosynth.adapters.autogen import get_autogen_tools

    def test_import_memory_bus(self):
        from mnemosynth.adapters.memory_bus import (
            MemoryBus,
            create_agent_memory,
        )
