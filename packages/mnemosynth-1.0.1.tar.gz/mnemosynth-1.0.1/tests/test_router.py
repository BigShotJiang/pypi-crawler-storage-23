"""Tests for the memory router — classification into episodic/semantic/procedural."""

from mnemosynth.engine.router import MemoryRouter
from mnemosynth.core.types import MemoryType


class TestMemoryRouter:
    def setup_method(self):
        self.router = MemoryRouter()

    def test_semantic_classification(self):
        result = self.router.classify("User prefers Python and dark mode")
        assert result == MemoryType.SEMANTIC

    def test_episodic_classification(self):
        result = self.router.classify("Yesterday we discussed the auth module bugs")
        assert result == MemoryType.EPISODIC

    def test_procedural_classification(self):
        result = self.router.classify("How to install: pip install mnemosynth && mnemosynth serve")
        assert result == MemoryType.PROCEDURAL

    def test_code_is_procedural(self):
        result = self.router.classify("```python\ndef hello():\n    print('hi')\n```")
        assert result == MemoryType.PROCEDURAL

    def test_fact_is_semantic(self):
        result = self.router.classify("The user is a software engineer")
        assert result == MemoryType.SEMANTIC

    def test_event_is_episodic(self):
        result = self.router.classify("Last week we had a meeting about the roadmap")
        assert result == MemoryType.EPISODIC

    def test_classify_with_confidence(self):
        mem_type, confidence = self.router.classify_with_confidence(
            "User always prefers TypeScript for frontend projects"
        )
        assert mem_type == MemoryType.SEMANTIC
        assert 0.0 < confidence <= 1.0
