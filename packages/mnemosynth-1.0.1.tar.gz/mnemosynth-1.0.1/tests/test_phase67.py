"""
Tests for Phase 6 (Production DB Stores) and Phase 7 (A2A Protocol + Telemetry).

Uses mocks to avoid requiring Qdrant, FalkorDB, or PostgreSQL at test time.
"""

from __future__ import annotations

import json
import pytest
from unittest.mock import MagicMock, patch
from dataclasses import dataclass
from datetime import datetime, timezone


# ---------------------------------------------------------------------------
# Mock MemoryNode
# ---------------------------------------------------------------------------

@dataclass
class MockMemoryNode:
    id: str = "test-id-123"
    content: str = "Test memory content"
    memory_type: MagicMock = None
    status: MagicMock = None
    confidence: float = 0.85
    sentiment_score: float = 0.0
    created_at: datetime = None
    last_accessed: datetime = None
    access_count: int = 0
    tags: list = None
    embedding: list = None
    supersedes: str = None
    superseded_by: str = None

    def __post_init__(self):
        if self.memory_type is None:
            self.memory_type = MagicMock()
            self.memory_type.value = "semantic"
        if self.status is None:
            self.status = MagicMock()
            self.status.value = "active"
        if self.created_at is None:
            self.created_at = datetime.now(timezone.utc)
        if self.last_accessed is None:
            self.last_accessed = datetime.now(timezone.utc)
        if self.tags is None:
            self.tags = []

    def to_dict(self):
        return {"id": self.id, "content": self.content}


def _make_mock_brain():
    brain = MagicMock()
    brain.remember.return_value = MockMemoryNode(tags=[])
    brain.recall.return_value = [
        MockMemoryNode(content="Memory 1", confidence=0.9),
        MockMemoryNode(content="Memory 2", confidence=0.8),
    ]
    brain.digest.return_value = "<digest>test</digest>"
    brain.db = MagicMock()
    return brain


# ===========================================================================
# Phase 6: Production Store Import Tests
# ===========================================================================

class TestProductionStoreImports:
    """Verify production stores import without needing actual DB clients."""

    def test_import_qdrant_store(self):
        from mnemosynth.stores.qdrant_store import QdrantEpisodicStore
        assert QdrantEpisodicStore is not None

    def test_import_falkordb_store(self):
        from mnemosynth.stores.falkordb_store import FalkorDBSemanticStore
        assert FalkorDBSemanticStore is not None

    def test_import_postgres_store(self):
        from mnemosynth.stores.postgres_store import PostgresStore
        assert PostgresStore is not None


class TestQdrantStore:
    """Test Qdrant store (mocked client)."""

    def test_init_defaults(self):
        from mnemosynth.stores.qdrant_store import QdrantEpisodicStore
        store = QdrantEpisodicStore()
        assert store.url == "http://localhost:6333"
        assert store.collection_name == "mnemosynth_episodic"
        assert store.embedding_dim == 384

    def test_lazy_client_init(self):
        from mnemosynth.stores.qdrant_store import QdrantEpisodicStore
        store = QdrantEpisodicStore()
        assert store._client is None  # Not initialized yet

    def test_add_requires_embedding(self):
        from mnemosynth.stores.qdrant_store import QdrantEpisodicStore
        store = QdrantEpisodicStore()
        node = MockMemoryNode(embedding=None)
        # add() should fail without an embedding when actually called
        # but since client is lazy, we test the attribute exists
        assert store.embedding_dim == 384


class TestFalkorDBStore:
    """Test FalkorDB store (mocked client)."""

    def test_init_defaults(self):
        from mnemosynth.stores.falkordb_store import FalkorDBSemanticStore
        store = FalkorDBSemanticStore()
        assert store.host == "localhost"
        assert store.port == 6379
        assert store.graph_name == "mnemosynth_kg"

    def test_lazy_graph_init(self):
        from mnemosynth.stores.falkordb_store import FalkorDBSemanticStore
        store = FalkorDBSemanticStore()
        assert store._graph is None


class TestPostgresStore:
    """Test PostgreSQL store (mocked connection)."""

    def test_init_defaults(self):
        from mnemosynth.stores.postgres_store import PostgresStore
        store = PostgresStore()
        assert "postgresql" in store.dsn
        assert store.pool_size == 5

    def test_lazy_pool_init(self):
        from mnemosynth.stores.postgres_store import PostgresStore
        store = PostgresStore()
        assert store._pool is None

    def test_schema_sql_exists(self):
        from mnemosynth.stores.postgres_store import CREATE_TABLES_SQL
        assert "CREATE TABLE IF NOT EXISTS memories" in CREATE_TABLES_SQL
        assert "CREATE TABLE IF NOT EXISTS causal_chains" in CREATE_TABLES_SQL
        assert "CREATE TABLE IF NOT EXISTS dream_logs" in CREATE_TABLES_SQL


# ===========================================================================
# Phase 7: A2A Protocol Tests
# ===========================================================================

class TestA2AProtocol:
    """Test the Agent-to-Agent protocol."""

    def test_register_agent(self):
        from mnemosynth.a2a import A2AProtocol
        proto = A2AProtocol()

        info = proto.register_agent(
            "researcher",
            capabilities=["search", "analyze"],
        )
        assert info["id"] == "researcher"
        assert "search" in info["capabilities"]

    def test_get_agents(self):
        from mnemosynth.a2a import A2AProtocol
        proto = A2AProtocol()
        proto.register_agent("agent-1")
        proto.register_agent("agent-2")

        agents = proto.get_agents()
        assert len(agents) == 2

    def test_handle_request(self):
        from mnemosynth.a2a import A2AProtocol, MemoryRequest

        brain = _make_mock_brain()
        proto = A2AProtocol(brain=brain)

        request = MemoryRequest(
            agent_id="researcher",
            query="user preferences",
            limit=3,
        )
        response = proto.handle_request(request)

        assert response.total_found == 2
        assert len(response.memories) == 2
        brain.recall.assert_called_once()

    def test_share_memory(self):
        from mnemosynth.a2a import A2AProtocol

        brain = _make_mock_brain()
        proto = A2AProtocol(brain=brain)

        node = proto.share_memory(
            content="User prefers dark mode",
            source_agent="coder-agent",
            visibility="shared",
        )
        assert node is not None
        brain.remember.assert_called_once()

    def test_heartbeat(self):
        from mnemosynth.a2a import A2AProtocol
        proto = A2AProtocol()
        proto.register_agent("agent-1")

        msg = proto.heartbeat("agent-1")
        assert msg.type.value == "heartbeat"
        assert msg.sender == "agent-1"

    def test_message_log(self):
        from mnemosynth.a2a import A2AProtocol
        proto = A2AProtocol()
        proto.heartbeat("agent-1")
        proto.heartbeat("agent-2")

        log = proto.get_message_log()
        assert len(log) == 2

    def test_a2a_message_serialization(self):
        from mnemosynth.a2a import A2AMessage, A2AMessageType
        msg = A2AMessage(
            type=A2AMessageType.MEMORY_SHARE,
            sender="test-agent",
            payload={"key": "value"},
        )
        json_str = msg.to_json()
        restored = A2AMessage.from_json(json_str)

        assert restored.sender == "test-agent"
        assert restored.type == A2AMessageType.MEMORY_SHARE
        assert restored.payload["key"] == "value"

    def test_handle_request_no_brain(self):
        from mnemosynth.a2a import A2AProtocol, MemoryRequest
        proto = A2AProtocol(brain=None)

        request = MemoryRequest(agent_id="test", query="anything")
        response = proto.handle_request(request)
        assert response.total_found == 0


# ===========================================================================
# Phase 7: Telemetry Tests
# ===========================================================================

class TestTelemetry:
    """Test the OpenTelemetry integration."""

    def test_metrics_increment(self):
        from mnemosynth.telemetry import MnemosynthMetrics
        metrics = MnemosynthMetrics()

        metrics.increment("remember_total")
        metrics.increment("remember_total")
        assert metrics._counters["remember_total"] == 2

    def test_metrics_duration(self):
        from mnemosynth.telemetry import MnemosynthMetrics
        metrics = MnemosynthMetrics()

        metrics.record_duration("remember", 15.5)
        metrics.record_duration("remember", 20.3)

        stats = metrics.get_stats()
        assert stats["remember_duration_ms_avg"] == 17.9

    def test_metrics_get_stats(self):
        from mnemosynth.telemetry import MnemosynthMetrics
        metrics = MnemosynthMetrics()
        stats = metrics.get_stats()

        assert "remember_total" in stats
        assert "recall_total" in stats
        assert "digest_total" in stats

    def test_traced_decorator(self):
        from mnemosynth.telemetry import traced

        @traced("test_op")
        def sample_func(x):
            return x * 2

        result = sample_func(5)
        assert result == 10

    def test_instrument_brain(self):
        from mnemosynth.telemetry import instrument_brain

        brain = _make_mock_brain()
        instrument_brain(brain)

        # Methods should still work after instrumentation
        brain.remember("test")
        brain.recall("test")

    def test_get_metrics(self):
        from mnemosynth.telemetry import get_metrics
        stats = get_metrics()
        assert isinstance(stats, dict)

    def test_noop_tracer(self):
        from mnemosynth.telemetry import _NoOpTracer, _NoOpSpan
        tracer = _NoOpTracer()
        span = tracer.start_as_current_span("test")
        assert isinstance(span, _NoOpSpan)

    def test_noop_span_context_manager(self):
        from mnemosynth.telemetry import _NoOpSpan
        span = _NoOpSpan()
        with span:
            span.set_attribute("key", "value")
            span.set_status("ok")
        # Should not raise


# ===========================================================================
# Import Smoke Tests
# ===========================================================================

class TestPhase67Imports:
    """Verify all Phase 6 & 7 modules import cleanly."""

    def test_import_a2a(self):
        from mnemosynth.a2a import A2AProtocol, A2AMessage, MemoryRequest, MemoryResponse

    def test_import_telemetry(self):
        from mnemosynth.telemetry import (
            instrument_brain,
            TracedMnemosynth,
            MnemosynthMetrics,
            get_metrics,
            traced,
        )

    def test_import_qdrant(self):
        from mnemosynth.stores.qdrant_store import QdrantEpisodicStore

    def test_import_falkordb(self):
        from mnemosynth.stores.falkordb_store import FalkorDBSemanticStore

    def test_import_postgres(self):
        from mnemosynth.stores.postgres_store import PostgresStore
