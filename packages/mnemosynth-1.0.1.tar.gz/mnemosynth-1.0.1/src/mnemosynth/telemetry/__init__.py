"""
MNEMOSYNTH OpenTelemetry Integration.

Adds observability to memory operations with structured tracing,
metrics, and logging via the OpenTelemetry standard.

Usage:
    from mnemosynth.telemetry import instrument_brain

    brain = Mnemosynth()
    instrument_brain(brain)  # Now all operations emit traces/metrics

    # Or use the traced wrapper directly:
    from mnemosynth.telemetry import TracedMnemosynth
    brain = TracedMnemosynth()

Requires: pip install opentelemetry-api opentelemetry-sdk
"""

from __future__ import annotations

import time
import functools
from typing import Any, Callable

from mnemosynth.core.types import MemoryNode


# ---------------------------------------------------------------------------
# Tracer stub (works without OpenTelemetry installed)
# ---------------------------------------------------------------------------

class _NoOpSpan:
    """No-op span when OpenTelemetry is not installed."""
    def set_attribute(self, key: str, value: Any) -> None:
        pass

    def set_status(self, status: Any) -> None:
        pass

    def record_exception(self, exc: Exception) -> None:
        pass

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass


class _NoOpTracer:
    """No-op tracer when OpenTelemetry is not installed."""
    def start_as_current_span(self, name: str, **kwargs) -> _NoOpSpan:
        return _NoOpSpan()


def _get_tracer(name: str = "mnemosynth"):
    """Get an OpenTelemetry tracer, or a no-op fallback."""
    try:
        from opentelemetry import trace
        return trace.get_tracer(name)
    except ImportError:
        return _NoOpTracer()


# ---------------------------------------------------------------------------
# Metrics
# ---------------------------------------------------------------------------

class MnemosynthMetrics:
    """Tracks memory operation metrics.

    Works with or without OpenTelemetry — falls back to in-memory counters.
    """

    def __init__(self):
        self._counters: dict[str, int] = {
            "remember_total": 0,
            "recall_total": 0,
            "digest_total": 0,
            "dream_total": 0,
            "forget_total": 0,
            "quarantined_total": 0,
        }
        self._histograms: dict[str, list[float]] = {
            "remember_duration_ms": [],
            "recall_duration_ms": [],
            "digest_duration_ms": [],
        }
        self._otel_meter = None
        self._setup_otel()

    def _setup_otel(self) -> None:
        """Try to set up OpenTelemetry metrics."""
        try:
            from opentelemetry import metrics
            self._otel_meter = metrics.get_meter("mnemosynth")
        except ImportError:
            pass

    def increment(self, name: str, value: int = 1) -> None:
        """Increment a counter metric."""
        if name in self._counters:
            self._counters[name] += value

    def record_duration(self, name: str, duration_ms: float) -> None:
        """Record a duration measurement."""
        key = f"{name}_duration_ms"
        if key in self._histograms:
            self._histograms[key].append(duration_ms)
            # Keep only last 1000 measurements
            if len(self._histograms[key]) > 1000:
                self._histograms[key] = self._histograms[key][-1000:]

    def get_stats(self) -> dict:
        """Get a summary of all metrics."""
        stats = dict(self._counters)
        for key, values in self._histograms.items():
            if values:
                stats[f"{key}_avg"] = round(sum(values) / len(values), 2)
                stats[f"{key}_p99"] = round(sorted(values)[int(len(values) * 0.99)], 2)
        return stats


# ---------------------------------------------------------------------------
# Instrumentation wrapper
# ---------------------------------------------------------------------------

_metrics = MnemosynthMetrics()
_tracer = _get_tracer()


def traced(operation_name: str) -> Callable:
    """Decorator to add tracing + metrics to a Mnemosynth method."""

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            span = _tracer.start_as_current_span(f"mnemosynth.{operation_name}")
            start = time.perf_counter()

            try:
                with span:
                    result = func(*args, **kwargs)

                    # Record metrics
                    _metrics.increment(f"{operation_name}_total")
                    duration = (time.perf_counter() - start) * 1000
                    _metrics.record_duration(operation_name, duration)

                    # Set span attributes
                    span.set_attribute("mnemosynth.operation", operation_name)
                    span.set_attribute("mnemosynth.duration_ms", duration)

                    if isinstance(result, MemoryNode):
                        span.set_attribute("mnemosynth.memory_type", result.memory_type.value)
                        span.set_attribute("mnemosynth.confidence", result.confidence)
                    elif isinstance(result, list):
                        span.set_attribute("mnemosynth.result_count", len(result))

                    return result

            except Exception as e:
                span.record_exception(e)
                raise

        return wrapper
    return decorator


def instrument_brain(brain) -> None:
    """Instrument a Mnemosynth instance with tracing and metrics.

    Wraps the core methods (remember, recall, digest, dream, forget)
    with OpenTelemetry spans and counters.

    Usage:
        brain = Mnemosynth()
        instrument_brain(brain)
        brain.remember("now traced!")
    """
    methods_to_instrument = [
        ("remember", "remember"),
        ("recall", "recall"),
        ("digest", "digest"),
        ("dream", "dream"),
        ("forget", "forget"),
    ]

    for attr_name, op_name in methods_to_instrument:
        if hasattr(brain, attr_name):
            original = getattr(brain, attr_name)
            wrapped = traced(op_name)(original)
            setattr(brain, attr_name, wrapped)


class TracedMnemosynth:
    """A pre-instrumented Mnemosynth wrapper.

    Usage:
        from mnemosynth.telemetry import TracedMnemosynth
        brain = TracedMnemosynth()
        brain.remember("automatically traced!")
    """

    def __init__(self, **kwargs):
        from mnemosynth import Mnemosynth
        self._brain = Mnemosynth(**kwargs)
        instrument_brain(self._brain)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._brain, name)


def get_metrics() -> dict:
    """Get current telemetry metrics."""
    return _metrics.get_stats()
