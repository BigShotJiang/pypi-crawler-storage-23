"""
MNEMOSYNTH Production Store — Qdrant Vector Database.

Drop-in replacement for the default LanceDB episodic store,
using Qdrant for production-grade vector search.

Usage:
    from mnemosynth.stores.qdrant_store import QdrantEpisodicStore

    store = QdrantEpisodicStore(
        url="http://localhost:6333",
        collection_name="mnemosynth_episodic",
    )

Requires: pip install mnemosynth[production]
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any, Optional

from mnemosynth.core.types import MemoryNode, MemoryType, MemoryStatus


class QdrantEpisodicStore:
    """Qdrant-backed episodic memory store for production deployments.

    Features:
    - Persistent vector storage with configurable distance metrics
    - HNSW indexing for sub-millisecond search at scale
    - Filtering by memory type, status, confidence, and tags
    - Automatic collection creation with proper schema
    """

    def __init__(
        self,
        url: str = "http://localhost:6333",
        api_key: str | None = None,
        collection_name: str = "mnemosynth_episodic",
        embedding_dim: int = 384,
        config: Any = None,
    ):
        self.url = url
        self.api_key = api_key
        self.collection_name = collection_name
        self.embedding_dim = embedding_dim
        self.config = config
        self._client = None

    @property
    def client(self):
        """Lazy-initialize Qdrant client."""
        if self._client is None:
            try:
                from qdrant_client import QdrantClient
            except ImportError:
                raise ImportError(
                    "Qdrant store requires qdrant-client. "
                    "Install with: pip install mnemosynth[production]"
                ) from None

            self._client = QdrantClient(url=self.url, api_key=self.api_key)
            self._ensure_collection()
        return self._client

    def _ensure_collection(self) -> None:
        """Create collection if it doesn't exist."""
        from qdrant_client.models import Distance, VectorParams

        collections = self.client.get_collections().collections
        exists = any(c.name == self.collection_name for c in collections)

        if not exists:
            self.client.create_collection(
                collection_name=self.collection_name,
                vectors_config=VectorParams(
                    size=self.embedding_dim,
                    distance=Distance.COSINE,
                ),
            )

    def add(self, node: MemoryNode) -> None:
        """Store a memory node in Qdrant."""
        from qdrant_client.models import PointStruct

        if node.embedding is None:
            raise ValueError("Memory node must have an embedding for Qdrant storage")

        payload = {
            "content": node.content,
            "memory_type": node.memory_type.value,
            "status": node.status.value,
            "confidence": node.confidence,
            "sentiment_score": getattr(node, "sentiment_score", 0.0),
            "tags": node.tags,
            "created_at": node.created_at.isoformat(),
            "last_accessed": node.last_accessed.isoformat(),
            "access_count": node.access_count,
        }

        point = PointStruct(
            id=node.id,
            vector=node.embedding,
            payload=payload,
        )

        self.client.upsert(
            collection_name=self.collection_name,
            points=[point],
        )

    def search(self, query: str, limit: int = 5, embedding: list[float] | None = None) -> list[MemoryNode]:
        """Search memories by vector similarity."""
        from qdrant_client.models import Filter, FieldCondition, MatchValue

        if embedding is None:
            return []

        # Only return active memories
        search_filter = Filter(
            must=[
                FieldCondition(key="status", match=MatchValue(value="active")),
            ]
        )

        results = self.client.search(
            collection_name=self.collection_name,
            query_vector=embedding,
            query_filter=search_filter,
            limit=limit,
        )

        nodes = []
        for hit in results:
            node = MemoryNode(
                id=hit.id,
                content=hit.payload["content"],
                memory_type=MemoryType(hit.payload["memory_type"]),
                status=MemoryStatus(hit.payload["status"]),
                confidence=hit.payload["confidence"],
                tags=hit.payload.get("tags", []),
                created_at=datetime.fromisoformat(hit.payload["created_at"]),
                last_accessed=datetime.fromisoformat(hit.payload["last_accessed"]),
                access_count=hit.payload.get("access_count", 0),
            )
            node.sentiment_score = hit.payload.get("sentiment_score", 0.0)
            nodes.append(node)

        return nodes

    def delete(self, memory_id: str) -> bool:
        """Delete a memory by ID."""
        try:
            self.client.delete(
                collection_name=self.collection_name,
                points_selector=[memory_id],
            )
            return True
        except Exception:
            return False

    def count(self) -> int:
        """Get total number of memories."""
        info = self.client.get_collection(self.collection_name)
        return info.points_count

    def clear(self) -> None:
        """Delete all memories in the collection."""
        self.client.delete_collection(self.collection_name)
        self._ensure_collection()
