"""
MNEMOSYNTH Production Store — FalkorDB Graph Database.

Drop-in replacement for the default NetworkX semantic store,
using FalkorDB (Redis-compatible graph database) for production scale.

Usage:
    from mnemosynth.stores.falkordb_store import FalkorDBSemanticStore

    store = FalkorDBSemanticStore(
        host="localhost",
        port=6379,
        graph_name="mnemosynth_kg",
    )

Requires: pip install mnemosynth[production]
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Optional

from mnemosynth.core.types import MemoryNode, MemoryType, MemoryStatus, RelationshipEdge


class FalkorDBSemanticStore:
    """FalkorDB-backed semantic (knowledge graph) store.

    Features:
    - Redis-compatible graph database for relationship queries
    - Cypher query support for complex traversals
    - Entity-relationship modeling with typed edges
    - Horizontal scaling via Redis Cluster
    """

    def __init__(
        self,
        host: str = "localhost",
        port: int = 6379,
        graph_name: str = "mnemosynth_kg",
        password: str | None = None,
        config: Any = None,
    ):
        self.host = host
        self.port = port
        self.graph_name = graph_name
        self.password = password
        self.config = config
        self._graph = None

    @property
    def graph(self):
        """Lazy-initialize FalkorDB connection."""
        if self._graph is None:
            try:
                from falkordb import FalkorDB
            except ImportError:
                raise ImportError(
                    "FalkorDB store requires falkordb. "
                    "Install with: pip install mnemosynth[production]"
                ) from None

            db = FalkorDB(host=self.host, port=self.port, password=self.password)
            self._graph = db.select_graph(self.graph_name)
            self._ensure_schema()
        return self._graph

    def _ensure_schema(self) -> None:
        """Create indexes for efficient querying."""
        try:
            self.graph.query("CREATE INDEX ON :Memory(id)")
            self.graph.query("CREATE INDEX ON :Memory(memory_type)")
            self.graph.query("CREATE INDEX ON :Memory(status)")
        except Exception:
            pass  # Indexes may already exist

    def add(self, node: MemoryNode) -> None:
        """Store a memory node as a graph vertex."""
        query = """
        MERGE (m:Memory {id: $id})
        SET m.content = $content,
            m.memory_type = $memory_type,
            m.status = $status,
            m.confidence = $confidence,
            m.sentiment_score = $sentiment_score,
            m.created_at = $created_at,
            m.tags = $tags
        """
        params = {
            "id": node.id,
            "content": node.content,
            "memory_type": node.memory_type.value,
            "status": node.status.value,
            "confidence": node.confidence,
            "sentiment_score": getattr(node, "sentiment_score", 0.0),
            "created_at": node.created_at.isoformat(),
            "tags": ",".join(node.tags),
        }
        self.graph.query(query, params)

    def add_relationship(self, edge: RelationshipEdge) -> None:
        """Create a typed edge between two memory nodes."""
        query = """
        MATCH (a:Memory {id: $source}), (b:Memory {id: $target})
        MERGE (a)-[r:%s]->(b)
        SET r.weight = $weight,
            r.created_at = $created_at
        """ % edge.relation_type.upper().replace(" ", "_")

        params = {
            "source": edge.source_id,
            "target": edge.target_id,
            "weight": edge.weight,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        self.graph.query(query, params)

    def search(self, query: str, limit: int = 5) -> list[MemoryNode]:
        """Search semantic memories by keyword matching in Cypher."""
        cypher = """
        MATCH (m:Memory)
        WHERE m.status = 'active' AND m.content CONTAINS $query
        RETURN m
        ORDER BY m.confidence DESC
        LIMIT $limit
        """
        result = self.graph.query(cypher, {"query": query, "limit": limit})

        nodes = []
        for record in result.result_set:
            props = record[0].properties
            node = MemoryNode(
                id=props["id"],
                content=props["content"],
                memory_type=MemoryType(props["memory_type"]),
                status=MemoryStatus(props["status"]),
                confidence=float(props["confidence"]),
                created_at=datetime.fromisoformat(props["created_at"]),
                tags=props.get("tags", "").split(",") if props.get("tags") else [],
            )
            node.sentiment_score = float(props.get("sentiment_score", 0.0))
            nodes.append(node)

        return nodes

    def get_neighbors(self, memory_id: str, max_depth: int = 2) -> list[dict]:
        """Get all connected nodes up to max_depth hops away."""
        cypher = """
        MATCH path = (m:Memory {id: $id})-[*1..%d]-(neighbor:Memory)
        RETURN DISTINCT neighbor, length(path) as depth
        ORDER BY depth, neighbor.confidence DESC
        """ % max_depth

        result = self.graph.query(cypher, {"id": memory_id})

        neighbors = []
        for record in result.result_set:
            props = record[0].properties
            neighbors.append({
                "id": props["id"],
                "content": props["content"],
                "memory_type": props["memory_type"],
                "confidence": float(props["confidence"]),
                "depth": int(record[1]),
            })

        return neighbors

    def delete(self, memory_id: str) -> bool:
        """Delete a memory node and all its relationships."""
        try:
            self.graph.query(
                "MATCH (m:Memory {id: $id}) DETACH DELETE m",
                {"id": memory_id},
            )
            return True
        except Exception:
            return False

    def count(self) -> int:
        """Get total number of memory nodes."""
        result = self.graph.query("MATCH (m:Memory) RETURN count(m)")
        return int(result.result_set[0][0])

    def clear(self) -> None:
        """Delete all memory nodes and relationships."""
        self.graph.query("MATCH (n) DETACH DELETE n")
