"""
MNEMOSYNTH Production Store — PostgreSQL Persistence.

Full SQL-backed persistence for production deployments.
Replaces the default SQLite DatabaseManager with PostgreSQL
for concurrent access, replication, and enterprise features.

Usage:
    from mnemosynth.stores.postgres_store import PostgresStore

    store = PostgresStore(
        dsn="postgresql://user:pass@localhost:5432/mnemosynth"
    )

Requires: pip install mnemosynth[production]  (includes psycopg)
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any, Optional

from mnemosynth.core.types import MemoryNode, MemoryType, MemoryStatus


# SQL schema for automatic table creation
CREATE_TABLES_SQL = """
CREATE TABLE IF NOT EXISTS memories (
    id TEXT PRIMARY KEY,
    content TEXT NOT NULL,
    memory_type TEXT NOT NULL DEFAULT 'semantic',
    status TEXT NOT NULL DEFAULT 'active',
    confidence REAL NOT NULL DEFAULT 0.5,
    sentiment_score REAL NOT NULL DEFAULT 0.0,
    tags TEXT DEFAULT '[]',
    embedding BYTEA,
    source_json TEXT DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_accessed TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    access_count INTEGER NOT NULL DEFAULT 0,
    supersedes TEXT,
    superseded_by TEXT
);

CREATE INDEX IF NOT EXISTS idx_memories_type ON memories(memory_type);
CREATE INDEX IF NOT EXISTS idx_memories_status ON memories(status);
CREATE INDEX IF NOT EXISTS idx_memories_confidence ON memories(confidence DESC);
CREATE INDEX IF NOT EXISTS idx_memories_created ON memories(created_at DESC);

CREATE TABLE IF NOT EXISTS causal_chains (
    id TEXT PRIMARY KEY,
    chain_data TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS dream_logs (
    id SERIAL PRIMARY KEY,
    promoted INTEGER DEFAULT 0,
    decayed INTEGER DEFAULT 0,
    contradictions_resolved INTEGER DEFAULT 0,
    run_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
"""


class PostgresStore:
    """PostgreSQL-backed persistence layer for production Mnemosynth.

    Features:
    - ACID compliance for critical memory operations
    - Connection pooling for concurrent agent access
    - Full-text search via PostgreSQL tsvector
    - Automatic schema migration
    - JSON-based tag and source storage
    """

    def __init__(
        self,
        dsn: str = "postgresql://localhost:5432/mnemosynth",
        pool_size: int = 5,
        config: Any = None,
    ):
        self.dsn = dsn
        self.pool_size = pool_size
        self.config = config
        self._pool = None

    @property
    def pool(self):
        """Lazy-initialize connection pool."""
        if self._pool is None:
            try:
                from psycopg_pool import ConnectionPool
            except ImportError:
                raise ImportError(
                    "PostgreSQL store requires psycopg. "
                    "Install with: pip install mnemosynth[production]"
                ) from None

            self._pool = ConnectionPool(
                self.dsn,
                min_size=1,
                max_size=self.pool_size,
            )
            self._ensure_schema()
        return self._pool

    def _ensure_schema(self) -> None:
        """Create tables if they don't exist."""
        with self.pool.connection() as conn:
            conn.execute(CREATE_TABLES_SQL)
            conn.commit()

    def save_memory(self, node: MemoryNode) -> None:
        """Insert or update a memory node."""
        sql = """
        INSERT INTO memories (id, content, memory_type, status, confidence,
                              sentiment_score, tags, created_at, last_accessed,
                              access_count, supersedes, superseded_by)
        VALUES (%(id)s, %(content)s, %(memory_type)s, %(status)s, %(confidence)s,
                %(sentiment_score)s, %(tags)s, %(created_at)s, %(last_accessed)s,
                %(access_count)s, %(supersedes)s, %(superseded_by)s)
        ON CONFLICT (id) DO UPDATE SET
            content = EXCLUDED.content,
            status = EXCLUDED.status,
            confidence = EXCLUDED.confidence,
            sentiment_score = EXCLUDED.sentiment_score,
            tags = EXCLUDED.tags,
            last_accessed = EXCLUDED.last_accessed,
            access_count = EXCLUDED.access_count,
            supersedes = EXCLUDED.supersedes,
            superseded_by = EXCLUDED.superseded_by
        """
        params = {
            "id": node.id,
            "content": node.content,
            "memory_type": node.memory_type.value,
            "status": node.status.value,
            "confidence": node.confidence,
            "sentiment_score": getattr(node, "sentiment_score", 0.0),
            "tags": json.dumps(node.tags),
            "created_at": node.created_at,
            "last_accessed": node.last_accessed,
            "access_count": node.access_count,
            "supersedes": getattr(node, "supersedes", None),
            "superseded_by": getattr(node, "superseded_by", None),
        }

        with self.pool.connection() as conn:
            conn.execute(sql, params)
            conn.commit()

    def get_memory(self, memory_id: str) -> MemoryNode | None:
        """Retrieve a memory by ID."""
        sql = "SELECT * FROM memories WHERE id = %s"

        with self.pool.connection() as conn:
            cursor = conn.execute(sql, (memory_id,))
            row = cursor.fetchone()

        if not row:
            return None

        return self._row_to_node(row, cursor.description)

    def search(self, query: str, limit: int = 5) -> list[MemoryNode]:
        """Full-text search for memories."""
        sql = """
        SELECT *, ts_rank(to_tsvector('english', content),
                          plainto_tsquery('english', %s)) AS rank
        FROM memories
        WHERE status = 'active'
          AND to_tsvector('english', content) @@ plainto_tsquery('english', %s)
        ORDER BY rank DESC, confidence DESC
        LIMIT %s
        """

        with self.pool.connection() as conn:
            cursor = conn.execute(sql, (query, query, limit))
            rows = cursor.fetchall()

        return [self._row_to_node(row, cursor.description) for row in rows]

    def get_all_active(self, memory_type: str | None = None) -> list[MemoryNode]:
        """Get all active memories, optionally filtered by type."""
        if memory_type:
            sql = "SELECT * FROM memories WHERE status = 'active' AND memory_type = %s ORDER BY created_at DESC"
            params = (memory_type,)
        else:
            sql = "SELECT * FROM memories WHERE status = 'active' ORDER BY created_at DESC"
            params = ()

        with self.pool.connection() as conn:
            cursor = conn.execute(sql, params)
            rows = cursor.fetchall()

        return [self._row_to_node(row, cursor.description) for row in rows]

    def delete_memory(self, memory_id: str) -> bool:
        """Delete a memory by ID."""
        sql = "DELETE FROM memories WHERE id = %s"
        with self.pool.connection() as conn:
            cursor = conn.execute(sql, (memory_id,))
            conn.commit()
            return cursor.rowcount > 0

    def get_stats(self) -> dict:
        """Get memory statistics."""
        with self.pool.connection() as conn:
            cursor = conn.execute("""
                SELECT
                    COUNT(*) as total,
                    COUNT(*) FILTER (WHERE memory_type = 'episodic') as episodic,
                    COUNT(*) FILTER (WHERE memory_type = 'semantic') as semantic,
                    COUNT(*) FILTER (WHERE memory_type = 'procedural') as procedural,
                    COUNT(*) FILTER (WHERE status = 'active') as active,
                    COUNT(*) FILTER (WHERE status = 'quarantined') as quarantined,
                    AVG(confidence) as avg_confidence
                FROM memories
            """)
            row = cursor.fetchone()

        return {
            "total": row[0],
            "episodic": row[1],
            "semantic": row[2],
            "procedural": row[3],
            "active": row[4],
            "quarantined": row[5],
            "avg_confidence": round(row[6] or 0, 3),
        }

    def log_dream(self, promoted: int, decayed: int, contradictions: int) -> None:
        """Log a dream consolidation run."""
        sql = """
        INSERT INTO dream_logs (promoted, decayed, contradictions_resolved)
        VALUES (%s, %s, %s)
        """
        with self.pool.connection() as conn:
            conn.execute(sql, (promoted, decayed, contradictions))
            conn.commit()

    def clear(self) -> None:
        """Delete all memories."""
        with self.pool.connection() as conn:
            conn.execute("TRUNCATE memories, causal_chains, dream_logs")
            conn.commit()

    def _row_to_node(self, row: tuple, description: Any) -> MemoryNode:
        """Convert a database row to a MemoryNode."""
        cols = [d[0] for d in description]
        data = dict(zip(cols, row))

        node = MemoryNode(
            id=data["id"],
            content=data["content"],
            memory_type=MemoryType(data["memory_type"]),
            status=MemoryStatus(data["status"]),
            confidence=float(data["confidence"]),
            created_at=data["created_at"],
            last_accessed=data["last_accessed"],
            access_count=data.get("access_count", 0),
            tags=json.loads(data.get("tags", "[]")),
        )
        node.sentiment_score = float(data.get("sentiment_score", 0.0))
        return node
