"""Abstract base class for all memory stores."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Optional

from mnemosynth.core.types import MemoryNode


class BaseStore(ABC):
    """Interface that all memory stores (episodic, semantic, procedural) must implement."""

    @abstractmethod
    def add(self, memory: MemoryNode) -> None:
        """Store a new memory."""
        ...

    @abstractmethod
    def search(self, query: str, limit: int = 5) -> list[MemoryNode]:
        """Search memories by query."""
        ...

    @abstractmethod
    def get(self, memory_id: str) -> Optional[MemoryNode]:
        """Retrieve a specific memory by ID."""
        ...

    @abstractmethod
    def update(self, memory: MemoryNode) -> None:
        """Update an existing memory."""
        ...

    @abstractmethod
    def delete(self, memory_id: str) -> bool:
        """Delete a memory by ID."""
        ...

    @abstractmethod
    def count(self) -> int:
        """Count total memories in this store."""
        ...
