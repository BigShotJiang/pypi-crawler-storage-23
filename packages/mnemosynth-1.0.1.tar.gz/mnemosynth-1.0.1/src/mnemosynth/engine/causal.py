"""
Causal Memory Chains — Decision → Reason → Outcome DAGs.

Tracks causal relationships between memories, forming directed acyclic graphs
that help AI understand WHY decisions were made and WHAT happened as a result.

Usage:
    from mnemosynth.engine.causal import CausalChainEngine

    engine = CausalChainEngine(brain)

    # Record a causal chain
    chain_id = engine.record_chain(
        decision="Switched database from PostgreSQL to SQLite",
        reasons=["Need zero-config deployment", "Single-user workload"],
        outcome="Reduced setup time from 30min to 0, users can pip install",
    )

    # Query chains by topic
    chains = engine.search("database decisions")

    # Get the full chain DAG
    chain = engine.get_chain(chain_id)
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional

from mnemosynth.core.types import MemoryNode, MemoryType


@dataclass
class CausalLink:
    """A single causal connection between two memories."""
    source_id: str
    target_id: str
    relation: str  # "caused_by", "resulted_in", "motivated_by"
    strength: float = 1.0  # 0.0 to 1.0

    def to_dict(self) -> dict:
        return {
            "source_id": self.source_id,
            "target_id": self.target_id,
            "relation": self.relation,
            "strength": self.strength,
        }


@dataclass
class CausalChain:
    """A complete Decision → Reason → Outcome chain."""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    decision: MemoryNode | None = None
    reasons: list[MemoryNode] = field(default_factory=list)
    outcome: MemoryNode | None = None
    links: list[CausalLink] = field(default_factory=list)
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    tags: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "decision": self.decision.to_dict() if self.decision else None,
            "reasons": [r.to_dict() for r in self.reasons],
            "outcome": self.outcome.to_dict() if self.outcome else None,
            "links": [l.to_dict() for l in self.links],
            "created_at": self.created_at.isoformat(),
            "tags": self.tags,
        }

    def summary(self) -> str:
        """Human-readable summary of the causal chain."""
        parts = []
        if self.decision:
            parts.append(f"DECISION: {self.decision.content}")
        if self.reasons:
            reason_text = "; ".join(r.content for r in self.reasons)
            parts.append(f"BECAUSE: {reason_text}")
        if self.outcome:
            parts.append(f"RESULT: {self.outcome.content}")
        return " → ".join(parts) if parts else "Empty causal chain"


class CausalChainEngine:
    """Engine for recording and querying causal memory chains.

    Each chain is a small DAG: Decision ← Reasons → Outcome.
    All chain nodes are stored as regular memories (tagged with chain ID),
    so they appear in normal recall and digest operations too.
    """

    CHAIN_TAG_PREFIX = "chain:"

    def __init__(self, brain=None):
        """Initialize with a Mnemosynth instance.

        Args:
            brain: A Mnemosynth instance. If None, chains are stored in-memory only.
        """
        self.brain = brain
        self._chains: dict[str, CausalChain] = {}

    def record_chain(
        self,
        decision: str,
        reasons: list[str] | None = None,
        outcome: str | None = None,
        tags: list[str] | None = None,
    ) -> str:
        """Record a new causal chain.

        Args:
            decision: What was decided or done.
            reasons: Why it was decided (supporting factors).
            outcome: What happened as a result.
            tags: Extra tags for categorization.

        Returns:
            The chain ID.
        """
        chain = CausalChain(tags=tags or [])
        chain_tag = f"{self.CHAIN_TAG_PREFIX}{chain.id}"

        # Create decision node
        decision_node = self._store_memory(
            content=f"[Decision] {decision}",
            extra_tags=[chain_tag, "causal:decision"],
        )
        chain.decision = decision_node

        # Create reason nodes
        for reason_text in (reasons or []):
            reason_node = self._store_memory(
                content=f"[Reason] {reason_text}",
                extra_tags=[chain_tag, "causal:reason"],
            )
            chain.reasons.append(reason_node)

            # Link: decision ← reason
            chain.links.append(CausalLink(
                source_id=reason_node.id,
                target_id=decision_node.id,
                relation="motivated_by",
            ))

        # Create outcome node
        if outcome:
            outcome_node = self._store_memory(
                content=f"[Outcome] {outcome}",
                extra_tags=[chain_tag, "causal:outcome"],
            )
            chain.outcome = outcome_node

            # Link: decision → outcome
            chain.links.append(CausalLink(
                source_id=decision_node.id,
                target_id=outcome_node.id,
                relation="resulted_in",
            ))

        self._chains[chain.id] = chain
        return chain.id

    def get_chain(self, chain_id: str) -> CausalChain | None:
        """Retrieve a chain by ID."""
        return self._chains.get(chain_id)

    def search(self, query: str, limit: int = 5) -> list[CausalChain]:
        """Search for chains relevant to a query.

        Searches decision and outcome text for keyword overlap.
        """
        query_words = set(query.lower().split())
        scored: list[tuple[float, CausalChain]] = []

        for chain in self._chains.values():
            score = 0.0

            if chain.decision:
                decision_words = set(chain.decision.content.lower().split())
                overlap = len(query_words & decision_words)
                score += overlap * 2.0  # Decision is more important

            if chain.outcome:
                outcome_words = set(chain.outcome.content.lower().split())
                overlap = len(query_words & outcome_words)
                score += overlap * 1.0

            for reason in chain.reasons:
                reason_words = set(reason.content.lower().split())
                overlap = len(query_words & reason_words)
                score += overlap * 0.5

            if score > 0:
                scored.append((score, chain))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [chain for _, chain in scored[:limit]]

    def list_chains(self) -> list[CausalChain]:
        """List all recorded causal chains."""
        return list(self._chains.values())

    def delete_chain(self, chain_id: str) -> bool:
        """Delete a causal chain and its associated memories."""
        chain = self._chains.pop(chain_id, None)
        if not chain:
            return False

        # Delete associated memories from the brain
        if self.brain:
            nodes = [chain.decision] + chain.reasons + ([chain.outcome] if chain.outcome else [])
            for node in nodes:
                if node:
                    self.brain.forget(node.id)

        return True

    def get_digest(self, query: str, max_chains: int = 3) -> str:
        """Get a formatted digest of relevant causal chains.

        Suitable for injection into LLM prompts.
        """
        chains = self.search(query, limit=max_chains)
        if not chains:
            return "<causal_context>No relevant causal chains found.</causal_context>"

        parts = ["<causal_context>"]
        for chain in chains:
            parts.append(f"  <chain id=\"{chain.id[:8]}\">")
            parts.append(f"    {chain.summary()}")
            parts.append("  </chain>")
        parts.append("</causal_context>")
        return "\n".join(parts)

    def _store_memory(
        self,
        content: str,
        extra_tags: list[str] | None = None,
    ) -> MemoryNode:
        """Store a memory via the brain, or create a standalone node."""
        if self.brain:
            node = self.brain.remember(content, memory_type="semantic")
            if extra_tags:
                node.tags.extend(extra_tags)
                self.brain.db.save_memory(node)
            return node

        # Standalone mode (no brain connected)
        node = MemoryNode.create(
            content=content,
            memory_type=MemoryType.SEMANTIC,
            tags=extra_tags or [],
        )
        return node
