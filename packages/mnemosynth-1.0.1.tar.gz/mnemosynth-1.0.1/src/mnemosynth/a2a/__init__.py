"""
MNEMOSYNTH Agent-to-Agent (A2A) Protocol.

Defines a standard protocol for AI agents to share, request,
and synchronize memories across heterogeneous systems.

Usage:
    from mnemosynth.a2a.protocol import A2AProtocol, MemoryRequest

    proto = A2AProtocol(brain)

    # Agent sends a memory request
    request = MemoryRequest(
        agent_id="researcher-agent",
        query="user preferences",
        scope="shared",
    )
    response = proto.handle_request(request)

    # Agent shares a memory
    proto.share_memory(
        content="User prefers Python for backend",
        source_agent="coder-agent",
        visibility="shared",
    )
"""

from __future__ import annotations

import uuid
import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional

from mnemosynth.core.types import MemoryNode, MemoryType


class Visibility(str, Enum):
    """Memory visibility levels in A2A."""
    PRIVATE = "private"     # Only the owning agent
    SHARED = "shared"       # All agents in the same workspace
    PUBLIC = "public"       # Any connected agent


class A2AMessageType(str, Enum):
    """Message types in the A2A protocol."""
    MEMORY_REQUEST = "memory_request"
    MEMORY_RESPONSE = "memory_response"
    MEMORY_SHARE = "memory_share"
    MEMORY_SYNC = "memory_sync"
    HEARTBEAT = "heartbeat"
    ACK = "ack"


@dataclass
class A2AMessage:
    """A single A2A protocol message."""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    type: A2AMessageType = A2AMessageType.HEARTBEAT
    sender: str = "unknown"
    recipient: str = "*"  # "*" = broadcast
    payload: dict = field(default_factory=dict)
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def to_json(self) -> str:
        return json.dumps({
            "id": self.id,
            "type": self.type.value,
            "sender": self.sender,
            "recipient": self.recipient,
            "payload": self.payload,
            "timestamp": self.timestamp.isoformat(),
        })

    @classmethod
    def from_json(cls, data: str) -> "A2AMessage":
        d = json.loads(data)
        return cls(
            id=d["id"],
            type=A2AMessageType(d["type"]),
            sender=d["sender"],
            recipient=d["recipient"],
            payload=d["payload"],
            timestamp=datetime.fromisoformat(d["timestamp"]),
        )


@dataclass
class MemoryRequest:
    """A structured request for memories."""
    agent_id: str
    query: str
    scope: str = "shared"
    limit: int = 5
    memory_types: list[str] | None = None


@dataclass
class MemoryResponse:
    """Response to a memory request."""
    request_id: str
    memories: list[dict] = field(default_factory=list)
    total_found: int = 0
    source_agent: str = "mnemosynth"


class A2AProtocol:
    """Agent-to-Agent memory sharing protocol.

    Enables agents to:
    - Request memories from the shared knowledge base
    - Share new memories with visibility controls
    - Synchronize state across distributed agents
    - Discover other agents via heartbeat
    """

    def __init__(self, brain=None):
        self.brain = brain
        self._agents: dict[str, dict] = {}  # Registered agents
        self._message_log: list[A2AMessage] = []

    def register_agent(
        self,
        agent_id: str,
        capabilities: list[str] | None = None,
        metadata: dict | None = None,
    ) -> dict:
        """Register an agent in the A2A network."""
        agent_info = {
            "id": agent_id,
            "capabilities": capabilities or [],
            "metadata": metadata or {},
            "registered_at": datetime.now(timezone.utc).isoformat(),
            "last_heartbeat": datetime.now(timezone.utc).isoformat(),
        }
        self._agents[agent_id] = agent_info
        return agent_info

    def handle_request(self, request: MemoryRequest) -> MemoryResponse:
        """Handle a memory request from an agent."""
        if not self.brain:
            return MemoryResponse(request_id="", memories=[], total_found=0)

        results = self.brain.recall(request.query, limit=request.limit)

        # Filter by visibility if scope is not "shared"
        filtered = results
        if request.memory_types:
            type_set = set(request.memory_types)
            filtered = [m for m in results if m.memory_type.value in type_set]

        memories = []
        for mem in filtered:
            memories.append({
                "id": mem.id,
                "content": mem.content,
                "memory_type": mem.memory_type.value,
                "confidence": mem.confidence,
                "sentiment": getattr(mem, "sentiment_score", 0.0),
                "tags": mem.tags,
            })

        # Log the request
        msg = A2AMessage(
            type=A2AMessageType.MEMORY_REQUEST,
            sender=request.agent_id,
            payload={"query": request.query, "limit": request.limit},
        )
        self._message_log.append(msg)

        return MemoryResponse(
            request_id=msg.id,
            memories=memories,
            total_found=len(memories),
            source_agent="mnemosynth",
        )

    def share_memory(
        self,
        content: str,
        source_agent: str,
        visibility: str = "shared",
        memory_type: str = "auto",
    ) -> MemoryNode | None:
        """Share a memory from an agent into the knowledge base."""
        if not self.brain:
            return None

        node = self.brain.remember(content, memory_type=memory_type)

        # Tag with provenance
        node.tags.extend([
            f"a2a:source:{source_agent}",
            f"a2a:visibility:{visibility}",
        ])

        if self.brain:
            self.brain.db.save_memory(node)

        # Log the share
        msg = A2AMessage(
            type=A2AMessageType.MEMORY_SHARE,
            sender=source_agent,
            payload={"memory_id": node.id, "visibility": visibility},
        )
        self._message_log.append(msg)

        return node

    def heartbeat(self, agent_id: str) -> A2AMessage:
        """Send a heartbeat to report agent liveness."""
        if agent_id in self._agents:
            self._agents[agent_id]["last_heartbeat"] = datetime.now(timezone.utc).isoformat()

        msg = A2AMessage(
            type=A2AMessageType.HEARTBEAT,
            sender=agent_id,
        )
        self._message_log.append(msg)
        return msg

    def get_agents(self) -> list[dict]:
        """List all registered agents."""
        return list(self._agents.values())

    def get_message_log(self, limit: int = 50) -> list[dict]:
        """Get recent A2A messages."""
        return [
            {
                "id": m.id,
                "type": m.type.value,
                "sender": m.sender,
                "timestamp": m.timestamp.isoformat(),
            }
            for m in self._message_log[-limit:]
        ]
