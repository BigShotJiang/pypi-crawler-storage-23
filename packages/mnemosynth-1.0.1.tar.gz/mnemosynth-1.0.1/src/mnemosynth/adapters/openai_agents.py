"""
MNEMOSYNTH × OpenAI Agents SDK Adapter

Provides pre-configured MCP server params for the OpenAI Agents SDK.

Usage:
    import asyncio
    from agents import Agent, Runner
    from mnemosynth.adapters.openai_agents import create_mcp_workbench

    async def main():
        async with create_mcp_workbench() as mcp:
            agent = Agent(
                name="Research Assistant",
                instructions="Use memory tools to remember and recall info.",
                mcp_servers=[mcp],
            )
            result = await Runner.run(agent, "What do you remember about me?")
            print(result.final_output)

    asyncio.run(main())

Requires: pip install mnemosynth[openai-agents]
"""

from __future__ import annotations

import shutil
import sys
from typing import Any


def get_server_params(**env_overrides: str) -> Any:
    """Return StdioServerParams for the OpenAI Agents SDK.

    Compatible with `agents.mcp.McpWorkbench`.
    """
    try:
        from agents.mcp import StdioServerParams
    except ImportError:
        raise ImportError(
            "OpenAI Agents SDK adapter requires openai-agents. "
            "Install with: pip install mnemosynth[openai-agents]"
        ) from None

    mnemosynth_bin = shutil.which("mnemosynth")
    command = mnemosynth_bin or sys.executable

    if mnemosynth_bin:
        args = ["serve"]
    else:
        args = ["-m", "mnemosynth", "serve"]

    env = {}
    env.update(env_overrides)

    return StdioServerParams(
        command=command,
        args=args,
        env=env if env else None,
    )


async def create_mcp_workbench(**env_overrides: str) -> Any:
    """Create an OpenAI Agents SDK McpWorkbench connected to Mnemosynth.

    Returns an async context manager:
        async with create_mcp_workbench() as mcp:
            agent = Agent(name="...", mcp_servers=[mcp])
    """
    try:
        from agents.mcp import McpWorkbench
    except ImportError:
        raise ImportError(
            "OpenAI Agents SDK adapter requires openai-agents. "
            "Install with: pip install mnemosynth[openai-agents]"
        ) from None

    params = get_server_params(**env_overrides)
    return McpWorkbench(params)
