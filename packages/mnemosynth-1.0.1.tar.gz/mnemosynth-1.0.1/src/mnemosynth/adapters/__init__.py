"""
MNEMOSYNTH Adapters — Drop-in integrations for popular agentic frameworks.

Usage:
    # CrewAI
    from mnemosynth.adapters.crewai import MnemosynthRememberTool, MnemosynthRecallTool

    # LangChain / LangGraph
    from mnemosynth.adapters.langchain import get_mnemosynth_tools, MnemosynthMemory

    # AutoGen
    from mnemosynth.adapters.autogen import create_mcp_workbench

    # OpenAI Agents SDK
    from mnemosynth.adapters.openai_agents import get_server_params

    # PydanticAI
    from mnemosynth.adapters.pydantic_ai import get_mcp_server

    # Cross-Agent Memory Bus
    from mnemosynth.adapters.memory_bus import MemoryBus
"""

__all__ = [
    "crewai",
    "langchain",
    "autogen",
    "openai_agents",
    "pydantic_ai",
    "memory_bus",
]
