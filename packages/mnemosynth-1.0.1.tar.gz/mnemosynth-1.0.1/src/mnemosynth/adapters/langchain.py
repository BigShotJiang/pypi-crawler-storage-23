"""
MNEMOSYNTH × LangChain / LangGraph Adapter

Provides LangChain-compatible tools and a BaseMemory implementation
for seamless integration with LangGraph agents.

Usage (tools):
    from mnemosynth.adapters.langchain import get_mnemosynth_tools
    tools = get_mnemosynth_tools()
    agent = create_react_agent(model, tools=tools)

Usage (memory):
    from mnemosynth.adapters.langchain import MnemosynthMemory
    memory = MnemosynthMemory()
    chain = ConversationChain(llm=llm, memory=memory)

Requires: pip install mnemosynth[langchain]
"""

from __future__ import annotations

from typing import Any

from mnemosynth import Mnemosynth


# ---------------------------------------------------------------------------
# LangChain @tool-style functions (framework-agnostic callables)
# ---------------------------------------------------------------------------

def _make_remember_tool(brain: Mnemosynth):
    """Create a remember tool function."""

    def remember_memory(content: str) -> str:
        """Store important information in long-term AI memory.
        Use this to save facts, user preferences, decisions, or any
        information that should persist across conversations."""
        node = brain.remember(content)
        return (
            f"✅ Stored [{node.memory_type.value}] memory "
            f"(confidence: {node.confidence:.2f}): {node.content[:120]}"
        )

    remember_memory.__name__ = "remember_memory"
    remember_memory.__doc__ = (
        "Store important information in long-term AI memory. "
        "Input should be a plain-text fact, preference, or observation."
    )
    return remember_memory


def _make_recall_tool(brain: Mnemosynth, limit: int = 5):
    """Create a recall tool function."""

    def recall_memory(query: str) -> str:
        """Search long-term AI memory for relevant past information.
        Returns the most relevant memories ranked by confidence and recency."""
        results = brain.recall(query, limit=limit)
        if not results:
            return "No relevant memories found."
        lines = []
        for i, mem in enumerate(results, 1):
            lines.append(
                f"{i}. [{mem.memory_type.value}] "
                f"(conf: {mem.confidence:.2f}) {mem.content}"
            )
        return "\n".join(lines)

    recall_memory.__name__ = "recall_memory"
    recall_memory.__doc__ = (
        "Search long-term AI memory for relevant past context. "
        "Input should be a natural-language query."
    )
    return recall_memory


def _make_digest_tool(brain: Mnemosynth):
    """Create a digest tool function."""

    def get_memory_digest(query: str) -> str:
        """Get a compressed summary of all relevant memories for the given topic."""
        return brain.digest(query)

    get_memory_digest.__name__ = "get_memory_digest"
    get_memory_digest.__doc__ = (
        "Get a compressed memory context block for a topic. "
        "Returns an XML-formatted digest suitable for LLM prompts."
    )
    return get_memory_digest


def get_mnemosynth_tools(brain: Mnemosynth | None = None, limit: int = 5) -> list:
    """Return a list of Mnemosynth tool functions.

    These work as plain callables with any framework. For LangChain,
    wrap them with @tool or use StructuredTool.from_function().

    Usage with LangGraph:
        from langchain_core.tools import tool
        from mnemosynth.adapters.langchain import get_mnemosynth_tools

        raw_tools = get_mnemosynth_tools()
        tools = [tool(fn) for fn in raw_tools]
        agent = create_react_agent(model, tools=tools)
    """
    b = brain or Mnemosynth()
    return [
        _make_remember_tool(b),
        _make_recall_tool(b, limit=limit),
        _make_digest_tool(b),
    ]


# ---------------------------------------------------------------------------
# LangChain BaseMemory implementation
# ---------------------------------------------------------------------------

class MnemosynthMemory:
    """LangChain-compatible memory class backed by Mnemosynth.

    Implements the BaseMemory interface via duck-typing so LangChain
    is only required at runtime. Drop this into any LangChain chain
    that accepts a `memory` parameter.

    Usage:
        memory = MnemosynthMemory()
        chain = ConversationChain(llm=llm, memory=memory)
    """

    memory_key: str = "memory_context"

    def __init__(
        self,
        brain: Mnemosynth | None = None,
        memory_key: str = "memory_context",
        max_tokens: int = 150,
        auto_save: bool = True,
    ):
        self.brain = brain or Mnemosynth()
        self.memory_key = memory_key
        self.max_tokens = max_tokens
        self.auto_save = auto_save

    @property
    def memory_variables(self) -> list[str]:
        """LangChain interface: list of keys injected into the chain."""
        return [self.memory_key]

    def load_memory_variables(self, inputs: dict[str, Any]) -> dict[str, str]:
        """LangChain interface: load relevant memories for the current input."""
        # Extract the user query from common input keys
        query = ""
        for key in ("input", "question", "query", "human_input"):
            if key in inputs:
                query = inputs[key]
                break

        if not query:
            query = str(inputs) if inputs else ""

        digest = self.brain.digest(query=query, max_tokens=self.max_tokens)
        return {self.memory_key: digest}

    def save_context(self, inputs: dict[str, Any], outputs: dict[str, str]) -> None:
        """LangChain interface: save the interaction context as a memory."""
        if not self.auto_save:
            return

        # Build a concise summary of the exchange
        input_text = inputs.get("input", inputs.get("question", ""))
        output_text = outputs.get("output", outputs.get("response", ""))

        if input_text and output_text:
            summary = f"User asked: {input_text[:200]} → AI answered: {output_text[:200]}"
            self.brain.remember(summary)

    def clear(self) -> None:
        """LangChain interface: clear all memories (no-op for safety)."""
        # Intentionally a no-op — memories are precious!
        # Use brain.forget(id) for targeted deletion.
        pass
