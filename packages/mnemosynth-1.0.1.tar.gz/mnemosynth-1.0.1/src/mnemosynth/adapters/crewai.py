"""
MNEMOSYNTH × CrewAI Adapter

Drop-in CrewAI tools that give any Crew persistent, verified memory.

Usage:
    from mnemosynth import Mnemosynth
    from mnemosynth.adapters.crewai import MnemosynthRememberTool, MnemosynthRecallTool

    brain = Mnemosynth()

    researcher = Agent(
        role="Senior Researcher",
        tools=[MnemosynthRememberTool(brain=brain), MnemosynthRecallTool(brain=brain)],
    )

Requires: pip install mnemosynth[crewai]
"""

from __future__ import annotations

from typing import Any, Type

from mnemosynth import Mnemosynth


def _check_crewai() -> None:
    """Raise a helpful error if crewai is not installed."""
    try:
        import crewai_tools  # noqa: F401
    except ImportError:
        raise ImportError(
            "CrewAI adapter requires crewai-tools. "
            "Install with: pip install mnemosynth[crewai]"
        ) from None


# ---------------------------------------------------------------------------
# Remember Tool
# ---------------------------------------------------------------------------

class MnemosynthRememberTool:
    """CrewAI-compatible tool that stores a memory in Mnemosynth.

    Works as a CrewAI BaseTool via duck-typing so the import of crewai
    is deferred until the tool is actually called.
    """

    name: str = "mnemosynth_remember"
    description: str = (
        "Store important information in long-term AI memory. "
        "Input: a plain-text fact, preference, or observation to remember."
    )

    def __init__(self, brain: Mnemosynth | None = None, **kwargs: Any):
        self.brain = brain or Mnemosynth()
        # If crewai BaseTool is available, register dynamically
        self._try_register_as_base_tool()

    def _try_register_as_base_tool(self) -> None:
        """Attempt to inherit from CrewAI BaseTool at runtime."""
        try:
            from crewai_tools import BaseTool
            # Dynamically add BaseTool methods if available
            self.__class__.__bases__ = (BaseTool,) + self.__class__.__bases__
        except ImportError:
            pass  # Pure duck-typing fallback

    def _run(self, content: str) -> str:
        """Execute the tool — store a memory."""
        node = self.brain.remember(content)
        return (
            f"✅ Stored memory [{node.memory_type.value}] "
            f"(confidence: {node.confidence:.2f}): {node.content[:100]}"
        )

    def run(self, content: str) -> str:
        """Public entry point (CrewAI calls _run, but we support both)."""
        return self._run(content)


# ---------------------------------------------------------------------------
# Recall Tool
# ---------------------------------------------------------------------------

class MnemosynthRecallTool:
    """CrewAI-compatible tool that searches Mnemosynth memory.

    Returns the top-K results ranked by confidence × recency.
    """

    name: str = "mnemosynth_recall"
    description: str = (
        "Search long-term AI memory for relevant past information. "
        "Input: a natural-language query describing what to recall."
    )

    def __init__(self, brain: Mnemosynth | None = None, limit: int = 5, **kwargs: Any):
        self.brain = brain or Mnemosynth()
        self.limit = limit
        self._try_register_as_base_tool()

    def _try_register_as_base_tool(self) -> None:
        try:
            from crewai_tools import BaseTool
            self.__class__.__bases__ = (BaseTool,) + self.__class__.__bases__
        except ImportError:
            pass

    def _run(self, query: str) -> str:
        """Execute the tool — search memories."""
        results = self.brain.recall(query, limit=self.limit)
        if not results:
            return "No relevant memories found."

        lines = []
        for i, mem in enumerate(results, 1):
            lines.append(
                f"{i}. [{mem.memory_type.value}] "
                f"(conf: {mem.confidence:.2f}) {mem.content}"
            )
        return "\n".join(lines)

    def run(self, query: str) -> str:
        return self._run(query)


# ---------------------------------------------------------------------------
# Digest Tool
# ---------------------------------------------------------------------------

class MnemosynthDigestTool:
    """CrewAI-compatible tool that returns a compressed memory context block."""

    name: str = "mnemosynth_digest"
    description: str = (
        "Get a compressed summary of all relevant memories for a topic. "
        "Input: a query or topic to build context for."
    )

    def __init__(self, brain: Mnemosynth | None = None, **kwargs: Any):
        self.brain = brain or Mnemosynth()
        self._try_register_as_base_tool()

    def _try_register_as_base_tool(self) -> None:
        try:
            from crewai_tools import BaseTool
            self.__class__.__bases__ = (BaseTool,) + self.__class__.__bases__
        except ImportError:
            pass

    def _run(self, query: str) -> str:
        return self.brain.digest(query)

    def run(self, query: str) -> str:
        return self._run(query)


# ---------------------------------------------------------------------------
# Convenience factory
# ---------------------------------------------------------------------------

def get_crewai_tools(brain: Mnemosynth | None = None) -> list:
    """Return a list of all Mnemosynth CrewAI tools.

    Usage:
        tools = get_crewai_tools(brain)
        agent = Agent(role="...", tools=tools)
    """
    b = brain or Mnemosynth()
    return [
        MnemosynthRememberTool(brain=b),
        MnemosynthRecallTool(brain=b),
        MnemosynthDigestTool(brain=b),
    ]
