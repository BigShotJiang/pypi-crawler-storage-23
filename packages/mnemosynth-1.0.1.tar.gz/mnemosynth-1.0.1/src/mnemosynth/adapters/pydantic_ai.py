"""
MNEMOSYNTH × PydanticAI Adapter

Provides a pre-configured MCPServerStdio for PydanticAI agents.

Usage:
    from pydantic_ai import Agent
    from mnemosynth.adapters.pydantic_ai import get_mcp_server

    mnemosynth_server = get_mcp_server()

    agent = Agent(
        "openai:gpt-4o",
        mcp_servers=[mnemosynth_server],
        system_prompt="You have persistent memory via MNEMOSYNTH.",
    )

    result = agent.run_sync("What are the user's preferences?")

Requires: pip install mnemosynth[pydantic-ai]
"""

from __future__ import annotations

import shutil
import sys
from typing import Any


def get_mcp_server(**env_overrides: str) -> Any:
    """Return a PydanticAI MCPServerStdio wired to `mnemosynth serve`.

    Usage:
        server = get_mcp_server()
        agent = Agent("openai:gpt-4o", mcp_servers=[server])
    """
    try:
        from pydantic_ai.mcp import MCPServerStdio
    except ImportError:
        raise ImportError(
            "PydanticAI adapter requires pydantic-ai. "
            "Install with: pip install mnemosynth[pydantic-ai]"
        ) from None

    mnemosynth_bin = shutil.which("mnemosynth")
    command = mnemosynth_bin or sys.executable

    if mnemosynth_bin:
        args = ["serve"]
    else:
        args = ["-m", "mnemosynth", "serve"]

    env = {}
    env.update(env_overrides)

    return MCPServerStdio(
        command,
        args=args,
        env=env if env else None,
    )


def get_mcp_servers(**env_overrides: str) -> list[Any]:
    """Convenience: return a list containing the Mnemosynth MCP server.

    Usage:
        agent = Agent("openai:gpt-4o", mcp_servers=get_mcp_servers())
    """
    return [get_mcp_server(**env_overrides)]
