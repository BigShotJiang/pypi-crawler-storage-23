"""
MNEMOSYNTH × AutoGen Adapter

Provides helpers to connect Mnemosynth as an MCP tool server
to Microsoft AutoGen agents via McpWorkbench.

Usage:
    import asyncio
    from autogen_agentchat.agents import AssistantAgent
    from mnemosynth.adapters.autogen import create_mcp_workbench

    async def main():
        async with create_mcp_workbench() as workbench:
            agent = AssistantAgent(
                "research_assistant",
                workbench=workbench,
                system_message="You have access to persistent memory."
            )
            # Agent now has all 8 MNEMOSYNTH MCP tools

    asyncio.run(main())

Requires: pip install mnemosynth[autogen]
"""

from __future__ import annotations

import shutil
import sys
from typing import Any


def get_server_params(**env_overrides: str) -> Any:
    """Return StdioServerParams pre-configured for `mnemosynth serve`.

    This locates the `mnemosynth` CLI entry point and returns params
    compatible with autogen-ext's McpWorkbench.

    Args:
        **env_overrides: Extra environment variables, e.g.
            MNEMOSYNTH_DATA_DIR="~/custom-dir"
    """
    try:
        from autogen_ext.tools.mcp import StdioServerParams
    except ImportError:
        raise ImportError(
            "AutoGen adapter requires autogen-ext. "
            "Install with: pip install mnemosynth[autogen]"
        ) from None

    # Locate the mnemosynth binary
    mnemosynth_bin = shutil.which("mnemosynth")
    command = mnemosynth_bin or sys.executable

    if mnemosynth_bin:
        args = ["serve"]
    else:
        # Fallback: run as a Python module
        args = ["-m", "mnemosynth", "serve"]

    env = {}
    env.update(env_overrides)

    return StdioServerParams(
        command=command,
        args=args,
        env=env if env else None,
    )


async def create_mcp_workbench(**env_overrides: str) -> Any:
    """Create an AutoGen McpWorkbench connected to Mnemosynth.

    Returns an async context manager:
        async with create_mcp_workbench() as workbench:
            agent = AssistantAgent("name", workbench=workbench)

    The workbench exposes all 8 Mnemosynth MCP tools:
    add_memory, search_memory, get_digest, get_contradictions,
    run_dream, forget, get_stats, get_provenance.
    """
    try:
        from autogen_ext.tools.mcp import McpWorkbench
    except ImportError:
        raise ImportError(
            "AutoGen adapter requires autogen-ext. "
            "Install with: pip install mnemosynth[autogen]"
        ) from None

    params = get_server_params(**env_overrides)
    return McpWorkbench(params)


# ---------------------------------------------------------------------------
# Direct Python tools (no MCP, no subprocess)
# ---------------------------------------------------------------------------

def get_autogen_tools(brain: Any = None) -> list[dict[str, Any]]:
    """Return Mnemosynth tools as AutoGen function_tool dicts.

    For use when you prefer direct Python calls over MCP spawning.

    Usage:
        from mnemosynth.adapters.autogen import get_autogen_tools
        tools = get_autogen_tools()
        # Register with ConversableAgent.register_for_llm()
    """
    from mnemosynth import Mnemosynth
    b = brain or Mnemosynth()

    def remember(content: str) -> str:
        """Store information in long-term AI memory."""
        node = b.remember(content)
        return f"Stored [{node.memory_type.value}]: {node.content[:100]}"

    def recall(query: str, limit: int = 5) -> str:
        """Search long-term AI memory."""
        results = b.recall(query, limit=limit)
        if not results:
            return "No memories found."
        return "\n".join(
            f"[{m.memory_type.value}] ({m.confidence:.2f}) {m.content}"
            for m in results
        )

    def digest(query: str) -> str:
        """Get compressed memory context for a topic."""
        return b.digest(query)

    return [remember, recall, digest]
