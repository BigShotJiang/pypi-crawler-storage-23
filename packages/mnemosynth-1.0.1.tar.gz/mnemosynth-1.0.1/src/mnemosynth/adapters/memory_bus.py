"""
MNEMOSYNTH Memory Bus — Cross-Agent Shared Memory

Namespaced memory system that lets multiple agents share a single
Mnemosynth knowledge base while keeping their memories organized.

Usage:
    from mnemosynth.adapters.memory_bus import MemoryBus

    bus = MemoryBus()

    # Agent 1 stores in its own namespace
    bus.remember("User prefers dark mode", namespace="researcher")

    # Agent 2 reads from all namespaces
    results = bus.recall("user preferences", namespace="*")

    # Agent 2 reads only its own namespace
    results = bus.recall("user preferences", namespace="coder")

    # Digest across all agents
    digest = bus.digest("project setup", namespace="*")
"""

from __future__ import annotations

from typing import Any

from mnemosynth import Mnemosynth
from mnemosynth.core.types import MemoryNode


class MemoryBus:
    """Cross-agent shared memory layer with namespace isolation.

    Each namespace represents one agent's memory partition.
    Memories are tagged with `ns:<namespace>` so they can be
    filtered during retrieval.

    Namespace "*" queries across all agents' memories.
    """

    NAMESPACE_TAG_PREFIX = "ns:"

    def __init__(self, brain: Mnemosynth | None = None, data_dir: str | None = None):
        self.brain = brain or Mnemosynth(data_dir=data_dir)
        self._namespaces: set[str] = set()

    def _ns_tag(self, namespace: str) -> str:
        return f"{self.NAMESPACE_TAG_PREFIX}{namespace}"

    def remember(
        self,
        content: str,
        namespace: str = "default",
        memory_type: str = "auto",
    ) -> MemoryNode:
        """Store a memory within a namespace.

        Args:
            content: The text content to remember.
            namespace: Agent/component identifier (e.g., "researcher", "coder").
            memory_type: "auto", "episodic", "semantic", or "procedural".
        """
        self._namespaces.add(namespace)
        node = self.brain.remember(content, memory_type=memory_type)

        # Tag the node with the namespace
        ns_tag = self._ns_tag(namespace)
        if ns_tag not in node.tags:
            node.tags.append(ns_tag)
            # Re-save with updated tags
            self.brain.db.save_memory(node)

        return node

    def recall(
        self,
        query: str,
        namespace: str = "*",
        limit: int = 5,
    ) -> list[MemoryNode]:
        """Search memories, optionally filtered by namespace.

        Args:
            query: Natural-language search query.
            namespace: Filter to a specific agent's memories, or "*" for all.
            limit: Maximum results to return.
        """
        # Get more results than needed, then filter
        results = self.brain.recall(query, limit=limit * 3)

        if namespace == "*":
            return results[:limit]

        ns_tag = self._ns_tag(namespace)
        filtered = [m for m in results if ns_tag in m.tags]
        return filtered[:limit]

    def digest(
        self,
        query: str,
        namespace: str = "*",
        max_tokens: int = 150,
    ) -> str:
        """Get a compressed memory digest, optionally scoped to a namespace.

        For namespace="*", returns the full cross-agent digest.
        For a specific namespace, retrieves and filters first.
        """
        if namespace == "*":
            return self.brain.digest(query, max_tokens=max_tokens)

        # For scoped digests, recall relevant memories and format manually
        memories = self.recall(query, namespace=namespace, limit=10)
        if not memories:
            return "<memory_digest>No relevant memories found.</memory_digest>"

        lines = []
        for mem in memories:
            lines.append(
                f"  <memory type=\"{mem.memory_type.value}\" "
                f"confidence=\"{mem.confidence:.2f}\">"
                f"{mem.content}</memory>"
            )
        inner = "\n".join(lines)
        return f"<memory_digest namespace=\"{namespace}\">\n{inner}\n</memory_digest>"

    def dream(self, namespace: str | None = None) -> dict:
        """Run dream consolidation across the entire memory store.

        Note: Dream mode always runs on all memories regardless of namespace,
        because cross-namespace patterns are valuable for consolidation.
        """
        return self.brain.dream()

    def get_namespaces(self) -> list[str]:
        """Return all registered namespaces."""
        return sorted(self._namespaces)

    def stats(self, namespace: str | None = None) -> dict:
        """Get memory statistics, optionally for a specific namespace."""
        base_stats = self.brain.stats()

        if namespace is None:
            base_stats["namespaces"] = self.get_namespaces()
            return base_stats

        # Count memories in a specific namespace
        ns_tag = self._ns_tag(namespace)
        # This is approximate — we'd need to query the DB for exact counts
        base_stats["namespace"] = namespace
        base_stats["namespaces"] = self.get_namespaces()
        return base_stats

    def forget(self, memory_id: str) -> bool:
        """Remove a specific memory from any namespace."""
        return self.brain.forget(memory_id)


# ---------------------------------------------------------------------------
# Convenience: Multi-agent scenario helpers
# ---------------------------------------------------------------------------

def create_agent_memory(
    agent_name: str,
    brain: Mnemosynth | None = None,
) -> dict[str, Any]:
    """Create a set of memory functions scoped to a specific agent.

    Returns a dict of callables that can be used as tools:
        tools = create_agent_memory("researcher")
        tools["remember"]("User prefers Python")
        results = tools["recall"]("user preferences")
    """
    bus = MemoryBus(brain=brain)

    def remember(content: str) -> str:
        node = bus.remember(content, namespace=agent_name)
        return f"[{agent_name}] Stored: {node.content[:100]}"

    def recall(query: str, limit: int = 5) -> str:
        results = bus.recall(query, namespace=agent_name, limit=limit)
        if not results:
            return f"[{agent_name}] No memories found."
        return "\n".join(
            f"({m.confidence:.2f}) {m.content}" for m in results
        )

    def recall_all(query: str, limit: int = 5) -> str:
        results = bus.recall(query, namespace="*", limit=limit)
        if not results:
            return "No shared memories found."
        return "\n".join(
            f"({m.confidence:.2f}) {m.content}" for m in results
        )

    def digest(query: str) -> str:
        return bus.digest(query, namespace=agent_name)

    return {
        "remember": remember,
        "recall": recall,
        "recall_all": recall_all,
        "digest": digest,
        "bus": bus,
    }
