"""Custom exceptions for lysqlnb."""


class NotebookParseError(Exception):
    """Raised when a notebook file cannot be parsed."""
