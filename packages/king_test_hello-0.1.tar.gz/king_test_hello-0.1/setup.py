from setuptools import setup, find_packages

setup(
    name='king_test_hello',
    version='0.1',
    packages=find_packages(),
    description='A simple package to test the hello function',
    author='Kingsley Asare',
    author_email='kingsleyasare20@yahoo.com',
)