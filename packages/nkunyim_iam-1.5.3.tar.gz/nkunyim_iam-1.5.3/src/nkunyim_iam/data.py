from datetime import datetime
from typing import Optional
from uuid import UUID
from pydantic import BaseModel



class UserinfoData(BaseModel):
    id: UUID
    username: str
    nickname: str
    first_name: str
    middle_name: Optional[str] = None
    last_name: str
    email_address: str
    email_verified: bool
    email_verified_at: Optional[datetime] = None
    phone_number: str
    phone_verified: bool
    phone_verified_at: Optional[datetime] = None
    serial: Optional[str] = None
    gender: str
    birth_date: Optional[datetime] = None
    photo_url: Optional[str] = None
    photo_verified: bool
    photo_verified_at: Optional[datetime] = None
    profile: Optional[str] = None
    is_pwd: bool
    is_active: bool
    is_admin: bool
    is_superuser: bool
    is_verified: bool


class ClaimData(BaseModel):
    user: UserinfoData
    roles: list[str] = []


class AccessTokenData(BaseModel):
    exp: int
    nbf: int
    iss: str
    aud: str
    iat: int
    sub: UUID
    sid: UUID
    jti: UUID
    azp: str
    access: ClaimData
    scope: str


class RefreshTokenData(BaseModel):
    exp: int
    iat: int
    sub: UUID
    sid: UUID
    jti: UUID
    azp: str


class TokenData(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str
    expires_in: int
    expires_at: datetime
    scope: str


class SessionData(BaseModel):
    code: str = ""
    verifier: str = ""
    state: str = ""
    nonce: str = ""
    next: str = "/home/"
    token: Optional[TokenData] = None

