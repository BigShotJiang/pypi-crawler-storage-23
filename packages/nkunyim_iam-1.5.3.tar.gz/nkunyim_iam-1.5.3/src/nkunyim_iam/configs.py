from enum import Enum
from uuid import UUID
from pydantic import BaseModel, ConfigDict



class ServiceConfig(BaseModel):
    name: str
    back_url: str
    front_url: str
    key: str
    verify: bool = False
    

class HashingAlgo(str, Enum):
    S256 = "S256"
    S384 = "S384"
    S512 = "S512"


class EnryptionAlgo(str, Enum):
    HS256 = "HS256"
    RS256 = "RS256"
    PS256 = "PS256"
    EdDSA = "EdDSA"
    ES256 = "ES256"


class AuthConfig(BaseModel):
    model_config = ConfigDict(use_enum_values=True)
    back_url: str = "http://auth.nkunyim.local"
    front_url: str = "https://auth.nkunyim.local"
    issuer: str = "https://auth.nkunyim.local"
    client_id: UUID
    client_secret: str
    client_name: str
    client_scope: str = "openid profile email phone offline_access"
    redirect_uri: str = "https://app.nkunyim.local/auth/callback/"
    grant_type: str = "authorization_code"
    response_type: str = "code"
    encryption_algo: EnryptionAlgo = EnryptionAlgo.RS256
    hashing_algo: HashingAlgo = HashingAlgo.S256
    authorize_path: str = "/auth/authorize/"
    userinfo_path: str = "/iam/users/userinfo/"
    token_path: str = "/auth/token/"
    logout_path: str = "/auth/logout/"
