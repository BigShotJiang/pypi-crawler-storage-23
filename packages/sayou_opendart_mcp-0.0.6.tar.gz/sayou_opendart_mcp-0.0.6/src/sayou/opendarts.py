import logging
import os
from datetime import datetime
from typing import Any, Optional

from fastmcp import FastMCP
from sayou.stock.opendart import OpenDartCrawler

logger = logging.getLogger(__name__)
logging.basicConfig(format="[%(levelname)s]: %(message)s", level=logging.INFO)

corpcode_filename = "corpcode.json"

# OpenDart API 키 불러오기
DART_API_KEY = os.environ.get("DART_API_KEY")
if not DART_API_KEY:
    raise ValueError("DART_API_KEY 환경 변수가 설정되지 않았습니다.")
# OpenDartCrawler를 초기화
crawler = OpenDartCrawler(api_key=DART_API_KEY)  # type: ignore
if not crawler.corp_data:
    crawler.save_corp_data(corpcode_filename)

mcp = FastMCP("OpenDart MCP Server")


@mcp.tool(
    name="find_opendart_finance",
    description="""OpenDART에서 한국 주식 재무제표 3종을 수집합니다.
    사용 대상:
    - 6자리 숫자 티커: 005930, 000660
    - .KS/.KQ 접미사: 005930.KS, 035720.KQ
    - 한국 기업명: 삼성전자, SK하이닉스

    반환: {
        "stock": str,
        "year": int,
        "quarter": int,
        "balance_sheet": str | None,      # JSON 문자열
        "income_statement": str | None,   # JSON 문자열
        "cash_flow": str | None           # JSON 문자열
    }

    참고: 크롤링은 최대 60초 이상 소요될 수 있습니다.
    """,
    tags={"opendart", "fundamentals", "korea", "standardized"},
)
async def find_opendart_finance(
    stock: str, year: Optional[int] = None, quarter: Optional[int] = None
):
    """
    OpenDART에서 한국 주식 재무제표 3종을 수집합니다.

    Args:
        stock: 종목 코드 (예: "005930", "삼성전자")
        year: 연도
        quarter: 분기

    Returns:
        dict: 재무제표 3종
    """
    logger.info(f">>> 🛠️ Tool: 'find_opendart_finance' called for '{stock}'")

    # 년도와 분기 정보가 있는지 확인하고,
    # 없으면 오늘 기준으로 이전 분기를 설정합니다.
    is_date = year is not None and quarter is not None
    year, quarter = _year_quarter(year, quarter)

    corp_code = crawler.fetch_corp_code(stock)

    # 단일회사 전체 재무제표
    count = 1
    data: list[Any] = []
    while True:
        logger.info(f"fetching finance data: {year}Q{quarter}")
        data = crawler.financial_statements(corp_code, str(year), quarter=quarter)
        if is_date or len(data) > 0 or count > 4:
            break
        quarter = quarter - 1 if quarter > 1 else 4
        year = year - 1 if quarter == 4 else year
        count += 1

    return [item.to_dict() for item in data]


@mcp.tool(
    name="find_opendart_dividend",
    description="""OpenDART에서 주식 배당 정보 수집.
    사용 대상:
    - 6자리 숫자 티커: 005930, 000660
    - .KS/.KQ 접미사: 005930.KS, 035720.KQ
    - 한국 기업명: 삼성전자, SK하이닉스

    반환: {
        "stock": str,
        "year": int,
        "quarter": int,
        "dividend": json,
    }

    참고: 크롤링은 최대 60초 이상 소요될 수 있습니다.
    """,
    tags={"opendart", "dividend", "korea", "standardized"},
)
async def find_opendart_dividend(
    stock: str, year: Optional[int] = None, quarter: Optional[int] = None
):
    """
    OpenDART에서 한국 주식 배당 정보를 수집합니다.

    Args:
        stock: 종목 코드 (예: "005930", "삼성전자")
        year: 연도
        quarter: 분기

    Returns:
        dict: 배당 정보
    """
    logger.info(f">>> 🛠️ Tool: 'find_opendart_dividend' called for '{stock}'")

    data = _find_dividend(stock, year, quarter)

    return [item.to_dict() for item in data]


@mcp.tool(
    name="find_opendart_compensation",
    description="""OpenDART에서 한국 기업의 이사 및 감사 보수 정보 수집.
    사용 대상:
    - 6자리 숫자 티커: 005930, 000660
    - .KS/.KQ 접미사: 005930.KS, 035720.KQ
    - 한국 기업명: 삼성전자, SK하이닉스

    반환: {
        "stock": str,
        "year": int,
        "quarter": int,
        "compensation": json,
    }

    참고: 크롤링은 최대 60초 이상 소요될 수 있습니다.
    """,
    tags={"opendart", "compensation", "korea", "standardized"},
)
async def find_opendart_compensation(
    stock: str, year: Optional[int] = None, quarter: Optional[int] = None
):
    """
    OpenDART에서 기업의 이사 및 감사 보수 정보를 수집합니다.

    Args:
        stock: 종목 코드 (예: "005930", "삼성전자")
        year: 연도
        quarter: 분기

    Returns:
        dict: 이사 및 감사 보수 정보
    """
    logger.info(f">>> 🛠️ Tool: 'find_opendart_compensation' called for '{stock}'")

    is_date = year is not None and quarter is not None
    year, quarter = _year_quarter(year, quarter)

    corp_code = crawler.fetch_corp_code(stock)

    outputs: list[dict[str, Any]] = []

    orig_year, orig_quarter = year, quarter

    # 이사·감사의 개인별 보수현황(5억원 이상)
    count = 1
    data: list[Any] = []
    while True:
        logger.info(f"fetching finance data: {year}Q{quarter}")
        data = (
            crawler.director_compensation(corp_code, year=str(year), quarter=quarter)
            or []
        )
        if is_date or len(data) > 0 or count > 4:
            break
        quarter = quarter - 1 if quarter > 1 else 4
        year = year - 1 if quarter == 4 else year
        count += 1

    for item in data:
        outputs.append(item.to_dict())

    # 이사·감사 전체의 보수현황(보수지급금액 - 이사·감사 전체)
    year, quarter = orig_year, orig_quarter
    count = 1
    data = []
    while True:
        logger.info(f"fetching finance data: {year}Q{quarter}")
        data = (
            crawler.total_director_compensation(
                corp_code, year=str(year), quarter=quarter
            )
            or []
        )
        if is_date or len(data) > 0 or count > 4:
            break
        quarter = quarter - 1 if quarter > 1 else 4
        year = year - 1 if quarter == 4 else year
        count += 1

    for item in data:
        outputs.append(item.to_dict())

    # 개인별 보수지급 금액(5억이상 상위5인)
    year, quarter = orig_year, orig_quarter
    count = 1
    data = []
    while True:
        logger.info(f"fetching finance data: {year}Q{quarter}")
        data = (
            crawler.top5_director_compensation(
                corp_code, year=str(year), quarter=quarter
            )
            or []
        )
        if is_date or len(data) > 0 or count > 4:
            break
        quarter = quarter - 1 if quarter > 1 else 4
        year = year - 1 if quarter == 4 else year
        count += 1

    for item in data:
        outputs.append(item.to_dict())

    return outputs


@mcp.prompt()
def dividend(stock: str, year: Optional[int] = None, quarter: Optional[int] = None):
    """Find dividend information of a company."""

    return (
        f"{stock}의 {year}년 {quarter}분기 배당 정보를 찾았습니다."
        f"문서번호, 기업코드, 기업명, 당기순이익(백만원), 현금배당수익률(%), 주당순이익(원), 주당 현금배당금(원), 현금배당성향(%), 현금배당금총액(백만원)을 응답합니다."
    )


@mcp.prompt()
def finance(stock: str, year: Optional[int] = None, quarter: Optional[int] = None):
    """Find financial statements of a company."""

    return (
        f"{stock}의 {year}년 {quarter}분기 재무제표를 찾았습니다."
        # f"문서번호, 기업코드, 기업명, 당기순이익(백만원), 현금배당수익률(%), 주당순이익(원), 주당 현금배당금(원), 현금배당성향(%), 현금배당금총액(백만원)을 응답합니다."
    )


@mcp.prompt()
def compensation(stock: str, year: Optional[int] = None):
    """Find director's compensation of a company."""

    return (
        f"{stock}의 {year}년 이사 및 감사 보수 정보를 찾았습니다."
        # f"문서번호, 기업코드, 기업명, 당기순이익(백만원), 현금배당수익률(%), 주당순이익(원), 주당 현금배당금(원), 현금배당성향(%), 현금배당금총액(백만원)을 응답합니다."
    )


def _find_dividend(
    stock: str, year: Optional[int] = None, quarter: Optional[int] = None
) -> list[Any]:
    is_date = year is not None and quarter is not None
    year, quarter = _year_quarter(year, quarter)

    corp_code = crawler.fetch_corp_code(stock)

    count = 1
    data: list[Any] = []
    while True:
        logger.info(f"fetching finance data: {year}Q{quarter}")
        data = crawler.dividends(corp_code, year=str(year), quarter=quarter) or []
        if is_date or len(data) > 0 or count > 4:
            break
        quarter = quarter - 1 if quarter > 1 else 4
        year = year - 1 if quarter == 4 else year
        count += 1

    return data


def _year_quarter(year: Optional[int], quarter: Optional[int]) -> tuple[int, int]:
    now = datetime.now()
    q = (now.month - 1) // 3
    default_year, default_quarter = (now.year - 1, 4) if q == 0 else (now.year, q)

    resolved_year = year or default_year
    resolved_quarter = quarter or (4 if resolved_year < now.year else default_quarter)

    return resolved_year, resolved_quarter
