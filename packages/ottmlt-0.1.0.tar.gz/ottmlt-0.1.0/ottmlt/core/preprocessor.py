"""
Text preprocessing for OTT content catalogs.

The Preprocessor turns a DataFrame of media items into a list of "soup" strings
(one per item) that can be fed into a vectorizer.  Fields can be weighted by
repeating them: a field with weight=3 is concatenated three times so the
TF-IDF vectorizer naturally up-weights its tokens.
"""

import math
import re
import unicodedata
from typing import Dict, List, Optional

import pandas as pd


class Preprocessor:
    """Build a weighted text soup from catalog DataFrame fields.

    Parameters
    ----------
    text_fields : list of str
        Column names to include in the soup (must exist in the catalog).
    field_weights : dict, optional
        ``{field_name: repeat_count}`` — higher repeat means higher weight.
        Fields not listed default to weight 1.
    separator : str
        Token used to join fields. Defaults to a single space.

    Examples
    --------
    >>> prep = Preprocessor(
    ...     text_fields=["title", "description", "genre", "cast"],
    ...     field_weights={"title": 3, "genre": 2},
    ... )
    >>> soups = prep.transform(catalog_df)
    """

    def __init__(
        self,
        text_fields: List[str],
        field_weights: Optional[Dict[str, int]] = None,
        separator: str = " ",
    ):
        if not text_fields:
            raise ValueError("`text_fields` must contain at least one field name.")
        self.text_fields = text_fields
        self.field_weights = field_weights or {}
        self.separator = separator

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def transform(self, df: pd.DataFrame) -> List[str]:
        """Return one soup string per row in *df*.

        Parameters
        ----------
        df : pd.DataFrame
            Catalog with columns that include ``self.text_fields``.

        Returns
        -------
        list of str
            A list of the same length as *df*.
        """
        missing = [f for f in self.text_fields if f not in df.columns]
        if missing:
            raise ValueError(
                f"The following fields are missing from the catalog: {missing}"
            )

        soups = []
        for _, row in df.iterrows():
            soups.append(self._build_soup(row))
        return soups

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _build_soup(self, row: pd.Series) -> str:
        parts = []
        for field in self.text_fields:
            weight = self.field_weights.get(field, 1)
            raw = row.get(field, "")
            # Treat None and float NaN as empty
            if raw is None or (isinstance(raw, float) and math.isnan(raw)):
                raw = ""
            cleaned = self._clean(str(raw))
            if cleaned:
                parts.extend([cleaned] * weight)
        return self.separator.join(parts)

    @staticmethod
    def _clean(text: str) -> str:
        """Lowercase, unicode-normalise, and strip punctuation."""
        # Normalise unicode (e.g. accented chars → ASCII where possible)
        text = unicodedata.normalize("NFKD", text)
        text = text.encode("ascii", "ignore").decode("ascii")
        text = text.lower()
        # Replace list-style separators (comma, pipe, semicolon) with spaces
        text = re.sub(r"[,|;/]", " ", text)
        # Remove non-alphanumeric characters except spaces
        text = re.sub(r"[^a-z0-9\s]", " ", text)
        # Collapse whitespace
        text = re.sub(r"\s+", " ", text).strip()
        return text
