"""
Efficient cosine-similarity utilities for recommendation.

We deliberately avoid materialising a full N×N dense matrix when the catalog
is large.  Instead we compute only the top-N scores for a single query row,
which keeps memory and compute proportional to the catalog size (not its square).
"""

from typing import List, Tuple

import numpy as np
from scipy.sparse import issparse


def cosine_similarity_top_n(
    query_vector,
    corpus_matrix,
    top_n: int = 10,
    exclude_indices: List[int] = None,
) -> List[Tuple[int, float]]:
    """Return the top-N (index, score) pairs most similar to *query_vector*.

    Works with both sparse (scipy CSR/CSC) and dense (numpy ndarray) inputs.

    Parameters
    ----------
    query_vector :
        Shape ``(1, n_features)`` — the item we want neighbours for.
    corpus_matrix :
        Shape ``(n_items, n_features)`` — the full catalog matrix.
    top_n : int
        Number of results to return.
    exclude_indices : list of int, optional
        Row indices to exclude from results (e.g. the query item itself).

    Returns
    -------
    list of (index, score) tuples, sorted by descending score.
    """
    exclude_indices = set(exclude_indices or [])

    if issparse(query_vector):
        query_vector = query_vector.toarray()
    if issparse(corpus_matrix):
        corpus_matrix = corpus_matrix.toarray()

    query_vector = np.asarray(query_vector, dtype=np.float32).ravel()
    corpus_matrix = np.asarray(corpus_matrix, dtype=np.float32)

    # Cosine similarity = dot(q, C^T) / (||q|| * ||C||)
    query_norm = np.linalg.norm(query_vector)
    if query_norm == 0:
        return []

    corpus_norms = np.linalg.norm(corpus_matrix, axis=1)
    # Avoid division by zero for zero-norm rows
    safe_norms = np.where(corpus_norms == 0, 1e-10, corpus_norms)

    scores = corpus_matrix.dot(query_vector) / (safe_norms * query_norm)

    # Zero out excluded indices
    for idx in exclude_indices:
        if 0 <= idx < len(scores):
            scores[idx] = -1.0

    # Partial sort — faster than full sort for large catalogs
    actual_top_n = min(top_n + len(exclude_indices), len(scores))
    top_indices = np.argpartition(scores, -actual_top_n)[-actual_top_n:]
    top_indices = top_indices[np.argsort(scores[top_indices])[::-1]]

    results = []
    for idx in top_indices:
        if idx not in exclude_indices and len(results) < top_n:
            results.append((int(idx), float(scores[idx])))

    return results
