"""
MoreLikeThis — the high-level public API for ottmlt.

This class is the single entry-point that most users will interact with.
It wraps the lower-level model classes and handles catalog management,
ID-to-index mapping, and result formatting.
"""

from typing import Any, Dict, List, Optional, Union

import pandas as pd

from ottmlt.core.preprocessor import Preprocessor


_DEFAULT_TEXT_FIELDS = ["title", "description", "genre", "cast", "director"]
_DEFAULT_FIELD_WEIGHTS = {"title": 3, "genre": 2, "director": 2}


class MoreLikeThis:
    """Content-based "more like this" recommender for OTT media catalogs.

    Parameters
    ----------
    text_fields : list of str, optional
        Catalog columns to use for similarity.  Defaults to
        ``["title", "description", "genre", "cast", "director"]``.
    field_weights : dict, optional
        Repeat-count per field (higher → stronger influence).
        Defaults to ``{"title": 3, "genre": 2, "director": 2}``.
    model : {"tfidf", "embedding", "hybrid"}
        Which underlying model to use.
        - ``"tfidf"`` — fast, no GPU, works out-of-the-box (default).
        - ``"embedding"`` — semantic, requires ``pip install ottmlt[embedding]``.
        - ``"hybrid"`` — weighted mix of tfidf + embedding.
    id_col : str
        Column in the catalog DataFrame that uniquely identifies each item.
        Defaults to ``"id"``.
    **model_kwargs
        Extra keyword arguments forwarded to the underlying model constructor.

    Examples
    --------
    >>> import pandas as pd
    >>> from ottmlt import MoreLikeThis
    >>> from ottmlt.utils.data import load_sample_catalog
    >>>
    >>> catalog = load_sample_catalog()
    >>> mlt = MoreLikeThis()
    >>> mlt.fit(catalog)
    MoreLikeThis(model='tfidf', n_items=50)
    >>> recs = mlt.recommend("tt0111161", n=5)
    >>> print(recs[["id", "title", "similarity_score"]])
    """

    def __init__(
        self,
        text_fields: Optional[List[str]] = None,
        field_weights: Optional[Dict[str, int]] = None,
        model: str = "tfidf",
        id_col: str = "id",
        **model_kwargs: Any,
    ):
        self.text_fields = text_fields or _DEFAULT_TEXT_FIELDS
        self.field_weights = field_weights or _DEFAULT_FIELD_WEIGHTS
        self.model_name = model
        self.id_col = id_col
        self.model_kwargs = model_kwargs

        self._catalog: Optional[pd.DataFrame] = None
        self._id_to_idx: Dict[Any, int] = {}
        self._model = None
        self._preprocessor = Preprocessor(
            text_fields=self.text_fields,
            field_weights=self.field_weights,
        )

    # ------------------------------------------------------------------
    # Fit
    # ------------------------------------------------------------------

    def fit(self, catalog: pd.DataFrame) -> "MoreLikeThis":
        """Fit the recommender on a media catalog.

        Parameters
        ----------
        catalog : pd.DataFrame
            Must contain ``id_col`` and the columns specified in ``text_fields``
            (missing text columns are filled with empty strings).

        Returns
        -------
        self
        """
        if self.id_col not in catalog.columns:
            raise ValueError(
                f"id_col '{self.id_col}' not found in catalog. "
                f"Available columns: {list(catalog.columns)}"
            )

        # Fill missing text fields silently
        for field in self.text_fields:
            if field not in catalog.columns:
                catalog = catalog.copy()
                catalog[field] = ""

        self._catalog = catalog.reset_index(drop=True)
        self._id_to_idx = {
            row[self.id_col]: idx
            for idx, row in self._catalog.iterrows()
        }

        soups = self._preprocessor.transform(self._catalog)
        self._model = self._build_model(soups)
        return self

    # ------------------------------------------------------------------
    # Recommend
    # ------------------------------------------------------------------

    def recommend(
        self,
        item_id: Any,
        n: int = 10,
        filters: Optional[Dict[str, Any]] = None,
    ) -> pd.DataFrame:
        """Return the top-N most similar items for *item_id*.

        Parameters
        ----------
        item_id :
            The ID of the seed item (must exist in the fitted catalog).
        n : int
            Number of recommendations to return.
        filters : dict, optional
            Column-value pairs to restrict results, e.g.
            ``{"genre": "Drama", "language": "English"}``.
            Supports a single value *or* a list of accepted values per key.

        Returns
        -------
        pd.DataFrame
            The catalog rows of recommended items, plus a ``similarity_score``
            column, sorted by descending similarity.

        Raises
        ------
        RuntimeError
            If ``fit()`` has not been called yet.
        KeyError
            If *item_id* is not in the fitted catalog.
        """
        self._check_fitted()

        if item_id not in self._id_to_idx:
            raise KeyError(
                f"item_id '{item_id}' not found in catalog. "
                "Make sure you called fit() with a catalog that contains this ID."
            )

        query_idx = self._id_to_idx[item_id]

        # Determine candidate pool after filtering
        candidate_mask = self._apply_filters(filters)
        # Always exclude the query item from results
        candidate_mask[query_idx] = False
        candidate_indices = list(candidate_mask[candidate_mask].index)

        if not candidate_indices:
            return pd.DataFrame(columns=list(self._catalog.columns) + ["similarity_score"])

        results = self._model.get_similar(
            query_idx=query_idx,
            candidate_indices=candidate_indices,
            top_n=n,
        )

        if not results:
            return pd.DataFrame(columns=list(self._catalog.columns) + ["similarity_score"])

        rec_indices, scores = zip(*results)
        recs = self._catalog.iloc[list(rec_indices)].copy()
        recs["similarity_score"] = [round(s, 4) for s in scores]
        return recs.reset_index(drop=True)

    # ------------------------------------------------------------------
    # Convenience
    # ------------------------------------------------------------------

    def get_item(self, item_id: Any) -> pd.Series:
        """Return the catalog row for *item_id*."""
        self._check_fitted()
        idx = self._id_to_idx.get(item_id)
        if idx is None:
            raise KeyError(f"item_id '{item_id}' not found in catalog.")
        return self._catalog.iloc[idx]

    @property
    def catalog(self) -> Optional[pd.DataFrame]:
        """The fitted catalog (read-only)."""
        return self._catalog

    @property
    def n_items(self) -> int:
        return len(self._catalog) if self._catalog is not None else 0

    def __repr__(self) -> str:
        return (
            f"MoreLikeThis(model='{self.model_name}', n_items={self.n_items})"
        )

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _build_model(self, soups: List[str]):
        if self.model_name == "tfidf":
            from ottmlt.models.tfidf import TFIDFRecommender
            m = TFIDFRecommender(**self.model_kwargs)
        elif self.model_name == "embedding":
            from ottmlt.models.embedding import EmbeddingRecommender
            m = EmbeddingRecommender(**self.model_kwargs)
        elif self.model_name == "hybrid":
            from ottmlt.models.hybrid import HybridRecommender
            m = HybridRecommender(**self.model_kwargs)
        else:
            raise ValueError(
                f"Unknown model '{self.model_name}'. "
                "Choose from: 'tfidf', 'embedding', 'hybrid'."
            )
        m.fit(soups)
        return m

    def _apply_filters(
        self, filters: Optional[Dict[str, Any]]
    ) -> pd.Series:
        """Return a boolean mask of catalog rows that pass all filters."""
        mask = pd.Series([True] * len(self._catalog), index=self._catalog.index)
        if not filters:
            return mask
        for col, values in filters.items():
            if col not in self._catalog.columns:
                continue
            if not isinstance(values, list):
                values = [values]
            mask &= self._catalog[col].isin(values)
        return mask

    def _check_fitted(self) -> None:
        if self._model is None or self._catalog is None:
            raise RuntimeError(
                "This MoreLikeThis instance is not fitted yet. "
                "Call fit(catalog) before recommend()."
            )
