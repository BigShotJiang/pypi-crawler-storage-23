"""
Utilities for loading and validating OTT content catalogs.
"""

import os
from pathlib import Path
from typing import List, Optional

import pandas as pd


_SAMPLE_CATALOG_PATH = Path(__file__).parent.parent / "data" / "sample_catalog.csv"

REQUIRED_COLUMNS = ["id"]
RECOMMENDED_COLUMNS = ["title", "description", "genre", "cast", "director", "language"]


def load_sample_catalog() -> pd.DataFrame:
    """Load the bundled sample OTT catalog (50 titles).

    This is great for quick experimentation and running the examples.

    Returns
    -------
    pd.DataFrame
        Columns: id, title, description, genre, cast, director, language,
        content_type, year, rating.

    Examples
    --------
    >>> from ottmlt.utils.data import load_sample_catalog
    >>> catalog = load_sample_catalog()
    >>> print(catalog.shape)
    (50, 10)
    """
    return pd.read_csv(_SAMPLE_CATALOG_PATH)


def validate_catalog(
    catalog: pd.DataFrame,
    text_fields: Optional[List[str]] = None,
    id_col: str = "id",
) -> None:
    """Validate a catalog DataFrame and warn about potential issues.

    Parameters
    ----------
    catalog : pd.DataFrame
        Your media catalog.
    text_fields : list of str, optional
        The text columns you intend to use for recommendations.
    id_col : str
        The column used as the unique item identifier.

    Raises
    ------
    ValueError
        If ``id_col`` is missing or if there are duplicate IDs.

    Warns
    -----
    UserWarning
        If recommended columns are missing or have high null rates.
    """
    import warnings

    if id_col not in catalog.columns:
        raise ValueError(
            f"id_col '{id_col}' not found. Available columns: {list(catalog.columns)}"
        )

    if catalog[id_col].duplicated().any():
        n_dupes = catalog[id_col].duplicated().sum()
        raise ValueError(
            f"Found {n_dupes} duplicate values in '{id_col}'. IDs must be unique."
        )

    if text_fields:
        missing_fields = [f for f in text_fields if f not in catalog.columns]
        if missing_fields:
            warnings.warn(
                f"text_fields not found in catalog (will be treated as empty): "
                f"{missing_fields}",
                UserWarning,
                stacklevel=2,
            )

        for field in text_fields:
            if field in catalog.columns:
                null_rate = catalog[field].isna().mean()
                if null_rate > 0.5:
                    warnings.warn(
                        f"Column '{field}' has {null_rate:.0%} null values. "
                        "Consider filling or dropping it.",
                        UserWarning,
                        stacklevel=2,
                    )
