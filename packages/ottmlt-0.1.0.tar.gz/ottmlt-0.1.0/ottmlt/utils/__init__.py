from ottmlt.utils.data import load_sample_catalog

__all__ = ["load_sample_catalog"]
