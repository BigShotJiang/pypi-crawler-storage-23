"""
ottmlt — More-Like-This recommendation engine for OTT/Media platforms.

Quick start
-----------
>>> import pandas as pd
>>> from ottmlt import MoreLikeThis
>>>
>>> catalog = pd.read_csv("my_catalog.csv")  # id, title, description, genre, cast, director
>>> mlt = MoreLikeThis(text_fields=["title", "description", "genre", "cast"])
>>> mlt.fit(catalog)
>>> recs = mlt.recommend("tt0111161", n=10)
>>> print(recs[["id", "title", "similarity_score"]])
"""

from ottmlt.core.recommender import MoreLikeThis
from ottmlt.core.preprocessor import Preprocessor
from ottmlt.models.tfidf import TFIDFRecommender
from ottmlt.models.hybrid import HybridRecommender

__version__ = "0.1.0"
__author__ = "ottmlt contributors"
__license__ = "MIT"

__all__ = [
    "MoreLikeThis",
    "Preprocessor",
    "TFIDFRecommender",
    "HybridRecommender",
    "__version__",
]
