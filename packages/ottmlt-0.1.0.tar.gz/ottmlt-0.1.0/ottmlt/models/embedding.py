"""
Sentence-Transformer based semantic recommender (optional dependency).

Install with:  pip install "ottmlt[embedding]"

Why embeddings for OTT?
- "A heart-warming family drama" and "emotional story about parents and children"
  are semantically similar but share almost no tokens.  TF-IDF misses this;
  a sentence transformer captures it.
- Useful for cold-start items with thin metadata (just a description).

Trade-offs vs TF-IDF:
- Requires a ~90 MB model download on first use.
- Fit time is slower (GPU helps but not required).
- Inference is slower at query time.
"""

from typing import List, Optional, Tuple

import numpy as np

from ottmlt.core.similarity import cosine_similarity_top_n


_DEFAULT_MODEL = "all-MiniLM-L6-v2"


class EmbeddingRecommender:
    """Sentence-Transformer cosine-similarity recommender.

    Parameters
    ----------
    model_name : str
        Any model from https://www.sbert.net/docs/pretrained_models.html.
        Defaults to ``"all-MiniLM-L6-v2"`` — a good balance of speed and
        quality (384-dim, ~90 MB, ~14k sentences/sec on CPU).
    batch_size : int
        Batch size for encoding. Increase if you have GPU.
    show_progress_bar : bool
        Show tqdm progress during encoding.
    """

    def __init__(
        self,
        model_name: str = _DEFAULT_MODEL,
        batch_size: int = 64,
        show_progress_bar: bool = False,
    ):
        self.model_name = model_name
        self.batch_size = batch_size
        self.show_progress_bar = show_progress_bar
        self._embeddings: Optional[np.ndarray] = None
        self._encoder = None

    # ------------------------------------------------------------------
    # Fit / predict
    # ------------------------------------------------------------------

    def fit(self, soups: List[str]) -> "EmbeddingRecommender":
        """Encode the corpus using sentence-transformers.

        Parameters
        ----------
        soups : list of str
            One pre-processed text string per catalog item.

        Returns
        -------
        self

        Raises
        ------
        ImportError
            If ``sentence-transformers`` is not installed.
        """
        try:
            from sentence_transformers import SentenceTransformer
        except ImportError as e:
            raise ImportError(
                "EmbeddingRecommender requires sentence-transformers. "
                "Install it with:  pip install 'ottmlt[embedding]'"
            ) from e

        self._encoder = SentenceTransformer(self.model_name)
        self._embeddings = self._encoder.encode(
            soups,
            batch_size=self.batch_size,
            show_progress_bar=self.show_progress_bar,
            convert_to_numpy=True,
            normalize_embeddings=True,  # L2-normalise → dot product == cosine sim
        )
        return self

    def get_similar(
        self,
        query_idx: int,
        candidate_indices: List[int],
        top_n: int = 10,
    ) -> List[Tuple[int, float]]:
        """Return top-N (index, score) pairs for the item at *query_idx*."""
        self._check_fitted()
        query_vec = self._embeddings[query_idx]
        candidate_matrix = self._embeddings[candidate_indices]

        raw_results = cosine_similarity_top_n(
            query_vector=query_vec,
            corpus_matrix=candidate_matrix,
            top_n=top_n,
        )
        return [(candidate_indices[local_idx], score) for local_idx, score in raw_results]

    def encode(self, texts: List[str]) -> np.ndarray:
        """Encode arbitrary texts using the fitted encoder (for custom use)."""
        self._check_fitted()
        return self._encoder.encode(
            texts,
            batch_size=self.batch_size,
            convert_to_numpy=True,
            normalize_embeddings=True,
        )

    def _check_fitted(self) -> None:
        if self._embeddings is None:
            raise RuntimeError("EmbeddingRecommender is not fitted. Call fit() first.")
