"""
TF-IDF based content recommender.

This is the default, zero-dependency model.  It uses scikit-learn's
TfidfVectorizer to build a term-frequency/inverse-document-frequency
matrix over the content "soup" strings, then retrieves neighbours via
cosine similarity.

Why TF-IDF for OTT?
- "Action Thriller" as a genre token will get a high IDF weight because
  not all titles are thrillers — so it discriminates well.
- Director and actor names are typically rare tokens, making them strong
  discriminators between titles.
- Fast to fit (<1 s for a 50 k title catalog on a laptop).
"""

from typing import List, Tuple

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer

from ottmlt.core.similarity import cosine_similarity_top_n


class TFIDFRecommender:
    """TF-IDF cosine-similarity recommender.

    Parameters
    ----------
    max_features : int, optional
        Maximum vocabulary size for the TF-IDF vectorizer.
        ``None`` means no limit (default).
    ngram_range : tuple
        ``(min_n, max_n)`` n-gram range. ``(1, 2)`` includes both unigrams
        and bigrams, which helps capture "tom hanks" as a single concept.
    min_df : int or float
        Minimum document frequency for a token to be included.
    sublinear_tf : bool
        Apply ``1 + log(tf)`` scaling (recommended for long descriptions).
    """

    def __init__(
        self,
        max_features: int = None,
        ngram_range: tuple = (1, 2),
        min_df: int = 1,
        sublinear_tf: bool = True,
    ):
        self.max_features = max_features
        self.ngram_range = ngram_range
        self.min_df = min_df
        self.sublinear_tf = sublinear_tf
        self._vectorizer: TfidfVectorizer = None
        self._matrix = None

    # ------------------------------------------------------------------
    # Fit / predict
    # ------------------------------------------------------------------

    def fit(self, soups: List[str]) -> "TFIDFRecommender":
        """Vectorize the corpus of soup strings.

        Parameters
        ----------
        soups : list of str
            One pre-processed text string per catalog item.

        Returns
        -------
        self
        """
        self._vectorizer = TfidfVectorizer(
            max_features=self.max_features,
            ngram_range=self.ngram_range,
            min_df=self.min_df,
            sublinear_tf=self.sublinear_tf,
            strip_accents="unicode",
            analyzer="word",
        )
        self._matrix = self._vectorizer.fit_transform(soups)
        return self

    def get_similar(
        self,
        query_idx: int,
        candidate_indices: List[int],
        top_n: int = 10,
    ) -> List[Tuple[int, float]]:
        """Return top-N (index, score) pairs for the item at *query_idx*.

        Parameters
        ----------
        query_idx : int
            Row index of the seed item in the fitted matrix.
        candidate_indices : list of int
            Row indices of items that are eligible to be recommended.
        top_n : int
            How many results to return.

        Returns
        -------
        list of (index, score) tuples, sorted descending by score.
        """
        self._check_fitted()
        query_vec = self._matrix[query_idx]
        candidate_matrix = self._matrix[candidate_indices]

        raw_results = cosine_similarity_top_n(
            query_vector=query_vec,
            corpus_matrix=candidate_matrix,
            top_n=top_n,
        )

        # Map local candidate indices back to global catalog indices
        return [(candidate_indices[local_idx], score) for local_idx, score in raw_results]

    def get_feature_names(self) -> List[str]:
        """Return the vocabulary tokens (useful for debugging)."""
        self._check_fitted()
        return self._vectorizer.get_feature_names_out().tolist()

    def _check_fitted(self) -> None:
        if self._matrix is None:
            raise RuntimeError("TFIDFRecommender is not fitted. Call fit() first.")
