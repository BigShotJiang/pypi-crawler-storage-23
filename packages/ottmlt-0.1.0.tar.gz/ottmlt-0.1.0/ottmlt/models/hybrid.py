"""
Hybrid recommender: weighted combination of TF-IDF + Embedding similarity.

The intuition:
- TF-IDF is great at exact keyword overlap (same genre tag, same actor name).
- Embeddings are great at semantic overlap (same "mood" or "theme").
- Blending both gives more robust recommendations.

Score formula:
    hybrid_score = alpha * tfidf_score + (1 - alpha) * embedding_score

where ``alpha`` defaults to 0.5 (equal weight).

Falls back to pure TF-IDF if sentence-transformers is not installed and
``alpha`` is set to 1.0 automatically in that case.
"""

import warnings
from typing import List, Optional, Tuple

from ottmlt.models.tfidf import TFIDFRecommender


class HybridRecommender:
    """Weighted hybrid of TF-IDF and Embedding recommenders.

    Parameters
    ----------
    alpha : float
        Weight for TF-IDF score (``0 <= alpha <= 1``).
        ``1.0`` → pure TF-IDF.  ``0.0`` → pure Embedding.
        Defaults to ``0.5``.
    tfidf_kwargs : dict, optional
        Extra keyword arguments forwarded to ``TFIDFRecommender``.
    embedding_kwargs : dict, optional
        Extra keyword arguments forwarded to ``EmbeddingRecommender``.
    """

    def __init__(
        self,
        alpha: float = 0.5,
        tfidf_kwargs: Optional[dict] = None,
        embedding_kwargs: Optional[dict] = None,
    ):
        if not 0.0 <= alpha <= 1.0:
            raise ValueError("`alpha` must be between 0.0 and 1.0.")
        self.alpha = alpha
        self._tfidf = TFIDFRecommender(**(tfidf_kwargs or {}))
        self._embedding = None
        self._embedding_kwargs = embedding_kwargs or {}
        self._use_embedding = False

    # ------------------------------------------------------------------
    # Fit / predict
    # ------------------------------------------------------------------

    def fit(self, soups: List[str]) -> "HybridRecommender":
        """Fit both TF-IDF and (if available) Embedding models."""
        self._tfidf.fit(soups)

        if self.alpha < 1.0:
            try:
                from ottmlt.models.embedding import EmbeddingRecommender
                self._embedding = EmbeddingRecommender(**self._embedding_kwargs)
                self._embedding.fit(soups)
                self._use_embedding = True
            except ImportError:
                warnings.warn(
                    "sentence-transformers not installed — HybridRecommender "
                    "falling back to pure TF-IDF.  "
                    "Install with:  pip install 'ottmlt[embedding]'",
                    UserWarning,
                    stacklevel=2,
                )
                self.alpha = 1.0
        return self

    def get_similar(
        self,
        query_idx: int,
        candidate_indices: List[int],
        top_n: int = 10,
    ) -> List[Tuple[int, float]]:
        """Return top-N (index, score) pairs using the hybrid score."""
        # Get a larger pool from TF-IDF to merge with embedding scores
        pool = max(top_n * 3, 50)

        tfidf_results = dict(
            self._tfidf.get_similar(query_idx, candidate_indices, top_n=pool)
        )

        if not self._use_embedding or self.alpha == 1.0:
            items = sorted(tfidf_results.items(), key=lambda x: x[1], reverse=True)
            return items[:top_n]

        embedding_results = dict(
            self._embedding.get_similar(query_idx, candidate_indices, top_n=pool)
        )

        # Merge all candidate indices seen in either model
        all_indices = set(tfidf_results) | set(embedding_results)
        hybrid_scores = {}
        for idx in all_indices:
            t_score = tfidf_results.get(idx, 0.0)
            e_score = embedding_results.get(idx, 0.0)
            hybrid_scores[idx] = self.alpha * t_score + (1 - self.alpha) * e_score

        top_items = sorted(hybrid_scores.items(), key=lambda x: x[1], reverse=True)
        return top_items[:top_n]
