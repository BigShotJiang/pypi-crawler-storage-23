"""Tests for the Preprocessor class."""

import pytest
import pandas as pd

from ottmlt.core.preprocessor import Preprocessor


@pytest.fixture
def sample_df():
    return pd.DataFrame(
        {
            "id": ["t1", "t2", "t3"],
            "title": ["The Dark Knight", "Inception", "Interstellar"],
            "genre": ["Action, Crime", "Sci-Fi | Thriller", "Sci-Fi Drama"],
            "cast": ["Christian Bale; Heath Ledger", "Leonardo DiCaprio", "Matthew McConaughey"],
            "director": ["Christopher Nolan", "Christopher Nolan", "Christopher Nolan"],
            "description": [
                "Batman fights the Joker in Gotham City.",
                "A thief steals secrets through dream-sharing technology.",
                "A team travels through a wormhole to save humanity.",
            ],
        }
    )


class TestPreprocessorInit:
    def test_raises_on_empty_fields(self):
        with pytest.raises(ValueError, match="text_fields"):
            Preprocessor(text_fields=[])

    def test_default_weights(self):
        p = Preprocessor(text_fields=["title"])
        assert p.field_weights == {}


class TestPreprocessorTransform:
    def test_returns_correct_length(self, sample_df):
        p = Preprocessor(text_fields=["title", "genre"])
        soups = p.transform(sample_df)
        assert len(soups) == len(sample_df)

    def test_all_lowercase(self, sample_df):
        p = Preprocessor(text_fields=["title"])
        soups = p.transform(sample_df)
        for soup in soups:
            assert soup == soup.lower()

    def test_special_chars_removed(self, sample_df):
        p = Preprocessor(text_fields=["cast"])
        soups = p.transform(sample_df)
        # Semicolons should be gone
        for soup in soups:
            assert ";" not in soup

    def test_field_weight_repeats(self, sample_df):
        p_no_weight = Preprocessor(text_fields=["title"])
        p_weighted = Preprocessor(text_fields=["title"], field_weights={"title": 3})
        soups_plain = p_no_weight.transform(sample_df)
        soups_heavy = p_weighted.transform(sample_df)
        # Weighted soup should be longer (title appears 3 times)
        for plain, heavy in zip(soups_plain, soups_heavy):
            assert len(heavy) > len(plain)

    def test_missing_field_raises(self, sample_df):
        p = Preprocessor(text_fields=["nonexistent_column"])
        with pytest.raises(ValueError, match="missing"):
            p.transform(sample_df)

    def test_null_values_handled(self):
        df = pd.DataFrame({"id": ["t1"], "title": [None], "genre": ["Drama"]})
        p = Preprocessor(text_fields=["title", "genre"])
        soups = p.transform(df)
        assert soups[0] == "drama"

    def test_multi_field_soup(self, sample_df):
        p = Preprocessor(text_fields=["title", "director"])
        soups = p.transform(sample_df)
        # All three titles have Christopher Nolan — he should appear in soup
        for soup in soups:
            assert "christopher nolan" in soup


class TestPreprocessorClean:
    def test_lowercase(self):
        assert Preprocessor._clean("Hello World") == "hello world"

    def test_comma_replaced(self):
        assert "," not in Preprocessor._clean("Action, Thriller")

    def test_pipe_replaced(self):
        assert "|" not in Preprocessor._clean("Sci-Fi | Drama")

    def test_unicode_normalised(self):
        result = Preprocessor._clean("Amélie")
        assert result == "amelie"

    def test_extra_whitespace_collapsed(self):
        result = Preprocessor._clean("  hello   world  ")
        assert result == "hello world"
