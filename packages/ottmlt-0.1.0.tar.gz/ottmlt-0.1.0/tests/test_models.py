"""Tests for TFIDFRecommender and HybridRecommender."""

import pytest

from ottmlt.models.tfidf import TFIDFRecommender
from ottmlt.models.hybrid import HybridRecommender


SOUPS = [
    "action thriller batman gotham city crime dark knight",
    "action adventure batman begins gotham city crime christopher nolan",
    "sci fi thriller inception dreams technology christopher nolan",
    "sci fi drama interstellar space wormhole christopher nolan",
    "crime drama godfather mafia family al pacino marlon brando",
    "crime drama goodfellas mob gangster robert de niro",
    "animation adventure family spirited away studio ghibli miyazaki",
    "animation adventure family spirited away fantasy miyazaki hayao",
]


class TestTFIDFRecommender:
    @pytest.fixture
    def fitted_model(self):
        m = TFIDFRecommender()
        m.fit(SOUPS)
        return m

    def test_fit_returns_self(self):
        m = TFIDFRecommender()
        result = m.fit(SOUPS)
        assert result is m

    def test_get_similar_returns_list(self, fitted_model):
        results = fitted_model.get_similar(
            query_idx=0, candidate_indices=list(range(1, len(SOUPS))), top_n=3
        )
        assert isinstance(results, list)
        assert len(results) == 3

    def test_get_similar_scores_between_0_and_1(self, fitted_model):
        results = fitted_model.get_similar(
            query_idx=0, candidate_indices=list(range(1, len(SOUPS))), top_n=5
        )
        for idx, score in results:
            assert 0.0 <= score <= 1.0

    def test_get_similar_sorted_descending(self, fitted_model):
        results = fitted_model.get_similar(
            query_idx=0, candidate_indices=list(range(1, len(SOUPS))), top_n=5
        )
        scores = [s for _, s in results]
        assert scores == sorted(scores, reverse=True)

    def test_batman_titles_similar(self, fitted_model):
        # Items 0 (dark knight) and 1 (batman begins) should be very similar
        results = fitted_model.get_similar(
            query_idx=0, candidate_indices=list(range(1, len(SOUPS))), top_n=3
        )
        top_idx = results[0][0]
        assert top_idx == 1, "Batman Begins should be most similar to The Dark Knight"

    def test_nolan_cluster(self, fitted_model):
        # Nolan films (0,1,2,3) should cluster together vs non-Nolan (4,5,6,7)
        results = fitted_model.get_similar(
            query_idx=2, candidate_indices=list(range(len(SOUPS))), top_n=3
        )
        top_indices = [idx for idx, _ in results if idx != 2][:2]
        nolan_indices = {0, 1, 3}
        assert any(i in nolan_indices for i in top_indices)

    def test_unfitted_raises(self):
        m = TFIDFRecommender()
        with pytest.raises(RuntimeError, match="not fitted"):
            m.get_similar(query_idx=0, candidate_indices=[1, 2], top_n=2)

    def test_get_feature_names(self, fitted_model):
        features = fitted_model.get_feature_names()
        assert isinstance(features, list)
        assert len(features) > 0
        assert "batman" in features

    def test_top_n_limit_respected(self, fitted_model):
        results = fitted_model.get_similar(
            query_idx=0, candidate_indices=list(range(1, len(SOUPS))), top_n=2
        )
        assert len(results) <= 2

    def test_custom_ngram_range(self):
        m = TFIDFRecommender(ngram_range=(1, 1))
        m.fit(SOUPS)
        results = m.get_similar(0, list(range(1, len(SOUPS))), top_n=3)
        assert len(results) == 3


class TestHybridRecommender:
    @pytest.fixture
    def fitted_hybrid(self):
        m = HybridRecommender(alpha=1.0)  # pure TF-IDF (no embedding dep needed)
        m.fit(SOUPS)
        return m

    def test_fit_returns_self(self):
        m = HybridRecommender(alpha=1.0)
        result = m.fit(SOUPS)
        assert result is m

    def test_invalid_alpha_raises(self):
        with pytest.raises(ValueError, match="alpha"):
            HybridRecommender(alpha=1.5)

    def test_pure_tfidf_alpha(self, fitted_hybrid):
        results = fitted_hybrid.get_similar(
            query_idx=0, candidate_indices=list(range(1, len(SOUPS))), top_n=3
        )
        assert len(results) == 3

    def test_results_are_sorted(self, fitted_hybrid):
        results = fitted_hybrid.get_similar(
            query_idx=0, candidate_indices=list(range(1, len(SOUPS))), top_n=5
        )
        scores = [s for _, s in results]
        assert scores == sorted(scores, reverse=True)
