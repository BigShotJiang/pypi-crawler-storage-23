"""Tests for the MoreLikeThis high-level API."""

import pytest
import pandas as pd

from ottmlt import MoreLikeThis
from ottmlt.utils.data import load_sample_catalog, validate_catalog


@pytest.fixture
def catalog():
    return load_sample_catalog()


@pytest.fixture
def fitted_mlt(catalog):
    mlt = MoreLikeThis(
        text_fields=["title", "description", "genre", "cast", "director"],
        field_weights={"title": 3, "genre": 2},
    )
    mlt.fit(catalog)
    return mlt


class TestMoreLikeThisInit:
    def test_default_model_is_tfidf(self):
        mlt = MoreLikeThis()
        assert mlt.model_name == "tfidf"

    def test_custom_text_fields(self):
        mlt = MoreLikeThis(text_fields=["title", "genre"])
        assert mlt.text_fields == ["title", "genre"]

    def test_repr_before_fit(self):
        mlt = MoreLikeThis()
        assert "MoreLikeThis" in repr(mlt)
        assert "n_items=0" in repr(mlt)


class TestMoreLikeThisFit:
    def test_fit_returns_self(self, catalog):
        mlt = MoreLikeThis()
        result = mlt.fit(catalog)
        assert result is mlt

    def test_n_items_after_fit(self, fitted_mlt, catalog):
        assert fitted_mlt.n_items == len(catalog)

    def test_repr_after_fit(self, fitted_mlt, catalog):
        r = repr(fitted_mlt)
        assert str(len(catalog)) in r

    def test_missing_id_col_raises(self, catalog):
        mlt = MoreLikeThis(id_col="nonexistent")
        with pytest.raises(ValueError, match="id_col"):
            mlt.fit(catalog)

    def test_missing_text_field_filled(self, catalog):
        mlt = MoreLikeThis(text_fields=["title", "nonexistent_field"])
        mlt.fit(catalog)  # Should not raise
        assert mlt.n_items == len(catalog)


class TestMoreLikeThisRecommend:
    def test_returns_dataframe(self, fitted_mlt):
        recs = fitted_mlt.recommend("tt0111161", n=5)
        assert isinstance(recs, pd.DataFrame)

    def test_correct_n_results(self, fitted_mlt):
        recs = fitted_mlt.recommend("tt0111161", n=5)
        assert len(recs) == 5

    def test_similarity_score_column_exists(self, fitted_mlt):
        recs = fitted_mlt.recommend("tt0111161", n=5)
        assert "similarity_score" in recs.columns

    def test_similarity_scores_between_0_and_1(self, fitted_mlt):
        recs = fitted_mlt.recommend("tt0111161", n=10)
        assert (recs["similarity_score"] >= 0).all()
        assert (recs["similarity_score"] <= 1).all()

    def test_scores_sorted_descending(self, fitted_mlt):
        recs = fitted_mlt.recommend("tt0111161", n=10)
        scores = recs["similarity_score"].tolist()
        assert scores == sorted(scores, reverse=True)

    def test_seed_item_not_in_results(self, fitted_mlt):
        seed_id = "tt0111161"
        recs = fitted_mlt.recommend(seed_id, n=10)
        assert seed_id not in recs["id"].tolist()

    def test_unknown_item_id_raises(self, fitted_mlt):
        with pytest.raises(KeyError):
            fitted_mlt.recommend("tt9999999", n=5)

    def test_unfitted_raises(self):
        mlt = MoreLikeThis()
        with pytest.raises(RuntimeError, match="not fitted"):
            mlt.recommend("tt0111161", n=5)

    def test_nolan_films_cluster(self, fitted_mlt):
        """Nolan films should recommend other Nolan films."""
        nolan_ids = {"tt0468569", "tt1375666", "tt0816692", "tt0482571", "tt0372784"}
        recs = fitted_mlt.recommend("tt0468569", n=5)  # The Dark Knight
        result_ids = set(recs["id"].tolist())
        overlap = result_ids & nolan_ids
        assert len(overlap) >= 1, "Expected at least 1 Nolan film in recommendations"

    def test_genre_filter(self, fitted_mlt):
        """Filter by genre should only return Drama results."""
        recs = fitted_mlt.recommend(
            "tt0111161",  # Shawshank — Drama
            n=5,
            filters={"genre": "Drama"},
        )
        if len(recs) > 0:
            assert all("Drama" in g for g in recs["genre"].tolist())

    def test_filter_unknown_column_ignored(self, fitted_mlt):
        # Should not crash — unknown filter columns are silently ignored
        recs = fitted_mlt.recommend("tt0111161", n=5, filters={"nonexistent": "x"})
        assert isinstance(recs, pd.DataFrame)

    def test_request_more_than_catalog_size(self, fitted_mlt, catalog):
        recs = fitted_mlt.recommend("tt0111161", n=9999)
        # Should return catalog size - 1 (excluding seed)
        assert len(recs) <= len(catalog) - 1


class TestMoreLikeThisGetItem:
    def test_get_item_returns_series(self, fitted_mlt):
        item = fitted_mlt.get_item("tt0111161")
        assert isinstance(item, pd.Series)
        assert item["id"] == "tt0111161"

    def test_get_item_unknown_raises(self, fitted_mlt):
        with pytest.raises(KeyError):
            fitted_mlt.get_item("tt9999999")


class TestValidateCatalog:
    def test_valid_catalog_no_error(self, catalog):
        validate_catalog(catalog, text_fields=["title", "genre"])

    def test_missing_id_col_raises(self, catalog):
        with pytest.raises(ValueError, match="id_col"):
            validate_catalog(catalog, id_col="nonexistent")

    def test_duplicate_ids_raises(self, catalog):
        duped = pd.concat([catalog, catalog.head(1)], ignore_index=True)
        with pytest.raises(ValueError, match="duplicate"):
            validate_catalog(duped)

    def test_missing_text_field_warns(self, catalog):
        with pytest.warns(UserWarning, match="text_fields not found"):
            validate_catalog(catalog, text_fields=["title", "missing_col"])


class TestLoadSampleCatalog:
    def test_returns_dataframe(self, catalog):
        assert isinstance(catalog, pd.DataFrame)

    def test_has_expected_columns(self, catalog):
        expected = {"id", "title", "description", "genre", "cast", "director"}
        assert expected.issubset(set(catalog.columns))

    def test_no_duplicate_ids(self, catalog):
        assert not catalog["id"].duplicated().any()

    def test_non_empty(self, catalog):
        assert len(catalog) > 0
