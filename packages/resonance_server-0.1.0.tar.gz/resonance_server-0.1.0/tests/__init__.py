"""Resonance test suite."""
