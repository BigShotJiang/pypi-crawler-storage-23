"""
Resonance - A modern Python implementation of the Logitech Media Server.

Resonance provides full compatibility with Squeezebox hardware and software
players while offering a cleaner, more maintainable codebase built on modern
Python patterns.

Copyright (C) 2025 Resonance contributors

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, see <https://www.gnu.org/licenses/>.
"""

__version__ = "0.1.0"
__author__ = "Resonance contributors"
__license__ = "GPL-2.0"

from resonance.server import ResonanceServer

__all__ = ["ResonanceServer", "__version__"]
