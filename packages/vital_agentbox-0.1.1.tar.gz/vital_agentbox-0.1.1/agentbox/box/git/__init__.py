"""Git integration: isomorphic-git in-browser + storage backends."""
