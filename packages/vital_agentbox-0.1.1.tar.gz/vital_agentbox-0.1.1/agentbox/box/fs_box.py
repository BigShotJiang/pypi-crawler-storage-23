from agentbox.box.box import Box


class FileSystemBox(Box):
    pass

