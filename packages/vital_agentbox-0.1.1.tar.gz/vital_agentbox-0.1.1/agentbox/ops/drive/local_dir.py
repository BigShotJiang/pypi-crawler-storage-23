
class LocalDir:
    pass
