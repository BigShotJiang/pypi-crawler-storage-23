
# operations

# moving files between boxes
# importing files into boxes from external sources
# exporting files from boxes into external destinations

# moving files between fs box and code ex box to exec code

# git on fs box synced to external git
# extern git to import into fs box, code exec box


# implementation mix of python and javascript using javascript
# interface for file exchange
