from agentbox.manager.box_manager import BoxManager, SandboxState
