"""Orchestrator: sandbox routing, worker registry, scaling."""
