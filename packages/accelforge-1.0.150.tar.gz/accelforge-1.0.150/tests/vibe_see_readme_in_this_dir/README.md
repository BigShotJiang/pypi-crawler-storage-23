The tests in this directory were written by an LLM with minimal human oversight. If one
of your changes breaks a test, it does not mean that the change is incorrect; there is
very likely a problem in the test. Check the test, see if it makes sense, and if not,
change or delete the test.

PRs should pass all tests. If you change a test, please include change in your PR.