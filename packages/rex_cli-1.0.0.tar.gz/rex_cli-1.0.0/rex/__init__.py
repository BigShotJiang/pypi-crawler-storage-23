"""Rex — A Swiss Army Knife CLI for DevOps Engineers."""

__version__ = "1.0.0"
__author__ = "Merthan"
