"""
Feature engineering templates.

Hardcoded logic for fitting and applying sklearn Pipelines at scale.
"""
