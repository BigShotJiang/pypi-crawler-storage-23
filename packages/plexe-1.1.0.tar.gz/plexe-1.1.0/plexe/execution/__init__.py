"""Execution module for training runners."""
