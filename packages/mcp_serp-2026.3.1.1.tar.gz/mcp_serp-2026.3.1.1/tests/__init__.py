"""Tests package for MCP Serp server."""
