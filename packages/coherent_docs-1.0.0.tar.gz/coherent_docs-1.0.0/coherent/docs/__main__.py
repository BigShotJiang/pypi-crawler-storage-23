from . import core

__name__ == '__main__' and core.run()
