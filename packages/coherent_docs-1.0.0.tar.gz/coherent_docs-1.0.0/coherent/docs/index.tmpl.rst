Welcome to |project| documentation!
===================================

.. sidebar-links::
   :home:
   :pypi:
   :releases:

.. toctree::
   :maxdepth: 1

{modules}

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
