[![](https://img.shields.io/pypi/v/coherent.docs)](https://pypi.org/project/coherent.docs)

![](https://img.shields.io/pypi/pyversions/coherent.docs)

[![](https://github.com/coherent-oss/coherent.docs/actions/workflows/main.yml/badge.svg)](https://github.com/coherent-oss/coherent.docs/actions?query=workflow%3A%22tests%22)

[![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)

[![Coherent Software Development System](https://img.shields.io/badge/coherent%20system-informational)](https://github.com/coherent-oss/system)

