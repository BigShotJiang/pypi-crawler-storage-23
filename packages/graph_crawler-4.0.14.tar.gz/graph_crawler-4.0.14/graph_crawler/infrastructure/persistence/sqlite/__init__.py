"""Module: infrastructure/persistence/sqlite"""
