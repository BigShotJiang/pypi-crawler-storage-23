"""Module: infrastructure/persistence/json"""
