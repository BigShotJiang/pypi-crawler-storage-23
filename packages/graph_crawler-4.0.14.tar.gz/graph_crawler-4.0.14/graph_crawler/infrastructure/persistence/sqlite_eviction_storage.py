"""
SQLiteEvictionStorage - спеціалізований storage для eviction operations.

Оптимізований для:
1. APPEND операцій (batch inserts)
2. LOOKUP операцій (indexed URL)
3. WAL mode для concurrent access

Відмінності від SQLiteStorage:
- НЕ підтримує load_graph() - тільки окремі ноди
- Оптимізований для high-throughput writes
- Мінімальний overhead для eviction workflow
"""

import json
import logging
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

logger = logging.getLogger(__name__)


class SQLiteEvictionStorage:
    """
    Спеціалізований SQLite storage для eviction operations.
    
    Використовується Graph у low_memory_mode для:
    - Збереження scanned нод при eviction
    - Завантаження нод по URL (lazy loading)
    - Збереження edges пов'язаних з evicted нодами
    
    Оптимізації:
    - WAL mode для concurrent read/write
    - Batch inserts для ефективного eviction
    - Indexed URL для швидкого lookup
    """
    
    def __init__(self, storage_path: str):
        """
        Ініціалізує eviction storage.
        
        Args:
            storage_path: Директорія для eviction.db
        """
        self.storage_path = Path(storage_path)
        self.storage_path.mkdir(parents=True, exist_ok=True)
        self.db_path = self.storage_path / "eviction.db"
        
        self._conn: Optional[sqlite3.Connection] = None
        self._init_database()
        
        logger.info(f"SQLiteEvictionStorage initialized: {self.db_path}")
    
    def _get_connection(self) -> sqlite3.Connection:
        """Отримує connection з оптимальними налаштуваннями."""
        if self._conn is None:
            self._conn = sqlite3.connect(
                str(self.db_path),
                check_same_thread=False,  # Allow multi-thread access
                isolation_level=None,  # Autocommit for better WAL performance
            )
            self._conn.row_factory = sqlite3.Row
            
            # Оптимізації для high-throughput writes
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA synchronous=NORMAL")
            self._conn.execute("PRAGMA cache_size=10000")  # 10k pages (~40MB)
            self._conn.execute("PRAGMA temp_store=MEMORY")
            self._conn.execute("PRAGMA mmap_size=268435456")  # 256MB mmap
            
        return self._conn
    
    def _init_database(self):
        """Ініціалізує схему бази даних."""
        conn = self._get_connection()
        
        conn.executescript("""
            -- Таблиця evicted нод
            CREATE TABLE IF NOT EXISTS evicted_nodes (
                url TEXT PRIMARY KEY,
                node_id TEXT NOT NULL,
                depth INTEGER,
                scanned INTEGER DEFAULT 1,
                response_status INTEGER,
                content_hash TEXT,
                simhash TEXT,
                priority INTEGER DEFAULT 0,
                metadata TEXT,
                user_data TEXT,
                created_at TEXT,
                evicted_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            
            -- Індекси для швидкого пошуку
            CREATE INDEX IF NOT EXISTS idx_evicted_nodes_node_id ON evicted_nodes(node_id);
            CREATE INDEX IF NOT EXISTS idx_evicted_nodes_depth ON evicted_nodes(depth);
            
            -- Таблиця evicted edges
            CREATE TABLE IF NOT EXISTS evicted_edges (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                edge_id TEXT NOT NULL,
                source_node_id TEXT NOT NULL,
                target_node_id TEXT NOT NULL,
                metadata TEXT,
                created_at TEXT,
                UNIQUE(source_node_id, target_node_id)
            );
            
            -- Індекси для edges
            CREATE INDEX IF NOT EXISTS idx_evicted_edges_source ON evicted_edges(source_node_id);
            CREATE INDEX IF NOT EXISTS idx_evicted_edges_target ON evicted_edges(target_node_id);
        """)
        
        logger.debug("Eviction database schema initialized")
    
    def save_nodes_sync(self, nodes: List[Any]) -> int:
        """
        Batch INSERT нод (sync версія).
        
        Args:
            nodes: Список Node об'єктів для збереження
            
        Returns:
            Кількість збережених нод
        """
        if not nodes:
            return 0
        
        conn = self._get_connection()
        
        data = []
        for node in nodes:
            data.append((
                node.url,
                node.node_id,
                node.depth,
                1 if node.scanned else 0,
                getattr(node, 'response_status', None),
                getattr(node, 'content_hash', None),
                getattr(node, 'simhash', None),
                getattr(node, 'priority', 0),
                json.dumps(node.metadata) if node.metadata else None,
                json.dumps(node.user_data) if node.user_data else None,
                node.created_at.isoformat() if hasattr(node, 'created_at') and node.created_at else None,
            ))
        
        conn.execute("BEGIN TRANSACTION")
        try:
            conn.executemany(
                """
                INSERT OR REPLACE INTO evicted_nodes 
                (url, node_id, depth, scanned, response_status, content_hash, 
                 simhash, priority, metadata, user_data, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                data
            )
            conn.execute("COMMIT")
            
            logger.debug(f"Evicted {len(nodes)} nodes to disk")
            return len(nodes)
            
        except Exception as e:
            conn.execute("ROLLBACK")
            logger.error(f"Failed to save nodes: {e}")
            raise
    
    def save_edges_sync(self, edges: List[Any]) -> int:
        """
        Batch INSERT edges (sync версія).
        
        Args:
            edges: Список Edge об'єктів для збереження
            
        Returns:
            Кількість збережених edges
        """
        if not edges:
            return 0
        
        conn = self._get_connection()
        
        data = []
        for edge in edges:
            data.append((
                getattr(edge, 'edge_id', str(id(edge))),
                edge.source_node_id,
                edge.target_node_id,
                json.dumps(edge.metadata) if hasattr(edge, 'metadata') and edge.metadata else None,
                edge.created_at.isoformat() if hasattr(edge, 'created_at') and edge.created_at else None,
            ))
        
        conn.execute("BEGIN TRANSACTION")
        try:
            conn.executemany(
                """
                INSERT OR IGNORE INTO evicted_edges 
                (edge_id, source_node_id, target_node_id, metadata, created_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                data
            )
            conn.execute("COMMIT")
            
            logger.debug(f"Saved {len(edges)} edges to eviction storage")
            return len(edges)
            
        except Exception as e:
            conn.execute("ROLLBACK")
            logger.error(f"Failed to save edges: {e}")
            raise
    
    def load_node_sync(self, url: str) -> Optional[Dict[str, Any]]:
        """
        Завантажує ноду по URL (sync версія).
        
        Повертає Dict з даними ноди для реконструкції Node об'єкта.
        
        Args:
            url: URL ноди для завантаження
            
        Returns:
            Dict з даними ноди або None якщо не знайдено
        """
        conn = self._get_connection()
        
        row = conn.execute(
            "SELECT * FROM evicted_nodes WHERE url = ?",
            (url,)
        ).fetchone()
        
        if not row:
            return None
        
        # Конвертуємо Row в dict
        node_data = {
            'url': row['url'],
            'node_id': row['node_id'],
            'depth': row['depth'],
            'scanned': bool(row['scanned']),
            'response_status': row['response_status'],
            'content_hash': row['content_hash'],
            'simhash': row['simhash'],
            'priority': row['priority'] or 0,
            'metadata': json.loads(row['metadata']) if row['metadata'] else {},
            'user_data': json.loads(row['user_data']) if row['user_data'] else {},
        }
        
        logger.debug(f"Loaded evicted node: {url}")
        return node_data
    
    def load_nodes_batch_sync(self, urls: List[str]) -> Dict[str, Dict[str, Any]]:
        """
        Batch завантаження нод по URLs.
        
        Args:
            urls: Список URLs для завантаження
            
        Returns:
            Dict[url, node_data]
        """
        if not urls:
            return {}
        
        conn = self._get_connection()
        
        # Використовуємо параметризований запит для безпеки
        placeholders = ','.join('?' * len(urls))
        rows = conn.execute(
            f"SELECT * FROM evicted_nodes WHERE url IN ({placeholders})",
            urls
        ).fetchall()
        
        result = {}
        for row in rows:
            result[row['url']] = {
                'url': row['url'],
                'node_id': row['node_id'],
                'depth': row['depth'],
                'scanned': bool(row['scanned']),
                'response_status': row['response_status'],
                'content_hash': row['content_hash'],
                'simhash': row['simhash'],
                'priority': row['priority'] or 0,
                'metadata': json.loads(row['metadata']) if row['metadata'] else {},
                'user_data': json.loads(row['user_data']) if row['user_data'] else {},
            }
        
        logger.debug(f"Batch loaded {len(result)} evicted nodes")
        return result
    
    def get_all_evicted_urls(self) -> Set[str]:
        """
        Повертає всі evicted URLs.
        
        Returns:
            Set URLs що знаходяться в eviction storage
        """
        conn = self._get_connection()
        rows = conn.execute("SELECT url FROM evicted_nodes").fetchall()
        return {row['url'] for row in rows}
    
    def get_evicted_count(self) -> int:
        """Повертає кількість evicted нод."""
        conn = self._get_connection()
        row = conn.execute("SELECT COUNT(*) as cnt FROM evicted_nodes").fetchone()
        return row['cnt'] if row else 0
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Повертає статистику eviction storage.
        
        Returns:
            Dict зі статистикою
        """
        conn = self._get_connection()
        
        nodes_count = conn.execute(
            "SELECT COUNT(*) as cnt FROM evicted_nodes"
        ).fetchone()['cnt']
        
        edges_count = conn.execute(
            "SELECT COUNT(*) as cnt FROM evicted_edges"
        ).fetchone()['cnt']
        
        # Розмір файлу
        db_size_bytes = self.db_path.stat().st_size if self.db_path.exists() else 0
        db_size_mb = round(db_size_bytes / 1024 / 1024, 2)
        
        return {
            'evicted_nodes': nodes_count,
            'evicted_edges': edges_count,
            'db_size_mb': db_size_mb,
            'db_path': str(self.db_path),
        }
    
    def clear(self):
        """Очищає eviction storage."""
        conn = self._get_connection()
        conn.execute("DELETE FROM evicted_edges")
        conn.execute("DELETE FROM evicted_nodes")
        conn.execute("VACUUM")
        logger.info("Eviction storage cleared")
    
    def close(self):
        """Закриває з'єднання з БД."""
        if self._conn:
            self._conn.close()
            self._conn = None
            logger.debug("Eviction storage connection closed")
    
    def cleanup(self, delete_files: bool = True):
        """
        Видаляє eviction storage після завершення краулінгу.
        
        Викликайте після завершення краулінгу для очищення диску.
        
        Args:
            delete_files: Якщо True - видаляє файли БД з диску
            
        Example:
            >>> # Після завершення краулінгу
            >>> graph.close_eviction_storage()
            >>> # або напряму
            >>> eviction_storage.cleanup()
        """
        self.close()
        
        if delete_files:
            import shutil
            try:
                # Видаляємо всю директорію з eviction даними
                if self.storage_path.exists():
                    shutil.rmtree(self.storage_path)
                    logger.info(f"Eviction storage deleted: {self.storage_path}")
            except Exception as e:
                logger.warning(f"Failed to delete eviction storage: {e}")
    
    def __del__(self):
        """Деструктор - закриває з'єднання (але НЕ видаляє файли)."""
        self.close()


__all__ = ['SQLiteEvictionStorage']
