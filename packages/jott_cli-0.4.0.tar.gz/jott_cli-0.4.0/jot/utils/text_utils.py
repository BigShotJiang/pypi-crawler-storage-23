"""Text manipulation and search utilities for jot"""

import re


def extract_urls(text):
    """Extract URLs from text

    Args:
        text: String to search for URLs

    Returns:
        List of URLs found in text
    """
    # URL regex pattern - matches http://, https://, and www. URLs
    url_pattern = r'https?://[^\s]+|www\.[^\s]+'

    urls = re.findall(url_pattern, text)

    # Ensure www. URLs have http:// prefix for webbrowser
    normalized_urls = []
    for url in urls:
        if url.startswith('www.'):
            normalized_urls.append('http://' + url)
        else:
            normalized_urls.append(url)

    return normalized_urls


def fuzzy_match(query, text):
    """
    Fuzzy match query against text.

    Returns:
        (is_match, score, match_positions) where:
        - is_match: bool indicating if all query chars found in text in order
        - score: int score (higher is better match)
        - match_positions: list of indices in text where query chars matched
    """
    if not query:
        return (True, 0, [])

    query_lower = query.lower()
    text_lower = text.lower()

    # Find all query characters in text in order
    match_positions = []
    text_idx = 0

    for query_char in query_lower:
        # Find next occurrence of query char in text
        found = False
        while text_idx < len(text_lower):
            if text_lower[text_idx] == query_char:
                match_positions.append(text_idx)
                text_idx += 1
                found = True
                break
            text_idx += 1

        if not found:
            return (False, 0, [])  # Query char not found

    # Calculate score based on match quality
    score = 0

    # Bonus for consecutive character runs
    consecutive_run = 1
    for i in range(1, len(match_positions)):
        if match_positions[i] == match_positions[i - 1] + 1:
            consecutive_run += 1
            score += 10 * consecutive_run  # Exponential bonus for longer runs
        else:
            consecutive_run = 1

    # Bonus for word boundary matches
    for pos in match_positions:
        if pos == 0 or text[pos - 1] in ' -_./':
            score += 5

    # Penalty for character gaps
    if len(match_positions) > 1:
        total_gap = match_positions[-1] - match_positions[0]
        gap_penalty = total_gap - len(match_positions)
        score -= gap_penalty

    # Bonus for exact case matches
    for i, pos in enumerate(match_positions):
        if query[i] == text[pos]:
            score += 2

    # Bonus for matching at start
    if match_positions and match_positions[0] == 0:
        score += 15

    return (True, score, match_positions)
