"""Date and time utility functions for jot"""

import re
from datetime import datetime, timedelta


def get_today_day_name():
    """Get the current day of the week

    Returns:
        str: Full day name like "Monday"
    """
    return datetime.now().strftime('%A')


def sort_tasks_by_day(tasks):
    """Sort tasks by day of week (Sunday-Saturday)

    Args:
        tasks: List of task dictionaries

    Returns:
        Sorted list: tasks with days (Sun-Sat order) + tasks without days
    """
    days_order = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
    day_index = {day: i for i, day in enumerate(days_order)}

    # Separate tasks with and without days
    with_day = [t for t in tasks if t.get('day')]
    without_day = [t for t in tasks if not t.get('day')]

    # Sort tasks with days by day order
    with_day.sort(key=lambda t: day_index.get(t.get('day'), 999))

    # Return: tasks with day (sorted Sun-Sat) + tasks without day
    return with_day + without_day


def filter_today_tasks(tasks, today):
    """Filter tasks to only show those assigned to today

    Args:
        tasks: List of task dictionaries
        today: String name of today's day (e.g., "Monday")

    Returns:
        List of tasks assigned to today
    """
    return [t for t in tasks if t.get('day') == today]


def extract_time_tag(text):
    """Extract military time tag (HHMM) from task text.

    Finds a standalone 4-digit pattern where HH is 00-23 and MM is 00-59.

    Args:
        text: Task text potentially containing a time tag

    Returns:
        (hour, minute, cleaned_text) if found, (None, None, text) otherwise
    """
    match = re.search(r'(?:^|\s)(([01]\d|2[0-3])([0-5]\d))(?:\s|$)', text)
    if not match:
        return None, None, text
    hour = int(match.group(2))
    minute = int(match.group(3))
    cleaned = text[:match.start(1)] + text[match.end(1):]
    cleaned = ' '.join(cleaned.split())
    return hour, minute, cleaned


def round_to_15_minutes(dt):
    """Round datetime to nearest 15 minutes

    Args:
        dt: datetime object

    Returns:
        datetime rounded to nearest 15 minutes
    """
    minute = dt.minute
    # Round to nearest 15: 0, 15, 30, 45
    rounded_minute = round(minute / 15) * 15

    if rounded_minute == 60:
        # Roll over to next hour
        dt = dt.replace(minute=0, second=0, microsecond=0)
        dt = dt + timedelta(hours=1)
    else:
        dt = dt.replace(minute=rounded_minute, second=0, microsecond=0)

    return dt
