"""jott package - Simple, extensible interactive CLI task list

This package provides modular components for the jott task management system.
"""

import importlib.util
from pathlib import Path

# Import extracted classes from their new modules
from jot.core.id_manager import IDManager
from jot.core.task_manager import TaskManager
from jot.projects.registry import ProjectRegistry
from jot.projects.backup import ProjectBackup
from jot.categories.manager import CategoryManager
from jot.categories.config import CategoryConfig
from jot.categories.templates import CategoryTemplates
from jot.integrations.gcal.account_manager import GoogleCalendarAccountManager
from jot.integrations.gcal.auth import GoogleCalendarAuth
from jot.integrations.gcal.events import create_gcal_event, fetch_gcal_events
from jot.integrations.keywords.handler import KeywordHandler

# Load jot.py for main() and other not-yet-extracted components
_jot_script_path = Path(__file__).parent.parent / 'jot.py'
_spec = importlib.util.spec_from_file_location("_jot_script", _jot_script_path)
_jot_script = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_jot_script)

# Export main function from jot.py
main = _jot_script.main

__version__ = "0.4.0"

__all__ = [
    'main',
    'TaskManager',
    'ProjectRegistry',
    'ProjectBackup',
    'IDManager',
    'CategoryManager',
    'CategoryConfig',
    'CategoryTemplates',
    'KeywordHandler',
    'GoogleCalendarAccountManager',
    'GoogleCalendarAuth',
    'create_gcal_event',
    'fetch_gcal_events',
]
