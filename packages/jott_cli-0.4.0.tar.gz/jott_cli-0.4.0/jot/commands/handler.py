"""Command handler for interactive jot UI"""

import json
import os
import platform
import shlex
import subprocess
import sys
import tempfile
import termios
import tty
import urllib.parse
import uuid
import webbrowser
from collections import Counter
from datetime import datetime, timedelta
from pathlib import Path

# Conditional imports
try:
    import pyperclip
    CLIPBOARD_AVAILABLE = True
except ImportError:
    CLIPBOARD_AVAILABLE = False

from jot.core.task_manager import TaskManager
from jot.core.constants import DAY_COLORS, DAY_ABBREVIATIONS
from jot.categories.manager import CategoryManager
from jot.categories.config import CategoryConfig
from jot.projects.registry import ProjectRegistry
from jot.integrations.gcal.account_manager import GoogleCalendarAccountManager
from jot.integrations.gcal.auth import GoogleCalendarAuth
from jot.integrations.gcal.events import create_gcal_event, fetch_gcal_events
from jot.integrations.keywords.handler import KeywordHandler
from jot.ui import display_help, display_categorized_shortcuts
from jot.utils.date_utils import extract_time_tag, get_today_day_name, round_to_15_minutes
from jot.ui.input import get_key
from jot.utils.text_utils import extract_urls, fuzzy_match

# Import availability flags
from jot.core.constants import GCAL_AVAILABLE, TTS_AVAILABLE

# Note: read_text_aloud not yet implemented in text_utils.py
# TODO: Implement TTS functionality when needed


class CommandHandler:
    """Extensible command system"""

    def __init__(self, task_manager, registry=None):
        self.task_manager = task_manager
        self.registry = registry
        self.commands = {
            'a': self.add_task,
            'c': self.set_current,
            'd': self.delete_task,
            'D': self.delete_current,
            'e': self.edit_task,
            'E': self.edit_current,
            'M': self.move_task_to_project,
            'r': self.refresh,
            'q': self.quit,
            'h': self.help,
        }

    @staticmethod
    def safe_launch_editor(file_path):
        """
        Safely launch editor with file_path, avoiding command injection.

        Security: Uses shlex.split() to safely parse $EDITOR which may contain
        arguments (e.g., "emacs -nw"), then calls subprocess without shell=True
        to prevent command injection attacks.

        Args:
            file_path: Path to file to edit (str or Path)

        Returns:
            True if editor launched successfully, False otherwise

        Raises:
            FileNotFoundError: If editor command not found
        """

        # Get editor from environment
        editor = os.environ.get('EDITOR', os.environ.get('VISUAL', 'nano'))

        # Parse editor command safely (handles editors with args like "emacs -nw")
        try:
            editor_parts = shlex.split(editor)
        except ValueError:
            # Invalid shell syntax in $EDITOR - use safe default
            print(f"\n⚠️  Invalid $EDITOR value: {editor}")
            print("   Using nano instead")
            editor_parts = ['nano']

        # Add file path to command
        editor_parts.append(str(file_path))

        # Execute without shell=True (prevents command injection)
        try:
            result = subprocess.call(editor_parts)
            return result == 0
        except FileNotFoundError:
            raise FileNotFoundError(f"Editor not found: {editor_parts[0]}")

    def add_task(self):
        """Add a new task"""
        print("\nEnter task: ", end='', flush=True)
        task_text = input().strip()
        if task_text:
            self.task_manager.add_task(task_text)
            print(f"✓ Added: {task_text}")
        return True

    def quit(self):
        """Quit the application"""
        print("\nGoodbye!")
        return False

    def set_current(self):
        """Mark a task as current"""
        print("\nTask ID to mark as current: ", end='', flush=True)
        try:
            task_id = int(input().strip())
            if self.task_manager.set_current(task_id):
                print(f"✓ Task {task_id} marked as current")
            else:
                print(f"✗ Task {task_id} not found")
        except ValueError:
            print("✗ Invalid task ID")
        return True

    def set_agent_task(self):
        """Mark current task as agent task (Claude Code is working on it)"""
        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            return True

        task_id = current_task['id']
        is_currently_agent = current_task.get('agent_task', False)

        if self.task_manager.set_agent_task(task_id):
            MAGENTA = '\033[95m'
            RESET = '\033[0m'
            if is_currently_agent:
                # Was unmarked
                print(f"\n✓ Task {task_id} unmarked as agent task")
            else:
                # Was marked
                print(f"\n{MAGENTA}✓ Task {task_id} marked as agent task 🤖{RESET}")
        else:
            print(f"\n✗ Failed to mark task")
        return True

    def fix_duplicate_ids_interactive(self):
        """Check for and fix duplicate task IDs (Shift+1)"""

        GREEN = '\033[92m'
        YELLOW = '\033[93m'
        RESET = '\033[0m'
        DIM = '\033[2m'
        BOLD = '\033[1m'

        # Check for duplicates
        all_tasks = self.task_manager.tasks + self.task_manager.archived
        ids = [task['id'] for task in all_tasks if 'id' in task]

        id_counts = Counter(ids)
        duplicates = {task_id: count for task_id, count in id_counts.items() if count > 1}

        if not duplicates:
            print(f"\n{GREEN}✓ No duplicate IDs found{RESET}")
            print(f"  {DIM}All task IDs are unique{RESET}")
            return True

        # Show what we found
        print(f"\n{YELLOW}🔧 Found duplicate IDs:{RESET}")
        for task_id, count in sorted(duplicates.items()):
            print(f"  ID {BOLD}{task_id}{RESET}: {count} occurrences")

        # Create backup before fixing
        now = datetime.now()
        timestamp = now.strftime("%Y%m%d_%H%M%S")
        year_month = now.strftime("%Y-%m")

        backup_dir = self.task_manager.storage_file.parent / '.jot-backups' / year_month
        backup_dir.mkdir(parents=True, exist_ok=True)

        backup_file = backup_dir / f'{timestamp}.json'
        with open(self.task_manager.storage_file, 'r') as f:
            backup_data = f.read()
        with open(backup_file, 'w') as f:
            f.write(backup_data)

        # Build list of tasks that need new IDs
        seen_ids = set()
        tasks_to_fix = []

        for idx, task in enumerate(self.task_manager.tasks):
            task_id = task.get('id')
            if task_id in duplicates:
                if task_id in seen_ids:
                    tasks_to_fix.append((task, 'tasks', idx))
                else:
                    seen_ids.add(task_id)

        for idx, task in enumerate(self.task_manager.archived):
            task_id = task.get('id')
            if task_id in duplicates:
                if task_id in seen_ids:
                    tasks_to_fix.append((task, 'archived', idx))
                else:
                    seen_ids.add(task_id)

        # Reassign IDs
        old_to_new = {}
        for task, list_name, idx in tasks_to_fix:
            old_id = task['id']
            new_id = self.task_manager.id_manager.allocate_id()
            task['id'] = new_id

            if old_id not in old_to_new:
                old_to_new[old_id] = []
            old_to_new[old_id].append(new_id)

        # Save fixed data
        self.task_manager._save_tasks()

        # Show success message
        print(f"\n{GREEN}✓ Fixed {len(tasks_to_fix)} duplicate ID(s){RESET}")
        print(f"  {DIM}Backup: {backup_file.name}{RESET}")

        changes = []
        for old_id, new_ids in sorted(old_to_new.items()):
            changes.append(f"{old_id} → {', '.join(map(str, new_ids))}")
        if changes:
            print(f"  {DIM}Changes: {', '.join(changes)}{RESET}")

        return True

    def delete_task(self):
        """Delete a task by ID"""
        print("\nTask ID to delete: ", end='', flush=True)
        try:
            task_id = int(input().strip())
            if self.task_manager.remove_task(task_id):
                print(f"✓ Task {task_id} deleted")
            else:
                print(f"✗ Task {task_id} not found")
        except ValueError:
            print("✗ Invalid task ID")
        return True

    def delete_current(self):
        """Delete the current task"""
        current_task = self.task_manager.get_current_task()
        if current_task:
            task_id = current_task['id']
            if self.task_manager.remove_task(task_id):
                print(f"\n✓ Current task deleted")
            else:
                print(f"\n✗ Failed to delete task")
        else:
            print("\n✗ No current task selected")
        return True

    def edit_task(self):
        """Edit a task's text"""
        print("\nTask ID to edit: ", end='', flush=True)
        try:
            task_id = int(input().strip())

            # Find the task to get current text
            task = None
            for t in self.task_manager.tasks:
                if t['id'] == task_id:
                    task = t
                    break

            if not task:
                print(f"✗ Task {task_id} not found")
                return True

            print(f"Editing task {task_id}:")
            try:
                new_text = input_with_prefill("", prefill=task['text']).strip()
                if new_text:
                    if self.task_manager.edit_task(task_id, new_text):
                        print(f"✓ Task {task_id} updated")
                    else:
                        print(f"✗ Failed to update task")
                else:
                    print("✗ Task text cannot be empty")
            except (EOFError, KeyboardInterrupt):
                print("\n✗ Edit cancelled")
        except ValueError:
            print("✗ Invalid task ID")
        return True

    def edit_current(self):
        """Edit the current task"""
        current_task = self.task_manager.get_current_task()
        if current_task:
            task_id = current_task['id']
            current_text = current_task['text']
            print(f"\nEditing task {task_id}:")
            try:
                new_text = input_with_prefill("", prefill=current_text).strip()
                if new_text:
                    if self.task_manager.edit_task(task_id, new_text):
                        print(f"✓ Task updated")
                    else:
                        print(f"✗ Failed to update task")
                else:
                    print("✗ Task text cannot be empty")
            except (EOFError, KeyboardInterrupt):
                print("\n✗ Edit cancelled")
        else:
            print("\n✗ No current task selected")
        return True

    def copy_task_to_project(self):
        """Copy current task to a different project (keeps original)"""
        if not self.registry:
            print("\n✗ Project registry not available")
            return True

        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            return True

        # Extract all task metadata for preservation
        task_text = current_task['text']
        task_priority = current_task.get('priority', 'none')
        task_status = current_task.get('status', 'todo')
        task_labels = current_task.get('labels', [])
        task_effort = current_task.get('effort', None)
        task_notes = current_task.get('notes', '')
        task_agent = current_task.get('agent_task', False)
        task_keyword = current_task.get('keyword', None)
        task_created = current_task.get('created_at', None)
        task_day = current_task.get('day', None)

        # Interactive fuzzy project picker
        target_project = self._pick_project_fuzzy(f"Copy '{task_text}' to:")
        if not target_project:
            print("\n✗ Cancelled")
            return True

        target_path = self.registry.get_project_path(target_project)

        # Check if we should preserve the category
        current_category = self.task_manager.category
        target_category = None
        category_preserved = False

        if current_category:
            target_cat_manager = CategoryManager(project_dir=target_path)
            if target_cat_manager.category_exists_locally(current_category):
                target_category = current_category
                category_preserved = True

        # Add task to target project (with or without category)
        target_tm = TaskManager(
            directory=target_path, category=target_category, project_registry=self.registry
        )
        target_tm.add_task(
            task_text,
            priority=task_priority,
            status=task_status,
            labels=task_labels,
            effort=task_effort,
        )

        # Get the newly created task to set additional metadata
        new_task = target_tm.tasks[-1]
        new_task['notes'] = task_notes
        new_task['agent_task'] = task_agent
        new_task['keyword'] = task_keyword
        new_task['day'] = task_day

        if task_created:
            new_task['created_at'] = task_created

        target_tm._save_tasks()
        self.registry.record_usage(target_project)

        if category_preserved:
            print(f"✓ Copied task to {target_project} (kept in '{current_category}' category)")
        elif current_category:
            print(
                f"✓ Copied task to {target_project} (category '{current_category}' not available, added to default)"
            )
        else:
            print(f"✓ Copied task to {target_project}")
        return True

    def _pick_project_fuzzy(self, prompt_text="Select project"):
        """Interactive fuzzy search project picker

        Returns project name or None if cancelled.
        """
        if not self.registry:
            return None

        current_dir = str(self.task_manager.project_dir.resolve())
        usage_items = self.registry.list_projects_by_usage()
        available = [
            (n, p, u) for n, p, u in usage_items
            if str(Path(p).resolve()) != current_dir
        ]

        if not available:
            print("\n\033[91m✗ No other projects available\033[0m")
            return None

        search_buffer = ""
        selected_idx = 0
        max_display = 15

        CYAN = '\033[96m'
        BOLD = '\033[1m'
        DIM = '\033[2m'
        RESET = '\033[0m'
        REVERSE = '\033[7m'
        GREEN = '\033[92m'

        while True:
            # Filter by fuzzy match
            if search_buffer:
                matches = []
                for name, path, usage in available:
                    is_match, score, positions = fuzzy_match(search_buffer, name)
                    if is_match:
                        matches.append((name, path, usage, score))
                matches.sort(key=lambda x: (-x[3], -x[2], x[0]))
            else:
                matches = [(n, p, u, 0) for n, p, u in available]

            # Clamp selected index
            if matches:
                selected_idx = min(selected_idx, len(matches) - 1)
            else:
                selected_idx = 0

            # Calculate visible window
            visible = matches[:max_display]

            # Clear screen and draw
            sys.stdout.write('\033[2J\033[H')  # Clear screen, cursor to top
            print(f"{BOLD}{prompt_text}{RESET}")
            print(f"{DIM}Type to filter · ↑↓ navigate · Enter select · ESC cancel{RESET}")
            cursor = "▌" if not search_buffer else ""
            print(f"\n{CYAN}> {search_buffer}{cursor}{RESET}")
            print()

            if not matches:
                print(f"  {DIM}No matching projects{RESET}")
            else:
                for i, (name, path, usage, score) in enumerate(visible):
                    prefix = "→ " if i == selected_idx else "  "
                    usage_str = f" {DIM}({usage}){RESET}" if usage > 0 else ""
                    if i == selected_idx:
                        print(f"  {GREEN}{BOLD}{prefix}{name}{RESET}{usage_str}")
                    else:
                        print(f"  {prefix}{name}{usage_str}")

                if len(matches) > max_display:
                    remaining = len(matches) - max_display
                    print(f"\n  {DIM}... and {remaining} more{RESET}")

            print(f"\n{DIM}{len(matches)}/{len(available)} projects{RESET}")

            # Read key
            key = get_key(timeout=30.0)
            if key is None:
                continue
            if key == '\x1b':  # ESC
                return None
            elif key == '\r' or key == '\n':  # Enter
                if matches:
                    return matches[selected_idx][0]
                return None
            elif key == 'UP':
                selected_idx = max(0, selected_idx - 1)
            elif key == 'DOWN':
                if matches:
                    selected_idx = min(len(matches) - 1, selected_idx + 1)
            elif key == '\x7f':  # Backspace
                search_buffer = search_buffer[:-1]
                selected_idx = 0
            elif isinstance(key, str) and len(key) == 1 and key.isprintable():
                search_buffer += key
                selected_idx = 0

    def move_task_to_project(self):
        """Move current task to a different project"""
        if not self.registry:
            print("\n✗ Project registry not available")
            return True

        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            return True

        # Extract all task metadata for preservation
        task_id = current_task['id']
        task_text = current_task['text']
        task_priority = current_task.get('priority', 'none')
        task_status = current_task.get('status', 'todo')
        task_labels = current_task.get('labels', [])
        task_effort = current_task.get('effort', None)
        task_notes = current_task.get('notes', '')
        task_agent = current_task.get('agent_task', False)
        task_keyword = current_task.get('keyword', None)
        task_created = current_task.get('created_at', None)
        task_day = current_task.get('day', None)

        # Interactive fuzzy project picker
        target_project = self._pick_project_fuzzy(f"Move '{task_text}' to:")
        if not target_project:
            print("\n✗ Cancelled")
            return True

        target_path = self.registry.get_project_path(target_project)

        # Check if we should preserve the category
        current_category = self.task_manager.category
        target_category = None
        category_preserved = False

        if current_category:
            target_cat_manager = CategoryManager(project_dir=target_path)
            if target_cat_manager.category_exists_locally(current_category):
                target_category = current_category
                category_preserved = True

        # Add task to target project (with or without category)
        target_tm = TaskManager(
            directory=target_path, category=target_category, project_registry=self.registry
        )
        target_tm.add_task(
            task_text,
            priority=task_priority,
            status=task_status,
            labels=task_labels,
            effort=task_effort,
        )

        # Get the newly created task to set additional metadata
        new_task = target_tm.tasks[-1]
        new_task['notes'] = task_notes
        new_task['agent_task'] = task_agent
        new_task['keyword'] = task_keyword
        new_task['day'] = task_day

        if task_created:
            new_task['created_at'] = task_created

        target_tm._save_tasks()
        self.task_manager.remove_task(task_id)
        self.registry.record_usage(target_project)

        if category_preserved:
            print(f"✓ Moved task to {target_project} (kept in '{current_category}' category)")
        elif current_category:
            print(
                f"✓ Moved task to {target_project} (category '{current_category}' not available, added to default)"
            )
        else:
            print(f"✓ Moved task to {target_project}")
        return True

    def transfer_task_to_category(self):
        """Transfer current task to a different category within the same project"""
        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            return True

        task_text = current_task['text']
        task_id = current_task['id']
        task_done = current_task.get('done', False)

        # Get current project directory
        project_dir = (
            self.task_manager.project_dir if not self.task_manager.is_global else Path.cwd()
        )
        current_category = self.task_manager.category

        # Discover available categories
        cat_manager = CategoryManager(project_dir=project_dir)
        local_categories = cat_manager.discover_categories()
        global_categories = cat_manager.discover_global_categories()

        # Build category list (excluding current category)
        categories = []

        # Add default if we're not already in it
        if current_category is not None:
            categories.append(("default", None, False))

        # Add local categories (excluding current)
        for cat in local_categories:
            if cat != current_category:
                categories.append((cat, cat, False))

        # Add global categories (excluding current, and avoiding duplicates with local)
        for cat in global_categories:
            if cat != current_category and cat not in local_categories:
                categories.append((cat, cat, True))

        if not categories:
            print("\n✗ No other categories available")
            return True

        # Display available categories
        RESET = '\033[0m'

        # Get category config for colors
        cat_config = CategoryConfig(project_dir=project_dir)

        print(f"\nTransfer task '{task_text}' to:")
        for i, (display_name, cat_name, is_global) in enumerate(categories, 1):
            if display_name == "default":
                cat_color = cat_config.get_color('default')
                print(f"  {i}. {cat_color}default (no category){RESET}")
            else:
                cat_color = cat_config.get_color(cat_name, for_global=is_global)
                if is_global:
                    print(f"  {i}. {cat_color}{cat_name} [global]{RESET}")
                else:
                    print(f"  {i}. {cat_color}{cat_name} [local]{RESET}")

        print("\nEnter number or name (ESC to cancel): ", end='', flush=True)

        # Restore terminal to normal mode and flush any pending input
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        termios.tcflush(fd, termios.TCIFLUSH)

        # Get user input
        try:
            user_input = input().strip()

            # Check if ESC or empty
            if not user_input or user_input == '\x1b':
                print("✗ Cancelled")
                return True

            # Try as number first
            selected_category = None
            selected_is_global = False

            try:
                choice_index = int(user_input) - 1
                if 0 <= choice_index < len(categories):
                    display_name, cat_name, is_global = categories[choice_index]
                    selected_category = cat_name
                    selected_is_global = is_global
                else:
                    print("✗ Invalid number")
                    return True
            except ValueError:
                # Try as category name
                found = False
                for display_name, cat_name, is_global in categories:
                    if cat_name == user_input or display_name == user_input:
                        selected_category = cat_name
                        selected_is_global = is_global
                        found = True
                        break

                if not found:
                    print(f"✗ Category '{user_input}' not found")
                    return True

            # Add task to destination category
            if selected_is_global:
                dest_tm = TaskManager(
                    category=selected_category, is_global=True, project_registry=self.registry
                )
            else:
                dest_tm = TaskManager(
                    directory=project_dir,
                    category=selected_category,
                    is_global=False,
                    project_registry=self.registry,
                )

            dest_tm.add_task(task_text)

            # Mark as done if original was done
            if task_done:
                new_task_id = dest_tm.tasks[-1]['id']  # Get the ID of newly added task
                dest_tm.set_task_status(new_task_id, 'done')

            # Remove from current category
            self.task_manager.remove_task(task_id)

            # Show result
            dest_name = selected_category or 'default'
            if selected_is_global:
                print(f"✓ Transferred task to global:{dest_name}")
            else:
                print(f"✓ Transferred task to {dest_name}")

            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        except KeyboardInterrupt:
            print("\n✗ Cancelled")
            return True

    def web_search(self):
        """Open a web search with the current task text"""
        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            return True

        task_text = current_task['text']

        # URL-encode the task text
        query = urllib.parse.quote_plus(task_text)

        # Build Google search URL
        search_url = f"https://www.google.com/search?q={query}"

        try:
            # Open URL in default browser
            webbrowser.open(search_url)
            print(f"\n✓ Opened web search for: {task_text}")
        except Exception as e:
            print(f"\n✗ Failed to open browser: {e}")

        return True

    def open_url(self):
        """Open URL(s) from current task text in browser"""
        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            return True

        task_text = current_task['text']

        # Extract URLs from task text
        urls = extract_urls(task_text)

        if not urls:
            print(f"\n✗ No URLs found in task: {task_text}")
            return True

        if len(urls) == 1:
            # Single URL - open it directly
            url = urls[0]
            try:
                webbrowser.open(url)
                print(f"\n✓ Opened URL: {url}")
            except Exception as e:
                print(f"\n✗ Failed to open browser: {e}")
        else:
            # Multiple URLs - show menu
            print(f"\nFound {len(urls)} URLs in task:")
            for i, url in enumerate(urls, 1):
                print(f"  {i}. {url}")

            print(
                "\nSelect URL to open (1-{}, or Enter to cancel): ".format(len(urls)),
                end='',
                flush=True,
            )
            try:
                choice = input().strip()
                if not choice:
                    print("✗ Cancelled")
                    return True

                index = int(choice) - 1
                if 0 <= index < len(urls):
                    url = urls[index]
                    webbrowser.open(url)
                    print(f"✓ Opened URL: {url}")
                else:
                    print("✗ Invalid selection")
            except (ValueError, KeyboardInterrupt):
                print("\n✗ Cancelled")

        return True

    def assign_day(self):
        """Assign a day of the week to the current task"""
        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            return True

        task_text = current_task['text']
        task_id = current_task['id']
        current_day = current_task.get('day')

        # Display menu
        RESET = '\033[0m'
        BOLD = '\033[1m'
        CYAN = '\033[96m'

        print(f"\n{BOLD}Assign day to task:{RESET} {task_text}")
        if current_day:
            day_color = DAY_COLORS.get(current_day, CYAN)
            print(f"Current: {day_color}{current_day}{RESET}\n")
        else:
            print("Current: (none)\n")

        # Get today's day of week (0=Monday, 6=Sunday)
        today_weekday = datetime.now().weekday()
        days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        today_index = today_weekday  # 0-6
        today_menu_number = today_index + 1  # 1-7
        today_name = days[today_index]

        # Show day options with colors, highlighting today
        for i, day in enumerate(days, 1):
            day_color = DAY_COLORS[day]
            abbrev = DAY_ABBREVIATIONS[day]
            if i == today_menu_number:
                # Highlight today with > indicator
                print(
                    f"  {BOLD}>{RESET} {i}. {day_color}{abbrev}{RESET} {day} {BOLD}(Today){RESET}"
                )
            else:
                print(f"    {i}. {day_color}{abbrev}{RESET} {day}")

        print(f"\n  {BOLD}c{RESET}. Clear day")
        print(f"  {BOLD}ESC{RESET}. Cancel\n")

        # Show default in prompt
        default_day_color = DAY_COLORS[today_name]
        default_abbrev = DAY_ABBREVIATIONS[today_name]
        print(
            f"Choice (default: {default_day_color}{default_abbrev}{RESET} {today_name}): ",
            end='',
            flush=True,
        )

        # Restore terminal and get input
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        termios.tcflush(fd, termios.TCIFLUSH)

        try:
            user_input = input().strip().lower()

            # Handle empty input - use today as default
            if not user_input:
                selected_day = today_name
                self.task_manager.set_task_day(task_id, selected_day)
                day_color = DAY_COLORS[selected_day]
                abbrev = DAY_ABBREVIATIONS[selected_day]
                print(f"✓ Day set to {day_color}{abbrev}{RESET} {selected_day}")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            # Handle ESC
            if user_input == '\x1b':
                print("✗ Cancelled")
                return True

            # Handle clear option
            if user_input == 'c':
                self.task_manager.set_task_day(task_id, None)
                print("✓ Day cleared")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            # Handle numeric selection
            try:
                choice = int(user_input)
                if 1 <= choice <= 7:
                    selected_day = days[choice - 1]
                    self.task_manager.set_task_day(task_id, selected_day)
                    day_color = DAY_COLORS[selected_day]
                    abbrev = DAY_ABBREVIATIONS[selected_day]
                    print(f"✓ Day set to {day_color}{abbrev}{RESET} {selected_day}")
                    print("\nPress Enter to continue...", end='', flush=True)
                    input()
                else:
                    print("✗ Invalid choice")
            except ValueError:
                print("✗ Invalid input")

        except KeyboardInterrupt:
            print("\n✗ Cancelled")

        return True

    def set_priority(self):
        """Set priority for the current task"""
        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        task_text = current_task['text']
        task_id = current_task['id']
        current_priority = current_task.get('priority', 'none')

        # Priority colors and symbols
        PRIORITY_COLORS = {
            'none': '\033[2m',  # DIM
            'low': '\033[94m',  # BLUE
            'medium': '\033[93m',  # YELLOW
            'high': '\033[91m',  # RED
        }
        PRIORITY_SYMBOLS = {
            'none': '○',
            'low': '◔',
            'medium': '◑',
            'high': '●',
        }

        # Display menu
        RESET = '\033[0m'
        BOLD = '\033[1m'

        print(f"\n{BOLD}Set priority for task:{RESET} {task_text}")
        priority_color = PRIORITY_COLORS[current_priority]
        priority_symbol = PRIORITY_SYMBOLS[current_priority]
        print(f"Current: {priority_color}{priority_symbol} {current_priority}{RESET}\n")

        # Show priority options
        priorities = ['none', 'low', 'medium', 'high']
        for i, priority in enumerate(priorities, 1):
            color = PRIORITY_COLORS[priority]
            symbol = PRIORITY_SYMBOLS[priority]
            print(f"  {i}. {color}{symbol} {priority}{RESET}")

        print(f"\n  {BOLD}ESC{RESET}. Cancel\n")
        print("Choice: ", end='', flush=True)

        # Restore terminal and get input
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        termios.tcflush(fd, termios.TCIFLUSH)

        try:
            user_input = input().strip().lower()

            if not user_input or user_input == '\x1b':
                print("✗ Cancelled")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            # Handle numeric selection
            try:
                choice = int(user_input)
                if 1 <= choice <= 4:
                    selected_priority = priorities[choice - 1]
                    self.task_manager.set_task_priority(task_id, selected_priority)
                    priority_color = PRIORITY_COLORS[selected_priority]
                    priority_symbol = PRIORITY_SYMBOLS[selected_priority]
                    print(
                        f"✓ Priority set to {priority_color}{priority_symbol} {selected_priority}{RESET}"
                    )
                    print("\nPress Enter to continue...", end='', flush=True)
                    input()
                else:
                    print("✗ Invalid choice")
                    print("\nPress Enter to continue...", end='', flush=True)
                    input()
            except ValueError:
                print("✗ Invalid input")
                print("\nPress Enter to continue...", end='', flush=True)
                input()

        except KeyboardInterrupt:
            print("\n✗ Cancelled")
            print("\nPress Enter to continue...", end='', flush=True)
            input()

        return True

    def set_priority_high(self):
        """Quickly set current task priority to high (shortcut)"""
        current_task = self.task_manager.get_current_task()
        if not current_task:
            # Silently return if no task - don't interrupt flow
            return True

        task_id = current_task['id']

        # Set priority to high
        self.task_manager.set_task_priority(task_id, 'high')

        # Show brief confirmation (no "Press Enter" prompt)
        RESET = '\033[0m'
        GREEN = '\033[92m'
        RED = '\033[91m'  # High priority color

        print(f"\n{GREEN}✓{RESET} Priority set to {RED}● high{RESET}")

        return True

    def set_status(self):
        """Set status for the current task"""
        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        task_text = current_task['text']
        task_id = current_task['id']
        current_status = current_task.get('status', 'todo')

        # Status colors and symbols
        STATUS_COLORS = {
            'todo': '\033[2m',  # DIM
            'in-progress': '\033[96m',  # CYAN
            'blocked': '\033[91m',  # RED
            'done': '\033[92m',  # GREEN
        }
        STATUS_SYMBOLS = {
            'todo': '☐',
            'in-progress': '▶',
            'blocked': '⚠',
            'done': '✓',
        }

        # Display menu
        RESET = '\033[0m'
        BOLD = '\033[1m'

        print(f"\n{BOLD}Set status for task:{RESET} {task_text}")
        status_color = STATUS_COLORS[current_status]
        status_symbol = STATUS_SYMBOLS[current_status]
        print(f"Current: {status_color}{status_symbol} {current_status}{RESET}\n")

        # Show status options
        statuses = ['todo', 'in-progress', 'blocked', 'done']
        for i, status in enumerate(statuses, 1):
            color = STATUS_COLORS[status]
            symbol = STATUS_SYMBOLS[status]
            print(f"  {i}. {color}{symbol} {status}{RESET}")

        print(f"\n  {BOLD}ESC{RESET}. Cancel\n")
        print("Choice: ", end='', flush=True)

        # Restore terminal and get input
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        termios.tcflush(fd, termios.TCIFLUSH)

        try:
            user_input = input().strip().lower()

            if not user_input or user_input == '\x1b':
                print("✗ Cancelled")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            # Handle numeric selection
            try:
                choice = int(user_input)
                if 1 <= choice <= 4:
                    selected_status = statuses[choice - 1]
                    self.task_manager.set_task_status(task_id, selected_status)
                    status_color = STATUS_COLORS[selected_status]
                    status_symbol = STATUS_SYMBOLS[selected_status]
                    print(f"✓ Status set to {status_color}{status_symbol} {selected_status}{RESET}")
                    print("\nPress Enter to continue...", end='', flush=True)
                    input()
                else:
                    print("✗ Invalid choice")
                    print("\nPress Enter to continue...", end='', flush=True)
                    input()
            except ValueError:
                print("✗ Invalid input")
                print("\nPress Enter to continue...", end='', flush=True)
                input()

        except KeyboardInterrupt:
            print("\n✗ Cancelled")
            print("\nPress Enter to continue...", end='', flush=True)
            input()

        return True

    def select_gcal_account(self):
        """Select Google Calendar account for import/export

        Returns:
            str: Selected account name, or None if cancelled
        """
        # Discover available accounts
        account_manager = GoogleCalendarAccountManager()
        accounts = account_manager.discover_accounts()

        # ANSI color codes
        CYAN = '\033[96m'
        BOLD = '\033[1m'
        GREEN = '\033[92m'
        YELLOW = '\033[93m'
        RESET = '\033[0m'

        # If no accounts exist, guide user to create one
        if not accounts:
            print(f"\n{YELLOW}No Google Calendar accounts configured yet.{RESET}")
            print(f"\nWould you like to set up an account? (y/N): ", end='', flush=True)

            # Restore terminal
            fd = sys.stdin.fileno()
            old_settings = termios.tcgetattr(fd)
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
            termios.tcflush(fd, termios.TCIFLUSH)

            try:
                response = input().strip().lower()
                if response != 'y':
                    return None

                # Prompt for account name
                print(f"\nEnter account name (e.g., 'work', 'personal'): ", end='', flush=True)
                account_name = input().strip()

                if not account_name:
                    print("✗ Cancelled")
                    return None

                # Create account directory
                account_path = account_manager.create_account(account_name)

                # Provide instructions
                print(f"\n{GREEN}✓{RESET} Created account: {account_name}")
                print(f"\n{CYAN}{BOLD}Setup Instructions:{RESET}")
                print(f"1. Download credentials.json from Google Cloud Console:")
                print(f"   https://developers.google.com/workspace/calendar/api/quickstart/python")
                print(f"2. Save it to: {account_path / 'credentials.json'}")
                print(f"3. Run this command again to authenticate")

                return None

            except (KeyboardInterrupt, EOFError):
                print("\n✗ Cancelled")
                return None

        # Display account selection menu
        print(f"\n{CYAN}{BOLD}Select Google Calendar account:{RESET}")
        for i, account in enumerate(accounts, 1):
            print(f"  {i}. {account}")

        print(f"\n  {GREEN}[n]{RESET} Add new account")
        print(f"  {BOLD}ESC{RESET} Cancel\n")
        print("Choice: ", end='', flush=True)

        # Restore terminal
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        termios.tcflush(fd, termios.TCIFLUSH)

        # Get user input
        try:
            user_input = input().strip().lower()

            # Check for cancel
            if not user_input or user_input == '\x1b':
                print("✗ Cancelled")
                return None

            # Check for new account
            if user_input == 'n':
                print(f"\nEnter account name (e.g., 'work', 'personal'): ", end='', flush=True)
                account_name = input().strip()

                if not account_name:
                    print("✗ Cancelled")
                    return None

                # Create account directory
                account_path = account_manager.create_account(account_name)

                # Provide instructions
                print(f"\n{GREEN}✓{RESET} Created account: {account_name}")
                print(f"\n{CYAN}{BOLD}Setup Instructions:{RESET}")
                print(f"1. Download credentials.json from Google Cloud Console:")
                print(f"   https://developers.google.com/workspace/calendar/api/quickstart/python")
                print(f"2. Save it to: {account_path / 'credentials.json'}")
                print(f"3. Run this command again to authenticate")

                return None

            # Try as number
            try:
                choice_index = int(user_input) - 1
                if 0 <= choice_index < len(accounts):
                    return accounts[choice_index]
                else:
                    print("✗ Invalid number")
                    return None
            except ValueError:
                # Try as account name
                if user_input in accounts:
                    return user_input
                else:
                    print(f"✗ Account '{user_input}' not found")
                    return None

        except (KeyboardInterrupt, EOFError):
            print("\n✗ Cancelled")
            return None

    def _build_gcal_start_time(self, task_text):
        """Parse time tag from task text and build start_time datetime.

        Returns:
            (start_time, end_time, cleaned_text) — start_time/end_time are tz-aware datetimes
        """
        hour, minute, cleaned = extract_time_tag(task_text)
        if hour is not None:
            today = datetime.now().astimezone()
            start_time = today.replace(hour=hour, minute=minute, second=0, microsecond=0)
        else:
            start_time = round_to_15_minutes(datetime.now().astimezone())
            cleaned = task_text
        end_time = start_time + timedelta(minutes=15)
        return start_time, end_time, cleaned

    def _export_single_task(self, service, account_name, task):
        """Export a single task to Google Calendar. Returns True on success."""
        task_text = task['text']
        start_time, end_time, cleaned_text = self._build_gcal_start_time(task_text)

        RESET = '\033[0m'
        BOLD = '\033[1m'
        GREEN = '\033[92m'
        DIM = '\033[2m'

        event_link = create_gcal_event(service, cleaned_text, start_time=start_time)
        print(f"  {GREEN}✓{RESET} {BOLD}{cleaned_text}{RESET}")
        print(f"    {start_time.strftime('%-I:%M %p')} - {end_time.strftime('%-I:%M %p')}")
        if event_link:
            print(f"    {DIM}{event_link}{RESET}")
        return True

    def export_to_gcal(self):
        """Export task(s) to Google Calendar — single or bulk today"""
        if not GCAL_AVAILABLE:
            print("\n✗ Google Calendar API not available")
            print("   Install with: pip install google-auth google-auth-oauthlib")
            print("                  google-auth-httplib2 google-api-python-client")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        RESET = '\033[0m'
        BOLD = '\033[1m'
        CYAN = '\033[96m'
        DIM = '\033[2m'

        # Menu: single or bulk
        print(f"\n{BOLD}Export to Google Calendar:{RESET}")
        print(f"  {CYAN}1{RESET} Export current task")
        print(f"  {CYAN}2{RESET} Export all today's tasks")
        print(f"  {DIM}ESC to cancel{RESET}")

        choice = get_key(timeout=30.0)
        if choice not in ('1', '2'):
            print("✗ Cancelled")
            return True

        try:
            account_name = self.select_gcal_account()
            if not account_name:
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            auth = GoogleCalendarAuth(account_name)
            service = auth.get_service()

            if choice == '1':
                current_task = self.task_manager.get_current_task()
                if not current_task:
                    print("\n✗ No current task selected")
                else:
                    print(f"\n{DIM}Account: {account_name}{RESET}")
                    self._export_single_task(service, account_name, current_task)

            else:  # choice == '2'
                today = get_today_day_name()
                today_tasks = [
                    t for t in self.task_manager.tasks
                    if t.get('day') == today and not t.get('done')
                ]
                if not today_tasks:
                    print(f"\n✗ No tasks assigned to {today}")
                else:
                    print(f"\n{DIM}Account: {account_name}{RESET}")
                    print(f"Exporting {len(today_tasks)} {today} tasks:\n")
                    exported = 0
                    for task in today_tasks:
                        try:
                            self._export_single_task(service, account_name, task)
                            exported += 1
                        except Exception as e:
                            print(f"  ✗ {task['text']}: {e}")
                    print(f"\n✓ Exported {exported}/{len(today_tasks)} tasks")

        except FileNotFoundError as e:
            print(f"\n✗ {e}")
        except ImportError as e:
            print(f"\n✗ {e}")
        except HttpError as e:
            print(f"\n✗ Google Calendar API error: {e}")
        except Exception as e:
            print(f"\n✗ Failed to create event: {e}")

        print("\nPress Enter to continue...", end='', flush=True)
        input()
        return True

    def import_from_gcal(self):
        """Import Google Calendar events as tasks (1-7 days)"""
        # Check if Google Calendar API is available
        if not GCAL_AVAILABLE:
            print("\n✗ Google Calendar API not available")
            print("   Install with: pip install google-auth google-auth-oauthlib")
            print("                  google-auth-httplib2 google-api-python-client")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        try:
            # Color codes
            RESET = '\033[0m'
            BOLD = '\033[1m'
            GREEN = '\033[92m'
            CYAN = '\033[96m'
            DIM = '\033[2m'
            YELLOW = '\033[93m'

            # Prompt for direction (past/future)
            print(f"\n{CYAN}{BOLD}Import Google Calendar Events{RESET}")
            print(f"\nImport from:")
            print(f"  {BOLD}p{RESET} - Past days (catch up on previous events)")
            print(f"  {BOLD}f{RESET} - Future days (plan upcoming events)")
            print(f"  {BOLD}t{RESET} - Today only")
            print(f"\nDirection [{BOLD}t{RESET}]: ", end='', flush=True)

            # Read direction input
            fd = sys.stdin.fileno()
            old_settings = termios.tcgetattr(fd)
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
            termios.tcflush(fd, termios.TCIFLUSH)

            try:
                direction_input = input().strip().lower()
                if direction_input == '' or direction_input == 't':
                    direction = 'today'
                    days = 1
                elif direction_input == 'p':
                    direction = 'past'
                elif direction_input == 'f':
                    direction = 'future'
                else:
                    print("\n✗ Invalid option")
                    print("\nPress Enter to continue...", end='', flush=True)
                    input()
                    return True
            except (KeyboardInterrupt, EOFError):
                print("\n✗ Import cancelled")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            # If not today only, prompt for number of days
            if direction != 'today':
                if direction == 'past':
                    print(f"\nHow many past days to import? (1-7)")
                    print(f"{DIM}  1 = Yesterday only")
                    print(f"  2 = Yesterday and today")
                    print(f"  3-7 = Multiple past days{RESET}")
                else:  # future
                    print(f"\nHow many future days to import? (1-7)")
                    print(f"{DIM}  1 = Tomorrow only")
                    print(f"  2 = Tomorrow and next day")
                    print(f"  3-7 = Multiple upcoming days{RESET}")

                print(f"\nDays to import [{BOLD}1{RESET}]: ", end='', flush=True)

                try:
                    days_input = input().strip()
                    if days_input == '':
                        days = 1
                    else:
                        days = int(days_input)
                        days = max(1, min(7, days))  # Clamp to 1-7
                except (ValueError, KeyboardInterrupt, EOFError):
                    print("\n✗ Import cancelled")
                    print("\nPress Enter to continue...", end='', flush=True)
                    input()
                    return True

            # Select Google Calendar account
            account_name = self.select_gcal_account()
            if not account_name:
                # User cancelled or needs to set up credentials
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            # Initialize auth and get service
            auth = GoogleCalendarAuth(account_name)
            service = auth.get_service()

            # Fetch events based on direction
            if direction == 'today':
                events = fetch_gcal_events(service, days=1)
                days_text = "today"
            elif direction == 'past':
                events = fetch_gcal_events(service, days=days, direction='past')
                days_text = "yesterday" if days == 1 else f"the past {days} days"
            else:  # future
                events = fetch_gcal_events(service, days=days, direction='future')
                days_text = "tomorrow" if days == 1 else f"the next {days} days"

            if not events:
                print(f"\n📅 No events found for {days_text} (account: {account_name})")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            # Group events by day for display
            from datetime import datetime
            from collections import defaultdict
            events_by_day = defaultdict(list)
            for event in events:
                events_by_day[event['date']].append(event)

            # Display events grouped by day
            # days_text already set above based on direction
            print(
                f"\n{CYAN}{BOLD}Found {len(events)} event(s) for {days_text}:{RESET} {DIM}({account_name}){RESET}\n"
            )

            # Days of week names
            day_names = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']

            event_index = 1
            for date in sorted(events_by_day.keys()):
                day_events = events_by_day[date]

                # Format date header
                day_name = day_names[date.weekday()]
                today = datetime.now().date()
                is_today = date == today
                is_yesterday = date == today - timedelta(days=1)
                is_tomorrow = date == today + timedelta(days=1)
                date_str = date.strftime('%b %d')

                if is_today:
                    print(f"{YELLOW}{BOLD}Today ({day_name}, {date_str}):{RESET}")
                elif is_yesterday:
                    print(f"{BOLD}Yesterday ({day_name}, {date_str}):{RESET}")
                elif is_tomorrow:
                    print(f"{BOLD}Tomorrow ({day_name}, {date_str}):{RESET}")
                else:
                    print(f"{BOLD}{day_name}, {date_str}:{RESET}")

                # Display events for this day
                for event in day_events:
                    if event['all_day']:
                        print(f"  {event_index}. 📅 {event['summary']}")
                    else:
                        start_time = event['start'].strftime('%-I:%M %p')
                        end_time = event['end'].strftime('%-I:%M %p')
                        print(f"  {event_index}. {start_time} - {end_time}: {event['summary']}")
                    event_index += 1
                print()  # Blank line between days

            print(f"\n{BOLD}Import all as tasks?{RESET} (y/N): ", end='', flush=True)

            fd = sys.stdin.fileno()
            old_settings = termios.tcgetattr(fd)
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
            termios.tcflush(fd, termios.TCIFLUSH)

            try:
                confirmation = input().strip().lower()

                if confirmation == 'y':
                    # Import each event as a task
                    imported_count = 0
                    today = datetime.now().date()

                    for event in events:
                        # Add day prefix for multi-day imports (not today)
                        day_prefix = ""
                        if event['date'] != today:
                            # For past/future multi-day imports, add relative or absolute day
                            yesterday = today - timedelta(days=1)
                            tomorrow = today + timedelta(days=1)

                            if event['date'] == yesterday:
                                day_prefix = "[Yesterday] "
                            elif event['date'] == tomorrow:
                                day_prefix = "[Tomorrow] "
                            elif direction != 'today':  # Multi-day import
                                day_name = day_names[event['date'].weekday()][:3]  # Mon, Tue, etc
                                day_prefix = f"[{day_name}] "

                        if event['all_day']:
                            # All-day event: use emoji prefix
                            task_text = f"{day_prefix}📅 {event['summary']}"
                        else:
                            # Timed event: include time range
                            start_time = event['start'].strftime('%-I:%M %p')
                            end_time = event['end'].strftime('%-I:%M %p')
                            task_text = f"{day_prefix}{start_time} - {end_time}: {event['summary']}"

                        self.task_manager.add_task(task_text)
                        # Set notes from event description if present
                        description = event.get('description', '')
                        if description:
                            new_task = self.task_manager.tasks[-1]
                            new_task['notes'] = description
                            self.task_manager._save_tasks()
                        imported_count += 1

                    print(f"\n{GREEN}✓{RESET} Imported {imported_count} event(s) as tasks")
                else:
                    print("\n✗ Import cancelled")

            except (KeyboardInterrupt, EOFError):
                print("\n✗ Import cancelled")

        except FileNotFoundError as e:
            print(f"\n✗ {e}")
        except ImportError as e:
            print(f"\n✗ {e}")
        except HttpError as e:
            print(f"\n✗ Google Calendar API error: {e}")
        except Exception as e:
            print(f"\n✗ Failed to fetch events: {e}")

        print("\nPress Enter to continue...", end='', flush=True)
        input()
        return True

    def reauthenticate_google_calendar(self):
        """Force re-authentication with Google Calendar (Shift+3)"""
        GREEN = '\033[92m'
        YELLOW = '\033[93m'
        CYAN = '\033[96m'
        RESET = '\033[0m'
        BOLD = '\033[1m'

        try:
            if not GCAL_AVAILABLE:
                print(f"\n{YELLOW}⚠️  Google Calendar libraries not installed{RESET}")
                print(f"\nInstall with: pip install google-auth google-auth-oauthlib "
                      f"google-auth-httplib2 google-api-python-client")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            # Get account manager
            account_manager = GoogleCalendarAccountManager()
            accounts = account_manager.discover_accounts()

            if not accounts:
                print(f"\n{YELLOW}⚠️  No Google Calendar accounts configured{RESET}")
                print(f"\n{CYAN}{BOLD}Setup Instructions:{RESET}")
                print(f"1. Download credentials.json from Google Cloud Console:")
                print(f"   https://developers.google.com/workspace/calendar/api/quickstart/python")
                print(f"2. Create account: mkdir -p ~/.jot/gcal-accounts/default")
                print(f"3. Save credentials: ~/.jot/gcal-accounts/default/credentials.json")
                print(f"4. Try again with Shift+3")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            # Select account to re-authenticate
            account_name = self._select_gcal_account()
            if not account_name:
                return True

            account_path = account_manager.get_account_path(account_name)
            token_file = account_path / 'token.json'

            # Check if token exists
            if not token_file.exists():
                print(f"\n{YELLOW}⚠️  No token found for account '{account_name}'{RESET}")
                print(f"\n{CYAN}This account hasn't been authenticated yet.{RESET}")
                print(f"Use {BOLD}Shift+G{RESET} or {BOLD}Shift+I{RESET} to authenticate.")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            # Confirm deletion
            print(f"\n{CYAN}{BOLD}Re-authenticate Google Calendar{RESET}")
            print(f"Account: {account_name}")
            print(f"\nThis will:")
            print(f"  1. Delete the current authentication token")
            print(f"  2. Open a browser for re-authentication")
            print(f"  3. Save the new token")
            print(f"\n{YELLOW}Continue? (y/N):{RESET} ", end='', flush=True)

            response = input().strip().lower()
            if response != 'y':
                print("✗ Cancelled")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            # Delete token
            token_file.unlink()
            print(f"\n{GREEN}✓{RESET} Deleted authentication token")

            # Trigger re-authentication by creating GoogleCalendarAuth
            print(f"\n{CYAN}Opening browser for authentication...{RESET}")
            gcal_auth = GoogleCalendarAuth(account_name=account_name)
            gcal_auth.get_credentials()  # This will trigger OAuth flow

            print(f"\n{GREEN}✓ Re-authentication successful!{RESET}")
            print(f"\n{CYAN}You can now use:{RESET}")
            print(f"  {BOLD}Shift+G{RESET} - Export tasks to Google Calendar")
            print(f"  {BOLD}Shift+I{RESET} - Import events from Google Calendar")

        except FileNotFoundError as e:
            print(f"\n{YELLOW}⚠️  {e}{RESET}")
        except ImportError as e:
            print(f"\n{YELLOW}⚠️  {e}{RESET}")
        except Exception as e:
            print(f"\n{YELLOW}⚠️  Re-authentication failed: {e}{RESET}")

        print("\nPress Enter to continue...", end='', flush=True)
        input()
        return True

    def start_priority_timer(self):
        """Launch bullet priority timer for current task"""

        current_task = self.task_manager.get_current_task()

        # Display info message
        RESET = '\033[0m'
        BOLD = '\033[1m'
        YELLOW = '\033[93m'

        if current_task:
            task_text = current_task['text']
            print(f"\n{YELLOW}🔥 Starting priority timer for:{RESET} {BOLD}{task_text}{RESET}")
        else:
            print(f"\n{YELLOW}🔥 Starting priority timer...{RESET}")

        print("Duration: 12 minutes (default)")
        print("\nPress Enter to continue...", end='', flush=True)
        input()

        # Launch bullet priority timer in background
        try:
            subprocess.Popen(
                ['bullet', 'priority'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
            )
            print("\n✓ Priority timer started")
        except FileNotFoundError:
            print("\n✗ bullet command not found")
            print("   Install: cd ~/projects/bullet && npm link")
        except Exception as e:
            print(f"\n✗ Failed to start timer: {e}")

        print("\nPress Enter to continue...", end='', flush=True)
        input()
        return True

    def copy_to_clipboard(self):
        """Copy current task text to clipboard"""
        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        task_text = current_task['text']

        # Copy to clipboard using pbcopy (macOS) or xclip/xsel (Linux)

        try:
            system = platform.system()
            if system == 'Darwin':  # macOS
                process = subprocess.Popen(
                    ['pbcopy'], stdin=subprocess.PIPE, stdout=subprocess.DEVNULL
                )
                process.communicate(task_text.encode('utf-8'))
            elif system == 'Linux':
                # Try xclip first, then xsel
                try:
                    process = subprocess.Popen(
                        ['xclip', '-selection', 'clipboard'],
                        stdin=subprocess.PIPE,
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                    )
                    process.communicate(task_text.encode('utf-8'))
                except FileNotFoundError:
                    process = subprocess.Popen(
                        ['xsel', '--clipboard', '--input'],
                        stdin=subprocess.PIPE,
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                    )
                    process.communicate(task_text.encode('utf-8'))
            else:
                print(f"\n✗ Clipboard not supported on {system}")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            # Success message
            CYAN = '\033[96m'
            RESET = '\033[0m'
            DIM = '\033[2m'

            # Truncate long text for display
            display_text = task_text if len(task_text) <= 60 else task_text[:57] + '...'

            print(f"\n{CYAN}✓ Copied to clipboard:{RESET}")
            print(f"  {DIM}{display_text}{RESET}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()

        except FileNotFoundError as e:
            print(f"\n✗ Clipboard tool not found: {e}")
            print("   Install xclip or xsel on Linux")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
        except Exception as e:
            print(f"\n✗ Failed to copy to clipboard: {e}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()

        return True

    def trigger_keyword_action(self):
        """Manually trigger keyword action for current task"""
        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        keyword = current_task.get('keyword')
        if not keyword:
            print("\n✗ Current task has no keyword")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        # ANSI color codes
        CYAN = '\033[96m'
        RESET = '\033[0m'
        DIM = '\033[2m'

        # Trigger the keyword action
        result = self.task_manager.keyword_handler.handle(keyword, current_task)

        if result:
            # Save task if handler modified it
            self.task_manager._save_tasks()

            print(f"\n{CYAN}✓ Executed keyword action:{RESET}")
            print(f"  {DIM}Keyword: {keyword}{RESET}")
            print(f"  {DIM}{result}{RESET}")
        else:
            print(f"\n✗ Unknown keyword: {keyword}")

        print("\nPress Enter to continue...", end='', flush=True)
        input()
        return True

    def get_notes_file_extension(self, editor):
        """Determine file extension based on editor

        Args:
            editor: Editor command string from $EDITOR

        Returns:
            File extension string (e.g., '.org', '.txt')
        """
        editor_lower = editor.lower()

        # Detect Emacs variants (emacs, emacsclient, etc.) -> org-mode
        if 'emacs' in editor_lower:
            return '.org'
        # Default to plain text for other editors
        else:
            return '.txt'

    def edit_task_notes(self):
        """Edit notes for the current task using $EDITOR"""

        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        task_id = current_task['id']
        task_text = current_task['text']

        # Get current notes
        current_notes = self.task_manager.get_task_notes(task_id)

        # Determine editor to use
        editor = os.environ.get('EDITOR', os.environ.get('VISUAL', 'nano'))

        # Determine file extension based on editor
        file_extension = self.get_notes_file_extension(editor)
        is_org_mode = file_extension == '.org'

        # Create temporary file with current notes
        with tempfile.NamedTemporaryFile(mode='w+', suffix=file_extension, delete=False) as tf:
            temp_file = tf.name
            # Write help header with appropriate comment syntax
            if is_org_mode:
                tf.write(f"#+TITLE: Notes for task: {task_text}\n")
                tf.write("#+COMMENT: Lines starting with #+COMMENT will be ignored\n")
                tf.write("\n")
            else:
                tf.write(f"# Notes for task: {task_text}\n")
                tf.write("# Lines starting with # will be ignored\n")
                tf.write("#\n")
            if current_notes:
                tf.write(current_notes)

        try:
            # Launch editor safely (no command injection)
            self.safe_launch_editor(temp_file)

            # Read edited content
            with open(temp_file, 'r') as f:
                lines = f.readlines()

            # Filter out comment lines based on file type
            if is_org_mode:
                # For org-mode, filter out #+TITLE, #+COMMENT, and other #+directives
                edited_notes = ''.join(
                    line for line in lines if not line.strip().startswith('#+')
                ).strip()
            else:
                # For plain text, filter out # comments
                edited_notes = ''.join(
                    line for line in lines if not line.strip().startswith('#')
                ).strip()

            # Save notes
            self.task_manager.set_task_notes(task_id, edited_notes)

            # Sync subtasks from checklist items in notes
            sync_result = self.task_manager.sync_subtasks_from_notes(task_id)

            # Show confirmation
            CYAN = '\033[96m'
            RESET = '\033[0m'
            DIM = '\033[2m'

            if edited_notes:
                # Show preview of notes (first 3 lines)
                note_lines = edited_notes.split('\n')
                preview = '\n  '.join(note_lines[:3])
                if len(note_lines) > 3:
                    preview += f"\n  {DIM}... ({len(note_lines)} lines total){RESET}"

                print(f"\n{CYAN}✓ Notes saved:{RESET}")
                print(f"  {DIM}{preview}{RESET}")
            else:
                print(f"\n{CYAN}✓ Notes cleared{RESET}")

            # Show subtask sync summary
            if sync_result and (sync_result['created'] or sync_result['updated']):
                parts = []
                if sync_result['created']:
                    parts.append(f"{sync_result['created']} created")
                if sync_result['updated']:
                    parts.append(f"{sync_result['updated']} updated")
                print(f"{CYAN}✓ Subtasks synced: {', '.join(parts)}{RESET}")

            print("\nPress Enter to continue...", end='', flush=True)
            input()

        except FileNotFoundError:
            print(f"\n✗ Editor not found: {editor}")
            print(f"   Set $EDITOR environment variable or install nano")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
        except Exception as e:
            print(f"\n✗ Failed to edit notes: {e}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
        finally:
            # Clean up temp file
            try:
                os.unlink(temp_file)
            except Exception:
                pass

        return True

    def sync_subtasks(self):
        """Manually sync subtasks from current task's notes (Ctrl+S)"""

        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        task_id = current_task['id']
        notes = current_task.get('notes', '')
        if not notes:
            print("\n✗ No notes on current task")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        result = self.task_manager.sync_subtasks_from_notes(task_id)

        CYAN = '\033[96m'
        RESET = '\033[0m'

        if result['created'] or result['updated']:
            parts = []
            if result['created']:
                parts.append(f"{result['created']} created")
            if result['updated']:
                parts.append(f"{result['updated']} updated")
            print(f"\n{CYAN}✓ Subtasks synced: {', '.join(parts)}{RESET}")
        elif result['total'] > 0:
            print(f"\n{CYAN}✓ {result['total']} subtasks already in sync{RESET}")
        else:
            print("\n✗ No checklist items found in notes (use '- [ ] task' format)")

        print("\nPress Enter to continue...", end='', flush=True)
        input()
        return True

    def ultrathink_task(self):
        """Analyze current task with Claude Code"""

        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        task_id = current_task['id']
        task_text = current_task['text']
        notes = current_task.get('notes', '')

        # Check if analysis already exists
        existing_analysis = Path.cwd() / f".jot.analysis.{task_id}.org"
        if existing_analysis.exists():
            # Ask if user wants to re-analyze
            print(f"\n⚠️  Analysis already exists: {existing_analysis.name}")
            print("\nOptions:")
            print("  [Enter] - View existing analysis")
            print("  [r]     - Re-analyze (overwrite)")
            print("  [c]     - Custom prompt re-analysis")
            print("  [q]     - Cancel")
            choice = input("\nChoice: ").strip().lower()

            if choice == 'q' or choice == '':
                if choice == '':
                    # View existing analysis
                    self.safe_launch_editor(existing_analysis)
                return True
            elif choice not in ['r', 'c']:
                return True

            if choice == 'c':
                # Get custom prompt
                print("\nEnter custom analysis focus (or press Enter for default):")
                print(
                    "Examples: 'security implications', 'performance optimization', 'test coverage'"
                )
                custom_focus = input("Focus: ").strip()
            else:
                custom_focus = None
        else:
            # New analysis - ask if user wants custom prompt
            print(f"\n🤔 Analyze: {task_text[:60]}{'...' if len(task_text) > 60 else ''}")
            print("\nOptions:")
            print("  [Enter] - Standard analysis")
            print("  [c]     - Custom analysis prompt")
            print("  [q]     - Cancel")
            choice = input("\nChoice: ").strip().lower()

            if choice == 'q':
                return True
            elif choice == 'c':
                print("\nEnter custom analysis focus:")
                print(
                    "Examples: 'security implications', 'performance optimization', 'test coverage'"
                )
                custom_focus = input("Focus: ").strip()
                if not custom_focus:
                    custom_focus = None
            else:
                custom_focus = None

        # Build analysis prompt
        notes_section = f"\n\nTask Notes:\n{notes}" if notes else ""

        if custom_focus:
            prompt = f"""Analyze this task with a focus on: {custom_focus}

Task: {task_text}{notes_section}

Please provide a detailed analysis in org-mode format, specifically addressing {custom_focus}.

Include relevant sections such as:
* Task Analysis
* {custom_focus.title()}
* Implementation Approach
* Acceptance Criteria
* Potential Risks

Format as a well-structured org-mode document."""
        else:
            # Default prompt (same as keyword handler)
            prompt = f"""Analyze this task and provide a structured implementation plan in org-mode format.

Task: {task_text}{notes_section}

Please create an org-mode document with the following sections:

* Task Analysis
** Overview
Brief description of what needs to be done

** Task Breakdown
- [ ] Subtask 1
- [ ] Subtask 2
- [ ] Subtask 3

** Technical Approach
Key technical decisions and implementation strategy

** Acceptance Criteria
- Criterion 1
- Criterion 2
- Criterion 3

** Complexity Estimate
Simple / Medium / Complex (with justification)

** Potential Risks
Any challenges or unknowns to consider

Format the entire response as a well-structured org-mode document."""

        # Show loading indicator
        CYAN = '\033[96m'
        RESET = '\033[0m'
        DIM = '\033[2m'
        GREEN = '\033[92m'
        YELLOW = '\033[93m'

        print(f"\n{CYAN}⏳ Analyzing with Claude Code...{RESET}")
        print(f"{DIM}This may take 10-15 seconds...{RESET}\n")

        try:
            # Check if claude CLI is available
            check_result = subprocess.run(['claude', '--version'], capture_output=True, timeout=5)

            if check_result.returncode != 0:
                print(f"{YELLOW}⚠️ Claude CLI not found.{RESET}")
                print("Install: https://claude.com/claude-code")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

        except (FileNotFoundError, subprocess.TimeoutExpired):
            print(f"{YELLOW}⚠️ Claude CLI not found.{RESET}")
            print("Install: https://claude.com/claude-code")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        try:
            # Invoke Claude in plan mode with JSON output
            result = subprocess.run(
                [
                    'claude',
                    '--print',
                    '--permission-mode',
                    'plan',
                    '--output-format',
                    'json',
                    '--max-turns',
                    '5',
                ],
                input=prompt,
                capture_output=True,
                text=True,
                timeout=120,  # 2 minute timeout
            )

            if result.returncode != 0:
                # Check for common errors
                stderr_lower = result.stderr.lower()

                if 'authentication' in stderr_lower or 'login' in stderr_lower:
                    print(f"{YELLOW}⚠️ Claude auth expired.{RESET}")
                    print("Run: claude login")
                elif 'network' in stderr_lower or 'connection' in stderr_lower:
                    print(f"{YELLOW}⚠️ Network error.{RESET}")
                    print("Check connection and try again")
                else:
                    error_msg = result.stderr[:100] if result.stderr else "Unknown error"
                    print(f"{YELLOW}⚠️ Claude failed: {error_msg}{RESET}")

                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            # Parse JSON response
            try:
                response = json.loads(result.stdout)
                analysis_text = response.get('result', '')

                if not analysis_text:
                    print(f"{YELLOW}⚠️ Empty response from Claude{RESET}")
                    print("\nPress Enter to continue...", end='', flush=True)
                    input()
                    return True

            except json.JSONDecodeError:
                print(f"{YELLOW}⚠️ Failed to parse Claude response{RESET}")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            # Save to .jot.analysis.{id}.org file
            output_file = Path.cwd() / f".jot.analysis.{task_id}.org"

            try:
                with open(output_file, 'w') as f:
                    f.write(f"#+TITLE: Analysis for Task {task_id}\n")
                    f.write(f"#+DATE: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n")
                    f.write(f"#+TASK: {task_text}\n")
                    if custom_focus:
                        f.write(f"#+FOCUS: {custom_focus}\n")
                    f.write("\n")
                    f.write(analysis_text)

                # Store analysis file reference in task
                current_task['analysis_file'] = str(output_file)
                self.task_manager._save_tasks()

                # Get cost from response
                cost = response.get('total_cost_usd', 0)
                cost_str = f" (${cost:.3f})" if cost > 0 else ""

                print(f"{GREEN}✓ Analysis saved to {output_file.name}{cost_str}{RESET}\n")

                # Ask if user wants to open in editor
                print("Open analysis in editor? [Y/n]: ", end='', flush=True)
                open_choice = input().strip().lower()

                if open_choice != 'n':
                    self.safe_launch_editor(output_file)

            except IOError as e:
                print(f"{YELLOW}⚠️ Failed to save analysis: {e}{RESET}")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

        except subprocess.TimeoutExpired:
            print(f"{YELLOW}⚠️ Analysis timed out (120s).{RESET}")
            print("Task may be too complex or network slow")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True
        except Exception as e:
            print(f"{YELLOW}⚠️ Analysis error: {e}{RESET}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        return True

    def suggest_task(self):
        """Analyze tasks and suggest a new one using Claude (Shift+4)"""
        tasks = self.task_manager.tasks
        archived = self.task_manager.archived

        if not tasks and not archived:
            print("\n✗ No tasks or archive history to analyze")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        CYAN = '\033[96m'
        RESET = '\033[0m'
        DIM = '\033[2m'

        print(f"\n{CYAN}⏳ Analyzing tasks for suggestion...{RESET}")
        print(f"{DIM}This may take 10-15 seconds...{RESET}\n")

        prompt = self._build_suggestion_prompt(tasks, archived)
        suggestion = self._call_claude_for_suggestion(prompt)

        if suggestion:
            self._present_suggestion(suggestion)

        return True

    def _build_suggestion_prompt(self, tasks, archived):
        """Build prompt for AI task suggestion"""
        lines = [
            "Analyze these tasks and suggest ONE new task to add.",
            "Return ONLY valid JSON with no other text.",
            "",
            "Active tasks:",
        ]

        for t in tasks:
            notes = t.get('notes', '')
            if len(notes) > 100:
                notes = notes[:100] + '...'
            lines.append(json.dumps({
                'id': t.get('id'),
                'text': t.get('text', ''),
                'priority': t.get('priority', 'none'),
                'labels': t.get('labels', []),
                'effort': t.get('effort'),
                'status': t.get('status', 'todo'),
                'day': t.get('day'),
                'notes': notes,
            }))

        recent_archived = archived[-20:] if len(archived) > 20 else archived
        if recent_archived:
            lines.append("")
            lines.append("Recently completed tasks:")
            for t in recent_archived:
                lines.append(json.dumps({
                    'id': t.get('id'),
                    'text': t.get('text', ''),
                    'labels': t.get('labels', []),
                    'priority': t.get('priority', 'none'),
                }))

        lines.append("")
        lines.append(
            "Based on patterns, gaps, and logical next steps, "
            "suggest ONE new task. Return strict JSON:"
        )
        lines.append(
            '{"text": "task description", "priority": "none|low|medium|high", '
            '"labels": ["label1"], "effort": 1-5, '
            '"reasoning": "why this task"}'
        )

        return "\n".join(lines)

    def _call_claude_for_suggestion(self, prompt):
        """Call Claude CLI and parse suggestion JSON"""
        YELLOW = '\033[93m'
        RESET = '\033[0m'

        try:
            check_result = subprocess.run(
                ['claude', '--version'], capture_output=True, timeout=5
            )
            if check_result.returncode != 0:
                print(f"{YELLOW}⚠️ Claude CLI not found.{RESET}")
                print("Install: https://claude.com/claude-code")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return None
        except (FileNotFoundError, subprocess.TimeoutExpired):
            print(f"{YELLOW}⚠️ Claude CLI not found.{RESET}")
            print("Install: https://claude.com/claude-code")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return None

        try:
            result = subprocess.run(
                [
                    'claude', '--print',
                    '--permission-mode', 'plan',
                    '--output-format', 'json',
                    '--max-turns', '5',
                ],
                input=prompt,
                capture_output=True,
                text=True,
                timeout=120,
            )

            if result.returncode != 0:
                error_msg = result.stderr[:100] if result.stderr else "Unknown error"
                print(f"{YELLOW}⚠️ Claude failed: {error_msg}{RESET}")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return None

            # Parse outer JSON envelope
            response = json.loads(result.stdout)
            inner_text = response.get('result', '')

            if not inner_text:
                print(f"{YELLOW}⚠️ Empty response from Claude{RESET}")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return None

            # Strip markdown code fences if present
            cleaned = inner_text.strip()
            if cleaned.startswith('```'):
                first_newline = cleaned.index('\n')
                cleaned = cleaned[first_newline + 1:]
            if cleaned.endswith('```'):
                cleaned = cleaned[:-3]
            cleaned = cleaned.strip()

            suggestion = json.loads(cleaned)

            if 'text' not in suggestion:
                print(f"{YELLOW}⚠️ Invalid suggestion format (missing 'text'){RESET}")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return None

            return suggestion

        except subprocess.TimeoutExpired:
            print(f"{YELLOW}⚠️ Suggestion timed out (120s).{RESET}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return None
        except json.JSONDecodeError:
            print(f"{YELLOW}⚠️ Failed to parse suggestion JSON{RESET}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return None
        except Exception as e:
            print(f"{YELLOW}⚠️ Suggestion error: {e}{RESET}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return None

    def _present_suggestion(self, suggestion):
        """Display suggestion and prompt for approval"""
        CYAN = '\033[96m'
        GREEN = '\033[92m'
        YELLOW = '\033[93m'
        BOLD = '\033[1m'
        DIM = '\033[2m'
        RESET = '\033[0m'

        text = suggestion.get('text', '')
        priority = suggestion.get('priority', 'none')
        labels = suggestion.get('labels', [])
        effort = suggestion.get('effort')
        reasoning = suggestion.get('reasoning', '')

        print(f"\n{BOLD}💡 Suggested Task:{RESET}")
        print(f"   {CYAN}{text}{RESET}")
        if priority != 'none':
            print(f"   Priority: {priority}")
        if labels:
            print(f"   Labels: {', '.join(labels)}")
        if effort:
            print(f"   Effort: {effort}/5")
        if reasoning:
            print(f"\n   {DIM}Reasoning: {reasoning}{RESET}")

        print(f"\n   Add this task? [y/N]: ", end='', flush=True)
        try:
            choice = input().strip().lower()
        except (EOFError, KeyboardInterrupt):
            print("\n✗ Cancelled")
            return

        if choice == 'y':
            self.task_manager.add_task(
                text,
                priority=priority,
                labels=labels if labels else None,
                effort=effort,
            )
            print(f"   {GREEN}✓ Task added{RESET}")
        else:
            print(f"   {DIM}Suggestion discarded{RESET}")

    def execute_analysis_task(self):
        """Execute analysis plan with Claude Code (Shift+0)"""

        CYAN = '\033[96m'
        RESET = '\033[0m'
        GREEN = '\033[92m'
        YELLOW = '\033[93m'
        DIM = '\033[2m'

        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        task_id = current_task['id']
        task_text = current_task['text']

        # Check if analysis file exists
        analysis_file = Path.cwd() / f".jot.analysis.{task_id}.org"
        if not analysis_file.exists():
            print(f"\n{YELLOW}⚠️  No analysis found for this task{RESET}")
            print(f"\n{DIM}Tip: Press Shift+9 to analyze first, then Shift+0 to execute{RESET}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        # Read analysis file
        try:
            with open(analysis_file, 'r') as f:
                analysis_content = f.read()
        except IOError as e:
            print(f"\n{YELLOW}⚠️  Failed to read analysis file: {e}{RESET}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        # Generate session UUID from task ID (deterministic)
        session_uuid = str(uuid.uuid5(uuid.NAMESPACE_DNS, f"jot.task.{task_id}"))

        # Check for existing execution
        execution_history = current_task.get('execution_history', [])
        if execution_history:
            last_execution = execution_history[-1]
            print(f"\n{CYAN}Previous execution found:{RESET}")
            print(f"  Started: {last_execution.get('started_at', 'unknown')}")
            print(f"  Status: {last_execution.get('status', 'unknown')}")
            print("\nOptions:")
            print("  [Enter] - Resume existing session")
            print("  [n]     - Start new execution")
            print("  [q]     - Cancel")
            choice = input("\nChoice: ").strip().lower()

            if choice == 'q':
                return True
            elif choice == 'n':
                # Generate new session ID
                session_uuid = str(uuid.uuid4())

        # Build system prompt with analysis
        system_prompt = f"""You are implementing a task from the jot task manager.

TASK: {task_text}

ANALYSIS PLAN:
{analysis_content}

Follow the implementation plan above. Execute it step by step, making commits as appropriate.
When complete, mark the jot task as done if appropriate."""

        # Prepare Terminal command
        # Use AppleScript on macOS to open new Terminal window

        system = platform.system()

        print(f"\n{CYAN}🚀 Launching Claude Code...{RESET}")
        print(f"{DIM}Task ID: {task_id}{RESET}")
        print(f"{DIM}Session: {session_uuid[:8]}...{RESET}")
        print(f"{DIM}Analysis: {analysis_file.name}{RESET}\n")

        # Store execution metadata
        execution_record = {
            'session_id': session_uuid,
            'started_at': datetime.now().isoformat(),
            'status': 'in_progress',
            'analysis_file': str(analysis_file),
        }

        if 'execution_history' not in current_task:
            current_task['execution_history'] = []
        current_task['execution_history'].append(execution_record)

        # Mark as agent task
        if 'agent_task' not in current_task or not current_task['agent_task']:
            current_task['agent_task'] = True

        self.task_manager._save_tasks()

        try:
            if system == 'Darwin':  # macOS
                # Write system prompt to temp file for easier passing

                with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as tf:
                    tf.write(system_prompt)
                    temp_prompt_file = tf.name

                # AppleScript to open new Terminal with claude command
                applescript = f'''
                tell application "Terminal"
                    activate
                    do script "claude --session-id {session_uuid} --system-prompt \\"$(cat {temp_prompt_file})\\" && rm {temp_prompt_file}"
                end tell
                '''

                subprocess.run(['osascript', '-e', applescript], check=True)

                print(f"{GREEN}✓ Terminal launched{RESET}")
                print(f"\n{DIM}Claude Code is running in a new Terminal window{RESET}")
                print(f"{DIM}Session ID: {session_uuid}{RESET}")

            elif system == 'Linux':
                # Try common Linux terminal emulators
                terminals = ['gnome-terminal', 'konsole', 'xterm']
                launched = False

                for terminal in terminals:
                    try:
                        if terminal == 'gnome-terminal':
                            subprocess.Popen(
                                [
                                    terminal,
                                    '--',
                                    'bash',
                                    '-c',
                                    f'claude --session-id {session_uuid} --system-prompt "{system_prompt}"; exec bash',
                                ]
                            )
                        else:
                            subprocess.Popen(
                                [
                                    terminal,
                                    '-e',
                                    f'claude --session-id {session_uuid} --system-prompt "{system_prompt}"',
                                ]
                            )
                        launched = True
                        print(f"{GREEN}✓ Terminal launched ({terminal}){RESET}")
                        break
                    except FileNotFoundError:
                        continue

                if not launched:
                    print(f"{YELLOW}⚠️  Could not find terminal emulator{RESET}")
                    print(f"\n{DIM}Run this command manually:{RESET}")
                    print(
                        f'claude --session-id {session_uuid} --system-prompt "$(cat {analysis_file})"'
                    )

            else:
                # Windows or other
                print(f"{YELLOW}⚠️  Auto-launch not supported on {system}{RESET}")
                print(f"\n{DIM}Run this command manually:{RESET}")
                print(
                    f'claude --session-id {session_uuid} --system-prompt "$(cat {analysis_file})"'
                )

        except Exception as e:
            print(f"{YELLOW}⚠️  Failed to launch Terminal: {e}{RESET}")
            print(f"\n{DIM}Run this command manually:{RESET}")
            print(f'claude --session-id {session_uuid} --system-prompt "$(cat {analysis_file})"')

        print("\nPress Enter to continue...", end='', flush=True)
        input()
        return True

    def read_tasks_aloud(self):
        """Read all tasks in current category aloud using TTS (Shift+2)"""
        GREEN = '\033[92m'
        YELLOW = '\033[93m'
        CYAN = '\033[96m'
        RESET = '\033[0m'
        DIM = '\033[2m'

        # Check if TTS is available
        if not TTS_AVAILABLE:
            print(f"\n{YELLOW}⚠️  Text-to-speech not available{RESET}")
            print(f"{DIM}Install pyttsx3: pip install pyttsx3{RESET}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        # Get TTS configuration
        cat_config = CategoryConfig(project_dir=self.task_manager.project_dir)
        tts_config = cat_config.get_tts_config()

        if not tts_config.get('enabled', True):
            print(f"\n{YELLOW}⚠️  Text-to-speech is disabled in configuration{RESET}")
            print(f"{DIM}Edit .jot.config.json to enable{RESET}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        # Get tasks to read
        tasks = self.task_manager.tasks
        if not tasks:
            print(f"\n{YELLOW}⚠️  No tasks to read{RESET}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        # Initialize TTS engine
        try:
            engine = pyttsx3.init()

            # Apply configuration
            engine.setProperty('rate', tts_config.get('rate', 150))
            engine.setProperty('volume', tts_config.get('volume', 0.9))

            # Set voice if specified
            voice_name = tts_config.get('voice')
            if voice_name:
                voices = engine.getProperty('voices')
                for voice in voices:
                    if voice_name in voice.name:
                        engine.setProperty('voice', voice.id)
                        break

        except Exception as e:
            print(f"\n{YELLOW}⚠️  Failed to initialize TTS: {e}{RESET}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        # Read category name if set
        category_name = self.task_manager.category or "default"
        print(f"\n{CYAN}🔊 Reading {len(tasks)} tasks from {category_name} category...{RESET}\n")

        try:
            # Queue all tasks first, then speak
            for i, task in enumerate(tasks, 1):
                task_text = task['text']
                print(f"{DIM}{i}. {task_text}{RESET}")
                # Queue the speech
                engine.say(f"Task {i}. {task_text}")

            # Now speak all queued tasks
            engine.runAndWait()

            print(f"\n{GREEN}✓ Finished reading {len(tasks)} tasks{RESET}")

        except KeyboardInterrupt:
            print(f"\n{YELLOW}⚠️  Reading interrupted{RESET}")
            engine.stop()
        except Exception as e:
            print(f"\n{YELLOW}⚠️  Error during reading: {e}{RESET}")
        finally:
            try:
                engine.stop()
            except Exception:
                pass

        print("\nPress Enter to continue...", end='', flush=True)
        input()
        return True

    def switch_category(self):
        """Switch to a different category (local or global)"""
        # Get current project directory
        project_dir = (
            self.task_manager.project_dir if not self.task_manager.is_global else Path.cwd()
        )

        # Discover available categories
        cat_manager = CategoryManager(project_dir=project_dir)
        local_categories = cat_manager.discover_categories()
        global_categories = cat_manager.discover_global_categories()

        # Build category list with type indicators
        categories = []

        # Add "default" option (no category)
        categories.append(("default", None, False))

        # Add local categories
        for cat in local_categories:
            categories.append((cat, cat, False))

        # Add global categories
        for cat in global_categories:
            # Skip if already exists locally (avoid duplicates)
            if cat not in local_categories:
                categories.append((cat, cat, True))

        # Always show picker - even with just default, user can create new categories
        # if not categories:  # This should never happen as we always add default
        #     print("\n✗ No categories available")
        #     return True

        # Display available categories
        CYAN = '\033[96m'
        BOLD = '\033[1m'
        RESET = '\033[0m'

        # Get category config for colors
        cat_config = CategoryConfig(project_dir=project_dir)

        print(f"\n{CYAN}{BOLD}Switch to category:{RESET}")
        for i, (display_name, cat_name, is_global) in enumerate(categories, 1):
            if display_name == "default":
                cat_color = cat_config.get_color('default')
                print(f"  {i}. {cat_color}default (no category){RESET}")
            else:
                cat_color = cat_config.get_color(cat_name, for_global=is_global)
                if is_global:
                    print(f"  {i}. {cat_color}{cat_name} [global]{RESET}")
                else:
                    print(f"  {i}. {cat_color}{cat_name} [local]{RESET}")

        print("\nEnter number or name (ESC to cancel): ", end='', flush=True)

        # Restore terminal to normal mode and flush any pending input
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        termios.tcflush(fd, termios.TCIFLUSH)  # Flush input buffer

        # Get user input
        try:
            user_input = input().strip()

            # Check if ESC or empty
            if not user_input or user_input == '\x1b':
                print("✗ Cancelled")
                return True

            # Try as number first
            selected_category = None
            selected_is_global = False

            try:
                choice_index = int(user_input) - 1
                if 0 <= choice_index < len(categories):
                    display_name, cat_name, is_global = categories[choice_index]
                    selected_category = cat_name
                    selected_is_global = is_global
                else:
                    print("✗ Invalid number")
                    return True
            except ValueError:
                # Try as category name
                found = False
                for display_name, cat_name, is_global in categories:
                    if cat_name == user_input or display_name == user_input:
                        selected_category = cat_name
                        selected_is_global = is_global
                        found = True
                        break

                if not found:
                    # Category doesn't exist - offer to create it
                    YELLOW = '\033[93m'
                    RESET = '\033[0m'
                    print(f"\n{YELLOW}Category '{user_input}' doesn't exist yet.{RESET}")
                    print("Create as:")
                    print("  1. Local (this project only)")
                    print("  2. Global (available in all projects)")
                    print("\nChoice (1/2, ESC to cancel): ", end='', flush=True)

                    try:
                        choice = input().strip()
                        if not choice or choice == '\x1b':
                            print("✗ Cancelled")
                            return True

                        if choice == '1' or choice.lower() == 'local':
                            # Check local category limit
                            can_create, error_msg = cat_manager.can_create_category(user_input)
                            if not can_create:
                                print(f"✗ {error_msg}")
                                return True

                            # Show warning if approaching limit
                            warning_msg = cat_manager.get_warning_message(user_input)
                            if warning_msg:
                                print(warning_msg)

                            selected_category = user_input
                            selected_is_global = False
                        elif choice == '2' or choice.lower() == 'global':
                            selected_category = user_input
                            selected_is_global = True
                        else:
                            print("✗ Invalid choice")
                            return True
                    except KeyboardInterrupt:
                        print("\n✗ Cancelled")
                        return True

            # Return the selected category info to trigger reload
            # We'll need to modify the main loop to handle this
            return ('switch_category', selected_category, selected_is_global)

        except KeyboardInterrupt:
            print("\n✗ Cancelled")
            return True

    def switch_project(self):
        """Switch to a different registered project"""
        # Get all registered projects
        all_projects = self.registry.list_projects()

        if not all_projects:
            print("\n✗ No projects registered")
            print("Run 'jott --refresh' to discover projects or '--register' to add one manually")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        # Get current project path to exclude it from the list
        current_project_path = str(self.task_manager.project_dir)

        # Build list of projects excluding current one
        available_projects = {}
        for name, path in all_projects.items():
            if path != current_project_path:
                available_projects[name] = path

        if not available_projects:
            print("\n✗ No other projects available")
            print("You are in the only registered project")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        # Display available projects
        CYAN = '\033[96m'
        BOLD = '\033[1m'
        RESET = '\033[0m'
        DIM = '\033[2m'

        print(f"\n{CYAN}{BOLD}Switch to project:{RESET}")
        project_list = sorted(available_projects.keys())
        for i, name in enumerate(project_list, 1):
            path = available_projects[name]
            print(f"  {i}. {BOLD}{name}{RESET} {DIM}→ {path}{RESET}")

        print("\nEnter number or name (ESC to cancel): ", end='', flush=True)

        # Restore terminal to normal mode and flush any pending input
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        termios.tcflush(fd, termios.TCIFLUSH)  # Flush input buffer

        # Get user input
        try:
            user_input = input().strip()

            # Check if ESC or empty
            if not user_input or user_input == '\x1b':
                print("✗ Cancelled")
                return True

            # Try as number first
            selected_project_name = None
            selected_project_path = None

            try:
                choice_index = int(user_input) - 1
                if 0 <= choice_index < len(project_list):
                    selected_project_name = project_list[choice_index]
                    selected_project_path = available_projects[selected_project_name]
                else:
                    print("✗ Invalid number")
                    return True
            except ValueError:
                # Try as project name
                if user_input in available_projects:
                    selected_project_name = user_input
                    selected_project_path = available_projects[user_input]
                else:
                    print(f"✗ Project '{user_input}' not found")
                    return True

            # Return the selected project info to trigger reload
            return ('switch_project', selected_project_name, selected_project_path)

        except KeyboardInterrupt:
            print("\n✗ Cancelled")
            return True

    def register_current_project(self):
        """Register the current project in the global project registry"""
        CYAN = '\033[96m'
        BOLD = '\033[1m'
        RESET = '\033[0m'
        DIM = '\033[2m'
        YELLOW = '\033[93m'

        # Get current project directory
        current_dir = self.task_manager.project_dir

        # Check if .jot.json exists
        jot_file = current_dir / '.jot.json'
        if not jot_file.exists():
            print(f"\n✗ No .jot.json file found in {current_dir}")
            print("Cannot register a directory without a .jot.json file")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        # Suggest project name based on directory name
        suggested_name = current_dir.name

        # Check if current directory is already registered
        all_projects = self.registry.list_projects()
        current_path_str = str(current_dir)
        already_registered_as = None
        for name, path in all_projects.items():
            if path == current_path_str:
                already_registered_as = name
                break

        print(f"\n{CYAN}{BOLD}Register Current Project{RESET}")
        print(f"Directory: {DIM}{current_dir}{RESET}")

        if already_registered_as:
            print(f"{YELLOW}⚠ Already registered as: {BOLD}{already_registered_as}{RESET}")
            print(f"\nEnter new name to re-register or press Enter to cancel: ", end='', flush=True)
        else:
            print(f"\nProject name [{suggested_name}]: ", end='', flush=True)

        # Restore terminal to normal mode and flush any pending input
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        termios.tcflush(fd, termios.TCIFLUSH)  # Flush input buffer

        # Get user input
        try:
            project_name = input().strip()

            # If empty and already registered, cancel
            if not project_name and already_registered_as:
                print("✗ Cancelled")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            # If empty and not already registered, use suggested name
            if not project_name:
                project_name = suggested_name

            # Check if project name already exists (pointing to different directory)
            if project_name in all_projects and all_projects[project_name] != current_path_str:
                existing_path = all_projects[project_name]
                print(f"{YELLOW}⚠ Project '{project_name}' already exists → {existing_path}{RESET}")
                print(f"Overwrite? (y/N): ", end='', flush=True)
                overwrite = input().strip().lower()
                if overwrite != 'y':
                    print("✗ Cancelled")
                    print("\nPress Enter to continue...", end='', flush=True)
                    input()
                    return True

            # Register the project
            self.registry.register_project(project_name, current_path_str)
            print(
                f"\n✓ Registered project '{BOLD}{project_name}{RESET}' → {DIM}{current_dir}{RESET}"
            )
            print(f"\nYou can now access it with: {CYAN}jott {project_name}{RESET}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        except KeyboardInterrupt:
            print("\n✗ Cancelled")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

    def collect_all_category_tasks(self, project_dir, show_archived=False):
        """Collect tasks from all categories (default + local + global)

        Args:
            project_dir: Project directory path
            show_archived: Whether to include archived tasks

        Returns:
            list: List of tuples (category_name, is_global, tasks, archived_tasks)
        """
        all_categories = []
        cat_manager = CategoryManager(project_dir=project_dir)

        # Default category
        try:
            tm_default = TaskManager(directory=project_dir, project_registry=self.registry)
            tasks = tm_default.tasks if not show_archived else tm_default.tasks
            archived = tm_default.archived if show_archived else []
            if tasks or archived:  # Only include if has tasks
                all_categories.append(('default', False, tasks, archived))
        except Exception:
            pass  # Skip if default doesn't exist

        # Local categories
        for cat in cat_manager.discover_categories():
            try:
                tm = TaskManager(
                    directory=project_dir, category=cat, project_registry=self.registry
                )
                tasks = tm.tasks if not show_archived else tm.tasks
                archived = tm.archived if show_archived else []
                if tasks or archived:  # Only include if has tasks
                    all_categories.append((cat, False, tasks, archived))
            except Exception:
                pass  # Skip problematic categories

        # Global categories
        for cat in cat_manager.discover_global_categories():
            try:
                tm = TaskManager(
                    category=cat, is_global=True, project_registry=self.registry
                )
                tasks = tm.tasks if not show_archived else tm.tasks
                archived = tm.archived if show_archived else []
                if tasks or archived:  # Only include if has tasks
                    all_categories.append((cat, True, tasks, archived))
            except Exception:
                pass  # Skip problematic categories

        return all_categories

    def toggle_all_categories_view(self, current_mode):
        """Toggle between normal view and all-categories view

        Args:
            current_mode: Current mode to return indication

        Returns:
            tuple: (should_toggle, new_mode)
        """
        if current_mode == MODE_ALL_CATEGORIES:
            # Exit all-categories view, return to quick-add
            return (True, MODE_QUICK_ADD)
        else:
            # Enter all-categories view
            return (True, MODE_ALL_CATEGORIES)

    def refresh(self):
        """Refresh task list from file"""
        self.task_manager.refresh()
        print("\n✓ Refreshed task list")
        return True

    def help(self):
        """Show help message"""
        print("\nCommands:")
        print("  a - Add a task")
        print("  c - Mark task as current")
        print("  d - Delete task by ID")
        print("  D - Delete current task")
        print("  e - Edit task by ID")
        print("  E - Edit current task")
        print("  M - Move current task to different project")
        print("  r - Refresh task list")
        print("  h - Show this help")
        print("  q - Quit")
        print("\nNavigation:")
        print("  ↑/Ctrl+p - Previous task")
        print("  ↓/Ctrl+n - Next task")
        print("  Shift+↑ - Move current task up")
        print("  Shift+↓ - Move current task down")
        print("\nQuick-Add Mode Shortcuts:")
        print("  ? - Toggle shortcuts display (press '?' to show/hide categorized shortcuts)")
        print("  Shift+F - Toggle inline notes display")
        print("  Shift+N - Edit task notes (📝)")
        print("  Shift+J - Mark current task as agent task (Claude Code working on it)")
        print("  Shift+C - Switch to different category")
        print("  Shift+Z - Switch to different project")
        print("  Ctrl+R - Register current project in global registry")
        print("  Shift+T - Transfer current task to different category")
        print("  Shift+M - Move current task to different project")
        print("  Ctrl+X - Quit")
        print("\nNote: Press '?' in Quick-Add mode to see all shortcuts organized by category")
        print("\nCommand Mode (press ESC):")
        print("  r - Refresh task list")
        print("\nFor full CLI documentation, run: jott --help")
        return True

    def bulk_actions_menu(self, selected_task_ids):
        """Show bulk actions menu and return selected action

        Args:
            selected_task_ids: Set of task IDs to operate on

        Returns:
            str: Action to perform ('priority', 'status', 'delete', 'archive', 'cancel', None)
        """
        if not selected_task_ids:
            print("\n✗ No tasks selected")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return None

        CYAN = '\033[96m'
        BOLD = '\033[1m'
        RESET = '\033[0m'

        print(f"\n{CYAN}{BOLD}Bulk Actions{RESET} ({len(selected_task_ids)} tasks selected)")
        print("-" * 50)
        print("  1. Set priority for all selected")
        print("  2. Set status for all selected")
        print("  3. Delete all selected")
        print("  4. Archive all selected")
        print("  5. Cancel")
        print("\nChoice: ", end='', flush=True)

        # Restore terminal

        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        termios.tcflush(fd, termios.TCIFLUSH)

        try:
            choice = input().strip()

            if choice == '1':
                return 'priority'
            elif choice == '2':
                return 'status'
            elif choice == '3':
                return 'delete'
            elif choice == '4':
                return 'archive'
            else:
                return 'cancel'

        except (KeyboardInterrupt, EOFError):
            return 'cancel'

    def bulk_set_priority(self, task_ids):
        """Set priority for multiple tasks

        Args:
            task_ids: Set of task IDs to update

        Returns:
            bool: True if operation completed
        """
        BOLD = '\033[1m'
        RESET = '\033[0m'
        YELLOW = '\033[93m'
        DIM = '\033[2m'

        # Priority colors and symbols
        PRIORITY_COLORS = {
            'none': DIM,
            'low': '\033[94m',  # BLUE
            'medium': YELLOW,
            'high': '\033[91m',  # RED
        }
        PRIORITY_SYMBOLS = {
            'none': '○',
            'low': '◔',
            'medium': '◑',
            'high': '●',
        }

        print(f"\n{BOLD}Set priority for {len(task_ids)} tasks:{RESET}")
        priorities = ['none', 'low', 'medium', 'high']
        for i, priority in enumerate(priorities, 1):
            color = PRIORITY_COLORS[priority]
            symbol = PRIORITY_SYMBOLS[priority]
            print(f"  {i}. {color}{symbol} {priority}{RESET}")

        print(f"\n  {BOLD}ESC{RESET}. Cancel\n")
        print("Choice: ", end='', flush=True)

        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        termios.tcflush(fd, termios.TCIFLUSH)

        try:
            user_input = input().strip()

            if not user_input or user_input == '\x1b':
                print("✗ Cancelled")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            choice = int(user_input)
            if 1 <= choice <= 4:
                selected_priority = priorities[choice - 1]
                count = 0
                for task_id in task_ids:
                    if self.task_manager.set_task_priority(task_id, selected_priority):
                        count += 1

                priority_color = PRIORITY_COLORS[selected_priority]
                priority_symbol = PRIORITY_SYMBOLS[selected_priority]
                print(
                    f"✓ Set priority to {priority_color}{priority_symbol} {selected_priority}{RESET} for {count} tasks"
                )
                print("\nPress Enter to continue...", end='', flush=True)
                input()
            else:
                print("✗ Invalid choice")
                print("\nPress Enter to continue...", end='', flush=True)
                input()

        except (ValueError, KeyboardInterrupt, EOFError):
            print("\n✗ Cancelled")
            print("\nPress Enter to continue...", end='', flush=True)
            input()

        return True

    def bulk_set_status(self, task_ids):
        """Set status for multiple tasks

        Args:
            task_ids: Set of task IDs to update

        Returns:
            bool: True if operation completed
        """
        CYAN = '\033[96m'
        BOLD = '\033[1m'
        RESET = '\033[0m'
        GREEN = '\033[92m'
        DIM = '\033[2m'

        # Status colors and symbols
        STATUS_COLORS = {
            'todo': DIM,
            'in-progress': CYAN,
            'blocked': '\033[91m',  # RED
            'done': GREEN,
        }
        STATUS_SYMBOLS = {
            'todo': '☐',
            'in-progress': '▶',
            'blocked': '⚠',
            'done': '✓',
        }

        print(f"\n{BOLD}Set status for {len(task_ids)} tasks:{RESET}")
        statuses = ['todo', 'in-progress', 'blocked', 'done']
        for i, status in enumerate(statuses, 1):
            color = STATUS_COLORS[status]
            symbol = STATUS_SYMBOLS[status]
            print(f"  {i}. {color}{symbol} {status}{RESET}")

        print(f"\n  {BOLD}ESC{RESET}. Cancel\n")
        print("Choice: ", end='', flush=True)

        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        termios.tcflush(fd, termios.TCIFLUSH)

        try:
            user_input = input().strip()

            if not user_input or user_input == '\x1b':
                print("✗ Cancelled")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            choice = int(user_input)
            if 1 <= choice <= 4:
                selected_status = statuses[choice - 1]
                count = 0
                for task_id in task_ids:
                    if self.task_manager.set_task_status(task_id, selected_status):
                        count += 1

                status_color = STATUS_COLORS[selected_status]
                status_symbol = STATUS_SYMBOLS[selected_status]
                print(
                    f"✓ Set status to {status_color}{status_symbol} {selected_status}{RESET} for {count} tasks"
                )
                print("\nPress Enter to continue...", end='', flush=True)
                input()
            else:
                print("✗ Invalid choice")
                print("\nPress Enter to continue...", end='', flush=True)
                input()

        except (ValueError, KeyboardInterrupt, EOFError):
            print("\n✗ Cancelled")
            print("\nPress Enter to continue...", end='', flush=True)
            input()

        return True

    def bulk_delete(self, task_ids):
        """Delete multiple tasks

        Args:
            task_ids: Set of task IDs to delete

        Returns:
            bool: True if operation completed
        """
        BOLD = '\033[1m'
        RESET = '\033[0m'
        YELLOW = '\033[93m'

        print(f"\n{YELLOW}{BOLD}⚠  WARNING{RESET}")
        print(f"About to delete {len(task_ids)} tasks. This cannot be undone.\n")
        print("Confirm deletion? (y/N): ", end='', flush=True)

        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        termios.tcflush(fd, termios.TCIFLUSH)

        try:
            confirmation = input().strip().lower()

            if confirmation == 'y':
                count = 0
                for task_id in task_ids:
                    if self.task_manager.delete_task_permanently(task_id):
                        count += 1

                print(f"✓ Deleted {count} tasks")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
            else:
                print("✗ Deletion cancelled")
                print("\nPress Enter to continue...", end='', flush=True)
                input()

        except (KeyboardInterrupt, EOFError):
            print("\n✗ Deletion cancelled")
            print("\nPress Enter to continue...", end='', flush=True)
            input()

        return True

    def bulk_archive(self, task_ids):
        """Archive multiple tasks

        Args:
            task_ids: Set of task IDs to archive

        Returns:
            bool: True if operation completed
        """
        BOLD = '\033[1m'
        RESET = '\033[0m'

        print(f"\n{BOLD}Archive {len(task_ids)} tasks?{RESET} (y/N): ", end='', flush=True)

        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        termios.tcflush(fd, termios.TCIFLUSH)

        try:
            confirmation = input().strip().lower()

            if confirmation == 'y':
                count = 0
                for task_id in task_ids:
                    if self.task_manager.archive_task(task_id):
                        count += 1

                print(f"✓ Archived {count} tasks")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
            else:
                print("✗ Archive cancelled")
                print("\nPress Enter to continue...", end='', flush=True)
                input()

        except (KeyboardInterrupt, EOFError):
            print("\n✗ Archive cancelled")
            print("\nPress Enter to continue...", end='', flush=True)
            input()

        return True

    def handle(self, command):
        """Handle a command"""
        # Check for exact match first (for case-sensitive commands like 'D')
        handler = self.commands.get(command)
        if not handler:
            # Fall back to lowercase
            handler = self.commands.get(command.lower())

        if handler:
            return handler()
        else:
            print(f"\nUnknown command: {command}. Press 'h' for help.")
            return True


# UI display functions removed - now imported from jot.ui
# (display_all_projects, display_category_stats, display_archive,
#  format_inline_notes, format_category_badges, display_tasks,
#  display_categorized_shortcuts, display_help)
