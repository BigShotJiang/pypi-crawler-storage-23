"""Display functions for task list UI"""

from datetime import datetime, timezone
from pathlib import Path

from jot.core.task_manager import TaskManager
from jot.core.constants import (
    MODE_QUICK_ADD,
    MODE_COMMAND,
    MODE_MULTISELECT,
    MODE_FUZZY_SEARCH,
    DAY_COLORS,
    DAY_ABBREVIATIONS,
)
from jot.categories.manager import CategoryManager
from jot.categories.config import CategoryConfig
from jot.ui.formatting import format_inline_notes, format_category_badges


def display_all_projects(registry, show_categories=False):
    """Display all projects with their tasks grouped by project"""
    # ANSI color codes
    CYAN = '\033[96m'
    RESET = '\033[0m'
    BOLD = '\033[1m'
    GREEN = '\033[92m'
    DIM = '\033[2m'

    projects = registry.list_projects()

    if not projects:
        print("\nNo registered projects. Run jot to auto-discover projects in ~/projects/")
        return

    print("\n" + "=" * 60)
    if show_categories:
        print(f"{BOLD}ALL PROJECTS OVERVIEW (with categories){RESET}")
    else:
        print(f"{BOLD}ALL PROJECTS OVERVIEW{RESET}")
    print("=" * 60)

    for project_name in sorted(projects.keys()):
        project_path = projects[project_name]

        # Load tasks for this project
        try:
            if show_categories:
                # Display with category breakdown
                cat_manager = CategoryManager(project_dir=project_path)
                local_categories = cat_manager.discover_categories()

                # Load default category
                tm_default = TaskManager(directory=project_path)
                default_count = len(tm_default.tasks)
                archived_count = len(tm_default.archived)

                # Count total tasks across all categories
                total_tasks = default_count
                category_counts = {}

                for cat in local_categories:
                    tm_cat = TaskManager(directory=project_path, category=cat)
                    cat_task_count = len(tm_cat.tasks)
                    total_tasks += cat_task_count
                    category_counts[cat] = cat_task_count

                # Project header
                print(
                    f"\n📁 {BOLD}{project_name}{RESET} ({total_tasks} tasks total, {archived_count} archived)"
                )
                print(f"   {DIM}{project_path}{RESET}")

                # Default category tasks
                if default_count > 0:
                    print(f"   ├─ default: {default_count} tasks")
                    for task in tm_default.tasks[:3]:  # Show first 3
                        print(f"      • {task['text'][:60]}")
                    if default_count > 3:
                        print(f"      ... and {default_count - 3} more")

                # Category breakdown
                for cat, count in sorted(category_counts.items()):
                    print(f"   ├─ {cat}: {count} tasks")
                    if count > 0:
                        tm_cat = TaskManager(directory=project_path, category=cat)
                        for task in tm_cat.tasks[:2]:  # Show first 2
                            print(f"      • {task['text'][:60]}")
                        if count > 2:
                            print(f"      ... and {count - 2} more")

            else:
                # Simple display (no category breakdown)
                tm = TaskManager(directory=project_path)
                task_count = len(tm.tasks)
                archived_count = len(tm.archived)

                print(f"\n📁 {BOLD}{project_name}{RESET} ({task_count} tasks, {archived_count} archived)")
                print(f"   {DIM}{project_path}{RESET}")

                # Show first few tasks
                if task_count > 0:
                    for task in tm.tasks[:5]:
                        print(f"   • {task['text'][:70]}")
                    if task_count > 5:
                        print(f"   ... and {task_count - 5} more tasks")
                else:
                    print(f"   {DIM}(no active tasks){RESET}")

        except FileNotFoundError:
            print(f"\n📁 {BOLD}{project_name}{RESET} {DIM}(no .jot.json found){RESET}")
            print(f"   {DIM}{project_path}{RESET}")
        except Exception as e:
            print(f"\n📁 {BOLD}{project_name}{RESET} {DIM}(error loading: {e}){RESET}")
            print(f"   {DIM}{project_path}{RESET}")

    print("\n" + "=" * 60)
    print(
        f"Total: {len(projects)} projects  |  "
        f"Use {CYAN}jot -p <project>{RESET} to switch  |  {CYAN}Shift+P{RESET} in jot UI"
    )
    print("=" * 60 + "\n")


def display_category_stats(project_dir):
    """Display statistics for all categories in a project"""
    # ANSI color codes
    CYAN = '\033[96m'
    YELLOW = '\033[93m'
    RESET = '\033[0m'
    BOLD = '\033[1m'
    GREEN = '\033[92m'
    DIM = '\033[2m'

    cat_manager = CategoryManager(project_dir=project_dir)
    local_categories = cat_manager.discover_categories()
    global_categories = CategoryManager.discover_global_categories()

    print(f"\n{BOLD}Category Statistics{RESET}")
    print("=" * 60)

    # Default (no category) stats
    tm_default = TaskManager(directory=project_dir)
    default_count = len(tm_default.tasks)
    default_archived = len(tm_default.archived)
    print(f"\n{CYAN}DEFAULT (uncategorized){RESET}")
    print(f"  Active: {default_count} | Archived: {default_archived}")

    # Local category stats
    if local_categories:
        print(f"\n{BOLD}Local Categories:{RESET}")
        for cat in sorted(local_categories):
            tm_cat = TaskManager(directory=project_dir, category=cat)
            count = len(tm_cat.tasks)
            archived = len(tm_cat.archived)
            print(f"\n{CYAN}{cat.upper()}{RESET}")
            print(f"  Active: {count} | Archived: {archived}")

    # Global category stats
    if global_categories:
        print(f"\n{BOLD}Global Categories:{RESET}")
        for cat in sorted(global_categories):
            tm_cat = TaskManager(category=cat, is_global=True)
            count = len(tm_cat.tasks)
            archived = len(tm_cat.archived)
            print(f"\n{GREEN}{cat.upper()} (GLOBAL){RESET}")
            print(f"  Active: {count} | Archived: {archived}")

    # Limits
    local_count = len(local_categories)
    global_count = len(global_categories)
    print(
        f"\n{YELLOW}⚠  Local categories: {local_count}/{CategoryManager.MAX_CATEGORIES}{RESET}"
    )
    print(f"{YELLOW}⚠  Global categories: {global_count}/{CategoryManager.MAX_CATEGORIES}{RESET}")
    print("=" * 60 + "\n")


def display_archive(project_dir, filter_category=None):
    """Display archived tasks with optional category filter"""
    # ANSI color codes
    CYAN = '\033[96m'
    YELLOW = '\033[93m'
    RESET = '\033[0m'
    BOLD = '\033[1m'
    DIM = '\033[2m'

    cat_manager = CategoryManager(project_dir=project_dir)

    # Build list of (category_name, TaskManager) tuples to display
    managers_to_check = []

    if filter_category:
        # Single category specified
        if filter_category == 'global':
            managers_to_check = [(cat, TaskManager(category=cat, is_global=True)) for cat in CategoryManager.discover_global_categories()]
        else:
            managers_to_check = [(filter_category, TaskManager(directory=project_dir, category=filter_category))]
    else:
        # All categories
        tm_default = TaskManager(directory=project_dir)
        managers_to_check.append(('default', tm_default))

        for cat in cat_manager.discover_categories():
            tm_cat = TaskManager(directory=project_dir, category=cat)
            managers_to_check.append((cat, tm_cat))

    # Display
    print(f"\n{BOLD}Archived Tasks{RESET}")
    print("=" * 60)

    total_archived = 0
    for cat_name, tm in managers_to_check:
        if tm.archived:
            print(f"\n{CYAN}{cat_name.upper()}{RESET} ({len(tm.archived)} archived)")
            for i, task in enumerate(tm.archived, 1):
                # Color code by type
                task_prefix = "✓"
                if task.get('type') == 'done':
                    task_prefix = f"{CYAN}✓{RESET}"
                elif task.get('type') == 'canceled':
                    task_prefix = f"{YELLOW}✗{RESET}"

                print(f"  {i}. {task_prefix} {task['text']}")
                if 'archived_at' in task:
                    print(f"     {DIM}Archived: {task['archived_at']}{RESET}")

            total_archived += len(tm.archived)

    if total_archived == 0:
        print(f"\n{DIM}No archived tasks{RESET}")

    print("=" * 60 + "\n")


def display_tasks(
    tasks,
    mode=MODE_QUICK_ADD,
    input_buffer="",
    project_name=None,
    category=None,
    is_global=False,
    show_archived=False,
    archived_tasks=None,
    selected_tasks=None,
    search_buffer="",
    archived_task_ids=None,
    include_archived_in_search=True,
    show_shortcuts=False,
    show_notes_inline=False,
):
    """Display current task list with mode indicator

    Args:
        tasks: Active tasks to display
        mode: Current mode (quick-add, command, or multiselect)
        input_buffer: Current input text
        project_name: Name of project
        category: Category name
        is_global: Whether category is global
        show_archived: Whether to show archived tasks below active tasks
        archived_tasks: List of archived tasks (only used if show_archived=True)
        selected_tasks: Set of task IDs that are selected (for multi-select mode)
        search_buffer: Current fuzzy search query
        archived_task_ids: Set of task IDs that are archived (for fuzzy search)
        include_archived_in_search: Whether archived tasks are included in search
    """
    # ANSI color codes
    CYAN = '\033[96m'
    RESET = '\033[0m'
    BOLD = '\033[1m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    DIM = '\033[2m'

    # Import Path at the top to avoid UnboundLocalError

    # Get category color
    cat_config = CategoryConfig()
    if category:
        cat_color = cat_config.get_color(category, for_global=is_global)
    else:
        cat_color = CYAN

    # ASCII art header
    print(f"\n{CYAN}{BOLD}")
    print("       ██╗ ██████╗ ████████╗████████╗")
    print("       ██║██╔═══██╗╚══██╔══╝╚══██╔══╝")
    print("       ██║██║   ██║   ██║      ██║")
    print("  ██   ██║██║   ██║   ██║      ██║")
    print("  ╚█████╔╝╚██████╔╝   ██║      ██║")
    print("   ╚════╝  ╚═════╝    ╚═╝      ╚═╝")
    print(f"{RESET}")

    # Find current task
    current_task_text = None
    for task in tasks:
        if task.get('current', False):
            current_task_text = task.get('text', '')
            # Truncate if too long
            if len(current_task_text) > 40:
                current_task_text = current_task_text[:37] + "..."
            break

    # Display project name with category
    if project_name:
        print(f"  {YELLOW}{BOLD}{project_name}{RESET} {DIM}({Path.cwd().name}){RESET}", end='')
    else:
        print(f"  {YELLOW}{BOLD}{Path.cwd().name}{RESET}", end='')

    # Display category if present with configured color
    if category:
        if is_global:
            print(f" {cat_color}{BOLD}[global:{category}]{RESET}", end='')
        else:
            print(f" {cat_color}{BOLD}[{category}]{RESET}", end='')

    # Display current task text in header if present
    if current_task_text:
        print(f" {DIM}→{RESET} {GREEN}{current_task_text}{RESET}")
    else:
        print()  # Newline if no current task

    # Display category badges
    try:
        project_dir = Path.cwd()
        cat_manager = CategoryManager(project_dir)
        badge_cat_config = CategoryConfig(project_dir)

        badges = format_category_badges(cat_manager, badge_cat_config, category, is_global)
        if badges:
            print(f"  {badges}")
    except Exception:
        pass  # Silently skip if category badges can't be displayed

    print("-" * 50)

    if not tasks:
        print("\n  No tasks yet. Start typing to add one!")
    else:
        # Initialize selected_tasks and archived_task_ids if None
        if selected_tasks is None:
            selected_tasks = set()
        if archived_task_ids is None:
            archived_task_ids = set()

        # Priority colors and symbols
        PRIORITY_COLORS = {
            'none': DIM,
            'low': '\033[94m',  # BLUE
            'medium': YELLOW,
            'high': '\033[91m',  # RED
        }
        PRIORITY_SYMBOLS = {
            'none': '',
            'low': '◔',
            'medium': '◑',
            'high': '●',
        }
        # Status colors and symbols
        STATUS_COLORS = {
            'todo': DIM,
            'in-progress': CYAN,
            'blocked': '\033[91m',  # RED
            'done': GREEN,
        }
        STATUS_SYMBOLS = {
            'todo': '',
            'in-progress': '▶',
            'blocked': '⚠',
            'done': '✓',
        }
        # Archive indicator
        ARCHIVE_SYMBOL = '📦'
        ARCHIVE_COLOR = DIM

        for task in tasks:
            status = "✓" if task.get('done', False) else " "
            is_current = task.get('current', False)
            is_selected = task['id'] in selected_tasks
            is_break_task = 'break' in task['text'].lower()
            is_agent_task = task.get('agent_task', False)
            has_notes = bool(task.get('notes', '').strip())
            day = task.get('day')
            tally = task.get('tally', 0)
            priority = task.get('priority', 'none')
            task_status = task.get('status', 'todo')

            # Build priority prefix if present
            priority_prefix = ""
            if priority and priority != 'none':
                priority_color = PRIORITY_COLORS.get(priority, DIM)
                priority_symbol = PRIORITY_SYMBOLS.get(priority, '')
                priority_prefix = f"{priority_color}{priority_symbol}{RESET} "

            # Build status prefix if present
            status_prefix = ""
            if task_status and task_status not in ['todo', 'done']:
                status_color = STATUS_COLORS.get(task_status, DIM)
                status_symbol = STATUS_SYMBOLS.get(task_status, '')
                status_prefix = f"{status_color}{status_symbol}{RESET} "

            # Build day prefix if present
            day_prefix = ""
            if day:
                day_color = DAY_COLORS.get(day, CYAN)
                day_abbrev = DAY_ABBREVIATIONS.get(day, day[:3])
                day_prefix = f"{day_color}[{day_abbrev}]{RESET} "

            # Build tally suffix if present
            tally_suffix = ""
            if tally > 0:
                tally_suffix = f" {DIM}(×{tally}){RESET}"

            # Build stale warning if task is old
            stale_warning = ""
            updated_at = task.get('updated_at')
            if updated_at and not task.get('done', False) and task_status != 'done':
                try:
                    updated_dt = datetime.fromisoformat(updated_at.replace('Z', '+00:00'))
                    now = datetime.now(timezone.utc)
                    age_days = (now - updated_dt).days

                    if age_days >= 14:  # 2+ weeks old
                        stale_warning = f" {DIM}⏰{age_days}d{RESET}"
                    elif age_days >= 7:  # 1+ week old
                        stale_warning = f" {DIM}⏰{age_days}d{RESET}"
                except (ValueError, AttributeError):
                    pass

            # Build selection checkbox if in multi-select mode
            selection_box = ""
            if mode == MODE_MULTISELECT:
                if is_selected:
                    selection_box = f"{GREEN}[✓]{RESET} "
                else:
                    selection_box = "[ ] "

            # Build archive indicator if task is archived (in fuzzy search results)
            archive_prefix = ""
            is_archived = task['id'] in archived_task_ids
            if is_archived:
                archive_prefix = f"{ARCHIVE_COLOR}{ARCHIVE_SYMBOL}{RESET} "

            # Build notes indicator if task has notes
            notes_prefix = ""
            if has_notes:
                notes_prefix = "📝 "

            # Build analysis indicator if task has analysis file
            analysis_prefix = ""
            analysis_file = Path.cwd() / f".jot.analysis.{task['id']}.org"
            if analysis_file.exists():
                analysis_prefix = "📋 "

            # Combine all prefixes
            all_prefixes = (
                selection_box
                + archive_prefix
                + notes_prefix
                + analysis_prefix
                + priority_prefix
                + status_prefix
                + day_prefix
            )

            if is_agent_task:
                # Agent task styling - Claude Code is working on this
                MAGENTA = '\033[95m'  # Bright purple/magenta
                if is_current:
                    # Agent task that is also current
                    print(
                        f"{MAGENTA}{BOLD}→ [{status}] {task['id']}. {all_prefixes}🤖 {task['text']}{RESET}{tally_suffix}{stale_warning}"
                    )
                else:
                    # Agent task but not current
                    print(
                        f"{MAGENTA}  [{status}] {task['id']}. {all_prefixes}🤖 {task['text']}{RESET}{tally_suffix}{stale_warning}"
                    )
            elif is_current:
                if is_break_task:
                    # Special styling for "take a break" when current
                    print(
                        f"{GREEN}{BOLD}→ [{status}] {task['id']}. {all_prefixes}🌿 {task['text']}{RESET}{tally_suffix}{stale_warning}"
                    )
                else:
                    # Regular current task styling
                    print(
                        f"{CYAN}{BOLD}→ [{status}] {task['id']}. {all_prefixes}✨ {task['text']}{RESET}{tally_suffix}{stale_warning}"
                    )
            else:
                print(
                    f"  [{status}] {task['id']}. {all_prefixes}{task['text']}{tally_suffix}{stale_warning}"
                )

            # Display inline notes if toggle is on, task has notes, and task is current
            if show_notes_inline and has_notes and is_current:
                note_lines = format_inline_notes(task.get('notes', ''))
                for line in note_lines:
                    print(line)

    print("\n" + "-" * 50)

    # Display archived tasks if toggle is on
    if show_archived and archived_tasks:
        print(f"\n{DIM}{BOLD}--- ARCHIVED ({len(archived_tasks)}) ---{RESET}")
        for task in archived_tasks:
            status = "✓" if task.get('done', False) else " "
            day = task.get('day')
            tally = task.get('tally', 0)

            # Build day prefix if present
            day_prefix = ""
            if day:
                day_color = DAY_COLORS.get(day, CYAN)
                day_abbrev = DAY_ABBREVIATIONS.get(day, day[:3])
                day_prefix = f"{day_color}[{day_abbrev}]{RESET} "

            # Build tally suffix if present
            tally_suffix = ""
            if tally > 0:
                tally_suffix = f" {DIM}(×{tally}){RESET}"

            # Display archived task in dimmed color
            print(
                f"{DIM}  [{status}] {task['id']}. {day_prefix}{task['text']}{tally_suffix}{RESET}"
            )

        print(f"{DIM}-" * 50 + RESET)

    # Display mode-specific footer
    if mode == MODE_QUICK_ADD:
        print(
            f"{GREEN}[QUICK ADD]{RESET} Type task, {BOLD}Enter{RESET} to save | {BOLD}/{RESET}: search | {BOLD}ESC{RESET}: commands | {BOLD}Shift+V{RESET}: multi-select | {BOLD}?{RESET}: shortcuts"
        )
        if show_shortcuts:
            display_categorized_shortcuts()
        print(f"→ {input_buffer}█", end='', flush=True)
    elif mode == MODE_MULTISELECT:
        selected_count = len(selected_tasks) if selected_tasks else 0
        print(
            f"{CYAN}{BOLD}[MULTI-SELECT]{RESET} {selected_count} selected | {BOLD}Space{RESET}: toggle | {BOLD}B{RESET}: bulk actions | {BOLD}ESC{RESET}: exit"
        )
        print(
            f"{CYAN}Navigation:{RESET} {BOLD}↑/↓{RESET}: move | {BOLD}Shift+↑/↓{RESET}: select while moving | {BOLD}A{RESET}: select all | {BOLD}N{RESET}: select none"
        )
        print("-" * 50)
    elif mode == MODE_FUZZY_SEARCH:
        # Display search prompt with result counts and toggle status
        # Count active and archived results
        active_count = sum(1 for task in tasks if task['id'] not in (archived_task_ids or set()))
        archived_count = len(archived_task_ids or set())

        # Build toggle status indicator
        toggle_status = (
            f"{GREEN}with archives{RESET}"
            if include_archived_in_search
            else f"{DIM}active only{RESET}"
        )

        # Show search query with counts
        if search_buffer:
            count_info = f" {DIM}({active_count} active"
            if archived_count > 0:
                count_info += f", {archived_count} archived"
            count_info += f"){RESET}"
        else:
            count_info = ""

        print(f"{CYAN}{BOLD}[FUZZY SEARCH]{RESET} {toggle_status} {search_buffer}█{count_info}")
        print(
            f"{CYAN}Keys:{RESET} Type to filter | {BOLD}↑/↓{RESET}: navigate | {BOLD}Enter{RESET}: select | {BOLD}Ctrl+A{RESET}: toggle archives | {BOLD}ESC{RESET}: cancel"
        )
        print("-" * 50)
    else:  # MODE_COMMAND
        print(
            f"{YELLOW}[COMMAND]{RESET} Press {BOLD}'a'{RESET} for quick-add | {BOLD}'h'{RESET} for help | {BOLD}'q'{RESET} to quit"
        )
        print(
            f"Commands: {BOLD}(a){RESET}dd | {BOLD}(c){RESET}urrent | {BOLD}(d){RESET}elete | {BOLD}(e){RESET}dit | {BOLD}(M){RESET}ove | {BOLD}(r){RESET}efresh | {BOLD}(h){RESET}elp | {BOLD}(q){RESET}uit"
        )
        print("-" * 50)
        print("Command: ", end='', flush=True)


def display_categorized_shortcuts():
    """Display keyboard shortcuts organized by category"""
    # ANSI color codes
    CYAN = '\033[96m'
    YELLOW = '\033[93m'
    RESET = '\033[0m'
    BOLD = '\033[1m'
    DIM = '\033[2m'

    shortcuts = {
        "Navigation": [
            ("↑/↓", "Navigate tasks"),
            ("Tab", "Cycle through categories"),
            ("Ctrl+/", "Fuzzy search tasks"),
            ("Shift+Z", "Switch project"),
            ("Shift+C", "Switch category"),
            ("Shift+L", "Toggle all categories view"),
        ],
        "Task Management": [
            ("Enter", "Add task"),
            ("c", "Mark current task"),
            ("d", "Delete task"),
            ("t", "Toggle task done"),
            ("a", "Archive task"),
            ("Shift+A", "Toggle archive view"),
            ("m", "Move to different category"),
            ("Shift+M", "Move task to another project"),
            ("Ctrl+K", "Copy task to another project"),
            ("Shift+T", "Transfer to category"),
            ("Ctrl+↑/↓", "Reorder tasks"),
            ("=", "Sort by priority"),
        ],
        "Task Details": [
            ("n", "Add/edit notes"),
            ("Shift+N", "Edit task notes"),
            ("Shift+F", "Toggle inline notes display"),
            ("p", "Toggle priority cycle"),
            ("Shift+H", "Set priority to high"),
            ("=", "Sort by priority"),
            ("Shift+X", "Set task status"),
            ("Shift+W", "Assign day to task"),
            ("Shift+O", "Toggle day sorting"),
            ("Shift+Y", "Toggle today filter"),
            ("Shift+D", "Mark current as done"),
            ("Shift+J", "Mark as agent task"),
        ],
        "Multi-Select Mode": [
            ("Shift+V", "Enter multi-select mode"),
            ("Space", "Toggle task selection"),
            ("Shift+↑/↓", "Select while moving"),
            ("A", "Select all tasks"),
            ("N", "Select none"),
            ("B", "Bulk actions menu"),
            ("Esc", "Exit multi-select"),
        ],
        "Bulk Operations": [
            ("Shift+B", "Bulk actions / Priority timer"),
        ],
        "Analysis & Export": [
            ("Shift+0", "Execute analysis plan"),
            ("Shift+1", "Fix duplicate task IDs"),
            ("Shift+4", "AI task suggestion"),
            ("Shift+E", "Execute keyword action"),
            ("Shift+G", "Google Calendar setup"),
            ("Shift+I", "Import from Google Calendar"),
            ("Shift+K", "Copy task to clipboard"),
            ("Ctrl+U", "Open URLs in task"),
        ],
        "System": [
            ("h/?", "Show this help"),
            ("r", "Refresh display"),
            ("Ctrl+R", "Register current project"),
            ("q", "Quit"),
            ("Ctrl+X", "Quit"),
            ("Esc", "Exit mode / Quit"),
        ],
        "Fuzzy Search": [
            ("Ctrl+A", "Toggle archived tasks in search"),
        ],
    }

    print(f"\n{BOLD}Keyboard Shortcuts{RESET}")
    print("=" * 60)

    for category, items in shortcuts.items():
        print(f"\n{CYAN}{category}:{RESET}")
        for key, description in items:
            print(f"  {YELLOW}{key:15}{RESET} {description}")

    print("\n" + "=" * 60 + "\n")


def display_help():
    """Display comprehensive help information"""
    # ANSI color codes
    CYAN = '\033[96m'
    YELLOW = '\033[93m'
    GREEN = '\033[92m'
    RESET = '\033[0m'
    BOLD = '\033[1m'
    DIM = '\033[2m'

    help_text = f"""
{BOLD}Jott - Simple Interactive Task List{RESET}
{DIM}Version 0.2.2{RESET}

{BOLD}BASIC USAGE:{RESET}
  jott                      Start interactive task manager (current project)
  jott -c <category>        Start in specific category
  jott --category <cat>     Start in specific category (long form)
  jott --global             Start with global tasks
  jott -h / --help          Show this help message

{BOLD}PROJECT MANAGEMENT:{RESET}
  jott --all-projects       Show tasks from all registered projects
  jott --list-projects      List all registered projects
  jott --register <name> <path>   Register a new project
  jott --unregister <name>  Remove project from registry
  jott --refresh            Refresh project registry (auto-discover)
  jott --fix-duplicates     Fix duplicate task IDs in current directory

{BOLD}NAVIGATION:{RESET}
  {CYAN}↑/↓{RESET}              Navigate through tasks
  {CYAN}Tab{RESET}              Cycle through categories
  {CYAN}Ctrl+/{RESET}           Fuzzy search tasks
  {CYAN}Shift+Z{RESET}          Switch between projects
  {CYAN}Shift+C{RESET}          Switch between categories
  {CYAN}Shift+L{RESET}          Toggle all categories view

{BOLD}TASK MANAGEMENT:{RESET}
  {CYAN}Type + Enter{RESET}     Add new task
  {CYAN}c{RESET}                Mark task as current
  {CYAN}d{RESET}                Delete selected task
  {CYAN}t{RESET}                Toggle task done/undone
  {CYAN}a{RESET}                Archive task (mark as done/canceled)
  {CYAN}Shift+A{RESET}          Toggle archive view
  {CYAN}m{RESET}                Move task to different category
  {CYAN}Shift+M{RESET}          Move task to another project
  {CYAN}Ctrl+K{RESET}           Copy task to another project
  {CYAN}Shift+T{RESET}          Transfer task to category
  {CYAN}Ctrl+↑/↓{RESET}         Reorder tasks
  {CYAN}={RESET}                Sort by priority

{BOLD}TASK DETAILS:{RESET}
  {CYAN}n{RESET}                Add/edit task notes (opens editor)
  {CYAN}Shift+N{RESET}          Edit task notes (multi-select: select none)
  {CYAN}Shift+F{RESET}          Toggle inline notes display
  {CYAN}p{RESET}                Toggle task priority cycle
  {CYAN}Shift+H{RESET}          Set priority to high
  {CYAN}Shift+X{RESET}          Set task status (todo/in-progress/blocked/done)
  {CYAN}Shift+W{RESET}          Assign day to task
  {CYAN}Shift+O{RESET}          Toggle day sorting
  {CYAN}Shift+Y{RESET}          Toggle today filter
  {CYAN}Shift+D{RESET}          Mark current task as done
  {CYAN}Shift+J{RESET}          Mark task for agent/AI assistance
  {CYAN}Shift+E{RESET}          Execute keyword action for task

{BOLD}MULTI-SELECT MODE:{RESET}
  {CYAN}Shift+V{RESET}          Enter multi-select mode
  {CYAN}Space{RESET}            Toggle task selection
  {CYAN}Shift+↑/↓{RESET}        Select while moving
  {CYAN}A{RESET}                Select all tasks
  {CYAN}N{RESET}                Select none
  {CYAN}B{RESET}                Bulk actions menu
  {CYAN}Esc{RESET}              Exit multi-select mode

{BOLD}BULK OPERATIONS:{RESET}
  {CYAN}Shift+B{RESET}          Bulk actions menu / Priority timer

{BOLD}KEYWORDS:{RESET}
  Keywords trigger automatic actions when added to task text:

  {YELLOW}bullet:{RESET} task    Start bullet priority timer
  {YELLOW}gcal:{RESET} task      Export to Google Calendar
  {YELLOW}ai:{RESET} task        Mark for AI/agent assistance
  {YELLOW}analyze:{RESET} task   Create analysis plan with Claude Code
  {YELLOW}remind:{RESET} task    Set system notification (Shift+E)

  Configure keywords in ~/.jot-keywords.json

{BOLD}CATEGORIES:{RESET}
  Categories organize tasks within projects:
  • Local categories: Project-specific (max 10 per project)
  • Global categories: Cross-project tasks (max 10 global)
  • Default: Tasks without a category

  {CYAN}jott -c backend{RESET}  Start in "backend" category
  {CYAN}Tab{RESET}              Cycle through categories
  {CYAN}Shift+C{RESET}          Create/switch categories interactively
  {CYAN}m{RESET}                Move task between categories

{BOLD}PROJECTS:{RESET}
  Multi-project support with auto-discovery:
  • Auto-discovers projects in ~/projects/
  • Each project has its own .jot.json
  • Switch projects with {CYAN}Shift+Z{RESET} or {CYAN}jott -p <name>{RESET}

{BOLD}ANALYSIS & EXPORT:{RESET}
  {CYAN}Shift+0{RESET}          Execute analysis plan (if exists)
  {CYAN}Shift+1{RESET}          Fix duplicate task IDs
  {CYAN}Shift+4{RESET}          AI task suggestion
  {CYAN}Shift+E{RESET}          Execute keyword action for task
  {CYAN}Shift+G{RESET}          Set up Google Calendar integration
  {CYAN}Shift+I{RESET}          Import tasks from Google Calendar
  {CYAN}Shift+K{RESET}          Copy task text to clipboard
  {CYAN}Ctrl+U{RESET}           Open URLs found in task text

{BOLD}FUZZY SEARCH:{RESET}
  {CYAN}Ctrl+/{RESET}           Enter fuzzy search mode
  {CYAN}Ctrl+A{RESET}           Toggle archived tasks in search results
  {CYAN}↑/↓{RESET}              Navigate results
  {CYAN}Enter{RESET}            Select task
  {CYAN}Esc{RESET}              Exit search

{BOLD}SYSTEM:{RESET}
  {CYAN}h or ?{RESET}           Show keyboard shortcuts
  {CYAN}r{RESET}                Refresh display
  {CYAN}Ctrl+R{RESET}           Register current project in registry
  {CYAN}q{RESET}                Quit
  {CYAN}Ctrl+X{RESET}           Quit
  {CYAN}Esc{RESET}              Exit current mode / Quit

{BOLD}FILES:{RESET}
  {GREEN}.jot.json{RESET}                   Task storage (per project)
  {GREEN}~/.jot-categories/<name>.json{RESET}  Global category tasks
  {GREEN}~/.jot-keywords.json{RESET}           Keyword configuration
  {GREEN}~/.jot-project-registry.json{RESET}   Project discovery cache

{BOLD}CONFIGURATION:{RESET}
  • Edit ~/.jot-keywords.json to customize keyword actions
  • Category colors: Edit category config (Shift+C)
  • Global vs local: Use -g flag or create global categories

{DIM}For more info: https://github.com/your-repo/jot{RESET}
"""
    print(help_text)
