"""Terminal input utilities for jot"""

import select
import sys
import termios
import tty


def get_key(timeout=1.0):
    """Read a single keypress with timeout, including arrow keys and shift combinations

    Args:
        timeout: Seconds to wait for input before returning None

    Returns:
        Key character/code, tuple for paste ('PASTE', text), or None on timeout
    """
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)

        # Use select to wait for input with timeout
        ready, _, _ = select.select([sys.stdin], [], [], timeout)
        if not ready:
            return None  # Timeout - no input available

        ch = sys.stdin.read(1)

        # Check if more characters are immediately available (paste detection)
        # Use a very short timeout (0.001 seconds) to detect rapid input
        more_ready, _, _ = select.select([sys.stdin], [], [], 0.001)
        if more_ready:
            # Multiple characters available - this is likely a paste
            pasted_text = ch
            # Read all available characters
            while True:
                chunk_ready, _, _ = select.select([sys.stdin], [], [], 0.001)
                if not chunk_ready:
                    break
                pasted_text += sys.stdin.read(1)
            return ('PASTE', pasted_text)

        # Handle Ctrl+n (next/down) and Ctrl+p (previous/up)
        if ch == '\x0e':  # Ctrl+n
            return 'DOWN'
        elif ch == '\x10':  # Ctrl+p
            return 'UP'

        # Handle escape sequences (arrow keys)
        if ch == '\x1b':  # ESC
            ch2 = sys.stdin.read(1)
            if ch2 == '[':
                ch3 = sys.stdin.read(1)
                # Check for standard arrow keys
                if ch3 == 'A':
                    return 'UP'
                elif ch3 == 'B':
                    return 'DOWN'
                # Check for shift+arrow keys (1;2A = Shift+Up, 1;2B = Shift+Down)
                elif ch3 == '1':
                    ch4 = sys.stdin.read(1)
                    if ch4 == ';':
                        ch5 = sys.stdin.read(1)
                        if ch5 == '2':
                            ch6 = sys.stdin.read(1)
                            if ch6 == 'A':
                                return 'SHIFT_UP'
                            elif ch6 == 'B':
                                return 'SHIFT_DOWN'

        return ch
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
