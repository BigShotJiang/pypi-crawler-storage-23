"""Category configuration and color management"""

import json
from pathlib import Path


class CategoryConfig:
    """Manages category colors and configuration"""

    # ANSI color codes
    COLORS = {
        'red': '\033[91m',
        'green': '\033[92m',
        'yellow': '\033[93m',
        'blue': '\033[94m',
        'magenta': '\033[95m',
        'cyan': '\033[96m',
        'white': '\033[97m',
        'orange': '\033[38;5;208m',
        'purple': '\033[38;5;141m',
        'pink': '\033[38;5;213m',
        'teal': '\033[38;5;44m',
        'lime': '\033[38;5;154m',
    }

    # Default color assignments for common categories
    DEFAULT_COLORS = {
        'default': 'white',
        'features': 'green',
        'bugs': 'red',
        'testing': 'yellow',
        'docs': 'blue',
        'backlog': 'cyan',
        'ideas': 'purple',
        'work': 'teal',
        'personal': 'pink',
        'bills': 'orange',
        'health': 'lime',
    }

    def __init__(self, project_dir=None):
        """Initialize category config"""
        self.project_dir = Path(project_dir) if project_dir else Path.cwd()
        self.config_file = self.project_dir / '.jot.config.json'
        self.config = self._load_config()

    def _load_config(self):
        """Load config from .jot.config.json"""
        if self.config_file.exists():
            try:
                with open(self.config_file, 'r') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                return {}
        return {}

    def _save_config(self):
        """Save config to .jot.config.json"""
        self.config_file.parent.mkdir(parents=True, exist_ok=True)
        with open(self.config_file, 'w') as f:
            json.dump(self.config, indent=2, fp=f)

    def get_color(self, category_name, for_global=False):
        """Get ANSI color code for a category"""
        # Check custom colors first
        if 'colors' in self.config and category_name in self.config['colors']:
            color_name = self.config['colors'][category_name]
            return self.COLORS.get(color_name, '\033[96m')  # Default to cyan

        # Use default color for known categories
        if category_name in self.DEFAULT_COLORS:
            return self.COLORS[self.DEFAULT_COLORS[category_name]]

        # Global categories get magenta by default
        if for_global:
            return self.COLORS['magenta']

        # Unknown local categories get cyan
        return self.COLORS['cyan']

    def set_color(self, category_name, color_name):
        """Set color for a category"""
        if color_name not in self.COLORS:
            return False, f"Invalid color. Available: {', '.join(sorted(self.COLORS.keys()))}"

        if 'colors' not in self.config:
            self.config['colors'] = {}

        self.config['colors'][category_name] = color_name
        self._save_config()
        return True, f"Set {category_name} color to {color_name}"

    def get_all_colors(self):
        """Get all configured colors"""
        return self.config.get('colors', {})

    def reset_colors(self):
        """Reset all colors to defaults"""
        if 'colors' in self.config:
            del self.config['colors']
            self._save_config()
        return True

    def list_available_colors(self):
        """List all available color names"""
        return sorted(self.COLORS.keys())

    def get_tts_config(self):
        """Get TTS configuration settings"""
        default_tts = {
            'enabled': True,
            'rate': 150,  # Words per minute
            'volume': 0.9,  # 0.0 to 1.0
            'voice': None,  # None = system default
        }
        return self.config.get('tts', default_tts)

    def set_tts_config(self, **kwargs):
        """Set TTS configuration settings"""
        if 'tts' not in self.config:
            self.config['tts'] = {
                'enabled': True,
                'rate': 150,
                'volume': 0.9,
                'voice': None,
            }

        for key, value in kwargs.items():
            if key in ['enabled', 'rate', 'volume', 'voice']:
                self.config['tts'][key] = value

        self._save_config()
        return True
