"""Category management for jot projects"""

from pathlib import Path


class CategoryManager:
    """Manages categories within a project directory and globally"""

    MAX_CATEGORIES = 12
    GLOBAL_CATEGORIES_DIR = Path.home() / '.jot-categories'

    def __init__(self, project_dir=None):
        """Initialize category manager for a project directory"""
        self.project_dir = Path(project_dir) if project_dir else Path.cwd()

    def discover_categories(self):
        """
        Find all category files in .jot-categories/ directory.
        Returns list of category names (without .json suffix).
        """
        categories = []

        # Check if .jot-categories directory exists
        categories_dir = self.project_dir / '.jot-categories'
        if not categories_dir.exists():
            return categories

        # Find all .json files in .jot-categories/
        for file in categories_dir.glob('*.json'):
            # Extract category name from filename
            # features.json -> features
            category = file.stem  # Get filename without extension
            categories.append(category)

        return sorted(categories)

    def count_categories(self):
        """Count existing categories in the project"""
        return len(self.discover_categories())

    def can_create_category(self, category_name):
        """
        Check if a new category can be created.
        Returns (can_create: bool, message: str)
        """
        existing = self.discover_categories()

        # Category already exists
        if category_name in existing:
            return True, None

        # Check limit
        if len(existing) >= self.MAX_CATEGORIES:
            return (
                False,
                f"Category limit reached ({self.MAX_CATEGORIES} max). Existing: {', '.join(existing)}",
            )

        return True, None

    def get_warning_message(self, category_name):
        """
        Get warning message if approaching category limit.
        Returns None if no warning needed.
        """
        existing = self.discover_categories()

        # No warning if category already exists
        if category_name in existing:
            return None

        count = len(existing)

        if count == 10:
            return f"Warning: Approaching category limit ({count + 1}/12 categories)"
        elif count == 11:
            return f"Warning: Near category limit ({count + 1}/12 categories)"
        elif count >= 12:
            return f"Error: Category limit reached ({self.MAX_CATEGORIES} max)"

        return None

    def discover_global_categories(self):
        """
        Find all global category files in ~/.jot-categories/
        Returns list of category names (without .json suffix).
        Excludes special files like ids, archive, etc.
        """
        # Return empty list if global directory doesn't exist
        if not self.GLOBAL_CATEGORIES_DIR.exists():
            return []

        categories = []
        reserved_names = {'ids', 'archive', 'index', 'config'}

        # Find all *.json files in global categories directory
        for file in self.GLOBAL_CATEGORIES_DIR.glob('*.json'):
            category = file.stem  # filename without .json

            # Skip reserved names and special files
            if category not in reserved_names and not category.endswith('.ids'):
                categories.append(category)

        return sorted(categories)

    def category_exists_locally(self, category_name):
        """Check if category exists locally in project"""
        categories_dir = self.project_dir / '.jot-categories'
        local_file = categories_dir / f'{category_name}.json'
        return local_file.exists()

    def category_exists_globally(self, category_name):
        """Check if category exists globally"""
        global_file = self.GLOBAL_CATEGORIES_DIR / f'{category_name}.json'
        return global_file.exists()

    def resolve_category_location(self, category_name):
        """
        Determine if category is local, global, or new.
        Returns: 'local', 'global', or 'new'
        """
        if self.category_exists_locally(category_name):
            return 'local'
        elif self.category_exists_globally(category_name):
            return 'global'
        else:
            return 'new'

    def get_category_file_path(self, category_name, is_global=False):
        """
        Get the full path for a category file.

        Args:
            category_name: Name of the category
            is_global: If True, return global path; if False, return local path

        Returns:
            Path object for the category file
        """
        if is_global:
            return self.GLOBAL_CATEGORIES_DIR / f'{category_name}.json'
        else:
            # Local categories are stored in .jot-categories/ directory
            categories_dir = self.project_dir / '.jot-categories'
            categories_dir.mkdir(exist_ok=True)
            return categories_dir / f'{category_name}.json'
