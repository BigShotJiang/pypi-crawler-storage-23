"""Category templates for quick project setup"""

from pathlib import Path

from jot.categories.config import CategoryConfig
from jot.categories.manager import CategoryManager
from jot.core.task_manager import TaskManager


class CategoryTemplates:
    """Manages category templates for quick project setup"""

    TEMPLATES = {
        'software-dev': {
            'name': 'Software Development',
            'description': 'Standard software project categories',
            'categories': ['features', 'bugs', 'testing', 'docs'],
            'sample_tasks': {
                'features': ['Plan next sprint', 'Review backlog'],
                'bugs': ['Triage bug reports'],
                'testing': ['Run test suite', 'Update test coverage'],
                'docs': ['Update README', 'Write API docs'],
            },
        },
        'personal': {
            'name': 'Personal Tasks',
            'description': 'Personal life management categories',
            'categories': ['work', 'home', 'bills', 'health'],
            'sample_tasks': {
                'work': ['Check email', 'Weekly planning'],
                'home': ['Grocery shopping', 'Clean house'],
                'bills': ['Pay rent', 'Review budget'],
                'health': ['Exercise', 'Doctor appointment'],
            },
        },
        'creative': {
            'name': 'Creative Project',
            'description': 'Creative and content creation categories',
            'categories': ['ideas', 'drafts', 'editing', 'publishing'],
            'sample_tasks': {
                'ideas': ['Brainstorm topics', 'Research inspiration'],
                'drafts': ['Write first draft'],
                'editing': ['Review and revise'],
                'publishing': ['Format and publish'],
            },
        },
        'business': {
            'name': 'Business Management',
            'description': 'Business and client work categories',
            'categories': ['leads', 'clients', 'invoicing', 'marketing'],
            'sample_tasks': {
                'leads': ['Follow up prospects', 'Update CRM'],
                'clients': ['Client meetings', 'Project deliverables'],
                'invoicing': ['Send invoices', 'Track payments'],
                'marketing': ['Social media posts', 'Email campaign'],
            },
        },
        'academic': {
            'name': 'Academic/Research',
            'description': 'Academic and research project categories',
            'categories': ['reading', 'research', 'writing', 'teaching'],
            'sample_tasks': {
                'reading': ['Literature review', 'Paper analysis'],
                'research': ['Experiment design', 'Data collection'],
                'writing': ['Draft paper', 'Revise manuscript'],
                'teaching': ['Prepare lecture', 'Grade assignments'],
            },
        },
    }

    def __init__(self, project_dir=None):
        """Initialize templates manager"""
        self.project_dir = Path(project_dir) if project_dir else Path.cwd()
        self.cat_manager = CategoryManager(project_dir=self.project_dir)
        self.cat_config = CategoryConfig(project_dir=self.project_dir)

    def list_templates(self):
        """List all available templates"""
        return self.TEMPLATES

    def apply_template(self, template_name, with_samples=False):
        """Apply a template to create categories"""
        if template_name not in self.TEMPLATES:
            return False, f"Template '{template_name}' not found"

        template = self.TEMPLATES[template_name]
        categories_to_create = template['categories']

        existing_categories = self.cat_manager.discover_categories()
        total_after = len(existing_categories) + len(categories_to_create)

        if total_after > CategoryManager.MAX_CATEGORIES:
            return (
                False,
                f"Cannot create {len(categories_to_create)} categories. "
                f"Would exceed limit ({CategoryManager.MAX_CATEGORIES} max)",
            )

        conflicts = [c for c in categories_to_create if c in existing_categories]
        if conflicts:
            return False, f"Categories already exist: {', '.join(conflicts)}"

        created = []
        for category in categories_to_create:
            tm = TaskManager(
                directory=self.project_dir,
                category=category,
                is_global=False,
            )
            if with_samples and category in template.get('sample_tasks', {}):
                for task_text in template['sample_tasks'][category]:
                    tm.add_task(task_text)
            created.append(category)

        return True, f"Created {len(created)} categories: {', '.join(created)}"

    def get_template_info(self, template_name):
        """Get detailed information about a template"""
        if template_name not in self.TEMPLATES:
            return None
        return self.TEMPLATES[template_name]
