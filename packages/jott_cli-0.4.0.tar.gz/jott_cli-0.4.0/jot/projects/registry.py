"""Project registry for managing multiple jot projects"""

import json
from pathlib import Path

from jot.utils.validation import validate_safe_name


def _get_path(entry):
    """Extract path from registry entry (handles old and new format)"""
    if isinstance(entry, str):
        return entry
    return entry.get("path", "")


class ProjectRegistry:
    """Manages project name → directory path mappings with usage tracking"""

    def __init__(self, registry_file='~/.jot-projects.json'):
        self.registry_file = Path(registry_file).expanduser()
        self.projects = {}
        self._load_registry()

    def _load_registry(self):
        """Load project registry from JSON file"""
        if self.registry_file.exists():
            try:
                with open(self.registry_file, 'r') as f:
                    self.projects = json.load(f)
            except json.JSONDecodeError:
                self.projects = {}
        else:
            # Auto-discover projects on first run
            self._auto_discover()

    def _save_registry(self):
        """Save project registry to JSON file"""
        self.registry_file.parent.mkdir(parents=True, exist_ok=True)
        with open(self.registry_file, 'w') as f:
            json.dump(self.projects, f, indent=2)

    def _auto_discover(self):
        """Auto-discover projects with .jot.json files"""
        projects_dir = Path.home() / 'projects'
        if projects_dir.exists():
            for item in projects_dir.iterdir():
                if item.is_dir():
                    jot_file = item / '.jot.json'
                    if jot_file.exists():
                        self.projects[item.name] = str(item)
            self._save_registry()

    def register_project(self, name, path):
        """Register a project

        Args:
            name: Project name (validated for safety)
            path: Project directory path

        Raises:
            ValueError: If name contains dangerous characters
        """
        # Validate project name for security
        name = validate_safe_name(name, "project name")
        resolved = str(Path(path).expanduser().resolve())
        # Preserve usage_count if project already exists
        existing = self.projects.get(name)
        usage = existing.get("usage_count", 0) if isinstance(existing, dict) else 0
        self.projects[name] = {"path": resolved, "usage_count": usage}
        self._save_registry()

    def unregister_project(self, name):
        """Unregister a project"""
        if name in self.projects:
            del self.projects[name]
            self._save_registry()
            return True
        return False

    def get_project_path(self, name):
        """Get path for a project name"""
        entry = self.projects.get(name)
        if entry is None:
            return None
        return _get_path(entry)

    def list_projects(self):
        """Return {name: path} dict (backward compatible)"""
        return {name: _get_path(entry) for name, entry in self.projects.items()}

    def list_projects_by_usage(self):
        """Return [(name, path, usage_count)] sorted by usage desc, then name asc"""
        items = []
        for name, entry in self.projects.items():
            if isinstance(entry, str):
                items.append((name, entry, 0))
            else:
                items.append((name, entry.get("path", ""), entry.get("usage_count", 0)))
        items.sort(key=lambda x: (-x[2], x[0]))
        return items

    def record_usage(self, name):
        """Increment usage count for a project"""
        if name not in self.projects:
            return
        entry = self.projects[name]
        if isinstance(entry, str):
            self.projects[name] = {"path": entry, "usage_count": 1}
        else:
            entry["usage_count"] = entry.get("usage_count", 0) + 1
        self._save_registry()

    def refresh(self):
        """Re-run auto-discovery"""
        self._auto_discover()
