"""Google Calendar event management"""

from datetime import datetime, timedelta

from jot.utils.date_utils import round_to_15_minutes


def create_gcal_event(service, task_text, start_time=None, duration_minutes=15):
    """Create a Google Calendar event from task text

    Args:
        service: Google Calendar API service object
        task_text: Task text to use as event summary
        start_time: Optional timezone-aware datetime for event start (default: now rounded to 15 min)
        duration_minutes: Event duration in minutes (default: 15)

    Returns:
        Event link (htmlLink) or None if failed

    Raises:
        HttpError: If API call fails
    """
    if start_time is None:
        now = datetime.now().astimezone()
        start_time = round_to_15_minutes(now)
    end_time = start_time + timedelta(minutes=duration_minutes)

    # Build event (isoformat() includes timezone when datetime is timezone-aware)
    event = {
        'summary': task_text,
        'start': {
            'dateTime': start_time.isoformat(),
        },
        'end': {
            'dateTime': end_time.isoformat(),
        },
        'description': 'Created from jot task',
    }

    # Insert event
    result = service.events().insert(calendarId='primary', body=event).execute()
    return result.get('htmlLink')


def fetch_gcal_events(service, date=None, days=1, direction='future'):
    """Fetch events from Google Calendar for a specific date or date range

    Args:
        service: Google Calendar API service object
        date: datetime.date object (default: today)
        days: Number of days to fetch events for (1-7)
        direction: 'future' for upcoming days, 'past' for previous days

    Returns:
        List of dicts with {'summary': str, 'start': datetime/None, 'end': datetime/None, 'all_day': bool, 'date': date, 'description': str}
        Returns empty list if no events found

    Raises:
        HttpError: If API call fails
    """
    if date is None:
        date = datetime.now().date()

    # Clamp days between 1 and 7
    days = max(1, min(7, days))

    # Set time range based on direction
    if direction == 'past':
        # For past events, go backwards from yesterday (exclude today)
        end_date = date - timedelta(days=1)
        start_date = end_date - timedelta(days=days - 1)
    else:
        # For future events (default), go forward from today
        start_date = date
        end_date = date + timedelta(days=days - 1)

    start_of_period = datetime.combine(start_date, datetime.min.time()).astimezone()
    end_of_period = datetime.combine(end_date, datetime.max.time()).astimezone()

    # Fetch events from primary calendar
    events_result = (
        service.events()
        .list(
            calendarId='primary',
            timeMin=start_of_period.isoformat(),
            timeMax=end_of_period.isoformat(),
            singleEvents=True,
            orderBy='startTime',
        )
        .execute()
    )

    events = events_result.get('items', [])

    # Parse events into simplified format
    parsed_events = []
    for event in events:
        summary = event.get('summary', '(No title)')
        description = event.get('description', '')

        # Check if all-day event
        start = event['start'].get('dateTime')
        end = event['end'].get('dateTime')

        if start:
            # Timed event
            start_dt = datetime.fromisoformat(start.replace('Z', '+00:00'))
            end_dt = datetime.fromisoformat(end.replace('Z', '+00:00'))
            event_date = start_dt.date()
            parsed_events.append(
                {'summary': summary, 'start': start_dt, 'end': end_dt, 'all_day': False, 'date': event_date, 'description': description}
            )
        else:
            # All-day event - get date from 'date' field
            event_date = datetime.fromisoformat(event['start'].get('date')).date()
            parsed_events.append({'summary': summary, 'start': None, 'end': None, 'all_day': True, 'date': event_date, 'description': description})

    return parsed_events
