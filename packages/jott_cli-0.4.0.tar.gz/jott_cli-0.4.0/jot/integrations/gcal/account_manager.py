"""Google Calendar account management"""

from pathlib import Path


class GoogleCalendarAccountManager:
    """Manage multiple Google Calendar accounts"""

    ACCOUNTS_DIR = Path.home() / '.jot' / 'gcal-accounts'

    def __init__(self):
        """Initialize account manager"""
        # Ensure accounts directory exists
        self.ACCOUNTS_DIR.mkdir(parents=True, exist_ok=True)

    def discover_accounts(self):
        """Discover all configured Google Calendar accounts

        Returns:
            list: Account names (subdirectories with credentials.json)
        """
        if not self.ACCOUNTS_DIR.exists():
            return []

        accounts = []
        for path in self.ACCOUNTS_DIR.iterdir():
            if path.is_dir() and (path / 'credentials.json').exists():
                accounts.append(path.name)

        return sorted(accounts)

    def get_account_path(self, account_name):
        """Get path to account directory

        Args:
            account_name: Name of the account

        Returns:
            Path: Path to account directory
        """
        return self.ACCOUNTS_DIR / account_name

    def account_exists(self, account_name):
        """Check if account is configured

        Args:
            account_name: Name of the account

        Returns:
            bool: True if account directory exists with credentials.json
        """
        account_path = self.get_account_path(account_name)
        return account_path.exists() and (account_path / 'credentials.json').exists()

    def create_account(self, account_name):
        """Create new account directory

        Args:
            account_name: Name of the account

        Returns:
            Path: Path to created account directory
        """
        account_path = self.get_account_path(account_name)
        account_path.mkdir(parents=True, exist_ok=True)
        return account_path
