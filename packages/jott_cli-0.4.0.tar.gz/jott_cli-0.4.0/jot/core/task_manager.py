"""Task management and storage for jot"""

import json
import os
import re
import sys
import uuid
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from jot.core.id_manager import IDManager
from jot.categories.manager import CategoryManager
from jot.integrations.keywords.handler import KeywordHandler
from jot.utils.validation import validate_safe_name

class TaskManager:
    """Handles task storage and retrieval"""

    def __init__(
        self,
        storage_file='.jot.json',
        directory=None,
        id_manager=None,
        category=None,
        is_global=False,
        project_registry=None,
    ):
        """
        Initialize TaskManager

        Args:
            storage_file: Base filename (used only if category is None and not global)
            directory: Project directory (ignored if is_global=True)
            id_manager: Shared IDManager instance
            category: Category name (validated for path traversal safety)
            is_global: If True, use global category storage in ~/.jot-categories/
            project_registry: Optional ProjectRegistry for keyword-based project routing

        Raises:
            ValueError: If category name contains dangerous characters
        """
        # Validate category name for security (prevent path traversal)
        if category and category != 'default':
            category = validate_safe_name(category, "category name")

        # Store category and global flag
        self.category = category
        self.is_global = is_global

        # Set up directory and file path
        if is_global:
            # Global category: ~/.jot-categories/ (use CategoryManager's constant)
            global_dir = CategoryManager.GLOBAL_CATEGORIES_DIR
            global_dir.mkdir(parents=True, exist_ok=True)
            self.project_dir = global_dir

            # Build filename for global category
            if category:
                filename = f'{category}.json'
            else:
                filename = 'default.json'

            self.storage_file = self.project_dir / filename

            # Use global ID manager for this category
            if id_manager:
                self.id_manager = id_manager
            else:
                # Global categories get their own ID manager per category
                ids_file = self.project_dir / f'{category or "default"}.ids.json'
                self.id_manager = IDManager(project_dir=self.project_dir)
                # Override the ids_file to be category-specific
                self.id_manager.ids_file = ids_file
                self.id_manager._load_ids()
        else:
            # Local category: project directory
            if directory:
                self.project_dir = Path(directory)
            else:
                self.project_dir = Path.cwd()

            # Build filename based on category
            if category:
                # Category-specific file: .jot-categories/{category}.json
                categories_dir = self.project_dir / '.jot-categories'
                categories_dir.mkdir(exist_ok=True)
                self.storage_file = categories_dir / f'{category}.json'
            else:
                # Default file: .jot.json (or custom storage_file)
                self.storage_file = self.project_dir / storage_file

            # Use provided ID manager or create new one
            self.id_manager = id_manager if id_manager else IDManager(self.project_dir)

        self.tasks = []
        self.archived = []
        self._load_tasks()

        # Migrate existing IDs to IDManager if needed
        self._migrate_ids_if_needed()

        # Initialize keyword handler for automation
        self.keyword_handler = KeywordHandler(project_registry=project_registry)

    def _load_tasks(self):
        """Load tasks from JSON file"""
        if self.storage_file.exists():
            try:
                with open(self.storage_file, 'r') as f:
                    data = json.load(f)
                    # Handle old format (list) and new format (dict)
                    if isinstance(data, list):
                        self.tasks = data
                        self.archived = []
                    else:
                        self.tasks = data.get('tasks', [])
                        self.archived = data.get('archived', [])
            except json.JSONDecodeError:
                self.tasks = []
                self.archived = []
        else:
            self.tasks = []
            self.archived = []

    def _save_tasks(self):
        """Save tasks to JSON file"""
        # Ensure parent directory exists
        self.storage_file.parent.mkdir(parents=True, exist_ok=True)

        with open(self.storage_file, 'w') as f:
            json.dump({'tasks': self.tasks, 'archived': self.archived}, f, indent=2)

    def _migrate_ids_if_needed(self):
        """Migrate existing task IDs to IDManager on first load"""
        # Collect all existing IDs from tasks and archived
        existing_ids = []
        for task in self.tasks + self.archived:
            if 'id' in task:
                existing_ids.append(task['id'])

        if not existing_ids:
            return

        # Always ensure existing IDs are tracked in IDManager
        # This prevents duplicate allocation even if next_id > 1
        max_existing = max(existing_ids)

        # Ensure next_id is at least max_existing + 1
        if self.id_manager.next_id <= max_existing:
            self.id_manager.next_id = max_existing + 1

        # Add any missing IDs to allocated list
        existing_set = set(existing_ids)
        allocated_set = set(self.id_manager.allocated)
        missing_ids = existing_set - allocated_set

        if missing_ids:
            # Add missing IDs and save
            self.id_manager.allocated.extend(sorted(missing_ids))
            self.id_manager.allocated = sorted(set(self.id_manager.allocated))
            self.id_manager._save_ids()

        # Auto-fix any duplicate IDs after migration
        self._autofix_duplicate_ids()

    def _autofix_duplicate_ids(self):
        """
        Detect and automatically fix duplicate task IDs.
        Creates backup before fixing and shows warning to user.
        """
        all_tasks = self.tasks + self.archived
        ids = [task['id'] for task in all_tasks if 'id' in task]

        # Check for duplicates

        id_counts = Counter(ids)
        duplicates = {task_id: count for task_id, count in id_counts.items() if count > 1}

        if not duplicates:
            return  # No duplicates, nothing to fix

        # Create backup before fixing
        now = datetime.now()
        timestamp = now.strftime("%Y%m%d_%H%M%S")
        year_month = now.strftime("%Y-%m")

        # Create backup directory structure
        backup_dir = self.storage_file.parent / '.jot-backups' / year_month
        backup_dir.mkdir(parents=True, exist_ok=True)

        # Create backup file in organized structure
        backup_file = backup_dir / f'{timestamp}.json'
        with open(self.storage_file, 'r') as f:
            backup_data = f.read()
        with open(backup_file, 'w') as f:
            f.write(backup_data)

        # Build list of tasks that need new IDs
        # Strategy: Keep first occurrence, reassign subsequent duplicates
        seen_ids = set()
        tasks_to_fix = []  # List of (task, list_name, index) tuples

        for idx, task in enumerate(self.tasks):
            task_id = task.get('id')
            if task_id in duplicates:
                if task_id in seen_ids:
                    # This is a duplicate, needs new ID
                    tasks_to_fix.append((task, 'tasks', idx))
                else:
                    # First occurrence, keep it
                    seen_ids.add(task_id)

        for idx, task in enumerate(self.archived):
            task_id = task.get('id')
            if task_id in duplicates:
                if task_id in seen_ids:
                    # This is a duplicate, needs new ID
                    tasks_to_fix.append((task, 'archived', idx))
                else:
                    # First occurrence, keep it
                    seen_ids.add(task_id)

        # Reassign IDs for duplicate tasks
        old_to_new = {}  # Map old ID -> new ID for reporting
        for task, list_name, idx in tasks_to_fix:
            old_id = task['id']
            new_id = self.id_manager.allocate_id()
            task['id'] = new_id

            if old_id not in old_to_new:
                old_to_new[old_id] = []
            old_to_new[old_id].append(new_id)

        # Save fixed data
        self._save_tasks()

        # Show warning message
        YELLOW = '\033[93m'
        RESET = '\033[0m'
        DIM = '\033[2m'

        print(f"\n{YELLOW}⚠ Auto-fixed duplicate task IDs{RESET}")
        print(f"  Backup: {DIM}{backup_file}{RESET}")
        changes = []
        for old_id, new_ids in sorted(old_to_new.items()):
            changes.append(f"{old_id} → {', '.join(map(str, new_ids))}")
        print(f"  Changed: {', '.join(changes)}")
        print()

    def _get_next_id(self):
        """
        DEPRECATED: Use id_manager.allocate_id() instead.
        Get next available ID by finding max across tasks and archive.
        """
        max_id = 0
        for task in self.tasks + self.archived:
            if task.get('id', 0) > max_id:
                max_id = task['id']
        return max_id + 1

    def add_task(self, task_text, priority='none', status='todo', labels=None, effort=None):
        """
        Add a new task with guaranteed unique ID from IDManager

        Args:
            task_text: Task description
            priority: Task priority ('none', 'low', 'medium', 'high')
            status: Task status ('todo', 'in-progress', 'blocked', 'done')
            labels: List of labels (e.g., ['bug', 'feature', 'tech-debt'])
            effort: Effort estimation (1-5 points or None)
        """

        now = datetime.now(timezone.utc).isoformat()

        # Extract keyword from task text (check for project routing first)
        keyword, task_text, project_name = self.keyword_handler.extract_keyword(task_text)

        # If a project name was detected, route the task to that project
        if project_name and self.keyword_handler.project_registry:
            # Broadcast to all registered projects
            if project_name == "__all__":
                projects = self.keyword_handler.project_registry.list_projects()
                for proj_name, proj_path in projects.items():
                    target_tm = TaskManager(
                        directory=proj_path,
                        category=None,
                        project_registry=self.keyword_handler.project_registry,
                    )
                    # Skip if project already has this task (prevent duplicates)
                    existing = [t['text'] for t in target_tm.tasks if not t.get('done')]
                    if task_text in existing:
                        continue
                    target_tm.add_task(
                        task_text,
                        priority=priority,
                        status=status,
                        labels=labels,
                        effort=effort,
                    )
                return

            target_path = self.keyword_handler.project_registry.get_project_path(project_name)
            if target_path:
                target_tm = TaskManager(
                    directory=target_path,
                    category=None,  # Use default category
                    project_registry=self.keyword_handler.project_registry,
                )
                target_tm.add_task(
                    task_text,
                    priority=priority,
                    status=status,
                    labels=labels,
                    effort=effort,
                )
                # Return early - task was routed to another project
                return

        # Allocate unique ID
        new_id = self.id_manager.allocate_id()

        # Validate ID uniqueness before creating task (safety check)
        existing_ids = {task['id'] for task in self.tasks + self.archived if 'id' in task}
        if new_id in existing_ids:
            # This should never happen with proper file locking, but if it does,
            # log error and auto-fix by requesting a new ID

            print(
                f"WARNING: Duplicate ID {new_id} detected during task creation. "
                f"This indicates a concurrency issue. Auto-fixing...",
                file=sys.stderr,
            )
            # Try to get a fresh ID by reloading state
            self.id_manager._load_ids()
            new_id = self.id_manager.allocate_id()

            # If still duplicate, something is very wrong
            if new_id in existing_ids:
                raise ValueError(
                    f"Critical error: Unable to allocate unique ID. "
                    f"ID {new_id} already exists. Please check .jot.ids.json"
                )

        # Create task object
        task = {
            'id': new_id,
            'text': task_text,
            'done': False,
            'current': False,
            'day': None,
            'tally': 0,
            'agent_task': False,  # Mark if Claude Code is working on this
            # Backlog grooming metadata
            'priority': priority,
            'status': status,
            'created_at': now,
            'updated_at': now,
            'labels': labels if labels is not None else [],
            'effort': effort,
            'blocked_by': [],
            'notes': '',  # Additional notes for the task
            'keyword': keyword,  # Automation keyword (e.g., 'bullet', 'gcal')
        }

        self.tasks.append(task)
        self._save_tasks()

        # Trigger keyword action if auto-trigger is enabled
        if keyword:
            result = self.keyword_handler.handle(keyword, task)
            if result:
                # Save task again if handler modified it (e.g., ai: sets agent_task)
                self._save_tasks()

    def migrate_backlog_schema(self):
        """
        Migrate existing tasks to include backlog grooming metadata.
        Adds missing fields with sensible defaults:
        - priority: 'none'
        - status: 'todo' (or 'done' if task.done == True)
        - created_at: current timestamp (best effort for existing tasks)
        - updated_at: current timestamp
        - labels: [] (empty list)
        - effort: None
        - blocked_by: [] (empty list)

        Returns:
            dict: Migration statistics
        """

        now = datetime.now(timezone.utc).isoformat()
        migrated_count = 0
        already_migrated = 0

        for task in self.tasks + self.archived:
            # Check if task already has new schema
            has_new_fields = (
                'priority' in task
                and 'status' in task
                and 'created_at' in task
                and 'updated_at' in task
                and 'labels' in task
                and 'effort' in task
                and 'blocked_by' in task
                and 'notes' in task
                and 'keyword' in task
            )

            if has_new_fields:
                already_migrated += 1
                continue

            # Add missing fields with defaults
            if 'priority' not in task:
                task['priority'] = 'none'

            if 'status' not in task:
                # Infer status from existing 'done' field
                task['status'] = 'done' if task.get('done', False) else 'todo'

            if 'created_at' not in task:
                task['created_at'] = now

            if 'updated_at' not in task:
                task['updated_at'] = now

            if 'labels' not in task:
                task['labels'] = []

            if 'effort' not in task:
                task['effort'] = None

            if 'blocked_by' not in task:
                task['blocked_by'] = []

            if 'notes' not in task:
                task['notes'] = ''

            if 'keyword' not in task:
                task['keyword'] = None

            migrated_count += 1

        # Save updated tasks
        if migrated_count > 0:
            self._save_tasks()

        return {
            'migrated': migrated_count,
            'already_migrated': already_migrated,
            'total': migrated_count + already_migrated,
        }

    def ensure_default_task(self):
        """Create default 'take a break' task if no tasks exist"""
        if not self.tasks and not self.archived:
            self.add_task("take a break")

    def set_current(self, task_id):
        """Mark a task as current (only one task can be current)

        If the task is archived, it will be automatically unarchived.
        """
        # Clear all current flags in active tasks
        for task in self.tasks:
            task['current'] = False

        # Check if task is in active tasks
        for task in self.tasks:
            if task['id'] == task_id:
                task['current'] = True
                self._save_tasks()
                return True

        # Check if task is archived - if so, unarchive it and set as current
        for i, task in enumerate(self.archived):
            if task['id'] == task_id:
                # Remove from archived
                archived_task = self.archived.pop(i)
                # Add to active tasks
                archived_task['current'] = True
                self.tasks.append(archived_task)
                self._save_tasks()
                return True

        return False

    def set_agent_task(self, task_id=None):
        """
        Mark a task as agent_task (Claude Code is working on it).
        Only one task can be marked as agent_task at a time.

        Args:
            task_id: Task ID to mark as agent_task. If None, uses current task.
                    If task_id is already agent_task, it will be unmarked.

        Returns:
            True if successful, False if task not found
        """
        # If no task_id provided, use current task
        if task_id is None:
            current = self.get_current_task()
            if not current:
                return False
            task_id = current['id']

        # Check if this task is already marked as agent_task (toggle behavior)
        target_task = None
        for task in self.tasks:
            if task['id'] == task_id:
                target_task = task
                break

        if not target_task:
            return False

        # Toggle: if already agent_task, unmark it
        if target_task.get('agent_task', False):
            target_task['agent_task'] = False
            self._save_tasks()
            return True

        # Otherwise, clear all agent_task flags and set the target
        for task in self.tasks:
            task['agent_task'] = False

        target_task['agent_task'] = True
        self._save_tasks()
        return True

    def get_tasks(self):
        """Return all tasks"""
        return self.tasks

    def get_current_task(self):
        """Get the currently selected task"""
        for task in self.tasks:
            if task.get('current', False):
                return task
        return None

    def move_task_up(self):
        """Move the current task up in the list"""
        if not self.tasks or len(self.tasks) < 2:
            return False

        current_idx = -1
        for i, task in enumerate(self.tasks):
            if task.get('current', False):
                current_idx = i
                break

        if current_idx <= 0:
            # Already at top or no current task
            return False

        # Swap with previous task
        self.tasks[current_idx], self.tasks[current_idx - 1] = (
            self.tasks[current_idx - 1],
            self.tasks[current_idx],
        )
        self._save_tasks()
        return True

    def move_task_down(self):
        """Move the current task down in the list"""
        if not self.tasks or len(self.tasks) < 2:
            return False

        current_idx = -1
        for i, task in enumerate(self.tasks):
            if task.get('current', False):
                current_idx = i
                break

        if current_idx == -1 or current_idx >= len(self.tasks) - 1:
            # No current task or already at bottom
            return False

        # Swap with next task
        self.tasks[current_idx], self.tasks[current_idx + 1] = (
            self.tasks[current_idx + 1],
            self.tasks[current_idx],
        )
        self._save_tasks()
        return True

    def sort_by_priority(self):
        """Sort tasks by priority (high → medium → low → none)

        Returns:
            bool: True if sorting was performed, False if no tasks
        """
        if not self.tasks:
            return False

        # Priority ordering: high > medium > low > none
        priority_order = {'high': 0, 'medium': 1, 'low': 2, 'none': 3}

        # Remember current task ID to restore it after sorting
        current_task_id = None
        for task in self.tasks:
            if task.get('current', False):
                current_task_id = task['id']
                break

        # Sort tasks by priority
        self.tasks.sort(key=lambda t: priority_order.get(t.get('priority', 'none'), 3))

        # Restore current task marker
        if current_task_id:
            for task in self.tasks:
                task['current'] = task['id'] == current_task_id

        self._save_tasks()
        return True

    def remove_task(self, task_id):
        """Archive a task by ID and set previous task as current"""
        # Save notes to org file before archiving (if task has notes)
        org_file = self.save_notes_to_org_file(task_id)
        if org_file:
            filename = os.path.basename(org_file)
            print(f"\n✓ Notes saved to {filename}")

        task_to_archive = None
        task_index = -1

        # Find the task and its index
        for i, task in enumerate(self.tasks):
            if task['id'] == task_id:
                task_to_archive = task
                task_index = i
                break

        if task_to_archive:
            # Remove from active tasks
            self.tasks = [task for task in self.tasks if task['id'] != task_id]
            # Add to archived tasks
            self.archived.append(task_to_archive)

            # Set previous task as current (if any tasks remain)
            if self.tasks:
                # Clear all current flags first
                for task in self.tasks:
                    task['current'] = False

                # Determine which task should be current
                if task_index == 0:
                    # Deleted first task, make new first task current
                    self.tasks[0]['current'] = True
                else:
                    # Make previous task current (index is now one less due to deletion)
                    new_index = min(task_index - 1, len(self.tasks) - 1)
                    self.tasks[new_index]['current'] = True

            self._save_tasks()
            return True
        return False

    def delete_task_permanently(self, task_id):
        """Permanently delete a task by ID (from both active and archived lists)
        and release its ID for reuse"""
        # Save notes to org file before permanent deletion (if task has notes)
        org_file = self.save_notes_to_org_file(task_id)
        if org_file:
            filename = os.path.basename(org_file)
            print(f"\n✓ Notes saved to {filename}")

        deleted = False

        # Remove from active tasks
        original_count = len(self.tasks)
        self.tasks = [task for task in self.tasks if task['id'] != task_id]
        if len(self.tasks) < original_count:
            deleted = True

        # Remove from archived tasks
        original_archived_count = len(self.archived)
        self.archived = [task for task in self.archived if task['id'] != task_id]
        if len(self.archived) < original_archived_count:
            deleted = True

        if deleted:
            # Release the ID for reuse
            self.id_manager.release_id(task_id)
            self._save_tasks()
            return True
        return False

    def archive_task(self, task_id):
        """Archive a task by ID (wrapper around remove_task for consistency)"""
        return self.remove_task(task_id)

    def edit_task(self, task_id, new_text):
        """Edit a task's text by ID"""
        for task in self.tasks:
            if task['id'] == task_id:
                task['text'] = new_text
                self._save_tasks()
                return True
        return False

    def set_task_day(self, task_id, day):
        """Assign a day of the week to a task

        Args:
            task_id: ID of task to update
            day: Day name (Monday-Sunday) or None to clear
        """
        for task in self.tasks:
            if task['id'] == task_id:
                task['day'] = day
                self._save_tasks()
                return True
        return False

    def set_task_priority(self, task_id, priority):
        """Set priority for a task

        Args:
            task_id: ID of task to update
            priority: Priority level ('none', 'low', 'medium', 'high')
        """

        valid_priorities = ['none', 'low', 'medium', 'high']
        if priority not in valid_priorities:
            raise ValueError(f"Priority must be one of: {', '.join(valid_priorities)}")

        for task in self.tasks:
            if task['id'] == task_id:
                task['priority'] = priority
                task['updated_at'] = datetime.now(timezone.utc).isoformat()
                self._save_tasks()
                return True
        return False

    def set_task_status(self, task_id, status):
        """Set status for a task

        Args:
            task_id: ID of task to update
            status: Status ('todo', 'in-progress', 'blocked', 'done')
        """

        valid_statuses = ['todo', 'in-progress', 'blocked', 'done']
        if status not in valid_statuses:
            raise ValueError(f"Status must be one of: {', '.join(valid_statuses)}")

        for task in self.tasks:
            if task['id'] == task_id:
                task['status'] = status
                task['updated_at'] = datetime.now(timezone.utc).isoformat()
                # Auto-update 'done' field based on status
                if status == 'done':
                    task['done'] = True
                elif task.get('done', False):
                    # If status is changing from done to something else, unmark done
                    task['done'] = False
                self._save_tasks()
                return True
        return False

    def get_task_notes(self, task_id):
        """Get notes for a task

        Args:
            task_id: ID of task

        Returns:
            str: Notes text (empty string if no notes)
        """
        for task in self.tasks:
            if task['id'] == task_id:
                return task.get('notes', '')
        return ''

    def set_task_notes(self, task_id, notes_text):
        """Set notes for a task

        Args:
            task_id: ID of task to update
            notes_text: Notes text (can be multi-line)

        Returns:
            bool: True if task found and updated, False otherwise
        """

        for task in self.tasks:
            if task['id'] == task_id:
                task['notes'] = notes_text
                task['updated_at'] = datetime.now(timezone.utc).isoformat()
                self._save_tasks()
                return True
        return False

    def sync_subtasks_from_notes(self, task_id):
        """Parse checklist items from task notes and sync as subtasks.

        Parses '- [ ] text' (todo) and '- [X] text' (done) lines.
        Creates new tasks with 'parent:{id}' label, skips duplicates.

        Returns:
            dict with 'created', 'updated', 'total' counts, or None if task not found
        """
        task = next((t for t in self.tasks if t['id'] == task_id), None)
        if not task:
            return None

        notes = task.get('notes', '')
        if not notes:
            return {'created': 0, 'updated': 0, 'total': 0}

        # Parse checklist items: "- [ ] text" or "- [X] text" or "- [x] text"
        pattern = r'^-\s*\[([ xX])\]\s+(.+)$'
        checklist_items = []
        for line in notes.split('\n'):
            match = re.match(pattern, line.strip())
            if match:
                done = match.group(1).lower() == 'x'
                text = match.group(2).strip()
                checklist_items.append((text, done))

        if not checklist_items:
            return {'created': 0, 'updated': 0, 'total': 0}

        parent_label = f"parent:{task_id}"
        existing = {
            t['text']: t for t in self.tasks
            if parent_label in t.get('labels', [])
        }

        now = datetime.now(timezone.utc).isoformat()
        created = 0
        updated = 0
        for text, done in checklist_items:
            if text in existing:
                sub = existing[text]
                new_status = 'done' if done else 'todo'
                if sub['status'] != new_status:
                    sub['status'] = new_status
                    sub['done'] = done
                    sub['updated_at'] = now
                    updated += 1
            else:
                self.add_task(
                    text,
                    status='done' if done else 'todo',
                    labels=[parent_label],
                )
                created += 1

        if updated:
            self._save_tasks()

        return {'created': created, 'updated': updated, 'total': len(checklist_items)}

    def save_notes_to_org_file(self, task_id):
        """Save task notes to an org file before deletion.
        Only creates file if task has non-empty notes.

        Args:
            task_id: ID of task to save notes from

        Returns:
            str: Path to created org file, or None if no notes
        """

        # Get the task from either active or archived list
        task = None
        for t in self.tasks:
            if t['id'] == task_id:
                task = t
                break
        if not task:
            for t in self.archived:
                if t['id'] == task_id:
                    task = t
                    break

        if not task:
            return None

        # Check if task has notes
        notes = task.get('notes', '').strip()
        if not notes:
            return None

        # Create org file content with proper formatting
        timestamp = datetime.now().strftime('%Y-%m-%d')
        created_at = task.get('created_at', 'unknown')
        if created_at != 'unknown':
            try:
                # Try to format ISO timestamp to readable format
                created_dt = datetime.fromisoformat(created_at.replace('Z', '+00:00'))
                created_at = created_dt.strftime('%Y-%m-%d %H:%M:%S')
            except Exception:
                pass

        org_content = f'''#+TITLE: Task #{task_id} Notes (Deleted)
#+DATE: {timestamp}

* Task Information
  - ID: {task_id}
  - Text: {task['text']}
  - Status: {task.get('status', 'todo')}
  - Priority: {task.get('priority', 'none')}
  - Created: {created_at}

* Notes
{notes}

* Metadata
  - Deleted: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
  - Original file: {self.storage_file.name}
'''

        # Create filename with timestamp to avoid conflicts
        file_timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f'TASK-{task_id}-notes-{file_timestamp}.org'
        org_file_path = self.project_dir / filename

        # Write file
        try:
            with open(org_file_path, 'w') as f:
                f.write(org_content)
            return str(org_file_path)
        except Exception as e:
            print(f"Warning: Could not save notes to org file: {e}")
            return None

    def get_task_age_days(self, task):
        """Calculate age of task in days since last update

        Args:
            task: Task dictionary

        Returns:
            int: Number of days since last update, or None if no timestamp
        """

        updated_at = task.get('updated_at')
        if not updated_at:
            return None

        try:
            # Parse ISO 8601 timestamp
            updated_dt = datetime.fromisoformat(updated_at.replace('Z', '+00:00'))
            now = datetime.now(timezone.utc)

            # Calculate days since last update
            age = (now - updated_dt).days
            return age
        except (ValueError, AttributeError):
            return None

    def is_task_stale(self, task, stale_threshold_days=7):
        """Check if a task is considered stale

        Args:
            task: Task dictionary
            stale_threshold_days: Number of days after which task is stale

        Returns:
            bool: True if task is stale, False otherwise
        """
        # Done tasks are not considered stale
        if task.get('done', False) or task.get('status') == 'done':
            return False

        age = self.get_task_age_days(task)
        if age is None:
            return False

        return age >= stale_threshold_days

    def transfer_old_tasks_to_backlog(self, age_threshold_days=30, backlog_category='backlog'):
        """Transfer tasks older than threshold to backlog category

        Args:
            age_threshold_days: Number of days after which task should be moved (default 30)
            backlog_category: Category to transfer old tasks to (default 'backlog')

        Returns:
            dict: Statistics about transferred tasks
        """
        from jot.categories.manager import CategoryManager

        transferred = []

        # Don't transfer if we're already in the backlog category
        if self.category == backlog_category:
            return {'transferred': 0, 'tasks': []}

        # Iterate through tasks and find old ones
        for task in self.tasks[:]:  # Use slice copy to avoid modification during iteration
            # Skip done tasks
            if task.get('done', False) or task.get('status') == 'done':
                continue

            age = self.get_task_age_days(task)
            if age is not None and age >= age_threshold_days:
                # Prepare task for transfer
                task_id = task['id']
                task_text = task['text']
                task_data = task.copy()

                # Create backlog category if it doesn't exist
                cat_manager = CategoryManager(project_dir=self.project_dir)

                # Transfer task to backlog
                backlog_tm = TaskManager(
                    directory=self.project_dir,
                    category=backlog_category,
                    project_registry=self.keyword_handler.project_registry,
                )

                # Add task to backlog with all metadata
                backlog_tm.add_task(
                    task_data['text'],
                    priority=task_data.get('priority', 'none'),
                    status=task_data.get('status', 'todo'),
                    labels=task_data.get('labels', []),
                    effort=task_data.get('effort', None),
                )

                # Get the newly created task and restore metadata
                new_task = backlog_tm.tasks[-1]
                new_task['notes'] = task_data.get('notes', '')
                new_task['agent_task'] = task_data.get('agent_task', False)
                new_task['keyword'] = task_data.get('keyword', None)
                new_task['day'] = task_data.get('day', None)
                new_task['tally'] = task_data.get('tally', 0)

                # Preserve creation time
                if 'created_at' in task_data:
                    new_task['created_at'] = task_data['created_at']

                backlog_tm._save_tasks()

                # Remove from current category
                self.tasks.remove(task)
                transferred.append({'id': task_id, 'text': task_text, 'age': age})

        # Save current category if tasks were removed
        if transferred:
            self._save_tasks()

        return {'transferred': len(transferred), 'tasks': transferred}

    def increment_tally(self):
        """Increment the tally counter for the current task"""
        for task in self.tasks:
            if task.get('current', False):
                # Initialize tally if not present (backward compatibility)
                if 'tally' not in task:
                    task['tally'] = 0
                task['tally'] += 1
                self._save_tasks()
                return task['tally']
        return None

    def set_next_current(self, filtered_tasks=None):
        """Set the next task as current

        Args:
            filtered_tasks: Optional list of tasks to navigate within.
                          If provided, navigation will only cycle through these tasks.
                          Useful for today filter or search results.
        """
        if not self.tasks:
            return False

        # Use filtered tasks if provided, otherwise use all tasks
        nav_tasks = filtered_tasks if filtered_tasks is not None else self.tasks
        if not nav_tasks:
            return False

        # Find current task's position in navigation list
        current_idx = -1
        current_task_id = None
        for task in self.tasks:
            if task.get('current', False):
                current_task_id = task['id']
                break

        # Find current task in navigation list
        if current_task_id:
            for i, task in enumerate(nav_tasks):
                if task['id'] == current_task_id:
                    current_idx = i
                    break

        # Clear all current flags
        for task in self.tasks:
            task['current'] = False

        # Set next task as current (wrap around within filtered list)
        if current_idx == -1:
            # No current task in filtered list, set first one
            nav_tasks[0]['current'] = True
        else:
            next_idx = (current_idx + 1) % len(nav_tasks)
            nav_tasks[next_idx]['current'] = True

        self._save_tasks()
        return True

    def set_prev_current(self, filtered_tasks=None):
        """Set the previous task as current

        Args:
            filtered_tasks: Optional list of tasks to navigate within.
                          If provided, navigation will only cycle through these tasks.
                          Useful for today filter or search results.
        """
        if not self.tasks:
            return False

        # Use filtered tasks if provided, otherwise use all tasks
        nav_tasks = filtered_tasks if filtered_tasks is not None else self.tasks
        if not nav_tasks:
            return False

        # Find current task's position in navigation list
        current_idx = -1
        current_task_id = None
        for task in self.tasks:
            if task.get('current', False):
                current_task_id = task['id']
                break

        # Find current task in navigation list
        if current_task_id:
            for i, task in enumerate(nav_tasks):
                if task['id'] == current_task_id:
                    current_idx = i
                    break

        # Clear all current flags
        for task in self.tasks:
            task['current'] = False

        # Set previous task as current (wrap around within filtered list)
        if current_idx == -1:
            # No current task in filtered list, set last one
            nav_tasks[-1]['current'] = True
        else:
            prev_idx = (current_idx - 1) % len(nav_tasks)
            nav_tasks[prev_idx]['current'] = True

        self._save_tasks()
        return True

    def refresh(self):
        """Reload tasks from file"""
        self._load_tasks()

