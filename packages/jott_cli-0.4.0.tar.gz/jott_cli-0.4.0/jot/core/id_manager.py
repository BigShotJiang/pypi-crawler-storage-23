"""Task ID management for jot"""

import json
from pathlib import Path

# Check filelock availability
try:
    from filelock import FileLock
    FILELOCK_AVAILABLE = True
except ImportError:
    FILELOCK_AVAILABLE = False
    FileLock = None


class IDManager:
    """Manages unique task IDs across all categories in a project"""

    def __init__(self, project_dir=None):
        """Initialize ID manager for a project directory"""
        self.project_dir = Path(project_dir) if project_dir else Path.cwd()
        self.ids_file = self.project_dir / '.jot.ids.json'
        self.lock_file = self.project_dir / '.jot.ids.json.lock'
        self.next_id = 1
        self.allocated = []
        self._load_ids()

    def _load_ids(self):
        """Load ID tracking from .jot.ids.json"""
        if self.ids_file.exists():
            try:
                if FILELOCK_AVAILABLE:
                    # Use file locking for concurrent access protection
                    with FileLock(str(self.lock_file), timeout=10):
                        with open(self.ids_file, 'r') as f:
                            data = json.load(f)
                            self.next_id = data.get('next_id', 1)
                            self.allocated = data.get('allocated', [])
                else:
                    # Fallback without locking if filelock not available
                    with open(self.ids_file, 'r') as f:
                        data = json.load(f)
                        self.next_id = data.get('next_id', 1)
                        self.allocated = data.get('allocated', [])
            except json.JSONDecodeError:
                self.next_id = 1
                self.allocated = []

    def _save_ids(self):
        """Save ID tracking to .jot.ids.json"""
        # Ensure parent directory exists
        self.ids_file.parent.mkdir(parents=True, exist_ok=True)

        if FILELOCK_AVAILABLE:
            # Use file locking for concurrent access protection
            with FileLock(str(self.lock_file), timeout=10):
                with open(self.ids_file, 'w') as f:
                    json.dump(
                        {'next_id': self.next_id, 'allocated': sorted(self.allocated)}, f, indent=2
                    )
        else:
            # Fallback without locking if filelock not available
            with open(self.ids_file, 'w') as f:
                json.dump(
                    {'next_id': self.next_id, 'allocated': sorted(self.allocated)}, f, indent=2
                )

    def allocate_id(self):
        """Allocate a new unique ID with atomic file locking"""
        if FILELOCK_AVAILABLE:
            # Use file locking to prevent race conditions
            with FileLock(str(self.lock_file), timeout=10):
                # Reload from disk to catch any concurrent changes
                self._load_ids_without_lock()

                # Allocate new ID
                new_id = self.next_id
                self.allocated.append(new_id)
                self.next_id += 1

                # Save atomically while holding lock
                self._save_ids_without_lock()
                return new_id
        else:
            # Fallback without locking (best effort)
            new_id = self.next_id
            self.allocated.append(new_id)
            self.next_id += 1
            self._save_ids()
            return new_id

    def _load_ids_without_lock(self):
        """Load ID tracking without acquiring lock (internal use only)"""
        if self.ids_file.exists():
            try:
                with open(self.ids_file, 'r') as f:
                    data = json.load(f)
                    self.next_id = data.get('next_id', 1)
                    self.allocated = data.get('allocated', [])
            except json.JSONDecodeError:
                self.next_id = 1
                self.allocated = []

    def _save_ids_without_lock(self):
        """Save ID tracking without acquiring lock (internal use only)"""
        # Ensure parent directory exists
        self.ids_file.parent.mkdir(parents=True, exist_ok=True)

        with open(self.ids_file, 'w') as f:
            json.dump({'next_id': self.next_id, 'allocated': sorted(self.allocated)}, f, indent=2)

    def release_id(self, task_id):
        """Release an ID (when task is deleted)"""
        if task_id in self.allocated:
            self.allocated.remove(task_id)
            self._save_ids()

    def migrate_from_existing_ids(self, existing_ids):
        """
        Migrate from existing task IDs found in category files.
        Sets next_id to max(existing_ids) + 1 and marks all as allocated.
        """
        if not existing_ids:
            return

        # Find maximum existing ID
        max_id = max(existing_ids)

        # Update next_id and allocated list
        self.next_id = max_id + 1
        self.allocated = sorted(set(existing_ids))
        self._save_ids()

    def get_stats(self):
        """Get ID allocation statistics"""
        return {
            'next_id': self.next_id,
            'allocated_count': len(self.allocated),
            'allocated_ids': self.allocated,
        }
