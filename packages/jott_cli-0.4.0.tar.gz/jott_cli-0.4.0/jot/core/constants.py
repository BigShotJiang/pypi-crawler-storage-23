"""Core constants for jot application"""

# Mode constants
MODE_QUICK_ADD = 'quick_add'
MODE_COMMAND = 'command'
MODE_MULTISELECT = 'multiselect'
MODE_FUZZY_SEARCH = 'fuzzy_search'
MODE_ALL_CATEGORIES = 'all_categories'

# Day of week colors
DAY_COLORS = {
    'Monday': '\033[91m',  # Red
    'Tuesday': '\033[38;5;208m',  # Orange
    'Wednesday': '\033[93m',  # Yellow
    'Thursday': '\033[92m',  # Green
    'Friday': '\033[94m',  # Blue
    'Saturday': '\033[95m',  # Magenta
    'Sunday': '\033[96m',  # Cyan
}

DAY_ABBREVIATIONS = {
    'Monday': 'Mon',
    'Tuesday': 'Tue',
    'Wednesday': 'Wed',
    'Thursday': 'Thu',
    'Friday': 'Fri',
    'Saturday': 'Sat',
    'Sunday': 'Sun',
}

# Optional dependency availability flags (set at import time in jot.py)
# These are initialized here but should be set by jot.py based on actual imports
FILELOCK_AVAILABLE = False
GCAL_AVAILABLE = False
TTS_AVAILABLE = False
