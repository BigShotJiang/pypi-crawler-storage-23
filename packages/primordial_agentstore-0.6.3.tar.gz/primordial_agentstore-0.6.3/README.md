# Primordial

CLI for the Primordial AgentStore — discover, install, and run AI agents.

## Install

```bash
pip install primordial-agentstore
```

## Usage

```bash
primordial --help
```
