pub mod aa;
pub mod aider;
pub mod arena;
pub mod livebench;
pub mod mock;
pub mod seal;
pub mod swebench;
pub mod swebench_r;
pub mod tbench;

use crate::cache::Cache;
use crate::config::Config;
use crate::models::{SourceResult, SourceTag};
use anyhow::Result;

pub trait Source {
    fn name(&self) -> &str;
    fn tags(&self) -> &'static [SourceTag];
    fn fetch(&self, config: &Config, cache: &Cache) -> Result<SourceResult>;
}

/// Returns all registered sources.
pub fn all_sources() -> Vec<Box<dyn Source>> {
    vec![
        Box::new(aa::ArtificialAnalysis),
        Box::new(arena::Arena),
        Box::new(swebench::SweBench),
        Box::new(aider::Aider),
        Box::new(livebench::LiveBench),
        Box::new(tbench::TerminalBench),
        Box::new(seal::Seal),
        Box::new(swebench_r::SweRebench),
    ]
}

/// Returns all sources including the mock (for testing/development).
pub fn all_sources_with_mock() -> Vec<Box<dyn Source>> {
    vec![Box::new(mock::MockSource)]
}
