"""
TikHub 小红书 API Python SDK

两个核心接口：
1. 获取笔记信息 V2 (蒲公英商家后台)
2. 搜索笔记

Usage:
    from tikhub_xiaohongshu import TikHubClient
    
    client = TikHubClient(api_key="your_api_key")
    
    # 获取笔记信息
    note = client.get_note_info(note_id="665f95200000000006005624")
    
    # 搜索笔记
    results = client.search_notes(keyword="美食推荐", page=1)
"""

import requests
from typing import Optional, Dict, Any, List
from dataclasses import dataclass


@dataclass
class TikHubResponse:
    """API 响应封装"""
    code: int
    message: str
    message_zh: str
    data: Optional[Dict[str, Any]] = None
    request_id: Optional[str] = None
    cache_url: Optional[str] = None
    
    @property
    def success(self) -> bool:
        return self.code == 200


class TikHubClient:
    """TikHub 小红书 API 客户端"""
    
    BASE_URL = "https://api.tikhub.io/api/v1"
    
    def __init__(self, api_key: str):
        """
        初始化客户端
        
        Args:
            api_key: TikHub API Key
        """
        self.api_key = api_key
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        })
    
    def _request(self, method: str, endpoint: str, params: Optional[Dict] = None) -> TikHubResponse:
        """发送 HTTP 请求"""
        url = f"{self.BASE_URL}{endpoint}"
        
        response = self.session.request(method, url, params=params)
        response.raise_for_status()
        
        result = response.json()
        return TikHubResponse(
            code=result.get("code", 0),
            message=result.get("message", ""),
            message_zh=result.get("message_zh", ""),
            data=result.get("data"),
            request_id=result.get("request_id"),
            cache_url=result.get("cache_url")
        )
    
    def get_note_info(
        self,
        note_id: Optional[str] = None,
        share_text: Optional[str] = None
    ) -> TikHubResponse:
        """
        获取笔记信息 V2 (蒲公英商家后台)
        
        能获取到笔记的曝光量（impNum）、阅读量（readNum）、关注量（followCnt）
        
        Args:
            note_id: 笔记 ID（从分享链接获取）
            share_text: 小红书分享链接（支持 APP 和 Web 端）
        
        Returns:
            TikHubResponse: 笔记详情数据
        
        Example:
            >>> client.get_note_info(note_id="665f95200000000006005624")
            >>> client.get_note_info(share_text="https://www.xiaohongshu.com/explore/xxx")
        
        Note:
            note_id 和 share_text 二选一，如都提供则以 note_id 为准
        """
        params = {}
        if note_id:
            params["note_id"] = note_id
        elif share_text:
            params["share_text"] = share_text
        else:
            raise ValueError("note_id 或 share_text 必须提供一个")
        
        return self._request("GET", "/xiaohongshu/app/get_note_info_v2", params)
    
    def search_notes(
        self,
        keyword: str,
        page: int = 1,
        sort_type: str = "general",
        note_type: str = "不限",
        time_filter: str = "不限",
        search_id: Optional[str] = None,
        search_session_id: Optional[str] = None,
        ai_mode: int = 0
    ) -> TikHubResponse:
        """
        搜索笔记
        
        Args:
            keyword: 搜索关键词（必需），如 "美食推荐"
            page: 页码，从 1 开始，默认 1
            sort_type: 排序方式
                - "general": 综合排序（默认）
                - "time_descending": 按时间倒序（最新）
                - "popularity_descending": 按点赞数排序
                - "comment_descending": 按评论数排序
                - "collect_descending": 按收藏数排序
                - "english_preferred": 英文优先
            note_type: 笔记类型筛选
                - "不限": 所有类型（默认）
                - "视频笔记": 仅视频
                - "普通笔记": 仅图文
                - "直播笔记": 仅直播
            time_filter: 发布时间筛选
                - "不限": 所有时间（默认）
                - "一天内": 24 小时内
                - "一周内": 7 天内
                - "半年内": 6 个月内
            search_id: 搜索 ID（翻页时使用，首次请求不需要）
            search_session_id: 搜索会话 ID（翻页时使用，首次请求不需要）
            ai_mode: AI 模式，0=关闭（默认），1=开启
        
        Returns:
            TikHubResponse: 搜索结果数据，包含笔记列表和分页信息
        
        Example:
            >>> # 首次搜索
            >>> result = client.search_notes(keyword="美食推荐", page=1)
            >>> notes = result.data["notes"]
            
            >>> # 翻页（使用首次返回的 search_id 和 search_session_id）
            >>> result2 = client.search_notes(
            ...     keyword="美食推荐",
            ...     page=2,
            ...     search_id=result.data["search_id"],
            ...     search_session_id=result.data["search_session_id"]
            ... )
        
        Note:
            翻页时必须传入首次搜索返回的 search_id 和 search_session_id
        """
        params = {
            "keyword": keyword,
            "page": page,
            "sort_type": sort_type,
            "note_type": note_type,
            "time_filter": time_filter,
            "ai_mode": ai_mode
        }
        
        if search_id:
            params["search_id"] = search_id
        if search_session_id:
            params["search_session_id"] = search_session_id
        
        return self._request("GET", "/xiaohongshu/app_v2/search_notes", params)
    
    def search_notes_all(
        self,
        keyword: str,
        max_pages: int = 10,
        **search_kwargs
    ) -> List[Dict[str, Any]]:
        """
        搜索笔记（自动翻页，获取全部结果）
        
        Args:
            keyword: 搜索关键词
            max_pages: 最大页数，默认 10
            **search_kwargs: 其他搜索参数（sort_type, note_type 等）
        
        Returns:
            List[Dict]: 所有笔记数据列表
        
        Example:
            >>> notes = client.search_notes_all("美食推荐", max_pages=5)
            >>> print(f"共获取 {len(notes)} 篇笔记")
        """
        all_notes = []
        search_id = None
        search_session_id = None
        
        for page in range(1, max_pages + 1):
            result = self.search_notes(
                keyword=keyword,
                page=page,
                search_id=search_id,
                search_session_id=search_session_id,
                **search_kwargs
            )
            
            if not result.success or not result.data:
                break
            
            notes = result.data.get("notes", [])
            all_notes.extend(notes)
            
            # 更新翻页参数
            search_id = result.data.get("search_id")
            search_session_id = result.data.get("search_session_id")
            
            # 没有更多数据时停止
            if not result.data.get("has_more"):
                break
        
        return all_notes


# 快捷使用示例
if __name__ == "__main__":
    import os
    
    # 从环境变量获取 API Key
    api_key = os.getenv("TIKHUB_API_KEY", "your_api_key_here")
    client = TikHubClient(api_key)
    
    # 示例 1: 获取笔记信息
    # note = client.get_note_info(note_id="665f95200000000006005624")
    # if note.success:
    #     print(f"标题：{note.data['title']}")
    #     print(f"点赞：{note.data['interact_info']['liked_count']}")
    
    # 示例 2: 搜索笔记
    # result = client.search_notes(keyword="美食推荐", page=1)
    # if result.success:
    #     for note in result.data["notes"]:
    #         print(f"- {note['title']}")
    
    # 示例 3: 搜索并自动翻页
    # notes = client.search_notes_all("美食推荐", max_pages=5)
    # print(f"共获取 {len(notes)} 篇笔记")
