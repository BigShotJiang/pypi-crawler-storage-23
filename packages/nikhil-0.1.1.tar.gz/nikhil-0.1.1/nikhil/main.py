import argparse
from .installer import install_zip


def main():
    parser = argparse.ArgumentParser(
        description="Install Nikhil Yadav resources."
    )

    parser.parse_args()

    install_zip()