"""
Nikhil Yadav Package
Provides installation utilities for bundled resources.
"""

from .installer import install_zip

__all__ = ["install_zip"]