from pathlib import Path
from importlib.resources import files
import shutil
import zipfile
import platform


def get_target_location():
    """
    Decide best accessible folder.
    Priority:
    1. Documents
    2. Desktop
    3. Downloads
    """

    home = Path.home()

    possible = [
        home / "Documents",
        home / "Desktop",
        home / "Downloads",
    ]

    for folder in possible:
        if folder.exists():
            return folder

    return home  # fallback


def install_zip():
    print("Installing Nikhil Yadav resources...")

    # Locate zip inside installed package
    zip_resource = files("nikhil").joinpath("data/java_bundle.zip")

    # Determine target location
    target_base = get_target_location()
    target_folder = target_base / "nikhil"
    target_folder.mkdir(exist_ok=True)

    # Copy ZIP
    copied_zip = target_folder / "java_setup.zip"
    shutil.copy(zip_resource, copied_zip)

    # Extract ZIP
    with zipfile.ZipFile(copied_zip, 'r') as zip_ref:
        zip_ref.extractall(target_folder)

    print(f"Files installed at: {target_folder}")
    print("Setup complete.")