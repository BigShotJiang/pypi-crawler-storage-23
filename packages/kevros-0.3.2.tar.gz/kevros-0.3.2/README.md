# kevros

[![Smithery](https://smithery.ai/badge/ndl-systems/kevros)](https://smithery.ai/servers/ndl-systems/kevros)

Python SDK for the **Kevros A2A Governance Gateway** — three cryptographic primitives for autonomous agents: precision decisioning, provenance attestation, and intent binding.

```
pip install kevros
```

## What This Does

Before your AI agent takes an action, ask Kevros: **"Is this within policy bounds?"**

After your agent acts, tell Kevros: **"Here's what I did."**

Every decision is HMAC-signed. Every action is hash-chained. Every intent is cryptographically bound to its command. Downstream services verify independently — no callbacks, no trust assumptions.

## Quick Start

```python
from kevros_governance import GovernanceClient

client = GovernanceClient(api_key="kvrs_...")

# 1. VERIFY before acting — get ALLOW, CLAMP, or DENY
result = client.verify(
    action_type="trade",
    action_payload={"symbol": "AAPL", "shares": 100, "price": 185.50},
    policy_context={"max_values": {"shares": 500, "price": 200.0}},
    agent_id="trading-bot-001",
)

if result.decision.value == "ALLOW":
    execute_trade(result.applied_action)

    # 2. ATTEST after acting — create provenance record
    attestation = client.attest(
        agent_id="trading-bot-001",
        action_description="Executed AAPL buy order",
        action_payload={"symbol": "AAPL", "shares": 100, "filled_price": 185.42},
    )
    print(f"Provenance hash: {attestation.hash_curr}")
```

## Intent Binding

Bind a declared intent to a specific command. Prove later that what happened is what was planned.

```python
from kevros_governance import GovernanceClient, IntentType

client = GovernanceClient(api_key="kvrs_...")

binding = client.bind(
    agent_id="nav-agent-001",
    intent_type=IntentType.NAVIGATION,
    intent_description="Navigate to waypoint Alpha",
    command_payload={"lat": 38.0293, "lon": -78.4767, "alt": 100},
    goal_state={"lat": 38.0293, "lon": -78.4767},
)

# Save binding.intent_id and binding.binding_id for verification
```

## Async Support

Every method has an async counterpart prefixed with `a`:

```python
async with GovernanceClient(api_key="kvrs_...") as client:
    result = await client.averify(
        action_type="trade",
        action_payload={"symbol": "AAPL", "shares": 50},
        agent_id="async-bot-001",
    )
```

## Pricing

- **Free tier:** 100 calls/month, instant signup, no payment required
- **Scout:** $29/mo — 5,000 calls
- **Sentinel:** $149/mo — 50,000 calls
- **Sovereign:** $499/mo — 500,000 calls

## Agent Card

The gateway publishes an [A2A Agent Card](https://governance.taskhawktech.com/.well-known/agent.json) for agent-to-agent discovery.

## MCP

For MCP-native agents, connect via streamable-http transport:

```
https://governance.taskhawktech.com/mcp/
```

## Links

- Gateway: https://governance.taskhawktech.com
- Agent Card: https://governance.taskhawktech.com/.well-known/agent.json
- Website: https://taskhawktech.com
