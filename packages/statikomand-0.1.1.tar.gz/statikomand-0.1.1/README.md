# Statikomand

Python static command parser, with command completion.

> Subclasses argparse, but without connection to CLI. Only string to python objects.

Parses a raw string list into a structured object, and proposes completion for options, flags, ...

## Getting Started

```bash
pip install statikomand
```

> **Basic Usage**

```python
from statikomand.komand_parser import KomandParser
# Example Usage
parser = KomandParser(prog="my-parser") # subclass of argparse.ArgumentParser

def pos1_completer(word, rank):
    return [f"pos1 completer : {word}-{rank}"]

def pos2_completer(word, rank):
    return [f"pos2 completer : {word}-{rank}"]

def opt1_completer(word, rank):
    return [f"opt1 completer : {word}-{rank}"]

def opt2_completer(word, rank):
    return [f"opt2 completer : {word}-{rank}"]

parser.add_argument("pos1", nargs=1, completer=pos1_completer) # give completer method, which is called when the parser is asked to complete the line

parser.add_argument("pos2", nargs=1, completer=pos2_completer)
parser.add_argument("--opt1", "-o1", nargs=2, completer=opt1_completer)
parser.add_argument("--opt2", "-o2", nargs=2, completer=opt2_completer)

arg_strings = shlex.split("argpos1 argpo")
print(parser.complete(arg_strings))  # ['pos2 completer : argpo-1']

arg_strings = shlex.split("argpos")
print(parser.complete(arg_strings))  # ['pos1 completer : argpos-1']

arg_strings = shlex.split("--")
print(
    parser.complete(arg_strings)
)  # ['--help', '--opt1', '--opt2'] - help flag is by default on all argparse.ArgumentParser

arg_strings = shlex.split("--op")
print(
    parser.complete(arg_strings)
)  # ['--opt1', '--opt2'] - help flag is by default on all argparse.ArgumentParser

arg_strings = shlex.split("argpos1 --opt1 argopt1 arg")
print(
    parser.complete(arg_strings)
)  # ['opt1 completer : arg-2'] - second argument of opt1 needs to be completed

arg_strings = shlex.split("argpos1 --opt1 argopt1 argopt2 arg")
print(
    parser.complete(arg_strings)
)  # ['pos2 completer : arg-1'] - completer of pos2

arg_strings = shlex.split("argpos1 --opt1 argopt1 argopt2 --o")
print(
    parser.complete(arg_strings)
)  # ['--opt2'] - completes flag name among the ones not already seen before
```

## Completion detail

When calling `add_argument` method of KomandParser, you can add a completer method, which is a function that take a string and an int as argument, and returns a list of strings (proposition of completions).

The 'complete' method of the parser tries to complete the flag names, and calls the `complete` method of positional and / or flag arguments; according to the position of the last caracter.
