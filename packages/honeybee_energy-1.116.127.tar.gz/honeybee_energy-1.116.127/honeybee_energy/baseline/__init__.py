"""Subpackage for creating baseline buildings and evaluating their simulation results.
"""
