"""
Kharma - The Over-Watch Network Monitor
"""
__version__ = "6.0.0"
