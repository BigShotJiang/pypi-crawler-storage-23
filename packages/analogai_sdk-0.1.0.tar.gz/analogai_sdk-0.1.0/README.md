# AnalogAI SDK (minimal)

This workspace contains a tiny Python helper for calling AnalogAI completion endpoints.

## Setup

1. Install dependencies with Poetry.
2. Set environment variables in `.env` (already created with placeholders):
   - `ANALOGAI_API_KEY`
   - `ANALOGAI_AGENT_ID`
   - `ANALOGAI_BASE_URL` (optional; defaults to `https://app.analogai.net:7777`)

## Install (Poetry)

```bash
poetry install
```

### Local install (editable)

```bash
poetry run pip install -e .
```

### Global install (Poetry)

```bash
poetry build
pip install dist/analogai_sdk-0.1.0-py3-none-any.whl
```

## PyPI name

Once published, the package will be available on PyPI as `analogai-sdk`.

## Usage

```python
from analogai_sdk import AnalogAIClient

client = AnalogAIClient()
print(client.generate_completion("your text here"))

for chunk in client.generate_streaming_completion("your text here"):
    print(chunk)
```
