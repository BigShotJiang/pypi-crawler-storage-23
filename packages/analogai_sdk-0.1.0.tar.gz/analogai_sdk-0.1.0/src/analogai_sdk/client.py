"""AnalogAI SDK helpers for completions and streaming."""

from __future__ import annotations

import os
from typing import Generator, Optional

import requests

DEFAULT_BASE_URL = "https://app.analogai.net:7777"


class AnalogAIClient:
    def __init__(
        self,
        api_key: Optional[str] = None,
        agent_id: Optional[str] = None,
        base_url: Optional[str] = None,
    ) -> None:
        self.api_key = api_key or os.getenv("ANALOGAI_API_KEY")
        self.agent_id = agent_id or os.getenv("ANALOGAI_AGENT_ID")
        self.base_url = (base_url or os.getenv("ANALOGAI_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")

        if not self.api_key:
            raise ValueError("Missing API key. Set ANALOGAI_API_KEY in environment or pass api_key.")
        if not self.agent_id:
            raise ValueError("Missing agent id. Set ANALOGAI_AGENT_ID in environment or pass agent_id.")

    def _headers(self) -> dict:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def generate_completion(self, message_text: str, auth_type: str = "system") -> str:
        url = f"{self.base_url}/agent_id/{self.agent_id}/generate-completion"
        response = requests.post(
            url,
            headers=self._headers(),
            json={"auth_type": auth_type, "message_text": message_text},
            timeout=60,
        )
        response.raise_for_status()
        data = response.json()
        return data.get("message_text", "")

    def generate_streaming_completion(
        self, message_text: str, auth_type: str = "system"
    ) -> Generator[str, None, None]:
        url = f"{self.base_url}/agent_id/{self.agent_id}/generate-streaming-completion"
        with requests.post(
            url,
            headers=self._headers(),
            json={"auth_type": auth_type, "message_text": message_text},
            stream=True,
            timeout=60,
        ) as response:
            response.raise_for_status()
            for line in response.iter_lines():
                if line:
                    yield line.decode("utf-8")


__all__ = ["AnalogAIClient"]
