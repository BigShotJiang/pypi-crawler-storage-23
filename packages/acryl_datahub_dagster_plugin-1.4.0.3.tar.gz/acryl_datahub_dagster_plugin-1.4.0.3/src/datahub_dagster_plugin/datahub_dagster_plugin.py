class DatahubDagsterPlugin:
    name = "datahub_dagster_plugin"
