from .translator import set_schema_prefix, get_schema_prefix

__all__ = ['set_schema_prefix', 'get_schema_prefix']
