.. automodapi:: peebee.optimize
   :no-inheritance-diagram:
