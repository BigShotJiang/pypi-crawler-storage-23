.. automodapi:: peebee.sampling
   :no-inheritance-diagram:
