.. automodapi:: peebee.noise
   :no-inheritance-diagram:
