.. automodapi:: peebee.convenience
   :no-inheritance-diagram:
