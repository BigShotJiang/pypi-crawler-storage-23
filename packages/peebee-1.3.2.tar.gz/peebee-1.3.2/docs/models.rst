.. automodapi:: peebee.models
   :no-inheritance-diagram:
