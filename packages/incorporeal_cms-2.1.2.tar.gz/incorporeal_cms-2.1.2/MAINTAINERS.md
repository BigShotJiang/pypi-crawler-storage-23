# Maintainers

This file contains information about people permitted to make major decisions and direction on the project.

* Brian S. Stephan (<bss@incorporeal.org>)

## Contributing Under the DCO

By adding your name and email address to this file, you certify that all of your subsequent contributions to
incorporeal-cms are made under the terms of the Developer's Certificate of Origin 1.1, available at
<https://developercertificate.org/> (and copied in `CONTRIBUTING.md`).
