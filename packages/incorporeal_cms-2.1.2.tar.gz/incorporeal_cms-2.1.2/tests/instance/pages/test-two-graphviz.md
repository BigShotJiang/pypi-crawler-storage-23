# test

test

~~~{ pydot:attack-plan }
digraph G {
    rankdir=LR
    Earth
    Mars
    Earth -> Mars
}
~~~

more test

~~~{ pydot:new-attack-plan }
digraph H {
    rankdir=LR
    Venus
    Mars
    Venus -> Mars
}
~~~

done
