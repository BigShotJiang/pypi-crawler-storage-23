# Network utilities shared across Arcade components.
