import csv
from enum import Enum


class Quoting(Enum):
    """
    Available quoting options for CSV mainly. Default is MINIMAL.
    """

    ALL = csv.QUOTE_ALL
    MINIMAL = csv.QUOTE_MINIMAL
    NONNUMERIC = csv.QUOTE_NONNUMERIC
    NONE = csv.QUOTE_NONE


QuotingCharacter = Enum(
    "QuotingCharacter",
    {
        '"': '"',
        "'": "'",
    },
)
QuotingCharacter.__doc__ = """
    Available quoting characters - default is ``\"``.
    | = Delimiter = | = Description = |
    | ``\"`` | Using the \" as separator. |
    | ``'`` | Using the ' as separator. |
"""

TableFormat = Enum(
    "TableFormat",
    {
        "List of lists": 0,
        "List of dicts": 1,
        "Dataframe": 2,
    },
)

TableFormat.__doc__ = """
    Available table formats. Mostly used as return type during reading/getting the table.
    | = Delimiter = | = Description = |
    | ``List of lists`` | Using the table format as list[list] |
    | ``List of dicts`` | Using the table format as list[dict] |
    | ``Dataframe``     | Using the table format as pandas.DataFrame |
"""


class FileType(Enum):
    """
    Available file types / extension for your input files.
    """

    CSV = "csv"
    Excel = "xlsx"
    Parquet = "parquet"


class FileSuffix(Enum):
    """
    Available file suffix for related file types.
    """

    TXT = "txt"
    CSV = "csv"
    TSV = "tsv"
    XLSX = "xlsx"
    XLS = "xls"
    Parquet = "parquet"


class FileEncoding(Enum):
    """
    Available file encodings for working with table files.

    see [Python Encoding Names|https://docs.python.org/3/library/codecs.html#standard-encodings]
    """

    ASCII = "ascii"
    BIG5 = "big5"
    BIG5HKSCS = "big5hkscs"
    CP037 = "cp037"
    CP273 = "cp273"
    CP424 = "cp424"
    CP437 = "cp437"
    CP500 = "cp500"
    CP720 = "cp720"
    CP737 = "cp737"
    CP775 = "cp775"
    CP850 = "cp850"
    CP852 = "cp852"
    CP855 = "cp855"
    CP856 = "cp856"
    CP857 = "cp857"
    CP858 = "cp858"
    CP860 = "cp860"
    CP861 = "cp861"
    CP862 = "cp862"
    CP863 = "cp863"
    CP864 = "cp864"
    CP865 = "cp865"
    CP866 = "cp866"
    CP869 = "cp869"
    CP874 = "cp874"
    CP875 = "cp875"
    CP932 = "cp932"
    CP949 = "cp949"
    CP950 = "cp950"
    CP1006 = "cp1006"
    CP1026 = "cp1026"
    CP1125 = "cp1125"
    CP1140 = "cp1140"
    CP1250 = "cp1250"
    CP1251 = "cp1251"
    CP1252 = "cp1252"
    CP1253 = "cp1253"
    CP1254 = "cp1254"
    CP1255 = "cp1255"
    CP1256 = "cp1256"
    CP1257 = "cp1257"
    CP1258 = "cp1258"
    EUC_JP = "euc_jp"
    EUC_JIS_2004 = "euc_jis_2004"
    EUC_JISX0213 = "euc_jisx0213"
    EUC_KR = "euc_kr"
    GB2312 = "gb2312"
    GBK = "gbk"
    GB18030 = "gb18030"
    HZ = "hz"
    ISO2022_JP = "iso2022_jp"
    ISO2022_JP_1 = "iso2022_jp_1"
    ISO2022_JP_2 = "iso2022_jp_2"
    ISO2022_JP_2004 = "iso2022_jp_2004"
    ISO2022_JP_3 = "iso2022_jp_3"
    ISO2022_JP_EXT = "iso2022_jp_ext"
    ISO2022_KR = "iso2022_kr"
    LATIN_1 = "latin_1"
    ISO8859_2 = "iso8859_2"
    ISO8859_3 = "iso8859_3"
    ISO8859_4 = "iso8859_4"
    ISO8859_5 = "iso8859_5"
    ISO8859_6 = "iso8859_6"
    ISO8859_7 = "iso8859_7"
    ISO8859_8 = "iso8859_8"
    ISO8859_9 = "iso8859_9"
    ISO8859_10 = "iso8859_10"
    ISO8859_11 = "iso8859_11"
    ISO8859_13 = "iso8859_13"
    ISO8859_14 = "iso8859_14"
    ISO8859_15 = "iso8859_15"
    ISO8859_16 = "iso8859_16"
    JOHAB = "johab"
    KOI8_R = "koi8_r"
    KOI8_T = "koi8_t"
    KOI8_U = "koi8_u"
    KZ1048 = "kz1048"
    MAC_CYRILLIC = "mac_cyrillic"
    MAC_GREEK = "mac_greek"
    MAC_ICELAND = "mac_iceland"
    MAC_LATIN2 = "mac_latin2"
    MAC_ROMAN = "mac_roman"
    MAC_TURKISH = "mac_turkish"
    PTCP154 = "ptcp154"
    SHIFT_JIS = "shift_jis"
    SHIFT_JIS_2004 = "shift_jis_2004"
    SHIFT_JISX0213 = "shift_jisx0213"
    UTF_32 = "utf_32"
    UTF_32_BE = "utf_32_be"
    UTF_32_LE = "utf_32_le"
    UTF_16 = "utf_16"
    UTF_16_BE = "utf_16_be"
    UTF_16_LE = "utf_16_le"
    UTF_7 = "utf_7"
    UTF_8 = "utf_8"
    UTF_8_SIG = "utf_8_sig"


class LineTerminator(Enum):
    """
    Available line terminators.
    """

    LF = "\n"
    CRLR = "\r\n"


Delimiter = Enum(
    "Delimiter",
    {
        ";": ";",
        ",": ",",
        "\t": "\t",
    },
)
Delimiter.__doc__ = """
    Available separators for splitting data columns in any table file - default is ``,``.
    | = Delimiter = | = Description = |
    | ``;`` | Using the semicolon as separator. |
    | ``,`` | Using the comma as separator. |
    | ``\\t`` | Using the ``tab`` character as separator. |
    | ... | In case of any missing separator, feel free to add it... |
"""

DecimalSeperator = Enum("DecimalSeperator", {".": ".", ",": ","})
DecimalSeperator.__doc__ = """
    Available decimal seperators.
"""
