"""
Factories and topology definitions for quantum circuits and coupling maps.

Circuit handles algorithm-based circuit creation.
Topology unifies coupling map creation with deterministic 2D layout generation
— each static method returns a TopologyResult containing both.
"""
import math
from collections.abc import Callable
from dataclasses import dataclass
from qiskit import QuantumCircuit
from qiskit.circuit.library import QFT, qaoa_ansatz
from qiskit.transpiler import CouplingMap

from .enums import AlgorithmType, TopologyType
from .config import CircuitGenerationConfig


@dataclass
class LayoutNode:
    id: int
    x: float
    y: float
    z: float = 0.0


@dataclass
class TopologyResult:
    coupling_map: CouplingMap
    layout: list[LayoutNode]


class Circuit:
    """Factory for creating quantum circuits based on AlgorithmType."""

    @classmethod
    def register(cls, algorithm_type: AlgorithmType, creator: Callable[[CircuitGenerationConfig], QuantumCircuit]):
        """Register a new circuit creator."""
        cls._creators[algorithm_type] = creator

    @classmethod
    def create(cls, config: CircuitGenerationConfig) -> QuantumCircuit:
        """Create a quantum circuit from configuration.""" 
        match config.algorithm:
            case AlgorithmType.QFT:
                return QFT(num_qubits=config.num_qubits, do_swaps=True, name=f"QFT-{config.num_qubits}")
            
            case AlgorithmType.GHZ:
                return cls._create_ghz(num_qubits=config.num_qubits)
            
            case AlgorithmType.QAOA:
                return cls._create_qaoa(config.num_qubits, config.algorithm_params["reps"])
            
            case AlgorithmType.CUSTOM_QASM:
                return QuantumCircuit.from_qasm_file(config.algorithm_params["qasm_path"])

            case _:
                raise ValueError(f"Algorithm {config.algorithm} not supported.")
    
    @classmethod
    def _create_ghz(cls, num_qubits: int) -> QuantumCircuit:
        circuit = QuantumCircuit(num_qubits, name=f"GHZ-{num_qubits}")
        circuit.h(0)
        for i in range(1, num_qubits):
            circuit.cx(0, i)
        return circuit

    @classmethod
    def _create_qaoa(cls, num_qubits: int, reps: int) -> QuantumCircuit:
        circuit = QuantumCircuit(num_qubits, name=f"QAOA-{num_qubits}-p{reps}")

        for _ in range(reps):
            # Problem layer (ZZ interactions)
            for i in range(num_qubits - 1):
                circuit.rzz(0.5, i, i + 1)

            # Mixer layer (X rotations)
            for i in range(num_qubits):
                circuit.rx(0.3, i)

        return circuit


def _layout_heavy_hex_nodes(coupling_map: CouplingMap, distance: int) -> list[LayoutNode]:
    N = len(coupling_map.graph)
    d = distance
    coords: dict[int, tuple[float, float]] = {}

    # 1. Data nodes: 0 to d*d - 1
    for r in range(d):
        for c in range(d):
            idx = r * d + c
            coords[idx] = (float(2 * c), float(2 * r))

    # 2. Vertical edge nodes
    v_start = d * d
    v_nodes_per_row = (d + 1) // 2
    for r in range(d - 1):
        for k in range(v_nodes_per_row):
            idx = v_start + r * v_nodes_per_row + k
            if r % 2 == 0:
                x = 0.0 if k == 0 else float(4 * k - 1)
            else:
                x = float(2 * d - 2) if k == v_nodes_per_row - 1 else float(4 * k + 1)
            coords[idx] = (x, float(2 * r + 1))

    # 3. Horizontal edge nodes
    h_start = v_start + (d - 1) * v_nodes_per_row
    for r in range(d):
        for c in range(d - 1):
            idx = h_start + r * (d - 1) + c
            coords[idx] = (float(2 * c + 1), float(2 * r))

    return [
        LayoutNode(id=i, x=coords.get(i, (0.0, 0.0))[0], y=coords.get(i, (0.0, 0.0))[1])
        for i in range(N)
    ]



# ---------------------------------------------------------------------------
# Unified Topology class
# ---------------------------------------------------------------------------

class Topology:
    """
    Unified topology: each static method returns a TopologyResult containing
    both the Qiskit CouplingMap and a deterministic 2D layout.
    """

    @staticmethod
    def line(physical_qubits: int, **_) -> TopologyResult:
        cm = CouplingMap.from_line(physical_qubits)
        layout = [LayoutNode(id=i, x=float(i), y=0.0) for i in range(physical_qubits)]
        return TopologyResult(coupling_map=cm, layout=layout)

    @staticmethod
    def ring(physical_qubits: int, **_) -> TopologyResult:
        cm = CouplingMap.from_ring(physical_qubits)
        r = physical_qubits / (2 * math.pi)
        layout = [
            LayoutNode(
                id=i,
                x=r * math.cos(2 * math.pi * i / physical_qubits),
                y=r * math.sin(2 * math.pi * i / physical_qubits),
            )
            for i in range(physical_qubits)
        ]
        return TopologyResult(coupling_map=cm, layout=layout)

    @staticmethod
    def grid(physical_qubits: int, **_) -> TopologyResult:
        n = math.ceil(math.sqrt(physical_qubits))
        cm = CouplingMap.from_grid(n, n)
        N = len(cm.graph)
        layout = [LayoutNode(id=i, x=float(i % n), y=float(i // n)) for i in range(N)]
        return TopologyResult(coupling_map=cm, layout=layout)

    @staticmethod
    def heavy_hex(physical_qubits: int, **kwargs) -> TopologyResult:
        distance = kwargs["distance"]
        cm = CouplingMap.from_heavy_hex(distance)
        layout = _layout_heavy_hex_nodes(cm, distance)
        return TopologyResult(coupling_map=cm, layout=layout)

    @staticmethod
    def full(physical_qubits: int, **_) -> TopologyResult:
        cm = CouplingMap.from_full(physical_qubits)
        r = physical_qubits / (2 * math.pi)
        layout = [
            LayoutNode(
                id=i,
                x=r * math.cos(2 * math.pi * i / physical_qubits),
                y=r * math.sin(2 * math.pi * i / physical_qubits),
            )
            for i in range(physical_qubits)
        ]
        return TopologyResult(coupling_map=cm, layout=layout)

    @classmethod
    def create(cls, topology: TopologyType, physical_qubits: int, **kwargs) -> TopologyResult:
        """Dispatch to the appropriate topology method by enum value."""
        method = getattr(cls, topology.value, None)
        if method is None:
            raise ValueError(f"Unsupported topology: {topology}")
        return method(physical_qubits, **kwargs)
