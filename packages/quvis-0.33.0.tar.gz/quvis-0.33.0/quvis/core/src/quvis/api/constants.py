"""
Authoritative parameter bounds and defaults for the Quvis playground.

These values are imported by FastAPI field validators and served to the
frontend via GET /api/constants. Change them here only.
"""

# Qubit counts (applies to both logical and physical qubits)
MIN_QUBITS = 2
MAX_QUBITS = 10000
DEFAULT_QUBITS = 100

# Heavy Hex topology distance parameter (must be odd, >= 3)
MIN_HEAVY_HEX_DISTANCE = 3
MAX_HEAVY_HEX_DISTANCE = 63
STEP_HEAVY_HEX_DISTANCE = 2
DEFAULT_HEAVY_HEX_DISTANCE = 7

# Grid topology row size (physical qubits = n * n)
MIN_GRID_SIZE = 2
MAX_GRID_SIZE = 100
DEFAULT_GRID_SIZE = 10

# Qiskit transpiler optimisation level
MIN_OPTIMIZATION_LEVEL = 0
MAX_OPTIMIZATION_LEVEL = 3
DEFAULT_OPTIMIZATION_LEVEL = 1

# QAOA algorithm repetitions (p-value)
MIN_QAOA_REPS = 1
MAX_QAOA_REPS = 10
DEFAULT_QAOA_REPS = 2
