from qiskit.transpiler import CouplingMap

heavy_hex = CouplingMap.from_heavy_hex(3)
print(len(heavy_hex.graph))