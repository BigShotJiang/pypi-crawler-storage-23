import * as THREE from 'three';
import { QubitGridController } from './objects/QubitGridController.js';
import { VISUALIZATION_DEFAULTS } from '../config/defaults.js';
import {
    ThreeSceneSetup,
    ThreeSceneComponents,
} from './interaction/modules/ThreeSceneSetup.js';
import {
    MouseInteractionHandler,
    TooltipData,
} from './interaction/modules/MouseInteractionHandler.js';
import { LayoutParameterManager } from './interaction/modules/LayoutParameterManager.js';
import { AppearanceParameterManager } from './interaction/modules/AppearanceParameterManager.js';
import { AnimationController } from './interaction/modules/AnimationController.js';
import { VisualizationStateManager } from './interaction/modules/VisualizationStateManager.js';
import { EventManager } from './interaction/modules/EventManager.js';

// Re-export TooltipData for backward compatibility
export type { TooltipData } from './interaction/modules/MouseInteractionHandler.js';

export class Playground {
    // Core components
    private threeSetup: ThreeSceneSetup;
    private mouseHandler: MouseInteractionHandler;
    private layoutManager: LayoutParameterManager;
    private appearanceManager: AppearanceParameterManager;
    private animationController: AnimationController;
    private visualizationStateManager: VisualizationStateManager;
    private eventManager: EventManager;
    public grid: QubitGridController;

    // Three.js components (from ThreeSceneSetup)
    private threeComponents: ThreeSceneComponents;

    // Instance properties
    public readonly instanceId: string;
    private containerElement: HTMLElement | null = null;

    constructor(
        container: HTMLElement | undefined,
        data: object,
        visualizationMode: 'compiled' | 'logical',
        onSlicesLoadedCallback?: (count: number, initialIndex: number) => void,
        onTooltipUpdate?: (data: TooltipData | null) => void,
        onModeSwitchedCallback?: (
            newSliceCount: number,
            newCurrentSliceIndex: number
        ) => void,
        onSettingsChangedCallback?: (settings: any) => void
    ) {
        this.containerElement = container || null;
        this.instanceId = `PlaygroundInstance_${Math.random().toString(36).substr(2, 9)}`;

        console.log(
            `Playground constructor called. Instance ID: ${this.instanceId}`
        );

        // Initialize modules
        this.threeSetup = new ThreeSceneSetup(this.containerElement);
        this.threeComponents = this.threeSetup.components;

        this.mouseHandler = new MouseInteractionHandler(
            this.containerElement,
            this.threeComponents.camera,
            this.threeComponents.scene,
            onTooltipUpdate
        );

        this.layoutManager = new LayoutParameterManager();
        this.appearanceManager = new AppearanceParameterManager();

        this.animationController = new AnimationController(
            this.threeComponents.scene,
            this.threeComponents.camera,
            this.threeComponents.renderer,
            this.threeComponents.controls
        );

        this.visualizationStateManager = new VisualizationStateManager(
            visualizationMode,
            VISUALIZATION_DEFAULTS.heatmap.maxSlices, // maxHeatmapSlices
            VISUALIZATION_DEFAULTS.fidelity.oneQubitBase,
            VISUALIZATION_DEFAULTS.fidelity.twoQubitBase,
            onModeSwitchedCallback,
            onSlicesLoadedCallback
        );

        this.eventManager = new EventManager(
            this.containerElement,
            this.threeComponents.camera,
            this.threeComponents.renderer
        );

        // Initialize event handlers
        this.mouseHandler.initialize(this.threeComponents.renderer.domElement);
        this.eventManager.initialize();

        // Create QubitGridController - pass the data or dataset name
        this.grid = new QubitGridController(
            this.threeComponents.scene,
            this.mouseHandler.getMouse(),
            this.threeComponents.camera,
            data,
            this.visualizationStateManager.getVisualizationMode(),
            this.visualizationStateManager.getMaxHeatmapSlices(),
            this.layoutManager.getRepelForce(),
            this.layoutManager.getIdealDistance(),
            this.layoutManager.getIterations(),
            this.layoutManager.getCoreDistance(),
            this.appearanceManager.getConnectionThickness(),
            this.appearanceManager.getInactiveAlpha(),
            this.appearanceManager.getQubitSize(),
            this.appearanceManager.areBlochSpheresVisible(),
            this.appearanceManager.areConnectionLinesVisible(),
            onSlicesLoadedCallback,
            () => this.threeSetup.isLightBackground(),
            this.threeComponents.smartAlignment,
            onSettingsChangedCallback
        );

        // Set up grid references in modules
        this.mouseHandler.setGrid(this.grid);
        this.animationController.setGrid(this.grid);
        this.eventManager.setGrid(this.grid);

        // Apply initial appearance settings
        this.grid.updateAppearanceParameters({
            qubitSize: this.appearanceManager.getQubitSize(),
        });
        this.grid.setBlochSpheresVisible(
            this.appearanceManager.areBlochSpheresVisible()
        );
        this.grid.setConnectionLinesVisible(
            this.appearanceManager.areConnectionLinesVisible()
        );

        // Set up heatmap aspect ratio
        if (this.grid.heatmap) {
            const renderWidth = this.containerElement
                ? this.containerElement.clientWidth
                : window.innerWidth;
            const renderHeight = this.containerElement
                ? this.containerElement.clientHeight
                : window.innerHeight;
            this.grid.heatmap.material.uniforms.aspect.value =
                renderWidth / renderHeight;
        }

        // Start animation
        this.animationController.start();
    }

    // Getters for accessing core components
    public get scene() {
        return this.threeComponents.scene;
    }
    public get camera() {
        return this.threeComponents.camera;
    }
    public get renderer() {
        return this.threeComponents.renderer;
    }
    public get controls() {
        return this.threeComponents.controls;
    }
    public get currentFPS() {
        return this.animationController.getCurrentFPS();
    }
    public get lastLayoutCalculationTime() {
        return this.grid.lastLayoutCalculationTime;
    }

    public isMultiCore(): boolean {
        return this.grid.isMultiCore();
    }

    // Animation methods
    public animate(): void {
        // Animation is already started in constructor, this is for compatibility
    }

    // Parameter getters for App compatibility
    public get currentQubitSize() {
        return this.appearanceManager.getQubitSize();
    }
    public get currentConnectionThickness() {
        return this.appearanceManager.getConnectionThickness();
    }
    public get currentInactiveAlpha() {
        return this.appearanceManager.getInactiveAlpha();
    }
    public get currentBaseSize() {
        return this.appearanceManager.getBaseSize();
    }
    public get currentRepelForce() {
        return this.layoutManager.getRepelForce();
    }
    public get currentIdealDistance() {
        return this.layoutManager.getIdealDistance();
    }
    public get currentIterations() {
        return this.layoutManager.getIterations();
    }
    public get currentOneQubitFidelityBase() {
        return this.visualizationStateManager.getOneQubitFidelityBase();
    }
    public get currentTwoQubitFidelityBase() {
        return this.visualizationStateManager.getTwoQubitFidelityBase();
    }
    public get currentCoreDistance() {
        return this.layoutManager.getCoreDistance();
    }

    // Visibility getters
    public get areBlochSpheresVisible() {
        return this.appearanceManager.areBlochSpheresVisible();
    }
    public get areConnectionLinesVisible() {
        return this.appearanceManager.areConnectionLinesVisible();
    }

    // Visualization state getters
    public get maxHeatmapSlices() {
        return this.visualizationStateManager.getMaxHeatmapSlices();
    }
    public get currentSlice() {
        return this.visualizationStateManager.getCurrentSlice();
    }

    // Layout methods
    public updateLayoutParameters(
        params: {
            repelForce?: number;
            idealDistance?: number;
            iterations?: number;
            attractForce?: number;
            coreDistance?: number;
            is3D?: boolean;
            distanceMaxMultiplier?: number;
        },
        onLayoutComplete?: () => void
    ) {
        const updatedParams = this.layoutManager.updateParameters(params);
        this.grid.updateLayoutParameters(updatedParams, onLayoutComplete);
    }

    public recompileLayout(onLayoutComplete?: () => void) {
        console.log('Recompiling layout with new parameters.');
        this.grid.updateLayoutParameters(
            this.layoutManager.getParameters(),
            () => {
                console.log('Layout recompile finished.');
                onLayoutComplete?.();
            }
        );
    }

    public updateIdealDistance(distance: number): void {
        this.layoutManager.setIdealDistance(distance);
        this.grid.updateIdealDistance(distance);
    }

    public updateCoreDistance(distance: number): void {
        this.layoutManager.setCoreDistance(distance);
        this.grid.updateLayoutParameters({ coreDistance: distance });
    }

    // Appearance methods
    public updateAppearanceParameters(params: {
        qubitSize?: number;
        connectionThickness?: number;
        inactiveAlpha?: number;
        baseSize?: number;
    }) {
        const updatedParams = this.appearanceManager.updateParameters(params);

        this.grid.updateAppearanceParameters({
            qubitSize: updatedParams.qubitSize,
            connectionThickness: updatedParams.connectionThickness,
            inactiveAlpha: updatedParams.inactiveAlpha,
        });

        if (params.baseSize !== undefined && this.grid.heatmap) {
            this.grid.heatmap.updateBaseSize(updatedParams.baseSize);
        }
    }

    public setBlochSpheresVisible(visible: boolean): void {
        this.appearanceManager.setBlochSpheresVisible(visible);
        this.grid.setBlochSpheresVisible(visible);
    }

    public setConnectionLinesVisible(visible: boolean): void {
        this.appearanceManager.setConnectionLinesVisible(visible);
        this.grid.setConnectionLinesVisible(visible);
    }

    // Visualization methods
    public updateHeatmapSlices(slices: number) {
        this.visualizationStateManager.setMaxHeatmapSlices(slices);
        this.grid.updateHeatmapSlices(slices);
    }

    public setLightBackground(lightMode: boolean) {
        this.threeSetup.setLightBackground(lightMode);

        // Update heatmap border color based on background mode
        this.grid.updateHeatmapLightBackground(lightMode);
        // Update connection colors based on background mode
        this.grid.updateConnectionColors();
    }


    public isLightBackground(): boolean {
        return this.threeSetup.isLightBackground();
    }

    public getKeyboardController() {
        return this.threeComponents.keyboardController;
    }

    public getSmartAlignment() {
        return this.threeComponents.smartAlignment;
    }

    public updateHeatmapColorParameters(params: {
        fadeThreshold?: number;
        greenThreshold?: number;
        yellowThreshold?: number;
        intensityPower?: number;
        minIntensity?: number;
        borderWidth?: number;
    }) {
        this.grid.updateHeatmapColorParameters(params);
    }

    public getHeatmapColorParameters(): {
        fadeThreshold: number;
        greenThreshold: number;
        yellowThreshold: number;
        intensityPower: number;
        minIntensity: number;
        borderWidth: number;
    } {
        return this.grid.getHeatmapColorParameters();
    }

    /**
     * Returns the current visualizer settings as an object, 
     * useful for copying to clipboard or saving state.
     */
    public getCurrentVisualizerSettings() {
        let layout, appearance;

        // Prefer live simulation parameters from the grid controller
        if (this.grid.simulationParameters) {
            const simParams = this.grid.simulationParameters;

            layout = {
                repel_force: simParams.layout.kRepel,
                ideal_distance: simParams.layout.idealDist,
                iterations: simParams.layout.iterations,
                attract_force: simParams.layout.kAttract,
                core_distance: simParams.layout.coreDistance,
            };

            appearance = {
                qubit_size: simParams.appearance.qubitScale,
                connection_thickness: simParams.appearance.connectionThickness,
                inactive_alpha: simParams.appearance.inactiveElementAlpha,
                render_bloch_spheres: this.appearanceManager.areBlochSpheresVisible(), // Visibility is managed by manager/UI state
                render_connection_lines: this.appearanceManager.areConnectionLinesVisible(),
            };
        } else {
            // Fallback to local managers if grid is not ready
            layout = {
                repel_force: this.layoutManager.getRepelForce(),
                ideal_distance: this.layoutManager.getIdealDistance(),
                iterations: this.layoutManager.getIterations(),
                attract_force: this.layoutManager.getAttractForce(),
                core_distance: this.layoutManager.getCoreDistance(),
            };

            appearance = {
                qubit_size: this.appearanceManager.getQubitSize(),
                connection_thickness: this.appearanceManager.getConnectionThickness(),
                inactive_alpha: this.appearanceManager.getInactiveAlpha(),
                render_bloch_spheres: this.appearanceManager.areBlochSpheresVisible(),
                render_connection_lines: this.appearanceManager.areConnectionLinesVisible(),
            };
        }

        // Heatmap
        const heatmapParams = this.getHeatmapColorParameters();
        const heatmap = {
            heatmap_max_slices: this.visualizationStateManager.getMaxHeatmapSlices(),
            heatmap_base_size: this.appearanceManager.getBaseSize(),
            heatmap_fade_threshold: heatmapParams.fadeThreshold,
            heatmap_green_threshold: heatmapParams.greenThreshold,
            heatmap_yellow_threshold: heatmapParams.yellowThreshold,
            heatmap_intensity_power: heatmapParams.intensityPower,
            heatmap_min_intensity: heatmapParams.minIntensity,
            heatmap_border_width: heatmapParams.borderWidth,
        };

        // Fidelity
        const fidelity = {
            one_qubit_fidelity_base: this.visualizationStateManager.getOneQubitFidelityBase(),
            two_qubit_fidelity_base: this.visualizationStateManager.getTwoQubitFidelityBase(),
        };

        return { ...layout, ...appearance, ...heatmap, ...fidelity };
    }

    public setCurrentSlice(sliceIndex: number) {
        this.visualizationStateManager.setCurrentSlice(sliceIndex);
        this.grid.setCurrentSlice(sliceIndex);
    }

    public switchToCircuit(circuitIndex: number): void {
        this.grid.switchToCircuit(circuitIndex);
        const newSliceCount = this.grid.getActiveSliceCount();
        const newCurrentSliceIndex = this.grid.getActiveCurrentSliceIndex();
        this.visualizationStateManager.notifyModeSwitched(
            newSliceCount,
            newCurrentSliceIndex
        );
        console.log(`Playground switched to circuit: ${circuitIndex}`);
    }

    public updateFidelityParameters(params: {
        oneQubitBase?: number;
        twoQubitBase?: number;
    }) {
        this.visualizationStateManager.updateFidelityParameters(params);
        this.mouseHandler.updateFidelityParameters(params);
    }

    // Camera methods
    public resetCamera(): void {
        if (this.controls) {
            this.controls.reset();
        }
    }

    // Utility methods
    public triggerLegendRefresh(): void {
        console.log(
            'Legend refresh triggered - handled internally by HeatmapManager'
        );
    }

    public dispose() {
        // Stop animation
        this.animationController.dispose();

        // Dispose modules
        this.mouseHandler.dispose();
        this.eventManager.dispose();
        this.threeSetup.dispose();

        // Dispose grid
        this.grid.dispose();

        // Dispose scene objects
        if (!this.threeComponents.scene) return;

        this.threeComponents.scene.traverse((object) => {
            if (!(object instanceof THREE.Mesh)) return;

            if (object.geometry) object.geometry.dispose();

            if (object.material) {
                if (Array.isArray(object.material)) {
                    object.material.forEach((material) => material.dispose());
                } else {
                    object.material.dispose();
                }
            }
        });
    }
}
