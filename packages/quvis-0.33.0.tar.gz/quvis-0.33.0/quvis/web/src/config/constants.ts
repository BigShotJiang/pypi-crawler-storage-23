// quvis/web/src/config/constants.ts
import { getConstantsUrl } from './api.js';

export interface ParameterBounds {
    min: number;
    max: number;
    default: number;
}

export interface ParameterBoundsWithStep extends ParameterBounds {
    step: number;
}

export interface AppConstants {
    qubits: ParameterBounds;
    heavy_hex_distance: ParameterBoundsWithStep;
    grid_size: ParameterBounds;
    optimization_level: ParameterBounds;
    qaoa_reps: ParameterBounds;
}

export async function fetchConstants(): Promise<AppConstants> {
    const response = await fetch(getConstantsUrl());
    if (!response.ok) {
        throw new Error(`Failed to fetch constants: HTTP ${response.status}`);
    }
    return response.json();
}
