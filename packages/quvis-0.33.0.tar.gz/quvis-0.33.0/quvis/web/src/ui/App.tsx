import React, { useRef, useEffect, useState } from 'react';
import { Playground, TooltipData } from '../scene/Playground.js';
import TimelineSlider from './components/TimelineSlider.js';
import AppearanceControls from './components/AppearanceControls.js';
import LayoutControls from './components/LayoutControls.js';
import FidelityControls from './components/FidelityControls.js';
import PlaygroundParameterSelection, {
    PlaygroundParams,
} from './components/PlaygroundParameterSelection.js';
import LoadingIndicator from './components/LoadingIndicator.js';
import CircuitTabSwitcher from './components/CircuitTabSwitcher.js';
import HeatmapControls from './components/HeatmapControls.js';
import Tooltip from './components/Tooltip.js';
import PlaybackControls from './components/PlaybackControls.js';
import DebugInfo from './components/DebugInfo.js';
import LightBackgroundToggle from './components/LightBackgroundToggle.js';
import KeyboardShortcutsHelp from './components/KeyboardShortcutsHelp.js';
import BackendConnectionError from './components/BackendConnectionError.js';
import { colors } from './theme/colors.js';
import { getCircuitGenerationUrl } from '../config/api.js';
import { fetchConstants, AppConstants } from '../config/constants.js';
import { VISUALIZATION_DEFAULTS } from "../config/defaults.js";

const BASE_TOP_MARGIN_PX = 20;
const INTER_PANEL_SPACING_PX = 20;
const COLLAPSED_PANEL_HEADER_HEIGHT_PX = 50;
const PANEL_BOTTOM_PADDING_PX = 15;
const CONTROL_GROUP_APPROX_HEIGHT_PX = 65;

const APPEARANCE_PANEL_SLIDER_COUNT = 4;
const APPEARANCE_PANEL_EXPANDED_CONTENT_HEIGHT =
    APPEARANCE_PANEL_SLIDER_COUNT * CONTROL_GROUP_APPROX_HEIGHT_PX;
const APPEARANCE_HEADER_ADJUSTMENT_PX = 20;
const APPEARANCE_PANEL_EXPANDED_HEIGHT_PX =
    COLLAPSED_PANEL_HEADER_HEIGHT_PX +
    APPEARANCE_PANEL_EXPANDED_CONTENT_HEIGHT +
    PANEL_BOTTOM_PADDING_PX +
    APPEARANCE_HEADER_ADJUSTMENT_PX;
const APPEARANCE_PANEL_COLLAPSED_HEIGHT_PX =
    COLLAPSED_PANEL_HEADER_HEIGHT_PX + PANEL_BOTTOM_PADDING_PX;

// Constants for FidelityControls panel
const FIDELITY_PANEL_SLIDER_COUNT = 2;
const FIDELITY_PANEL_EXPANDED_CONTENT_HEIGHT =
    FIDELITY_PANEL_SLIDER_COUNT * CONTROL_GROUP_APPROX_HEIGHT_PX;
const FIDELITY_HEADER_ADJUSTMENT_PX = 10;
const FIDELITY_PANEL_EXPANDED_HEIGHT_PX =
    COLLAPSED_PANEL_HEADER_HEIGHT_PX +
    FIDELITY_PANEL_EXPANDED_CONTENT_HEIGHT +
    PANEL_BOTTOM_PADDING_PX +
    FIDELITY_HEADER_ADJUSTMENT_PX;
const FIDELITY_PANEL_COLLAPSED_HEIGHT_PX =
    COLLAPSED_PANEL_HEADER_HEIGHT_PX + PANEL_BOTTOM_PADDING_PX;

// Constants for right-side components
const PLAYBACK_CONTROLS_EXPANDED_HEIGHT_PX = 143;  // Container padding (30px) + header (24px) + content (70px)
const PLAYBACK_CONTROLS_COLLAPSED_HEIGHT_PX = 54;  // Container padding (30px) + header (24px) only
const DEBUG_INFO_HEIGHT_PX = 80;
const LIGHT_TOGGLE_HEIGHT_PX = 48;
const BASE_BOTTOM_MARGIN_PX = 20;

const App: React.FC = () => {
    const mountRef = useRef<HTMLDivElement>(null);
    const playgroundRef = useRef<Playground | null>(null);

    const [isLoading, setIsLoading] = useState(false);
    const [loadingStage, setLoadingStage] = useState<string>('Loading');
    const [compilationProgress, setCompilationProgress] = useState<string[]>(
        []
    );
    const [currentParams, setCurrentParams] = useState<PlaygroundParams | null>(
        null
    );

    const [currentCircuitIndex, setCurrentCircuitIndex] = useState<number>(0);
    const [circuitInfo, setCircuitInfo] = useState<
        Array<{
            algorithm_name: string;
            circuit_type: 'logical' | 'compiled';
            circuit_stats: any;
        }>
    >([]);

    // State for timeline
    const [maxSliceIndex, setMaxSliceIndex] = useState<number>(0);
    const [actualSliceCount, setActualSliceCount] = useState<number>(0);
    const [currentSliceValue, setCurrentSliceValue] = useState<number>(0);
    const [isTimelineInitialized, setIsTimelineInitialized] =
        useState<boolean>(false);
    const [isPlaygroundInitialized, setIsPlaygroundInitialized] =
        useState<boolean>(false);

    // State for AppearanceControls initial values (matching Playground defaults)
    const [initialAppearance, setInitialAppearance] = useState<{
        qubitSize: number;
        connectionThickness: number;
        inactiveAlpha: number;
        renderBlochSpheres: boolean;
        renderConnectionLines: boolean;
    }>({
        qubitSize:            VISUALIZATION_DEFAULTS.appearance.qubitSize,
        connectionThickness:  VISUALIZATION_DEFAULTS.appearance.connectionThickness,
        inactiveAlpha:        VISUALIZATION_DEFAULTS.appearance.inactiveAlpha,
        renderBlochSpheres:   VISUALIZATION_DEFAULTS.appearance.renderBlochSpheres,
        renderConnectionLines: VISUALIZATION_DEFAULTS.appearance.renderConnectionLines,
    });

    // State for LayoutControls initial values (matching Playground defaults)
    const [initialLayout, setInitialLayout] = useState<{
        repelForce: number;
        idealDistance: number;
        iterations: number;
        attractForce: number;
        coreDistance: number;
        is3D: boolean;
        distanceMaxMultiplier: number;
    }>({
        repelForce:            VISUALIZATION_DEFAULTS.layout.repelForce,
        idealDistance:         VISUALIZATION_DEFAULTS.layout.idealDistance,
        iterations:            VISUALIZATION_DEFAULTS.layout.iterations,
        attractForce:          VISUALIZATION_DEFAULTS.layout.attractForce,
        coreDistance:          VISUALIZATION_DEFAULTS.layout.coreDistance,
        is3D:                  VISUALIZATION_DEFAULTS.layout.is3D,
        distanceMaxMultiplier: VISUALIZATION_DEFAULTS.layout.distanceMaxMultiplier,
    });

    // Hide LayoutControls when the backend provides a deterministic layout
    const [hasBackendLayout, setHasBackendLayout] = useState(false);

    // State for HeatmapControls initial values (matching Playground defaults)
    const [initialHeatmapSettings, setInitialHeatmapSettings] = useState<{
        maxSlices: number;
        baseSize: number;
        fadeThreshold: number;
        greenThreshold: number;
        yellowThreshold: number;
        intensityPower: number;
        minIntensity: number;
        borderWidth: number;
    }>({
        maxSlices:       VISUALIZATION_DEFAULTS.heatmap.maxSlices,
        baseSize:        VISUALIZATION_DEFAULTS.appearance.baseSize,
        fadeThreshold:   VISUALIZATION_DEFAULTS.heatmap.fadeThreshold,
        greenThreshold:  VISUALIZATION_DEFAULTS.heatmap.greenThreshold,
        yellowThreshold: VISUALIZATION_DEFAULTS.heatmap.yellowThreshold,
        intensityPower:  VISUALIZATION_DEFAULTS.heatmap.intensityPower,
        minIntensity:    VISUALIZATION_DEFAULTS.heatmap.minIntensity,
        borderWidth:     VISUALIZATION_DEFAULTS.heatmap.borderWidth,
    });

    // State for FidelityControls initial values
    const [initialFidelitySettings, setInitialFidelitySettings] = useState<{
        oneQubitBase: number;
        twoQubitBase: number;
    }>({
        oneQubitBase: VISUALIZATION_DEFAULTS.fidelity.oneQubitBase,
        twoQubitBase: VISUALIZATION_DEFAULTS.fidelity.twoQubitBase,
    });

    // State for Tooltip
    const [tooltipVisible, setTooltipVisible] = useState(false);
    const [tooltipContent, setTooltipContent] = useState('');
    const [tooltipX, setTooltipX] = useState(0);
    const [tooltipY, setTooltipY] = useState(0);

    // State for panel collapse
    const [isAppearanceCollapsed, setIsAppearanceCollapsed] = useState(false);
    const [isLayoutCollapsed, setIsLayoutCollapsed] = useState(false);
    const [isFidelityCollapsed, setIsFidelityCollapsed] = useState(false);
    const [isHeatmapCollapsed, setIsHeatmapCollapsed] = useState(false);
    const [isTimelineCollapsed, setIsTimelineCollapsed] = useState(false);
    const [isPlaybackCollapsed, setIsPlaybackCollapsed] = useState(false);
    const [isCircuitTabsCollapsed, setIsCircuitTabsCollapsed] = useState(false);
    const [isKeyboardShortcutsVisible, setIsKeyboardShortcutsVisible] = useState(false);

    // State for playback
    const [isPlaying, setIsPlaying] = useState(false);
    const [playbackSpeed, setPlaybackSpeed] = useState(0.01); // 10ms per slice

    // State for Debug Info
    const [fps, setFps] = useState(0);
    const [layoutTime, setLayoutTime] = useState(0);

    // State for UI visibility
    const [isUiVisible, setIsUiVisible] = useState(true);

    // State for light background mode
    const [lightMode, setLightMode] = useState(false);

    // State for Playground data (for library mode)
    const [playgroundData, setPlaygroundData] = useState<any>(null);

    // State for backend connection error
    const [showBackendError, setShowBackendError] = useState(false);

    // State for backend-provided constants (bounds + defaults)
    const [appConstants, setAppConstants] = useState<AppConstants | null>(null);

    // Check backend connection on startup
    useEffect(() => {
        const checkBackendConnection = async () => {
            try {
                const apiUrl = getCircuitGenerationUrl();
                // Only check if using external API (not Vite middleware)
                if (apiUrl && apiUrl.startsWith('http')) {
                    const healthUrl = apiUrl.replace('/api/generate-circuit', '/api/health');
                    const response = await fetch(healthUrl, {
                        method: 'GET',
                        signal: AbortSignal.timeout(5000)
                    });
                    if (!response.ok) {
                        setShowBackendError(true);
                    }
                }
            } catch (error) {
                // Backend not available
                const apiUrl = getCircuitGenerationUrl();
                if (apiUrl && apiUrl.startsWith('http')) {
                    setShowBackendError(true);
                }
            }
        };

        checkBackendConnection();
    }, []);

    useEffect(() => {
        fetchConstants()
            .then(setAppConstants)
            .catch(() => setShowBackendError(true));
    }, []);

    // Check for library mode on app initialization
    useEffect(() => {
        // Check if we're in library mode via environment variables
        const isLibraryModeFromEnv =
            (import.meta as any).env.VITE_LIBRARY_MODE === 'true';
        const libraryDataFile =
            (import.meta as any).env.VITE_LIBRARY_DATA_FILE ||
            'temp_circuit_data.json';

        if (isLibraryModeFromEnv) {
            console.log('🚀 Library mode activated');

            // Immediately set library mode
            // setIsLibraryMode(true); // This was causing an error, removed

            // Load the data with retry mechanism
            const loadLibraryData = async () => {
                const maxRetries = 15; // Increased retries for better reliability
                let retryCount = 0;

                const attemptLoad = async (): Promise<void> => {
                    try {
                        const dataResponse = await fetch(
                            `/${libraryDataFile}?t=${Date.now()}`
                        );
                        if (dataResponse.ok) {
                            const data = await dataResponse.json();
                            console.log('✅ Circuit data loaded successfully');

                            // All data should be in library_multi format
                            setCurrentCircuitIndex(0);
                            setCircuitInfo(
                                data.circuits.map((circuit: any) => ({
                                    algorithm_name: circuit.algorithm_name,
                                    circuit_type: circuit.circuit_type,
                                    circuit_stats: circuit.circuit_stats,
                                }))
                            );
                            console.log(
                                `🔄 Loaded ${data.circuits.length} circuits`
                            );

                            setPlaygroundData(data);
                            return;
                        } else {
                            throw new Error(
                                `HTTP ${dataResponse.status}: ${dataResponse.statusText}`
                            );
                        }
                    } catch (error) {
                        retryCount++;

                        // Different handling for different error types
                        let errorMessage = 'Unknown error';
                        let isNetworkError = false;

                        if (
                            error instanceof TypeError &&
                            error.message.includes('NetworkError')
                        ) {
                            errorMessage = 'Development server not ready yet';
                            isNetworkError = true;
                        } else if (
                            error instanceof TypeError &&
                            error.message.includes('fetch')
                        ) {
                            errorMessage = 'Server not responding';
                            isNetworkError = true;
                        } else if (error instanceof Error) {
                            errorMessage = error.message;
                        }

                        if (retryCount >= maxRetries) {
                            console.error(
                                `❌ Failed to load circuit data after ${maxRetries} attempts`
                            );
                            console.error(`💡 Last error: ${errorMessage}`);
                            return;
                        }

                        // Progressive delay: start faster for network errors, slower for others
                        const baseDelay = isNetworkError ? 500 : 1000;
                        const delay = Math.min(
                            baseDelay * Math.pow(1.5, retryCount - 1),
                            5000
                        );

                        if (retryCount <= 3) {
                            console.log(
                                `⏳ Waiting for server... (${retryCount}/${maxRetries})`
                            );
                        }

                        await new Promise((resolve) =>
                            setTimeout(resolve, delay)
                        );
                        return attemptLoad();
                    }
                };

                await attemptLoad();
            };

            loadLibraryData();
        }
    }, []);

    const toggleAppearanceCollapse = () => {
        setIsAppearanceCollapsed(!isAppearanceCollapsed);
        setTooltipVisible(false);
    };

    const toggleLayoutCollapse = () => {
        setIsLayoutCollapsed(!isLayoutCollapsed);
    };

    const toggleFidelityCollapse = () => {
        setIsFidelityCollapsed(!isFidelityCollapsed);
    };

    const toggleHeatmapCollapse = () => {
        setIsHeatmapCollapsed(!isHeatmapCollapsed);
    };

    const toggleTimelineCollapse = () => {
        setIsTimelineCollapsed(!isTimelineCollapsed);
    };

    const togglePlaybackCollapse = () => {
        setIsPlaybackCollapsed(!isPlaybackCollapsed);
    };

    const toggleCircuitTabsCollapse = () => {
        setIsCircuitTabsCollapsed(!isCircuitTabsCollapsed);
    };

    const toggleKeyboardShortcuts = () => {
        setIsKeyboardShortcutsVisible(!isKeyboardShortcutsVisible);
    };

    const collapseAllPanels = () => {
        setIsAppearanceCollapsed(true);
        setIsLayoutCollapsed(true);
        setIsFidelityCollapsed(true);
        setIsHeatmapCollapsed(true);
        setIsTimelineCollapsed(true);
        setIsPlaybackCollapsed(true);
        setIsCircuitTabsCollapsed(true);
    };

    const expandAllPanels = () => {
        setIsAppearanceCollapsed(false);
        setIsLayoutCollapsed(false);
        setIsFidelityCollapsed(false);
        setIsHeatmapCollapsed(false);
        setIsTimelineCollapsed(false);
        setIsPlaybackCollapsed(false);
        setIsCircuitTabsCollapsed(false);
    };

    const handleRenderBlochSpheresChange = (checked: boolean) => {
        playgroundRef.current?.setBlochSpheresVisible(checked);
    };

    const handleRenderConnectionLinesChange = (checked: boolean) => {
        playgroundRef.current?.setConnectionLinesVisible(checked);
    };

    // Callback for when QubitGrid has loaded slice data
    const handleSlicesLoaded = (
        sliceCount: number,
        initialSliceIndex: number
    ) => {
        setActualSliceCount(sliceCount); // Store the raw slice count
        setMaxSliceIndex(sliceCount > 0 ? sliceCount - 1 : 0); // Max index for slider
        setCurrentSliceValue(initialSliceIndex);
        setIsTimelineInitialized(true);
        setIsLoading(false);
    };

    // Callback for when visualization mode has switched and slice parameters might have changed
    const handleModeSwitched = (
        newSliceCount: number,
        newCurrentSliceIndex: number
    ) => {
        setActualSliceCount(newSliceCount);
        setMaxSliceIndex(newSliceCount > 0 ? newSliceCount - 1 : 0);
        setCurrentSliceValue(newCurrentSliceIndex);
        // Ensure timeline is marked as initialized if there are slices, otherwise not.
        // This handles cases where a mode might have 0 slices.
        setIsTimelineInitialized(newSliceCount > 0);
    };

    const handleTooltipUpdate = (data: any | null) => {
        if (!data) {
            setTooltipVisible(false);
            return;
        }

        // Helper function for pluralization
        const pluralize = (count: number, singular: string) => {
            return count === 1 ? singular : `${singular}s`;
        };

        let content = `Qubit ${data.id}\n`;
        const isQubitGateData =
            data.oneQubitGatesInWindow !== undefined &&
            data.twoQubitGatesInWindow !== undefined &&
            data.sliceWindowForGateCount !== undefined;
        if (isQubitGateData) {
            const oneQubitGateLabel = pluralize(
                data.oneQubitGatesInWindow,
                '1-Qubit Gate'
            );
            const twoQubitGateLabel = pluralize(
                data.twoQubitGatesInWindow,
                '2-Qubit Gate'
            );

            content += `${oneQubitGateLabel}: ${data.oneQubitGatesInWindow}\n`;
            content += `${twoQubitGateLabel}: ${data.twoQubitGatesInWindow}`;

            if (data.fidelity !== undefined) {
                content += `\nFidelity: ${data.fidelity.toFixed(4)}`;
            }
        } else if (data.stateName) {
            content += `|${data.stateName}⟩`;
        }

        setTooltipContent(content);
        setTooltipX(data.x);
        setTooltipY(data.y);
        setTooltipVisible(true);
    };

    const handleParameterGeneration = async (params: PlaygroundParams) => {
        setIsLoading(true);
        setCurrentParams(params);
        setLoadingStage('Preparing');
        setCompilationProgress([]);

        // Reset playground and timeline related states
        if (playgroundRef.current) {
            playgroundRef.current.dispose();
            playgroundRef.current = null;
        }
        setIsPlaygroundInitialized(false);
        setIsTimelineInitialized(false);
        setMaxSliceIndex(0);
        setActualSliceCount(0);
        setCurrentSliceValue(0);
        setPlaygroundData(null); // Reset playground data

        try {
            setLoadingStage('Compiling Circuit');
            setCompilationProgress(['Initializing circuit generation...']);

            // Call the circuit generation API
            const requestBody: any = {
                algorithm: params.algorithm,
                num_qubits: params.numQubits,
                physical_qubits: params.physicalQubits,
                topology: params.topology,
                optimization_level: params.optimizationLevel,
                qasm: params.qasm,
                ...(params.customParams || {}),
            };

            if (params.heavyHexDistance !== undefined) {
                requestBody.heavy_hex_distance = params.heavyHexDistance;
            }

            const response = await fetch(getCircuitGenerationUrl(), {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(requestBody),
            });

            if (!response.ok) {
                throw new Error(
                    `HTTP ${response.status}: ${response.statusText}`
                );
            }

            const result = await response.json();

            if (!result.generation_successful) {
                throw new Error(result.error || 'Circuit generation failed');
            }

            setHasBackendLayout(
                !!(result.circuits?.[0]?.device_info?.layout_nodes?.length)
            );

            // Add compilation progress info - playground always generates multi-circuit format
            const logicalCircuit = result.circuits.find(
                (c: any) => c.circuit_type === 'logical'
            );
            const compiledCircuit = result.circuits.find(
                (c: any) => c.circuit_type === 'compiled'
            );

            const progress = [
                'Circuit generation completed',
                `Generated ${logicalCircuit?.circuit_stats?.original_gates || 0} logical gates`,
                `Transpiled to ${compiledCircuit?.circuit_stats?.transpiled_gates || 0} physical gates`,
                `Added ${compiledCircuit?.circuit_stats?.swap_count || 0} SWAP gates for routing`,
                `Routing overhead: ${compiledCircuit?.routing_analysis?.routing_overhead_percentage?.toFixed(1) || 0}%`,
            ];

            setCompilationProgress(progress);

            // Small delay to show the compilation results
            await new Promise((resolve) => setTimeout(resolve, 1000));

            setLoadingStage('Rendering Visualization');
            setCompilationProgress([
                ...progress,
                'Initializing 3D renderer...',
            ]);

            // Playground always generates multi-circuit data (logical + compiled)
            setCurrentCircuitIndex(0);
            setCircuitInfo(
                result.circuits.map((circuit: any) => ({
                    algorithm_name: circuit.algorithm_name,
                    circuit_type: circuit.circuit_type,
                    circuit_stats: circuit.circuit_stats,
                }))
            );
            console.log(
                `🔄 Playground generated ${result.circuits.length} circuits`
            );

            // Set the playground data - this will trigger the useEffect to create the Playground
            setPlaygroundData(result);
        } catch (error) {
            console.error('❌ Circuit generation failed:', error);
            setIsLoading(false);
            setLoadingStage('Loading');
            setCompilationProgress([]);
            setCurrentParams(null);

            // Check if it's a network error (backend not available)
            if (error instanceof TypeError && error.message.includes('fetch')) {
                setShowBackendError(true);
            }
        }
    };

    useEffect(() => {
        const handleKeyDown = (event: KeyboardEvent) => {
            if (event.key === '0' && playgroundRef.current) {
                playgroundRef.current.resetCamera();
            } else if (event.key.toLowerCase() === 'c') {
                collapseAllPanels();
            } else if (event.key.toLowerCase() === 'e') {
                expandAllPanels();
            } else if (
                event.code === 'Space' &&
                isPlaygroundInitialized &&
                actualSliceCount > 0
            ) {
                event.preventDefault();
                handlePlayPause();
            }
        };

        window.addEventListener('keydown', handleKeyDown);
        return () => {
            window.removeEventListener('keydown', handleKeyDown);
        };
    }, [isPlaygroundInitialized, actualSliceCount]);

    // Separate effect for 'n' key to copy settings, depending on all settings state
    useEffect(() => {
        const handleCopySettings = (event: KeyboardEvent) => {
            if (event.key === 'n') {
                console.log('📋 Generating settings code...');

                if (!playgroundRef.current) {
                    console.warn('Playground not initialized, cannot copy settings.');
                    return;
                }

                const settings = playgroundRef.current.getCurrentVisualizerSettings();

                const settingsCode = `VisualizerSettings(
    # Layout
    repel_force=${settings.repel_force},
    ideal_distance=${settings.ideal_distance},
    iterations=${settings.iterations},
    attract_force=${settings.attract_force ?? 0.1},
    core_distance=${settings.core_distance},
    is_3d=${settings.is_3d ? 'True' : 'False'},
    distance_max_multiplier=${settings.distance_max_multiplier},
    
    # Appearance
    qubit_size=${settings.qubit_size},
    connection_thickness=${settings.connection_thickness},
    inactive_alpha=${settings.inactive_alpha},
    render_bloch_spheres=${settings.render_bloch_spheres ? 'True' : 'False'},
    render_connection_lines=${settings.render_connection_lines ? 'True' : 'False'},
    
    # Heatmap
    heatmap_max_slices=${settings.heatmap_max_slices},
    heatmap_base_size=${settings.heatmap_base_size},
    heatmap_fade_threshold=${settings.heatmap_fade_threshold},
    heatmap_green_threshold=${settings.heatmap_green_threshold},
    heatmap_yellow_threshold=${settings.heatmap_yellow_threshold},
    heatmap_intensity_power=${settings.heatmap_intensity_power},
    heatmap_min_intensity=${settings.heatmap_min_intensity},
    heatmap_border_width=${settings.heatmap_border_width},
    
    # Fidelity
    one_qubit_fidelity_base=${settings.one_qubit_fidelity_base},
    two_qubit_fidelity_base=${settings.two_qubit_fidelity_base}
)`;
                navigator.clipboard.writeText(settingsCode).then(() => {
                    console.log('✅ Settings copied to clipboard!');
                    setTooltipContent('Settings copied to clipboard!');
                    setTooltipVisible(true);
                    setTooltipX(window.innerWidth / 2);
                    setTooltipY(window.innerHeight - 50);
                    setTimeout(() => setTooltipVisible(false), 2000);
                }).catch(err => {
                    console.error('Failed to copy settings:', err);
                });
            }
        };

        window.addEventListener('keydown', handleCopySettings);
        return () => window.removeEventListener('keydown', handleCopySettings);
    }, []); // No dependencies needed as we read from ref

    useEffect(() => {
        if (!isPlaying || !isPlaygroundInitialized) {
            return;
        }

        if (currentSliceValue >= maxSliceIndex) {
            setIsPlaying(false); // Stop at the end
            return;
        }

        const timerId = setTimeout(() => {
            // Directly increment slice value
            const nextSlice = currentSliceValue + 1;
            if (nextSlice <= maxSliceIndex) {
                setCurrentSliceValue(nextSlice);
                if (playgroundRef.current) {
                    playgroundRef.current.setCurrentSlice(nextSlice);
                }
            }
        }, playbackSpeed * 1000);

        return () => clearTimeout(timerId);
    }, [
        isPlaying,
        currentSliceValue,
        maxSliceIndex,
        playbackSpeed,
        isPlaygroundInitialized,
    ]);

    useEffect(() => {
        if (!mountRef.current) {
            return;
        }

        if (!playgroundData) {
            return;
        }

        if (playgroundRef.current) {
            return;
        }

        const handleSettingsChanged = (settings: any) => {
            console.log('🔄 UI received settings update from Playground:', settings);

            // Update initial states which controls read from
            if (settings) {
                // Update Appearance
                setInitialAppearance(prev => ({
                    ...prev,
                    qubitSize: settings.qubit_size ?? prev.qubitSize,
                    connectionThickness: settings.connection_thickness ?? prev.connectionThickness,
                    inactiveAlpha: settings.inactive_alpha ?? prev.inactiveAlpha,
                    renderBlochSpheres: settings.render_bloch_spheres ?? prev.renderBlochSpheres,
                    renderConnectionLines: settings.render_connection_lines ?? prev.renderConnectionLines,
                }));

                // Update Layout
                setInitialLayout(prev => ({
                    ...prev,
                    repelForce: settings.repel_force ?? prev.repelForce,
                    idealDistance: settings.ideal_distance ?? prev.idealDistance,
                    iterations: settings.iterations ?? prev.iterations,
                    attractForce: settings.layout?.attract_force ?? prev.attractForce,
                    coreDistance: settings.layout?.core_distance ?? prev.coreDistance,
                    is3D: settings.layout?.is_3d ?? prev.is3D,
                    distanceMaxMultiplier: settings.layout?.distance_max_multiplier ?? prev.distanceMaxMultiplier,
                }));

                // Update Heatmap
                setInitialHeatmapSettings(prev => ({
                    ...prev,
                    maxSlices: settings.heatmap_max_slices ?? prev.maxSlices,
                    // baseSize: settings.heatmap_base_size ?? prev.baseSize, // Not dynamic in UI yet?
                    fadeThreshold: settings.heatmap_fade_threshold ?? prev.fadeThreshold,
                    greenThreshold: settings.heatmap_green_threshold ?? prev.greenThreshold,
                    yellowThreshold: settings.heatmap_yellow_threshold ?? prev.yellowThreshold,
                    intensityPower: settings.heatmap_intensity_power ?? prev.intensityPower,
                    minIntensity: settings.heatmap_min_intensity ?? prev.minIntensity,
                    borderWidth: settings.heatmap_border_width ?? prev.borderWidth,
                }));
            }
        };

        const playgroundInstance = new Playground(
            mountRef.current,
            playgroundData,
            'compiled',
            handleSlicesLoaded,
            handleTooltipUpdate,
            handleModeSwitched,
            handleSettingsChanged
        );
        playgroundRef.current = playgroundInstance;
        setIsPlaygroundInitialized(true);
        playgroundInstance.animate();

        // Ensure starting on the correct circuit BEFORE applying settings
        const initialCircuitIndex = playgroundData.circuits && playgroundData.circuits.length > 1 ? 1 : 0;

        if (playgroundData.circuits && initialCircuitIndex > 0) {
            playgroundInstance.switchToCircuit(initialCircuitIndex);
            setCurrentCircuitIndex(initialCircuitIndex);
        }

        const completeLoading = () => {
            if (isLoading) {
                setCompilationProgress((prev) => [
                    ...prev,
                    '3D visualization loaded',
                    'Ready for interaction',
                ]);
                setTimeout(() => {
                    setIsLoading(false);
                    setLoadingStage('Loading');
                    setCompilationProgress([]);
                    setCurrentParams(null);
                }, 500); // Small delay to show completion
            }
        };

        // We look for visualizer_settings attached to the current circuit initially
        // Default to the compiled circuit (index 1) if available, otherwise 0
        const initialCircuit = playgroundData.circuits && playgroundData.circuits.length > 1
            ? playgroundData.circuits[1]
            : (playgroundData.circuits ? playgroundData.circuits[0] : playgroundData);

        const settings = initialCircuit.visualizer_settings;

        if (settings) {
            console.log("⚙️ Applying settings from circuit data:", settings);

            // Apply appearance settings
            setInitialAppearance({
                qubitSize: settings.appearance?.qubit_size ?? 1.0,
                connectionThickness: settings.appearance?.connection_thickness ?? 0.05,
                inactiveAlpha: settings.appearance?.inactive_alpha ?? 0.1,
                renderBlochSpheres: settings.appearance?.render_bloch_spheres ?? false,
                renderConnectionLines: settings.appearance?.render_connection_lines ?? true,
            });

            // Apply layout settings
            setInitialLayout({
                repelForce: settings.layout?.repel_force ?? 0.6,
                idealDistance: settings.layout?.ideal_distance ?? 1.0,
                iterations: settings.layout?.iterations ?? 500,
                attractForce: settings.layout?.attract_force ?? 0.1,
                coreDistance: settings.layout?.core_distance ?? 5.0,
                is3D: settings.layout?.is_3d ?? false,
                distanceMaxMultiplier: settings.layout?.distance_max_multiplier ?? 5.0,
            });

            // Apply heatmap settings (all params — ensures sliders and scene stay in sync)
            setInitialHeatmapSettings({
                maxSlices:       settings.heatmap?.max_slices      ?? VISUALIZATION_DEFAULTS.heatmap.maxSlices,
                baseSize:        settings.heatmap?.base_size       ?? VISUALIZATION_DEFAULTS.appearance.baseSize,
                fadeThreshold:   settings.heatmap?.fade_threshold  ?? VISUALIZATION_DEFAULTS.heatmap.fadeThreshold,
                greenThreshold:  settings.heatmap?.green_threshold ?? VISUALIZATION_DEFAULTS.heatmap.greenThreshold,
                yellowThreshold: settings.heatmap?.yellow_threshold ?? VISUALIZATION_DEFAULTS.heatmap.yellowThreshold,
                intensityPower:  settings.heatmap?.intensity_power ?? VISUALIZATION_DEFAULTS.heatmap.intensityPower,
                minIntensity:    settings.heatmap?.min_intensity   ?? VISUALIZATION_DEFAULTS.heatmap.minIntensity,
                borderWidth:     settings.heatmap?.border_width    ?? VISUALIZATION_DEFAULTS.heatmap.borderWidth,
            });

            // Apply fidelity settings
            setInitialFidelitySettings({
                oneQubitBase: settings.fidelity?.one_qubit_fidelity_base ?? 0.99,
                twoQubitBase: settings.fidelity?.two_qubit_fidelity_base ?? 0.98,
            });

            // Update the Playground instance with these settings
            playgroundInstance.updateAppearanceParameters({
                qubitSize: settings.appearance?.qubit_size,
                connectionThickness: settings.appearance?.connection_thickness,
                inactiveAlpha: settings.appearance?.inactive_alpha,
                baseSize: settings.heatmap?.base_size,
            });

            playgroundInstance.setBlochSpheresVisible(settings.appearance?.render_bloch_spheres ?? false);
            playgroundInstance.setConnectionLinesVisible(settings.appearance?.render_connection_lines ?? true);

            playgroundInstance.updateLayoutParameters({
                repelForce: settings.layout?.repel_force,
                idealDistance: settings.layout?.ideal_distance,
                iterations: settings.layout?.iterations,
                attractForce: settings.layout?.attract_force,
                coreDistance: settings.layout?.core_distance,
                is3D: settings.layout?.is_3d,
                distanceMaxMultiplier: settings.layout?.distance_max_multiplier,
            }, completeLoading);

            playgroundInstance.updateHeatmapSlices(settings.heatmap?.max_slices ?? -1);

            playgroundInstance.updateHeatmapColorParameters({
                fadeThreshold: settings.heatmap?.fade_threshold,
                greenThreshold: settings.heatmap?.green_threshold,
                yellowThreshold: settings.heatmap?.yellow_threshold,
                intensityPower: settings.heatmap?.intensity_power,
                minIntensity: settings.heatmap?.min_intensity,
                borderWidth: settings.heatmap?.border_width,
            });

            playgroundInstance.updateFidelityParameters({
                oneQubitBase: settings.fidelity?.one_qubit_fidelity_base,
                twoQubitBase: settings.fidelity?.two_qubit_fidelity_base,
            });

        } else {
            // Fallback to reading defaults FROM the playground instance (legacy behavior)
            setInitialAppearance({
                qubitSize: playgroundInstance.currentQubitSize,
                connectionThickness: playgroundInstance.currentConnectionThickness,
                inactiveAlpha: playgroundInstance.currentInactiveAlpha,
                renderBlochSpheres: playgroundInstance.areBlochSpheresVisible,
                renderConnectionLines: playgroundInstance.areConnectionLinesVisible,
            });
            setInitialLayout({
                repelForce:            playgroundInstance.currentRepelForce,
                idealDistance:         playgroundInstance.currentIdealDistance,
                iterations:            playgroundInstance.currentIterations,
                attractForce:          VISUALIZATION_DEFAULTS.layout.attractForce,
                coreDistance:          playgroundInstance.currentCoreDistance,
                is3D:                  VISUALIZATION_DEFAULTS.layout.is3D,
                distanceMaxMultiplier: VISUALIZATION_DEFAULTS.layout.distanceMaxMultiplier,
            });
            const heatmapColorParams = playgroundInstance.getHeatmapColorParameters();
            setInitialHeatmapSettings({
                maxSlices: playgroundInstance.maxHeatmapSlices,
                baseSize:  playgroundInstance.currentBaseSize,
                ...heatmapColorParams,
            });
            setInitialFidelitySettings({
                oneQubitBase: playgroundInstance.currentOneQubitFidelityBase,
                twoQubitBase: playgroundInstance.currentTwoQubitFidelityBase,
            });
            completeLoading();
        }

        // Initialize light mode from playground background state
        setLightMode(playgroundInstance.isLightBackground());

        // Set up keyboard controller help toggle callback
        const keyboardController = playgroundInstance.getKeyboardController();
        if (keyboardController) {
            keyboardController.setHelpToggleCallback(() => {
                setIsKeyboardShortcutsVisible(prev => !prev);
            });
        }
    }, [playgroundData]);

    // Effect specifically for dataset changes to dispose the old playground
    useEffect(() => {
        return () => {
            // This cleanup runs when playgroundData is about to change OR on unmount.
            if (playgroundRef.current) {
                console.log(
                    'Disposing playground due to dataset change or unmount. Instance ID:',
                    playgroundRef.current.instanceId
                );
                playgroundRef.current.dispose();
                playgroundRef.current = null;
                setIsPlaygroundInitialized(false);
                setIsTimelineInitialized(false);
                // Reset other related states if necessary
                setActualSliceCount(0);
                setMaxSliceIndex(0);
            }
        };
    }, [playgroundData]); // Only run this effect when playgroundData changes

    useEffect(() => {
        const intervalId = setInterval(() => {
            if (playgroundRef.current) {
                setFps(playgroundRef.current.currentFPS);
                const newLayoutTime =
                    playgroundRef.current.lastLayoutCalculationTime;
                if (newLayoutTime > 0) {
                    setLayoutTime(newLayoutTime);
                    // Resetting it in the source might be an option if we only want to show it once
                    // For now, we'll just keep showing the last value.
                }
            }
        }, 500); // Poll for debug info every 500ms

        return () => clearInterval(intervalId);
    }, [isPlaygroundInitialized]); // Rerun when playground is initialized

    const handleTimelineChange = (newSliceIndex: number) => {
        if (isPlaying) {
            setIsPlaying(false);
        }
        setCurrentSliceValue(newSliceIndex);
        if (playgroundRef.current) {
            playgroundRef.current.setCurrentSlice(newSliceIndex);
        }
    };

    // Callback for circuit tab switching
    const handleCircuitChange = (circuitIndex: number) => {
        if (playgroundRef.current) {
            playgroundRef.current.switchToCircuit(circuitIndex);
            setCurrentCircuitIndex(circuitIndex);
        }
    };

    const handlePlayPause = () => {
        if (currentSliceValue >= maxSliceIndex && !isPlaying) {
            return; // Don't start playing if at the end
        }
        setIsPlaying((prev) => !prev);
    };

    const handleSpeedChange = (newSpeed: number) => {
        setPlaybackSpeed(newSpeed);
    };

    const handleLightModeToggle = (newLightMode: boolean) => {
        setLightMode(newLightMode);
        if (playgroundRef.current) {
            playgroundRef.current.setLightBackground(newLightMode);
        }
    };

    // Left-side panel positioning (existing logic)
    const fidelityPanelTop = isAppearanceCollapsed
        ? `${BASE_TOP_MARGIN_PX + APPEARANCE_PANEL_COLLAPSED_HEIGHT_PX + INTER_PANEL_SPACING_PX}px`
        : `${BASE_TOP_MARGIN_PX + APPEARANCE_PANEL_EXPANDED_HEIGHT_PX + INTER_PANEL_SPACING_PX}px`;
    const layoutPanelTop = isFidelityCollapsed
        ? `${parseInt(fidelityPanelTop) + FIDELITY_PANEL_COLLAPSED_HEIGHT_PX + INTER_PANEL_SPACING_PX}px`
        : `${parseInt(fidelityPanelTop) + FIDELITY_PANEL_EXPANDED_HEIGHT_PX + INTER_PANEL_SPACING_PX}px`;

    // Right-side component positioning (new unified system)
    const playbackControlsHeight = isPlaybackCollapsed
        ? PLAYBACK_CONTROLS_COLLAPSED_HEIGHT_PX
        : PLAYBACK_CONTROLS_EXPANDED_HEIGHT_PX;

    const debugInfoBottom = `${BASE_BOTTOM_MARGIN_PX + playbackControlsHeight + INTER_PANEL_SPACING_PX}px`;
    const lightToggleBottom = `${parseInt(debugInfoBottom) + DEBUG_INFO_HEIGHT_PX + INTER_PANEL_SPACING_PX}px`;

    return (
        <div className="App">
            {isLoading && (
                <LoadingIndicator
                    stage={loadingStage}
                    progress={compilationProgress}
                    algorithm={currentParams?.algorithm}
                    numQubits={currentParams?.numQubits}
                    topology={currentParams?.topology}
                />
            )}
            {!playgroundData ? (
                appConstants && (
                    <PlaygroundParameterSelection
                        onGenerate={handleParameterGeneration}
                        constants={appConstants}
                    />
                )
            ) : (
                <>
                    <div
                        ref={mountRef}
                        style={{ width: '100vw', height: '100vh' }}
                    />
                    {isUiVisible && (
                        <>
                            {/* Show CircuitTabSwitcher for multi-circuit mode */}
                            <CircuitTabSwitcher
                                circuits={circuitInfo}
                                currentCircuitIndex={currentCircuitIndex}
                                onCircuitChange={handleCircuitChange}
                                disabled={!isPlaygroundInitialized}
                                isCollapsed={isCircuitTabsCollapsed}
                                onToggleCollapse={toggleCircuitTabsCollapse}
                            />
                            <AppearanceControls
                                playground={playgroundRef.current}
                                initialValues={initialAppearance}
                                isCollapsed={isAppearanceCollapsed}
                                onToggleCollapse={toggleAppearanceCollapse}
                                onRenderBlochSpheresChange={
                                    handleRenderBlochSpheresChange
                                }
                                onRenderConnectionLinesChange={
                                    handleRenderConnectionLinesChange
                                }
                            />
                            <FidelityControls
                                playground={playgroundRef.current}
                                initialValues={initialFidelitySettings}
                                isCollapsed={isFidelityCollapsed}
                                onToggleCollapse={toggleFidelityCollapse}
                                topPosition={fidelityPanelTop}
                            />
                            {!hasBackendLayout && (
                                <LayoutControls
                                    playground={playgroundRef.current}
                                    initialValues={initialLayout}
                                    isCollapsed={isLayoutCollapsed}
                                    onToggleCollapse={toggleLayoutCollapse}
                                    topPosition={layoutPanelTop}
                                    setIsLoading={setIsLoading}
                                />
                            )}
                            <HeatmapControls
                                playground={playgroundRef.current}
                                initialValues={initialHeatmapSettings}
                                isCollapsed={isHeatmapCollapsed}
                                onToggleCollapse={toggleHeatmapCollapse}
                            />
                            {isTimelineInitialized && actualSliceCount > 0 && (
                                <>
                                    <LightBackgroundToggle
                                        lightMode={lightMode}
                                        onToggle={handleLightModeToggle}
                                        playground={playgroundRef.current}
                                        bottomPosition={lightToggleBottom}
                                    />
                                    <DebugInfo
                                        fps={fps}
                                        layoutTime={layoutTime}
                                        bottomPosition={debugInfoBottom}
                                    />
                                    <PlaybackControls
                                        isPlaying={isPlaying}
                                        onPlayPause={handlePlayPause}
                                        speed={playbackSpeed}
                                        onSpeedChange={handleSpeedChange}
                                        disabled={
                                            !isPlaygroundInitialized ||
                                            actualSliceCount === 0
                                        }
                                        isAtEnd={
                                            currentSliceValue >= maxSliceIndex
                                        }
                                        isCollapsed={isPlaybackCollapsed}
                                        onToggleCollapse={
                                            togglePlaybackCollapse
                                        }
                                    />
                                </>
                            )}
                            {isTimelineInitialized && actualSliceCount > 0 && (
                                <TimelineSlider
                                    min={0}
                                    max={maxSliceIndex}
                                    value={currentSliceValue}
                                    onChange={handleTimelineChange}
                                    disabled={actualSliceCount === 0}
                                    label="Time Slice"
                                    isCollapsed={isTimelineCollapsed}
                                    onToggleCollapse={toggleTimelineCollapse}
                                />
                            )}
                            {isTimelineInitialized &&
                                actualSliceCount === 0 && (
                                    <div
                                        style={{
                                            position: 'fixed',
                                            bottom: '30px',
                                            left: '50%',
                                            transform: 'translateX(-50%)',
                                            color: colors.text.primary,
                                            background: colors.shadow.medium,
                                            padding: '10px',
                                            borderRadius: '5px',
                                        }}
                                    >
                                        Loading slice data or no slices found.
                                    </div>
                                )}
                            <Tooltip
                                visible={tooltipVisible}
                                content={tooltipContent}
                                x={tooltipX}
                                y={tooltipY}
                            />
                        </>
                    )}
                </>
            )}

            <KeyboardShortcutsHelp
                isVisible={isKeyboardShortcutsVisible}
                onClose={() => setIsKeyboardShortcutsVisible(false)}
            />

            <BackendConnectionError
                isVisible={showBackendError}
                onClose={() => setShowBackendError(false)}
                apiUrl={getCircuitGenerationUrl()}
            />
        </div>
    );
};

export default App;
