import React, { useState, useEffect } from "react";
import type { Playground } from "../../scene/Playground.js";
import { colors } from "../theme/colors.js";

interface LayoutControlsProps {
    playground: Playground | null;
    initialValues: {
        repelForce: number;
        idealDistance: number;
        iterations: number;
        attractForce?: number;
        coreDistance?: number;
        is3D?: boolean;
        distanceMaxMultiplier?: number;
    };
    isCollapsed: boolean;
    onToggleCollapse: () => void;
    topPosition: string;
    setIsLoading: (loading: boolean) => void;
}

const basePanelStyle: React.CSSProperties = {
    position: "fixed",
    left: "20px",
    backgroundColor: colors.background.panel,
    padding: "15px",
    borderRadius: "8px",
    color: colors.text.primary,
    fontFamily: "Inter, system-ui, sans-serif",
    zIndex: 10,
    width: "280px",
    boxShadow: `0 2px 10px ${colors.shadow.light}`,
    transition: "all 0.3s ease",
};

const headerStyle: React.CSSProperties = {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    cursor: "pointer",
    padding: "4px 8px",
    borderRadius: "4px",
    transition: "background-color 0.2s ease",
    borderBottom: `1px solid ${colors.border.separator}`,
    paddingBottom: "10px",
    marginBottom: "0",
};

const headerHoverStyle: React.CSSProperties = {
    backgroundColor: colors.ui.surface,
};

const headerTitleStyle: React.CSSProperties = {
    margin: "0",
    fontSize: "14px",
    fontWeight: 600,
    color: colors.text.primary,
    textTransform: "uppercase",
    letterSpacing: "0.5px",
};

const toggleIconStyle: React.CSSProperties = {
    fontSize: "12px",
    color: colors.text.secondary,
    fontWeight: 600,
    transition: "transform 0.3s ease, color 0.2s ease",
    width: "16px",
    height: "16px",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    userSelect: "none",
};

const contentStyle: React.CSSProperties = {
    opacity: 1,
    maxHeight: "60vh",
    overflowY: "auto",
    overflowX: "hidden",
    transition: "all 0.3s ease",
    marginTop: "20px",
    paddingRight: "5px",
};

const collapsedContentStyle: React.CSSProperties = {
    opacity: 0,
    maxHeight: "0",
    overflow: "hidden",
    transition: "all 0.3s ease",
    marginTop: "0",
};

const controlGroupStyle: React.CSSProperties = {
    marginBottom: "15px",
};

const labelStyle: React.CSSProperties = {
    display: "block",
    marginBottom: "5px",
    fontSize: "0.9em",
};

const sliderStyle: React.CSSProperties = {
    width: "100%",
    cursor: "pointer",
};

const valueStyle: React.CSSProperties = {
    marginLeft: "10px",
    fontSize: "0.9em",
};

const buttonStyle: React.CSSProperties = {
    width: "100%",
    padding: "10px",
    backgroundColor: colors.primary.main,
    color: colors.text.primary,
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
    fontSize: "1em",
    marginTop: "10px",
    transition: "all 0.2s ease",
};

const LayoutControls: React.FC<LayoutControlsProps> = ({
    playground,
    initialValues,
    isCollapsed,
    onToggleCollapse,
    topPosition,
    setIsLoading,
}) => {
    const [isHovered, setIsHovered] = useState(false);
    const [repelForce, setRepelForce] = useState(initialValues.repelForce);
    const [idealDistance, setIdealDistance] = useState(initialValues.idealDistance);
    const [iterations, setIterations] = useState(initialValues.iterations);
    const [attractForce, setAttractForce] = useState(initialValues.attractForce ?? 0.1);
    const [coreDistance, setCoreDistance] = useState(initialValues.coreDistance ?? 5.0);
    const [is3D, setIs3D] = useState(initialValues.is3D ?? false);
    const [distanceMaxMultiplier, setDistanceMaxMultiplier] = useState(
        initialValues.distanceMaxMultiplier ?? 5.0,
    );

    useEffect(() => {
        setRepelForce(initialValues.repelForce);
        setIdealDistance(initialValues.idealDistance);
        setIterations(initialValues.iterations);
        setAttractForce(initialValues.attractForce ?? 0.1);
        setCoreDistance(initialValues.coreDistance ?? 5.0);
    }, [initialValues]);

    const handleCoreDistanceChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        setCoreDistance(parseFloat(event.target.value));
    };

    const handleIs3DChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        setIs3D(event.target.checked);
    };

    const handleDistanceMaxMultiplierChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        setDistanceMaxMultiplier(parseFloat(event.target.value));
    };

    const handleRepelForceChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        setRepelForce(parseFloat(event.target.value));
    };

    const handleIdealDistanceChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        setIdealDistance(parseFloat(event.target.value));
    };

    const handleIterationsChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        setIterations(parseInt(event.target.value));
    };

    const handleAttractForceChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        setAttractForce(parseFloat(event.target.value));
    };

    const handleForceButtonClick = () => {
        const multiCore = playground?.isMultiCore() ?? false;
        if (multiCore) setIsLoading(true);

        playground?.updateLayoutParameters(
            {
                repelForce,
                idealDistance,
                iterations,
                attractForce,
                coreDistance,
                is3D,
                distanceMaxMultiplier,
            },
            () => {
                if (multiCore) setIsLoading(false);
            }
        );
    };

    const panelStyle: React.CSSProperties = {
        ...basePanelStyle,
        top: topPosition,
    };

    return (
        <div style={panelStyle}>
            <div
                style={{
                    ...headerStyle,
                    ...(isHovered ? headerHoverStyle : {})
                }}
                onClick={onToggleCollapse}
                onMouseEnter={() => setIsHovered(true)}
                onMouseLeave={() => setIsHovered(false)}
            >
                <h4 style={headerTitleStyle}>
                    Layout Controls
                </h4>
                <div
                    style={{
                        ...toggleIconStyle,
                        transform: isCollapsed ? "rotate(0deg)" : "rotate(180deg)",
                        color: isHovered ? colors.text.primary : colors.text.secondary,
                    }}
                >
                    ▼
                </div>
            </div>

            <div style={isCollapsed ? collapsedContentStyle : contentStyle}>
                <div style={controlGroupStyle}>
                    <label htmlFor="core-distance" style={labelStyle}>
                        Core Distance:{" "}
                        <span style={valueStyle}>
                            {coreDistance.toFixed(1)}
                        </span>
                    </label>
                    <input
                        type="range"
                        id="core-distance"
                        min="1.0"
                        max="500"
                        step="0.5"
                        value={coreDistance}
                        onChange={handleCoreDistanceChange}
                        style={sliderStyle}
                    />
                </div>

                <div style={controlGroupStyle}>
                    <label htmlFor="is-3d" style={{ ...labelStyle, display: "flex", alignItems: "center" }}>
                        <input
                            type="checkbox"
                            id="is-3d"
                            checked={is3D}
                            onChange={handleIs3DChange}
                            style={{ marginRight: "10px", cursor: "pointer" }}
                        />
                        Enable 3D Layout
                    </label>
                </div>

                <div style={controlGroupStyle}>
                    <label htmlFor="distance-max-multiplier" style={labelStyle}>
                        Repulsion Max Distance:{" "}
                        <span style={valueStyle}>
                            {distanceMaxMultiplier.toFixed(1)}x
                        </span>
                    </label>
                    <input
                        type="range"
                        id="distance-max-multiplier"
                        min="1.0"
                        max="20.0"
                        step="0.5"
                        value={distanceMaxMultiplier}
                        onChange={handleDistanceMaxMultiplierChange}
                        style={sliderStyle}
                    />
                </div>

                <div style={controlGroupStyle}>
                    <label htmlFor="repel-force" style={labelStyle}>
                        Repel Force:{" "}
                        <span style={valueStyle}>
                            {repelForce.toFixed(2)}
                        </span>
                    </label>
                    <input
                        type="range"
                        id="repel-force"
                        min="0.1"
                        max="2.0"
                        step="0.01"
                        value={repelForce}
                        onChange={handleRepelForceChange}
                        style={sliderStyle}
                    />
                </div>

                <div style={controlGroupStyle}>
                    <label htmlFor="ideal-distance" style={labelStyle}>
                        Ideal Distance:{" "}
                        <span style={valueStyle}>
                            {idealDistance.toFixed(1)}
                        </span>
                    </label>
                    <input
                        type="range"
                        id="ideal-distance"
                        min="1.0"
                        max="10.0"
                        step="0.5"
                        value={idealDistance}
                        onChange={handleIdealDistanceChange}
                        style={sliderStyle}
                    />
                </div>

                <div style={controlGroupStyle}>
                    <label htmlFor="iterations" style={labelStyle}>
                        Iterations:{" "}
                        <span style={valueStyle}>{iterations}</span>
                    </label>
                    <input
                        type="range"
                        id="iterations"
                        min="100"
                        max="20000"
                        step="100"
                        value={iterations}
                        onChange={handleIterationsChange}
                        style={sliderStyle}
                    />
                </div>

                <div style={controlGroupStyle}>
                    <label htmlFor="attract-force" style={labelStyle}>
                        Attract Force:{" "}
                        <span style={valueStyle}>
                            {attractForce.toFixed(3)}
                        </span>
                    </label>
                    <input
                        type="range"
                        id="attract-force"
                        min="0"
                        max="1"
                        step="0.001"
                        value={attractForce}
                        onChange={handleAttractForceChange}
                        style={sliderStyle}
                    />
                </div>

                <div style={controlGroupStyle}>
                    <button style={buttonStyle} onClick={handleForceButtonClick}>
                        Apply Force Layout
                    </button>
                </div>
            </div>
        </div>
    );
};

export default LayoutControls;
