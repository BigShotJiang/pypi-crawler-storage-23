import { describe, it, expect, beforeEach, vi } from "vitest";
import { Heatmap } from "../scene/objects/Heatmap.js";
import { VISUALIZATION_DEFAULTS } from "../config/defaults.js";
import * as THREE from "three";

describe("Heatmap Core Functions", () => {
    let heatmap: Heatmap;
    let mockCamera: THREE.PerspectiveCamera;
    const qubitNumber = 5;
    const maxSlices = 10;

    beforeEach(() => {
        mockCamera = new THREE.PerspectiveCamera();
        heatmap = new Heatmap(mockCamera, qubitNumber, maxSlices);
    });

    describe("Constructor", () => {
        it("should initialize with correct parameters", () => {
            expect(heatmap.camera).toBe(mockCamera);
            expect(heatmap.maxSlices).toBe(maxSlices);
            expect(heatmap.positions).toBeInstanceOf(Float32Array);
            expect(heatmap.positions.length).toBe(qubitNumber * 3);
            expect(heatmap.intensities).toBeInstanceOf(Float32Array);
            expect(heatmap.intensities.length).toBe(qubitNumber);
        });

        it("should initialize mesh and material correctly", () => {
            expect(heatmap.mesh).toBeDefined();
            expect(heatmap.material).toBeDefined();
            expect(heatmap.mesh.visible).toBe(true);
            expect(heatmap.mesh.geometry).toBeDefined();
        });

        it("should initialize shader uniforms", () => {
            const uniforms = heatmap.material.uniforms;
            expect(uniforms.aspect).toBeDefined();
            expect(uniforms.radius).toBeDefined();
            expect(uniforms.baseSize).toBeDefined();
            expect(uniforms.cameraPosition).toBeDefined();
            expect(uniforms.scaleFactor).toBeDefined();
            expect(uniforms.baseSize.value).toBe(500.0);
        });

        it("should initialize geometry attributes", () => {
            const geometry = heatmap.mesh.geometry;
            expect(geometry.attributes.position).toBeDefined();
            expect(geometry.attributes.intensity).toBeDefined();
            if (geometry.attributes.position.array) {
                expect(geometry.attributes.position.array.length).toBe(
                    qubitNumber * 3,
                );
            }
            if (geometry.attributes.intensity.array) {
                expect(geometry.attributes.intensity.array.length).toBe(
                    qubitNumber,
                );
            }
        });

        it("should handle edge case with zero qubits", () => {
            const zeroQubitHeatmap = new Heatmap(mockCamera, 0, maxSlices);

            expect(zeroQubitHeatmap.positions.length).toBe(0);
            expect(zeroQubitHeatmap.intensities.length).toBe(0);
        });

        it("should handle edge case with negative maxSlices", () => {
            const negativeSliceHeatmap = new Heatmap(
                mockCamera,
                qubitNumber,
                -1,
            );

            expect(negativeSliceHeatmap.maxSlices).toBe(-1);
            expect(negativeSliceHeatmap.positions.length).toBe(qubitNumber * 3);
        });
    });

    describe("updateBaseSize method", () => {
        it("should update main mesh base size", () => {
            const newSize = 750.0;

            heatmap.updateBaseSize(newSize);

            expect(heatmap.material.uniforms.baseSize.value).toBe(newSize);
        });

        it("should handle zero and negative values", () => {
            heatmap.updateBaseSize(0);
            expect(heatmap.material.uniforms.baseSize.value).toBe(0);

            heatmap.updateBaseSize(-100);
            expect(heatmap.material.uniforms.baseSize.value).toBe(-100);
        });
    });

    describe("clearPositionsCache method", () => {
        it("should clear qubit positions array", () => {
            heatmap.qubitPositions = [
                new THREE.Vector3(1, 2, 3),
                new THREE.Vector3(4, 5, 6),
            ];

            heatmap.clearPositionsCache();

            expect(heatmap.qubitPositions).toEqual([]);
            expect(heatmap.qubitPositions.length).toBe(0);
        });

        it("should not affect other properties", () => {
            const originalPositions = heatmap.positions;
            const originalIntensities = heatmap.intensities;
            const originalMesh = heatmap.mesh;

            heatmap.clearPositionsCache();

            expect(heatmap.positions).toBe(originalPositions);
            expect(heatmap.intensities).toBe(originalIntensities);
            expect(heatmap.mesh).toBe(originalMesh);
        });
    });

    describe("updatePoints method", () => {
        it("should handle empty qubit positions", () => {
            const emptyPositions = new Map<number, THREE.Vector3>();
            const cumulativeInteractions: number[][] = [];

            const result = heatmap.updatePoints(
                emptyPositions,
                0,
                cumulativeInteractions,
            );

            expect(result.maxObservedRawWeightedSum).toBe(0);
            expect(result.numSlicesEffectivelyUsed).toBe(0);
            expect(Array.from(heatmap.intensities)).toEqual([0, 0, 0, 0, 0]);
        });

        it("should update positions correctly", () => {
            const qubitPositions = new Map<number, THREE.Vector3>();
            qubitPositions.set(0, new THREE.Vector3(1, 2, 3));
            qubitPositions.set(1, new THREE.Vector3(4, 5, 6));
            const cumulativeInteractions: number[][] = [
                [10, 20],
                [5, 15],
            ];

            heatmap.updatePoints(qubitPositions, 1, cumulativeInteractions);

            expect(heatmap.positions[0]).toBe(1);
            expect(heatmap.positions[1]).toBe(2);
            expect(heatmap.positions[2]).toBe(3);
            expect(heatmap.positions[3]).toBe(4);
            expect(heatmap.positions[4]).toBe(5);
            expect(heatmap.positions[5]).toBe(6);
        });

        it("should normalize intensities correctly", () => {
            const qubitPositions = new Map<number, THREE.Vector3>();
            qubitPositions.set(0, new THREE.Vector3(0, 0, 0));
            qubitPositions.set(1, new THREE.Vector3(1, 1, 1));
            const cumulativeInteractions: number[][] = [
                [10, 20], // qubit 0: slice 0=10, slice 1=20, window=20
                [5, 15], // qubit 1: slice 0=5, slice 1=15, window=15
            ];

            const result = heatmap.updatePoints(
                qubitPositions,
                1,
                cumulativeInteractions,
            );

            expect(result.maxObservedRawWeightedSum).toBe(20);
            expect(heatmap.intensities[0]).toBe(1.0); // 20/20 = 1.0
            expect(heatmap.intensities[1]).toBe(0.75); // 15/20 = 0.75
        });

        it("should handle window size correctly with maxSlices", () => {
            const qubitPositions = new Map<number, THREE.Vector3>();
            qubitPositions.set(0, new THREE.Vector3(0, 0, 0));
            const cumulativeInteractions: number[][] = [
                [1, 3, 6, 10, 15, 21], // 6 slices of interactions
            ];

            const result = heatmap.updatePoints(
                qubitPositions,
                5,
                cumulativeInteractions,
            );

            expect(result.numSlicesEffectivelyUsed).toBe(6); // All 6 slices since maxSlices=10 > 6
            expect(result.maxObservedRawWeightedSum).toBe(21);
        });

        it("should handle all slices mode (maxSlices = -1)", () => {
            const allSlicesHeatmap = new Heatmap(mockCamera, 1, -1);
            const qubitPositions = new Map<number, THREE.Vector3>();
            qubitPositions.set(0, new THREE.Vector3(0, 0, 0));
            const cumulativeInteractions: number[][] = [
                [1, 3, 6, 10], // 4 slices
            ];

            const result = allSlicesHeatmap.updatePoints(
                qubitPositions,
                3,
                cumulativeInteractions,
            );

            expect(result.numSlicesEffectivelyUsed).toBe(4);
            expect(result.maxObservedRawWeightedSum).toBe(10);
        });

        it("should handle negative slice index", () => {
            const qubitPositions = new Map<number, THREE.Vector3>();
            qubitPositions.set(0, new THREE.Vector3(0, 0, 0));
            const cumulativeInteractions: number[][] = [[1, 2, 3]];

            const result = heatmap.updatePoints(
                qubitPositions,
                -1,
                cumulativeInteractions,
            );

            expect(result.maxObservedRawWeightedSum).toBe(0);
            expect(result.numSlicesEffectivelyUsed).toBe(0);
            expect(heatmap.intensities[0]).toBe(0);
        });

        it("should handle empty cumulative interactions", () => {
            const qubitPositions = new Map<number, THREE.Vector3>();
            qubitPositions.set(0, new THREE.Vector3(0, 0, 0));
            const emptyCumulativeInteractions: number[][] = [];

            const result = heatmap.updatePoints(
                qubitPositions,
                0,
                emptyCumulativeInteractions,
            );

            expect(result.maxObservedRawWeightedSum).toBe(0);
            expect(heatmap.intensities[0]).toBe(0);
        });

        it("should resize buffers when qubit positions size changes", () => {
            const smallPositions = new Map<number, THREE.Vector3>();
            smallPositions.set(0, new THREE.Vector3(0, 0, 0));
            heatmap.updatePoints(smallPositions, 0, []);

            const largePositions = new Map<number, THREE.Vector3>();
            for (let i = 0; i < 10; i++) {
                largePositions.set(i, new THREE.Vector3(i, i, i));
            }

            heatmap.updatePoints(largePositions, 0, []);

            expect(heatmap.positions.length).toBe(10 * 3);
            expect(heatmap.intensities.length).toBe(10);
        });
    });

    describe("dispose method", () => {
        it("should dispose main mesh geometry and material", () => {
            const geometryDisposeSpy = vi.spyOn(
                heatmap.mesh.geometry,
                "dispose",
            );
            const materialDisposeSpy = vi.spyOn(
                heatmap.mesh.material,
                "dispose",
            );

            heatmap.dispose();

            expect(geometryDisposeSpy).toHaveBeenCalled();
            expect(materialDisposeSpy).toHaveBeenCalled();
        });

        it("should not throw when disposing", () => {
            expect(() => {
                heatmap.dispose();
            }).not.toThrow();
        });
    });

    describe("Integration tests", () => {
        it("should handle complex workflow: create, update, dispose", () => {
            const qubitPositions = new Map<number, THREE.Vector3>();
            for (let i = 0; i < 8; i++) {
                qubitPositions.set(i, new THREE.Vector3(i, i, i));
            }

            const cumulativeInteractions: number[][] = [];
            for (let i = 0; i < 8; i++) {
                cumulativeInteractions.push([i * 2, i * 4, i * 6]);
            }

            expect(() => {
                heatmap.updateBaseSize(800);
                heatmap.updatePoints(qubitPositions, 2, cumulativeInteractions);
                heatmap.clearPositionsCache();
                heatmap.dispose();
            }).not.toThrow();
        });
    });

    describe("getColorParameters defaults", () => {
        it("returns defaults matching VISUALIZATION_DEFAULTS when material is initialized", () => {
            const params = heatmap.getColorParameters();
            const h = VISUALIZATION_DEFAULTS.heatmap;
            expect(params.fadeThreshold).toBe(h.fadeThreshold);
            expect(params.greenThreshold).toBe(h.greenThreshold);
            expect(params.yellowThreshold).toBe(h.yellowThreshold);
            expect(params.intensityPower).toBe(h.intensityPower);
            expect(params.minIntensity).toBe(h.minIntensity);
            expect(params.borderWidth).toBe(h.borderWidth);
        });
    });
});
