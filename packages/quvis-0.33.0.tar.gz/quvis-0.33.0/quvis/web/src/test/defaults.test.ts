import { describe, it, expect } from "vitest";
import { VISUALIZATION_DEFAULTS } from "../config/defaults.js";

describe("VISUALIZATION_DEFAULTS", () => {
    it("has correct appearance defaults", () => {
        const a = VISUALIZATION_DEFAULTS.appearance;
        expect(a.qubitSize).toBe(a.qubitSize);
        expect(a.connectionThickness).toBeGreaterThan(0);
        expect(a.inactiveAlpha).toBeGreaterThanOrEqual(0);
        expect(typeof a.renderBlochSpheres).toBe("boolean");
        expect(typeof a.renderConnectionLines).toBe("boolean");
        expect(a.baseSize).toBeGreaterThan(0);
    });

    it("has correct layout defaults", () => {
        const l = VISUALIZATION_DEFAULTS.layout;
        expect(l.repelForce).toBeGreaterThan(0);
        expect(l.idealDistance).toBeGreaterThan(0);
        expect(l.iterations).toBeGreaterThan(0);
        expect(l.attractForce).toBeGreaterThan(0);
        expect(l.coreDistance).toBeGreaterThan(0);
        expect(typeof l.is3D).toBe("boolean");
        expect(l.distanceMaxMultiplier).toBeGreaterThan(0);
    });

    it("has correct heatmap defaults", () => {
        const h = VISUALIZATION_DEFAULTS.heatmap;
        expect(h.maxSlices).toBe(-1);
        expect(h.fadeThreshold).toBeGreaterThanOrEqual(0);
        expect(h.greenThreshold).toBeGreaterThan(0);
        expect(h.yellowThreshold).toBeGreaterThan(0);
        expect(h.intensityPower).toBeGreaterThan(0);
        expect(h.minIntensity).toBeGreaterThan(0);
        expect(h.borderWidth).toBeGreaterThanOrEqual(0);
    });

    it("has correct fidelity defaults", () => {
        const f = VISUALIZATION_DEFAULTS.fidelity;
        expect(f.oneQubitBase).toBeGreaterThan(0);
        expect(f.oneQubitBase).toBeLessThanOrEqual(1);
        expect(f.twoQubitBase).toBeGreaterThan(0);
        expect(f.twoQubitBase).toBeLessThanOrEqual(1);
    });

    it("greenThreshold is less than yellowThreshold", () => {
        expect(VISUALIZATION_DEFAULTS.heatmap.greenThreshold)
            .toBeLessThan(VISUALIZATION_DEFAULTS.heatmap.yellowThreshold);
    });
});
