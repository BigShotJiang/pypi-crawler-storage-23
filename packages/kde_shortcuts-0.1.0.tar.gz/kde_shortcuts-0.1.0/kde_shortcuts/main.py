"""Command-line tool for managing KDE keyboard shortcuts."""

from __future__ import annotations

import configparser
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import click

__version__ = "0.1.0"

DEFAULT_CONFIG_PATH = Path.home() / ".config" / "kglobalshortcutsrc"
DESKTOP_DIR = Path.home() / ".local" / "share" / "applications"

# Mapping from tkinter keysym names to KDE shortcut names
TKINTER_TO_KDE = {
    "Control_L": "Ctrl", "Control_R": "Ctrl",
    "Alt_L": "Alt", "Alt_R": "Alt",
    "Super_L": "Meta", "Super_R": "Meta",
    "Shift_L": "Shift", "Shift_R": "Shift",
    "Print": "Print",
    "Escape": "Escape",
    "Return": "Return",
    "space": "Space",
    "Tab": "Tab",
    "BackSpace": "BackSpace",
    "Delete": "Delete",
    "Home": "Home",
    "End": "End",
    "Prior": "Page Up",
    "Next": "Page Down",
    "Up": "Up", "Down": "Down", "Left": "Left", "Right": "Right",
}

MODIFIER_KEYSYMS = {
    "Control_L", "Control_R", "Alt_L", "Alt_R",
    "Super_L", "Super_R", "Shift_L", "Shift_R",
}


# --- Config handling ---


@dataclass
class Shortcut:
    group: str
    key: str
    active: str
    default: str
    description: str

    @property
    def is_set(self) -> bool:
        return self.active not in ("", "none", "None")

    def format_value(self) -> str:
        return f"{self.active},{self.default},{self.description}"

    @classmethod
    def from_value(cls, group: str, key: str, raw_value: str) -> "Shortcut":
        parts = raw_value.split(",", 2)
        if len(parts) == 3:
            active, default, description = parts
        elif len(parts) == 2:
            active, default = parts
            description = ""
        else:
            active = parts[0] if parts else ""
            default = ""
            description = ""
        return cls(
            group=group,
            key=key,
            active=active.strip(),
            default=default.strip(),
            description=description.strip(),
        )


class ShortcutConfig:
    def __init__(self, path: Optional[Path] = None):
        self.path = path or DEFAULT_CONFIG_PATH
        self._parser = configparser.RawConfigParser()
        self._parser.optionxform = str  # preserve case
        if self.path.exists():
            self._parser.read(str(self.path))

    def groups(self) -> list[str]:
        return self._parser.sections()

    def shortcuts(self, group: Optional[str] = None) -> list[Shortcut]:
        results = []
        sections = [group] if group else self._parser.sections()
        for section in sections:
            if not self._parser.has_section(section):
                continue
            for key, value in self._parser.items(section):
                if key == "_k_friendly_name":
                    continue
                results.append(Shortcut.from_value(section, key, value))
        return results

    def get(self, group: str, key: str) -> Optional[Shortcut]:
        if not self._parser.has_section(group):
            return None
        if not self._parser.has_option(group, key):
            return None
        value = self._parser.get(group, key)
        return Shortcut.from_value(group, key, value)

    def set(self, group: str, key: str, shortcut: str, description: str = "") -> Shortcut:
        if not self._parser.has_section(group):
            self._parser.add_section(group)

        existing = self.get(group, key)
        if existing:
            default = existing.default
            desc = description or existing.description
        else:
            default = ""
            desc = description or key

        sc = Shortcut(
            group=group, key=key, active=shortcut, default=default, description=desc,
        )
        self._parser.set(group, key, sc.format_value())
        return sc

    def remove(self, group: str, key: str) -> bool:
        existing = self.get(group, key)
        if existing is None:
            return False
        existing.active = "none"
        self._parser.set(group, key, existing.format_value())
        return True

    def save(self):
        if self.path.exists():
            shutil.copy2(self.path, self.path.with_suffix(".bak"))

        with open(self.path, "w") as f:
            self._parser.write(f, space_around_delimiters=False)

        self._reload()

    @staticmethod
    def _reload():
        try:
            subprocess.run(
                ["qdbus", "org.kde.kglobalaccel", "/kglobalaccel",
                 "org.kde.KGlobalAccel.reloadConfig"],
                capture_output=True, timeout=5,
            )
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

    def search(self, query: str, group: Optional[str] = None) -> list[Shortcut]:
        query_lower = query.lower()
        return [
            sc for sc in self.shortcuts(group)
            if query_lower in sc.key.lower()
            or query_lower in sc.description.lower()
            or query_lower in sc.active.lower()
            or query_lower in sc.group.lower()
        ]

    def find_collisions(self, shortcut: str) -> list[Shortcut]:
        """Find all shortcuts that use the same key binding."""
        shortcut_lower = shortcut.lower()
        results = []
        for sc in self.shortcuts():
            if not sc.is_set:
                continue
            for binding in sc.active.split("\\t"):
                if binding.strip().lower() == shortcut_lower:
                    results.append(sc)
                    break
        return results


# --- Desktop file handling ---


def slugify(text: str) -> str:
    """Convert text to a filename-safe slug."""
    text = text.lower().strip()
    text = re.sub(r"[^\w\s-]", "", text)
    text = re.sub(r"[\s_-]+", "-", text)
    return text


def create_desktop_file(command: str, description: str, name: Optional[str] = None) -> Path:
    """Create a .desktop file and return its path."""
    slug = name or f"kde-shortcut-{slugify(description)}"
    if not slug.endswith(".desktop"):
        slug = f"{slug}.desktop"

    DESKTOP_DIR.mkdir(parents=True, exist_ok=True)
    path = DESKTOP_DIR / slug

    content = f"""[Desktop Entry]
Type=Application
Name={description}
Exec={command}
Icon=utilities-terminal
NoDisplay=true
"""
    path.write_text(content)
    return path


# --- Shortcut grabber ---


def _block_global_shortcuts(block: bool):
    """Tell kglobalaccel to block/unblock global shortcuts."""
    try:
        subprocess.run(
            ["qdbus", "org.kde.kglobalaccel", "/kglobalaccel",
             "blockGlobalShortcuts", "true" if block else "false"],
            capture_output=True, timeout=5,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass


def grab_shortcut() -> Optional[str]:
    """Open a tkinter popup to capture a keyboard shortcut."""
    try:
        import tkinter as tk
    except ImportError:
        click.echo("tkinter not available. Use --shortcut to specify manually.", err=True)
        return None

    result = {"shortcut": None}
    modifiers_held: set[str] = set()

    def on_key_press(event):
        keysym = event.keysym
        if keysym in MODIFIER_KEYSYMS:
            kde_name = TKINTER_TO_KDE.get(keysym, keysym)
            modifiers_held.add(kde_name)
            update_label()
        else:
            kde_key = TKINTER_TO_KDE.get(keysym, keysym)

            # Single character keys should be uppercase
            if len(keysym) == 1:
                kde_key = keysym.upper()

            # F-keys stay as-is
            if re.match(r"^F\d+$", keysym):
                kde_key = keysym

            parts = []
            for mod in ["Meta", "Ctrl", "Alt", "Shift"]:
                if mod in modifiers_held:
                    parts.append(mod)
            parts.append(kde_key)

            result["shortcut"] = "+".join(parts)
            root.destroy()

    def on_key_release(event):
        keysym = event.keysym
        if keysym in MODIFIER_KEYSYMS:
            kde_name = TKINTER_TO_KDE.get(keysym, keysym)
            modifiers_held.discard(kde_name)
            update_label()

    def update_label():
        if modifiers_held:
            parts = []
            for mod in ["Meta", "Ctrl", "Alt", "Shift"]:
                if mod in modifiers_held:
                    parts.append(mod)
            label.config(text="+".join(parts) + "+...")
        else:
            label.config(text="Press your shortcut...")

    def on_escape(event):
        root.destroy()

    _block_global_shortcuts(True)
    try:
        root = tk.Tk()
        root.title("Capture Shortcut")
        root.geometry("350x120")
        root.resizable(False, False)
        root.attributes("-topmost", True)

        root.update_idletasks()
        x = (root.winfo_screenwidth() - 350) // 2
        y = (root.winfo_screenheight() - 120) // 2
        root.geometry(f"350x120+{x}+{y}")

        label = tk.Label(root, text="Press your shortcut...", font=("sans-serif", 14))
        label.pack(expand=True, fill="both", padx=20, pady=10)

        hint = tk.Label(root, text="Esc to cancel", font=("sans-serif", 9), fg="gray")
        hint.pack(pady=(0, 10))

        root.bind("<KeyPress>", on_key_press)
        root.bind("<KeyRelease>", on_key_release)
        root.bind("<Escape>", on_escape)
        root.focus_force()
        root.mainloop()
    finally:
        _block_global_shortcuts(False)

    return result["shortcut"]


# --- CLI ---


def get_config(config_path: Optional[str]) -> ShortcutConfig:
    path = Path(config_path) if config_path else None
    cfg = ShortcutConfig(path)
    if not cfg.path.exists():
        click.echo(f"Config file not found: {cfg.path}", err=True)
        sys.exit(1)
    return cfg


@click.group()
@click.option("--config", "config_path", default=None,
              help="Path to kglobalshortcutsrc (default: ~/.config/kglobalshortcutsrc)")
@click.pass_context
def main(ctx, config_path):
    """Manage KDE keyboard shortcuts from the command line."""
    ctx.ensure_object(dict)
    ctx.obj["config_path"] = config_path


@main.command("grab")
@click.pass_context
def grab_key(ctx):
    """Capture a keyboard shortcut and print it."""
    shortcut = grab_shortcut()
    if shortcut is None:
        click.echo("Cancelled.")
        return

    click.echo(shortcut)

    cfg = get_config(ctx.obj["config_path"])
    collisions = cfg.find_collisions(shortcut)
    if collisions:
        click.echo()
        for sc in collisions:
            click.echo(f"  Already bound: {sc.group} → {sc.key} ({sc.description})")


@main.command("list")
@click.option("--group", "-g", default=None, help="Filter by group (e.g. kwin, plasmashell)")
@click.option("--search", "-s", default=None, help="Search shortcuts by name, key, or binding")
@click.option("--all", "show_all", is_flag=True, help="Include unbound shortcuts")
@click.option("--desktop", is_flag=True, help="Only show .desktop groups")
@click.pass_context
def list_shortcuts(ctx, group, search, show_all, desktop):
    """List keyboard shortcuts."""
    cfg = get_config(ctx.obj["config_path"])

    if search:
        shortcuts = cfg.search(search, group)
    else:
        shortcuts = cfg.shortcuts(group)

    if desktop:
        shortcuts = [s for s in shortcuts if s.group.endswith(".desktop")]

    if not show_all:
        shortcuts = [s for s in shortcuts if s.is_set]

    if not shortcuts:
        click.echo("No shortcuts found.")
        return

    max_group = max(len(s.group) for s in shortcuts)
    max_key = max(len(s.active) for s in shortcuts)
    max_name = max(len(s.key) for s in shortcuts)

    for sc in sorted(shortcuts, key=lambda s: (s.group, s.key)):
        click.echo(
            f"{sc.group:<{max_group}}  "
            f"{sc.active:<{max_key}}  "
            f"{sc.key:<{max_name}}  "
            f"{sc.description}"
        )


@main.command("groups")
@click.pass_context
def list_groups(ctx):
    """List all shortcut groups."""
    cfg = get_config(ctx.obj["config_path"])
    for group in sorted(cfg.groups()):
        count = len([s for s in cfg.shortcuts(group) if s.is_set])
        click.echo(f"{group}  ({count} active)")


@main.command("show")
@click.option("--group", "-g", required=True, help="Shortcut group")
@click.option("--key", "-k", required=True, help="Shortcut key name")
@click.pass_context
def show_shortcut(ctx, group, key):
    """Show details for a single shortcut."""
    cfg = get_config(ctx.obj["config_path"])
    sc = cfg.get(group, key)
    if sc is None:
        click.echo(f"Not found: [{group}] {key}", err=True)
        sys.exit(1)

    click.echo(f"Group:       {sc.group}")
    click.echo(f"Key:         {sc.key}")
    click.echo(f"Shortcut:    {sc.active}")
    click.echo(f"Default:     {sc.default}")
    click.echo(f"Description: {sc.description}")


@main.command("add")
@click.option("--command", "-c", required=True, help="Command to run (e.g. 'flameshot gui')")
@click.option("--description", "-d", required=True, help="Human-readable description")
@click.option("--shortcut", "-s", default=None,
              help="Key binding (e.g. 'Meta+Print'). Omit to capture interactively.")
@click.option("--name", "-n", default=None,
              help="Desktop filename (auto-generated from description if omitted)")
@click.option("--group", "-g", default=None,
              help="Existing group to add to (skips .desktop creation)")
@click.option("--key", "-k", default=None, help="Action key name (only with --group)")
@click.option("--force", is_flag=True, help="Overwrite conflicting shortcuts without prompting")
@click.pass_context
def add_shortcut(ctx, command, description, shortcut, name, group, key, force):
    """Add a keyboard shortcut, creating a .desktop file if needed."""
    cfg = get_config(ctx.obj["config_path"])

    # Resolve command to absolute path if it's a bare name
    cmd_parts = command.split(None, 1)
    resolved = shutil.which(cmd_parts[0])
    if resolved:
        cmd_parts[0] = resolved
        command = " ".join(cmd_parts)
    else:
        click.echo(f"WARNING: '{cmd_parts[0]}' not found on PATH", err=True)

    # Get shortcut — interactive or from flag
    if shortcut is None:
        click.echo("Opening shortcut capture window...")
        shortcut = grab_shortcut()
        if shortcut is None:
            click.echo("Cancelled.")
            return
        click.echo(f"Captured: {shortcut}")

    # Check for collisions
    collisions = cfg.find_collisions(shortcut)
    if collisions:
        click.echo(f"\nWARNING: '{shortcut}' is already bound to:")
        for sc in collisions:
            click.echo(f"  {sc.group} → {sc.key} ({sc.description})")
        click.echo()

        if not force:
            if not click.confirm("Overwrite?", default=False):
                click.echo("Cancelled.")
                return

        for sc in collisions:
            cfg.remove(sc.group, sc.key)
            click.echo(f"Cleared [{sc.group}] {sc.key}")

    if group:
        # Add to existing group (no desktop file)
        action_key = key or "_launch"
        sc = cfg.set(group, action_key, shortcut, description)
        cfg.save()
        click.echo(f"Added [{group}] {action_key}: {sc.active}")
    else:
        # Create desktop file
        desktop_path = create_desktop_file(command, description, name)
        desktop_name = desktop_path.name

        click.echo(f"Created {desktop_path}")

        sc = cfg.set(desktop_name, "_launch", shortcut, description)
        cfg.save()
        click.echo(f"Added [{desktop_name}] _launch: {sc.active}")


@main.command("set")
@click.option("--group", "-g", default=None, help="Shortcut group (optional if key is unique)")
@click.option("--key", "-k", required=True, help="Action key name (e.g. 'previous activity')")
@click.option("--shortcut", "-s", default=None,
              help="Key binding (e.g. 'Meta+Shift+A'). Omit to capture interactively.")
@click.option("--force", is_flag=True, help="Overwrite conflicting shortcuts without prompting")
@click.pass_context
def set_shortcut(ctx, group, key, shortcut, force):
    """Change the binding for an existing shortcut."""
    cfg = get_config(ctx.obj["config_path"])

    # Find the key across all groups if group not specified
    if group is None:
        matches = []
        for sc in cfg.shortcuts():
            if sc.key.lower() == key.lower():
                matches.append(sc)
        if len(matches) == 0:
            click.echo(f"Not found: '{key}'", err=True)
            sys.exit(1)
        elif len(matches) > 1:
            click.echo(f"'{key}' found in multiple groups:", err=True)
            for sc in matches:
                click.echo(f"  {sc.group} → {sc.key} ({sc.description})", err=True)
            click.echo("Use -g to specify which group.", err=True)
            sys.exit(1)
        group = matches[0].group
        key = matches[0].key  # preserve original case

    existing = cfg.get(group, key)
    if existing is None:
        click.echo(f"Not found: [{group}] {key}", err=True)
        sys.exit(1)

    # Get shortcut
    if shortcut is None:
        click.echo("Opening shortcut capture window...")
        shortcut = grab_shortcut()
        if shortcut is None:
            click.echo("Cancelled.")
            return
        click.echo(f"Captured: {shortcut}")

    # Check for collisions (excluding the key we're setting)
    collisions = [
        sc for sc in cfg.find_collisions(shortcut)
        if not (sc.group == group and sc.key == key)
    ]
    if collisions:
        click.echo(f"\nWARNING: '{shortcut}' is already bound to:")
        for sc in collisions:
            click.echo(f"  {sc.group} → {sc.key} ({sc.description})")
        click.echo()

        if not force:
            if not click.confirm("Overwrite?", default=False):
                click.echo("Cancelled.")
                return

        for sc in collisions:
            cfg.remove(sc.group, sc.key)
            click.echo(f"Cleared [{sc.group}] {sc.key}")

    old_binding = existing.active
    cfg.set(group, key, shortcut, existing.description)
    cfg.save()
    click.echo(f"Updated [{group}] {key}: {old_binding} → {shortcut}")


@main.command("remove")
@click.option("--group", "-g", required=True, help="Shortcut group")
@click.option("--key", "-k", required=True, help="Action key name")
@click.pass_context
def remove_shortcut(ctx, group, key):
    """Remove a shortcut binding (reset to none)."""
    cfg = get_config(ctx.obj["config_path"])

    if cfg.remove(group, key):
        cfg.save()
        click.echo(f"Removed [{group}] {key}")
    else:
        click.echo(f"Not found: [{group}] {key}", err=True)
        sys.exit(1)


if __name__ == "__main__":
    main()