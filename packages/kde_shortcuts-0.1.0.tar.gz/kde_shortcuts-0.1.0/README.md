# kde-shortcuts
Command-line tool to list and create kde-shortcuts

This is unreviewed AI-generated code.

## Motivation
I don't like GUIs you have to continually search and click. I want to use KDE because I like being *able* to be lazy when I want to and sometimes tiling window managers like i3 are too much work.

I am therefore creating a command-line tool to make it easier to list, search, delete and create new shortcuts for kde.

## Installation
```
pipx install kde-shortcuts
```

## Alternatives and prior work
Many tiling window managers make it very easy to define keys (such as i3wm or awesome) in their config files. Emacs allows you to query keybindings programmatically.

## Usage
List shortcuts: `kde-shortcuts list`

List shortcuts .desktop files: `kde-shortcuts list --desktop`

Add a shortcut: `kde-shortcuts add`

List shortcuts: kde-shortcuts list

List .desktop shortcuts: kde-shortcuts list --desktop

Search shortcuts: kde-shortcuts list --search maximize

Filter by group: kde-shortcuts list --group kwin

Include unbound shortcuts: kde-shortcuts list --all

List groups: kde-shortcuts groups

Show a shortcut: kde-shortcuts show -g kwin -k "Window Maximize"

Grab a shortcut: kde-shortcuts grab

Add a shortcut: kde-shortcuts add -c "flameshot gui" -d "Screenshot"

Add with specific binding: kde-shortcuts add -c "raise-claude.sh" -d "Raise Claude" -s "Meta+C"

Change a shortcut: kde-shortcuts set -k "previous activity" -s "Meta+Shift+A"

Change with grabber: kde-shortcuts set -k "Window Maximize"

Remove a shortcut: kde-shortcuts remove -g kwin -k "Window Maximize"

## About
I am @readwithai. I make tools for reading with and without AI and agency as well as a stream of day to day tools.

If you like tools like this, you might like to [follow me on github](https://github.com/talwrii)

