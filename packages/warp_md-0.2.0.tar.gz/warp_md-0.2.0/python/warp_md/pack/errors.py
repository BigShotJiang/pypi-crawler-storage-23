"""Pack configuration errors."""


class ValidationError(Exception):
    """Raised when pack configuration validation fails."""

    pass
