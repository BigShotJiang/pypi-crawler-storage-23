# FastChat Server Architecture
![server arch](../assets/server_arch.png)
