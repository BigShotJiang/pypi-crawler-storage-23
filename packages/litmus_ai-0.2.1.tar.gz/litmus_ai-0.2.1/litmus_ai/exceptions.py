class LitmusAuthError(Exception):
    """Raised when the LITMUS_API_KEY is missing, invalid, or inactive."""
    pass


class LitmusAPIError(Exception):
    """Raised when the Litmus backend returns an unexpected error."""
    def __init__(self, status_code: int, detail: str):
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"Litmus API error {status_code}: {detail}")
