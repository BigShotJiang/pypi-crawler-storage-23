from dataclasses import dataclass, field
from typing import Any, Dict


@dataclass
class LitmusResult:
    """Result returned by LitmusDetector.check()"""
    score: float
    is_hallucination: bool
    details: Dict[str, Any] = field(default_factory=dict)

    def __repr__(self):
        status = "HALLUCINATION" if self.is_hallucination else "OK"
        return f"LitmusResult(score={self.score:.4f}, status={status})"
