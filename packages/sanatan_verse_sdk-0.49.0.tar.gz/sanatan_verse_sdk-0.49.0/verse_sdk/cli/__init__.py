"""CLI commands for verse-sdk."""
