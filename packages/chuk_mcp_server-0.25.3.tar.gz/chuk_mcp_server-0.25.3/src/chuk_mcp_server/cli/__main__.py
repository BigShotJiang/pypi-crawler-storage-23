"""Allow ``python -m chuk_mcp_server.cli`` to work."""

from .main import main

main()
