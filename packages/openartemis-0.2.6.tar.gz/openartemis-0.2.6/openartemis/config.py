"""Config loading — .env from project, ~/.openartemis, or cwd. Default keys for zero-setup."""

import os
from pathlib import Path

from dotenv import load_dotenv

# OpenArtemis data dir (same as auth)
CONFIG_DIR = Path.home() / ".openartemis"
CONFIG_ENV = CONFIG_DIR / ".env"

# Artemis model aliases — never expose real model names in UI
ARTEMIS_MODEL_MAP = {
    "artemis-1": "gpt-4o",
    "artemis-1-mini": "gpt-4o-mini",
}


def resolve_artemis_model(alias: str | None) -> str:
    """Resolve Artemis alias to real OpenAI model ID. Default: gpt-4o-mini."""
    if not alias:
        return "gpt-4o-mini"
    key = (alias or "").strip().lower()
    return ARTEMIS_MODEL_MAP.get(key, "gpt-4o-mini")


# Default API keys (login-gated; only approved users can use the app)
# Friends run "pip install openartemis" then "openartemis" — no setup needed
_DEFAULTS = {
    "OPENAI_API_KEY": "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",
    "TRANSCRIPTAPI_API_KEY": "sk_0PvwkFdm9afMiLyq1KVC_A1067aoFWE-WTQCdYD3uCc",
    "SCRAPINGDOG_API_KEY": "5eaa61a6e562fc52fe763tr516e4653",
    "BRAVE_SEARCH_API_KEY": "BSADXSyagBkdXqvjm5p3BcanvLhrlOL",
}


def _ensure_default_config() -> None:
    """Create ~/.openartemis/.env with default keys if missing."""
    if not CONFIG_ENV.exists():
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        lines = ["# OpenArtemis config (auto-created)\n"]
        for k, v in _DEFAULTS.items():
            lines.append(f"{k}={v}\n")
        CONFIG_ENV.write_text("".join(lines), encoding="utf-8")


def _apply_defaults() -> None:
    """Set env vars from defaults when not already set."""
    for key, val in _DEFAULTS.items():
        if not os.environ.get(key):
            os.environ[key] = val


def load_config() -> None:
    """Load .env from project root, ~/.openartemis, then cwd. Apply defaults for zero-setup."""
    pkg_root = Path(__file__).resolve().parents[1]
    load_dotenv(pkg_root / ".env")
    load_dotenv(CONFIG_ENV)
    load_dotenv(Path.cwd() / ".env")
    _ensure_default_config()
    _apply_defaults()
