"""Abstract harvester interface."""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Iterator


class Harvester(ABC):
    """Base class for platform harvesters."""

    @abstractmethod
    def harvest(
        self,
        query: str,
        max_results: int,
        out_dir: Path,
        whisper_model: str = "base",
    ) -> Iterator[dict[str, Any]]:
        """
        Harvest transcripts for the given query.
        Yields post data dicts suitable for output.write_post.
        """
        ...
