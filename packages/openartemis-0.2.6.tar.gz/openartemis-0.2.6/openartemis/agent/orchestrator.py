"""Orchestrator — creates a structured plan from user request (single LLM call, no tools)."""

import json
import os
from pathlib import Path

from dotenv import load_dotenv
from openai import OpenAI

load_dotenv(Path(__file__).resolve().parents[2] / ".env")

PLAN_PROMPT = """You are a research planner. Given a user request, create a plan of up to 5 parallel tasks.

Output a JSON object with this exact structure:
{"tasks": [
  {"id": 1, "description": "Task description", "hint": "tool_name", "url": "optional url if applicable"},
  ...
]}

Available tools/hints:
- brave_search — web search (use for recent news, general web info)
- harvest_transcripts — YouTube, TikTok, Instagram, X transcripts
- fetch_webpage — fast text extraction from a URL (static HTML)
- browse_webpage — full render with headless browser (JS-heavy sites)
- list_transcripts — list harvested files (use out_dir from harvest)
- read_transcript — read a transcript file

Rules:
- Max 5 tasks (one per worker)
- Each task should be independent and parallelizable
- Include "url" in task only when the task targets a specific URL (fetch_webpage, browse_webpage)
- For harvest_transcripts, include the search query in description
- For brave_search, include the search query in description
- Output ONLY valid JSON, no markdown or extra text."""


def create_plan(user_request: str, model: str = "gpt-4o-mini") -> list[dict]:
    """Create a plan of up to 5 tasks from user request. Returns list of task dicts."""
    client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
    resp = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": PLAN_PROMPT},
            {"role": "user", "content": user_request},
        ],
    )
    content = (resp.choices[0].message.content or "").strip()
    # Strip markdown code blocks if present
    if content.startswith("```"):
        lines = content.split("\n")
        if lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        content = "\n".join(lines)
    try:
        data = json.loads(content)
        tasks = data.get("tasks", [])
        return tasks[:5]
    except json.JSONDecodeError:
        return []
