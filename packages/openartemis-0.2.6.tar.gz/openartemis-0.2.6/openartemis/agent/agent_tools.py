"""Agent workspace tools — read_file, write_file, list_dir, run_terminal, take_screenshot. Sandboxed to workspace."""

import base64
import subprocess
from pathlib import Path

from openartemis.auth.db import DATA_DIR

AGENT_WORKSPACE = DATA_DIR / "agent_workspace"


def _resolve(path: str) -> Path:
    """Resolve path within workspace. Raises ValueError if outside."""
    base = AGENT_WORKSPACE.resolve()
    resolved = (base / path).resolve()
    if not str(resolved).startswith(str(base)):
        raise ValueError("Path must be inside workspace")
    return resolved


def read_file(path: str) -> str:
    """Read file contents. Path is relative to workspace."""
    try:
        p = _resolve(path)
        return p.read_text(encoding="utf-8", errors="replace")
    except FileNotFoundError:
        return f"Error: File not found: {path}"
    except ValueError as e:
        return f"Error: {e}"
    except Exception as e:
        return f"Error: {e}"


def write_file(path: str, content: str) -> str:
    """Write content to file. Path is relative to workspace. Creates parent dirs."""
    try:
        p = _resolve(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        return f"Wrote {path}"
    except ValueError as e:
        return f"Error: {e}"
    except Exception as e:
        return f"Error: {e}"


def list_dir(path: str = ".") -> str:
    """List files and dirs. Path is relative to workspace."""
    AGENT_WORKSPACE.mkdir(parents=True, exist_ok=True)
    try:
        p = _resolve(path)
        if not p.is_dir():
            return f"Error: Not a directory: {path}"
        items = []
        for x in sorted(p.iterdir()):
            kind = "dir" if x.is_dir() else "file"
            items.append(f"  {kind}: {x.name}")
        return "\n".join(items) if items else "(empty)"
    except ValueError as e:
        return f"Error: {e}"
    except Exception as e:
        return f"Error: {e}"


def take_screenshot(url_or_path: str, prompt: str = "Describe what you see. Any issues or improvements?") -> str:
    """Take screenshot of URL or file path, send to vision model for feedback."""
    try:
        from playwright.sync_api import sync_playwright
        from openai import OpenAI
        import os

        if url_or_path.startswith(("http://", "https://")):
            url = url_or_path
        else:
            p = _resolve(url_or_path)
            url = f"file:///{p.as_posix()}"

        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            page = browser.new_page(viewport={"width": 1280, "height": 720})
            page.goto(url, wait_until="networkidle", timeout=15000)
            screenshot_bytes = page.screenshot()
            browser.close()

        b64 = base64.standard_b64encode(screenshot_bytes).decode()
        client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
        resp = client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt},
                        {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{b64}"}},
                    ],
                }
            ],
        )
        return (resp.choices[0].message.content or "").strip()
    except Exception as e:
        return f"Error: {e}"


def run_terminal(command: str) -> str:
    """Run command in workspace directory. Restricted to workspace cwd."""
    try:
        AGENT_WORKSPACE.mkdir(parents=True, exist_ok=True)
        result = subprocess.run(
            command,
            shell=True,
            cwd=str(AGENT_WORKSPACE),
            capture_output=True,
            text=True,
            timeout=300,
        )
        out = result.stdout or ""
        err = result.stderr or ""
        if err:
            out = out + "\n[stderr]\n" + err
        return out.strip() or f"(exit {result.returncode})"
    except subprocess.TimeoutExpired:
        return "Error: Command timed out (5 min)"
    except Exception as e:
        return f"Error: {e}"


AGENT_TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "Read file contents. Path is relative to workspace.",
            "parameters": {
                "type": "object",
                "properties": {"path": {"type": "string", "description": "File path (e.g. index.html)"}},
                "required": ["path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "write_file",
            "description": "Write content to file. Creates parent dirs if needed.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "File path"},
                    "content": {"type": "string", "description": "File content"},
                },
                "required": ["path", "content"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "list_dir",
            "description": "List files and directories in path.",
            "parameters": {
                "type": "object",
                "properties": {"path": {"type": "string", "description": "Directory path (default: .)", "default": "."}},
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "run_terminal",
            "description": "Run shell command in workspace. Use for npm, python, etc.",
            "parameters": {
                "type": "object",
                "properties": {"command": {"type": "string", "description": "Shell command to run"}},
                "required": ["command"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "take_screenshot",
            "description": "Take screenshot of URL (e.g. http://localhost:8000) or file path. Sends to vision model for feedback on UI.",
            "parameters": {
                "type": "object",
                "properties": {
                    "url_or_path": {"type": "string", "description": "URL or file path to capture"},
                    "prompt": {"type": "string", "description": "What to ask the vision model (default: describe and suggest improvements)", "default": "Describe what you see. Any issues or improvements?"},
                },
                "required": ["url_or_path"],
            },
        },
    },
]
