"""Chat session — AI with research tools, used when user asks."""

import json
import os
from pathlib import Path
from typing import Any, Callable

from openai import OpenAI

from openartemis.config import load_config, resolve_artemis_model

load_config()

from openartemis.agent import TOOLS, DetectiveAgent

CHAT_SYSTEM = """You are Artemis, a helpful AI assistant in a CLI chat. You can have normal conversations.

You also have research tools: harvest_transcripts, list_transcripts, read_transcript, brave_search, fetch_webpage, browse_webpage.
For deeper research, the user can use /research to run the multi-agent pipeline.
Use them ONLY when the user explicitly asks you to research, find, harvest, or look something up.
Examples: "research Mr Beast's latest video", "find out about X", "harvest transcripts about Y"

For normal chat, just respond. For research requests, use the tools and summarize what you find."""


class ChatSession:
    """Persistent chat with AI that can use research tools."""

    def __init__(
        self,
        on_tool_call: Callable[[str, dict], None] | None = None,
        user_id: int | None = None,
        is_admin: bool = False,
        session_id: int | None = None,
    ):
        self.client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
        self.agent = DetectiveAgent(out_dir=Path("./detective_output"))
        self.model_display = "Artemis-1-Mini"
        self.model = resolve_artemis_model(self.model_display)
        self.messages: list[dict[str, Any]] = [{"role": "system", "content": CHAT_SYSTEM}]
        self.on_tool_call = on_tool_call
        self.credits_used = 0
        self.user_id = user_id
        self.is_admin = is_admin
        self.session_id = session_id
        self._last_persisted = 1

    def persist(self) -> None:
        """Append new messages to DB and sync to local file."""
        if not self.session_id or not self.user_id:
            return
        from openartemis.auth.db import append_chat_message, DATA_DIR

        for i in range(self._last_persisted, len(self.messages)):
            m = self.messages[i]
            role = m.get("role", "")
            content = m.get("content", "") or ""
            tc = m.get("tool_calls")
            append_chat_message(self.session_id, role, content, tc)
        self._last_persisted = len(self.messages)

        local_dir = DATA_DIR / "chat_history"
        local_dir.mkdir(parents=True, exist_ok=True)
        local_path = local_dir / f"{self.session_id}.json"
        with open(local_path, "w", encoding="utf-8") as f:
            json.dump(
                [{"role": m["role"], "content": m.get("content", ""), "tool_calls": m.get("tool_calls")} for m in self.messages if m["role"] != "system"],
                f,
                indent=2,
                ensure_ascii=False,
            )

    def send(
        self,
        user_text: str,
        stream_callback: Callable[[str], None] | None = None,
    ) -> str:
        """Send user message, get AI response (may use tools). Returns final text.
        If stream_callback is set, call it with each content chunk for streaming display."""
        self.messages.append({"role": "user", "content": user_text})

        for _ in range(15):
            stream = self.client.chat.completions.create(
                model=self.model,
                messages=self.messages,
                tools=TOOLS,
                tool_choice="auto",
                stream=True,
            )

            content_parts: list[str] = []
            tool_calls_acc: dict[int, dict] = {}

            for chunk in stream:
                delta = chunk.choices[0].delta if chunk.choices else None
                if not delta:
                    continue
                if getattr(delta, "content", None):
                    text = delta.content or ""
                    content_parts.append(text)
                    if stream_callback:
                        stream_callback(text)
                if getattr(delta, "tool_calls", None):
                    for tc in delta.tool_calls:
                        idx = getattr(tc, "index", len(tool_calls_acc))
                        if idx not in tool_calls_acc:
                            tool_calls_acc[idx] = {"id": "", "name": "", "arguments": ""}
                        if getattr(tc, "id", None):
                            tool_calls_acc[idx]["id"] = tc.id
                        if getattr(tc, "function", None):
                            if getattr(tc.function, "name", None):
                                tool_calls_acc[idx]["name"] = tc.function.name or ""
                            if getattr(tc.function, "arguments", None):
                                tool_calls_acc[idx]["arguments"] += tc.function.arguments or ""

            content = "".join(content_parts)
            tool_calls_list = [
                {
                    "id": tool_calls_acc[i]["id"],
                    "function": {"name": tool_calls_acc[i]["name"], "arguments": tool_calls_acc[i]["arguments"]},
                }
                for i in sorted(tool_calls_acc.keys())
            ]

            msg_dict: dict[str, Any] = {
                "role": "assistant",
                "content": content or "",
                "tool_calls": None,
            }
            if tool_calls_list:
                msg_dict["tool_calls"] = [
                    {"id": t["id"], "type": "function", "function": t["function"]}
                    for t in tool_calls_list
                ]
            self.messages.append(msg_dict)

            if not tool_calls_list:
                return content.strip()

            for tc in tool_calls_list:
                name = tc["function"]["name"]
                try:
                    args = json.loads(tc["function"]["arguments"])
                except json.JSONDecodeError:
                    args = {}
                if self.on_tool_call:
                    self.on_tool_call(name, args)
                result = self.agent._execute_tool(name, args)
                if name == "harvest_transcripts" and not self.is_admin:
                    try:
                        r = json.loads(result)
                        credits = 1 + r.get("harvested_count", 0)
                        self.credits_used += credits
                        if self.user_id:
                            from openartemis.auth.db import log_usage
                            log_usage(self.user_id, credits, "harvest")
                    except (json.JSONDecodeError, TypeError):
                        self.credits_used += 1
                        if self.user_id:
                            from openartemis.auth.db import log_usage
                            log_usage(self.user_id, 1, "harvest")
                self.messages.append({
                    "role": "tool",
                    "tool_call_id": tc["id"],
                    "content": result,
                })

        return "Max turns reached."
