"""OpenArtemis auth — login, invite codes, sessions."""

from openartemis.auth.db import (
    init_db,
    get_user_count,
    create_admin,
    reset_admin_password,
    get_user_by_username,
    get_user_by_id,
    list_users,
    revoke_user,
    create_user_direct,
    log_usage,
    get_usage_by_user,
    create_invite_code,
    redeem_invite_code,
    create_chat_session,
    get_chat_sessions,
    get_chat_messages,
    update_chat_session_title,
)
from openartemis.auth.passwords import hash_password, verify_password
from openartemis.auth.sessions import create_session, get_session_user, revoke_session


def login(username: str, password: str) -> dict | None:
    """Login with username/password. Returns user dict if valid, else None."""
    from openartemis.auth.db import get_failed_login_count, record_failed_login
    if get_failed_login_count(username) >= 5:
        return None  # Rate limited: 5 failed logins per 15 min per username
    user = get_user_by_username(username)
    if not user or not verify_password(password, user["password_hash"]):
        record_failed_login(username)
        return None
    if not user["approved"]:
        return None  # Pending approval
    return user
