"""Auto-update: at startup, check PyPI and upgrade openartemis if a newer version exists."""

import os
import subprocess
import sys
import urllib.request
from pathlib import Path


def _parse_version(s: str) -> tuple[int, ...]:
    """Parse '0.2.5' or '0.2.6a1' into comparable tuple; trailing non-numeric parts ignored for comparison."""
    parts: list[int] = []
    for x in s.strip().split("."):
        n = ""
        for c in x:
            if c.isdigit():
                n += c
            else:
                break
        if n:
            parts.append(int(n))
        else:
            break
    return tuple(parts) if parts else (0,)


def _get_latest_pypi_version() -> str | None:
    """Fetch latest version string from PyPI. Returns None on any error."""
    try:
        req = urllib.request.Request(
            "https://pypi.org/pypi/openartemis/json",
            headers={"Accept": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            import json
            data = json.load(resp)
        return data.get("info", {}).get("version")
    except Exception:
        return None


def _get_current_version() -> str:
    """Current installed version from metadata."""
    try:
        from importlib.metadata import version
        return version("openartemis")
    except Exception:
        return "0.0.0"


def _upgrade_and_restart() -> bool:
    """Run pip install --upgrade openartemis and re-exec this process. Returns True if we restarted."""
    print("Updating OpenArtemis...", flush=True)
    executable = sys.executable
    args = [executable, "-m", "pip", "install", "--upgrade", "openartemis"]
    try:
        subprocess.run(args, check=True, capture_output=True, timeout=120)
    except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired):
        return False
    # Re-exec so the user runs the new code
    reexec = [executable, "-m", "openartemis"] + sys.argv[1:]
    os.execv(executable, reexec)
    return True  # unreachable


def ensure_updated() -> None:
    """
    If a newer version of openartemis is on PyPI, upgrade and restart.
    Skips if OPENARTEMIS_NO_UPDATE is set. Fails silently on errors.
    """
    if os.environ.get("OPENARTEMIS_NO_UPDATE", "").strip().lower() in ("1", "true", "yes"):
        return
    current = _get_current_version()
    latest = _get_latest_pypi_version()
    if not latest:
        return
    if _parse_version(latest) <= _parse_version(current):
        return
    # Newer version available: upgrade and restart
    try:
        _upgrade_and_restart()
    except Exception:
        pass
