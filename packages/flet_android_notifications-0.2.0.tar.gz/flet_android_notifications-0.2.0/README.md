See the [full documentation on GitHub](https://github.com/alex-stoica/flet-android-notifications).
