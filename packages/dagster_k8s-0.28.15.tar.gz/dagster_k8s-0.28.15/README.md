# dagster-k8s

The docs for `dagster-k8s` can be found
[here](https://docs.dagster.io/integrations/libraries/k8s/dagster-k8s).
