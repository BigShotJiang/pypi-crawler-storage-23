from django.contrib import admin

from .models import Apple

admin.site.register(Apple)
