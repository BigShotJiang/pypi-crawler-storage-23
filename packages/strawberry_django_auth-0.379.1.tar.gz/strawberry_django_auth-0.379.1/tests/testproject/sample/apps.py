from django.apps import AppConfig


class SampleModelConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "tests.testproject.sample"
