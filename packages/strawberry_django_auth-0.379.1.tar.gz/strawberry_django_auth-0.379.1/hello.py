def main():
    print("Hello from strawberry-django-auth!")


if __name__ == "__main__":
    main()
