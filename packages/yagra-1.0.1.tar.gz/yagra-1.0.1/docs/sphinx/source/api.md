# API Reference

Yagra's Python API typically builds an instance with `Yagra.from_workflow(...)` and executes it with `invoke(...)`.
The CLI entry point is `main()` (the `yagra` command).

```{eval-rst}
.. automodule:: yagra
   :members:
   :undoc-members:
   :show-inheritance:
```
