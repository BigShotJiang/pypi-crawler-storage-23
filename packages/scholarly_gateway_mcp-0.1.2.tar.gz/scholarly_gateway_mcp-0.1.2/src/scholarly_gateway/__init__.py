"""Scholarly Gateway MCP — V1."""
