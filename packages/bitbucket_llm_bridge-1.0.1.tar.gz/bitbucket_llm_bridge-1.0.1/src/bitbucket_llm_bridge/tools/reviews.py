from __future__ import annotations

import json
from typing import Any, Callable

from mcp.server.fastmcp import FastMCP

from ..client.base import BitbucketClient


def _resolve(value: str, default: str, name: str) -> str:
    resolved = value or default
    if not resolved:
        raise ValueError(
            f"{name} is required. Provide it as a parameter or set the "
            f"corresponding BITBUCKET_DEFAULT_* environment variable."
        )
    return resolved


def register(
    mcp: FastMCP,
    get_client: Any,
    get_defaults: Callable[[], tuple[str, str]],
) -> None:
    """Register review/approval tools on the MCP server."""

    @mcp.tool()
    async def add_reviewer(
        pr_id: int,
        reviewers: list[str],
        workspace: str = "",
        repo_slug: str = "",
    ) -> str:
        """Add reviewer(s) / approver(s) to a pull request.

        Args:
            pr_id: Pull request ID.
            reviewers: List of usernames to add as reviewers.
            workspace: Bitbucket Cloud workspace slug or Server project key. Uses BITBUCKET_DEFAULT_WORKSPACE if omitted.
            repo_slug: Repository slug. Uses BITBUCKET_DEFAULT_REPO_SLUG if omitted.
        """
        dw, dr = get_defaults()
        ws = _resolve(workspace, dw, "workspace")
        repo = _resolve(repo_slug, dr, "repo_slug")
        client: BitbucketClient = get_client()
        result = await client.add_reviewer(ws, repo, pr_id, reviewers)
        return json.dumps(result, indent=2)

    @mcp.tool()
    async def approve_pr(
        pr_id: int,
        workspace: str = "",
        repo_slug: str = "",
    ) -> str:
        """Approve a pull request as the authenticated user.

        Args:
            pr_id: Pull request ID.
            workspace: Bitbucket Cloud workspace slug or Server project key. Uses BITBUCKET_DEFAULT_WORKSPACE if omitted.
            repo_slug: Repository slug. Uses BITBUCKET_DEFAULT_REPO_SLUG if omitted.
        """
        dw, dr = get_defaults()
        ws = _resolve(workspace, dw, "workspace")
        repo = _resolve(repo_slug, dr, "repo_slug")
        client: BitbucketClient = get_client()
        result = await client.approve_pr(ws, repo, pr_id)
        return json.dumps(result, indent=2)
