from __future__ import annotations

from typing import Any, Callable

from mcp.server.fastmcp import FastMCP

from ..client.base import BitbucketClient


def _resolve(value: str, default: str, name: str) -> str:
    resolved = value or default
    if not resolved:
        raise ValueError(
            f"{name} is required. Provide it as a parameter or set the "
            f"corresponding BITBUCKET_DEFAULT_* environment variable."
        )
    return resolved


def register(
    mcp: FastMCP,
    get_client: Any,
    get_defaults: Callable[[], tuple[str, str]],
) -> None:
    """Register diff-related tools on the MCP server."""

    @mcp.tool()
    async def get_pr_diff(
        pr_id: int,
        workspace: str = "",
        repo_slug: str = "",
    ) -> str:
        """Get the full unified diff for a pull request.

        Args:
            pr_id: Pull request ID.
            workspace: Bitbucket Cloud workspace slug or Server project key. Uses BITBUCKET_DEFAULT_WORKSPACE if omitted.
            repo_slug: Repository slug. Uses BITBUCKET_DEFAULT_REPO_SLUG if omitted.
        """
        dw, dr = get_defaults()
        ws = _resolve(workspace, dw, "workspace")
        repo = _resolve(repo_slug, dr, "repo_slug")
        client: BitbucketClient = get_client()
        return await client.get_pr_diff(ws, repo, pr_id)

    @mcp.tool()
    async def get_pr_commit_diff(
        pr_id: int,
        commit_hash: str,
        workspace: str = "",
        repo_slug: str = "",
    ) -> str:
        """Get the diff for a specific commit in a pull request.

        Args:
            pr_id: Pull request ID.
            commit_hash: The full or short SHA of the commit.
            workspace: Bitbucket Cloud workspace slug or Server project key. Uses BITBUCKET_DEFAULT_WORKSPACE if omitted.
            repo_slug: Repository slug. Uses BITBUCKET_DEFAULT_REPO_SLUG if omitted.
        """
        dw, dr = get_defaults()
        ws = _resolve(workspace, dw, "workspace")
        repo = _resolve(repo_slug, dr, "repo_slug")
        client: BitbucketClient = get_client()
        return await client.get_pr_commit_diff(
            ws, repo, pr_id, commit_hash
        )
