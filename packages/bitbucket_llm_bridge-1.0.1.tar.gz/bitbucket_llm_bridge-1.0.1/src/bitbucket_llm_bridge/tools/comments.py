from __future__ import annotations

import json
from typing import Any, Callable

from mcp.server.fastmcp import FastMCP

from ..client.base import BitbucketClient


def _resolve(value: str, default: str, name: str) -> str:
    resolved = value or default
    if not resolved:
        raise ValueError(
            f"{name} is required. Provide it as a parameter or set the "
            f"corresponding BITBUCKET_DEFAULT_* environment variable."
        )
    return resolved


def register(
    mcp: FastMCP,
    get_client: Any,
    get_defaults: Callable[[], tuple[str, str]],
) -> None:
    """Register comment-related tools on the MCP server."""

    @mcp.tool()
    async def get_pr_comments(
        pr_id: int,
        workspace: str = "",
        repo_slug: str = "",
    ) -> str:
        """Read all comments on a pull request.

        Args:
            pr_id: Pull request ID.
            workspace: Bitbucket Cloud workspace slug or Server project key. Uses BITBUCKET_DEFAULT_WORKSPACE if omitted.
            repo_slug: Repository slug. Uses BITBUCKET_DEFAULT_REPO_SLUG if omitted.
        """
        dw, dr = get_defaults()
        ws = _resolve(workspace, dw, "workspace")
        repo = _resolve(repo_slug, dr, "repo_slug")
        client: BitbucketClient = get_client()
        result = await client.get_pr_comments(ws, repo, pr_id)
        return json.dumps(result, indent=2)

    @mcp.tool()
    async def add_pr_comment(
        pr_id: int,
        content: str,
        workspace: str = "",
        repo_slug: str = "",
    ) -> str:
        """Add a general comment to a pull request.

        Args:
            pr_id: Pull request ID.
            content: The comment text (markdown supported).
            workspace: Bitbucket Cloud workspace slug or Server project key. Uses BITBUCKET_DEFAULT_WORKSPACE if omitted.
            repo_slug: Repository slug. Uses BITBUCKET_DEFAULT_REPO_SLUG if omitted.
        """
        dw, dr = get_defaults()
        ws = _resolve(workspace, dw, "workspace")
        repo = _resolve(repo_slug, dr, "repo_slug")
        client: BitbucketClient = get_client()
        result = await client.add_comment(ws, repo, pr_id, content)
        return json.dumps(result, indent=2)

    @mcp.tool()
    async def add_pr_inline_comment(
        pr_id: int,
        content: str,
        file_path: str,
        line: int,
        workspace: str = "",
        repo_slug: str = "",
        line_type: str = "new",
    ) -> str:
        """Comment on a specific line of code in a pull request diff.

        Args:
            pr_id: Pull request ID.
            content: The comment text (markdown supported).
            file_path: Path of the file in the diff (e.g. "src/main.py").
            line: Line number to comment on.
            workspace: Bitbucket Cloud workspace slug or Server project key. Uses BITBUCKET_DEFAULT_WORKSPACE if omitted.
            repo_slug: Repository slug. Uses BITBUCKET_DEFAULT_REPO_SLUG if omitted.
            line_type: Which side of the diff: "new" (added lines) or "old" (removed lines).
        """
        dw, dr = get_defaults()
        ws = _resolve(workspace, dw, "workspace")
        repo = _resolve(repo_slug, dr, "repo_slug")
        client: BitbucketClient = get_client()
        result = await client.add_inline_comment(
            ws, repo, pr_id, content, file_path, line, line_type
        )
        return json.dumps(result, indent=2)

    @mcp.tool()
    async def resolve_pr_comment(
        pr_id: int,
        comment_id: int,
        workspace: str = "",
        repo_slug: str = "",
        resolved: bool = True,
    ) -> str:
        """Resolve or unresolve a comment on a pull request.

        Args:
            pr_id: Pull request ID.
            comment_id: The ID of the comment to resolve.
            workspace: Bitbucket Cloud workspace slug or Server project key. Uses BITBUCKET_DEFAULT_WORKSPACE if omitted.
            repo_slug: Repository slug. Uses BITBUCKET_DEFAULT_REPO_SLUG if omitted.
            resolved: True to resolve, False to unresolve.
        """
        dw, dr = get_defaults()
        ws = _resolve(workspace, dw, "workspace")
        repo = _resolve(repo_slug, dr, "repo_slug")
        client: BitbucketClient = get_client()
        result = await client.resolve_comment(
            ws, repo, pr_id, comment_id, resolved
        )
        return json.dumps(result, indent=2)
