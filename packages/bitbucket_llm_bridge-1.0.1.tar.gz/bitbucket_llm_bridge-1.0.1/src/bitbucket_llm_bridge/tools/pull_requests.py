from __future__ import annotations

import json
from typing import Any, Callable

from mcp.server.fastmcp import FastMCP

from ..client.base import BitbucketClient


def _resolve(value: str, default: str, name: str) -> str:
    resolved = value or default
    if not resolved:
        raise ValueError(
            f"{name} is required. Provide it as a parameter or set the "
            f"corresponding BITBUCKET_DEFAULT_* environment variable."
        )
    return resolved


def register(
    mcp: FastMCP,
    get_client: Any,
    get_defaults: Callable[[], tuple[str, str]],
) -> None:
    """Register pull-request tools on the MCP server."""

    @mcp.tool()
    async def create_pr(
        title: str,
        source_branch: str,
        destination_branch: str,
        workspace: str = "",
        repo_slug: str = "",
        description: str = "",
        reviewers: list[str] | None = None,
        close_source_branch: bool = False,
    ) -> str:
        """Create a new pull request.

        Args:
            title: PR title.
            source_branch: Source branch name.
            destination_branch: Destination/target branch name.
            workspace: Bitbucket Cloud workspace slug or Server project key. Uses BITBUCKET_DEFAULT_WORKSPACE if omitted.
            repo_slug: Repository slug. Uses BITBUCKET_DEFAULT_REPO_SLUG if omitted.
            description: PR description (markdown supported).
            reviewers: List of reviewer usernames to add.
            close_source_branch: Whether to close/delete the source branch on merge.
        """
        dw, dr = get_defaults()
        ws = _resolve(workspace, dw, "workspace")
        repo = _resolve(repo_slug, dr, "repo_slug")
        client: BitbucketClient = get_client()
        result = await client.create_pr(
            workspace=ws,
            repo_slug=repo,
            title=title,
            source_branch=source_branch,
            destination_branch=destination_branch,
            description=description,
            reviewers=reviewers,
            close_source_branch=close_source_branch,
        )
        return json.dumps(result, indent=2)

    @mcp.tool()
    async def get_pr(
        pr_id: int,
        workspace: str = "",
        repo_slug: str = "",
    ) -> str:
        """Get details of a pull request including title, description, state, author, and reviewers.

        Args:
            pr_id: Pull request ID.
            workspace: Bitbucket Cloud workspace slug or Server project key. Uses BITBUCKET_DEFAULT_WORKSPACE if omitted.
            repo_slug: Repository slug. Uses BITBUCKET_DEFAULT_REPO_SLUG if omitted.
        """
        dw, dr = get_defaults()
        ws = _resolve(workspace, dw, "workspace")
        repo = _resolve(repo_slug, dr, "repo_slug")
        client: BitbucketClient = get_client()
        result = await client.get_pr(ws, repo, pr_id)
        return json.dumps(result, indent=2)

    @mcp.tool()
    async def list_prs(
        workspace: str = "",
        repo_slug: str = "",
        state: str = "OPEN",
        author: str | None = None,
        limit: int = 25,
    ) -> str:
        """List pull requests with optional filters.

        Args:
            workspace: Bitbucket Cloud workspace slug or Server project key. Uses BITBUCKET_DEFAULT_WORKSPACE if omitted.
            repo_slug: Repository slug. Uses BITBUCKET_DEFAULT_REPO_SLUG if omitted.
            state: Filter by state: OPEN, MERGED, DECLINED, or SUPERSEDED.
            author: Filter by author username.
            limit: Maximum number of results to return (default 25).
        """
        dw, dr = get_defaults()
        ws = _resolve(workspace, dw, "workspace")
        repo = _resolve(repo_slug, dr, "repo_slug")
        client: BitbucketClient = get_client()
        result = await client.list_prs(ws, repo, state, author, limit)
        return json.dumps(result, indent=2)

    @mcp.tool()
    async def merge_pr(
        pr_id: int,
        workspace: str = "",
        repo_slug: str = "",
        merge_strategy: str = "merge_commit",
        close_source_branch: bool = True,
        message: str | None = None,
    ) -> str:
        """Merge a pull request.

        Args:
            pr_id: Pull request ID.
            workspace: Bitbucket Cloud workspace slug or Server project key. Uses BITBUCKET_DEFAULT_WORKSPACE if omitted.
            repo_slug: Repository slug. Uses BITBUCKET_DEFAULT_REPO_SLUG if omitted.
            merge_strategy: One of merge_commit, squash, or fast_forward.
            close_source_branch: Delete the source branch after merge.
            message: Custom merge commit message.
        """
        dw, dr = get_defaults()
        ws = _resolve(workspace, dw, "workspace")
        repo = _resolve(repo_slug, dr, "repo_slug")
        client: BitbucketClient = get_client()
        result = await client.merge_pr(
            ws, repo, pr_id, merge_strategy, close_source_branch, message
        )
        return json.dumps(result, indent=2)

    @mcp.tool()
    async def decline_pr(
        pr_id: int,
        workspace: str = "",
        repo_slug: str = "",
    ) -> str:
        """Decline (close without merging) a pull request.

        Args:
            pr_id: Pull request ID.
            workspace: Bitbucket Cloud workspace slug or Server project key. Uses BITBUCKET_DEFAULT_WORKSPACE if omitted.
            repo_slug: Repository slug. Uses BITBUCKET_DEFAULT_REPO_SLUG if omitted.
        """
        dw, dr = get_defaults()
        ws = _resolve(workspace, dw, "workspace")
        repo = _resolve(repo_slug, dr, "repo_slug")
        client: BitbucketClient = get_client()
        result = await client.decline_pr(ws, repo, pr_id)
        return json.dumps(result, indent=2)
