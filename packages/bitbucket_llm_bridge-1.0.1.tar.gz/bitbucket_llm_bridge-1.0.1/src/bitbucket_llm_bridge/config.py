from __future__ import annotations

import os
from dataclasses import dataclass
from enum import Enum


class BitbucketType(str, Enum):
    CLOUD = "cloud"
    SERVER = "server"


@dataclass(frozen=True)
class CloudConfig:
    username: str
    app_password: str
    base_url: str = "https://api.bitbucket.org/2.0"


@dataclass(frozen=True)
class ServerConfig:
    base_url: str
    token: str


@dataclass(frozen=True)
class BitbucketConfig:
    type: BitbucketType
    cloud: CloudConfig | None = None
    server: ServerConfig | None = None
    default_workspace: str = ""
    default_repo_slug: str = ""

    @staticmethod
    def from_env() -> BitbucketConfig:
        bb_type = BitbucketType(os.environ.get("BITBUCKET_TYPE", "cloud").lower())

        default_workspace = os.environ.get("BITBUCKET_DEFAULT_WORKSPACE", "")
        default_repo_slug = os.environ.get("BITBUCKET_DEFAULT_REPO_SLUG", "")

        if bb_type == BitbucketType.CLOUD:
            username = os.environ.get("BITBUCKET_CLOUD_USERNAME", "")
            app_password = os.environ.get("BITBUCKET_CLOUD_APP_PASSWORD", "")
            if not username or not app_password:
                raise ValueError(
                    "BITBUCKET_CLOUD_USERNAME and BITBUCKET_CLOUD_APP_PASSWORD "
                    "must be set for Bitbucket Cloud"
                )
            return BitbucketConfig(
                type=bb_type,
                cloud=CloudConfig(username=username, app_password=app_password),
                default_workspace=default_workspace,
                default_repo_slug=default_repo_slug,
            )

        server_url = os.environ.get("BITBUCKET_SERVER_URL", "")
        token = os.environ.get("BITBUCKET_SERVER_TOKEN", "")
        if not server_url or not token:
            raise ValueError(
                "BITBUCKET_SERVER_URL and BITBUCKET_SERVER_TOKEN "
                "must be set for Bitbucket Server/Data Center"
            )
        return BitbucketConfig(
            type=bb_type,
            server=ServerConfig(
                base_url=server_url.rstrip("/"),
                token=token,
            ),
            default_workspace=default_workspace,
            default_repo_slug=default_repo_slug,
        )
