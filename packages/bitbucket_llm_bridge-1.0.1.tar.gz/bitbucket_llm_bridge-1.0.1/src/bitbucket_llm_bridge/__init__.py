"""Bitbucket LLM Bridge - Model Context Protocol server for Bitbucket Cloud and Server/Data Center."""

__version__ = "1.0.1"
