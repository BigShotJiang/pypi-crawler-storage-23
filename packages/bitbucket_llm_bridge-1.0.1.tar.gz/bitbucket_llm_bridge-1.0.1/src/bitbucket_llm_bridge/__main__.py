"""Allow running with `python -m bitbucket_llm_bridge`."""

from .server import main

main()
