from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from .client.base import BitbucketClient
from .client.cloud import CloudClient
from .client.datacenter import DataCenterClient
from .config import BitbucketConfig, BitbucketType
from .tools import comments, diff, pull_requests, reviews

_client: BitbucketClient | None = None
_config: BitbucketConfig | None = None


def _load_config() -> BitbucketConfig:
    global _config
    if _config is None:
        _config = BitbucketConfig.from_env()
    return _config


def _get_client() -> BitbucketClient:
    global _client
    if _client is None:
        config = _load_config()
        if config.type == BitbucketType.CLOUD:
            assert config.cloud is not None
            _client = CloudClient(config.cloud)
        else:
            assert config.server is not None
            _client = DataCenterClient(config.server)
    return _client


def _get_defaults() -> tuple[str, str]:
    config = _load_config()
    return config.default_workspace, config.default_repo_slug


def create_server() -> FastMCP:
    mcp = FastMCP("bitbucket-llm-bridge")

    pull_requests.register(mcp, _get_client, _get_defaults)
    comments.register(mcp, _get_client, _get_defaults)
    reviews.register(mcp, _get_client, _get_defaults)
    diff.register(mcp, _get_client, _get_defaults)

    return mcp


def main() -> None:
    server = create_server()
    server.run(transport="stdio")


if __name__ == "__main__":
    main()
