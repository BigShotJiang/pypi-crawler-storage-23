from __future__ import annotations

from typing import Any

import httpx

from ..config import ServerConfig
from .base import BitbucketClient


class DataCenterClient(BitbucketClient):
    """Bitbucket Server / Data Center REST API 1.0 client."""

    def __init__(self, config: ServerConfig) -> None:
        self._config = config
        self._http = httpx.AsyncClient(
            base_url=f"{config.base_url}/rest/api/1.0",
            headers={
                "Authorization": f"Bearer {config.token}",
                "Accept": "application/json",
                "Content-Type": "application/json",
            },
            timeout=30.0,
        )

    # -- helpers --------------------------------------------------------------

    def _repo_url(self, project: str, repo_slug: str) -> str:
        return f"/projects/{project}/repos/{repo_slug}"

    def _pr_url(self, project: str, repo_slug: str, pr_id: int) -> str:
        return f"{self._repo_url(project, repo_slug)}/pull-requests/{pr_id}"

    async def _raise_for_status(self, resp: httpx.Response) -> None:
        if resp.status_code >= 400:
            body = resp.text
            raise RuntimeError(
                f"Bitbucket Server API error {resp.status_code}: {body}"
            )

    # -- Pull Requests --------------------------------------------------------

    async def create_pr(
        self,
        workspace: str,
        repo_slug: str,
        title: str,
        source_branch: str,
        destination_branch: str,
        description: str = "",
        reviewers: list[str] | None = None,
        close_source_branch: bool = False,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "title": title,
            "description": description,
            "fromRef": {"id": f"refs/heads/{source_branch}"},
            "toRef": {"id": f"refs/heads/{destination_branch}"},
            "close_source_branch": close_source_branch,
        }
        if reviewers:
            body["reviewers"] = [{"user": {"name": r}} for r in reviewers]
        resp = await self._http.post(
            f"{self._repo_url(workspace, repo_slug)}/pull-requests",
            json=body,
        )
        await self._raise_for_status(resp)
        return resp.json()

    async def get_pr(
        self, workspace: str, repo_slug: str, pr_id: int
    ) -> dict[str, Any]:
        resp = await self._http.get(self._pr_url(workspace, repo_slug, pr_id))
        await self._raise_for_status(resp)
        return resp.json()

    async def list_prs(
        self,
        workspace: str,
        repo_slug: str,
        state: str = "OPEN",
        author: str | None = None,
        limit: int = 25,
    ) -> list[dict[str, Any]]:
        params: dict[str, Any] = {"state": state, "limit": limit}
        if author:
            params["author"] = author
        resp = await self._http.get(
            f"{self._repo_url(workspace, repo_slug)}/pull-requests",
            params=params,
        )
        await self._raise_for_status(resp)
        data = resp.json()
        return data.get("values", [])

    async def merge_pr(
        self,
        workspace: str,
        repo_slug: str,
        pr_id: int,
        merge_strategy: str = "merge_commit",
        close_source_branch: bool = True,
        message: str | None = None,
    ) -> dict[str, Any]:
        pr = await self.get_pr(workspace, repo_slug, pr_id)
        body: dict[str, Any] = {"version": pr.get("version", 0)}
        if message:
            body["message"] = message
        strategy_map = {
            "merge_commit": "no-ff",
            "squash": "squash",
            "fast_forward": "ff-only",
        }
        if merge_strategy in strategy_map:
            body["strategyId"] = strategy_map[merge_strategy]
        if close_source_branch:
            body["deleteSourceRef"] = True
        resp = await self._http.post(
            f"{self._pr_url(workspace, repo_slug, pr_id)}/merge",
            json=body,
        )
        await self._raise_for_status(resp)
        return resp.json()

    async def decline_pr(
        self, workspace: str, repo_slug: str, pr_id: int
    ) -> dict[str, Any]:
        pr = await self.get_pr(workspace, repo_slug, pr_id)
        resp = await self._http.post(
            f"{self._pr_url(workspace, repo_slug, pr_id)}/decline",
            json={"version": pr.get("version", 0)},
        )
        await self._raise_for_status(resp)
        return resp.json()

    # -- Reviews / Approvals --------------------------------------------------

    async def add_reviewer(
        self,
        workspace: str,
        repo_slug: str,
        pr_id: int,
        reviewers: list[str],
    ) -> dict[str, Any]:
        pr = await self.get_pr(workspace, repo_slug, pr_id)
        existing = pr.get("reviewers", [])
        existing_names = {r.get("user", {}).get("name") for r in existing}
        new_reviewers = [
            {"user": {"name": r}} for r in reviewers if r not in existing_names
        ]
        all_reviewers = existing + new_reviewers
        resp = await self._http.put(
            self._pr_url(workspace, repo_slug, pr_id),
            json={
                "title": pr["title"],
                "reviewers": all_reviewers,
                "version": pr.get("version", 0),
            },
        )
        await self._raise_for_status(resp)
        return resp.json()

    async def approve_pr(
        self, workspace: str, repo_slug: str, pr_id: int
    ) -> dict[str, Any]:
        resp = await self._http.post(
            f"{self._pr_url(workspace, repo_slug, pr_id)}/approve",
        )
        await self._raise_for_status(resp)
        return resp.json()

    # -- Comments -------------------------------------------------------------

    async def get_pr_comments(
        self, workspace: str, repo_slug: str, pr_id: int
    ) -> list[dict[str, Any]]:
        comments: list[dict[str, Any]] = []
        start = 0
        while True:
            resp = await self._http.get(
                f"{self._pr_url(workspace, repo_slug, pr_id)}/activities",
                params={"start": start, "limit": 100},
            )
            await self._raise_for_status(resp)
            data = resp.json()
            for activity in data.get("values", []):
                if activity.get("action") == "COMMENTED":
                    comment = activity.get("comment", {})
                    if comment:
                        comments.append(comment)
            if data.get("isLastPage", True):
                break
            start = data.get("nextPageStart", start + 100)
        return comments

    async def add_comment(
        self, workspace: str, repo_slug: str, pr_id: int, content: str
    ) -> dict[str, Any]:
        resp = await self._http.post(
            f"{self._pr_url(workspace, repo_slug, pr_id)}/comments",
            json={"text": content},
        )
        await self._raise_for_status(resp)
        return resp.json()

    async def add_inline_comment(
        self,
        workspace: str,
        repo_slug: str,
        pr_id: int,
        content: str,
        file_path: str,
        line: int,
        line_type: str = "new",
    ) -> dict[str, Any]:
        line_type_map = {"new": "ADDED", "old": "REMOVED", "context": "CONTEXT"}
        anchor = {
            "path": file_path,
            "line": line,
            "lineType": line_type_map.get(line_type, "ADDED"),
            "fileType": "TO" if line_type == "new" else "FROM",
        }
        resp = await self._http.post(
            f"{self._pr_url(workspace, repo_slug, pr_id)}/comments",
            json={"text": content, "anchor": anchor},
        )
        await self._raise_for_status(resp)
        return resp.json()

    async def resolve_comment(
        self,
        workspace: str,
        repo_slug: str,
        pr_id: int,
        comment_id: int,
        resolved: bool = True,
    ) -> dict[str, Any]:
        url = f"{self._pr_url(workspace, repo_slug, pr_id)}/comments/{comment_id}"
        comment = (await self._http.get(url)).json()
        version = comment.get("version", 0)
        body: dict[str, Any] = {
            "version": version,
            "text": comment.get("text", ""),
        }
        if resolved:
            body["state"] = "RESOLVED"
        else:
            body["state"] = "OPEN"
        resp = await self._http.put(url, json=body)
        await self._raise_for_status(resp)
        return resp.json()

    # -- Diffs ----------------------------------------------------------------

    async def get_pr_diff(
        self, workspace: str, repo_slug: str, pr_id: int
    ) -> str:
        resp = await self._http.get(
            f"{self._pr_url(workspace, repo_slug, pr_id)}/diff",
            headers={"Accept": "text/plain"},
        )
        await self._raise_for_status(resp)
        return resp.text

    async def get_pr_commit_diff(
        self,
        workspace: str,
        repo_slug: str,
        pr_id: int,
        commit_hash: str,
    ) -> str:
        resp = await self._http.get(
            f"{self._pr_url(workspace, repo_slug, pr_id)}/commits/{commit_hash}/diff",
            headers={"Accept": "text/plain"},
        )
        await self._raise_for_status(resp)
        return resp.text

    # -- Lifecycle ------------------------------------------------------------

    async def close(self) -> None:
        await self._http.aclose()
