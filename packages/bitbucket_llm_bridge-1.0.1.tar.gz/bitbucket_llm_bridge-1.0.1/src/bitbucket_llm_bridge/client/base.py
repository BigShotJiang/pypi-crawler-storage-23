from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class BitbucketClient(ABC):
    """Abstract interface for Bitbucket API operations.

    Concrete implementations exist for Bitbucket Cloud (API v2.0)
    and Bitbucket Server / Data Center (REST API 1.0).
    """

    # -- Pull Requests --------------------------------------------------------

    @abstractmethod
    async def create_pr(
        self,
        workspace: str,
        repo_slug: str,
        title: str,
        source_branch: str,
        destination_branch: str,
        description: str = "",
        reviewers: list[str] | None = None,
        close_source_branch: bool = False,
    ) -> dict[str, Any]: ...

    @abstractmethod
    async def get_pr(
        self,
        workspace: str,
        repo_slug: str,
        pr_id: int,
    ) -> dict[str, Any]: ...

    @abstractmethod
    async def list_prs(
        self,
        workspace: str,
        repo_slug: str,
        state: str = "OPEN",
        author: str | None = None,
        limit: int = 25,
    ) -> list[dict[str, Any]]: ...

    @abstractmethod
    async def merge_pr(
        self,
        workspace: str,
        repo_slug: str,
        pr_id: int,
        merge_strategy: str = "merge_commit",
        close_source_branch: bool = True,
        message: str | None = None,
    ) -> dict[str, Any]: ...

    @abstractmethod
    async def decline_pr(
        self,
        workspace: str,
        repo_slug: str,
        pr_id: int,
    ) -> dict[str, Any]: ...

    # -- Reviews / Approvals --------------------------------------------------

    @abstractmethod
    async def add_reviewer(
        self,
        workspace: str,
        repo_slug: str,
        pr_id: int,
        reviewers: list[str],
    ) -> dict[str, Any]: ...

    @abstractmethod
    async def approve_pr(
        self,
        workspace: str,
        repo_slug: str,
        pr_id: int,
    ) -> dict[str, Any]: ...

    # -- Comments -------------------------------------------------------------

    @abstractmethod
    async def get_pr_comments(
        self,
        workspace: str,
        repo_slug: str,
        pr_id: int,
    ) -> list[dict[str, Any]]: ...

    @abstractmethod
    async def add_comment(
        self,
        workspace: str,
        repo_slug: str,
        pr_id: int,
        content: str,
    ) -> dict[str, Any]: ...

    @abstractmethod
    async def add_inline_comment(
        self,
        workspace: str,
        repo_slug: str,
        pr_id: int,
        content: str,
        file_path: str,
        line: int,
        line_type: str = "new",
    ) -> dict[str, Any]: ...

    @abstractmethod
    async def resolve_comment(
        self,
        workspace: str,
        repo_slug: str,
        pr_id: int,
        comment_id: int,
        resolved: bool = True,
    ) -> dict[str, Any]: ...

    # -- Diffs ----------------------------------------------------------------

    @abstractmethod
    async def get_pr_diff(
        self,
        workspace: str,
        repo_slug: str,
        pr_id: int,
    ) -> str: ...

    @abstractmethod
    async def get_pr_commit_diff(
        self,
        workspace: str,
        repo_slug: str,
        pr_id: int,
        commit_hash: str,
    ) -> str: ...

    # -- Lifecycle ------------------------------------------------------------

    @abstractmethod
    async def close(self) -> None: ...
