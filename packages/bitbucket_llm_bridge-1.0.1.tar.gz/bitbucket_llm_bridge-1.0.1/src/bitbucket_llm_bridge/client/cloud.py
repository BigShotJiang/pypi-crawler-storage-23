from __future__ import annotations

from typing import Any

import httpx

from ..config import CloudConfig
from .base import BitbucketClient


class CloudClient(BitbucketClient):
    """Bitbucket Cloud API v2.0 client."""

    def __init__(self, config: CloudConfig) -> None:
        self._config = config
        self._http = httpx.AsyncClient(
            base_url=config.base_url,
            auth=(config.username, config.app_password),
            headers={"Accept": "application/json"},
            timeout=30.0,
        )

    # -- helpers --------------------------------------------------------------

    def _repo_url(self, workspace: str, repo_slug: str) -> str:
        return f"/repositories/{workspace}/{repo_slug}"

    def _pr_url(self, workspace: str, repo_slug: str, pr_id: int) -> str:
        return f"{self._repo_url(workspace, repo_slug)}/pullrequests/{pr_id}"

    async def _raise_for_status(self, resp: httpx.Response) -> None:
        if resp.status_code >= 400:
            body = resp.text
            raise RuntimeError(
                f"Bitbucket Cloud API error {resp.status_code}: {body}"
            )

    # -- Pull Requests --------------------------------------------------------

    async def create_pr(
        self,
        workspace: str,
        repo_slug: str,
        title: str,
        source_branch: str,
        destination_branch: str,
        description: str = "",
        reviewers: list[str] | None = None,
        close_source_branch: bool = False,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "title": title,
            "source": {"branch": {"name": source_branch}},
            "destination": {"branch": {"name": destination_branch}},
            "description": description,
            "close_source_branch": close_source_branch,
        }
        if reviewers:
            body["reviewers"] = [{"username": r} for r in reviewers]
        resp = await self._http.post(
            f"{self._repo_url(workspace, repo_slug)}/pullrequests",
            json=body,
        )
        await self._raise_for_status(resp)
        return resp.json()

    async def get_pr(
        self, workspace: str, repo_slug: str, pr_id: int
    ) -> dict[str, Any]:
        resp = await self._http.get(self._pr_url(workspace, repo_slug, pr_id))
        await self._raise_for_status(resp)
        return resp.json()

    async def list_prs(
        self,
        workspace: str,
        repo_slug: str,
        state: str = "OPEN",
        author: str | None = None,
        limit: int = 25,
    ) -> list[dict[str, Any]]:
        params: dict[str, Any] = {"state": state, "pagelen": limit}
        if author:
            params["q"] = f'author.username="{author}"'
        resp = await self._http.get(
            f"{self._repo_url(workspace, repo_slug)}/pullrequests",
            params=params,
        )
        await self._raise_for_status(resp)
        data = resp.json()
        return data.get("values", [])

    async def merge_pr(
        self,
        workspace: str,
        repo_slug: str,
        pr_id: int,
        merge_strategy: str = "merge_commit",
        close_source_branch: bool = True,
        message: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "type": "pullrequest",
            "merge_strategy": merge_strategy,
            "close_source_branch": close_source_branch,
        }
        if message:
            body["message"] = message
        resp = await self._http.post(
            f"{self._pr_url(workspace, repo_slug, pr_id)}/merge",
            json=body,
        )
        await self._raise_for_status(resp)
        return resp.json()

    async def decline_pr(
        self, workspace: str, repo_slug: str, pr_id: int
    ) -> dict[str, Any]:
        resp = await self._http.post(
            f"{self._pr_url(workspace, repo_slug, pr_id)}/decline",
        )
        await self._raise_for_status(resp)
        return resp.json()

    # -- Reviews / Approvals --------------------------------------------------

    async def add_reviewer(
        self,
        workspace: str,
        repo_slug: str,
        pr_id: int,
        reviewers: list[str],
    ) -> dict[str, Any]:
        pr = await self.get_pr(workspace, repo_slug, pr_id)
        existing = pr.get("reviewers", [])
        existing_usernames = {r.get("username") for r in existing}
        new_reviewers = [
            {"username": r} for r in reviewers if r not in existing_usernames
        ]
        updated_reviewers = existing + new_reviewers
        resp = await self._http.put(
            self._pr_url(workspace, repo_slug, pr_id),
            json={"reviewers": updated_reviewers},
        )
        await self._raise_for_status(resp)
        return resp.json()

    async def approve_pr(
        self, workspace: str, repo_slug: str, pr_id: int
    ) -> dict[str, Any]:
        resp = await self._http.post(
            f"{self._pr_url(workspace, repo_slug, pr_id)}/approve",
        )
        await self._raise_for_status(resp)
        return resp.json()

    # -- Comments -------------------------------------------------------------

    async def get_pr_comments(
        self, workspace: str, repo_slug: str, pr_id: int
    ) -> list[dict[str, Any]]:
        comments: list[dict[str, Any]] = []
        url: str | None = f"{self._pr_url(workspace, repo_slug, pr_id)}/comments"
        while url:
            resp = await self._http.get(url)
            await self._raise_for_status(resp)
            data = resp.json()
            comments.extend(data.get("values", []))
            url = data.get("next")
        return comments

    async def add_comment(
        self, workspace: str, repo_slug: str, pr_id: int, content: str
    ) -> dict[str, Any]:
        resp = await self._http.post(
            f"{self._pr_url(workspace, repo_slug, pr_id)}/comments",
            json={"content": {"raw": content}},
        )
        await self._raise_for_status(resp)
        return resp.json()

    async def add_inline_comment(
        self,
        workspace: str,
        repo_slug: str,
        pr_id: int,
        content: str,
        file_path: str,
        line: int,
        line_type: str = "new",
    ) -> dict[str, Any]:
        inline: dict[str, Any] = {"path": file_path}
        if line_type == "old":
            inline["from"] = line
        else:
            inline["to"] = line
        resp = await self._http.post(
            f"{self._pr_url(workspace, repo_slug, pr_id)}/comments",
            json={"content": {"raw": content}, "inline": inline},
        )
        await self._raise_for_status(resp)
        return resp.json()

    async def resolve_comment(
        self,
        workspace: str,
        repo_slug: str,
        pr_id: int,
        comment_id: int,
        resolved: bool = True,
    ) -> dict[str, Any]:
        url = f"{self._pr_url(workspace, repo_slug, pr_id)}/comments/{comment_id}"
        if resolved:
            body = {"resolution": {"type": "pullrequest_comment_resolution"}}
        else:
            body = {"resolution": None}  # type: ignore[dict-item]
        resp = await self._http.put(url, json=body)
        await self._raise_for_status(resp)
        return resp.json()

    # -- Diffs ----------------------------------------------------------------

    async def get_pr_diff(
        self, workspace: str, repo_slug: str, pr_id: int
    ) -> str:
        resp = await self._http.get(
            f"{self._pr_url(workspace, repo_slug, pr_id)}/diff",
            headers={"Accept": "text/plain"},
        )
        await self._raise_for_status(resp)
        return resp.text

    async def get_pr_commit_diff(
        self,
        workspace: str,
        repo_slug: str,
        pr_id: int,
        commit_hash: str,
    ) -> str:
        resp = await self._http.get(
            f"{self._repo_url(workspace, repo_slug)}/diff/{commit_hash}",
            headers={"Accept": "text/plain"},
        )
        await self._raise_for_status(resp)
        return resp.text

    # -- Lifecycle ------------------------------------------------------------

    async def close(self) -> None:
        await self._http.aclose()
