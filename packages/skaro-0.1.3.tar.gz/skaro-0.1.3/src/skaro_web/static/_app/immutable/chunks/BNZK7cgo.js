import{c,a as p}from"./BqgPKE-B.js";import"./zzPCSqzL.js";import{f as i}from"./6mnWt3YZ.js";import{I as l,s as m}from"./BfTcz1DI.js";import{l as d,s as f}from"./BJ0MJm0w.js";function k(t,o){const e=d(o,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const r=[["path",{d:"M20 6 9 17l-5-5"}]];l(t,f({name:"check"},()=>e,{get iconNode(){return r},children:(a,$)=>{var s=c(),n=i(s);m(n,o,"default",{}),p(a,s)},$$slots:{default:!0}}))}export{k as C};
