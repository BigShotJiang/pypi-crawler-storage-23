import{c as n,a as c}from"./BqgPKE-B.js";import"./zzPCSqzL.js";import{f as d}from"./6mnWt3YZ.js";import{I as l,s as m}from"./BfTcz1DI.js";import{l as i,s as f}from"./BJ0MJm0w.js";function P(o,a){const s=i(a,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const e=[["path",{d:"M11 21.73a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73z"}],["path",{d:"M12 22V12"}],["path",{d:"m3.3 7 7.703 4.734a2 2 0 0 0 1.994 0L20.7 7"}],["path",{d:"m7.5 4.27 9 5.15"}]];l(o,f({name:"package"},()=>s,{get iconNode(){return e},children:(r,$)=>{var t=n(),p=d(t);m(p,a,"default",{}),c(r,t)},$$slots:{default:!0}}))}export{P};
