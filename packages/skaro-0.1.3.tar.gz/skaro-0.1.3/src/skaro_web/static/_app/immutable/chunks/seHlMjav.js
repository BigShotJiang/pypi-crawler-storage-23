import{c as i,a as p}from"./BqgPKE-B.js";import"./zzPCSqzL.js";import{f as l}from"./6mnWt3YZ.js";import{I as c,s as d}from"./BfTcz1DI.js";import{l as m,s as f}from"./BJ0MJm0w.js";function v(e,o){const t=m(o,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const r=[["polyline",{points:"16 18 22 12 16 6"}],["polyline",{points:"8 6 2 12 8 18"}]];c(e,f({name:"code"},()=>t,{get iconNode(){return r},children:(n,$)=>{var s=i(),a=l(s);d(a,o,"default",{}),p(n,s)},$$slots:{default:!0}}))}export{v as C};
