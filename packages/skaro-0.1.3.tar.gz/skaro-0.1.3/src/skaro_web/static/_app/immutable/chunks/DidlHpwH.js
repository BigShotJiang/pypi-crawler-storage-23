import{c as p,a as i}from"./BqgPKE-B.js";import"./zzPCSqzL.js";import{f as l}from"./6mnWt3YZ.js";import{I as c,s as d}from"./BfTcz1DI.js";import{l as m,s as f}from"./BJ0MJm0w.js";function P(t,s){const r=m(s,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const a=[["path",{d:"M5 12h14"}],["path",{d:"M12 5v14"}]];c(t,f({name:"plus"},()=>r,{get iconNode(){return a},children:(e,$)=>{var o=p(),n=l(o);d(n,s,"default",{}),i(e,o)},$$slots:{default:!0}}))}export{P};
