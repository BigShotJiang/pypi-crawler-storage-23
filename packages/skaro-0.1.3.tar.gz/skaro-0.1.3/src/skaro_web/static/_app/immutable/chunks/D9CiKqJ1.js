import{c as n,a as d}from"./BqgPKE-B.js";import"./zzPCSqzL.js";import{f as i}from"./6mnWt3YZ.js";import{I as l,s as c}from"./BfTcz1DI.js";import{l as m,s as f}from"./BJ0MJm0w.js";function g(o,t){const e=m(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const s=[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4"}],["path",{d:"M10 9H8"}],["path",{d:"M16 13H8"}],["path",{d:"M16 17H8"}]];l(o,f({name:"file-text"},()=>e,{get iconNode(){return s},children:(r,h)=>{var a=n(),p=i(a);c(p,t,"default",{}),d(r,a)},$$slots:{default:!0}}))}export{g as F};
