import{c as n,a as c}from"./BqgPKE-B.js";import"./zzPCSqzL.js";import{f as d}from"./6mnWt3YZ.js";import{I as i,s as m}from"./BfTcz1DI.js";import{l as f,s as l}from"./BJ0MJm0w.js";function M(o,s){const r=f(s,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const a=[["path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"}],["path",{d:"M21 3v5h-5"}],["path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"}],["path",{d:"M8 16H3v5"}]];i(o,l({name:"refresh-cw"},()=>r,{get iconNode(){return a},children:(e,h)=>{var t=n(),p=d(t);m(p,s,"default",{}),c(e,t)},$$slots:{default:!0}}))}export{M as R};
