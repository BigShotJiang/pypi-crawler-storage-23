import{c as p,a as l}from"./BqgPKE-B.js";import"./zzPCSqzL.js";import{f as i}from"./6mnWt3YZ.js";import{I as c,s as m}from"./BfTcz1DI.js";import{l as d,s as f}from"./BJ0MJm0w.js";function z(s,a){const t=d(a,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const r=[["path",{d:"M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"}]];c(s,f({name:"zap"},()=>t,{get iconNode(){return r},children:(e,$)=>{var o=p(),n=i(o);m(n,a,"default",{}),l(e,o)},$$slots:{default:!0}}))}export{z as Z};
