import{c as l,a as d}from"./BqgPKE-B.js";import"./zzPCSqzL.js";import{f as c}from"./6mnWt3YZ.js";import{I as i,s as p}from"./BfTcz1DI.js";import{l as $,s as m}from"./BJ0MJm0w.js";function z(e,a){const o=$(a,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const s=[["path",{d:"M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"}],["path",{d:"m15 5 4 4"}]];i(e,m({name:"pencil"},()=>o,{get iconNode(){return s},children:(n,f)=>{var t=l(),r=c(t);p(r,a,"default",{}),d(n,t)},$$slots:{default:!0}}))}function M(e,a){const o=$(a,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const s=[["path",{d:"M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z"}],["path",{d:"M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7"}],["path",{d:"M7 3v4a1 1 0 0 0 1 1h7"}]];i(e,m({name:"save"},()=>o,{get iconNode(){return s},children:(n,f)=>{var t=l(),r=c(t);p(r,a,"default",{}),d(n,t)},$$slots:{default:!0}}))}export{z as P,M as S};
