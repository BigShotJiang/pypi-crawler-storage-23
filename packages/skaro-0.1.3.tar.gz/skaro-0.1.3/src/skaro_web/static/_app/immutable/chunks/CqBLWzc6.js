import{c as l,a as d}from"./BqgPKE-B.js";import"./zzPCSqzL.js";import{f as p}from"./6mnWt3YZ.js";import{I as c,s as i}from"./BfTcz1DI.js";import{l as $,s as m}from"./BJ0MJm0w.js";function M(t,a){const o=$(a,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const s=[["path",{d:"m6 14 1.5-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.54 6a2 2 0 0 1-1.95 1.5H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H18a2 2 0 0 1 2 2v2"}]];c(t,m({name:"folder-open"},()=>o,{get iconNode(){return s},children:(r,f)=>{var e=l(),n=p(e);i(n,a,"default",{}),d(r,e)},$$slots:{default:!0}}))}function A(t,a){const o=$(a,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const s=[["path",{d:"M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z"}],["path",{d:"M20 3v4"}],["path",{d:"M22 5h-4"}],["path",{d:"M4 17v2"}],["path",{d:"M5 18H3"}]];c(t,m({name:"sparkles"},()=>o,{get iconNode(){return s},children:(r,f)=>{var e=l(),n=p(e);i(n,a,"default",{}),d(r,e)},$$slots:{default:!0}}))}export{M as F,A as S};
