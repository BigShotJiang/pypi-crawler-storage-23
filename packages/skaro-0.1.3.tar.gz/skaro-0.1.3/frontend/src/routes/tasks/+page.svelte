<script>
	import TasksPage from '$lib/pages/TasksPage.svelte';
</script>

<TasksPage />
