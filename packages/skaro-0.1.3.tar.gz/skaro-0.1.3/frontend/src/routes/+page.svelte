<script>
	import DashboardPage from '$lib/pages/DashboardPage.svelte';
</script>

<DashboardPage />
