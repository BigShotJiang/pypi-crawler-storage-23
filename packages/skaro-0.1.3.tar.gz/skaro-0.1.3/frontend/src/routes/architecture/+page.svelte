<script>
	import ArchitecturePage from '$lib/pages/ArchitecturePage.svelte';
</script>

<ArchitecturePage />
