<script>
	import DevPlanPage from '$lib/pages/DevPlanPage.svelte';
</script>

<DevPlanPage />
