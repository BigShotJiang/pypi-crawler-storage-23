<script>
	import SettingsPage from '$lib/pages/SettingsPage.svelte';
</script>

<SettingsPage />
