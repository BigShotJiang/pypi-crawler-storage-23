# Implementation Plan: <task name>

## Stage 1: <title>
**Goal:** <what this stage achieves>
**Dependencies:** none | stage N

### Inputs
- <what's needed to start>

### Outputs
- <what this stage produces — list ALL files with full paths>

### Risks
- <potential issues>

### DoD
- [ ] <check 1>
- [ ] <check 2>

---

## Stage 2: <title>
**Goal:** <what this stage achieves>
**Dependencies:** stage 1

### Inputs
- <what's needed>

### Outputs
- <what's produced — list ALL files with full paths>

### Risks
- <potential issues>

### DoD
- [ ] <check 1>
- [ ] <check 2>
