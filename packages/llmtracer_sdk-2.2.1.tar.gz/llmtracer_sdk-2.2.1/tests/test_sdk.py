"""Comprehensive tests for llmtracer v2.0 SDK.

All LLM API calls are mocked — no real API calls.
"""

import asyncio
import sys
import types
import uuid
from io import StringIO
from unittest import mock

import pytest

# ═══════════════════════════════════════════════════════════════════════════════
# Helpers: fake OpenAI / Anthropic modules for patching tests
# ═══════════════════════════════════════════════════════════════════════════════


class _FakeUsage:
    """Mimics openai.types.completion_usage.CompletionUsage."""

    def __init__(self, prompt_tokens=100, completion_tokens=50):
        self.prompt_tokens = prompt_tokens
        self.completion_tokens = completion_tokens


class _FakeOpenAIResponse:
    """Mimics openai ChatCompletion response."""

    def __init__(self, model="gpt-4o"):
        self.model = model
        self.usage = _FakeUsage(prompt_tokens=100, completion_tokens=50)
        self.choices = [types.SimpleNamespace(message=types.SimpleNamespace(content="hello"))]


class _FakeAnthropicUsage:
    def __init__(self, input_tokens=200, output_tokens=80):
        self.input_tokens = input_tokens
        self.output_tokens = output_tokens


class _FakeAnthropicResponse:
    """Mimics anthropic Message response."""

    def __init__(self, model="claude-sonnet-4-5-20250929"):
        self.model = model
        self.usage = _FakeAnthropicUsage()
        self.stop_reason = "end_turn"
        self.content = [types.SimpleNamespace(text="hello")]


def _install_fake_openai():
    """Install a fake openai module into sys.modules for testing."""
    # Build module hierarchy: openai.resources.chat.completions
    openai_mod = types.ModuleType("openai")
    openai_mod.__version__ = "1.51.0"

    resources_mod = types.ModuleType("openai.resources")
    chat_mod = types.ModuleType("openai.resources.chat")
    completions_mod = types.ModuleType("openai.resources.chat.completions")

    class Completions:
        @staticmethod
        def create(*args, **kwargs):
            return _FakeOpenAIResponse(model=kwargs.get("model", "gpt-4o"))

    class AsyncCompletions:
        @staticmethod
        async def create(*args, **kwargs):
            return _FakeOpenAIResponse(model=kwargs.get("model", "gpt-4o"))

    completions_mod.Completions = Completions
    completions_mod.AsyncCompletions = AsyncCompletions

    chat_mod.completions = completions_mod
    resources_mod.chat = chat_mod
    openai_mod.resources = resources_mod

    sys.modules["openai"] = openai_mod
    sys.modules["openai.resources"] = resources_mod
    sys.modules["openai.resources.chat"] = chat_mod
    sys.modules["openai.resources.chat.completions"] = completions_mod

    return openai_mod, Completions, AsyncCompletions


class _FakeMessageStream:
    """Mimics Anthropic MessageStream returned inside a .stream() context."""

    def __init__(self, model="claude-sonnet-4-5-20250929"):
        self._final = _FakeAnthropicResponse(model=model)

    def get_final_message(self):
        return self._final

    def __iter__(self):
        return iter([])


class _FakeStreamManager:
    """Mimics Anthropic MessageStreamManager (sync context manager)."""

    def __init__(self, model="claude-sonnet-4-5-20250929"):
        self._model = model
        self._stream = None

    def __enter__(self):
        self._stream = _FakeMessageStream(model=self._model)
        return self._stream

    def __exit__(self, *exc):
        return False


class _FakeAsyncMessageStream:
    """Mimics Anthropic AsyncMessageStream."""

    def __init__(self, model="claude-sonnet-4-5-20250929"):
        self._final = _FakeAnthropicResponse(model=model)

    def get_final_message(self):
        return self._final

    def __aiter__(self):
        return self

    async def __anext__(self):
        raise StopAsyncIteration


class _FakeAsyncStreamManager:
    """Mimics Anthropic AsyncMessageStreamManager (async context manager)."""

    def __init__(self, model="claude-sonnet-4-5-20250929"):
        self._model = model
        self._stream = None

    async def __aenter__(self):
        self._stream = _FakeAsyncMessageStream(model=self._model)
        return self._stream

    async def __aexit__(self, *exc):
        return False


def _install_fake_anthropic():
    """Install a fake anthropic module into sys.modules for testing."""
    anthropic_mod = types.ModuleType("anthropic")
    anthropic_mod.__version__ = "0.39.0"

    resources_mod = types.ModuleType("anthropic.resources")
    messages_mod = types.ModuleType("anthropic.resources.messages")

    class Messages:
        @staticmethod
        def create(*args, **kwargs):
            return _FakeAnthropicResponse(model=kwargs.get("model", "claude-sonnet-4-5-20250929"))

        @staticmethod
        def stream(*args, **kwargs):
            return _FakeStreamManager(model=kwargs.get("model", "claude-sonnet-4-5-20250929"))

    class AsyncMessages:
        @staticmethod
        async def create(*args, **kwargs):
            return _FakeAnthropicResponse(model=kwargs.get("model", "claude-sonnet-4-5-20250929"))

        @staticmethod
        def stream(*args, **kwargs):
            return _FakeAsyncStreamManager(model=kwargs.get("model", "claude-sonnet-4-5-20250929"))

    messages_mod.Messages = Messages
    messages_mod.AsyncMessages = AsyncMessages

    resources_mod.messages = messages_mod
    anthropic_mod.resources = resources_mod

    sys.modules["anthropic"] = anthropic_mod
    sys.modules["anthropic.resources"] = resources_mod
    sys.modules["anthropic.resources.messages"] = messages_mod

    return anthropic_mod, Messages, AsyncMessages


def _cleanup_fake_modules():
    """Remove fake modules from sys.modules."""
    for key in list(sys.modules):
        if key.startswith("openai") or key.startswith("anthropic"):
            del sys.modules[key]


# ═══════════════════════════════════════════════════════════════════════════════
# Fixtures
# ═══════════════════════════════════════════════════════════════════════════════


@pytest.fixture(autouse=True)
def _reset_state():
    """Reset all global state between tests."""
    import llmtracer
    from llmtracer import _config, _patcher, _transport, _context

    # Reset config
    _config.api_key = ""
    _config.debug = False
    _config.enabled = False
    _config.session_id = ""
    _config.endpoint = "https://us-central1-llmtracer-alt.cloudfunctions.net/v1Events"

    # Reset transport and save original enqueue
    _transport._reset()
    from llmtracer._transport import enqueue as _original_enqueue
    _transport.enqueue = _original_enqueue

    # Unpatch anything
    _patcher.unpatch_all()

    # Clean fake modules
    _cleanup_fake_modules()

    yield

    # Teardown
    _config.enabled = False
    _transport._reset()
    _transport.enqueue = _original_enqueue
    _patcher.unpatch_all()
    _cleanup_fake_modules()


# ═══════════════════════════════════════════════════════════════════════════════
# 1. Crash-proof tests
# ═══════════════════════════════════════════════════════════════════════════════


class TestCrashProof:
    """SDK NEVER impacts the customer's app."""

    def test_init_no_providers_installed(self):
        """init() with no providers doesn't throw."""
        import llmtracer

        # No openai or anthropic in sys.modules
        llmtracer.init(api_key="lt_test123")
        # Should not raise

    def test_init_no_api_key(self):
        """init() without API key disables tracing silently."""
        import llmtracer
        from llmtracer import _config

        llmtracer.init()
        assert not _config.enabled

    def test_init_no_api_key_debug(self, capsys):
        """init(debug=True) without API key prints message."""
        import llmtracer

        llmtracer.init(debug=True)
        captured = capsys.readouterr()
        assert "No API key found" in captured.out

    def test_wrapper_with_broken_context_still_calls_original(self):
        """Even if context capture fails, original function runs."""
        import llmtracer
        from llmtracer import _config, _wrapper

        _config.enabled = True
        _config.api_key = "lt_test"

        call_log = []

        def original_fn(*args, **kwargs):
            call_log.append("called")
            return "result"

        def bad_parse(result):
            raise RuntimeError("parse failed")

        wrapped = _wrapper.make_sync_wrapper(original_fn, "test", bad_parse, lambda *a: None)

        result = wrapped(model="test")
        assert result == "result"
        assert len(call_log) == 1

    def test_stream_wrapping_failure_returns_raw_stream(self):
        """If stream wrapping fails, raw stream is returned."""
        import llmtracer
        from llmtracer import _config, _wrapper

        _config.enabled = True
        _config.api_key = "lt_test"

        raw_stream = iter([1, 2, 3])

        def original_fn(*args, **kwargs):
            return raw_stream

        def bad_wrap(*args):
            raise RuntimeError("wrap failed")

        wrapped = _wrapper.make_sync_wrapper(original_fn, "test", lambda r: {}, bad_wrap)

        result = wrapped(stream=True)
        assert result is raw_stream

    def test_flush_never_throws(self):
        """flush() swallows all errors."""
        import llmtracer

        llmtracer.flush()  # no init, no transport — should not throw

    def test_trace_exception_returns_function(self):
        """If trace setup fails, original function is returned."""
        import llmtracer
        from llmtracer import _context

        # Temporarily break push
        original_push = _context.push
        _context.push = mock.Mock(side_effect=RuntimeError("broken"))

        try:
            @llmtracer.trace
            def my_func():
                return 42

            # Should still work even though trace broke
            # (trace() catches the exception and returns fn unmodified)
            assert callable(my_func)
        finally:
            _context.push = original_push


# ═══════════════════════════════════════════════════════════════════════════════
# 2. Patching tests
# ═══════════════════════════════════════════════════════════════════════════════


class TestPatching:
    """After init(), provider methods are wrapped."""

    def test_openai_patched(self):
        """OpenAI completions.create is wrapped after init."""
        _openai_mod, Completions, AsyncCompletions = _install_fake_openai()

        import llmtracer

        original_create = Completions.create
        llmtracer.init(api_key="lt_test123")

        # create should now be wrapped
        assert Completions.create is not original_create

    def test_anthropic_patched(self):
        """Anthropic messages.create is wrapped after init."""
        _anth_mod, Messages, AsyncMessages = _install_fake_anthropic()

        import llmtracer

        original_create = Messages.create
        llmtracer.init(api_key="lt_test123")

        assert Messages.create is not original_create

    def test_openai_event_enqueued(self):
        """After a call, an event is enqueued with correct fields."""
        _install_fake_openai()

        import llmtracer
        from llmtracer import _transport

        llmtracer.init(api_key="lt_test123")

        # Patch transport to capture events
        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            from openai.resources.chat.completions import Completions
            Completions.create(model="gpt-4o", messages=[{"role": "user", "content": "hi"}])

            assert len(events) == 1
            event = events[0]
            assert event["provider"] == "openai"
            assert event["model"] == "gpt-4o"
            assert event["input_tokens"] == 100
            assert event["output_tokens"] == 50
            assert event["status"] == "success"
            assert "event_id" in event
            assert "timestamp" in event
            assert "latency_ms" in event
        finally:
            _transport.enqueue = original_enqueue

    def test_anthropic_event_enqueued(self):
        """Anthropic call enqueues event with correct fields."""
        _install_fake_anthropic()

        import llmtracer
        from llmtracer import _transport

        llmtracer.init(api_key="lt_test123")

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            from anthropic.resources.messages import Messages
            Messages.create(model="claude-sonnet-4-5-20250929", messages=[{"role": "user", "content": "hi"}])

            assert len(events) == 1
            event = events[0]
            assert event["provider"] == "anthropic"
            assert event["model"] == "claude-sonnet-4-5-20250929"
            assert event["input_tokens"] == 200
            assert event["output_tokens"] == 80
        finally:
            _transport.enqueue = original_enqueue

    def test_unpatch_restores_original(self):
        """unpatch_all() restores original methods."""
        _openai_mod, Completions, _ = _install_fake_openai()

        import llmtracer
        from llmtracer import _patcher

        original_create = Completions.create
        llmtracer.init(api_key="lt_test123")
        assert Completions.create is not original_create

        _patcher.unpatch_all()
        assert Completions.create is original_create

    def test_no_double_patch(self):
        """Calling init() twice doesn't double-wrap."""
        _install_fake_openai()

        import llmtracer

        llmtracer.init(api_key="lt_test123")
        from openai.resources.chat.completions import Completions
        first_wrapped = Completions.create

        # Re-init
        llmtracer.init(api_key="lt_test123")
        assert Completions.create is first_wrapped

    def test_disabled_skips_wrapper(self):
        """When disabled, wrapper passes through to original."""
        _install_fake_openai()

        import llmtracer
        from llmtracer import _config, _transport

        llmtracer.init(api_key="lt_test123")
        _config.enabled = False

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            from openai.resources.chat.completions import Completions
            result = Completions.create(model="gpt-4o", messages=[])

            assert result.model == "gpt-4o"
            assert len(events) == 0  # nothing enqueued when disabled
        finally:
            _transport.enqueue = original_enqueue


# ═══════════════════════════════════════════════════════════════════════════════
# 3. Caller capture tests
# ═══════════════════════════════════════════════════════════════════════════════


class TestCallerCapture:
    """caller_file points to the calling code, not wrapper internals."""

    def test_caller_file_points_to_test(self):
        """caller_file should be THIS file, not _wrapper.py or _caller.py."""
        _install_fake_openai()

        import llmtracer
        from llmtracer import _transport

        llmtracer.init(api_key="lt_test123")

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            from openai.resources.chat.completions import Completions
            Completions.create(model="gpt-4o", messages=[])

            assert len(events) == 1
            caller_file = events[0].get("caller_file", "")
            # Should point to this test file, not internals
            assert "test_sdk.py" in caller_file or caller_file == "", \
                f"caller_file should be test_sdk.py, got: {caller_file}"
            # Should NOT point to wrapper internals
            assert "_wrapper.py" not in caller_file
            assert "_caller.py" not in caller_file
        finally:
            _transport.enqueue = original_enqueue

    def test_caller_info_graceful_fallback(self):
        """get_caller_info returns empty dict on failure."""
        from llmtracer._caller import get_caller_info

        # Very deep depth should fail gracefully
        result = get_caller_info(depth=9999)
        assert result == {}


# ═══════════════════════════════════════════════════════════════════════════════
# 4. Context propagation tests
# ═══════════════════════════════════════════════════════════════════════════════


class TestContextPropagation:
    """Events inside trace() inherit context tags."""

    def test_trace_context_manager_tags(self):
        """Events inside trace(conversation_id='x') have that tag."""
        _install_fake_openai()

        import llmtracer
        from llmtracer import _transport

        llmtracer.init(api_key="lt_test123")

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            from openai.resources.chat.completions import Completions

            with llmtracer.trace(conversation_id="conv_abc", user_id="tim"):
                Completions.create(model="gpt-4o", messages=[])

            assert len(events) == 1
            assert events[0]["tags"]["conversation_id"] == "conv_abc"
            assert events[0]["tags"]["user_id"] == "tim"
            assert "trace_id" in events[0]
            assert "span_id" in events[0]
        finally:
            _transport.enqueue = original_enqueue

    def test_nested_traces_merge_tags(self):
        """Nested trace() calls merge parent + child tags."""
        _install_fake_openai()

        import llmtracer
        from llmtracer import _transport

        llmtracer.init(api_key="lt_test123")

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            from openai.resources.chat.completions import Completions

            with llmtracer.trace(user_id="tim"):
                with llmtracer.trace(phase="planning"):
                    Completions.create(model="gpt-4o", messages=[])

            assert len(events) == 1
            assert events[0]["tags"]["user_id"] == "tim"
            assert events[0]["tags"]["phase"] == "planning"
            assert events[0].get("parent_span_id") is not None
        finally:
            _transport.enqueue = original_enqueue

    def test_trace_context_cleanup(self):
        """Context is properly cleaned up after trace exits."""
        import llmtracer
        from llmtracer import _context

        assert _context.get_current() is None

        with llmtracer.trace(test="value"):
            ctx = _context.get_current()
            assert ctx is not None
            assert ctx.tags["test"] == "value"

        assert _context.get_current() is None

    def test_no_trace_no_context(self):
        """Without trace(), events have no trace_id/tags."""
        _install_fake_openai()

        import llmtracer
        from llmtracer import _transport

        llmtracer.init(api_key="lt_test123")

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            from openai.resources.chat.completions import Completions
            Completions.create(model="gpt-4o", messages=[])

            assert len(events) == 1
            assert "trace_id" not in events[0]
            assert "tags" not in events[0]
        finally:
            _transport.enqueue = original_enqueue


# ═══════════════════════════════════════════════════════════════════════════════
# 5. Streaming tests
# ═══════════════════════════════════════════════════════════════════════════════


class _FakeStreamChunk:
    """Mimics an OpenAI stream chunk."""

    def __init__(self, model="gpt-4o", usage=None):
        self.model = model
        self.choices = [types.SimpleNamespace(delta=types.SimpleNamespace(content="hi"))]
        self.usage = usage


class TestStreaming:
    """Wrapped streams yield same chunks and record events."""

    def test_openai_sync_stream_passthrough(self):
        """Wrapped stream yields identical chunks to original."""
        _install_fake_openai()

        import llmtracer
        from llmtracer import _transport

        llmtracer.init(api_key="lt_test123")

        # Replace the create to return a stream
        chunks = [
            _FakeStreamChunk(),
            _FakeStreamChunk(),
            _FakeStreamChunk(usage=_FakeUsage(prompt_tokens=100, completion_tokens=25)),
        ]

        from openai.resources.chat.completions import Completions
        original_wrapped = Completions.create

        # We need a create that returns an iterator when stream=True
        def stream_create(*args, **kwargs):
            if kwargs.get("stream"):
                return iter(chunks)
            return _FakeOpenAIResponse()

        # Patch at the *original* level (before our wrapper)
        from llmtracer import _patcher
        key = "openai.resources.chat.completions.Completions.create"
        if key in _patcher._originals:
            cls, method_name, _ = _patcher._originals[key]
            _patcher._originals[key] = (cls, method_name, stream_create)
            # Re-wrap with the new original
            from llmtracer._providers import _openai
            from llmtracer._wrapper import make_sync_wrapper
            new_wrapped = make_sync_wrapper(stream_create, "openai", _openai.parse_response, _openai.wrap_stream)
            setattr(cls, method_name, new_wrapped)

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            result = Completions.create(model="gpt-4o", messages=[], stream=True)
            received = list(result)
            assert len(received) == 3
            # Each chunk should be the same object
            for i, chunk in enumerate(received):
                assert chunk is chunks[i]
            # Event recorded after stream completion
            assert len(events) == 1
            assert events[0]["input_tokens"] == 100
            assert events[0]["output_tokens"] == 25
        finally:
            _transport.enqueue = original_enqueue

    def test_anthropic_sync_stream_passthrough(self):
        """Anthropic stream wrapper extracts tokens from events."""
        from llmtracer._providers._anthropic import _WrappedStream

        msg_start = types.SimpleNamespace(
            type="message_start",
            message=types.SimpleNamespace(
                model="claude-sonnet-4-5-20250929",
                usage=types.SimpleNamespace(input_tokens=150),
            ),
        )
        content = types.SimpleNamespace(type="content_block_delta")
        msg_delta = types.SimpleNamespace(
            type="message_delta",
            usage=types.SimpleNamespace(output_tokens=60),
        )

        raw_stream = iter([msg_start, content, msg_delta])

        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            context = {"context": {}, "caller": {}}
            wrapped = _WrappedStream(raw_stream, context, 500, {"model": "claude-sonnet-4-5-20250929"})

            received = list(wrapped)
            assert len(received) == 3
            assert received[0] is msg_start

            assert len(events) == 1
            assert events[0]["input_tokens"] == 150
            assert events[0]["output_tokens"] == 60
            assert events[0]["model"] == "claude-sonnet-4-5-20250929"
        finally:
            _transport.enqueue = original_enqueue

    def test_anthropic_sync_stream_manager(self):
        """Messages.stream() context manager captures event via get_final_message."""
        _install_fake_anthropic()

        import llmtracer
        from llmtracer import _transport

        llmtracer.init(api_key="lt_test123")

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            from anthropic.resources.messages import Messages
            with Messages.stream(model="claude-sonnet-4-5-20250929", messages=[]) as stream:
                final = stream.get_final_message()

            assert len(events) == 1
            assert events[0]["provider"] == "anthropic"
            assert events[0]["model"] == "claude-sonnet-4-5-20250929"
            assert events[0]["input_tokens"] == 200
            assert events[0]["output_tokens"] == 80
        finally:
            _transport.enqueue = original_enqueue

    def test_anthropic_stream_method_patched(self):
        """Messages.stream is wrapped after init."""
        _anth_mod, Messages, AsyncMessages = _install_fake_anthropic()
        import llmtracer
        original_stream = Messages.stream
        llmtracer.init(api_key="lt_test123")
        assert Messages.stream is not original_stream
        assert AsyncMessages.stream is not original_stream


# ═══════════════════════════════════════════════════════════════════════════════
# 6. Async tests
# ═══════════════════════════════════════════════════════════════════════════════


class TestAsync:
    """Async wrapper works correctly."""

    @pytest.mark.asyncio
    async def test_async_openai_call(self):
        """Async wrapper captures events."""
        _install_fake_openai()

        import llmtracer
        from llmtracer import _transport

        llmtracer.init(api_key="lt_test123")

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            from openai.resources.chat.completions import AsyncCompletions
            result = await AsyncCompletions.create(model="gpt-4o", messages=[])

            assert result.model == "gpt-4o"
            assert len(events) == 1
            assert events[0]["provider"] == "openai"
            assert events[0]["model"] == "gpt-4o"
        finally:
            _transport.enqueue = original_enqueue

    @pytest.mark.asyncio
    async def test_async_anthropic_call(self):
        """Async Anthropic wrapper captures events."""
        _install_fake_anthropic()

        import llmtracer
        from llmtracer import _transport

        llmtracer.init(api_key="lt_test123")

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            from anthropic.resources.messages import AsyncMessages
            result = await AsyncMessages.create(model="claude-sonnet-4-5-20250929", messages=[])

            assert result.model == "claude-sonnet-4-5-20250929"
            assert len(events) == 1
            assert events[0]["provider"] == "anthropic"
        finally:
            _transport.enqueue = original_enqueue

    @pytest.mark.asyncio
    async def test_async_anthropic_stream_manager(self):
        """AsyncMessages.stream() async context manager captures event."""
        _install_fake_anthropic()

        import llmtracer
        from llmtracer import _transport

        llmtracer.init(api_key="lt_test123")

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            from anthropic.resources.messages import AsyncMessages
            async with AsyncMessages.stream(model="claude-sonnet-4-5-20250929", messages=[]) as stream:
                final = stream.get_final_message()

            assert len(events) == 1
            assert events[0]["provider"] == "anthropic"
            assert events[0]["model"] == "claude-sonnet-4-5-20250929"
            assert events[0]["input_tokens"] == 200
            assert events[0]["output_tokens"] == 80
        finally:
            _transport.enqueue = original_enqueue

    @pytest.mark.asyncio
    async def test_async_context_propagation(self):
        """Context propagates correctly in async code."""
        _install_fake_openai()

        import llmtracer
        from llmtracer import _transport

        llmtracer.init(api_key="lt_test123")

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            from openai.resources.chat.completions import AsyncCompletions

            with llmtracer.trace(user_id="async_user"):
                await AsyncCompletions.create(model="gpt-4o", messages=[])

            assert len(events) == 1
            assert events[0]["tags"]["user_id"] == "async_user"
        finally:
            _transport.enqueue = original_enqueue

    @pytest.mark.asyncio
    async def test_async_trace_decorator(self):
        """@llmtracer.trace works on async functions."""
        _install_fake_openai()

        import llmtracer
        from llmtracer import _transport

        llmtracer.init(api_key="lt_test123")

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            from openai.resources.chat.completions import AsyncCompletions

            @llmtracer.trace(phase="async_phase")
            async def do_async_work():
                return await AsyncCompletions.create(model="gpt-4o", messages=[])

            result = await do_async_work()
            assert result.model == "gpt-4o"
            assert len(events) == 1
            assert events[0]["tags"]["phase"] == "async_phase"
        finally:
            _transport.enqueue = original_enqueue


# ═══════════════════════════════════════════════════════════════════════════════
# 7. Bare decorator tests
# ═══════════════════════════════════════════════════════════════════════════════


class TestBareDecorator:
    """@llmtracer.trace (no parens) works."""

    def test_bare_decorator_sync(self):
        """@llmtracer.trace without parens wraps sync function."""
        import llmtracer

        @llmtracer.trace
        def my_func(x):
            return x * 2

        assert my_func(5) == 10
        assert my_func.__name__ == "my_func"

    @pytest.mark.asyncio
    async def test_bare_decorator_async(self):
        """@llmtracer.trace without parens wraps async function."""
        import llmtracer

        @llmtracer.trace
        async def my_async_func(x):
            return x * 3

        result = await my_async_func(5)
        assert result == 15
        assert my_async_func.__name__ == "my_async_func"

    def test_decorator_with_kwargs(self):
        """@llmtracer.trace(phase='x') wraps function with tags."""
        _install_fake_openai()

        import llmtracer
        from llmtracer import _transport

        llmtracer.init(api_key="lt_test123")

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            from openai.resources.chat.completions import Completions

            @llmtracer.trace(phase="planning")
            def plan():
                return Completions.create(model="gpt-4o", messages=[])

            result = plan()
            assert result.model == "gpt-4o"
            assert len(events) == 1
            assert events[0]["tags"]["phase"] == "planning"
        finally:
            _transport.enqueue = original_enqueue

    def test_bare_decorator_creates_trace_context(self):
        """@llmtracer.trace creates a trace context (trace_id/span_id)."""
        _install_fake_openai()

        import llmtracer
        from llmtracer import _transport

        llmtracer.init(api_key="lt_test123")

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            from openai.resources.chat.completions import Completions

            @llmtracer.trace
            def plan():
                return Completions.create(model="gpt-4o", messages=[])

            plan()
            assert len(events) == 1
            assert "trace_id" in events[0]
            assert "span_id" in events[0]
        finally:
            _transport.enqueue = original_enqueue


# ═══════════════════════════════════════════════════════════════════════════════
# 8. Debug mode tests
# ═══════════════════════════════════════════════════════════════════════════════


class TestDebugMode:
    """init(debug=True) prints expected output."""

    def test_debug_init_prints_patched(self, capsys):
        """Debug mode prints patch confirmations."""
        _install_fake_openai()
        _install_fake_anthropic()

        import llmtracer

        llmtracer.init(api_key="lt_test123", debug=True)
        captured = capsys.readouterr()

        assert "Patched openai" in captured.out
        assert "Patched anthropic" in captured.out
        assert "Ready" in captured.out

    def test_debug_prints_capture(self, capsys):
        """Debug mode prints per-call capture line."""
        _install_fake_openai()

        import llmtracer
        from llmtracer import _config

        llmtracer.init(api_key="lt_test123", debug=True)

        # Suppress transport HTTP calls
        from llmtracer import _transport
        _transport.enqueue = lambda e: None

        capsys.readouterr()  # clear init output

        from openai.resources.chat.completions import Completions
        Completions.create(model="gpt-4o", messages=[])

        captured = capsys.readouterr()
        assert "openai/gpt-4o" in captured.out
        assert "100" in captured.out  # input tokens
        assert "50" in captured.out  # output tokens


# ═══════════════════════════════════════════════════════════════════════════════
# 9. Transport tests
# ═══════════════════════════════════════════════════════════════════════════════


class TestTransport:
    """Transport batching and HTTP delivery."""

    def test_enqueue_and_flush(self):
        """Events can be enqueued and flushed."""
        from llmtracer import _transport, _config

        _config.api_key = "lt_test"
        _config.enabled = True

        _transport.enqueue({"test": "event1"})
        _transport.enqueue({"test": "event2"})

        # Mock urlopen to capture the request
        with mock.patch("urllib.request.urlopen") as mock_urlopen:
            mock_resp = mock.MagicMock()
            mock_resp.status = 200
            mock_resp.__enter__ = mock.Mock(return_value=mock_resp)
            mock_resp.__exit__ = mock.Mock(return_value=False)
            mock_urlopen.return_value = mock_resp

            _transport.flush()

            assert mock_urlopen.called
            call_args = mock_urlopen.call_args
            req = call_args[0][0]
            assert req.method == "POST"
            assert req.get_header("Content-type") == "application/json"
            assert req.get_header("Authorization") == "Bearer lt_test"

            import json
            payload = json.loads(req.data)
            assert len(payload["events"]) == 2

    def test_flush_empty_queue_noop(self):
        """Flushing empty queue makes no HTTP calls."""
        from llmtracer import _transport

        with mock.patch("urllib.request.urlopen") as mock_urlopen:
            _transport.flush()
            assert not mock_urlopen.called

    def test_flush_failure_requeues(self):
        """Failed flush re-queues events."""
        from llmtracer import _transport, _config

        _config.api_key = "lt_test"

        _transport.enqueue({"test": "event"})

        with mock.patch("urllib.request.urlopen", side_effect=Exception("network error")):
            _transport.flush()

        # Event should be re-queued
        assert not _transport._event_queue.empty()

    def test_requeue_limit(self):
        """Re-queue is limited to prevent memory leaks."""
        from llmtracer import _transport, _config

        _config.api_key = "lt_test"

        # Enqueue more than _MAX_REQUEUE
        for i in range(150):
            _transport.enqueue({"i": i})

        with mock.patch("urllib.request.urlopen", side_effect=Exception("fail")):
            _transport.flush()

        # Should have at most _MAX_REQUEUE items
        count = 0
        while not _transport._event_queue.empty():
            _transport._event_queue.get_nowait()
            count += 1
        assert count <= _transport._MAX_REQUEUE

    def test_atexit_registered_on_start(self):
        """start() registers _atexit_flush with atexit."""
        from llmtracer import _transport

        with mock.patch("llmtracer._transport.atexit.register") as mock_register:
            _transport.start()
            mock_register.assert_called_once_with(_transport._atexit_flush)

    def test_atexit_registered_only_once(self):
        """Multiple start() calls only register atexit once."""
        from llmtracer import _transport

        with mock.patch("llmtracer._transport.atexit.register") as mock_register:
            _transport.start()
            # stop and start again
            _transport.stop()
            _transport.start()
            # Should still be only one registration since flag persists
            assert mock_register.call_count == 1

    def test_reset_unregisters_atexit(self):
        """_reset() unregisters the atexit handler."""
        from llmtracer import _transport

        with mock.patch("llmtracer._transport.atexit.register"):
            _transport.start()

        assert _transport._atexit_registered is True

        with mock.patch("llmtracer._transport.atexit.unregister") as mock_unregister:
            _transport._reset()
            mock_unregister.assert_called_once_with(_transport._atexit_flush)

        assert _transport._atexit_registered is False

    def test_atexit_flush_skips_empty_queue(self):
        """_atexit_flush does nothing when queue is empty."""
        from llmtracer import _transport

        with mock.patch("urllib.request.urlopen") as mock_urlopen:
            _transport._atexit_flush()
            assert not mock_urlopen.called

    def test_atexit_flush_uses_short_timeout(self):
        """_atexit_flush uses a 3s timeout for urlopen."""
        from llmtracer import _transport, _config

        _config.api_key = "lt_test"
        _transport.enqueue({"test": "event"})

        with mock.patch("urllib.request.urlopen") as mock_urlopen:
            mock_resp = mock.MagicMock()
            mock_resp.status = 200
            mock_resp.__enter__ = mock.Mock(return_value=mock_resp)
            mock_resp.__exit__ = mock.Mock(return_value=False)
            mock_urlopen.return_value = mock_resp

            _transport._atexit_flush()

            assert mock_urlopen.called
            _, kwargs = mock_urlopen.call_args
            assert kwargs["timeout"] == 3

    def test_atexit_flush_never_raises(self):
        """_atexit_flush swallows all exceptions silently."""
        from llmtracer import _transport

        _transport.enqueue({"test": "event"})

        with mock.patch("urllib.request.urlopen", side_effect=Exception("network down")):
            # Must not raise
            _transport._atexit_flush()

    def test_atexit_flush_never_prints(self, capsys):
        """_atexit_flush produces no output even in debug mode."""
        from llmtracer import _transport, _config

        _config.api_key = "lt_test"
        _config.debug = True

        _transport.enqueue({"test": "event"})

        with mock.patch("urllib.request.urlopen") as mock_urlopen:
            mock_resp = mock.MagicMock()
            mock_resp.status = 200
            mock_resp.__enter__ = mock.Mock(return_value=mock_resp)
            mock_resp.__exit__ = mock.Mock(return_value=False)
            mock_urlopen.return_value = mock_resp

            _transport._atexit_flush()

        captured = capsys.readouterr()
        assert captured.out == ""

    def test_atexit_flush_no_output_on_failure(self, capsys):
        """_atexit_flush produces no output even when flush fails in debug mode."""
        from llmtracer import _transport, _config

        _config.api_key = "lt_test"
        _config.debug = True

        _transport.enqueue({"test": "event"})

        with mock.patch("urllib.request.urlopen", side_effect=Exception("fail")):
            _transport._atexit_flush()

        captured = capsys.readouterr()
        assert captured.out == ""


# ═══════════════════════════════════════════════════════════════════════════════
# 10. Schema tests
# ═══════════════════════════════════════════════════════════════════════════════


class TestSchema:
    """Event schema correctness."""

    def test_event_has_required_fields(self):
        """Built events have all required fields."""
        from llmtracer._schema import build_event

        event = build_event(
            context_data={"trace_id": "t1", "span_id": "s1", "tags": {"k": "v"}},
            response_data={"provider": "openai", "model": "gpt-4o", "input_tokens": 100, "output_tokens": 50, "status": "success"},
            latency_ms=1200,
            caller_info={"caller_file": "app.py", "caller_function": "main", "caller_line": 10},
        )

        assert event["event_id"]  # non-empty uuid
        assert event["timestamp"]
        assert event["provider"] == "openai"
        assert event["model"] == "gpt-4o"
        assert event["input_tokens"] == 100
        assert event["output_tokens"] == 50
        assert event["latency_ms"] == 1200
        assert event["status"] == "success"
        assert event["caller_file"] == "app.py"
        assert event["caller_function"] == "main"
        assert event["caller_line"] == 10
        assert event["trace_id"] == "t1"
        assert event["span_id"] == "s1"
        assert event["tags"] == {"k": "v"}
        assert event["sdk_version"] == "2.0.0"
        assert event["sdk_language"] == "python"

    def test_event_without_context(self):
        """Events without trace context omit trace fields."""
        from llmtracer._schema import build_event

        event = build_event(
            context_data=None,
            response_data={"provider": "openai", "model": "gpt-4o", "input_tokens": 0, "output_tokens": 0, "status": "success"},
            latency_ms=500,
            caller_info={},
        )

        assert "trace_id" not in event
        assert "tags" not in event
        assert event["provider"] == "openai"


# ═══════════════════════════════════════════════════════════════════════════════
# 11. Public API surface tests
# ═══════════════════════════════════════════════════════════════════════════════


class TestPublicAPI:
    """Only init, trace, flush, __version__ are public."""

    def test_public_exports(self):
        import llmtracer

        assert llmtracer.__all__ == ["init", "trace", "flush", "__version__"]

    def test_version(self):
        import llmtracer

        assert llmtracer.__version__ == "2.2.1"

    def test_no_langchain_exports(self):
        """No LangChain-related names in the public API."""
        import llmtracer

        assert not hasattr(llmtracer, "LLMTracerCallbackHandler")
        assert not hasattr(llmtracer, "LLMTracer")

    def test_init_reads_env_var(self):
        """init() reads LLMTRACER_API_KEY from env."""
        import llmtracer
        from llmtracer import _config

        with mock.patch.dict("os.environ", {"LLMTRACER_API_KEY": "lt_from_env"}):
            llmtracer.init()

        assert _config.api_key == "lt_from_env"
        assert _config.enabled is True


# ═══════════════════════════════════════════════════════════════════════════════
# 12. Google Gemini token extraction tests
# ═══════════════════════════════════════════════════════════════════════════════


class TestGoogleTokenExtraction:
    """Token extraction handles multiple Google SDK versions."""

    def test_old_style_field_names(self):
        """Extracts tokens from older google-generativeai style fields."""
        from llmtracer._providers._google import _extract_tokens_from_usage

        usage = types.SimpleNamespace(
            prompt_token_count=1835,
            candidates_token_count=383,
            total_token_count=2218,
        )
        inp, out = _extract_tokens_from_usage(usage)
        assert inp == 1835
        assert out == 383

    def test_new_style_field_names(self):
        """Extracts tokens from newer google-genai style fields."""
        from llmtracer._providers._google import _extract_tokens_from_usage

        usage = types.SimpleNamespace(
            input_tokens=1835,
            output_tokens=383,
        )
        inp, out = _extract_tokens_from_usage(usage)
        assert inp == 1835
        assert out == 383

    def test_prompt_tokens_completion_tokens(self):
        """Extracts tokens from prompt_tokens/completion_tokens style fields."""
        from llmtracer._providers._google import _extract_tokens_from_usage

        usage = types.SimpleNamespace(
            prompt_tokens=500,
            completion_tokens=200,
        )
        inp, out = _extract_tokens_from_usage(usage)
        assert inp == 500
        assert out == 200

    def test_cached_content_tokens_added(self):
        """Cached content tokens are added to input count."""
        from llmtracer._providers._google import _extract_tokens_from_usage

        usage = types.SimpleNamespace(
            prompt_token_count=1835,
            candidates_token_count=383,
            total_token_count=5300,
            cached_content_token_count=3082,
        )
        inp, out = _extract_tokens_from_usage(usage)
        assert inp == 1835 + 3082
        assert out == 383

    def test_cached_tokens_not_double_counted(self):
        """If cached == input, don't double-count."""
        from llmtracer._providers._google import _extract_tokens_from_usage

        usage = types.SimpleNamespace(
            prompt_token_count=500,
            candidates_token_count=100,
            total_token_count=600,
            cached_content_token_count=500,
        )
        inp, out = _extract_tokens_from_usage(usage)
        # cached == input, so should not add
        assert inp == 500
        assert out == 100

    def test_none_usage_returns_zeros(self):
        """None usage returns (0, 0)."""
        from llmtracer._providers._google import _extract_tokens_from_usage

        inp, out = _extract_tokens_from_usage(None)
        assert inp == 0
        assert out == 0

    def test_empty_usage_returns_zeros(self):
        """Usage with no matching fields returns (0, 0)."""
        from llmtracer._providers._google import _extract_tokens_from_usage

        usage = types.SimpleNamespace()
        inp, out = _extract_tokens_from_usage(usage)
        assert inp == 0
        assert out == 0

    def test_total_token_fallback(self):
        """Falls back to total_token_count when extracted values are too small."""
        from llmtracer._providers._google import _extract_tokens_from_usage

        # Simulates the bug scenario: only total available, no per-field tokens
        usage = types.SimpleNamespace(
            total_token_count=5300,
        )
        inp, out = _extract_tokens_from_usage(usage)
        assert inp == 5300
        assert out == 0

    def test_total_fallback_with_output(self):
        """Total fallback subtracts output_tokens when available."""
        from llmtracer._providers._google import _extract_tokens_from_usage

        usage = types.SimpleNamespace(
            candidates_token_count=383,
            total_token_count=5300,
        )
        inp, out = _extract_tokens_from_usage(usage)
        # input should be total - output since extracted input (0) is < 10% of total
        assert inp == 5300 - 383
        assert out == 383

    def test_no_fallback_when_values_reasonable(self):
        """No fallback when extracted values are reasonable vs total."""
        from llmtracer._providers._google import _extract_tokens_from_usage

        usage = types.SimpleNamespace(
            prompt_token_count=1835,
            candidates_token_count=383,
            total_token_count=2218,
        )
        inp, out = _extract_tokens_from_usage(usage)
        # 1835+383=2218, which is >= 10% of 2218, so no fallback
        assert inp == 1835
        assert out == 383

    def test_non_int_values_ignored(self):
        """Non-integer values are ignored gracefully."""
        from llmtracer._providers._google import _extract_tokens_from_usage

        usage = types.SimpleNamespace(
            prompt_token_count="not a number",
            candidates_token_count=None,
        )
        inp, out = _extract_tokens_from_usage(usage)
        assert inp == 0
        assert out == 0

    def test_parse_response_integration(self):
        """parse_response uses the shared helper correctly."""
        from llmtracer._providers._google import parse_response

        response = types.SimpleNamespace(
            usage_metadata=types.SimpleNamespace(
                prompt_token_count=1835,
                candidates_token_count=383,
                total_token_count=2218,
            ),
            model_version="gemini-2.0-flash",
        )
        result = parse_response(response)
        assert result["provider"] == "google"
        assert result["model"] == "gemini-2.0-flash"
        assert result["input_tokens"] == 1835
        assert result["output_tokens"] == 383
        assert result["status"] == "success"

    def test_parse_response_new_style(self):
        """parse_response works with new-style SDK fields."""
        from llmtracer._providers._google import parse_response

        response = types.SimpleNamespace(
            usage_metadata=types.SimpleNamespace(
                input_tokens=2000,
                output_tokens=500,
            ),
            model="gemini-1.5-pro",
        )
        result = parse_response(response)
        assert result["model"] == "gemini-1.5-pro"
        assert result["input_tokens"] == 2000
        assert result["output_tokens"] == 500

    def test_thoughts_token_count_added_to_output(self):
        """Gemini 2.5 thinking tokens are added to output count."""
        from llmtracer._providers._google import _extract_tokens_from_usage

        usage = types.SimpleNamespace(
            prompt_token_count=1000,
            candidates_token_count=200,
            total_token_count=3700,
            thoughts_token_count=2500,
        )
        inp, out = _extract_tokens_from_usage(usage)
        assert inp == 1000
        assert out == 200 + 2500  # base output + thinking tokens

    def test_tool_use_prompt_tokens_added_to_input(self):
        """Tool/function definition tokens are added to input count."""
        from llmtracer._providers._google import _extract_tokens_from_usage

        usage = types.SimpleNamespace(
            prompt_token_count=1000,
            candidates_token_count=200,
            total_token_count=1650,
            tool_use_prompt_token_count=450,
        )
        inp, out = _extract_tokens_from_usage(usage)
        assert inp == 1000 + 450  # base input + tool tokens
        assert out == 200

    def test_all_billable_fields_combined(self):
        """All billable fields work together: cached, tools, thoughts."""
        from llmtracer._providers._google import _extract_tokens_from_usage

        usage = types.SimpleNamespace(
            prompt_token_count=1000,
            candidates_token_count=200,
            total_token_count=6750,
            cached_content_token_count=3000,
            tool_use_prompt_token_count=550,
            thoughts_token_count=2000,
        )
        inp, out = _extract_tokens_from_usage(usage)
        assert inp == 1000 + 3000 + 550  # base + cached + tools
        assert out == 200 + 2000  # base + thoughts

    def test_debug_logging(self, capsys):
        """Debug mode logs detailed token breakdown."""
        from llmtracer._providers._google import _extract_tokens_from_usage
        from llmtracer import _config

        _config.debug = True
        try:
            usage = types.SimpleNamespace(
                prompt_token_count=100,
                candidates_token_count=50,
                total_token_count=150,
            )
            _extract_tokens_from_usage(usage)
            captured = capsys.readouterr()
            assert "[llmtracer] Google tokens extracted: in=100 out=50" in captured.out
            assert "[llmtracer] Google tokens —" in captured.out
        finally:
            _config.debug = False

    def test_debug_logging_with_thoughts_and_tools(self, capsys):
        """Debug mode logs thinking and tool token breakdown."""
        from llmtracer._providers._google import _extract_tokens_from_usage
        from llmtracer import _config

        _config.debug = True
        try:
            usage = types.SimpleNamespace(
                prompt_token_count=1000,
                candidates_token_count=200,
                total_token_count=4000,
                thoughts_token_count=2500,
                tool_use_prompt_token_count=300,
            )
            _extract_tokens_from_usage(usage)
            captured = capsys.readouterr()
            assert "thoughts=2500" in captured.out
            assert "tools=300" in captured.out
            assert "in=1300 out=2700" in captured.out
        finally:
            _config.debug = False

    def test_stream_wrapper_token_extraction(self):
        """Sync stream wrapper uses shared helper for token extraction."""
        from llmtracer._providers._google import _WrappedStream
        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        # Create chunks with new-style token fields on the last chunk
        chunk1 = types.SimpleNamespace(text="hello")
        chunk2 = types.SimpleNamespace(
            text="world",
            usage_metadata=types.SimpleNamespace(
                input_tokens=1835,
                output_tokens=383,
            ),
        )

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            context = {"context": {}, "caller": {}}
            wrapped = _WrappedStream(iter([chunk1, chunk2]), context, 500, {"model": "gemini-2.0-flash"})
            list(wrapped)

            assert len(events) == 1
            assert events[0]["input_tokens"] == 1835
            assert events[0]["output_tokens"] == 383
        finally:
            _transport.enqueue = original_enqueue


# ═══════════════════════════════════════════════════════════════════════════════
# 13. OpenAI token detail tests
# ═══════════════════════════════════════════════════════════════════════════════


class TestOpenAITokenDetails:
    """OpenAI reasoning/cached tokens are included in base counts — verify no double-counting."""

    def test_reasoning_tokens_not_double_counted(self):
        """reasoning_tokens in completion_tokens_details don't inflate output."""
        from llmtracer._providers._openai import parse_response

        usage = types.SimpleNamespace(
            prompt_tokens=500,
            completion_tokens=800,  # includes 600 reasoning
            completion_tokens_details=types.SimpleNamespace(
                reasoning_tokens=600,
                accepted_prediction_tokens=0,
                rejected_prediction_tokens=0,
            ),
            prompt_tokens_details=None,
        )
        response = types.SimpleNamespace(model="o3-mini", usage=usage)
        result = parse_response(response)
        # Should use completion_tokens as-is (reasoning already included)
        assert result["output_tokens"] == 800
        assert result["input_tokens"] == 500

    def test_cached_tokens_not_double_counted(self):
        """cached_tokens in prompt_tokens_details don't inflate input."""
        from llmtracer._providers._openai import parse_response

        usage = types.SimpleNamespace(
            prompt_tokens=1000,  # includes 400 cached
            completion_tokens=200,
            completion_tokens_details=None,
            prompt_tokens_details=types.SimpleNamespace(cached_tokens=400),
        )
        response = types.SimpleNamespace(model="gpt-4o", usage=usage)
        result = parse_response(response)
        assert result["input_tokens"] == 1000
        assert result["output_tokens"] == 200

    def test_debug_logging_shows_details(self, capsys):
        """Debug mode logs reasoning and cached token breakdown."""
        from llmtracer._providers._openai import parse_response
        from llmtracer import _config

        _config.debug = True
        try:
            usage = types.SimpleNamespace(
                prompt_tokens=1000,
                completion_tokens=800,
                completion_tokens_details=types.SimpleNamespace(
                    reasoning_tokens=600,
                    accepted_prediction_tokens=50,
                    rejected_prediction_tokens=25,
                ),
                prompt_tokens_details=types.SimpleNamespace(cached_tokens=400),
            )
            response = types.SimpleNamespace(model="o3-mini", usage=usage)
            parse_response(response)
            captured = capsys.readouterr()
            assert "reasoning=600" in captured.out
            assert "cached=400" in captured.out
            assert "accepted_pred=50" in captured.out
            assert "rejected_pred=25" in captured.out
        finally:
            _config.debug = False

    def test_prediction_tokens_in_details(self):
        """Predicted output tokens (accepted + rejected) are in completion_tokens."""
        from llmtracer._providers._openai import parse_response

        usage = types.SimpleNamespace(
            prompt_tokens=500,
            completion_tokens=300,  # includes accepted + rejected prediction tokens
            completion_tokens_details=types.SimpleNamespace(
                reasoning_tokens=0,
                accepted_prediction_tokens=100,
                rejected_prediction_tokens=50,
            ),
            prompt_tokens_details=None,
        )
        response = types.SimpleNamespace(model="gpt-4o", usage=usage)
        result = parse_response(response)
        # completion_tokens already includes everything
        assert result["output_tokens"] == 300

    def test_no_details_fields(self):
        """Works fine when details fields are absent."""
        from llmtracer._providers._openai import parse_response

        usage = types.SimpleNamespace(prompt_tokens=100, completion_tokens=50)
        response = types.SimpleNamespace(model="gpt-4o", usage=usage)
        result = parse_response(response)
        assert result["input_tokens"] == 100
        assert result["output_tokens"] == 50


# ═══════════════════════════════════════════════════════════════════════════════
# 14. Anthropic cache token tests
# ═══════════════════════════════════════════════════════════════════════════════


class TestAnthropicCacheTokens:
    """Anthropic cache tokens are added to input totals."""

    def test_cache_creation_tokens_added(self):
        """cache_creation_input_tokens are added to input total."""
        from llmtracer._providers._anthropic import parse_response

        usage = types.SimpleNamespace(
            input_tokens=1000,
            output_tokens=200,
            cache_creation_input_tokens=5000,
            cache_read_input_tokens=0,
        )
        response = types.SimpleNamespace(
            model="claude-sonnet-4-5-20250929",
            usage=usage,
            stop_reason="end_turn",
        )
        result = parse_response(response)
        assert result["input_tokens"] == 1000 + 5000
        assert result["output_tokens"] == 200

    def test_cache_read_tokens_added(self):
        """cache_read_input_tokens are added to input total."""
        from llmtracer._providers._anthropic import parse_response

        usage = types.SimpleNamespace(
            input_tokens=500,
            output_tokens=100,
            cache_creation_input_tokens=0,
            cache_read_input_tokens=3000,
        )
        response = types.SimpleNamespace(
            model="claude-sonnet-4-5-20250929",
            usage=usage,
            stop_reason="end_turn",
        )
        result = parse_response(response)
        assert result["input_tokens"] == 500 + 3000
        assert result["output_tokens"] == 100

    def test_both_cache_fields_added(self):
        """Both cache creation and read tokens are added."""
        from llmtracer._providers._anthropic import parse_response

        usage = types.SimpleNamespace(
            input_tokens=500,
            output_tokens=100,
            cache_creation_input_tokens=2000,
            cache_read_input_tokens=3000,
        )
        response = types.SimpleNamespace(
            model="claude-sonnet-4-5-20250929",
            usage=usage,
            stop_reason="end_turn",
        )
        result = parse_response(response)
        assert result["input_tokens"] == 500 + 2000 + 3000
        assert result["output_tokens"] == 100

    def test_no_cache_fields_unchanged(self):
        """Without cache fields, input_tokens is unchanged."""
        from llmtracer._providers._anthropic import parse_response

        usage = types.SimpleNamespace(
            input_tokens=200,
            output_tokens=80,
        )
        response = types.SimpleNamespace(
            model="claude-sonnet-4-5-20250929",
            usage=usage,
            stop_reason="end_turn",
        )
        result = parse_response(response)
        assert result["input_tokens"] == 200
        assert result["output_tokens"] == 80

    def test_stream_captures_cache_tokens(self):
        """Stream wrapper captures cache tokens from message_start."""
        from llmtracer._providers._anthropic import _WrappedStream
        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        msg_start = types.SimpleNamespace(
            type="message_start",
            message=types.SimpleNamespace(
                model="claude-sonnet-4-5-20250929",
                usage=types.SimpleNamespace(
                    input_tokens=500,
                    cache_creation_input_tokens=2000,
                    cache_read_input_tokens=1000,
                ),
            ),
        )
        msg_delta = types.SimpleNamespace(
            type="message_delta",
            usage=types.SimpleNamespace(output_tokens=100),
        )

        raw_stream = iter([msg_start, msg_delta])

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            context = {"context": {}, "caller": {}}
            wrapped = _WrappedStream(raw_stream, context, 500, {"model": "claude-sonnet-4-5-20250929"})
            list(wrapped)

            assert len(events) == 1
            assert events[0]["input_tokens"] == 500 + 2000 + 1000
            assert events[0]["output_tokens"] == 100
        finally:
            _transport.enqueue = original_enqueue

    def test_debug_logging_cache_tokens(self, capsys):
        """Debug mode logs cache token breakdown."""
        from llmtracer._providers._anthropic import parse_response
        from llmtracer import _config

        _config.debug = True
        try:
            usage = types.SimpleNamespace(
                input_tokens=500,
                output_tokens=100,
                cache_creation_input_tokens=2000,
                cache_read_input_tokens=3000,
            )
            response = types.SimpleNamespace(
                model="claude-sonnet-4-5-20250929",
                usage=usage,
                stop_reason="end_turn",
            )
            parse_response(response)
            captured = capsys.readouterr()
            assert "cache_create=2000" in captured.out
            assert "cache_read=3000" in captured.out
        finally:
            _config.debug = False


# ═══════════════════════════════════════════════════════════════════════════════
# 15. Anthropic streaming robustness tests
# ═══════════════════════════════════════════════════════════════════════════════


class TestAnthropicStreamingRobust:
    """Anthropic stream wrappers record events on every form of termination."""

    def test_stream_records_on_clean_iteration(self):
        """Normal iteration records model, tokens, and status=success."""
        from llmtracer._providers._anthropic import _WrappedStream
        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        msg_start = types.SimpleNamespace(
            type="message_start",
            message=types.SimpleNamespace(
                model="claude-sonnet-4-20250514",
                usage=types.SimpleNamespace(
                    input_tokens=100,
                    cache_creation_input_tokens=0,
                    cache_read_input_tokens=0,
                ),
            ),
        )
        msg_delta = types.SimpleNamespace(
            type="message_delta",
            usage=types.SimpleNamespace(output_tokens=50),
        )
        raw_stream = iter([msg_start, msg_delta])

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            context = {"context": {}, "caller": {}}
            wrapped = _WrappedStream(raw_stream, context, 100, {"model": "claude-sonnet-4-20250514"})
            list(wrapped)

            assert len(events) == 1
            assert events[0]["model"] == "claude-sonnet-4-20250514"
            assert events[0]["input_tokens"] == 100
            assert events[0]["output_tokens"] == 50
            assert events[0]["status"] == "success"
        finally:
            _transport.enqueue = original_enqueue

    def test_stream_records_on_context_manager_exit(self):
        """Stream used as context manager records on __exit__."""
        from llmtracer._providers._anthropic import _WrappedStream
        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        msg_start = types.SimpleNamespace(
            type="message_start",
            message=types.SimpleNamespace(
                model="claude-sonnet-4-20250514",
                usage=types.SimpleNamespace(
                    input_tokens=200,
                    cache_creation_input_tokens=0,
                    cache_read_input_tokens=0,
                ),
            ),
        )
        content = types.SimpleNamespace(type="content_block_delta")
        msg_delta = types.SimpleNamespace(
            type="message_delta",
            usage=types.SimpleNamespace(output_tokens=75),
        )
        raw_stream = iter([msg_start, content, msg_delta])

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            context = {"context": {}, "caller": {}}
            wrapped = _WrappedStream(raw_stream, context, 100, {"model": "claude-sonnet-4-20250514"})
            with wrapped as s:
                # Only consume first event, then exit
                first = next(s)
                assert first is msg_start

            # Event should be recorded on __exit__ even though not fully consumed
            assert len(events) == 1
            assert events[0]["model"] == "claude-sonnet-4-20250514"
            assert events[0]["input_tokens"] == 200
            assert events[0]["output_tokens"] == 0  # didn't reach message_delta
            assert events[0]["status"] == "success"
        finally:
            _transport.enqueue = original_enqueue

    def test_stream_records_on_early_break(self):
        """Breaking out of a for loop with context manager still records."""
        from llmtracer._providers._anthropic import _WrappedStream
        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        msg_start = types.SimpleNamespace(
            type="message_start",
            message=types.SimpleNamespace(
                model="claude-sonnet-4-20250514",
                usage=types.SimpleNamespace(input_tokens=300),
            ),
        )
        content1 = types.SimpleNamespace(type="content_block_delta")
        content2 = types.SimpleNamespace(type="content_block_delta")
        msg_delta = types.SimpleNamespace(
            type="message_delta",
            usage=types.SimpleNamespace(output_tokens=100),
        )
        raw_stream = iter([msg_start, content1, content2, msg_delta])

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            context = {"context": {}, "caller": {}}
            wrapped = _WrappedStream(raw_stream, context, 50, {"model": "claude-sonnet-4-20250514"})
            with wrapped as s:
                for event in s:
                    if event.type == "content_block_delta":
                        break  # early exit

            assert len(events) == 1
            assert events[0]["model"] == "claude-sonnet-4-20250514"
            assert events[0]["input_tokens"] == 300
            assert events[0]["status"] == "success"
        finally:
            _transport.enqueue = original_enqueue

    def test_stream_records_on_exception(self):
        """Stream iteration exception records status=error."""
        from llmtracer._providers._anthropic import _WrappedStream
        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        msg_start = types.SimpleNamespace(
            type="message_start",
            message=types.SimpleNamespace(
                model="claude-sonnet-4-20250514",
                usage=types.SimpleNamespace(input_tokens=150),
            ),
        )

        def _error_stream():
            yield msg_start
            raise ConnectionError("stream interrupted")

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            context = {"context": {}, "caller": {}}
            wrapped = _WrappedStream(
                _error_stream(), context, 50, {"model": "claude-sonnet-4-20250514"}
            )
            with pytest.raises(ConnectionError):
                list(wrapped)

            assert len(events) == 1
            assert events[0]["model"] == "claude-sonnet-4-20250514"
            assert events[0]["input_tokens"] == 150
            assert events[0]["status"] == "error"
        finally:
            _transport.enqueue = original_enqueue

    def test_stream_records_on_close(self):
        """Calling close() records event with model from kwargs."""
        from llmtracer._providers._anthropic import _WrappedStream
        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        raw_stream = iter([types.SimpleNamespace(type="ping")])

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            context = {"context": {}, "caller": {}}
            wrapped = _WrappedStream(raw_stream, context, 50, {"model": "claude-sonnet-4-20250514"})
            wrapped.close()

            assert len(events) == 1
            assert events[0]["model"] == "claude-sonnet-4-20250514"
            assert events[0]["status"] == "success"
        finally:
            _transport.enqueue = original_enqueue

    def test_stream_no_double_record(self):
        """Event is only recorded once even with multiple exit paths."""
        from llmtracer._providers._anthropic import _WrappedStream
        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        msg_start = types.SimpleNamespace(
            type="message_start",
            message=types.SimpleNamespace(
                model="claude-sonnet-4-20250514",
                usage=types.SimpleNamespace(input_tokens=100),
            ),
        )
        raw_stream = iter([msg_start])

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            context = {"context": {}, "caller": {}}
            wrapped = _WrappedStream(raw_stream, context, 50, {"model": "claude-sonnet-4-20250514"})

            # Consume fully (triggers _record via StopIteration)
            list(wrapped)
            # Then close (should be no-op)
            wrapped.close()
            # Then __exit__ (should be no-op)
            wrapped.__exit__(None, None, None)

            assert len(events) == 1
        finally:
            _transport.enqueue = original_enqueue

    def test_stream_model_from_kwargs_when_no_events(self):
        """Model captured from kwargs even if stream yields no events."""
        from llmtracer._providers._anthropic import _WrappedStream
        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        raw_stream = iter([])  # empty stream

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            context = {"context": {}, "caller": {}}
            wrapped = _WrappedStream(raw_stream, context, 50, {"model": "claude-sonnet-4-20250514"})
            list(wrapped)

            assert len(events) == 1
            assert events[0]["model"] == "claude-sonnet-4-20250514"
            assert events[0]["input_tokens"] == 0
            assert events[0]["output_tokens"] == 0
            assert events[0]["status"] == "success"
        finally:
            _transport.enqueue = original_enqueue

    def test_stream_context_manager_exception_records_error(self):
        """Exception inside 'with' block records status=error."""
        from llmtracer._providers._anthropic import _WrappedStream
        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        msg_start = types.SimpleNamespace(
            type="message_start",
            message=types.SimpleNamespace(
                model="claude-sonnet-4-20250514",
                usage=types.SimpleNamespace(input_tokens=250),
            ),
        )
        raw_stream = iter([msg_start])

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            context = {"context": {}, "caller": {}}
            wrapped = _WrappedStream(raw_stream, context, 50, {"model": "claude-sonnet-4-20250514"})
            with pytest.raises(ValueError):
                with wrapped:
                    next(wrapped)
                    raise ValueError("app error")

            assert len(events) == 1
            assert events[0]["status"] == "error"
            assert events[0]["model"] == "claude-sonnet-4-20250514"
        finally:
            _transport.enqueue = original_enqueue

    def test_parse_response_always_success(self):
        """parse_response returns success regardless of stop_reason."""
        from llmtracer._providers._anthropic import parse_response

        # No stop_reason
        response = types.SimpleNamespace(
            model="claude-sonnet-4-20250514",
            usage=types.SimpleNamespace(input_tokens=100, output_tokens=50),
        )
        result = parse_response(response)
        assert result["status"] == "success"
        assert result["model"] == "claude-sonnet-4-20250514"

        # stop_reason=None (streaming intermediate state)
        response2 = types.SimpleNamespace(
            model="claude-sonnet-4-20250514",
            usage=types.SimpleNamespace(input_tokens=100, output_tokens=50),
            stop_reason=None,
        )
        result2 = parse_response(response2)
        assert result2["status"] == "success"

    @pytest.mark.asyncio
    async def test_async_stream_records_on_clean_iteration(self):
        """Async stream records on StopAsyncIteration."""
        from llmtracer._providers._anthropic import _WrappedAsyncStream
        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        msg_start = types.SimpleNamespace(
            type="message_start",
            message=types.SimpleNamespace(
                model="claude-sonnet-4-20250514",
                usage=types.SimpleNamespace(
                    input_tokens=100,
                    cache_creation_input_tokens=0,
                    cache_read_input_tokens=0,
                ),
            ),
        )
        msg_delta = types.SimpleNamespace(
            type="message_delta",
            usage=types.SimpleNamespace(output_tokens=50),
        )

        class _FakeAsyncIter:
            def __init__(self, items):
                self._items = iter(items)

            def __aiter__(self):
                return self

            async def __anext__(self):
                try:
                    return next(self._items)
                except StopIteration:
                    raise StopAsyncIteration

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            context = {"context": {}, "caller": {}}
            raw = _FakeAsyncIter([msg_start, msg_delta])
            wrapped = _WrappedAsyncStream(raw, context, 100, {"model": "claude-sonnet-4-20250514"})

            received = []
            async for event in wrapped:
                received.append(event)

            assert len(received) == 2
            assert len(events) == 1
            assert events[0]["model"] == "claude-sonnet-4-20250514"
            assert events[0]["input_tokens"] == 100
            assert events[0]["output_tokens"] == 50
            assert events[0]["status"] == "success"
        finally:
            _transport.enqueue = original_enqueue

    @pytest.mark.asyncio
    async def test_async_stream_records_on_aexit(self):
        """Async stream used as context manager records on __aexit__."""
        from llmtracer._providers._anthropic import _WrappedAsyncStream
        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        msg_start = types.SimpleNamespace(
            type="message_start",
            message=types.SimpleNamespace(
                model="claude-sonnet-4-20250514",
                usage=types.SimpleNamespace(input_tokens=200),
            ),
        )
        content = types.SimpleNamespace(type="content_block_delta")

        class _FakeAsyncIter:
            def __init__(self, items):
                self._items = iter(items)

            def __aiter__(self):
                return self

            async def __anext__(self):
                try:
                    return next(self._items)
                except StopIteration:
                    raise StopAsyncIteration

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            context = {"context": {}, "caller": {}}
            raw = _FakeAsyncIter([msg_start, content])
            wrapped = _WrappedAsyncStream(raw, context, 100, {"model": "claude-sonnet-4-20250514"})

            async with wrapped as s:
                event = await s.__anext__()
                assert event is msg_start
                # exit early without consuming all events

            assert len(events) == 1
            assert events[0]["model"] == "claude-sonnet-4-20250514"
            assert events[0]["input_tokens"] == 200
            assert events[0]["status"] == "success"
        finally:
            _transport.enqueue = original_enqueue

    @pytest.mark.asyncio
    async def test_async_stream_records_on_exception(self):
        """Async stream exception records status=error."""
        from llmtracer._providers._anthropic import _WrappedAsyncStream
        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        class _FakeErrorAsyncIter:
            def __aiter__(self):
                return self

            async def __anext__(self):
                raise ConnectionError("stream failed")

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            context = {"context": {}, "caller": {}}
            raw = _FakeErrorAsyncIter()
            wrapped = _WrappedAsyncStream(raw, context, 50, {"model": "claude-sonnet-4-20250514"})

            with pytest.raises(ConnectionError):
                async for _ in wrapped:
                    pass

            assert len(events) == 1
            assert events[0]["model"] == "claude-sonnet-4-20250514"
            assert events[0]["status"] == "error"
        finally:
            _transport.enqueue = original_enqueue

    def test_stream_never_crashes_app(self):
        """Even if _record fails internally, iteration continues."""
        from llmtracer._providers._anthropic import _WrappedStream
        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        events = [1, 2, 3]
        raw_stream = iter(events)

        # Make _build_and_enqueue raise
        original_enqueue = _transport.enqueue
        _transport.enqueue = mock.Mock(side_effect=RuntimeError("transport broken"))

        try:
            context = {"context": {}, "caller": {}}
            wrapped = _WrappedStream(raw_stream, context, 50, {"model": "claude-sonnet-4-20250514"})

            # Should not raise — iteration works even when recording fails
            received = list(wrapped)
            assert received == [1, 2, 3]
        finally:
            _transport.enqueue = original_enqueue


# ═══════════════════════════════════════════════════════════════════════════════
# 16. OpenAI streaming robustness tests
# ═══════════════════════════════════════════════════════════════════════════════


class TestOpenAIStreamingRobust:
    """OpenAI stream wrappers record events on every form of termination."""

    def test_stream_records_on_clean_iteration(self):
        """Normal iteration records model, tokens, and status=success."""
        from llmtracer._providers._openai import _WrappedStream
        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        chunks = [
            _FakeStreamChunk(),
            _FakeStreamChunk(),
            _FakeStreamChunk(usage=_FakeUsage(prompt_tokens=200, completion_tokens=80)),
        ]
        raw_stream = iter(chunks)

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            context = {"context": {}, "caller": {}}
            wrapped = _WrappedStream(raw_stream, context, 100, {"model": "gpt-4o"})
            received = list(wrapped)

            assert len(received) == 3
            assert len(events) == 1
            assert events[0]["model"] == "gpt-4o"
            assert events[0]["input_tokens"] == 200
            assert events[0]["output_tokens"] == 80
            assert events[0]["status"] == "success"
        finally:
            _transport.enqueue = original_enqueue

    def test_stream_records_on_context_manager_exit(self):
        """Stream used as context manager records on __exit__."""
        from llmtracer._providers._openai import _WrappedStream
        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        chunks = [
            _FakeStreamChunk(),
            _FakeStreamChunk(),
            _FakeStreamChunk(usage=_FakeUsage(prompt_tokens=150, completion_tokens=60)),
        ]
        raw_stream = iter(chunks)

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            context = {"context": {}, "caller": {}}
            wrapped = _WrappedStream(raw_stream, context, 100, {"model": "gpt-4o"})
            with wrapped as s:
                # Only consume first chunk, then exit
                first = next(s)
                assert first is chunks[0]

            # Event should be recorded on __exit__
            assert len(events) == 1
            assert events[0]["model"] == "gpt-4o"
            assert events[0]["status"] == "success"
        finally:
            _transport.enqueue = original_enqueue

    def test_stream_records_on_early_break(self):
        """Breaking out of for loop with context manager still records."""
        from llmtracer._providers._openai import _WrappedStream
        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        chunks = [
            _FakeStreamChunk(),
            _FakeStreamChunk(),
            _FakeStreamChunk(usage=_FakeUsage(prompt_tokens=100, completion_tokens=25)),
        ]
        raw_stream = iter(chunks)

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            context = {"context": {}, "caller": {}}
            wrapped = _WrappedStream(raw_stream, context, 50, {"model": "gpt-4o"})
            with wrapped as s:
                for chunk in s:
                    break  # early exit after first chunk

            assert len(events) == 1
            assert events[0]["model"] == "gpt-4o"
            assert events[0]["status"] == "success"
        finally:
            _transport.enqueue = original_enqueue

    def test_stream_records_on_exception(self):
        """Stream iteration exception records status=error."""
        from llmtracer._providers._openai import _WrappedStream
        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        def _error_stream():
            yield _FakeStreamChunk()
            raise ConnectionError("stream interrupted")

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            context = {"context": {}, "caller": {}}
            wrapped = _WrappedStream(
                _error_stream(), context, 50, {"model": "gpt-4o"}
            )
            with pytest.raises(ConnectionError):
                list(wrapped)

            assert len(events) == 1
            assert events[0]["model"] == "gpt-4o"
            assert events[0]["status"] == "error"
        finally:
            _transport.enqueue = original_enqueue

    def test_stream_records_on_close(self):
        """Calling close() records event."""
        from llmtracer._providers._openai import _WrappedStream
        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        raw_stream = iter([_FakeStreamChunk()])

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            context = {"context": {}, "caller": {}}
            wrapped = _WrappedStream(raw_stream, context, 50, {"model": "gpt-4o"})
            wrapped.close()

            assert len(events) == 1
            assert events[0]["model"] == "gpt-4o"
            assert events[0]["status"] == "success"
        finally:
            _transport.enqueue = original_enqueue

    def test_stream_no_double_record(self):
        """Event is only recorded once even with multiple exit paths."""
        from llmtracer._providers._openai import _WrappedStream
        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        raw_stream = iter([_FakeStreamChunk()])

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            context = {"context": {}, "caller": {}}
            wrapped = _WrappedStream(raw_stream, context, 50, {"model": "gpt-4o"})

            # Consume fully (triggers _record via StopIteration)
            list(wrapped)
            # Then close (should be no-op)
            wrapped.close()
            # Then __exit__ (should be no-op)
            wrapped.__exit__(None, None, None)

            assert len(events) == 1
        finally:
            _transport.enqueue = original_enqueue

    def test_stream_model_from_kwargs_when_no_chunks(self):
        """Model captured from kwargs when stream yields nothing."""
        from llmtracer._providers._openai import _WrappedStream
        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        raw_stream = iter([])

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            context = {"context": {}, "caller": {}}
            wrapped = _WrappedStream(raw_stream, context, 50, {"model": "gpt-4o-mini"})
            list(wrapped)

            assert len(events) == 1
            assert events[0]["model"] == "gpt-4o-mini"
            assert events[0]["input_tokens"] == 0
            assert events[0]["output_tokens"] == 0
            assert events[0]["status"] == "success"
        finally:
            _transport.enqueue = original_enqueue

    def test_stream_context_manager_exception_records_error(self):
        """Exception inside 'with' block records status=error."""
        from llmtracer._providers._openai import _WrappedStream
        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        raw_stream = iter([_FakeStreamChunk()])

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            context = {"context": {}, "caller": {}}
            wrapped = _WrappedStream(raw_stream, context, 50, {"model": "gpt-4o"})
            with pytest.raises(ValueError):
                with wrapped:
                    next(wrapped)
                    raise ValueError("app error")

            assert len(events) == 1
            assert events[0]["status"] == "error"
            assert events[0]["model"] == "gpt-4o"
        finally:
            _transport.enqueue = original_enqueue

    @pytest.mark.asyncio
    async def test_async_stream_records_on_clean_iteration(self):
        """Async stream records on StopAsyncIteration."""
        from llmtracer._providers._openai import _WrappedAsyncStream
        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        chunks = [
            _FakeStreamChunk(),
            _FakeStreamChunk(usage=_FakeUsage(prompt_tokens=100, completion_tokens=50)),
        ]

        class _FakeAsyncIter:
            def __init__(self, items):
                self._items = iter(items)

            def __aiter__(self):
                return self

            async def __anext__(self):
                try:
                    return next(self._items)
                except StopIteration:
                    raise StopAsyncIteration

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            context = {"context": {}, "caller": {}}
            raw = _FakeAsyncIter(chunks)
            wrapped = _WrappedAsyncStream(raw, context, 100, {"model": "gpt-4o"})

            received = []
            async for chunk in wrapped:
                received.append(chunk)

            assert len(received) == 2
            assert len(events) == 1
            assert events[0]["model"] == "gpt-4o"
            assert events[0]["input_tokens"] == 100
            assert events[0]["output_tokens"] == 50
            assert events[0]["status"] == "success"
        finally:
            _transport.enqueue = original_enqueue

    @pytest.mark.asyncio
    async def test_async_stream_records_on_aexit(self):
        """Async stream used as context manager records on __aexit__."""
        from llmtracer._providers._openai import _WrappedAsyncStream
        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        chunks = [_FakeStreamChunk(), _FakeStreamChunk()]

        class _FakeAsyncIter:
            def __init__(self, items):
                self._items = iter(items)

            def __aiter__(self):
                return self

            async def __anext__(self):
                try:
                    return next(self._items)
                except StopIteration:
                    raise StopAsyncIteration

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            context = {"context": {}, "caller": {}}
            raw = _FakeAsyncIter(chunks)
            wrapped = _WrappedAsyncStream(raw, context, 100, {"model": "gpt-4o"})

            async with wrapped as s:
                event = await s.__anext__()
                assert event is chunks[0]
                # exit early

            assert len(events) == 1
            assert events[0]["model"] == "gpt-4o"
            assert events[0]["status"] == "success"
        finally:
            _transport.enqueue = original_enqueue

    @pytest.mark.asyncio
    async def test_async_stream_records_on_exception(self):
        """Async stream exception records status=error."""
        from llmtracer._providers._openai import _WrappedAsyncStream
        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        class _FakeErrorAsyncIter:
            def __aiter__(self):
                return self

            async def __anext__(self):
                raise ConnectionError("stream failed")

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            context = {"context": {}, "caller": {}}
            raw = _FakeErrorAsyncIter()
            wrapped = _WrappedAsyncStream(raw, context, 50, {"model": "gpt-4o"})

            with pytest.raises(ConnectionError):
                async for _ in wrapped:
                    pass

            assert len(events) == 1
            assert events[0]["model"] == "gpt-4o"
            assert events[0]["status"] == "error"
        finally:
            _transport.enqueue = original_enqueue

    def test_stream_never_crashes_app(self):
        """Even if _record fails internally, iteration continues."""
        from llmtracer._providers._openai import _WrappedStream
        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        chunks = [_FakeStreamChunk(), _FakeStreamChunk()]
        raw_stream = iter(chunks)

        original_enqueue = _transport.enqueue
        _transport.enqueue = mock.Mock(side_effect=RuntimeError("transport broken"))

        try:
            context = {"context": {}, "caller": {}}
            wrapped = _WrappedStream(raw_stream, context, 50, {"model": "gpt-4o"})

            received = list(wrapped)
            assert len(received) == 2
        finally:
            _transport.enqueue = original_enqueue


# ═══════════════════════════════════════════════════════════════════════════════
# 17. Google streaming robustness tests
# ═══════════════════════════════════════════════════════════════════════════════


class TestGoogleStreamingRobust:
    """Google stream wrappers record events on every form of termination."""

    def test_stream_records_on_clean_iteration(self):
        """Normal iteration records model, tokens, and status=success."""
        from llmtracer._providers._google import _WrappedStream
        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        chunk1 = types.SimpleNamespace(text="hello")
        chunk2 = types.SimpleNamespace(
            text="world",
            usage_metadata=types.SimpleNamespace(
                input_tokens=500,
                output_tokens=100,
            ),
        )
        raw_stream = iter([chunk1, chunk2])

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            context = {"context": {}, "caller": {}}
            wrapped = _WrappedStream(raw_stream, context, 100, {"model": "gemini-2.0-flash"})
            received = list(wrapped)

            assert len(received) == 2
            assert len(events) == 1
            assert events[0]["model"] == "gemini-2.0-flash"
            assert events[0]["input_tokens"] == 500
            assert events[0]["output_tokens"] == 100
            assert events[0]["status"] == "success"
        finally:
            _transport.enqueue = original_enqueue

    def test_stream_records_on_context_manager_exit(self):
        """Stream used as context manager records on __exit__."""
        from llmtracer._providers._google import _WrappedStream
        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        chunk1 = types.SimpleNamespace(text="hello")
        chunk2 = types.SimpleNamespace(
            text="world",
            usage_metadata=types.SimpleNamespace(
                input_tokens=500,
                output_tokens=100,
            ),
        )
        raw_stream = iter([chunk1, chunk2])

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            context = {"context": {}, "caller": {}}
            wrapped = _WrappedStream(raw_stream, context, 100, {"model": "gemini-2.0-flash"})
            with wrapped as s:
                first = next(s)
                assert first is chunk1

            assert len(events) == 1
            assert events[0]["model"] == "gemini-2.0-flash"
            assert events[0]["status"] == "success"
        finally:
            _transport.enqueue = original_enqueue

    def test_stream_records_on_early_break(self):
        """Breaking out of for loop with context manager still records."""
        from llmtracer._providers._google import _WrappedStream
        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        chunks = [
            types.SimpleNamespace(text="a"),
            types.SimpleNamespace(text="b"),
            types.SimpleNamespace(
                text="c",
                usage_metadata=types.SimpleNamespace(
                    input_tokens=300,
                    output_tokens=50,
                ),
            ),
        ]
        raw_stream = iter(chunks)

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            context = {"context": {}, "caller": {}}
            wrapped = _WrappedStream(raw_stream, context, 50, {"model": "gemini-2.0-flash"})
            with wrapped as s:
                for chunk in s:
                    break  # early exit

            assert len(events) == 1
            assert events[0]["model"] == "gemini-2.0-flash"
            assert events[0]["status"] == "success"
        finally:
            _transport.enqueue = original_enqueue

    def test_stream_records_on_exception(self):
        """Stream iteration exception records status=error."""
        from llmtracer._providers._google import _WrappedStream
        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        def _error_stream():
            yield types.SimpleNamespace(text="hello")
            raise ConnectionError("stream interrupted")

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            context = {"context": {}, "caller": {}}
            wrapped = _WrappedStream(
                _error_stream(), context, 50, {"model": "gemini-2.0-flash"}
            )
            with pytest.raises(ConnectionError):
                list(wrapped)

            assert len(events) == 1
            assert events[0]["model"] == "gemini-2.0-flash"
            assert events[0]["status"] == "error"
        finally:
            _transport.enqueue = original_enqueue

    def test_stream_records_on_close(self):
        """Calling close() records event."""
        from llmtracer._providers._google import _WrappedStream
        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        raw_stream = iter([types.SimpleNamespace(text="hi")])

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            context = {"context": {}, "caller": {}}
            wrapped = _WrappedStream(raw_stream, context, 50, {"model": "gemini-2.0-flash"})
            wrapped.close()

            assert len(events) == 1
            assert events[0]["model"] == "gemini-2.0-flash"
            assert events[0]["status"] == "success"
        finally:
            _transport.enqueue = original_enqueue

    def test_stream_no_double_record(self):
        """Event is only recorded once even with multiple exit paths."""
        from llmtracer._providers._google import _WrappedStream
        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        raw_stream = iter([types.SimpleNamespace(text="hi")])

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            context = {"context": {}, "caller": {}}
            wrapped = _WrappedStream(raw_stream, context, 50, {"model": "gemini-2.0-flash"})

            list(wrapped)
            wrapped.close()
            wrapped.__exit__(None, None, None)

            assert len(events) == 1
        finally:
            _transport.enqueue = original_enqueue

    def test_stream_model_from_kwargs_when_no_chunks(self):
        """Model captured from kwargs when stream yields nothing."""
        from llmtracer._providers._google import _WrappedStream
        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        raw_stream = iter([])

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            context = {"context": {}, "caller": {}}
            wrapped = _WrappedStream(raw_stream, context, 50, {"model": "gemini-1.5-pro"})
            list(wrapped)

            assert len(events) == 1
            assert events[0]["model"] == "gemini-1.5-pro"
            assert events[0]["input_tokens"] == 0
            assert events[0]["output_tokens"] == 0
            assert events[0]["status"] == "success"
        finally:
            _transport.enqueue = original_enqueue

    def test_stream_context_manager_exception_records_error(self):
        """Exception inside 'with' block records status=error."""
        from llmtracer._providers._google import _WrappedStream
        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        raw_stream = iter([types.SimpleNamespace(text="hi")])

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            context = {"context": {}, "caller": {}}
            wrapped = _WrappedStream(raw_stream, context, 50, {"model": "gemini-2.0-flash"})
            with pytest.raises(ValueError):
                with wrapped:
                    next(wrapped)
                    raise ValueError("app error")

            assert len(events) == 1
            assert events[0]["status"] == "error"
            assert events[0]["model"] == "gemini-2.0-flash"
        finally:
            _transport.enqueue = original_enqueue

    @pytest.mark.asyncio
    async def test_async_stream_records_on_clean_iteration(self):
        """Async stream records on StopAsyncIteration."""
        from llmtracer._providers._google import _WrappedAsyncStream
        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        chunk1 = types.SimpleNamespace(text="hello")
        chunk2 = types.SimpleNamespace(
            text="world",
            usage_metadata=types.SimpleNamespace(
                input_tokens=800,
                output_tokens=200,
            ),
        )

        class _FakeAsyncIter:
            def __init__(self, items):
                self._items = iter(items)

            def __aiter__(self):
                return self

            async def __anext__(self):
                try:
                    return next(self._items)
                except StopIteration:
                    raise StopAsyncIteration

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            context = {"context": {}, "caller": {}}
            raw = _FakeAsyncIter([chunk1, chunk2])
            wrapped = _WrappedAsyncStream(raw, context, 100, {"model": "gemini-2.0-flash"})

            received = []
            async for chunk in wrapped:
                received.append(chunk)

            assert len(received) == 2
            assert len(events) == 1
            assert events[0]["model"] == "gemini-2.0-flash"
            assert events[0]["input_tokens"] == 800
            assert events[0]["output_tokens"] == 200
            assert events[0]["status"] == "success"
        finally:
            _transport.enqueue = original_enqueue

    @pytest.mark.asyncio
    async def test_async_stream_records_on_aexit(self):
        """Async stream used as context manager records on __aexit__."""
        from llmtracer._providers._google import _WrappedAsyncStream
        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        chunks = [
            types.SimpleNamespace(text="hello"),
            types.SimpleNamespace(text="world"),
        ]

        class _FakeAsyncIter:
            def __init__(self, items):
                self._items = iter(items)

            def __aiter__(self):
                return self

            async def __anext__(self):
                try:
                    return next(self._items)
                except StopIteration:
                    raise StopAsyncIteration

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            context = {"context": {}, "caller": {}}
            raw = _FakeAsyncIter(chunks)
            wrapped = _WrappedAsyncStream(raw, context, 100, {"model": "gemini-2.0-flash"})

            async with wrapped as s:
                event = await s.__anext__()
                assert event is chunks[0]

            assert len(events) == 1
            assert events[0]["model"] == "gemini-2.0-flash"
            assert events[0]["status"] == "success"
        finally:
            _transport.enqueue = original_enqueue

    @pytest.mark.asyncio
    async def test_async_stream_records_on_exception(self):
        """Async stream exception records status=error."""
        from llmtracer._providers._google import _WrappedAsyncStream
        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        class _FakeErrorAsyncIter:
            def __aiter__(self):
                return self

            async def __anext__(self):
                raise ConnectionError("stream failed")

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            context = {"context": {}, "caller": {}}
            raw = _FakeErrorAsyncIter()
            wrapped = _WrappedAsyncStream(raw, context, 50, {"model": "gemini-2.0-flash"})

            with pytest.raises(ConnectionError):
                async for _ in wrapped:
                    pass

            assert len(events) == 1
            assert events[0]["model"] == "gemini-2.0-flash"
            assert events[0]["status"] == "error"
        finally:
            _transport.enqueue = original_enqueue

    def test_stream_never_crashes_app(self):
        """Even if _record fails internally, iteration continues."""
        from llmtracer._providers._google import _WrappedStream
        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        chunks = [types.SimpleNamespace(text="a"), types.SimpleNamespace(text="b")]
        raw_stream = iter(chunks)

        original_enqueue = _transport.enqueue
        _transport.enqueue = mock.Mock(side_effect=RuntimeError("transport broken"))

        try:
            context = {"context": {}, "caller": {}}
            wrapped = _WrappedStream(raw_stream, context, 50, {"model": "gemini-2.0-flash"})

            received = list(wrapped)
            assert len(received) == 2
        finally:
            _transport.enqueue = original_enqueue


# ═══════════════════════════════════════════════════════════════════════════════
# 18. Session ID tests
# ═══════════════════════════════════════════════════════════════════════════════


class TestSessionId:
    """Automatic session_id — zero-config process-level grouping."""

    def test_session_id_generated_on_init(self):
        """init() generates a valid UUID4 session_id."""
        import llmtracer
        from llmtracer import _config

        llmtracer.init(api_key="lt_test123")
        assert _config.session_id != ""
        # Validate it's a proper UUID
        parsed = uuid.UUID(_config.session_id)
        assert parsed.version == 4

    def test_session_id_in_event_payload(self):
        """session_id appears in every event sent to transport."""
        import llmtracer
        from llmtracer import _config, _transport

        _install_fake_openai()
        llmtracer.init(api_key="lt_test123")

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)
        try:
            import openai
            openai.resources.chat.completions.Completions.create(
                None, model="gpt-4o", messages=[{"role": "user", "content": "hi"}]
            )
            assert len(events) == 1
            assert "session_id" in events[0]
            assert events[0]["session_id"] == _config.session_id
            # Validate UUID format
            uuid.UUID(events[0]["session_id"])
        finally:
            _transport.enqueue = original_enqueue

    def test_session_id_constant_across_calls(self):
        """All events in the same init() share the same session_id."""
        import llmtracer
        from llmtracer import _config, _transport

        _install_fake_openai()
        llmtracer.init(api_key="lt_test123")
        session = _config.session_id

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)
        try:
            import openai
            for _ in range(3):
                openai.resources.chat.completions.Completions.create(
                    None, model="gpt-4o", messages=[{"role": "user", "content": "hi"}]
                )
            assert len(events) == 3
            assert all(e["session_id"] == session for e in events)
        finally:
            _transport.enqueue = original_enqueue

    def test_session_id_coexists_with_trace_id(self):
        """Events inside trace() have both session_id and trace_id (different values)."""
        import llmtracer
        from llmtracer import _config, _transport

        _install_fake_openai()
        llmtracer.init(api_key="lt_test123")

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)
        try:
            import openai
            with llmtracer.trace(user_id="tim"):
                openai.resources.chat.completions.Completions.create(
                    None, model="gpt-4o", messages=[{"role": "user", "content": "hi"}]
                )
            assert len(events) == 1
            ev = events[0]
            assert "session_id" in ev
            assert "trace_id" in ev
            assert ev["session_id"] == _config.session_id
            assert ev["session_id"] != ev["trace_id"]
        finally:
            _transport.enqueue = original_enqueue

    def test_session_id_regenerates_on_reinit(self):
        """Calling init() again generates a fresh session_id."""
        import llmtracer
        from llmtracer import _config

        llmtracer.init(api_key="lt_test123")
        first = _config.session_id

        llmtracer.init(api_key="lt_test123")
        second = _config.session_id

        assert first != ""
        assert second != ""
        assert first != second

    def test_session_id_debug_print(self, capsys):
        """Debug mode prints session_id."""
        import llmtracer

        llmtracer.init(api_key="lt_test123", debug=True)
        captured = capsys.readouterr()
        assert "[llmtracer] Session:" in captured.out

