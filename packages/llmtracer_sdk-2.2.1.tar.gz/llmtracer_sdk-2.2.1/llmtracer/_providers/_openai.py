"""OpenAI-specific: patch targets, response parsing, stream wrapping."""

import time

from .. import _config
from .._wrapper import _build_and_enqueue

# ── Patch targets ─────────────────────────────────────────────────────────────

SYNC_TARGET = ("openai.resources.chat.completions", "Completions", "create")
ASYNC_TARGET = ("openai.resources.chat.completions", "AsyncCompletions", "create")


# ── Response parsing ──────────────────────────────────────────────────────────


def parse_response(result):
    """Extract provider/model/tokens from an OpenAI ChatCompletion."""
    # LangChain may wrap response in LegacyAPIResponse / APIResponse
    # Unwrap to get the actual ChatCompletion object
    inner = result
    if hasattr(result, "parse"):
        try:
            inner = result.parse()
        except Exception:
            pass
    elif hasattr(result, "_parsed"):
        inner = getattr(result, "_parsed", result)

    usage = getattr(inner, "usage", None)
    input_tokens = getattr(usage, "prompt_tokens", 0) or 0 if usage else 0
    output_tokens = getattr(usage, "completion_tokens", 0) or 0 if usage else 0

    if _config.debug and usage:
        _log_openai_token_details(usage, input_tokens, output_tokens)

    return {
        "provider": "openai",
        "model": getattr(inner, "model", None) or "unknown",
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "status": "success",
    }


def _log_openai_token_details(usage, input_tokens, output_tokens):
    """Log detailed token breakdown in debug mode."""
    # completion_tokens_details (reasoning_tokens for o1/o3/o4, prediction tokens)
    details = getattr(usage, "completion_tokens_details", None)
    reasoning = 0
    accepted_prediction = 0
    rejected_prediction = 0
    if details:
        reasoning = getattr(details, "reasoning_tokens", 0) or 0
        accepted_prediction = getattr(details, "accepted_prediction_tokens", 0) or 0
        rejected_prediction = getattr(details, "rejected_prediction_tokens", 0) or 0

    # prompt_tokens_details (cached_tokens)
    prompt_details = getattr(usage, "prompt_tokens_details", None)
    cached = 0
    if prompt_details:
        cached = getattr(prompt_details, "cached_tokens", 0) or 0

    print(f"[llmtracer] OpenAI tokens — in={input_tokens} (cached={cached}) out={output_tokens} (reasoning={reasoning} accepted_pred={accepted_prediction} rejected_pred={rejected_prediction})")
    print(f"[llmtracer] OpenAI note: reasoning/cached tokens are INCLUDED in base counts")


# ── Sync stream wrapper ──────────────────────────────────────────────────────


class _WrappedStream:
    """Transparent wrapper that passes through chunks and records on completion.

    Records the tracing event when the stream terminates — via StopIteration,
    an exception, context-manager exit, close(), or garbage collection.
    """

    def __init__(self, original_stream, context, start_elapsed_ms, kwargs):
        self._stream = original_stream
        self._context = context
        self._create_elapsed_ms = start_elapsed_ms
        self._start_time = time.monotonic()
        self._kwargs = kwargs
        self._chunks = []
        self._recorded = False

    def __iter__(self):
        return self

    def __next__(self):
        try:
            chunk = next(self._stream)
            self._chunks.append(chunk)
            return chunk
        except StopIteration:
            self._record(status="success")
            raise
        except Exception:
            self._record(status="error")
            raise

    def _record(self, status="success"):
        """Extract usage from accumulated chunks and record event once."""
        if self._recorded:
            return
        self._recorded = True
        try:
            elapsed_ms = self._create_elapsed_ms + int(
                (time.monotonic() - self._start_time) * 1000
            )
            model = self._kwargs.get("model", "unknown")
            input_tokens = 0
            output_tokens = 0

            # OpenAI includes usage in the final chunk when
            # stream_options={"include_usage": True}
            for chunk in reversed(self._chunks):
                usage = getattr(chunk, "usage", None)
                if usage:
                    input_tokens = getattr(usage, "prompt_tokens", 0) or 0
                    output_tokens = getattr(usage, "completion_tokens", 0) or 0
                    if _config.debug:
                        _log_openai_token_details(usage, input_tokens, output_tokens)
                    break

            if getattr(self._chunks[0] if self._chunks else None, "model", None):
                model = self._chunks[0].model

            response_data = {
                "provider": "openai",
                "model": model,
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
                "status": status,
            }
            _build_and_enqueue(self._context, response_data, elapsed_ms)
        except Exception:
            pass

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self._record(status="error" if exc_type else "success")
        if hasattr(self._stream, "__exit__"):
            return self._stream.__exit__(exc_type, exc_val, exc_tb)
        return False

    def close(self):
        self._record(status="success")
        if hasattr(self._stream, "close"):
            self._stream.close()

    def __del__(self):
        try:
            self._record(status="error")
        except Exception:
            pass


def wrap_stream(result, context, elapsed_ms, kwargs):
    """Wrap a sync OpenAI stream."""
    return _WrappedStream(result, context, elapsed_ms, kwargs)


# ── Async stream wrapper ─────────────────────────────────────────────────────


class _WrappedAsyncStream:
    """Async transparent wrapper for OpenAI streaming."""

    def __init__(self, original_stream, context, start_elapsed_ms, kwargs):
        self._stream = original_stream
        self._context = context
        self._create_elapsed_ms = start_elapsed_ms
        self._start_time = time.monotonic()
        self._kwargs = kwargs
        self._chunks = []
        self._recorded = False

    def __aiter__(self):
        return self

    async def __anext__(self):
        try:
            chunk = await self._stream.__anext__()
            self._chunks.append(chunk)
            return chunk
        except StopAsyncIteration:
            self._record(status="success")
            raise
        except Exception:
            self._record(status="error")
            raise

    def _record(self, status="success"):
        """Extract usage from accumulated chunks and record event once."""
        if self._recorded:
            return
        self._recorded = True
        try:
            elapsed_ms = self._create_elapsed_ms + int(
                (time.monotonic() - self._start_time) * 1000
            )
            model = self._kwargs.get("model", "unknown")
            input_tokens = 0
            output_tokens = 0

            for chunk in reversed(self._chunks):
                usage = getattr(chunk, "usage", None)
                if usage:
                    input_tokens = getattr(usage, "prompt_tokens", 0) or 0
                    output_tokens = getattr(usage, "completion_tokens", 0) or 0
                    if _config.debug:
                        _log_openai_token_details(usage, input_tokens, output_tokens)
                    break

            if getattr(self._chunks[0] if self._chunks else None, "model", None):
                model = self._chunks[0].model

            response_data = {
                "provider": "openai",
                "model": model,
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
                "status": status,
            }
            _build_and_enqueue(self._context, response_data, elapsed_ms)
        except Exception:
            pass

    def __getattr__(self, name):
        return getattr(self._stream, name)

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        self._record(status="error" if exc_type else "success")
        if hasattr(self._stream, "__aexit__"):
            return await self._stream.__aexit__(exc_type, exc_val, exc_tb)
        return False

    def close(self):
        self._record(status="success")
        if hasattr(self._stream, "close"):
            self._stream.close()

    def __del__(self):
        try:
            self._record(status="error")
        except Exception:
            pass


def wrap_async_stream(result, context, elapsed_ms, kwargs):
    """Wrap an async OpenAI stream."""
    return _WrappedAsyncStream(result, context, elapsed_ms, kwargs)
