"""Provider-specific patch targets, response parsing, and stream wrapping."""
