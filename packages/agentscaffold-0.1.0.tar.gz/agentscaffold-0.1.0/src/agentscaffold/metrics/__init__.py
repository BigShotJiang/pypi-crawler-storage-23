"""Metrics dashboard and reporting."""

from __future__ import annotations

from agentscaffold.metrics.dashboard import run_metrics

__all__ = ["run_metrics"]
