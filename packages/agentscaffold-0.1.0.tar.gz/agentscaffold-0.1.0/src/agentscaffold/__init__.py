"""AgentScaffold -- Structured AI-assisted development framework."""

__version__ = "0.1.0"
