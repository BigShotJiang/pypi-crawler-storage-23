"""Task runner setup (Justfile / Makefile generation)."""

from __future__ import annotations

from agentscaffold.taskrunner.setup import run_taskrunner_setup

__all__ = ["run_taskrunner_setup"]
