"""Notification sending (stdout, GitHub Issues, Slack)."""

from __future__ import annotations

from agentscaffold.notify.sender import send_notification

__all__ = ["send_notification"]
