"""CI provider setup and configuration."""

from __future__ import annotations

from agentscaffold.ci.setup import run_ci_setup

__all__ = ["run_ci_setup"]
