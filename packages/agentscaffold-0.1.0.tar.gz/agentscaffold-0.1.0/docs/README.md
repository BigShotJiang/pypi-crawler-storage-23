# AgentScaffold Documentation

| Document | Description |
|----------|-------------|
| [Getting Started](getting-started.md) | Installation, init, first plan, review, execution, retrospective, validation |
| [Configuration](configuration.md) | Full scaffold.yaml reference, gates, rigor presets |
| [Domain Packs](domain-packs.md) | Available packs, installation, using multiple packs |
| [Creating Domain Packs](creating-domain-packs.md) | Structure, manifest, prompts, standards |
| [Semi-Autonomous Guide](semi-autonomous-guide.md) | CLI/CI agent mode, session tracking, safety, notifications |
| [Importing Conversations](importing-conversations.md) | ChatGPT, markdown, Claude exports |
| [CI Integration](ci-integration.md) | scaffold ci setup, workflows, task runner |
