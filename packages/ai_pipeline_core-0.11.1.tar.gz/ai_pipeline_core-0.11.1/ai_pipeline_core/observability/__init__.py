"""Observability system for AI pipelines.

Contains debug tracing, ClickHouse-based tracking, and initialization utilities.
"""

__all__: list[str] = []
