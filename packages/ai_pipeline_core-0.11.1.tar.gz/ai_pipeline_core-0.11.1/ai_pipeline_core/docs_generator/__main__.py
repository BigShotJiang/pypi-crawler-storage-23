"""Entry point for python -m ai_pipeline_core.docs_generator."""

from ai_pipeline_core.docs_generator.cli import main

raise SystemExit(main())
