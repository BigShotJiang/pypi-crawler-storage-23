"""Entry point for: python -m ai_pipeline_core.replay run <file>."""

from .cli import main

raise SystemExit(main())
