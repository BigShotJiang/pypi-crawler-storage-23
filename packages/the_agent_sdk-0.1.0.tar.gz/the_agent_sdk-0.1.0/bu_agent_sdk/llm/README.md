# LLM Connectors

Current, implemented connectors in this repository:

- OpenAI (`ChatOpenAI`)
- OpenAI-compatible APIs (`ChatOpenAILike`)
- Anthropic (`ChatAnthropic`)
- Google Gemini (`ChatGoogle`)
- xAI Grok (`ChatGrok`)
No unresolved provider stubs are exported from `bu_agent_sdk.llm`.
