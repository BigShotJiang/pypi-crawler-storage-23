"""Shared test helpers — one definition, used everywhere."""
