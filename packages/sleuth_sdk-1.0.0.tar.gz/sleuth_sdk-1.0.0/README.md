# Sleuth SDK for Python

Official Python SDK for the [Sleuth Wallet Intelligence Platform](https://sleuth.io).

## Installation

```bash
pip install sleuth-sdk
```

## Quick Start

```python
from sleuth_sdk import SleuthClient

# Initialize client
client = SleuthClient(api_key="your_api_key")

# Search a wallet
profile = client.wallet.search("0xd8da6bf26964af9d7eed9e03e53415d37aa96045")
print(f"30d PnL: ${profile.pnl_30d:,.2f}")
print(f"Win Rate: {profile.win_rate}%")

# Get alpha signals (Premium)
signals = client.premium.get_signals(
    signal_types=["whale_accumulation", "smart_money_buy"],
    min_confidence=0.8
)

for signal in signals:
    print(f"{signal.signal_type}: {signal.token} ({signal.strength})")

# Get top traders to copy
traders = client.premium.get_top_traders()
for trader in traders:
    print(f"{trader['label']}: {trader['pnl_30d']}")
```

## Real-time Alerts (WebSocket)

```python
import asyncio
from sleuth_sdk import SleuthWebSocket

async def handle_alert(alert):
    print(f"🚨 {alert['alert_type']}: {alert['data']}")

async def main():
    ws = SleuthWebSocket(api_key="your_key")
    ws.on_alert = handle_alert
    
    # Subscribe to specific alert types
    await ws.connect()
    await ws.subscribe(["whale_movement", "alpha_signal", "rug_detected"])

asyncio.run(main())
```

## Available Features

### Free Tier
- Wallet search & analysis
- Basic social intel
- Trade history

### Premium Tiers
- Alpha signals API
- Wallet labels database (10M+ addresses)
- Token launch scanner
- Copy trade execution
- MEV protection
- Historical backtesting
- Social alpha (CT intelligence)

## Documentation

Full documentation at [docs.sleuth.io](https://docs.sleuth.io)

## License

MIT
