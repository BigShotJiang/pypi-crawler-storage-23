"""
Sleuth SDK - WebSocket Client for Real-time Alerts
"""

import json
import asyncio
import websockets
from typing import Optional, Callable, List, Dict, Any


class SleuthWebSocket:
    """
    WebSocket client for real-time Sleuth alerts
    
    Usage:
        async def handle_alert(alert):
            print(f"Got alert: {alert['alert_type']}")
        
        ws = SleuthWebSocket(api_key="your_key")
        ws.on_alert = handle_alert
        await ws.connect()
    """
    
    DEFAULT_WS_URL = "wss://api.sleuth.io/ws/alerts"
    
    def __init__(
        self,
        api_key: str,
        ws_url: Optional[str] = None,
        auto_reconnect: bool = True
    ):
        """
        Initialize WebSocket client
        
        Args:
            api_key: Your Sleuth API key
            ws_url: WebSocket URL (defaults to production)
            auto_reconnect: Auto-reconnect on disconnect
        """
        self.api_key = api_key
        self.ws_url = ws_url or self.DEFAULT_WS_URL
        self.auto_reconnect = auto_reconnect
        
        self._ws = None
        self._running = False
        
        # Event handlers
        self.on_alert: Optional[Callable[[Dict], Any]] = None
        self.on_connect: Optional[Callable[[], Any]] = None
        self.on_disconnect: Optional[Callable[[], Any]] = None
        self.on_error: Optional[Callable[[Exception], Any]] = None
    
    async def connect(self):
        """Connect to WebSocket and start receiving alerts"""
        self._running = True
        
        while self._running:
            try:
                async with websockets.connect(
                    f"{self.ws_url}?api_key={self.api_key}",
                    ping_interval=30,
                    ping_timeout=10
                ) as ws:
                    self._ws = ws
                    
                    if self.on_connect:
                        await self._call_handler(self.on_connect)
                    
                    async for message in ws:
                        await self._handle_message(message)
            
            except Exception as e:
                if self.on_error:
                    await self._call_handler(self.on_error, e)
                
                if self.on_disconnect:
                    await self._call_handler(self.on_disconnect)
                
                if self.auto_reconnect and self._running:
                    await asyncio.sleep(5)  # Wait before reconnect
                else:
                    break
    
    async def _handle_message(self, message: str):
        """Handle incoming WebSocket message"""
        try:
            data = json.loads(message)
            
            if data.get("type") == "alert" and self.on_alert:
                await self._call_handler(self.on_alert, data)
        except json.JSONDecodeError:
            pass
    
    async def _call_handler(self, handler: Callable, *args):
        """Call handler (sync or async)"""
        result = handler(*args)
        if asyncio.iscoroutine(result):
            await result
    
    async def subscribe(self, alert_types: List[str]):
        """Subscribe to specific alert types"""
        if self._ws:
            await self._ws.send(json.dumps({
                "action": "subscribe",
                "alert_types": alert_types
            }))
    
    async def disconnect(self):
        """Disconnect from WebSocket"""
        self._running = False
        if self._ws:
            await self._ws.close()
