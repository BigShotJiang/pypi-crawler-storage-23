"""
Sleuth SDK - Main Client
"""

import httpx
from typing import Optional, Dict, Any, List
from .exceptions import SleuthError, AuthenticationError, RateLimitError, TrialLimitError
from .models import WalletProfile, AlphaSignal


class SleuthClient:
    """
    Main client for interacting with Sleuth API
    
    Usage:
        client = SleuthClient(api_key="your_api_key")
        
        # Search wallet
        profile = client.wallet.search("0xd8da6bf26964af9d7eed9e03e53415d37aa96045")
        print(profile.pnl_30d)
        
        # Get alpha signals
        signals = client.premium.get_signals(signal_types=["whale_accumulation"])
    """
    
    DEFAULT_BASE_URL = "https://api.sleuth.io"
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: int = 30
    ):
        """
        Initialize Sleuth client
        
        Args:
            api_key: Your Sleuth API key (get one at https://sleuth.io/developer)
            base_url: API base URL (defaults to production)
            timeout: Request timeout in seconds
        """
        self.api_key = api_key
        self.base_url = (base_url or self.DEFAULT_BASE_URL).rstrip("/")
        self.timeout = timeout
        
        # Sub-clients
        self.wallet = WalletAPI(self)
        self.premium = PremiumAPI(self)
        self.social = SocialAPI(self)
        self.alerts = AlertsAPI(self)
    
    def _get_headers(self) -> Dict[str, str]:
        """Get request headers"""
        headers = {
            "Content-Type": "application/json",
            "User-Agent": "sleuth-sdk-python/1.0.0"
        }
        if self.api_key:
            headers["X-API-Key"] = self.api_key
        return headers
    
    def _request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict] = None,
        json: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """Make HTTP request to API"""
        url = f"{self.base_url}{endpoint}"
        
        with httpx.Client(timeout=self.timeout) as client:
            response = client.request(
                method=method,
                url=url,
                headers=self._get_headers(),
                params=params,
                json=json
            )
        
        # Handle errors
        if response.status_code == 401:
            raise AuthenticationError("Invalid or missing API key")
        elif response.status_code == 429:
            data = response.json()
            if "trial_limit" in str(data):
                raise TrialLimitError(data.get("detail", {}).get("message", "Trial limit exceeded"))
            raise RateLimitError("Rate limit exceeded")
        elif response.status_code >= 400:
            raise SleuthError(f"API error: {response.status_code} - {response.text}")
        
        return response.json()
    
    def get(self, endpoint: str, params: Optional[Dict] = None) -> Dict:
        """GET request"""
        return self._request("GET", endpoint, params=params)
    
    def post(self, endpoint: str, json: Optional[Dict] = None) -> Dict:
        """POST request"""
        return self._request("POST", endpoint, json=json)


class WalletAPI:
    """Wallet-related API endpoints"""
    
    def __init__(self, client: SleuthClient):
        self.client = client
    
    def search(self, address: str) -> WalletProfile:
        """
        Search and analyze a wallet address
        
        Args:
            address: Wallet address to analyze
            
        Returns:
            WalletProfile with PnL, trades, and more
        """
        data = self.client.post("/api/sleuth/wallet/search", json={"address": address})
        return WalletProfile.from_dict(data.get("wallet", data))
    
    def get_trades(self, address: str, limit: int = 50) -> List[Dict]:
        """Get recent trades for a wallet"""
        data = self.client.get(f"/api/sleuth/wallet/{address}/trades", params={"limit": limit})
        return data.get("trades", [])
    
    def get_social(self, address: str) -> Dict:
        """Get social intel for a wallet"""
        return self.client.get(f"/api/sleuth/social/wallet/{address}")


class PremiumAPI:
    """Premium feature endpoints"""
    
    def __init__(self, client: SleuthClient):
        self.client = client
    
    def get_signals(
        self,
        signal_types: Optional[List[str]] = None,
        min_confidence: float = 0.7,
        limit: int = 50
    ) -> List[AlphaSignal]:
        """
        Get alpha signals
        
        Args:
            signal_types: Filter by signal type (whale_accumulation, smart_money_buy, etc.)
            min_confidence: Minimum confidence score (0-1)
            limit: Max results
            
        Returns:
            List of AlphaSignal objects
        """
        params = {"min_confidence": min_confidence, "limit": limit}
        if signal_types:
            params["signal_types"] = ",".join(signal_types)
        
        data = self.client.get("/api/premium/signals", params=params)
        return [AlphaSignal.from_dict(s) for s in data.get("signals", [])]
    
    def get_wallet_label(self, address: str) -> Dict:
        """Get label for a wallet address"""
        return self.client.get(f"/api/premium/labels/{address}")
    
    def get_top_traders(self) -> List[Dict]:
        """Get top traders to copy"""
        data = self.client.get("/api/premium/copy-trade/top-traders")
        return data.get("traders", [])
    
    def get_token_launches(self, chains: Optional[List[str]] = None, limit: int = 50) -> List[Dict]:
        """Get recent token launches"""
        params = {"limit": limit}
        if chains:
            params["chains"] = ",".join(chains)
        
        data = self.client.get("/api/premium/launches", params=params)
        return data.get("launches", [])
    
    def get_trending_social(self) -> List[Dict]:
        """Get trending tokens by social activity"""
        data = self.client.get("/api/premium/social/trending")
        return data.get("trending", [])
    
    def submit_mev_protected_tx(self, chain: str, transaction: Dict) -> Dict:
        """Submit MEV-protected transaction"""
        return self.client.post("/api/premium/mev/submit", json={
            "chain": chain,
            "transaction": transaction
        })


class SocialAPI:
    """Social/Twitter API endpoints"""
    
    def __init__(self, client: SleuthClient):
        self.client = client
    
    def get_user(self, username: str) -> Dict:
        """Get Twitter user profile"""
        return self.client.get(f"/api/sleuth/twitter/user/{username}")
    
    def search_tweets(self, query: str, limit: int = 50) -> List[Dict]:
        """Search tweets"""
        data = self.client.post("/api/sleuth/twitter/search", json={"query": query, "limit": limit})
        return data.get("tweets", [])


class AlertsAPI:
    """Alerts API endpoints"""
    
    def __init__(self, client: SleuthClient):
        self.client = client
    
    def subscribe(self, wallet: str, alert_types: List[str]) -> Dict:
        """Subscribe to alerts for a wallet"""
        return self.client.post("/api/alerts/subscribe", json={
            "wallet_address": wallet,
            "alert_types": alert_types
        })
    
    def list_subscriptions(self) -> List[Dict]:
        """List active alert subscriptions"""
        data = self.client.get("/api/alerts/subscriptions")
        return data.get("subscriptions", [])
