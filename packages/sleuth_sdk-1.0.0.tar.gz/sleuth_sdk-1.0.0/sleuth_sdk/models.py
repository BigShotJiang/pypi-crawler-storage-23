"""
Sleuth SDK - Data Models
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any
from datetime import datetime


@dataclass
class WalletProfile:
    """Wallet profile with PnL and activity data"""
    
    address: str
    pnl_30d: float
    pnl_1y: float
    win_rate: float
    total_trades: int
    top_tokens: List[str]
    chains_active: List[str]
    risk_score: int
    label: Optional[str] = None
    twitter: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "WalletProfile":
        """Create from API response dict"""
        return cls(
            address=data.get("address", ""),
            pnl_30d=data.get("pnl_30d", 0),
            pnl_1y=data.get("pnl_1y", 0),
            win_rate=data.get("win_rate", 0),
            total_trades=data.get("total_trades", 0),
            top_tokens=data.get("top_tokens", []),
            chains_active=data.get("chains_active", []),
            risk_score=data.get("risk_score", 50),
            label=data.get("label"),
            twitter=data.get("twitter")
        )


@dataclass
class AlphaSignal:
    """Alpha signal from Sleuth"""
    
    signal_type: str
    token: str
    chain: str
    strength: str  # strong, moderate, weak
    confidence: float
    volume_usd: float
    wallets_involved: int
    timestamp: str
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AlphaSignal":
        """Create from API response dict"""
        return cls(
            signal_type=data.get("signal_type", ""),
            token=data.get("token", ""),
            chain=data.get("chain", ""),
            strength=data.get("strength", "moderate"),
            confidence=data.get("confidence", 0),
            volume_usd=data.get("volume_usd", 0),
            wallets_involved=data.get("wallets_involved", 0),
            timestamp=data.get("timestamp", "")
        )


@dataclass
class WhaleAlert:
    """Whale movement alert"""
    
    wallet: str
    token: str
    amount_usd: float
    direction: str  # in, out
    chain: str
    timestamp: str
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "WhaleAlert":
        return cls(
            wallet=data.get("wallet", ""),
            token=data.get("token", ""),
            amount_usd=data.get("amount_usd", 0),
            direction=data.get("direction", ""),
            chain=data.get("chain", ""),
            timestamp=data.get("timestamp", "")
        )


@dataclass
class TradeSignal:
    """Copy trade signal"""
    
    source_wallet: str
    action: str  # buy, sell
    token: str
    amount_usd: float
    confidence: str  # HIGH, MEDIUM, LOW
    source_pnl: str
    timestamp: str
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TradeSignal":
        return cls(
            source_wallet=data.get("source_wallet", ""),
            action=data.get("action", ""),
            token=data.get("token", ""),
            amount_usd=data.get("amount_usd", 0),
            confidence=data.get("confidence", "LOW"),
            source_pnl=data.get("source_pnl", ""),
            timestamp=data.get("timestamp", "")
        )
