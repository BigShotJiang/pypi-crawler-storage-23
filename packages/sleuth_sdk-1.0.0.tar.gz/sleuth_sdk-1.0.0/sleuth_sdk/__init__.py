"""
Sleuth SDK for Python
Official Python SDK for the Sleuth Wallet Intelligence Platform

Install: pip install sleuth-sdk
Docs: https://docs.sleuth.io
"""

__version__ = "1.0.0"
__author__ = "Sleuth Team"

from .client import SleuthClient
from .websocket import SleuthWebSocket
from .models import WalletProfile, AlphaSignal, WhaleAlert, TradeSignal
from .exceptions import SleuthError, AuthenticationError, RateLimitError, TrialLimitError

__all__ = [
    "SleuthClient",
    "SleuthWebSocket", 
    "WalletProfile",
    "AlphaSignal",
    "WhaleAlert",
    "TradeSignal",
    "SleuthError",
    "AuthenticationError",
    "RateLimitError",
    "TrialLimitError"
]
