"""
Sleuth SDK - Exceptions
"""


class SleuthError(Exception):
    """Base exception for Sleuth SDK"""
    pass


class AuthenticationError(SleuthError):
    """Raised when API key is invalid or missing"""
    pass


class RateLimitError(SleuthError):
    """Raised when rate limit is exceeded"""
    pass


class TrialLimitError(SleuthError):
    """Raised when trial limit is exceeded"""
    
    def __init__(self, message: str = "Trial limit exceeded"):
        self.message = message
        self.upgrade_url = "/developer/billing"
        super().__init__(f"{message}. Upgrade at: {self.upgrade_url}")
