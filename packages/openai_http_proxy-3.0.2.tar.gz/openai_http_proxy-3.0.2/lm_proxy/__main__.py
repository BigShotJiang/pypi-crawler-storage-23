"""Provides the CLI entry point when the package is executed as a Python module."""

from .app import cli_app


if __name__ == "__main__":
    cli_app()
