"""
Flex Meditate — offline graph intelligence.

Produces columns that SQL consumes. networkx computes things SQL can't:
PageRank, Louvain communities, hub/bridge identification.

Output is INSERT INTO _enrich_* tables. Once persisted as columns,
SQL composes them freely. networkx is the producer, SQL is the consumer.

Four functions:
- build_similarity_graph() → embeddings → networkx graph
- compute_scores()         → louvain, pagerank, hubs, bridges
- persist()                → INSERT INTO _enrich_*, regenerate views
- run_sandbox()            → execute arbitrary networkx script
"""

import numpy as np
import sqlite3
from typing import Optional


def build_similarity_graph(db: sqlite3.Connection, table: str = '_raw_sources',
                           id_col: str = 'id', embedding_col: str = 'embedding',
                           threshold: float = 0.5, top_k: int = None,
                           where: str = None, center: bool = False):
    """
    Build similarity graph from embeddings via matrix multiply.

    Args:
        db: SQLite connection
        table: Table with embeddings
        id_col: Column with item identifiers
        embedding_col: Column with embedding blobs
        threshold: Minimum cosine similarity for edge creation
        top_k: If set, keep only top K neighbors per node
        where: Optional SQL WHERE fragment to filter rows (e.g.
               "source_id IN (SELECT source_id FROM _edges_source
               GROUP BY source_id HAVING COUNT(*) >= 20)")
        center: If True, subtract corpus mean before similarity computation.
                Removes shared embedding direction (e.g. "I'm a Claude Code
                session"), making pairwise similarity reflect topical
                differences rather than shared vocabulary.

    Returns:
        (NetworkX graph, edge_count) or (None, 0)
    """
    import networkx as nx

    # Load embeddings
    query = (
        f"SELECT [{id_col}], [{embedding_col}] FROM [{table}] "
        f"WHERE [{embedding_col}] IS NOT NULL"
    )
    if where:
        query += f" AND ({where})"
    rows = db.execute(query).fetchall()

    if not rows:
        return None, 0

    item_ids = []
    embeddings = []
    for row in rows:
        item_ids.append(row[0])
        embeddings.append(np.frombuffer(row[1], dtype=np.float32))

    # Matrix multiply for all-pairs cosine similarity
    emb_matrix = np.vstack(embeddings)
    norms = np.linalg.norm(emb_matrix, axis=1, keepdims=True)
    emb_matrix = emb_matrix / (norms + 1e-10)

    # Mean centering: subtract corpus mean, re-normalize.
    # What remains is what makes each item *different* from the average.
    if center:
        corpus_mean = emb_matrix.mean(axis=0)
        emb_matrix = emb_matrix - corpus_mean
        norms = np.linalg.norm(emb_matrix, axis=1, keepdims=True)
        norms[norms == 0] = 1  # avoid div by zero
        emb_matrix = emb_matrix / norms

    sim_matrix = emb_matrix @ emb_matrix.T

    # Build graph — vectorized edge creation
    G = nx.Graph()
    for item_id in item_ids:
        G.add_node(item_id)

    n = len(item_ids)
    edge_count = 0

    if top_k:
        for i in range(n):
            sims = sim_matrix[i]
            top_indices = np.argsort(sims)[::-1][1:top_k + 1]
            for j in top_indices:
                if sims[j] > 0.1:
                    G.add_edge(item_ids[i], item_ids[j],
                               weight=float(sims[j]))
                    edge_count += 1
    else:
        # Vectorized: compute boolean mask, extract qualifying pairs
        mask = sim_matrix >= threshold
        np.fill_diagonal(mask, False)
        ii, jj = np.where(np.triu(mask))
        for idx in range(len(ii)):
            G.add_edge(item_ids[ii[idx]], item_ids[jj[idx]],
                        weight=float(sim_matrix[ii[idx], jj[idx]]))
        edge_count = len(ii)

    print(f"Graph: {G.number_of_nodes()} nodes, {edge_count} edges")
    return G, edge_count


def compute_scores(G) -> dict:
    """
    Run graph algorithms on a networkx graph.

    Returns:
        {
            'communities': [{'id': int, 'members': [str]}],
            'centralities': {node_id: float},
            'hubs': [node_id],
            'bridges': [node_id],
        }
    """
    import networkx as nx
    from networkx.algorithms import community as nx_community

    if G is None or G.number_of_nodes() == 0:
        return {'communities': [], 'centralities': {}, 'hubs': [], 'bridges': []}

    # Louvain community detection
    communities = []
    try:
        partition = nx_community.louvain_communities(G, seed=42)
        for i, members in enumerate(partition):
            communities.append({
                'id': i,
                'members': list(members),
                'size': len(members)
            })
    except (nx.NetworkXError, ValueError, ZeroDivisionError):
        pass

    # PageRank centrality
    try:
        centralities = nx.pagerank(G, weight='weight')
    except (nx.NetworkXError, nx.PowerIterationFailedConvergence, ZeroDivisionError):
        centralities = {}

    # Hub identification (top 10% by centrality)
    hubs = []
    if centralities:
        sorted_nodes = sorted(centralities.items(), key=lambda x: x[1], reverse=True)
        hub_threshold = max(1, len(sorted_nodes) // 10)
        hubs = [node for node, _ in sorted_nodes[:hub_threshold]]

    # Bridge identification (high betweenness centrality)
    # Use approximate betweenness (k samples) for large graphs to avoid O(V*E)
    bridges = []
    try:
        n_nodes = G.number_of_nodes()
        if n_nodes > 500:
            k = min(100, n_nodes // 5)
            betweenness = nx.betweenness_centrality(G, weight='weight', k=k)
        else:
            betweenness = nx.betweenness_centrality(G, weight='weight')
        if betweenness:
            sorted_bridges = sorted(betweenness.items(), key=lambda x: x[1], reverse=True)
            bridge_threshold = max(1, len(sorted_bridges) // 20)
            bridges = [node for node, _ in sorted_bridges[:bridge_threshold]]
    except (nx.NetworkXError, ZeroDivisionError):
        pass

    return {
        'communities': communities,
        'centralities': centralities,
        'hubs': hubs,
        'bridges': bridges,
    }


def persist(db: sqlite3.Connection, scores: dict,
            table: str = '_enrich_source_graph',
            id_col: str = None):
    """
    Write graph scores to enrichment table.

    Creates table if needed. Wipes and rewrites (enrichments are mutable).
    Caller should run regenerate_views() after.

    Args:
        db: SQLite connection
        scores: Output from compute_scores()
        table: Target enrichment table
        id_col: Column for the node identifier. Auto-detected from table
                name if None: 'source_id' if 'source' in table, else 'chunk_id'.
    """
    if id_col is None:
        id_col = 'source_id' if 'source' in table else 'chunk_id'

    # Create table if not exists
    db.execute(f"""
        CREATE TABLE IF NOT EXISTS [{table}] (
            [{id_col}] TEXT PRIMARY KEY,
            centrality REAL,
            is_hub INTEGER DEFAULT 0,
            is_bridge INTEGER DEFAULT 0,
            community_id INTEGER,
            community_label TEXT
        )
    """)

    # Wipe existing (enrichments are always safe to wipe)
    db.execute(f"DELETE FROM [{table}]")

    # Build community membership map
    community_map = {}
    for comm in scores.get('communities', []):
        for member in comm.get('members', []):
            community_map[member] = comm['id']

    hub_set = set(scores.get('hubs', []))
    bridge_set = set(scores.get('bridges', []))
    centralities = scores.get('centralities', {})

    # Collect all node IDs
    all_ids = set(centralities.keys())
    for comm in scores.get('communities', []):
        all_ids.update(comm.get('members', []))

    # Insert
    for node_id in all_ids:
        db.execute(
            f"INSERT OR REPLACE INTO [{table}] "
            f"([{id_col}], centrality, is_hub, is_bridge, community_id) "
            f"VALUES (?, ?, ?, ?, ?)",
            (
                node_id,
                centralities.get(node_id, 0.0),
                1 if node_id in hub_set else 0,
                1 if node_id in bridge_set else 0,
                community_map.get(node_id),
            )
        )

    db.commit()
    print(f"Persisted {len(all_ids)} graph scores to {table}")

    # Log mutation
    from flex.core import log_op
    log_op(db, 'persist_graph_scores', table,
           rows_affected=len(all_ids), source='meditate.py')

    # Regenerate views to pick up new/changed enrichment
    from flex.core import regenerate_views
    regenerate_views(db)


def run_sandbox(db: sqlite3.Connection, G, script: str) -> dict:
    """
    Execute arbitrary networkx script in a sandboxed environment.

    The script has access to: graph (G), db, numpy, networkx.
    It writes results to the `result` dict.

    Args:
        db: SQLite connection
        G: NetworkX graph
        script: Python code string

    Returns:
        The `result` dict from the sandbox
    """
    import json
    import networkx as nx
    from networkx.algorithms import community as nx_community
    from collections import Counter

    safe_globals = {
        'np': np, 'nx': nx,
        'nx_community': nx_community,
        'Counter': Counter,
        'graph': G, 'db': db,
        'result': {},
        '__builtins__': {
            k: v for k, v in (
                __builtins__ if isinstance(__builtins__, dict)
                else vars(__builtins__)
            ).items()
            if k in {
                'print', 'len', 'range', 'enumerate', 'str', 'int', 'float',
                'list', 'dict', 'set', 'tuple', 'bool', 'None', 'True', 'False',
                'isinstance', 'sorted', 'min', 'max', 'sum', 'round',
                'zip', 'map', 'filter', 'any', 'all', 'abs', 'hasattr',
                'getattr', 'setattr', 'ValueError', 'TypeError', 'KeyError',
                'Exception',
            }
        },
    }

    try:
        exec(compile(script, '<meditate>', 'exec'), safe_globals)
        result = safe_globals.get('result', {})
        parsed = json.loads(json.dumps(
            result,
            default=lambda x: int(x) if hasattr(x, 'item') else str(x)
        ))

        # Log sandbox execution
        from flex.core import log_op
        log_op(db, 'run_sandbox', '_enrich_*',
               params={'script_len': len(script),
                       'result_keys': list(parsed.keys()) if isinstance(parsed, dict) else None},
               sql=script[:500] if script else None,
               source='meditate.py')

        return parsed
    except (SyntaxError, NameError, TypeError, ValueError, KeyError,
            AttributeError, IndexError, ZeroDivisionError, RuntimeError,
            ArithmeticError, LookupError, StopIteration, ImportError) as e:
        return {'error': str(e), 'type': type(e).__name__}
