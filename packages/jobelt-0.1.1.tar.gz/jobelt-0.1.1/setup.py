from setuptools import setup, find_packages
from pathlib import Path

this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text()

setup(
    name="jobelt",  # make sure this name is available on PyPI
    version="0.1.1",
    description="Python ETL framework with Business Rule Validator for Databricks and PostgreSQL",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Complere Infosystem",
    author_email="puneet.taneja@complereinfosystem.com",
    packages=find_packages(exclude=["tests*", "build*", "dist*"]),
    include_package_data=True,
    install_requires=[
        "pandas>=1.3.0",
        "pyspark>=3.0.0",
        "databricks-sdk>=0.1.0",
        "psycopg2-binary>=2.9.0",
        "sqlalchemy>=1.4.0",
        "pytz"
    ],
    python_requires=">=3.8",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "License :: OSI Approved :: MIT License",
    ],
)