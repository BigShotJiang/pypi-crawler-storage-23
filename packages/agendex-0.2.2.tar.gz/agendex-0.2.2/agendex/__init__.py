"""
Agendex SDK - Governance for AI Agents

Runtime policy enforcement, activity capture, and approval workflows
for LangChain, CrewAI, and custom agent frameworks.

Quick Start:
    from agendex import AgendexClient, GovernedDBClient, GovernedTool

    client = AgendexClient()  # Reads from env vars
    db = GovernedDBClient(client, task="monthly_report")

    # All DB calls are now governed at resource level
    result = db.query("monthly_revenue", {"month": "2025-01"})

    # With reasoning for audit trail
    result = db.query(
        "monthly_revenue",
        {"month": "2025-01"},
        reasoning="User requested Q1 financial summary"
    )

    # Task switching (safe for concurrent use)
    with db.with_task("audit") as db_audit:
        db_audit.query("all_transactions", {})

    # Generic tool for custom actions
    slack = GovernedTool(client, action="slack.post", task="alerts")
    slack.invoke(channel="#ops", message="Alert!")

Configuration:
    from agendex import configure_actions

    # Override default action names globally
    configure_actions(
        db_query="database.execute",
        http_request="api.call",
    )
"""

from .client import AgendexClient
from .errors import (
    AgendexError,
    DeniedError,
    PendingApprovalError,
    ShadowDecisionError,
    ConnectionError as AgendexConnectionError,
)
from .db import GovernedDBClient
from .s3 import GovernedS3Client
from .http import GovernedHTTPSession
from .crm import GovernedCRMClient
from .tool import GovernedTool
from .config import configure_actions, ActionConfig, get_global_config, reset_config
from .context import set_reasoning, get_reasoning, clear_reasoning
from .integrations.agentx import (
    AgentXGovernanceConfig,
    AgentXGovernanceHooks,
    GovernedAgentBuilder,
    enable_agentx_governance,
    install_agentx_runtime_shims,
)
# Framework integrations
from . import langchain
from . import crewai

from importlib.metadata import version as _pkg_version

__version__ = _pkg_version("agendex")

__all__ = [
    # Core
    "AgendexClient",
    # Resource clients (the main integration surface)
    "GovernedDBClient",
    "GovernedS3Client",
    "GovernedHTTPSession",
    "GovernedCRMClient",
    # Generic tool
    "GovernedTool",
    # Configuration
    "configure_actions",
    "ActionConfig",
    "get_global_config",
    "reset_config",
    # Context (for auto-reasoning)
    "set_reasoning",
    "get_reasoning",
    "clear_reasoning",
    # AgentX integration hooks
    "AgentXGovernanceConfig",
    "AgentXGovernanceHooks",
    "GovernedAgentBuilder",
    "enable_agentx_governance",
    "install_agentx_runtime_shims",
    # Framework integrations
    "langchain",
    "crewai",
    # Errors
    "AgendexError",
    "DeniedError",
    "PendingApprovalError",
    "ShadowDecisionError",
    "AgendexConnectionError",
    "__version__",
]
