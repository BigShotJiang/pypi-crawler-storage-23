"""
Context Variables for Agendex SDK.

Provides async-safe storage for reasoning and other context that can be
automatically captured from agent frameworks (LangChain, CrewAI) and
injected into governed operations.
"""
from contextvars import ContextVar
from typing import Optional

# Current reasoning for the async context
_current_reasoning: ContextVar[Optional[str]] = ContextVar(
    "agendex_reasoning", default=None
)


def set_reasoning(reasoning: str) -> None:
    """
    Set the current reasoning for this async context.

    This is typically called by framework callbacks (LangChain, CrewAI)
    when the agent provides reasoning before a tool call.

    Args:
        reasoning: The agent's reasoning/explanation
    """
    _current_reasoning.set(reasoning)


def get_reasoning() -> Optional[str]:
    """
    Get the current reasoning for this async context.

    Returns None if no reasoning has been set.
    """
    return _current_reasoning.get()


def clear_reasoning() -> None:
    """
    Clear the current reasoning after a tool call completes.

    This prevents stale reasoning from being attached to subsequent calls.
    """
    _current_reasoning.set(None)
