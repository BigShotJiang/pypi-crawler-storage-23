from py_auto_migrate.migrate_models.base import BaseMigration
from py_auto_migrate.base_models.base_mssql import BaseMSSQL
from py_auto_migrate.insert_models.insert_mssql import InsertMSSQL

from py_auto_migrate.insert_models.insert_mysql import InsertMySQL
from py_auto_migrate.insert_models.insert_mongodb import InsertMongoDB
from py_auto_migrate.insert_models.insert_sqlite import InsertSQLite
from py_auto_migrate.insert_models.insert_postgressql import InsertPostgresSQL
from py_auto_migrate.insert_models.insert_mariadb import InsertMariaDB
from py_auto_migrate.insert_models.insert_oracle import InsertOracle
from py_auto_migrate.insert_models.insert_redis import InsertRedis
from py_auto_migrate.insert_models.insert_dynamodb import InsertDynamoDB
from py_auto_migrate.insert_models.insert_elasticsearch import InsertElasticsearch
from py_auto_migrate.insert_models.insert_clickhouse import InsertClickHouse



class BaseMSSQLMigration(BaseMigration, BaseMSSQL):

    def _initialize_source_connection(self):
        BaseMSSQL.__init__(self, self.source_uri)
    
    def read_table(self, collection_name: str):
        return BaseMSSQL.read_table(self, collection_name)
    
    def get_tables(self):
        return BaseMSSQL.get_tables(self)


class MSSQLToMySQL(BaseMSSQLMigration):
    def __init__(self, source_uri, target_uri):
        super().__init__(source_uri, target_uri, InsertMySQL)


class MSSQLToPostgres(BaseMSSQLMigration):
    def __init__(self, source_uri, target_uri):
        super().__init__(source_uri, target_uri, InsertPostgresSQL)


class MSSQLToSQLite(BaseMSSQLMigration):
    def __init__(self, source_uri, target_uri):
        super().__init__(source_uri, target_uri, InsertSQLite)


class MSSQLToMaria(BaseMSSQLMigration):
    def __init__(self, source_uri, target_uri):
        super().__init__(source_uri, target_uri, InsertMariaDB)


class MSSQLToMSSQL(BaseMSSQLMigration):
    def __init__(self, source_uri, target_uri):
        super().__init__(source_uri, target_uri, InsertMSSQL)


class MSSQLToMongo(BaseMSSQLMigration):
    def __init__(self, source_uri, target_uri):
        super().__init__(source_uri, target_uri, InsertMongoDB)


class MSSQLToOracle(BaseMSSQLMigration):
    def __init__(self, source_uri, target_uri):
        super().__init__(source_uri, target_uri, InsertOracle)


class MSSQLToRedis(BaseMSSQLMigration):
    def __init__(self, source_uri, target_uri):
        super().__init__(source_uri, target_uri, InsertRedis)


class MSSQLToDynamoDB(BaseMSSQLMigration):
    def __init__(self, source_uri, target_uri):
        super().__init__(source_uri, target_uri, InsertDynamoDB)


class MSSQLToElastic(BaseMSSQLMigration):
    def __init__(self, source_uri, target_uri):
        super().__init__(source_uri, target_uri, InsertElasticsearch)


class MSSQLToClickHouse(BaseMSSQLMigration):
    def __init__(self, source_uri, target_uri):
        super().__init__(source_uri, target_uri, InsertClickHouse)