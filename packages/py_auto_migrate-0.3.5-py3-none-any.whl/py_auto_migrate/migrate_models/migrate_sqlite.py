from py_auto_migrate.migrate_models.base import BaseMigration
from py_auto_migrate.base_models.base_sqlite import BaseSQLite
from py_auto_migrate.insert_models.insert_sqlite import InsertSQLite

from py_auto_migrate.insert_models.insert_mssql import InsertMSSQL
from py_auto_migrate.insert_models.insert_mongodb import InsertMongoDB
from py_auto_migrate.insert_models.insert_postgressql import InsertPostgresSQL
from py_auto_migrate.insert_models.insert_mysql import InsertMySQL
from py_auto_migrate.insert_models.insert_mariadb import InsertMariaDB
from py_auto_migrate.insert_models.insert_oracle import InsertOracle
from py_auto_migrate.insert_models.insert_redis import InsertRedis
from py_auto_migrate.insert_models.insert_dynamodb import InsertDynamoDB
from py_auto_migrate.insert_models.insert_elasticsearch import InsertElasticsearch
from py_auto_migrate.insert_models.insert_clickhouse import InsertClickHouse


class BaseSQLiteMigration(BaseMigration, BaseSQLite):

    def _initialize_source_connection(self):
        BaseSQLite.__init__(self, self.source_uri)

    def read_table(self, collection_name: str):
        return BaseSQLite.read_table(self, collection_name)

    def get_tables(self):
        return BaseSQLite.get_tables(self)


class SQLiteToMySQL(BaseSQLiteMigration):
    def __init__(self, source_uri, target_uri):
        super().__init__(source_uri, target_uri, InsertMySQL)


class SQLiteToMongo(BaseSQLiteMigration):
    def __init__(self, source_uri, target_uri):
        super().__init__(source_uri, target_uri, InsertMongoDB)


class SQLiteToSQLite(BaseSQLiteMigration):
    def __init__(self, source_uri, target_uri):
        super().__init__(source_uri, target_uri, InsertSQLite)


class SQLiteToPostgres(BaseSQLiteMigration):
    def __init__(self, source_uri, target_uri):
        super().__init__(source_uri, target_uri, InsertPostgresSQL)


class SQLiteToMaria(BaseSQLiteMigration):
    def __init__(self, source_uri, target_uri):
        super().__init__(source_uri, target_uri, InsertMariaDB)


class SQLiteToMSSQL(BaseSQLiteMigration):
    def __init__(self, source_uri, target_uri):
        super().__init__(source_uri, target_uri, InsertMSSQL)


class SQLiteToOracle(BaseSQLiteMigration):
    def __init__(self, source_uri, target_uri):
        super().__init__(source_uri, target_uri, InsertOracle)


class SQLiteToRedis(BaseSQLiteMigration):
    def __init__(self, source_uri, target_uri):
        super().__init__(source_uri, target_uri, InsertRedis)


class SQLiteToDynamoDB(BaseSQLiteMigration):
    def __init__(self, source_uri, target_uri):
        super().__init__(source_uri, target_uri, InsertDynamoDB)


class SQLiteToElastic(BaseSQLiteMigration):
    def __init__(self, source_uri, target_uri):
        super().__init__(source_uri, target_uri, InsertElasticsearch)


class SQLiteToClickHouse(BaseSQLiteMigration):
    def __init__(self, source_uri, target_uri):
        super().__init__(source_uri, target_uri, InsertClickHouse)
