from py_auto_migrate.migrate_models.base import BaseMigration
from py_auto_migrate.base_models.base_elasticsearch import BaseElasticsearch
from py_auto_migrate.insert_models.insert_elasticsearch import InsertElasticsearch

from py_auto_migrate.insert_models.insert_mssql import InsertMSSQL
from py_auto_migrate.insert_models.insert_mongodb import InsertMongoDB
from py_auto_migrate.insert_models.insert_postgressql import InsertPostgresSQL
from py_auto_migrate.insert_models.insert_mysql import InsertMySQL
from py_auto_migrate.insert_models.insert_mariadb import InsertMariaDB
from py_auto_migrate.insert_models.insert_oracle import InsertOracle
from py_auto_migrate.insert_models.insert_redis import InsertRedis
from py_auto_migrate.insert_models.insert_dynamodb import InsertDynamoDB
from py_auto_migrate.insert_models.insert_sqlite import InsertSQLite
from py_auto_migrate.insert_models.insert_clickhouse import InsertClickHouse



class BaseElasticMigration(BaseMigration, BaseElasticsearch):

    def _initialize_source_connection(self):
        BaseElasticsearch.__init__(self, self.source_uri)
    
    def read_table(self, collection_name: str):
        return BaseElasticsearch.read_table(self, collection_name)
    
    def get_tables(self):
        return BaseElasticsearch.get_tables(self)



class ElasticToMySQL(BaseElasticMigration):
    def __init__(self, source_uri, target_uri):
        super().__init__(source_uri, target_uri, InsertMySQL)


class ElasticToMongo(BaseElasticMigration):
    def __init__(self, source_uri, target_uri):
        super().__init__(source_uri, target_uri, InsertMongoDB)


class ElasticToSQLite(BaseElasticMigration):
    def __init__(self, source_uri, target_uri):
        super().__init__(source_uri, target_uri, InsertSQLite)


class ElasticToPostgres(BaseElasticMigration):
    def __init__(self, source_uri, target_uri):
        super().__init__(source_uri, target_uri, InsertPostgresSQL)


class ElasticToMaria(BaseElasticMigration):
    def __init__(self, source_uri, target_uri):
        super().__init__(source_uri, target_uri, InsertMariaDB)


class ElasticToMSSQL(BaseElasticMigration):
    def __init__(self, source_uri, target_uri):
        super().__init__(source_uri, target_uri, InsertMSSQL)


class ElasticToOracle(BaseElasticMigration):
    def __init__(self, source_uri, target_uri):
        super().__init__(source_uri, target_uri, InsertOracle)


class ElasticToRedis(BaseElasticMigration):
    def __init__(self, source_uri, target_uri):
        super().__init__(source_uri, target_uri, InsertRedis)


class ElasticToDynamoDB(BaseElasticMigration):
    def __init__(self, source_uri, target_uri):
        super().__init__(source_uri, target_uri, InsertDynamoDB)


class ElasticToElastic(BaseElasticMigration):
    def __init__(self, source_uri, target_uri):
        super().__init__(source_uri, target_uri, InsertElasticsearch)


class ElasticToClickHouse(BaseElasticMigration):
    def __init__(self, source_uri, target_uri):
        super().__init__(source_uri, target_uri, InsertClickHouse)