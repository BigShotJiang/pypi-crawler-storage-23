"""
Logger module providing a ``Logger`` class with various features.

    Logger          : coloured console/file logger with optional level
                      filtering, structured context, exception capture,
                      log-file rotation, JSON output, child loggers,
                      thread safety, performance counters, and timed
                      context-manager blocks.

Factory
-------
    get_logger()    : creates (or retrieves) a Logger instance.

Quick start
-----------
    >>> from sysame.utils.logger import get_logger
    >>> log = get_logger()                          # simple console logger
    >>> log.info("hello")

    >>> log = get_logger("app.log",                 # with advanced features
    ...                  level="DEBUG",
    ...                  max_bytes=5_000_000,
    ...                  json_output=True)
    >>> log.info("started", user_id=42)
"""

##### IMPORTS #####
# Standard imports
from __future__ import annotations

import atexit
import json
import shutil
import sys
import threading
import time
import traceback
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime
from enum import IntEnum
from pathlib import Path
from typing import Any, Generator, Optional


# Third-party imports

# Local imports

# Import Rules

##### CONSTANTS #####
_REGISTRY: dict[str, Logger] = {}
"""Module-level registry so ``get_logger`` can return the same instance for the same *name*."""


##### ENUMS #####
class LogLevel(IntEnum):
    """Numeric log levels : higher value = more severe."""

    DEBUG = 10
    INFO = 20
    WARN = 30
    ERROR = 40
    CRITICAL = 50


##### DATA CLASSES #####
@dataclass(frozen=True)
class LogColors:
    """ANSI escape sequences for each severity."""

    DEBUG: str = "\033[90m"
    INFO: str = "\033[97m"
    WARN: str = "\033[1;33m"
    ERROR: str = "\033[1;91m"
    CRITICAL: str = "\033[1;97;41m"
    RESET: str = "\033[0m"

    def for_level(self, level: LogLevel) -> str:
        """Return the colour string for a given ``LogLevel``."""
        return {
            LogLevel.DEBUG: self.DEBUG,
            LogLevel.INFO: self.INFO,
            LogLevel.WARN: self.WARN,
            LogLevel.ERROR: self.ERROR,
            LogLevel.CRITICAL: self.CRITICAL,
        }.get(level, self.RESET)


##### CLASSES #####
class Logger:
    """Coloured console / file logger with various advanced features.

    With default arguments this behaves as a simple, zero-config coloured
    console logger.  Pass additional keyword arguments to enable level
    filtering, structured context, JSON output, log-file rotation,
    buffering, child loggers, performance counters, and timed blocks.

    Parameters
    ----------
    file_path : str | Path | None
        Optional path to a log file (appended to).
    name : str
        Logger name shown in every log line.
    console : bool
        Whether to echo to *stdout*.
    colors : LogColors
        ANSI colour overrides.
    dt_format : str
        ``strftime`` format for the timestamp column.
    level_width : int
        Fixed column width for the level label.
    delimiter : str
        Column separator character.
    level : LogLevel | str
        Minimum severity to emit (default ``DEBUG``, log everything).
    max_bytes : int
        Maximum log-file size in bytes before rotation (0 = no limit).
    backup_count : int
        How many rotated files to keep (``app.log.1``, ``app.log.2`` …).
    json_output : bool
        When *True*, file output is written as one JSON object per line
        (structured logging).  Console output stays human-readable.
    buffer_size : int
        Number of lines to buffer before flushing to disk (0 = immediate).
    indent : bool
        When *True* (default), messages inside ``timed()`` blocks are
        automatically indented to reflect nesting depth.
    extra : dict
        Default key/value context attached to **every** log entry.
    """

    def __init__(
        self,
        file_path: Optional[str | Path] = None,
        *,
        name: str = "",
        console: bool = True,
        colors: LogColors = LogColors(),
        dt_format: str = "%Y-%m-%d %H:%M:%S",
        level_width: int = 8,
        delimiter: str = "|",
        level: LogLevel | str = LogLevel.DEBUG,
        max_bytes: int = 0,
        backup_count: int = 3,
        json_output: bool = False,
        buffer_size: int = 0,
        indent: bool = True,
        extra: Optional[dict[str, Any]] = None,
    ) -> None:
        if file_path is None and not console:
            raise ValueError(
                "At least one output must be enabled: set file_path and/or console=True"
            )
        self.file_path = Path(file_path) if file_path is not None else None
        self.name = name
        self.console = console
        self.colors = colors
        self.dt_format = dt_format
        self.level_width = level_width
        self.delimiter = delimiter
        self.name_width = len(name) if name else 0
        self.level = LogLevel[level.upper()] if isinstance(level, str) else level
        self.max_bytes = max_bytes
        self.backup_count = backup_count
        self.json_output = json_output
        self.buffer_size = buffer_size
        self.indent = indent
        self.extra: dict[str, Any] = extra or {}

        # Thread safety
        self._lock = threading.RLock()

        # Thread-local timed-block indent depth
        self._indent = threading.local()
        self._indent_str = "  "

        # Internal buffer for batched file writes
        self._buffer: list[str] = []

        # Performance counters
        self._counts: dict[str, int] = {lvl.name: 0 for lvl in LogLevel}

        if self.file_path is not None:
            self._ensure_path()

        # Register atexit hook to flush buffer on interpreter shutdown
        if self.buffer_size > 0:
            atexit.register(self.flush)

    def _ensure_path(self) -> None:
        assert self.file_path is not None  # guarded by caller
        directory = self.file_path.resolve().parent
        if not directory.exists() or not directory.is_dir():
            raise FileNotFoundError(f"Log directory does not exist: {directory}")
        try:
            self.file_path.touch(exist_ok=True)
        except PermissionError as e:
            raise PermissionError(f"No write permission for: {directory}") from e

    def _timestamp(self) -> str:
        return datetime.now().strftime(self.dt_format)

    @property
    def _indent_depth(self) -> int:
        """Current indent depth (per-thread)."""
        return getattr(self._indent, "depth", 0)

    @_indent_depth.setter
    def _indent_depth(self, value: int) -> None:
        self._indent.depth = value

    def _format_line(self, level: str, message: str) -> str:
        d = self.delimiter
        name_part = f"{self.name:<{self.name_width}} {d} " if self.name else ""
        indent = self._indent_str * self._indent_depth if self.indent else ""
        return (
            f"{self._timestamp()} {d} "
            f"{level:^{self.level_width}} {d} "
            f"{name_part}{indent}{message}"
        )

    def _format_line_advanced(
        self,
        level: LogLevel,
        message: str,
        extra: dict[str, Any],
        tb: Optional[str] = None,
    ) -> str:
        """Human-readable line, optionally including extra context and traceback."""
        base = self._format_line(level.name, message)
        if extra:
            kv = " ".join(f"{k}={v!r}" for k, v in extra.items())
            base = f"{base}  [{kv}]"
        if tb:
            base = f"{base}\n{tb}"
        return base

    def _format_json(
        self,
        level: LogLevel,
        message: str,
        extra: dict[str, Any],
        tb: Optional[str] = None,
    ) -> str:
        """Return a single-line JSON string for structured log output."""
        record: dict[str, Any] = {
            "ts": self._timestamp(),
            "level": level.name,
            "message": message,
        }
        if self.name:
            record["logger"] = self.name
        if self.indent and self._indent_depth:
            record["indent"] = self._indent_depth
        if extra:
            record["extra"] = extra
        if tb:
            record["traceback"] = tb
        return json.dumps(record, default=str)

    def _rotate_if_needed(self) -> None:
        """Rotate the log file when it exceeds ``max_bytes``."""
        if self.file_path is None or self.max_bytes <= 0:
            return
        try:
            if self.file_path.stat().st_size < self.max_bytes:
                return
        except FileNotFoundError:
            return

        # Shift existing backups: app.log.2 -> app.log.3, app.log.1 -> app.log.2 …
        for i in range(self.backup_count, 0, -1):
            src = self.file_path.with_suffix(f"{self.file_path.suffix}.{i}")
            dst = self.file_path.with_suffix(f"{self.file_path.suffix}.{i + 1}")
            if src.exists():
                if i == self.backup_count:
                    src.unlink()  # discard oldest
                else:
                    shutil.move(str(src), str(dst))

        # Current -> .1
        backup_one = self.file_path.with_suffix(f"{self.file_path.suffix}.1")
        shutil.move(str(self.file_path), str(backup_one))
        self.file_path.touch()

    def _flush_buffer(self) -> None:
        """Write buffered lines to disk and clear the buffer."""
        if not self._buffer or self.file_path is None:
            return
        with self.file_path.open("a", encoding="utf-8") as f:
            f.writelines(self._buffer)
        self._buffer.clear()

    def _write_line(self, line: str, color: Optional[str] = None) -> None:
        """Thread-safe write with optional buffering and rotation."""
        with self._lock:
            if self.file_path is not None:
                self._rotate_if_needed()
                if self.buffer_size > 0:
                    self._buffer.append(line + "\n")
                    if len(self._buffer) >= self.buffer_size:
                        self._flush_buffer()
                else:
                    with self.file_path.open("a", encoding="utf-8") as f:
                        f.write(line + "\n")
            if self.console:
                print(f"{color or ''}{line}{self.colors.RESET if color else ''}")

    def _should_log(self, level: LogLevel) -> bool:
        """Return *True* if *level* meets the minimum threshold."""
        return level >= self.level

    def _emit(
        self,
        level: LogLevel,
        message: str,
        exc_info: Optional[bool] = None,
        **extra: Any,
    ) -> None:
        if not self._should_log(level):
            return

        with self._lock:
            self._counts[level.name] += 1

        merged_extra = {**self.extra, **extra}
        tb: Optional[str] = None
        # Auto-detect: if exc_info is None, include traceback when inside
        # an active except block.  True/False force the behaviour.
        include_tb = (
            exc_info if exc_info is not None else (sys.exc_info()[1] is not None)
        )
        if include_tb:
            if sys.exc_info()[1] is not None:
                tb = traceback.format_exc()

        try:
            # File output (JSON when enabled)
            if self.file_path is not None and self.json_output:
                json_line = self._format_json(level, message, merged_extra, tb)
                # bypass _format_line path — write raw JSON
                with self._lock:
                    self._rotate_if_needed()
                    if self.buffer_size > 0:
                        self._buffer.append(json_line + "\n")
                        if (
                            len(self._buffer) >= self.buffer_size
                            or level >= LogLevel.ERROR
                        ):
                            self._flush_buffer()
                    else:
                        with self.file_path.open("a", encoding="utf-8") as f:
                            f.write(json_line + "\n")
                # Console still gets human-readable form
                if self.console:
                    human = self._format_line_advanced(level, message, merged_extra, tb)
                    color = self.colors.for_level(level)
                    print(f"{color}{human}{self.colors.RESET}")
            else:
                human = self._format_line_advanced(level, message, merged_extra, tb)
                color = self.colors.for_level(level)
                self._write_line(human, color)

                # Auto-flush buffer on high-severity messages
                if self.buffer_size > 0 and level >= LogLevel.ERROR:
                    with self._lock:
                        self._flush_buffer()

        except Exception:
            # Formatting / serialisation failed — flush what we already
            # have so previously buffered lines are not lost.
            with self._lock:
                self._flush_buffer()
            # Write a best-effort fallback line so the failure is visible
            fallback = (
                f"{self._timestamp()} {self.delimiter} "
                f"{level.name:^{self.level_width}} {self.delimiter} "
                f"{message} [LOGGING FORMAT ERROR]"
            )
            self._write_line(fallback)

    def debug(
        self, message: str, *, exc_info: Optional[bool] = None, **extra: Any
    ) -> None:
        self._emit(LogLevel.DEBUG, message, exc_info=exc_info, **extra)

    def info(
        self, message: str, *, exc_info: Optional[bool] = None, **extra: Any
    ) -> None:
        self._emit(LogLevel.INFO, message, exc_info=exc_info, **extra)

    def warn(
        self, message: str, *, exc_info: Optional[bool] = None, **extra: Any
    ) -> None:
        self._emit(LogLevel.WARN, message, exc_info=exc_info, **extra)

    def error(
        self, message: str, *, exc_info: Optional[bool] = None, **extra: Any
    ) -> None:
        self._emit(LogLevel.ERROR, message, exc_info=exc_info, **extra)

    def critical(
        self, message: str, *, exc_info: Optional[bool] = None, **extra: Any
    ) -> None:
        self._emit(LogLevel.CRITICAL, message, exc_info=exc_info, **extra)

    def separator(self, marker: str = "----") -> None:
        self._write_line(marker)

    def __enter__(self) -> Logger:
        """Enable use as a context manager: ``with get_logger(...) as log:``."""
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Flush the buffer when leaving the ``with`` block."""
        self.flush()

    def child(self, child_name: str) -> Logger:
        """Create a child logger that inherits this logger's configuration.

        The child's ``name`` is ``"parent.child_name"`` and it shares the
        same file path, level, rotation settings, and default extra context.
        """
        full_name = f"{self.name}.{child_name}" if self.name else child_name
        child_logger = Logger(
            file_path=self.file_path,
            name=full_name,
            console=self.console,
            colors=self.colors,
            dt_format=self.dt_format,
            level_width=self.level_width,
            delimiter=self.delimiter,
            level=self.level,
            max_bytes=self.max_bytes,
            backup_count=self.backup_count,
            json_output=self.json_output,
            buffer_size=self.buffer_size,
            indent=self.indent,
            extra={**self.extra},
        )
        # Share lock to keep writes/rotation serialised when parent and child
        # log to the same destination.
        child_logger._lock = self._lock
        return child_logger

    @contextmanager
    def timed(
        self, label: str, level: LogLevel | str = LogLevel.INFO
    ) -> Generator[None, None, None]:
        """Log elapsed wall-clock time for a block of code.

        Usage::

            with log.timed("data load"):
                df = load_big_frame()
            # => "data load completed in 1.34s"
        """
        lvl = LogLevel[level.upper()] if isinstance(level, str) else level
        start = time.perf_counter()
        failed = False
        self._emit(lvl, f"{label} started")
        self._indent_depth += 1
        try:
            yield
        except Exception:
            failed = True
            raise
        finally:
            self._indent_depth = max(0, self._indent_depth - 1)
            elapsed = time.perf_counter() - start
            if failed:
                self._emit(
                    LogLevel.ERROR,
                    f"{label} failed in {elapsed:.3f}s",
                    exc_info=True,
                )
            else:
                self._emit(lvl, f"{label} completed in {elapsed:.3f}s")

    @property
    def counts(self) -> dict[str, int]:
        """Return a copy of per-level message counts."""
        return dict(self._counts)

    def flush(self) -> None:
        """Force-flush the internal buffer to disk."""
        with self._lock:
            self._flush_buffer()

    def reset_counts(self) -> None:
        """Zero all performance counters."""
        for k in self._counts:
            self._counts[k] = 0


def get_logger(
    file_path: Optional[str | Path] = None,
    *,
    name: str = "",
    console: bool = True,
    colors: LogColors = LogColors(),
    dt_format: str = "%Y-%m-%d %H:%M:%S",
    level_width: int = 8,
    delimiter: str = "|",
    level: LogLevel | str = LogLevel.DEBUG,
    max_bytes: int = 0,
    backup_count: int = 3,
    json_output: bool = False,
    buffer_size: int = 0,
    indent: bool = True,
    extra: Optional[dict[str, Any]] = None,
    singleton: bool = True,
) -> Logger:
    """Create (or retrieve) a :class:`Logger` instance.

    Parameters
    ----------
    singleton : bool
        When *True* (default), a second call with the same *name* returns
        the previously created instance from an internal registry.
    """
    norm_level = LogLevel[level.upper()] if isinstance(level, str) else level
    requested_path = Path(file_path) if file_path is not None else None

    if singleton and name in _REGISTRY:
        existing = _REGISTRY[name]
        if (
            existing.file_path != requested_path
            or existing.console != console
            or existing.colors != colors
            or existing.dt_format != dt_format
            or existing.level_width != level_width
            or existing.delimiter != delimiter
            or existing.level != norm_level
            or existing.max_bytes != max_bytes
            or existing.backup_count != backup_count
            or existing.json_output != json_output
            or existing.buffer_size != buffer_size
            or existing.indent != indent
            or existing.extra != (extra or {})
        ):
            raise ValueError(
                f"Logger '{name}' already exists with different configuration. "
                "Use a different name or pass singleton=False."
            )
        return existing

    logger = Logger(
        file_path,
        name=name,
        console=console,
        colors=colors,
        dt_format=dt_format,
        level_width=level_width,
        delimiter=delimiter,
        level=norm_level,
        max_bytes=max_bytes,
        backup_count=backup_count,
        json_output=json_output,
        buffer_size=buffer_size,
        indent=indent,
        extra=extra,
    )

    if singleton and name:
        _REGISTRY[name] = logger
    return logger
