"""
Sentry Logger SDK - Push logs from your Python app to the Sentry dashboard.
"""
from __future__ import annotations

from typing import Optional

from .handler import SentryLogHandler
from .config import SentryLoggerConfig
from .local_config import load_local_config, resolve_dsn

__all__ = ["SentryLogHandler", "SentryLoggerConfig", "init"]


def init(
    api_key: Optional[str] = None,
    dsn: Optional[str] = None,
    batch_size: int = 50,
    flush_interval_seconds: float = 5.0,
) -> SentryLogHandler:
    """
    Initialize Sentry Logger and attach it to the root Python logger.

    Args:
        api_key: Your Sentry API key.  If omitted, reads from the local config
                 file written by ``sentry-logger init`` (~/.sentry_logger/config.json).
        dsn:     Backend base URL.  If omitted, uses the production endpoint
                 (https://api.sentrylabs.live) or the value saved by the CLI.
                 Can also be overridden with the SENTRY_INGEST_URL env var.
        batch_size: Logs to buffer before flushing (default 50).
        flush_interval_seconds: Seconds between automatic flushes (default 5).

    Returns:
        SentryLogHandler — attach to specific loggers if needed.

    Example (CLI-linked app, zero config):
        >>> from sentry_logger import init
        >>> init()

    Example (explicit key):
        >>> from sentry_logger import init
        >>> init(api_key="sk_...")
    """
    import logging

    resolved_dsn = resolve_dsn(dsn)

    if not api_key:
        cfg = load_local_config()
        api_key = cfg.get("api_key")
        # Also prefer the DSN saved by the CLI if not provided explicitly
        if not dsn and cfg.get("dsn"):
            resolved_dsn = str(cfg["dsn"]).rstrip("/")

    if not api_key:
        raise ValueError(
            "api_key is required. Either run `sentry-logger init` first, "
            "or pass api_key= to init()."
        )

    config = SentryLoggerConfig(
        api_key=api_key,
        batch_size=batch_size,
        flush_interval_seconds=flush_interval_seconds,
        _backend_url=resolved_dsn,
    )
    handler = SentryLogHandler(config)
    logging.getLogger().addHandler(handler)
    logging.getLogger().setLevel(logging.INFO)
    return handler
