# Sentry Logger SDK (Python)

Push logs from your Python app to the Sentry dashboard.

## Installation

```bash
pip install sentry-logger
# or from the repo:
pip install ./sdk/python
```

## Quick Start — CLI + Browser OAuth

```bash
sentry-logger init --app-name "my-service" --dsn "http://localhost:9000"
```

What happens:

1. CLI requests a device session from the backend
2. Browser opens your sign-in page
3. Sign in with Google — your app is registered and an API key is created
4. CLI polls and stores credentials in `~/.sentry_logger/config.json`

Check the currently linked app:

```bash
sentry-logger status
```

## SDK Usage

```python
from sentry_logger import init

# Reads api_key and dsn from ~/.sentry_logger/config.json
init()

import logging
logging.info("Hello from my app")
logging.error("Something went wrong")
```

Explicit configuration:

```python
from sentry_logger import init

init(
    api_key="sk_...",
    dsn="http://localhost:9000",   # your backend URL
)
```

## Environment Variables

| Variable           | Default                  | Description                     |
|--------------------|--------------------------|--------------------------------|
| `LOGSENTRY_URL`    | `http://localhost:9000`  | Backend ingest URL base        |

## FastAPI Example

```python
import logging
from fastapi import FastAPI
from sentry_logger import init

app = FastAPI()

@app.on_event("startup")
def setup_logging() -> None:
    init()
    logging.getLogger(__name__).info("Sentry SDK initialized")
```

## Configuration Reference

| Parameter                | Default | Description                                           |
|--------------------------|---------|-------------------------------------------------------|
| `api_key`                | —       | API key (`sk_...`). If omitted, loaded from CLI config |
| `dsn`                    | —       | Ingest URL. Falls back to `LOGSENTRY_URL` env or `http://localhost:8001` |
| `batch_size`             | `50`    | Send logs when buffer reaches this size               |
| `flush_interval_seconds` | `5.0`   | Auto-flush buffer after this many seconds             |

## Log Format

The SDK formats logs in the standard Python logging format. The backend parses:

```
2024-01-01 10:00:00,123 [INFO] [ServiceName]: Log message here
```

The `ServiceName` in brackets is used to group logs by service in the dashboard.
Use Python logger names to map to service names:

```python
logger = logging.getLogger("PaymentService")
logger.info("Payment processed")
```
