# Claude-specific additions
# This content is appended to the base ATDD.md when syncing to CLAUDE.md
