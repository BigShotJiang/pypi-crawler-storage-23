"""Tester audits, conventions and schemas."""
