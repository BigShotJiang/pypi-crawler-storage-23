"""Encryption backend implementations for adk-secure-sessions.

Examples:
    Import the Fernet backend::

        from adk_secure_sessions.backends.fernet import FernetBackend

See Also:
    [`adk_secure_sessions.backends.fernet`][adk_secure_sessions.backends.fernet]:
    Fernet symmetric encryption backend.
"""
