"""
Shell module - I/O layer.

This module contains all I/O code: API endpoints, MCP server, storage.
All functions must return Result[T, E] from the returns library.
"""

# Shell implementations will be here
