"""Tests for prompt metadata."""

from datetime import datetime, timezone

import pytest

from folderbot.prompt_metadata import PromptMetadata, get_install_time


class TestGetInstallTime:
    def test_returns_datetime(self):
        result = get_install_time()
        assert isinstance(result, datetime)

    def test_returns_utc(self):
        result = get_install_time()
        assert result.tzinfo is not None

    def test_is_in_the_past(self):
        result = get_install_time()
        assert result < datetime.now(timezone.utc)


class TestPromptMetadata:
    def test_frozen(self):
        meta = PromptMetadata(
            current_date="Monday, February 17, 2026",
            version="0.1.56",
            last_upgraded="February 15, 2026 at 14:30 UTC",
            user_name="Jorge",
            confirmation_tools_section="",
        )
        with pytest.raises(AttributeError):
            meta.version = "0.2.0"  # type: ignore[misc]

    def test_format_dict_keys(self):
        meta = PromptMetadata(
            current_date="Monday, February 17, 2026",
            version="0.1.56",
            last_upgraded="February 15, 2026 at 14:30 UTC",
            user_name="Jorge",
            confirmation_tools_section="",
        )
        d = meta.format_dict()
        assert "current_date" in d
        assert "version" in d
        assert "last_upgraded" in d
        assert "user_name" in d
        assert "confirmation_tools_section" in d

    def test_format_dict_values(self):
        meta = PromptMetadata(
            current_date="Monday, February 17, 2026",
            version="0.1.56",
            last_upgraded="February 15, 2026 at 14:30 UTC",
            user_name="Jorge",
            confirmation_tools_section="some section",
        )
        d = meta.format_dict()
        assert d["current_date"] == "Monday, February 17, 2026"
        assert d["version"] == "0.1.56"
        assert d["last_upgraded"] == "February 15, 2026 at 14:30 UTC"
        assert d["user_name"] == "Jorge"
        assert d["confirmation_tools_section"] == "some section"

    def test_build_creates_metadata(self):
        meta = PromptMetadata.build(
            user_name="TestUser",
            confirmation_tools=[],
        )
        assert meta.user_name == "TestUser"
        assert meta.version
        assert meta.current_date
        assert meta.last_upgraded
        assert meta.confirmation_tools_section == ""

    def test_build_with_confirmation_tools(self):
        meta = PromptMetadata.build(
            user_name="TestUser",
            confirmation_tools=["write_file", "delete_file"],
        )
        assert "write_file" in meta.confirmation_tools_section
        assert "delete_file" in meta.confirmation_tools_section

    def test_build_date_matches_today(self):
        from datetime import date

        meta = PromptMetadata.build(user_name="User", confirmation_tools=[])
        today = date.today().strftime("%A, %B %d, %Y")
        assert meta.current_date == today
