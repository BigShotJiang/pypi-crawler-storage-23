"""Tests for session manager."""

from pathlib import Path

import pytest

from folderbot.session_manager import (
    SessionManager,
    TopicReassignment,
    validate_topic_name,
)


@pytest.fixture
def session_manager(tmp_path: Path) -> SessionManager:
    """Create a session manager with a temporary database."""
    db_path = tmp_path / "test_sessions.db"
    return SessionManager(db_path)


class TestSessionManager:
    def test_creates_database(self, tmp_path: Path):
        db_path = tmp_path / "subdir" / "sessions.db"
        SessionManager(db_path)  # Creates DB on init

        assert db_path.exists()
        assert db_path.parent.exists()

    def test_empty_history_for_new_user(self, session_manager: SessionManager):
        history = session_manager.get_history(user_id=12345)

        assert history == []

    def test_add_single_message(self, session_manager: SessionManager):
        session_manager.add_message(user_id=12345, role="user", content="Hello")

        history = session_manager.get_history(user_id=12345)

        assert len(history) == 1
        assert history[0]["role"] == "user"
        assert history[0]["content"] == "Hello"
        assert "timestamp" in history[0]

    def test_add_multiple_messages(self, session_manager: SessionManager):
        session_manager.add_message(user_id=12345, role="user", content="Hello")
        session_manager.add_message(
            user_id=12345, role="assistant", content="Hi there!"
        )
        session_manager.add_message(user_id=12345, role="user", content="How are you?")

        history = session_manager.get_history(user_id=12345)

        assert len(history) == 3
        assert history[0]["content"] == "Hello"
        assert history[1]["content"] == "Hi there!"
        assert history[2]["content"] == "How are you?"

    def test_separate_user_sessions(self, session_manager: SessionManager):
        session_manager.add_message(user_id=111, role="user", content="User 1 message")
        session_manager.add_message(user_id=222, role="user", content="User 2 message")

        history_1 = session_manager.get_history(user_id=111)
        history_2 = session_manager.get_history(user_id=222)

        assert len(history_1) == 1
        assert len(history_2) == 1
        assert history_1[0]["content"] == "User 1 message"
        assert history_2[0]["content"] == "User 2 message"

    def test_clear_session(self, session_manager: SessionManager):
        session_manager.add_message(user_id=12345, role="user", content="Hello")
        session_manager.add_message(user_id=12345, role="assistant", content="Hi!")

        session_manager.clear_session(user_id=12345)

        history = session_manager.get_history(user_id=12345)
        assert history == []

    def test_clear_session_only_affects_specific_user(
        self, session_manager: SessionManager
    ):
        session_manager.add_message(user_id=111, role="user", content="User 1")
        session_manager.add_message(user_id=222, role="user", content="User 2")

        session_manager.clear_session(user_id=111)

        assert session_manager.get_history(user_id=111) == []
        assert len(session_manager.get_history(user_id=222)) == 1

    def test_get_session_info_new_user(self, session_manager: SessionManager):
        info = session_manager.get_session_info(user_id=99999)

        assert info["message_count"] == 0
        assert info["created_at"] is None
        assert info["updated_at"] is None

    def test_get_session_info_existing_user(self, session_manager: SessionManager):
        session_manager.add_message(user_id=12345, role="user", content="Hello")
        session_manager.add_message(user_id=12345, role="assistant", content="Hi!")

        info = session_manager.get_session_info(user_id=12345)

        assert info["message_count"] == 2
        assert info["created_at"] is not None
        assert info["updated_at"] is not None

    def test_session_info_after_clear(self, session_manager: SessionManager):
        session_manager.add_message(user_id=12345, role="user", content="Hello")
        session_manager.clear_session(user_id=12345)

        info = session_manager.get_session_info(user_id=12345)

        assert info["message_count"] == 0
        # Timestamps should still exist after clear
        assert info["updated_at"] is not None

    def test_persistence_across_instances(self, tmp_path: Path):
        db_path = tmp_path / "persistent.db"

        # First instance
        manager1 = SessionManager(db_path)
        manager1.add_message(user_id=12345, role="user", content="Persistent message")

        # Second instance with same db
        manager2 = SessionManager(db_path)
        history = manager2.get_history(user_id=12345)

        assert len(history) == 1
        assert history[0]["content"] == "Persistent message"

    def test_unicode_content(self, session_manager: SessionManager):
        session_manager.add_message(
            user_id=12345, role="user", content="Hello 你好 مرحبا 🎉"
        )

        history = session_manager.get_history(user_id=12345)

        assert history[0]["content"] == "Hello 你好 مرحبا 🎉"

    def test_long_content(self, session_manager: SessionManager):
        long_content = "x" * 10000
        session_manager.add_message(user_id=12345, role="user", content=long_content)

        history = session_manager.get_history(user_id=12345)

        assert history[0]["content"] == long_content


class TestTopics:
    def test_add_message_with_topic(self, session_manager: SessionManager):
        session_manager.add_message(
            user_id=1, role="user", content="What's the weather?", topic="weather"
        )

        history = session_manager.get_history(user_id=1)

        assert len(history) == 1
        assert history[0]["topic"] == "weather"

    def test_add_message_default_topic(self, session_manager: SessionManager):
        session_manager.add_message(user_id=1, role="user", content="Hello")

        history = session_manager.get_history(user_id=1)

        assert history[0]["topic"] == "general"

    def test_get_history_filtered_by_topic(self, session_manager: SessionManager):
        session_manager.add_message(
            user_id=1, role="user", content="Weather msg", topic="weather"
        )
        session_manager.add_message(
            user_id=1, role="user", content="Recipe msg", topic="recipes"
        )
        session_manager.add_message(
            user_id=1, role="user", content="Another weather", topic="weather"
        )

        weather_history = session_manager.get_history(user_id=1, topic="weather")

        assert len(weather_history) == 2
        assert all(m["topic"] == "weather" for m in weather_history)

    def test_get_history_no_topic_returns_all(self, session_manager: SessionManager):
        session_manager.add_message(
            user_id=1, role="user", content="A", topic="weather"
        )
        session_manager.add_message(
            user_id=1, role="user", content="B", topic="recipes"
        )

        history = session_manager.get_history(user_id=1)

        assert len(history) == 2

    def test_get_topics(self, session_manager: SessionManager):
        session_manager.add_message(
            user_id=1, role="user", content="Q1", topic="weather"
        )
        session_manager.add_message(
            user_id=1, role="assistant", content="A1", topic="weather"
        )
        session_manager.add_message(
            user_id=1, role="user", content="Q2", topic="recipes"
        )

        topics = session_manager.get_topics(user_id=1)

        assert len(topics) == 2
        topic_names = {t["topic"] for t in topics}
        assert topic_names == {"weather", "recipes"}

        weather_topic = next(t for t in topics if t["topic"] == "weather")
        assert weather_topic["message_count"] == 2

    def test_get_topics_empty(self, session_manager: SessionManager):
        topics = session_manager.get_topics(user_id=1)

        assert topics == []

    def test_backward_compat_messages_without_topic(
        self, session_manager: SessionManager
    ):
        """Old messages stored without a topic field get 'general' as default."""
        import json
        import sqlite3
        from datetime import datetime

        # Manually insert a message without topic (simulating old format)
        now = datetime.now().isoformat()
        messages = [{"role": "user", "content": "old message", "timestamp": now}]
        with sqlite3.connect(session_manager.db_path) as conn:
            conn.execute(
                "INSERT INTO sessions (user_id, messages, created_at, updated_at) "
                "VALUES (?, ?, ?, ?)",
                (1, json.dumps(messages), now, now),
            )
            conn.commit()

        history = session_manager.get_history(user_id=1)

        assert len(history) == 1
        assert history[0]["topic"] == "general"


class TestValidateTopicName:
    def test_simple_name_unchanged(self):
        assert validate_topic_name("weather") == "weather"

    def test_spaces_to_underscores(self):
        assert validate_topic_name("project planning") == "project_planning"

    def test_uppercase_to_lowercase(self):
        assert validate_topic_name("Weather") == "weather"

    def test_hyphens_to_underscores(self):
        assert validate_topic_name("my-project") == "my_project"

    def test_special_characters_stripped(self):
        assert validate_topic_name("hello!@#world") == "helloworld"

    def test_mixed_normalization(self):
        assert validate_topic_name("Project Planning!") == "project_planning"

    def test_numbers_allowed(self):
        assert validate_topic_name("task123") == "task123"

    def test_repeated_underscores_collapsed(self):
        assert validate_topic_name("a___b") == "a_b"

    def test_leading_trailing_underscores_stripped(self):
        assert validate_topic_name("_topic_") == "topic"

    def test_empty_after_normalization_raises(self):
        with pytest.raises(ValueError):
            validate_topic_name("!!!")

    def test_empty_string_raises(self):
        with pytest.raises(ValueError):
            validate_topic_name("")

    def test_general_passes(self):
        assert validate_topic_name("general") == "general"


class TestUpdateMessageTopics:
    def test_basic_reassignment(self, session_manager: SessionManager):
        session_manager.add_message(1, "user", "Q1", topic="general")
        session_manager.add_message(1, "assistant", "A1", topic="general")
        session_manager.add_message(1, "user", "Q2", topic="general")

        updated = session_manager.update_message_topics(
            1,
            [
                TopicReassignment(message_index=0, new_topic="weather"),
                TopicReassignment(message_index=1, new_topic="weather"),
                TopicReassignment(message_index=2, new_topic="recipes"),
            ],
        )

        assert updated == 3
        history = session_manager.get_history(1)
        assert history[0]["topic"] == "weather"
        assert history[1]["topic"] == "weather"
        assert history[2]["topic"] == "recipes"

    def test_partial_reassignment(self, session_manager: SessionManager):
        session_manager.add_message(1, "user", "Q1", topic="weather")
        session_manager.add_message(1, "user", "Q2", topic="general")

        updated = session_manager.update_message_topics(
            1,
            [TopicReassignment(message_index=1, new_topic="weather")],
        )

        assert updated == 1
        history = session_manager.get_history(1)
        assert history[0]["topic"] == "weather"
        assert history[1]["topic"] == "weather"

    def test_no_change_returns_zero(self, session_manager: SessionManager):
        session_manager.add_message(1, "user", "Q1", topic="weather")

        updated = session_manager.update_message_topics(
            1,
            [TopicReassignment(message_index=0, new_topic="weather")],
        )

        assert updated == 0

    def test_invalid_index_raises(self, session_manager: SessionManager):
        session_manager.add_message(1, "user", "Q1", topic="general")

        with pytest.raises(ValueError, match="out of range"):
            session_manager.update_message_topics(
                1,
                [TopicReassignment(message_index=5, new_topic="weather")],
            )

    def test_negative_index_raises(self, session_manager: SessionManager):
        session_manager.add_message(1, "user", "Q1", topic="general")

        with pytest.raises(ValueError, match="out of range"):
            session_manager.update_message_topics(
                1,
                [TopicReassignment(message_index=-1, new_topic="weather")],
            )

    def test_nonexistent_user_returns_zero(self, session_manager: SessionManager):
        updated = session_manager.update_message_topics(
            999,
            [TopicReassignment(message_index=0, new_topic="weather")],
        )
        assert updated == 0

    def test_topic_names_are_normalized(self, session_manager: SessionManager):
        session_manager.add_message(1, "user", "Q1", topic="general")

        updated = session_manager.update_message_topics(
            1,
            [TopicReassignment(message_index=0, new_topic="Project Planning")],
        )

        assert updated == 1
        history = session_manager.get_history(1)
        assert history[0]["topic"] == "project_planning"

    def test_invalid_topic_name_raises(self, session_manager: SessionManager):
        session_manager.add_message(1, "user", "Q1", topic="general")

        with pytest.raises(ValueError):
            session_manager.update_message_topics(
                1,
                [TopicReassignment(message_index=0, new_topic="!!!")],
            )


class TestAddMessageTopicValidation:
    def test_normalizes_topic_on_add(self, session_manager: SessionManager):
        session_manager.add_message(1, "user", "hello", topic="Project Planning")
        history = session_manager.get_history(1)
        assert history[0]["topic"] == "project_planning"

    def test_invalid_topic_on_add_raises(self, session_manager: SessionManager):
        with pytest.raises(ValueError):
            session_manager.add_message(1, "user", "hello", topic="!!!")


class TestTokenUsage:
    def test_record_and_get_usage(self, session_manager: SessionManager):
        session_manager.record_token_usage(
            user_id=1,
            input_tokens=100,
            output_tokens=50,
            model="anthropic/claude-sonnet-4-20250514",
            topic="weather",
        )

        records = session_manager.get_token_usage(user_id=1)
        assert len(records) == 1
        assert records[0].input_tokens == 100
        assert records[0].output_tokens == 50
        assert records[0].model == "anthropic/claude-sonnet-4-20250514"
        assert records[0].topic == "weather"
        assert records[0].created_at is not None

    def test_multiple_records(self, session_manager: SessionManager):
        session_manager.record_token_usage(1, 100, 50, "model-a", "weather")
        session_manager.record_token_usage(1, 200, 80, "model-a", "recipes")
        session_manager.record_token_usage(1, 150, 60, "model-b", "weather")

        records = session_manager.get_token_usage(user_id=1)
        assert len(records) == 3
        total_input = sum(r.input_tokens for r in records)
        total_output = sum(r.output_tokens for r in records)
        assert total_input == 450
        assert total_output == 190

    def test_separate_users(self, session_manager: SessionManager):
        session_manager.record_token_usage(1, 100, 50, "model", "general")
        session_manager.record_token_usage(2, 200, 80, "model", "general")

        user1 = session_manager.get_token_usage(user_id=1)
        user2 = session_manager.get_token_usage(user_id=2)
        assert len(user1) == 1
        assert len(user2) == 1
        assert user1[0].input_tokens == 100
        assert user2[0].input_tokens == 200

    def test_get_usage_since(self, session_manager: SessionManager):
        """get_token_usage with since parameter filters by date."""
        import sqlite3
        from datetime import datetime, timedelta

        # Insert an old record directly (2 weeks ago)
        old_date = (datetime.now() - timedelta(days=14)).isoformat()
        with sqlite3.connect(session_manager.db_path) as conn:
            conn.execute(
                "INSERT INTO token_usage "
                "(user_id, input_tokens, output_tokens, model, topic, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (1, 500, 200, "model", "old-topic", old_date),
            )
            conn.commit()

        # Insert a recent record
        session_manager.record_token_usage(1, 100, 50, "model", "new-topic")

        # Get all records
        all_records = session_manager.get_token_usage(user_id=1)
        assert len(all_records) == 2

        # Get records from last 7 days
        since = (datetime.now() - timedelta(days=7)).isoformat()
        recent_records = session_manager.get_token_usage(user_id=1, since=since)
        assert len(recent_records) == 1
        assert recent_records[0].topic == "new-topic"

    def test_empty_usage(self, session_manager: SessionManager):
        records = session_manager.get_token_usage(user_id=999)
        assert records == []

    def test_frozen_record(self, session_manager: SessionManager):
        session_manager.record_token_usage(1, 100, 50, "model", "general")
        records = session_manager.get_token_usage(user_id=1)
        with pytest.raises(AttributeError):
            records[0].input_tokens = 999  # type: ignore[misc]
