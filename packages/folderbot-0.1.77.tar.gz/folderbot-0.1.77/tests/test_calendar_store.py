"""Tests for calendar event store."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from folderbot.calendar_store import (
    EVENT_STATUSES,
    RECURRENCE_TYPES,
    CalendarEvent,
    CalendarStore,
)


@pytest.fixture
def store(tmp_path: Path) -> CalendarStore:
    return CalendarStore(tmp_path / "test.db")


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _future_iso(hours: int = 1) -> str:
    return (datetime.now(timezone.utc) + timedelta(hours=hours)).isoformat()


def _past_iso(days: int = 1) -> str:
    return (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()


class TestCalendarStoreConstants:
    """Test module-level constants."""

    def test_event_statuses(self) -> None:
        assert "scheduled" in EVENT_STATUSES
        assert "cancelled" in EVENT_STATUSES
        assert "completed" in EVENT_STATUSES

    def test_recurrence_types(self) -> None:
        assert "" in RECURRENCE_TYPES
        assert "daily" in RECURRENCE_TYPES
        assert "weekly" in RECURRENCE_TYPES
        assert "monthly" in RECURRENCE_TYPES
        assert "yearly" in RECURRENCE_TYPES


class TestCalendarEventDataclass:
    """Test CalendarEvent frozen dataclass."""

    def test_is_frozen(self) -> None:
        event = CalendarEvent(
            id=1,
            user_id=42,
            title="Test",
            description="",
            start_time=_now_iso(),
            end_time=_future_iso(),
            location="",
            tags=[],
            reminders=[],
            recurrence="",
            recurrence_end=None,
            status="scheduled",
            created_at=_now_iso(),
            updated_at=_now_iso(),
        )
        with pytest.raises(AttributeError):
            event.title = "Changed"  # type: ignore[misc]


class TestCalendarStoreAdd:
    """Test adding events."""

    def test_add_basic(self, store: CalendarStore) -> None:
        start = _now_iso()
        end = _future_iso()
        event = store.add(user_id=42, title="Meeting", start_time=start, end_time=end)
        assert event.id > 0
        assert event.user_id == 42
        assert event.title == "Meeting"
        assert event.status == "scheduled"
        assert event.description == ""
        assert event.location == ""
        assert event.tags == []
        assert event.reminders == []
        assert event.recurrence == ""

    def test_add_with_all_fields(self, store: CalendarStore) -> None:
        start = _now_iso()
        end = _future_iso()
        event = store.add(
            user_id=42,
            title="Team Standup",
            start_time=start,
            end_time=end,
            description="Daily standup meeting",
            location="Conference Room A",
            tags=["work", "team"],
            reminders=["15m_before", "1h_before"],
            recurrence="daily",
            recurrence_end=_future_iso(hours=24 * 30),
        )
        assert event.title == "Team Standup"
        assert event.description == "Daily standup meeting"
        assert event.location == "Conference Room A"
        assert event.tags == ["work", "team"]
        assert event.reminders == ["15m_before", "1h_before"]
        assert event.recurrence == "daily"
        assert event.recurrence_end is not None

    def test_add_increments_id(self, store: CalendarStore) -> None:
        e1 = store.add(42, "Event 1", _now_iso(), _future_iso())
        e2 = store.add(42, "Event 2", _now_iso(), _future_iso())
        assert e2.id == e1.id + 1

    def test_add_sets_timestamps(self, store: CalendarStore) -> None:
        event = store.add(42, "Test", _now_iso(), _future_iso())
        assert event.created_at
        assert event.updated_at

    def test_add_invalid_status_raises(self, store: CalendarStore) -> None:
        with pytest.raises(ValueError, match="status"):
            store.add(42, "Test", _now_iso(), _future_iso(), status="invalid")

    def test_add_invalid_recurrence_raises(self, store: CalendarStore) -> None:
        with pytest.raises(ValueError, match="recurrence"):
            store.add(42, "Test", _now_iso(), _future_iso(), recurrence="biweekly")


class TestCalendarStoreGet:
    """Test fetching single events."""

    def test_get_existing(self, store: CalendarStore) -> None:
        added = store.add(42, "Meeting", _now_iso(), _future_iso())
        fetched = store.get(added.id, user_id=42)
        assert fetched is not None
        assert fetched.id == added.id
        assert fetched.title == "Meeting"

    def test_get_nonexistent(self, store: CalendarStore) -> None:
        assert store.get(999, user_id=42) is None

    def test_get_wrong_user(self, store: CalendarStore) -> None:
        added = store.add(42, "Meeting", _now_iso(), _future_iso())
        assert store.get(added.id, user_id=99) is None


class TestCalendarStoreList:
    """Test listing events."""

    def test_list_empty(self, store: CalendarStore) -> None:
        events = store.list_events(user_id=42)
        assert events == []

    def test_list_returns_user_events_only(self, store: CalendarStore) -> None:
        store.add(42, "Mine", _now_iso(), _future_iso())
        store.add(99, "Theirs", _now_iso(), _future_iso())
        events = store.list_events(user_id=42)
        assert len(events) == 1
        assert events[0].title == "Mine"

    def test_list_excludes_cancelled_by_default(self, store: CalendarStore) -> None:
        store.add(42, "Active", _now_iso(), _future_iso())
        e = store.add(42, "Cancelled", _now_iso(), _future_iso())
        store.update(e.id, 42, status="cancelled")
        events = store.list_events(user_id=42)
        assert len(events) == 1
        assert events[0].title == "Active"

    def test_list_include_cancelled(self, store: CalendarStore) -> None:
        store.add(42, "Active", _now_iso(), _future_iso())
        e = store.add(42, "Cancelled", _now_iso(), _future_iso())
        store.update(e.id, 42, status="cancelled")
        events = store.list_events(user_id=42, include_cancelled=True)
        assert len(events) == 2

    def test_list_filter_by_tag(self, store: CalendarStore) -> None:
        store.add(42, "Work", _now_iso(), _future_iso(), tags=["work"])
        store.add(42, "Personal", _now_iso(), _future_iso(), tags=["personal"])
        events = store.list_events(user_id=42, tag="work")
        assert len(events) == 1
        assert events[0].title == "Work"

    def test_list_filter_by_search(self, store: CalendarStore) -> None:
        store.add(42, "Team standup", _now_iso(), _future_iso())
        store.add(42, "Lunch", _now_iso(), _future_iso())
        events = store.list_events(user_id=42, search="standup")
        assert len(events) == 1
        assert events[0].title == "Team standup"

    def test_list_search_matches_description(self, store: CalendarStore) -> None:
        store.add(
            42,
            "Meeting",
            _now_iso(),
            _future_iso(),
            description="Discuss quarterly goals",
        )
        events = store.list_events(user_id=42, search="quarterly")
        assert len(events) == 1

    def test_list_filter_by_date_range(self, store: CalendarStore) -> None:
        past = _past_iso(days=5)
        past_end = (
            datetime.now(timezone.utc) - timedelta(days=5) + timedelta(hours=1)
        ).isoformat()
        future = _future_iso(hours=24)
        future_end = _future_iso(hours=25)

        store.add(42, "Past event", past, past_end)
        store.add(42, "Future event", future, future_end)

        # Only events starting after today
        today = datetime.now(timezone.utc).replace(
            hour=0, minute=0, second=0, microsecond=0
        )
        events = store.list_events(user_id=42, start_after=today.isoformat())
        assert len(events) == 1
        assert events[0].title == "Future event"

    def test_list_filter_by_start_before(self, store: CalendarStore) -> None:
        store.add(42, "Now", _now_iso(), _future_iso())
        far_future = _future_iso(hours=24 * 30)
        far_future_end = _future_iso(hours=24 * 30 + 1)
        store.add(42, "Far future", far_future, far_future_end)

        cutoff = _future_iso(hours=24 * 7)
        events = store.list_events(user_id=42, start_before=cutoff)
        assert len(events) == 1
        assert events[0].title == "Now"

    def test_list_ordered_by_start_time(self, store: CalendarStore) -> None:
        later = _future_iso(hours=3)
        later_end = _future_iso(hours=4)
        sooner = _future_iso(hours=1)
        sooner_end = _future_iso(hours=2)

        store.add(42, "Later", later, later_end)
        store.add(42, "Sooner", sooner, sooner_end)

        events = store.list_events(user_id=42)
        assert events[0].title == "Sooner"
        assert events[1].title == "Later"


class TestCalendarStoreUpdate:
    """Test updating events."""

    def test_update_title(self, store: CalendarStore) -> None:
        event = store.add(42, "Old title", _now_iso(), _future_iso())
        updated = store.update(event.id, 42, title="New title")
        assert updated is not None
        assert updated.title == "New title"

    def test_update_status(self, store: CalendarStore) -> None:
        event = store.add(42, "Meeting", _now_iso(), _future_iso())
        updated = store.update(event.id, 42, status="completed")
        assert updated is not None
        assert updated.status == "completed"

    def test_update_location(self, store: CalendarStore) -> None:
        event = store.add(42, "Meeting", _now_iso(), _future_iso())
        updated = store.update(event.id, 42, location="Room B")
        assert updated is not None
        assert updated.location == "Room B"

    def test_update_tags(self, store: CalendarStore) -> None:
        event = store.add(42, "Meeting", _now_iso(), _future_iso())
        updated = store.update(event.id, 42, tags=["work", "important"])
        assert updated is not None
        assert updated.tags == ["work", "important"]

    def test_update_times(self, store: CalendarStore) -> None:
        event = store.add(42, "Meeting", _now_iso(), _future_iso())
        new_start = _future_iso(hours=5)
        new_end = _future_iso(hours=6)
        updated = store.update(event.id, 42, start_time=new_start, end_time=new_end)
        assert updated is not None
        assert updated.start_time == new_start
        assert updated.end_time == new_end

    def test_update_nonexistent(self, store: CalendarStore) -> None:
        assert store.update(999, 42, title="Nope") is None

    def test_update_wrong_user(self, store: CalendarStore) -> None:
        event = store.add(42, "Meeting", _now_iso(), _future_iso())
        assert store.update(event.id, 99, title="Nope") is None

    def test_update_invalid_status(self, store: CalendarStore) -> None:
        event = store.add(42, "Meeting", _now_iso(), _future_iso())
        with pytest.raises(ValueError, match="status"):
            store.update(event.id, 42, status="invalid")

    def test_update_changes_updated_at(self, store: CalendarStore) -> None:
        event = store.add(42, "Meeting", _now_iso(), _future_iso())
        updated = store.update(event.id, 42, title="Changed")
        assert updated is not None
        assert updated.updated_at >= event.updated_at


class TestCalendarStoreRemove:
    """Test removing events."""

    def test_remove_existing(self, store: CalendarStore) -> None:
        event = store.add(42, "Meeting", _now_iso(), _future_iso())
        assert store.remove(event.id, 42) is True
        assert store.get(event.id, 42) is None

    def test_remove_nonexistent(self, store: CalendarStore) -> None:
        assert store.remove(999, 42) is False

    def test_remove_wrong_user(self, store: CalendarStore) -> None:
        event = store.add(42, "Meeting", _now_iso(), _future_iso())
        assert store.remove(event.id, 99) is False
        assert store.get(event.id, 42) is not None


class TestCalendarStoreUpcoming:
    """Test upcoming events query."""

    def test_upcoming_empty(self, store: CalendarStore) -> None:
        events = store.upcoming(user_id=42)
        assert events == []

    def test_upcoming_returns_future_events(self, store: CalendarStore) -> None:
        store.add(42, "Future", _future_iso(hours=1), _future_iso(hours=2))
        store.add(42, "Past", _past_iso(days=2), _past_iso(days=1))
        events = store.upcoming(user_id=42)
        assert len(events) == 1
        assert events[0].title == "Future"

    def test_upcoming_respects_days_ahead(self, store: CalendarStore) -> None:
        store.add(42, "Tomorrow", _future_iso(hours=24), _future_iso(hours=25))
        store.add(
            42, "Next month", _future_iso(hours=24 * 35), _future_iso(hours=24 * 35 + 1)
        )
        events = store.upcoming(user_id=42, days_ahead=7)
        assert len(events) == 1
        assert events[0].title == "Tomorrow"

    def test_upcoming_respects_limit(self, store: CalendarStore) -> None:
        for i in range(5):
            store.add(
                42,
                f"Event {i}",
                _future_iso(hours=i + 1),
                _future_iso(hours=i + 2),
            )
        events = store.upcoming(user_id=42, limit=3)
        assert len(events) == 3

    def test_upcoming_excludes_cancelled(self, store: CalendarStore) -> None:
        e = store.add(42, "Cancelled", _future_iso(hours=1), _future_iso(hours=2))
        store.update(e.id, 42, status="cancelled")
        store.add(42, "Active", _future_iso(hours=3), _future_iso(hours=4))
        events = store.upcoming(user_id=42)
        assert len(events) == 1
        assert events[0].title == "Active"


class TestCalendarStoreStats:
    """Test event statistics."""

    def test_stats_empty(self, store: CalendarStore) -> None:
        stats = store.stats(user_id=42)
        assert stats["total"] == 0
        assert stats["scheduled"] == 0

    def test_stats_counts(self, store: CalendarStore) -> None:
        store.add(42, "A", _now_iso(), _future_iso())
        store.add(42, "B", _now_iso(), _future_iso())
        e = store.add(42, "C", _now_iso(), _future_iso())
        store.update(e.id, 42, status="completed")
        stats = store.stats(user_id=42)
        assert stats["total"] == 3
        assert stats["scheduled"] == 2
        assert stats["completed"] == 1

    def test_stats_user_scoped(self, store: CalendarStore) -> None:
        store.add(42, "Mine", _now_iso(), _future_iso())
        store.add(99, "Theirs", _now_iso(), _future_iso())
        stats = store.stats(user_id=42)
        assert stats["total"] == 1
