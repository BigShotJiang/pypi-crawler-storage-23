"""Tests for calendar tool functions."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from folderbot.calendar_store import CalendarStore
from folderbot.tools.calendar import (
    AddEventRequest,
    DeleteEventRequest,
    ListEventsRequest,
    UpdateEventRequest,
    UpcomingEventsRequest,
    calendar_add,
    calendar_delete,
    calendar_list,
    calendar_upcoming,
    calendar_update,
)


@pytest.fixture
def calendar_store(tmp_path: Path) -> CalendarStore:
    return CalendarStore(tmp_path / "test.db")


def _make_context(calendar_store: CalendarStore, user_id: int = 42):
    context = MagicMock()
    context.user_id = user_id
    context.services = {"calendar": calendar_store, "folder": MagicMock()}
    context.services["folder"].get_tool_config = lambda name: {}
    return context


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _future_iso(hours: int = 1) -> str:
    return (datetime.now(timezone.utc) + timedelta(hours=hours)).isoformat()


class TestCalendarAdd:
    """Tests for calendar_add tool."""

    @pytest.mark.asyncio
    async def test_no_context(self) -> None:
        result = await calendar_add(
            AddEventRequest(
                title="Meeting",
                start_time=_now_iso(),
                end_time=_future_iso(),
            ),
            None,
        )
        assert result.is_error

    @pytest.mark.asyncio
    async def test_add_basic(self, calendar_store: CalendarStore) -> None:
        ctx = _make_context(calendar_store)
        result = await calendar_add(
            AddEventRequest(
                title="Team standup",
                start_time=_now_iso(),
                end_time=_future_iso(),
            ),
            ctx,
        )
        assert not result.is_error
        assert "team standup" in result.content.lower()

    @pytest.mark.asyncio
    async def test_add_with_all_fields(self, calendar_store: CalendarStore) -> None:
        ctx = _make_context(calendar_store)
        result = await calendar_add(
            AddEventRequest(
                title="Sprint Planning",
                start_time=_now_iso(),
                end_time=_future_iso(),
                description="Q1 sprint planning",
                location="Room A",
                tags=["work", "sprint"],
                reminders=["15m_before"],
                recurrence="weekly",
            ),
            ctx,
        )
        assert not result.is_error
        assert "sprint planning" in result.content.lower()

    @pytest.mark.asyncio
    async def test_add_stores_in_db(self, calendar_store: CalendarStore) -> None:
        ctx = _make_context(calendar_store)
        await calendar_add(
            AddEventRequest(
                title="DB Test",
                start_time=_now_iso(),
                end_time=_future_iso(),
            ),
            ctx,
        )
        events = calendar_store.list_events(user_id=42)
        assert len(events) == 1
        assert events[0].title == "DB Test"


class TestCalendarList:
    """Tests for calendar_list tool."""

    @pytest.mark.asyncio
    async def test_no_context(self) -> None:
        result = await calendar_list(ListEventsRequest(), None)
        assert result.is_error

    @pytest.mark.asyncio
    async def test_empty_list(self, calendar_store: CalendarStore) -> None:
        ctx = _make_context(calendar_store)
        result = await calendar_list(ListEventsRequest(), ctx)
        assert not result.is_error
        assert "no" in result.content.lower() or "0" in result.content

    @pytest.mark.asyncio
    async def test_list_with_events(self, calendar_store: CalendarStore) -> None:
        calendar_store.add(42, "Event A", _now_iso(), _future_iso())
        calendar_store.add(42, "Event B", _now_iso(), _future_iso())
        ctx = _make_context(calendar_store)
        result = await calendar_list(ListEventsRequest(), ctx)
        assert not result.is_error
        assert "event a" in result.content.lower()
        assert "event b" in result.content.lower()

    @pytest.mark.asyncio
    async def test_list_filter_by_search(self, calendar_store: CalendarStore) -> None:
        calendar_store.add(42, "Standup", _now_iso(), _future_iso())
        calendar_store.add(42, "Lunch", _now_iso(), _future_iso())
        ctx = _make_context(calendar_store)
        result = await calendar_list(ListEventsRequest(search="standup"), ctx)
        assert not result.is_error
        assert "standup" in result.content.lower()
        assert "lunch" not in result.content.lower()

    @pytest.mark.asyncio
    async def test_list_filter_by_tag(self, calendar_store: CalendarStore) -> None:
        calendar_store.add(42, "Work", _now_iso(), _future_iso(), tags=["work"])
        calendar_store.add(42, "Personal", _now_iso(), _future_iso(), tags=["personal"])
        ctx = _make_context(calendar_store)
        result = await calendar_list(ListEventsRequest(tag="work"), ctx)
        assert not result.is_error
        assert "work" in result.content.lower()
        assert "personal" not in result.content.lower()


class TestCalendarUpcoming:
    """Tests for calendar_upcoming tool."""

    @pytest.mark.asyncio
    async def test_no_context(self) -> None:
        result = await calendar_upcoming(UpcomingEventsRequest(), None)
        assert result.is_error

    @pytest.mark.asyncio
    async def test_upcoming_empty(self, calendar_store: CalendarStore) -> None:
        ctx = _make_context(calendar_store)
        result = await calendar_upcoming(UpcomingEventsRequest(), ctx)
        assert not result.is_error
        assert "no" in result.content.lower() or "0" in result.content

    @pytest.mark.asyncio
    async def test_upcoming_with_events(self, calendar_store: CalendarStore) -> None:
        calendar_store.add(42, "Tomorrow", _future_iso(hours=24), _future_iso(hours=25))
        ctx = _make_context(calendar_store)
        result = await calendar_upcoming(UpcomingEventsRequest(), ctx)
        assert not result.is_error
        assert "tomorrow" in result.content.lower()


class TestCalendarUpdate:
    """Tests for calendar_update tool."""

    @pytest.mark.asyncio
    async def test_no_context(self) -> None:
        result = await calendar_update(
            UpdateEventRequest(event_id=1, title="New"), None
        )
        assert result.is_error

    @pytest.mark.asyncio
    async def test_update_title(self, calendar_store: CalendarStore) -> None:
        event = calendar_store.add(42, "Old", _now_iso(), _future_iso())
        ctx = _make_context(calendar_store)
        result = await calendar_update(
            UpdateEventRequest(event_id=event.id, title="New Title"), ctx
        )
        assert not result.is_error
        assert "new title" in result.content.lower()

    @pytest.mark.asyncio
    async def test_update_nonexistent(self, calendar_store: CalendarStore) -> None:
        ctx = _make_context(calendar_store)
        result = await calendar_update(
            UpdateEventRequest(event_id=999, title="Nope"), ctx
        )
        assert result.is_error

    @pytest.mark.asyncio
    async def test_update_status(self, calendar_store: CalendarStore) -> None:
        event = calendar_store.add(42, "Meeting", _now_iso(), _future_iso())
        ctx = _make_context(calendar_store)
        result = await calendar_update(
            UpdateEventRequest(event_id=event.id, status="completed"), ctx
        )
        assert not result.is_error
        assert "completed" in result.content.lower()


class TestCalendarDelete:
    """Tests for calendar_delete tool."""

    @pytest.mark.asyncio
    async def test_no_context(self) -> None:
        result = await calendar_delete(DeleteEventRequest(event_id=1), None)
        assert result.is_error

    @pytest.mark.asyncio
    async def test_delete_existing(self, calendar_store: CalendarStore) -> None:
        event = calendar_store.add(42, "Meeting", _now_iso(), _future_iso())
        ctx = _make_context(calendar_store)
        result = await calendar_delete(DeleteEventRequest(event_id=event.id), ctx)
        assert not result.is_error
        assert calendar_store.get(event.id, 42) is None

    @pytest.mark.asyncio
    async def test_delete_nonexistent(self, calendar_store: CalendarStore) -> None:
        ctx = _make_context(calendar_store)
        result = await calendar_delete(DeleteEventRequest(event_id=999), ctx)
        assert result.is_error
