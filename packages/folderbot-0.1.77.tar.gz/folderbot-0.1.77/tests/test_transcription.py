"""Tests for audio transcription via faster-whisper."""

from unittest.mock import MagicMock, patch

import pytest

from folderbot.transcription import TranscriptionResult, transcribe_audio


def _make_segment(text: str) -> MagicMock:
    """Create a mock faster-whisper segment with a .text attribute."""
    seg = MagicMock()
    seg.text = text
    return seg


class TestTranscriptionResult:
    def test_frozen_dataclass(self):
        result = TranscriptionResult(text="hello world")
        assert result.text == "hello world"
        with pytest.raises(AttributeError):
            result.text = "changed"


class TestTranscribeAudio:
    @pytest.fixture(autouse=True)
    def _clear_model_cache(self):
        """Clear the model cache before each test to avoid leaking mocks."""
        with patch.dict("folderbot.transcription._model_cache", clear=True):
            yield

    @pytest.mark.asyncio
    async def test_transcribes_audio_bytes(self):
        mock_model = MagicMock()
        mock_model.transcribe.return_value = (
            iter([_make_segment("Hello, this is a test.")]),
            MagicMock(),  # info object
        )

        with patch("folderbot.transcription.WhisperModel", return_value=mock_model):
            result = await transcribe_audio(
                audio_bytes=b"fake audio data",
                model_name="base",
            )

        assert result == TranscriptionResult(text="Hello, this is a test.")
        mock_model.transcribe.assert_called_once()

    @pytest.mark.asyncio
    async def test_loads_requested_model(self):
        mock_model = MagicMock()
        mock_model.transcribe.return_value = (
            iter([_make_segment("transcribed")]),
            MagicMock(),
        )

        with patch(
            "folderbot.transcription.WhisperModel", return_value=mock_model
        ) as mock_cls:
            await transcribe_audio(
                audio_bytes=b"data",
                model_name="small",
            )

        mock_cls.assert_called_with("small")

    @pytest.mark.asyncio
    async def test_joins_multiple_segments(self):
        mock_model = MagicMock()
        mock_model.transcribe.return_value = (
            iter([_make_segment(" hello "), _make_segment(" world ")]),
            MagicMock(),
        )

        with patch("folderbot.transcription.WhisperModel", return_value=mock_model):
            result = await transcribe_audio(
                audio_bytes=b"data",
                model_name="base",
            )

        assert result.text == "hello world"

    @pytest.mark.asyncio
    async def test_propagates_error(self):
        mock_model = MagicMock()
        mock_model.transcribe.side_effect = RuntimeError("decode failed")

        with patch("folderbot.transcription.WhisperModel", return_value=mock_model):
            with pytest.raises(RuntimeError, match="decode failed"):
                await transcribe_audio(
                    audio_bytes=b"data",
                    model_name="base",
                )

    @pytest.mark.asyncio
    async def test_caches_model_across_calls(self):
        mock_model = MagicMock()
        mock_model.transcribe.return_value = (
            iter([_make_segment("hello")]),
            MagicMock(),
        )

        with patch(
            "folderbot.transcription.WhisperModel", return_value=mock_model
        ) as mock_cls:
            # Need fresh return values for each call (generators are consumed)
            mock_model.transcribe.side_effect = [
                (iter([_make_segment("hello")]), MagicMock()),
                (iter([_make_segment("hello")]), MagicMock()),
            ]
            await transcribe_audio(audio_bytes=b"a", model_name="base")
            await transcribe_audio(audio_bytes=b"b", model_name="base")

        # Model should only be loaded once for the same name
        assert mock_cls.call_count == 1

    @pytest.mark.asyncio
    async def test_empty_transcription_raises(self):
        mock_model = MagicMock()
        mock_model.transcribe.return_value = (
            iter([]),  # no segments
            MagicMock(),
        )

        with patch("folderbot.transcription.WhisperModel", return_value=mock_model):
            with pytest.raises(ValueError, match="empty"):
                await transcribe_audio(
                    audio_bytes=b"data",
                    model_name="base",
                )
