"""Tests for web tools."""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from folderbot.tools.web_fetch import WebFetchInput
from folderbot.tools.web_search import WebSearchInput, WebSearchRequest, web_search
from folderbot.tools.web_tools import WebTools
from folderbot.tools import web_fetch


def _make_context(google_api_key="test-key", google_cx="test-cx", tools=None):
    """Create a mock BotContext with Google config."""
    config = MagicMock()
    config.google_api_key = google_api_key
    config.google_cx = google_cx
    config.tools = tools or {}
    services = MagicMock()
    services.config = config
    services.get_tool_config = lambda name: config.tools.get(name, {})
    context = MagicMock()
    context.services = {"folder": services}
    return context


class TestWebSearchInput:
    """Tests for WebSearchInput dataclass."""

    def test_defaults(self):
        """Test default values."""
        input_model = WebSearchInput(query="test")
        assert input_model.query == "test"
        assert input_model.max_results == 5

    def test_custom_max_results(self):
        """Test custom max_results."""
        input_model = WebSearchInput(query="test", max_results=10)
        assert input_model.max_results == 10


class TestWebFetchInput:
    """Tests for WebFetchInput dataclass."""

    def test_defaults(self):
        """Test default values."""
        input_model = WebFetchInput(url="https://example.com")
        assert input_model.url == "https://example.com"
        assert input_model.max_chars == 10000

    def test_custom_max_chars(self):
        """Test custom max_chars."""
        input_model = WebFetchInput(url="https://example.com", max_chars=5000)
        assert input_model.max_chars == 5000


class TestWebTools:
    """Tests for WebTools class."""

    def test_init(self):
        """Test WebTools initialization."""
        tools = WebTools()
        # Should not raise, even if dependencies are missing
        assert isinstance(tools, WebTools)

    @pytest.mark.asyncio
    async def test_execute_unknown_tool(self):
        """Test execute returns None for unknown tools."""
        tools = WebTools()
        result = await tools.execute("unknown_tool", {})
        assert result is None

    def test_get_tool_definitions_structure(self):
        """Test tool definitions have correct structure."""
        tools = WebTools()
        definitions = tools.get_tool_definitions()
        # May be empty if dependencies not installed
        for defn in definitions:
            assert "name" in defn
            assert "description" in defn
            assert "input_schema" in defn


class TestWebSearchExecution:
    """Tests for web_search tool execution with Google Custom Search API."""

    @pytest.mark.asyncio
    async def test_search_no_context(self):
        """Test search with no context returns error."""
        result = await web_search(WebSearchRequest(query="test"), None)
        assert result.is_error
        assert "not available" in result.content

    @pytest.mark.asyncio
    async def test_search_no_config(self):
        """Test search with no config returns error."""
        context = MagicMock()
        services = MagicMock()
        services.config = None
        context.services = {"folder": services}
        result = await web_search(WebSearchRequest(query="test"), context)
        assert result.is_error
        assert "not available" in result.content

    @pytest.mark.asyncio
    async def test_search_missing_api_key(self):
        """Test search with missing API key returns error."""
        context = _make_context(google_api_key="", google_cx="test-cx")
        result = await web_search(WebSearchRequest(query="test"), context)
        assert result.is_error
        assert "not configured" in result.content.lower()

    @pytest.mark.asyncio
    async def test_search_missing_cx(self):
        """Test search with missing CX returns error."""
        context = _make_context(google_api_key="test-key", google_cx="")
        result = await web_search(WebSearchRequest(query="test"), context)
        assert result.is_error
        assert "not configured" in result.content.lower()

    @pytest.mark.asyncio
    async def test_search_success(self):
        """Test successful search returns formatted results."""
        context = _make_context()
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "items": [
                {
                    "title": "Result 1",
                    "link": "https://example.com/1",
                    "snippet": "Snippet 1",
                },
                {
                    "title": "Result 2",
                    "link": "https://example.com/2",
                    "snippet": "Snippet 2",
                },
            ]
        }
        mock_response.raise_for_status = MagicMock()

        mock_client = AsyncMock()
        mock_client.get.return_value = mock_response
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch(
            "folderbot.tools.web_search.httpx.AsyncClient", return_value=mock_client
        ):
            result = await web_search(
                WebSearchRequest(query="python programming"), context
            )

        assert not result.is_error
        assert "Result 1" in result.content
        assert "Result 2" in result.content
        assert "https://example.com/1" in result.content

    @pytest.mark.asyncio
    async def test_search_no_results(self):
        """Test search with no results."""
        context = _make_context()
        mock_response = MagicMock()
        mock_response.json.return_value = {"items": []}
        mock_response.raise_for_status = MagicMock()

        mock_client = AsyncMock()
        mock_client.get.return_value = mock_response
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch(
            "folderbot.tools.web_search.httpx.AsyncClient", return_value=mock_client
        ):
            result = await web_search(
                WebSearchRequest(query="xyznonexistent123"), context
            )

        assert not result.is_error
        assert "No results found" in result.content

    @pytest.mark.asyncio
    async def test_search_max_results_clamped(self):
        """Test max_results is clamped to 1-10."""
        context = _make_context()
        mock_response = MagicMock()
        mock_response.json.return_value = {"items": []}
        mock_response.raise_for_status = MagicMock()

        mock_client = AsyncMock()
        mock_client.get.return_value = mock_response
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch(
            "folderbot.tools.web_search.httpx.AsyncClient", return_value=mock_client
        ):
            # Test max_results > 10 gets clamped
            await web_search(WebSearchRequest(query="test", max_results=100), context)
            call_kwargs = mock_client.get.call_args
            assert call_kwargs[1]["params"]["num"] == 10

            mock_client.get.reset_mock()

            # Test max_results < 1 gets clamped
            await web_search(WebSearchRequest(query="test", max_results=0), context)
            call_kwargs = mock_client.get.call_args
            assert call_kwargs[1]["params"]["num"] == 1

    @pytest.mark.asyncio
    async def test_search_http_error(self):
        """Test search handles HTTP errors."""
        context = _make_context()

        mock_client = AsyncMock()
        mock_client.get.side_effect = Exception("Connection refused")
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch(
            "folderbot.tools.web_search.httpx.AsyncClient", return_value=mock_client
        ):
            result = await web_search(WebSearchRequest(query="test"), context)

        assert result.is_error
        assert "Search error" in result.content

    @pytest.mark.asyncio
    async def test_search_passes_correct_params(self):
        """Test search passes correct parameters to Google API."""
        context = _make_context(google_api_key="my-key", google_cx="my-cx")
        mock_response = MagicMock()
        mock_response.json.return_value = {"items": []}
        mock_response.raise_for_status = MagicMock()

        mock_client = AsyncMock()
        mock_client.get.return_value = mock_response
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch(
            "folderbot.tools.web_search.httpx.AsyncClient", return_value=mock_client
        ):
            await web_search(
                WebSearchRequest(query="hello world", max_results=3), context
            )

        mock_client.get.assert_called_once()
        call_args = mock_client.get.call_args
        assert call_args[0][0] == "https://www.googleapis.com/customsearch/v1"
        params = call_args[1]["params"]
        assert params["key"] == "my-key"
        assert params["cx"] == "my-cx"
        assert params["q"] == "hello world"
        assert params["num"] == 3

    @pytest.mark.asyncio
    async def test_search_reads_from_tool_config(self):
        """Test web_search reads keys from [tools.web_search] config."""
        context = _make_context(
            google_api_key="",
            google_cx="",
            tools={
                "web_search": {
                    "google_api_key": "tools-key",
                    "google_cx": "tools-cx",
                }
            },
        )
        mock_response = MagicMock()
        mock_response.json.return_value = {"items": []}
        mock_response.raise_for_status = MagicMock()

        mock_client = AsyncMock()
        mock_client.get.return_value = mock_response
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch(
            "folderbot.tools.web_search.httpx.AsyncClient", return_value=mock_client
        ):
            result = await web_search(WebSearchRequest(query="test"), context)

        assert not result.is_error
        params = mock_client.get.call_args[1]["params"]
        assert params["key"] == "tools-key"
        assert params["cx"] == "tools-cx"


class TestWebFetchExecution:
    """Tests for web_fetch tool execution."""

    @pytest.mark.asyncio
    @patch.object(web_fetch, "_FETCH_AVAILABLE", False)
    async def test_fetch_unavailable(self):
        """Test fetch when dependencies not available."""
        from folderbot.tools.web_fetch import web_fetch as wf_func, WebFetchRequest

        result = await wf_func(WebFetchRequest(url="https://example.com"), None)
        assert result.is_error
        assert "not available" in result.content

    @pytest.mark.asyncio
    @patch.object(web_fetch, "_FETCH_AVAILABLE", True)
    @patch.object(web_fetch, "httpx")
    @patch.object(web_fetch, "BeautifulSoup")
    async def test_fetch_html_success(self, mock_bs, mock_httpx):
        """Test successful HTML fetch."""
        mock_response = MagicMock()
        mock_response.headers = {"content-type": "text/html"}
        mock_response.text = "<html><body><p>Hello World</p></body></html>"
        mock_response.raise_for_status = MagicMock()

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get.return_value = mock_response
        mock_httpx.Client.return_value = mock_client

        mock_soup = MagicMock()
        mock_soup.title = MagicMock()
        mock_soup.title.string = "Test Page"
        mock_soup.get_text.return_value = "Hello World"
        mock_soup.return_value = mock_soup
        mock_bs.return_value = mock_soup

        from folderbot.tools.web_fetch import web_fetch as wf_func, WebFetchRequest

        result = await wf_func(WebFetchRequest(url="https://example.com"), None)

        assert not result.is_error
        assert "Hello World" in result.content

    @pytest.mark.asyncio
    @patch.object(web_fetch, "_FETCH_AVAILABLE", True)
    @patch.object(web_fetch, "httpx")
    async def test_fetch_plain_text(self, mock_httpx):
        """Test fetching plain text content."""
        mock_response = MagicMock()
        mock_response.headers = {"content-type": "text/plain"}
        mock_response.text = "Plain text content"
        mock_response.raise_for_status = MagicMock()

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get.return_value = mock_response
        mock_httpx.Client.return_value = mock_client

        from folderbot.tools.web_fetch import web_fetch as wf_func, WebFetchRequest

        result = await wf_func(
            WebFetchRequest(url="https://example.com/file.txt"), None
        )

        assert not result.is_error
        assert "Plain text content" in result.content

    @pytest.mark.asyncio
    @patch.object(web_fetch, "_FETCH_AVAILABLE", True)
    @patch.object(web_fetch, "httpx")
    async def test_fetch_truncation(self, mock_httpx):
        """Test content truncation at max_chars."""
        long_content = "x" * 20000
        mock_response = MagicMock()
        mock_response.headers = {"content-type": "text/plain"}
        mock_response.text = long_content
        mock_response.raise_for_status = MagicMock()

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get.return_value = mock_response
        mock_httpx.Client.return_value = mock_client

        from folderbot.tools.web_fetch import web_fetch as wf_func, WebFetchRequest

        result = await wf_func(
            WebFetchRequest(url="https://example.com", max_chars=1000), None
        )

        assert not result.is_error
        assert len(result.content) < 1200  # Some buffer for truncation message
        assert "Truncated" in result.content
