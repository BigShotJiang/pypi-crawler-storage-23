"""Tests for the plotting tool."""

from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

from folderbot.session_manager import SessionManager
from folderbot.tools.plot import (
    PlotRequest,
    plot_chart,
    _MATPLOTLIB_AVAILABLE,
)


@pytest.fixture
def session_manager(tmp_path: Path) -> SessionManager:
    return SessionManager(tmp_path / "test.db")


def _make_context(session_manager: SessionManager, tmp_path: Path, user_id: int = 42):
    context = MagicMock()
    context.user_id = user_id
    uploads_dir = tmp_path / "uploads"
    uploads_dir.mkdir(exist_ok=True)
    upload_services = MagicMock()
    upload_services.uploads_dir = uploads_dir
    upload_services.chat_id = 123
    upload_services.send_document = AsyncMock()
    context.services = {
        "session": session_manager,
        "folder": MagicMock(),
        "uploads": upload_services,
    }
    context.services["folder"].root = tmp_path
    return context


@pytest.mark.skipif(not _MATPLOTLIB_AVAILABLE, reason="matplotlib not installed")
class TestPlotChart:
    """Tests for the plot_chart tool."""

    @pytest.mark.asyncio
    async def test_no_context(self) -> None:
        result = await plot_chart(
            PlotRequest(
                chart_type="bar",
                title="Test",
                x_values=["a", "b"],
                y_values=[1, 2],
            ),
            None,
        )
        assert result.is_error

    @pytest.mark.asyncio
    async def test_bar_chart(self, session_manager, tmp_path) -> None:
        ctx = _make_context(session_manager, tmp_path)
        result = await plot_chart(
            PlotRequest(
                chart_type="bar",
                title="Test Bar",
                x_values=["A", "B", "C"],
                y_values=[10, 20, 30],
            ),
            ctx,
        )
        assert not result.is_error
        assert "chart" in result.content.lower() or "plot" in result.content.lower()
        uploads = list((tmp_path / "uploads").glob("*.png"))
        assert len(uploads) == 1

    @pytest.mark.asyncio
    async def test_line_chart(self, session_manager, tmp_path) -> None:
        ctx = _make_context(session_manager, tmp_path)
        result = await plot_chart(
            PlotRequest(
                chart_type="line",
                title="Test Line",
                x_values=["Mon", "Tue", "Wed"],
                y_values=[5, 15, 10],
            ),
            ctx,
        )
        assert not result.is_error

    @pytest.mark.asyncio
    async def test_pie_chart(self, session_manager, tmp_path) -> None:
        ctx = _make_context(session_manager, tmp_path)
        result = await plot_chart(
            PlotRequest(
                chart_type="pie",
                title="Test Pie",
                x_values=["Cats", "Dogs", "Birds"],
                y_values=[45, 35, 20],
            ),
            ctx,
        )
        assert not result.is_error

    @pytest.mark.asyncio
    async def test_empty_data(self, session_manager, tmp_path) -> None:
        ctx = _make_context(session_manager, tmp_path)
        result = await plot_chart(
            PlotRequest(
                chart_type="bar",
                title="Empty",
                x_values=[],
                y_values=[],
            ),
            ctx,
        )
        assert result.is_error
        assert "empty" in result.content.lower() or "no data" in result.content.lower()

    @pytest.mark.asyncio
    async def test_mismatched_lengths(self, session_manager, tmp_path) -> None:
        ctx = _make_context(session_manager, tmp_path)
        result = await plot_chart(
            PlotRequest(
                chart_type="bar",
                title="Mismatch",
                x_values=["a", "b"],
                y_values=[1, 2, 3],
            ),
            ctx,
        )
        assert result.is_error

    @pytest.mark.asyncio
    async def test_with_labels(self, session_manager, tmp_path) -> None:
        ctx = _make_context(session_manager, tmp_path)
        result = await plot_chart(
            PlotRequest(
                chart_type="bar",
                title="Labeled",
                x_values=["A", "B"],
                y_values=[10, 20],
                x_label="Category",
                y_label="Count",
            ),
            ctx,
        )
        assert not result.is_error

    @pytest.mark.asyncio
    async def test_result_contains_path(self, session_manager, tmp_path) -> None:
        ctx = _make_context(session_manager, tmp_path)
        result = await plot_chart(
            PlotRequest(
                chart_type="bar",
                title="Path Test",
                x_values=["X"],
                y_values=[1],
            ),
            ctx,
        )
        assert not result.is_error
        assert ".png" in result.content

    @pytest.mark.asyncio
    async def test_sends_chart_via_telegram(self, session_manager, tmp_path) -> None:
        ctx = _make_context(session_manager, tmp_path)
        result = await plot_chart(
            PlotRequest(
                chart_type="bar",
                title="Send Test",
                x_values=["A", "B"],
                y_values=[10, 20],
            ),
            ctx,
        )
        assert not result.is_error
        send_mock = ctx.services["uploads"].send_document
        send_mock.assert_awaited_once()
        call_args = send_mock.call_args
        assert call_args[0][0] == 123
        assert str(call_args[0][1]).endswith(".png")
