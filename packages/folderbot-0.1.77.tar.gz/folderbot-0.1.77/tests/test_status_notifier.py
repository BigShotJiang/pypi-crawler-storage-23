"""Tests for status notifier."""

import asyncio
from unittest.mock import AsyncMock, patch

import pytest

from folderbot.status_notifier import StatusNotifier, tool_label


class TestToolLabel:
    def test_known_tool(self):
        assert tool_label("web_search") == "Searching the web"

    def test_known_tool_read_file(self):
        assert tool_label("read_file") == "Reading a file"

    def test_unknown_tool_fallback(self):
        result = tool_label("some_custom_tool")
        assert result == "Some Custom Tool"

    def test_ask_user(self):
        assert tool_label("ask_user") == "Waiting for your input"


class TestStatusNotifierStart:
    @pytest.mark.asyncio
    async def test_start_sends_typing(self):
        bot = AsyncMock()
        notifier = StatusNotifier(chat_id=123, bot=bot)
        await notifier.start()
        await asyncio.sleep(0.05)
        bot.send_chat_action.assert_called_with(123, "typing")
        await notifier.stop()

    @pytest.mark.asyncio
    async def test_typing_repeats(self):
        bot = AsyncMock()
        notifier = StatusNotifier(chat_id=123, bot=bot)
        with patch("folderbot.status_notifier._TYPING_INTERVAL", 0.02):
            await notifier.start()
            await asyncio.sleep(0.07)
            await notifier.stop()
        assert bot.send_chat_action.call_count >= 2


class TestStatusNotifierStop:
    @pytest.mark.asyncio
    async def test_stop_cancels_typing(self):
        bot = AsyncMock()
        notifier = StatusNotifier(chat_id=123, bot=bot)
        await notifier.start()
        await asyncio.sleep(0.01)
        await notifier.stop()
        assert notifier._typing_task.cancelled() or notifier._typing_task.done()

    @pytest.mark.asyncio
    async def test_stop_deletes_status_message(self):
        bot = AsyncMock()
        status_msg = AsyncMock()
        bot.send_message.return_value = status_msg
        notifier = StatusNotifier(chat_id=123, bot=bot)
        await notifier.start()
        await notifier.update("web_search")
        await notifier.stop()
        status_msg.delete.assert_called_once()

    @pytest.mark.asyncio
    async def test_stop_without_start_is_safe(self):
        bot = AsyncMock()
        notifier = StatusNotifier(chat_id=123, bot=bot)
        await notifier.stop()

    @pytest.mark.asyncio
    async def test_stop_handles_delete_failure(self):
        bot = AsyncMock()
        status_msg = AsyncMock()
        status_msg.delete.side_effect = Exception("Message not found")
        bot.send_message.return_value = status_msg
        notifier = StatusNotifier(chat_id=123, bot=bot)
        await notifier.start()
        await notifier.update("read_file")
        await notifier.stop()


class TestStatusNotifierUpdate:
    @pytest.mark.asyncio
    async def test_first_update_sends_message(self):
        bot = AsyncMock()
        status_msg = AsyncMock()
        bot.send_message.return_value = status_msg
        notifier = StatusNotifier(chat_id=123, bot=bot)
        await notifier.update("web_search")
        bot.send_message.assert_called_once_with(
            123, "<i>Searching the web...</i>", parse_mode="HTML"
        )
        await notifier.stop()

    @pytest.mark.asyncio
    async def test_second_update_edits_message(self):
        bot = AsyncMock()
        status_msg = AsyncMock()
        bot.send_message.return_value = status_msg
        notifier = StatusNotifier(chat_id=123, bot=bot)
        await notifier.update("web_search")
        await notifier.update("read_file")
        status_msg.edit_text.assert_called_once_with(
            "<i>Reading a file...</i>", parse_mode="HTML"
        )
        await notifier.stop()

    @pytest.mark.asyncio
    async def test_update_handles_edit_failure(self):
        from telegram.error import BadRequest

        bot = AsyncMock()
        status_msg = AsyncMock()
        status_msg.edit_text.side_effect = BadRequest("Message is not modified")
        bot.send_message.return_value = status_msg
        notifier = StatusNotifier(chat_id=123, bot=bot)
        await notifier.update("web_search")
        await notifier.update("web_search")
        await notifier.stop()

    @pytest.mark.asyncio
    async def test_multiple_updates_only_one_send(self):
        bot = AsyncMock()
        status_msg = AsyncMock()
        bot.send_message.return_value = status_msg
        notifier = StatusNotifier(chat_id=123, bot=bot)
        await notifier.update("list_files")
        await notifier.update("read_file")
        await notifier.update("web_search")
        bot.send_message.assert_called_once()
        assert status_msg.edit_text.call_count == 2
        await notifier.stop()
