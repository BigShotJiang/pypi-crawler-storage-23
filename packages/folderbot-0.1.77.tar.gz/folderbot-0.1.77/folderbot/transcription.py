"""Audio transcription via faster-whisper (CTranslate2)."""

import asyncio
import tempfile
from dataclasses import dataclass

from faster_whisper import WhisperModel

_model_cache: dict[str, WhisperModel] = {}


def _get_model(model_name: str) -> WhisperModel:
    """Load a faster-whisper model, caching it for reuse."""
    if model_name not in _model_cache:
        _model_cache[model_name] = WhisperModel(model_name)
    return _model_cache[model_name]


@dataclass(frozen=True)
class TranscriptionResult:
    text: str


def _transcribe_sync(audio_bytes: bytes, model_name: str) -> str:
    """Synchronous transcription — runs faster-whisper on a temp file."""
    model = _get_model(model_name)
    with tempfile.NamedTemporaryFile(suffix=".ogg", delete=True) as tmp:
        tmp.write(audio_bytes)
        tmp.flush()
        segments, _info = model.transcribe(tmp.name)
        # Consume the generator inside the with block — segments is lazy
        # and the file must exist while transcription runs.
        text = " ".join(seg.text.strip() for seg in segments).strip()
    if not text:
        raise ValueError("Transcription returned empty result")
    return text


async def transcribe_audio(
    audio_bytes: bytes, model_name: str = "base"
) -> TranscriptionResult:
    """Transcribe audio bytes using faster-whisper.

    Args:
        audio_bytes: Raw audio file bytes.
        model_name: Whisper model size (tiny, base, small, medium, large-v3).

    Returns:
        TranscriptionResult with the transcribed text.
    """
    text = await asyncio.to_thread(_transcribe_sync, audio_bytes, model_name)
    return TranscriptionResult(text=text)
