"""Self-update mechanism: check PyPI for newer versions and upgrade."""

from __future__ import annotations

import json
import subprocess
import sys
from dataclasses import dataclass
from urllib.error import URLError
from urllib.request import urlopen

from packaging.version import Version

PYPI_URL = "https://pypi.org/pypi/{package}/json"


class UpdateError(RuntimeError):
    """Raised when an update check or installation fails."""


@dataclass(frozen=True)
class UpdateCheckResult:
    """Result of checking PyPI for updates."""

    current_version: str
    latest_version: str
    update_available: bool


def fetch_pypi_version(package: str = "folderbot") -> str:
    """Fetch the latest version of a package from PyPI.

    Raises:
        UpdateError: On network failure or unexpected response format.
    """
    url = PYPI_URL.format(package=package)
    try:
        with urlopen(url, timeout=15) as response:
            data = json.loads(response.read())
    except (URLError, OSError) as e:
        raise UpdateError(f"Failed to fetch version from PyPI: {e}") from e
    except (json.JSONDecodeError, ValueError) as e:
        raise UpdateError(f"Invalid response from PyPI: {e}") from e

    try:
        return data["info"]["version"]
    except (KeyError, TypeError) as e:
        raise UpdateError(f"Missing version in PyPI response: {e}") from e


def check_for_update(current_version: str, latest_version: str) -> UpdateCheckResult:
    """Compare current version with latest available version."""
    update_available = Version(latest_version) > Version(current_version)
    return UpdateCheckResult(
        current_version=current_version,
        latest_version=latest_version,
        update_available=update_available,
    )


def run_pip_upgrade(package: str = "folderbot") -> tuple[int, str]:
    """Run pip install --upgrade for the given package.

    Returns:
        Tuple of (return_code, output_text).
    """
    result = subprocess.run(
        [sys.executable, "-m", "pip", "install", "--upgrade", package],
        capture_output=True,
        text=True,
    )
    output = result.stdout if result.returncode == 0 else result.stderr
    return result.returncode, output
