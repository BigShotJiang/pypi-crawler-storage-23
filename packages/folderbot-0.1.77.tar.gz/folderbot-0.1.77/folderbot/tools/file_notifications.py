"""File notification tools."""

from pydantic import BaseModel

from ..bot import BotContext
from .base import ToolResult
from .registry import folder_bot, get_services


class EnableFileNotificationsRequest(BaseModel, frozen=True):
    """Request to enable file notifications."""

    pass


class DisableFileNotificationsRequest(BaseModel, frozen=True):
    """Request to disable file notifications."""

    pass


class GetFileNotificationStatusRequest(BaseModel, frozen=True):
    """Request to get file notification status."""

    pass


@folder_bot.tool(
    name="enable_file_notifications",
    request_type=EnableFileNotificationsRequest,
    response_type=ToolResult,
)
async def enable_file_notifications(
    _request: EnableFileNotificationsRequest, context: BotContext | None = None
) -> ToolResult:
    """Enable file change notifications.

    When enabled, the user will receive Telegram messages whenever files
    in the folder are created, modified, or deleted.
    Use this when the user wants to be notified about changes.
    """
    services = get_services(context)
    if services is None:
        return ToolResult(content="Services not available", is_error=True)

    if not services.session_manager:
        return ToolResult(content="Session manager not available", is_error=True)

    user_id = context.user_id if context else 0
    if not user_id:
        return ToolResult(content="User ID not available", is_error=True)

    services.session_manager.set_file_notifications_enabled(user_id, True)
    return ToolResult(
        content="File change notifications enabled. You will now receive "
        "notifications when files are created, modified, or deleted."
    )


@folder_bot.tool(
    name="disable_file_notifications",
    request_type=DisableFileNotificationsRequest,
    response_type=ToolResult,
)
async def disable_file_notifications(
    _request: DisableFileNotificationsRequest, context: BotContext | None = None
) -> ToolResult:
    """Disable file change notifications.

    Use this when the user no longer wants to receive notifications about file changes.
    """
    services = get_services(context)
    if services is None:
        return ToolResult(content="Services not available", is_error=True)

    if not services.session_manager:
        return ToolResult(content="Session manager not available", is_error=True)

    user_id = context.user_id if context else 0
    if not user_id:
        return ToolResult(content="User ID not available", is_error=True)

    services.session_manager.set_file_notifications_enabled(user_id, False)
    return ToolResult(content="File change notifications disabled.")


@folder_bot.tool(
    name="get_file_notification_status",
    request_type=GetFileNotificationStatusRequest,
    response_type=ToolResult,
)
async def get_file_notification_status(
    _request: GetFileNotificationStatusRequest, context: BotContext | None = None
) -> ToolResult:
    """Check if file change notifications are currently enabled or disabled for the user."""
    services = get_services(context)
    if services is None:
        return ToolResult(content="Services not available", is_error=True)

    if not services.session_manager:
        return ToolResult(content="Session manager not available", is_error=True)

    user_id = context.user_id if context else 0
    if not user_id:
        return ToolResult(content="User ID not available", is_error=True)

    enabled = services.session_manager.get_file_notifications_enabled(user_id)
    status = "enabled" if enabled else "disabled"
    return ToolResult(content=f"File change notifications are {status}.")


# Backward compatibility aliases
EnableFileNotificationsInput = EnableFileNotificationsRequest
DisableFileNotificationsInput = DisableFileNotificationsRequest
GetFileNotificationStatusInput = GetFileNotificationStatusRequest
