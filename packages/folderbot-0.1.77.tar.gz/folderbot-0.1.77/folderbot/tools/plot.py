"""Plotting tool using matplotlib for chart generation."""

from __future__ import annotations

import hashlib
import logging
from typing import TYPE_CHECKING

from pydantic import BaseModel, Field

from .base import ToolResult
from .registry import folder_bot

if TYPE_CHECKING:
    from ..bot import BotContext

logger = logging.getLogger(__name__)

try:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    plt.style.use("bmh")
    _MATPLOTLIB_AVAILABLE = True
except ImportError:
    _MATPLOTLIB_AVAILABLE = False


class PlotRequest(BaseModel, frozen=True):
    """Request to generate a chart."""

    chart_type: str = Field(
        description=(
            "Type of chart: 'bar', 'line', 'pie', 'scatter', or 'horizontal_bar'."
        ),
    )
    title: str = Field(description="Chart title.")
    x_values: list[str] = Field(description="Labels or categories for the x-axis.")
    y_values: list[float] = Field(description="Numeric values for the y-axis.")
    x_label: str = Field(default="", description="Optional x-axis label.")
    y_label: str = Field(default="", description="Optional y-axis label.")


@folder_bot.tool(
    name="plot_chart",
    request_type=PlotRequest,
    response_type=ToolResult,
)
async def plot_chart(
    request: PlotRequest, _context: BotContext | None = None
) -> ToolResult:
    """Generate a chart and save it as an image.

    Creates bar, line, pie, scatter, or horizontal bar charts using matplotlib.
    The chart is saved as a PNG image in the uploads folder and can be
    sent to the user via Telegram.

    Use this when the user asks for a visual representation of data,
    trends, or comparisons.
    """
    if not _MATPLOTLIB_AVAILABLE:
        return ToolResult(
            content="Plotting not available: matplotlib is not installed.",
            is_error=True,
        )

    if _context is None:
        return ToolResult(content="Plotting not available: no context.", is_error=True)

    if not request.x_values or not request.y_values:
        return ToolResult(content="No data provided: values are empty.", is_error=True)

    if len(request.x_values) != len(request.y_values):
        return ToolResult(
            content=(
                f"Data mismatch: {len(request.x_values)} x-values "
                f"vs {len(request.y_values)} y-values."
            ),
            is_error=True,
        )

    upload_services = _context.services.get("uploads")
    folder_services = _context.services.get("folder")
    if upload_services is not None:
        uploads_dir = upload_services.uploads_dir
    elif folder_services is not None:
        uploads_dir = folder_services.root / ".folderbot" / "uploads"
    else:
        return ToolResult(content="No uploads directory available.", is_error=True)

    uploads_dir.mkdir(parents=True, exist_ok=True)

    try:
        fig, ax = _create_figure(request)
        content_hash = hashlib.sha256(
            f"{request.title}-{request.chart_type}-{request.x_values}".encode()
        ).hexdigest()[:16]
        filename = f"chart_{content_hash}.png"
        filepath = uploads_dir / filename
        fig.savefig(str(filepath), dpi=150, bbox_inches="tight")
        plt.close(fig)
        if upload_services is not None and hasattr(upload_services, "send_document"):
            await upload_services.send_document(
                upload_services.chat_id, filepath, filename
            )
        return ToolResult(content=f"Chart saved: {filepath}\nTitle: {request.title}")
    except Exception as e:
        logger.exception("Error generating chart")
        return ToolResult(content=f"Error generating chart: {e}", is_error=True)


def _create_figure(request: PlotRequest) -> tuple:
    """Create a matplotlib figure and axes from the request."""
    import matplotlib.pyplot as plt

    chart_type = request.chart_type.lower()

    if chart_type == "pie":
        fig, ax = plt.subplots(figsize=(8, 5))
        ax.pie(request.y_values, labels=request.x_values, autopct="%1.1f%%")
    elif chart_type == "line":
        fig, ax = plt.subplots(figsize=(8, 5))
        ax.plot(request.x_values, request.y_values, marker="o")
    elif chart_type == "scatter":
        fig, ax = plt.subplots(figsize=(8, 5))
        ax.scatter(request.x_values, request.y_values)
    elif chart_type == "horizontal_bar":
        fig, ax = plt.subplots(figsize=(8, 5))
        ax.barh(request.x_values, request.y_values)
    else:
        fig, ax = plt.subplots(figsize=(8, 5))
        ax.bar(request.x_values, request.y_values)

    ax.set_title(request.title)
    if request.x_label:
        ax.set_xlabel(request.x_label)
    if request.y_label:
        ax.set_ylabel(request.y_label)

    fig.tight_layout()
    return fig, ax
