import math
import typing as t

import pytest

from qs_codec import Charset, DecodeOptions
from qs_codec.enums.decode_kind import DecodeKind
from qs_codec.utils.decode_utils import DecodeUtils


class TestDecodeOptionsPostInitDefaults:
    def test_defaults_normalize(self) -> None:
        opts = DecodeOptions()
        assert opts.decode_dot_in_keys is False
        assert opts.allow_dots is False

    def test_decode_dot_implies_allow_dots(self) -> None:
        opts = DecodeOptions(decode_dot_in_keys=True)
        assert opts.allow_dots is True

    def test_invariant_violation_raises(self) -> None:
        with pytest.raises(ValueError):
            DecodeOptions(decode_dot_in_keys=True, allow_dots=False)


class TestDecodeOptionsDecoderDefault:
    def test_default_decoder_behaves_like_decodeutils(self) -> None:
        # The adapter may wrap the default, so compare behavior rather than identity.
        opts = DecodeOptions()
        s = "a+b%2E"
        decoder = require_decoder(opts)
        out_key = decoder(s, Charset.UTF8, kind=DecodeKind.KEY)
        out_val = decoder(s, Charset.UTF8, kind=DecodeKind.VALUE)
        assert out_key == DecodeUtils.decode(s, charset=Charset.UTF8, kind=DecodeKind.KEY)
        assert out_val == DecodeUtils.decode(s, charset=Charset.UTF8, kind=DecodeKind.VALUE)


class TestDecoderAdapterSignatures:
    def test_legacy_single_arg(self) -> None:
        calls: t.List[t.Tuple[t.Optional[str]]] = []

        def dec(s: t.Optional[str]) -> t.Optional[str]:
            calls.append((s,))
            return None if s is None else s.upper()

        opts = DecodeOptions(decoder=dec)
        decoder = require_decoder(opts)
        assert decoder("x", Charset.UTF8, kind=DecodeKind.KEY) == "X"
        assert calls == [("x",)]

    def test_two_args_s_charset(self) -> None:
        seen: t.List[t.Tuple[t.Optional[str], t.Optional[Charset]]] = []

        def dec(s: t.Optional[str], charset: t.Optional[Charset]) -> t.Optional[str]:
            seen.append((s, charset))
            # Echo string and charset name to prove we passed it
            return None if s is None else f"{s}|{charset.name if charset else 'NONE'}"

        opts = DecodeOptions(decoder=dec)
        decoder = require_decoder(opts)
        assert decoder("hi", Charset.LATIN1, kind=DecodeKind.VALUE) == "hi|LATIN1"
        assert seen == [("hi", Charset.LATIN1)]

    def test_three_args_kind_enum_annotation(self) -> None:
        seen: t.List[t.Any] = []

        def dec(s: t.Optional[str], charset: t.Optional[Charset], kind: DecodeKind) -> t.Optional[str]:
            seen.append(kind)
            # return a marker showing what we received
            return None if s is None else f"K:{'E' if isinstance(kind, DecodeKind) else type(kind).__name__}"

        opts = DecodeOptions(decoder=dec)
        decoder = require_decoder(opts)
        assert decoder("z", Charset.UTF8, kind=DecodeKind.KEY) == "K:E"
        assert seen and isinstance(seen[0], DecodeKind) and seen[0] is DecodeKind.KEY

    def test_three_args_kind_str_annotation(self) -> None:
        seen: t.List[t.Any] = []

        def dec(s: t.Optional[str], charset: t.Optional[Charset], kind: str) -> t.Optional[str]:
            seen.append(kind)
            return None if s is None else kind  # echo back

        opts = DecodeOptions(decoder=dec)
        decoder = require_decoder(opts)
        assert decoder("z", Charset.UTF8, kind=DecodeKind.KEY) == "key"
        assert seen == ["key"]

    def test_kwonly_kind_str(self) -> None:
        seen: t.List[t.Any] = []

        def dec(s: t.Optional[str], charset: t.Optional[Charset], *, kind: str) -> t.Optional[str]:
            seen.append(kind)
            return None if s is None else kind

        opts = DecodeOptions(decoder=dec)
        decoder = require_decoder(opts)
        assert decoder("z", Charset.UTF8, kind=DecodeKind.VALUE) == "value"
        assert seen == ["value"]

    def test_varargs_kwargs_receives_kind_string(self) -> None:
        seen: t.List[t.Any] = []

        def dec(s: t.Optional[str], *args, **kwargs) -> t.Optional[str]:  # type: ignore[no-untyped-def]
            seen.append(kwargs.get("kind"))
            return s

        opts = DecodeOptions(decoder=dec)
        decoder = require_decoder(opts)
        assert decoder("ok", Charset.UTF8, kind=DecodeKind.KEY) == "ok"
        assert seen == ["key"]

    def test_user_decoder_typeerror_is_not_swallowed(self) -> None:
        def dec(s: t.Optional[str]) -> t.Optional[str]:
            raise TypeError("boom")

        opts = DecodeOptions(decoder=dec)
        decoder = require_decoder(opts)
        with pytest.raises(TypeError):
            _ = decoder("oops", Charset.UTF8, kind=DecodeKind.KEY)

    def test_kwonly_charset_receives_keyword_argument(self) -> None:
        calls: t.List[t.Dict[str, t.Any]] = []

        def dec(s: t.Optional[str], *, charset: t.Optional[Charset], kind: str) -> t.Optional[str]:
            calls.append({"charset": charset, "kind": kind})
            return s

        opts = DecodeOptions(decoder=dec)
        decoder = require_decoder(opts)
        assert decoder("x", Charset.LATIN1, kind=DecodeKind.KEY) == "x"
        assert calls == [{"charset": Charset.LATIN1, "kind": "key"}]

    def test_positional_only_kind_receives_string(self) -> None:
        seen: t.List[t.Any] = []

        def dec(
            s: t.Optional[str],
            kind,  # type: ignore[no-untyped-def]
            /,
            *,
            charset: t.Optional[Charset] = None,
        ) -> t.Optional[str]:
            seen.append((kind, charset))
            return s

        opts = DecodeOptions(decoder=dec)
        decoder = require_decoder(opts)
        assert decoder("value", Charset.UTF8, kind=DecodeKind.VALUE) == "value"
        assert seen == [("value", Charset.UTF8)]

    def test_unannotated_kind_parameter_receives_string(self) -> None:
        seen: t.List[t.Any] = []

        def dec(s: t.Optional[str], charset: t.Optional[Charset], kind) -> t.Optional[str]:  # type: ignore[no-untyped-def]
            seen.append(kind)
            return s

        opts = DecodeOptions(decoder=dec)
        decoder = require_decoder(opts)
        assert decoder("q", Charset.UTF8, kind=DecodeKind.KEY) == "q"
        assert seen == ["key"]

    def test_literal_kind_annotation_prefers_string(self) -> None:
        seen: t.List[t.Any] = []

        def dec(
            s: t.Optional[str],
            charset: t.Optional[Charset],
            kind: t.Literal["key", "value"],
        ) -> t.Optional[str]:
            seen.append(kind)
            return s

        opts = DecodeOptions(decoder=dec)
        decoder = require_decoder(opts)
        assert decoder("ok", Charset.UTF8, kind=DecodeKind.VALUE) == "ok"
        assert seen == ["value"]

    def test_builtin_signature_unavailable_single_arg_fallback(self) -> None:
        class BadSignature:
            __signature__ = "nope"

            def __call__(self, s: t.Optional[str]) -> t.Optional[str]:
                return None if s is None else f"{s}-ok"

        opts = DecodeOptions(decoder=BadSignature())
        decoder = require_decoder(opts)
        assert decoder("x", Charset.UTF8, kind=DecodeKind.KEY) == "x-ok"

    def test_builtin_signature_unavailable_two_arg_fallback(self) -> None:
        class BadSignature:
            __signature__ = "nope"

            def __call__(self, s: t.Optional[str], charset: t.Optional[Charset]) -> t.Optional[str]:
                return None if s is None else f"{s}|{charset.name if charset else 'NONE'}"

        opts = DecodeOptions(decoder=BadSignature())
        decoder = require_decoder(opts)
        assert decoder("x", Charset.UTF8, kind=DecodeKind.VALUE) == "x|UTF8"

    def test_builtin_signature_unavailable_raises_original_typeerror(self) -> None:
        class BadSignature:
            __signature__ = "nope"

            def __call__(self) -> t.Optional[str]:
                return "nope"

        opts = DecodeOptions(decoder=BadSignature())
        decoder = require_decoder(opts)
        with pytest.raises(TypeError) as exc_info:
            _ = decoder("x", Charset.UTF8, kind=DecodeKind.KEY)
        assert exc_info.value.__cause__ is not None

    def test_builtin_without_signature_raises_original_typeerror(self) -> None:
        opts = DecodeOptions(decoder=math.hypot)  # type: ignore[arg-type]

        with pytest.raises(TypeError):
            _ = opts.decode_value("10")


class TestDecodeOptionsFallbacks:
    def test_legacy_decoder_selected_when_decoder_none(self) -> None:
        calls: t.List[t.Tuple[t.Optional[str], t.Optional[Charset]]] = []

        def legacy(value: t.Optional[str], charset: t.Optional[Charset]) -> t.Optional[str]:
            calls.append((value, charset))
            return "LEGACY" if value else None

        opts = DecodeOptions(decoder=None, legacy_decoder=legacy)
        assert opts.decode_value("foo", Charset.LATIN1) == "LEGACY"
        assert calls == [("foo", Charset.LATIN1)]

    def test_default_decoder_selected_when_all_none(self) -> None:
        opts = DecodeOptions(decoder=None, legacy_decoder=None)
        assert opts.decode_key("a%2Eb") == "a.b"

    def test_decode_method_falls_back_when_decoder_missing(self) -> None:
        opts = DecodeOptions()
        opts.decoder = None
        assert opts.decode_value("a%20b") == "a b"


class TestParserStateIsolation:
    def test_parse_lists_toggle_does_not_leak_across_calls(self) -> None:
        # Construct a query with many top-level params to trigger the internal optimization
        big_query = "&".join(f"k{i}=v{i}" for i in range(25))
        opts = DecodeOptions(list_limit=20)

        # First call may temporarily disable parse_lists internally
        from qs_codec import decode

        res1 = decode(big_query, opts)
        assert isinstance(res1, dict) and len(res1) == 25
        # The option should be restored on the options object
        assert opts.parse_lists is True

        # Second call should still parse lists as lists
        res2 = decode("a[]=1&a[]=2", opts)
        assert res2 == {"a": ["1", "2"]}


class TestAllowDotsDecodeDotInKeysInterplay:
    def test_constructor_invalid_combination_throws(self) -> None:
        import pytest

        with pytest.raises((ValueError, AssertionError, TypeError)):
            DecodeOptions(decode_dot_in_keys=True, allow_dots=False)


class TestDefaultDecodeKeyEncodedDots:
    def test_key_maps_2e_inside_brackets_allowdots_true(self) -> None:
        for cs in (Charset.UTF8, Charset.LATIN1):
            opts = DecodeOptions(allow_dots=True, charset=cs)
            decoder = require_decoder(opts)
            assert decoder("a[%2E]", cs, kind=DecodeKind.KEY) == "a[.]"
            assert decoder("a[%2e]", cs, kind=DecodeKind.KEY) == "a[.]"

    def test_key_maps_2e_outside_brackets_allowdots_true_independent_of_decodeopt(self) -> None:
        for cs in (Charset.UTF8, Charset.LATIN1):
            opts1 = DecodeOptions(allow_dots=True, decode_dot_in_keys=False, charset=cs)
            opts2 = DecodeOptions(allow_dots=True, decode_dot_in_keys=True, charset=cs)
            decoder1 = require_decoder(opts1)
            decoder2 = require_decoder(opts2)
            assert decoder1("a%2Eb", cs, kind=DecodeKind.KEY) == "a.b"
            assert decoder2("a%2Eb", cs, kind=DecodeKind.KEY) == "a.b"

    def test_non_key_decodes_2e_to_dot_control(self) -> None:
        for cs in (Charset.UTF8, Charset.LATIN1):
            opts = DecodeOptions(allow_dots=True, charset=cs)
            decoder = require_decoder(opts)
            assert decoder("a%2Eb", cs, kind=DecodeKind.VALUE) == "a.b"

    def test_key_maps_2e_inside_brackets_allowdots_false(self) -> None:
        for cs in (Charset.UTF8, Charset.LATIN1):
            opts = DecodeOptions(allow_dots=False, charset=cs)
            decoder = require_decoder(opts)
            assert decoder("a[%2E]", cs, kind=DecodeKind.KEY) == "a[.]"
            assert decoder("a[%2e]", cs, kind=DecodeKind.KEY) == "a[.]"

    def test_key_outside_2e_decodes_to_dot_allowdots_false(self) -> None:
        for cs in (Charset.UTF8, Charset.LATIN1):
            opts = DecodeOptions(allow_dots=False, charset=cs)
            decoder = require_decoder(opts)
            assert decoder("a%2Eb", cs, kind=DecodeKind.KEY) == "a.b"
            assert decoder("a%2eb", cs, kind=DecodeKind.KEY) == "a.b"


class TestCustomDecoderBehavior:
    def test_decode_key_decodes_percent_sequences_like_values_when_decode_dot_in_keys_false(self) -> None:
        opts = DecodeOptions(allow_dots=True, decode_dot_in_keys=False)
        decoder = require_decoder(opts)
        assert decoder("a%2Eb", Charset.UTF8, kind=DecodeKind.KEY) == "a.b"
        assert decoder("a%2eb", Charset.UTF8, kind=DecodeKind.KEY) == "a.b"

    def test_decode_value_decodes_percent_sequences_normally(self) -> None:
        opts = DecodeOptions()
        decoder = require_decoder(opts)
        assert decoder("%2E", Charset.UTF8, kind=DecodeKind.VALUE) == "."

    def test_decoder_is_used_for_key_and_value(self) -> None:
        calls: t.List[t.Tuple[t.Optional[str], DecodeKind]] = []

        def dec(s: t.Optional[str], charset: t.Optional[Charset], kind: DecodeKind) -> t.Optional[str]:  # type: ignore[override]
            calls.append((s, kind))
            return s

        opts = DecodeOptions(decoder=dec)
        decoder = require_decoder(opts)
        assert decoder("x", Charset.UTF8, kind=DecodeKind.KEY) == "x"
        assert decoder("y", Charset.UTF8, kind=DecodeKind.VALUE) == "y"

        assert len(calls) == 2
        assert calls[0][1] is DecodeKind.KEY and calls[0][0] == "x"
        assert calls[1][1] is DecodeKind.VALUE and calls[1][0] == "y"

    def test_decoder_null_return_is_honored(self) -> None:
        def dec(s: t.Optional[str], charset: t.Optional[Charset], kind: DecodeKind) -> t.Optional[str]:  # type: ignore[override]
            return None

        opts = DecodeOptions(decoder=dec)
        decoder = require_decoder(opts)
        assert decoder("foo", Charset.UTF8, kind=DecodeKind.VALUE) is None
        assert decoder("bar", Charset.UTF8, kind=DecodeKind.KEY) is None

    def test_single_decoder_acts_like_legacy_when_ignoring_kind(self) -> None:
        def dec(s: t.Optional[str], *args, **kwargs):  # type: ignore[no-untyped-def]
            return None if s is None else s.upper()

        opts = DecodeOptions(decoder=dec)
        decoder = require_decoder(opts)
        assert decoder("abc", Charset.UTF8, kind=DecodeKind.VALUE) == "ABC"
        # For keys, custom decoder gets the raw token; no default percent-decoding happens first.
        assert decoder("a%2Eb", Charset.UTF8, kind=DecodeKind.KEY) == "A%2EB"

    def test_decoder_wins_over_legacy_decoder_when_both_provided(self) -> None:
        # decoder must take precedence over legacy_decoder (parity with Kotlin/C#)
        def legacy(v: t.Optional[str], charset: t.Optional[Charset] = None) -> t.Optional[str]:
            return f"L:{'null' if v is None else v}"

        def dec(
            v: t.Optional[str],
            charset: t.Optional[Charset] = None,
            *,
            kind: DecodeKind = DecodeKind.VALUE,
        ) -> t.Optional[str]:
            return f"K:{kind.name}:{'null' if v is None else v}"

        opts = DecodeOptions(decoder=dec, legacy_decoder=legacy)
        assert opts.decode_key("x") == "K:KEY:x"
        assert opts.decode_value("y") == "K:VALUE:y"

    def test_decode_key_coerces_non_string_decoder_result(self) -> None:
        # When the decoder returns a non-string scalar, decode_key coerces it via str()
        def dec(
            v: t.Optional[str],
            charset: t.Optional[Charset] = None,
            *,
            kind: DecodeKind = DecodeKind.VALUE,
        ) -> t.Any:
            return 42 if v is not None else None

        opts = DecodeOptions(decoder=dec)
        assert opts.decode_key("anything") == "42"


DecoderCallable = t.Callable[..., t.Optional[t.Any]]


def require_decoder(opts: DecodeOptions) -> DecoderCallable:
    assert opts.decoder is not None
    return opts.decoder
