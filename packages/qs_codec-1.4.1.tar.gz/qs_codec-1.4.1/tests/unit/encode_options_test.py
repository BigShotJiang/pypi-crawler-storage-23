import pytest

from qs_codec import EncodeOptions
from qs_codec.utils.encode_utils import EncodeUtils


class TestEncodeOptions:
    def test_post_init_restores_default_encoder(self) -> None:
        opts = EncodeOptions()
        left = getattr(opts._encoder, "__func__", None)
        right = getattr(EncodeUtils.encode, "__func__", None)
        assert left is not None and right is not None
        assert left is right

    def test_post_init_recovers_when_encoder_missing(self) -> None:
        opts = EncodeOptions()
        delattr(opts, "_encoder")
        EncodeOptions.__post_init__(opts)
        left = getattr(opts._encoder, "__func__", None)
        right = getattr(EncodeUtils.encode, "__func__", None)
        assert left is not None and right is not None
        assert left is right

    def test_equality_with_other_type_returns_false(self) -> None:
        opts = EncodeOptions()
        assert opts != object()

    def test_equality_detects_field_difference(self) -> None:
        lhs = EncodeOptions()
        rhs = EncodeOptions(allow_dots=True)
        assert lhs != rhs

    def test_max_depth_must_be_positive(self) -> None:
        for value in (0, -1, True, 1.5):
            with pytest.raises(ValueError, match="max_depth must be a positive integer or None"):
                EncodeOptions(max_depth=value)  # type: ignore[arg-type]

        assert EncodeOptions(max_depth=5).max_depth == 5
