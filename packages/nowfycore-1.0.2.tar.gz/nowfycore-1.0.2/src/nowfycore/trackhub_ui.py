def render_track_hub_box_cell(plugin, cell, title_text, subtitle_text, cover_url=""):
    try:
        mod = None
        try:
            import nowfy as nowfy_mod

            mod = nowfy_mod
        except Exception:
            mod = None
        if mod is None:
            return False
        AndroidUtilities = getattr(mod, "AndroidUtilities", None)
        Theme = getattr(mod, "Theme", None)
        LinearLayout = getattr(mod, "LinearLayout", None)
        TextView = getattr(mod, "TextView", None)
        ImageView = getattr(mod, "ImageView", None)
        FrameLayout = getattr(mod, "FrameLayout", None)
        GradientDrawable = getattr(mod, "GradientDrawable", None)
        Gravity = getattr(mod, "Gravity", None)
        TypedValue = getattr(mod, "TypedValue", None)
        View = getattr(mod, "View", None)
        run_on_ui_thread = getattr(mod, "run_on_ui_thread", None)
        run_on_queue = getattr(mod, "run_on_queue", None)
        BitmapFactory = getattr(mod, "BitmapFactory", None)
        if not all((AndroidUtilities, LinearLayout, TextView, ImageView, FrameLayout, GradientDrawable, Gravity, TypedValue)):
            return False

        side = AndroidUtilities.dp(50)
        try:
            card = cell.findViewWithTag("nowfy_track_hub_card")
        except Exception:
            card = None
        if card is None:
            try:
                card = LinearLayout(cell.getContext())
                card.setTag("nowfy_track_hub_card")
                card.setOrientation(LinearLayout.HORIZONTAL)
                card.setGravity(Gravity.CENTER_VERTICAL)
                card.setPadding(AndroidUtilities.dp(14), AndroidUtilities.dp(10), AndroidUtilities.dp(14), AndroidUtilities.dp(10))
                bg = GradientDrawable()
                bg.setCornerRadius(float(AndroidUtilities.dp(14)))
                try:
                    if Theme is not None:
                        bg.setColor(Theme.getColor(Theme.key_windowBackgroundWhite))
                    else:
                        bg.setColor(0x00000000)
                except Exception:
                    pass
                card.setBackground(bg)

                cover = ImageView(cell.getContext())
                cover.setTag("nowfy_track_hub_card_cover")
                cover.setScaleType(ImageView.ScaleType.CENTER_CROP)
                lp_cover = LinearLayout.LayoutParams(side, side)
                lp_cover.rightMargin = AndroidUtilities.dp(10)
                card.addView(cover, lp_cover)

                text_wrap = LinearLayout(cell.getContext())
                text_wrap.setTag("nowfy_track_hub_card_text_wrap")
                text_wrap.setOrientation(LinearLayout.VERTICAL)
                text_wrap.setGravity(Gravity.CENTER_VERTICAL)
                lp_text = LinearLayout.LayoutParams(0, -2, 1.0)
                card.addView(text_wrap, lp_text)

                title = TextView(cell.getContext())
                title.setTag("nowfy_track_hub_card_title")
                title.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 15)
                try:
                    if Theme is not None:
                        title.setTextColor(Theme.getColor(Theme.key_windowBackgroundWhiteBlackText))
                except Exception:
                    pass
                text_wrap.addView(title, LinearLayout.LayoutParams(-1, -2))

                sub = TextView(cell.getContext())
                sub.setTag("nowfy_track_hub_card_sub")
                sub.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 13)
                try:
                    if Theme is not None:
                        sub.setTextColor(Theme.getColor(Theme.key_windowBackgroundWhiteGrayText2))
                except Exception:
                    pass
                lp_sub = LinearLayout.LayoutParams(-1, -2)
                lp_sub.topMargin = AndroidUtilities.dp(2)
                text_wrap.addView(sub, lp_sub)

                lp = FrameLayout.LayoutParams(-1, -2)
                lp.gravity = Gravity.CENTER_VERTICAL
                lp.leftMargin = AndroidUtilities.dp(12)
                lp.rightMargin = AndroidUtilities.dp(12)
                cell.addView(card, lp)
            except Exception:
                return False

        t = card.findViewWithTag("nowfy_track_hub_card_title")
        s = card.findViewWithTag("nowfy_track_hub_card_sub")
        c = card.findViewWithTag("nowfy_track_hub_card_cover")
        try:
            if t:
                t.setText(str(title_text or ""))
            if s:
                s.setText(str(subtitle_text or ""))
            if c:
                c.setImageDrawable(None)
        except Exception:
            pass

        url = str(cover_url or "").strip()
        if c and url.startswith(("http://", "https://")) and BitmapFactory is not None and callable(run_on_queue):
            def _load():
                try:
                    data = None
                    try:
                        if hasattr(plugin, "_get_cached_image_enhanced"):
                            data = plugin._get_cached_image_enhanced(url, cache_key=f"trackhub_box_cover_{hash(url)}")
                    except Exception:
                        data = None
                    if not data:
                        try:
                            import requests

                            rr = requests.get(url, timeout=7)
                            if rr.status_code == 200 and rr.content:
                                data = rr.content
                        except Exception:
                            data = None
                    if not data:
                        return
                    bmp = BitmapFactory.decodeByteArray(data, 0, len(data))
                    if bmp and callable(run_on_ui_thread):
                        run_on_ui_thread(lambda: c.setImageBitmap(bmp))
                except Exception:
                    pass

            run_on_queue(_load)

        try:
            if View is not None:
                cell.textView.setVisibility(View.GONE)
                cell.valueTextView.setVisibility(View.GONE)
        except Exception:
            pass
        return True
    except Exception:
        return False


def clear_track_hub_box_cell(plugin, cell):
    try:
        card = cell.findViewWithTag("nowfy_track_hub_card")
        if card:
            try:
                parent = card.getParent()
                if parent:
                    parent.removeView(card)
            except Exception:
                pass
        return True
    except Exception:
        return False
