def animate_opening_avatar(plugin, avatar_view, from_y_dp=20, duration_ms=620):
    try:
        if avatar_view is None:
            return False
        AndroidUtilities = None
        try:
            from hook_utils import find_class

            AndroidUtilities = find_class("org.telegram.messenger.AndroidUtilities")
        except Exception:
            AndroidUtilities = None
        try:
            if AndroidUtilities is not None:
                avatar_view.setCameraDistance(float(AndroidUtilities.dp(800)))
        except Exception:
            pass
        try:
            if AndroidUtilities is not None:
                avatar_view.setTranslationY(float(AndroidUtilities.dp(int(from_y_dp or 20))))
        except Exception:
            pass
        try:
            avatar_view.setAlpha(0.0)
        except Exception:
            pass
        try:
            avatar_view.setRotationY(-120.0)
        except Exception:
            pass
        try:
            avatar_view.animate().cancel()
        except Exception:
            pass
        try:
            avatar_view.animate().translationY(0.0).alpha(1.0).rotationY(0.0).setDuration(int(duration_ms or 620)).start()
        except Exception:
            pass
        return True
    except Exception:
        return False


def _build_support_project_rich_item(plugin, description_text=None):
    try:
        from org.telegram.messenger import ApplicationLoader
        from org.telegram.ui.Components import UItem
        from android.widget import LinearLayout, TextView
        from android.view import Gravity
        from android.util import TypedValue
        from android.graphics.drawable import GradientDrawable

        Theme = None
        AndroidUtilities = None
        get_last_fragment = None
        tr_fn = None
        try:
            import nowfy as nowfy_mod

            Theme = getattr(nowfy_mod, "Theme", None)
            AndroidUtilities = getattr(nowfy_mod, "AndroidUtilities", None)
            get_last_fragment = getattr(nowfy_mod, "get_last_fragment", None)
            tr_fn = getattr(nowfy_mod, "tr", None)
        except Exception:
            pass

        ctx = None
        try:
            frag = get_last_fragment() if callable(get_last_fragment) else None
            ctx = frag.getParentActivity() if frag and frag.getParentActivity() else ApplicationLoader.applicationContext
        except Exception:
            ctx = ApplicationLoader.applicationContext
        if ctx is None:
            return None

        rich = LinearLayout(ctx)
        rich.setOrientation(LinearLayout.VERTICAL)
        rich.setGravity(Gravity.START)
        try:
            if AndroidUtilities is not None:
                rich.setPadding(AndroidUtilities.dp(14), AndroidUtilities.dp(14), AndroidUtilities.dp(14), AndroidUtilities.dp(14))
        except Exception:
            pass
        try:
            bg = GradientDrawable()
            if AndroidUtilities is not None:
                bg.setCornerRadius(AndroidUtilities.dp(16))
            bg.setColor(0x162B3E5A)
            rich.setBackground(bg)
        except Exception:
            pass

        desc = TextView(ctx)
        txt = str(description_text or "").strip()
        if not txt:
            try:
                txt = str(plugin.tr("about_plugin_description") if hasattr(plugin, "tr") else "")
            except Exception:
                txt = ""
        if not txt:
            try:
                txt = str(tr_fn("about_plugin_description") if callable(tr_fn) else "")
            except Exception:
                txt = ""
        if not txt:
            txt = "Support the project."
        desc.setText(txt)
        desc.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 13)
        desc.setGravity(Gravity.START)
        try:
            if Theme is not None:
                desc.setTextColor(Theme.getColor(Theme.key_windowBackgroundWhiteGrayText))
            else:
                desc.setTextColor(0xFFD2DCEB)
        except Exception:
            pass
        rich.addView(desc)
        return UItem.asCustom(rich)
    except Exception:
        return None


def inject_about_support_rich_header(plugin, activity, items):
    try:
        if activity is None or items is None:
            return False
        desc_txt = ""
        try:
            desc_txt = str(plugin.tr("about_plugin_description") if hasattr(plugin, "tr") else "")
        except Exception:
            desc_txt = ""

        remove_idxs = []
        for i in range(items.size()):
            try:
                it = items.get(i)
                txt = ""
                try:
                    if hasattr(plugin, "_get_uitem_text"):
                        txt = str(plugin._get_uitem_text(it) or "").strip()
                except Exception:
                    txt = ""
                if desc_txt and txt == desc_txt:
                    remove_idxs.append(i)
            except Exception:
                pass
        for i in reversed(remove_idxs):
            try:
                items.remove(i)
            except Exception:
                pass

        rich_item = _build_support_project_rich_item(plugin, desc_txt)
        if rich_item is not None:
            try:
                rich_item.object2 = "__about_support_rich__"
            except Exception:
                pass
            try:
                items.add(0, rich_item)
            except Exception:
                items.add(rich_item)
            return True
        return False
    except Exception:
        return False
