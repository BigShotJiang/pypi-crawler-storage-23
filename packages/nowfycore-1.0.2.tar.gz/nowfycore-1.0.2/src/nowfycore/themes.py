def _tr(plugin, key, fallback):
    try:
        fn = getattr(plugin, "tr", None)
        if callable(fn):
            v = str(fn(key) or "").strip()
            if v and v != key:
                return v
    except Exception:
        pass
    return fallback


def inject_core_theme_multiselect(plugin, activity, items):
    try:
        from org.telegram.ui.Components import UItem
        from android_utils import OnClickListener

        insert_idx = -1
        remove_indices = []
        for i in range(items.size()):
            try:
                it = items.get(i)
                key = plugin._get_uitem_setting_key(it)
                if key == "core_theme_multiselect_marker":
                    insert_idx = i
                    remove_indices.append(i)
                k2 = str(getattr(it, "object2", "") or "")
                if k2 == "__core_themes_parent__" or k2.startswith("coretheme_"):
                    remove_indices.append(i)
            except Exception:
                pass
        for idx in reversed(sorted(list(set(remove_indices)))):
            try:
                items.remove(idx)
            except Exception:
                pass
        if insert_idx < 0:
            return False

        mapping = [("spotlight", "Spotlight"), ("nowv", "Nowv")]
        enabled = set(plugin._get_core_enabled_optional_themes())
        total_on = len([k for k, _ in mapping if k in enabled])
        expanded = bool(getattr(plugin, "_core_theme_expand_expanded", False))

        parent = UItem.asExteraExpandableSwitch(
            hash("nowfy_core_theme_expand") & 0x7FFFFFFF,
            _tr(plugin, "theming_expand", "Optional Themes"),
            f"{total_on}/{len(mapping)}",
            OnClickListener(lambda v: None),
        )
        parent.setChecked(total_on > 0)
        parent.setCollapsed(not expanded)
        parent.object2 = "__core_themes_parent__"
        items.add(insert_idx, parent)

        if expanded:
            for idx, (k, label) in enumerate(mapping, start=1):
                chk = UItem.asRoundCheckbox(hash(f"coretheme_{k}") & 0x7FFFFFFF, label)
                chk.setChecked(k in enabled)
                chk.pad()
                chk.object2 = f"coretheme_{k}"
                items.add(insert_idx + idx, chk)
        return True
    except Exception:
        return False
