"""Otto — AI agent platform."""

__version__ = "0.8.0"
