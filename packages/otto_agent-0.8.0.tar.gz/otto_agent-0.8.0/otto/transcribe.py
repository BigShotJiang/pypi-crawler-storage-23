"""Voice transcription using faster-whisper (optional dependency)."""

import asyncio

_models: dict = {}


def _sync_transcribe(path: str, model_size: str) -> str:
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        raise ImportError(
            "Voice transcription requires faster-whisper. "
            "Install with: pip install 'otto-agent[voice]'"
        )

    if model_size not in _models:
        _models[model_size] = WhisperModel(model_size, device="cpu", compute_type="int8")

    segments, _ = _models[model_size].transcribe(path)
    return " ".join(seg.text.strip() for seg in segments).strip()


async def transcribe(path: str, *, model_size: str = "base") -> str:
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, _sync_transcribe, path, model_size)
