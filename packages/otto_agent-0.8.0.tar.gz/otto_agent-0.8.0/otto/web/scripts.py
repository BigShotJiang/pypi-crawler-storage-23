"""JavaScript for dashboard and setup wizard."""

from __future__ import annotations

DASHBOARD_JS = """
<script>
(function () {
    'use strict';

    window.doAction = function (endpoint) {
        fetch(endpoint, { method: 'POST' }).then(function () {
            window.location.reload();
        });
    };

    /* ── Element refs ─────────────────────────────────────────── */
    var summaryEl    = document.getElementById('orch-summary');
    var subagentsEl  = document.getElementById('orch-subagents');
    var jobsEl       = document.getElementById('orch-jobs');
    var eventsEl     = document.getElementById('orch-events');
    var evCountEl    = document.getElementById('orch-events-count');
    var evPagEl      = document.getElementById('orch-events-pagination');
    var evInfoEl     = document.getElementById('orch-events-info');
    var evPrevEl     = document.getElementById('orch-events-prev');
    var evNextEl     = document.getElementById('orch-events-next');

    var jobLogPanelEl = document.getElementById('orch-job-log');
    var jobLogTitleEl = document.getElementById('orch-job-log-title');
    var jobLogJobIdEl = document.getElementById('orch-job-log-id');
    var jobLogMetaEl = document.getElementById('orch-job-log-meta');
    var jobLogErrorEl = document.getElementById('orch-job-log-error');
    var jobLogFeedbackEl = document.getElementById('orch-job-log-feedback');
    var jobLogTextEl = document.getElementById('orch-job-log-text');
    var jobLogCloseEl = document.getElementById('orch-job-log-close');
    var jobLogRefreshEl = document.getElementById('orch-job-log-refresh');
    var jobLogAutoTailEl = document.getElementById('orch-job-log-autotail');

    if (!summaryEl || !jobsEl || !eventsEl) return;

    /* ── State ────────────────────────────────────────────────── */
    var eventsState = { cursor: null, next: null, prev: null };
    var agentFilter = null; /* null = all */
    var selectedJobId = null;
    var jobLogAutoTail = true;

    /* ── Helpers ──────────────────────────────────────────────── */
    function esc(v) {
        var d = document.createElement('div');
        d.textContent = String(v == null ? '' : v);
        return d.innerHTML;
    }

    function timeAgo(isoOrEpoch) {
        var ts;
        if (typeof isoOrEpoch === 'number') {
            ts = isoOrEpoch * 1000;
        } else {
            ts = new Date(String(isoOrEpoch || '')).getTime();
        }
        if (!ts || isNaN(ts)) return '—';
        var diff = Math.max(0, Math.floor((Date.now() - ts) / 1000));
        if (diff < 60)   return diff + 's ago';
        if (diff < 3600) return Math.floor(diff / 60) + 'm ago';
        if (diff < 86400) return Math.floor(diff / 3600) + 'h ago';
        return Math.floor(diff / 86400) + 'd ago';
    }

    function shortTime(isoOrEpoch) {
        var ts;
        if (typeof isoOrEpoch === 'number') {
            ts = new Date(isoOrEpoch * 1000);
        } else {
            ts = new Date(String(isoOrEpoch || ''));
        }
        if (!ts.getTime() || isNaN(ts.getTime())) return '';
        var h = ts.getHours(), m = ts.getMinutes();
        return (h < 10 ? '0' : '') + h + ':' + (m < 10 ? '0' : '') + m;
    }

    function trimText(v, maxLen) {
        var text = String(v == null ? '' : v);
        if (text.length <= maxLen) return text;
        return text.slice(0, Math.max(0, maxLen - 1)) + '…';
    }

    function statusClass(s) {
        s = String(s || '').toLowerCase();
        if (s === 'in_progress' || s === 'delivered') return 'running';
        if (s === 'reworking') return 'reworking';
        if (s === 'ready') return 'ready';
        if (s === 'failed') return 'failed';
        return 'done';
    }

    function statusLabel(s) {
        s = String(s || '').toLowerCase();
        if (s === 'in_progress') return 'running';
        if (s === 'delivered') return 'running';
        if (s === 'reworking') return 'reworking';
        return s || 'unknown';
    }

    function dotClass(eventType) {
        var t = String(eventType || '').toLowerCase();
        if (t.indexOf('rework') >= 0) return 'dot-reworking';
        if (t.indexOf('fail') >= 0 || t.indexOf('error') >= 0) return 'dot-failed';
        if (t.indexOf('start') >= 0 || t.indexOf('progress') >= 0 || t.indexOf('pick') >= 0)
            return 'dot-active';
        if (t.indexOf('done') >= 0 || t.indexOf('complete') >= 0) return 'dot-done';
        return '';
    }

    function eventSentence(ev) {
        var parts = [];
        var job = ev.job_id || ev.task_id || '';
        var event = ev.event || ev.type || 'event';
        var status = ev.status || '';
        var assignee = ev.assignee || ev.subagent || '';

        parts.push('<strong>' + esc(event) + '</strong>');
        if (job) parts.push('<span class="ev-job">' + esc(job) + '</span>');
        if (assignee) parts.push('→ ' + esc(assignee));
        if (status && status !== event) parts.push('(' + esc(status) + ')');

        return parts.join(' ');
    }

    /* ── Render: Summary Strip ────────────────────────────────── */
    function renderSummary(payload) {
        var s = payload.summary || {};
        var stats = [
            { count: s.running || 0, label: 'active', cls: 'running' },
            { count: s.reworking || 0, label: 'reworking', cls: 'reworking' },
            { count: s.ready || 0, label: 'queued', cls: 'ready' },
            { count: s.failed || 0, label: 'failed', cls: 'failed' },
            { count: s.done_recent || 0, label: 'done', cls: 'done' },
        ];

        var html = '';
        for (var i = 0; i < stats.length; i++) {
            if (i > 0) html += '<span class="orch-summary-sep"></span>';
            var st = stats[i];
            html += '<span class="orch-summary-stat" style="color: var(--status-' + st.cls + ');">'
                  + '<span class="stat-count">' + esc(st.count) + '</span>'
                  + '<span class="stat-label">' + esc(st.label) + '</span>'
                  + '</span>';
        }
        html += '<span class="orch-summary-updated">' + timeAgo(payload.updated_at) + '</span>';
        summaryEl.innerHTML = html;

        /* Subagent pills */
        var agents = payload.subagents || [];
        var pillsHtml = '<button class="orch-agent-pill' + (agentFilter === null ? ' active' : '')
                       + '" data-agent="">'
                       + '<span class="pill-dot" style="background:var(--text-muted)"></span>'
                       + 'All'
                       + '</button>';
        for (var j = 0; j < agents.length; j++) {
            var a = agents[j];
            var isActive = agentFilter === a.name;
            var running = a.running || 0;
            var pillColor = running > 0 ? 'var(--status-running)'
                          : (a.failed || 0) > 0 ? 'var(--status-failed)'
                          : 'var(--text-muted)';
            pillsHtml += '<button class="orch-agent-pill' + (isActive ? ' active' : '')
                       + '" data-agent="' + esc(a.name) + '">'
                       + '<span class="pill-dot" style="background:' + pillColor + '"></span>'
                       + esc(a.name);
            if (running > 0) {
                pillsHtml += ' <span class="orch-agent-count">' + running + '</span>';
            }
            pillsHtml += '</button>';
        }
        subagentsEl.innerHTML = pillsHtml;

        /* Bind pill clicks */
        subagentsEl.querySelectorAll('.orch-agent-pill').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var val = btn.getAttribute('data-agent');
                agentFilter = val || null;
                subagentsEl.querySelectorAll('.orch-agent-pill').forEach(function (b) {
                    b.classList.remove('active');
                });
                btn.classList.add('active');
                loadJobs();
            });
        });
    }

    /* ── Render: Grouped Jobs ─────────────────────────────────── */
    function renderJobs(payload) {
        var rows = payload.rows || [];

        /* Split into groups */
        var active = [], failed = [], done = [];
        for (var i = 0; i < rows.length; i++) {
            var r = rows[i];
            var sc = statusClass(r.status);
            if (sc === 'running' || sc === 'ready' || sc === 'reworking') active.push(r);
            else if (sc === 'failed') failed.push(r);
            else done.push(r);
        }

        if (rows.length === 0) {
            jobsEl.innerHTML = '<div class="orch-section"><div class="orch-jobs-empty">'
                             + 'No jobs to display.</div></div>';
            return;
        }

        var html = '';
        html += renderJobGroup('Active', active, false);
        html += renderJobGroup('Failed', failed, false);
        html += renderJobGroup('Completed', done, done.length > 5);

        /* Pagination at the bottom if applicable */
        var paginationHtml = '';
        if (payload.total > (payload.rows || []).length
            || payload.prev_cursor != null || payload.next_cursor != null) {
            paginationHtml = '<div class="orch-pagination">'
                + '<span>' + rows.length + ' of ' + (payload.total || rows.length) + '</span>'
                + '<div class="orch-pagination-btns">'
                + '<button class="btn btn-sm" id="orch-jobs-prev"'
                + (payload.prev_cursor == null ? ' disabled' : '') + '>← Prev</button>'
                + '<button class="btn btn-sm" id="orch-jobs-next"'
                + (payload.next_cursor == null ? ' disabled' : '') + '>Next →</button>'
                + '</div></div>';
        }
        html += paginationHtml;
        jobsEl.innerHTML = html;

        /* Wire section toggles */
        jobsEl.querySelectorAll('.orch-section-header').forEach(function (hdr) {
            hdr.addEventListener('click', function () {
                hdr.parentElement.classList.toggle('collapsed');
            });
        });

        /* Wire job row clicks */
        jobsEl.querySelectorAll('.orch-job-row[data-job-id]').forEach(function (row) {
            row.addEventListener('click', function () {
                var jobId = row.getAttribute('data-job-id');
                openJobLog(jobId);
            });
        });

        /* Wire pagination */
        var prevBtn = document.getElementById('orch-jobs-prev');
        var nextBtn = document.getElementById('orch-jobs-next');
        if (prevBtn) prevBtn.addEventListener('click', function () {
            if (payload.prev_cursor != null) { jobsCursor = payload.prev_cursor; loadJobs(); }
        });
        if (nextBtn) nextBtn.addEventListener('click', function () {
            if (payload.next_cursor != null) { jobsCursor = payload.next_cursor; loadJobs(); }
        });
    }

    function renderJobGroup(title, items, collapsed) {
        if (items.length === 0) return '';
        var cls = collapsed ? ' collapsed' : '';
        var html = '<div class="orch-section' + cls + '">'
            + '<div class="orch-section-header">'
            + '<span class="orch-section-title">' + esc(title)
            + ' <span class="section-count">' + items.length + '</span></span>'
            + '<span class="orch-section-chevron">▾</span>'
            + '</div>'
            + '<div class="orch-section-body">';

        for (var i = 0; i < items.length; i++) {
            html += renderJobRow(items[i]);
        }

        html += '</div></div>';
        return html;
    }

    function renderJobRow(row) {
        var sc = statusClass(row.status);
        var indent = (row.depth || 0) * 20;
        var title = row.title || row.description || row.id || '—';
        var assignee = row.assignee || 'main';
        var jobId = row.id || '';

        var html = '<div class="orch-job-row" data-job-id="' + esc(jobId) + '" style="padding-left:'
            + (20 + indent) + 'px">'
            + '<div class="orch-job-status">'
            + '<span class="status-pill status-pill--' + sc + '">'
            + '<span class="pill-dot"></span>' + esc(statusLabel(row.status))
            + '</span></div>'
            + '<div class="orch-job-body">'
            + '<div class="orch-job-title">' + esc(title)
            + '<span class="job-id">' + esc(jobId) + '</span>'
            + '<span class="orch-job-log-open" title="Open live log">↗</span>'
            + '</div>'
            + '<div class="orch-job-meta">';

        html += '<span>' + esc(assignee) + '</span>';
        if (row.attempts != null && row.attempts > 0) {
            var attemptText = 'attempt ' + row.attempts;
            if (row.maxAttempts) attemptText += '/' + row.maxAttempts;
            html += '<span>' + esc(attemptText) + '</span>';
        }
        if (row.children && row.children.length) {
            html += '<span>' + row.children.length + ' children</span>';
        }
        if (row.updatedAt) {
            html += '<span>' + timeAgo(row.updatedAt) + '</span>';
        }

        html += '</div>';

        if (row.error) {
            html += '<div class="orch-job-error">⚠ '
                  + esc(String(row.error).slice(0, 200)) + '</div>';
        }

        html += '</div></div>';
        return html;
    }

    function closeJobLog() {
        selectedJobId = null;
        if (jobLogPanelEl) {
            jobLogPanelEl.hidden = true;
        }
    }

    function renderJobLog(payload) {
        if (!jobLogPanelEl) return;
        var job = payload.job || {};
        if (jobLogTitleEl) {
            jobLogTitleEl.textContent = job.title || 'Orchestration Job';
        }
        if (jobLogJobIdEl) {
            jobLogJobIdEl.textContent = job.id || '';
        }
        if (jobLogMetaEl) {
            var meta = '';
            if (job.assignee) meta += 'Assignee: ' + job.assignee;
            if (job.status) meta += (meta ? ' · ' : '') + 'Status: ' + String(job.status);
            if (job.attempts != null) {
                meta += (meta ? ' · ' : '') + 'Attempt: ' + String(job.attempts);
                if (job.maxAttempts) meta += '/' + job.maxAttempts;
            }
            if (job.updatedAt) meta += (meta ? ' · ' : '') + 'Updated: ' + timeAgo(job.updatedAt);
            if (jobLogMetaEl) jobLogMetaEl.textContent = meta;
        }
        if (jobLogErrorEl) {
            var errText = job.error || '';
            if (!errText && String(job.status || '').toLowerCase() === 'failed') {
                errText = 'No failure details were captured for this failure.';
            }
            jobLogErrorEl.textContent = errText ? ('Why: ' + String(errText)) : '';
            if (errText) {
                jobLogErrorEl.style.display = 'block';
            } else {
                jobLogErrorEl.style.display = 'none';
            }
        }
        if (jobLogFeedbackEl) {
            var fbText = job.feedback || '';
            jobLogFeedbackEl.textContent = fbText ? ('Feedback: ' + String(fbText)) : '';
            if (fbText) {
                jobLogFeedbackEl.style.display = 'block';
            } else {
                jobLogFeedbackEl.style.display = 'none';
            }
        }

        var lines = payload.lines || [];
        if (jobLogTextEl) {
            if (!lines.length) {
                jobLogTextEl.textContent = 'No live session logs yet.';
            } else {
                var text = '';
                for (var i = 0; i < lines.length; i++) {
                    var line = lines[i];
                    var ts = shortTime(line.ts || line.timestamp || '');
                    var src = line.source || 'log';
                    var evt = line.event || line.message || 'log';
                    var msg = line.messageText || line.text || '';
                    text += ('[' + ts + '] ' + src + '/' + evt + ': ' + trimText(msg, 320)) + '\\n';
                }
                jobLogTextEl.textContent = text.trim();
                jobLogTextEl.scrollTop = jobLogTextEl.scrollHeight;
            }
        }

        jobLogPanelEl.hidden = false;
    }

    function openJobLog(jobId) {
        if (!jobId) return;
        selectedJobId = jobId;
        loadJobLog();
    }

    async function loadJobLog() {
        if (!selectedJobId || !jobLogPanelEl) return;
        try {
            var q = new URLSearchParams();
            q.set('limit', '300');
            var url = '/orchestration/jobs/' + encodeURIComponent(selectedJobId) + '/session?'
                    + q.toString();
            var res = await fetch(url);
            if (!res.ok) {
                if (jobLogTextEl) {
                    jobLogTextEl.textContent = 'Failed to load session logs.';
                }
                return;
            }
            renderJobLog(await res.json());
        } catch (e) {
            if (jobLogTextEl) {
                jobLogTextEl.textContent = 'Failed to load session logs.';
            }
        }
    }

    /* ── Render: Events Timeline ──────────────────────────────── */
    function renderEvents(payload) {
        eventsState.next = payload.next_cursor;
        eventsState.prev = payload.prev_cursor;

        var events = payload.events || [];

        if (evCountEl) {
            evCountEl.textContent = events.length + ' of ' + (payload.total || events.length);
        }

        if (events.length === 0) {
            eventsEl.innerHTML = '<div class="orch-jobs-empty">No events recorded.</div>';
        } else {
            /* Show newest first */
            var reversed = events.slice().reverse();
            var html = '';
            for (var i = 0; i < reversed.length; i++) {
                var ev = reversed[i];
                var dc = dotClass(ev.event || ev.type || '');
                var ts = ev.ts || ev.timestamp || '';

                html += '<div class="orch-event">'
                    + '<div class="orch-event-time">' + esc(shortTime(ts)) + '</div>'
                    + '<div class="orch-event-dot-col">'
                    + '<div class="orch-event-dot ' + dc + '"></div>'
                    + '</div>'
                    + '<div class="orch-event-text">' + eventSentence(ev) + '</div>'
                    + '</div>';
            }
            eventsEl.innerHTML = html;
        }

        /* Pagination */
        var showPag = payload.prev_cursor != null || payload.next_cursor != null;
        evPagEl.style.display = showPag ? 'flex' : 'none';
        if (evInfoEl) {
            evInfoEl.textContent = events.length + ' events';
        }
        evPrevEl.disabled = payload.prev_cursor == null;
        evNextEl.disabled = payload.next_cursor == null;
    }

    /* ── Data loading ─────────────────────────────────────────── */
    var jobsCursor = 0;

    async function loadSummary() {
        try {
            var res = await fetch('/orchestration/summary');
            if (!res.ok) return;
            renderSummary(await res.json());
        } catch (e) { /* noop */ }
    }

    async function loadJobs() {
        try {
            var q = new URLSearchParams();
            q.set('scope', 'all');
            q.set('limit', '100');
            q.set('cursor', String(jobsCursor || 0));
            if (agentFilter) q.set('assignee', agentFilter);
            var res = await fetch('/orchestration/jobs?' + q.toString());
            if (!res.ok) return;
            renderJobs(await res.json());
        } catch (e) { /* noop */ }
    }

    async function loadEvents() {
        try {
            var q = new URLSearchParams();
            q.set('limit', '200');
            if (eventsState.cursor != null) {
                q.set('cursor', String(eventsState.cursor));
            }
            var res = await fetch('/orchestration/events?' + q.toString());
            if (!res.ok) return;
            renderEvents(await res.json());
        } catch (e) { /* noop */ }
    }

    if (jobLogCloseEl) {
        jobLogCloseEl.addEventListener('click', closeJobLog);
    }

    if (jobLogRefreshEl) {
        jobLogRefreshEl.addEventListener('click', function () {
            loadJobLog();
        });
    }

    if (jobLogAutoTailEl) {
        jobLogAutoTail = jobLogAutoTailEl.checked;
        jobLogAutoTailEl.addEventListener('change', function () {
            jobLogAutoTail = jobLogAutoTailEl.checked;
        });
    }

    evPrevEl.addEventListener('click', function () {
        if (eventsState.prev == null) return;
        eventsState.cursor = eventsState.prev;
        loadEvents();
    });

    evNextEl.addEventListener('click', function () {
        if (eventsState.next == null) return;
        eventsState.cursor = eventsState.next;
        loadEvents();
    });

    /* ── Polling ──────────────────────────────────────────────── */
    function tick() {
        if (document.visibilityState === 'hidden') return;
        loadSummary();
        loadJobs();
        /* Only auto-refresh events when viewing latest (no manual cursor) */
        if (eventsState.cursor == null) loadEvents();
        if (selectedJobId && jobLogPanelEl && !jobLogPanelEl.hidden && jobLogAutoTail) {
            loadJobLog();
        }
    }
    tick();
    setInterval(tick, 4000);

    document.addEventListener('visibilitychange', function () {
        if (document.visibilityState === 'visible') tick();
    });
})();
</script>
"""

WIZARD_JS = """
<script>
(function () {
    var step = 1, total = 4;
    var oauthState = window.ottoWizardOAuthState || {};

    var oauthProviders = [
        { key: 'anthropic', display: 'Anthropic', prefixes: ['anthropic/', 'claude-code/'] },
        { key: 'openai', display: 'OpenAI', prefixes: ['openai/', 'codex/'] },
        { key: 'google', display: 'Google', prefixes: ['google/', 'gemini-cli/', 'vertex_ai/'] },
        { key: 'copilot', display: 'GitHub Copilot', prefixes: ['copilot/', 'github_copilot/'] }
    ];

    function detectOAuthProvider(model) {
        var normalized = (model || '').trim().toLowerCase();
        if (!normalized) return null;
        for (var i = 0; i < oauthProviders.length; i++) {
            var provider = oauthProviders[i];
            for (var j = 0; j < provider.prefixes.length; j++) {
                if (normalized.indexOf(provider.prefixes[j]) === 0) return provider;
            }
        }
        return null;
    }

    function updateAuthField() {
        var modelInput = document.getElementById('setup_model');
        var apiInput = document.getElementById('setup_api_key');
        var authMode = document.getElementById('setup_auth_mode');
        var label = document.getElementById('setup_api_key_label');
        var hint = document.getElementById('setup_api_key_hint');
        if (!modelInput || !apiInput || !authMode || !label || !hint) return;

        var provider = detectOAuthProvider(modelInput.value);
        if (!provider) {
            authMode.value = 'api_key';
            label.innerHTML = 'API key <span class="hint" style="display:inline; text-transform: none; font-weight: normal;">(optional)</span>';
            apiInput.placeholder = 'sk-... or leave blank to use env var';
            apiInput.disabled = false;
            hint.textContent = 'Used for API-key providers.';
            return;
        }

        authMode.value = 'oauth';
        apiInput.value = '';
        apiInput.disabled = true;

        if (oauthState[provider.key]) {
            label.textContent = provider.display + ' OAuth';
            apiInput.placeholder = 'Using saved OAuth credentials';
            hint.textContent = 'Stored OAuth credentials detected. Continue to use them.';
            return;
        }

        label.textContent = 'Authenticate with ' + provider.display;
        apiInput.placeholder = 'Run: otto auth login ' + provider.key;
        hint.textContent = 'OAuth credentials are required. Run: otto auth login ' + provider.key;
    }

    function show(n) {
        for (var i = 1; i <= total; i++) {
            var el = document.getElementById('sw-step-' + i);
            if (el) el.classList.toggle('active', i === n);
            var dot = document.getElementById('sw-fill-' + i);
            if (dot) dot.classList.toggle('active', i <= n);
        }
        document.getElementById('sw-back').hidden   = (n === 1);
        document.getElementById('sw-next').hidden   = (n === total);
        document.getElementById('sw-submit').hidden = (n !== total);
        if (n === total) buildReview();
    }

    function buildReview() {
        var model = (document.getElementById('setup_model') || {}).value || '\u2014';
        var tgSel = document.querySelector('input[name="_add_telegram"]:checked');
        var tg    = tgSel && tgSel.value === 'yes' ? 'Yes' : 'No';
        var name  = (document.getElementById('setup_owner_name') || {}).value || 'owner';
        var rows  = [['Model', model], ['Telegram', tg], ['Owner', name]];
        document.getElementById('sw-review').innerHTML = rows.map(function (r) {
            return '<div class="sw-review-row"><span class="sw-review-key">' + r[0] +
                   '</span><span class="sw-review-val">' + r[1] + '</span></div>';
        }).join('');
    }

    window.swNext = function () { if (step < total) { step++; show(step); } };
    window.swBack = function () { if (step > 1)     { step--; show(step); } };

    var modelInput = document.getElementById('setup_model');
    if (modelInput) {
        modelInput.addEventListener('input', updateAuthField);
        modelInput.addEventListener('change', updateAuthField);
    }
    updateAuthField();

    document.querySelectorAll('input[name="_add_telegram"]').forEach(function (r) {
        r.addEventListener('change', function () {
            var add = r.value === 'yes' && r.checked;
            var tgf = document.getElementById('sw-tg-fields');
            if (tgf) tgf.hidden = !add;
            var tw = document.getElementById('sw-tid-wrap');
            if (tw) tw.hidden = !add;
        });
    });
})();
</script>
"""
