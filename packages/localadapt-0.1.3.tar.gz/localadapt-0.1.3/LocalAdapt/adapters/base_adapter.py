# adapters/router.py
from abc import ABC, abstractmethod
from dataclasses import dataclass
from PIL import Image

@dataclass
class Value:
    text:str = None
    image:Image = None
    path:str = None
    done:bool = False

class BaseAdapter(ABC):
    def __init__(self):
        super().__init__()
        self.model = None

    @abstractmethod
    def supports(self, request: dict) -> bool:
        """Return True if this adapter can handle the request."""
        pass

    @abstractmethod
    def register_model(self, **kwargs):
        """Return a Dataclass for the given model and parameters."""
        pass

    @abstractmethod
    def load(self, model):
        """Loads an model into the Adapter(Lazy load)."""
        pass

    @abstractmethod
    def unload(self):
        """Unloads the loaded model."""
        self.model = None

    @abstractmethod
    def run(self, request) -> Value:
        """Runs the loaded model with the given request and returns the result as an Value object."""
        pass