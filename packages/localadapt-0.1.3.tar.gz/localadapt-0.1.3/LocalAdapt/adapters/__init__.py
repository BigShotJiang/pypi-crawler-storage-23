from .router import Router
from .llm import LLMAdapter
import os

log = int(os.getenv("LOCALADAPT_LOG_LVL", "0")) == 1

if log: print("Setting up Router...")
router = Router()
if log: print("Setting up LLM Adapter...")
llmAdapt = LLMAdapter()

router.register_adapter(llmAdapt)
