# denoise/__main__.py
from __future__ import annotations

from .denoise import main

if __name__ == "__main__":
    raise SystemExit(main())