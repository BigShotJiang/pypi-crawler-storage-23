"""
Data models (dataclasses) for AgentChatBus.
These are plain Python objects used across the DB, MCP, and API layers.
"""
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional, Any


@dataclass
class Thread:
    id: str
    topic: str
    status: str          # discuss | implement | review | done | closed | archived
    created_at: datetime
    closed_at: Optional[datetime]
    summary: Optional[str]
    metadata: Optional[str]  # JSON string for arbitrary extra data
    system_prompt: Optional[str] = None


@dataclass
class Message:
    id: str
    thread_id: str
    author: str          # legacy fallback field
    role: str            # user | assistant | system
    content: str
    seq: int             # monotonically increasing per-bus sequence number
    created_at: datetime
    metadata: Optional[str]  # JSON string
    author_id: Optional[str] = None
    author_name: Optional[str] = None


@dataclass
class AgentInfo:
    id: str
    name: str              # auto-generated: "IDE (Model)" or "IDE (Model) 2"
    ide: str               # e.g. "Cursor", "Claude Desktop", "CLI"
    model: str             # e.g. "GPT-4", "claude-3-5-sonnet-20241022"
    description: str
    capabilities: Optional[str]   # JSON list of capability tags
    registered_at: datetime
    last_heartbeat: datetime
    is_online: bool               # derived: last_heartbeat within timeout window
    token: str                    # simple auth token for heartbeat/unregister calls
    display_name: Optional[str] = None    # human-readable alias (auto-generated or user-provided)
    alias_source: Optional[str] = None    # 'auto' or 'user'
    last_activity: Optional[str] = None    # activity type: 'registered', 'heartbeat', 'msg_wait', 'msg_post', etc.
    last_activity_time: Optional[datetime] = None  # when the last activity occurred


@dataclass
class Event:
    """
    Transient notification row used to fan-out SSE events to subscribers.
    Rows are written by any mutating operation and consumed+deleted by the SSE pump.
    """
    id: int
    event_type: str      # msg.new | thread.state | agent.online | agent.offline | agent.typing
    thread_id: Optional[str]
    payload: str         # JSON string
    created_at: datetime
