# Sqlmelt
 *This library is not that useful. Perhaps someday it will become great.*

[![N|Solid](https://i.yapx.cc/X7gXT.png)](https://i.yapx.cc/X7gXT.png)

## What is it?

**Sqlmelt** - this library is an alternative to the "melt" function from **Pandas**, for DBMS in which this alternative is not available. 
At the moment, the library contains only one function - for **Vertica**.

## Where to get it
```python
#for PyPI
%pip install sqlmelt
```