"""
Regulayer SDK Constants
"""

DEFAULT_API_ENDPOINT = "https://api.regulayer.tech"
DEFAULT_TIMEOUT_SECONDS = 5.0
DEFAULT_MAX_RETRIES = 3
DEFAULT_ENVIRONMENT = "prod"
