"""ADB entry point — the main user-facing API for managing devices."""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING

from adbflow.core.connection import Connection
from adbflow.core.transport import SubprocessTransport
from adbflow.utils.exceptions import DeviceNotFoundError
from adbflow.utils.parsers import parse_device_list
from adbflow.utils.types import DeviceListEntry, DeviceState

if TYPE_CHECKING:
    from adbflow.device.device import Device


class ADB:
    """Top-level ADB interface for discovering and connecting to devices.

    Usage::

        adb = ADB()
        devices = adb.devices()
        device = adb.device("emulator-5554")
    """

    def __init__(self, adb_path: str | None = None) -> None:
        self._transport = SubprocessTransport(adb_path=adb_path)

    @property
    def transport(self) -> SubprocessTransport:
        """The underlying transport instance."""
        return self._transport

    # ------------------------------------------------------------------
    # Async API
    # ------------------------------------------------------------------

    async def devices_async(self) -> list[DeviceListEntry]:
        """List connected devices (async).

        Returns a list of ``DeviceListEntry`` with serial, state, model info.
        """
        result = await self._transport.execute(["devices", "-l"])
        result.raise_on_error(["adb", "devices", "-l"])
        return parse_device_list(result.output)

    async def device_async(
        self,
        serial: str | None = None,
        **kwargs: str,
    ) -> Device:
        """Get a Device instance for the given serial (async).

        If *serial* is not provided, uses the first available device.

        Args:
            serial: Device serial number. If None, auto-selects.
            **kwargs: Additional properties to match (e.g. ``model="Pixel_6"``).

        Raises:
            DeviceNotFoundError: If no matching device is found.
        """
        entries = await self.devices_async()
        online = [e for e in entries if e.state == DeviceState.DEVICE]

        if not online:
            raise DeviceNotFoundError(serial or "")

        entry: DeviceListEntry
        if serial:
            match = [e for e in online if e.serial == serial]
            if not match:
                raise DeviceNotFoundError(serial)
            entry = match[0]
        elif kwargs:
            # Match by properties (e.g. model=...)
            found: DeviceListEntry | None = None
            for e in online:
                if all(getattr(e, k, None) == v for k, v in kwargs.items()):
                    found = e
                    break
            if found is None:
                raise DeviceNotFoundError(str(kwargs))
            entry = found
        else:
            entry = online[0]

        return self._make_device(entry.serial)

    async def connect_async(
        self,
        host: str,
        port: int = 5555,
    ) -> Device:
        """Connect to a device over TCP/IP (async).

        Args:
            host: Device IP address.
            port: Device port (default 5555).

        Returns:
            A ``Device`` instance for the connected device.
        """
        serial = f"{host}:{port}"
        conn = Connection(serial=serial, transport=self._transport)
        await conn.connect()
        return self._make_device(serial)

    async def disconnect_async(self, host: str, port: int = 5555) -> None:
        """Disconnect a TCP/IP device (async).

        Args:
            host: Device IP address.
            port: Device port (default 5555).
        """
        serial = f"{host}:{port}"
        conn = Connection(serial=serial, transport=self._transport)
        await conn.disconnect()

    # ------------------------------------------------------------------
    # Sync wrappers
    # ------------------------------------------------------------------

    def devices(self) -> list[DeviceListEntry]:
        """List connected devices (sync wrapper)."""
        return asyncio.run(self.devices_async())

    def device(self, serial: str | None = None, **kwargs: str) -> Device:
        """Get a Device instance (sync wrapper)."""
        return asyncio.run(self.device_async(serial, **kwargs))

    def connect(self, host: str, port: int = 5555) -> Device:
        """Connect to a device over TCP/IP (sync wrapper)."""
        return asyncio.run(self.connect_async(host, port))

    def disconnect(self, host: str, port: int = 5555) -> None:
        """Disconnect a TCP/IP device (sync wrapper)."""
        asyncio.run(self.disconnect_async(host, port))

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _make_device(self, serial: str) -> Device:
        """Create a Device instance (runtime import to avoid circular deps)."""
        from adbflow.device.device import Device

        return Device(serial=serial, transport=self._transport)
