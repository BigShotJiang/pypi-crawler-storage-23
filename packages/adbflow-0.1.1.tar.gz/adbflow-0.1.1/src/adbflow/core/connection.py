"""Connection lifecycle management for ADB devices."""

from __future__ import annotations

import asyncio
import logging
import re

from adbflow.core.transport import SubprocessTransport
from adbflow.utils.exceptions import (
    ADBConnectionError,
    ADBTimeoutError,
)
from adbflow.utils.types import ConnectionType

logger = logging.getLogger(__name__)


def detect_connection_type(serial: str) -> ConnectionType:
    """Determine whether a serial refers to USB or TCP.

    TCP serials match the pattern ``<ip>:<port>``.
    """
    if re.match(r"\d+\.\d+\.\d+\.\d+:\d+", serial):
        return ConnectionType.TCP
    return ConnectionType.USB


class Connection:
    """Manages the connection lifecycle for a single device.

    Supports USB and TCP connections, health checking, and optional
    heartbeat with auto-reconnect.
    """

    def __init__(
        self,
        serial: str,
        transport: SubprocessTransport,
        heartbeat_interval: float = 0.0,
    ) -> None:
        self._serial = serial
        self._transport = transport
        self._heartbeat_interval = heartbeat_interval
        self._heartbeat_task: asyncio.Task[None] | None = None
        self._connected = False

    @property
    def serial(self) -> str:
        """Device serial number."""
        return self._serial

    @property
    def connection_type(self) -> ConnectionType:
        """Whether this is a USB or TCP connection."""
        return detect_connection_type(self._serial)

    @property
    def connected(self) -> bool:
        """Whether the device is currently considered connected."""
        return self._connected

    async def connect(self) -> None:
        """Connect to the device.

        For TCP devices, runs ``adb connect <serial>``.
        For USB, just verifies the device is visible.

        Raises:
            ADBConnectionError: If the connection fails.
        """
        if self.connection_type == ConnectionType.TCP:
            result = await self._transport.execute(["connect", self._serial])
            output = result.output
            if "connected" not in output.lower() and "already" not in output.lower():
                raise ADBConnectionError(
                    f"Failed to connect to {self._serial}: {output}"
                )
        else:
            # USB: verify device is visible
            if not await self.health_check():
                raise ADBConnectionError(
                    f"USB device {self._serial} not found"
                )

        self._connected = True
        logger.info("Connected to %s (%s)", self._serial, self.connection_type.value)

        if self._heartbeat_interval > 0:
            self._start_heartbeat()

    async def disconnect(self) -> None:
        """Disconnect from the device."""
        self._stop_heartbeat()

        if self.connection_type == ConnectionType.TCP:
            await self._transport.execute(["disconnect", self._serial])

        self._connected = False
        logger.info("Disconnected from %s", self._serial)

    async def health_check(self) -> bool:
        """Check if the device is alive and responding."""
        try:
            result = await self._transport.execute(
                ["shell", "echo", "ok"],
                serial=self._serial,
                timeout=5.0,
            )
            return result.success and "ok" in result.output
        except (ADBTimeoutError, OSError):
            return False

    async def wait_for_device(self, timeout: float = 30.0) -> None:
        """Wait until the device is online.

        Args:
            timeout: Maximum time to wait in seconds.

        Raises:
            ADBTimeoutError: If the device doesn't come online.
            DeviceNotFoundError: If the device cannot be found.
        """
        deadline = asyncio.get_event_loop().time() + timeout
        while asyncio.get_event_loop().time() < deadline:
            if await self.health_check():
                self._connected = True
                return
            await asyncio.sleep(1.0)

        raise ADBTimeoutError(timeout=timeout, operation=f"wait_for_device({self._serial})")

    def _start_heartbeat(self) -> None:
        """Start background heartbeat task."""
        if self._heartbeat_task is not None:
            return
        self._heartbeat_task = asyncio.create_task(self._heartbeat_loop())

    def _stop_heartbeat(self) -> None:
        """Stop background heartbeat task."""
        if self._heartbeat_task is not None:
            self._heartbeat_task.cancel()
            self._heartbeat_task = None

    async def _heartbeat_loop(self) -> None:
        """Periodically check device health and reconnect if needed."""
        while True:
            await asyncio.sleep(self._heartbeat_interval)
            try:
                if not await self.health_check():
                    logger.warning("Heartbeat failed for %s, reconnecting...", self._serial)
                    self._connected = False
                    try:
                        await self.connect()
                    except ADBConnectionError:
                        logger.error("Reconnection failed for %s", self._serial)
            except asyncio.CancelledError:
                return
            except Exception:
                logger.exception("Heartbeat error for %s", self._serial)
