"""Async subprocess transport for ADB commands."""

from __future__ import annotations

import asyncio
import os
import shutil
import time
from collections.abc import AsyncIterator

from adbflow.utils.exceptions import (
    ADBTimeoutError,
    BinaryNotFoundError,
)
from adbflow.utils.types import Result


def _find_adb() -> str:
    """Locate the ADB binary.

    Search order:
    1. ``ADB_PATH`` environment variable
    2. ``ANDROID_HOME/platform-tools/adb``
    3. ``shutil.which("adb")``

    Raises:
        BinaryNotFoundError: If ADB cannot be found.
    """
    searched: list[str] = []

    # 1. Explicit env var
    env_path = os.environ.get("ADB_PATH")
    if env_path:
        searched.append(env_path)
        if os.path.isfile(env_path) and os.access(env_path, os.X_OK):
            return env_path

    # 2. ANDROID_HOME
    android_home = os.environ.get("ANDROID_HOME") or os.environ.get("ANDROID_SDK_ROOT")
    if android_home:
        candidate = os.path.join(android_home, "platform-tools", "adb")
        searched.append(candidate)
        if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            return candidate

    # 3. shutil.which
    which_result = shutil.which("adb")
    searched.append("PATH (shutil.which)")
    if which_result:
        return which_result

    raise BinaryNotFoundError(searched)


class SubprocessTransport:
    """ADB transport that executes commands via ``asyncio.create_subprocess_exec``."""

    def __init__(self, adb_path: str | None = None) -> None:
        self._adb_path = adb_path or _find_adb()

    @property
    def adb_path(self) -> str:
        """Path to the ADB binary."""
        return self._adb_path

    def _build_args(
        self, args: list[str], serial: str | None = None
    ) -> list[str]:
        """Prepend adb binary and serial flag to the argument list."""
        cmd = [self._adb_path]
        if serial:
            cmd.extend(["-s", serial])
        cmd.extend(args)
        return cmd

    async def execute(
        self,
        args: list[str],
        serial: str | None = None,
        timeout: float | None = None,
    ) -> Result:
        """Execute an ADB command and return the result.

        Args:
            args: Command arguments (e.g. ``["devices", "-l"]``).
            serial: Target device serial. Prepends ``-s <serial>``.
            timeout: Timeout in seconds. None means no timeout.

        Raises:
            ADBTimeoutError: If the command times out.
        """
        cmd = self._build_args(args, serial)
        start = time.monotonic()

        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        try:
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(),
                timeout=timeout,
            )
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            elapsed = (time.monotonic() - start) * 1000
            raise ADBTimeoutError(
                timeout=timeout or 0,
                operation=" ".join(cmd),
            ) from None

        elapsed = (time.monotonic() - start) * 1000
        return Result(
            stdout=stdout,
            stderr=stderr,
            return_code=proc.returncode or 0,
            duration_ms=elapsed,
        )

    async def execute_shell(
        self,
        command: str,
        serial: str | None = None,
        timeout: float | None = None,
    ) -> Result:
        """Execute an ADB shell command.

        Args:
            command: Shell command string (e.g. ``"getprop ro.build.model"``).
            serial: Target device serial.
            timeout: Timeout in seconds.
        """
        return await self.execute(
            ["shell", command],
            serial=serial,
            timeout=timeout,
        )

    async def stream(
        self,
        args: list[str],
        serial: str | None = None,
    ) -> AsyncIterator[bytes]:
        """Stream raw bytes from a long-running ADB command (e.g. logcat).

        Yields chunks of stdout as they arrive.
        """
        cmd = self._build_args(args, serial)
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        assert proc.stdout is not None  # noqa: S101
        try:
            while True:
                chunk = await proc.stdout.read(4096)
                if not chunk:
                    break
                yield chunk
        finally:
            proc.kill()
            await proc.wait()

    async def stream_lines(
        self,
        args: list[str],
        serial: str | None = None,
    ) -> AsyncIterator[str]:
        """Stream decoded lines from a long-running ADB command.

        Yields one line at a time (without trailing newline).
        """
        cmd = self._build_args(args, serial)
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        assert proc.stdout is not None  # noqa: S101
        try:
            async for raw_line in proc.stdout:
                yield raw_line.decode("utf-8", errors="replace").rstrip("\n\r")
        finally:
            proc.kill()
            await proc.wait()
