"""Multi-device parallel execution."""

from adbflow.parallel.pool import DevicePool

__all__ = ["DevicePool"]
