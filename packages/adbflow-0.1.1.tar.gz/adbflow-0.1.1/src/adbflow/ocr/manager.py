"""OCR manager — ADB-integrated text recognition."""

from __future__ import annotations

import asyncio
import time

from PIL import Image

from adbflow.ocr.engine import OCREngine
from adbflow.utils.exceptions import OCRError, WaitTimeoutError
from adbflow.utils.types import OCRResult, TransportProtocol


class OCRManager:
    """High-level OCR operations integrated with ADB screenshots.

    Args:
        serial: Device serial number.
        transport: ADB transport implementation.
    """

    def __init__(self, serial: str, transport: TransportProtocol) -> None:
        self._serial = serial
        self._transport = transport
        self._engine = OCREngine()

    async def _capture_pil(self) -> Image.Image:
        """Capture a screenshot and return a PIL Image."""
        import io

        result = await self._transport.execute(
            ["exec-out", "screencap", "-p"], serial=self._serial,
        )
        result.raise_on_error("screencap")
        return Image.open(io.BytesIO(result.stdout))

    async def read_screen_async(
        self,
        languages: tuple[str, ...] = ("en",),
    ) -> list[OCRResult]:
        """Read all text from the current screen.

        Args:
            languages: Language codes for recognition.

        Returns:
            List of ``OCRResult`` objects.
        """
        screenshot = await self._capture_pil()
        return self._engine.recognize(screenshot, languages)

    async def find_text_async(
        self,
        text: str,
        languages: tuple[str, ...] = ("en",),
    ) -> OCRResult | None:
        """Find exact text on the current screen.

        Args:
            text: Exact text to search for.
            languages: Language codes for recognition.

        Returns:
            Matching ``OCRResult`` or ``None``.
        """
        screenshot = await self._capture_pil()
        return self._engine.find_text(screenshot, text, languages)

    async def find_text_contains_async(
        self,
        text: str,
        languages: tuple[str, ...] = ("en",),
    ) -> list[OCRResult]:
        """Find text containing a substring on the current screen.

        Args:
            text: Substring to search for.
            languages: Language codes for recognition.

        Returns:
            List of matching ``OCRResult`` objects.
        """
        screenshot = await self._capture_pil()
        return self._engine.find_text_contains(screenshot, text, languages)

    async def tap_text_async(
        self,
        text: str,
        languages: tuple[str, ...] = ("en",),
    ) -> OCRResult:
        """Find text on screen and tap its center.

        Args:
            text: Exact text to find and tap.
            languages: Language codes for recognition.

        Returns:
            The ``OCRResult`` that was tapped.

        Raises:
            OCRError: If text not found on screen.
        """
        result = await self.find_text_async(text, languages)
        if result is None:
            raise OCRError(f"Text not found on screen: {text!r}")
        center = result.bounds.center
        await self._transport.execute_shell(
            f"input tap {center.x} {center.y}",
            serial=self._serial,
        )
        return result

    async def wait_for_text_async(
        self,
        text: str,
        timeout: float = 10.0,
        interval: float = 1.0,
        languages: tuple[str, ...] = ("en",),
    ) -> OCRResult:
        """Wait for text to appear on screen.

        Args:
            text: Exact text to wait for.
            timeout: Maximum wait time in seconds.
            interval: Polling interval in seconds.
            languages: Language codes for recognition.

        Returns:
            The ``OCRResult`` when found.

        Raises:
            WaitTimeoutError: If text not found within *timeout*.
        """
        start = time.monotonic()
        while True:
            result = await self.find_text_async(text, languages)
            if result is not None:
                return result
            elapsed = time.monotonic() - start
            if elapsed >= timeout:
                raise WaitTimeoutError(
                    timeout=timeout,
                    condition_name=f"OCR text: {text!r}",
                    elapsed=elapsed,
                )
            await asyncio.sleep(min(interval, timeout - elapsed))
