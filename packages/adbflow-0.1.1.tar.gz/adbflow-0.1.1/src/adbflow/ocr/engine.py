"""OCR engine — pure OCR operations using EasyOCR."""

from __future__ import annotations

from typing import Any

from PIL import Image

from adbflow.utils.exceptions import OCRError
from adbflow.utils.geometry import Rect
from adbflow.utils.types import OCRResult

import importlib.util

_HAS_EASYOCR = importlib.util.find_spec("easyocr") is not None


def _require_easyocr() -> None:
    if not _HAS_EASYOCR:
        raise OCRError(
            "easyocr not installed. Install with: pip install adbflow[ocr]"
        )


class OCREngine:
    """Pure OCR operations using EasyOCR.

    The EasyOCR Reader is lazily initialized on first call and cached.
    """

    def __init__(self) -> None:
        self._reader: Any = None
        self._reader_languages: tuple[str, ...] = ()

    def _get_reader(self, languages: tuple[str, ...]) -> Any:
        """Get or create an EasyOCR Reader, cached by language set."""
        _require_easyocr()
        import easyocr as _easyocr  # type: ignore[import-not-found]

        if self._reader is None or self._reader_languages != languages:
            self._reader = _easyocr.Reader(list(languages), verbose=False)
            self._reader_languages = languages
        return self._reader

    def recognize(
        self,
        image: Image.Image,
        languages: tuple[str, ...] = ("en",),
    ) -> list[OCRResult]:
        """Recognize text in an image.

        Args:
            image: PIL Image to process.
            languages: Language codes for recognition.

        Returns:
            List of ``OCRResult`` objects with text, bounds, and confidence.
        """
        import numpy as np  # type: ignore[import-not-found]

        reader = self._get_reader(languages)
        arr: Any = np.array(image.convert("RGB"))
        raw_results: list[Any] = reader.readtext(arr)

        results: list[OCRResult] = []
        for bbox, text, conf in raw_results:
            # bbox is [[x1,y1],[x2,y1],[x2,y2],[x1,y2]]
            xs = [int(pt[0]) for pt in bbox]
            ys = [int(pt[1]) for pt in bbox]
            rect = Rect(
                left=min(xs), top=min(ys),
                right=max(xs), bottom=max(ys),
            )
            results.append(OCRResult(text=text, bounds=rect, confidence=float(conf)))

        return results

    def find_text(
        self,
        image: Image.Image,
        text: str,
        languages: tuple[str, ...] = ("en",),
    ) -> OCRResult | None:
        """Find exact text match in an image.

        Args:
            image: PIL Image to process.
            text: Exact text to search for.
            languages: Language codes for recognition.

        Returns:
            Matching ``OCRResult`` or ``None``.
        """
        results = self.recognize(image, languages)
        for r in results:
            if r.text == text:
                return r
        return None

    def find_text_contains(
        self,
        image: Image.Image,
        text: str,
        languages: tuple[str, ...] = ("en",),
    ) -> list[OCRResult]:
        """Find text containing a substring in an image.

        Args:
            image: PIL Image to process.
            text: Substring to search for.
            languages: Language codes for recognition.

        Returns:
            List of matching ``OCRResult`` objects.
        """
        results = self.recognize(image, languages)
        return [r for r in results if text in r.text]
