"""Accessibility service management."""

from adbflow.accessibility.manager import AccessibilityManager

__all__ = ["AccessibilityManager"]
