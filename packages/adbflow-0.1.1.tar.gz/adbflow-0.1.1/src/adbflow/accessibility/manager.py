"""Accessibility service management."""

from __future__ import annotations

from adbflow.utils.parsers import parse_accessibility_services
from adbflow.utils.types import AccessibilityService, TransportProtocol


class AccessibilityManager:
    """Manages accessibility services on the device.

    Args:
        serial: Device serial number.
        transport: ADB transport implementation.
    """

    def __init__(self, serial: str, transport: TransportProtocol) -> None:
        self._serial = serial
        self._transport = transport

    async def list_services_async(self) -> list[AccessibilityService]:
        """List all accessibility services.

        Returns:
            List of ``AccessibilityService`` objects.
        """
        result = await self._transport.execute_shell(
            "dumpsys accessibility",
            serial=self._serial,
        )
        return parse_accessibility_services(result.output)

    async def get_enabled_async(self) -> list[str]:
        """Get list of currently enabled accessibility service components.

        Returns:
            List of component strings (e.g. ``"package/class"``).
        """
        result = await self._transport.execute_shell(
            "settings get secure enabled_accessibility_services",
            serial=self._serial,
        )
        value = result.output.strip()
        if not value or value == "null":
            return []
        return [c.strip() for c in value.split(":") if c.strip()]

    async def is_enabled_async(self, component: str) -> bool:
        """Check if a specific accessibility service is enabled.

        Args:
            component: Service component string (e.g. ``"package/class"``).

        Returns:
            ``True`` if the service is currently enabled.
        """
        enabled = await self.get_enabled_async()
        return component in enabled

    async def enable_async(self, component: str) -> None:
        """Enable an accessibility service.

        Args:
            component: Service component string to enable.
        """
        enabled = await self.get_enabled_async()
        if component not in enabled:
            enabled.append(component)
        new_value = ":".join(enabled)
        await self._transport.execute_shell(
            f"settings put secure enabled_accessibility_services {new_value}",
            serial=self._serial,
        )

    async def disable_async(self, component: str) -> None:
        """Disable an accessibility service.

        Args:
            component: Service component string to disable.
        """
        enabled = await self.get_enabled_async()
        enabled = [c for c in enabled if c != component]
        new_value = ":".join(enabled) if enabled else "null"
        await self._transport.execute_shell(
            f"settings put secure enabled_accessibility_services {new_value}",
            serial=self._serial,
        )
