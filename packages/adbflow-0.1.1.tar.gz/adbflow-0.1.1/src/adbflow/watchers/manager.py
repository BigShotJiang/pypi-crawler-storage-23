"""Watcher manager — auto-respond to UI conditions."""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Callable, Coroutine
from typing import Any

from adbflow.ui.element import UIElement
from adbflow.ui.manager import UIManager
from adbflow.ui.selector import Selector
from adbflow.utils.types import TransportProtocol

logger = logging.getLogger(__name__)

WatcherAction = Callable[[UIElement], Coroutine[Any, Any, None]]


class WatcherManager:
    """Watches for UI conditions and auto-responds.

    Args:
        serial: Device serial number.
        transport: ADB transport implementation.
        ui_manager: UI manager for hierarchy access.
    """

    def __init__(
        self,
        serial: str,
        transport: TransportProtocol,
        ui_manager: UIManager,
    ) -> None:
        self._serial = serial
        self._transport = transport
        self._ui = ui_manager
        self._watchers: dict[str, tuple[Selector, WatcherAction]] = {}
        self._task: asyncio.Task[None] | None = None

    def register(self, name: str, selector: Selector, action: WatcherAction) -> None:
        """Register a watcher.

        Args:
            name: Unique watcher name.
            selector: Selector to match UI elements.
            action: Async callback receiving the matched element.
        """
        self._watchers[name] = (selector, action)

    def unregister(self, name: str) -> None:
        """Unregister a watcher by name.

        Args:
            name: Watcher name to remove.
        """
        self._watchers.pop(name, None)

    @property
    def is_running(self) -> bool:
        """Whether the watcher loop is active."""
        return self._task is not None and not self._task.done()

    def list_watchers(self) -> list[str]:
        """Return registered watcher names."""
        return list(self._watchers.keys())

    async def start_async(self, interval: float = 1.0) -> None:
        """Start the watcher background loop.

        Args:
            interval: Polling interval in seconds.
        """
        if self.is_running:
            return
        self._task = asyncio.create_task(self._loop(interval))

    async def stop_async(self) -> None:
        """Stop the watcher background loop."""
        if self._task is not None and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None

    async def _loop(self, interval: float) -> None:
        """Background polling loop."""
        try:
            while True:
                await self._check_watchers()
                await asyncio.sleep(interval)
        except asyncio.CancelledError:
            return

    async def _check_watchers(self) -> None:
        """Check all watchers against the current UI hierarchy."""
        if not self._watchers:
            return
        self._ui.invalidate_cache()
        root = await self._ui.dump_async()
        for name, (selector, action) in list(self._watchers.items()):
            for node in root.iter_all():
                if selector.matches(node):
                    element = UIElement(node, self._ui._gestures, self._ui)
                    try:
                        await action(element)
                    except Exception:
                        logger.exception("Watcher %r action failed", name)
                    break


def click_watcher(name: str, selector: Selector) -> tuple[str, Selector, WatcherAction]:
    """Create a watcher that auto-taps matching elements.

    Args:
        name: Watcher name.
        selector: Selector to match.

    Returns:
        Tuple of ``(name, selector, action)`` for use with ``register()``.
    """

    async def _click(element: UIElement) -> None:
        await element.tap_async()

    return name, selector, _click


def dismiss_watcher(name: str, text: str) -> tuple[str, Selector, WatcherAction]:
    """Create a watcher that auto-dismisses dialogs containing text.

    Args:
        name: Watcher name.
        text: Text to match (e.g. "OK", "Allow").

    Returns:
        Tuple of ``(name, selector, action)`` for use with ``register()``.
    """
    selector = Selector().text_contains(text).clickable()

    async def _dismiss(element: UIElement) -> None:
        await element.tap_async()

    return name, selector, _dismiss
