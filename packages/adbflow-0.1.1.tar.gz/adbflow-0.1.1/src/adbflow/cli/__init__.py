"""CLI entry point."""

from adbflow.cli.app import app

__all__ = ["app"]
