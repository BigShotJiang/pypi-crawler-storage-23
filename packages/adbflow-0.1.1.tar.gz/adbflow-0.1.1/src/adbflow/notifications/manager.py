"""Notification management — list, filter, clear, and wait for notifications."""

from __future__ import annotations

import asyncio
import time

from adbflow.utils.exceptions import WaitTimeoutError
from adbflow.utils.parsers import parse_notifications
from adbflow.utils.types import Notification, TransportProtocol


class NotificationManager:
    """Manages device notifications via ``dumpsys notification``.

    Args:
        serial: Device serial number.
        transport: ADB transport implementation.
    """

    def __init__(self, serial: str, transport: TransportProtocol) -> None:
        self._serial = serial
        self._transport = transport

    async def list_async(self) -> list[Notification]:
        """List all current notifications.

        Returns:
            List of parsed ``Notification`` objects.
        """
        result = await self._transport.execute_shell(
            "dumpsys notification --noredact",
            serial=self._serial,
        )
        return parse_notifications(result.output)

    async def clear_all_async(self) -> None:
        """Clear all notifications."""
        await self._transport.execute_shell(
            "service call notification 1",
            serial=self._serial,
        )

    async def find_async(
        self,
        package: str | None = None,
        title_contains: str | None = None,
        text_contains: str | None = None,
    ) -> list[Notification]:
        """Find notifications matching the given filters.

        Args:
            package: Filter by package name (exact match).
            title_contains: Filter by title substring.
            text_contains: Filter by text substring.

        Returns:
            List of matching ``Notification`` objects.
        """
        notifications = await self.list_async()
        filtered: list[Notification] = []
        for n in notifications:
            if package is not None and n.package != package:
                continue
            if title_contains is not None and title_contains not in n.title:
                continue
            if text_contains is not None and text_contains not in n.text:
                continue
            filtered.append(n)
        return filtered

    async def wait_for_async(
        self,
        package: str | None = None,
        title_contains: str | None = None,
        timeout: float = 10.0,
        interval: float = 1.0,
    ) -> Notification:
        """Wait until a matching notification appears.

        Args:
            package: Filter by package name.
            title_contains: Filter by title substring.
            timeout: Maximum wait time in seconds.
            interval: Polling interval in seconds.

        Returns:
            The first matching ``Notification``.

        Raises:
            WaitTimeoutError: If no match within *timeout*.
        """
        start = time.monotonic()
        while True:
            matches = await self.find_async(
                package=package, title_contains=title_contains,
            )
            if matches:
                return matches[0]
            elapsed = time.monotonic() - start
            if elapsed >= timeout:
                desc = "notification"
                if package:
                    desc += f" from {package}"
                if title_contains:
                    desc += f" with title containing '{title_contains}'"
                raise WaitTimeoutError(
                    timeout=timeout,
                    condition_name=desc,
                    elapsed=elapsed,
                )
            await asyncio.sleep(min(interval, timeout - elapsed))
