"""Notification management."""

from adbflow.notifications.manager import NotificationManager

__all__ = ["NotificationManager"]
