"""UI hierarchy node model and XML parser."""

from __future__ import annotations

from collections.abc import Iterator
from dataclasses import dataclass

from lxml import etree

from adbflow.utils.geometry import Rect
from adbflow.utils.parsers import parse_bounds_string


def _parse_bool(value: str | None) -> bool:
    return value == "true"


@dataclass(frozen=True)
class UINode:
    """A node in the Android UI hierarchy.

    Corresponds to a single ``<node>`` element in a ``uiautomator dump``.
    """

    text: str
    resource_id: str
    class_name: str
    package: str
    content_desc: str
    checkable: bool
    checked: bool
    clickable: bool
    enabled: bool
    focusable: bool
    focused: bool
    scrollable: bool
    long_clickable: bool
    selected: bool
    bounds: Rect
    index: int
    children: tuple[UINode, ...]

    def iter_descendants(self) -> Iterator[UINode]:
        """Yield all descendant nodes depth-first (excludes self)."""
        for child in self.children:
            yield child
            yield from child.iter_descendants()

    def iter_all(self) -> Iterator[UINode]:
        """Yield self and all descendant nodes depth-first."""
        yield self
        yield from self.iter_descendants()


_DEFAULT_BOUNDS = Rect(0, 0, 0, 0)


def _parse_node(element: etree._Element) -> UINode:
    """Recursively parse an lxml ``<node>`` element into a ``UINode``."""
    bounds_str = element.get("bounds", "")
    bounds = parse_bounds_string(bounds_str) or _DEFAULT_BOUNDS

    try:
        index = int(element.get("index", "0"))
    except ValueError:
        index = 0

    children = tuple(_parse_node(child) for child in element if child.tag == "node")

    return UINode(
        text=element.get("text", ""),
        resource_id=element.get("resource-id", ""),
        class_name=element.get("class", ""),
        package=element.get("package", ""),
        content_desc=element.get("content-desc", ""),
        checkable=_parse_bool(element.get("checkable")),
        checked=_parse_bool(element.get("checked")),
        clickable=_parse_bool(element.get("clickable")),
        enabled=_parse_bool(element.get("enabled")),
        focusable=_parse_bool(element.get("focusable")),
        focused=_parse_bool(element.get("focused")),
        scrollable=_parse_bool(element.get("scrollable")),
        long_clickable=_parse_bool(element.get("long-clickable")),
        selected=_parse_bool(element.get("selected")),
        bounds=bounds,
        index=index,
        children=children,
    )


_EMPTY_ROOT = UINode(
    text="",
    resource_id="",
    class_name="",
    package="",
    content_desc="",
    checkable=False,
    checked=False,
    clickable=False,
    enabled=False,
    focusable=False,
    focused=False,
    scrollable=False,
    long_clickable=False,
    selected=False,
    bounds=_DEFAULT_BOUNDS,
    index=0,
    children=(),
)


def parse_hierarchy(xml_content: str) -> UINode:
    """Parse a ``uiautomator dump`` XML string into a ``UINode`` tree.

    Args:
        xml_content: XML string from ``uiautomator dump``.

    Returns:
        Root ``UINode`` of the hierarchy. Returns an empty synthetic root
        if the XML content is empty or cannot be parsed.
    """
    stripped = xml_content.strip()
    if not stripped:
        return _EMPTY_ROOT
    try:
        root = etree.fromstring(stripped.encode("utf-8"))  # noqa: S320
    except etree.XMLSyntaxError:
        return _EMPTY_ROOT
    # The root is usually <hierarchy>, with child <node> elements
    nodes = [child for child in root if child.tag == "node"]
    if nodes:
        return _parse_node(nodes[0])
    # If the root itself is a <node>
    if root.tag == "node":
        return _parse_node(root)
    # Empty hierarchy — return a synthetic root
    return _EMPTY_ROOT
