"""UI element wrapper — rich interaction on a matched node."""

from __future__ import annotations

from typing import TYPE_CHECKING

from adbflow.gestures.manager import GestureManager
from adbflow.ui.hierarchy import UINode
from adbflow.utils.geometry import Point, Rect
from adbflow.utils.types import SwipeDirection

if TYPE_CHECKING:
    from adbflow.ui.manager import UIManager


class UIElement:
    """Wraps a ``UINode`` with gesture and re-query capabilities.

    Args:
        node: The matched hierarchy node.
        gestures: Gesture manager for touch interactions.
        ui_manager: UI manager for re-dumping hierarchy.
    """

    def __init__(
        self,
        node: UINode,
        gestures: GestureManager,
        ui_manager: UIManager,
    ) -> None:
        self._node = node
        self._gestures = gestures
        self._ui_manager = ui_manager

    @property
    def info(self) -> UINode:
        """The underlying ``UINode``."""
        return self._node

    def get_text(self) -> str:
        """Return the element's text."""
        return self._node.text

    def get_bounds(self) -> Rect:
        """Return the element's bounding rectangle."""
        return self._node.bounds

    def get_center(self) -> Point:
        """Return the center point of the element."""
        return self._node.bounds.center

    async def tap_async(self) -> None:
        """Tap the center of this element."""
        center = self.get_center()
        await self._gestures.tap_async(center)
        self._ui_manager.invalidate_cache()

    async def long_tap_async(self, duration_ms: int = 1000) -> None:
        """Long-tap the center of this element.

        Args:
            duration_ms: Hold duration in milliseconds.
        """
        center = self.get_center()
        await self._gestures.long_tap_async(center, duration_ms=duration_ms)
        self._ui_manager.invalidate_cache()

    async def swipe_async(
        self,
        direction: SwipeDirection,
        distance: int = 500,
        duration_ms: int = 300,
    ) -> None:
        """Swipe from this element's center in *direction*.

        Args:
            direction: Swipe direction.
            distance: Swipe distance in pixels.
            duration_ms: Swipe duration in milliseconds.
        """
        center = self.get_center()
        await self._gestures.swipe_direction_async(
            direction,
            start=center,
            distance=distance,
            duration_ms=duration_ms,
        )
        self._ui_manager.invalidate_cache()

    async def text_input_async(self, text: str) -> None:
        """Tap this element then type *text*.

        Args:
            text: Text to type.
        """
        await self.tap_async()
        await self._gestures.text_async(text)
        self._ui_manager.invalidate_cache()

    async def exists_async(self) -> bool:
        """Re-dump the hierarchy and check if this element still exists."""
        from adbflow.ui.selector import Selector

        selector = Selector().text(self._node.text).resource_id(self._node.resource_id)
        return await self._ui_manager.exists_async(selector)

    async def wait_for_async(self, timeout: float = 10.0) -> UIElement:
        """Poll until this element reappears in the hierarchy.

        Args:
            timeout: Maximum wait time in seconds.

        Returns:
            The refreshed ``UIElement``.
        """
        from adbflow.ui.selector import Selector

        selector = Selector().text(self._node.text).resource_id(self._node.resource_id)
        return await self._ui_manager.wait_for_async(selector, timeout=timeout)
