"""UI automation — hierarchy parsing, selectors, element interaction."""

from adbflow.ui.hierarchy import UINode, parse_hierarchy
from adbflow.ui.manager import UIManager
from adbflow.ui.selector import Selector

# UIElement imported from manager to avoid circular issues at import time
from adbflow.ui.element import UIElement

__all__ = [
    "UIManager",
    "UIElement",
    "UINode",
    "Selector",
    "parse_hierarchy",
]
