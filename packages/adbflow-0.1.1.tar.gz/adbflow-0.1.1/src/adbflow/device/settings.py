"""Android settings management (system, secure, global)."""

from __future__ import annotations

from typing import Literal

from adbflow.core.transport import SubprocessTransport
from adbflow.utils.parsers import parse_settings_value

SettingsNamespace = Literal["system", "secure", "global"]


class DeviceSettings:
    """Read and write Android settings across namespaces."""

    def __init__(self, serial: str, transport: SubprocessTransport) -> None:
        self._serial = serial
        self._transport = transport

    async def get_async(
        self,
        namespace: SettingsNamespace,
        key: str,
    ) -> str | None:
        """Get a settings value (async).

        Returns None if the key doesn't exist.
        """
        result = await self._transport.execute_shell(
            f"settings get {namespace} {key}",
            serial=self._serial,
        )
        return parse_settings_value(result.output)

    async def put_async(
        self,
        namespace: SettingsNamespace,
        key: str,
        value: str,
    ) -> None:
        """Set a settings value (async)."""
        result = await self._transport.execute_shell(
            f"settings put {namespace} {key} {value}",
            serial=self._serial,
        )
        result.raise_on_error(f"settings put {namespace} {key} {value}")

    async def delete_async(
        self,
        namespace: SettingsNamespace,
        key: str,
    ) -> None:
        """Delete a settings key (async)."""
        result = await self._transport.execute_shell(
            f"settings delete {namespace} {key}",
            serial=self._serial,
        )
        result.raise_on_error(f"settings delete {namespace} {key}")

    async def list_async(
        self,
        namespace: SettingsNamespace,
    ) -> dict[str, str]:
        """List all settings in a namespace (async)."""
        result = await self._transport.execute_shell(
            f"settings list {namespace}",
            serial=self._serial,
        )
        settings: dict[str, str] = {}
        for line in result.output.strip().splitlines():
            if "=" in line:
                key, _, val = line.partition("=")
                settings[key.strip()] = val.strip()
        return settings
