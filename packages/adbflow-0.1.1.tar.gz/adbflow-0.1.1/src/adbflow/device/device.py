"""Main Device class — the central API object for device interaction."""

from __future__ import annotations

import asyncio
from functools import cached_property

from adbflow.accessibility.manager import AccessibilityManager
from adbflow.apps.manager import AppManager
from adbflow.core.transport import SubprocessTransport
from adbflow.device.info import DeviceInfo
from adbflow.device.input_method import InputMethodManager
from adbflow.device.power import DevicePower
from adbflow.device.properties import DeviceProperties
from adbflow.device.settings import DeviceSettings
from adbflow.files.operations import FileManager
from adbflow.gestures.manager import GestureManager
from adbflow.logcat.stream import LogcatManager
from adbflow.media.manager import MediaManager
from adbflow.network.controls import NetworkManager
from adbflow.notifications.manager import NotificationManager
from adbflow.ocr.manager import OCRManager
from adbflow.recorder.recorder import ActionRecorder
from adbflow.ui.manager import UIManager
from adbflow.utils.types import KeyCode, Result
from adbflow.vision.manager import VisionManager
from adbflow.wait.conditions import ActivityIs, TextVisible
from adbflow.wait.engine import wait_for
from adbflow.watchers.manager import WatcherManager


class Device:
    """Represents a connected Android device.

    This is the main user-facing object. Sub-modules (info, settings, power, etc.)
    are lazily initialized on first access.

    Usage::

        device = ADB().device("emulator-5554")
        print(await device.info.model_async())
        print(await device.shell_async("echo hello"))
    """

    def __init__(self, serial: str, transport: SubprocessTransport) -> None:
        self._serial = serial
        self._transport = transport

    @property
    def serial(self) -> str:
        """Device serial number."""
        return self._serial

    @property
    def transport(self) -> SubprocessTransport:
        """The underlying transport."""
        return self._transport

    # ------------------------------------------------------------------
    # Lazy sub-module properties
    # ------------------------------------------------------------------

    @cached_property
    def properties(self) -> DeviceProperties:
        """Device property (getprop/setprop) manager."""
        return DeviceProperties(self._serial, self._transport)

    @cached_property
    def info(self) -> DeviceInfo:
        """Device information accessors."""
        return DeviceInfo(self._serial, self._transport, self.properties)

    @cached_property
    def settings(self) -> DeviceSettings:
        """Android settings manager."""
        return DeviceSettings(self._serial, self._transport)

    @cached_property
    def power(self) -> DevicePower:
        """Power controls."""
        return DevicePower(self._serial, self._transport)

    @cached_property
    def ime(self) -> InputMethodManager:
        """Input Method Editor manager."""
        return InputMethodManager(self._serial, self._transport)

    @cached_property
    def files(self) -> FileManager:
        """File operations manager."""
        return FileManager(self._serial, self._transport)

    @cached_property
    def apps(self) -> AppManager:
        """App management (install, uninstall, start, stop, etc.)."""
        return AppManager(self._serial, self._transport)

    @cached_property
    def media(self) -> MediaManager:
        """Media operations (screenshot, recording, audio)."""
        return MediaManager(self._serial, self._transport)

    @cached_property
    def logcat(self) -> LogcatManager:
        """Logcat streaming and crash detection."""
        return LogcatManager(self._serial, self._transport)

    @cached_property
    def network(self) -> NetworkManager:
        """Network controls (WiFi, data, airplane, forwarding, proxy)."""
        return NetworkManager(self._serial, self._transport)

    @cached_property
    def gestures(self) -> GestureManager:
        """Touch gesture controls (tap, swipe, drag, pinch, text)."""
        return GestureManager(self._serial, self._transport)

    @cached_property
    def ui(self) -> UIManager:
        """UI automation (hierarchy, selectors, elements)."""
        return UIManager(self._serial, self._transport, self.gestures)

    @cached_property
    def notifications(self) -> NotificationManager:
        """Notification management."""
        return NotificationManager(self._serial, self._transport)

    @cached_property
    def accessibility(self) -> AccessibilityManager:
        """Accessibility service management."""
        return AccessibilityManager(self._serial, self._transport)

    @cached_property
    def vision(self) -> VisionManager:
        """Vision operations (template matching, color detection)."""
        return VisionManager(self._serial, self._transport)

    @cached_property
    def ocr(self) -> OCRManager:
        """OCR text recognition."""
        return OCRManager(self._serial, self._transport)

    @cached_property
    def watchers(self) -> WatcherManager:
        """UI watchers (auto-respond to UI conditions)."""
        return WatcherManager(self._serial, self._transport, self.ui)

    @cached_property
    def recorder(self) -> ActionRecorder:
        """Action recorder."""
        return ActionRecorder(self._serial, self._transport)

    # ------------------------------------------------------------------
    # Direct methods — async
    # ------------------------------------------------------------------

    async def shell_async(self, command: str, timeout: float | None = None) -> str:
        """Run a shell command on the device and return stdout (async).

        Args:
            command: Shell command string.
            timeout: Timeout in seconds.

        Returns:
            Decoded stdout string (stripped).
        """
        result = await self._transport.execute_shell(
            command,
            serial=self._serial,
            timeout=timeout,
        )
        return result.output

    async def shell_result_async(
        self, command: str, timeout: float | None = None
    ) -> Result:
        """Run a shell command and return the full Result (async).

        Args:
            command: Shell command string.
            timeout: Timeout in seconds.
        """
        return await self._transport.execute_shell(
            command,
            serial=self._serial,
            timeout=timeout,
        )

    async def keyevent_async(self, key: KeyCode | int) -> None:
        """Send a key event to the device (async).

        Args:
            key: Key code (KeyCode enum or raw int).
        """
        await self._transport.execute_shell(
            f"input keyevent {int(key)}",
            serial=self._serial,
        )

    async def screenshot_async(self) -> bytes:
        """Capture a screenshot (convenience shortcut).

        Returns:
            PNG image data as bytes.
        """
        return await self.media.screenshot.capture_async()

    async def wait_for_text_async(self, text: str, timeout: float = 10.0) -> bool:
        """Wait for text to appear in the UI hierarchy.

        Args:
            text: Text to look for.
            timeout: Maximum wait time in seconds.

        Returns:
            ``True`` when the text is found.

        Raises:
            WaitTimeoutError: If the text does not appear within *timeout*.
        """
        condition = TextVisible(text, self._serial, self._transport)
        return await wait_for(condition, timeout=timeout)

    async def wait_for_activity_async(self, activity: str, timeout: float = 10.0) -> bool:
        """Wait for a specific foreground activity.

        Args:
            activity: Activity name to match.
            timeout: Maximum wait time in seconds.

        Returns:
            ``True`` when the activity is in the foreground.

        Raises:
            WaitTimeoutError: If the activity does not appear within *timeout*.
        """
        condition = ActivityIs(activity, self._serial, self._transport)
        return await wait_for(condition, timeout=timeout)

    # ------------------------------------------------------------------
    # Direct methods — sync wrappers
    # ------------------------------------------------------------------

    def shell(self, command: str, timeout: float | None = None) -> str:
        """Run a shell command on the device (sync wrapper)."""
        return asyncio.run(self.shell_async(command, timeout=timeout))

    def shell_result(self, command: str, timeout: float | None = None) -> Result:
        """Run a shell command and return the full Result (sync wrapper)."""
        return asyncio.run(self.shell_result_async(command, timeout=timeout))

    def keyevent(self, key: KeyCode | int) -> None:
        """Send a key event (sync wrapper)."""
        asyncio.run(self.keyevent_async(key))

    def __repr__(self) -> str:
        return f"Device(serial={self._serial!r})"
