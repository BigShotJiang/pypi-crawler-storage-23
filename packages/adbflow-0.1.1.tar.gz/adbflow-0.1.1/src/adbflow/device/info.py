"""Device information accessors."""

from __future__ import annotations

from adbflow.core.transport import SubprocessTransport
from adbflow.device.properties import DeviceProperties
from adbflow.utils.parsers import (
    parse_dumpsys_battery,
    parse_ip_address,
    parse_screen_density,
    parse_screen_size,
)
from adbflow.utils.types import BatteryInfo, Size


class DeviceInfo:
    """Cached accessors for device information.

    Static properties (model, manufacturer) are cached permanently.
    Dynamic properties (battery, IP) are fetched fresh each time.
    """

    def __init__(
        self,
        serial: str,
        transport: SubprocessTransport,
        properties: DeviceProperties,
    ) -> None:
        self._serial = serial
        self._transport = transport
        self._properties = properties
        self._static_cache: dict[str, str | None] = {}

    async def _get_static(self, prop: str) -> str | None:
        """Get a static property, using cache."""
        if prop not in self._static_cache:
            self._static_cache[prop] = await self._properties.get_async(prop)
        return self._static_cache[prop]

    async def model_async(self) -> str:
        """Device model name (async)."""
        return await self._get_static("ro.product.model") or "unknown"

    async def manufacturer_async(self) -> str:
        """Device manufacturer (async)."""
        return await self._get_static("ro.product.manufacturer") or "unknown"

    async def android_version_async(self) -> str:
        """Android version string (async)."""
        return await self._get_static("ro.build.version.release") or "unknown"

    async def sdk_level_async(self) -> int:
        """SDK / API level (async)."""
        val = await self._get_static("ro.build.version.sdk")
        try:
            return int(val or "0")
        except ValueError:
            return 0

    async def screen_size_async(self) -> Size | None:
        """Physical screen size (async)."""
        result = await self._transport.execute_shell(
            "wm size",
            serial=self._serial,
        )
        return parse_screen_size(result.output)

    async def density_async(self) -> int | None:
        """Screen density in DPI (async)."""
        result = await self._transport.execute_shell(
            "wm density",
            serial=self._serial,
        )
        return parse_screen_density(result.output)

    async def battery_async(self) -> BatteryInfo | None:
        """Battery information (async, always fresh)."""
        result = await self._transport.execute_shell(
            "dumpsys battery",
            serial=self._serial,
        )
        return parse_dumpsys_battery(result.output)

    async def ip_address_async(self) -> str | None:
        """Device IP address (async, always fresh)."""
        result = await self._transport.execute_shell(
            "ip route",
            serial=self._serial,
        )
        return parse_ip_address(result.output)
