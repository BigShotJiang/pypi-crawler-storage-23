"""Screenshot capture."""

from __future__ import annotations

from adbflow.core.transport import SubprocessTransport


class ScreenshotManager:
    """Captures screenshots from a connected device.

    Uses ``exec-out screencap -p`` to avoid ``\\r\\n`` binary corruption
    that occurs with ``adb shell screencap -p``.

    Args:
        serial: Device serial number.
        transport: ADB transport instance.
    """

    def __init__(self, serial: str, transport: SubprocessTransport) -> None:
        self._serial = serial
        self._transport = transport

    async def capture_async(self) -> bytes:
        """Capture a screenshot and return raw PNG bytes.

        Returns:
            PNG image data as bytes.
        """
        result = await self._transport.execute(
            ["exec-out", "screencap", "-p"], serial=self._serial,
        )
        result.raise_on_error("screencap")
        return result.stdout

    async def capture_to_file_async(self, path: str) -> None:
        """Capture a screenshot and save to a local file.

        Args:
            path: Local file path to save the PNG.
        """
        data = await self.capture_async()
        with open(path, "wb") as f:
            f.write(data)

    async def capture_pil_async(self) -> object:
        """Capture a screenshot and return a PIL Image.

        Returns:
            PIL ``Image.Image`` object.

        Raises:
            ImportError: If Pillow is not installed.
        """
        import io

        from PIL import Image

        data = await self.capture_async()
        return Image.open(io.BytesIO(data))
