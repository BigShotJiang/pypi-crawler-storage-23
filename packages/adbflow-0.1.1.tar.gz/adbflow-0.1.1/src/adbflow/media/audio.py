"""Audio volume control."""

from __future__ import annotations

import re

from adbflow.core.transport import SubprocessTransport
from adbflow.utils.types import AudioStream

# Map AudioStream to the stream name in dumpsys audio output.
_STREAM_NAMES: dict[AudioStream, str] = {
    AudioStream.VOICE_CALL: "STREAM_VOICE_CALL",
    AudioStream.SYSTEM: "STREAM_SYSTEM",
    AudioStream.RING: "STREAM_RING",
    AudioStream.MUSIC: "STREAM_MUSIC",
    AudioStream.ALARM: "STREAM_ALARM",
    AudioStream.NOTIFICATION: "STREAM_NOTIFICATION",
}

# Map AudioStream to the settings key used by `settings put system`.
_SETTINGS_KEYS: dict[AudioStream, str] = {
    AudioStream.VOICE_CALL: "volume_voice",
    AudioStream.SYSTEM: "volume_system",
    AudioStream.RING: "volume_ring",
    AudioStream.MUSIC: "volume_music",
    AudioStream.ALARM: "volume_alarm",
    AudioStream.NOTIFICATION: "volume_notification",
}


class AudioManager:
    """Manages audio volume levels on a connected device.

    Uses ``dumpsys audio`` to read volume (works on all Android versions)
    and ``settings put system`` to set volume.

    Args:
        serial: Device serial number.
        transport: ADB transport instance.
    """

    def __init__(self, serial: str, transport: SubprocessTransport) -> None:
        self._serial = serial
        self._transport = transport

    async def get_volume_async(self, stream: AudioStream) -> int:
        """Get the current volume level for a stream.

        Args:
            stream: Audio stream type.

        Returns:
            Current volume level.
        """
        stream_name = _STREAM_NAMES.get(stream, f"STREAM_{stream.name}")
        result = await self._transport.execute_shell(
            f"dumpsys audio | grep -A 8 {stream_name}:",
            serial=self._serial,
        )
        output = result.output
        # Parse "streamVolume:N" from dumpsys audio
        match = re.search(r"streamVolume:\s*(\d+)", output)
        if match:
            return int(match.group(1))
        return 0

    async def set_volume_async(self, stream: AudioStream, level: int) -> None:
        """Set the volume level for a stream.

        Uses ``settings put system`` which works across Android versions.

        Args:
            stream: Audio stream type.
            level: Volume level to set.
        """
        key = _SETTINGS_KEYS.get(stream, f"volume_{stream.name.lower()}")
        result = await self._transport.execute_shell(
            f"settings put system {key} {level}",
            serial=self._serial,
        )
        result.raise_on_error(f"set volume {stream.name}")

    async def mute_async(self, stream: AudioStream) -> None:
        """Mute a specific audio stream.

        Args:
            stream: Audio stream type.
        """
        await self.set_volume_async(stream, 0)

    async def unmute_async(self, stream: AudioStream) -> None:
        """Unmute a specific audio stream (sets volume to a mid-level default).

        Args:
            stream: Audio stream type.
        """
        # Reasonable mid-level default — 7 out of typical max 15
        await self.set_volume_async(stream, 7)

    async def is_muted_async(self, stream: AudioStream) -> bool:
        """Check whether a stream is muted.

        Uses ``dumpsys audio`` Muted field, falling back to volume == 0.

        Args:
            stream: Audio stream type.

        Returns:
            True if the stream is muted.
        """
        stream_name = _STREAM_NAMES.get(stream, f"STREAM_{stream.name}")
        result = await self._transport.execute_shell(
            f"dumpsys audio | grep -A 3 {stream_name}:",
            serial=self._serial,
        )
        output = result.output
        # Parse "Muted: true/false" from dumpsys audio
        match = re.search(r"Muted:\s*(true|false)", output)
        if match:
            return match.group(1) == "true"
        return await self.get_volume_async(stream) == 0
