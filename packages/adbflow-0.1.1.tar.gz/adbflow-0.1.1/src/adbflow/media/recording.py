"""Screen recording management."""

from __future__ import annotations

from adbflow.core.transport import SubprocessTransport
from adbflow.utils.types import RecordingOptions


class ScreenRecorder:
    """Manages screen recording on a connected device.

    Args:
        serial: Device serial number.
        transport: ADB transport instance.
    """

    def __init__(self, serial: str, transport: SubprocessTransport) -> None:
        self._serial = serial
        self._transport = transport

    async def start_async(
        self,
        remote_path: str = "/sdcard/screenrecord.mp4",
        options: RecordingOptions | None = None,
    ) -> None:
        """Start screen recording in the background.

        Args:
            remote_path: Path on device to save the recording.
            options: Recording options (bitrate, resolution, etc.).
        """
        cmd = "screenrecord"
        if options:
            if options.bitrate is not None:
                cmd += f" --bit-rate {options.bitrate}"
            if options.width is not None and options.height is not None:
                cmd += f" --size {options.width}x{options.height}"
            if options.time_limit is not None:
                cmd += f" --time-limit {options.time_limit}"
            if options.rotate:
                cmd += " --rotate"
        cmd += f" {remote_path}"

        # Run in background on device (nohup + &)
        await self._transport.execute_shell(
            f"nohup {cmd} > /dev/null 2>&1 &", serial=self._serial,
        )

    async def stop_async(self) -> None:
        """Stop the current screen recording."""
        await self._transport.execute_shell(
            "pkill -f screenrecord || killall screenrecord",
            serial=self._serial,
        )

    async def pull_async(
        self,
        local_path: str,
        remote_path: str = "/sdcard/screenrecord.mp4",
    ) -> None:
        """Pull a recorded file from the device.

        Args:
            local_path: Local destination path.
            remote_path: Remote path of the recording.
        """
        result = await self._transport.execute(
            ["pull", remote_path, local_path], serial=self._serial,
        )
        result.raise_on_error(f"pull {remote_path}")

    async def is_recording_async(self) -> bool:
        """Check whether screen recording is in progress.

        Returns:
            True if a screenrecord process is running.
        """
        result = await self._transport.execute_shell(
            "pgrep -f screenrecord", serial=self._serial,
        )
        return result.success and bool(result.output.strip())
