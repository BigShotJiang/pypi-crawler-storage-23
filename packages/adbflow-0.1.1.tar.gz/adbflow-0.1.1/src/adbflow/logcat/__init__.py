"""Logcat streaming module."""

from adbflow.logcat.stream import LogcatManager

__all__ = ["LogcatManager"]
