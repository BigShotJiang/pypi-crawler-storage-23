"""Action recorder — record user actions for replay."""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

from adbflow.utils.types import ActionType, RecordedAction, TransportProtocol


class ActionRecorder:
    """Records user actions into a replayable sequence.

    Args:
        serial: Device serial number.
        transport: ADB transport implementation.
    """

    def __init__(self, serial: str, transport: TransportProtocol) -> None:
        self._serial = serial
        self._transport = transport
        self._actions: list[RecordedAction] = []

    @property
    def actions(self) -> list[RecordedAction]:
        """The recorded action sequence."""
        return list(self._actions)

    def record_tap(self, x: int, y: int) -> None:
        """Record a tap action.

        Args:
            x: X coordinate.
            y: Y coordinate.
        """
        self._actions.append(RecordedAction(
            action_type=ActionType.TAP,
            params={"x": x, "y": y},
            timestamp=time.monotonic(),
            description=f"Tap ({x}, {y})",
        ))

    def record_swipe(
        self, x1: int, y1: int, x2: int, y2: int, duration: int = 300,
    ) -> None:
        """Record a swipe action.

        Args:
            x1: Start X coordinate.
            y1: Start Y coordinate.
            x2: End X coordinate.
            y2: End Y coordinate.
            duration: Swipe duration in milliseconds.
        """
        self._actions.append(RecordedAction(
            action_type=ActionType.SWIPE,
            params={"x1": x1, "y1": y1, "x2": x2, "y2": y2, "duration": duration},
            timestamp=time.monotonic(),
            description=f"Swipe ({x1},{y1}) -> ({x2},{y2})",
        ))

    def record_key(self, keycode: int) -> None:
        """Record a key event action.

        Args:
            keycode: Android key code.
        """
        self._actions.append(RecordedAction(
            action_type=ActionType.KEY,
            params={"keycode": keycode},
            timestamp=time.monotonic(),
            description=f"Key {keycode}",
        ))

    def record_text(self, text: str) -> None:
        """Record a text input action.

        Args:
            text: Text to input.
        """
        self._actions.append(RecordedAction(
            action_type=ActionType.TEXT,
            params={"text": text},
            timestamp=time.monotonic(),
            description=f"Text '{text}'",
        ))

    def record_wait(self, seconds: float) -> None:
        """Record a wait action.

        Args:
            seconds: Seconds to wait.
        """
        self._actions.append(RecordedAction(
            action_type=ActionType.WAIT,
            params={"seconds": seconds},
            timestamp=time.monotonic(),
            description=f"Wait {seconds}s",
        ))

    def record_shell(self, command: str) -> None:
        """Record a shell command action.

        Args:
            command: Shell command string.
        """
        self._actions.append(RecordedAction(
            action_type=ActionType.SHELL,
            params={"command": command},
            timestamp=time.monotonic(),
            description=f"Shell: {command}",
        ))

    def clear(self) -> None:
        """Reset recorded actions."""
        self._actions.clear()

    def to_json(self) -> str:
        """Serialize recorded actions to JSON.

        Returns:
            JSON string representation.
        """
        data = [
            {
                "action_type": a.action_type.value,
                "params": a.params,
                "timestamp": a.timestamp,
                "description": a.description,
            }
            for a in self._actions
        ]
        return json.dumps(data, indent=2)

    @classmethod
    def from_json(
        cls, json_str: str, serial: str = "", transport: TransportProtocol | None = None,
    ) -> ActionRecorder:
        """Deserialize actions from JSON.

        Args:
            json_str: JSON string to parse.
            serial: Device serial (optional for deserialization).
            transport: ADB transport (optional for deserialization).

        Returns:
            A new ``ActionRecorder`` with the deserialized actions.
        """
        # Use a dummy transport for deserialization-only use cases
        recorder = cls.__new__(cls)
        recorder._serial = serial
        recorder._transport = transport  # type: ignore[assignment]
        recorder._actions = []

        data: list[dict[str, Any]] = json.loads(json_str)
        for item in data:
            recorder._actions.append(RecordedAction(
                action_type=ActionType(item["action_type"]),
                params=item["params"],
                timestamp=float(item["timestamp"]),
                description=item["description"],
            ))
        return recorder

    def save(self, path: str | Path) -> None:
        """Write recorded actions to a JSON file.

        Args:
            path: File path to save to.
        """
        Path(path).write_text(self.to_json())

    @classmethod
    def load(
        cls, path: str | Path, serial: str = "", transport: TransportProtocol | None = None,
    ) -> ActionRecorder:
        """Load recorded actions from a JSON file.

        Args:
            path: File path to load from.
            serial: Device serial.
            transport: ADB transport.

        Returns:
            A new ``ActionRecorder`` with the loaded actions.
        """
        json_str = Path(path).read_text()
        return cls.from_json(json_str, serial=serial, transport=transport)
