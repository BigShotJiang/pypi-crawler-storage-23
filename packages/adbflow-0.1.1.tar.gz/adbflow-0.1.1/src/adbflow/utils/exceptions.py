"""ADBFlow exception hierarchy."""

from __future__ import annotations


class ADBFlowError(Exception):
    """Base exception for all ADBFlow errors."""


class ADBError(ADBFlowError):
    """Raised when an ADB command fails."""

    def __init__(
        self,
        command: str | list[str],
        stderr: str = "",
        return_code: int = 1,
    ) -> None:
        self.command = command if isinstance(command, str) else " ".join(command)
        self.stderr = stderr
        self.return_code = return_code
        super().__init__(
            f"ADB command failed (rc={return_code}): {self.command}"
            + (f"\nstderr: {stderr}" if stderr else "")
        )


class DeviceNotFoundError(ADBFlowError):
    """Raised when the target device is not found."""

    def __init__(self, serial: str = "") -> None:
        self.serial = serial
        msg = f"Device not found: {serial}" if serial else "No device found"
        super().__init__(msg)


class ElementNotFoundError(ADBFlowError):
    """Raised when a UI element is not found."""


class ADBTimeoutError(ADBFlowError):
    """Raised when an ADB operation times out."""

    def __init__(self, timeout: float, operation: str = "") -> None:
        self.timeout = timeout
        self.operation = operation
        msg = f"Operation timed out after {timeout}s"
        if operation:
            msg += f": {operation}"
        super().__init__(msg)


class ADBConnectionError(ADBFlowError):
    """Raised when connection to ADB or a device fails."""


class CommandBuildError(ADBFlowError):
    """Raised when building an ADB command fails."""


class BinaryNotFoundError(ADBFlowError):
    """Raised when the ADB binary cannot be found."""

    def __init__(self, searched_paths: list[str] | None = None) -> None:
        self.searched_paths = searched_paths or []
        paths_str = ", ".join(self.searched_paths) if self.searched_paths else "none"
        super().__init__(f"ADB binary not found. Searched: {paths_str}")


class FileOperationError(ADBFlowError):
    """Raised when a file operation fails."""

    def __init__(self, operation: str = "", path: str = "", detail: str = "") -> None:
        self.operation = operation
        self.path = path
        self.detail = detail
        msg = f"File operation failed: {operation}"
        if path:
            msg += f" ({path})"
        if detail:
            msg += f" — {detail}"
        super().__init__(msg)


class InstallError(ADBFlowError):
    """Raised when APK installation fails."""

    def __init__(self, apk_path: str = "", detail: str = "") -> None:
        self.apk_path = apk_path
        self.detail = detail
        msg = f"Install failed: {apk_path}" if apk_path else "Install failed"
        if detail:
            msg += f" — {detail}"
        super().__init__(msg)


class PackageNotFoundError(ADBFlowError):
    """Raised when a package is not found on the device."""

    def __init__(self, package: str = "") -> None:
        self.package = package
        msg = f"Package not found: {package}" if package else "Package not found"
        super().__init__(msg)


class VisionError(ADBFlowError):
    """Raised when a vision operation fails (template not found or OpenCV error)."""


class OCRError(ADBFlowError):
    """Raised when an OCR operation fails (engine error or missing dependency)."""


class WaitTimeoutError(ADBFlowError):
    """Raised when a condition is not met within the timeout period."""

    def __init__(
        self,
        timeout: float,
        condition_name: str = "",
        elapsed: float = 0.0,
    ) -> None:
        self.timeout = timeout
        self.condition_name = condition_name
        self.elapsed = elapsed
        msg = f"Condition not met within {timeout}s"
        if condition_name:
            msg += f": {condition_name}"
        super().__init__(msg)
