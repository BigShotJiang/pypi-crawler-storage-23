"""Types, enums, protocols, and data structures for ADBFlow."""

from __future__ import annotations

import enum
from collections.abc import Callable, Coroutine
from dataclasses import dataclass, field
from typing import Any, Protocol, TypeAlias, runtime_checkable

from adbflow.utils.exceptions import ADBError
from adbflow.utils.geometry import Point, Rect

# ---------------------------------------------------------------------------
# Type aliases
# ---------------------------------------------------------------------------

Serial = str
ProgressCallback = Callable[[int, int], None]
AsyncProgressCallback = Callable[[int, int], Coroutine[Any, Any, None]]


# ---------------------------------------------------------------------------
# Result dataclass
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Result:
    """Represents the result of an ADB command execution."""

    stdout: bytes
    stderr: bytes
    return_code: int
    duration_ms: float

    @property
    def output(self) -> str:
        """Decoded stdout as string."""
        return self.stdout.decode("utf-8", errors="replace").strip()

    @property
    def error(self) -> str:
        """Decoded stderr as string."""
        return self.stderr.decode("utf-8", errors="replace").strip()

    @property
    def success(self) -> bool:
        """Whether the command completed successfully."""
        return self.return_code == 0

    def raise_on_error(self, command: str | list[str] = "") -> None:
        """Raise ADBError if the command failed."""
        if not self.success:
            cmd = command if isinstance(command, str) else " ".join(command)
            raise ADBError(
                command=cmd or "<unknown>",
                stderr=self.error,
                return_code=self.return_code,
            )


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class KeyCode(enum.IntEnum):
    """Android key codes."""

    HOME = 3
    BACK = 4
    CALL = 5
    ENDCALL = 6
    DPAD_UP = 19
    DPAD_DOWN = 20
    DPAD_LEFT = 21
    DPAD_RIGHT = 22
    DPAD_CENTER = 23
    VOLUME_UP = 24
    VOLUME_DOWN = 25
    POWER = 26
    CAMERA = 27
    CLEAR = 28
    ENTER = 66
    DELETE = 67
    MENU = 82
    SEARCH = 84
    MEDIA_PLAY_PAUSE = 85
    MEDIA_STOP = 86
    MEDIA_NEXT = 87
    MEDIA_PREVIOUS = 88
    TAB = 61
    SPACE = 62
    ESCAPE = 111
    APP_SWITCH = 187
    WAKEUP = 224
    SLEEP = 223
    BRIGHTNESS_UP = 221
    BRIGHTNESS_DOWN = 220


class SwipeDirection(enum.Enum):
    """Swipe direction."""

    UP = "up"
    DOWN = "down"
    LEFT = "left"
    RIGHT = "right"


class Orientation(enum.IntEnum):
    """Screen orientation."""

    PORTRAIT = 0
    LANDSCAPE = 1
    REVERSE_PORTRAIT = 2
    REVERSE_LANDSCAPE = 3


class InstallFlag(enum.Enum):
    """APK install flags."""

    REPLACE = "-r"
    TEST = "-t"
    DOWNGRADE = "-d"
    GRANT_PERMISSIONS = "-g"
    INSTANT = "--instant"


class DeviceState(enum.Enum):
    """ADB device state."""

    DEVICE = "device"
    OFFLINE = "offline"
    UNAUTHORIZED = "unauthorized"
    NO_PERMISSIONS = "no permissions"
    RECOVERY = "recovery"
    SIDELOAD = "sideload"
    BOOTLOADER = "bootloader"


class ConnectionType(enum.Enum):
    """Connection type."""

    USB = "usb"
    TCP = "tcp"


class RebootMode(enum.Enum):
    """Reboot modes."""

    SYSTEM = ""
    RECOVERY = "recovery"
    BOOTLOADER = "bootloader"
    SIDELOAD = "sideload"


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Size:
    """Screen size in pixels."""

    width: int
    height: int

    def __str__(self) -> str:
        return f"{self.width}x{self.height}"


@dataclass(frozen=True)
class BatteryInfo:
    """Battery status information."""

    level: int
    powered: bool
    status: str
    temperature: float


@dataclass(frozen=True)
class DeviceListEntry:
    """Entry from `adb devices -l` output."""

    serial: str
    state: DeviceState
    model: str = ""
    device: str = ""
    transport_id: str = ""


# ---------------------------------------------------------------------------
# Protocols
# ---------------------------------------------------------------------------


@runtime_checkable
class Condition(Protocol):
    """Protocol for wait conditions.

    Any async callable with a ``name`` property qualifies.
    """

    @property
    def name(self) -> str:
        """Human-readable description of this condition."""
        ...

    async def __call__(self) -> bool:
        """Evaluate the condition. Returns True when met."""
        ...


@runtime_checkable
class TransportProtocol(Protocol):
    """Protocol for ADB transport implementations."""

    async def execute(
        self,
        args: list[str],
        serial: str | None = None,
        timeout: float | None = None,
    ) -> Result:
        """Execute an ADB command and return the result."""
        ...

    async def execute_shell(
        self,
        command: str,
        serial: str | None = None,
        timeout: float | None = None,
    ) -> Result:
        """Execute an ADB shell command."""
        ...


# ---------------------------------------------------------------------------
# File operation types
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class FileInfo:
    """Metadata for a file on the device."""

    name: str
    size: int
    permissions: str
    modified: str
    is_dir: bool
    owner: str = ""
    group: str = ""
    path: str = ""


class FileChangeType(enum.Enum):
    """Type of file change detected by a watcher."""

    CREATED = "created"
    MODIFIED = "modified"
    DELETED = "deleted"


@dataclass(frozen=True)
class FileChange:
    """A detected file change."""

    path: str
    change_type: FileChangeType
    file_info: FileInfo | None = None


@dataclass(frozen=True)
class SyncResult:
    """Result of a directory sync operation."""

    transferred: int = 0
    skipped: int = 0
    deleted: int = 0
    errors: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# App management types
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class PackageInfo:
    """Information about an installed package."""

    package_name: str
    version_code: str = ""
    version_name: str = ""
    install_time: str = ""
    update_time: str = ""
    apk_path: str = ""
    data_size: int = 0
    is_system: bool = False
    is_enabled: bool = True


class PackageFilter(enum.Enum):
    """Filter for listing packages."""

    ALL = ""
    SYSTEM = "-s"
    THIRD_PARTY = "-3"
    DISABLED = "-d"
    ENABLED = "-e"


@dataclass(frozen=True)
class PermissionInfo:
    """Information about an app permission."""

    name: str
    granted: bool


class IntentFlag(enum.IntEnum):
    """Common Android intent flags."""

    FLAG_ACTIVITY_NEW_TASK = 0x10000000
    FLAG_ACTIVITY_CLEAR_TOP = 0x04000000
    FLAG_ACTIVITY_SINGLE_TOP = 0x20000000
    FLAG_ACTIVITY_NO_HISTORY = 0x40000000


# ---------------------------------------------------------------------------
# Media types
# ---------------------------------------------------------------------------


class AudioStream(enum.IntEnum):
    """Android audio stream types."""

    VOICE_CALL = 0
    SYSTEM = 1
    RING = 2
    MUSIC = 3
    ALARM = 4
    NOTIFICATION = 5


@dataclass(frozen=True)
class RecordingOptions:
    """Options for screen recording."""

    bitrate: int | None = None
    width: int | None = None
    height: int | None = None
    time_limit: int | None = None
    rotate: bool = False


# ---------------------------------------------------------------------------
# Logcat types
# ---------------------------------------------------------------------------


class LogLevel(enum.Enum):
    """Logcat log levels."""

    VERBOSE = "V"
    DEBUG = "D"
    INFO = "I"
    WARNING = "W"
    ERROR = "E"
    FATAL = "F"
    SILENT = "S"


@dataclass(frozen=True)
class LogEntry:
    """A parsed logcat entry."""

    timestamp: str
    pid: str
    tid: str
    level: LogLevel
    tag: str
    message: str


@dataclass(frozen=True)
class CrashInfo:
    """Information about a detected crash."""

    package: str
    pid: str
    signal: str
    stacktrace: str
    timestamp: str


CrashCallback: TypeAlias = Callable[[CrashInfo], None]
AsyncCrashCallback: TypeAlias = Callable[[CrashInfo], Coroutine[Any, Any, None]]


# ---------------------------------------------------------------------------
# Network types
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ForwardRule:
    """An ADB port forwarding rule."""

    serial: str
    local: str
    remote: str


@dataclass(frozen=True)
class WifiInfo:
    """WiFi connection information."""

    ssid: str
    ip_address: str
    link_speed: int
    rssi: int


@dataclass(frozen=True)
class ProxyConfig:
    """HTTP proxy configuration."""

    host: str
    port: int
    exclude: str = ""


# ---------------------------------------------------------------------------
# Vision types
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class MatchResult:
    """Result of a template match operation."""

    location: Rect
    confidence: float
    center: Point


# ---------------------------------------------------------------------------
# OCR types
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class OCRResult:
    """Result of an OCR recognition operation."""

    text: str
    bounds: Rect
    confidence: float


# ---------------------------------------------------------------------------
# Notification types
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Notification:
    """A parsed notification from the device."""

    key: str
    package: str
    title: str
    text: str
    posted_time: str
    tag: str


# ---------------------------------------------------------------------------
# Accessibility types
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class AccessibilityService:
    """An accessibility service installed on the device."""

    component: str
    enabled: bool
    description: str


# ---------------------------------------------------------------------------
# Recorder types
# ---------------------------------------------------------------------------


class ActionType(enum.Enum):
    """Type of recorded action."""

    TAP = "tap"
    SWIPE = "swipe"
    KEY = "key"
    TEXT = "text"
    WAIT = "wait"
    SHELL = "shell"


@dataclass(frozen=True)
class RecordedAction:
    """A single recorded user action."""

    action_type: ActionType
    params: dict[str, Any]
    timestamp: float
    description: str


# ---------------------------------------------------------------------------
# Flow types
# ---------------------------------------------------------------------------


class ErrorStrategy(enum.Enum):
    """Error handling strategy for flow steps."""

    STOP = "stop"
    SKIP = "skip"
    RETRY = "retry"
