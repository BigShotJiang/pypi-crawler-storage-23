"""File operations on an Android device."""

from __future__ import annotations

from adbflow.core.transport import SubprocessTransport
from adbflow.utils.exceptions import FileOperationError
from adbflow.utils.parsers import parse_ls_la, parse_stat
from adbflow.utils.types import FileInfo, ProgressCallback


class FileManager:
    """Manages file operations on a connected device.

    Args:
        serial: Device serial number.
        transport: ADB transport instance.
    """

    def __init__(self, serial: str, transport: SubprocessTransport) -> None:
        self._serial = serial
        self._transport = transport

    async def push_async(
        self,
        local: str,
        remote: str,
        progress: ProgressCallback | None = None,
    ) -> None:
        """Push a local file to the device.

        Args:
            local: Local file path.
            remote: Remote file path on device.
            progress: Optional progress callback ``(transferred, total)``.
        """
        if progress:
            progress(0, 1)
        result = await self._transport.execute(
            ["push", local, remote], serial=self._serial,
        )
        result.raise_on_error(f"push {local} {remote}")
        if progress:
            progress(1, 1)

    async def pull_async(
        self,
        remote: str,
        local: str,
        progress: ProgressCallback | None = None,
    ) -> None:
        """Pull a file from the device.

        Args:
            remote: Remote file path on device.
            local: Local destination path.
            progress: Optional progress callback ``(transferred, total)``.
        """
        if progress:
            progress(0, 1)
        result = await self._transport.execute(
            ["pull", remote, local], serial=self._serial,
        )
        result.raise_on_error(f"pull {remote} {local}")
        if progress:
            progress(1, 1)

    async def ls_async(self, path: str) -> list[FileInfo]:
        """List files in a directory.

        Args:
            path: Directory path on device.

        Returns:
            List of FileInfo entries.
        """
        result = await self._transport.execute_shell(
            f"ls -la {path}", serial=self._serial,
        )
        result.raise_on_error(f"ls -la {path}")
        return parse_ls_la(result.output)

    async def stat_async(self, path: str) -> FileInfo | None:
        """Get detailed file information.

        Args:
            path: File path on device.

        Returns:
            FileInfo or None if file does not exist.
        """
        result = await self._transport.execute_shell(
            f"stat {path}", serial=self._serial,
        )
        if not result.success:
            return None
        return parse_stat(result.output)

    async def exists_async(self, path: str) -> bool:
        """Check whether a file or directory exists.

        Args:
            path: Path on device.
        """
        result = await self._transport.execute_shell(
            f"[ -e {path} ] && echo 1 || echo 0", serial=self._serial,
        )
        return result.output.strip() == "1"

    async def mkdir_async(self, path: str, parents: bool = True) -> None:
        """Create a directory on the device.

        Args:
            path: Directory path.
            parents: If True, create parent directories as needed.
        """
        flag = "-p " if parents else ""
        result = await self._transport.execute_shell(
            f"mkdir {flag}{path}", serial=self._serial,
        )
        result.raise_on_error(f"mkdir {path}")

    async def rm_async(
        self, path: str, recursive: bool = False, force: bool = False,
    ) -> None:
        """Remove a file or directory.

        Args:
            path: Path to remove.
            recursive: Remove directories recursively.
            force: Force removal without prompts.
        """
        flags = ""
        if recursive:
            flags += "r"
        if force:
            flags += "f"
        flag_str = f"-{flags} " if flags else ""
        result = await self._transport.execute_shell(
            f"rm {flag_str}{path}", serial=self._serial,
        )
        result.raise_on_error(f"rm {path}")

    async def mv_async(self, src: str, dst: str) -> None:
        """Move or rename a file.

        Args:
            src: Source path.
            dst: Destination path.
        """
        result = await self._transport.execute_shell(
            f"mv {src} {dst}", serial=self._serial,
        )
        result.raise_on_error(f"mv {src} {dst}")

    async def cp_async(self, src: str, dst: str, recursive: bool = False) -> None:
        """Copy a file or directory.

        Args:
            src: Source path.
            dst: Destination path.
            recursive: Copy directories recursively.
        """
        flag = "-r " if recursive else ""
        result = await self._transport.execute_shell(
            f"cp {flag}{src} {dst}", serial=self._serial,
        )
        result.raise_on_error(f"cp {src} {dst}")

    async def cat_async(self, path: str) -> str:
        """Read file contents.

        Args:
            path: File path on device.

        Returns:
            File content as string.
        """
        result = await self._transport.execute_shell(
            f"cat {path}", serial=self._serial,
        )
        result.raise_on_error(f"cat {path}")
        return result.output

    async def head_async(self, path: str, lines: int = 10) -> str:
        """Read the first N lines of a file.

        Args:
            path: File path on device.
            lines: Number of lines to read.

        Returns:
            File content as string.
        """
        result = await self._transport.execute_shell(
            f"head -n {lines} {path}", serial=self._serial,
        )
        result.raise_on_error(f"head {path}")
        return result.output

    async def tail_async(self, path: str, lines: int = 10) -> str:
        """Read the last N lines of a file.

        Args:
            path: File path on device.
            lines: Number of lines to read.

        Returns:
            File content as string.
        """
        result = await self._transport.execute_shell(
            f"tail -n {lines} {path}", serial=self._serial,
        )
        result.raise_on_error(f"tail {path}")
        return result.output

    async def backup_async(
        self,
        output: str,
        packages: list[str] | None = None,
        apk: bool = False,
        shared: bool = False,
    ) -> None:
        """Create a device backup.

        Args:
            output: Local output path for the backup file.
            packages: Specific packages to back up.
            apk: Include APK files in backup.
            shared: Include shared storage.

        Raises:
            FileOperationError: If backup fails.
        """
        args = ["backup", "-f", output]
        if apk:
            args.append("-apk")
        if shared:
            args.append("-shared")
        if packages:
            args.extend(packages)
        else:
            args.append("-all")
        result = await self._transport.execute(args, serial=self._serial)
        if not result.success:
            raise FileOperationError("backup", output, result.error)

    async def restore_async(self, backup_path: str) -> None:
        """Restore a device backup.

        Args:
            backup_path: Local path to the backup file.

        Raises:
            FileOperationError: If restore fails.
        """
        result = await self._transport.execute(
            ["restore", backup_path], serial=self._serial,
        )
        if not result.success:
            raise FileOperationError("restore", backup_path, result.error)
