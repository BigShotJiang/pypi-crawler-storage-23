# Gestures

The `GestureManager` provides methods for touch input — tap, swipe, drag, pinch, text entry, and key events. All gestures use ADB's `input` shell commands.

Access it via `device.gestures`.

## Tap

```python
from adbflow.utils.geometry import Point

async def tap_examples(device):
    # Tap at coordinates
    await device.gestures.tap_async(500, 1000)

    # Tap a Point
    await device.gestures.tap_async(Point(500, 1000))

    # Long tap
    await device.gestures.long_tap_async(Point(500, 1000), duration_ms=2000)
```

## Swipe

```python
from adbflow.utils.geometry import Point
from adbflow.utils.types import SwipeDirection

async def swipe_examples(device):
    # Swipe between two points
    await device.gestures.swipe_async(
        Point(500, 1500), Point(500, 500),
        duration_ms=300
    )

    # Swipe by direction (from screen center)
    await device.gestures.swipe_direction_async(SwipeDirection.UP)
    await device.gestures.swipe_direction_async(SwipeDirection.DOWN)
    await device.gestures.swipe_direction_async(SwipeDirection.LEFT)
    await device.gestures.swipe_direction_async(SwipeDirection.RIGHT)

    # Custom distance and speed
    await device.gestures.swipe_direction_async(
        SwipeDirection.UP,
        distance=800,
        duration_ms=500
    )

    # Swipe from a specific start point
    await device.gestures.swipe_direction_async(
        SwipeDirection.LEFT,
        start=Point(900, 500),
        distance=600
    )
```

## Drag

Drag is a slow swipe, used for moving elements:

```python
async def drag_example(device):
    await device.gestures.drag_async(
        Point(200, 500), Point(800, 500),
        duration_ms=1000
    )
```

## Pinch

Pinch gestures for zoom in/out:

```python
async def pinch_examples(device):
    center = Point(540, 960)

    # Zoom out (pinch in)
    await device.gestures.pinch_in_async(center, distance=200, duration_ms=500)

    # Zoom in (pinch out)
    await device.gestures.pinch_out_async(center, distance=200, duration_ms=500)
```

## Text Input

```python
async def text_example(device):
    # Type text (requires a focused input field)
    await device.gestures.text_async("Hello, world!")
```

!!! note
    `text_async` uses ADB's `input text` command, which has limitations with special characters. For complex text, consider using the clipboard or an input method.

## Key Events

```python
from adbflow.utils.types import KeyCode

async def key_examples(device):
    # Common keys
    await device.gestures.key_async(KeyCode.HOME)
    await device.gestures.key_async(KeyCode.BACK)
    await device.gestures.key_async(KeyCode.ENTER)
    await device.gestures.key_async(KeyCode.VOLUME_UP)
    await device.gestures.key_async(KeyCode.VOLUME_DOWN)
    await device.gestures.key_async(KeyCode.POWER)

    # Or use raw keycodes
    await device.gestures.key_async(66)  # ENTER

    # Also available directly on device
    await device.keyevent_async(KeyCode.HOME)
```

## Tips

- **Duration** controls gesture speed. Higher values = slower gestures. Use longer durations for drag operations to avoid being interpreted as swipes.
- **Coordinate system** starts at (0, 0) in the top-left corner. Get screen size with `device.info.screen_size_async()` to calculate relative positions.
- **Swipe direction** defaults to starting from the screen center. Override with the `start` parameter for lists or specific areas.
