# Recorder & Playback

Record a sequence of actions, save them to a file, and replay them later. Useful for test automation, demos, and repeatable workflows.

## Recording Actions

```python
async def record_example(device):
    recorder = device.recorder

    # Record individual actions
    recorder.record_tap(500, 1000)
    recorder.record_wait(1.0)
    recorder.record_swipe(500, 1500, 500, 500, duration=300)
    recorder.record_text("hello")
    recorder.record_key(66)  # ENTER
    recorder.record_shell("input keyevent BACK")
    recorder.record_wait(0.5)

    # View recorded actions
    for action in recorder.actions:
        print(action)
```

## Save & Load

```python
async def save_load_example(device):
    recorder = device.recorder

    # Record some actions...
    recorder.record_tap(500, 1000)
    recorder.record_wait(1.0)
    recorder.record_text("test")

    # Save to JSON file
    recorder.save("/path/to/recording.json")

    # Save as JSON string
    json_str = recorder.to_json()

    # Load from file
    from adbflow.recorder import ActionRecorder
    loaded = ActionRecorder.load(
        "/path/to/recording.json",
        serial=device.serial,
        transport=device.transport
    )

    # Load from JSON string
    loaded = ActionRecorder.from_json(
        json_str,
        serial=device.serial,
        transport=device.transport
    )

    # Clear recorded actions
    recorder.clear()
```

## Playback

```python
from adbflow.recorder import ActionPlayer

async def playback_example(device):
    recorder = device.recorder
    recorder.record_tap(500, 1000)
    recorder.record_wait(0.5)
    recorder.record_text("hello")

    player = ActionPlayer(device.transport, device.serial)

    # Play once
    await player.play_async(recorder.actions)

    # Play at half speed (slower)
    await player.play_async(recorder.actions, speed=0.5)

    # Play at double speed (faster)
    await player.play_async(recorder.actions, speed=2.0)

    # Loop playback
    await player.play_loop_async(recorder.actions, count=3)

    # Loop with speed adjustment
    await player.play_loop_async(recorder.actions, count=5, speed=1.5)
```

## CLI

Record and play from the command line:

```bash
# Record actions interactively
adbflow record -o actions.json

# Play back a recording
adbflow play actions.json

# Play with speed multiplier
adbflow play actions.json --speed 2.0
```

## Tips

- `record_wait` inserts deliberate pauses between actions. Without them, playback may be too fast for the UI to keep up.
- The `speed` parameter in playback scales wait durations — `2.0` halves all waits, `0.5` doubles them.
- Recordings are plain JSON, so you can edit them manually or generate them programmatically.
- Combine recordings with watchers to handle unexpected dialogs during playback.
