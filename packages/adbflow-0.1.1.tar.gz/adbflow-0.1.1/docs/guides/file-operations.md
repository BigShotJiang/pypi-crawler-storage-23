# File Operations

The `FileManager` provides file system operations on the device — push, pull, browse, copy, move, and more. Access it via `device.files`.

## Push & Pull

```python
async def transfer_examples(device):
    # Push a file to the device
    await device.files.push_async("/local/file.txt", "/sdcard/file.txt")

    # Pull a file from the device
    await device.files.pull_async("/sdcard/file.txt", "/local/file.txt")

    # With progress callback
    def on_progress(transferred, total):
        pct = (transferred / total * 100) if total else 0
        print(f"{pct:.1f}%")

    await device.files.push_async("/local/big.zip", "/sdcard/big.zip", progress=on_progress)
    await device.files.pull_async("/sdcard/big.zip", "/local/big.zip", progress=on_progress)
```

## Browse Files

```python
async def browse_examples(device):
    # List directory contents
    files = await device.files.ls_async("/sdcard/")
    for f in files:
        print(f"{f.name}  {f.size}  {f.is_directory}")

    # Stat a single file
    info = await device.files.stat_async("/sdcard/file.txt")
    if info:
        print(f"Size: {info.size}")

    # Check if a path exists
    exists = await device.files.exists_async("/sdcard/photos/")
```

## Read File Contents

```python
async def read_examples(device):
    # Read entire file
    content = await device.files.cat_async("/sdcard/config.txt")

    # Read first 10 lines
    head = await device.files.head_async("/sdcard/log.txt", lines=10)

    # Read last 10 lines
    tail = await device.files.tail_async("/sdcard/log.txt", lines=10)
```

## Create, Move, Copy, Delete

```python
async def fs_examples(device):
    # Create directory (parents=True by default)
    await device.files.mkdir_async("/sdcard/my_app/data")

    # Copy
    await device.files.cp_async("/sdcard/file.txt", "/sdcard/backup/file.txt")
    await device.files.cp_async("/sdcard/photos/", "/sdcard/backup/photos/", recursive=True)

    # Move / rename
    await device.files.mv_async("/sdcard/old_name.txt", "/sdcard/new_name.txt")

    # Delete
    await device.files.rm_async("/sdcard/temp.txt")
    await device.files.rm_async("/sdcard/temp_dir/", recursive=True, force=True)
```

## Directory Sync

Synchronize directories between host and device using checksum-based diffing:

```python
from adbflow.files import DirectorySync

async def sync_example(device):
    sync = DirectorySync(device.transport, device.serial)

    # Push local directory to device (only changed files)
    result = await sync.sync_async(
        "/local/project/assets/",
        "/sdcard/assets/",
        direction="push"
    )
    print(f"Transferred: {result.transferred}, Skipped: {result.skipped}")

    # Pull device directory to local
    result = await sync.sync_async(
        "/local/backup/",
        "/sdcard/data/",
        direction="pull"
    )

    # Delete extra files on destination
    result = await sync.sync_async(
        "/local/assets/",
        "/sdcard/assets/",
        direction="push",
        delete_extra=True
    )
```

## File Watcher

Watch a directory for changes:

```python
from adbflow.files import FileWatcher

async def watch_example(device):
    watcher = FileWatcher(device.transport, device.serial)

    async for change in watcher.watch_async("/sdcard/Download/", interval=2.0):
        print(f"{change.change_type}: {change.path}")
        # FileChangeType.CREATED, MODIFIED, or DELETED
```

## Backup & Restore

```python
async def backup_example(device):
    # Full backup
    await device.files.backup_async("/local/backup.ab")

    # Backup specific packages with APK
    await device.files.backup_async(
        "/local/backup.ab",
        packages=["com.example.app"],
        apk=True,
        shared=True
    )

    # Restore
    await device.files.restore_async("/local/backup.ab")
```
