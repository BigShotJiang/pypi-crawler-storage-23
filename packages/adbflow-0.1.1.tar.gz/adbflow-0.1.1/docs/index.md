# adbflow

**Async-first, type-safe Python package for Android device automation via ADB.**

adbflow gives you a clean, modern Python API for everything you'd do with `adb` — UI automation, gestures, app management, file operations, screen capture, and more. Built on `asyncio` with full type hints and a fluent interface.

## Features

- **Async-first** — every operation is `async/await` with sync wrappers available
- **Type-safe** — full type hints, passes `mypy --strict`
- **UI automation** — find elements, tap, type text, wait for conditions
- **Gestures** — tap, swipe, drag, pinch, multi-touch
- **App management** — install, launch, stop, permissions, intents
- **File operations** — push, pull, ls, sync directories
- **Screen capture** — screenshots (bytes, PIL, file), screen recording
- **Wait engine** — composable conditions with `AllOf`, `AnyOf`, `Not`
- **Vision & OCR** — template matching, color detection, text recognition
- **Watchers** — auto-dismiss dialogs, background UI monitors
- **Recorder** — record and replay action sequences
- **Flow engine** — build multi-step automation workflows
- **Multi-device** — parallel execution across device pools
- **Logcat** — stream, filter, and capture logs
- **Network** — WiFi, mobile data, airplane mode, port forwarding

## Quick Example

```python
import asyncio
from adbflow import ADB

async def main():
    adb = ADB()
    device = await adb.device_async()

    # Shell commands
    output = await device.shell_async("getprop ro.product.model")
    print(f"Device: {output}")

    # UI automation
    element = await device.ui.find_async(
        Selector().text("Settings").clickable()
    )
    if element:
        await element.tap_async()

    # Wait for a condition
    await device.wait_for_text_async("Display", timeout=5.0)

    # Gestures
    await device.gestures.swipe_direction_async(SwipeDirection.UP)

    # Screenshot
    png_bytes = await device.screenshot_async()

asyncio.run(main())
```

## Installation

```bash
pip install adbflow
```

With optional extras:

```bash
pip install adbflow[vision]   # template matching, color detection
pip install adbflow[ocr]      # text recognition (EasyOCR)
pip install adbflow[all]      # everything
```

See the [Installation guide](getting-started/installation.md) for details.

## Requirements

- Python 3.10+
- ADB installed and on `PATH` (or specify path explicitly)
- An Android device connected via USB or TCP/IP
