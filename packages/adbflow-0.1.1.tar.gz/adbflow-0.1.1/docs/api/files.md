# Files

## FileManager

`adbflow.files.operations.FileManager`

File operations on the device. Access via `device.files`.

### Methods

| Method | Parameters | Returns | Description |
| ------ | ---------- | ------- | ----------- |
| `push_async` | `local, remote, progress=None` | `None` | Push file to device |
| `pull_async` | `remote, local, progress=None` | `None` | Pull file from device |
| `ls_async` | `path: str` | `list[FileInfo]` | List directory contents |
| `stat_async` | `path: str` | `FileInfo \| None` | Get file info |
| `exists_async` | `path: str` | `bool` | Check if path exists |
| `mkdir_async` | `path, parents=True` | `None` | Create directory |
| `rm_async` | `path, recursive=False, force=False` | `None` | Delete file/directory |
| `mv_async` | `src, dst` | `None` | Move/rename |
| `cp_async` | `src, dst, recursive=False` | `None` | Copy |
| `cat_async` | `path: str` | `str` | Read file contents |
| `head_async` | `path, lines=10` | `str` | Read first N lines |
| `tail_async` | `path, lines=10` | `str` | Read last N lines |
| `backup_async` | `output, packages=None, apk=False, shared=False` | `None` | Create backup |
| `restore_async` | `backup_path: str` | `None` | Restore from backup |

## DirectorySync

`adbflow.files.sync.DirectorySync`

Synchronize directories using checksum-based diffing.

### Methods

| Method | Parameters | Returns | Description |
| ------ | ---------- | ------- | ----------- |
| `sync_async` | `local_dir, remote_dir, direction="push", delete_extra=False, progress=None` | `SyncResult` | Sync directories |

`direction` is `"push"` (local → device) or `"pull"` (device → local).

### Example

```python
from adbflow.files import DirectorySync

sync = DirectorySync(device.transport, device.serial)
result = await sync.sync_async("/local/assets/", "/sdcard/assets/", direction="push")
print(f"Transferred: {result.transferred}, Skipped: {result.skipped}")
```

## FileWatcher

`adbflow.files.watcher.FileWatcher`

Watch a directory for file changes.

### Methods

| Method | Parameters | Returns | Description |
| ------ | ---------- | ------- | ----------- |
| `watch_async` | `path, interval=2.0` | `AsyncIterator[FileChange]` | Watch for changes |

### Example

```python
from adbflow.files import FileWatcher

watcher = FileWatcher(device.transport, device.serial)
async for change in watcher.watch_async("/sdcard/Download/"):
    print(f"{change.change_type}: {change.path}")
```
