# Media

## MediaManager

`adbflow.media.manager.MediaManager`

Composite facade for screenshots, recording, and audio. Access via `device.media`.

### Properties

| Property | Type | Description |
| -------- | ---- | ----------- |
| `screenshot` | `ScreenshotManager` | Screenshot capture |
| `recording` | `ScreenRecorder` | Screen recording |
| `audio` | `AudioManager` | Audio/volume control |

## ScreenshotManager

`adbflow.media.screenshot.ScreenshotManager`

### Methods

| Method | Parameters | Returns | Description |
| ------ | ---------- | ------- | ----------- |
| `capture_async` | — | `bytes` | Capture as PNG bytes |
| `capture_to_file_async` | `path: str` | `None` | Capture and save to file |
| `capture_pil_async` | — | `Image.Image` | Capture as PIL Image |

## ScreenRecorder

`adbflow.media.recording.ScreenRecorder`

### Methods

| Method | Parameters | Returns | Description |
| ------ | ---------- | ------- | ----------- |
| `start_async` | `remote_path="/sdcard/screenrecord.mp4", options=None` | `None` | Start recording |
| `stop_async` | — | `None` | Stop recording |
| `pull_async` | `local_path, remote_path="/sdcard/screenrecord.mp4"` | `None` | Pull recording to host |
| `is_recording_async` | — | `bool` | Check if recording |

## AudioManager

`adbflow.media.audio.AudioManager`

### Methods

| Method | Parameters | Returns | Description |
| ------ | ---------- | ------- | ----------- |
| `get_volume_async` | `stream: AudioStream` | `int` | Get volume level |
| `set_volume_async` | `stream: AudioStream, level: int` | `None` | Set volume level |
| `mute_async` | `stream: AudioStream` | `None` | Mute stream |
| `unmute_async` | `stream: AudioStream` | `None` | Unmute stream |
| `is_muted_async` | `stream: AudioStream` | `bool` | Check if muted |

### Example

```python
from adbflow.utils.types import AudioStream

audio = device.media.audio
await audio.set_volume_async(AudioStream.MUSIC, 10)
await audio.mute_async(AudioStream.NOTIFICATION)
```
