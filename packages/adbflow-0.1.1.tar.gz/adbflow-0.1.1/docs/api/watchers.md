# Watchers

## WatcherManager

`adbflow.watchers.manager.WatcherManager`

Background UI monitoring with auto-response. Access via `device.watchers`.

### Properties

| Property | Type | Description |
| -------- | ---- | ----------- |
| `is_running` | `bool` | Whether the watcher loop is active |

### Methods

| Method | Parameters | Returns | Description |
| ------ | ---------- | ------- | ----------- |
| `register` | `name, selector, action: WatcherAction` | `None` | Register a watcher |
| `unregister` | `name: str` | `None` | Remove a watcher |
| `list_watchers` | — | `list[str]` | List registered watcher names |
| `start_async` | `interval: float = 1.0` | `None` | Start the polling loop |
| `stop_async` | — | `None` | Stop the polling loop |

## Factory Helpers

Module-level functions for common watcher patterns:

| Function | Parameters | Returns | Description |
| -------- | ---------- | ------- | ----------- |
| `click_watcher` | `name, selector` | `tuple[str, Selector, WatcherAction]` | Click matching element |
| `dismiss_watcher` | `name, text: str` | `tuple[str, Selector, WatcherAction]` | Dismiss dialog with text |

### Example

```python
from adbflow.watchers import click_watcher, dismiss_watcher

wm = device.watchers

# Auto-click "OK" buttons
name, sel, act = click_watcher("ok", Selector().text("OK"))
wm.register(name, sel, act)

# Auto-dismiss crash dialogs
name, sel, act = dismiss_watcher("crash", "has stopped")
wm.register(name, sel, act)

await wm.start_async(interval=1.0)
# ... run automation ...
await wm.stop_async()
```
