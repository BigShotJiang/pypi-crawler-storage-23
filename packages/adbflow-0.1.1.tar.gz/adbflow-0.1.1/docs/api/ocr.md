# OCR

Requires the `[ocr]` extra: `pip install adbflow[ocr]`

## OCRManager

`adbflow.ocr.manager.OCRManager`

On-screen text recognition via EasyOCR. Access via `device.ocr`.

### Methods

| Method | Parameters | Returns | Description |
| ------ | ---------- | ------- | ----------- |
| `read_screen_async` | `languages=("en",)` | `list[OCRResult]` | Read all text on screen |
| `find_text_async` | `text, languages=("en",)` | `OCRResult \| None` | Find exact text |
| `find_text_contains_async` | `text, languages=("en",)` | `list[OCRResult]` | Find text containing substring |
| `tap_text_async` | `text, languages=("en",)` | `OCRResult` | Find and tap text |
| `wait_for_text_async` | `text, timeout=10.0, interval=1.0, languages=("en",)` | `OCRResult` | Wait for text to appear |

### Example

```python
# Read all text
results = await device.ocr.read_screen_async()
for r in results:
    print(f"'{r.text}' at {r.bounds} ({r.confidence:.2f})")

# Find and tap
await device.ocr.tap_text_async("Submit")

# Multi-language
results = await device.ocr.read_screen_async(languages=("en", "ja"))
```

## OCREngine

`adbflow.ocr.engine.OCREngine`

Low-level EasyOCR wrapper. Reader is lazily initialized and cached.

### Methods

| Method | Parameters | Returns | Description |
| ------ | ---------- | ------- | ----------- |
| `recognize` | `image, languages=("en",)` | `list[OCRResult]` | Recognize text in image |
| `find_text` | `image, text, languages=("en",)` | `OCRResult \| None` | Find exact text |
| `find_text_contains` | `image, text, languages=("en",)` | `list[OCRResult]` | Find containing text |
