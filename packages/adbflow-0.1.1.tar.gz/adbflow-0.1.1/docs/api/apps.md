# Apps

## AppManager

`adbflow.apps.manager.AppManager`

Manages app installation, lifecycle, and intents. Access via `device.apps`.

### Methods

| Method | Parameters | Returns | Description |
| ------ | ---------- | ------- | ----------- |
| `install_async` | `apk_path, flags=None, progress=None` | `None` | Install an APK |
| `install_multiple_async` | `apk_paths, flags=None` | `None` | Install split APKs |
| `uninstall_async` | `package, keep_data=False` | `None` | Uninstall a package |
| `list_async` | `filter=PackageFilter.ALL` | `list[str]` | List packages |
| `info_async` | `package: str` | `PackageInfo \| None` | Get package details |
| `is_installed_async` | `package: str` | `bool` | Check if installed |
| `start_async` | `package, activity=None` | `None` | Launch an app |
| `stop_async` | `package: str` | `None` | Force stop an app |
| `clear_data_async` | `package: str` | `None` | Clear app data |
| `current_async` | — | `str \| None` | Current foreground app |
| `extract_async` | `package, output_path` | `None` | Extract APK from device |
| `broadcast_async` | `intent: Intent` | `str` | Send a broadcast |
| `start_activity_async` | `intent: Intent` | `None` | Start an activity |
| `start_service_async` | `intent: Intent` | `None` | Start a service |

### Properties

| Property | Type | Description |
| -------- | ---- | ----------- |
| `permissions` | `AppPermissions` | Permission management |

## Intent

`adbflow.apps.intent.Intent`

Fluent builder for Android intents.

### Methods

All methods return `self` for chaining.

| Method | Parameters | Description |
| ------ | ---------- | ----------- |
| `action` | `action: str` | Set intent action |
| `data` | `uri: str` | Set data URI |
| `mime_type` | `mime: str` | Set MIME type |
| `category` | `cat: str` | Add a category |
| `component` | `comp: str` | Set target component |
| `extra_string` | `key, value` | Add string extra |
| `extra_int` | `key, value` | Add integer extra |
| `extra_bool` | `key, value` | Add boolean extra |
| `extra_float` | `key, value` | Add float extra |
| `flags` | `*flags: IntentFlag` | Add intent flags |
| `build_am_args` | — | Build `am` command args |

### Example

```python
from adbflow.apps import Intent

intent = (
    Intent()
    .action("android.intent.action.VIEW")
    .data("https://example.com")
    .category("android.intent.category.BROWSABLE")
)
await device.apps.start_activity_async(intent)
```

## AppPermissions

`adbflow.apps.permissions.AppPermissions`

Access via `device.apps.permissions`.

### Methods

| Method | Parameters | Returns | Description |
| ------ | ---------- | ------- | ----------- |
| `list_async` | `package: str` | `list[PermissionInfo]` | List all permissions |
| `grant_async` | `package, permission` | `None` | Grant a permission |
| `revoke_async` | `package, permission` | `None` | Revoke a permission |
| `is_granted_async` | `package, permission` | `bool` | Check if granted |
