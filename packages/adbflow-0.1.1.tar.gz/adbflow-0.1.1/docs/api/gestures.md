# Gestures

## GestureManager

`adbflow.gestures.manager.GestureManager`

Touch input via ADB `input` commands. Access via `device.gestures`.

### Methods

| Method | Parameters | Returns | Description |
| ------ | ---------- | ------- | ----------- |
| `tap_async` | `x: int \| Point, y: int \| None = None` | `None` | Tap at coordinates |
| `long_tap_async` | `point: Point, duration_ms: int = 1000` | `None` | Long press |
| `swipe_async` | `start: Point, end: Point, duration_ms: int = 300` | `None` | Swipe between points |
| `swipe_direction_async` | `direction: SwipeDirection, start=None, distance=500, duration_ms=300, screen_size=(1080, 1920)` | `None` | Swipe by direction |
| `drag_async` | `start: Point, end: Point, duration_ms: int = 1000` | `None` | Drag (slow swipe) |
| `pinch_in_async` | `center: Point, distance=200, duration_ms=500` | `None` | Pinch inward (zoom out) |
| `pinch_out_async` | `center: Point, distance=200, duration_ms=500` | `None` | Pinch outward (zoom in) |
| `text_async` | `text: str` | `None` | Type text |
| `key_async` | `code: KeyCode \| int` | `None` | Send key event |

### Example

```python
from adbflow.utils.geometry import Point
from adbflow.utils.types import SwipeDirection, KeyCode

async def gestures(device):
    g = device.gestures

    # Tap
    await g.tap_async(500, 1000)
    await g.tap_async(Point(500, 1000))

    # Swipe
    await g.swipe_async(Point(500, 1500), Point(500, 500))
    await g.swipe_direction_async(SwipeDirection.UP)

    # Drag
    await g.drag_async(Point(100, 500), Point(800, 500))

    # Pinch
    await g.pinch_in_async(Point(540, 960), distance=200)
    await g.pinch_out_async(Point(540, 960), distance=200)

    # Text and keys
    await g.text_async("hello")
    await g.key_async(KeyCode.ENTER)
```
