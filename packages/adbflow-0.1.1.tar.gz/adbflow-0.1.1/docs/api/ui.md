# UI

## UIManager

`adbflow.ui.manager.UIManager`

Manages UI hierarchy dumps and element queries. Access via `device.ui`.

The hierarchy is cached for 2 seconds and automatically invalidated after interactions.

### Methods

| Method | Parameters | Returns | Description |
| ------ | ---------- | ------- | ----------- |
| `dump_async` | `force: bool = False` | `UINode` | Dump UI hierarchy |
| `find_async` | `selector: Selector` | `UIElement \| None` | Find first matching element |
| `find_all_async` | `selector: Selector` | `list[UIElement]` | Find all matching elements |
| `exists_async` | `selector: Selector` | `bool` | Check if element exists |
| `wait_for_async` | `selector, timeout=10.0, interval=0.5` | `UIElement` | Wait for element to appear |
| `invalidate_cache` | — | `None` | Clear hierarchy cache |

## Selector

`adbflow.ui.selector.Selector`

Fluent builder for matching UI nodes. All methods return `self` for chaining.

### Text Matchers

| Method | Parameters | Description |
| ------ | ---------- | ----------- |
| `text` | `value: str` | Exact text match |
| `text_contains` | `value: str` | Text contains substring |
| `text_starts_with` | `value: str` | Text starts with prefix |

### ID & Class Matchers

| Method | Parameters | Description |
| ------ | ---------- | ----------- |
| `resource_id` | `value: str` | Exact resource ID match |
| `resource_id_contains` | `value: str` | Resource ID contains substring |
| `class_name` | `value: str` | Widget class name |
| `package` | `value: str` | Package name |

### Description Matchers

| Method | Parameters | Description |
| ------ | ---------- | ----------- |
| `description` | `value: str` | Exact content description |
| `description_contains` | `value: str` | Description contains substring |

### Boolean Attributes

| Method | Parameter | Description |
| ------ | --------- | ----------- |
| `clickable` | `value=True` | Is clickable |
| `enabled` | `value=True` | Is enabled |
| `scrollable` | `value=True` | Is scrollable |
| `checkable` | `value=True` | Is checkable |
| `checked` | `value=True` | Is checked |
| `focusable` | `value=True` | Is focusable |
| `focused` | `value=True` | Is focused |
| `long_clickable` | `value=True` | Is long-clickable |
| `selected` | `value=True` | Is selected |

### Structural

| Method | Parameters | Description |
| ------ | ---------- | ----------- |
| `index` | `value: int` | Sibling index |
| `child` | `selector: Selector` | Match within children |
| `sibling` | `selector: Selector` | Match among siblings |

### Other

| Method | Parameters | Returns | Description |
| ------ | ---------- | ------- | ----------- |
| `matches` | `node: UINode` | `bool` | Test if a node matches |
| `describe` | — | `str` | Human-readable description |

## UIElement

`adbflow.ui.element.UIElement`

Wraps a `UINode` with interaction capabilities.

### Properties

| Property | Type | Description |
| -------- | ---- | ----------- |
| `info` | `UINode` | The underlying node data |

### Methods

| Method | Parameters | Returns | Description |
| ------ | ---------- | ------- | ----------- |
| `get_text` | — | `str` | Element text |
| `get_bounds` | — | `Rect` | Bounding rectangle |
| `get_center` | — | `Point` | Center point |
| `tap_async` | — | `None` | Tap the element |
| `long_tap_async` | `duration_ms=1000` | `None` | Long tap |
| `swipe_async` | `direction, distance=500, duration_ms=300` | `None` | Swipe on element |
| `text_input_async` | `text: str` | `None` | Type text |
| `exists_async` | — | `bool` | Check if still visible |
| `wait_for_async` | `timeout=10.0` | `UIElement` | Wait for re-appearance |

## UINode

`adbflow.ui.hierarchy.UINode`

Frozen dataclass representing one node in the UI hierarchy tree.

### Fields

| Field | Type | Description |
| ----- | ---- | ----------- |
| `text` | `str` | Display text |
| `resource_id` | `str` | Resource ID |
| `class_name` | `str` | Widget class |
| `package` | `str` | Package name |
| `content_desc` | `str` | Content description |
| `checkable` | `bool` | — |
| `checked` | `bool` | — |
| `clickable` | `bool` | — |
| `enabled` | `bool` | — |
| `focusable` | `bool` | — |
| `focused` | `bool` | — |
| `scrollable` | `bool` | — |
| `long_clickable` | `bool` | — |
| `selected` | `bool` | — |
| `bounds` | `Rect` | Bounding rectangle |
| `index` | `int` | Sibling index |
| `children` | `tuple[UINode, ...]` | Child nodes |

### Methods

| Method | Returns | Description |
| ------ | ------- | ----------- |
| `iter_descendants` | `Iterator[UINode]` | Iterate all descendants |
| `iter_all` | `Iterator[UINode]` | Iterate self + all descendants |

### parse_hierarchy

```python
from adbflow.ui.hierarchy import parse_hierarchy

root = parse_hierarchy(xml_content)
```

Parses uiautomator XML into a `UINode` tree.
