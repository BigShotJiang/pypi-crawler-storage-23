# Wait

## wait_for

`adbflow.wait.engine.wait_for`

```python
async wait_for(condition: Condition, timeout: float = 10.0, interval: float = 0.5) -> bool
```

Polls `condition` every `interval` seconds until it returns `True` or `timeout` is exceeded. Raises `WaitTimeoutError` on timeout.

## Conditions

`adbflow.wait.conditions`

All conditions implement the `Condition` protocol (an async callable returning `bool`).

| Class | Parameters | True when... |
| ----- | ---------- | ------------ |
| `TextVisible` | `device, text: str` | Text appears in UI hierarchy |
| `ActivityIs` | `device, activity: str` | Foreground activity matches |
| `ScreenOn` | `device` | Screen is on |
| `ScreenOff` | `device` | Screen is off |
| `PackageRunning` | `device, package: str` | Package has a running process |
| `ElementExists` | `match_fn: Callable[[], Awaitable[bool]]` | Custom async function returns True |

### Example

```python
from adbflow.wait import wait_for, TextVisible, ActivityIs, ScreenOn

await wait_for(TextVisible(device, "Welcome"), timeout=10.0)
await wait_for(ActivityIs(device, "com.example/.Main"), timeout=5.0)
await wait_for(ScreenOn(device))
```

## Combinators

`adbflow.wait.combinators`

| Class / Function | Parameters | Description |
| ---------------- | ---------- | ----------- |
| `AnyOf` / `any_of` | `*conditions` | True if any condition is True |
| `AllOf` / `all_of` | `*conditions` | True if all conditions are True |
| `Not` / `not_` | `condition` | True if condition is False |

### Example

```python
from adbflow.wait import wait_for, TextVisible, any_of, all_of, not_

# Wait for success or error
await wait_for(
    any_of(TextVisible(device, "Success"), TextVisible(device, "Error")),
    timeout=10.0
)

# Wait for loading to finish
await wait_for(
    not_(TextVisible(device, "Loading...")),
    timeout=15.0
)

# Complex: screen on AND (home OR dashboard visible)
await wait_for(
    all_of(
        ScreenOn(device),
        any_of(TextVisible(device, "Home"), TextVisible(device, "Dashboard"))
    )
)
```
