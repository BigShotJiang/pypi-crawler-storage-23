# Installation

## Basic Install

```bash
pip install adbflow
```

This installs the core package with `Pillow` and `lxml` as dependencies.

## Optional Extras

adbflow has optional dependency groups for heavier features:

| Extra       | Deps                | Use case                                    |
| ----------- | ------------------- | ------------------------------------------- |
| `[vision]`  | `opencv-python`     | Template matching, color detection          |
| `[ocr]`     | `easyocr`           | On-screen text recognition                  |
| `[all]`     | Both of the above   | Everything                                  |
| `[dev]`     | pytest, ruff, mypy  | Development and testing                     |
| `[docs]`    | mkdocs-material     | Building documentation                      |

```bash
# Vision features (template matching, color detection)
pip install adbflow[vision]

# OCR features (text recognition via EasyOCR)
pip install adbflow[ocr]

# All optional features
pip install adbflow[all]

# Development dependencies
pip install adbflow[dev]

# Multiple extras
pip install adbflow[all,dev]
```

## ADB Setup

adbflow requires the Android Debug Bridge (`adb`) binary. Install it via:

**Android SDK Platform-Tools** (recommended):

```bash
# macOS
brew install android-platform-tools

# Ubuntu/Debian
sudo apt install android-tools-adb

# Windows (scoop)
scoop install adb
```

Or download directly from [developer.android.com](https://developer.android.com/tools/releases/platform-tools).

Verify ADB is available:

```bash
adb version
```

## Device Setup

Enable **USB Debugging** on your Android device:

1. Go to **Settings → About Phone**
2. Tap **Build Number** 7 times to enable Developer Options
3. Go to **Settings → Developer Options**
4. Enable **USB Debugging**

For wireless debugging (Android 11+):

1. Enable **Wireless Debugging** in Developer Options
2. Use `adb pair <ip>:<port>` with the pairing code
3. Then `adb connect <ip>:<port>`

## Verify Installation

```python
import asyncio
from adbflow import ADB

async def check():
    adb = ADB()
    devices = await adb.devices_async()
    for d in devices:
        print(f"{d.serial} — {d.state}")

asyncio.run(check())
```
