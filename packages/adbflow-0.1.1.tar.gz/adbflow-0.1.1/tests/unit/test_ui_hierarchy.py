"""Tests for UI hierarchy parsing."""

from __future__ import annotations

from adbflow.ui.hierarchy import UINode, parse_hierarchy
from adbflow.utils.geometry import Rect


SIMPLE_XML = """\
<?xml version="1.0" encoding="UTF-8"?>
<hierarchy rotation="0">
  <node index="0" text="Hello"
        resource-id="com.app:id/text"
        class="android.widget.TextView"
        package="com.app"
        content-desc="greeting"
        checkable="false" checked="false"
        clickable="true" enabled="true"
        focusable="false" focused="false"
        scrollable="false" long-clickable="false"
        selected="false"
        bounds="[0,0][540,96]" />
</hierarchy>
"""

NESTED_XML = """\
<?xml version="1.0" encoding="UTF-8"?>
<hierarchy rotation="0">
  <node index="0" text="" resource-id="" class="android.widget.FrameLayout"
        package="com.app" content-desc=""
        checkable="false" checked="false" clickable="false" enabled="true"
        focusable="false" focused="false" scrollable="false"
        long-clickable="false" selected="false" bounds="[0,0][1080,1920]">
    <node index="0" text="Child1" resource-id="com.app:id/c1"
          class="android.widget.TextView" package="com.app" content-desc=""
          checkable="false" checked="false" clickable="true" enabled="true"
          focusable="false" focused="false" scrollable="false"
          long-clickable="false" selected="false" bounds="[0,0][540,96]" />
    <node index="1" text="Child2" resource-id="com.app:id/c2"
          class="android.widget.Button" package="com.app" content-desc=""
          checkable="false" checked="false" clickable="true" enabled="true"
          focusable="true" focused="false" scrollable="false"
          long-clickable="true" selected="false" bounds="[540,0][1080,96]" />
  </node>
</hierarchy>
"""


class TestParseHierarchy:
    def test_basic_node(self) -> None:
        root = parse_hierarchy(SIMPLE_XML)
        assert root.text == "Hello"
        assert root.resource_id == "com.app:id/text"
        assert root.class_name == "android.widget.TextView"
        assert root.package == "com.app"
        assert root.content_desc == "greeting"

    def test_boolean_attrs(self) -> None:
        root = parse_hierarchy(SIMPLE_XML)
        assert root.clickable is True
        assert root.enabled is True
        assert root.checkable is False
        assert root.checked is False
        assert root.focusable is False
        assert root.focused is False
        assert root.scrollable is False
        assert root.long_clickable is False
        assert root.selected is False

    def test_bounds_parsed(self) -> None:
        root = parse_hierarchy(SIMPLE_XML)
        assert root.bounds == Rect(0, 0, 540, 96)

    def test_index_parsed(self) -> None:
        root = parse_hierarchy(SIMPLE_XML)
        assert root.index == 0

    def test_children(self) -> None:
        root = parse_hierarchy(NESTED_XML)
        assert len(root.children) == 2
        assert root.children[0].text == "Child1"
        assert root.children[1].text == "Child2"

    def test_nested_boolean_attrs(self) -> None:
        root = parse_hierarchy(NESTED_XML)
        assert root.children[1].focusable is True
        assert root.children[1].long_clickable is True

    def test_empty_hierarchy(self) -> None:
        xml = '<hierarchy rotation="0"></hierarchy>'
        root = parse_hierarchy(xml)
        assert root.text == ""
        assert root.children == ()

    def test_invalid_xml_returns_empty(self) -> None:
        root = parse_hierarchy("not xml at all <<<")
        assert root.text == ""
        assert root.children == ()

    def test_empty_string_returns_empty(self) -> None:
        root = parse_hierarchy("")
        assert root.text == ""
        assert root.children == ()


class TestUINodeIteration:
    def test_iter_descendants(self) -> None:
        root = parse_hierarchy(NESTED_XML)
        descs = list(root.iter_descendants())
        assert len(descs) == 2
        texts = [n.text for n in descs]
        assert "Child1" in texts
        assert "Child2" in texts

    def test_iter_all(self) -> None:
        root = parse_hierarchy(NESTED_XML)
        all_nodes = list(root.iter_all())
        # root + 2 children
        assert len(all_nodes) == 3
        assert all_nodes[0] is root

    def test_iter_descendants_empty(self) -> None:
        root = parse_hierarchy(SIMPLE_XML)
        assert list(root.iter_descendants()) == []

    def test_iter_all_leaf(self) -> None:
        root = parse_hierarchy(SIMPLE_XML)
        all_nodes = list(root.iter_all())
        assert len(all_nodes) == 1
