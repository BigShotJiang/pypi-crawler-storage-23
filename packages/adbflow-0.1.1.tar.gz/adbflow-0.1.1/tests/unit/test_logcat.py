"""Tests for logcat module."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from adbflow.core.transport import SubprocessTransport
from adbflow.logcat.stream import LogcatManager
from adbflow.utils.types import LogLevel

from tests.conftest import make_result


@pytest.fixture
def logcat_mgr(mock_transport: SubprocessTransport) -> LogcatManager:
    return LogcatManager(serial="emulator-5554", transport=mock_transport)


class TestLogcatStream:
    async def test_stream_yields_entries(self, logcat_mgr: LogcatManager) -> None:
        lines = [
            "01-15 10:30:00.123  1234  5678 D MyTag   : Hello world",
            "01-15 10:30:00.124  1234  5678 I MyTag   : Info message",
        ]

        async def mock_stream_lines(
            args: list[str], **kwargs: object,
        ) -> object:
            async def _gen() -> object:
                for line in lines:
                    yield line
            return _gen()

        # Use an async generator directly
        async def stream_gen(
            args: list[str], **kwargs: object,
        ) -> object:
            for line in lines:
                yield line

        logcat_mgr._transport.stream_lines = stream_gen  # type: ignore[assignment]

        entries = []
        async for entry in logcat_mgr.stream_async():
            entries.append(entry)
            if len(entries) == 2:
                break

        assert len(entries) == 2
        assert entries[0].tag == "MyTag"
        assert entries[0].level == LogLevel.DEBUG
        assert entries[0].message == "Hello world"
        assert entries[1].level == LogLevel.INFO

    async def test_stream_filters_by_pid(self, logcat_mgr: LogcatManager) -> None:
        lines = [
            "01-15 10:30:00.123  1234  5678 D MyTag   : match",
            "01-15 10:30:00.124  9999  5678 D MyTag   : no match",
        ]

        async def stream_gen(
            args: list[str], **kwargs: object,
        ) -> object:
            for line in lines:
                yield line

        logcat_mgr._transport.stream_lines = stream_gen  # type: ignore[assignment]

        entries = []
        async for entry in logcat_mgr.stream_async(pid=1234):
            entries.append(entry)
            if len(entries) >= 2:
                break

        assert len(entries) == 1
        assert entries[0].message == "match"

    async def test_stream_filters_by_pattern(self, logcat_mgr: LogcatManager) -> None:
        lines = [
            "01-15 10:30:00.123  1234  5678 D MyTag   : Error occurred",
            "01-15 10:30:00.124  1234  5678 D MyTag   : All good",
        ]

        async def stream_gen(
            args: list[str], **kwargs: object,
        ) -> object:
            for line in lines:
                yield line

        logcat_mgr._transport.stream_lines = stream_gen  # type: ignore[assignment]

        entries = []
        async for entry in logcat_mgr.stream_async(pattern="Error"):
            entries.append(entry)
            if len(entries) >= 2:
                break

        assert len(entries) == 1
        assert "Error" in entries[0].message


class TestLogcatClear:
    async def test_clear(self, logcat_mgr: LogcatManager) -> None:
        logcat_mgr._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        await logcat_mgr.clear_async()
        cmd = logcat_mgr._transport.execute_shell.call_args[0][0]  # type: ignore[union-attr]
        assert "logcat -c" in cmd


class TestLogcatCapture:
    async def test_capture_to_file(
        self, logcat_mgr: LogcatManager, tmp_path: object,
    ) -> None:
        import pathlib

        assert isinstance(tmp_path, pathlib.Path)
        lines = [
            "01-15 10:30:00.123  1234  5678 D Tag1    : message1",
            "01-15 10:30:00.124  1234  5678 I Tag2    : message2",
        ]

        async def stream_gen(
            args: list[str], **kwargs: object,
        ) -> object:
            for line in lines:
                yield line

        logcat_mgr._transport.stream_lines = stream_gen  # type: ignore[assignment]

        output_file = tmp_path / "logcat.txt"
        await logcat_mgr.capture_async(str(output_file), count=2)

        content = output_file.read_text()
        assert "message1" in content
        assert "message2" in content
