"""Tests for files module."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from adbflow.core.transport import SubprocessTransport
from adbflow.files.operations import FileManager
from adbflow.files.watcher import FileWatcher
from adbflow.utils.types import FileChangeType

from tests.conftest import make_result


@pytest.fixture
def file_manager(mock_transport: SubprocessTransport) -> FileManager:
    return FileManager(serial="emulator-5554", transport=mock_transport)


@pytest.fixture
def file_watcher(mock_transport: SubprocessTransport) -> FileWatcher:
    return FileWatcher(serial="emulator-5554", transport=mock_transport)


class TestFileManagerPushPull:
    async def test_push(self, file_manager: FileManager) -> None:
        file_manager._transport.execute = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        await file_manager.push_async("/local/file.txt", "/sdcard/file.txt")
        file_manager._transport.execute.assert_called_once()  # type: ignore[union-attr]
        args = file_manager._transport.execute.call_args  # type: ignore[union-attr]
        assert args[0][0] == ["push", "/local/file.txt", "/sdcard/file.txt"]

    async def test_pull(self, file_manager: FileManager) -> None:
        file_manager._transport.execute = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        await file_manager.pull_async("/sdcard/file.txt", "/local/file.txt")
        args = file_manager._transport.execute.call_args  # type: ignore[union-attr]
        assert args[0][0] == ["pull", "/sdcard/file.txt", "/local/file.txt"]

    async def test_push_with_progress(self, file_manager: FileManager) -> None:
        file_manager._transport.execute = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        calls: list[tuple[int, int]] = []
        await file_manager.push_async(
            "/local/f.txt", "/sdcard/f.txt", progress=lambda t, total: calls.append((t, total)),
        )
        assert (0, 1) in calls
        assert (1, 1) in calls


class TestFileManagerLs:
    async def test_ls_parses_output(self, file_manager: FileManager) -> None:
        output = (
            "total 24\n"
            "drwxr-xr-x 2 root root 4096 2024-01-15 10:30 subdir\n"
            "-rw-r--r-- 1 root root 1234 2024-01-15 10:30 file.txt\n"
        )
        file_manager._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout=output),
        )
        entries = await file_manager.ls_async("/sdcard")
        assert len(entries) == 2
        assert entries[0].name == "subdir"
        assert entries[0].is_dir is True
        assert entries[1].name == "file.txt"
        assert entries[1].size == 1234


class TestFileManagerExists:
    async def test_exists_true(self, file_manager: FileManager) -> None:
        file_manager._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout="1"),
        )
        assert await file_manager.exists_async("/sdcard/file.txt") is True

    async def test_exists_false(self, file_manager: FileManager) -> None:
        file_manager._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout="0"),
        )
        assert await file_manager.exists_async("/sdcard/nope") is False


class TestFileManagerMkdirRm:
    async def test_mkdir_with_parents(self, file_manager: FileManager) -> None:
        file_manager._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        await file_manager.mkdir_async("/sdcard/a/b/c")
        cmd = file_manager._transport.execute_shell.call_args[0][0]  # type: ignore[union-attr]
        assert "-p" in cmd

    async def test_mkdir_without_parents(self, file_manager: FileManager) -> None:
        file_manager._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        await file_manager.mkdir_async("/sdcard/dir", parents=False)
        cmd = file_manager._transport.execute_shell.call_args[0][0]  # type: ignore[union-attr]
        assert "-p" not in cmd

    async def test_rm_recursive_force(self, file_manager: FileManager) -> None:
        file_manager._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        await file_manager.rm_async("/sdcard/dir", recursive=True, force=True)
        cmd = file_manager._transport.execute_shell.call_args[0][0]  # type: ignore[union-attr]
        assert "-rf" in cmd


class TestFileManagerMvCp:
    async def test_mv(self, file_manager: FileManager) -> None:
        file_manager._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        await file_manager.mv_async("/sdcard/a", "/sdcard/b")
        cmd = file_manager._transport.execute_shell.call_args[0][0]  # type: ignore[union-attr]
        assert "mv" in cmd

    async def test_cp_recursive(self, file_manager: FileManager) -> None:
        file_manager._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        await file_manager.cp_async("/sdcard/a", "/sdcard/b", recursive=True)
        cmd = file_manager._transport.execute_shell.call_args[0][0]  # type: ignore[union-attr]
        assert "-r" in cmd


class TestFileManagerCatHeadTail:
    async def test_cat(self, file_manager: FileManager) -> None:
        file_manager._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout="hello world"),
        )
        content = await file_manager.cat_async("/sdcard/file.txt")
        assert content == "hello world"

    async def test_head(self, file_manager: FileManager) -> None:
        file_manager._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout="line1\nline2"),
        )
        content = await file_manager.head_async("/sdcard/file.txt", lines=2)
        assert "line1" in content

    async def test_tail(self, file_manager: FileManager) -> None:
        file_manager._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout="last line"),
        )
        content = await file_manager.tail_async("/sdcard/file.txt", lines=1)
        assert "last line" in content


class TestFileWatcher:
    async def test_watcher_detects_creation(self, file_watcher: FileWatcher) -> None:
        """Test that the watcher detects new files."""
        import asyncio

        initial_output = (
            "total 4\n"
            "-rw-r--r-- 1 root root 100 2024-01-15 10:30 existing.txt\n"
        )
        new_output = (
            "total 8\n"
            "-rw-r--r-- 1 root root 100 2024-01-15 10:30 existing.txt\n"
            "-rw-r--r-- 1 root root 200 2024-01-15 10:31 new_file.txt\n"
        )

        call_count = 0

        async def mock_shell(cmd: str, **kwargs: object) -> object:
            nonlocal call_count
            call_count += 1
            if call_count <= 1:
                return make_result(stdout=initial_output)
            return make_result(stdout=new_output)

        file_watcher._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            side_effect=mock_shell,
        )

        changes = []
        async for change in file_watcher.watch_async("/sdcard", interval=0.01):
            changes.append(change)
            break  # Just get the first change

        assert len(changes) == 1
        assert changes[0].change_type == FileChangeType.CREATED
        assert "new_file.txt" in changes[0].path
