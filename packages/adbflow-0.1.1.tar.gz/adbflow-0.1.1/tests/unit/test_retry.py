"""Tests for async retry decorator."""

from __future__ import annotations

import pytest

from adbflow.utils.exceptions import ADBFlowError, ADBTimeoutError
from adbflow.utils.retry import retry, retry_call


class TestRetryDecorator:
    async def test_success_no_retry(self) -> None:
        call_count = 0

        @retry(max_attempts=3, delay=0.01)
        async def succeed() -> str:
            nonlocal call_count
            call_count += 1
            return "ok"

        result = await succeed()
        assert result == "ok"
        assert call_count == 1

    async def test_retry_then_succeed(self) -> None:
        call_count = 0

        @retry(max_attempts=3, delay=0.01, jitter=0)
        async def flaky() -> str:
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise ADBFlowError("fail")
            return "ok"

        result = await flaky()
        assert result == "ok"
        assert call_count == 3

    async def test_all_attempts_fail(self) -> None:
        @retry(max_attempts=2, delay=0.01, jitter=0)
        async def always_fail() -> str:
            raise ADBFlowError("fail")

        with pytest.raises(ADBFlowError, match="fail"):
            await always_fail()

    async def test_exception_filtering(self) -> None:
        """Only retry on specified exceptions."""

        @retry(max_attempts=3, delay=0.01, exceptions=(ADBTimeoutError,))
        async def wrong_exception() -> str:
            raise ADBFlowError("not retried")

        with pytest.raises(ADBFlowError):
            await wrong_exception()

    async def test_on_retry_callback(self) -> None:
        attempts: list[int] = []

        def on_retry(attempt: int, exc: Exception, delay: float) -> None:
            attempts.append(attempt)

        @retry(max_attempts=3, delay=0.01, jitter=0, on_retry=on_retry)
        async def flaky() -> str:
            if len(attempts) < 2:
                raise ADBFlowError("fail")
            return "ok"

        result = await flaky()
        assert result == "ok"
        assert attempts == [1, 2]


class TestRetryCall:
    async def test_imperative_retry(self) -> None:
        call_count = 0

        async def flaky() -> str:
            nonlocal call_count
            call_count += 1
            if call_count < 2:
                raise ADBFlowError("fail")
            return "ok"

        result = await retry_call(flaky, max_attempts=3, delay=0.01, jitter=0)
        assert result == "ok"
        assert call_count == 2
