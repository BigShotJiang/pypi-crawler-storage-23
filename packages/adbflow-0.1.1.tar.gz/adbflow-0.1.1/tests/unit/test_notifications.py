"""Tests for notifications module."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from adbflow.core.transport import SubprocessTransport
from adbflow.notifications.manager import NotificationManager
from adbflow.utils.exceptions import WaitTimeoutError
from adbflow.utils.parsers import parse_notifications
from adbflow.utils.types import Notification
from tests.conftest import make_result

SAMPLE_DUMPSYS = """\
Current Notification List:
  NotificationRecord(0xabc123 pkg=com.example.app key=0|com.example.app|1|null|10042 \
tag=my_tag postTime=1700000000)
    extras:
      android.title=String (Hello World)
      android.text=String (This is a notification)

  NotificationRecord(0xdef456 pkg=com.other.app key=0|com.other.app|2|null|10043 \
tag=other_tag postTime=1700000100)
    extras:
      android.title=String (Alert)
      android.text=String (Something happened)
"""


@pytest.fixture
def notification_mgr(mock_transport: SubprocessTransport) -> NotificationManager:
    mock_transport.execute_shell = AsyncMock(  # type: ignore[assignment]
        return_value=make_result(stdout=SAMPLE_DUMPSYS),
    )
    return NotificationManager("emu", mock_transport)


class TestParseNotifications:
    def test_parse_basic(self) -> None:
        results = parse_notifications(SAMPLE_DUMPSYS)
        assert len(results) == 2
        assert results[0].package == "com.example.app"
        assert results[0].title == "Hello World"
        assert results[0].text == "This is a notification"
        assert results[0].posted_time == "1700000000"
        assert results[0].tag == "my_tag"

    def test_parse_empty(self) -> None:
        assert parse_notifications("") == []
        assert parse_notifications("No notifications") == []

    def test_parse_second_notification(self) -> None:
        results = parse_notifications(SAMPLE_DUMPSYS)
        assert results[1].package == "com.other.app"
        assert results[1].title == "Alert"


class TestNotificationManager:
    async def test_list(self, notification_mgr: NotificationManager) -> None:
        result = await notification_mgr.list_async()
        assert len(result) == 2
        assert result[0].package == "com.example.app"

    async def test_clear_all(self, notification_mgr: NotificationManager) -> None:
        notification_mgr._transport.execute_shell = AsyncMock(  # type: ignore[union-attr]
            return_value=make_result(),
        )
        await notification_mgr.clear_all_async()
        call = notification_mgr._transport.execute_shell  # type: ignore[union-attr]
        call.assert_called_once()
        assert "service call notification 1" in call.call_args[0][0]

    async def test_find_by_package(self, notification_mgr: NotificationManager) -> None:
        result = await notification_mgr.find_async(package="com.other.app")
        assert len(result) == 1
        assert result[0].title == "Alert"

    async def test_find_by_title(self, notification_mgr: NotificationManager) -> None:
        result = await notification_mgr.find_async(title_contains="Hello")
        assert len(result) == 1
        assert result[0].package == "com.example.app"

    async def test_find_by_text(self, notification_mgr: NotificationManager) -> None:
        result = await notification_mgr.find_async(text_contains="happened")
        assert len(result) == 1
        assert result[0].package == "com.other.app"

    async def test_find_no_match(self, notification_mgr: NotificationManager) -> None:
        result = await notification_mgr.find_async(package="com.nonexistent")
        assert result == []

    async def test_wait_for_immediate(self, notification_mgr: NotificationManager) -> None:
        n = await notification_mgr.wait_for_async(package="com.example.app", timeout=1.0)
        assert n.package == "com.example.app"

    async def test_wait_for_timeout(self, mock_transport: SubprocessTransport) -> None:
        mock_transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout=""),
        )
        mgr = NotificationManager("emu", mock_transport)
        with pytest.raises(WaitTimeoutError):
            await mgr.wait_for_async(package="com.none", timeout=0.1, interval=0.05)
