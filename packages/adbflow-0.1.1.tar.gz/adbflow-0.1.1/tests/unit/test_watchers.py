"""Tests for watchers module."""

from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from adbflow.core.transport import SubprocessTransport
from adbflow.ui.element import UIElement
from adbflow.ui.hierarchy import UINode
from adbflow.ui.manager import UIManager
from adbflow.ui.selector import Selector
from adbflow.utils.geometry import Rect
from adbflow.watchers.manager import WatcherManager, click_watcher, dismiss_watcher
from tests.conftest import make_result


def _make_node(text: str = "", clickable: bool = False) -> UINode:
    """Create a minimal UINode for testing."""
    return UINode(
        index=0,
        text=text,
        resource_id="",
        class_name="android.widget.Button",
        package="com.example",
        content_desc="",
        checkable=False,
        checked=False,
        clickable=clickable,
        enabled=True,
        focusable=False,
        focused=False,
        scrollable=False,
        long_clickable=False,
        selected=False,
        bounds=Rect(left=0, top=0, right=100, bottom=100),
        children=(),
    )


@pytest.fixture
def mock_ui(mock_transport: SubprocessTransport) -> UIManager:
    from adbflow.gestures.manager import GestureManager

    gestures = GestureManager("emu", mock_transport)
    ui = UIManager("emu", mock_transport, gestures)
    return ui


@pytest.fixture
def watcher_mgr(
    mock_transport: SubprocessTransport, mock_ui: UIManager,
) -> WatcherManager:
    return WatcherManager("emu", mock_transport, mock_ui)


class TestWatcherManager:
    def test_register_unregister(self, watcher_mgr: WatcherManager) -> None:
        selector = Selector().text("OK")

        async def action(el: UIElement) -> None:
            pass

        watcher_mgr.register("test", selector, action)
        assert "test" in watcher_mgr.list_watchers()

        watcher_mgr.unregister("test")
        assert "test" not in watcher_mgr.list_watchers()

    def test_list_watchers(self, watcher_mgr: WatcherManager) -> None:
        async def action(el: UIElement) -> None:
            pass

        watcher_mgr.register("w1", Selector().text("A"), action)
        watcher_mgr.register("w2", Selector().text("B"), action)
        assert set(watcher_mgr.list_watchers()) == {"w1", "w2"}

    def test_is_running_initial(self, watcher_mgr: WatcherManager) -> None:
        assert watcher_mgr.is_running is False

    async def test_start_stop(self, watcher_mgr: WatcherManager) -> None:
        # Mock dump_async to avoid real ADB calls
        with patch.object(watcher_mgr._ui, "dump_async", new_callable=AsyncMock) as mock_dump:
            root = _make_node()
            root_with_iter = MagicMock()
            root_with_iter.iter_all.return_value = []
            mock_dump.return_value = root_with_iter

            await watcher_mgr.start_async(interval=0.05)
            assert watcher_mgr.is_running is True

            await asyncio.sleep(0.1)

            await watcher_mgr.stop_async()
            assert watcher_mgr.is_running is False

    async def test_watcher_triggers_action(self, watcher_mgr: WatcherManager) -> None:
        triggered: list[str] = []

        async def action(el: UIElement) -> None:
            triggered.append("triggered")

        selector = Selector().text("OK")
        watcher_mgr.register("ok_watcher", selector, action)

        node = _make_node(text="OK", clickable=True)
        root = MagicMock()
        root.iter_all.return_value = [node]

        with patch.object(watcher_mgr._ui, "dump_async", new_callable=AsyncMock, return_value=root):
            await watcher_mgr._check_watchers()

        assert len(triggered) == 1

    async def test_watcher_no_match_skipped(self, watcher_mgr: WatcherManager) -> None:
        triggered: list[str] = []

        async def action(el: UIElement) -> None:
            triggered.append("triggered")

        selector = Selector().text("Cancel")
        watcher_mgr.register("cancel_watcher", selector, action)

        node = _make_node(text="OK")
        root = MagicMock()
        root.iter_all.return_value = [node]

        with patch.object(watcher_mgr._ui, "dump_async", new_callable=AsyncMock, return_value=root):
            await watcher_mgr._check_watchers()

        assert len(triggered) == 0


class TestWatcherHelpers:
    def test_click_watcher(self) -> None:
        name, selector, action = click_watcher("test", Selector().text("OK"))
        assert name == "test"
        assert asyncio.iscoroutinefunction(action)

    def test_dismiss_watcher(self) -> None:
        name, selector, action = dismiss_watcher("dismiss", "Allow")
        assert name == "dismiss"
        assert asyncio.iscoroutinefunction(action)
