"""Tests for SubprocessTransport."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from adbflow.core.transport import SubprocessTransport, _find_adb
from adbflow.utils.exceptions import ADBTimeoutError, BinaryNotFoundError


class TestFindAdb:
    def test_adb_path_env(self, tmp_path: object) -> None:
        """ADB_PATH env var takes priority."""
        import tempfile

        with tempfile.NamedTemporaryFile(suffix="adb", delete=False) as f:
            import os
            import stat

            os.chmod(f.name, stat.S_IRWXU)
            with patch.dict(os.environ, {"ADB_PATH": f.name}):
                assert _find_adb() == f.name

    def test_not_found_raises(self) -> None:
        with patch.dict(
            "os.environ", {"ADB_PATH": "", "ANDROID_HOME": "", "ANDROID_SDK_ROOT": ""}, clear=False
        ):
            with patch("shutil.which", return_value=None):
                with pytest.raises(BinaryNotFoundError):
                    _find_adb()


class TestSubprocessTransport:
    async def test_execute(self) -> None:
        mock_proc = MagicMock()
        mock_proc.communicate = AsyncMock(return_value=(b"output", b""))
        mock_proc.returncode = 0

        with patch("asyncio.create_subprocess_exec", AsyncMock(return_value=mock_proc)):
            transport = SubprocessTransport(adb_path="/usr/bin/adb")
            result = await transport.execute(["devices"])

        assert result.output == "output"
        assert result.success

    async def test_execute_with_serial(self) -> None:
        mock_proc = MagicMock()
        mock_proc.communicate = AsyncMock(return_value=(b"ok", b""))
        mock_proc.returncode = 0

        with patch("asyncio.create_subprocess_exec", AsyncMock(return_value=mock_proc)) as mock_exec:
            transport = SubprocessTransport(adb_path="/usr/bin/adb")
            await transport.execute(["shell", "ls"], serial="emulator-5554")

        call_args = mock_exec.call_args[0]
        assert "-s" in call_args
        assert "emulator-5554" in call_args

    async def test_execute_shell(self) -> None:
        mock_proc = MagicMock()
        mock_proc.communicate = AsyncMock(return_value=(b"hello", b""))
        mock_proc.returncode = 0

        with patch("asyncio.create_subprocess_exec", AsyncMock(return_value=mock_proc)):
            transport = SubprocessTransport(adb_path="/usr/bin/adb")
            result = await transport.execute_shell("echo hello")

        assert result.output == "hello"

    async def test_timeout(self) -> None:
        mock_proc = MagicMock()
        mock_proc.communicate = AsyncMock(side_effect=TimeoutError)
        mock_proc.kill = MagicMock()
        mock_proc.wait = AsyncMock()

        with patch("asyncio.create_subprocess_exec", AsyncMock(return_value=mock_proc)):
            transport = SubprocessTransport(adb_path="/usr/bin/adb")
            with pytest.raises(ADBTimeoutError):
                await transport.execute(["shell", "sleep 100"], timeout=0.1)

    async def test_result_construction(self) -> None:
        mock_proc = MagicMock()
        mock_proc.communicate = AsyncMock(return_value=(b"stdout", b"stderr"))
        mock_proc.returncode = 1

        with patch("asyncio.create_subprocess_exec", AsyncMock(return_value=mock_proc)):
            transport = SubprocessTransport(adb_path="/usr/bin/adb")
            result = await transport.execute(["bad-command"])

        assert result.stdout == b"stdout"
        assert result.stderr == b"stderr"
        assert result.return_code == 1
        assert not result.success
        assert result.duration_ms > 0
