"""Tests for ADB output parsers."""

from __future__ import annotations

from adbflow.utils.geometry import Rect
from adbflow.utils.parsers import (
    parse_bounds_string,
    parse_device_list,
    parse_dumpsys_battery,
    parse_dumpsys_package,
    parse_forward_list,
    parse_getprop,
    parse_ip_address,
    parse_logcat_line,
    parse_ls_la,
    parse_pm_list_packages,
    parse_pm_path,
    parse_screen_density,
    parse_screen_size,
    parse_settings_value,
    parse_stat,
    parse_wifi_info,
)
from adbflow.utils.types import DeviceState, LogLevel, Size


class TestParseDeviceList:
    def test_single_device(self) -> None:
        output = (
            "List of devices attached\n"
            "emulator-5554          device product:sdk_gphone64 model:sdk_gphone64 "
            "transport_id:1\n"
        )
        entries = parse_device_list(output)
        assert len(entries) == 1
        assert entries[0].serial == "emulator-5554"
        assert entries[0].state == DeviceState.DEVICE
        assert entries[0].model == "sdk_gphone64"

    def test_multiple_devices(self) -> None:
        output = (
            "List of devices attached\n"
            "emulator-5554          device transport_id:1\n"
            "192.168.1.100:5555     device transport_id:2\n"
        )
        entries = parse_device_list(output)
        assert len(entries) == 2

    def test_unauthorized_device(self) -> None:
        output = (
            "List of devices attached\n"
            "SERIAL123              unauthorized transport_id:1\n"
        )
        entries = parse_device_list(output)
        assert entries[0].state == DeviceState.UNAUTHORIZED

    def test_empty_output(self) -> None:
        assert parse_device_list("") == []
        assert parse_device_list("List of devices attached\n") == []


class TestParseGetprop:
    def test_normal(self) -> None:
        output = (
            "[ro.build.model]: [Pixel 6]\n"
            "[ro.build.version.sdk]: [33]\n"
            "[ro.product.manufacturer]: [Google]\n"
        )
        props = parse_getprop(output)
        assert props["ro.build.model"] == "Pixel 6"
        assert props["ro.build.version.sdk"] == "33"

    def test_empty_value(self) -> None:
        output = "[ro.some.prop]: []\n"
        props = parse_getprop(output)
        assert props["ro.some.prop"] == ""

    def test_empty_output(self) -> None:
        assert parse_getprop("") == {}


class TestParseDumpsysBattery:
    def test_normal(self) -> None:
        output = (
            "Current Battery Service state:\n"
            "  AC powered: false\n"
            "  USB powered: true\n"
            "  Wireless powered: false\n"
            "  status: 2\n"
            "  level: 85\n"
            "  temperature: 250\n"
        )
        info = parse_dumpsys_battery(output)
        assert info is not None
        assert info.level == 85
        assert info.powered is True
        assert info.temperature == 25.0


class TestParseScreenSize:
    def test_normal(self) -> None:
        assert parse_screen_size("Physical size: 1080x1920") == Size(1080, 1920)

    def test_override(self) -> None:
        output = "Physical size: 1080x1920\nOverride size: 540x960"
        result = parse_screen_size(output)
        assert result == Size(1080, 1920)

    def test_empty(self) -> None:
        assert parse_screen_size("") is None


class TestParseScreenDensity:
    def test_normal(self) -> None:
        assert parse_screen_density("Physical density: 480") == 480

    def test_empty(self) -> None:
        assert parse_screen_density("") is None


class TestParsePmListPackages:
    def test_normal(self) -> None:
        output = "package:com.android.settings\npackage:com.android.chrome\n"
        packages = parse_pm_list_packages(output)
        assert packages == ["com.android.settings", "com.android.chrome"]

    def test_empty(self) -> None:
        assert parse_pm_list_packages("") == []


class TestParseSettingsValue:
    def test_normal(self) -> None:
        assert parse_settings_value("1") == "1"

    def test_null(self) -> None:
        assert parse_settings_value("null") is None

    def test_empty(self) -> None:
        assert parse_settings_value("") is None


class TestParseIpAddress:
    def test_ip_route(self) -> None:
        output = "192.168.1.0/24 dev wlan0 proto kernel scope link src 192.168.1.100"
        assert parse_ip_address(output) == "192.168.1.100"

    def test_no_ip(self) -> None:
        assert parse_ip_address("") is None


class TestParseBoundsString:
    def test_normal(self) -> None:
        rect = parse_bounds_string("[0,0][1080,1920]")
        assert rect == Rect(0, 0, 1080, 1920)

    def test_invalid(self) -> None:
        assert parse_bounds_string("invalid") is None


# ---------------------------------------------------------------------------
# Phase 2 parsers
# ---------------------------------------------------------------------------


class TestParseLsLa:
    def test_files_and_dirs(self) -> None:
        output = (
            "total 24\n"
            "drwxr-xr-x 2 root root 4096 2024-01-15 10:30 subdir\n"
            "-rw-r--r-- 1 root root 1234 2024-01-15 10:30 file.txt\n"
        )
        entries = parse_ls_la(output)
        assert len(entries) == 2
        assert entries[0].name == "subdir"
        assert entries[0].is_dir is True
        assert entries[0].size == 4096
        assert entries[0].permissions == "drwxr-xr-x"
        assert entries[1].name == "file.txt"
        assert entries[1].is_dir is False
        assert entries[1].size == 1234

    def test_symlink(self) -> None:
        output = "lrwxrwxrwx 1 root root 10 2024-01-15 10:30 link -> target\n"
        entries = parse_ls_la(output)
        assert len(entries) == 1
        assert entries[0].name == "link"

    def test_empty(self) -> None:
        assert parse_ls_la("") == []
        assert parse_ls_la("total 0\n") == []


class TestParseStat:
    def test_normal(self) -> None:
        output = (
            "  File: /sdcard/test.txt\n"
            "  Size: 1234\tBlocks: 8\tIO Block: 4096\tregular file\n"
            "Access: (0644/-rw-r--r--)  Uid: (    0/    root)   Gid: (    0/    root)\n"
            "Modify: 2024-01-15 10:30:00.000000000 +0000\n"
        )
        info = parse_stat(output)
        assert info is not None
        assert info.name == "test.txt"
        assert info.size == 1234
        assert info.owner == "root"
        assert info.path == "/sdcard/test.txt"

    def test_directory(self) -> None:
        output = (
            "  File: /sdcard/mydir\n"
            "  Size: 4096\tBlocks: 8\tIO Block: 4096\tdirectory\n"
            "Access: (0755/drwxr-xr-x)  Uid: (    0/    root)   Gid: (    0/    root)\n"
            "Modify: 2024-01-15 10:30:00.000000000 +0000\n"
        )
        info = parse_stat(output)
        assert info is not None
        assert info.is_dir is True

    def test_empty(self) -> None:
        assert parse_stat("") is None


class TestParseDumpsysPackage:
    def test_basic_package(self) -> None:
        output = (
            "Packages:\n"
            "  Package [com.example.app] (abcdef):\n"
            "    versionCode=42 minSdk=21 targetSdk=33\n"
            "    versionName=1.2.3\n"
            "    codePath=/data/app/com.example.app-1\n"
            "    firstInstallTime=2024-01-01 00:00:00\n"
            "    lastUpdateTime=2024-06-01 00:00:00\n"
            "    pkgFlags=[ HAS_CODE ]\n"
            "    enabled=0\n"
        )
        info = parse_dumpsys_package(output, "com.example.app")
        assert info is not None
        assert info.package_name == "com.example.app"
        assert info.version_code == "42"
        assert info.version_name == "1.2.3"

    def test_system_package(self) -> None:
        output = "pkgFlags=[ SYSTEM HAS_CODE ]\n"
        info = parse_dumpsys_package(output, "com.android.settings")
        assert info is not None
        assert info.is_system is True

    def test_empty(self) -> None:
        assert parse_dumpsys_package("", "com.example") is None


class TestParsePmPath:
    def test_normal(self) -> None:
        output = "package:/data/app/com.example-1/base.apk\n"
        assert parse_pm_path(output) == "/data/app/com.example-1/base.apk"

    def test_empty(self) -> None:
        assert parse_pm_path("") is None

    def test_no_match(self) -> None:
        assert parse_pm_path("error: not found") is None


class TestParseLogcatLine:
    def test_normal(self) -> None:
        line = "01-15 10:30:00.123  1234  5678 D MyTag   : Hello world"
        entry = parse_logcat_line(line)
        assert entry is not None
        assert entry.timestamp == "01-15 10:30:00.123"
        assert entry.pid == "1234"
        assert entry.tid == "5678"
        assert entry.level == LogLevel.DEBUG
        assert entry.tag == "MyTag"
        assert entry.message == "Hello world"

    def test_all_levels(self) -> None:
        for level_char, level_enum in [
            ("V", LogLevel.VERBOSE),
            ("D", LogLevel.DEBUG),
            ("I", LogLevel.INFO),
            ("W", LogLevel.WARNING),
            ("E", LogLevel.ERROR),
            ("F", LogLevel.FATAL),
        ]:
            line = f"01-15 10:30:00.123  1234  5678 {level_char} Tag     : msg"
            entry = parse_logcat_line(line)
            assert entry is not None
            assert entry.level == level_enum

    def test_invalid_line(self) -> None:
        assert parse_logcat_line("not a logcat line") is None
        assert parse_logcat_line("") is None


class TestParseForwardList:
    def test_normal(self) -> None:
        output = (
            "emulator-5554 tcp:8080 tcp:80\n"
            "emulator-5554 tcp:9090 localabstract:foo\n"
        )
        rules = parse_forward_list(output)
        assert len(rules) == 2
        assert rules[0].serial == "emulator-5554"
        assert rules[0].local == "tcp:8080"
        assert rules[0].remote == "tcp:80"
        assert rules[1].remote == "localabstract:foo"

    def test_empty(self) -> None:
        assert parse_forward_list("") == []


class TestParseWifiInfo:
    def test_normal(self) -> None:
        output = (
            "Wi-Fi is enabled\n"
            '  SSID: "HomeNetwork"\n'
            "  Link speed: 72Mbps\n"
            "  RSSI: -45\n"
            "  mIpAddress /192.168.1.50\n"
        )
        info = parse_wifi_info(output)
        assert info is not None
        assert info.ssid == "HomeNetwork"
        assert info.ip_address == "192.168.1.50"
        assert info.link_speed == 72
        assert info.rssi == -45

    def test_empty(self) -> None:
        assert parse_wifi_info("") is None
