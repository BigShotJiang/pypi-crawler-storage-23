"""Tests for OCR module."""

from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest
from PIL import Image

from adbflow.core.transport import SubprocessTransport
from adbflow.utils.exceptions import OCRError, WaitTimeoutError
from adbflow.utils.geometry import Point, Rect
from adbflow.utils.types import OCRResult, Result
from tests.conftest import make_result


def _make_image(w: int = 100, h: int = 100) -> Image.Image:
    return Image.new("RGB", (w, h), "white")


def _make_png_result() -> Result:
    import io

    img = _make_image()
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return Result(stdout=buf.getvalue(), stderr=b"", return_code=0, duration_ms=1.0)


class TestOCREngine:
    def test_recognize(self) -> None:
        """Test recognize returns OCRResults via mocked engine."""
        from adbflow.ocr.engine import OCREngine

        engine = OCREngine()
        expected = [
            OCRResult(text="Hello", bounds=Rect(10, 20, 100, 50), confidence=0.95),
            OCRResult(text="World", bounds=Rect(10, 60, 80, 90), confidence=0.88),
        ]
        with patch.object(engine, "recognize", return_value=expected):
            results = engine.recognize(_make_image())

        assert len(results) == 2
        assert results[0].text == "Hello"
        assert results[0].confidence == 0.95
        assert results[0].bounds == Rect(left=10, top=20, right=100, bottom=50)

    def test_find_text_exact(self) -> None:
        """Test find_text returns exact match."""
        from adbflow.ocr.engine import OCREngine

        engine = OCREngine()
        ocr_results = [
            OCRResult(text="Hello", bounds=Rect(0, 0, 50, 20), confidence=0.9),
            OCRResult(text="World", bounds=Rect(0, 30, 50, 50), confidence=0.85),
        ]
        with patch.object(engine, "recognize", return_value=ocr_results):
            result = engine.find_text(_make_image(), "World")

        assert result is not None
        assert result.text == "World"

    def test_find_text_not_found(self) -> None:
        """Test find_text returns None when no match."""
        from adbflow.ocr.engine import OCREngine

        engine = OCREngine()
        with patch.object(engine, "recognize", return_value=[]):
            result = engine.find_text(_make_image(), "Missing")

        assert result is None

    def test_find_text_contains(self) -> None:
        """Test find_text_contains returns substring matches."""
        from adbflow.ocr.engine import OCREngine

        engine = OCREngine()
        ocr_results = [
            OCRResult(text="Hello World", bounds=Rect(0, 0, 100, 20), confidence=0.9),
            OCRResult(text="Goodbye", bounds=Rect(0, 30, 80, 50), confidence=0.85),
        ]
        with patch.object(engine, "recognize", return_value=ocr_results):
            results = engine.find_text_contains(_make_image(), "World")

        assert len(results) == 1
        assert results[0].text == "Hello World"

    def test_easyocr_not_installed(self) -> None:
        """Test OCRError when easyocr not installed."""
        from adbflow.ocr.engine import _require_easyocr

        with patch("adbflow.ocr.engine._HAS_EASYOCR", False):
            with pytest.raises(OCRError, match="easyocr not installed"):
                _require_easyocr()


class TestOCRManager:
    async def test_read_screen(self, mock_transport: SubprocessTransport) -> None:
        mock_transport.execute = AsyncMock(  # type: ignore[assignment]
            return_value=_make_png_result(),
        )
        from adbflow.ocr.manager import OCRManager

        mgr = OCRManager("emu", mock_transport)
        expected = [OCRResult(text="Test", bounds=Rect(0, 0, 50, 20), confidence=0.9)]
        with patch.object(mgr._engine, "recognize", return_value=expected):
            results = await mgr.read_screen_async()

        assert len(results) == 1
        assert results[0].text == "Test"

    async def test_tap_text_not_found(self, mock_transport: SubprocessTransport) -> None:
        mock_transport.execute = AsyncMock(  # type: ignore[assignment]
            return_value=_make_png_result(),
        )
        from adbflow.ocr.manager import OCRManager

        mgr = OCRManager("emu", mock_transport)
        with patch.object(mgr._engine, "find_text", return_value=None):
            with pytest.raises(OCRError, match="Text not found"):
                await mgr.tap_text_async("Missing")

    async def test_tap_text_success(self, mock_transport: SubprocessTransport) -> None:
        mock_transport.execute = AsyncMock(  # type: ignore[assignment]
            return_value=_make_png_result(),
        )
        mock_transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        from adbflow.ocr.manager import OCRManager

        mgr = OCRManager("emu", mock_transport)
        found = OCRResult(text="OK", bounds=Rect(40, 40, 60, 60), confidence=0.95)
        with patch.object(mgr._engine, "find_text", return_value=found):
            result = await mgr.tap_text_async("OK")

        assert result.text == "OK"
        call = mock_transport.execute_shell.call_args[0][0]  # type: ignore[union-attr]
        assert "input tap 50 50" in call

    async def test_wait_for_text_timeout(self, mock_transport: SubprocessTransport) -> None:
        mock_transport.execute = AsyncMock(  # type: ignore[assignment]
            return_value=_make_png_result(),
        )
        from adbflow.ocr.manager import OCRManager

        mgr = OCRManager("emu", mock_transport)
        with patch.object(mgr._engine, "find_text", return_value=None):
            with pytest.raises(WaitTimeoutError):
                await mgr.wait_for_text_async("Missing", timeout=0.1, interval=0.05)
