"""Tests for media module."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from adbflow.core.transport import SubprocessTransport
from adbflow.media.audio import AudioManager
from adbflow.media.manager import MediaManager
from adbflow.media.recording import ScreenRecorder
from adbflow.media.screenshot import ScreenshotManager
from adbflow.utils.types import AudioStream, RecordingOptions

from tests.conftest import make_result


@pytest.fixture
def screenshot_mgr(mock_transport: SubprocessTransport) -> ScreenshotManager:
    return ScreenshotManager(serial="emulator-5554", transport=mock_transport)


@pytest.fixture
def recorder(mock_transport: SubprocessTransport) -> ScreenRecorder:
    return ScreenRecorder(serial="emulator-5554", transport=mock_transport)


@pytest.fixture
def audio_mgr(mock_transport: SubprocessTransport) -> AudioManager:
    return AudioManager(serial="emulator-5554", transport=mock_transport)


@pytest.fixture
def media_mgr(mock_transport: SubprocessTransport) -> MediaManager:
    return MediaManager(serial="emulator-5554", transport=mock_transport)


class TestScreenshot:
    async def test_capture_returns_bytes(self, screenshot_mgr: ScreenshotManager) -> None:
        png_data = b"\x89PNG\r\n\x1a\nfakedata"
        from adbflow.utils.types import Result

        screenshot_mgr._transport.execute = AsyncMock(  # type: ignore[assignment]
            return_value=Result(
                stdout=png_data, stderr=b"", return_code=0, duration_ms=1.0,
            ),
        )
        data = await screenshot_mgr.capture_async()
        assert data == png_data

    async def test_capture_uses_exec_out(self, screenshot_mgr: ScreenshotManager) -> None:
        from adbflow.utils.types import Result

        screenshot_mgr._transport.execute = AsyncMock(  # type: ignore[assignment]
            return_value=Result(
                stdout=b"png", stderr=b"", return_code=0, duration_ms=1.0,
            ),
        )
        await screenshot_mgr.capture_async()
        args = screenshot_mgr._transport.execute.call_args[0][0]  # type: ignore[union-attr]
        assert args == ["exec-out", "screencap", "-p"]


class TestScreenRecorder:
    async def test_start_default(self, recorder: ScreenRecorder) -> None:
        recorder._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        await recorder.start_async()
        cmd = recorder._transport.execute_shell.call_args[0][0]  # type: ignore[union-attr]
        assert "screenrecord" in cmd
        assert "/sdcard/screenrecord.mp4" in cmd

    async def test_start_with_options(self, recorder: ScreenRecorder) -> None:
        recorder._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        opts = RecordingOptions(bitrate=4000000, width=1280, height=720, time_limit=30)
        await recorder.start_async(options=opts)
        cmd = recorder._transport.execute_shell.call_args[0][0]  # type: ignore[union-attr]
        assert "--bit-rate 4000000" in cmd
        assert "--size 1280x720" in cmd
        assert "--time-limit 30" in cmd

    async def test_stop(self, recorder: ScreenRecorder) -> None:
        recorder._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        await recorder.stop_async()
        cmd = recorder._transport.execute_shell.call_args[0][0]  # type: ignore[union-attr]
        assert "pkill" in cmd or "killall" in cmd

    async def test_is_recording(self, recorder: ScreenRecorder) -> None:
        recorder._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout="1234"),
        )
        assert await recorder.is_recording_async() is True

    async def test_is_not_recording(self, recorder: ScreenRecorder) -> None:
        recorder._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout="", return_code=1),
        )
        assert await recorder.is_recording_async() is False


class TestAudioManager:
    async def test_get_volume(self, audio_mgr: AudioManager) -> None:
        audio_mgr._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout="Volume is 10"),
        )
        vol = await audio_mgr.get_volume_async(AudioStream.MUSIC)
        assert vol == 10

    async def test_set_volume(self, audio_mgr: AudioManager) -> None:
        audio_mgr._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        await audio_mgr.set_volume_async(AudioStream.MUSIC, 5)
        cmd = audio_mgr._transport.execute_shell.call_args[0][0]  # type: ignore[union-attr]
        assert "--stream 3" in cmd
        assert "--set 5" in cmd

    async def test_mute(self, audio_mgr: AudioManager) -> None:
        audio_mgr._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(),
        )
        await audio_mgr.mute_async(AudioStream.RING)
        cmd = audio_mgr._transport.execute_shell.call_args[0][0]  # type: ignore[union-attr]
        assert "--set 0" in cmd

    async def test_is_muted(self, audio_mgr: AudioManager) -> None:
        audio_mgr._transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout="Volume is 0"),
        )
        assert await audio_mgr.is_muted_async(AudioStream.MUSIC) is True


class TestMediaManager:
    def test_cached_properties(self, media_mgr: MediaManager) -> None:
        assert media_mgr.screenshot is media_mgr.screenshot
        assert media_mgr.recording is media_mgr.recording
        assert media_mgr.audio is media_mgr.audio
