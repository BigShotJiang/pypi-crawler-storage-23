"""Tests for the wait module — engine, conditions, and combinators."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from adbflow.utils.exceptions import WaitTimeoutError
from adbflow.wait.combinators import AllOf, AnyOf, Not, all_of, any_of, not_
from adbflow.wait.conditions import (
    ActivityIs,
    ElementExists,
    PackageRunning,
    ScreenOff,
    ScreenOn,
    TextVisible,
)
from adbflow.wait.engine import wait_for

from tests.conftest import make_result


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class _FakeCondition:
    """Simple condition for testing."""

    def __init__(self, name: str, results: list[bool]) -> None:
        self._name = name
        self._results = list(results)
        self._call_count = 0

    @property
    def name(self) -> str:
        return self._name

    async def __call__(self) -> bool:
        idx = min(self._call_count, len(self._results) - 1)
        self._call_count += 1
        return self._results[idx]


# ---------------------------------------------------------------------------
# wait_for
# ---------------------------------------------------------------------------


class TestWaitFor:
    async def test_immediate_success(self) -> None:
        cond = _FakeCondition("test", [True])
        result = await wait_for(cond, timeout=1.0, interval=0.01)
        assert result is True

    async def test_eventual_success(self) -> None:
        cond = _FakeCondition("test", [False, False, True])
        result = await wait_for(cond, timeout=2.0, interval=0.01)
        assert result is True

    async def test_timeout_raises(self) -> None:
        cond = _FakeCondition("never_true", [False])
        with pytest.raises(WaitTimeoutError) as exc_info:
            await wait_for(cond, timeout=0.05, interval=0.01)
        assert exc_info.value.condition_name == "never_true"
        assert exc_info.value.timeout == 0.05

    async def test_timeout_error_has_elapsed(self) -> None:
        cond = _FakeCondition("slow", [False])
        with pytest.raises(WaitTimeoutError) as exc_info:
            await wait_for(cond, timeout=0.05, interval=0.01)
        assert exc_info.value.elapsed > 0


# ---------------------------------------------------------------------------
# Built-in conditions
# ---------------------------------------------------------------------------


class TestTextVisible:
    async def test_text_found(self, mock_transport: object) -> None:
        from adbflow.core.transport import SubprocessTransport

        transport = mock_transport
        assert isinstance(transport, SubprocessTransport)
        transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout='<node text="Login" />'),
        )
        cond = TextVisible("Login", "emu", transport)
        assert await cond() is True
        assert cond.name == "TextVisible('Login')"

    async def test_text_not_found(self, mock_transport: object) -> None:
        from adbflow.core.transport import SubprocessTransport

        transport = mock_transport
        assert isinstance(transport, SubprocessTransport)
        transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout="<hierarchy />"),
        )
        cond = TextVisible("Login", "emu", transport)
        assert await cond() is False


class TestActivityIs:
    async def test_activity_matches(self, mock_transport: object) -> None:
        from adbflow.core.transport import SubprocessTransport

        transport = mock_transport
        assert isinstance(transport, SubprocessTransport)
        transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout="mResumedActivity=com.app/.MainActivity"),
        )
        cond = ActivityIs("com.app/.MainActivity", "emu", transport)
        assert await cond() is True

    async def test_activity_no_match(self, mock_transport: object) -> None:
        from adbflow.core.transport import SubprocessTransport

        transport = mock_transport
        assert isinstance(transport, SubprocessTransport)
        transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout="mResumedActivity=com.other/.Other"),
        )
        cond = ActivityIs("com.app/.MainActivity", "emu", transport)
        assert await cond() is False


class TestScreenOnOff:
    async def test_screen_on(self, mock_transport: object) -> None:
        from adbflow.core.transport import SubprocessTransport

        transport = mock_transport
        assert isinstance(transport, SubprocessTransport)
        transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout="Display Power: state=ON"),
        )
        assert await ScreenOn("emu", transport)() is True
        assert await ScreenOff("emu", transport)() is False

    async def test_screen_off(self, mock_transport: object) -> None:
        from adbflow.core.transport import SubprocessTransport

        transport = mock_transport
        assert isinstance(transport, SubprocessTransport)
        transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout="Display Power: state=OFF"),
        )
        assert await ScreenOff("emu", transport)() is True
        assert await ScreenOn("emu", transport)() is False


class TestPackageRunning:
    async def test_running(self, mock_transport: object) -> None:
        from adbflow.core.transport import SubprocessTransport

        transport = mock_transport
        assert isinstance(transport, SubprocessTransport)
        transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout="12345"),
        )
        cond = PackageRunning("com.app", "emu", transport)
        assert await cond() is True
        assert "com.app" in cond.name

    async def test_not_running(self, mock_transport: object) -> None:
        from adbflow.core.transport import SubprocessTransport

        transport = mock_transport
        assert isinstance(transport, SubprocessTransport)
        transport.execute_shell = AsyncMock(  # type: ignore[assignment]
            return_value=make_result(stdout=""),
        )
        cond = PackageRunning("com.app", "emu", transport)
        assert await cond() is False


class TestElementExists:
    async def test_exists(self) -> None:
        fn: AsyncMock = AsyncMock(return_value=True)
        cond = ElementExists("button", fn)
        assert await cond() is True
        assert "button" in cond.name

    async def test_not_exists(self) -> None:
        fn: AsyncMock = AsyncMock(return_value=False)
        cond = ElementExists("button", fn)
        assert await cond() is False


# ---------------------------------------------------------------------------
# Combinators
# ---------------------------------------------------------------------------


class TestCombinators:
    async def test_any_of_true(self) -> None:
        c1 = _FakeCondition("a", [False])
        c2 = _FakeCondition("b", [True])
        comb = any_of(c1, c2)
        assert await comb() is True
        assert "AnyOf" in comb.name

    async def test_any_of_false(self) -> None:
        c1 = _FakeCondition("a", [False])
        c2 = _FakeCondition("b", [False])
        assert await AnyOf(c1, c2)() is False

    async def test_all_of_true(self) -> None:
        c1 = _FakeCondition("a", [True])
        c2 = _FakeCondition("b", [True])
        comb = all_of(c1, c2)
        assert await comb() is True
        assert "AllOf" in comb.name

    async def test_all_of_false(self) -> None:
        c1 = _FakeCondition("a", [True])
        c2 = _FakeCondition("b", [False])
        assert await AllOf(c1, c2)() is False

    async def test_not_true(self) -> None:
        c = _FakeCondition("a", [False])
        comb = not_(c)
        assert await comb() is True
        assert "Not" in comb.name

    async def test_not_false(self) -> None:
        c = _FakeCondition("a", [True])
        assert await Not(c)() is False

    async def test_nested_combinators(self) -> None:
        c1 = _FakeCondition("a", [True])
        c2 = _FakeCondition("b", [False])
        c3 = _FakeCondition("c", [True])
        # any_of(all_of(c1, c2), c3) → any_of(False, True) → True
        comb = any_of(all_of(c1, c2), c3)
        assert await comb() is True
