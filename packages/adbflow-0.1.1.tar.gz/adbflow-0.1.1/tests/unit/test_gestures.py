"""Tests for the gestures module."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from adbflow.core.transport import SubprocessTransport
from adbflow.gestures.manager import GestureManager
from adbflow.utils.geometry import Point
from adbflow.utils.types import KeyCode, SwipeDirection

from tests.conftest import make_result


@pytest.fixture
def gestures(mock_transport: SubprocessTransport) -> GestureManager:
    return GestureManager("emu", mock_transport)


class TestTap:
    async def test_tap_with_point(self, gestures: GestureManager) -> None:
        await gestures.tap_async(Point(100, 200))
        gestures._transport.execute_shell.assert_called_once()  # type: ignore[union-attr]
        call_args = gestures._transport.execute_shell.call_args  # type: ignore[union-attr]
        assert "input tap 100 200" in call_args[0][0]

    async def test_tap_with_xy(self, gestures: GestureManager) -> None:
        await gestures.tap_async(300, 400)
        call_args = gestures._transport.execute_shell.call_args  # type: ignore[union-attr]
        assert "input tap 300 400" in call_args[0][0]


class TestLongTap:
    async def test_long_tap(self, gestures: GestureManager) -> None:
        await gestures.long_tap_async(Point(50, 60), duration_ms=2000)
        call_args = gestures._transport.execute_shell.call_args  # type: ignore[union-attr]
        cmd = call_args[0][0]
        assert "input swipe 50 60 50 60 2000" in cmd


class TestSwipe:
    async def test_swipe(self, gestures: GestureManager) -> None:
        await gestures.swipe_async(Point(10, 20), Point(300, 400), duration_ms=500)
        call_args = gestures._transport.execute_shell.call_args  # type: ignore[union-attr]
        cmd = call_args[0][0]
        assert "input swipe 10 20 300 400 500" in cmd


class TestSwipeDirection:
    @pytest.mark.parametrize(
        ("direction", "expected_end"),
        [
            (SwipeDirection.UP, Point(540, 460)),
            (SwipeDirection.DOWN, Point(540, 1460)),
            (SwipeDirection.LEFT, Point(40, 960)),
            (SwipeDirection.RIGHT, Point(1040, 960)),
        ],
    )
    async def test_swipe_directions(
        self,
        gestures: GestureManager,
        direction: SwipeDirection,
        expected_end: Point,
    ) -> None:
        await gestures.swipe_direction_async(direction, distance=500)
        call_args = gestures._transport.execute_shell.call_args  # type: ignore[union-attr]
        cmd: str = call_args[0][0]
        assert f"{expected_end.x} {expected_end.y}" in cmd

    async def test_swipe_direction_custom_start(self, gestures: GestureManager) -> None:
        await gestures.swipe_direction_async(
            SwipeDirection.UP, start=Point(100, 500), distance=200
        )
        call_args = gestures._transport.execute_shell.call_args  # type: ignore[union-attr]
        cmd: str = call_args[0][0]
        assert "100 500" in cmd
        assert "100 300" in cmd


class TestDrag:
    async def test_drag(self, gestures: GestureManager) -> None:
        await gestures.drag_async(Point(10, 20), Point(300, 400))
        call_args = gestures._transport.execute_shell.call_args  # type: ignore[union-attr]
        cmd = call_args[0][0]
        assert "input swipe 10 20 300 400 1000" in cmd


class TestPinch:
    async def test_pinch_in(self, gestures: GestureManager) -> None:
        await gestures.pinch_in_async(Point(540, 960))
        gestures._transport.execute_shell.assert_called_once()  # type: ignore[union-attr]
        call_args = gestures._transport.execute_shell.call_args  # type: ignore[union-attr]
        cmd: str = call_args[0][0]
        assert "motionevent" in cmd

    async def test_pinch_out(self, gestures: GestureManager) -> None:
        await gestures.pinch_out_async(Point(540, 960))
        gestures._transport.execute_shell.assert_called_once()  # type: ignore[union-attr]
        call_args = gestures._transport.execute_shell.call_args  # type: ignore[union-attr]
        cmd: str = call_args[0][0]
        assert "motionevent" in cmd


class TestText:
    async def test_text_simple(self, gestures: GestureManager) -> None:
        await gestures.text_async("hello")
        call_args = gestures._transport.execute_shell.call_args  # type: ignore[union-attr]
        cmd: str = call_args[0][0]
        assert "input text" in cmd
        assert "hello" in cmd

    async def test_text_spaces_replaced(self, gestures: GestureManager) -> None:
        await gestures.text_async("hello world")
        call_args = gestures._transport.execute_shell.call_args  # type: ignore[union-attr]
        cmd: str = call_args[0][0]
        assert "hello%sworld" in cmd


class TestKey:
    async def test_key_event(self, gestures: GestureManager) -> None:
        await gestures.key_async(KeyCode.HOME)
        call_args = gestures._transport.execute_shell.call_args  # type: ignore[union-attr]
        cmd: str = call_args[0][0]
        assert "input keyevent 3" in cmd

    async def test_key_event_int(self, gestures: GestureManager) -> None:
        await gestures.key_async(66)
        call_args = gestures._transport.execute_shell.call_args  # type: ignore[union-attr]
        cmd: str = call_args[0][0]
        assert "input keyevent 66" in cmd
