"""Tests for the UI selector."""

from __future__ import annotations

from adbflow.ui.hierarchy import UINode, parse_hierarchy
from adbflow.ui.selector import Selector
from adbflow.utils.geometry import Rect


def _make_node(
    text: str = "",
    resource_id: str = "",
    class_name: str = "",
    package: str = "",
    content_desc: str = "",
    clickable: bool = False,
    enabled: bool = True,
    scrollable: bool = False,
    checkable: bool = False,
    checked: bool = False,
    focusable: bool = False,
    focused: bool = False,
    long_clickable: bool = False,
    selected: bool = False,
    index: int = 0,
    children: tuple[UINode, ...] = (),
) -> UINode:
    return UINode(
        text=text,
        resource_id=resource_id,
        class_name=class_name,
        package=package,
        content_desc=content_desc,
        checkable=checkable,
        checked=checked,
        clickable=clickable,
        enabled=enabled,
        focusable=focusable,
        focused=focused,
        scrollable=scrollable,
        long_clickable=long_clickable,
        selected=selected,
        bounds=Rect(0, 0, 100, 100),
        index=index,
        children=children,
    )


class TestSelectorMatching:
    def test_match_text(self) -> None:
        sel = Selector().text("Login")
        assert sel.matches(_make_node(text="Login"))
        assert not sel.matches(_make_node(text="Logout"))

    def test_match_text_contains(self) -> None:
        sel = Selector().text_contains("ogi")
        assert sel.matches(_make_node(text="Login"))
        assert not sel.matches(_make_node(text="Submit"))

    def test_match_text_starts_with(self) -> None:
        sel = Selector().text_starts_with("Log")
        assert sel.matches(_make_node(text="Login"))
        assert sel.matches(_make_node(text="Logout"))
        assert not sel.matches(_make_node(text="Submit"))

    def test_match_resource_id(self) -> None:
        sel = Selector().resource_id("com.app:id/btn")
        assert sel.matches(_make_node(resource_id="com.app:id/btn"))
        assert not sel.matches(_make_node(resource_id="com.app:id/other"))

    def test_match_resource_id_contains(self) -> None:
        sel = Selector().resource_id_contains("btn")
        assert sel.matches(_make_node(resource_id="com.app:id/btn_login"))

    def test_match_class_name(self) -> None:
        sel = Selector().class_name("android.widget.Button")
        assert sel.matches(_make_node(class_name="android.widget.Button"))
        assert not sel.matches(_make_node(class_name="android.widget.TextView"))

    def test_match_package(self) -> None:
        sel = Selector().package("com.app")
        assert sel.matches(_make_node(package="com.app"))

    def test_match_description(self) -> None:
        sel = Selector().description("Close")
        assert sel.matches(_make_node(content_desc="Close"))
        assert not sel.matches(_make_node(content_desc="Open"))

    def test_match_description_contains(self) -> None:
        sel = Selector().description_contains("Clo")
        assert sel.matches(_make_node(content_desc="Close"))

    def test_match_clickable(self) -> None:
        sel = Selector().clickable()
        assert sel.matches(_make_node(clickable=True))
        assert not sel.matches(_make_node(clickable=False))

    def test_match_enabled(self) -> None:
        sel = Selector().enabled(False)
        assert sel.matches(_make_node(enabled=False))
        assert not sel.matches(_make_node(enabled=True))

    def test_match_scrollable(self) -> None:
        sel = Selector().scrollable()
        assert sel.matches(_make_node(scrollable=True))

    def test_match_checkable(self) -> None:
        sel = Selector().checkable()
        assert sel.matches(_make_node(checkable=True))

    def test_match_checked(self) -> None:
        sel = Selector().checked()
        assert sel.matches(_make_node(checked=True))

    def test_match_focusable(self) -> None:
        sel = Selector().focusable()
        assert sel.matches(_make_node(focusable=True))

    def test_match_focused(self) -> None:
        sel = Selector().focused()
        assert sel.matches(_make_node(focused=True))

    def test_match_long_clickable(self) -> None:
        sel = Selector().long_clickable()
        assert sel.matches(_make_node(long_clickable=True))

    def test_match_selected(self) -> None:
        sel = Selector().selected()
        assert sel.matches(_make_node(selected=True))

    def test_match_index(self) -> None:
        sel = Selector().index(2)
        assert sel.matches(_make_node(index=2))
        assert not sel.matches(_make_node(index=0))

    def test_match_multiple_criteria(self) -> None:
        sel = Selector().text("OK").clickable().enabled()
        assert sel.matches(_make_node(text="OK", clickable=True, enabled=True))
        assert not sel.matches(_make_node(text="OK", clickable=False, enabled=True))

    def test_no_criteria_matches_all(self) -> None:
        sel = Selector()
        assert sel.matches(_make_node())
        assert sel.matches(_make_node(text="anything"))

    def test_child_selector(self) -> None:
        child = _make_node(text="InnerBtn", clickable=True)
        parent = _make_node(text="Container", children=(child,))
        sel = Selector().text("Container").child(Selector().text("InnerBtn"))
        assert sel.matches(parent)

    def test_child_selector_no_match(self) -> None:
        child = _make_node(text="Other")
        parent = _make_node(text="Container", children=(child,))
        sel = Selector().text("Container").child(Selector().text("InnerBtn"))
        assert not sel.matches(parent)


class TestSelectorDescribe:
    def test_describe_empty(self) -> None:
        desc = Selector().describe()
        assert desc == "Selector(<any>)"

    def test_describe_with_criteria(self) -> None:
        desc = Selector().text("Login").clickable().describe()
        assert "text='Login'" in desc
        assert "clickable=True" in desc


class TestSelectorFluent:
    def test_chaining_returns_self(self) -> None:
        sel = Selector()
        result = sel.text("x").clickable().enabled()
        assert result is sel
