"""Tests for ADB command builder."""

from __future__ import annotations

import pytest

from adbflow.utils.command import ADBCommand, escape_shell_arg
from adbflow.utils.exceptions import CommandBuildError


class TestEscapeShellArg:
    def test_empty_string(self) -> None:
        assert escape_shell_arg("") == "''"

    def test_safe_string(self) -> None:
        assert escape_shell_arg("hello") == "hello"

    def test_string_with_spaces(self) -> None:
        assert escape_shell_arg("hello world") == "'hello world'"

    def test_string_with_single_quote(self) -> None:
        assert escape_shell_arg("it's") == "'it'\\''s'"

    def test_path_safe(self) -> None:
        assert escape_shell_arg("/data/local/tmp/test.apk") == "/data/local/tmp/test.apk"


class TestADBCommand:
    def test_basic_build(self) -> None:
        cmd = ADBCommand().args("devices", "-l").build()
        assert cmd == ["adb", "devices", "-l"]

    def test_with_serial(self) -> None:
        cmd = ADBCommand().serial("emulator-5554").args("shell", "ls").build()
        assert cmd == ["adb", "-s", "emulator-5554", "shell", "ls"]

    def test_with_flag(self) -> None:
        cmd = ADBCommand().args("install").flag("-r").flag("-t").build()
        assert cmd == ["adb", "install", "-r", "-t"]

    def test_shell_command(self) -> None:
        cmd = ADBCommand().serial("abc").shell("getprop ro.build.model").build()
        assert cmd == ["adb", "-s", "abc", "shell", "getprop", "ro.build.model"]

    def test_custom_adb_path(self) -> None:
        cmd = ADBCommand(adb_path="/opt/adb").args("version").build()
        assert cmd[0] == "/opt/adb"

    def test_shell_and_args_raises(self) -> None:
        with pytest.raises(CommandBuildError):
            ADBCommand().args("install").shell("ls").build()

    def test_build_shell_string(self) -> None:
        result = ADBCommand().args("devices").build_shell_string()
        assert "adb" in result
        assert "devices" in result
