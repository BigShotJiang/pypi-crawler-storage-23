"""E2E tests for media operations — screenshot, audio, recording."""

from __future__ import annotations

import asyncio
import tempfile
from pathlib import Path

import pytest
from PIL import Image

from adbflow.device.device import Device
from adbflow.utils.types import AudioStream


class TestScreenshot:
    """Screenshot capture."""

    async def test_capture_bytes(self, device: Device):
        data = await device.media.screenshot.capture_async()
        assert isinstance(data, bytes)
        assert len(data) > 1000  # Should be a valid PNG
        assert data[:4] == b"\x89PNG"

    async def test_capture_to_file(self, device: Device):
        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f:
            path = f.name
        await device.media.screenshot.capture_to_file_async(path)
        assert Path(path).exists()
        assert Path(path).stat().st_size > 1000
        Path(path).unlink(missing_ok=True)

    async def test_capture_pil(self, device: Device):
        img = await device.media.screenshot.capture_pil_async()
        assert isinstance(img, Image.Image)
        assert img.width > 0
        assert img.height > 0

    async def test_device_screenshot_shortcut(self, device: Device):
        data = await device.screenshot_async()
        assert isinstance(data, bytes)
        assert data[:4] == b"\x89PNG"


class TestAudio:
    """Audio volume operations with real state changes."""

    async def test_get_volume(self, device: Device):
        vol = await device.media.audio.get_volume_async(AudioStream.MUSIC)
        assert isinstance(vol, int)
        assert vol >= 0

    async def test_volume_up_increases(self, device: Device):
        """Press VOLUME_DOWN then VOLUME_UP — verify volume changed."""
        from adbflow.utils.types import KeyCode
        # Lower volume first
        await device.shell_async(f"input keyevent {int(KeyCode.VOLUME_DOWN)}")
        await asyncio.sleep(0.3)
        await device.shell_async(f"input keyevent {int(KeyCode.VOLUME_DOWN)}")
        await asyncio.sleep(0.3)

        before = await device.media.audio.get_volume_async(AudioStream.MUSIC)
        await device.shell_async(f"input keyevent {int(KeyCode.VOLUME_UP)}")
        await asyncio.sleep(0.5)
        after = await device.media.audio.get_volume_async(AudioStream.MUSIC)
        assert after > before

    async def test_is_muted(self, device: Device):
        """Read mute status — with volume > 0, should not be muted."""
        from adbflow.utils.types import KeyCode
        # Ensure volume is up
        for _ in range(3):
            await device.shell_async(f"input keyevent {int(KeyCode.VOLUME_UP)}")
            await asyncio.sleep(0.2)

        muted = await device.media.audio.is_muted_async(AudioStream.MUSIC)
        assert muted is False


class TestRecording:
    """Screen recording with file verification."""

    async def test_record_and_pull(self, device: Device):
        """Start recording, wait, stop, pull locally — verify valid mp4 file."""
        await device.media.recording.start_async()
        await asyncio.sleep(3)
        await device.media.recording.stop_async()
        await asyncio.sleep(1)

        with tempfile.NamedTemporaryFile(suffix=".mp4", delete=False) as f:
            local_path = f.name
        await device.media.recording.pull_async(local_path)

        assert Path(local_path).exists()
        size = Path(local_path).stat().st_size
        assert size > 0
        Path(local_path).unlink(missing_ok=True)
