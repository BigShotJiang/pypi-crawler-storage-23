"""E2E tests for UI automation — hierarchy, selectors, elements."""

from __future__ import annotations

import asyncio

import pytest

from adbflow.device.device import Device
from adbflow.ui.selector import Selector
from adbflow.utils.exceptions import WaitTimeoutError

PKG = "com.adbflow.test"


class TestUIDump:
    """UI hierarchy dump operations."""

    async def test_dump_contains_app_elements(self, launched_app: Device):
        """Dump hierarchy and verify it contains known elements from the test app."""
        device = launched_app
        root = await device.ui.dump_async(force=True)
        assert root is not None
        # Iterate all nodes and find our app's title
        texts = [n.text for n in root.iter_all()]
        assert "ADBFlow Test App" in texts

    async def test_dump_cached_returns_same_content(self, launched_app: Device):
        """Dump twice (second from cache), verify both have the same title text."""
        device = launched_app
        root1 = await device.ui.dump_async(force=True)
        root2 = await device.ui.dump_async()  # Should use cache
        texts1 = [n.text for n in root1.iter_all()]
        texts2 = [n.text for n in root2.iter_all()]
        assert "ADBFlow Test App" in texts1
        assert "ADBFlow Test App" in texts2

    async def test_dump_force_refresh_after_interaction(self, launched_app: Device):
        """Interact with the UI, then force-dump — verify new state is reflected."""
        device = launched_app
        # Type into input field
        el = await device.ui.find_async(
            Selector().resource_id(f"{PKG}:id/input_field")
        )
        assert el is not None
        await el.tap_async()
        await asyncio.sleep(0.3)
        await device.gestures.text_async("dump_test")
        await asyncio.sleep(0.3)

        # Force dump should reflect the typed text
        root = await device.ui.dump_async(force=True)
        texts = [n.text for n in root.iter_all()]
        assert any("dump_test" in t for t in texts)


class TestUIFind:
    """Element finding by various selectors."""

    async def test_find_by_text(self, launched_app: Device):
        device = launched_app
        el = await device.ui.find_async(Selector().text("ADBFlow Test App"))
        assert el is not None
        assert el.get_text() == "ADBFlow Test App"

    async def test_find_by_text_contains(self, launched_app: Device):
        device = launched_app
        el = await device.ui.find_async(Selector().text_contains("ADBFlow"))
        assert el is not None
        assert "ADBFlow" in el.get_text()

    async def test_find_by_resource_id(self, launched_app: Device):
        device = launched_app
        el = await device.ui.find_async(
            Selector().resource_id(f"{PKG}:id/title_text")
        )
        assert el is not None

    async def test_find_by_class_name(self, launched_app: Device):
        device = launched_app
        el = await device.ui.find_async(
            Selector().class_name("android.widget.Button")
        )
        assert el is not None

    async def test_find_by_package(self, launched_app: Device):
        device = launched_app
        el = await device.ui.find_async(
            Selector().package(PKG).text("ADBFlow Test App")
        )
        assert el is not None

    async def test_find_clickable(self, launched_app: Device):
        device = launched_app
        el = await device.ui.find_async(
            Selector().text("OPEN SECOND").clickable()
        )
        assert el is not None

    async def test_find_checkable(self, launched_app: Device):
        device = launched_app
        el = await device.ui.find_async(Selector().checkable())
        assert el is not None

    async def test_find_scrollable(self, launched_app: Device):
        device = launched_app
        el = await device.ui.find_async(Selector().scrollable())
        assert el is not None

    async def test_find_all(self, launched_app: Device):
        device = launched_app
        elements = await device.ui.find_all_async(
            Selector().class_name("android.widget.Button")
        )
        assert len(elements) >= 4  # btn_second, btn_dialog, btn_notify, btn_broadcast

    async def test_exists_true(self, launched_app: Device):
        device = launched_app
        assert await device.ui.exists_async(Selector().text("ADBFlow Test App"))

    async def test_exists_false(self, launched_app: Device):
        device = launched_app
        assert not await device.ui.exists_async(
            Selector().text("This text does not exist XYZ123")
        )


class TestUIElement:
    """Element interaction."""

    async def test_get_text(self, launched_app: Device):
        device = launched_app
        el = await device.ui.find_async(Selector().text("ADBFlow Test App"))
        assert el is not None
        assert el.get_text() == "ADBFlow Test App"

    async def test_get_bounds(self, launched_app: Device):
        device = launched_app
        el = await device.ui.find_async(Selector().text("ADBFlow Test App"))
        assert el is not None
        bounds = el.get_bounds()
        assert bounds.width > 0
        assert bounds.height > 0

    async def test_get_center(self, launched_app: Device):
        device = launched_app
        el = await device.ui.find_async(Selector().text("ADBFlow Test App"))
        assert el is not None
        center = el.get_center()
        assert center.x > 0
        assert center.y > 0

    async def test_tap(self, launched_app: Device):
        device = launched_app
        el = await device.ui.find_async(Selector().text("OPEN SECOND"))
        assert el is not None
        await el.tap_async()
        await asyncio.sleep(1.5)
        # Should navigate to SecondActivity
        found = await device.ui.find_async(Selector().text("Second Activity"))
        assert found is not None
        await device.keyevent_async(4)  # BACK
        await asyncio.sleep(0.5)

    async def test_long_tap(self, launched_app: Device):
        """Long tap on title — verify app stays on same activity (no crash/nav)."""
        device = launched_app
        el = await device.ui.find_async(Selector().text("ADBFlow Test App"))
        assert el is not None
        await el.long_tap_async(duration_ms=500)
        await asyncio.sleep(0.5)

        # Verify we're still on MainActivity
        await device.ui.dump_async(force=True)
        title = await device.ui.find_async(Selector().text("ADBFlow Test App"))
        assert title is not None

    async def test_text_input(self, launched_app: Device):
        device = launched_app
        el = await device.ui.find_async(
            Selector().resource_id(f"{PKG}:id/input_field")
        )
        assert el is not None
        await el.text_input_async("hello")
        await asyncio.sleep(0.5)

    async def test_swipe_element(self, launched_app: Device):
        device = launched_app
        from adbflow.utils.types import SwipeDirection
        scroll = await device.ui.find_async(Selector().scrollable())
        if scroll is not None:
            await scroll.swipe_async(SwipeDirection.UP, distance=300)
            await asyncio.sleep(0.5)


class TestUIWait:
    """Wait for UI elements."""

    async def test_wait_for_immediate(self, launched_app: Device):
        device = launched_app
        el = await device.ui.wait_for_async(
            Selector().text("ADBFlow Test App"), timeout=5.0
        )
        assert el is not None

    async def test_wait_for_timeout(self, launched_app: Device):
        device = launched_app
        with pytest.raises(WaitTimeoutError):
            await device.ui.wait_for_async(
                Selector().text("Nonexistent Element XYZ"), timeout=2.0
            )
