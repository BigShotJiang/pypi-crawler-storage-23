"""E2E tests for file operations."""

from __future__ import annotations

import tempfile
from pathlib import Path

import pytest

from adbflow.device.device import Device


class TestFileOperations:
    """File push/pull/read/write on device."""

    async def test_push_pull_roundtrip(self, device: Device, tmp_remote_dir: str):
        content = "hello adbflow e2e test\n"
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
            f.write(content)
            local_src = f.name

        remote = f"{tmp_remote_dir}/test_push.txt"
        await device.files.push_async(local_src, remote)

        with tempfile.NamedTemporaryFile(suffix=".txt", delete=False) as f:
            local_dst = f.name

        await device.files.pull_async(remote, local_dst)
        pulled = Path(local_dst).read_text()
        assert pulled.strip() == content.strip()

        # Cleanup
        Path(local_src).unlink(missing_ok=True)
        Path(local_dst).unlink(missing_ok=True)

    async def test_exists_true(self, device: Device, tmp_remote_dir: str):
        remote = f"{tmp_remote_dir}/exists_test.txt"
        await device.shell_async(f"echo test > {remote}")
        assert await device.files.exists_async(remote)

    async def test_exists_false(self, device: Device, tmp_remote_dir: str):
        assert not await device.files.exists_async(f"{tmp_remote_dir}/nonexistent.txt")

    async def test_stat(self, device: Device, tmp_remote_dir: str):
        remote = f"{tmp_remote_dir}/stat_test.txt"
        await device.shell_async(f"echo hello > {remote}")
        info = await device.files.stat_async(remote)
        assert info is not None

    async def test_cat(self, device: Device, tmp_remote_dir: str):
        remote = f"{tmp_remote_dir}/cat_test.txt"
        await device.shell_async(f"echo 'line content' > {remote}")
        content = await device.files.cat_async(remote)
        assert "line content" in content

    async def test_head(self, device: Device, tmp_remote_dir: str):
        remote = f"{tmp_remote_dir}/head_test.txt"
        lines = "\n".join(f"line{i}" for i in range(20))
        await device.shell_async(f"printf '{lines}' > {remote}")
        head = await device.files.head_async(remote, lines=5)
        assert "line0" in head
        assert "line4" in head

    async def test_tail(self, device: Device, tmp_remote_dir: str):
        remote = f"{tmp_remote_dir}/tail_test.txt"
        lines = "\n".join(f"line{i}" for i in range(20))
        await device.shell_async(f"printf '{lines}' > {remote}")
        tail = await device.files.tail_async(remote, lines=3)
        assert "line19" in tail

    async def test_ls(self, device: Device, tmp_remote_dir: str):
        await device.shell_async(f"echo a > {tmp_remote_dir}/ls1.txt")
        await device.shell_async(f"echo b > {tmp_remote_dir}/ls2.txt")
        entries = await device.files.ls_async(tmp_remote_dir)
        names = [e.name for e in entries]
        assert "ls1.txt" in names
        assert "ls2.txt" in names

    async def test_mkdir(self, device: Device, tmp_remote_dir: str):
        new_dir = f"{tmp_remote_dir}/new_subdir/nested"
        await device.files.mkdir_async(new_dir, parents=True)
        assert await device.files.exists_async(new_dir)

    async def test_cp(self, device: Device, tmp_remote_dir: str):
        src = f"{tmp_remote_dir}/cp_src.txt"
        dst = f"{tmp_remote_dir}/cp_dst.txt"
        await device.shell_async(f"echo copied > {src}")
        await device.files.cp_async(src, dst)
        content = await device.files.cat_async(dst)
        assert "copied" in content

    async def test_mv(self, device: Device, tmp_remote_dir: str):
        src = f"{tmp_remote_dir}/mv_src.txt"
        dst = f"{tmp_remote_dir}/mv_dst.txt"
        await device.shell_async(f"echo moved > {src}")
        await device.files.mv_async(src, dst)
        assert not await device.files.exists_async(src)
        assert await device.files.exists_async(dst)

    async def test_rm(self, device: Device, tmp_remote_dir: str):
        remote = f"{tmp_remote_dir}/rm_test.txt"
        await device.shell_async(f"echo delete > {remote}")
        await device.files.rm_async(remote)
        assert not await device.files.exists_async(remote)

    async def test_rm_recursive(self, device: Device, tmp_remote_dir: str):
        subdir = f"{tmp_remote_dir}/rm_recursive_dir"
        await device.files.mkdir_async(subdir)
        await device.shell_async(f"echo x > {subdir}/file.txt")
        await device.files.rm_async(subdir, recursive=True, force=True)
        assert not await device.files.exists_async(subdir)
