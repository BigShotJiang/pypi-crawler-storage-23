"""E2E tests for wait conditions and engine — all against real device state."""

from __future__ import annotations

import asyncio

import pytest

from adbflow.device.device import Device
from adbflow.ui.selector import Selector
from adbflow.utils.exceptions import WaitTimeoutError
from adbflow.wait.conditions import (
    ActivityIs,
    ElementExists,
    PackageRunning,
    ScreenOn,
)
from adbflow.wait.engine import wait_for

PKG = "com.adbflow.test"


class TestScreenConditions:
    """ScreenOn condition with real device wake."""

    async def test_wake_then_wait_for_screen_on(self, device: Device):
        """Wake the device, then wait_for ScreenOn — should resolve True."""
        await device.power.wake_async()
        condition = ScreenOn(device.serial, device.transport)
        result = await wait_for(condition, timeout=5.0)
        assert result is True

    async def test_screen_on_after_unlock(self, device: Device):
        """Unlock and verify screen is on via is_screen_on_async."""
        await device.power.wake_async()
        await device.power.unlock_async()
        is_on = await device.power.is_screen_on_async()
        assert is_on is True


class TestPackageRunning:
    """PackageRunning condition with real app lifecycle."""

    async def test_launch_then_wait_for_running(self, device: Device):
        """Launch the app, then wait for PackageRunning to be True."""
        await device.apps.start_async(PKG, ".MainActivity")
        await asyncio.sleep(1.5)
        condition = PackageRunning(PKG, device.serial, device.transport)
        result = await wait_for(condition, timeout=5.0)
        assert result is True
        await device.apps.stop_async(PKG)

    async def test_stop_then_check_not_running(self, device: Device):
        """Stop the app, verify PackageRunning returns False."""
        await device.apps.stop_async(PKG)
        await asyncio.sleep(0.5)
        condition = PackageRunning(PKG, device.serial, device.transport)
        result = await condition()
        assert result is False


class TestTextVisible:
    """TextVisible condition via device convenience methods."""

    async def test_wait_for_text_on_screen(self, launched_app: Device):
        """App is launched, wait for title text — should resolve immediately."""
        device = launched_app
        result = await device.wait_for_text_async("ADBFlow Test App", timeout=5.0)
        assert result is True

    async def test_wait_for_text_after_navigation(self, launched_app: Device):
        """Navigate to SecondActivity, wait for its title text."""
        device = launched_app
        btn = await device.ui.find_async(Selector().text("OPEN SECOND"))
        assert btn is not None
        await btn.tap_async()

        result = await device.wait_for_text_async("Second Activity", timeout=5.0)
        assert result is True

        await device.keyevent_async(4)  # BACK
        await asyncio.sleep(0.5)

    async def test_wait_for_text_timeout(self, launched_app: Device):
        """Wait for non-existent text — should timeout."""
        device = launched_app
        with pytest.raises(WaitTimeoutError):
            await device.wait_for_text_async(
                "This Text Will Never Exist 12345", timeout=2.0
            )


class TestActivityIs:
    """ActivityIs condition with real activity transitions."""

    async def test_wait_for_main_activity(self, launched_app: Device):
        """App is launched, wait for MainActivity to be the current activity."""
        device = launched_app
        result = await device.wait_for_activity_async("MainActivity", timeout=5.0)
        assert result is True

    async def test_wait_for_wrong_activity_returns_false(self, launched_app: Device):
        """Directly poll for a non-existent activity — returns False."""
        device = launched_app
        condition = ActivityIs("NonExistentActivity999", device.serial, device.transport)
        result = await condition()
        assert result is False

    async def test_navigate_then_wait_for_second_activity(self, launched_app: Device):
        """Tap OPEN SECOND, then wait for SecondActivity."""
        device = launched_app
        btn = await device.ui.find_async(Selector().text("OPEN SECOND"))
        assert btn is not None
        await btn.tap_async()
        await asyncio.sleep(0.5)

        result = await device.wait_for_activity_async("SecondActivity", timeout=5.0)
        assert result is True

        await device.keyevent_async(4)  # BACK
        await asyncio.sleep(0.5)


class TestElementExists:
    """ElementExists condition with real UI queries."""

    async def test_element_exists_on_screen(self, launched_app: Device):
        """Wait for the title element to exist — resolves immediately."""
        device = launched_app

        async def check():
            return await device.ui.exists_async(Selector().text("ADBFlow Test App"))

        condition = ElementExists("title text", check)
        result = await wait_for(condition, timeout=5.0)
        assert result is True

    async def test_element_not_exists_timeout(self, launched_app: Device):
        """Wait for a non-existent element — should timeout."""
        device = launched_app

        async def check():
            return await device.ui.exists_async(Selector().text("Nope XYZ"))

        condition = ElementExists("missing element", check)
        with pytest.raises(WaitTimeoutError):
            await wait_for(condition, timeout=2.0)


class TestWaitEngine:
    """Wait engine timeout behavior against device."""

    async def test_wait_for_timeout_on_device(self, device: Device):
        """Always-false device condition times out correctly."""
        async def package_not_there():
            # Check for a package that definitely doesn't exist
            result = await device.shell_async("pm list packages com.fake.xyz999")
            return "com.fake.xyz999" in result

        package_not_there.name = "FakePackageCheck"  # type: ignore[attr-defined]
        with pytest.raises(WaitTimeoutError):
            await wait_for(package_not_there, timeout=2.0)  # type: ignore[arg-type]
