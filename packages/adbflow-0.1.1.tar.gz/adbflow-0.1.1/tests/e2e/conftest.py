"""E2E test fixtures for adbflow against a real Android device."""

from __future__ import annotations

import asyncio
import os
from pathlib import Path

import pytest

from adbflow import ADB
from adbflow.device.device import Device

PKG = "com.adbflow.test"
MAIN_ACTIVITY = ".MainActivity"

# Resolve APK path relative to project root
_PROJECT_ROOT = Path(__file__).resolve().parents[2]
_APK_PATH = _PROJECT_ROOT.parent / "adbflow-test" / "adbflow-test.apk"


@pytest.fixture(scope="session")
def event_loop():
    """Session-scoped event loop for async fixtures."""
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()


@pytest.fixture(scope="session")
def device(event_loop: asyncio.AbstractEventLoop) -> Device:
    """Get the first connected device, wake and unlock screen."""
    adb = ADB()
    dev = event_loop.run_until_complete(adb.device_async())
    # Wake and unlock
    event_loop.run_until_complete(dev.power.wake_async())
    event_loop.run_until_complete(dev.power.unlock_async())
    return dev


@pytest.fixture(scope="session", autouse=True)
def install_test_apk(device: Device, event_loop: asyncio.AbstractEventLoop):
    """Install the test APK before session, uninstall after."""
    apk = str(_APK_PATH)
    assert os.path.isfile(apk), f"Test APK not found at {apk}"

    async def setup():
        # Uninstall first if present
        if await device.apps.is_installed_async(PKG):
            await device.apps.uninstall_async(PKG)
        await device.apps.install_async(apk)

    async def teardown():
        try:
            await device.apps.stop_async(PKG)
        except Exception:
            pass
        try:
            await device.apps.uninstall_async(PKG)
        except Exception:
            pass

    event_loop.run_until_complete(setup())
    yield
    event_loop.run_until_complete(teardown())


@pytest.fixture
async def launched_app(device: Device):
    """Launch MainActivity before test, stop and go HOME after."""
    await device.apps.start_async(PKG, MAIN_ACTIVITY)
    await asyncio.sleep(1.5)
    yield device
    await device.apps.stop_async(PKG)
    await device.keyevent_async(3)  # HOME
    await asyncio.sleep(0.5)


@pytest.fixture
async def clean_state(device: Device):
    """Go HOME before and after test."""
    await device.keyevent_async(3)  # HOME
    await asyncio.sleep(0.5)
    yield device
    await device.keyevent_async(3)
    await asyncio.sleep(0.5)


@pytest.fixture
async def tmp_remote_dir(device: Device):
    """Create a temp directory on device, clean up after."""
    path = "/sdcard/adbflow_e2e_test"
    await device.files.mkdir_async(path)
    yield path
    try:
        await device.files.rm_async(path, recursive=True, force=True)
    except Exception:
        pass
