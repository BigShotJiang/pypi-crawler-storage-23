# coding=utf-8
import os

from easy_use_tools.utils.common import base
def show_config_folder():
    root_path = base.get_root_path()
    conf_path = os.path.join(root_path,'conf')
    print(f"修改配置文件的目录是: {conf_path}/*.toml")


def show_helper():
    from prettytable import PrettyTable
    from prettytable import ALL, FRAME, NONE, HEADER
    # 创建一个表格实例
    table = PrettyTable()
    table.title = "本pip包支持可执行功能"
    # 设置表格的列名
    table.field_names = ["命令", "作用"]

    # 添加多行数据
    pkg_conf_path = os.path.join(os.path.dirname(base.get_root_path()),'pyproject.toml')
    # 读取配置文件
    with open(pkg_conf_path,'r+',encoding='utf-8') as f_r:
        tmp_str = f_r.read()
        a_str = tmp_str.split('[tool.poetry.scripts]')[-1]
        b_str = a_str.split('[tool.setuptools]')[0]
        for i in b_str.split('\n'):
            if '=' and '#' in i:
                cmd_str = i.split("=")[0].strip()
                des_str = i.split("#")[-1].strip()
                table.add_row([cmd_str,des_str])
    # 启用行与行之间的横线
    table.hrules = ALL

    # 设置表格样式（可选）
    # table.align = "l"  # 文本左对齐
    # 打印表格
    print(table)

# show_helper()


