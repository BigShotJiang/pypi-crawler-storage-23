# coding=utf-8
from flask import Flask, jsonify, request, render_template
import datetime

# 创建 Flask 应用
app = Flask(__name__)


# 首页路由 - 返回简单的欢迎信息
@app.route('/')
def home():
    return """
    <h1>Flask 服务运行成功！</h1>
    <p>当前时间: {}</p>
    <h3>可用接口：</h3>
    <ul>
        <li><a href="/">首页</a> (当前页面)</li>
        <li><a href="/api/hello">/api/hello</a> - 返回欢迎信息</li>
        <li><a href="/api/time">/api/time</a> - 返回服务器时间</li>
        <li><a href="/api/data">/api/data</a> - 返回示例JSON数据</li>
        <li><a href="/api/echo?text=你好">/api/echo?text=你好</a> - 回显你发送的文本</li>
        <li><a href="/hello/你的名字">/hello/你的名字</a> - 个性化问候</li>
    </ul>
    <p>使用 GET 或 POST 请求测试接口。</p>
    """.format(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))


# 返回 JSON 数据的 API 接口
@app.route('/api/hello')
def api_hello():
    return jsonify({
        "message": "你好！这是一个 Flask API 示例",
        "status": "success",
        "code": 200
    })


# 返回服务器时间的接口
@app.route('/api/time')
def api_time():
    current_time = datetime.datetime.now()
    return jsonify({
        "timestamp": current_time.timestamp(),
        "datetime": current_time.strftime("%Y-%m-%d %H:%M:%S"),
        "timezone": "UTC+8"
    })


# 带路径参数的路由
@app.route('/hello/<name>')
def hello_name(name):
    return f"<h2>你好, {name}!</h2><p>欢迎使用 Flask 服务。</p><a href='/'>返回首页</a>"


# 带查询参数的接口
@app.route('/api/echo')
def api_echo():
    # 获取查询参数，例如 /api/echo?text=你好
    text = request.args.get('text', 'Hello World!')
    return jsonify({
        "original_text": text,
        "echo": text,
        "length": len(text)
    })


# 处理 POST 请求的接口
@app.route('/api/submit', methods=['POST'])
def api_submit():
    # 获取 POST 请求的 JSON 数据
    data = request.get_json()

    if not data:
        return jsonify({
            "error": "没有接收到数据",
            "status": "fail"
        }), 400

    return jsonify({
        "message": "数据接收成功",
        "received_data": data,
        "status": "success",
        "timestamp": datetime.datetime.now().timestamp()
    })


# 返回示例数据的接口
@app.route('/api/data')
def api_data():
    sample_data = [
        {"id": 1, "name": "张三", "age": 25, "city": "北京"},
        {"id": 2, "name": "李四", "age": 30, "city": "上海"},
        {"id": 3, "name": "王五", "age": 28, "city": "深圳"}
    ]
    return jsonify({
        "data": sample_data,
        "count": len(sample_data),
        "description": "示例用户数据"
    })


# 一个简单的 HTML 页面示例
@app.route('/page')
def show_page():
    return '''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Flask 页面示例</title>
        <style>
            body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }
            h1 { color: #333; }
            .card { border: 1px solid #ddd; border-radius: 5px; padding: 15px; margin: 10px 0; }
            button { padding: 10px 15px; background-color: #4CAF50; color: white; border: none; border-radius: 4px; cursor: pointer; }
            button:hover { background-color: #45a049; }
        </style>
    </head>
    <body>
        <h1>Flask 页面示例</h1>
        <div class="card">
            <h2>这是一个简单的 HTML 页面</h2>
            <p>这个页面完全由 Flask 路由返回的 HTML 字符串渲染。</p>
            <p>当前时间: {}</p>
        </div>
        <button onclick="fetchData()">获取数据</button>
        <div id="result" style="margin-top: 20px;"></div>

        <script>
            function fetchData() {
                fetch('/api/data')
                    .then(response => response.json())
                    .then(data => {
                        document.getElementById('result').innerHTML = 
                            '<h3>获取到的数据：</h3><pre>' + JSON.stringify(data, null, 2) + '</pre>';
                    });
            }
        </script>
    </body>
    </html>
    '''.format(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

# 启动 Flask 应用
def run_flask_server():
    print("=" * 50)
    print("Flask 服务启动中...")
    print("访问地址: http://127.0.0.1:5000")
    print("按 Ctrl+C 停止服务")
    print("=" * 50)

    # 运行应用
    # debug=True 开启调试模式，代码修改后会自动重启
    # host='0.0.0.0' 可以让局域网内其他设备访问
    app.run(debug=True, host='0.0.0.0', port=5000)

