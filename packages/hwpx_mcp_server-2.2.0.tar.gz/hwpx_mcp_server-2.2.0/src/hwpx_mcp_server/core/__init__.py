"""Stateless HWPX 코어 연산."""
