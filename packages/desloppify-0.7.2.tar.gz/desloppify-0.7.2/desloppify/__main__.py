"""Allow running as: python -m desloppify"""

from desloppify.cli import main

main()
