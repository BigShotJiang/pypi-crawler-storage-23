"""Internal state-management package."""
