"""C# detectors package.

Detection modules are introduced in later scaffolding tasks.
"""
