"""Review data package for Python subjective dimensions."""
