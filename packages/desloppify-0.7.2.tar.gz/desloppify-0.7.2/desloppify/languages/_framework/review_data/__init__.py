"""Review data package for shared subjective dimensions."""
