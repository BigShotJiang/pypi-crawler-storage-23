
.. _configuration_usage_index:

Configurations (libcasm.configuration)
======================================

.. toctree::
    :maxdepth: 2
    :hidden:

    configuration_examples


The :py:mod:`libcasm.configuration` module supports construction and comparison of configurations.
