
.. _enumerate_usage_index:

Configuration Enumeration (libcasm.enumerate)
=============================================

.. toctree::
    :maxdepth: 2
    :hidden:

    enumerate_examples


The :py:mod:`libcasm.enumerate` module supports enumerating configurations.
