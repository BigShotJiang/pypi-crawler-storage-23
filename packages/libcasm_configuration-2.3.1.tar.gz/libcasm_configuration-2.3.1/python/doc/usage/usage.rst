Usage
=====

.. toctree::
    :maxdepth: 2
    :hidden:

    occ_events/occ_events

This section of the documentation provides (or will provide) examples using the modules installed as part of libcasm-configuration:


:ref:`occ_events_usage_index`:

- :ref:`occupation-events-basics`
- :ref:`constructing-local-cluster-orbits`


