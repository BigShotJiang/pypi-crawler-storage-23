
.. _clusterography_usage_index:

Cluster orbits (libcasm.clusterography)
=======================================

.. toctree::
    :maxdepth: 2
    :hidden:

    clusterography_examples


The :py:mod:`libcasm.clusterography` module supports construction of orbits of clusters.
