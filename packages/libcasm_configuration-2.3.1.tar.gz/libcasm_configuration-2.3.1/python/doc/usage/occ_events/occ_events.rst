
.. _occ_events_usage_index:

Occupation Events (libcasm.occ_events)
======================================

.. toctree::
    :maxdepth: 2
    :hidden:

    construct_occevent
    construct_occevent_cluster_specs


The :py:mod:`libcasm.occ_events` module supports construction and comparison of events that result in change of occupation.
