..
    DO NOT DELETE! This causes _autosummary to generate stub files

Reference (libcasm-configuration)
=================================

.. autosummary::
    :toctree: _autosummary
    :template: custom-module-template.rst
    :recursive:

    libcasm.clusterography
    libcasm.configuration
    libcasm.enumerate
    libcasm.irreps
    libcasm.local_configuration
    libcasm.occ_events
    libcasm.sym_info
