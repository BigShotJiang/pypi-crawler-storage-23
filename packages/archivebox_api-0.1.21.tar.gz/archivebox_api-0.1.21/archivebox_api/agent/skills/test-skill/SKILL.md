---
name: test-skill
description: A test skill.
version: 0.1.0
tags: [test-skill]
input_modes: [text]
output_modes: [text]
---

# test-skill Skill

## When to use
For testing.

## How to use
Call it.

## Examples
- Example 1: ...
