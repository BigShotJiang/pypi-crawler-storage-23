# ptx_parse

`ptx_parse` is the Python component (written in Rust for efficiency and fast iteration) that parses PTX files and exposes a structured interface to navigate through functions, statements and instructions.

If for any reason the architecture fails to load a PTX file, the parser is likely the cause — feel free to open an issue with the file attached.

You could install it as any other pip packet.