
use std::fs::read;

mod parser;

fn main() {
    let code = read("./examples/relu.ptx").unwrap();
    let code = std::str::from_utf8(&code).unwrap();
    match parser::ptx_parser::program_without_py(code) {
        Ok(prog) => {
            println!("Parsed successfully: {:#?}", prog);
        }
        Err(err) => {
            eprintln!("Parse error: {}", err);
        }
    }
}
