use pyo3::{Py, Python, pyclass, pymethods};
use std::collections::HashMap;
use std::fmt::Display;

peg::parser! {
    pub grammar ptx_parser() for str {
        // Rule to filter whitespace characters and commas
        rule _() = quiet!{ ([' ' | '\t' | '\r' | '\n'] / comment())* }

        rule comment() = "//" (!"\n" [_])* ("\n" / ![_])

        pub rule program(py: Python<'_>) -> PTXFile
            = _ header:header() _ items:top_level_item()* _ {
                let functions: Vec<PTXFunction> = items.into_iter().flatten().collect();
                let (map, labels, custom_registers) = elaborate_functions(Some(py), &functions);
                PTXFile { header, functions, instructions: map, labels_ref: labels, custom_registers }
            }

        pub rule program_without_py() -> PTXFile
            = _ header:header() _ items:top_level_item()* _ {
                let functions: Vec<PTXFunction> = items.into_iter().flatten().collect();
                let (map, labels, custom_registers) = elaborate_functions(None, &functions);

            PTXFile { header, functions, instructions: map, labels_ref: labels, custom_registers} }

        rule top_level_item() -> Option<PTXFunction>
            = f:function() { Some(f) }
            / global_decl() { None }

        // currently ignored, in a future version we will support it
        rule global_decl() -> ()
            = ".extern" _ ".shared" _ ".align" _ $(['0'..='9']+) _ type_:type_() _ identifier() "[" _ "]" ";" _ { }
            / ".global" _ ".align" _ $(['0'..='9']+) _ type_:type_() _ identifier() "[" $(['0'..='9' | 'A'..='Z' | 'a'..='z' | '_']+) "]" _ "=" _ "{" _ $(['0'..='9' | ',' | ' ']+) _ "}" ";" _ { }
            / ".global" _ ".align" _ $(['0'..='9']+) _ type_:type_() _ identifier() "[" $(['0'..='9' | 'A'..='Z' | 'a'..='z']+) "]" ";" _ {  }

        pub rule parse_single_instruction() -> PTXInstruction
            = instruction:instruction() { instruction }

        pub rule parse_function_body_line() -> BodyItem
            = param:function_signature() { BodyItem::Param()}
              / (_)? bod:body_item() (_)? { bod }

        rule function() -> PTXFunction
            = offset:position!() link_directive:link_directive()? _ kind:function_kind() _ name:identifier() _ signature:function_signature() _ body:function_body()
            { PTXFunction { offset, name: name.to_string(), link_directive: link_directive.unwrap_or(PTXLinkDirective::None), kind, signature, body } }
            / offset:position!() link_directive:link_directive()? _ kind:function_kind() _ name:identifier() _ signature:function_signature() ";" _ {
                PTXFunction { offset, name: name.to_string(), link_directive: link_directive.unwrap_or(PTXLinkDirective::None), kind, signature, body: PTXFunctionBody { statements: vec![], instructions: vec![] }, }
            }

        rule function_body() -> PTXFunctionBody
        = "{" _ items:body_items() _ "}" _ {
                let mut statements = Vec::new();
                let mut instructions = Vec::new();

                for it in items {
                    match it {
                        BodyItem::Statement(s) => statements.push(s),
                        BodyItem::Instruction(i) => instructions.push(i),
                        _ => continue,
                    }
                }

                PTXFunctionBody { statements, instructions }
            }

        rule body_items() -> Vec<BodyItem>
            = items:(body_item() ** _) { items }

        rule label_def() -> String
            = "$" lab:label_() ":" { lab }

        rule call_block() -> BodyItem
            = "{" _
              ".reg" _ type_:type_() _ "temp_param_reg" ";" _
              params:call_param()* _
              "call" _ modifiers:modifier()* _ name:identifier() "," _
              "(" _ args:(identifier() ** (_ "," _)) _ ")" _ ";" _
              "}"
            { BodyItem::Call(name) }

        rule call_param() -> ()
            = ".param" _ type_:type_() _ name:identifier() ";" _
              "st.param" _ modifier()* _ "[" identifier() _ "+" _ $(['0'..='9']+) "]" "," _ parse_register() ";" _
            { }

        rule body_item() -> BodyItem
            = (_())? s:label_def() { BodyItem::LabelDef(s) }
            / c:call_block() { c }
            /  s:statement() { BodyItem::Statement(s) }
            / i:instruction() { BodyItem::Instruction(i) }

        rule label_() -> String
            = lab:$(['a'..='z' | '0'..='9' | '_' | 'A'..='Z' ]+) {lab.to_string()}

        rule statement() -> PTXStatement
            = ".shared" _ (align:".align" _ num:$(['0'..='9']+))? _ type_:type_() _ lab:label_() _ "[" _ num:$(['0'..='9']+) _ "];" { PTXStatement::SharedMemory(PTXSpace::SharedMemory, type_, num.parse().unwrap(), PTXOperand::Label(lab)) }
            / ".reg" _ type_:type_() _ "%p<" num:$(['0'..='9']+) ">;" _ { PTXStatement::RegisterCount(PTXSpace::Register, PTXType::PRED, num.parse().unwrap()) }
            / ".reg" _ type_:type_() _ "%rd<" num:$(['0'..='9']+)">;" _ { PTXStatement::RegisterCount(PTXSpace::Register, type_, num.parse().unwrap()) }
            / ".reg" _ type_:type_() _ "%r<" num:$(['0'..='9']+)">;" _ { PTXStatement::RegisterCount(PTXSpace::Register, type_, num.parse().unwrap()) }
            / ".reg" _ type_:type_() _ "%f<" num:$(['0'..='9']+)">;" _ { PTXStatement::RegisterCount(PTXSpace::FloatRegister, type_, num.parse().unwrap()) }
            / ".reg" _ type_:type_() _ "%" id:identifier()_ ";" _ { PTXStatement::CustomRegister(PTXSpace::CustomRegister, type_, id.to_string())}
            / ".pragma" _ "\"" $([|'0'..='9'| 'a'..='z' | 'A'..='Z']+) "\"" ";" _ { PTXStatement::Pragma() }
            / ".local" _ (align:".align" _ num:$(['0'..='9']+))? _ type_:type_() _ lab:label_() _ "[" _ num:$(['0'..='9']+) _ "];" { PTXStatement::LocalMemory(PTXSpace::LocalMemory, type_, num.parse().unwrap(), PTXOperand::Label(lab)) }

        rule instruction() -> PTXInstruction
            = pred:("@%p" n:$(['0'..='9']+) { n.parse::<u64>().unwrap() })?
                _ offset:position!() opcode:opcode() mods:modifier()* _ ops:(operand() ** (_ "," _))?  _ ";" _ {
                PTXInstruction {
                    offset,
                    opcode,
                    modifiers: mods.join("."),
                    operands: ops.unwrap_or_default(),
                    is_predicated: pred,
                }
            }

        rule modifier() -> String
            = "." m:$(['a'..='z' | '0'..='9']+) { m.to_string() }

        rule opcode() -> PTXOpcode
            = "xor" { PTXOpcode::Xor }
            / "wmma" { PTXOpcode::Wmma }
            / "wgmma" { PTXOpcode::Wgmma }
            / "vsub4" { PTXOpcode::Vsub4 }
            / "vsub2" { PTXOpcode::Vsub2 }
            / "vsub" { PTXOpcode::Vsub }
            / "vshr" { PTXOpcode::Vshr }
            / "vshl" { PTXOpcode::Vshl }
            / "vset4" { PTXOpcode::Vset4 }
            / "vset2" { PTXOpcode::Vset2 }
            / "vset" { PTXOpcode::Vset }
            / "vote" { PTXOpcode::Vote }
            / "vmin4" { PTXOpcode::Vmin4 }
            / "vmin2" { PTXOpcode::Vmin2 }
            / "vmin" { PTXOpcode::Vmin }
            / "vmax4" { PTXOpcode::Vmax4 }
            / "vmax2" { PTXOpcode::Vmax2 }
            / "vmax" { PTXOpcode::Vmax }
            / "vmad" { PTXOpcode::Vmad }
            / "vavrg4" { PTXOpcode::Vavrg4 }
            / "vavrg2" { PTXOpcode::Vavrg2 }
            / "vadd4" { PTXOpcode::Vadd4 }
            / "vadd2" { PTXOpcode::Vadd2 }
            / "vadd" { PTXOpcode::Vadd }
            / "vabsdiff4" { PTXOpcode::Vabsdiff4 }
            / "vabsdiff2" { PTXOpcode::Vabsdiff2 }
            / "vabsdiff" { PTXOpcode::Vabsdiff }
            / "txq" { PTXOpcode::Txq }
            / "trap" { PTXOpcode::Trap }
            / "testp" { PTXOpcode::Testp }
            / "tensormap" { PTXOpcode::Tensormap }
            / "tex" { PTXOpcode::Tex }
            / "tcgen05" { PTXOpcode::Tcgen05 }
            / "tanh" { PTXOpcode::Tanh }
            / "szext" { PTXOpcode::Szext }
            / "sust" { PTXOpcode::Sust }
            / "sured" { PTXOpcode::Sured }
            / "suq" { PTXOpcode::Suq }
            / "suld" { PTXOpcode::Suld }
            / "subc" { PTXOpcode::Subc }
            / "stmatrix" { PTXOpcode::Stmatrix }
            / "stacksave" { PTXOpcode::Stacksave }
            / "stackrestore" { PTXOpcode::Stackrestore }
            / "sqrt" { PTXOpcode::Sqrt }
            / "slct" { PTXOpcode::Slct }
            / "sin" { PTXOpcode::Sin }
            / "shfl" { PTXOpcode::Shfl }
            / "shf" { PTXOpcode::Shf }
            / "shr" { PTXOpcode::Shr }
            / "shl" { PTXOpcode::Shl }
            / "setmaxnreg" { PTXOpcode::Setmaxnreg }
            / "setp" { PTXOpcode::Setp }
            / "set" { PTXOpcode::Set }
            / "selp" { PTXOpcode::Selp }
            / "sad" { PTXOpcode::Sad }
            / "st" { PTXOpcode::St }
            / "sub" { PTXOpcode::Sub }
            / "rsqrt" { PTXOpcode::Rsqrt }
            / "ret" { PTXOpcode::Ret }
            / "redux" { PTXOpcode::Redux }
            / "red" { PTXOpcode::Red }
            / "rem" { PTXOpcode::Rem }
            / "rcp" { PTXOpcode::Rcp }
            / "prmt" { PTXOpcode::Prmt }
            / "prefetchu" { PTXOpcode::Prefetchu }
            / "prefetch" { PTXOpcode::Prefetch }
            / "popc" { PTXOpcode::Popc }
            / "pmevent" { PTXOpcode::Pmevent }
            / "or" { PTXOpcode::Or }
            / "not" { PTXOpcode::Not }
            / "neg" { PTXOpcode::Neg }
            / "nanosleep" { PTXOpcode::Nanosleep }
            / "multimem" { PTXOpcode::Multimem }
            / "mul24" { PTXOpcode::Mul24 }
            / "mul" { PTXOpcode::Mul }
            / "movmatrix" { PTXOpcode::Movmatrix }
            / "mov" { PTXOpcode::Mov }
            / "mma" { PTXOpcode::Mma }
            / "min" { PTXOpcode::Min }
            / "membar" { PTXOpcode::Membar }
            / "mbarrier" { PTXOpcode::Mbarrier }
            / "match" { PTXOpcode::Match }
            / "mapa" { PTXOpcode::Mapa }
            / "madc" { PTXOpcode::Madc }
            / "mad24" { PTXOpcode::Mad24 }
            / "mad" { PTXOpcode::Mad }
            / "max" { PTXOpcode::Max }
            / "lop3" { PTXOpcode::Lop3 }
            / "ldu" { PTXOpcode::Ldu }
            / "ldmatrix" { PTXOpcode::Ldmatrix }
            / "lg2" { PTXOpcode::Lg2 }
            / "ld" { PTXOpcode::Ld }
            / "istypep" { PTXOpcode::Istypep }
            / "isspacep" { PTXOpcode::Isspacep }
            / "griddepcontrol" { PTXOpcode::Griddepcontrol }
            / "getctarank" { PTXOpcode::Getctarank }
            / "fns" { PTXOpcode::Fns }
            / "fma" { PTXOpcode::Fma }
            / "fence" { PTXOpcode::Fence }
            / "ex2" { PTXOpcode::Ex2 }
            / "exit" { PTXOpcode::Exit }
            / "elect" { PTXOpcode::Elect }
            / "dp4a" { PTXOpcode::Dp4a }
            / "dp2a" { PTXOpcode::Dp2a }
            / "div" { PTXOpcode::Div }
            / "discard" { PTXOpcode::Discard }
            / "cvta" { PTXOpcode::Cvta }
            / "cvt" { PTXOpcode::Cvt }
            / "createpolicy" { PTXOpcode::Createpolicy }
            / "copysign" { PTXOpcode::Copysign }
            / "cos" { PTXOpcode::Cos }
            / "cnot" { PTXOpcode::Cnot }
            / "clz" { PTXOpcode::Clz }
            / "clusterlaunchcontrol" { PTXOpcode::Clusterlaunchcontrol }
            / "cp" { PTXOpcode::Cp }
            / "call" { PTXOpcode::Call }
            / "brx" { PTXOpcode::Brx }
            / "brkpt" { PTXOpcode::Brkpt }
            / "brev" { PTXOpcode::Brev }
            / "bra" { PTXOpcode::Bra }
            / "bmsk" { PTXOpcode::Bmsk }
            / "bfind" { PTXOpcode::Bfind }
            / "bfi" { PTXOpcode::Bfi }
            / "bfe" { PTXOpcode::Bfe }
            / "barrier" { PTXOpcode::Barrier }
            / "bar" { PTXOpcode::Bar }
            / "atom" { PTXOpcode::Atom }
            / "alloca" { PTXOpcode::Alloca }
            / "addc" { PTXOpcode::Addc }
            / "add" { PTXOpcode::Add }
            / "and" { PTXOpcode::And }
            / "applypriority" { PTXOpcode::Applypriority }
            / "activemask" { PTXOpcode::Activemask }
            / "abs" { PTXOpcode::Abs }

        rule parse_register() -> PTXRegister
            = "%tid.y" { PTXRegister::Special(PTXSpecialRegister::TID, PTXDirection::Y)}
            / "%tid.x" { PTXRegister::Special(PTXSpecialRegister::TID, PTXDirection::X)}
            / "%rd" n:$(['0'..='9']+) { PTXRegister::Wide(n.parse().unwrap()) }
            / "%r" n:$(['0'..='9']+) { PTXRegister::General(n.parse().unwrap()) }
            / "%f" n:$(['0'..='9']+) { PTXRegister::Float(n.parse().unwrap())}
            / "%ntid.x" { PTXRegister::Special(PTXSpecialRegister::NTID, PTXDirection::X)}
            / "%ctaid.y" { PTXRegister::Special(PTXSpecialRegister::CTAID, PTXDirection::Y)}
            / "%ctaid.x" { PTXRegister::Special(PTXSpecialRegister::CTAID, PTXDirection::X) }
            / "%tid.x" { PTXRegister::Special(PTXSpecialRegister::TID, PTXDirection::X) }
            / "%tid.y" { PTXRegister::Special(PTXSpecialRegister::TID, PTXDirection::Y) }
            / "%tid.z" { PTXRegister::Special(PTXSpecialRegister::TID, PTXDirection::Z) }
            / "%ntid.x" { PTXRegister::Special(PTXSpecialRegister::NTID, PTXDirection::X) }
            / "%ntid.y" { PTXRegister::Special(PTXSpecialRegister::NTID, PTXDirection::Y) }
            / "%ntid.z" { PTXRegister::Special(PTXSpecialRegister::NTID, PTXDirection::Z) }
            / "%ctaid.x" { PTXRegister::Special(PTXSpecialRegister::CTAID, PTXDirection::X) }
            / "%ctaid.y" { PTXRegister::Special(PTXSpecialRegister::CTAID, PTXDirection::Y) }
            / "%ctaid.z" { PTXRegister::Special(PTXSpecialRegister::CTAID, PTXDirection::Z) }
            / "%nctaid.x" { PTXRegister::Special(PTXSpecialRegister::NCTAID, PTXDirection::X) }
            / "%nctaid.y" { PTXRegister::Special(PTXSpecialRegister::NCTAID, PTXDirection::Y) }
            / "%nctaid.z" { PTXRegister::Special(PTXSpecialRegister::NCTAID, PTXDirection::Z) }
            / "%warpid" { PTXRegister::Special(PTXSpecialRegister::WARPID, PTXDirection::None) }
            / "%laneid" { PTXRegister::Special(PTXSpecialRegister::LANEID, PTXDirection::None) }
            / "%warpsize" { PTXRegister::Special(PTXSpecialRegister::WARPSIZE, PTXDirection::None) }
            / "%gridid" { PTXRegister::Special(PTXSpecialRegister::GRIDID, PTXDirection::None) }
            / "%lanemask_eq" { PTXRegister::Special(PTXSpecialRegister::LANEMASK_EQ, PTXDirection::None) }
            / "%lanemask_le" { PTXRegister::Special(PTXSpecialRegister::LANEMASK_LE, PTXDirection::None) }
            / "%lanemask_lt" { PTXRegister::Special(PTXSpecialRegister::LANEMASK_LT, PTXDirection::None) }
            / "%lanemask_ge" { PTXRegister::Special(PTXSpecialRegister::LANEMASK_GE, PTXDirection::None) }
            / "%lanemask_gt" { PTXRegister::Special(PTXSpecialRegister::LANEMASK_GT, PTXDirection::None) }
            / "%clock" { PTXRegister::Special(PTXSpecialRegister::CLOCK, PTXDirection::None) }
            / "%clock64" { PTXRegister::Special(PTXSpecialRegister::CLOCK64, PTXDirection::None) }
            / "%pm0" { PTXRegister::Special(PTXSpecialRegister::PM0, PTXDirection::None) }
            / "%pm1" { PTXRegister::Special(PTXSpecialRegister::PM1, PTXDirection::None) }
            / "%pm2" { PTXRegister::Special(PTXSpecialRegister::PM2, PTXDirection::None) }
            / "%pm3" { PTXRegister::Special(PTXSpecialRegister::PM3, PTXDirection::None) }


        rule vector_operand() -> PTXOperand
            = "{" _ regs:(parse_register() ** (_ "," _)) _ "}" { PTXOperand::VectorOperand(regs) }

        rule operand() -> PTXOperand
            = vect:vector_operand() { vect }
            / reg:parse_register() "|" "%p" n:$(['0'..='9']+) { PTXOperand::RegPredPair(reg, n.parse().unwrap())}
            / reg:parse_register() { PTXOperand::Register(reg) }
            / "%p" n:$(['0'..='9']+) { PTXOperand::Predicate(n.parse().unwrap()) }
            / "[" _ reg:parse_register() _ "+" _ "-" n:$(['0'..='9']+) _ "]" { PTXOperand::MemoryRegDisp(reg, -(n.parse::<i64>().unwrap()) as u64) }
            / "[" _ reg:parse_register() _ "+" _ n:$(['0'..='9']+) _ "]" { PTXOperand::MemoryRegDisp(reg, n.parse().unwrap()) }
            / "[" _ reg:parse_register() _ "]" { PTXOperand::MemoryRegDisp(reg, 0) }
            / "[" _ lab:label_() _ "]" { PTXOperand::MemoryLbl(lab.to_string()) }
            / "0f" n:$(['0'..='9' | 'a'..='f' | 'A'..='F']+) { PTXOperand::FloatImmediate(u64::from_str_radix(n, 16).unwrap()) }
            / "-" n:$(['0'..='9']+) { PTXOperand::Immediate(-(n.parse::<i64>().unwrap()) as u64) }
            / n:$(['0'..='9']+) {PTXOperand::Immediate(n.parse().unwrap())}
            / "$str$" n:$(['0'..='9']+) { PTXOperand::Label(format!("$str${}", n)) }
            / ("$")? lab:label_() {PTXOperand::Label(lab.to_string())}
            / "%" id:$(['a'..='z'|'A'..='Z']+) {PTXOperand::Register(PTXRegister::Custom(id.to_string())) }

        rule function_signature() -> PTXFunctionSignature
            = "(" _ params:(functions_parameter() ** (_ "," _))? _ ")"
            { PTXFunctionSignature { parameters: params.unwrap_or_default() } }

        rule functions_parameter() -> PTXFunctionParameter
            = ".param" _ type_:type_() _ name:identifier() _ { PTXFunctionParameter { name, type_ }}

        rule type_() -> PTXType
            = ".b64" { PTXType::B64 }
            / ".b32" { PTXType::B32 }
            / ".b8" { PTXType::B8 }
            / ".f8" { PTXType::F8 }
            / ".f32" { PTXType::F32 }
            / ".f64" { PTXType::F64 }
            / ".pred" { PTXType::PRED }
            / ".s32" { PTXType::S32 }
            / ".s64" { PTXType::S64 }
            / ".u32" { PTXType::U32 }
            / ".u64" { PTXType::U64 }

        rule identifier() -> String
            = id:$(['a'..='z' | 'A'..='Z' | '_' | '$'] ['a'..='z' | 'A'..='Z' | '0'..='9' | '_' | '$']*) { id.to_string() }

        rule function_kind() -> PTXFunctionKind
            = ".entry" { PTXFunctionKind::Kernel }
            / ".func" { PTXFunctionKind::Function }

        rule link_directive() -> PTXLinkDirective
            = ".weak" { PTXLinkDirective::Weak }
            / ".visible" { PTXLinkDirective::Visible}
            / ".extern" { PTXLinkDirective::Extern }

        rule header() -> PTXHeader
            = ".version" _ v:$(['0'..='9']+"."['0'..='9']+) _ ".target" _ target:target() _ ".address_size" _ addr:$(['0'..='9']+)
            { PTXHeader { version: v.to_string(), target, address_size: addr.parse().unwrap() } }

        rule target() -> PTXTarget
            = "sm_10"  { PTXTarget::SM10 }
            / "sm_11"  { PTXTarget::SM11 }
            / "sm_12"  { PTXTarget::SM12 }
            / "sm_13"  { PTXTarget::SM13 }
            / "sm_20"  { PTXTarget::SM20 }
            / "sm_30"  { PTXTarget::SM30 }
            / "sm_32"  { PTXTarget::SM32 }
            / "sm_35"  { PTXTarget::SM35 }
            / "sm_37"  { PTXTarget::SM37 }
            / "sm_50"  { PTXTarget::SM50 }
            / "sm_52"  { PTXTarget::SM52 }
            / "sm_53"  { PTXTarget::SM53 }
            / "sm_60"  { PTXTarget::SM60 }
            / "sm_61"  { PTXTarget::SM61 }
            / "sm_62"  { PTXTarget::SM62 }
            / "sm_70"  { PTXTarget::SM70 }
            / "sm_72"  { PTXTarget::SM72 }
            / "sm_75"  { PTXTarget::SM75 }
            / "sm_80"  { PTXTarget::SM80 }
            / "sm_86"  { PTXTarget::SM86 }
            / "sm_87"  { PTXTarget::SM87 }
            / "sm_88"  { PTXTarget::SM88 }
            / "sm_89"  { PTXTarget::SM89 }
            / "sm_90"  { PTXTarget::SM90 }
            / "sm_90a" { PTXTarget::SM90A }
            / "sm_100"  { PTXTarget::SM100 }
            / "sm_100f" { PTXTarget::SM100F }
            / "sm_100a" { PTXTarget::SM100A }
            / "sm_103"  { PTXTarget::SM103 }
            / "sm_103f" { PTXTarget::SM103F }
            / "sm_103a" { PTXTarget::SM103A }
            / "sm_110"  { PTXTarget::SM110 }
            / "sm_110f" { PTXTarget::SM110F }
            / "sm_110a" { PTXTarget::SM110A }
            / "sm_120"  { PTXTarget::SM120 }
            / "sm_120f" { PTXTarget::SM120F }
            / "sm_120a" { PTXTarget::SM120A }
            / "sm_121"  { PTXTarget::SM121 }
            / "sm_121f" { PTXTarget::SM121F }
            / "sm_121a" { PTXTarget::SM121A }

    }
}

#[derive(Debug)]
#[pyclass]
pub struct PTXFile {
    #[pyo3(get)]
    pub header: PTXHeader,
    #[pyo3(get)]
    pub functions: Vec<PTXFunction>,
    // pub how_much_to_allocate
    pub instructions: HashMap<u64, Py<PTXInstruction>>,
    #[pyo3(get)]
    pub labels_ref: Vec<String>,
    /// PTX allows some custom registers, we map into some custom registers we have created
    /// through binary ninja
    #[pyo3(get)]
    pub custom_registers: HashMap<String, String>,
}

#[pymethods]
impl PTXFile {
    pub fn get_instruction(&self, py: Python<'_>, addr: u64) -> Option<Py<PTXInstruction>> {
        self.instructions
            .get(&addr)
            .map(|obj: &Py<PTXInstruction>| obj.clone_ref(py))
    }
}

#[derive(Debug, Clone)]
#[pyclass]
pub struct PTXHeader {
    #[pyo3(get)]
    pub version: String,
    #[pyo3(get)]
    pub target: PTXTarget,
    #[pyo3(get)]
    pub address_size: usize,
}

#[derive(Debug, Clone)]
#[pyclass]
pub struct PTXFunction {
    #[pyo3(get)]
    pub name: String,
    #[pyo3(get)]
    pub offset: usize,
    #[pyo3(get)]
    pub link_directive: PTXLinkDirective,
    #[pyo3(get)]
    pub kind: PTXFunctionKind,
    #[pyo3(get)]
    pub signature: PTXFunctionSignature,
    #[pyo3(get)]
    pub body: PTXFunctionBody,
}

#[derive(Debug, Clone)]
#[pyclass]
pub struct PTXFunctionSignature {
    #[pyo3(get)]
    parameters: Vec<PTXFunctionParameter>,
}

#[derive(Debug, Clone)]
#[pyclass]
pub enum PTXFunctionKind {
    Kernel,
    Function,
}

#[derive(Debug, Clone)]
#[pyclass]
pub enum PTXStatement {
    CustomRegister(PTXSpace, PTXType, String),
    RegisterCount(PTXSpace, PTXType, u128),
    SharedMemory(PTXSpace, PTXType, u128, PTXOperand),
    LocalMemory(PTXSpace, PTXType, u128, PTXOperand),
    Pragma(),
}

#[derive(Debug, Clone, PartialEq)]
#[pyclass]
pub enum PTXSpace {
    Register,
    SpecialRegister,
    CustomRegister,
    FloatRegister,
    SharedMemory,
    LocalMemory,
}

#[derive(Debug, Clone)]
#[allow(clippy::upper_case_acronyms)]
#[pyclass]
pub enum PTXType {
    PRED,
    B8,
    B32,
    B64,
    F8,
    F32,
    F64,
    S32,
    S64,
    U32,
    U64,
}

#[derive(Debug, Clone)]
#[pyclass]
pub struct PTXFunctionParameter {
    #[pyo3(get)]
    name: String,
    #[pyo3(get)]
    type_: PTXType,
}

#[derive(Debug, Clone)]
#[pyclass(from_py_object)]
pub enum PTXLinkDirective {
    Extern,
    Visible,
    Weak,
    None,
}

#[derive(Debug, Clone)]
#[pyclass]
pub struct PTXInstruction {
    #[pyo3(get)]
    offset: usize,
    #[pyo3(get)]
    opcode: PTXOpcode,
    #[pyo3(get)]
    modifiers: String,
    #[pyo3(get)]
    operands: Vec<PTXOperand>,
    #[pyo3(get)]
    is_predicated: Option<u64>,
}

#[derive(Debug, Clone)]
#[pyclass]
pub enum PTXOperand {
    Immediate(u64),
    FloatImmediate(u64),
    Register(PTXRegister),
    Predicate(u64),
    Memory(),
    MemoryLbl(String),
    MemoryRegDisp(PTXRegister, u64),
    Label(String),
    VectorOperand(Vec<PTXRegister>),
    RegPredPair(PTXRegister, u64),
}

#[derive(Debug, Clone)]
#[pyclass]
pub enum PTXRegister {
    General(u64),
    Wide(u64),
    Float(u64),
    Special(PTXSpecialRegister, PTXDirection),
    Custom(String),
}

#[derive(Debug, Clone)]
#[pyclass]
pub enum PTXDirection {
    None,
    X,
    Y,
    Z,
}

#[derive(Debug, Clone)]
#[allow(non_camel_case_types)]
#[allow(clippy::upper_case_acronyms)]
#[pyclass]
pub enum PTXSpecialRegister {
    TID,
    NTID,
    LANEID,
    WARPID,
    NWARPID,
    CTAID,
    NCTAID,
    SMID,
    NSMID,
    GRIDID,
    WARPSIZE,
    IS_EXPLICIT_CLUSTER,
    CLUSTERID,
    NCLUSTERID,
    CLUSTER_CTAID,
    CLUSTER_NCTAID,
    CLUSTER_CTARANK,
    CLUSTER_NCTARANK,
    LANEMASK_EQ,
    LANEMASK_LE,
    LANEMASK_LT,
    LANEMASK_GE,
    LANEMASK_GT,
    CLOCK,
    CLOCK_HI,
    CLOCK64,
    PM0,
    PM1,
    PM2,
    PM3,
    PM4,
    PM5,
    PM6,
    PM7,
    PM0_64,
    PM1_64,
    PM2_64,
    PM3_64,
    PM4_64,
    PM5_64,
    PM6_64,
    PM7_64,
    // extracted from section 10
}

#[derive(Debug, Clone)]
#[pyclass]
pub enum PTXOpcode {
    Abs,
    Activemask,
    Add,
    Addc,
    Alloca,
    And,
    Applypriority,
    Atom,
    Bar,
    Barrier,
    Bfe,
    Bfi,
    Bfind,
    Bmsk,
    Bra,
    Brev,
    Brkpt,
    Brx,
    Call,
    Clusterlaunchcontrol,
    Clz,
    Cnot,
    Copysign,
    Cos,
    Cp,
    Createpolicy,
    Cvt,
    Cvta,
    Discard,
    Div,
    Dp2a,
    Dp4a,
    Elect,
    Ex2,
    Exit,
    Fence,
    Fma,
    Fns,
    Getctarank,
    Griddepcontrol,
    Isspacep,
    Istypep,
    Ld,
    Ldmatrix,
    Ldu,
    Lg2,
    Lop3,
    Mad,
    Mad24,
    Madc,
    Mapa,
    Match,
    Max,
    Mbarrier,
    Membar,
    Min,
    Mma,
    Mov,
    Movmatrix,
    Mul,
    Mul24,
    Multimem,
    Nanosleep,
    Neg,
    Not,
    Or,
    Pmevent,
    Popc,
    Prefetch,
    Prefetchu,
    Prmt,
    Rcp,
    Red,
    Redux,
    Rem,
    Ret,
    Rsqrt,
    Sad,
    Selp,
    Set,
    Setmaxnreg,
    Setp,
    Shf,
    Shfl,
    Shl,
    Shr,
    Sin,
    Slct,
    Sqrt,
    St,
    Stackrestore,
    Stacksave,
    Stmatrix,
    Sub,
    Subc,
    Suld,
    Suq,
    Sured,
    Sust,
    Szext,
    Tanh,
    Tcgen05,
    Tensormap,
    Testp,
    Tex,
    Tld4,
    Trap,
    Txq,
    Vabsdiff,
    Vabsdiff2,
    Vabsdiff4,
    Vadd,
    Vadd2,
    Vadd4,
    Vavrg2,
    Vavrg4,
    Vmad,
    Vmax,
    Vmax2,
    Vmax4,
    Vmin,
    Vmin2,
    Vmin4,
    Vote,
    Vset,
    Vset2,
    Vset4,
    Vshl,
    Vshr,
    Vsub,
    Vsub2,
    Vsub4,
    Wgmma,
    Wmma,
    Xor,
}

#[derive(Debug, Clone)]
#[pyclass]
pub struct PTXFunctionBody {
    #[pyo3(get)]
    pub statements: Vec<PTXStatement>,
    #[pyo3(get)]
    pub instructions: Vec<PTXInstruction>,
}

#[derive(Debug, Clone)]
#[pyclass]
pub enum PTXTarget {
    SM10,
    SM11,
    SM12,
    SM13,

    SM20,

    SM30,
    SM32,
    SM35,
    SM37,

    SM50,
    SM52,
    SM53,

    SM60,
    SM61,
    SM62,

    SM70,
    SM72,
    SM75,

    SM80,
    SM86,
    SM87,
    SM88,
    SM89,

    SM90,
    SM90A,

    SM100,
    SM100F,
    SM100A,
    SM103,
    SM103F,
    SM103A,

    SM110,
    SM110F,
    SM110A,

    SM120,
    SM120F,
    SM120A,
    SM121,
    SM121F,
    SM121A,
}

#[pymethods]
impl PTXInstruction {
    fn is_float(&self) -> bool {
        self.modifiers.contains("f32") || self.modifiers.contains("f64") || self.modifiers.contains("f8")
    }

    fn __str__(&self) -> String {
        format!(
            "PTXInstruction(opcode='{:?}', modifiers='{}', operands={:?})",
            self.opcode, self.modifiers, self.operands
        )
    }
}

#[pymethods]
impl BodyItem {
    pub fn kind(&self) -> String {
        match self {
            BodyItem::Statement(_) => "statement".to_string(),
            BodyItem::Instruction(_) => "instruction".to_string(),
            BodyItem::LabelDef(_) => "label".to_string(),
            BodyItem::Param() => "param".to_string(),
            BodyItem::Call(_) => "call".to_string(),
        }
    }

    pub fn as_instruction(&self) -> Option<PTXInstruction> {
        match self {
            BodyItem::Instruction(i) => Some(i.clone()),
            _ => None,
        }
    }
}

#[pymethods]
impl PTXOperand {
    pub fn kind(&self) -> &'static str {
        match self {
            PTXOperand::Register(_) => "reg",
            PTXOperand::Label(_) => "label",
            PTXOperand::Immediate(_) => "imm",
            PTXOperand::FloatImmediate(_) => "float_imm",
            PTXOperand::Predicate(_) => "predicate",
            PTXOperand::Memory() => "memory",
            PTXOperand::MemoryLbl(_) => "memory_label",
            PTXOperand::MemoryRegDisp(_, _) => "memory_reg_disp",
            PTXOperand::VectorOperand(_) => "vector",
            PTXOperand::RegPredPair(_, _) => "reg_pred_pair",
        }
    }

    pub fn get_float_imm(&self) -> Option<u64> {
        match self {
            PTXOperand::FloatImmediate(fl) => Some(*fl),
            _ => None,
        }
    }

    pub fn get_register(&self) -> Option<String> {
        match self {
            PTXOperand::Register(r) => Some(format!("{}", r)),
            PTXOperand::Predicate(r) => Some(format!("%p{}", r)),
            _ => None,
        }
    }

    pub fn get_label(&self) -> Option<String> {
        match self {
            PTXOperand::Label(r) => Some(r.clone()),
            _ => None,
        }
    }

    pub fn get_immediate(&self) -> Option<u64> {
        match self {
            PTXOperand::Immediate(r) => Some(*r),
            _ => None,
        }
    }

    pub fn get_memory_lbl(&self) -> Option<String> {
        match self {
            PTXOperand::MemoryLbl(r) => Some(r.clone()),
            _ => None,
        }
    }

    pub fn get_memory_disp(&self) -> Option<(PTXRegister, u64)> {
        match self {
            PTXOperand::MemoryRegDisp(r, disp) => Some((r.clone(), *disp)),
            _ => None,
        }
    }

    pub fn get_predicate(&self) -> Option<String> {
        match self {
            PTXOperand::Predicate(r) => Some(format!("%p{}", r).to_string()),
            _ => None,
        }
    }

    pub fn get_reg_pred_pair(&self) -> Option<(String, String)> {
        match self {
            PTXOperand::RegPredPair(reg, predicate) => Some((format!("{}", reg).to_string(), format!("{}", predicate).to_string())),
            _ => None,
        }
    }

    fn __str__(&self) -> String {
        match self {
            PTXOperand::Register(r) => format!("%{:?}", r),
            PTXOperand::Predicate(n) => format!("@%p{}", n),
            PTXOperand::Label(l) => l.clone(),
            PTXOperand::Immediate(v) => v.to_string(),
            PTXOperand::Memory() => "[]".to_string(),
            PTXOperand::MemoryLbl(l) => format!("[{}]", l),
            PTXOperand::FloatImmediate(fl) => format!("{}", fl),
            PTXOperand::MemoryRegDisp(reg, d) => {
                if *d == 0 {
                    format!("[%{:?}]", reg)
                } else {
                    format!("[%{:?}+{}]", reg, d)
                }
            }
            PTXOperand::VectorOperand(_) => "vector".to_string(),
            PTXOperand::RegPredPair(_, _) => "rp_pair".to_string(),
        }
    }
}

#[pymethods]
impl PTXRegister {
    fn __str__(&self) -> String {
        match self {
            PTXRegister::General(gena) => format!("%r{}", gena),
            PTXRegister::Wide(wide) => format!("%rd{}", wide),
            PTXRegister::Special(special, tilde) => format!("%{:?}.{:?}", special, tilde),
            PTXRegister::Float(fl) => format!("%f{}", fl),
            PTXRegister::Custom(id) => {
                format!("%{}", id)
            }
        }
    }
}

impl Display for PTXRegister {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            PTXRegister::General(gena) => write!(f, "%r{}", gena),
            PTXRegister::Wide(wide) => write!(f, "%rd{}", wide),
            PTXRegister::Special(special, tilde) => write!(f,"%{:?}.{:?}", special, tilde),
            PTXRegister::Float(fl) => write!(f, "%f{}", fl),
            PTXRegister::Custom(id) => {
                write!(f, "%{}", id)
            }
        }
    }
}

#[pymethods]
impl PTXOpcode {
    fn __str__(&self) -> String {
        match self {
            PTXOpcode::Abs => "abs".to_string(),
            PTXOpcode::Activemask => "activemask".to_string(),
            PTXOpcode::Add => "add".to_string(),
            PTXOpcode::Addc => "addc".to_string(),
            PTXOpcode::Alloca => "alloca".to_string(),
            PTXOpcode::And => "and".to_string(),
            PTXOpcode::Applypriority => "applypriority".to_string(),
            PTXOpcode::Atom => "atom".to_string(),
            PTXOpcode::Bar => "bar".to_string(),
            PTXOpcode::Barrier => "barrier".to_string(),
            PTXOpcode::Bfe => "bfe".to_string(),
            PTXOpcode::Bfi => "bfi".to_string(),
            PTXOpcode::Bfind => "bfind".to_string(),
            PTXOpcode::Bmsk => "bmsk".to_string(),
            PTXOpcode::Bra => "bra".to_string(),
            PTXOpcode::Brev => "brev".to_string(),
            PTXOpcode::Brkpt => "brkpt".to_string(),
            PTXOpcode::Brx => "brx".to_string(),
            PTXOpcode::Call => "call".to_string(),
            PTXOpcode::Clusterlaunchcontrol => "clusterlaunchcontrol".to_string(),
            PTXOpcode::Clz => "clz".to_string(),
            PTXOpcode::Cnot => "cnot".to_string(),
            PTXOpcode::Copysign => "copysign".to_string(),
            PTXOpcode::Cos => "cos".to_string(),
            PTXOpcode::Cp => "cp".to_string(),
            PTXOpcode::Createpolicy => "createpolicy".to_string(),
            PTXOpcode::Cvt => "cvt".to_string(),
            PTXOpcode::Cvta => "cvta".to_string(),
            PTXOpcode::Discard => "discard".to_string(),
            PTXOpcode::Div => "div".to_string(),
            PTXOpcode::Dp2a => "dp2a".to_string(),
            PTXOpcode::Dp4a => "dp4a".to_string(),
            PTXOpcode::Elect => "elect".to_string(),
            PTXOpcode::Ex2 => "ex2".to_string(),
            PTXOpcode::Exit => "exit".to_string(),
            PTXOpcode::Fence => "fence".to_string(),
            PTXOpcode::Fma => "fma".to_string(),
            PTXOpcode::Fns => "fns".to_string(),
            PTXOpcode::Getctarank => "getctarank".to_string(),
            PTXOpcode::Griddepcontrol => "griddepcontrol".to_string(),
            PTXOpcode::Isspacep => "isspacep".to_string(),
            PTXOpcode::Istypep => "istypep".to_string(),
            PTXOpcode::Ld => "ld".to_string(),
            PTXOpcode::Ldmatrix => "ldmatrix".to_string(),
            PTXOpcode::Ldu => "ldu".to_string(),
            PTXOpcode::Lg2 => "lg2".to_string(),
            PTXOpcode::Lop3 => "lop3".to_string(),
            PTXOpcode::Mad => "mad".to_string(),
            PTXOpcode::Mad24 => "mad24".to_string(),
            PTXOpcode::Madc => "madc".to_string(),
            PTXOpcode::Mapa => "mapa".to_string(),
            PTXOpcode::Match => "match".to_string(),
            PTXOpcode::Max => "max".to_string(),
            PTXOpcode::Mbarrier => "mbarrier".to_string(),
            PTXOpcode::Membar => "membar".to_string(),
            PTXOpcode::Min => "min".to_string(),
            PTXOpcode::Mma => "mma".to_string(),
            PTXOpcode::Mov => "mov".to_string(),
            PTXOpcode::Movmatrix => "movmatrix".to_string(),
            PTXOpcode::Mul => "mul".to_string(),
            PTXOpcode::Mul24 => "mul24".to_string(),
            PTXOpcode::Multimem => "multimem".to_string(),
            PTXOpcode::Nanosleep => "nanosleep".to_string(),
            PTXOpcode::Neg => "neg".to_string(),
            PTXOpcode::Not => "not".to_string(),
            PTXOpcode::Or => "or".to_string(),
            PTXOpcode::Pmevent => "pmevent".to_string(),
            PTXOpcode::Popc => "popc".to_string(),
            PTXOpcode::Prefetch => "prefetch".to_string(),
            PTXOpcode::Prefetchu => "prefetchu".to_string(),
            PTXOpcode::Prmt => "prmt".to_string(),
            PTXOpcode::Rcp => "rcp".to_string(),
            PTXOpcode::Red => "red".to_string(),
            PTXOpcode::Redux => "redux".to_string(),
            PTXOpcode::Rem => "rem".to_string(),
            PTXOpcode::Ret => "ret".to_string(),
            PTXOpcode::Rsqrt => "rsqrt".to_string(),
            PTXOpcode::Sad => "sad".to_string(),
            PTXOpcode::Selp => "selp".to_string(),
            PTXOpcode::Set => "set".to_string(),
            PTXOpcode::Setmaxnreg => "setmaxnreg".to_string(),
            PTXOpcode::Setp => "setp".to_string(),
            PTXOpcode::Shf => "shf".to_string(),
            PTXOpcode::Shfl => "shfl".to_string(),
            PTXOpcode::Shl => "shl".to_string(),
            PTXOpcode::Shr => "shr".to_string(),
            PTXOpcode::Sin => "sin".to_string(),
            PTXOpcode::Slct => "slct".to_string(),
            PTXOpcode::Sqrt => "sqrt".to_string(),
            PTXOpcode::St => "st".to_string(),
            PTXOpcode::Stackrestore => "stackrestore".to_string(),
            PTXOpcode::Stacksave => "stacksave".to_string(),
            PTXOpcode::Stmatrix => "stmatrix".to_string(),
            PTXOpcode::Sub => "sub".to_string(),
            PTXOpcode::Subc => "subc".to_string(),
            PTXOpcode::Suld => "suld".to_string(),
            PTXOpcode::Suq => "suq".to_string(),
            PTXOpcode::Sured => "sured".to_string(),
            PTXOpcode::Sust => "sust".to_string(),
            PTXOpcode::Szext => "szext".to_string(),
            PTXOpcode::Tanh => "tanh".to_string(),
            PTXOpcode::Tcgen05 => "tcgen05".to_string(),
            PTXOpcode::Tensormap => "tensormap".to_string(),
            PTXOpcode::Testp => "testp".to_string(),
            PTXOpcode::Tex => "tex".to_string(),
            PTXOpcode::Tld4 => "tld4".to_string(),
            PTXOpcode::Trap => "trap".to_string(),
            PTXOpcode::Txq => "txq".to_string(),
            PTXOpcode::Vabsdiff => "vabsdiff".to_string(),
            PTXOpcode::Vabsdiff2 => "vabsdiff2".to_string(),
            PTXOpcode::Vabsdiff4 => "vabsdiff4".to_string(),
            PTXOpcode::Vadd => "vadd".to_string(),
            PTXOpcode::Vadd2 => "vadd2".to_string(),
            PTXOpcode::Vadd4 => "vadd4".to_string(),
            PTXOpcode::Vavrg2 => "vavrg2".to_string(),
            PTXOpcode::Vavrg4 => "vavrg4".to_string(),
            PTXOpcode::Vmad => "vmad".to_string(),
            PTXOpcode::Vmax => "vmax".to_string(),
            PTXOpcode::Vmax2 => "vmax2".to_string(),
            PTXOpcode::Vmax4 => "vmax4".to_string(),
            PTXOpcode::Vmin => "vmin".to_string(),
            PTXOpcode::Vmin2 => "vmin2".to_string(),
            PTXOpcode::Vmin4 => "vmin4".to_string(),
            PTXOpcode::Vote => "vote".to_string(),
            PTXOpcode::Vset => "vset".to_string(),
            PTXOpcode::Vset2 => "vset2".to_string(),
            PTXOpcode::Vset4 => "vset4".to_string(),
            PTXOpcode::Vshl => "vshl".to_string(),
            PTXOpcode::Vshr => "vshr".to_string(),
            PTXOpcode::Vsub => "vsub".to_string(),
            PTXOpcode::Vsub2 => "vsub2".to_string(),
            PTXOpcode::Vsub4 => "vsub4".to_string(),
            PTXOpcode::Wgmma => "wgmma".to_string(),
            PTXOpcode::Wmma => "wmma".to_string(),
            PTXOpcode::Xor => "xor".to_string(),
        }
    }
}

#[derive(Debug)]
#[pyclass]
pub enum BodyItem {
    Statement(PTXStatement),
    Instruction(PTXInstruction),
    LabelDef(String),
    Call(String),
    Param(),
}

#[allow(clippy::type_complexity)]
fn elaborate_functions(python: Option<Python<'_>>, functions: &[PTXFunction]) -> (HashMap<u64, Py<PTXInstruction>>, Vec<String>, HashMap<String, String>) {
    let mut map = HashMap::new();
    let mut labels = Vec::new();
    for function in functions {
        let instructions = &function.body.instructions;
        for instruction in instructions {

            if let Some(python) = python {
                map.insert(instruction.offset as u64, Py::new(python, instruction.clone()).unwrap());
            }

            for operand in &instruction.operands {
                match operand {
                    PTXOperand::Label(l) if !l.starts_with('L') => labels.push(l.clone()),
                    PTXOperand::MemoryLbl(l) if !l.starts_with('L') => labels.push(l.clone()),
                    _ => {}
                }
            }
        }
    }

    let mut custom_registers: HashMap<String, String> = HashMap::new();

    for function in functions {
        let mut index_32 = 0;
        let mut index_64 = 0;
        for statement in &function.body.statements {
            match statement {
                PTXStatement::CustomRegister(space, type_, id)
                    if *space == PTXSpace::CustomRegister =>
                {
                    match type_ {
                        PTXType::B32 | PTXType::S32 | PTXType::U32 => {
                            custom_registers
                                .insert(id.to_string().to_lowercase(), format!("cr{}", index_32));
                            index_32 += 1;
                        }
                        PTXType::B64 | PTXType::S64 | PTXType::U64 => {
                            custom_registers
                                .insert(id.to_string().to_lowercase(), format!("crd{}", index_64));
                            index_64 += 1;
                        }
                        _ => continue,
                    }
                }
                _ => continue,
            }
        }
    }


    (map, labels, custom_registers)
}
