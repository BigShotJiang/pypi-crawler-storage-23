use crate::parser::{BodyItem, PTXFile, PTXInstruction};
use pyo3::exceptions::PyValueError;
use pyo3::types::{PyModule, PyModuleMethods};
use pyo3::{
    Bound, PyResult, Python, pyfunction, pymodule, wrap_pyfunction,
};

pub mod parser;
#[pyfunction]
fn parse_ptx(py: Python<'_>, content: &str) -> PyResult<PTXFile> {
    match parser::ptx_parser::program(content, py) {
        Ok(prog) => Ok(prog),
        Err(err) => Err(PyValueError::new_err(format!("{}", err))),
    }
}

#[pyfunction]
fn parse_instruction(content: &str) -> PyResult<Option<PTXInstruction>> {
    match parser::ptx_parser::parse_single_instruction(content) {
        Ok(instr) => Ok(Some(instr)),
        Err(_) => Ok(None),
    }
}

#[pyfunction]
fn parse_function_body_line(line: &str) -> PyResult<Option<BodyItem>> {
    match parser::ptx_parser::parse_function_body_line(line) {
        Ok(instr) => Ok(Some(instr)),
        Err(_) => Ok(None),
    }
}

#[pymodule]
fn ptx_parser(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(parse_ptx, m)?)?;
    m.add_function(wrap_pyfunction!(parse_instruction, m)?)?;
    m.add_function(wrap_pyfunction!(parse_function_body_line, m)?)?;
    m.add_class::<PTXFile>()?;
    Ok(())
}
