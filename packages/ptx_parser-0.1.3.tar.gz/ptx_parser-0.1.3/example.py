import ptx_parser

code = """
.version 8.0
.target sm_52
.address_size 64

.visible .entry _Z30matrixMultiplicationKernel_ShMPiS_iS_(
.param .u64 _Z30matrixMultiplicationKernel_ShMPiS_iS__param_0,
.param .u64 _Z30matrixMultiplicationKernel_ShMPiS_iS__param_1,
.param .u32 _Z30matrixMultiplicationKernel_ShMPiS_iS__param_2,
.param .u64 _Z30matrixMultiplicationKernel_ShMPiS_iS__param_3
) {
    .reg .pred %p<3>;
    .reg .b32 %r<91>;
    .reg .b64 %rd<19>;

    ld.param.u64 %rd18, %rd19;
    mov.u32 %r1, %ctaid.y;
    mov.u32 %r2, %tid.y;
    mov.u32 %r17, %ctaid.x;
    shl.b32 %r3, %r17, 4;
    mov.u32 %r4, %tid.x;
    setp.lt.s32 %p1, %r15, 16;
    mov.u32 %r90, 0;
}
"""

result = ptx_parser.parse_ptx(code)
header = result.header
print("Header\nversion:", str(header.version), "\ntarget:", header.target,"\naddress_size:", header.address_size)
functions = result.functions

for function in functions:
    print(function.name, function.offset)
    body = function.body
    for instruction in function.body.instructions:
        offset = instruction.offset
        print(offset, "\t", str(instruction))

