"""Agent signing module."""

__version__ = "0.1.0"


def sign(message: str) -> str:
    """Sign a message and return a signature string."""
    import hashlib
    return hashlib.sha256(message.encode()).hexdigest()
