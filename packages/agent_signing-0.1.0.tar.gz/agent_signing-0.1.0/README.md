# agent-signing

A Python package for signing agent setups. It produces a SHA-256 signature for a given agent configuration message, allowing you to verify that an agent setup has not been tampered with.

## Installation

```bash
pip install -e .
```

## Usage

```python
import agent_signing

signature = agent_signing.sign("my agent config")
```
