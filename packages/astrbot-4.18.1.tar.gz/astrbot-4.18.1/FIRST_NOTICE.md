## 欢迎使用 AstrBot

🌟 感谢您使用 AstrBot！

AstrBot 是一款可接入多种 IM 平台的 Agentic AI 个人 / 群聊助手，内置多项强大功能，希望能为您带来高效、愉快的使用体验。❤️

我们想特别说明：

AstrBot 是受 AGPLv3 开源协议保护的**免费开源软件项目**，您可以在[**官方网站**](https://astrbot.app)、[**GitHub**](https://github.com/astrbotdevs/astrbot) 上找到 AstrBot 的全部源代码及相关资源。
截至目前，AstrBot 项目**未开展任何形式的商业化服务**，官方**不会以任何名义向用户收取费用**。

如果您在使用 AstrBot 的过程中被要求付费，**表明您已经遭遇诈骗行为**。请立即向相关方申请退款，并及时通过邮件向我们反馈。

📮 官方邮箱：[community@astrbot.app](mailto:community@astrbot.app)
