from .dense_mfac import DenseMFAC

__all__ = [
    'DenseMFAC'
]