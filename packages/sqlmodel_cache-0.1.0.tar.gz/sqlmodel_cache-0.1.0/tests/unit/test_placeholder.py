# Placeholder — unit tests will be added from Story 1.2 onwards.
# pytest tests/unit/ must exit 0 even with zero test functions collected (AC5).
