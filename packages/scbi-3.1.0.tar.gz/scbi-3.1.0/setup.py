"""
SCBI Setup Script
Stochastic Covariance-Based Initialization for Neural Networks
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read long description from README
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding='utf-8')

setup(
    name="scbi",
    version="3.1.0",
    author="Fares Ashraf",
    author_email="farsashraf44@gmail.com",
    description="Neural network initialization achieving 87× faster convergence via ridge regression",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/faresashraf/SCBI",
    project_urls={
        "Bug Tracker": "https://github.com/faresashraf/SCBI/issues",
        "Documentation": "https://github.com/faresashraf/SCBI#readme",
        "Source Code": "https://github.com/faresashraf/SCBI",
        "Research Paper": "https://doi.org/10.5281/zenodo.18850507",
        "Zenodo Archive": "https://doi.org/10.5281/zenodo.18850507",
    },
    packages=find_packages(where=".", exclude=["tests*", "benchmarks*", "examples*", "docs*","scbi_env*", "build*", "dist*"]),
    py_modules=["SCBI"],
    classifiers=[
        # Development status
        "Development Status :: 4 - Beta",
        
        # Intended audience
        "Intended Audience :: Science/Research",
        "Intended Audience :: Developers",
        "Intended Audience :: Education",
        
        # Topic
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Scientific/Engineering :: Mathematics",
        "Topic :: Software Development :: Libraries :: Python Modules",
        
        # License
        "License :: OSI Approved :: MIT License",
        
        # Python versions
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3 :: Only",
        
        # OS
        "Operating System :: OS Independent",
        
        # Framework
        "Framework :: Jupyter",
        
        # Natural language
        "Natural Language :: English",
    ],
    keywords=[
        "neural-networks",
        "initialization",
        "deep-learning",
        "pytorch",
        "ridge-regression",
        "machine-learning",
        "weight-initialization",
        "convergence-acceleration",
        "transfer-learning",
    ],
    python_requires=">=3.8",
    install_requires=[
        "torch>=1.9.0",
        "numpy>=1.19.0",
        "scikit-learn>=0.24.0",
    ],
    extras_require={
        "benchmarks": [
            "pandas>=1.2.0",
            "matplotlib>=3.3.0",
            "seaborn>=0.11.0",
            "scipy>=1.6.0",
            "tqdm>=4.50.0",
        ],
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=3.0.0",
            "black>=22.0.0",
            "flake8>=4.0.0",
            "isort>=5.10.0",
            "mypy>=0.950",
        ],
        "docs": [
            "sphinx>=4.5.0",
            "sphinx-rtd-theme>=1.0.0",
        ],
        "all": [
            "pandas>=1.2.0",
            "matplotlib>=3.3.0",
            "seaborn>=0.11.0",
            "scipy>=1.6.0",
            "tqdm>=4.50.0",
            "pytest>=7.0.0",
            "pytest-cov>=3.0.0",
            "black>=22.0.0",
            "flake8>=4.0.0",
        ],
    },
    include_package_data=True,
    zip_safe=False,
    license="MIT",
    platforms=["any"],
)
