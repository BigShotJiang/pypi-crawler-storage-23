# dumbo-utils

Different utilities to be reused in other projects


# Prerequisites

- Python 3.10+



## Install

Add to your project with
```bash
$ poetry add dumbo-utils
```