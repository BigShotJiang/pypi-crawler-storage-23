# SPDX-License-Identifier: Apache-2.0
"""
Suno vulnerable test application package.
"""
