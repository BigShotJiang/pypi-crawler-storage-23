# SPDX-License-Identifier: Apache-2.0
"""
Uxarion CLI - AI-driven penetration testing toolkit
"""

__version__ = "0.1.0"
__author__ = "Uxarion Team"
