"""
License business logic — will be obfuscated before distribution.
Do not import this module directly in user-facing code beyond settings.py.
"""

import os
import json
import uuid
import hashlib
import platform
from typing import Optional

import keyring
import keyring.errors
import requests


# ── Constants ─────────────────────────────────────────────────────────────────

BASE_URL = "https://altera-license-server.onrender.com"
ACTIVATION_URL = f"{BASE_URL}/license/activate"
VALIDATE_URL = f"{BASE_URL}/license/validate"
DEACTIVATE_URL = f"{BASE_URL}/license/deactivate"


# ── Machine ID ────────────────────────────────────────────────────────────────

def _get_cpu_id() -> str:
    import subprocess

    sys = platform.system()
    try:
        if sys == "Windows":
            out = subprocess.check_output(
                ["wmic", "cpu", "get", "ProcessorId"],
                text=True,
                stderr=subprocess.DEVNULL,
            )
            lines = [
                l.strip()
                for l in out.splitlines()
                if l.strip() and l.strip() != "ProcessorId"
            ]
            return lines[0] if lines else ""
        if sys == "Darwin":
            return platform.processor()
        if sys == "Linux":
            with open("/proc/cpuinfo") as f:
                for line in f:
                    if line.lower().startswith("serial"):
                        return line.split(":", 1)[1].strip()
            with open("/proc/cpuinfo") as f:
                for line in f:
                    if "model name" in line.lower():
                        return hashlib.md5(
                            line.split(":", 1)[1].strip().encode()
                        ).hexdigest()
    except Exception:
        pass
    return ""


def _get_motherboard_id() -> str:
    import subprocess

    sys = platform.system()
    try:
        if sys == "Windows":
            out = subprocess.check_output(
                ["wmic", "baseboard", "get", "SerialNumber"],
                text=True,
                stderr=subprocess.DEVNULL,
            )
            lines = [
                l.strip()
                for l in out.splitlines()
                if l.strip() and l.strip() != "SerialNumber"
            ]
            return lines[0] if lines else ""
        if sys == "Darwin":
            out = subprocess.check_output(
                ["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"],
                text=True,
                stderr=subprocess.DEVNULL,
            )
            for line in out.splitlines():
                if "IOPlatformSerialNumber" in line:
                    return line.split('"')[-2]
        if sys == "Linux":
            try:
                out = subprocess.check_output(
                    ["sudo", "-n", "dmidecode", "-s", "baseboard-serial-number"],
                    text=True,
                    stderr=subprocess.DEVNULL,
                )
                val = out.strip()
                if val and val.lower() not in ("", "to be filled by o.e.m.", "none"):
                    return val
            except Exception:
                pass
            for path in (
                "/sys/class/dmi/id/board_serial",
                "/sys/class/dmi/id/product_uuid",
            ):
                if os.path.exists(path):
                    try:
                        with open(path) as f:
                            val = f.read().strip()
                        if val:
                            return val
                    except PermissionError:
                        pass
    except Exception:
        pass
    return ""


def get_machine_id() -> str:
    cpu_id = _get_cpu_id()
    mb_id = _get_motherboard_id()

    if cpu_id or mb_id:
        digest = hashlib.sha256(f"{cpu_id}|{mb_id}".encode()).hexdigest().upper()
        d = digest[:16]
        return f"{d[0:4]}-{d[4:8]}-{d[8:12]}-{d[12:16]}"

    # Fallback: persist a random ID in the user's app data folder
    fallback_dir = os.path.join(os.path.expanduser("~"), ".altera_suite")
    fallback_path = os.path.join(fallback_dir, "machine_id")
    os.makedirs(fallback_dir, exist_ok=True)
    if os.path.exists(fallback_path):
        with open(fallback_path) as f:
            return f.read().strip()
    digest = hashlib.sha256(str(uuid.uuid4()).encode()).hexdigest().upper()
    d = digest[:16]
    mid = f"{d[0:4]}-{d[4:8]}-{d[8:12]}-{d[12:16]}"
    with open(fallback_path, "w") as f:
        f.write(mid)
    return mid


# ── Token storage ─────────────────────────────────────────────────────────────

KEYRING_SERVICE = "AlteraDataSuite"
KEYRING_USER = "license"

LEGACY_TOKEN_FILE = os.path.join(
    os.path.expanduser("~"), ".altera_suite", "license.json"
)


def _migrate_legacy_token() -> None:
    if not os.path.exists(LEGACY_TOKEN_FILE):
        return
    try:
        with open(LEGACY_TOKEN_FILE) as f:
            data = json.load(f)
        if data.get("token"):
            keyring.set_password(KEYRING_SERVICE, KEYRING_USER, json.dumps(data))
            os.remove(LEGACY_TOKEN_FILE)
            print("[License] migrated legacy license.json → keyring")
    except Exception as e:
        print(f"[License] migration error (ignored): {e}")


def load_stored_license() -> Optional[dict]:
    _migrate_legacy_token()
    try:
        val = keyring.get_password(KEYRING_SERVICE, KEYRING_USER)
        if not val:
            return None
        return json.loads(val)
    except Exception as e:
        print(f"[License] keyring read error: {e}")
        return None


def save_license(data: dict) -> None:
    try:
        keyring.set_password(KEYRING_SERVICE, KEYRING_USER, json.dumps(data))
    except Exception as e:
        print(f"[License] keyring write error: {e}")


def delete_license() -> None:
    try:
        keyring.delete_password(KEYRING_SERVICE, KEYRING_USER)
    except keyring.errors.PasswordDeleteError:
        pass
    except Exception as e:
        print(f"[License] keyring delete error: {e}")


# ── License operations ────────────────────────────────────────────────────────

def check_license(machine_id: str, send: callable) -> None:
    stored = load_stored_license()
    if not stored or "token" not in stored:
        print("[License] check_license: no stored token")
        send({"type": "license_check_result", "valid": False, "state": "invalid"})
        return

    token = stored["token"]
    print(f"[License] check_license: POST {VALIDATE_URL}")
    try:
        resp = requests.post(
            VALIDATE_URL,
            json={"token": token, "machine_id": machine_id},
            timeout=5,
        )
        print(f"[License] check_license: HTTP {resp.status_code} — {resp.text[:200]}")

        if resp.ok:
            data = resp.json()

            if data.get("valid"):
                license_data = {
                    "token": token,
                    "email": data.get("email", stored.get("email", "")),
                    "plan": data.get("plan", stored.get("plan", "")),
                    "expiry": data.get("expiry_date", stored.get("expiry", "")),
                }
                save_license(license_data)
                send(
                    {
                        "type": "license_check_result",
                        "valid": True,
                        "state": "valid",
                        "token": token,
                        "email": license_data["email"],
                        "plan": license_data["plan"],
                        "expiry_date": license_data["expiry"],
                    }
                )

            elif data.get("expired"):
                stored["expiry"] = data.get("expiry_date", stored.get("expiry", ""))
                stored["email"] = data.get("email", stored.get("email", ""))
                stored["plan"] = data.get("plan", stored.get("plan", ""))
                save_license(stored)
                send(
                    {
                        "type": "license_check_result",
                        "valid": False,
                        "state": "expired",
                        "expired": True,
                        "email": stored["email"],
                        "plan": stored["plan"],
                        "expiry_date": stored["expiry"],
                        "message": data.get("message")
                        or f"License expired on {stored['expiry']}",
                    }
                )

            else:
                delete_license()
                send(
                    {
                        "type": "license_check_result",
                        "valid": False,
                        "state": "invalid",
                        "message": data.get("message", "License is no longer valid"),
                    }
                )

        else:
            delete_license()
            send({"type": "license_check_result", "valid": False, "state": "invalid"})

    except requests.exceptions.ConnectionError:
        print("[License] check_license: offline, using cached token")
        send(
            {
                "type": "license_check_result",
                "valid": True,
                "state": "valid",
                "token": token,
                "email": stored.get("email", ""),
                "plan": stored.get("plan", ""),
                "expiry_date": stored.get("expiry", ""),
                "offline": True,
            }
        )
    except requests.exceptions.Timeout:
        print("[License] check_license: timed out, using cached token")
        send(
            {
                "type": "license_check_result",
                "valid": True,
                "state": "valid",
                "token": token,
                "email": stored.get("email", ""),
                "plan": stored.get("plan", ""),
                "expiry_date": stored.get("expiry", ""),
                "offline": True,
            }
        )
    except Exception as e:
        print(f"[License] check_license error: {e}")
        send({"type": "license_check_result", "valid": False, "state": "invalid"})


def activate_license(license_key: str, machine_id: str, send: callable) -> None:
    print(f"[License] activate: POST {ACTIVATION_URL}")
    try:
        username = os.environ.get("USERNAME") or os.environ.get("USER") or ""
        resp = requests.post(
            ACTIVATION_URL,
            json={
                "license_key": license_key,
                "machine_id": machine_id,
                "username": username,
            },
            timeout=15,
        )
        print(f"[License] activate: HTTP {resp.status_code} — {resp.text[:200]}")
        if resp.ok:
            data = resp.json()
            license_data = {
                "token": data.get("token", ""),
                "email": data.get("email", ""),
                "plan": data.get("plan", ""),
                "expiry": data.get("expiry_date", ""),
            }
            save_license(license_data)
            send(
                {
                    "type": "activate_result",
                    "success": True,
                    "token": data.get("token", ""),
                    "email": data.get("email", ""),
                    "plan": data.get("plan", ""),
                    "expiry_date": data.get("expiry_date", ""),
                }
            )
        else:
            try:
                err = resp.json().get("detail", resp.text)
            except Exception:
                err = resp.text or f"HTTP {resp.status_code}"
            send({"type": "activate_result", "success": False, "error": err})

    except requests.exceptions.ConnectionError:
        send(
            {
                "type": "activate_result",
                "success": False,
                "error": "No internet connection.",
            }
        )
    except Exception as e:
        send({"type": "activate_result", "success": False, "error": str(e)})


def deactivate_license(machine_id: str, send: callable) -> None:
    stored = load_stored_license()
    token = stored.get("token") if stored else None
    if token:
        try:
            requests.post(
                DEACTIVATE_URL,
                json={"token": token, "machine_id": machine_id},
                timeout=10,
            )
        except Exception as e:
            print(f"[License] deactivate call failed (ignoring): {e}")

    delete_license()
    send(
        {
            "type": "deactivate_result",
            "success": True,
            "message": "License deactivated successfully",
        }
    )
