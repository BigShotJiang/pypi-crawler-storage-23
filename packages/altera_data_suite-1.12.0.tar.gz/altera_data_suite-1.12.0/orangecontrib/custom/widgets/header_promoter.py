import os
import json
from PyQt6.QtCore import QObject, pyqtSlot
from Orange.widgets import widget
from Orange.widgets.widget import Input, Output
from Orange.widgets.settings import Setting
from Orange.data import Table
from .web_utils import WebEngineMixin
from .auxiliary_functions import _o2dwc, _prth, _d2ohp


class _Br(QObject):
    def __init__(self, _v, _pw):
        super().__init__()
        self._v = _v
        self._pw = _pw
        self._pj = []
        self._ld = False
        self._v.loadFinished.connect(self._ol)

    def _ol(self, ok):
        if ok:
            self._ld = True
            for _j in self._pj:
                self._v.page().runJavaScript(_j)
            self._pj.clear()

    def _rj(self, _j):
        if self._ld:
            self._v.page().runJavaScript(_j)
        else:
            self._pj.append(_j)

    def _std(self, _d):
        self._rj(f"window.updateTableData&&window.updateTableData({_d});")

    def _rs(self, _s):
        self._rj(f"window.restoreState&&window.restoreState({_s});")

    def _sn(self):
        self._rj("window.showNoDataMessage&&window.showNoDataMessage();")

    @pyqtSlot(str)
    def promoteRow(self, _s):
        self._pw._opr(_s)


class OWRowToHeader(WebEngineMixin, widget.OWWidget):
    name = "Header Promoter"
    description = "Promote any row in your table to become column headers"
    category = "Altera Data Suite"
    icon = "icons/header_promoter.svg"
    priority = 15

    class Inputs:
        data = Input("Input Table", Table)

    class Outputs:
        output_data = Output("Output Table", Table)

    row_index = Setting(None)
    remove_above = Setting(True)
    DESTROY_TIMEOUT = 300
    want_main_area = True
    want_control_area = False
    resizing_enabled = True

    class Error(widget.OWWidget.Error):
        license_error = widget.Msg("License error: {}")

    def __init__(self):
        super().__init__()
        self._id = None
        self._df = None
        self._od = None
        self._ov = []
        _h = os.path.join(
            os.path.dirname(__file__), "UI", "header_promoter_ui", "index.html"
        )
        self.setup_webengine_lazy(_h, _Br, zoom_factor=0.9)

    def on_webengine_ready(self):
        if self._df is not None:
            self._sdui()
            if self.row_index is not None:
                self.bridge._rs(
                    json.dumps(
                        {"rowIndex": self.row_index, "removeAbove": self.remove_above}
                    )
                )
            if self.row_index is not None and self.row_index < len(self._df):
                self._at()
        elif self.web_loaded and self.bridge:
            self.bridge._sn()

    def on_webengine_show(self):
        pass

    @Inputs.data
    def set_data(self, data):
        self.Error.clear()
        if data is None:
            self._id = None
            self._df = None
            self._od = None
            self._ov = []
            self.Outputs.output_data.send(None)
            if self.web_loaded and self.bridge:
                self.bridge._sn()
            return
        self._id = data
        self._od = data.domain
        self._ov = (
            list(data.domain.attributes)
            + list(data.domain.class_vars)
            + list(data.domain.metas)
        )
        self._df = _o2dwc(data)
        if self.row_index is not None and self.row_index < len(self._df):
            self._at()
        else:
            self.Outputs.output_data.send(self._id)
        if self.web_loaded and self.bridge:
            self._sdui()

    def _sdui(self):
        if self._df is None or not self.bridge:
            return
        _pr = min(100, len(self._df))
        _dp = self._df.head(_pr)
        self.bridge._std(
            json.dumps(
                {
                    "columns": self._df.columns.tolist(),
                    "rows": [[str(c) for c in r] for r in _dp.values.tolist()],
                    "totalRows": len(self._df),
                    "previewRows": _pr,
                }
            )
        )

    @pyqtSlot(str)
    def _opr(self, _s):
        try:
            _p = json.loads(_s)
            self.row_index = _p.get("row_index")
            self.remove_above = _p.get("remove_above", True)
            self._at()
        except RuntimeError as _e:
            self.Error.license_error(str(_e))
            self.Outputs.output_data.send(None)
        except Exception:
            import traceback

            traceback.print_exc()

    def _at(self):
        if self._df is None or self.row_index is None:
            self.Outputs.output_data.send(self._id)
            return
        try:
            self.Outputs.output_data.send(
                _d2ohp(
                    _prth(self._df, self.row_index, self.remove_above),
                    self._ov,
                    self._od,
                    self._id,
                )
            )
        except RuntimeError as _e:
            self.Error.license_error(str(_e))
            self.Outputs.output_data.send(None)
        except IndexError:
            self.Outputs.output_data.send(self._id)
        except Exception:
            import traceback

            traceback.print_exc()
            self.Outputs.output_data.send(self._id)
