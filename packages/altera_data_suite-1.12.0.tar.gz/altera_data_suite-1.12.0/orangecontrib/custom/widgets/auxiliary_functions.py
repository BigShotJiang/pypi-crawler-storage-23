import os,re,json,base64,string
from io import BytesIO
import fitz,camelot,numpy as np,pandas as pd
from PIL import Image
from pypdfium2 import PdfDocument
from Orange.data import Table,Domain,ContinuousVariable,DiscreteVariable,StringVariable,TimeVariable
import keyring,keyring.errors,requests

_KS="AlteraDataSuite"
_KU="license"
_VU="https://altera-license-server.onrender.com/license/validate"

def _lt()->tuple:
    try:
        _v=keyring.get_password(_KS,_KU);
        if not _v:return None,None
        _d=json.loads(_v);_tk=_d.get("token")
        return _tk,_d
    except Exception:return None,None

def verify_license()->bool:
    from .settings_business_logic import _gid
    _tk,_stored=_lt()
    if not _tk:return False
    try:
        _r=requests.post(_VU,json={"token":_tk,"machine_id":_gid()},timeout=5)
        if _r.ok:return _r.json().get("valid",False)
        return False
    except (requests.exceptions.ConnectionError,requests.exceptions.Timeout):
        return bool(_tk)
    except Exception:return False

def check_license():
    if not verify_license():
        raise RuntimeError("Altera Data Suite: Invalid or expired license. Please contact support to renew.")

def make_unique_column_names(columns)->list:
    seen={};unique=[]
    for col in columns:
        name=str(col)
        if name not in seen:seen[name]=0;unique.append(name)
        else:seen[name]+=1;unique.append(f"{name}_{seen[name]}")
    return unique

def orange_to_df(table:Table)->pd.DataFrame:
    df_dict={};d=table.domain
    for i,v in enumerate(d.attributes):df_dict[v.name]=table.X[:,i]
    for i,v in enumerate(d.class_vars):
        col=table.Y[:,i] if table.Y.ndim>1 else table.Y;df_dict[v.name]=col
    for i,v in enumerate(d.metas):df_dict[v.name]=table.metas[:,i]
    return pd.DataFrame(df_dict)

def orange_to_df_ordered(table:Table)->pd.DataFrame:
    df_dict={};column_order=[];d=table.domain
    for i,v in enumerate(d.attributes):df_dict[v.name]=table.X[:,i];column_order.append(v.name)
    for i,v in enumerate(d.class_vars):
        col=table.Y[:,i] if table.Y.ndim>1 else table.Y;df_dict[v.name]=col;column_order.append(v.name)
    for i,v in enumerate(d.metas):df_dict[v.name]=table.metas[:,i];column_order.append(v.name)
    return pd.DataFrame(df_dict)[column_order]

def orange_to_df_with_categoricals(table:Table)->pd.DataFrame:
    df={};d=table.domain
    for i,v in enumerate(d.attributes):
        if v.is_discrete:
            col_data=table.X[:,i]
            df[v.name]=[v.values[int(idx)] if not np.isnan(idx) else "" for idx in col_data]
        elif v.is_continuous:df[v.name]=table.X[:,i]
        else:df[v.name]=table.X[:,i].astype(str)
    for i,v in enumerate(d.class_vars):
        col=table.Y[:,i] if table.Y.ndim>1 else table.Y
        if v.is_discrete:df[v.name]=[v.values[int(idx)] if not np.isnan(idx) else "" for idx in col]
        elif v.is_continuous:df[v.name]=col
        else:df[v.name]=col.astype(str)
    for i,v in enumerate(d.metas):
        col_data=table.metas[:,i]
        if v.is_discrete:df[v.name]=[v.values[int(idx)] if not np.isnan(idx) else "" for idx in col_data]
        elif v.is_continuous:df[v.name]=col_data
        elif v.is_string:df[v.name]=col_data
        else:df[v.name]=[str(x) for x in col_data]
    return pd.DataFrame(df)

def df_to_orange_preserve_domain(df:pd.DataFrame,original_domain:Domain)->Table:
    check_license();d=original_domain;n=len(df)
    X=np.zeros((n,len(d.attributes)));Y=np.zeros((n,len(d.class_vars))) if d.class_vars else None
    M=np.empty((n,len(d.metas)),dtype=object)
    for i,v in enumerate(d.attributes):X[:,i]=df[v.name].to_numpy()
    for i,v in enumerate(d.class_vars):
        col=df[v.name].to_numpy()
        if Y is not None:
            if Y.ndim>1:Y[:,i]=col
            else:Y=col
    for i,v in enumerate(d.metas):M[:,i]=df[v.name].astype(str).to_numpy()
    return Table.from_numpy(d,X,Y=Y,metas=M)

def dataframe_to_orange_table_basic(df:pd.DataFrame)->Table:
    check_license();df=df.copy();df.columns=make_unique_column_names(df.columns)
    attributes,metas,X_data,metas_data=[],[],[],[]
    for col in df.columns:
        col_data=df[col]
        if col.lower()=="page" or pd.api.types.is_numeric_dtype(col_data.dtype):
            attributes.append(ContinuousVariable(col));X_data.append(col_data.to_numpy(dtype=float))
        elif pd.api.types.is_datetime64_any_dtype(col_data.dtype):
            metas.append(TimeVariable(col));metas_data.append(col_data.astype("int64")/1e9)
        else:
            metas.append(StringVariable(col));metas_data.append(col_data.astype(str).to_numpy())
    X_matrix=np.column_stack(X_data) if X_data else np.empty((len(df),0))
    metas_matrix=np.column_stack(metas_data) if metas_data else None
    return Table.from_numpy(Domain(attributes,metas=metas),X_matrix,metas=metas_matrix)

# ── PDF CONVERTER ──────────────────────────────────────────────────────────────

_CM={"rgb(49, 122, 185)":"Blue","rgb(239, 68, 68)":"Red","rgb(34, 197, 94)":"Green","rgb(168, 85, 247)":"Purple","rgb(249, 115, 22)":"Orange"}

def _h1(page,zoom=2.0,white_threshold=150,invert=False,gamma=1.0,min_alpha=0,max_alpha=255,ink_color=(0,0,0)):
    mat=fitz.Matrix(zoom,zoom);pix=page.get_pixmap(matrix=mat,alpha=False)
    img=Image.frombytes("RGB",(pix.width,pix.height),pix.samples)
    arr=np.array(img.convert("L")).astype(np.float32)
    if invert:arr=255-arr
    ink_strength=np.clip((white_threshold-arr)/white_threshold,0,1);ink_strength=np.power(ink_strength,gamma)
    alpha=np.clip((ink_strength*255).astype(np.uint8),min_alpha,max_alpha)
    rgba=np.zeros((arr.shape[0],arr.shape[1],4),dtype=np.uint8);rgba[...,:3]=ink_color;rgba[...,3]=alpha
    return Image.fromarray(rgba,"RGBA")

def _h0(args):
    pdf_path,page_index,params=args;doc=fitz.open(pdf_path);page=doc[page_index]
    img=_h1(page,zoom=params["zoom"],white_threshold=params["white_threshold"],invert=params["invert"],gamma=params["gamma"],min_alpha=params["min_alpha"],max_alpha=params["max_alpha"],ink_color=params["ink_color"])
    alpha=img.split()[3].point(lambda a:int(a*params["opacity"]));img.putalpha(alpha)
    buf=BytesIO();img.save(buf,format="PNG");doc.close();return page_index,buf.getvalue()

def open_pdf_document(pdf_path):
    try:pdf_doc=PdfDocument(pdf_path);return pdf_doc,len(pdf_doc)
    except Exception:return None,0

def render_pdf_page(pdf_doc,page_index,dpi=72):
    page=pdf_doc[page_index];scale_factor=dpi/72.0;bitmap=page.render(scale=scale_factor)
    pil_image=bitmap.to_pil();buffer=BytesIO();pil_image.save(buffer,format="PNG")
    return f"data:image/png;base64,{base64.b64encode(buffer.getvalue()).decode('utf-8')}"

def parse_coordinates_from_js(data_str):
    data=json.loads(data_str);tables_info=[]
    for item in data:
        table_area=item.get("table_area",[]);columns=item.get("columns",[]);color=item.get("color","")
        tables_info.append({"color":color,"table_area":table_area,"columns":[str(c) for c in columns] if columns else []})
    return tables_info

def generate_javascript_call(function_name,*args):
    if function_name=="restoreHtmlDelimiters":return f"restoreHtmlDelimiters({args[0]})"
    elif function_name=="restoreHtmlTableArea":return f"restoreHtmlTableArea({args[0]})"
    elif function_name=="restoreBreakLines":return f"restoreBreakLines({args[0]})"
    elif function_name=="displayPdfImage":
        img_data,page_num,total_pages,file_path,show_loader=args
        return f"displayPdfImage('{img_data}',{page_num},{total_pages},'{file_path}',showLoader={show_loader})"
    elif function_name=="restoreUiState":return f"restoreUiState({args[0]})"
    return ""

def _h2(file_path,page_num,tables_info,dpi):
    page_dataframes=[]
    for i,info in enumerate(tables_info):
        table_area_coords=info.get("table_area")
        if not table_area_coords or len(table_area_coords)!=4:continue
        table_area=[",".join(map(str,table_area_coords))]
        column_coords=info.get("columns",[]);columns=[",".join(column_coords)] if column_coords else None
        try:
            tables=camelot.read_pdf(file_path,flavor="stream",pages=str(page_num),table_areas=table_area,columns=columns,split_text=True)
            color_value=info.get("color","Unknown")
            color_name=color_value if color_value in _CM.values() else _CM.get(color_value,"Unknown")
            for table in tables:
                df=table.df.copy();df["Table Color"]=f"Table: {color_name}";df["Page"]=page_num;page_dataframes.append(df)
        except Exception:pass
    return page_dataframes

def _f1(file_path,tables_info,total_pages,dpi,progress_callback=None):
    all_dataframes=[]
    for i,page_num in enumerate(range(1,total_pages+1)):
        page_tables=_h2(file_path,page_num,tables_info,dpi=dpi);all_dataframes.extend(page_tables)
        if progress_callback:progress_callback(i+1,total_pages)
    if not all_dataframes:return None
    concat_df=pd.concat(all_dataframes,ignore_index=True)
    cols=[c for c in concat_df.columns if c not in ("Table Color","Page")]
    return concat_df[cols+["Table Color","Page"]]

def _f2(df):
    df.columns=make_unique_column_names(df.columns)
    attributes,metas,X_data,metas_data=[],[],[],[]
    for col in df.columns:
        col_data=df[col];dtype=col_data.dtype
        if col=="Page":
            attributes.append(ContinuousVariable(col));X_data.append(col_data.to_numpy(dtype=int))
        elif col=="Table Color":
            unique_values=col_data.unique().tolist();discrete_var=DiscreteVariable(col,values=unique_values);attributes.append(discrete_var)
            X_data.append(col_data.map({val:idx for idx,val in enumerate(unique_values)}).to_numpy(dtype=float))
        elif pd.api.types.is_numeric_dtype(dtype):
            attributes.append(ContinuousVariable(col));X_data.append(col_data.to_numpy(dtype=float))
        elif pd.api.types.is_datetime64_any_dtype(dtype):
            metas.append(TimeVariable(col));metas_data.append(col_data.astype("int64")/1e9)
        else:
            metas.append(StringVariable(col));metas_data.append(col_data.astype(str).to_numpy())
    X_matrix=np.column_stack(X_data) if X_data else np.empty((len(df),0))
    metas_matrix=np.column_stack(metas_data) if metas_data else None
    return Table.from_numpy(Domain(attributes=attributes,metas=metas),X=X_matrix,metas=metas_matrix)

def validate_pdf_path(file_path):
    if not file_path:return False,"empty"
    if not os.path.exists(file_path):return False,"not_found"
    if not os.path.isfile(file_path):return False,"not_file"
    if not file_path.lower().endswith(".pdf"):return False,"not_pdf"
    return True,None

def _f4(file_path):
    try:pdf_doc=PdfDocument(file_path);count=len(pdf_doc);pdf_doc.close();return count
    except Exception:return 0

def should_restore_settings(file_path,table_area):
    return file_path!="" and table_area!=[]

def _f3(file_path):
    if file_path:return f"Processed: {os.path.basename(file_path)}"
    return "Ready"

def cleanup_pdf_resources(pdf_doc):
    try:
        if pdf_doc:pdf_doc.close()
    except Exception:pass

def _f0(pdf_path,output_path,*,zoom=3.0,opacity=0.3,white_threshold=150,invert=False,gamma=1.0,min_alpha=0,max_alpha=255,ink_color=(0,0,0),progress_cb=None,max_workers=None):
    from concurrent.futures import ProcessPoolExecutor,as_completed
    import io
    doc=fitz.open(pdf_path);total=len(doc);doc.close()
    params=dict(zoom=zoom,opacity=opacity,white_threshold=white_threshold,invert=invert,gamma=gamma,min_alpha=min_alpha,max_alpha=max_alpha,ink_color=ink_color)
    tasks=[(pdf_path,i,params) for i in range(total)];base=None;completed=0
    workers=max_workers or max(1,os.cpu_count()-1)
    with ProcessPoolExecutor(max_workers=workers) as pool:
        futures=[pool.submit(_h0,t) for t in tasks]
        for future in as_completed(futures):
            page_index,png_bytes=future.result();img=Image.open(io.BytesIO(png_bytes)).convert("RGBA")
            if base is None:base=Image.new("RGBA",img.size,(0,0,0,0))
            base=Image.alpha_composite(base,img);completed+=1
            if progress_cb:progress_cb(completed,total)
    base.save(output_path)
    if progress_cb:progress_cb(total,total)

# ── CLEANER ────────────────────────────────────────────────────────────────────

def apply_cleaning_operation(series:pd.Series,operation:str,params:dict)->pd.Series:
    check_license();s=series.astype(str)
    if operation=="replace":
        find=params.get("find","");replace=params.get("replace","");case_sensitive=params.get("caseSensitive",False)
        if find:
            if case_sensitive:s=s.str.replace(find,replace,regex=False)
            else:s=s.str.replace(find,replace,case=False,regex=False)
    elif operation=="remove_spaces":s=s.str.replace(r"\s+"," ",regex=True)
    elif operation=="trim":s=s.str.strip()
    elif operation=="remove_special":s=s.str.replace(r"[^a-zA-Z0-9\s]","",regex=True)
    elif operation=="uppercase":s=s.str.upper()
    elif operation=="lowercase":s=s.str.lower()
    elif operation=="titlecase":s=s.str.title()
    elif operation=="remove_digits":s=s.str.replace(r"\d","",regex=True)
    elif operation=="remove_punctuation":s=s.str.replace(f"[{re.escape(string.punctuation)}]","",regex=True)
    elif operation=="strip_chars":
        chars=params.get("chars","")
        if chars:s=s.str.replace(f"[{re.escape(chars)}]","",regex=True)
    elif operation=="remove_prefix":
        prefix=params.get("prefix","")
        if prefix:s=s.str.removeprefix(prefix)
    elif operation=="remove_suffix":
        suffix=params.get("suffix","")
        if suffix:s=s.str.removesuffix(suffix)
    return s

def apply_all_cleaning_operations(df:pd.DataFrame,state_json:str)->pd.DataFrame:
    check_license();state=json.loads(state_json);operations=state.get("operations",[])
    if not operations:return df
    result=df.copy()
    for op in operations:
        column=op.get("column");operation=op.get("operation");params=op.get("params",{})
        if column not in result.columns:continue
        result[column]=apply_cleaning_operation(result[column],operation,params)
    return result

# ── FILTER BUILDER ─────────────────────────────────────────────────────────────

def build_columns_json_for_filter(domain:Domain,df:pd.DataFrame)->str:
    cols=[]
    for v in list(domain.attributes)+list(domain.class_vars)+list(domain.metas):
        if v.is_discrete:col_def={"name":v.name,"type":"categorical","values":list(v.values)}
        elif v.is_continuous:col_def={"name":v.name,"type":"float"}
        else:
            unique_vals=df[v.name].dropna().astype(str).unique()
            col_def={"name":v.name,"type":"text","values":sorted(unique_vals[:100].tolist())}
        cols.append(col_def)
    return json.dumps(cols)

def _apply_condition_mask(df:pd.DataFrame,condition:dict,domain:Domain):
    col=condition["column"];op=condition["operator"];val=condition["value"];s=df[col];var=domain[col]
    if op=="is_defined":return s.notna()&(s.astype(str)!="")
    if op=="is_not_defined":return s.isna()|(s.astype(str)=="")
    try:
        if var.is_continuous:
            v=float(val)
            return {"equals":s==v,"not_equals":s!=v,"greater_than":s>v,"less_than":s<v,"greater_or_equal":s>=v,"less_or_equal":s<=v}.get(op)
        elif var.is_discrete:
            idx=var.values.index(val);return {"equals":s==idx,"not_equals":s!=idx}.get(op)
        else:
            s=s.astype(str)
            return {"equals":s==val,"not_equals":s!=val,"contains":s.str.contains(val,case=False,na=False),"not_contains":~s.str.contains(val,case=False,na=False),"starts_with":s.str.startswith(val,na=False),"ends_with":s.str.endswith(val,na=False)}.get(op)
    except Exception:return None

def build_filter_mask(df:pd.DataFrame,state_json:str,invalid_columns:list,domain:Domain)->np.ndarray:
    check_license();state=json.loads(state_json);group_masks=[]
    for g in state.get("groups",[]):
        masks=[]
        for c in g.get("conditions",[]):
            if c["column"] in invalid_columns:continue
            m=_apply_condition_mask(df,c,domain)
            if m is not None:masks.append(m)
        if not masks:continue
        if g.get("match","all")=="all":group_masks.append(np.logical_and.reduce(masks))
        else:group_masks.append(np.logical_or.reduce(masks))
    if not group_masks:return np.zeros(len(df),dtype=bool)
    return np.logical_or.reduce(group_masks)

# ── COLUMN MANAGER ─────────────────────────────────────────────────────────────

def get_var_type(var)->str:
    if isinstance(var,ContinuousVariable):return "number"
    elif isinstance(var,DiscreteVariable):return "categorical"
    elif isinstance(var,StringVariable):return "string"
    return "string"

def get_columns_info(data:Table,df:pd.DataFrame)->list:
    domain=data.domain;var_map={}
    for var in list(domain.attributes)+list(domain.class_vars)+list(domain.metas):
        var_map[var.name]={"name":var.name,"type":get_var_type(var),"field":var.name,"isNew":False}
    return [var_map[col] for col in df.columns if col in var_map]

def is_compatible_configuration(saved_columns:list,current_columns:list)->bool:
    saved_fields={c["field"] for c in saved_columns if not c.get("isNew")}
    current_fields={c["field"] for c in current_columns}
    if current_fields.issubset(saved_fields):return True
    return len(saved_fields.intersection(current_fields))>0

def apply_saved_configuration(saved_columns:list,current_columns:list,column_state_json:str)->list:
    check_license();current_fields={col["field"]:col for col in current_columns}
    try:saved_state=json.loads(column_state_json);original_input_fields=set(saved_state.get("originalInputFields",[]))
    except Exception:original_input_fields=set()
    saved_fields_set={col["field"] for col in saved_columns};result=[]
    for saved_col in saved_columns:
        field=saved_col["field"]
        if not saved_col.get("isNew"):
            if field in current_fields:col=current_fields[field].copy();col["name"]=saved_col["name"];result.append(col)
        else:result.append(saved_col)
    for field,col in current_fields.items():
        if field not in saved_fields_set and field not in original_input_fields:result.append(col)
    return result

def apply_column_changes(df:pd.DataFrame,columns_info:list)->pd.DataFrame:
    check_license();new_df=pd.DataFrame()
    for col_info in columns_info:
        field=col_info["field"]
        if field in df.columns:new_df[field]=df[field]
        elif col_info.get("isNew"):
            default_val=col_info.get("defaultValue","")
            if col_info["type"]=="number":
                try:default_val=float(default_val) if default_val else 0.0
                except (ValueError,TypeError):default_val=0.0
            new_df[field]=[default_val]*len(df)
    return new_df

def df_to_orange_columns_manager(df:pd.DataFrame,columns_info:list,original_domain:Domain)->Table:
    check_license();metas,metas_data=[],[]
    for col_info in columns_info:
        field=col_info["field"];name=col_info["name"];col_type=col_info["type"]
        if field not in df.columns:continue
        col_data=df[field];orig_var=original_domain[field] if field in original_domain else None
        if col_type=="number":
            var=(orig_var.copy(name=name) if orig_var and isinstance(orig_var,ContinuousVariable) else ContinuousVariable(name))
            metas.append(var);metas_data.append(col_data.to_numpy(dtype=float))
        elif col_type=="categorical":
            unique_vals=col_data.dropna().astype(str).unique()
            if len(unique_vals)==0:unique_vals=[""]
            var=DiscreteVariable(name,values=list(unique_vals));metas.append(var)
            value_map={val:idx for idx,val in enumerate(unique_vals)}
            metas_data.append(col_data.astype(str).map(value_map).fillna(0).to_numpy(dtype=float))
        else:
            var=(orig_var.copy(name=name) if orig_var and isinstance(orig_var,StringVariable) else StringVariable(name))
            metas.append(var);metas_data.append(col_data.astype(str).to_numpy())
    n=len(df);X=np.empty((n,0))
    M=np.column_stack(metas_data) if metas_data else np.empty((n,0),dtype=object)
    return Table.from_numpy(Domain([],[],metas),X,Y=None,metas=M)

def build_preview_payload(df:pd.DataFrame,columns_info:list,deleted_columns:list,preview_rows:int=100)->str:
    n=min(preview_rows,len(df));data_rows=[]
    for i in range(n):
        row_data={}
        for col_info in columns_info:
            field=col_info["field"]
            if field in df.columns:
                val=df.iloc[i][field]
                if pd.isna(val):row_data[field]=""
                elif isinstance(val,(np.integer,np.floating)):row_data[field]=float(val)
                else:row_data[field]=str(val)
            elif col_info.get("isNew"):row_data[field]=col_info.get("defaultValue","")
        data_rows.append(row_data)
    return json.dumps({"columns":columns_info,"data":data_rows,"totalRows":len(df),"deletedColumns":deleted_columns})

# ── HEADER PROMOTER ────────────────────────────────────────────────────────────

def make_unique_headers(headers:list)->list:
    seen={};unique=[]
    for header in headers:
        name=str(header) if header else "Unnamed"
        if name not in seen:seen[name]=0;unique.append(name)
        else:seen[name]+=1;unique.append(f"{name}_{seen[name]}")
    return unique

def promote_row_to_header(df:pd.DataFrame,row_index:int,remove_above:bool)->pd.DataFrame:
    check_license()
    if row_index<0 or row_index>=len(df):raise IndexError(f"row_index {row_index} out of range for df of length {len(df)}")
    new_headers=make_unique_headers(df.iloc[row_index].astype(str).tolist())
    df_new=df.iloc[row_index+1:].copy() if remove_above else df.drop(df.index[row_index]).copy()
    df_new.columns=new_headers;df_new.reset_index(drop=True,inplace=True);return df_new

def df_to_orange_header_promoter(df:pd.DataFrame,original_variables:list,original_domain:Domain,input_data:Table)->Table:
    check_license()
    if len(df.columns)!=len(original_variables):return input_data
    new_attributes,new_class_vars,new_metas=[],[],[];X_data,Y_data,M_data=[],[],[]
    for new_col_name,original_var in zip(df.columns,original_variables):
        col_data=df[new_col_name]
        if isinstance(original_var,ContinuousVariable):
            new_var=ContinuousVariable(str(new_col_name))
            numeric=pd.to_numeric(col_data,errors="coerce").fillna(0).to_numpy(dtype=float)
            if original_var in original_domain.attributes:new_attributes.append(new_var);X_data.append(numeric)
            elif original_var in original_domain.class_vars:new_class_vars.append(new_var);Y_data.append(numeric)
            else:new_metas.append(new_var);M_data.append(numeric.astype(object))
        elif isinstance(original_var,DiscreteVariable):
            unique_values=col_data.dropna().astype(str).unique()
            values=sorted([str(v) for v in unique_values]) if len(unique_values)>0 else [""]
            new_var=DiscreteVariable(str(new_col_name),values=values);value_to_idx={v:i for i,v in enumerate(values)}
            indices=np.array([value_to_idx.get(str(val),np.nan) if pd.notna(val) else np.nan for val in col_data],dtype=float)
            if original_var in original_domain.attributes:new_attributes.append(new_var);X_data.append(indices)
            elif original_var in original_domain.class_vars:new_class_vars.append(new_var);Y_data.append(indices)
            else:new_metas.append(new_var);M_data.append(indices.astype(object))
        elif isinstance(original_var,StringVariable):
            new_var=StringVariable(str(new_col_name));new_metas.append(new_var);M_data.append(col_data.fillna("").astype(str).to_numpy())
        else:
            new_var=StringVariable(str(new_col_name));new_metas.append(new_var);M_data.append(col_data.fillna("").astype(str).to_numpy())
    n=len(df)
    X_matrix=np.column_stack(X_data) if X_data else np.empty((n,0))
    Y_matrix=np.column_stack(Y_data) if Y_data else (np.empty((n,0)) if new_class_vars else None)
    M_matrix=np.column_stack(M_data) if M_data else np.empty((n,0),dtype=object)
    return Table.from_numpy(Domain(attributes=new_attributes,class_vars=new_class_vars,metas=new_metas),X=X_matrix,Y=Y_matrix,metas=M_matrix)

# ── MULTI SHIFT COLUMNS ────────────────────────────────────────────────────────

def apply_column_shift(df:pd.DataFrame,selected_columns:list,direction:str,steps:int)->pd.DataFrame:
    check_license();result=df.copy()
    if not selected_columns:return result
    shift_amount=steps if direction=="down" else -steps
    for col in selected_columns:
        if col in result.columns:result[col]=result[col].shift(shift_amount,fill_value=None)
    return result

# ── REGEX EXTRACTOR ────────────────────────────────────────────────────────────

PATTERN_LIBRARY={"email":r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b","phone_us":r"\b\d{3}[-.]?\d{3}[-.]?\d{4}\b","phone_international":r"\+?\d{1,3}[-.\s]?\(?\d{1,4}\)?[-.\s]?\d{1,4}[-.\s]?\d{1,9}","url":r"https?://(?:www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_\+.~#?&/=]*)","date_mdy":r"\b\d{1,2}[-/]\d{1,2}[-/]\d{2,4}\b","date_ymd":r"\b\d{4}[-/]\d{1,2}[-/]\d{1,2}\b","ssn":r"\b\d{3}-\d{2}-\d{4}\b","credit_card":r"\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b","ip_address":r"\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b","numbers":r"\b\d+\.?\d*\b","currency":r"\$\s?\d+(?:,\d{3})*(?:\.\d{2})?","time":r"\b\d{1,2}:\d{2}(?::\d{2})?\s?(?:AM|PM|am|pm)?\b","hashtag":r"#\w+","mention":r"@\w+","zipcode":r"\b\d{5}(?:-\d{4})?\b"}

def _numeric_page_columns(df:pd.DataFrame)->None:
    for col in [c for c in df.columns if c.lower()=="page"]:
        df[col]=pd.to_numeric(df[col],errors="coerce").fillna(0)

def process_regex_pattern(df:pd.DataFrame,column:str,pattern:str,mode:str,literal:bool,new_col_name:str)->tuple:
    check_license()
    if column not in df.columns:return df,{"type":"result","status":"error","message":"Selected column not found"}
    if not pattern:
        out=df.copy();_numeric_page_columns(out)
        return out,{"type":"result","status":"empty","message":"Enter a pattern to begin extraction","all_columns":{c:out[c].astype(str).tolist() for c in out.columns},"column_data":out[column].astype(str).tolist(),"selected_column":column,"matches":[[] for _ in range(len(out))],"match_count":0}
    if literal:pattern=re.escape(pattern)
    try:re.compile(pattern)
    except re.error as exc:return df,{"type":"result","status":"error","message":f"Invalid regex: {exc}"}
    out=df.copy();col_data=out[column].astype(str);all_matches=[];total_match_count=0
    if mode=="smart_extract":
        for text in col_data:
            try:
                m=re.search(pattern,text)
                if m:row=[m.group(0)]+list(m.groups()) if m.groups() else [m.group(0)];all_matches.append(row);total_match_count+=1
                else:all_matches.append([])
            except Exception:all_matches.append([])
    elif mode=="precision_capture":
        for text in col_data:
            try:
                matches=re.findall(pattern,text)
                if matches:
                    if isinstance(matches[0],tuple):flat=[m for m in matches[0] if m];all_matches.append(flat if flat else []);total_match_count+=len(flat)
                    else:all_matches.append([matches[0]]);total_match_count+=1
                else:all_matches.append([])
            except Exception:all_matches.append([])
    elif mode=="greedy_collect":
        for text in col_data:
            try:found=[m.group(0) for m in re.finditer(pattern,text)];all_matches.append(found);total_match_count+=len(found)
            except Exception:all_matches.append([])
    if mode=="greedy_collect":
        max_len=max((len(m) for m in all_matches),default=0)
        for i in range(max_len):out[f"{new_col_name}_{i+1}"]=[m[i] if i<len(m) else "" for m in all_matches]
    else:
        max_groups=max((len(m) for m in all_matches),default=0)
        if max_groups>1:
            for i in range(max_groups):
                suffix="" if i==0 else f"_group{i}"
                out[f"{new_col_name}{suffix}"]=[m[i] if i<len(m) else "" for m in all_matches]
        else:out[new_col_name]=[m[0] if m else "" for m in all_matches]
    _numeric_page_columns(out)
    return out,{"type":"result","status":"success","all_columns":{c:out[c].astype(str).tolist() for c in out.columns},"column_data":col_data.tolist(),"selected_column":column,"matches":all_matches,"match_count":total_match_count,"new_column_name":new_col_name,"mode":mode}

# ── HORIZONTAL STACK ───────────────────────────────────────────────────────────

def dataframe_to_orange_table_stacked(df:pd.DataFrame)->Table:
    check_license();df=df.copy();df.columns=make_unique_column_names(df.columns)
    attrs,metas,x_data,m_data=[],[],[],[]
    for col in df.columns:
        data=df[col]
        if pd.api.types.is_numeric_dtype(data):attrs.append(ContinuousVariable(col));x_data.append(data.to_numpy(dtype=float))
        elif pd.api.types.is_datetime64_any_dtype(data):metas.append(TimeVariable(col));m_data.append(data.astype("int64").to_numpy()/1e9)
        else:metas.append(StringVariable(col));m_data.append(data.astype(str).to_numpy())
    X=np.column_stack(x_data) if x_data else np.empty((len(df),0))
    M=np.column_stack(m_data) if m_data else np.empty((len(df),0))
    return Table.from_numpy(Domain(attrs,metas=metas),X,metas=M)

# ── Aliases (short names used by widgets) ─────────────────────────────────────
_o2d   = orange_to_df
_o2do  = orange_to_df_ordered
_o2dwc = orange_to_df_with_categoricals
_d2o   = df_to_orange_preserve_domain
_d2ob  = dataframe_to_orange_table_basic
_aaco  = apply_all_cleaning_operations
_bcj   = build_columns_json_for_filter
_bfm   = build_filter_mask
_gci   = get_columns_info
_icc   = is_compatible_configuration
_asc   = apply_saved_configuration
_acc   = apply_column_changes
_d2ocm = df_to_orange_columns_manager
_bpp   = build_preview_payload
_prth  = promote_row_to_header
_d2ohp = df_to_orange_header_promoter
_acs   = apply_column_shift
_prp   = process_regex_pattern
_PL    = PATTERN_LIBRARY
_d2os  = dataframe_to_orange_table_stacked
