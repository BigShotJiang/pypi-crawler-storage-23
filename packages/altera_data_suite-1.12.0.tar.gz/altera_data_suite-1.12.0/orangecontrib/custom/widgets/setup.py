import os
from setuptools import setup
from Cython.Build import cythonize

# Run this from inside orangecontrib\custom\widgets\
os.makedirs(".", exist_ok=True)

setup(
    ext_modules=cythonize(
        ["settings_business_logic.py", "auxiliary_functions.py"],
        compiler_directives={
            "language_level": "3",
            "embedsignature": False,
            "annotation_typing": False,
            "emit_code_comments": False,
        },
    )
)
