"""Import of tasks is directly from package by convention"""

from dkist_processing_ops.tasks.read_memory_leak import *
from dkist_processing_ops.tasks.smoke import *
from dkist_processing_ops.tasks.wait import *
