"""Property-based tests for verify_signature.

Feature: git-catcher, Property 1: Signature verification round-trip
**Validates: Requirements 2.1, 2.2**

Feature: git-catcher, Property 2: Reject invalid signatures
**Validates: Requirements 2.3**
"""
import hashlib
import hmac

from hypothesis import assume, given, settings
from hypothesis import strategies as st

from git_catcher.smee_client import verify_signature


# Strategy: arbitrary payload bytes and non-empty secret strings
payload_strategy = st.binary(min_size=0, max_size=1024)
secret_strategy = st.text(min_size=1, max_size=128).filter(lambda s: len(s.strip()) > 0)


@given(payload=payload_strategy, secret=secret_strategy)
@settings(max_examples=200)
def test_signature_roundtrip(payload: bytes, secret: str):
    """Property 1: A correctly generated signature must always pass verification.

    For any payload bytes and secret string,
    a signature generated with hmac.new(secret, payload, sha256).hexdigest()
    must always return True when passed to verify_signature.
    """
    # Arrange: generate a correct signature
    signature = "sha256=" + hmac.new(
        secret.encode(), payload, hashlib.sha256
    ).hexdigest()

    # Act & Assert
    assert verify_signature(payload, signature, secret) is True


@given(payload=payload_strategy, secret=secret_strategy, wrong_sig=st.text(
    alphabet=st.characters(codec="ascii", categories=("L", "N", "P", "S")),
    min_size=1, max_size=256,
))
@settings(max_examples=200)
def test_wrong_signature_rejected(payload: bytes, secret: str, wrong_sig: str):
    """Property 2: Reject invalid signatures

    # Feature: git-catcher, Property 2: Reject invalid signatures
    **Validates: Requirements 2.3**

    For any payload bytes, secret string, and an arbitrary string
    different from the correct signature, verify_signature must always return False.
    """
    # Arrange: compute the correct signature
    correct_signature = "sha256=" + hmac.new(
        secret.encode(), payload, hashlib.sha256
    ).hexdigest()

    # Skip if wrong_sig happens to equal the correct signature
    assume(wrong_sig != correct_signature)

    # Act & Assert
    assert verify_signature(payload, wrong_sig, secret) is False


# Feature: git-catcher, Property 3: Accept all events when secret is empty
# **Validates: Requirements 2.4**

# Strategy: arbitrary signature strings (including empty)
any_signature_strategy = st.text(
    alphabet=st.characters(codec="ascii"),
    min_size=0,
    max_size=256,
)


@given(payload=payload_strategy, signature=any_signature_strategy)
@settings(max_examples=200)
def test_empty_secret_accepts_all(payload: bytes, signature: str):
    """Property 3: Accept all events when secret is empty

    # Feature: git-catcher, Property 3: Accept all events when secret is empty
    **Validates: Requirements 2.4**

    For any payload bytes and arbitrary signature string,
    verify_signature must always return True when the secret is an empty string.
    """
    # Act & Assert: always True when secret is empty
    assert verify_signature(payload, signature, "") is True
