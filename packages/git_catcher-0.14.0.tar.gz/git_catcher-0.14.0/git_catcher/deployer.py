"""Git pull + deployment script execution (async)"""
import asyncio
import logging
from pathlib import Path

from .config import DeployConfig

async def check_behind(config: DeployConfig, branch: str) -> tuple[bool, str]:
    """Check whether the local branch is behind origin. Returns (is_behind, commit_message)."""
    repo = config.repo_path
    if not Path(repo).is_dir():
        return False, ""

    rc, _, _ = await run_command(["git", "fetch", "origin"], cwd=repo)
    if rc != 0:
        return False, ""

    _, local_hash, _ = await run_command(["git", "rev-parse", branch], cwd=repo)
    _, remote_hash, _ = await run_command(["git", "rev-parse", f"origin/{branch}"], cwd=repo)

    if local_hash.strip() == remote_hash.strip():
        return False, ""

    _, message, _ = await run_command(
        ["git", "log", "--format=%s", "-1", f"origin/{branch}"], cwd=repo
    )
    return True, message.strip()


logger = logging.getLogger(__name__)


async def run_command(cmd: list[str], cwd: str) -> tuple[int, str, str]:
    """Run a command asynchronously and return (returncode, stdout, stderr)."""
    proc = await asyncio.create_subprocess_exec(
        *cmd, cwd=cwd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=120)
    return proc.returncode, stdout.decode(), stderr.decode()


def should_deploy(branch: str, allowed_branches: list[str]) -> bool:
    """Return True if the branch is in the allowed list."""
    return branch in allowed_branches


async def git_pull(config: DeployConfig, branch: str) -> bool:
    """Run git pull. Returns True on success."""
    repo = config.repo_path
    if not Path(repo).is_dir():
        logger.error(f"Repository path does not exist: {repo}")
        return False

    # Execute safely in order: fetch → checkout → pull
    steps = [
        (["git", "fetch", "origin"], "fetch"),
        (["git", "checkout", branch], "checkout"),
        (["git", "pull", "origin", branch], "pull"),
    ]

    for cmd, label in steps:
        returncode, stdout, stderr = await run_command(cmd, cwd=repo)
        if returncode != 0:
            logger.error(f"git {label} failed: {stderr.strip()}")
            return False
        logger.info(f"git {label} succeeded: {stdout.strip()}")

    return True


async def run_post_pull(config: DeployConfig) -> bool:
    """Run the post-pull command. Skipped if not configured."""
    if not config.post_pull_command:
        logger.info("post_pull_command not set, skipping")
        return True

    logger.info(f"Running deploy command: {config.post_pull_command}")
    returncode, stdout, stderr = await run_command(
        ["sh", "-c", config.post_pull_command], cwd=config.repo_path
    )

    if returncode != 0:
        logger.error(f"Deploy command failed: {stderr.strip()}")
        return False

    logger.info(f"Deploy command succeeded: {stdout.strip()}")
    return True


async def deploy(config: DeployConfig, branch: str) -> bool:
    """Run git pull + deploy command. Returns True if everything succeeds."""
    if not await git_pull(config, branch):
        return False
    return await run_post_pull(config)
