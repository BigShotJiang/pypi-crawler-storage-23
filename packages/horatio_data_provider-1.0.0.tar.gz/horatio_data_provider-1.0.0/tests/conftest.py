import io

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import pytest


def make_parquet_bytes(df: pd.DataFrame) -> bytes:
    table = pa.Table.from_pandas(df)
    buf = io.BytesIO()
    pq.write_table(table, buf)
    return buf.getvalue()


@pytest.fixture
def sample_df():
    return pd.DataFrame({"amount": [1.0, 2.0], "token": ["USDT", "USDC"]})


@pytest.fixture
def parquet_bytes(sample_df):
    return make_parquet_bytes(sample_df)
