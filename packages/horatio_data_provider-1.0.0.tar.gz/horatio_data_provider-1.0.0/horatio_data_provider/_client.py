import httpx

from .erc20 import ERC20Namespace
from .binance import BinanceNamespace
from .protocols import (
    AaveNamespace,
    UniswapNamespace,
    LidoNamespace,
    StaderNamespace,
    ThresholdNamespace,
    NativeNamespace,
    CacheNamespace,
)


class DataProviderClient:
    def __init__(self, url: str):
        self._url = url.rstrip("/")
        self._session = httpx.AsyncClient(timeout=3600)
        self.erc20 = ERC20Namespace(self._session, self._url)
        self.binance = BinanceNamespace(self._session, self._url)
        self.aave = AaveNamespace(self._session, self._url)
        self.uniswap = UniswapNamespace(self._session, self._url)
        self.lido = LidoNamespace(self._session, self._url)
        self.stader = StaderNamespace(self._session, self._url)
        self.threshold = ThresholdNamespace(self._session, self._url)
        self.native = NativeNamespace(self._session, self._url)
        self.cache = CacheNamespace(self._session, self._url)

    async def health(self) -> bool:
        response = await self._session.get(self._url + "/health")
        response.raise_for_status()
        return True

    async def close(self) -> None:
        await self._session.aclose()

    async def __aenter__(self) -> "DataProviderClient":
        return self

    async def __aexit__(self, *_) -> None:
        await self.close()
