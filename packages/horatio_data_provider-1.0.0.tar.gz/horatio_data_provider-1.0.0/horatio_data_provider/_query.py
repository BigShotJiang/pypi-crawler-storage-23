import httpx
import pandas as pd

from ._http import fetch_parquet


class BaseQuery:
    def __init__(self, session: httpx.AsyncClient, base_url: str, body: dict):
        self._session = session
        self._base_url = base_url
        self._body = body

    def network(self, n: str) -> "BaseQuery":
        self._body["network"] = n
        return self

    def time_range(self, since: str, until: str) -> "BaseQuery":
        self._body["since"] = since
        self._body["until"] = until
        return self

    def involving(self, address: str) -> "BaseQuery":
        self._body["involving"] = address
        return self

    def involving_label(self, label: str) -> "BaseQuery":
        self._body["involving_label"] = label
        return self

    def involving_category(self, category: str) -> "BaseQuery":
        self._body["involving_category"] = category
        return self

    def with_value(self) -> "BaseQuery":
        self._body["with_value"] = True
        return self

    def verbose(self) -> "BaseQuery":
        self._body["verbose"] = True
        return self

    def aggregate(self, group_by: str = "time", period: str = "1h") -> "BaseQuery":
        self._body["aggregate"] = True
        self._body["group_by"] = group_by
        self._body["period"] = period
        return self


class CacheableQuery(BaseQuery):
    def cache(self, cache_type: str = "append") -> "CacheableQuery":
        self._body["cache"] = True
        self._body["cache_type"] = cache_type
        return self


class EventQuery(CacheableQuery):
    def __init__(self, session: httpx.AsyncClient, base_url: str, path: str, body: dict):
        super().__init__(session, base_url, body)
        self._path = path

    async def fetch(self) -> pd.DataFrame:
        path = self._path
        if self._body.get("aggregate"):
            path = path.rsplit("/read", 1)[0] + "/aggregate"
        return await fetch_parquet(self._session, self._base_url + path, self._body)
