"""Hush test suite."""
