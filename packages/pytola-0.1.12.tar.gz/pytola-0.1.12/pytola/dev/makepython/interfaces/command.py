"""Command interface definition for MakePython."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING, Any, Protocol

from pytola._logger import logger

if TYPE_CHECKING:
    from ..core.context import ExecutionContext


class CommandType(Enum):
    """Enumeration of command types."""

    BUILD = "build"
    CLEAN = "clean"
    TEST = "test"
    PUBLISH = "publish"
    BUMP_VERSION = "bumpversion"
    TOKEN = "token"
    UTIL = "util"


@dataclass
class CommandResult:
    """Result of command execution."""

    success: bool
    message: str = ""
    data: dict[str, Any] | None = None
    exit_code: int = 0


class Command(Protocol):
    """Interface for all MakePython commands."""

    name: str
    alias: str
    description: str
    command_type: CommandType

    def execute(self, context: ExecutionContext) -> CommandResult:
        """Execute the command with given context.

        Args:
            context: Execution context containing config, logger, etc.

        Returns
        -------
            CommandResult with execution status and details
        """
        ...


class ValidatableCommand(ABC):
    """Abstract base class for commands that need validation."""

    def __init__(self):
        """Initialize the command with a logger."""
        self.logger = logger

    @abstractmethod
    def validate(self, context: ExecutionContext) -> bool:
        """Validate command inputs and prerequisites.

        Args:
            context: Execution context

        Returns
        -------
            True if validation passes, False otherwise
        """
        ...

    @abstractmethod
    def execute(self, context: ExecutionContext) -> CommandResult:
        """Execute the command with validation."""
        ...
