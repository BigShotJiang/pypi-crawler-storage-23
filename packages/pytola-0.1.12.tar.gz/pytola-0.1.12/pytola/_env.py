import os
from abc import ABC, abstractmethod
from pathlib import Path

from ._logger import logger

__all__ = [
    "setup_pyside_env",
]


class BaseEnv(ABC):
    """Base environment class for all environments."""

    @classmethod
    @abstractmethod
    def setup(cls):
        """Set up the environment."""


class PysideEnv(BaseEnv):
    """PySide environment class for creating GUI applications."""

    @classmethod
    def setup(cls):
        """Set up the PySide environment."""
        try:
            import PySide2

            pyside2_dir = Path(PySide2.__file__).parent
            plugins_path = pyside2_dir / "plugins"

            if plugins_path.exists():
                qt_plugins_path = str(plugins_path.absolute()).strip()
                os.environ["QT_QPA_PLATFORM_PLUGIN_PATH"] = qt_plugins_path
                os.environ["QT_PLUGIN_PATH"] = qt_plugins_path
        except ImportError:
            pass
        else:
            logger.info(f"PySide2 plugins path: {qt_plugins_path}")


setup_pyside_env = PysideEnv.setup
