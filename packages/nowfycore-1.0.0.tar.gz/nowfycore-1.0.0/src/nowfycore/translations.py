def get_nowfy_translations():
    """Compatibility hook expected by nowfy.plugin.

    Returns an external translation map when available. During migration we keep
    this empty so nowfy.plugin can still bootstrap its own defaults safely.
    """
    return {}
