"""Gasoline MCP package metadata.

Purpose: Expose package-level metadata for the PyPI wrapper runtime.
Why: Keeps version identity centralized for diagnostics and packaging checks.
Docs: docs/features/feature/enhanced-cli-config/index.md
"""

__version__ = "0.7.8"
