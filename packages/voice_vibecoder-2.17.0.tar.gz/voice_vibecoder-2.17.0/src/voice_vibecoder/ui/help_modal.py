"""Help modal showing keyboard shortcuts and voice command guide."""

from textual.binding import Binding
from textual.containers import Vertical, VerticalScroll
from textual.screen import ModalScreen
from textual.widgets import Static, Button


class HelpModal(ModalScreen[None]):
    """Modal overlay with keyboard shortcuts and usage guide."""

    BINDINGS = [
        Binding("escape", "dismiss_help", "Close", priority=True),
        Binding("h", "dismiss_help", "Close", priority=True),
        Binding("q", "dismiss_help", "Close", priority=True),
    ]

    CSS = """
    HelpModal {
        align: center middle;
    }

    #help-dialog {
        width: 72;
        height: auto;
        max-height: 85%;
        border: thick $accent;
        background: $surface;
        padding: 1 2;
    }

    #help-title {
        text-align: center;
        text-style: bold;
        margin-bottom: 1;
    }

    #help-scroll {
        height: auto;
        max-height: 70vh;
    }

    .help-section {
        text-style: bold;
        color: $accent;
        margin-top: 1;
    }

    .help-body {
        margin-bottom: 1;
    }

    #help-close {
        margin-top: 1;
        align: center middle;
        width: 100%;
    }

    #help-close Button {
        min-width: 16;
    }
    """

    def compose(self):
        with Vertical(id="help-dialog"):
            yield Static("[bold cyan]Olaf The Vibecoder[/bold cyan] — Help", id="help-title")
            with VerticalScroll(id="help-scroll"):
                yield Static("How It Works", classes="help-section")
                yield Static(
                    "Olaf connects your voice to AI coding agents. You speak\n"
                    "naturally, and a voice AI (ChatGPT) interprets your intent\n"
                    "and delegates tasks to coding agents (Claude Code, Cursor)\n"
                    "that edit your code in real time.\n\n"
                    "Code tasks run on git branches with their own panels.\n"
                    "Non-code tasks (research, Jira, CI) run in named sessions.\n"
                    "Panels appear dynamically as tasks are created.",
                    classes="help-body",
                )

                yield Static("Keyboard Shortcuts", classes="help-section")
                yield Static(
                    "[bold]h[/bold]         Show this help screen\n"
                    "[bold]m[/bold]         Toggle microphone mute/unmute\n"
                    "[bold]c[/bold]         Cancel running agent (focused panel, or all)\n"
                    "[bold]s[/bold]         Open settings (provider, voice, agents)\n"
                    "[bold]space[/bold]     Push-to-talk (hold to record, release to send)\n"
                    "[bold]q[/bold] / [bold]esc[/bold]   Quit",
                    classes="help-body",
                )

                yield Static("Voice Tools", classes="help-section")
                yield Static(
                    "These are the tools Olaf can use when you speak to him.\n"
                    "You don't need to name them — just describe what you want.\n",
                    classes="help-body",
                )
                yield Static(
                    "[bold]send_to_agent[/bold]\n"
                    "  Send a coding task to an agent on a specific branch.\n"
                    '  "Add dark mode support on feat/theming"\n'
                    '  "Fix the null pointer bug on fix/crash-123"\n'
                    "  Code tasks always need a branch — Olaf will ask if you\n"
                    "  don't specify one. Branches are fuzzy-matched.\n",
                    classes="help-body",
                )
                yield Static(
                    "[bold]get_agent_status[/bold]\n"
                    "  Check what an agent is doing right now.\n"
                    '  "How\'s the login branch going?"\n'
                    '  "Is the agent done yet?"\n',
                    classes="help-body",
                )
                yield Static(
                    "[bold]show_diff[/bold]\n"
                    "  Show a GitHub-style diff of changes on a branch.\n"
                    '  "Show me the diff on feat/login"\n'
                    '  "What changed in config.ts?"\n',
                    classes="help-body",
                )
                yield Static(
                    "[bold]cancel_agent[/bold] / [bold]reset_agent[/bold]\n"
                    "  Stop the current task or start a fresh session.\n"
                    '  "Cancel the agent on feat/login"\n'
                    '  "Start fresh" / "Reset"\n',
                    classes="help-body",
                )
                yield Static(
                    "[bold]answer_agent_question[/bold]\n"
                    "  When an agent asks a question (panel shows [magenta]?[/magenta]),\n"
                    "  just answer by speaking. Olaf forwards your response.\n",
                    classes="help-body",
                )
                yield Static(
                    "[bold]list_branches[/bold]\n"
                    "  See all active instances and available git branches.\n"
                    '  "What branches are there?" / "List instances"\n',
                    classes="help-body",
                )
                yield Static(
                    "[bold]toggle_fullscreen[/bold] / [bold]show_output[/bold]\n"
                    "  Expand one panel to fill the screen, or go back.\n"
                    '  "Fullscreen the login branch"\n'
                    '  "Go back" / "Show output"\n',
                    classes="help-body",
                )
                yield Static(
                    "[bold]create_branch_instance[/bold] / [bold]remove_branch_instance[/bold]\n"
                    "  Manually add or remove a branch panel.\n"
                    "  Usually not needed — send_to_agent auto-creates panels.\n",
                    classes="help-body",
                )
                yield Static(
                    "[bold]delete_worktree[/bold]\n"
                    "  Delete a git worktree (and optionally the branch).\n"
                    '  "Delete the feat/old-experiment worktree"\n',
                    classes="help-body",
                )

                yield Static("Agent Panels", classes="help-section")
                yield Static(
                    "Each branch gets its own panel showing live agent output:\n"
                    "  [green]✎ [Edit][/green]  — file edits with inline diffs\n"
                    "  [cyan]$ [Bash][/cyan]  — shell commands\n"
                    "  [bold yellow]⚡ [Tool][/bold yellow] — other tool calls (grep, glob, etc.)\n\n"
                    "Panel headers show status:\n"
                    "  [dim]○[/dim] idle  [yellow]⏳[/yellow] running  "
                    "[magenta]❓[/magenta] waiting for input  [red]✗[/red] error",
                    classes="help-body",
                )

                yield Static("Tips", classes="help-section")
                yield Static(
                    "• Be specific about which branch to work on\n"
                    "• Use sessions for non-code tasks (research, Jira, CI)\n"
                    "• Say \"show diff\" to see what changed on a branch\n"
                    "• Say \"go back\" or \"show output\" to return to normal view\n"
                    "• Press [bold]c[/bold] with a panel focused to cancel just that agent",
                    classes="help-body",
                )

            with Static(id="help-close"):
                yield Button("Close (h / esc)", id="btn-close-help", variant="primary")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        self.dismiss(None)

    def action_dismiss_help(self) -> None:
        self.dismiss(None)
