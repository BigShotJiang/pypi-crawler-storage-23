"""File tree data gathering for worktree panels.

Builds a hierarchical file tree from a git worktree, showing all tracked files
with their status (modified, new, deleted, or unchanged). Folders containing
changes are automatically expanded. Provides periodic updates via a background
timer while an agent is running.
"""

import logging
import subprocess
import threading
from concurrent.futures import ThreadPoolExecutor
from pathlib import PurePosixPath

logger = logging.getLogger(__name__)

MAX_DEPTH = 10  # Maximum tree depth to prevent excessive nesting


def _git(args: list[str], cwd: str) -> subprocess.CompletedProcess:
    """Run a git command and return the CompletedProcess."""
    return subprocess.run(
        ["git", *args],
        cwd=cwd,
        capture_output=True,
        text=True,
        timeout=10,
    )


def _build_tree_node(path: str, status: str | None, is_folder: bool) -> dict:
    """Build a tree node (file or folder)."""
    parts = path.split("/")
    name = parts[-1]
    node = {
        "name": name,
        "path": path,
        "type": "folder" if is_folder else "file",
    }
    if status and not is_folder:
        node["status"] = status
    if is_folder:
        node["children"] = []
        node["expanded"] = False
    return node


def _insert_into_tree(tree: dict, path: str, status: str) -> None:
    """Insert a file path into the tree structure."""
    parts = path.split("/")
    current = tree

    # Navigate/create folder structure
    for i, part in enumerate(parts[:-1]):
        folder_path = "/".join(parts[:i+1])

        # Find or create folder node
        folder_node = None
        for child in current["children"]:
            if child["name"] == part and child["type"] == "folder":
                folder_node = child
                break

        if not folder_node:
            folder_node = _build_tree_node(folder_path, None, True)
            current["children"].append(folder_node)

        current = folder_node

    # Add the file (check for duplicates)
    file_name = parts[-1]
    existing = any(child["name"] == file_name for child in current["children"])
    if not existing:
        file_node = _build_tree_node(path, status, False)
        current["children"].append(file_node)


def _mark_expanded_folders(node: dict, changed_paths: set[str]) -> bool:
    """Mark folders as expanded if they contain changed files. Returns True if contains changes."""
    if node["type"] == "file":
        return node["path"] in changed_paths

    contains_changes = False
    for child in node["children"]:
        if _mark_expanded_folders(child, changed_paths):
            contains_changes = True

    if contains_changes:
        node["expanded"] = True

    return contains_changes


def _sort_tree(node: dict) -> None:
    """Sort tree nodes: folders first, then files, alphabetically within each group."""
    if node["type"] == "folder" and "children" in node:
        # Sort children: folders first, then files
        node["children"].sort(key=lambda n: (n["type"] == "file", n["name"].lower()))
        # Recursively sort children
        for child in node["children"]:
            _sort_tree(child)


def get_file_tree(worktree_path: str) -> dict:
    """Get hierarchical file tree with status for a worktree.

    Shows all tracked files in a tree structure with their status (modified, new,
    deleted, unchanged). Folders containing changes are automatically expanded.

    Returns:
        {"root": "branch-name", "tree": {...},
         "summary": {"modified": N, "new": N, "deleted": N, "unchanged": N}}
    """
    try:
        # Run independent git commands in parallel, then diff after merge-base
        with ThreadPoolExecutor(max_workers=4) as pool:
            branch_fut = pool.submit(_git, ["rev-parse", "--abbrev-ref", "HEAD"], worktree_path)
            base_fut = pool.submit(_git, ["merge-base", "main", "HEAD"], worktree_path)
            untracked_fut = pool.submit(_git, ["ls-files", "--others", "--exclude-standard"], worktree_path)
            all_files_fut = pool.submit(_git, ["ls-files"], worktree_path)

            # Wait for merge-base, then submit diff (overlaps with ls-files)
            base_result = base_fut.result()
            base = base_result.stdout.strip() if base_result.returncode == 0 else "main"
            diff_fut = pool.submit(_git, ["diff", "--name-status", base], worktree_path)

            # Collect remaining results
            branch_result = branch_fut.result()
            diff_result = diff_fut.result()
            untracked_result = untracked_fut.result()
            all_files_result = all_files_fut.result()

        root = branch_result.stdout.strip() if branch_result.returncode == 0 else "unknown"

        changed: dict[str, str] = {}  # path -> status
        if diff_result.returncode == 0:
            for line in diff_result.stdout.strip().splitlines():
                if not line.strip():
                    continue
                parts = line.split("\t", 1)
                if len(parts) == 2:
                    status_code = parts[0][0]
                    path = parts[1]
                    if status_code == "M":
                        changed[path] = "modified"
                    elif status_code == "A":
                        changed[path] = "new"
                    elif status_code == "D":
                        changed[path] = "deleted"
                    elif status_code in ("R", "C"):
                        changed[path] = "modified"

        if untracked_result.returncode == 0:
            for path in untracked_result.stdout.strip().splitlines():
                path = path.strip()
                if path and path not in changed:
                    changed[path] = "new"

        all_paths: dict[str, str] = {}  # path -> status
        if all_files_result.returncode == 0:
            for f in all_files_result.stdout.strip().splitlines():
                f = f.strip()
                if f:
                    all_paths[f] = changed.get(f, "unchanged")

        # Build tree structure
        tree = {
            "name": root,
            "path": "",
            "type": "folder",
            "children": [],
            "expanded": True,  # Root is always expanded
        }

        for path, status in sorted(all_paths.items()):
            _insert_into_tree(tree, path, status)

        # Mark folders as expanded if they contain changes
        changed_paths = set(changed.keys())
        _mark_expanded_folders(tree, changed_paths)

        # Sort tree
        _sort_tree(tree)

        # Summary counts
        summary = {"modified": 0, "new": 0, "deleted": 0, "unchanged": 0}
        for status in all_paths.values():
            if status in summary:
                summary[status] += 1

        # Flat entries list for the TUI sidebar
        entries = [{"path": p, "status": s} for p, s in sorted(all_paths.items())]

        return {"root": root, "tree": tree, "summary": summary, "entries": entries}

    except Exception as e:
        logger.warning("Failed to build file tree: %s", e)
        return {
            "root": "unknown",
            "tree": {"name": "unknown", "path": "", "type": "folder", "children": [], "expanded": True},
            "summary": {"modified": 0, "new": 0, "deleted": 0, "unchanged": 0},
            "entries": [],
        }


# -- Timer management for periodic updates --

_timers: dict[str, threading.Timer] = {}
_UPDATE_INTERVAL = 5.0  # seconds


def _fire_update(instance_id: str, worktree_path: str, registry) -> None:
    """Fire a single file tree update and schedule the next one."""
    try:
        tree_data = get_file_tree(worktree_path)
        if registry and registry.on_ui_command:
            registry.on_ui_command(instance_id, "file_tree", tree_data)
    except Exception as e:
        logger.debug("File tree update failed for %s: %s", instance_id, e)

    # Schedule next update (only if still registered)
    if instance_id in _timers:
        timer = threading.Timer(
            _UPDATE_INTERVAL,
            _fire_update,
            args=(instance_id, worktree_path, registry),
        )
        timer.daemon = True
        _timers[instance_id] = timer
        timer.start()


def start_file_tree_updates(instance_id: str, worktree_path: str, registry) -> None:
    """Start periodic file tree updates for an instance."""
    stop_file_tree_updates(instance_id)  # Clean up any existing timer

    # Fire immediately, then every _UPDATE_INTERVAL seconds
    timer = threading.Timer(
        0.1,  # near-immediate first update
        _fire_update,
        args=(instance_id, worktree_path, registry),
    )
    timer.daemon = True
    _timers[instance_id] = timer
    timer.start()


def stop_file_tree_updates(instance_id: str) -> None:
    """Stop the periodic timer for an instance."""
    timer = _timers.pop(instance_id, None)
    if timer:
        timer.cancel()
