---
name: nextcloud-dev-manual
description: Developer manual for Nextcloud server version 14.
source_url: https://docs.nextcloud.com/server/14/developer_manual/
categories: [Documentation, Knowledge Base, Reference]
tags: [docs, reference, nextcloud-dev-manual, knowledge-base]
---

# Nextcloud Dev Manual Documentation

Developer manual for Nextcloud server version 14.

**Original Source**: [https://docs.nextcloud.com/server/14/developer_manual/](https://docs.nextcloud.com/server/14/developer_manual/)

**Contains**: 71 markdown files with full folder structure.
*Last updated: February 27, 2026*

## 📚 Table of Contents

- [Android Library Index.Html](reference/android_library_index.html.md)
- [Api.Html](reference/api.html.md)
- [App Api.Html](reference/app_api.html.md)
- [App Appdata.Html](reference/app_appdata.html.md)
- [App Backgroundjobs.Html](reference/app_backgroundjobs.html.md)
- [App Changelog.Html](reference/app_changelog.html.md)
- [App Classloader.Html](reference/app_classloader.html.md)
- [App Code Signing.Html](reference/app_code_signing.html.md)
- [App Configuration.Html](reference/app_configuration.html.md)
- [App Container.Html](reference/app_container.html.md)
- [App Controllers.Html](reference/app_controllers.html.md)
- [App Css.Html](reference/app_css.html.md)
- [App Database.Html](reference/app_database.html.md)
- [App Filesystem.Html](reference/app_filesystem.html.md)
- [App Hooks.Html](reference/app_hooks.html.md)
- [App Index.Html](reference/app_index.html.md)
- [App Info.Html](reference/app_info.html.md)
- [App Init.Html](reference/app_init.html.md)
- [App Js.Html](reference/app_js.html.md)
- [App L10N.Html](reference/app_l10n.html.md)
- [App Logging.Html](reference/app_logging.html.md)
- [App Middleware.Html](reference/app_middleware.html.md)
- [App Migrations.Html](reference/app_migrations.html.md)
- [App Publishing.Html](reference/app_publishing.html.md)
- [App Repair.Html](reference/app_repair.html.md)
- [App Request.Html](reference/app_request.html.md)
- [App Routes.Html](reference/app_routes.html.md)
- [App Schema.Html](reference/app_schema.html.md)
- [App Settings.Html](reference/app_settings.html.md)
- [App Startapp.Html](reference/app_startapp.html.md)
- [App Templates.Html](reference/app_templates.html.md)
- [App Testing.Html](reference/app_testing.html.md)
- [App Theming.Html](reference/app_theming.html.md)
- [App Tutorial.Html](reference/app_tutorial.html.md)
- [App Two Factor Provider.Html](reference/app_two-factor-provider.html.md)
- [App Users.Html](reference/app_users.html.md)
- [Bugtracker Index.Html](reference/bugtracker_index.html.md)
- [Builds](reference/builds.md)
- [Client Apis Loginflow Index.Html](reference/client_apis_LoginFlow_index.html.md)
- [Client Apis Ocs Index.Html](reference/client_apis_OCS_index.html.md)
- [Client Apis Webdav Index.Html](reference/client_apis_WebDAV_index.html.md)
- [Client Apis Index.Html](reference/client_apis_index.html.md)
- [Commun Index.Html](reference/commun_index.html.md)
- [Core Externalapi.Html](reference/core_externalapi.html.md)
- [Core Index.Html](reference/core_index.html.md)
- [Core Ocs Share Api.Html](reference/core_ocs-share-api.html.md)
- [Core Theming.Html](reference/core_theming.html.md)
- [Core Translation.Html](reference/core_translation.html.md)
- [Core Unit Testing.Html](reference/core_unit-testing.html.md)
- [Design Content.Html](reference/design_content.html.md)
- [Design Css.Html](reference/design_css.html.md)
- [Design Html.Html](reference/design_html.html.md)
- [Design Icons.Html](reference/design_icons.html.md)
- [Design Index.Html](reference/design_index.html.md)
- [Design List.Html](reference/design_list.html.md)
- [Design Navigation.Html](reference/design_navigation.html.md)
- [Design Popovermenu.Html](reference/design_popovermenu.html.md)
- [General Backporting.Html](reference/general_backporting.html.md)
- [General Code Of Conduct.Html](reference/general_code-of-conduct.html.md)
- [General Codingguidelines.Html](reference/general_codingguidelines.html.md)
- [General Debugging.Html](reference/general_debugging.html.md)
- [General Devenv.Html](reference/general_devenv.html.md)
- [General Index.Html](reference/general_index.html.md)
- [General Performance.Html](reference/general_performance.html.md)
- [General Security.Html](reference/general_security.html.md)
- [Projects](reference/projects.md)
- [Server 14 Developer Manual](reference/server_14_developer_manual.md)
- [Nextcloud developer documentation[¶](https://docs.nextcloud.com/server/15/developer_manual/#nextcloud-developer-documentation "Permalink to this headline")](reference/server_15_developer_manual.md)
- [Nextcloud developer documentation[¶](https://docs.nextcloud.com/server/16/developer_manual/#nextcloud-developer-documentation "Permalink to this headline")](reference/server_16_developer_manual.md)
- [Nextcloud developer documentation[](https://docs.nextcloud.com/server/latest/developer_manual/#nextcloud-developer-documentation "Link to this heading")](reference/server_latest_developer_manual.md)
- [Nextcloud developer documentation[](https://docs.nextcloud.com/server/stable/developer_manual/#nextcloud-developer-documentation "Link to this heading")](reference/server_stable_developer_manual.md)

## 🤖 Agent Usage Guide

- When the user asks anything about **Nextcloud Dev Manual**, consult the reference files.
- Prefer exact quotes and direct links to the relevant file/section.
- The hierarchical TOC above makes navigation fast and intuitive.
- All images and assets are preserved so links work perfectly.
