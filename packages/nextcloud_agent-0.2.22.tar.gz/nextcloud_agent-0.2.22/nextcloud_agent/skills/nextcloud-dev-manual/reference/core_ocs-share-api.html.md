[ ![Logo](https://docs.nextcloud.com/server/14/developer_manual/_static/logo-white.png) ](https://docs.nextcloud.com/server/14/developer_manual/index.html)
  * [General contributor guidelines](https://docs.nextcloud.com/server/14/developer_manual/general/index.html)
  * [Changelog](https://docs.nextcloud.com/server/14/developer_manual/app/changelog.html)
  * [Tutorial](https://docs.nextcloud.com/server/14/developer_manual/app/tutorial.html)
  * [Create an app](https://docs.nextcloud.com/server/14/developer_manual/app/startapp.html)
  * [Navigation and pre-app configuration](https://docs.nextcloud.com/server/14/developer_manual/app/init.html)
  * [App metadata](https://docs.nextcloud.com/server/14/developer_manual/app/info.html)
  * [Classloader](https://docs.nextcloud.com/server/14/developer_manual/app/classloader.html)
  * [Request lifecycle](https://docs.nextcloud.com/server/14/developer_manual/app/request.html)
  * [Routing](https://docs.nextcloud.com/server/14/developer_manual/app/routes.html)
  * [Middleware](https://docs.nextcloud.com/server/14/developer_manual/app/middleware.html)
  * [Container](https://docs.nextcloud.com/server/14/developer_manual/app/container.html)
  * [Controllers](https://docs.nextcloud.com/server/14/developer_manual/app/controllers.html)
  * [RESTful API](https://docs.nextcloud.com/server/14/developer_manual/app/api.html)
  * [Templates](https://docs.nextcloud.com/server/14/developer_manual/app/templates.html)
  * [JavaScript](https://docs.nextcloud.com/server/14/developer_manual/app/js.html)
  * [CSS](https://docs.nextcloud.com/server/14/developer_manual/app/css.html)
  * [Translation](https://docs.nextcloud.com/server/14/developer_manual/app/l10n.html)
  * [Theming support](https://docs.nextcloud.com/server/14/developer_manual/app/theming.html)
  * [Database schema](https://docs.nextcloud.com/server/14/developer_manual/app/schema.html)
  * [Database access](https://docs.nextcloud.com/server/14/developer_manual/app/database.html)
  * [Configuration](https://docs.nextcloud.com/server/14/developer_manual/app/configuration.html)
  * [Filesystem](https://docs.nextcloud.com/server/14/developer_manual/app/filesystem.html)
  * [AppData](https://docs.nextcloud.com/server/14/developer_manual/app/appdata.html)
  * [User management](https://docs.nextcloud.com/server/14/developer_manual/app/users.html)
  * [Two-factor providers](https://docs.nextcloud.com/server/14/developer_manual/app/two-factor-provider.html)
  * [Hooks](https://docs.nextcloud.com/server/14/developer_manual/app/hooks.html)
  * [Background jobs (Cron)](https://docs.nextcloud.com/server/14/developer_manual/app/backgroundjobs.html)
  * [Settings](https://docs.nextcloud.com/server/14/developer_manual/app/settings.html)
  * [Logging](https://docs.nextcloud.com/server/14/developer_manual/app/logging.html)
  * [Migrations](https://docs.nextcloud.com/server/14/developer_manual/app/migrations.html)
  * [Repair steps](https://docs.nextcloud.com/server/14/developer_manual/app/repair.html)
  * [Testing](https://docs.nextcloud.com/server/14/developer_manual/app/testing.html)
  * [App store publishing](https://docs.nextcloud.com/server/14/developer_manual/app/publishing.html)
  * [Code signing](https://docs.nextcloud.com/server/14/developer_manual/app/code_signing.html)
  * [App development](https://docs.nextcloud.com/server/14/developer_manual/app/index.html)
  * [Design guidelines](https://docs.nextcloud.com/server/14/developer_manual/design/index.html)
  * [Android application development](https://docs.nextcloud.com/server/14/developer_manual/android_library/index.html)
  * [Client APIs](https://docs.nextcloud.com/server/14/developer_manual/client_apis/index.html)
  * [](https://docs.nextcloud.com/server/14/developer_manual/core/index.html)
    * [Translation](https://docs.nextcloud.com/server/14/developer_manual/core/translation.html)
    * [Unit-Testing](https://docs.nextcloud.com/server/14/developer_manual/core/unit-testing.html)
    * [Theming Nextcloud](https://docs.nextcloud.com/server/14/developer_manual/core/theming.html)
    * [External API](https://docs.nextcloud.com/server/14/developer_manual/core/externalapi.html)
    * [](https://docs.nextcloud.com/server/14/developer_manual/core/ocs-share-api.html)
      * [](https://docs.nextcloud.com/server/14/developer_manual/core/ocs-share-api.html#local-shares)
        * [Get all Shares](https://docs.nextcloud.com/server/14/developer_manual/core/ocs-share-api.html#get-all-shares)
        * [Get Shares from a specific file or folder](https://docs.nextcloud.com/server/14/developer_manual/core/ocs-share-api.html#get-shares-from-a-specific-file-or-folder)
        * [Get information about a known Share](https://docs.nextcloud.com/server/14/developer_manual/core/ocs-share-api.html#get-information-about-a-known-share)
        * [Create a new Share](https://docs.nextcloud.com/server/14/developer_manual/core/ocs-share-api.html#create-a-new-share)
        * [Delete Share](https://docs.nextcloud.com/server/14/developer_manual/core/ocs-share-api.html#delete-share)
        * [Update Share](https://docs.nextcloud.com/server/14/developer_manual/core/ocs-share-api.html#update-share)
      * [](https://docs.nextcloud.com/server/14/developer_manual/core/ocs-share-api.html#federated-cloud-shares)
        * [Create a new Federated Cloud Share](https://docs.nextcloud.com/server/14/developer_manual/core/ocs-share-api.html#create-a-new-federated-cloud-share)
        * [List accepted Federated Cloud Shares](https://docs.nextcloud.com/server/14/developer_manual/core/ocs-share-api.html#list-accepted-federated-cloud-shares)
        * [Get information about a known Federated Cloud Share](https://docs.nextcloud.com/server/14/developer_manual/core/ocs-share-api.html#get-information-about-a-known-federated-cloud-share)
        * [Delete an accepted Federated Cloud Share](https://docs.nextcloud.com/server/14/developer_manual/core/ocs-share-api.html#delete-an-accepted-federated-cloud-share)
        * [List pending Federated Cloud Shares](https://docs.nextcloud.com/server/14/developer_manual/core/ocs-share-api.html#list-pending-federated-cloud-shares)
        * [Accept a pending Federated Cloud Share](https://docs.nextcloud.com/server/14/developer_manual/core/ocs-share-api.html#accept-a-pending-federated-cloud-share)
        * [Decline a pending Federated Cloud Share](https://docs.nextcloud.com/server/14/developer_manual/core/ocs-share-api.html#decline-a-pending-federated-cloud-share)
  * [Bugtracker](https://docs.nextcloud.com/server/14/developer_manual/bugtracker/index.html)
  * [Help and communication](https://docs.nextcloud.com/server/14/developer_manual/commun/index.html)
  * [API Documentation](https://docs.nextcloud.com/server/14/developer_manual/api.html)


[Nextcloud 14 Developer Manual](https://docs.nextcloud.com/server/14/developer_manual/index.html)
  * [](https://docs.nextcloud.com/server/14/developer_manual/index.html) »
  * [Core development](https://docs.nextcloud.com/server/14/developer_manual/core/index.html) »
  * OCS Share API
  * [ Edit on GitHub](https://github.com/nextcloud/documentation/edit/stable14/developer_manual/core/ocs-share-api.rst)


* * *
# OCS Share API[¶](https://docs.nextcloud.com/server/14/developer_manual/core/ocs-share-api.html#ocs-share-api "Permalink to this headline")
The OCS Share API allows you to access the sharing API from outside over pre-defined OCS calls.
The base URL for all calls to the share API is: _< nextcloud_base_url>/ocs/v2.php/apps/files_sharing/api/v1_
All calls to OCS endpoints require the `OCS-APIRequest` header to be set to `true`.
## Local Shares[¶](https://docs.nextcloud.com/server/14/developer_manual/core/ocs-share-api.html#local-shares "Permalink to this headline")
### Get all Shares[¶](https://docs.nextcloud.com/server/14/developer_manual/core/ocs-share-api.html#get-all-shares "Permalink to this headline")
Get all shares from the user.
  * Syntax: /shares
  * Method: GET
  * Result: XML with all shares


Statuscodes:
  * 100 - successful
  * 404 - couldn’t fetch shares


### Get Shares from a specific file or folder[¶](https://docs.nextcloud.com/server/14/developer_manual/core/ocs-share-api.html#get-shares-from-a-specific-file-or-folder "Permalink to this headline")
Get all shares from a given file/folder.
  * Syntax: /shares
  * Method: GET
  * URL Arguments: path - (string) path to file/folder
  * URL Arguments: reshares - (boolean) returns not only the shares from the current user but all shares from the given file.
  * URL Arguments: subfiles - (boolean) returns all shares within a folder, given that _path_ defines a folder
  * Mandatory fields: path
  * Result: XML with the shares


Statuscodes:
  * 100 - successful
  * 400 - not a directory (if the ‘subfile’ argument was used)
  * 404 - file doesn’t exist


### Get information about a known Share[¶](https://docs.nextcloud.com/server/14/developer_manual/core/ocs-share-api.html#get-information-about-a-known-share "Permalink to this headline")
Get information about a given share.
  * Syntax: /shares/_< share_id>_
  * Method: GET
  * Arguments: share_id - (int) share ID
  * Result: XML with the share information


Statuscodes:
  * 100 - successful
  * 404 - share doesn’t exist


### Create a new Share[¶](https://docs.nextcloud.com/server/14/developer_manual/core/ocs-share-api.html#create-a-new-share "Permalink to this headline")
Share a file/folder with a user/group or as public link.
  * Syntax: /shares
  * Method: POST
  * POST Arguments: path - (string) path to the file/folder which should be shared
  * POST Arguments: shareType - (int) 0 = user; 1 = group; 3 = public link; 6 = federated cloud share
  * POST Arguments: shareWith - (string) user / group id with which the file should be shared
  * POST Arguments: publicUpload - (string) allow public upload to a public shared folder (true/false)
  * POST Arguments: password - (string) password to protect public link Share with
  * POST Arguments: permissions - (int) 1 = read; 2 = update; 4 = create; 8 = delete; 16 = share; 31 = all (default: 31, for public shares: 1)
  * Mandatory fields: shareType, path and shareWith for shareType 0 or 1.
  * Result: XML containing the share ID (int) of the newly created share


Statuscodes:
  * 100 - successful
  * 400 - unknown share type
  * 403 - public upload was disabled by the admin
  * 404 - file couldn’t be shared


### Delete Share[¶](https://docs.nextcloud.com/server/14/developer_manual/core/ocs-share-api.html#delete-share "Permalink to this headline")
Remove the given share.
  * Syntax: /shares/_< share_id>_
  * Method: DELETE
  * Arguments: share_id - (int) share ID


Statuscodes:
  * 100 - successful
  * 404 - file couldn’t be deleted


### Update Share[¶](https://docs.nextcloud.com/server/14/developer_manual/core/ocs-share-api.html#update-share "Permalink to this headline")
Update a given share. Only one value can be updated per request.
  * Syntax: /shares/_< share_id>_
  * Method: PUT
  * Arguments: share_id - (int) share ID
  * PUT Arguments: permissions - (int) update permissions (see “Create share” above)
  * PUT Arguments: password - (string) updated password for public link Share
  * PUT Arguments: publicUpload - (string) enable (true) /disable (false) public upload for public shares.
  * PUT Arguments: expireDate - (string) set a expire date for public link shares. This argument expects a well formatted date string, e.g. ‘YYYY-MM-DD’
  * PUT Arguments: note - (string) Adds a note for the share recipient.


Note
Only one of the update parameters can be specified at once.
Statuscodes:
  * 100 - successful
  * 400 - wrong or no update parameter given
  * 403 - public upload disabled by the admin
  * 404 - couldn’t update share


## Federated Cloud Shares[¶](https://docs.nextcloud.com/server/14/developer_manual/core/ocs-share-api.html#federated-cloud-shares "Permalink to this headline")
Both the sending and the receiving instance need to have federated cloud sharing enabled and configured. See [Configuring Federated Cloud Sharing](https://docs.nextcloud.org/server/14/admin_manual/configuration_files/federated_cloud_sharing_configuration.html).
### Create a new Federated Cloud Share[¶](https://docs.nextcloud.com/server/14/developer_manual/core/ocs-share-api.html#create-a-new-federated-cloud-share "Permalink to this headline")
Creating a federated cloud share can be done via the local share endpoint, using (int) 6 as a shareType and the [Federated Cloud ID](https://nextcloud.com/federation/) of the share recipient as shareWith. See [Create a new Share](https://docs.nextcloud.com/server/14/developer_manual/core/ocs-share-api.html#create-a-new-share) for more information.
### List accepted Federated Cloud Shares[¶](https://docs.nextcloud.com/server/14/developer_manual/core/ocs-share-api.html#list-accepted-federated-cloud-shares "Permalink to this headline")
Get all federated cloud shares the user has accepted.
  * Syntax: /remote_shares
  * Method: GET
  * Result: XML with all accepted federated cloud shares


Statuscodes:
  * 100 - successful


### Get information about a known Federated Cloud Share[¶](https://docs.nextcloud.com/server/14/developer_manual/core/ocs-share-api.html#get-information-about-a-known-federated-cloud-share "Permalink to this headline")
Get information about a given received federated cloud that was sent from a remote instance.
  * Syntax: /remote_shares/_< share_id>_
  * Method: GET
  * Arguments: share_id - (int) share ID as listed in the id field in the `remote_shares` list
  * Result: XML with the share information


Statuscodes:
  * 100 - successful
  * 404 - share doesn’t exist


### Delete an accepted Federated Cloud Share[¶](https://docs.nextcloud.com/server/14/developer_manual/core/ocs-share-api.html#delete-an-accepted-federated-cloud-share "Permalink to this headline")
Locally delete a received federated cloud share that was sent from a remote instance.
  * Syntax: /remote_shares/_< share_id>_
  * Method: DELETE
  * Arguments: share_id - (int) share ID as listed in the id field in the `remote_shares` list
  * Result: XML with the share information


Statuscodes:
  * 100 - successful
  * 404 - share doesn’t exist


### List pending Federated Cloud Shares[¶](https://docs.nextcloud.com/server/14/developer_manual/core/ocs-share-api.html#list-pending-federated-cloud-shares "Permalink to this headline")
Get all pending federated cloud shares the user has received.
  * Syntax: /remote_shares/pending
  * Method: GET
  * Result: XML with all pending federated cloud shares


Statuscodes:
  * 100 - successful


### Accept a pending Federated Cloud Share[¶](https://docs.nextcloud.com/server/14/developer_manual/core/ocs-share-api.html#accept-a-pending-federated-cloud-share "Permalink to this headline")
Locally accept a received federated cloud share that was sent from a remote instance.
  * Syntax: /remote_shares/pending/_< share_id>_
  * Method: POST
  * Arguments: share_id - (int) share ID as listed in the id field in the `remote_shares/pending` list
  * Result: XML with the share information


Statuscodes:
  * 100 - successful
  * 404 - share doesn’t exist


### Decline a pending Federated Cloud Share[¶](https://docs.nextcloud.com/server/14/developer_manual/core/ocs-share-api.html#decline-a-pending-federated-cloud-share "Permalink to this headline")
Locally decline a received federated cloud share that was sent from a remote instance.
  * Syntax: /remote_shares/pending/_< share_id>_
  * Method: DELETE
  * Arguments: share_id - (int) share ID as listed in the id field in the `remote_shares/pending` list
  * Result: XML with the share information


Statuscodes:
  * 100 - successful
  * 404 - share doesn’t exist


[Next ](https://docs.nextcloud.com/server/14/developer_manual/bugtracker/index.html "Bugtracker") [](https://docs.nextcloud.com/server/14/developer_manual/core/externalapi.html "External API")
* * *
© Copyright 2021 Nextcloud GmbH.
Read the Docs v: 14

Versions
    [14](https://docs.nextcloud.com/server/14/developer_manual)     [15](https://docs.nextcloud.com/server/15/developer_manual)     [16](https://docs.nextcloud.com/server/16/developer_manual)     [stable](https://docs.nextcloud.com/server/stable/developer_manual)     [latest](https://docs.nextcloud.com/server/latest/developer_manual)

Downloads


On Read the Docs
     [Project Home](https://docs.nextcloud.com/projects//?fromdocs=)      [Builds](https://docs.nextcloud.com/builds//?fromdocs=)
