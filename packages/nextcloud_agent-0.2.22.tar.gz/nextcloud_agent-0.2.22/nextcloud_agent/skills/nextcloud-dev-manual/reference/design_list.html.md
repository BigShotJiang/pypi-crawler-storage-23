[ ![Logo](https://docs.nextcloud.com/server/14/developer_manual/_static/logo-white.png) ](https://docs.nextcloud.com/server/14/developer_manual/index.html)
  * [General contributor guidelines](https://docs.nextcloud.com/server/14/developer_manual/general/index.html)
  * [Changelog](https://docs.nextcloud.com/server/14/developer_manual/app/changelog.html)
  * [Tutorial](https://docs.nextcloud.com/server/14/developer_manual/app/tutorial.html)
  * [Create an app](https://docs.nextcloud.com/server/14/developer_manual/app/startapp.html)
  * [Navigation and pre-app configuration](https://docs.nextcloud.com/server/14/developer_manual/app/init.html)
  * [App metadata](https://docs.nextcloud.com/server/14/developer_manual/app/info.html)
  * [Classloader](https://docs.nextcloud.com/server/14/developer_manual/app/classloader.html)
  * [Request lifecycle](https://docs.nextcloud.com/server/14/developer_manual/app/request.html)
  * [Routing](https://docs.nextcloud.com/server/14/developer_manual/app/routes.html)
  * [Middleware](https://docs.nextcloud.com/server/14/developer_manual/app/middleware.html)
  * [Container](https://docs.nextcloud.com/server/14/developer_manual/app/container.html)
  * [Controllers](https://docs.nextcloud.com/server/14/developer_manual/app/controllers.html)
  * [RESTful API](https://docs.nextcloud.com/server/14/developer_manual/app/api.html)
  * [Templates](https://docs.nextcloud.com/server/14/developer_manual/app/templates.html)
  * [JavaScript](https://docs.nextcloud.com/server/14/developer_manual/app/js.html)
  * [CSS](https://docs.nextcloud.com/server/14/developer_manual/app/css.html)
  * [Translation](https://docs.nextcloud.com/server/14/developer_manual/app/l10n.html)
  * [Theming support](https://docs.nextcloud.com/server/14/developer_manual/app/theming.html)
  * [Database schema](https://docs.nextcloud.com/server/14/developer_manual/app/schema.html)
  * [Database access](https://docs.nextcloud.com/server/14/developer_manual/app/database.html)
  * [Configuration](https://docs.nextcloud.com/server/14/developer_manual/app/configuration.html)
  * [Filesystem](https://docs.nextcloud.com/server/14/developer_manual/app/filesystem.html)
  * [AppData](https://docs.nextcloud.com/server/14/developer_manual/app/appdata.html)
  * [User management](https://docs.nextcloud.com/server/14/developer_manual/app/users.html)
  * [Two-factor providers](https://docs.nextcloud.com/server/14/developer_manual/app/two-factor-provider.html)
  * [Hooks](https://docs.nextcloud.com/server/14/developer_manual/app/hooks.html)
  * [Background jobs (Cron)](https://docs.nextcloud.com/server/14/developer_manual/app/backgroundjobs.html)
  * [Settings](https://docs.nextcloud.com/server/14/developer_manual/app/settings.html)
  * [Logging](https://docs.nextcloud.com/server/14/developer_manual/app/logging.html)
  * [Migrations](https://docs.nextcloud.com/server/14/developer_manual/app/migrations.html)
  * [Repair steps](https://docs.nextcloud.com/server/14/developer_manual/app/repair.html)
  * [Testing](https://docs.nextcloud.com/server/14/developer_manual/app/testing.html)
  * [App store publishing](https://docs.nextcloud.com/server/14/developer_manual/app/publishing.html)
  * [Code signing](https://docs.nextcloud.com/server/14/developer_manual/app/code_signing.html)
  * [App development](https://docs.nextcloud.com/server/14/developer_manual/app/index.html)
  * [](https://docs.nextcloud.com/server/14/developer_manual/design/index.html)
    * [Introduction](https://docs.nextcloud.com/server/14/developer_manual/design/navigation.html)
    * [New button](https://docs.nextcloud.com/server/14/developer_manual/design/navigation.html#new-button)
    * [App navigation menu](https://docs.nextcloud.com/server/14/developer_manual/design/navigation.html#app-navigation-menu)
    * [Settings](https://docs.nextcloud.com/server/14/developer_manual/design/navigation.html#settings)
    * [Main content](https://docs.nextcloud.com/server/14/developer_manual/design/content.html)
    * [](https://docs.nextcloud.com/server/14/developer_manual/design/list.html)
      * [Introduction](https://docs.nextcloud.com/server/14/developer_manual/design/list.html#introduction)
      * [Basic layout](https://docs.nextcloud.com/server/14/developer_manual/design/list.html#basic-layout)
      * [Rules and information](https://docs.nextcloud.com/server/14/developer_manual/design/list.html#rules-and-information)
      * [Popovermenu in item](https://docs.nextcloud.com/server/14/developer_manual/design/list.html#popovermenu-in-item)
    * [Popover menu](https://docs.nextcloud.com/server/14/developer_manual/design/popovermenu.html)
    * [HTML elements](https://docs.nextcloud.com/server/14/developer_manual/design/html.html)
    * [SCSS](https://docs.nextcloud.com/server/14/developer_manual/design/css.html)
    * [Icons](https://docs.nextcloud.com/server/14/developer_manual/design/icons.html)
  * [Android application development](https://docs.nextcloud.com/server/14/developer_manual/android_library/index.html)
  * [Client APIs](https://docs.nextcloud.com/server/14/developer_manual/client_apis/index.html)
  * [Core development](https://docs.nextcloud.com/server/14/developer_manual/core/index.html)
  * [Bugtracker](https://docs.nextcloud.com/server/14/developer_manual/bugtracker/index.html)
  * [Help and communication](https://docs.nextcloud.com/server/14/developer_manual/commun/index.html)
  * [API Documentation](https://docs.nextcloud.com/server/14/developer_manual/api.html)


[Nextcloud 14 Developer Manual](https://docs.nextcloud.com/server/14/developer_manual/index.html)
  * [](https://docs.nextcloud.com/server/14/developer_manual/index.html) »
  * [Design guidelines](https://docs.nextcloud.com/server/14/developer_manual/design/index.html) »
  * Content list
  * [ Edit on GitHub](https://github.com/nextcloud/documentation/edit/stable14/developer_manual/design/list.rst)


* * *
# Content list[¶](https://docs.nextcloud.com/server/14/developer_manual/design/list.html#content-list "Permalink to this headline")
## Introduction[¶](https://docs.nextcloud.com/server/14/developer_manual/design/list.html#introduction "Permalink to this headline")
On the main content, you may want to have a list of items displayed (like the contacts, or the mail app). We provide a standardized structure for this specific purpose.
## Basic layout[¶](https://docs.nextcloud.com/server/14/developer_manual/design/list.html#basic-layout "Permalink to this headline")
![Content list screenshot](https://docs.nextcloud.com/server/14/developer_manual/_images/list.png)
```
<div id="app-content-wrapper">
    <div class="app-content-list">
        <a href="#" class="app-content-list-item">
            <input type="checkbox" id="test1" class="app-content-list-item-checkbox checkbox" checked="checked"><label for="test1"></label>
            <div class="app-content-list-item-icon" style="background-color: rgb(231, 192, 116);">C</div>
            <div class="app-content-list-item-line-one">Contact 1</div>
            <div class="icon-delete"></div>
        </a>
        <a href="#" class="app-content-list-item">
            <div class="app-content-list-item-star icon-starred"></div>
            <div class="app-content-list-item-icon" style="background-color: rgb(151, 72, 96);">T</div>
            <div class="app-content-list-item-line-one">Favourited task #2</div>
            <div class="icon-more"></div>
        </a>
        <a href="#" class="app-content-list-item">
            <div class="app-content-list-item-icon" style="background-color: rgb(152, 59, 144);">T</div>
            <div class="app-content-list-item-line-one">Task #2</div>
            <div class="icon-more"></div>
        </a>
        <a href="#" class="app-content-list-item">
            <div class="app-content-list-item-icon" style="background-color: rgb(31, 192, 216);">M</div>
            <div class="app-content-list-item-line-one">Important mail is very important! Don't ignore me</div>
            <div class="app-content-list-item-line-two">Hello there, here is an important mail from your mom</div>
        </a>
        <a href="#" class="app-content-list-item">
            <div class="app-content-list-item-icon" style="background-color: rgb(41, 97, 156);">N</div>
            <div class="app-content-list-item-line-one">Important mail with a very long subject</div>
            <div class="app-content-list-item-line-two">Hello there, here is an important mail from your mom</div>
            <span class="app-content-list-item-details">8 hours ago</span>
            <div class="icon-delete"></div>
        </a>
        <a href="#" class="app-content-list-item">
            <div class="app-content-list-item-icon" style="background-color: rgb(141, 197, 156);">N</div>
            <div class="app-content-list-item-line-one">New contact</div>
            <div class="app-content-list-item-line-two">blabla@bla.com</div>
            <div class="icon-delete"></div>
        </a>
    </div>
    <div class="app-content-detail">
    </div>
</div>

```

## Rules and information[¶](https://docs.nextcloud.com/server/14/developer_manual/design/list.html#rules-and-information "Permalink to this headline")
  * You need to have the following structure for your global content:


```
<div id="app-content-wrapper">
    <div class="app-content-list">HERE YOUR CONTENT LIST</div>
    <div class="app-content-detail">HERE YOUR GLOBAL CONTENT</div>
</div>

```

  * The first code/screenshot example show all the combination allowed/available.
  * When displaying the checkbox, the star will automatically be hidden.
  * The checkboxes are hidden by default. They’re shown when checked or when hover/focus/active
  * If you want to show **all** the checkboxes, apply the `selection` class to the `app-content-list`.
  *

You can **NOT** have more than one button in an entry. You need to create a [popover menu](https://docs.nextcloud.com/server/14/developer_manual/design/popovermenu.html#popovermenu) if multiple options are needed.

    * In case of a popovermenu, see the [popover menu](https://docs.nextcloud.com/server/14/developer_manual/design/list.html#popovermenulist).
    * As always, the **JS** is still needed to toggle the `open` class on this menu
  * If you use the `app-content-list` standard, the `app-content-details` div will be hidden in mobile mode (full screen). You will need to add the `showdetails` class to the `app-content-list` to show the main content. On mobile view, the whole list/details section (depending on which is shown) will scroll the body.


## Popovermenu in item[¶](https://docs.nextcloud.com/server/14/developer_manual/design/list.html#popovermenu-in-item "Permalink to this headline")
If you need a menu inside an item, you need to wrap it with the `icon-more` `div` inside a `app-content-list-menu` div.
![Content list with menu](https://docs.nextcloud.com/server/14/developer_manual/_images/list-menu.png)
```
<div class="app-content-list-item-menu">
    <div class="icon-more"></div>
    <div class="popovermenu">
        <ul>
            <li>
                <a href="#" class="icon-details">
                    <span>Details</span>
                </a>
            </li>
            <li>
                <button class="icon-details">
                    <span>Details</span>
                </button>
            </li>
            <li>
                <button>
                    <span class="icon-details"></span>
                    <span>Details</span>
                </button>
            </li>
            <li>
                <a>
                    <span class="icon-details"></span>
                    <span>Details</span>
                </a>
            </li>
        </ul>
    </div>
</div>

```

[Next ](https://docs.nextcloud.com/server/14/developer_manual/design/popovermenu.html "Popover menu") [](https://docs.nextcloud.com/server/14/developer_manual/design/content.html "Main content")
* * *
© Copyright 2021 Nextcloud GmbH.
Read the Docs v: 14

Versions
    [14](https://docs.nextcloud.com/server/14/developer_manual)     [15](https://docs.nextcloud.com/server/15/developer_manual)     [16](https://docs.nextcloud.com/server/16/developer_manual)     [stable](https://docs.nextcloud.com/server/stable/developer_manual)     [latest](https://docs.nextcloud.com/server/latest/developer_manual)

Downloads


On Read the Docs
     [Project Home](https://docs.nextcloud.com/projects//?fromdocs=)      [Builds](https://docs.nextcloud.com/builds//?fromdocs=)
