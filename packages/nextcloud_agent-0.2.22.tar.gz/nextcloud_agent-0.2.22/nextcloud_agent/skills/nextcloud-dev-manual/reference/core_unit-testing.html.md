[ ![Logo](https://docs.nextcloud.com/server/14/developer_manual/_static/logo-white.png) ](https://docs.nextcloud.com/server/14/developer_manual/index.html)
  * [General contributor guidelines](https://docs.nextcloud.com/server/14/developer_manual/general/index.html)
  * [Changelog](https://docs.nextcloud.com/server/14/developer_manual/app/changelog.html)
  * [Tutorial](https://docs.nextcloud.com/server/14/developer_manual/app/tutorial.html)
  * [Create an app](https://docs.nextcloud.com/server/14/developer_manual/app/startapp.html)
  * [Navigation and pre-app configuration](https://docs.nextcloud.com/server/14/developer_manual/app/init.html)
  * [App metadata](https://docs.nextcloud.com/server/14/developer_manual/app/info.html)
  * [Classloader](https://docs.nextcloud.com/server/14/developer_manual/app/classloader.html)
  * [Request lifecycle](https://docs.nextcloud.com/server/14/developer_manual/app/request.html)
  * [Routing](https://docs.nextcloud.com/server/14/developer_manual/app/routes.html)
  * [Middleware](https://docs.nextcloud.com/server/14/developer_manual/app/middleware.html)
  * [Container](https://docs.nextcloud.com/server/14/developer_manual/app/container.html)
  * [Controllers](https://docs.nextcloud.com/server/14/developer_manual/app/controllers.html)
  * [RESTful API](https://docs.nextcloud.com/server/14/developer_manual/app/api.html)
  * [Templates](https://docs.nextcloud.com/server/14/developer_manual/app/templates.html)
  * [JavaScript](https://docs.nextcloud.com/server/14/developer_manual/app/js.html)
  * [CSS](https://docs.nextcloud.com/server/14/developer_manual/app/css.html)
  * [Translation](https://docs.nextcloud.com/server/14/developer_manual/app/l10n.html)
  * [Theming support](https://docs.nextcloud.com/server/14/developer_manual/app/theming.html)
  * [Database schema](https://docs.nextcloud.com/server/14/developer_manual/app/schema.html)
  * [Database access](https://docs.nextcloud.com/server/14/developer_manual/app/database.html)
  * [Configuration](https://docs.nextcloud.com/server/14/developer_manual/app/configuration.html)
  * [Filesystem](https://docs.nextcloud.com/server/14/developer_manual/app/filesystem.html)
  * [AppData](https://docs.nextcloud.com/server/14/developer_manual/app/appdata.html)
  * [User management](https://docs.nextcloud.com/server/14/developer_manual/app/users.html)
  * [Two-factor providers](https://docs.nextcloud.com/server/14/developer_manual/app/two-factor-provider.html)
  * [Hooks](https://docs.nextcloud.com/server/14/developer_manual/app/hooks.html)
  * [Background jobs (Cron)](https://docs.nextcloud.com/server/14/developer_manual/app/backgroundjobs.html)
  * [Settings](https://docs.nextcloud.com/server/14/developer_manual/app/settings.html)
  * [Logging](https://docs.nextcloud.com/server/14/developer_manual/app/logging.html)
  * [Migrations](https://docs.nextcloud.com/server/14/developer_manual/app/migrations.html)
  * [Repair steps](https://docs.nextcloud.com/server/14/developer_manual/app/repair.html)
  * [Testing](https://docs.nextcloud.com/server/14/developer_manual/app/testing.html)
  * [App store publishing](https://docs.nextcloud.com/server/14/developer_manual/app/publishing.html)
  * [Code signing](https://docs.nextcloud.com/server/14/developer_manual/app/code_signing.html)
  * [App development](https://docs.nextcloud.com/server/14/developer_manual/app/index.html)
  * [Design guidelines](https://docs.nextcloud.com/server/14/developer_manual/design/index.html)
  * [Android application development](https://docs.nextcloud.com/server/14/developer_manual/android_library/index.html)
  * [Client APIs](https://docs.nextcloud.com/server/14/developer_manual/client_apis/index.html)
  * [](https://docs.nextcloud.com/server/14/developer_manual/core/index.html)
    * [Translation](https://docs.nextcloud.com/server/14/developer_manual/core/translation.html)
    * [](https://docs.nextcloud.com/server/14/developer_manual/core/unit-testing.html)
      * [](https://docs.nextcloud.com/server/14/developer_manual/core/unit-testing.html#php-unit-testing)
        * [Getting PHPUnit](https://docs.nextcloud.com/server/14/developer_manual/core/unit-testing.html#getting-phpunit)
        * [Writing PHP unit tests](https://docs.nextcloud.com/server/14/developer_manual/core/unit-testing.html#writing-php-unit-tests)
        * [Bootstrapping Nextcloud](https://docs.nextcloud.com/server/14/developer_manual/core/unit-testing.html#bootstrapping-nextcloud)
        * [Running unit tests for the Nextcloud core project](https://docs.nextcloud.com/server/14/developer_manual/core/unit-testing.html#running-unit-tests-for-the-nextcloud-core-project)
        * [Further reading](https://docs.nextcloud.com/server/14/developer_manual/core/unit-testing.html#further-reading)
      * [](https://docs.nextcloud.com/server/14/developer_manual/core/unit-testing.html#javascript-unit-testing-for-core)
        * [Installing Node JS](https://docs.nextcloud.com/server/14/developer_manual/core/unit-testing.html#installing-node-js)
        * [Running all tests](https://docs.nextcloud.com/server/14/developer_manual/core/unit-testing.html#running-all-tests)
        * [Debugging tests in the browser](https://docs.nextcloud.com/server/14/developer_manual/core/unit-testing.html#debugging-tests-in-the-browser)
        * [Unit test paths](https://docs.nextcloud.com/server/14/developer_manual/core/unit-testing.html#unit-test-paths)
        * [Documentation](https://docs.nextcloud.com/server/14/developer_manual/core/unit-testing.html#documentation)
    * [Theming Nextcloud](https://docs.nextcloud.com/server/14/developer_manual/core/theming.html)
    * [External API](https://docs.nextcloud.com/server/14/developer_manual/core/externalapi.html)
    * [OCS Share API](https://docs.nextcloud.com/server/14/developer_manual/core/ocs-share-api.html)
  * [Bugtracker](https://docs.nextcloud.com/server/14/developer_manual/bugtracker/index.html)
  * [Help and communication](https://docs.nextcloud.com/server/14/developer_manual/commun/index.html)
  * [API Documentation](https://docs.nextcloud.com/server/14/developer_manual/api.html)


[Nextcloud 14 Developer Manual](https://docs.nextcloud.com/server/14/developer_manual/index.html)
  * [](https://docs.nextcloud.com/server/14/developer_manual/index.html) »
  * [Core development](https://docs.nextcloud.com/server/14/developer_manual/core/index.html) »
  * Unit-Testing
  * [ Edit on GitHub](https://github.com/nextcloud/documentation/edit/stable14/developer_manual/core/unit-testing.rst)


* * *
# Unit-Testing[¶](https://docs.nextcloud.com/server/14/developer_manual/core/unit-testing.html#unit-testing "Permalink to this headline")
## PHP unit testing[¶](https://docs.nextcloud.com/server/14/developer_manual/core/unit-testing.html#php-unit-testing "Permalink to this headline")
### Getting PHPUnit[¶](https://docs.nextcloud.com/server/14/developer_manual/core/unit-testing.html#getting-phpunit "Permalink to this headline")
Nextcloud uses PHPUnit >= 4.8 for unit testing.
To install it, either get it via your package manager:
```
sudo apt-get install phpunit

```

or install it manually:
```
wget https://phar.phpunit.de/phpunit.phar
chmod +x phpunit.phar
sudo mv phpunit.phar /usr/local/bin/phpunit

```

After the installation the **phpunit** command is available:
```
phpunit --version

```

And you can update it using:
```
phpunit --self-update

```

You can find more information in the PHPUnit documentation: <https://phpunit.de/manual/current/en/installation.html>
### Writing PHP unit tests[¶](https://docs.nextcloud.com/server/14/developer_manual/core/unit-testing.html#writing-php-unit-tests "Permalink to this headline")

To get started, do the following:

  * Create a directory called `tests` in the top level of your application
  * Create a PHP file in the directory and `require_once` your class which you want to test


Then you can simply run the created test with **phpunit**.
Note
If you use Nextcloud functions in your class under test (i.e., OC::getUser()) you’ll need to bootstrap Nextcloud or use dependency injection.
Note
You’ll most likely run your tests under a different user than the Web server. This might cause problems with your PHP settings (i.e., open_basedir) and requires you to adjust your configuration.
An example for a simple test would be:
`/srv/http/nextcloud/apps/myapp/tests/testaddtwo.php`
```
<?php
namespace OCA\Myapp\Tests;

class TestAddTwo extends \Test\TestCase {
    protected $testMe;

    protected function setUp() {
        parent::setUp();
        $this->testMe = new \OCA\Myapp\TestMe();
    }

    public function testAddTwo(){
          $this->assertEquals(5, $this->testMe->addTwo(3));
    }

}

```

`/srv/http/nextcloud/apps/myapp/lib/testme.php`
```
<?php
namespace OCA\Myapp;

class TestMe {
    public function addTwo($number){
        return $number + 2;
    }
}

```

In `/srv/http/nextcloud/apps/myapp/` you run the test with:
```
phpunit tests/testaddtwo.php

```

Make sure to extend the `\Test\TestCase` class with your test and always call the parent methods when overwriting `setUp()`, `setUpBeforeClass()`, `tearDown()` or `tearDownAfterClass()` method from the TestCase. These methods set up important stuff and clean up the system after the test, so the next test can run without side effects, like remaining files and entries in the file cache, etc.
For more resources on PHPUnit visit: <http://www.phpunit.de/manual/current/en/writing-tests-for-phpunit.html>
### Bootstrapping Nextcloud[¶](https://docs.nextcloud.com/server/14/developer_manual/core/unit-testing.html#bootstrapping-nextcloud "Permalink to this headline")
If you use Nextcloud functions or classes in your code, you’ll need to make them available to your test by bootstrapping Nextcloud.
To do this, you’ll need to provide the `--bootstrap` argument when running PHPUnit:
`/srv/http/nextcloud`:
```
phpunit --bootstrap tests/bootstrap.php apps/myapp/tests/testsuite.php

```

If you run the test under a different user than your Web server, you’ll have to adjust your php.ini and file rights.
`/etc/php/php.ini`:
```
open_basedir = none

```

`/srv/http/nextcloud`:
```
su -c "chmod a+r config/config.php"
su -c "chmod a+rx data/"
su -c "chmod a+w data/nextcloud.log"

```

### Running unit tests for the Nextcloud core project[¶](https://docs.nextcloud.com/server/14/developer_manual/core/unit-testing.html#running-unit-tests-for-the-nextcloud-core-project "Permalink to this headline")
The core project provides core unit tests using different database backends like sqlite, mysql, pgsql, oci (for Oracle). Every database to test needs to accesible either
  * natively, setup with
    * Host: localhost
    * Database: oc_autotest
    * User: oc_autotest
    * Password: owncloud
  * or via docker by setting the USEDOCKER environment variable.


Notes on how to setup databases for this test can be found in <https://github.com/nextcloud/server/blob/master/autotest.sh>.
To run tests for all database engines:
```
./autotest.sh

```

To run tests only for sqlite:
```
./autotest.sh sqlite

```

To run a specific test suite (note that the test file path is relative to the “tests” directory):
```
./autotest.sh sqlite lib/share/share.php

```

### Further reading[¶](https://docs.nextcloud.com/server/14/developer_manual/core/unit-testing.html#further-reading "Permalink to this headline")
  * <http://googletesting.blogspot.de/2008/08/by-miko-hevery-so-you-decided-to.html>
  * <http://www.phpunit.de/manual/current/en/writing-tests-for-phpunit.html>
  * [http://www.youtube.com/watch?v=4E4672CS58Q&feature=bf_prev&list=PLBDAB2BA83BB6588E](http://www.youtube.com/watch?v=4E4672CS58Q&feature=bf_prev&list=PLBDAB2BA83BB6588E)
  * Clean Code: A Handbook of Agile Software Craftsmanship (Robert C. Martin)


## JavaScript unit testing for core[¶](https://docs.nextcloud.com/server/14/developer_manual/core/unit-testing.html#javascript-unit-testing-for-core "Permalink to this headline")
JavaScript Unit testing for **core** and **core apps** is done using the [Karma](http://karma-runner.github.io) test runner with [Jasmine](https://jasmine.github.io/).
### Installing Node JS[¶](https://docs.nextcloud.com/server/14/developer_manual/core/unit-testing.html#installing-node-js "Permalink to this headline")
To run the JavaScript unit tests you will need to install **Node JS**.
You can get it here: <http://nodejs.org/>
After that you will need to setup the **Karma** test environment. The easiest way to do this is to run the automatic test script first, see next section.
### Running all tests[¶](https://docs.nextcloud.com/server/14/developer_manual/core/unit-testing.html#running-all-tests "Permalink to this headline")
To run all tests, just run:
```
./autotest-js.sh

```

This will also automatically set up your test environment.
### Debugging tests in the browser[¶](https://docs.nextcloud.com/server/14/developer_manual/core/unit-testing.html#debugging-tests-in-the-browser "Permalink to this headline")
To debug tests in the browser, you need to run **Karma** in browser mode:
```
karma start tests/karma.config.js

```

From there, open the URL <http://localhost:9876> in a web browser.
On that page, click on the “Debug” button.
An empty page will appear, from which you must open the browser console (F12 in Firefox/Chrome).
Every time you reload the page, the unit tests will be relaunched and will output the results in the browser console.
### Unit test paths[¶](https://docs.nextcloud.com/server/14/developer_manual/core/unit-testing.html#unit-test-paths "Permalink to this headline")
JavaScript unit test examples can be found in `apps/files/tests/js/`.
Unit tests for the core app JavaScript code can be found in `core/js/tests/specs`.
### Documentation[¶](https://docs.nextcloud.com/server/14/developer_manual/core/unit-testing.html#documentation "Permalink to this headline")
Here are some useful links about how to write unit tests with Jasmine and Sinon:
  * Karma test runner: <http://karma-runner.github.io>
  * Jasmine: <http://pivotal.github.io/jasmine>
  * Sinon (for mocking and stubbing): <http://sinonjs.org/>


[Next ](https://docs.nextcloud.com/server/14/developer_manual/core/theming.html "Theming Nextcloud") [](https://docs.nextcloud.com/server/14/developer_manual/core/translation.html "Translation")
* * *
© Copyright 2021 Nextcloud GmbH.
Read the Docs v: 14

Versions
    [14](https://docs.nextcloud.com/server/14/developer_manual)     [15](https://docs.nextcloud.com/server/15/developer_manual)     [16](https://docs.nextcloud.com/server/16/developer_manual)     [stable](https://docs.nextcloud.com/server/stable/developer_manual)     [latest](https://docs.nextcloud.com/server/latest/developer_manual)

Downloads


On Read the Docs
     [Project Home](https://docs.nextcloud.com/projects//?fromdocs=)      [Builds](https://docs.nextcloud.com/builds//?fromdocs=)
