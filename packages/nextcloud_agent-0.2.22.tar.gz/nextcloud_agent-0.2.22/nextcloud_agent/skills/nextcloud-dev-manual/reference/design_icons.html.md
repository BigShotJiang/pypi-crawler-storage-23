[ ![Logo](https://docs.nextcloud.com/server/14/developer_manual/_static/logo-white.png) ](https://docs.nextcloud.com/server/14/developer_manual/index.html)
  * [General contributor guidelines](https://docs.nextcloud.com/server/14/developer_manual/general/index.html)
  * [Changelog](https://docs.nextcloud.com/server/14/developer_manual/app/changelog.html)
  * [Tutorial](https://docs.nextcloud.com/server/14/developer_manual/app/tutorial.html)
  * [Create an app](https://docs.nextcloud.com/server/14/developer_manual/app/startapp.html)
  * [Navigation and pre-app configuration](https://docs.nextcloud.com/server/14/developer_manual/app/init.html)
  * [App metadata](https://docs.nextcloud.com/server/14/developer_manual/app/info.html)
  * [Classloader](https://docs.nextcloud.com/server/14/developer_manual/app/classloader.html)
  * [Request lifecycle](https://docs.nextcloud.com/server/14/developer_manual/app/request.html)
  * [Routing](https://docs.nextcloud.com/server/14/developer_manual/app/routes.html)
  * [Middleware](https://docs.nextcloud.com/server/14/developer_manual/app/middleware.html)
  * [Container](https://docs.nextcloud.com/server/14/developer_manual/app/container.html)
  * [Controllers](https://docs.nextcloud.com/server/14/developer_manual/app/controllers.html)
  * [RESTful API](https://docs.nextcloud.com/server/14/developer_manual/app/api.html)
  * [Templates](https://docs.nextcloud.com/server/14/developer_manual/app/templates.html)
  * [JavaScript](https://docs.nextcloud.com/server/14/developer_manual/app/js.html)
  * [CSS](https://docs.nextcloud.com/server/14/developer_manual/app/css.html)
  * [Translation](https://docs.nextcloud.com/server/14/developer_manual/app/l10n.html)
  * [Theming support](https://docs.nextcloud.com/server/14/developer_manual/app/theming.html)
  * [Database schema](https://docs.nextcloud.com/server/14/developer_manual/app/schema.html)
  * [Database access](https://docs.nextcloud.com/server/14/developer_manual/app/database.html)
  * [Configuration](https://docs.nextcloud.com/server/14/developer_manual/app/configuration.html)
  * [Filesystem](https://docs.nextcloud.com/server/14/developer_manual/app/filesystem.html)
  * [AppData](https://docs.nextcloud.com/server/14/developer_manual/app/appdata.html)
  * [User management](https://docs.nextcloud.com/server/14/developer_manual/app/users.html)
  * [Two-factor providers](https://docs.nextcloud.com/server/14/developer_manual/app/two-factor-provider.html)
  * [Hooks](https://docs.nextcloud.com/server/14/developer_manual/app/hooks.html)
  * [Background jobs (Cron)](https://docs.nextcloud.com/server/14/developer_manual/app/backgroundjobs.html)
  * [Settings](https://docs.nextcloud.com/server/14/developer_manual/app/settings.html)
  * [Logging](https://docs.nextcloud.com/server/14/developer_manual/app/logging.html)
  * [Migrations](https://docs.nextcloud.com/server/14/developer_manual/app/migrations.html)
  * [Repair steps](https://docs.nextcloud.com/server/14/developer_manual/app/repair.html)
  * [Testing](https://docs.nextcloud.com/server/14/developer_manual/app/testing.html)
  * [App store publishing](https://docs.nextcloud.com/server/14/developer_manual/app/publishing.html)
  * [Code signing](https://docs.nextcloud.com/server/14/developer_manual/app/code_signing.html)
  * [App development](https://docs.nextcloud.com/server/14/developer_manual/app/index.html)
  * [](https://docs.nextcloud.com/server/14/developer_manual/design/index.html)
    * [Introduction](https://docs.nextcloud.com/server/14/developer_manual/design/navigation.html)
    * [New button](https://docs.nextcloud.com/server/14/developer_manual/design/navigation.html#new-button)
    * [App navigation menu](https://docs.nextcloud.com/server/14/developer_manual/design/navigation.html#app-navigation-menu)
    * [Settings](https://docs.nextcloud.com/server/14/developer_manual/design/navigation.html#settings)
    * [Main content](https://docs.nextcloud.com/server/14/developer_manual/design/content.html)
    * [Content list](https://docs.nextcloud.com/server/14/developer_manual/design/list.html)
    * [Popover menu](https://docs.nextcloud.com/server/14/developer_manual/design/popovermenu.html)
    * [HTML elements](https://docs.nextcloud.com/server/14/developer_manual/design/html.html)
    * [SCSS](https://docs.nextcloud.com/server/14/developer_manual/design/css.html)
    * [](https://docs.nextcloud.com/server/14/developer_manual/design/icons.html)
      * [List of available icons](https://docs.nextcloud.com/server/14/developer_manual/design/icons.html#list-of-available-icons)
      * [Svg color api](https://docs.nextcloud.com/server/14/developer_manual/design/icons.html#svg-color-api)
  * [Android application development](https://docs.nextcloud.com/server/14/developer_manual/android_library/index.html)
  * [Client APIs](https://docs.nextcloud.com/server/14/developer_manual/client_apis/index.html)
  * [Core development](https://docs.nextcloud.com/server/14/developer_manual/core/index.html)
  * [Bugtracker](https://docs.nextcloud.com/server/14/developer_manual/bugtracker/index.html)
  * [Help and communication](https://docs.nextcloud.com/server/14/developer_manual/commun/index.html)
  * [API Documentation](https://docs.nextcloud.com/server/14/developer_manual/api.html)


[Nextcloud 14 Developer Manual](https://docs.nextcloud.com/server/14/developer_manual/index.html)
  * [](https://docs.nextcloud.com/server/14/developer_manual/index.html) »
  * [Design guidelines](https://docs.nextcloud.com/server/14/developer_manual/design/index.html) »
  * Icons
  * [ Edit on GitHub](https://github.com/nextcloud/documentation/edit/stable14/developer_manual/design/icons.rst)


* * *
# Icons[¶](https://docs.nextcloud.com/server/14/developer_manual/design/icons.html#icons "Permalink to this headline")
## List of available icons[¶](https://docs.nextcloud.com/server/14/developer_manual/design/icons.html#list-of-available-icons "Permalink to this headline")
White icons only have a grey background on this documentation page for readability purposes.
> [![../_images/add.png](https://docs.nextcloud.com/server/14/developer_manual/_images/add.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/add.png)
> icon-add
> [![../_images/add-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/add-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/add-white.png)
> icon-add-white
> [![../_images/address.png](https://docs.nextcloud.com/server/14/developer_manual/_images/address.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/address.png)
> icon-address
> [![../_images/address-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/address-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/address-white.png)
> icon-address-white
> [![../_images/audio.png](https://docs.nextcloud.com/server/14/developer_manual/_images/audio.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/audio.png)
> icon-audio
> [![../_images/audio-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/audio-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/audio-white.png)
> icon-audio-white
> [![../_images/audio-off.png](https://docs.nextcloud.com/server/14/developer_manual/_images/audio-off.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/audio-off.png)
> icon-audio-off
> [![../_images/audio-off-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/audio-off-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/audio-off-white.png)
> icon-audio-off-white
> [![../_images/caret-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/caret-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/caret-white.png)
> icon-caret-white
> [![../_images/caret.png](https://docs.nextcloud.com/server/14/developer_manual/_images/caret.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/caret.png)
> icon-caret-dark
> [![../_images/checkmark.png](https://docs.nextcloud.com/server/14/developer_manual/_images/checkmark.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/checkmark.png)
> icon-checkmark
> [![../_images/checkmark-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/checkmark-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/checkmark-white.png)
> icon-checkmark-white
> [![../_images/checkmark.png](https://docs.nextcloud.com/server/14/developer_manual/_images/checkmark.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/checkmark.png)
> icon-checkmark-color
> [![../_images/clippy.png](https://docs.nextcloud.com/server/14/developer_manual/_images/clippy.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/clippy.png)
> icon-clippy
> [![../_images/clippy-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/clippy-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/clippy-white.png)
> icon-clippy-white
> [![../_images/close.png](https://docs.nextcloud.com/server/14/developer_manual/_images/close.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/close.png)
> icon-close
> [![../_images/close-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/close-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/close-white.png)
> icon-close-white
> [![../_images/comment.png](https://docs.nextcloud.com/server/14/developer_manual/_images/comment.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/comment.png)
> icon-comment
> [![../_images/comment-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/comment-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/comment-white.png)
> icon-comment-white
> [![../_images/confirm.png](https://docs.nextcloud.com/server/14/developer_manual/_images/confirm.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/confirm.png)
> icon-confirm
> [![../_images/confirm-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/confirm-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/confirm-white.png)
> icon-confirm-white
> [![../_images/download.png](https://docs.nextcloud.com/server/14/developer_manual/_images/download.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/download.png)
> icon-download
> [![../_images/download-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/download-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/download-white.png)
> icon-download-white
> [![../_images/confirm-fade.png](https://docs.nextcloud.com/server/14/developer_manual/_images/confirm-fade.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/confirm-fade.png)
> icon-confirm-fade
> [![../_images/delete.png](https://docs.nextcloud.com/server/14/developer_manual/_images/delete.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/delete.png)
> icon-delete
> [![../_images/delete-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/delete-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/delete-white.png)
> icon-delete-white
> [![../_images/details.png](https://docs.nextcloud.com/server/14/developer_manual/_images/details.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/details.png)
> icon-details
> [![../_images/details-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/details-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/details-white.png)
> icon-details-white
> [![../_images/edit.png](https://docs.nextcloud.com/server/14/developer_manual/_images/edit.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/edit.png)
> icon-edit
> [![../_images/edit-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/edit-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/edit-white.png)
> icon-edit-white
> [![../_images/error.png](https://docs.nextcloud.com/server/14/developer_manual/_images/error.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/error.png)
> icon-error
> [![../_images/error-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/error-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/error-white.png)
> icon-error-white
> [![../_images/error.png](https://docs.nextcloud.com/server/14/developer_manual/_images/error.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/error.png)
> icon-error-color
> [![../_images/external.png](https://docs.nextcloud.com/server/14/developer_manual/_images/external.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/external.png)
> icon-external
> [![../_images/external-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/external-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/external-white.png)
> icon-external-white
> [![../_images/fullscreen.png](https://docs.nextcloud.com/server/14/developer_manual/_images/fullscreen.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/fullscreen.png)
> icon-fullscreen
> [![../_images/fullscreen-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/fullscreen-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/fullscreen-white.png)
> icon-fullscreen-white
> [![../_images/history.png](https://docs.nextcloud.com/server/14/developer_manual/_images/history.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/history.png)
> icon-history
> [![../_images/history-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/history-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/history-white.png)
> icon-history-white
> [![../_images/info.png](https://docs.nextcloud.com/server/14/developer_manual/_images/info.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/info.png)
> icon-info
> [![../_images/info-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/info-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/info-white.png)
> icon-info-white
> [![../_images/logout.png](https://docs.nextcloud.com/server/14/developer_manual/_images/logout.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/logout.png)
> icon-logout
> [![../_images/logout-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/logout-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/logout-white.png)
> icon-logout-white
> [![../_images/mail.png](https://docs.nextcloud.com/server/14/developer_manual/_images/mail.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/mail.png)
> icon-mail
> [![../_images/mail-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/mail-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/mail-white.png)
> icon-mail-white
> [![../_images/menu.png](https://docs.nextcloud.com/server/14/developer_manual/_images/menu.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/menu.png)
> icon-menu
> [![../_images/menu-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/menu-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/menu-white.png)
> icon-menu-white
> [![../_images/menu-sidebar.png](https://docs.nextcloud.com/server/14/developer_manual/_images/menu-sidebar.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/menu-sidebar.png)
> icon-menu-sidebar
> [![../_images/menu-sidebar-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/menu-sidebar-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/menu-sidebar-white.png)
> icon-menu-sidebar-white
> [![../_images/more.png](https://docs.nextcloud.com/server/14/developer_manual/_images/more.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/more.png)
> icon-more
> [![../_images/more-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/more-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/more-white.png)
> icon-more-white
> [![../_images/password.png](https://docs.nextcloud.com/server/14/developer_manual/_images/password.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/password.png)
> icon-password
> [![../_images/password-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/password-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/password-white.png)
> icon-password-white
> [![../_images/pause.png](https://docs.nextcloud.com/server/14/developer_manual/_images/pause.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/pause.png)
> icon-pause
> [![../_images/pause-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/pause-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/pause-white.png)
> icon-pause-white
> [![../_images/play.png](https://docs.nextcloud.com/server/14/developer_manual/_images/play.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/play.png)
> icon-play
> [![../_images/play-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/play-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/play-white.png)
> icon-play-white
> [![../_images/play-add.png](https://docs.nextcloud.com/server/14/developer_manual/_images/play-add.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/play-add.png)
> icon-play-add
> [![../_images/play-add-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/play-add-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/play-add-white.png)
> icon-play-add-white
> [![../_images/play-next.png](https://docs.nextcloud.com/server/14/developer_manual/_images/play-next.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/play-next.png)
> icon-play-next
> [![../_images/play-next-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/play-next-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/play-next-white.png)
> icon-play-next-white
> [![../_images/play-previous.png](https://docs.nextcloud.com/server/14/developer_manual/_images/play-previous.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/play-previous.png)
> icon-play-previous
> [![../_images/play-previous-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/play-previous-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/play-previous-white.png)
> icon-play-previous-white
> [![../_images/projects.png](https://docs.nextcloud.com/server/14/developer_manual/_images/projects.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/projects.png)
> icon-projects
> [![../_images/projects-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/projects-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/projects-white.png)
> icon-projects-white
> [![../_images/public.png](https://docs.nextcloud.com/server/14/developer_manual/_images/public.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/public.png)
> icon-public
> [![../_images/public-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/public-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/public-white.png)
> icon-public-white
> [![../_images/quota.png](https://docs.nextcloud.com/server/14/developer_manual/_images/quota.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/quota.png)
> icon-quota
> [![../_images/quota-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/quota-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/quota-white.png)
> icon-quota-white
> [![../_images/rename.png](https://docs.nextcloud.com/server/14/developer_manual/_images/rename.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/rename.png)
> icon-rename
> [![../_images/rename-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/rename-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/rename-white.png)
> icon-rename-white
> [![../_images/screen.png](https://docs.nextcloud.com/server/14/developer_manual/_images/screen.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/screen.png)
> icon-screen
> [![../_images/screen-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/screen-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/screen-white.png)
> icon-screen-white
> [![../_images/template-add.png](https://docs.nextcloud.com/server/14/developer_manual/_images/template-add.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/template-add.png)
> icon-template-add
> [![../_images/template-add-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/template-add-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/template-add-white.png)
> icon-template-add-white
> [![../_images/screen-off.png](https://docs.nextcloud.com/server/14/developer_manual/_images/screen-off.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/screen-off.png)
> icon-screen-off
> [![../_images/screen-off-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/screen-off-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/screen-off-white.png)
> icon-screen-off-white
> [![../_images/search.png](https://docs.nextcloud.com/server/14/developer_manual/_images/search.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/search.png)
> icon-search
> [![../_images/search-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/search-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/search-white.png)
> icon-search-white
> [![../_images/settings.png](https://docs.nextcloud.com/server/14/developer_manual/_images/settings.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/settings.png)
> icon-settings
> [![../_images/settings-dark.png](https://docs.nextcloud.com/server/14/developer_manual/_images/settings-dark.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/settings-dark.png)
> icon-settings-dark
> [![../_images/settings-dark-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/settings-dark-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/settings-dark-white.png)
> icon-settings-white
> [![../_images/share.png](https://docs.nextcloud.com/server/14/developer_manual/_images/share.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/share.png)
> icon-shared
> [![../_images/share-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/share-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/share-white.png)
> icon-shared-white
> [![../_images/sound.png](https://docs.nextcloud.com/server/14/developer_manual/_images/sound.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/sound.png)
> icon-sound
> [![../_images/sound-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/sound-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/sound-white.png)
> icon-sound-white
> [![../_images/sound-off.png](https://docs.nextcloud.com/server/14/developer_manual/_images/sound-off.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/sound-off.png)
> icon-sound-off
> [![../_images/sound-off-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/sound-off-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/sound-off-white.png)
> icon-sound-off-white
> [![../_images/star-dark.png](https://docs.nextcloud.com/server/14/developer_manual/_images/star-dark.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/star-dark.png)
> icon-favorite
> [![../_images/star-dark.png](https://docs.nextcloud.com/server/14/developer_manual/_images/star-dark.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/star-dark.png)
> icon-star
> [![../_images/star-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/star-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/star-white.png)
> icon-star-white
> [![../_images/star.png](https://docs.nextcloud.com/server/14/developer_manual/_images/star.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/star.png)
> icon-star-dark
> [![../_images/star.png](https://docs.nextcloud.com/server/14/developer_manual/_images/star.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/star.png)
> icon-starred
> [![../_images/tag.png](https://docs.nextcloud.com/server/14/developer_manual/_images/tag.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/tag.png)
> icon-tag
> [![../_images/tag-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/tag-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/tag-white.png)
> icon-tag-white
> [![../_images/timezone.png](https://docs.nextcloud.com/server/14/developer_manual/_images/timezone.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/timezone.png)
> icon-timezone
> [![../_images/timezone-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/timezone-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/timezone-white.png)
> icon-timezone-white
> [![../_images/toggle.png](https://docs.nextcloud.com/server/14/developer_manual/_images/toggle.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/toggle.png)
> icon-toggle
> [![../_images/toggle-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/toggle-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/toggle-white.png)
> icon-toggle-white
> [![../_images/toggle-background.png](https://docs.nextcloud.com/server/14/developer_manual/_images/toggle-background.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/toggle-background.png)
> icon-toggle-background
> [![../_images/toggle-background-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/toggle-background-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/toggle-background-white.png)
> icon-toggle-background-white
> [![../_images/toggle-pictures.png](https://docs.nextcloud.com/server/14/developer_manual/_images/toggle-pictures.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/toggle-pictures.png)
> icon-toggle-pictures
> [![../_images/toggle-pictures-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/toggle-pictures-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/toggle-pictures-white.png)
> icon-toggle-pictures-white
> [![../_images/toggle-filelist.png](https://docs.nextcloud.com/server/14/developer_manual/_images/toggle-filelist.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/toggle-filelist.png)
> icon-toggle-filelist
> [![../_images/toggle-filelist-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/toggle-filelist-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/toggle-filelist-white.png)
> icon-toggle-filelist-white
> [![../_images/triangle-e.png](https://docs.nextcloud.com/server/14/developer_manual/_images/triangle-e.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/triangle-e.png)
> icon-triangle-e
> [![../_images/triangle-e-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/triangle-e-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/triangle-e-white.png)
> icon-triangle-e-white
> [![../_images/triangle-n.png](https://docs.nextcloud.com/server/14/developer_manual/_images/triangle-n.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/triangle-n.png)
> icon-triangle-n
> [![../_images/triangle-n-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/triangle-n-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/triangle-n-white.png)
> icon-triangle-n-white
> [![../_images/triangle-s.png](https://docs.nextcloud.com/server/14/developer_manual/_images/triangle-s.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/triangle-s.png)
> icon-triangle-s
> [![../_images/triangle-s-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/triangle-s-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/triangle-s-white.png)
> icon-triangle-s-white
> [![../_images/upload.png](https://docs.nextcloud.com/server/14/developer_manual/_images/upload.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/upload.png)
> icon-upload
> [![../_images/upload-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/upload-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/upload-white.png)
> icon-upload-white
> [![../_images/user.png](https://docs.nextcloud.com/server/14/developer_manual/_images/user.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/user.png)
> icon-user
> [![../_images/user-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/user-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/user-white.png)
> icon-user-white
> [![../_images/group.png](https://docs.nextcloud.com/server/14/developer_manual/_images/group.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/group.png)
> icon-group
> [![../_images/group-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/group-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/group-white.png)
> icon-group-white
> [![../_images/filter.png](https://docs.nextcloud.com/server/14/developer_manual/_images/filter.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/filter.png)
> icon-filter
> [![../_images/filter-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/filter-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/filter-white.png)
> icon-filter-white
> [![../_images/video.png](https://docs.nextcloud.com/server/14/developer_manual/_images/video.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/video.png)
> icon-video
> [![../_images/video-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/video-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/video-white.png)
> icon-video-white
> [![../_images/video-off.png](https://docs.nextcloud.com/server/14/developer_manual/_images/video-off.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/video-off.png)
> icon-video-off
> [![../_images/video-off-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/video-off-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/video-off-white.png)
> icon-video-off-white
> [![../_images/video-switch.png](https://docs.nextcloud.com/server/14/developer_manual/_images/video-switch.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/video-switch.png)
> icon-video-switch
> [![../_images/video-switch-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/video-switch-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/video-switch-white.png)
> icon-video-switch-white
> [![../_images/view-close.png](https://docs.nextcloud.com/server/14/developer_manual/_images/view-close.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/view-close.png)
> icon-view-close
> [![../_images/view-download.png](https://docs.nextcloud.com/server/14/developer_manual/_images/view-download.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/view-download.png)
> icon-view-download
> [![../_images/view-pause.png](https://docs.nextcloud.com/server/14/developer_manual/_images/view-pause.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/view-pause.png)
> icon-view-pause
> [![../_images/view-play.png](https://docs.nextcloud.com/server/14/developer_manual/_images/view-play.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/view-play.png)
> icon-view-play
> [![../_images/arrow-right.png](https://docs.nextcloud.com/server/14/developer_manual/_images/arrow-right.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/arrow-right.png)
> icon-view-next
> [![../_images/arrow-left.png](https://docs.nextcloud.com/server/14/developer_manual/_images/arrow-left.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/arrow-left.png)
> icon-view-previous
> [![../_images/disabled-user.png](https://docs.nextcloud.com/server/14/developer_manual/_images/disabled-user.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/disabled-user.png)
> icon-disabled-user
> [![../_images/disabled-user-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/disabled-user-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/disabled-user-white.png)
> icon-disabled-user-white
> [![../_images/disabled-users.png](https://docs.nextcloud.com/server/14/developer_manual/_images/disabled-users.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/disabled-users.png)
> icon-disabled-users
> [![../_images/disabled-users-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/disabled-users-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/disabled-users-white.png)
> icon-disabled-users-white
> [![../_images/user-admin.png](https://docs.nextcloud.com/server/14/developer_manual/_images/user-admin.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/user-admin.png)
> icon-user-admin
> [![../_images/user-admin-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/user-admin-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/user-admin-white.png)
> icon-user-admin-white
> [![../_images/calendar.png](https://docs.nextcloud.com/server/14/developer_manual/_images/calendar.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/calendar.png)
> icon-calendar
> [![../_images/calendar.png](https://docs.nextcloud.com/server/14/developer_manual/_images/calendar.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/calendar.png)
> icon-calendar-dark
> [![../_images/contacts.png](https://docs.nextcloud.com/server/14/developer_manual/_images/contacts.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/contacts.png)
> icon-contacts
> [![../_images/contacts.png](https://docs.nextcloud.com/server/14/developer_manual/_images/contacts.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/contacts.png)
> icon-contacts-dark
> [![../_images/files.png](https://docs.nextcloud.com/server/14/developer_manual/_images/files.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/files.png)
> icon-files
> [![../_images/files.png](https://docs.nextcloud.com/server/14/developer_manual/_images/files.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/files.png)
> icon-files-dark
> [![../_images/text.png](https://docs.nextcloud.com/server/14/developer_manual/_images/text.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/text.png)
> icon-file
> [![../_images/file.png](https://docs.nextcloud.com/server/14/developer_manual/_images/file.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/file.png)
> icon-filetype-file
> [![../_images/folder.png](https://docs.nextcloud.com/server/14/developer_manual/_images/folder.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/folder.png)
> icon-folder
> [![../_images/folder-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/folder-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/folder-white.png)
> icon-folder-white
> [![../_images/folder.png](https://docs.nextcloud.com/server/14/developer_manual/_images/folder.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/folder.png)
> icon-filetype-folder
> [![../_images/folder-drag-accept.png](https://docs.nextcloud.com/server/14/developer_manual/_images/folder-drag-accept.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/folder-drag-accept.png)
> icon-filetype-folder-drag-accept
> [![../_images/home.png](https://docs.nextcloud.com/server/14/developer_manual/_images/home.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/home.png)
> icon-home
> [![../_images/home-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/home-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/home-white.png)
> icon-home-white
> [![../_images/link.png](https://docs.nextcloud.com/server/14/developer_manual/_images/link.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/link.png)
> icon-link
> [![../_images/link-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/link-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/link-white.png)
> icon-link-white
> [![../_images/music.png](https://docs.nextcloud.com/server/14/developer_manual/_images/music.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/music.png)
> icon-music
> [![../_images/music-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/music-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/music-white.png)
> icon-music-white
> [![../_images/picture.png](https://docs.nextcloud.com/server/14/developer_manual/_images/picture.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/picture.png)
> icon-picture
> [![../_images/picture-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/picture-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/picture-white.png)
> icon-picture-white
> [![../_images/desktop.png](https://docs.nextcloud.com/server/14/developer_manual/_images/desktop.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/desktop.png)
> icon-desktop
> [![../_images/desktop-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/desktop-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/desktop-white.png)
> icon-desktop-white
> [![../_images/phone.png](https://docs.nextcloud.com/server/14/developer_manual/_images/phone.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/phone.png)
> icon-phone
> [![../_images/phone-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/phone-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/phone-white.png)
> icon-phone-white
> [![../_images/tablet.png](https://docs.nextcloud.com/server/14/developer_manual/_images/tablet.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/tablet.png)
> icon-tablet
> [![../_images/tablet-white.png](https://docs.nextcloud.com/server/14/developer_manual/_images/tablet-white.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/tablet-white.png)
> icon-tablet-white
> [![../_images/user.png](https://docs.nextcloud.com/server/14/developer_manual/_images/user.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/user.png)
> icon-category-installed
> [![../_images/checkmark.png](https://docs.nextcloud.com/server/14/developer_manual/_images/checkmark.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/checkmark.png)
> icon-category-enabled
> [![../_images/close.png](https://docs.nextcloud.com/server/14/developer_manual/_images/close.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/close.png)
> icon-category-disabled
> [![../_images/bundles.png](https://docs.nextcloud.com/server/14/developer_manual/_images/bundles.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/bundles.png)
> icon-category-app-bundles
> [![../_images/download.png](https://docs.nextcloud.com/server/14/developer_manual/_images/download.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/download.png)
> icon-category-updates
> [![../_images/files1.png](https://docs.nextcloud.com/server/14/developer_manual/_images/files1.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/files1.png)
> icon-category-files
> [![../_images/social.png](https://docs.nextcloud.com/server/14/developer_manual/_images/social.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/social.png)
> icon-category-social
> [![../_images/office.png](https://docs.nextcloud.com/server/14/developer_manual/_images/office.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/office.png)
> icon-category-office
> [![../_images/auth.png](https://docs.nextcloud.com/server/14/developer_manual/_images/auth.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/auth.png)
> icon-category-auth
> [![../_images/monitoring.png](https://docs.nextcloud.com/server/14/developer_manual/_images/monitoring.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/monitoring.png)
> icon-category-monitoring
> [![../_images/multimedia.png](https://docs.nextcloud.com/server/14/developer_manual/_images/multimedia.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/multimedia.png)
> icon-category-multimedia
> [![../_images/organization.png](https://docs.nextcloud.com/server/14/developer_manual/_images/organization.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/organization.png)
> icon-category-organization
> [![../_images/customization.png](https://docs.nextcloud.com/server/14/developer_manual/_images/customization.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/customization.png)
> icon-category-customization
> [![../_images/integration.png](https://docs.nextcloud.com/server/14/developer_manual/_images/integration.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/integration.png)
> icon-category-integration
> [![../_images/settings-dark.png](https://docs.nextcloud.com/server/14/developer_manual/_images/settings-dark.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/settings-dark.png)
> icon-category-tools
> [![../_images/games.png](https://docs.nextcloud.com/server/14/developer_manual/_images/games.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/games.png)
> icon-category-games
> [![../_images/password.png](https://docs.nextcloud.com/server/14/developer_manual/_images/password.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/password.png)
> icon-category-security
> [![../_images/search.png](https://docs.nextcloud.com/server/14/developer_manual/_images/search.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/search.png)
> icon-category-search
> [![../_images/workflow.png](https://docs.nextcloud.com/server/14/developer_manual/_images/workflow.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/workflow.png)
> icon-category-workflow
> [![../_images/dashboard.png](https://docs.nextcloud.com/server/14/developer_manual/_images/dashboard.png)](https://docs.nextcloud.com/server/14/developer_manual/_images/dashboard.png)
> icon-category-dashboard
## Svg color api[¶](https://docs.nextcloud.com/server/14/developer_manual/design/icons.html#svg-color-api "Permalink to this headline")
More informations about scss and this api: [scss mixins and functions](https://docs.nextcloud.com/server/14/developer_manual/design/css.html#cssicons)
You can request and color any svg icons used in nextcloud with this api. The server will directly change the colours of the `circle`, `rect` and `path` elements in the svg you provide. Simply use those urls:
  * `https://yourdomain/svg/core/actions/menu/ffffff` Will serve the svg located in the core/img directory as a white icon `/core/img/actions/menu.svg`
  * `https://yourdomain/svg/core/places/calendar/0082c9` Will serve the svg located in the core/img directory with the color #0082c9 `/core/img/places/calendar.svg`
  * `https://yourdomain/svg/files/app/000000` Will serve the svg located in the files app `img` directory ad a black icon `/app/files/img/app.svg`


[Next ](https://docs.nextcloud.com/server/14/developer_manual/android_library/index.html "Android application development") [](https://docs.nextcloud.com/server/14/developer_manual/design/css.html "SCSS")
* * *
© Copyright 2021 Nextcloud GmbH.
Read the Docs v: 14

Versions
    [14](https://docs.nextcloud.com/server/14/developer_manual)     [15](https://docs.nextcloud.com/server/15/developer_manual)     [16](https://docs.nextcloud.com/server/16/developer_manual)     [stable](https://docs.nextcloud.com/server/stable/developer_manual)     [latest](https://docs.nextcloud.com/server/latest/developer_manual)

Downloads


On Read the Docs
     [Project Home](https://docs.nextcloud.com/projects//?fromdocs=)      [Builds](https://docs.nextcloud.com/builds//?fromdocs=)
