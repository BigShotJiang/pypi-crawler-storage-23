[ ![Logo](https://docs.nextcloud.com/server/14/developer_manual/_static/logo-white.png) ](https://docs.nextcloud.com/server/14/developer_manual/index.html)
  * [General contributor guidelines](https://docs.nextcloud.com/server/14/developer_manual/general/index.html)
  * [Changelog](https://docs.nextcloud.com/server/14/developer_manual/app/changelog.html)
  * [Tutorial](https://docs.nextcloud.com/server/14/developer_manual/app/tutorial.html)
  * [Create an app](https://docs.nextcloud.com/server/14/developer_manual/app/startapp.html)
  * [Navigation and pre-app configuration](https://docs.nextcloud.com/server/14/developer_manual/app/init.html)
  * [App metadata](https://docs.nextcloud.com/server/14/developer_manual/app/info.html)
  * [Classloader](https://docs.nextcloud.com/server/14/developer_manual/app/classloader.html)
  * [Request lifecycle](https://docs.nextcloud.com/server/14/developer_manual/app/request.html)
  * [Routing](https://docs.nextcloud.com/server/14/developer_manual/app/routes.html)
  * [Middleware](https://docs.nextcloud.com/server/14/developer_manual/app/middleware.html)
  * [Container](https://docs.nextcloud.com/server/14/developer_manual/app/container.html)
  * [Controllers](https://docs.nextcloud.com/server/14/developer_manual/app/controllers.html)
  * [RESTful API](https://docs.nextcloud.com/server/14/developer_manual/app/api.html)
  * [Templates](https://docs.nextcloud.com/server/14/developer_manual/app/templates.html)
  * [JavaScript](https://docs.nextcloud.com/server/14/developer_manual/app/js.html)
  * [CSS](https://docs.nextcloud.com/server/14/developer_manual/app/css.html)
  * [Translation](https://docs.nextcloud.com/server/14/developer_manual/app/l10n.html)
  * [Theming support](https://docs.nextcloud.com/server/14/developer_manual/app/theming.html)
  * [Database schema](https://docs.nextcloud.com/server/14/developer_manual/app/schema.html)
  * [Database access](https://docs.nextcloud.com/server/14/developer_manual/app/database.html)
  * [Configuration](https://docs.nextcloud.com/server/14/developer_manual/app/configuration.html)
  * [Filesystem](https://docs.nextcloud.com/server/14/developer_manual/app/filesystem.html)
  * [AppData](https://docs.nextcloud.com/server/14/developer_manual/app/appdata.html)
  * [User management](https://docs.nextcloud.com/server/14/developer_manual/app/users.html)
  * [Two-factor providers](https://docs.nextcloud.com/server/14/developer_manual/app/two-factor-provider.html)
  * [Hooks](https://docs.nextcloud.com/server/14/developer_manual/app/hooks.html)
  * [Background jobs (Cron)](https://docs.nextcloud.com/server/14/developer_manual/app/backgroundjobs.html)
  * [Settings](https://docs.nextcloud.com/server/14/developer_manual/app/settings.html)
  * [Logging](https://docs.nextcloud.com/server/14/developer_manual/app/logging.html)
  * [Migrations](https://docs.nextcloud.com/server/14/developer_manual/app/migrations.html)
  * [Repair steps](https://docs.nextcloud.com/server/14/developer_manual/app/repair.html)
  * [Testing](https://docs.nextcloud.com/server/14/developer_manual/app/testing.html)
  * [](https://docs.nextcloud.com/server/14/developer_manual/app/publishing.html)
    * [The Nextcloud app store](https://docs.nextcloud.com/server/14/developer_manual/app/publishing.html#the-nextcloud-app-store)
    * [](https://docs.nextcloud.com/server/14/developer_manual/app/publishing.html#getting-an-app-approved)
      * [Using the code checker](https://docs.nextcloud.com/server/14/developer_manual/app/publishing.html#using-the-code-checker)
      * [Losing a rating](https://docs.nextcloud.com/server/14/developer_manual/app/publishing.html#losing-a-rating)
    * [](https://docs.nextcloud.com/server/14/developer_manual/app/publishing.html#app-guidelines)
      * [Legal and security](https://docs.nextcloud.com/server/14/developer_manual/app/publishing.html#legal-and-security)
      * [Be technically sound](https://docs.nextcloud.com/server/14/developer_manual/app/publishing.html#be-technically-sound)
      * [Respect the users](https://docs.nextcloud.com/server/14/developer_manual/app/publishing.html#respect-the-users)
    * [](https://docs.nextcloud.com/server/14/developer_manual/app/publishing.html#moving-your-repo-to-the-nextcloud-organization)
      * [Benefits](https://docs.nextcloud.com/server/14/developer_manual/app/publishing.html#benefits)
      * [Requirements](https://docs.nextcloud.com/server/14/developer_manual/app/publishing.html#requirements)
      * [How to move](https://docs.nextcloud.com/server/14/developer_manual/app/publishing.html#how-to-move)
  * [Code signing](https://docs.nextcloud.com/server/14/developer_manual/app/code_signing.html)
  * [App development](https://docs.nextcloud.com/server/14/developer_manual/app/index.html)
  * [Design guidelines](https://docs.nextcloud.com/server/14/developer_manual/design/index.html)
  * [Android application development](https://docs.nextcloud.com/server/14/developer_manual/android_library/index.html)
  * [Client APIs](https://docs.nextcloud.com/server/14/developer_manual/client_apis/index.html)
  * [Core development](https://docs.nextcloud.com/server/14/developer_manual/core/index.html)
  * [Bugtracker](https://docs.nextcloud.com/server/14/developer_manual/bugtracker/index.html)
  * [Help and communication](https://docs.nextcloud.com/server/14/developer_manual/commun/index.html)
  * [API Documentation](https://docs.nextcloud.com/server/14/developer_manual/api.html)


[Nextcloud 14 Developer Manual](https://docs.nextcloud.com/server/14/developer_manual/index.html)
  * [](https://docs.nextcloud.com/server/14/developer_manual/index.html) »
  * [App development](https://docs.nextcloud.com/server/14/developer_manual/app/index.html) »
  * App store publishing
  * [ Edit on GitHub](https://github.com/nextcloud/documentation/edit/stable14/developer_manual/app/publishing.rst)


* * *
# App store publishing[¶](https://docs.nextcloud.com/server/14/developer_manual/app/publishing.html#app-store-publishing "Permalink to this headline")
## The Nextcloud app store[¶](https://docs.nextcloud.com/server/14/developer_manual/app/publishing.html#the-nextcloud-app-store "Permalink to this headline")
The Nextcloud app store is built into Nextcloud to allow you to get your apps to users as easily and safely as possible. The app store and the process of publishing apps aims to be:
  * secure
  * transparent
  * welcoming
  * fair
  * easy to maintain


## Getting an app approved[¶](https://docs.nextcloud.com/server/14/developer_manual/app/publishing.html#getting-an-app-approved "Permalink to this headline")
You can find documentation on getting apps in our app store [here.](http://nextcloudappstore.readthedocs.io/en/latest/developer.html#publishing-apps-on-the-app-store)
### Using the code checker[¶](https://docs.nextcloud.com/server/14/developer_manual/app/publishing.html#using-the-code-checker "Permalink to this headline")
Before getting the app in the app store, it is best to check your app code with the code checker, and fix the issues found by the code checker.
```
./occ app:check-code <app_name>

```

### Losing a rating[¶](https://docs.nextcloud.com/server/14/developer_manual/app/publishing.html#losing-a-rating "Permalink to this headline")
Apps can lose their rating when:
  * they are found to no longer satisfy the requirements
  * when security/malicious intent issues are found
  * when a developer requests so


## App guidelines[¶](https://docs.nextcloud.com/server/14/developer_manual/app/publishing.html#app-guidelines "Permalink to this headline")
These are the app guidelines an app has to comply with to have a chance to be approved.
### Legal and security[¶](https://docs.nextcloud.com/server/14/developer_manual/app/publishing.html#legal-and-security "Permalink to this headline")
  * Apps can not use ‘Nextcloud’ in their name.
  * Irregular and unannounced security audits of all apps can and will take place.
  *

If any indication of malicious intent or bad faith is found the developer(s) in question can count on a minimum 2 year ban from any Nextcloud infrastructure.

    * Malicious intent includes deliberate spying on users by leaking user data to a third party system or adding a back door (like a hard-coded user account) to Nextcloud. An unintentional security bug that gets fixed in time won’t be considered bad faith.
  * Apps do not violate any laws; it has to comply with copyright- and trademark law.
  * App authors have to respond timely to security concerns and not make Nextcloud more vulnerable to attack.


Note
Distributing malicious or illegal applications can have legal consequences including, but not limited to Nextcloud or affected users taking legal action.
### Be technically sound[¶](https://docs.nextcloud.com/server/14/developer_manual/app/publishing.html#be-technically-sound "Permalink to this headline")
  * Apps can only use the public Nextcloud API.
  * At time of the release of an app it can only be configured to be compatible with the latest Nextcloud release +1.
  * Apps should not cause Nextcloud to break, consume excessive memory or slow Nextcloud down.
  * Apps should not hamper functionality of Nextcloud unless that is explicitly the goal of the app.


### Respect the users[¶](https://docs.nextcloud.com/server/14/developer_manual/app/publishing.html#respect-the-users "Permalink to this headline")
  * Apps have to follow design and [HTML/CSS layout guidelines](https://docs.nextcloud.com/server/14/developer_manual/app/css.html).
  * Apps correctly clean up after themselves on uninstall and correctly handle up- and downgrades.
  * Apps clearly communicate their intended purpose and active features, including features introduced through updates.
  * Apps respect the users’ choices and do not make unexpected changes, or limit users’ ability to revert them. For example, they do not remove other apps or disable settings.
  * Apps must respect user privacy. IF user data is sent anywhere, this must be clearly explained and be kept to a minimum for the functioning of an app. Use proper security measures when needed.
  * App authors must provide means to contact them, be it through a bug tracker, forum or mail.


Apps which break the guidelines will lose their ‘approved’ or ‘official’ state; and might be blocked from the app store altogether. This also has repercussions for the author, especially in case of security concerns, he/she might find themselves blocked from submitting applications.
## Moving your repo to the Nextcloud organization[¶](https://docs.nextcloud.com/server/14/developer_manual/app/publishing.html#moving-your-repo-to-the-nextcloud-organization "Permalink to this headline")
We’re always delighted to hear app developers are interested in moving their app to the Nextcloud organization at [github.com/nextcloud](https://github.com/nextcloud)! There are benefits for users and developers in being there. However, it comes with some requirements as well.
### Benefits[¶](https://docs.nextcloud.com/server/14/developer_manual/app/publishing.html#benefits "Permalink to this headline")
  * You can use the tools and bots we have set up, including translations and such
  * Everybody in the Nextcloud organization can contribute more easily
  * Your visibility to app developers increases
  * Users can expect apps in our project to be better maintained


### Requirements[¶](https://docs.nextcloud.com/server/14/developer_manual/app/publishing.html#requirements "Permalink to this headline")
To deliver on the promises above, we have two simple rules.
  * You work and communicate according to the values of our [Code of Conduct](https://docs.nextcloud.com/server/14/developer_manual/general/code-of-conduct.html)
  * When you are no longer active, our admins can decide to hand over maintainership to another contributor


We want to make sure that when you find other things in life which are more urgent or otherwise are unable to help your project anymore, it does not become ‘dead code’ as long as there are people who want to keep it alive. This is not fair to users, who would be forced to remove the app and install another.
Please note that the role of a maintainer is not to be the most active or prolific contributor to a project! Being friendly, welcoming and responsive are what it takes to be a successful maintainer. Not being the most brilliant developer ever, or spending nights and weekends coding!
The goal of these rules is simple: help your project be more successful. We also suggest you watch this talk by [Jan about building a great community.](https://www.youtube.com/watch?v=UtAoRIKVpW4)
### How to move[¶](https://docs.nextcloud.com/server/14/developer_manual/app/publishing.html#how-to-move "Permalink to this headline")
To move your repository to our Github organization, just ask any of our contributors, [especially those who are admin.](https://github.com/orgs/nextcloud/people?utf8=%E2%9C%93&query=+role%3Aowner) They will be happy to help!
[Next ](https://docs.nextcloud.com/server/14/developer_manual/app/code_signing.html "Code signing") [](https://docs.nextcloud.com/server/14/developer_manual/app/testing.html "Testing")
* * *
© Copyright 2021 Nextcloud GmbH.
Read the Docs v: 14

Versions
    [14](https://docs.nextcloud.com/server/14/developer_manual)     [15](https://docs.nextcloud.com/server/15/developer_manual)     [16](https://docs.nextcloud.com/server/16/developer_manual)     [stable](https://docs.nextcloud.com/server/stable/developer_manual)     [latest](https://docs.nextcloud.com/server/latest/developer_manual)

Downloads


On Read the Docs
     [Project Home](https://docs.nextcloud.com/projects//?fromdocs=)      [Builds](https://docs.nextcloud.com/builds//?fromdocs=)
