[ ![Logo](https://docs.nextcloud.com/server/15/developer_manual/_static/logo-white.png) ](https://docs.nextcloud.com/server/15/developer_manual/)
  * [General contributor guidelines](https://docs.nextcloud.com/server/15/developer_manual/general/index.html)
  * [App development](https://docs.nextcloud.com/server/15/developer_manual/app/index.html)
  * [Design guidelines](https://docs.nextcloud.com/server/15/developer_manual/design/index.html)
  * [Android application development](https://docs.nextcloud.com/server/15/developer_manual/android_library/index.html)
  * [Client APIs](https://docs.nextcloud.com/server/15/developer_manual/client_apis/index.html)
  * [Core development](https://docs.nextcloud.com/server/15/developer_manual/core/index.html)
  * [Bugtracker](https://docs.nextcloud.com/server/15/developer_manual/bugtracker/index.html)
  * [Help and communication](https://docs.nextcloud.com/server/15/developer_manual/commun/index.html)
  * [API Documentation](https://docs.nextcloud.com/server/15/developer_manual/api.html)


[Nextcloud 15 Developer Manual](https://docs.nextcloud.com/server/15/developer_manual/)
  * [](https://docs.nextcloud.com/server/15/developer_manual/) »
  * Nextcloud developer documentation
  * [ Edit on GitHub](https://github.com/nextcloud/documentation/edit/stable15/developer_manual/index.rst)


* * *
# Nextcloud developer documentation[¶](https://docs.nextcloud.com/server/15/developer_manual/#nextcloud-developer-documentation "Permalink to this headline")
## Table of contents[¶](https://docs.nextcloud.com/server/15/developer_manual/#table-of-contents "Permalink to this headline")
  * [General contributor guidelines](https://docs.nextcloud.com/server/15/developer_manual/general/index.html)
    * [Community code of conduct](https://docs.nextcloud.com/server/15/developer_manual/general/code-of-conduct.html)
    * [Development environment](https://docs.nextcloud.com/server/15/developer_manual/general/devenv.html)
    * [Security guidelines](https://docs.nextcloud.com/server/15/developer_manual/general/security.html)
    * [Coding style & general guidelines](https://docs.nextcloud.com/server/15/developer_manual/general/codingguidelines.html)
    * [Performance considerations](https://docs.nextcloud.com/server/15/developer_manual/general/performance.html)
    * [Debugging](https://docs.nextcloud.com/server/15/developer_manual/general/debugging.html)
    * [Backporting](https://docs.nextcloud.com/server/15/developer_manual/general/backporting.html)
  * [App development](https://docs.nextcloud.com/server/15/developer_manual/app/index.html)
    * [Introduction](https://docs.nextcloud.com/server/15/developer_manual/app/intro.html)
    * [Tutorial](https://docs.nextcloud.com/server/15/developer_manual/app/tutorial.html)
    * [Request lifecycle](https://docs.nextcloud.com/server/15/developer_manual/app/requests/index.html)
    * [View](https://docs.nextcloud.com/server/15/developer_manual/app/view/index.html)
    * [Storage and database](https://docs.nextcloud.com/server/15/developer_manual/app/storage/index.html)
    * [Changelog](https://docs.nextcloud.com/server/15/developer_manual/app/changelog.html)
    * [Classloader](https://docs.nextcloud.com/server/15/developer_manual/app/classloader.html)
    * [Code signing](https://docs.nextcloud.com/server/15/developer_manual/app/code_signing.html)
    * [App metadata](https://docs.nextcloud.com/server/15/developer_manual/app/info.html)
    * [Navigation and pre-app configuration](https://docs.nextcloud.com/server/15/developer_manual/app/init.html)
    * [App store publishing](https://docs.nextcloud.com/server/15/developer_manual/app/publishing.html)
    * [User management](https://docs.nextcloud.com/server/15/developer_manual/app/users.html)
    * [Two-factor providers](https://docs.nextcloud.com/server/15/developer_manual/app/two-factor-provider.html)
    * [Hooks](https://docs.nextcloud.com/server/15/developer_manual/app/hooks.html)
    * [Background jobs (Cron)](https://docs.nextcloud.com/server/15/developer_manual/app/backgroundjobs.html)
    * [Settings](https://docs.nextcloud.com/server/15/developer_manual/app/settings.html)
    * [Notifications](https://docs.nextcloud.com/server/15/developer_manual/app/notifications.html)
    * [Logging](https://docs.nextcloud.com/server/15/developer_manual/app/logging.html)
    * [Repair steps](https://docs.nextcloud.com/server/15/developer_manual/app/repair.html)
    * [Public Pages](https://docs.nextcloud.com/server/15/developer_manual/app/publicpage.html)
    * [Testing](https://docs.nextcloud.com/server/15/developer_manual/app/testing.html)
    * [API Documentation](https://docs.nextcloud.com/server/15/developer_manual/api.html)
  * [Design guidelines](https://docs.nextcloud.com/server/15/developer_manual/design/index.html)
    * [Introduction](https://docs.nextcloud.com/server/15/developer_manual/design/navigation.html)
    * [New button](https://docs.nextcloud.com/server/15/developer_manual/design/navigation.html#new-button)
    * [App navigation menu](https://docs.nextcloud.com/server/15/developer_manual/design/navigation.html#app-navigation-menu)
    * [Settings](https://docs.nextcloud.com/server/15/developer_manual/design/navigation.html#settings)
    * [Main content](https://docs.nextcloud.com/server/15/developer_manual/design/content.html)
    * [Content list](https://docs.nextcloud.com/server/15/developer_manual/design/list.html)
    * [Popover menu](https://docs.nextcloud.com/server/15/developer_manual/design/popovermenu.html)
    * [HTML elements](https://docs.nextcloud.com/server/15/developer_manual/design/html.html)
    * [SCSS](https://docs.nextcloud.com/server/15/developer_manual/design/css.html)
    * [Icons](https://docs.nextcloud.com/server/15/developer_manual/design/icons.html)
  * [Android application development](https://docs.nextcloud.com/server/15/developer_manual/android_library/index.html)
    * [Android Nextcloud client development](https://docs.nextcloud.com/server/15/developer_manual/android_library/index.html#android-nextcloud-client-development)
    * [Nextcloud Android library](https://docs.nextcloud.com/server/15/developer_manual/android_library/index.html#nextcloud-android-library)
  * [Client APIs](https://docs.nextcloud.com/server/15/developer_manual/client_apis/index.html)
    * [Webdav](https://docs.nextcloud.com/server/15/developer_manual/client_apis/WebDAV/index.html)
    * [OCS API’s](https://docs.nextcloud.com/server/15/developer_manual/client_apis/OCS/index.html)
    * [Login Flow](https://docs.nextcloud.com/server/15/developer_manual/client_apis/LoginFlow/index.html)
  * [Core development](https://docs.nextcloud.com/server/15/developer_manual/core/index.html)
    * [Unit-Testing](https://docs.nextcloud.com/server/15/developer_manual/core/unit-testing.html)
    * [Theming Nextcloud](https://docs.nextcloud.com/server/15/developer_manual/core/theming.html)
    * [External API](https://docs.nextcloud.com/server/15/developer_manual/core/externalapi.html)
    * [OCS Share API](https://docs.nextcloud.com/server/15/developer_manual/core/ocs-share-api.html)
  * [Bugtracker](https://docs.nextcloud.com/server/15/developer_manual/bugtracker/index.html)
  * [Help and communication](https://docs.nextcloud.com/server/15/developer_manual/commun/index.html)
    * [Forums](https://docs.nextcloud.com/server/15/developer_manual/commun/index.html#forums)
    * [IRC channels](https://docs.nextcloud.com/server/15/developer_manual/commun/index.html#irc-channels)
    * [Maintainers](https://docs.nextcloud.com/server/15/developer_manual/commun/index.html#maintainers)
  * [API Documentation](https://docs.nextcloud.com/server/15/developer_manual/api.html)
    * [PHP public API](https://docs.nextcloud.com/server/15/developer_manual/api.html#php-public-api)
    * [PHP class reference](https://docs.nextcloud.com/server/15/developer_manual/api.html#php-class-reference)


[Next ](https://docs.nextcloud.com/server/15/developer_manual/general/index.html "General contributor guidelines")
* * *
© Copyright 2021 Nextcloud GmbH.
Read the Docs v: 15

Versions
    [15](https://docs.nextcloud.com/server/15/developer_manual)     [16](https://docs.nextcloud.com/server/16/developer_manual)     [17](https://docs.nextcloud.com/server/17/developer_manual)     [stable](https://docs.nextcloud.com/server/stable/developer_manual)     [latest](https://docs.nextcloud.com/server/latest/developer_manual)

Downloads


On Read the Docs
     [Project Home](https://docs.nextcloud.com/projects//?fromdocs=)      [Builds](https://docs.nextcloud.com/builds//?fromdocs=)
