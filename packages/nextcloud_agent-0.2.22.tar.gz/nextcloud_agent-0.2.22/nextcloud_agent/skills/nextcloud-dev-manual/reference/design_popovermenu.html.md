[ ![Logo](https://docs.nextcloud.com/server/14/developer_manual/_static/logo-white.png) ](https://docs.nextcloud.com/server/14/developer_manual/index.html)
  * [General contributor guidelines](https://docs.nextcloud.com/server/14/developer_manual/general/index.html)
  * [Changelog](https://docs.nextcloud.com/server/14/developer_manual/app/changelog.html)
  * [Tutorial](https://docs.nextcloud.com/server/14/developer_manual/app/tutorial.html)
  * [Create an app](https://docs.nextcloud.com/server/14/developer_manual/app/startapp.html)
  * [Navigation and pre-app configuration](https://docs.nextcloud.com/server/14/developer_manual/app/init.html)
  * [App metadata](https://docs.nextcloud.com/server/14/developer_manual/app/info.html)
  * [Classloader](https://docs.nextcloud.com/server/14/developer_manual/app/classloader.html)
  * [Request lifecycle](https://docs.nextcloud.com/server/14/developer_manual/app/request.html)
  * [Routing](https://docs.nextcloud.com/server/14/developer_manual/app/routes.html)
  * [Middleware](https://docs.nextcloud.com/server/14/developer_manual/app/middleware.html)
  * [Container](https://docs.nextcloud.com/server/14/developer_manual/app/container.html)
  * [Controllers](https://docs.nextcloud.com/server/14/developer_manual/app/controllers.html)
  * [RESTful API](https://docs.nextcloud.com/server/14/developer_manual/app/api.html)
  * [Templates](https://docs.nextcloud.com/server/14/developer_manual/app/templates.html)
  * [JavaScript](https://docs.nextcloud.com/server/14/developer_manual/app/js.html)
  * [CSS](https://docs.nextcloud.com/server/14/developer_manual/app/css.html)
  * [Translation](https://docs.nextcloud.com/server/14/developer_manual/app/l10n.html)
  * [Theming support](https://docs.nextcloud.com/server/14/developer_manual/app/theming.html)
  * [Database schema](https://docs.nextcloud.com/server/14/developer_manual/app/schema.html)
  * [Database access](https://docs.nextcloud.com/server/14/developer_manual/app/database.html)
  * [Configuration](https://docs.nextcloud.com/server/14/developer_manual/app/configuration.html)
  * [Filesystem](https://docs.nextcloud.com/server/14/developer_manual/app/filesystem.html)
  * [AppData](https://docs.nextcloud.com/server/14/developer_manual/app/appdata.html)
  * [User management](https://docs.nextcloud.com/server/14/developer_manual/app/users.html)
  * [Two-factor providers](https://docs.nextcloud.com/server/14/developer_manual/app/two-factor-provider.html)
  * [Hooks](https://docs.nextcloud.com/server/14/developer_manual/app/hooks.html)
  * [Background jobs (Cron)](https://docs.nextcloud.com/server/14/developer_manual/app/backgroundjobs.html)
  * [Settings](https://docs.nextcloud.com/server/14/developer_manual/app/settings.html)
  * [Logging](https://docs.nextcloud.com/server/14/developer_manual/app/logging.html)
  * [Migrations](https://docs.nextcloud.com/server/14/developer_manual/app/migrations.html)
  * [Repair steps](https://docs.nextcloud.com/server/14/developer_manual/app/repair.html)
  * [Testing](https://docs.nextcloud.com/server/14/developer_manual/app/testing.html)
  * [App store publishing](https://docs.nextcloud.com/server/14/developer_manual/app/publishing.html)
  * [Code signing](https://docs.nextcloud.com/server/14/developer_manual/app/code_signing.html)
  * [App development](https://docs.nextcloud.com/server/14/developer_manual/app/index.html)
  * [](https://docs.nextcloud.com/server/14/developer_manual/design/index.html)
    * [Introduction](https://docs.nextcloud.com/server/14/developer_manual/design/navigation.html)
    * [New button](https://docs.nextcloud.com/server/14/developer_manual/design/navigation.html#new-button)
    * [App navigation menu](https://docs.nextcloud.com/server/14/developer_manual/design/navigation.html#app-navigation-menu)
    * [Settings](https://docs.nextcloud.com/server/14/developer_manual/design/navigation.html#settings)
    * [Main content](https://docs.nextcloud.com/server/14/developer_manual/design/content.html)
    * [Content list](https://docs.nextcloud.com/server/14/developer_manual/design/list.html)
    * [](https://docs.nextcloud.com/server/14/developer_manual/design/popovermenu.html)
      * [What is a popover menu](https://docs.nextcloud.com/server/14/developer_manual/design/popovermenu.html#what-is-a-popover-menu)
      * [Basic layout](https://docs.nextcloud.com/server/14/developer_manual/design/popovermenu.html#basic-layout)
      * [Technical details](https://docs.nextcloud.com/server/14/developer_manual/design/popovermenu.html#technical-details)
      * [Alignment](https://docs.nextcloud.com/server/14/developer_manual/design/popovermenu.html#alignment)
    * [HTML elements](https://docs.nextcloud.com/server/14/developer_manual/design/html.html)
    * [SCSS](https://docs.nextcloud.com/server/14/developer_manual/design/css.html)
    * [Icons](https://docs.nextcloud.com/server/14/developer_manual/design/icons.html)
  * [Android application development](https://docs.nextcloud.com/server/14/developer_manual/android_library/index.html)
  * [Client APIs](https://docs.nextcloud.com/server/14/developer_manual/client_apis/index.html)
  * [Core development](https://docs.nextcloud.com/server/14/developer_manual/core/index.html)
  * [Bugtracker](https://docs.nextcloud.com/server/14/developer_manual/bugtracker/index.html)
  * [Help and communication](https://docs.nextcloud.com/server/14/developer_manual/commun/index.html)
  * [API Documentation](https://docs.nextcloud.com/server/14/developer_manual/api.html)


[Nextcloud 14 Developer Manual](https://docs.nextcloud.com/server/14/developer_manual/index.html)
  * [](https://docs.nextcloud.com/server/14/developer_manual/index.html) »
  * [Design guidelines](https://docs.nextcloud.com/server/14/developer_manual/design/index.html) »
  * Popover menu
  * [ Edit on GitHub](https://github.com/nextcloud/documentation/edit/stable14/developer_manual/design/popovermenu.rst)


* * *
# Popover menu[¶](https://docs.nextcloud.com/server/14/developer_manual/design/popovermenu.html#popover-menu "Permalink to this headline")
## What is a popover menu[¶](https://docs.nextcloud.com/server/14/developer_manual/design/popovermenu.html#what-is-a-popover-menu "Permalink to this headline")
This is a quick menu that open on click. For menus, we use the three-dot-icon.
This is exactly the same as the [navigation menu](https://docs.nextcloud.com/server/14/developer_manual/design/navigation.html#navigation-menu). The only difference is the popovermenu class.
## Basic layout[¶](https://docs.nextcloud.com/server/14/developer_manual/design/popovermenu.html#basic-layout "Permalink to this headline")
![Popover image example](https://docs.nextcloud.com/server/14/developer_manual/_images/popovermenu.png)
```
<div class="popovermenu">
    <ul>
       <li>
           <a href="#" class="icon-details">
               <span>Details</span>
           </a>
       </li>
       <li>
           <button class="icon-close">
               <span>Remove</span>
           </button>
       </li>
       <li>
           <button>
               <span class="icon-favorite"></span>
               <span>Favorite</span>
           </button>
       </li>
       <li>
           <a>
               <span class="icon-rename"></span>
               <span>Edit</span>
           </a>
       </li>
       <li>
           <span class="menuitem">
               <input id="check1" type="checkbox" class="checkbox" />
               <label for="check1">Enable</label>
           </span>
       </li>
       <li>
           <span class="menuitem">
               <input id="radio1" type="radio" class="radio" />
               <label for="radio1">Select</label>
           </span>
       </li>
        <li>
            <span class="menuitem">
                <span class="icon icon-user"></span>
                <form>
                        <input id="input-folder" type="text" value="new email">
                        <input type="submit" value=" " class="primary icon-checkmark-white">
                </form>
            </span>
        </li>
         <li>
             <span class="menuitem">
                 <span class="icon icon-folder"></span>
                 <form>
                         <input id="input-folder" type="text" value="New folder">
                         <input type="submit" value=" " class="icon-confirm">
                 </form>
             </span>
         </li>
    </ul>
</div>

```

## Technical details[¶](https://docs.nextcloud.com/server/14/developer_manual/design/popovermenu.html#technical-details "Permalink to this headline")
  * The only allowed menu items elements are **a** , **button** and **span** for the checkbox and radio only.
  * You can mix between a and button on the same menu (in case of form or direct link) like the example above
  * You need to put the entire menu just after the three dot icon `<div><span class="icon-more"></span><div class="popovermenu">...</div></div>`
  * You do not need JS, CSS only is ok for positioning. JS is **still** required to handle the hide/show.
  * Only **one** ul is allowed.
  * Only **one level** of menu is allowed.
  * Every entry **needs** to have its own icon. This greatly improves the UX.
  * The required **right** distance to the border (or padding, whatever you want to use) of the three-dot icon should be 14px (5 for menu margin and 6 for arrow position)
  * The `span` element **must** have the `menuitem` class.
  * The checkbox/radio must use the [nextcloud custom](https://docs.nextcloud.com/server/14/developer_manual/design/html.html#checkboxes-and-radios)
  * The form element is optionnal if you’re using inputs.
  * Supported inputs are all text based ones and buttons type ones

![../_images/popover-position.png](https://docs.nextcloud.com/server/14/developer_manual/_images/popover-position.png)
## Alignment[¶](https://docs.nextcloud.com/server/14/developer_manual/design/popovermenu.html#alignment "Permalink to this headline")
If you want to align your menu, you can add the class to the main popovermenu div.
  * Center: `menu-center`
  * Left: `menu-left`
  * Right is by default


[Next ](https://docs.nextcloud.com/server/14/developer_manual/design/html.html "HTML elements") [](https://docs.nextcloud.com/server/14/developer_manual/design/list.html "Content list")
* * *
© Copyright 2021 Nextcloud GmbH.
Read the Docs v: 14

Versions
    [14](https://docs.nextcloud.com/server/14/developer_manual)     [15](https://docs.nextcloud.com/server/15/developer_manual)     [16](https://docs.nextcloud.com/server/16/developer_manual)     [stable](https://docs.nextcloud.com/server/stable/developer_manual)     [latest](https://docs.nextcloud.com/server/latest/developer_manual)

Downloads


On Read the Docs
     [Project Home](https://docs.nextcloud.com/projects//?fromdocs=)      [Builds](https://docs.nextcloud.com/builds//?fromdocs=)
