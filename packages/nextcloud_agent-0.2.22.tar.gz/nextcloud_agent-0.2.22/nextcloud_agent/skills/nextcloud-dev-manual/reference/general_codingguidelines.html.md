[ ![Logo](https://docs.nextcloud.com/server/14/developer_manual/_static/logo-white.png) ](https://docs.nextcloud.com/server/14/developer_manual/index.html)
  * [](https://docs.nextcloud.com/server/14/developer_manual/general/index.html)
    * [Community code of conduct](https://docs.nextcloud.com/server/14/developer_manual/general/code-of-conduct.html)
    * [Development environment](https://docs.nextcloud.com/server/14/developer_manual/general/devenv.html)
    * [Security guidelines](https://docs.nextcloud.com/server/14/developer_manual/general/security.html)
    * [](https://docs.nextcloud.com/server/14/developer_manual/general/codingguidelines.html)
      * [General](https://docs.nextcloud.com/server/14/developer_manual/general/codingguidelines.html#general)
      * [Labels](https://docs.nextcloud.com/server/14/developer_manual/general/codingguidelines.html#labels)
      * [Coding](https://docs.nextcloud.com/server/14/developer_manual/general/codingguidelines.html#coding)
      * [License headers](https://docs.nextcloud.com/server/14/developer_manual/general/codingguidelines.html#license-headers)
      * [User interface](https://docs.nextcloud.com/server/14/developer_manual/general/codingguidelines.html#user-interface)
      * [](https://docs.nextcloud.com/server/14/developer_manual/general/codingguidelines.html#php)
        * [Comments](https://docs.nextcloud.com/server/14/developer_manual/general/codingguidelines.html#comments)
        * [Objects, functions, arrays & variables](https://docs.nextcloud.com/server/14/developer_manual/general/codingguidelines.html#objects-functions-arrays-variables)
        * [Operators](https://docs.nextcloud.com/server/14/developer_manual/general/codingguidelines.html#operators)
        * [Control structures](https://docs.nextcloud.com/server/14/developer_manual/general/codingguidelines.html#control-structures)
        * [Unit tests](https://docs.nextcloud.com/server/14/developer_manual/general/codingguidelines.html#unit-tests)
      * [](https://docs.nextcloud.com/server/14/developer_manual/general/codingguidelines.html#javascript)
        * [Objects & inheritance](https://docs.nextcloud.com/server/14/developer_manual/general/codingguidelines.html#objects-inheritance)
        * [Objects, functions & variables](https://docs.nextcloud.com/server/14/developer_manual/general/codingguidelines.html#objects-functions-variables)
        * [Operators](https://docs.nextcloud.com/server/14/developer_manual/general/codingguidelines.html#id1)
        * [Control structures](https://docs.nextcloud.com/server/14/developer_manual/general/codingguidelines.html#id2)
      * [CSS](https://docs.nextcloud.com/server/14/developer_manual/general/codingguidelines.html#css)
    * [Performance considerations](https://docs.nextcloud.com/server/14/developer_manual/general/performance.html)
    * [Debugging](https://docs.nextcloud.com/server/14/developer_manual/general/debugging.html)
    * [Backporting](https://docs.nextcloud.com/server/14/developer_manual/general/backporting.html)
  * [Changelog](https://docs.nextcloud.com/server/14/developer_manual/app/changelog.html)
  * [Tutorial](https://docs.nextcloud.com/server/14/developer_manual/app/tutorial.html)
  * [Create an app](https://docs.nextcloud.com/server/14/developer_manual/app/startapp.html)
  * [Navigation and pre-app configuration](https://docs.nextcloud.com/server/14/developer_manual/app/init.html)
  * [App metadata](https://docs.nextcloud.com/server/14/developer_manual/app/info.html)
  * [Classloader](https://docs.nextcloud.com/server/14/developer_manual/app/classloader.html)
  * [Request lifecycle](https://docs.nextcloud.com/server/14/developer_manual/app/request.html)
  * [Routing](https://docs.nextcloud.com/server/14/developer_manual/app/routes.html)
  * [Middleware](https://docs.nextcloud.com/server/14/developer_manual/app/middleware.html)
  * [Container](https://docs.nextcloud.com/server/14/developer_manual/app/container.html)
  * [Controllers](https://docs.nextcloud.com/server/14/developer_manual/app/controllers.html)
  * [RESTful API](https://docs.nextcloud.com/server/14/developer_manual/app/api.html)
  * [Templates](https://docs.nextcloud.com/server/14/developer_manual/app/templates.html)
  * [JavaScript](https://docs.nextcloud.com/server/14/developer_manual/app/js.html)
  * [CSS](https://docs.nextcloud.com/server/14/developer_manual/app/css.html)
  * [Translation](https://docs.nextcloud.com/server/14/developer_manual/app/l10n.html)
  * [Theming support](https://docs.nextcloud.com/server/14/developer_manual/app/theming.html)
  * [Database schema](https://docs.nextcloud.com/server/14/developer_manual/app/schema.html)
  * [Database access](https://docs.nextcloud.com/server/14/developer_manual/app/database.html)
  * [Configuration](https://docs.nextcloud.com/server/14/developer_manual/app/configuration.html)
  * [Filesystem](https://docs.nextcloud.com/server/14/developer_manual/app/filesystem.html)
  * [AppData](https://docs.nextcloud.com/server/14/developer_manual/app/appdata.html)
  * [User management](https://docs.nextcloud.com/server/14/developer_manual/app/users.html)
  * [Two-factor providers](https://docs.nextcloud.com/server/14/developer_manual/app/two-factor-provider.html)
  * [Hooks](https://docs.nextcloud.com/server/14/developer_manual/app/hooks.html)
  * [Background jobs (Cron)](https://docs.nextcloud.com/server/14/developer_manual/app/backgroundjobs.html)
  * [Settings](https://docs.nextcloud.com/server/14/developer_manual/app/settings.html)
  * [Logging](https://docs.nextcloud.com/server/14/developer_manual/app/logging.html)
  * [Migrations](https://docs.nextcloud.com/server/14/developer_manual/app/migrations.html)
  * [Repair steps](https://docs.nextcloud.com/server/14/developer_manual/app/repair.html)
  * [Testing](https://docs.nextcloud.com/server/14/developer_manual/app/testing.html)
  * [App store publishing](https://docs.nextcloud.com/server/14/developer_manual/app/publishing.html)
  * [Code signing](https://docs.nextcloud.com/server/14/developer_manual/app/code_signing.html)
  * [App development](https://docs.nextcloud.com/server/14/developer_manual/app/index.html)
  * [Design guidelines](https://docs.nextcloud.com/server/14/developer_manual/design/index.html)
  * [Android application development](https://docs.nextcloud.com/server/14/developer_manual/android_library/index.html)
  * [Client APIs](https://docs.nextcloud.com/server/14/developer_manual/client_apis/index.html)
  * [Core development](https://docs.nextcloud.com/server/14/developer_manual/core/index.html)
  * [Bugtracker](https://docs.nextcloud.com/server/14/developer_manual/bugtracker/index.html)
  * [Help and communication](https://docs.nextcloud.com/server/14/developer_manual/commun/index.html)
  * [API Documentation](https://docs.nextcloud.com/server/14/developer_manual/api.html)


[Nextcloud 14 Developer Manual](https://docs.nextcloud.com/server/14/developer_manual/index.html)
  * [](https://docs.nextcloud.com/server/14/developer_manual/index.html) »
  * [General contributor guidelines](https://docs.nextcloud.com/server/14/developer_manual/general/index.html) »
  * Coding style & general guidelines
  * [ Edit on GitHub](https://github.com/nextcloud/documentation/edit/stable14/developer_manual/general/codingguidelines.rst)


* * *
# Coding style & general guidelines[¶](https://docs.nextcloud.com/server/14/developer_manual/general/codingguidelines.html#coding-style-general-guidelines "Permalink to this headline")
## General[¶](https://docs.nextcloud.com/server/14/developer_manual/general/codingguidelines.html#general "Permalink to this headline")
  * Ideally, discuss your plans on the [forums](https://help.nextcloud.com) to see if others want to work with you on it
  * We use [GitHub](https://github.com/nextcloud), please get an account there and clone the repositories you want to work on
  * Fixes go directly to master, nevertheless they need to be tested thoroughly.
  * New features are always developed in a branch and only merged to master once they are fully done.
  * Software should work. We only put features into master when they are complete. It’s better to not have a feature instead of having one that works poorly.
  * It is best to start working based on an issue - create one if there is none. You describe what you want to do, ask feedback on the direction you take it and take it from there.
  * When you are finished, use the merge request function on GitHub to create a pull request. The other developers will look at it and give you feedback. You can signify that your PR is ready for review by adding the label “5 - ready for review” to it. You can also post your merge request to the mailing list to let people know. See [the code review page for more information](https://docs.nextcloud.com/server/14/developer_manual/bugtracker/codereviews.html)
  * It is key to keep changes separate and small. The bigger and more hairy a PR grows, the harder it is to get it in. So split things up where you can in smaller changes - if you need a small improvement like a API addition for a big feature addition, get it in first rather than adding it to the big piece of work!
  * Decisions are made by consensus. We strive for making the best technical decisions and as nobody can know everything, we collaborate. That means a first negative comment might not be the final word, neither is positive feedback an immediate GO. Nextcloud is built out of modular pieces (apps) and maintainers have a strong influence. In case of disagreement we consult other seasoned contributors.


## Labels[¶](https://docs.nextcloud.com/server/14/developer_manual/general/codingguidelines.html#labels "Permalink to this headline")
We assign labels to issues and pull requests to make it easy to find them and to signal what needs to be done. Some of these are assigned by the developers, others by QA, bug triagers, project lead or maintainers and so on. It is not desired that users/reporters of bugs assign labels themselves, unless they are developers/contributors to Nextcloud.
The most important labels and their meaning:
  * #backport-request - the pull requests also needs to be applied to older Nextcloud versions
  * #bug - this issue is a bug
  * #enhancement - this issue is a feature request/idea for improvement of Nextcloud
  * #design - this needs help from the design team or is a design-related issue/pull request
  * #technical debt - this issue or PR is about [technical debt](http://en.wikipedia.org/wiki/Technical_debt)
  * #good first issue - these are issues which are relatively easy to solve and ideal for people who want to learn how to code in Nextcloud
  * #needs info - this issue needs further information from the reporter, see [Nextcloud bug triaging](https://docs.nextcloud.com/server/14/developer_manual/bugtracker/triaging.html)
  * #high #medium #low signify how important the bug is.
  * Tags showing the state of the issue or PR, numbered 0-4:
    * 0. Needs triage - ready to start development on this
    * 1. to develop - ready to start development on this
    * 2. developing - development in progress
    * 3. to review - ready for review
    * 4. to release - reviewed PR that awaits unfreeze of a branch to get merged
  * Feature tags: #feature: something. These tags indicate the features across apps and components which are impacted by the issue or which the PR is related to


If you want a label not in the list above, please first discuss on the mailing list.
## Coding[¶](https://docs.nextcloud.com/server/14/developer_manual/general/codingguidelines.html#coding "Permalink to this headline")
  * Maximum line-length of 80 characters
  * Use tabs to indent
  * A tab is 4 spaces wide
  * Opening braces of blocks are on the same line as the definition
  * Quotes: ‘ for everything, ” for HTML attributes (<p class=”my_class”>)
  * End of Lines : Unix style (LF / ‘n’) only
  * No global variables or functions
  * Unit tests
  * HTML should be HTML5 compliant
  * Check these [database performance tips](https://mailman.owncloud.org/pipermail/devel/2014-June/000262.html)
  * When you `git pull`, always `git pull --rebase` to avoid generating extra commits like: _merged master into master_


## License headers[¶](https://docs.nextcloud.com/server/14/developer_manual/general/codingguidelines.html#license-headers "Permalink to this headline")
Nextcloud is licensed under the [GNU AGPLv3](https://www.gnu.org/licenses/agpl). From June, 16 2016 on we switched to “GNU AGPLv3 or any later version” for better long-term maintainability. If you create a new file please use this header:
```
/**
 *
 * @copyright Copyright (c) <year>, <your name> (<your email address>)
 *
 * @license GNU AGPL version 3 or any later version
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

```

If you edit an existing file please add a copyright notice with your name, if you consider your changes substantial enough to claim copyright. As a rule if thumb, this is the case if you contributed more than seven lines of code.
## User interface[¶](https://docs.nextcloud.com/server/14/developer_manual/general/codingguidelines.html#user-interface "Permalink to this headline")
  * Software should get out of the way. Do things automatically instead of offering configuration options.
  * Software should be easy to use. Show only the most important elements. Secondary elements only on hover or via Advanced function.
  * User data is sacred. Provide undo instead of asking for confirmation - [which might be dismissed](http://www.alistapart.com/articles/neveruseawarning/)
  * The state of the application should be clear. If something loads, provide feedback.
  * Do not adapt broken concepts (for example design of desktop apps) just for the sake of consistency. We aim to provide a better interface, so let’s find out how to do that!
  * Regularly reset your installation to see how the first-run experience is like. And improve it.
  * Ideally do [usability testing](http://jancborchardt.net/usability-in-free-software) to know how people use the software.
  * For further UX principles, read [Alex Faaborg from Mozilla](http://uxmag.com/articles/quantifying-usability).


## PHP[¶](https://docs.nextcloud.com/server/14/developer_manual/general/codingguidelines.html#php "Permalink to this headline")
The Nextcloud coding style guide is based on [PEAR Coding Standards](http://pear.php.net/manual/en/standards.php).
Always use:
```
<?php

```

at the start of your php code. The final closing:
```
?>

```

should not be used at the end of the file due to the [possible issue of sending white spaces](http://stackoverflow.com/questions/4410704/php-closing-tag).
### Comments[¶](https://docs.nextcloud.com/server/14/developer_manual/general/codingguidelines.html#comments "Permalink to this headline")
All API methods need to be marked with [PHPDoc](http://en.wikipedia.org/wiki/PHPDoc) markup. An example would be:
```
<?php

/**
 * Description what method does
 * @param Controller $controller the controller that will be transformed
 * @param API $api an instance of the API class
 * @throws APIException if the api is broken
 * @since 4.5
 * @return string a name of a user
 */
public function myMethod(Controller $controller, API $api) {
  // ...
}

```

### Objects, functions, arrays & variables[¶](https://docs.nextcloud.com/server/14/developer_manual/general/codingguidelines.html#objects-functions-arrays-variables "Permalink to this headline")
Use _UpperCamelCase_ for Objects, _lowerCamelCase_ for functions and variables. If you set a default function/method parameter, do not use spaces. Do not prepend private class members with underscores.
```
class MyClass {

}

function myFunction($default=null) {

}

$myVariable = 'blue';

$someArray = array(
    'foo'  => 'bar',
    'spam' => 'ham',
);

?>

```

### Operators[¶](https://docs.nextcloud.com/server/14/developer_manual/general/codingguidelines.html#operators "Permalink to this headline")
Use **===** and **!==** instead of **==** and **!=**.
Here’s why:
```
<?php

var_dump(0 == "a"); // 0 == 0 -> true
var_dump("1" == "01"); // 1 == 1 -> true
var_dump("10" == "1e1"); // 10 == 10 -> true
var_dump(100 == "1e2"); // 100 == 100 -> true

?>

```

### Control structures[¶](https://docs.nextcloud.com/server/14/developer_manual/general/codingguidelines.html#control-structures "Permalink to this headline")
  * Always use { } for one line ifs
  * Split long ifs into multiple lines
  * Always use break in switch statements and prevent a default block with warnings if it shouldn’t be accessed


```
<?php

// single line if
if ($myVar === 'hi') {
    $myVar = 'ho';
} else {
    $myVar = 'bye';
}

// long ifs
if (   $something === 'something'
    || $condition2
    && $condition3
) {
  // your code
}

// for loop
for ($i = 0; $i < 4; $i++) {
    // your code
}

switch ($condition) {
    case 1:
        // action1
        break;

    case 2:
        // action2;
        break;

    default:
        // defaultaction;
        break;
}

?>

```

### Unit tests[¶](https://docs.nextcloud.com/server/14/developer_manual/general/codingguidelines.html#unit-tests "Permalink to this headline")
Unit tests must always extend the `\Test\TestCase` class, which takes care of cleaning up the installation after the test.
If a test is run with multiple different values, a data provider must be used. The name of the data provider method must not start with `test` and must end with `Data`.
```
<?php
namespace Test;
class Dummy extends \Test\TestCase {
    public function dummyData() {
        return array(
            array(1, true),
            array(2, false),
        );
    }

    /**
     * @dataProvider dummyData
     */
    public function testDummy($input, $expected) {
        $this->assertEquals($expected, \Dummy::method($input));
    }
}

```

## JavaScript[¶](https://docs.nextcloud.com/server/14/developer_manual/general/codingguidelines.html#javascript "Permalink to this headline")
In general take a look at [JSLint](http://www.jslint.com) without the whitespace rules.
  * Use a `js/main.js` or `js/app.js` where your program is started
  * Complete every statement with a **;**
  * Use **var** to limit variable to local scope
  * To keep your code local, wrap everything in a self executing function. To access global objects or export things to the global namespace, pass all global objects to the self executing function.
  * Use JavaScript strict mode
  * Use a global namespace object where you bind publicly used functions and objects to


**DO** :
```
// set up namespace for sharing across multiple files
var MyApp = MyApp || {};

(function(window, $, exports, undefined) {
    'use strict';

    // if this function or object should be global, attach it to the namespace
    exports.myGlobalFunction = function(params) {
        return params;
    };

})(window, jQuery, MyApp);

```

**DONT** (Seriously):
```
// This does not only make everything global but you're programming
// JavaScript like C functions with namespaces
MyApp = {
    myFunction:function(params) {
        return params;
    },
    ...
};

```

### Objects & inheritance[¶](https://docs.nextcloud.com/server/14/developer_manual/general/codingguidelines.html#objects-inheritance "Permalink to this headline")
Try to use OOP in your JavaScript to make your code reusable and flexible.
This is how you’d do inheritance in JavaScript:
```
// create parent object and bind methods to it
var ParentObject = function(name) {
    this.name = name;
};

ParentObject.prototype.sayHello = function() {
    console.log(this.name);
}


// create childobject, call parents constructor and inherit methods
var ChildObject = function(name, age) {
    ParentObject.call(this, name);
    this.age = age;
};

ChildObject.prototype = Object.create(ParentObject.prototype);

// overwrite parent method
ChildObject.prototype.sayHello = function() {
    // call parent method if you want to
    ParentObject.prototype.sayHello.call(this);
    console.log('childobject');
};

var child = new ChildObject('toni', 23);

// prints:
// toni
// childobject
child.sayHello();

```

### Objects, functions & variables[¶](https://docs.nextcloud.com/server/14/developer_manual/general/codingguidelines.html#objects-functions-variables "Permalink to this headline")
Use _UpperCamelCase_ for Objects, _lowerCamelCase_ for functions and variables.
```
var MyObject = function() {
    this.attr = "hi";
};

var myFunction = function() {
    return true;
};

var myVariable = 'blue';

var objectLiteral = {
    value1: 'somevalue'
};

```

### Operators[¶](https://docs.nextcloud.com/server/14/developer_manual/general/codingguidelines.html#id1 "Permalink to this headline")
Use **===** and **!==** instead of **==** and **!=**.
Here’s why:
```
'' == '0'           // false
0 == ''             // true
0 == '0'            // true

false == 'false'    // false
false == '0'        // true

false == undefined  // false
false == null       // false
null == undefined   // true

' \t\r\n ' == 0     // true

```

### Control structures[¶](https://docs.nextcloud.com/server/14/developer_manual/general/codingguidelines.html#id2 "Permalink to this headline")
  * Always use { } for one line ifs
  * Split long ifs into multiple lines
  * Always use break in switch statements and prevent a default block with warnings if it shouldn’t be accessed


**DO** :
```
// single line if
if (myVar === 'hi') {
    myVar = 'ho';
} else {
    myVar = 'bye';
}

// long ifs
if (   something === 'something'
    || condition2
    && condition3
) {
  // your code
}

// for loop
for (var i = 0; i < 4; i++) {
    // your code
}

// switch
switch (value) {

    case 'hi':
        // yourcode
        break;

    default:
        console.warn('Entered undefined default block in switch');
        break;
}

```

## CSS[¶](https://docs.nextcloud.com/server/14/developer_manual/general/codingguidelines.html#css "Permalink to this headline")
Take a look at the [Writing Tactical CSS & HTML](http://www.youtube.com/watch?v=hou2wJCh3XE&feature=plcp) video on YouTube.
Don’t bind your CSS too much to your HTML structure and try to avoid IDs. Also try to make your CSS reusable by grouping common attributes into classes.
**DO** :
```
.list {
    list-style-type: none;
}

.list > .list_item {
    display: inline-block;
}

.important_list_item {
    color: red;
}

```

**DON’T** :
```
#content .myHeader ul {
    list-style-type: none;
}

#content .myHeader ul li.list_item {
    color: red;
    display: inline-block;
}

```

**TBD**
[Next ](https://docs.nextcloud.com/server/14/developer_manual/general/performance.html "Performance considerations") [](https://docs.nextcloud.com/server/14/developer_manual/general/security.html "Security guidelines")
* * *
© Copyright 2021 Nextcloud GmbH.
Read the Docs v: 14

Versions
    [14](https://docs.nextcloud.com/server/14/developer_manual)     [15](https://docs.nextcloud.com/server/15/developer_manual)     [16](https://docs.nextcloud.com/server/16/developer_manual)     [stable](https://docs.nextcloud.com/server/stable/developer_manual)     [latest](https://docs.nextcloud.com/server/latest/developer_manual)

Downloads


On Read the Docs
     [Project Home](https://docs.nextcloud.com/projects//?fromdocs=)      [Builds](https://docs.nextcloud.com/builds//?fromdocs=)
