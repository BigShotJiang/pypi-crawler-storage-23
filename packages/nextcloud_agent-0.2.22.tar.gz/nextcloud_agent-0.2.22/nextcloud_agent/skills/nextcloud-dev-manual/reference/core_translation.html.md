[ ![Logo](https://docs.nextcloud.com/server/14/developer_manual/_static/logo-white.png) ](https://docs.nextcloud.com/server/14/developer_manual/index.html)
  * [General contributor guidelines](https://docs.nextcloud.com/server/14/developer_manual/general/index.html)
  * [Changelog](https://docs.nextcloud.com/server/14/developer_manual/app/changelog.html)
  * [Tutorial](https://docs.nextcloud.com/server/14/developer_manual/app/tutorial.html)
  * [Create an app](https://docs.nextcloud.com/server/14/developer_manual/app/startapp.html)
  * [Navigation and pre-app configuration](https://docs.nextcloud.com/server/14/developer_manual/app/init.html)
  * [App metadata](https://docs.nextcloud.com/server/14/developer_manual/app/info.html)
  * [Classloader](https://docs.nextcloud.com/server/14/developer_manual/app/classloader.html)
  * [Request lifecycle](https://docs.nextcloud.com/server/14/developer_manual/app/request.html)
  * [Routing](https://docs.nextcloud.com/server/14/developer_manual/app/routes.html)
  * [Middleware](https://docs.nextcloud.com/server/14/developer_manual/app/middleware.html)
  * [Container](https://docs.nextcloud.com/server/14/developer_manual/app/container.html)
  * [Controllers](https://docs.nextcloud.com/server/14/developer_manual/app/controllers.html)
  * [RESTful API](https://docs.nextcloud.com/server/14/developer_manual/app/api.html)
  * [Templates](https://docs.nextcloud.com/server/14/developer_manual/app/templates.html)
  * [JavaScript](https://docs.nextcloud.com/server/14/developer_manual/app/js.html)
  * [CSS](https://docs.nextcloud.com/server/14/developer_manual/app/css.html)
  * [Translation](https://docs.nextcloud.com/server/14/developer_manual/app/l10n.html)
  * [Theming support](https://docs.nextcloud.com/server/14/developer_manual/app/theming.html)
  * [Database schema](https://docs.nextcloud.com/server/14/developer_manual/app/schema.html)
  * [Database access](https://docs.nextcloud.com/server/14/developer_manual/app/database.html)
  * [Configuration](https://docs.nextcloud.com/server/14/developer_manual/app/configuration.html)
  * [Filesystem](https://docs.nextcloud.com/server/14/developer_manual/app/filesystem.html)
  * [AppData](https://docs.nextcloud.com/server/14/developer_manual/app/appdata.html)
  * [User management](https://docs.nextcloud.com/server/14/developer_manual/app/users.html)
  * [Two-factor providers](https://docs.nextcloud.com/server/14/developer_manual/app/two-factor-provider.html)
  * [Hooks](https://docs.nextcloud.com/server/14/developer_manual/app/hooks.html)
  * [Background jobs (Cron)](https://docs.nextcloud.com/server/14/developer_manual/app/backgroundjobs.html)
  * [Settings](https://docs.nextcloud.com/server/14/developer_manual/app/settings.html)
  * [Logging](https://docs.nextcloud.com/server/14/developer_manual/app/logging.html)
  * [Migrations](https://docs.nextcloud.com/server/14/developer_manual/app/migrations.html)
  * [Repair steps](https://docs.nextcloud.com/server/14/developer_manual/app/repair.html)
  * [Testing](https://docs.nextcloud.com/server/14/developer_manual/app/testing.html)
  * [App store publishing](https://docs.nextcloud.com/server/14/developer_manual/app/publishing.html)
  * [Code signing](https://docs.nextcloud.com/server/14/developer_manual/app/code_signing.html)
  * [App development](https://docs.nextcloud.com/server/14/developer_manual/app/index.html)
  * [Design guidelines](https://docs.nextcloud.com/server/14/developer_manual/design/index.html)
  * [Android application development](https://docs.nextcloud.com/server/14/developer_manual/android_library/index.html)
  * [Client APIs](https://docs.nextcloud.com/server/14/developer_manual/client_apis/index.html)
  * [](https://docs.nextcloud.com/server/14/developer_manual/core/index.html)
    * [](https://docs.nextcloud.com/server/14/developer_manual/core/translation.html)
      * [Make text translatable](https://docs.nextcloud.com/server/14/developer_manual/core/translation.html#make-text-translatable)
      * [](https://docs.nextcloud.com/server/14/developer_manual/core/translation.html#you-shall-never-split-sentences)
        * [Reason:](https://docs.nextcloud.com/server/14/developer_manual/core/translation.html#reason)
        * [Example:](https://docs.nextcloud.com/server/14/developer_manual/core/translation.html#example)
        * [Translators will translate:](https://docs.nextcloud.com/server/14/developer_manual/core/translation.html#translators-will-translate)
        * [HTML on translation string:](https://docs.nextcloud.com/server/14/developer_manual/core/translation.html#html-on-translation-string)
        * [What about variable in the strings?](https://docs.nextcloud.com/server/14/developer_manual/core/translation.html#what-about-variable-in-the-strings)
      * [](https://docs.nextcloud.com/server/14/developer_manual/core/translation.html#automated-synchronization-of-translations)
        * [Please follow the steps below to add translation support to your app:](https://docs.nextcloud.com/server/14/developer_manual/core/translation.html#please-follow-the-steps-below-to-add-translation-support-to-your-app)
      * [Manual quick translation update:](https://docs.nextcloud.com/server/14/developer_manual/core/translation.html#manual-quick-translation-update)
      * [Configure Transifex](https://docs.nextcloud.com/server/14/developer_manual/core/translation.html#configure-transifex)
    * [Unit-Testing](https://docs.nextcloud.com/server/14/developer_manual/core/unit-testing.html)
    * [Theming Nextcloud](https://docs.nextcloud.com/server/14/developer_manual/core/theming.html)
    * [External API](https://docs.nextcloud.com/server/14/developer_manual/core/externalapi.html)
    * [OCS Share API](https://docs.nextcloud.com/server/14/developer_manual/core/ocs-share-api.html)
  * [Bugtracker](https://docs.nextcloud.com/server/14/developer_manual/bugtracker/index.html)
  * [Help and communication](https://docs.nextcloud.com/server/14/developer_manual/commun/index.html)
  * [API Documentation](https://docs.nextcloud.com/server/14/developer_manual/api.html)


[Nextcloud 14 Developer Manual](https://docs.nextcloud.com/server/14/developer_manual/index.html)
  * [](https://docs.nextcloud.com/server/14/developer_manual/index.html) »
  * [Core development](https://docs.nextcloud.com/server/14/developer_manual/core/index.html) »
  * Translation
  * [ Edit on GitHub](https://github.com/nextcloud/documentation/edit/stable14/developer_manual/core/translation.rst)


* * *
# Translation[¶](https://docs.nextcloud.com/server/14/developer_manual/core/translation.html#translation "Permalink to this headline")
## Make text translatable[¶](https://docs.nextcloud.com/server/14/developer_manual/core/translation.html#make-text-translatable "Permalink to this headline")
In HTML or PHP wrap it like this `<?php p($l->t('This is some text'));?>` or this `<?php print_unescaped($l->t('This is some text'));?>`. For the right date format use `<?php p($l->l('date', time()));?>`. Change the way dates are shown by editing `/core/l10n/l10n-_lang_.php`.
To translate text in JavaScript use: `t('appname','text to translate');`
Note
`print_unescaped()` should be preferred only if you would like to display HTML code. Otherwise, using `p()` is strongly preferred to escape HTML characters against XSS attacks.
## You shall never split sentences![¶](https://docs.nextcloud.com/server/14/developer_manual/core/translation.html#you-shall-never-split-sentences "Permalink to this headline")
### Reason:[¶](https://docs.nextcloud.com/server/14/developer_manual/core/translation.html#reason "Permalink to this headline")
Translators lose the context and they have no chance to possibly re-arrange words.
### Example:[¶](https://docs.nextcloud.com/server/14/developer_manual/core/translation.html#example "Permalink to this headline")
```
<?php p($l->t('Select file from')) . ' '; ?><a href='#' id="browselink"><?php p($l->t('local filesystem'));?></a><?php p($l->t(' or ')); ?><a href='#' id="cloudlink"><?php p($l->t('cloud'));?></a>

```

### Translators will translate:[¶](https://docs.nextcloud.com/server/14/developer_manual/core/translation.html#translators-will-translate "Permalink to this headline")
  * Select file from
  * local filesystem
  * ‘ or “
  * cloud


Translating these individual strings results in `local filesystem` and `cloud` losing case. The two white spaces surrounding `or` will get lost while translating as well. For languages that have a different grammatical order it prevents the translators from reordering the sentence components.
### HTML on translation string:[¶](https://docs.nextcloud.com/server/14/developer_manual/core/translation.html#html-on-translation-string "Permalink to this headline")
HTML tags in translation strings is ugly but usually translators can handle this.
### What about variable in the strings?[¶](https://docs.nextcloud.com/server/14/developer_manual/core/translation.html#what-about-variable-in-the-strings "Permalink to this headline")
If you need to add variables to the translation strings do it like this:
PHP:
```
$l->t('%s is available. Get <a href="%s">more information</a>', array($data['versionstring'], $data['web']));

```

JavaScript:
```
t(appName, '{name} is available. Get <a href="{link}">more information</a>', {name: 'Nextcloud 16', link: '...'});

```

## Automated synchronization of translations[¶](https://docs.nextcloud.com/server/14/developer_manual/core/translation.html#automated-synchronization-of-translations "Permalink to this headline")
Multiple nightly jobs have been setup in order to synchronize translations - it’s a multi-step process:
  1. `perl l10n.pl read` will rescan all PHP and JavaScript files and generate the templates.
  2. The templates are pushed to [Transifex](https://www.transifex.com/nextcloud/) (tx push -s).
  3. All translations are pulled from [Transifex](https://www.transifex.com/nextcloud/) (tx pull -a).
  4. `perl l10n.pl write` will write the PHP files containing the translations.
  5. Finally the changes are pushed to Git.


### Please follow the steps below to add translation support to your app:[¶](https://docs.nextcloud.com/server/14/developer_manual/core/translation.html#please-follow-the-steps-below-to-add-translation-support-to-your-app "Permalink to this headline")
  1. Create a folder `l10n`.
  2. Create the file `ignorelist` which can contain files which shall not be scanned during step 4.
  3. Edit `l10n/.tx/config` and copy/paste a config section and adapt it by changing the app/folder name.
  4. Run `perl l10n.pl read` within the folder `l10n`.
  5. Add the newly created translation template (_l10n/Templates/ <appname>.pot_) to Git and commit the changes above.
  6. After the next nightly sync job a new resource will appear on Transifex and from now on every night the latest translations will arrive.


**Caution: information below is in general not needed!**
## Manual quick translation update:[¶](https://docs.nextcloud.com/server/14/developer_manual/core/translation.html#manual-quick-translation-update "Permalink to this headline")
```
cd l10n/ && perl l10n.pl read && tx push -s && tx pull -a && perl l10n.pl write && cd ..

```

The translation script requires Locale::PO, installable via `apt-get install liblocale-po-perl`.
## Configure Transifex[¶](https://docs.nextcloud.com/server/14/developer_manual/core/translation.html#configure-transifex "Permalink to this headline")
```
tx init

for resource in calendar contacts core files media gallery settings
do
tx set --auto-local -r nextcloud.$resource "<lang>/$resource.po" --source-language=en \
 --source-file "templates/$resource.pot" --execute
done

```

[Next ](https://docs.nextcloud.com/server/14/developer_manual/core/unit-testing.html "Unit-Testing") [](https://docs.nextcloud.com/server/14/developer_manual/core/index.html "Core development")
* * *
© Copyright 2021 Nextcloud GmbH.
Read the Docs v: 14

Versions
    [14](https://docs.nextcloud.com/server/14/developer_manual)     [15](https://docs.nextcloud.com/server/15/developer_manual)     [16](https://docs.nextcloud.com/server/16/developer_manual)     [stable](https://docs.nextcloud.com/server/stable/developer_manual)     [latest](https://docs.nextcloud.com/server/latest/developer_manual)

Downloads


On Read the Docs
     [Project Home](https://docs.nextcloud.com/projects//?fromdocs=)      [Builds](https://docs.nextcloud.com/builds//?fromdocs=)
