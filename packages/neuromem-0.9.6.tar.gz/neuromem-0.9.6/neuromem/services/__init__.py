"""neuromem service layer."""
