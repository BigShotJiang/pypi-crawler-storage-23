Get all diffs for a file across revisions.

Arguments: <file> <start_rev> [end_rev]

Run: taskman history-diffs $ARGUMENTS

Display the output.
