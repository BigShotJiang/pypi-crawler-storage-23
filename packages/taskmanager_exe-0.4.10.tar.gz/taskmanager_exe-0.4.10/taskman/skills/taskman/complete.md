Complete a task and archive it.

1. Update the task file:
   - Set Status: complete
   - Add Completed: date
   - Fill Notes with any gotchas or uncompleted work

2. Move task to _archive/

3. Update STATUS.md:
   - Remove from active tasks
   - Add pointer to next task (if any)

4. Run: taskman sync "complete: $ARGUMENTS"

Keep it brief - the task is done.
