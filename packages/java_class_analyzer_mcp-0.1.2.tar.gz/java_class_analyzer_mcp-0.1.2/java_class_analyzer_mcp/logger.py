"""
统一日志模块

日志同时输出到:
  1. stderr（不污染 MCP stdout JSON-RPC）
  2. <projectPath>/.java-class-analyzer/logs/YYYY-MM-DD.log（按天滚动）

用法:
    from .logger import get_logger
    logger = get_logger(project_path)   # project_path 可为 None
    logger.debug("...")
    logger.info("...")
    logger.warning("...")
    logger.error("...")
"""

import logging
import os
import sys
from logging.handlers import TimedRotatingFileHandler
from typing import Optional

_LOG_DIR_NAME = ".java-class-analyzer"
_LOG_SUBDIR = "logs"

# 全局 logger 缓存，key = project_path（或 "" 表示无项目路径）
_loggers: dict[str, logging.Logger] = {}


def _is_debug() -> bool:
    return os.environ.get("LOG_LEVEL", "DEBUG").upper() == "DEBUG"


def _build_logger(name: str, log_file: Optional[str]) -> logging.Logger:
    """构造一个 Logger 实例（stderr + 可选的文件处理器）"""
    logger = logging.getLogger(name)
    # 避免重复添加 handler
    if logger.handlers:
        return logger

    logger.setLevel(logging.DEBUG if _is_debug() else logging.INFO)
    logger.propagate = False

    fmt = logging.Formatter(
        fmt="%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # Handler 1: stderr
    stderr_handler = logging.StreamHandler(sys.stderr)
    stderr_handler.setLevel(logging.DEBUG)
    stderr_handler.setFormatter(fmt)
    logger.addHandler(stderr_handler)

    # Handler 2: 按天滚动的文件日志
    if log_file:
        try:
            os.makedirs(os.path.dirname(log_file), exist_ok=True)
            file_handler = TimedRotatingFileHandler(
                filename=log_file,
                when="midnight",  # 每天零点切割
                interval=1,
                backupCount=30,  # 保留最近 30 天
                encoding="utf-8",
                utc=False,
            )
            # 切割后的文件名后缀格式：YYYY-MM-DD
            file_handler.suffix = "%Y-%m-%d"
            file_handler.setLevel(logging.DEBUG)
            file_handler.setFormatter(fmt)
            logger.addHandler(file_handler)
        except Exception as e:
            # 文件日志初始化失败不影响程序运行
            print(f"[logger] 初始化文件日志失败: {e}", file=sys.stderr)

    return logger


def get_logger(project_path: Optional[str] = None) -> logging.Logger:
    """
    获取（或创建）与 project_path 绑定的 Logger。

    Args:
        project_path: Maven 项目根目录路径。为 None 时只写 stderr，不写文件。
    """
    key = project_path or ""
    if key in _loggers:
        return _loggers[key]

    log_file: Optional[str] = None
    if project_path:
        log_dir = os.path.join(project_path, _LOG_DIR_NAME, _LOG_SUBDIR)
        # 文件名使用当天日期（TimedRotatingFileHandler 会自动按天切割）
        log_file = os.path.join(log_dir, "java-class-analyzer.log")

    logger_name = f"java_class_analyzer.{key}" if key else "java_class_analyzer"
    logger = _build_logger(logger_name, log_file)
    _loggers[key] = logger
    return logger
