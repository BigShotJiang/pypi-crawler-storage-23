"""Database backend adapter registry."""

from __future__ import annotations

from .base import BackendAdapter
from .postgresql import PostgresqlBackendAdapter
from .sqlite import SqliteBackendAdapter

_SQLITE = SqliteBackendAdapter()
_POSTGRES = PostgresqlBackendAdapter()

_BACKENDS: dict[str, BackendAdapter] = {
    "sqlite": _SQLITE,
    "sqlite3": _SQLITE,
    "ferrum.db.backends.sqlite3": _SQLITE,
    "ferrum.db.backends.sqlite": _SQLITE,
    "postgres": _POSTGRES,
    "postgresql": _POSTGRES,
    "ferrum.db.backends.postgresql": _POSTGRES,
}


def get_backend_adapter(engine: str) -> BackendAdapter:
    key = str(engine).strip().lower()
    adapter = _BACKENDS.get(key)
    if adapter is None:
        supported = ", ".join(sorted({"ferrum.db.backends.sqlite3", "ferrum.db.backends.postgresql"}))
        raise ValueError(f"unsupported database ENGINE '{engine}'. Supported: {supported}")
    return adapter


__all__ = ["BackendAdapter", "get_backend_adapter"]
