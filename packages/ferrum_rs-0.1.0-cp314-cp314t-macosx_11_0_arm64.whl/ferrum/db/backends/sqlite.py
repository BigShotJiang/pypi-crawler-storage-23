"""SQLite backend adapter."""

from __future__ import annotations

from pathlib import Path
from typing import Mapping

from ferrum._ferrum import configure_db as _configure_db

from .base import BackendAdapter


class SqliteBackendAdapter(BackendAdapter):
    def __init__(self) -> None:
        super().__init__(
            engine="ferrum.db.backends.sqlite3",
            dialect="sqlite",
            param_style="qmark",
        )

    def resolve_database_url(
        self,
        database_settings: Mapping[str, object],
        *,
        base_dir: str | Path | None = None,
    ) -> str:
        explicit_url = database_settings.get("URL")
        if isinstance(explicit_url, str) and explicit_url.strip():
            return explicit_url.strip()

        name = database_settings.get("NAME")
        if not isinstance(name, str) or not name.strip():
            raise ValueError(
                "sqlite backend requires DATABASES['default']['NAME'] or URL"
            )

        path = Path(name.strip()).expanduser()
        if path.is_absolute():
            return str(path)

        if isinstance(base_dir, (str, Path)):
            return str((Path(base_dir) / path).resolve())

        return str(path.resolve())

    def configure_connection(self, database_url: str) -> None:
        _configure_db(str(database_url))
