"""Backend adapter contracts for Ferrum database engines."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Mapping


@dataclass(frozen=True)
class BackendAdapter:
    engine: str
    dialect: str
    param_style: str

    def resolve_database_url(
        self,
        database_settings: Mapping[str, object],
        *,
        base_dir: str | Path | None = None,
    ) -> str:
        raise NotImplementedError

    def configure_connection(self, database_url: str) -> None:
        raise NotImplementedError
