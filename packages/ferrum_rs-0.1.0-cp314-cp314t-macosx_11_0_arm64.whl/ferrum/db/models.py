"""Ghost ORM layer for Ferrum.

This module records query intent in Python and forwards execution to Rust.
"""

from __future__ import annotations

import json
import threading
from collections.abc import Iterable
from dataclasses import dataclass
from typing import Any, ClassVar

from ferrum._ferrum import (
    configure_allowed_tables as _configure_allowed_tables,
    configure_db as _configure_db,
    ensure_model_table as _ensure_model_table,
    execute_query as _execute_query,
    execute_sql as _execute_sql,
    save_model as _save_model,
    FerrumModel,
)

_MODEL_REGISTRY: dict[str, type[Model]] = {}
_MODEL_REGISTRY_BY_LABEL: dict[str, type[Model]] = {}
_PENDING_REVERSE_RELATIONS: list[tuple[type[Model], ForeignKey]] = []
_PENDING_MANY_TO_MANY_RELATIONS: list[tuple[type[Model], ManyToManyField]] = []
_INTERNAL_TABLES = {
    "ferrum_migrations",
    "ferrum_migration_meta",
    "ferrum_installed_apps",
}
_SUPPORTED_LOOKUPS = {
    "exact",
    "gt",
    "gte",
    "lt",
    "lte",
    "contains",
    "icontains",
    "startswith",
    "istartswith",
    "endswith",
    "iendswith",
    "range",
    "in",
    "isnull",
}

_ATOMIC_STATE = threading.local()


def _atomic_stack() -> list[str | None]:
    stack = getattr(_ATOMIC_STATE, "stack", None)
    if stack is None:
        stack = []
        _ATOMIC_STATE.stack = stack
    return stack


def _normalize_choices(choices: Iterable[Any] | None) -> tuple[Any, ...] | None:
    if choices is None:
        return None

    normalized: list[Any] = []
    for item in choices:
        if isinstance(item, tuple) and item:
            normalized.append(item[0])
        else:
            normalized.append(item)

    return tuple(normalized)


def _infer_model_app_label(model_cls: type[Model]) -> str:
    meta = getattr(model_cls, "Meta", None)
    configured = getattr(meta, "app_label", None) if meta else None
    if isinstance(configured, str) and configured:
        if not configured.isidentifier():
            raise ValueError(
                f"Meta.app_label for {model_cls.__name__} must be a valid identifier"
            )
        return configured

    module_name = model_cls.__module__
    parts = [part for part in module_name.split(".") if part]
    if len(parts) >= 2 and parts[-1] == "models":
        candidate = parts[-2]
        if candidate.isidentifier():
            return candidate

    if parts:
        first = parts[0]
        if first.isidentifier():
            return first

    return "main"


def _sync_allowed_tables() -> None:
    known_tables = {
        model_cls.table_name() for model_cls in _MODEL_REGISTRY_BY_LABEL.values()
    }
    known_tables.update(_INTERNAL_TABLES)
    _configure_allowed_tables(sorted(known_tables))


@dataclass(frozen=True)
class QueryIR:
    steps: tuple[dict[str, object], ...]

    @classmethod
    def from_steps(cls, steps: Iterable[dict[str, object]]) -> QueryIR:
        frozen_steps = tuple(dict(step) for step in steps)
        return cls(steps=frozen_steps)

    def to_json(self) -> str:
        return json.dumps(
            list(self.steps),
            separators=(",", ":"),
            sort_keys=True,
        )


class Aggregate:
    function = ""

    def __init__(self, field: str = "*") -> None:
        if not isinstance(field, str) or not field:
            raise ValueError("aggregate field must be a non-empty string")
        self.field = field

    def default_alias(self) -> str:
        field_token = "all" if self.field == "*" else self.field
        return f"{field_token}__{self.function}"


class Count(Aggregate):
    function = "count"


class Sum(Aggregate):
    function = "sum"


class Avg(Aggregate):
    function = "avg"


class Min(Aggregate):
    function = "min"


class Max(Aggregate):
    function = "max"


class Q:
    def __init__(self, **kwargs: object) -> None:
        self.children: list[Q | dict[str, object]] = []
        self.connector = "and"
        self.negated = False

        if kwargs:
            self.children.append(dict(kwargs))

    def __and__(self, other: Q) -> Q:
        if not isinstance(other, Q):
            return NotImplemented
        return self._combine(other, "and")

    def __or__(self, other: Q) -> Q:
        if not isinstance(other, Q):
            return NotImplemented
        return self._combine(other, "or")

    def __invert__(self) -> Q:
        clone = self._clone()
        clone.negated = not clone.negated
        return clone

    def _clone(self) -> Q:
        clone = Q()
        clone.connector = self.connector
        clone.negated = self.negated
        clone.children = []

        for child in self.children:
            if isinstance(child, Q):
                clone.children.append(child._clone())
            else:
                clone.children.append(dict(child))

        return clone

    def _combine(self, other: Q, connector: str) -> Q:
        combined = Q()
        combined.connector = connector
        combined.children = [self._clone(), other._clone()]
        return combined


class Field:
    rust_type = "text"

    def __init__(
        self,
        *,
        nullable: bool = False,
        default: Any = None,
        unique: bool = False,
        db_index: bool = False,
        choices: Iterable[Any] | None = None,
    ) -> None:
        self.nullable = nullable
        self.default = default
        self.unique = unique
        self.db_index = db_index
        self.choices = _normalize_choices(choices)
        self.name = ""

    def __set_name__(self, owner: type[Model], name: str) -> None:
        _ = owner
        self.name = name

    def __get__(self, instance: Model | None, owner: type[Model]) -> Any:
        _ = owner
        if instance is None:
            return self

        if self.name in instance.__dict__:
            return instance.__dict__[self.name]

        return self.default_value()

    def __set__(self, instance: Model, value: Any) -> None:
        instance.__dict__[self.name] = self.validate(value)

    def default_value(self) -> Any:
        if callable(self.default):
            return self.default()
        return self.default

    def storage_name(self) -> str:
        return self.name

    def _validate_choices(self, value: Any) -> Any:
        if self.choices is None or value is None:
            return value

        if value not in self.choices:
            raise ValueError(
                f"field '{self.name}' must be one of {list(self.choices)!r}"
            )

        return value

    def validate(self, value: Any) -> Any:
        if value is None:
            if self.nullable:
                return None
            raise ValueError(f"field '{self.name}' cannot be null")

        return self._validate_choices(value)

    def to_storage_value(self, value: Any) -> Any:
        return self.validate(value)

    def from_storage_value(self, value: Any) -> Any:
        return self.validate(value)

    def value_from_instance(self, instance: Model) -> Any:
        return getattr(instance, self.name, None)

    def to_record_value(self, instance: Model) -> Any:
        return self.to_storage_value(self.value_from_instance(instance))

    def set_from_storage_key(self, instance: Model, value: Any) -> None:
        setattr(instance, self.name, self.from_storage_value(value))

    def validate_lookup(self, lookup: str, raw_key: str) -> None:
        _ = (lookup, raw_key)

    def normalize_lookup_value(self, lookup: str, value: Any) -> Any:
        if lookup == "isnull":
            if not isinstance(value, bool):
                raise ValueError(f"lookup '{self.name}__isnull' expects a boolean")
            return value

        if lookup == "in":
            if isinstance(value, (str, bytes)) or not isinstance(value, Iterable):
                raise ValueError(f"lookup '{self.name}__in' expects an iterable")
            return [self.to_storage_value(item) for item in value]

        if lookup == "range":
            if isinstance(value, (str, bytes)) or not isinstance(value, Iterable):
                raise ValueError(f"lookup '{self.name}__range' expects an iterable")
            values = list(value)
            if len(values) != 2:
                raise ValueError(
                    f"lookup '{self.name}__range' expects exactly two values"
                )
            return [
                self.to_storage_value(values[0]),
                self.to_storage_value(values[1]),
            ]

        return self.to_storage_value(value)

    def schema_spec(self) -> dict[str, object]:
        return {
            "type": self.rust_type,
            "nullable": self.nullable,
            "unique": self.unique,
            "db_index": self.db_index,
        }


class CharField(Field):
    rust_type = "text"

    def __init__(
        self,
        *,
        max_length: int,
        nullable: bool = False,
        default: str | None = None,
        unique: bool = False,
        db_index: bool = False,
        choices: Iterable[Any] | None = None,
    ) -> None:
        super().__init__(
            nullable=nullable,
            default=default,
            unique=unique,
            db_index=db_index,
            choices=choices,
        )
        self.max_length = max_length

    def validate(self, value: Any) -> str | None:
        value = super().validate(value)
        if value is None:
            return None
        if not isinstance(value, str):
            raise ValueError(f"field '{self.name}' expects a string")
        if len(value) > self.max_length:
            raise ValueError(
                f"field '{self.name}' exceeds max_length={self.max_length}"
            )
        return self._validate_choices(value)


class IntegerField(Field):
    rust_type = "integer"

    def __init__(
        self,
        *,
        nullable: bool = False,
        default: int | None = None,
        unique: bool = False,
        db_index: bool = False,
        choices: Iterable[Any] | None = None,
    ) -> None:
        super().__init__(
            nullable=nullable,
            default=default,
            unique=unique,
            db_index=db_index,
            choices=choices,
        )

    def validate(self, value: Any) -> int | None:
        value = super().validate(value)
        if value is None:
            return None
        if isinstance(value, bool) or not isinstance(value, int):
            raise ValueError(f"field '{self.name}' expects an integer")
        return self._validate_choices(value)


class FloatField(Field):
    rust_type = "float"

    def __init__(
        self,
        *,
        nullable: bool = False,
        default: float | None = None,
        unique: bool = False,
        db_index: bool = False,
        choices: Iterable[Any] | None = None,
    ) -> None:
        super().__init__(
            nullable=nullable,
            default=default,
            unique=unique,
            db_index=db_index,
            choices=choices,
        )

    def validate(self, value: Any) -> float | None:
        value = super().validate(value)
        if value is None:
            return None
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError(f"field '{self.name}' expects a float")
        return self._validate_choices(float(value))


class BooleanField(Field):
    rust_type = "boolean"

    def __init__(
        self,
        *,
        nullable: bool = False,
        default: bool = False,
        unique: bool = False,
        db_index: bool = False,
        choices: Iterable[Any] | None = None,
    ) -> None:
        super().__init__(
            nullable=nullable,
            default=default,
            unique=unique,
            db_index=db_index,
            choices=choices,
        )

    def validate(self, value: Any) -> bool | None:
        value = super().validate(value)
        if value is None:
            return None
        if not isinstance(value, bool):
            raise ValueError(f"field '{self.name}' expects a boolean")
        return self._validate_choices(value)


class ForeignKey(Field):
    rust_type = "integer"

    def __init__(
        self,
        to: type[Model] | str,
        *,
        related_name: str | None = None,
        nullable: bool = False,
        default: int | Model | None = None,
        db_index: bool = True,
    ) -> None:
        super().__init__(
            nullable=nullable,
            default=default,
            unique=False,
            db_index=db_index,
            choices=None,
        )
        self.to = to
        self.related_name = related_name
        self._owner_model: type[Model] | None = None

    def __set_name__(self, owner: type[Model], name: str) -> None:
        super().__set_name__(owner, name)
        self._owner_model = owner

    def storage_name(self) -> str:
        return f"{self.name}_id"

    def _cache_name(self) -> str:
        return f"_{self.name}_cache"

    def _coerce_related_id(self, value: Any) -> int | None:
        if value is None:
            if self.nullable:
                return None
            raise ValueError(f"field '{self.name}' cannot be null")

        if isinstance(value, bool):
            raise ValueError(f"field '{self.name}' expects an integer id or model")

        if isinstance(value, Model):
            related_model = self.resolve_related_model(strict=True)
            if not isinstance(value, related_model):
                raise ValueError(
                    f"field '{self.name}' expects an instance of {related_model.__name__}"
                )
            if value.id is None:
                raise ValueError(
                    f"field '{self.name}' expects a saved related model instance"
                )
            return value.id

        if isinstance(value, int):
            return value

        raise ValueError(f"field '{self.name}' expects an integer id or model")

    def resolve_related_model(
        self,
        *,
        owner: type[Model] | None = None,
        strict: bool = True,
    ) -> type[Model] | None:
        candidate_owner = owner or self._owner_model

        if isinstance(self.to, type):
            return self.to

        target_name = str(self.to)
        if target_name == "self":
            if candidate_owner is not None:
                return candidate_owner
            if strict:
                raise RuntimeError("ForeignKey('self') requires an owner model")
            return None

        resolved = _MODEL_REGISTRY.get(target_name)
        if resolved is not None:
            return resolved

        if strict:
            raise RuntimeError(
                f"ForeignKey field '{self.name}' references unknown model '{target_name}'"
            )
        return None

    def related_model_label(self) -> str:
        if isinstance(self.to, type):
            return self.to.__name__
        return str(self.to)

    def get_raw_id(self, instance: Model) -> int | None:
        raw = instance.__dict__.get(self.storage_name())
        if raw is None:
            return None
        if isinstance(raw, bool) or not isinstance(raw, int):
            raise ValueError(f"field '{self.name}' expects an integer id")
        return raw

    def set_raw_id(self, instance: Model, value: Any) -> None:
        raw_id = self._coerce_related_id(value)
        instance.__dict__[self.storage_name()] = raw_id

        cached = instance.__dict__.get(self._cache_name())
        if cached is None:
            return

        if raw_id is None or getattr(cached, "id", None) != raw_id:
            instance.__dict__.pop(self._cache_name(), None)

    def __get__(self, instance: Model | None, owner: type[Model]) -> Any:
        if instance is None:
            return self

        cached = instance.__dict__.get(self._cache_name())
        if cached is not None:
            return cached

        raw_id = self.get_raw_id(instance)
        if raw_id is None:
            return None

        related_model = self.resolve_related_model(owner=owner, strict=True)
        if related_model is None:
            return None

        related = related_model.objects.get(id=raw_id)
        instance.__dict__[self._cache_name()] = related
        return related

    def __set__(self, instance: Model, value: Any) -> None:
        if isinstance(value, Model):
            related_model = self.resolve_related_model(strict=True)
            if related_model is None:
                raise ValueError(f"field '{self.name}' cannot resolve related model")
            if not isinstance(value, related_model):
                raise ValueError(
                    f"field '{self.name}' expects an instance of {related_model.__name__}"
                )
            if value.id is None:
                raise ValueError(
                    f"field '{self.name}' expects a saved related model instance"
                )
            instance.__dict__[self.storage_name()] = value.id
            instance.__dict__[self._cache_name()] = value
            return

        self.set_raw_id(instance, value)

    def validate(self, value: Any) -> Any:
        return self._coerce_related_id(value)

    def to_storage_value(self, value: Any) -> int | None:
        return self._coerce_related_id(value)

    def from_storage_value(self, value: Any) -> int | None:
        return self._coerce_related_id(value)

    def value_from_instance(self, instance: Model) -> Any:
        return self.get_raw_id(instance)

    def to_record_value(self, instance: Model) -> Any:
        return self.get_raw_id(instance)

    def set_from_storage_key(self, instance: Model, value: Any) -> None:
        self.set_raw_id(instance, value)

    def validate_lookup(self, lookup: str, raw_key: str) -> None:
        allowed = {"exact", "gt", "gte", "lt", "lte", "range", "in", "isnull"}
        if lookup not in allowed:
            raise ValueError(
                f"unsupported lookup '{lookup}' for foreign key '{raw_key}'"
            )

    def normalize_lookup_value(self, lookup: str, value: Any) -> Any:
        if lookup == "isnull":
            if not isinstance(value, bool):
                raise ValueError(f"lookup '{self.name}__isnull' expects a boolean")
            return value

        if lookup == "in":
            if isinstance(value, (str, bytes)) or not isinstance(value, Iterable):
                raise ValueError(f"lookup '{self.name}__in' expects an iterable")
            return [self._coerce_related_id(item) for item in value]

        if lookup == "range":
            if isinstance(value, (str, bytes)) or not isinstance(value, Iterable):
                raise ValueError(f"lookup '{self.name}__range' expects an iterable")
            values = list(value)
            if len(values) != 2:
                raise ValueError(
                    f"lookup '{self.name}__range' expects exactly two values"
                )
            return [
                self._coerce_related_id(values[0]),
                self._coerce_related_id(values[1]),
            ]

        return self._coerce_related_id(value)

    def schema_spec(self) -> dict[str, object]:
        spec = super().schema_spec()
        spec["relation_model"] = self.related_model_label()
        if self.related_name:
            spec["related_name"] = self.related_name
        return spec


class RelatedManager:
    def __init__(
        self,
        *,
        source_model: type[Model],
        field_name: str,
        instance: Model,
    ) -> None:
        self.source_model = source_model
        self.field_name = field_name
        self.instance = instance

    def _cache_name(self) -> str:
        return f"_{self.field_name}_prefetch_cache"

    def _prefetched(self) -> list[Model] | None:
        cached = self.instance.__dict__.get(self._cache_name())
        if cached is None:
            return None
        if not isinstance(cached, list):
            return None
        return [item for item in cached if isinstance(item, self.source_model)]

    def _matches_kwargs(self, item: Model, kwargs: dict[str, object]) -> bool:
        for key, expected in kwargs.items():
            value = getattr(item, key)
            if isinstance(expected, Model):
                if getattr(value, "id", None) != getattr(expected, "id", None):
                    return False
                continue
            if value != expected:
                return False
        return True

    def get_queryset(self) -> QuerySet:
        if self.instance.id is None:
            raise ValueError("related manager requires a saved parent instance")
        return self.source_model.objects.filter(**{self.field_name: self.instance})

    def all(self) -> list[Model]:
        prefetched = self._prefetched()
        if prefetched is not None:
            return list(prefetched)
        return self.get_queryset().all()

    def filter(self, *expressions: Q, **kwargs: object) -> QuerySet:
        prefetched = self._prefetched()
        if prefetched is not None and not expressions:
            matched = [
                item for item in prefetched if self._matches_kwargs(item, kwargs)
            ]
            ids = [item.id for item in matched if isinstance(item.id, int)]
            return self.source_model.objects.filter(id__in=ids)
        return self.get_queryset().filter(*expressions, **kwargs)

    def exclude(self, *expressions: Q, **kwargs: object) -> QuerySet:
        prefetched = self._prefetched()
        if prefetched is not None and not expressions:
            excluded = [
                item for item in prefetched if not self._matches_kwargs(item, kwargs)
            ]
            ids = [item.id for item in excluded if isinstance(item.id, int)]
            return self.source_model.objects.filter(id__in=ids)
        return self.get_queryset().exclude(*expressions, **kwargs)

    def order_by(self, *fields: str) -> QuerySet:
        return self.get_queryset().order_by(*fields)

    def count(self) -> int:
        prefetched = self._prefetched()
        if prefetched is not None:
            return len(prefetched)
        return self.get_queryset().count()

    def first(self) -> Model | None:
        prefetched = self._prefetched()
        if prefetched is not None:
            return prefetched[0] if prefetched else None
        return self.get_queryset().first()

    def get(self, *expressions: Q, **kwargs: object) -> Model:
        prefetched = self._prefetched()
        if prefetched is not None and not expressions:
            matched = [
                item for item in prefetched if self._matches_kwargs(item, kwargs)
            ]
            if not matched:
                raise self.source_model.DoesNotExist(
                    f"{self.source_model.__name__} matching query does not exist"
                )
            if len(matched) > 1:
                raise self.source_model.MultipleObjectsReturned(
                    f"get() returned more than one {self.source_model.__name__}"
                )
            return matched[0]
        return self.get_queryset().get(*expressions, **kwargs)

    def create(self, **kwargs: object) -> Model:
        kwargs[self.field_name] = self.instance
        created = self.source_model.objects.create(**kwargs)
        prefetched = self._prefetched()
        if prefetched is not None:
            prefetched.append(created)
            self.instance.__dict__[self._cache_name()] = prefetched
        return created


class ReverseRelationDescriptor:
    def __init__(
        self,
        *,
        source_model: type[Model],
        field_name: str,
    ) -> None:
        self.source_model = source_model
        self.field_name = field_name

    def __get__(self, instance: Model | None, owner: type[Model]) -> Any:
        _ = owner
        if instance is None:
            return self

        return RelatedManager(
            source_model=self.source_model,
            field_name=self.field_name,
            instance=instance,
        )


def _attach_reverse_relation(source_model: type[Model], field: ForeignKey) -> bool:
    target_model = field.resolve_related_model(owner=source_model, strict=False)
    if target_model is None:
        return False

    if field.related_name == "+":
        return True

    descriptor_name = field.related_name or f"{source_model.__name__.lower()}_set"
    if hasattr(target_model, descriptor_name):
        return True

    descriptor = ReverseRelationDescriptor(
        source_model=source_model,
        field_name=field.name,
    )
    setattr(target_model, descriptor_name, descriptor)
    return True


def _finalize_pending_reverse_relations() -> None:
    unresolved: list[tuple[type[Model], ForeignKey]] = []
    for source_model, field in _PENDING_REVERSE_RELATIONS:
        if not _attach_reverse_relation(source_model, field):
            unresolved.append((source_model, field))

    _PENDING_REVERSE_RELATIONS.clear()
    _PENDING_REVERSE_RELATIONS.extend(unresolved)


class ManyToManyManager:
    def __init__(
        self,
        *,
        instance: Model,
        target_model: type[Model],
        through_model: type[Model],
        source_field_name: str,
        target_field_name: str,
        cache_name: str,
    ) -> None:
        self.instance = instance
        self.target_model = target_model
        self.through_model = through_model
        self.source_field_name = source_field_name
        self.target_field_name = target_field_name
        self.cache_name = cache_name

    def _require_saved_instance(self) -> int:
        if self.instance.id is None:
            raise ValueError("many-to-many manager requires a saved parent instance")
        return self.instance.id

    def _prefetched(self) -> list[Model] | None:
        cached = self.instance.__dict__.get(self.cache_name)
        if cached is None:
            return None
        if not isinstance(cached, list):
            return None
        return [item for item in cached if isinstance(item, self.target_model)]

    def _invalidate_prefetch_cache(self) -> None:
        self.instance.__dict__.pop(self.cache_name, None)

    def _normalize_target_ids(self, values: Iterable[object]) -> list[int]:
        normalized: list[int] = []
        seen: set[int] = set()

        for value in values:
            if isinstance(value, self.target_model):
                if value.id is None:
                    raise ValueError(
                        "many-to-many relation expects saved model instances"
                    )
                target_id = value.id
            elif isinstance(value, bool) or not isinstance(value, int):
                raise ValueError(
                    "many-to-many relation expects model instances or integer ids"
                )
            else:
                target_id = value

            if target_id in seen:
                continue
            seen.add(target_id)
            normalized.append(target_id)

        return normalized

    def _target_ids(self) -> list[int]:
        self._require_saved_instance()
        id_attr = f"{self.target_field_name}_id"
        rows = self.through_model.objects.filter(
            **{self.source_field_name: self.instance}
        ).all()
        output: list[int] = []
        seen: set[int] = set()

        for row in rows:
            value = getattr(row, id_attr, None)
            if (
                isinstance(value, int)
                and not isinstance(value, bool)
                and value not in seen
            ):
                seen.add(value)
                output.append(value)

        return output

    def get_queryset(self) -> QuerySet:
        ids = self._target_ids()
        if not ids:
            return self.target_model.objects.filter(id__in=[])
        return self.target_model.objects.filter(id__in=ids)

    def all(self) -> list[Model]:
        prefetched = self._prefetched()
        if prefetched is not None:
            return list(prefetched)
        return self.get_queryset().all()

    def filter(self, *expressions: Q, **kwargs: object) -> QuerySet:
        prefetched = self._prefetched()
        if prefetched is not None and not expressions:
            matched: list[int] = []
            for item in prefetched:
                valid = True
                for key, expected in kwargs.items():
                    value = getattr(item, key)
                    if isinstance(expected, Model):
                        if getattr(value, "id", None) != getattr(expected, "id", None):
                            valid = False
                            break
                    elif value != expected:
                        valid = False
                        break
                if valid and isinstance(item.id, int):
                    matched.append(item.id)
            return self.target_model.objects.filter(id__in=matched)

        return self.get_queryset().filter(*expressions, **kwargs)

    def exclude(self, *expressions: Q, **kwargs: object) -> QuerySet:
        prefetched = self._prefetched()
        if prefetched is not None and not expressions:
            if not kwargs:
                ids = [item.id for item in prefetched if isinstance(item.id, int)]
                return self.target_model.objects.filter(id__in=ids)

            matched: list[int] = []
            for item in prefetched:
                valid = True
                for key, expected in kwargs.items():
                    value = getattr(item, key)
                    if isinstance(expected, Model):
                        if getattr(value, "id", None) != getattr(expected, "id", None):
                            valid = False
                            break
                    elif value != expected:
                        valid = False
                        break
                if not valid and isinstance(item.id, int):
                    matched.append(item.id)
            return self.target_model.objects.filter(id__in=matched)

        return self.get_queryset().exclude(*expressions, **kwargs)

    def order_by(self, *fields: str) -> QuerySet:
        return self.get_queryset().order_by(*fields)

    def count(self) -> int:
        prefetched = self._prefetched()
        if prefetched is not None:
            return len(prefetched)

        self._require_saved_instance()
        return self.through_model.objects.filter(
            **{self.source_field_name: self.instance}
        ).count()

    def first(self) -> Model | None:
        prefetched = self._prefetched()
        if prefetched is not None:
            return prefetched[0] if prefetched else None
        return self.get_queryset().first()

    def get(self, *expressions: Q, **kwargs: object) -> Model:
        prefetched = self._prefetched()
        if prefetched is not None and not expressions:
            matched = self.filter(**kwargs).all()
            if not matched:
                raise self.target_model.DoesNotExist(
                    f"{self.target_model.__name__} matching query does not exist"
                )
            if len(matched) > 1:
                raise self.target_model.MultipleObjectsReturned(
                    f"get() returned more than one {self.target_model.__name__}"
                )
            return matched[0]

        return self.get_queryset().get(*expressions, **kwargs)

    def create(self, **kwargs: object) -> Model:
        created = self.target_model.objects.create(**kwargs)
        self.add(created)
        return created

    def add(self, *values: object) -> None:
        self._require_saved_instance()
        target_ids = self._normalize_target_ids(values)
        if not target_ids:
            return

        existing = set(
            self.through_model.objects.filter(
                **{
                    self.source_field_name: self.instance,
                    f"{self.target_field_name}__in": target_ids,
                }
            ).values_list(f"{self.target_field_name}_id", flat=True)
        )

        for target_id in target_ids:
            if target_id in existing:
                continue

            self.through_model.objects.create(
                **{
                    self.source_field_name: self.instance,
                    self.target_field_name: target_id,
                }
            )

        self._invalidate_prefetch_cache()

    def remove(self, *values: object) -> int:
        self._require_saved_instance()
        target_ids = self._normalize_target_ids(values)
        if not target_ids:
            return 0

        deleted = self.through_model.objects.filter(
            **{
                self.source_field_name: self.instance,
                f"{self.target_field_name}__in": target_ids,
            }
        ).delete()
        self._invalidate_prefetch_cache()
        return deleted

    def clear(self) -> int:
        self._require_saved_instance()
        deleted = self.through_model.objects.filter(
            **{self.source_field_name: self.instance}
        ).delete()
        self._invalidate_prefetch_cache()
        return deleted

    def set(self, values: Iterable[object], *, clear: bool = False) -> None:
        self._require_saved_instance()
        target_ids = self._normalize_target_ids(values)

        if clear:
            self.clear()
            if not target_ids:
                self._invalidate_prefetch_cache()
                return
            existing = set()
        else:
            existing = set(
                self.through_model.objects.filter(
                    **{self.source_field_name: self.instance}
                ).values_list(f"{self.target_field_name}_id", flat=True)
            )

        incoming = set(target_ids)
        remove_ids = [value for value in existing if value not in incoming]
        add_ids = [value for value in target_ids if value not in existing]

        if remove_ids:
            self.through_model.objects.filter(
                **{
                    self.source_field_name: self.instance,
                    f"{self.target_field_name}_id__in": remove_ids,
                }
            ).delete()

        if add_ids:
            through_instances = [
                self.through_model(
                    **{
                        self.source_field_name: self.instance,
                        self.target_field_name: tid,
                    }
                )
                for tid in add_ids
            ]
            self.through_model.objects.bulk_create(through_instances)

        self._invalidate_prefetch_cache()


class ManyToManyField:
    def __init__(
        self,
        to: type[Model] | str,
        *,
        related_name: str | None = None,
        through: type[Model] | str | None = None,
    ) -> None:
        self.to = to
        self.related_name = related_name
        self.name = ""
        self._owner_model: type[Model] | None = None
        self._through_model: type[Model] | None = None
        self._through_source_field_name = ""
        self._through_target_field_name = ""

        if through is not None:
            self._through_model = self._resolve_through_model(through)

    def _resolve_through_model(self, through: type[Model] | str) -> type[Model]:
        if isinstance(through, type):
            if not issubclass(through, Model):
                raise ValueError("through model must be a Model subclass")
            return through

        resolved = _MODEL_REGISTRY.get(str(through))
        if resolved is not None:
            if not issubclass(resolved, Model):
                raise ValueError("through model must be a Model subclass")
            return resolved

        raise RuntimeError(
            f"ManyToManyField through model '{through}' not found in registry"
        )

    def __set_name__(self, owner: type[Model], name: str) -> None:
        self._owner_model = owner
        self.name = name

    def __get__(self, instance: Model | None, owner: type[Model]) -> Any:
        _ = owner
        if instance is None:
            return self

        related_model = self.resolve_related_model(strict=True)
        if related_model is None:
            raise RuntimeError(
                f"ManyToMany field '{self.name}' cannot resolve related model"
            )

        return ManyToManyManager(
            instance=instance,
            target_model=related_model,
            through_model=self.through_model(),
            source_field_name=self.source_field_name(),
            target_field_name=self.target_field_name(),
            cache_name=self.cache_name(),
        )

    def __set__(self, instance: Model, value: object) -> None:
        _ = (instance, value)
        raise AttributeError(
            "direct assignment to many-to-many fields is not supported; use .set()"
        )

    def bind_owner(self, owner: type[Model]) -> None:
        self._owner_model = owner

    def cache_name(self) -> str:
        return f"_{self.name}_prefetch_cache"

    def through_table_name(self) -> str:
        owner = self._owner_model
        if owner is None:
            raise RuntimeError("many-to-many field is not bound to a model")
        return f"{owner.table_name()}_{self.name}"

    def source_field_name(self) -> str:
        self._ensure_through_model()
        return self._through_source_field_name

    def target_field_name(self) -> str:
        self._ensure_through_model()
        return self._through_target_field_name

    def resolve_related_model(self, *, strict: bool = True) -> type[Model] | None:
        owner = self._owner_model

        if isinstance(self.to, type):
            return self.to

        target_name = str(self.to)
        if target_name == "self":
            if owner is not None:
                return owner
            if strict:
                raise RuntimeError("ManyToManyField('self') requires an owner model")
            return None

        resolved = _MODEL_REGISTRY.get(target_name)
        if resolved is not None:
            return resolved

        if strict:
            raise RuntimeError(
                f"ManyToManyField '{self.name}' references unknown model '{target_name}'"
            )
        return None

    def _ensure_through_model(self) -> type[Model]:
        if self._through_model is not None:
            if (
                not self._through_source_field_name
                or not self._through_target_field_name
            ):
                self._infer_through_field_names()
            return self._through_model

        owner = self._owner_model
        if owner is None:
            raise RuntimeError("many-to-many field is not bound to a model")

        related = self.resolve_related_model(strict=True)
        if related is None:
            raise RuntimeError(
                f"ManyToMany field '{self.name}' cannot resolve related model"
            )

        source_name = owner.__name__.lower()
        target_name = related.__name__.lower()
        if source_name == target_name:
            source_name = "from_object"
            target_name = "to_object"

        class_name = f"{owner.__name__}{self.name.title()}Through"
        namespace: dict[str, object] = {
            "__module__": owner.__module__,
            "__ferrum_internal_through_model__": True,
            source_name: ForeignKey(owner, related_name="+"),
            target_name: ForeignKey(related, related_name="+"),
        }

        class Meta:
            table_name = self.through_table_name()
            app_label = owner.app_label()

        namespace["Meta"] = Meta

        through_model = ModelMeta(class_name, (Model,), namespace)
        self._through_model = through_model
        self._through_source_field_name = source_name
        self._through_target_field_name = target_name
        return through_model

    def _infer_through_field_names(self) -> None:
        through = self._through_model
        if through is None:
            return

        owner = self._owner_model
        related = self.resolve_related_model(strict=True)
        if owner is None or related is None:
            return

        found_fields: list[tuple[str, type[Model]]] = []
        for field_name, field in through._meta_fields.items():
            if isinstance(field, ForeignKey):
                resolved = field.resolve_related_model(owner=through, strict=False)
                if resolved is owner:
                    found_fields.append((field_name, owner))
                elif resolved is related:
                    found_fields.append((field_name, related))

        if len(found_fields) >= 2:
            for field_name, model in found_fields:
                if model is owner:
                    self._through_source_field_name = field_name
                elif model is related:
                    self._through_target_field_name = field_name

    def through_model(self) -> type[Model]:
        return self._ensure_through_model()

    def ensure_through_table(self) -> None:
        self.through_model().create_table()


class ReverseManyToManyDescriptor:
    def __init__(
        self,
        *,
        source_model: type[Model],
        field: ManyToManyField,
        relation_name: str,
    ) -> None:
        self.source_model = source_model
        self.field = field
        self.relation_name = relation_name

    def cache_name(self) -> str:
        return f"_{self.relation_name}_prefetch_cache"

    def __get__(self, instance: Model | None, owner: type[Model]) -> Any:
        _ = owner
        if instance is None:
            return self

        return ManyToManyManager(
            instance=instance,
            target_model=self.source_model,
            through_model=self.field.through_model(),
            source_field_name=self.field.target_field_name(),
            target_field_name=self.field.source_field_name(),
            cache_name=self.cache_name(),
        )


def _attach_many_to_many_relation(
    source_model: type[Model], field: ManyToManyField
) -> bool:
    target_model = field.resolve_related_model(strict=False)
    if target_model is None:
        return False

    field.bind_owner(source_model)
    field.through_model()

    if field.related_name == "+":
        return True

    descriptor_name = field.related_name or f"{source_model.__name__.lower()}_set"
    if hasattr(target_model, descriptor_name):
        return True

    descriptor = ReverseManyToManyDescriptor(
        source_model=source_model,
        field=field,
        relation_name=descriptor_name,
    )
    setattr(target_model, descriptor_name, descriptor)
    return True


def _finalize_pending_many_to_many_relations() -> None:
    unresolved: list[tuple[type[Model], ManyToManyField]] = []
    for source_model, field in _PENDING_MANY_TO_MANY_RELATIONS:
        if not _attach_many_to_many_relation(source_model, field):
            unresolved.append((source_model, field))

    _PENDING_MANY_TO_MANY_RELATIONS.clear()
    _PENDING_MANY_TO_MANY_RELATIONS.extend(unresolved)


class QuerySet:
    def __init__(
        self,
        model_cls: type[Model],
        query_plan: list[dict[str, object]] | None = None,
        python_predicates: list[tuple[dict[str, object], bool]] | None = None,
        select_related_fields: tuple[str, ...] | None = None,
        prefetch_related_fields: tuple[str, ...] | None = None,
        slice_bounds: tuple[int, int | None] | None = None,
        distinct_columns: tuple[str, ...] | None = None,
    ) -> None:
        self.model_cls = model_cls
        self.query_plan = list(query_plan or [])
        self.python_predicates = list(python_predicates or [])
        self.select_related_fields = tuple(select_related_fields or ())
        self.prefetch_related_fields = tuple(prefetch_related_fields or ())
        self.slice_bounds = slice_bounds
        self.distinct_columns = distinct_columns

    def _clone_with_step(self, step: dict[str, object]) -> QuerySet:
        plan = [*self.query_plan, step]
        return QuerySet(
            self.model_cls,
            plan,
            self.python_predicates,
            self.select_related_fields,
            self.prefetch_related_fields,
            self.slice_bounds,
            self.distinct_columns,
        )

    def _clone_with_python_predicate(
        self,
        predicate: dict[str, object],
        include: bool,
    ) -> QuerySet:
        predicates = [*self.python_predicates, (predicate, include)]
        return QuerySet(
            self.model_cls,
            self.query_plan,
            predicates,
            self.select_related_fields,
            self.prefetch_related_fields,
            self.slice_bounds,
            self.distinct_columns,
        )

    def _clone_with_select_related(self, fields: tuple[str, ...]) -> QuerySet:
        merged = list(self.select_related_fields)
        for field in fields:
            if field not in merged:
                merged.append(field)

        return QuerySet(
            self.model_cls,
            self.query_plan,
            self.python_predicates,
            tuple(merged),
            self.prefetch_related_fields,
            self.slice_bounds,
            self.distinct_columns,
        )

    def _clone_with_prefetch_related(self, fields: tuple[str, ...]) -> QuerySet:
        merged = list(self.prefetch_related_fields)
        for field in fields:
            if field not in merged:
                merged.append(field)

        return QuerySet(
            self.model_cls,
            self.query_plan,
            self.python_predicates,
            self.select_related_fields,
            tuple(merged),
            self.slice_bounds,
            self.distinct_columns,
        )

    def _clone_with_slice(self, start: int, stop: int | None) -> QuerySet:
        return QuerySet(
            self.model_cls,
            self.query_plan,
            self.python_predicates,
            self.select_related_fields,
            self.prefetch_related_fields,
            (start, stop),
            self.distinct_columns,
        )

    def _clone_with_distinct(self, columns: tuple[str, ...]) -> QuerySet:
        return QuerySet(
            self.model_cls,
            self.query_plan,
            self.python_predicates,
            self.select_related_fields,
            self.prefetch_related_fields,
            self.slice_bounds,
            columns,
        )

    def _parse_lookup_key(self, raw_key: str) -> tuple[str, str, Field | None]:
        if "__" in raw_key:
            field_key, lookup = raw_key.rsplit("__", 1)
        else:
            field_key, lookup = raw_key, "exact"

        field, column = self.model_cls.resolve_field_and_column(field_key)
        if lookup not in _SUPPORTED_LOOKUPS:
            raise ValueError(f"unsupported lookup '{lookup}' for key '{raw_key}'")

        if field is not None:
            field.validate_lookup(lookup, raw_key)

        return column, lookup, field

    def _conditions_from_kwargs(
        self, kwargs: dict[str, object]
    ) -> list[dict[str, object]]:
        conditions: list[dict[str, object]] = []

        for raw_key, raw_value in kwargs.items():
            column, lookup, field = self._parse_lookup_key(raw_key)

            condition: dict[str, object] = {
                "field": column,
                "lookup": lookup,
            }

            if field is not None:
                condition["value"] = field.normalize_lookup_value(lookup, raw_value)
            elif lookup == "in":
                if isinstance(raw_value, (str, bytes)) or not isinstance(
                    raw_value, Iterable
                ):
                    raise ValueError(f"lookup '{raw_key}' expects an iterable")
                condition["value"] = list(raw_value)
            elif lookup == "range":
                if isinstance(raw_value, (str, bytes)) or not isinstance(
                    raw_value, Iterable
                ):
                    raise ValueError(f"lookup '{raw_key}' expects an iterable")
                values = list(raw_value)
                if len(values) != 2:
                    raise ValueError(f"lookup '{raw_key}' expects exactly two values")
                condition["value"] = values
            elif lookup == "isnull":
                if not isinstance(raw_value, bool):
                    raise ValueError(f"lookup '{raw_key}' expects a boolean")
                condition["value"] = raw_value
            else:
                condition["value"] = raw_value

            conditions.append(condition)

        return conditions

    def _compile_q(self, expression: Q) -> dict[str, object]:
        children: list[dict[str, object]] = []

        for child in expression.children:
            if isinstance(child, Q):
                children.append(self._compile_q(child))
                continue

            child_conditions = self._conditions_from_kwargs(child)
            for condition in child_conditions:
                children.append(
                    {
                        "type": "condition",
                        "field": condition["field"],
                        "lookup": condition["lookup"],
                        "value": condition["value"],
                    }
                )

        node: dict[str, object] = {
            "type": "group",
            "connector": expression.connector,
            "children": children,
            "negated": expression.negated,
        }
        return node

    def _evaluate_condition(
        self, row: dict[str, object], condition: dict[str, object]
    ) -> bool:
        field = str(condition["field"])
        lookup = str(condition["lookup"])
        expected = condition["value"]
        current = row.get(field)

        if lookup == "exact":
            return current == expected
        if lookup == "gt":
            return current is not None and current > expected
        if lookup == "gte":
            return current is not None and current >= expected
        if lookup == "lt":
            return current is not None and current < expected
        if lookup == "lte":
            return current is not None and current <= expected
        if lookup == "contains":
            if not isinstance(current, str) or not isinstance(expected, str):
                return False
            return expected in current
        if lookup == "icontains":
            if not isinstance(current, str) or not isinstance(expected, str):
                return False
            return expected.casefold() in current.casefold()
        if lookup == "startswith":
            if not isinstance(current, str) or not isinstance(expected, str):
                return False
            return current.startswith(expected)
        if lookup == "istartswith":
            if not isinstance(current, str) or not isinstance(expected, str):
                return False
            return current.casefold().startswith(expected.casefold())
        if lookup == "endswith":
            if not isinstance(current, str) or not isinstance(expected, str):
                return False
            return current.endswith(expected)
        if lookup == "iendswith":
            if not isinstance(current, str) or not isinstance(expected, str):
                return False
            return current.casefold().endswith(expected.casefold())
        if lookup == "range":
            if not isinstance(expected, list) or len(expected) != 2:
                return False
            lower, upper = expected
            if current is None:
                return False
            return lower <= current <= upper
        if lookup == "in":
            if not isinstance(expected, list):
                return False
            return current in expected
        if lookup == "isnull":
            if not isinstance(expected, bool):
                return False
            return (current is None) if expected else (current is not None)

        raise ValueError(f"unsupported lookup '{lookup}'")

    def _evaluate_predicate(
        self, row: dict[str, object], predicate: dict[str, object]
    ) -> bool:
        node_type = predicate.get("type")

        if node_type == "condition":
            return self._evaluate_condition(row, predicate)

        if node_type != "group":
            raise RuntimeError("invalid predicate node")

        connector = predicate.get("connector", "and")
        children = predicate.get("children", [])
        negated = bool(predicate.get("negated", False))

        if not isinstance(children, list):
            raise RuntimeError("invalid predicate children")

        results = [self._evaluate_predicate(row, child) for child in children]
        if connector == "or":
            value = any(results)
        else:
            value = all(results)

        if negated:
            return not value
        return value

    def _apply_python_predicates(
        self, rows: list[dict[str, object]]
    ) -> list[dict[str, object]]:
        if not self.python_predicates:
            return rows

        output: list[dict[str, object]] = []

        for row in rows:
            keep = True
            for predicate, include in self.python_predicates:
                matched = self._evaluate_predicate(row, predicate)
                if include and not matched:
                    keep = False
                    break
                if not include and matched:
                    keep = False
                    break

            if keep:
                output.append(row)

        return output

    def _apply_distinct(self, rows: list[dict[str, object]]) -> list[dict[str, object]]:
        if self.distinct_columns is None:
            return rows

        seen: set[tuple[object, ...]] = set()
        output: list[dict[str, object]] = []
        distinct_columns = self.distinct_columns

        for row in rows:
            if not distinct_columns:
                marker = tuple(sorted(row.items()))
            else:
                marker = tuple(row.get(column) for column in distinct_columns)

            if marker in seen:
                continue
            seen.add(marker)
            output.append(row)

        return output

    def _apply_slice_bounds(
        self, rows: list[dict[str, object]]
    ) -> list[dict[str, object]]:
        if self.slice_bounds is None:
            return rows

        start, stop = self.slice_bounds
        return rows[start:stop]

    def _fetch_row_dicts(self) -> list[dict[str, object]]:
        result = self._execute_terminal("all")

        if result is None:
            return []

        if not isinstance(result, list):
            raise RuntimeError("expected list result for .all()")

        rows: list[dict[str, object]] = []
        for item in result:
            if not isinstance(item, dict):
                raise RuntimeError("expected dict rows for .all()")
            rows.append(item)

        rows = self._apply_python_predicates(rows)
        rows = self._apply_distinct(rows)
        rows = self._apply_slice_bounds(rows)
        return rows

    def _execute_terminal(
        self,
        op: str,
        extra_conditions: dict[str, object] | None = None,
        updates: dict[str, object] | None = None,
        aggregates: list[dict[str, object]] | None = None,
    ) -> object:
        terminal_step: dict[str, object] = {"op": op}

        if extra_conditions:
            terminal_step["conditions"] = self._conditions_from_kwargs(extra_conditions)

        if updates:
            terminal_step["updates"] = updates
        if aggregates:
            terminal_step["aggregates"] = aggregates

        query_ir = QueryIR.from_steps([*self.query_plan, terminal_step])
        payload = query_ir.to_json()

        return _execute_query(
            self.model_cls.table_name(),
            payload,
            self.model_cls.field_type_map(),
        )

    def _resolve_aggregate_entries(
        self,
        *aggregates: Aggregate,
        **named_aggregates: Aggregate,
    ) -> list[dict[str, object]]:
        entries: list[dict[str, object]] = []
        aliases: set[str] = set()

        for aggregate in aggregates:
            if not isinstance(aggregate, Aggregate):
                raise TypeError(
                    "aggregate() positional arguments must be Aggregate instances"
                )
            alias = aggregate.default_alias()
            if alias in aliases:
                raise ValueError(f"duplicate aggregate alias '{alias}'")
            aliases.add(alias)
            entries.append(self._aggregate_to_plan_entry(alias, aggregate))

        for alias, aggregate in named_aggregates.items():
            if not isinstance(aggregate, Aggregate):
                raise TypeError(
                    "aggregate() keyword arguments must map alias names to Aggregate instances"
                )
            if not isinstance(alias, str) or not alias.isidentifier():
                raise ValueError("aggregate aliases must be valid identifiers")
            if alias in aliases:
                raise ValueError(f"duplicate aggregate alias '{alias}'")
            aliases.add(alias)
            entries.append(self._aggregate_to_plan_entry(alias, aggregate))

        if not entries:
            raise ValueError("aggregate() requires at least one Aggregate expression")

        return entries

    def _aggregate_to_plan_entry(
        self,
        alias: str,
        aggregate: Aggregate,
    ) -> dict[str, object]:
        field = aggregate.field
        if field != "*":
            _, column = self.model_cls.resolve_field_and_column(field)
        else:
            column = "*"

        return {
            "alias": alias,
            "function": aggregate.function,
            "field": column,
        }

    def _compute_python_aggregate(
        self,
        rows: list[dict[str, object]],
        function: str,
        field: str,
    ) -> object:
        if field == "*":
            if function != "count":
                raise ValueError(f"aggregate '{function}' does not support '*' field")
            return len(rows)

        values = [row.get(field) for row in rows if row.get(field) is not None]

        if function == "count":
            return len(values)
        if function == "sum":
            return sum(values) if values else None
        if function == "avg":
            return (sum(values) / len(values)) if values else None
        if function == "min":
            return min(values) if values else None
        if function == "max":
            return max(values) if values else None

        raise ValueError(f"unsupported aggregate function '{function}'")

    def _normalize_projection(self, fields: tuple[str, ...]) -> list[tuple[str, str]]:
        if not fields:
            output: list[tuple[str, str]] = [("id", "id")]
            for field_name, field in self.model_cls._meta_fields.items():
                output.append((field_name, field.storage_name()))
            return output

        output: list[tuple[str, str]] = []
        for field_name in fields:
            if not isinstance(field_name, str) or not field_name:
                raise ValueError("projection fields must be non-empty strings")
            _, column = self.model_cls.resolve_field_and_column(field_name)
            output.append((field_name, column))
        return output

    def __getitem__(self, index: slice | int) -> QuerySet | Model:
        if isinstance(index, slice):
            if index.step not in (None, 1):
                raise ValueError("slice step is not supported")
            start = 0 if index.start is None else index.start
            stop = index.stop
            if start < 0 or (stop is not None and stop < 0):
                raise ValueError("negative slicing is not supported")
            return self._clone_with_slice(start, stop)

        if not isinstance(index, int):
            raise TypeError("QuerySet indices must be integers or slices")
        if index < 0:
            raise ValueError("negative indexing is not supported")

        rows = self._clone_with_slice(index, index + 1).all()
        if not rows:
            raise IndexError("QuerySet index out of range")
        return rows[0]

    def _normalize_update_values(self, kwargs: dict[str, object]) -> dict[str, object]:
        if not kwargs:
            raise ValueError("update() requires at least one field")

        updates: dict[str, object] = {}
        for raw_key, raw_value in kwargs.items():
            field, column = self.model_cls.resolve_field_and_column(raw_key)
            if column == "id":
                raise ValueError("cannot update the primary key field 'id'")

            if field is None:
                raise ValueError(
                    f"unknown field '{raw_key}' for {self.model_cls.__name__}"
                )

            updates[column] = field.to_storage_value(raw_value)

        return updates

    def _ids_for_python_filtered_queryset(self) -> list[int]:
        ids = [instance.id for instance in self.all()]
        return [row_id for row_id in ids if isinstance(row_id, int)]

    def _apply_select_related(self, instances: list[Model]) -> None:
        if not instances or not self.select_related_fields:
            return

        for field_name in self.select_related_fields:
            field = self.model_cls._meta_fields.get(field_name)
            if not isinstance(field, ForeignKey):
                raise ValueError(
                    f"select_related field '{field_name}' is not a ForeignKey on "
                    f"{self.model_cls.__name__}"
                )

            related_ids = {
                field.get_raw_id(instance)
                for instance in instances
                if field.get_raw_id(instance) is not None
            }
            if not related_ids:
                continue

            related_model = field.resolve_related_model(
                owner=self.model_cls, strict=True
            )
            if related_model is None:
                continue

            payload = QueryIR.from_steps(
                [
                    {
                        "op": "filter",
                        "conditions": [
                            {
                                "field": "id",
                                "lookup": "in",
                                "value": sorted(related_ids),
                            }
                        ],
                    },
                    {"op": "all"},
                ]
            )
            plan_json = payload.to_json()
            related_result = _execute_query(
                related_model.table_name(),
                plan_json,
                related_model.field_type_map(),
            )
            if not isinstance(related_result, list):
                raise RuntimeError("expected list result for select_related lookup")

            related_rows = []
            for item in related_result:
                if not isinstance(item, dict):
                    raise RuntimeError("expected dict rows for select_related lookup")
                related_rows.append(related_model.from_row(item))

            related_by_id = {
                row.id: row for row in related_rows if isinstance(row.id, int)
            }

            for instance in instances:
                raw_id = field.get_raw_id(instance)
                if raw_id is None:
                    continue
                cached = related_by_id.get(raw_id)
                if cached is not None:
                    instance.__dict__[field._cache_name()] = cached

    def _apply_prefetch_related(self, instances: list[Model]) -> None:
        if not instances or not self.prefetch_related_fields:
            return

        for raw in self.prefetch_related_fields:
            forward_field = self.model_cls._meta_fields.get(raw)
            if isinstance(forward_field, ForeignKey):
                related_ids = {
                    forward_field.get_raw_id(instance)
                    for instance in instances
                    if forward_field.get_raw_id(instance) is not None
                }
                if not related_ids:
                    continue

                related_model = forward_field.resolve_related_model(
                    owner=self.model_cls, strict=True
                )
                if related_model is None:
                    continue

                related = related_model.objects.filter(id__in=sorted(related_ids)).all()
                related_by_id = {
                    row.id: row for row in related if isinstance(row.id, int)
                }
                for instance in instances:
                    related_id = forward_field.get_raw_id(instance)
                    if related_id is None:
                        continue
                    resolved = related_by_id.get(related_id)
                    if resolved is not None:
                        instance.__dict__[forward_field._cache_name()] = resolved
                continue

            forward_m2m = self.model_cls._meta_many_to_many.get(raw)
            if isinstance(forward_m2m, ManyToManyField):
                parent_ids = [
                    instance.id
                    for instance in instances
                    if isinstance(instance.id, int)
                ]
                if not parent_ids:
                    continue

                through_model = forward_m2m.through_model()
                source_name = forward_m2m.source_field_name()
                target_name = forward_m2m.target_field_name()
                through_rows = through_model.objects.filter(
                    **{f"{source_name}__in": parent_ids}
                ).all()

                related_ids: set[int] = set()
                for row in through_rows:
                    target_id = getattr(row, f"{target_name}_id", None)
                    if isinstance(target_id, int):
                        related_ids.add(target_id)

                if not related_ids:
                    continue

                related_model = forward_m2m.resolve_related_model(strict=True)
                if related_model is None:
                    continue

                related = related_model.objects.filter(id__in=sorted(related_ids)).all()
                related_by_id = {
                    row.id: row for row in related if isinstance(row.id, int)
                }

                grouped: dict[int, list[Model]] = {
                    parent_id: [] for parent_id in parent_ids
                }
                for row in through_rows:
                    source_id = getattr(row, f"{source_name}_id", None)
                    target_id = getattr(row, f"{target_name}_id", None)
                    if not isinstance(source_id, int) or not isinstance(target_id, int):
                        continue
                    related_item = related_by_id.get(target_id)
                    if related_item is not None:
                        grouped.setdefault(source_id, []).append(related_item)

                cache_name = forward_m2m.cache_name()
                for instance in instances:
                    instance_id = instance.id
                    if isinstance(instance_id, int):
                        instance.__dict__[cache_name] = grouped.get(instance_id, [])
                continue

            descriptor = getattr(self.model_cls, raw, None)
            if isinstance(descriptor, ReverseRelationDescriptor):
                parent_ids = [
                    instance.id
                    for instance in instances
                    if isinstance(instance.id, int)
                ]
                if not parent_ids:
                    continue

                children = descriptor.source_model.objects.filter(
                    **{f"{descriptor.field_name}__in": parent_ids}
                ).all()
                grouped: dict[int, list[Model]] = {
                    parent_id: [] for parent_id in parent_ids
                }
                for child in children:
                    parent = getattr(child, descriptor.field_name)
                    parent_id = getattr(parent, "id", None)
                    if isinstance(parent_id, int):
                        grouped.setdefault(parent_id, []).append(child)

                cache_name = f"_{descriptor.field_name}_prefetch_cache"
                for instance in instances:
                    instance_id = instance.id
                    if isinstance(instance_id, int):
                        instance.__dict__[cache_name] = grouped.get(instance_id, [])
                continue

            if isinstance(descriptor, ReverseManyToManyDescriptor):
                parent_ids = [
                    instance.id
                    for instance in instances
                    if isinstance(instance.id, int)
                ]
                if not parent_ids:
                    continue

                through_model = descriptor.field.through_model()
                source_name = descriptor.field.target_field_name()
                target_name = descriptor.field.source_field_name()
                through_rows = through_model.objects.filter(
                    **{f"{source_name}__in": parent_ids}
                ).all()

                related_ids: set[int] = set()
                for row in through_rows:
                    target_id = getattr(row, f"{target_name}_id", None)
                    if isinstance(target_id, int):
                        related_ids.add(target_id)

                if not related_ids:
                    continue

                related = descriptor.source_model.objects.filter(
                    id__in=sorted(related_ids)
                ).all()
                related_by_id = {
                    row.id: row for row in related if isinstance(row.id, int)
                }

                grouped: dict[int, list[Model]] = {
                    parent_id: [] for parent_id in parent_ids
                }
                for row in through_rows:
                    source_id = getattr(row, f"{source_name}_id", None)
                    target_id = getattr(row, f"{target_name}_id", None)
                    if not isinstance(source_id, int) or not isinstance(target_id, int):
                        continue
                    related_item = related_by_id.get(target_id)
                    if related_item is not None:
                        grouped.setdefault(source_id, []).append(related_item)

                cache_name = descriptor.cache_name()
                for instance in instances:
                    instance_id = instance.id
                    if isinstance(instance_id, int):
                        instance.__dict__[cache_name] = grouped.get(instance_id, [])
                continue

            raise ValueError(
                f"prefetch_related field '{raw}' is not a relation on "
                f"{self.model_cls.__name__}"
            )

    def filter(self, *expressions: Q, **kwargs: object) -> QuerySet:
        result = self

        if kwargs:
            result = result._clone_with_step(
                {
                    "op": "filter",
                    "conditions": self._conditions_from_kwargs(kwargs),
                }
            )

        for expression in expressions:
            if not isinstance(expression, Q):
                raise TypeError("filter() positional arguments must be Q objects")
            result = result._clone_with_python_predicate(
                result._compile_q(expression),
                include=True,
            )

        return result

    def exclude(self, *expressions: Q, **kwargs: object) -> QuerySet:
        result = self

        if kwargs:
            result = result._clone_with_step(
                {
                    "op": "exclude",
                    "conditions": self._conditions_from_kwargs(kwargs),
                }
            )

        for expression in expressions:
            if not isinstance(expression, Q):
                raise TypeError("exclude() positional arguments must be Q objects")
            result = result._clone_with_python_predicate(
                result._compile_q(expression),
                include=False,
            )

        return result

    def order_by(self, *fields: str) -> QuerySet:
        if not fields:
            return self

        normalized_fields: list[str] = []
        for field in fields:
            if not isinstance(field, str) or not field:
                raise ValueError("order_by fields must be non-empty strings")

            descending = field.startswith("-")
            field_token = field[1:] if descending else field
            _, column = self.model_cls.resolve_field_and_column(field_token)
            normalized_fields.append(f"-{column}" if descending else column)

        return self._clone_with_step(
            {
                "op": "order_by",
                "fields": normalized_fields,
            }
        )

    def limit(self, value: int) -> QuerySet:
        if isinstance(value, bool) or not isinstance(value, int):
            raise ValueError("limit value must be an integer")
        if value < 0:
            raise ValueError("limit value cannot be negative")

        return self._clone_with_step(
            {
                "op": "limit",
                "value": value,
            }
        )

    def select_related(self, *fields: str) -> QuerySet:
        if not fields:
            fields = tuple(
                name
                for name, field in self.model_cls._meta_fields.items()
                if isinstance(field, ForeignKey)
            )

        normalized: list[str] = []
        for raw in fields:
            if not isinstance(raw, str) or not raw:
                raise ValueError("select_related fields must be non-empty strings")

            field = self.model_cls._meta_fields.get(raw)
            if not isinstance(field, ForeignKey):
                raise ValueError(
                    f"select_related field '{raw}' is not a ForeignKey on "
                    f"{self.model_cls.__name__}"
                )

            normalized.append(raw)

        return self._clone_with_select_related(tuple(normalized))

    def prefetch_related(self, *fields: str) -> QuerySet:
        if not fields:
            fields = tuple(
                name
                for name, value in self.model_cls.__dict__.items()
                if isinstance(
                    value, (ReverseRelationDescriptor, ReverseManyToManyDescriptor)
                )
            )

        normalized: list[str] = []
        for raw in fields:
            if not isinstance(raw, str) or not raw:
                raise ValueError("prefetch_related fields must be non-empty strings")

            field = self.model_cls._meta_fields.get(raw)
            if isinstance(field, ForeignKey):
                normalized.append(raw)
                continue

            m2m_field = self.model_cls._meta_many_to_many.get(raw)
            if isinstance(m2m_field, ManyToManyField):
                normalized.append(raw)
                continue

            descriptor = getattr(self.model_cls, raw, None)
            if not isinstance(
                descriptor,
                (ReverseRelationDescriptor, ReverseManyToManyDescriptor),
            ):
                raise ValueError(
                    f"prefetch_related field '{raw}' is not a relation on "
                    f"{self.model_cls.__name__}"
                )

            normalized.append(raw)

        return self._clone_with_prefetch_related(tuple(normalized))

    def get(self, *expressions: Q, **kwargs: object) -> Model:
        queryset = self.filter(*expressions, **kwargs)

        if (
            queryset.python_predicates
            or queryset.slice_bounds is not None
            or queryset.distinct_columns is not None
        ):
            rows = queryset.all()
            if not rows:
                raise self.model_cls.DoesNotExist(
                    f"{self.model_cls.__name__} matching query does not exist"
                )
            if len(rows) > 1:
                raise self.model_cls.MultipleObjectsReturned(
                    f"get() returned more than one {self.model_cls.__name__}"
                )
            return rows[0]

        try:
            result = queryset._execute_terminal("get")
        except RuntimeError as err:
            if "multiple objects returned" in str(err).lower():
                raise self.model_cls.MultipleObjectsReturned(
                    f"get() returned more than one {self.model_cls.__name__}"
                ) from err
            raise

        if result is None:
            raise self.model_cls.DoesNotExist(
                f"{self.model_cls.__name__} matching query does not exist"
            )

        if not isinstance(result, dict):
            raise RuntimeError("expected dict result for .get()")

        instance = self.model_cls.from_row(result)
        queryset._apply_select_related([instance])
        queryset._apply_prefetch_related([instance])
        return instance

    def first(self) -> Model | None:
        if (
            self.python_predicates
            or self.slice_bounds is not None
            or self.distinct_columns is not None
        ):
            rows = self.all()
            return rows[0] if rows else None

        result = self._execute_terminal("first")

        if result is None:
            return None

        if not isinstance(result, dict):
            raise RuntimeError("expected dict result for .first()")

        instance = self.model_cls.from_row(result)
        self._apply_select_related([instance])
        self._apply_prefetch_related([instance])
        return instance

    def count(self) -> int:
        if (
            self.python_predicates
            or self.slice_bounds is not None
            or self.distinct_columns is not None
        ):
            return len(self._fetch_row_dicts())

        result = self._execute_terminal("count")

        if isinstance(result, bool) or not isinstance(result, int):
            raise RuntimeError("expected integer result for .count()")

        return result

    def aggregate(
        self, *aggregates: Aggregate, **named_aggregates: Aggregate
    ) -> dict[str, object]:
        entries = self._resolve_aggregate_entries(*aggregates, **named_aggregates)

        if (
            self.python_predicates
            or self.slice_bounds is not None
            or self.distinct_columns is not None
        ):
            rows = self._fetch_row_dicts()
            return {
                str(entry["alias"]): self._compute_python_aggregate(
                    rows,
                    str(entry["function"]),
                    str(entry["field"]),
                )
                for entry in entries
            }

        result = self._execute_terminal("aggregate", aggregates=entries)
        if not isinstance(result, dict):
            raise RuntimeError("expected dict result for .aggregate()")
        return result

    def all(self) -> list[Model]:
        rows = self._fetch_row_dicts()
        instances = [self.model_cls.from_row(row) for row in rows]
        self._apply_select_related(instances)
        self._apply_prefetch_related(instances)
        return instances

    def exists(self) -> bool:
        return self.first() is not None

    def last(self) -> Model | None:
        rows = self.all()
        if not rows:
            return None
        return rows[-1]

    def latest(self, field_name: str = "id") -> Model:
        instance = self.order_by(f"-{field_name}").first()
        if instance is None:
            raise self.model_cls.DoesNotExist(
                f"{self.model_cls.__name__} matching query does not exist"
            )
        return instance

    def earliest(self, field_name: str = "id") -> Model:
        instance = self.order_by(field_name).first()
        if instance is None:
            raise self.model_cls.DoesNotExist(
                f"{self.model_cls.__name__} matching query does not exist"
            )
        return instance

    def distinct(self, *fields: str) -> QuerySet:
        if not fields:
            return self._clone_with_distinct(())

        normalized: list[str] = []
        for field in fields:
            if not isinstance(field, str) or not field:
                raise ValueError("distinct fields must be non-empty strings")
            _, column = self.model_cls.resolve_field_and_column(field)
            normalized.append(column)

        return self._clone_with_distinct(tuple(normalized))

    def values(self, *fields: str) -> list[dict[str, object]]:
        projection = self._normalize_projection(fields)
        rows = self._fetch_row_dicts()
        return [
            {output_key: row.get(column_name) for output_key, column_name in projection}
            for row in rows
        ]

    def values_list(self, *fields: str, flat: bool = False) -> list[object]:
        projection = self._normalize_projection(fields)
        if flat and len(projection) != 1:
            raise ValueError("values_list(flat=True) requires exactly one field")

        rows = self._fetch_row_dicts()
        if flat:
            _, column_name = projection[0]
            return [row.get(column_name) for row in rows]

        return [
            tuple(row.get(column_name) for _, column_name in projection) for row in rows
        ]

    def create(self, **kwargs: object) -> Model:
        instance = self.model_cls(**kwargs)
        instance.save()
        return instance

    def bulk_create(self, instances: Iterable[Model]) -> list[Model]:
        normalized = list(instances)

        with atomic():
            for instance in normalized:
                if not isinstance(instance, self.model_cls):
                    raise TypeError(
                        f"bulk_create() expected instances of {self.model_cls.__name__}"
                    )
                instance.save()

        return normalized

    def update(self, **kwargs: object) -> int:
        updates = self._normalize_update_values(kwargs)

        if self.python_predicates:
            row_ids = self._ids_for_python_filtered_queryset()
            if not row_ids:
                return 0
            return self.model_cls.objects.filter(id__in=row_ids).update(**updates)

        result = self._execute_terminal("update", updates=updates)
        if isinstance(result, bool) or not isinstance(result, int):
            raise RuntimeError("expected integer result for .update()")

        return result

    def delete(self) -> int:
        if self.python_predicates:
            row_ids = self._ids_for_python_filtered_queryset()
            if not row_ids:
                return 0
            return self.model_cls.objects.filter(id__in=row_ids).delete()

        result = self._execute_terminal("delete")
        if isinstance(result, bool) or not isinstance(result, int):
            raise RuntimeError("expected integer result for .delete()")

        return result

    def get_or_create(
        self,
        defaults: dict[str, object] | None = None,
        **kwargs: object,
    ) -> tuple[Model, bool]:
        try:
            return self.get(**kwargs), False
        except self.model_cls.DoesNotExist:
            payload = dict(kwargs)
            if defaults:
                payload.update(defaults)

            try:
                with atomic():
                    return self.create(**payload), True
            except RuntimeError as err:
                if "unique" not in str(err).lower():
                    raise
                return self.get(**kwargs), False

    def update_or_create(
        self,
        defaults: dict[str, object] | None = None,
        **kwargs: object,
    ) -> tuple[Model, bool]:
        update_values = dict(defaults or {})

        with atomic():
            instance, created = self.get_or_create(defaults=update_values, **kwargs)
            if created:
                return instance, True

            if update_values:
                self.model_cls.objects.filter(id=instance.id).update(**update_values)
                for key, value in update_values.items():
                    setattr(instance, key, value)

            return instance, False


class Manager:
    def __init__(self) -> None:
        self.model_cls: type[Model] | None = None

    def __set_name__(self, owner: type[Model], name: str) -> None:
        _ = name
        self.model_cls = owner

    def _require_model_cls(self) -> type[Model]:
        if self.model_cls is None:
            raise RuntimeError("manager is not bound to a model")
        return self.model_cls

    def get_queryset(self) -> QuerySet:
        return QuerySet(self._require_model_cls())

    def create(self, **kwargs: object) -> Model:
        return self.get_queryset().create(**kwargs)

    def bulk_create(self, instances: Iterable[Model]) -> list[Model]:
        return self.get_queryset().bulk_create(instances)

    def filter(self, *expressions: Q, **kwargs: object) -> QuerySet:
        return self.get_queryset().filter(*expressions, **kwargs)

    def exclude(self, *expressions: Q, **kwargs: object) -> QuerySet:
        return self.get_queryset().exclude(*expressions, **kwargs)

    def order_by(self, *fields: str) -> QuerySet:
        return self.get_queryset().order_by(*fields)

    def limit(self, value: int) -> QuerySet:
        return self.get_queryset().limit(value)

    def select_related(self, *fields: str) -> QuerySet:
        return self.get_queryset().select_related(*fields)

    def prefetch_related(self, *fields: str) -> QuerySet:
        return self.get_queryset().prefetch_related(*fields)

    def get(self, *expressions: Q, **kwargs: object) -> Model:
        return self.get_queryset().get(*expressions, **kwargs)

    def get_or_create(
        self,
        defaults: dict[str, object] | None = None,
        **kwargs: object,
    ) -> tuple[Model, bool]:
        return self.get_queryset().get_or_create(defaults=defaults, **kwargs)

    def update_or_create(
        self,
        defaults: dict[str, object] | None = None,
        **kwargs: object,
    ) -> tuple[Model, bool]:
        return self.get_queryset().update_or_create(defaults=defaults, **kwargs)

    def update(self, **kwargs: object) -> int:
        return self.get_queryset().update(**kwargs)

    def delete(self) -> int:
        return self.get_queryset().delete()

    def first(self) -> Model | None:
        return self.get_queryset().first()

    def last(self) -> Model | None:
        return self.get_queryset().last()

    def latest(self, field_name: str = "id") -> Model:
        return self.get_queryset().latest(field_name)

    def earliest(self, field_name: str = "id") -> Model:
        return self.get_queryset().earliest(field_name)

    def exists(self) -> bool:
        return self.get_queryset().exists()

    def count(self) -> int:
        return self.get_queryset().count()

    def aggregate(
        self, *aggregates: Aggregate, **named_aggregates: Aggregate
    ) -> dict[str, object]:
        return self.get_queryset().aggregate(*aggregates, **named_aggregates)

    def all(self) -> list[Model]:
        return self.get_queryset().all()

    def values(self, *fields: str) -> list[dict[str, object]]:
        return self.get_queryset().values(*fields)

    def values_list(self, *fields: str, flat: bool = False) -> list[object]:
        return self.get_queryset().values_list(*fields, flat=flat)

    def distinct(self, *fields: str) -> QuerySet:
        return self.get_queryset().distinct(*fields)


class ObjectDoesNotExist(Exception):
    """Base class for model-specific DoesNotExist exceptions."""


class MultipleObjectsReturnedError(Exception):
    """Base class for model-specific MultipleObjectsReturned exceptions."""


class ModelMeta(type):
    def __new__(
        mcls,
        name: str,
        bases: tuple[type, ...],
        namespace: dict[str, object],
    ) -> ModelMeta:
        declared_fields: dict[str, Field] = {}
        declared_many_to_many: dict[str, ManyToManyField] = {}

        for base in bases:
            declared_fields.update(getattr(base, "_meta_fields", {}))
            declared_many_to_many.update(getattr(base, "_meta_many_to_many", {}))

        for key, value in namespace.items():
            if isinstance(value, Field):
                declared_fields[key] = value
            elif isinstance(value, ManyToManyField):
                declared_many_to_many[key] = value

        is_base_model = name == "Model"
        if not is_base_model and "objects" not in namespace:
            namespace["objects"] = Manager()

        cls = super().__new__(mcls, name, bases, namespace)
        cls._meta_fields = declared_fields
        cls._meta_many_to_many = declared_many_to_many
        cls._meta_storage_to_field = {
            field.storage_name(): field_name
            for field_name, field in declared_fields.items()
        }
        cls._meta_app_label = "main"
        cls._meta_model_label = name

        for field in declared_many_to_many.values():
            field.bind_owner(cls)

        for field_name, field in declared_fields.items():
            if isinstance(field, ForeignKey):
                id_attr = field.storage_name()
                if id_attr in declared_fields:
                    continue
                if hasattr(cls, id_attr):
                    continue

                def _id_getter(
                    instance: Model, _field: ForeignKey = field
                ) -> int | None:
                    return _field.get_raw_id(instance)

                def _id_setter(
                    instance: Model,
                    value: int | None,
                    _field: ForeignKey = field,
                ) -> None:
                    _field.set_raw_id(instance, value)

                setattr(cls, id_attr, property(_id_getter, _id_setter))
        if not is_base_model:
            cls._meta_app_label = _infer_model_app_label(cls)
            cls._meta_model_label = f"{cls._meta_app_label}.{name}"
            cls.DoesNotExist = type("DoesNotExist", (ObjectDoesNotExist,), {})
            cls.MultipleObjectsReturned = type(
                "MultipleObjectsReturned",
                (MultipleObjectsReturnedError,),
                {},
            )
            _MODEL_REGISTRY[name] = cls
            _MODEL_REGISTRY[cls._meta_model_label] = cls
            _MODEL_REGISTRY_BY_LABEL[cls._meta_model_label] = cls

            is_internal_through = bool(
                namespace.get("__ferrum_internal_through_model__", False)
            )

            if not is_internal_through:
                for field in declared_fields.values():
                    if not isinstance(field, ForeignKey):
                        continue
                    if not _attach_reverse_relation(cls, field):
                        _PENDING_REVERSE_RELATIONS.append((cls, field))

                for field in declared_many_to_many.values():
                    if not _attach_many_to_many_relation(cls, field):
                        _PENDING_MANY_TO_MANY_RELATIONS.append((cls, field))

                _finalize_pending_reverse_relations()
                _finalize_pending_many_to_many_relations()

            _sync_allowed_tables()

        return cls


class Model(FerrumModel, metaclass=ModelMeta):
    id: int | None = None
    objects: ClassVar[Manager]
    DoesNotExist: ClassVar[type[Exception]] = ObjectDoesNotExist
    MultipleObjectsReturned: ClassVar[type[Exception]] = MultipleObjectsReturnedError
    _meta_fields: ClassVar[dict[str, Field]] = {}
    _meta_many_to_many: ClassVar[dict[str, ManyToManyField]] = {}
    _meta_storage_to_field: ClassVar[dict[str, str]] = {}
    _meta_app_label: ClassVar[str] = "main"
    _meta_model_label: ClassVar[str] = "Model"

    class Meta:
        table_name: str | None = None
        app_label: str | None = None

    def __new__(cls, **kwargs: object) -> "Model":
        obj = super(Model, cls).__new__(cls)
        return obj

    def __init__(self, **kwargs: object) -> None:
        super(Model, self).__init__()
        allowed_keys = {
            "id",
            *self._meta_fields.keys(),
            *self._meta_storage_to_field.keys(),
        }
        unknown = sorted(set(kwargs.keys()) - set(allowed_keys))
        if unknown:
            joined = ", ".join(unknown)
            raise TypeError(f"unexpected field(s): {joined}")

        raw_id = kwargs.get("id")
        if raw_id is not None:
            if isinstance(raw_id, bool) or not isinstance(raw_id, int):
                raise ValueError("field 'id' expects an integer")
            self.id = raw_id

        for field_name, field in self._meta_fields.items():
            logical_present = field_name in kwargs
            storage_name = field.storage_name()
            storage_present = storage_name in kwargs and storage_name != field_name

            if logical_present and storage_present:
                raise TypeError(
                    f"both '{field_name}' and '{storage_name}' provided; use only one"
                )

            if logical_present:
                setattr(self, field_name, kwargs[field_name])
                continue

            if storage_present:
                field.set_from_storage_key(self, kwargs[storage_name])
                continue

            default_value = field.default_value()
            if default_value is None and not field.nullable:
                continue
            setattr(self, field_name, default_value)

    @classmethod
    def table_name(cls) -> str:
        meta = getattr(cls, "Meta", None)
        configured = getattr(meta, "table_name", None) if meta else None
        if configured:
            return str(configured)
        return f"{cls.app_label()}_{cls.__name__.lower()}s"

    @classmethod
    def app_label(cls) -> str:
        return cls._meta_app_label

    @classmethod
    def model_label(cls) -> str:
        return cls._meta_model_label

    @classmethod
    def resolve_field_and_column(cls, field_key: str) -> tuple[Field | None, str]:
        if field_key == "id":
            return None, "id"

        direct = cls._meta_fields.get(field_key)
        if direct is not None:
            return direct, direct.storage_name()

        field_name = cls._meta_storage_to_field.get(field_key)
        if field_name is not None:
            field = cls._meta_fields[field_name]
            return field, field_key

        raise ValueError(f"unknown field '{field_key}' for {cls.__name__}")

    @classmethod
    def has_field(cls, field_name: str) -> bool:
        if field_name == "id":
            return True
        return (
            field_name in cls._meta_fields
            or field_name in cls._meta_storage_to_field
            or field_name in cls._meta_many_to_many
        )

    @classmethod
    def schema(cls) -> dict[str, dict[str, object]]:
        return {
            field.storage_name(): field.schema_spec()
            for field in cls._meta_fields.values()
        }

    @classmethod
    def field_type_map(cls) -> dict[str, str]:
        mapping = {"id": "integer"}
        for field in cls._meta_fields.values():
            mapping[field.storage_name()] = field.rust_type
        return mapping

    @classmethod
    def create_table(cls) -> None:
        _ensure_model_table(cls.table_name(), cls.schema())
        for field in cls._meta_many_to_many.values():
            field.ensure_through_table()

    @classmethod
    def from_row(cls, row: dict[str, object]) -> Model:
        instance = cls.__new__(cls)

        raw_id = row.get("id")
        if isinstance(raw_id, bool):
            instance.id = int(raw_id)
        elif isinstance(raw_id, int):
            instance.id = raw_id
        elif raw_id is None:
            instance.id = None
        else:
            raise ValueError("column 'id' expects an integer")

        for field_name, field in cls._meta_fields.items():
            storage_name = field.storage_name()
            if storage_name in row:
                field.set_from_storage_key(instance, row[storage_name])
                continue

            default_value = field.default_value()
            if default_value is None and not field.nullable:
                continue
            setattr(instance, field_name, default_value)

        return instance

    def to_record(self) -> dict[str, object]:
        payload: dict[str, object] = {}
        for field in self._meta_fields.values():
            payload[field.storage_name()] = field.to_record_value(self)
        return payload

    def _normalize_update_fields(
        self,
        update_fields: Iterable[str],
    ) -> list[str]:
        if isinstance(update_fields, (str, bytes)):
            raise ValueError("update_fields must be an iterable of field names")

        normalized_columns: list[str] = []
        seen: set[str] = set()

        for raw_field in update_fields:
            if not isinstance(raw_field, str) or not raw_field:
                raise ValueError("update_fields entries must be non-empty strings")

            field, column = self.resolve_field_and_column(raw_field)
            if column == "id":
                raise ValueError("update_fields cannot include primary key 'id'")
            if field is None:
                raise ValueError(
                    f"unknown field '{raw_field}' for {self.__class__.__name__}"
                )
            if column in seen:
                continue

            seen.add(column)
            normalized_columns.append(column)

        return normalized_columns

    def _payload_for_columns(
        self, columns: Iterable[str] | None = None
    ) -> dict[str, object]:
        selected = set(columns) if columns is not None else None
        payload: dict[str, object] = {}

        for field_name, field in self._meta_fields.items():
            storage_name = field.storage_name()
            if selected is not None and storage_name not in selected:
                continue

            payload[field_name] = field.value_from_instance(self)

        return payload

    def save(self, *, update_fields: Iterable[str] | None = None) -> int:
        if update_fields is not None:
            if self.id is None:
                raise ValueError("update_fields requires an existing row")

            columns = self._normalize_update_fields(update_fields)
            if not columns:
                return self.id

            update_payload = self._payload_for_columns(columns)
            self.__class__.objects.filter(id=self.id).update(**update_payload)
            return self.id

        if self.id is None:
            row_id = _save_model(self.table_name(), self.schema(), self.to_record())
            self.id = row_id
            return row_id

        update_payload = self._payload_for_columns()
        self.__class__.objects.filter(id=self.id).update(**update_payload)
        return self.id

    def refresh_from_db(self) -> None:
        if self.id is None:
            raise ValueError("cannot refresh an unsaved model instance")

        fresh = self.__class__.objects.get(id=self.id)
        self.id = fresh.id

        for field_name, field in self._meta_fields.items():
            storage_name = field.storage_name()
            value = fresh.__dict__.get(storage_name, field.default_value())
            field.set_from_storage_key(self, value)
            if isinstance(field, ForeignKey):
                cache_name = field._cache_name()
                if cache_name in fresh.__dict__:
                    self.__dict__[cache_name] = fresh.__dict__[cache_name]
                else:
                    self.__dict__.pop(cache_name, None)

    def delete(self) -> int:
        if self.id is None:
            return 0

        deleted = self.__class__.objects.filter(id=self.id).delete()
        if deleted:
            self.id = None
            for field in self._meta_fields.values():
                if isinstance(field, ForeignKey):
                    self.__dict__.pop(field._cache_name(), None)
        return deleted


def configure_db(database_url: str) -> None:
    _configure_db(database_url)
    _sync_allowed_tables()


def get_model_registry() -> dict[str, type[Model]]:
    return dict(_MODEL_REGISTRY_BY_LABEL)


class _AtomicContext:
    def __enter__(self) -> _AtomicContext:
        stack = _atomic_stack()
        if not stack:
            try:
                _execute_sql("BEGIN")
            except Exception:
                raise
            stack.append(None)
            return self

        savepoint = f"ferrum_sp_{len(stack)}"
        _execute_sql(f"SAVEPOINT {savepoint}")
        stack.append(savepoint)
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> bool:
        _ = (exc, tb)
        stack = _atomic_stack()
        if not stack:
            raise RuntimeError("atomic block exited without active transaction")

        marker = stack.pop()
        is_outermost = marker is None

        try:
            if exc_type is None:
                if is_outermost:
                    _execute_sql("COMMIT")
                else:
                    _execute_sql(f"RELEASE SAVEPOINT {marker}")
            else:
                if is_outermost:
                    _execute_sql("ROLLBACK")
                else:
                    _execute_sql(f"ROLLBACK TO SAVEPOINT {marker}")
                    _execute_sql(f"RELEASE SAVEPOINT {marker}")
        except Exception:
            if is_outermost:
                try:
                    _execute_sql("ROLLBACK")
                except Exception:
                    pass
            raise

        return False


def atomic() -> _AtomicContext:
    return _AtomicContext()


__all__ = [
    "Aggregate",
    "Avg",
    "BooleanField",
    "CharField",
    "Count",
    "Field",
    "FloatField",
    "ForeignKey",
    "IntegerField",
    "ManyToManyField",
    "ManyToManyManager",
    "Manager",
    "Max",
    "Min",
    "Model",
    "MultipleObjectsReturnedError",
    "ObjectDoesNotExist",
    "Q",
    "QueryIR",
    "QuerySet",
    "RelatedManager",
    "Sum",
    "atomic",
    "configure_db",
    "get_model_registry",
]
