"""Entry point for Ferrum's command-line management API."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Sequence

from .base import CommandError, CommandNotFoundError
from .loader import list_available_commands, load_command_class
from .project import ensure_settings_module

_HELP_ALIASES = {"-h", "--help"}


def execute_from_command_line(
    argv: Sequence[str] | None = None,
    *,
    project_dir: str | Path | None = None,
) -> None:
    raw_argv = list(sys.argv if argv is None else argv)
    if not raw_argv:
        raw_argv = ["manage.py"]

    resolved_project_dir = _resolve_project_dir(project_dir)
    if resolved_project_dir is not None:
        _prepend_to_syspath(resolved_project_dir)
        ensure_settings_module(resolved_project_dir, required=False)

    if len(raw_argv) <= 1:
        raw_argv.append("runserver")

    program_name = Path(raw_argv[0]).name
    command_name = raw_argv[1]

    if command_name in _HELP_ALIASES:
        _print_main_help(program_name, resolved_project_dir)
        return

    if command_name == "help":
        if len(raw_argv) == 2:
            _print_main_help(program_name, resolved_project_dir)
            return

        target = raw_argv[2]
        try:
            command_cls = load_command_class(target, resolved_project_dir)
        except CommandNotFoundError as err:
            available = ", ".join(list_available_commands(resolved_project_dir))
            raise SystemExit(
                f"Unknown command: {target}\nAvailable commands: {available}"
            ) from err
        command = command_cls(project_dir=resolved_project_dir)
        command.run_from_argv([raw_argv[0], target, "--help"])
        return

    try:
        command_cls = load_command_class(command_name, resolved_project_dir)
    except CommandNotFoundError as err:
        available = ", ".join(list_available_commands(resolved_project_dir))
        raise SystemExit(
            f"Unknown command: {command_name}\nAvailable commands: {available}"
        ) from err

    command = command_cls(project_dir=resolved_project_dir)
    try:
        command.run_from_argv(raw_argv)
    except CommandError as err:
        raise SystemExit(str(err)) from err


def _resolve_project_dir(project_dir: str | Path | None) -> Path | None:
    if project_dir is None:
        return None

    return Path(project_dir).expanduser().resolve()


def _prepend_to_syspath(project_dir: Path) -> None:
    project_dir_str = str(project_dir)
    if project_dir_str not in sys.path:
        sys.path.insert(0, project_dir_str)


def _print_main_help(program_name: str, project_dir: Path | None) -> None:
    commands = list_available_commands(project_dir)
    print(f"Usage: {program_name} <command> [options]")
    print("\nAvailable commands:")

    if not commands:
        print("  (none)")
        return

    for name in commands:
        print(f"  {name}")
