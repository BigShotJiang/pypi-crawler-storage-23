"""Base classes for Ferrum management commands."""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Sequence


class CommandError(Exception):
    """Raised when a command cannot complete due to user-facing errors."""


class CommandNotFoundError(CommandError):
    """Raised when a command name cannot be resolved."""


class BaseCommand:
    help = ""

    def __init__(self, *, project_dir: Path | None = None) -> None:
        self.project_dir = project_dir.resolve() if project_dir else None

    def create_parser(self, prog_name: str, subcommand: str) -> argparse.ArgumentParser:
        parser = argparse.ArgumentParser(
            prog=f"{prog_name} {subcommand}",
            description=self.help or None,
        )
        self.add_arguments(parser)
        return parser

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        _ = parser

    def run_from_argv(self, argv: Sequence[str]) -> None:
        if len(argv) < 2:
            raise CommandError("missing command name")

        prog_name = Path(argv[0]).name
        subcommand = argv[1]

        parser = self.create_parser(prog_name, subcommand)
        options = vars(parser.parse_args(list(argv[2:])))
        self.execute(**options)

    def execute(self, **options: object) -> None:
        self.handle(**options)

    def handle(self, **options: object) -> None:
        _ = options
        raise NotImplementedError("subclasses of BaseCommand must provide handle()")

    def require_project_dir(self) -> Path:
        if self.project_dir is None:
            raise CommandError("project_dir is required for this command")
        return self.project_dir
