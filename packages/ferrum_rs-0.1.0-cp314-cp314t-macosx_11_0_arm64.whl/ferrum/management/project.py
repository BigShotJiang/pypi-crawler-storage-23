"""Project settings and installed app helpers."""

from __future__ import annotations

import importlib
import os
from pathlib import Path
from types import ModuleType
from typing import Sequence

from ferrum.apps import AppConfig, apps
from ferrum.conf import ENVIRONMENT_VARIABLE, ImproperlyConfigured, settings

from .base import CommandError


def ensure_settings_module(
    project_dir: Path | None,
    *,
    required: bool,
) -> str | None:
    configured = os.environ.get(ENVIRONMENT_VARIABLE)
    if configured:
        return configured

    if project_dir is None:
        if required:
            raise CommandError(
                f"{ENVIRONMENT_VARIABLE} is not set and project_dir is unavailable"
            )
        return None

    nested_settings = project_dir / project_dir.name / "settings.py"
    flat_settings = project_dir / "settings.py"

    if nested_settings.exists():
        module_name = f"{project_dir.name}.settings"
    elif flat_settings.exists():
        module_name = "settings"
    else:
        if required:
            raise CommandError(
                "could not find settings.py. Expected either "
                f"{nested_settings} or {flat_settings}"
            )
        return None

    os.environ[ENVIRONMENT_VARIABLE] = module_name
    settings.reset()
    return module_name


def load_settings_module(
    project_dir: Path | None,
    *,
    required: bool,
) -> ModuleType | None:
    module_name = ensure_settings_module(project_dir, required=required)
    if module_name is None:
        return None

    try:
        if (
            not settings.configured
            or getattr(settings, "SETTINGS_MODULE", None) != module_name
        ):
            settings.configure(settings_module=module_name)
        return importlib.import_module(module_name)
    except (ImproperlyConfigured, ModuleNotFoundError) as err:
        if required:
            raise CommandError(f"failed to load settings module '{module_name}': {err}") from err
        return None


def get_installed_apps(
    project_dir: Path | None,
    *,
    required: bool,
) -> list[AppConfig]:
    settings_module = load_settings_module(project_dir, required=required)
    if settings_module is None:
        return []

    installed_apps = getattr(settings, "INSTALLED_APPS", None)
    if installed_apps is None:
        if required:
            raise CommandError("settings must define INSTALLED_APPS")
        return []

    try:
        apps.populate(installed_apps)
    except ImproperlyConfigured as err:
        raise CommandError(str(err)) from err

    app_configs = apps.get_app_configs()
    if required and not app_configs:
        raise CommandError("INSTALLED_APPS is empty; add at least one app")
    return app_configs


def import_models_modules(app_configs: Sequence[AppConfig]) -> None:
    _ = app_configs
    # Apps.populate(...) imports models modules already.


def get_root_urlconf(project_dir: Path | None) -> str:
    load_settings_module(project_dir, required=False)
    configured = getattr(settings, "ROOT_URLCONF", "urls")
    if not isinstance(configured, str) or not configured.strip():
        raise CommandError("ROOT_URLCONF must be a non-empty string")
    return configured.strip()


def get_default_database_url(project_dir: Path | None) -> str | None:
    load_settings_module(project_dir, required=False)

    databases = getattr(settings, "DATABASES", None)
    if not isinstance(databases, dict):
        return None

    default_config = databases.get("default")
    if not isinstance(default_config, dict):
        return None

    explicit_url = default_config.get("URL")
    if isinstance(explicit_url, str) and explicit_url.strip():
        return explicit_url.strip()

    name = default_config.get("NAME")
    if not isinstance(name, str) or not name.strip():
        return None

    path = Path(name.strip()).expanduser()
    if path.is_absolute():
        return str(path)

    base_dir = getattr(settings, "BASE_DIR", None)
    if isinstance(base_dir, (str, Path)):
        return str((Path(base_dir) / path).resolve())

    if project_dir is not None:
        return str((project_dir / path).resolve())
    return str(path.resolve())


def select_apps(
    all_apps: Sequence[AppConfig],
    app_labels: Sequence[str] | None,
) -> list[AppConfig]:
    if not app_labels:
        return list(all_apps)

    by_label = {app.label: app for app in all_apps}
    by_name = {app.name: app for app in all_apps}

    selected: list[AppConfig] = []
    seen: set[str] = set()
    for token in app_labels:
        app = by_label.get(token) or by_name.get(token)
        if app is None:
            available = ", ".join(sorted(by_name))
            raise CommandError(
                f"unknown app '{token}'. Available apps: {available}"
            )
        if app.name in seen:
            continue
        seen.add(app.name)
        selected.append(app)

    return selected

