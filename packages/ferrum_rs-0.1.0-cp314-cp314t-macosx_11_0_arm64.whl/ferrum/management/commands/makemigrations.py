"""Generate migration files from model state changes."""

from __future__ import annotations

import argparse
from collections import defaultdict

from ferrum.db import migrations, models as db_models
from ferrum.management.base import BaseCommand

from ._common import import_models_for_apps, load_target_apps


class Command(BaseCommand):
    help = "Create new migration files from current models in installed apps."

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        parser.add_argument(
            "app_labels",
            nargs="*",
            help="Optional app labels to limit migration generation",
        )
        parser.add_argument(
            "--name",
            default=None,
            help="Optional migration name suffix",
        )

    def handle(self, *, app_labels: list[str], name: str | None) -> None:
        apps = load_target_apps(self, app_labels, allow_empty=True)
        if not apps:
            print("No installed apps configured; nothing to migrate.")
            return
        import_models_for_apps(apps)

        registry = db_models.get_model_registry()
        models_by_app: dict[str, dict[str, type[db_models.Model]]] = defaultdict(dict)
        for model_cls in registry.values():
            models_by_app[model_cls.app_label()][model_cls.model_label()] = model_cls

        created_any = False
        for app in apps:
            migration_file, warnings = migrations.make_migration(
                app.migrations_dir,
                models_by_app.get(app.label, {}),
                name=name,
            )

            for warning in warnings:
                print(f"{app.label}: Warning: {warning}")

            if migration_file is None:
                print(f"{app.label}: No model changes detected.")
                continue

            created_any = True
            print(f"{app.label}: Created migration: {migration_file.name}")

        if not created_any:
            return
