"""Display migration state."""

from __future__ import annotations

import argparse

from ferrum.db import migrations
from ferrum.management.base import BaseCommand

from ._common import load_target_apps, resolve_project_database_url


class Command(BaseCommand):
    help = "Show applied/pending migrations by app."

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        parser.add_argument(
            "app_labels",
            nargs="*",
            help="Optional app labels to limit migration status output",
        )
        parser.add_argument(
            "--database",
            default=None,
            help="Optional database path/URL override",
        )

    def handle(self, *, app_labels: list[str], database: str | None) -> None:
        database_url = resolve_project_database_url(self, database)
        apps = load_target_apps(self, app_labels, allow_empty=True)
        if not apps:
            print("No installed apps configured.")
            return

        any_output = False
        for app in apps:
            statuses, unknown_applied = migrations.get_migration_status(
                app.migrations_dir,
                database_url=database_url,
                app_label=app.label,
            )

            print(f"{app.label}:")
            any_output = True

            if not statuses:
                print(" [ ] (no migrations found)")
            else:
                for name, applied in statuses:
                    marker = "X" if applied else " "
                    print(f" [{marker}] {name}")

            if unknown_applied:
                print(" Applied in DB but missing on disk:")
                for name in unknown_applied:
                    print(f"  - {name}")

        if not any_output:
            print("No migrations found.")
