"""Shared helpers for built-in management commands."""

from __future__ import annotations

from pathlib import Path
from typing import Sequence

from ferrum.management.base import BaseCommand, CommandError
from ferrum.management.project import (
    AppConfig,
    get_default_database_url,
    get_installed_apps,
    import_models_modules,
    select_apps,
)


def resolve_project_database_url(command: BaseCommand, database: str | None) -> str:
    project_dir = command.require_project_dir()

    if database:
        explicit = database.strip()
        if "://" in explicit:
            return explicit
        path = Path(explicit).expanduser()
        if not path.is_absolute():
            path = project_dir / path
        path = path.resolve()
        path.parent.mkdir(parents=True, exist_ok=True)
        return str(path)

    configured = get_default_database_url(project_dir)
    if configured:
        if "://" not in configured:
            path = Path(configured).expanduser().resolve()
            path.parent.mkdir(parents=True, exist_ok=True)
            return str(path)
        return configured

    path = (project_dir / "ferrum.sqlite").resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    return str(path)


def load_target_apps(
    command: BaseCommand,
    app_labels: Sequence[str] | None,
    *,
    allow_empty: bool = False,
) -> list[AppConfig]:
    project_dir = command.require_project_dir()
    installed_apps = get_installed_apps(project_dir, required=not allow_empty)
    if not installed_apps:
        if allow_empty:
            return []
        raise CommandError("INSTALLED_APPS is empty; add at least one app")
    return select_apps(installed_apps, app_labels)


def import_models_for_apps(apps: Sequence[AppConfig]) -> None:
    import_models_modules(apps)
