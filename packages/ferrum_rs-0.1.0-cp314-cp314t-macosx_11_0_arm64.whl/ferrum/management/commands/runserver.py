"""Run Ferrum development server."""

from __future__ import annotations

import argparse
import importlib
import os
import subprocess
import sys
import time
from pathlib import Path

from ferrum import setup, start_server
from ferrum.conf import settings
from ferrum.management.base import BaseCommand, CommandError
from ferrum.management.project import get_root_urlconf

_RELOAD_ENV = "FERRUM_RUN_MAIN"


class Command(BaseCommand):
    help = "Start Ferrum development server."

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        parser.add_argument(
            "port",
            nargs="?",
            type=int,
            default=None,
            help="Port to bind (default: settings.PORT or 8000)",
        )
        parser.add_argument(
            "--reload",
            action="store_true",
            help="Enable development autoreload for Python files.",
        )
        parser.add_argument(
            "--noreload",
            action="store_true",
            help="Disable autoreload (used internally by the reloader child process).",
        )

    def handle(self, *, port: int | None, reload: bool, noreload: bool) -> None:
        project_dir = self.require_project_dir()
        setup()

        urlconf_module = get_root_urlconf(project_dir)
        try:
            importlib.import_module(urlconf_module)
        except ModuleNotFoundError as err:
            if err.name == urlconf_module:
                raise CommandError(
                    f"ROOT_URLCONF module '{urlconf_module}' could not be imported"
                ) from err
            raise

        selected_port = int(port if port is not None else getattr(settings, "PORT", 8000))
        print(f"Starting Ferrum development server at http://127.0.0.1:{selected_port}")
        if noreload:
            start_server(selected_port)
            return

        if reload:
            run_with_reloader(project_dir, selected_port)
            return

        start_server(selected_port)


def run_with_reloader(project_dir: Path, port: int) -> None:
    print("Watching for file changes with Ferrum StatReloader")

    while True:
        env = os.environ.copy()
        env[_RELOAD_ENV] = "1"
        process = subprocess.Popen(
            [
                sys.executable,
                "manage.py",
                "runserver",
                str(port),
                "--noreload",
            ],
            cwd=project_dir,
            env=env,
        )

        baseline = snapshot_python_files(project_dir)
        should_restart = False

        try:
            while process.poll() is None:
                time.sleep(0.75)
                current = snapshot_python_files(project_dir)
                if has_changed(baseline, current):
                    should_restart = True
                    print("File change detected. Reloading server...")
                    process.terminate()
                    try:
                        process.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait()
                    break
                baseline = current
        except KeyboardInterrupt:
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
            raise

        if should_restart:
            continue

        returncode = process.poll()
        if returncode not in (0, None):
            raise SystemExit(returncode)
        return


def snapshot_python_files(project_dir: Path) -> dict[Path, float]:
    state: dict[Path, float] = {}
    for path in project_dir.rglob("*.py"):
        if "__pycache__" in path.parts:
            continue
        try:
            stat = path.stat()
        except OSError:
            continue
        state[path] = stat.st_mtime
    return state


def has_changed(previous: dict[Path, float], current: dict[Path, float]) -> bool:
    if previous.keys() != current.keys():
        return True
    for path, mtime in previous.items():
        if current.get(path) != mtime:
            return True
    return False
