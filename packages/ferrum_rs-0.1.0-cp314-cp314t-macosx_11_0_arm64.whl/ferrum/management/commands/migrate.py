"""Apply pending migrations."""

from __future__ import annotations

import argparse

from ferrum.db import migrations
from ferrum.management.base import BaseCommand, CommandError

from ._common import (
    import_models_for_apps,
    load_target_apps,
    resolve_project_database_url,
)


class Command(BaseCommand):
    help = "Apply pending migrations for installed apps."

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        parser.add_argument(
            "app_label",
            nargs="?",
            default=None,
            help="Optional app label to limit migration execution",
        )
        parser.add_argument(
            "target",
            nargs="?",
            default=None,
            help="Optional migration target (e.g. 0001_initial or 'zero') for app_label",
        )
        parser.add_argument(
            "--database",
            default=None,
            help="Optional database path/URL override",
        )
        parser.add_argument(
            "--fake",
            action="store_true",
            help="Mark migrations as applied/unapplied without executing operations",
        )

    def handle(
        self,
        *,
        app_label: str | None,
        target: str | None,
        database: str | None,
        fake: bool,
    ) -> None:
        database_url = resolve_project_database_url(self, database)
        requested_labels = [app_label] if app_label else None
        apps = load_target_apps(self, requested_labels, allow_empty=True)
        if not apps:
            print("No installed apps configured; nothing to migrate.")
            return
        import_models_for_apps(apps)
        if target and not app_label:
            raise CommandError("target migration requires an explicit app_label")

        migrations_dirs = {
            app.label: app.migrations_dir
            for app in apps
        }
        targets = {app_label: target} if app_label and target else None
        applied = migrations.apply_migrations_for_apps(
            migrations_dirs,
            database_url=database_url,
            targets=targets,
            fake=fake,
        )

        if applied:
            header = "Faked migrations:" if fake else "Applied migrations:"
            print(header)
            for app_label, name in applied:
                print(f"  - {app_label}.{name}")
        else:
            print("No migrations to apply.")
