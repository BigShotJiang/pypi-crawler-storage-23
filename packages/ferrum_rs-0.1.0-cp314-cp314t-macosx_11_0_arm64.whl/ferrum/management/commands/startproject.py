"""Create a new Ferrum project scaffold."""

from __future__ import annotations

import argparse
from pathlib import Path

from ferrum.management.base import BaseCommand, CommandError


class Command(BaseCommand):
    help = "Create a new Ferrum project (Django-style layout)."

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        parser.add_argument(
            "name",
            help="Project package name",
        )
        parser.add_argument(
            "directory",
            nargs="?",
            default=None,
            help="Optional destination directory (defaults to ./<name>)",
        )

    def handle(self, *, name: str, directory: str | None) -> None:
        if not name.isidentifier():
            raise CommandError(
                f"invalid project name '{name}'; use a valid Python identifier"
            )

        destination = self._resolve_destination(name, directory)
        if destination.exists() and any(destination.iterdir()):
            raise CommandError(f"destination '{destination}' already exists and is not empty")

        destination.mkdir(parents=True, exist_ok=True)
        package_dir = destination / name
        package_dir.mkdir(parents=True, exist_ok=True)

        files: dict[Path, str] = {
            destination / "manage.py": self._manage_py(name),
            package_dir / "__init__.py": "",
            package_dir / "settings.py": self._settings_py(name),
            package_dir / "urls.py": self._urls_py(),
            package_dir / "asgi.py": self._asgi_py(name),
            package_dir / "wsgi.py": self._wsgi_py(name),
        }

        for path, contents in files.items():
            path.write_text(contents, encoding="utf-8")

        print(f"Created Ferrum project '{name}' at {destination}")

    def _resolve_destination(self, name: str, directory: str | None) -> Path:
        if directory is None:
            return (Path.cwd() / name).resolve()
        return Path(directory).expanduser().resolve()

    def _manage_py(self, project_name: str) -> str:
        return (
            "import os\n"
            "import sys\n"
            "from pathlib import Path\n\n"
            "from ferrum.management import execute_from_command_line\n\n"
            "BASE_DIR = Path(__file__).resolve().parent\n"
            f'os.environ.setdefault("FERRUM_SETTINGS_MODULE", "{project_name}.settings")\n\n'
            "if __name__ == \"__main__\":\n"
            "    execute_from_command_line(sys.argv, project_dir=BASE_DIR)\n"
        )

    def _settings_py(self, project_name: str) -> str:
        return (
            "from pathlib import Path\n\n"
            "BASE_DIR = Path(__file__).resolve().parent.parent\n"
            "DEBUG = True\n"
            "PORT = 8000\n\n"
            "INSTALLED_APPS = []\n\n"
            "MIDDLEWARE = []\n\n"
            f'ROOT_URLCONF = "{project_name}.urls"\n\n'
            "DATABASES = {\n"
            '    "default": {\n'
            '        "ENGINE": "ferrum.db.backends.sqlite3",\n'
            '        "NAME": "ferrum.sqlite",\n'
            "    }\n"
            "}\n"
        )

    def _urls_py(self) -> str:
        return (
            "from ferrum.urls import path\n\n\n"
            "urlpatterns = [\n"
            "    # path(\"\", your_view),\n"
            "]\n"
        )

    def _wsgi_py(self, project_name: str) -> str:
        return (
            '"""WSGI placeholder for future server integrations."""\n\n'
            "import os\n\n"
            f'os.environ.setdefault("FERRUM_SETTINGS_MODULE", "{project_name}.settings")\n'
        )

    def _asgi_py(self, project_name: str) -> str:
        return (
            '"""ASGI placeholder for future async server integrations."""\n\n'
            "import os\n\n"
            f'os.environ.setdefault("FERRUM_SETTINGS_MODULE", "{project_name}.settings")\n'
        )
