"""Command discovery and loading."""

from __future__ import annotations

import importlib
import importlib.util
from pathlib import Path
from types import ModuleType

from .base import BaseCommand, CommandNotFoundError
from .project import get_installed_apps

_BUILTIN_COMMANDS_DIR = Path(__file__).resolve().parent / "commands"


def list_available_commands(project_dir: Path | None = None) -> list[str]:
    command_names = set(_discover_file_commands(_BUILTIN_COMMANDS_DIR))

    if project_dir is not None:
        command_names.update(_discover_file_commands(_project_commands_dir(project_dir)))
        for app in get_installed_apps(project_dir, required=False):
            command_names.update(_discover_file_commands(app.commands_dir))

    return sorted(command_names)


def load_command_class(name: str, project_dir: Path | None = None) -> type[BaseCommand]:
    project_commands = _project_commands_dir(project_dir) if project_dir else None
    project_command_file = (
        project_commands / f"{name}.py" if project_commands is not None else None
    )

    if project_command_file is not None and project_command_file.exists():
        module = _load_module_from_path(project_command_file)
        return _extract_command_class(module, str(project_command_file))

    if project_dir is not None:
        for app in get_installed_apps(project_dir, required=False):
            app_command_file = app.commands_dir / f"{name}.py"
            if app_command_file.exists():
                module = _load_module_from_path(app_command_file)
                return _extract_command_class(module, str(app_command_file))

    builtin_module_name = f"ferrum.management.commands.{name}"
    try:
        module = importlib.import_module(builtin_module_name)
    except ModuleNotFoundError as err:
        if err.name == builtin_module_name:
            raise CommandNotFoundError(f"unknown command '{name}'") from err
        raise

    return _extract_command_class(module, builtin_module_name)


def _discover_file_commands(commands_dir: Path) -> list[str]:
    if not commands_dir.exists() or not commands_dir.is_dir():
        return []

    names: list[str] = []
    for path in sorted(commands_dir.glob("*.py")):
        if path.stem == "__init__" or path.stem.startswith("_"):
            continue
        if path.stem.isidentifier():
            names.append(path.stem)

    return names


def _project_commands_dir(project_dir: Path) -> Path:
    return project_dir / "management" / "commands"


def _load_module_from_path(path: Path) -> ModuleType:
    module_name = f"_ferrum_project_command_{path.stem}_{abs(hash(path.resolve()))}"
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"failed to load command module from {path}")

    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _extract_command_class(module: ModuleType, source: str) -> type[BaseCommand]:
    command_cls = getattr(module, "Command", None)
    if command_cls is None:
        raise TypeError(f"command module '{source}' must define a Command class")

    if not isinstance(command_cls, type) or not issubclass(command_cls, BaseCommand):
        raise TypeError(
            f"Command in '{source}' must subclass ferrum.management.base.BaseCommand"
        )

    return command_cls
