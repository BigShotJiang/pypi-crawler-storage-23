"""App registry used during Ferrum startup."""

from __future__ import annotations

import importlib
from dataclasses import dataclass
from pathlib import Path
from types import ModuleType
from typing import Any, Iterable

from ferrum.conf import ImproperlyConfigured


@dataclass(frozen=True)
class AppConfig:
    entry: str
    name: str
    label: str
    module: ModuleType
    path: Path
    config_class_path: str | None = None
    config_instance: object | None = None

    @property
    def models_module_name(self) -> str:
        return f"{self.name}.models"

    @property
    def commands_dir(self) -> Path:
        return self.path / "management" / "commands"

    @property
    def migrations_dir(self) -> Path:
        return self.path / "migrations"


class Apps:
    def __init__(self) -> None:
        self.app_configs: dict[str, AppConfig] = {}
        self.ready = False
        self._loaded_signature: tuple[str, ...] | None = None

    def clear(self) -> None:
        self.app_configs.clear()
        self.ready = False
        self._loaded_signature = None

    def populate(self, installed_apps: Iterable[str]) -> None:
        app_entries = tuple(self._normalize_app_entry(name) for name in installed_apps)

        if self.ready and self._loaded_signature == app_entries:
            return

        self.clear()

        for app_entry in app_entries:
            config = self._create_config(app_entry)
            if config.label in self.app_configs:
                raise ImproperlyConfigured(
                    f"duplicate app label '{config.label}' in INSTALLED_APPS"
                )
            self.app_configs[config.label] = config
            self._import_models(config)
        self._run_ready_hooks()

        self.ready = True
        self._loaded_signature = app_entries

    def get_app_configs(self) -> list[AppConfig]:
        return list(self.app_configs.values())

    def get_app_labels(self) -> list[str]:
        return sorted(self.app_configs)

    def _normalize_app_entry(self, value: str) -> str:
        if not isinstance(value, str) or not value.strip():
            raise ImproperlyConfigured(
                "INSTALLED_APPS entries must be non-empty strings"
            )
        return value.strip()

    def _create_config(self, app_entry: str) -> AppConfig:
        config = self._create_config_from_class_path(app_entry)
        if config is not None:
            return config

        return self._create_config_from_module_path(app_entry)

    def _create_config_from_module_path(self, app_name: str) -> AppConfig:
        try:
            module = importlib.import_module(app_name)
        except ModuleNotFoundError as err:
            if err.name == app_name:
                raise ImproperlyConfigured(
                    f"installed app '{app_name}' cannot be imported"
                ) from err
            raise ImproperlyConfigured(
                f"failed importing app '{app_name}': {err}"
            ) from err

        discovered = self._discover_default_config(app_name)
        if discovered is not None:
            config_instance, config_class_path = discovered
            configured_name = getattr(config_instance, "name", None)
            if configured_name != app_name:
                raise ImproperlyConfigured(
                    f"default AppConfig for '{app_name}' must set name = '{app_name}'"
                )
            label = self._resolve_app_label(
                app_name,
                getattr(config_instance, "label", None),
            )
        else:
            config_instance = None
            config_class_path = None
            label = app_name.rsplit(".", 1)[-1]

        if not label.isidentifier():
            raise ImproperlyConfigured(
                f"app label '{label}' from '{app_name}' is not a valid identifier"
            )

        return AppConfig(
            entry=app_name,
            name=app_name,
            label=label,
            module=module,
            path=self._module_path(module),
            config_class_path=config_class_path,
            config_instance=config_instance,
        )

    def _create_config_from_class_path(self, app_entry: str) -> AppConfig | None:
        module_path, separator, class_name = app_entry.rpartition(".")
        if not separator:
            return None
        if not class_name.isidentifier():
            return None

        try:
            config_module = importlib.import_module(module_path)
        except ModuleNotFoundError as err:
            if err.name == module_path:
                return None
            raise ImproperlyConfigured(
                f"failed importing app config module '{module_path}': {err}"
            ) from err

        config_class = getattr(config_module, class_name, None)
        if config_class is None:
            return None
        if not isinstance(config_class, type):
            raise ImproperlyConfigured(
                f"app config '{app_entry}' must reference a class"
            )

        try:
            config_instance = config_class()
        except Exception as err:
            raise ImproperlyConfigured(
                f"failed constructing app config '{app_entry}': {err}"
            ) from err

        app_name = getattr(config_instance, "name", None)
        if not isinstance(app_name, str) or not app_name.strip():
            raise ImproperlyConfigured(
                f"app config '{app_entry}' must define non-empty 'name'"
            )
        app_name = app_name.strip()

        try:
            module = importlib.import_module(app_name)
        except ModuleNotFoundError as err:
            if err.name == app_name:
                raise ImproperlyConfigured(
                    f"app config '{app_entry}' references missing app module '{app_name}'"
                ) from err
            raise ImproperlyConfigured(
                f"failed importing app module '{app_name}' for '{app_entry}': {err}"
            ) from err

        label = self._resolve_app_label(app_name, getattr(config_instance, "label", None))

        return AppConfig(
            entry=app_entry,
            name=app_name,
            label=label,
            module=module,
            path=self._module_path(module),
            config_class_path=app_entry,
            config_instance=config_instance,
        )

    def _discover_default_config(self, app_name: str) -> tuple[object, str] | None:
        module_name = f"{app_name}.apps"
        try:
            module = importlib.import_module(module_name)
        except ModuleNotFoundError as err:
            if err.name == module_name:
                return None
            raise ImproperlyConfigured(
                f"failed importing app config module '{module_name}': {err}"
            ) from err

        matching: list[tuple[str, type]] = []
        fallback: list[tuple[str, type]] = []
        for attribute in dir(module):
            candidate = getattr(module, attribute)
            if not isinstance(candidate, type):
                continue
            configured_name = getattr(candidate, "name", None)
            if configured_name == app_name:
                matching.append((attribute, candidate))
                continue
            if isinstance(configured_name, str) and configured_name:
                fallback.append((attribute, candidate))

        selected: tuple[str, type] | None = None
        if len(matching) == 1:
            selected = matching[0]
        elif len(matching) > 1:
            raise ImproperlyConfigured(
                f"multiple AppConfig classes in '{module_name}' declare name '{app_name}'"
            )
        elif len(fallback) == 1:
            selected = fallback[0]
        elif len(fallback) > 1:
            raise ImproperlyConfigured(
                f"multiple AppConfig candidates found in '{module_name}'"
            )
        else:
            return None

        attr_name, config_class = selected
        class_path = f"{module_name}.{attr_name}"
        try:
            instance = config_class()
        except Exception as err:
            raise ImproperlyConfigured(
                f"failed constructing default app config '{class_path}': {err}"
            ) from err
        return instance, class_path

    def _resolve_app_label(
        self,
        app_name: str,
        configured_label: Any,
    ) -> str:
        if configured_label is None:
            label = app_name.rsplit(".", 1)[-1]
        else:
            if not isinstance(configured_label, str) or not configured_label.strip():
                raise ImproperlyConfigured(
                    f"app '{app_name}' has invalid label '{configured_label}'"
                )
            label = configured_label.strip()

        if not label.isidentifier():
            raise ImproperlyConfigured(
                f"app label '{label}' from '{app_name}' is not a valid identifier"
            )
        return label

    def _import_models(self, config: AppConfig) -> None:
        module_name = config.models_module_name
        try:
            importlib.import_module(module_name)
        except ModuleNotFoundError as err:
            if err.name == module_name:
                return
            raise ImproperlyConfigured(
                f"failed importing models for app '{config.label}': {err}"
            ) from err

    def _run_ready_hooks(self) -> None:
        for config in self.app_configs.values():
            instance = config.config_instance
            if instance is None:
                continue

            ready = getattr(instance, "ready", None)
            if ready is None:
                continue
            if not callable(ready):
                raise ImproperlyConfigured(
                    f"app config '{config.config_class_path}' defines non-callable ready"
                )
            ready()

    def _module_path(self, module: ModuleType) -> Path:
        file_value: Any = getattr(module, "__file__", None)
        if isinstance(file_value, str):
            return Path(file_value).resolve().parent

        package_path: Any = getattr(module, "__path__", None)
        if package_path:
            first = next(iter(package_path), None)
            if isinstance(first, str):
                return Path(first).resolve()

        raise ImproperlyConfigured(
            f"cannot resolve filesystem path for app '{module.__name__}'"
        )


apps = Apps()

__all__ = ["AppConfig", "Apps", "apps"]
