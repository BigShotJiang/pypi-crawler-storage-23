"""Settings loader inspired by Django's LazySettings."""

from __future__ import annotations

import importlib
import os
from typing import Any

from . import global_settings

ENVIRONMENT_VARIABLE = "FERRUM_SETTINGS_MODULE"


class ImproperlyConfigured(Exception):
    """Raised when Ferrum settings cannot be loaded."""


class Settings:
    def __init__(self, settings_module: str) -> None:
        self.SETTINGS_MODULE = settings_module
        self._load_defaults()
        self._load_module(settings_module)
        self._validate_contract()

    def _load_defaults(self) -> None:
        for setting_name in dir(global_settings):
            if setting_name.isupper():
                setattr(self, setting_name, getattr(global_settings, setting_name))

    def _load_module(self, settings_module: str) -> None:
        try:
            module = importlib.import_module(settings_module)
        except ModuleNotFoundError as err:
            if err.name == settings_module:
                raise ImproperlyConfigured(
                    f"settings module '{settings_module}' could not be imported"
                ) from err
            raise ImproperlyConfigured(
                f"failed loading settings module '{settings_module}': {err}"
            ) from err

        for setting_name in dir(module):
            if setting_name.isupper():
                setattr(self, setting_name, getattr(module, setting_name))

    def _validate_contract(self) -> None:
        root_urlconf = getattr(self, "ROOT_URLCONF", None)
        if not isinstance(root_urlconf, str) or not root_urlconf.strip():
            raise ImproperlyConfigured("ROOT_URLCONF must be a non-empty string")

        installed_apps = getattr(self, "INSTALLED_APPS", None)
        if not isinstance(installed_apps, (list, tuple)):
            raise ImproperlyConfigured("INSTALLED_APPS must be a list or tuple of app paths")

        for index, app in enumerate(installed_apps):
            if not isinstance(app, str) or not app.strip():
                raise ImproperlyConfigured(
                    f"INSTALLED_APPS[{index}] must be a non-empty string"
                )

        middleware = getattr(self, "MIDDLEWARE", None)
        if not isinstance(middleware, (list, tuple)):
            raise ImproperlyConfigured("MIDDLEWARE must be a list or tuple of dotted paths")

        for index, entry in enumerate(middleware):
            if not isinstance(entry, str) or not entry.strip():
                raise ImproperlyConfigured(
                    f"MIDDLEWARE[{index}] must be a non-empty dotted path string"
                )

        databases = getattr(self, "DATABASES", None)
        if not isinstance(databases, dict):
            raise ImproperlyConfigured("DATABASES must be a dict")

        default_db = databases.get("default")
        if not isinstance(default_db, dict):
            raise ImproperlyConfigured("DATABASES must define a 'default' dict")

        engine = default_db.get("ENGINE")
        if not isinstance(engine, str) or not engine.strip():
            raise ImproperlyConfigured(
                "DATABASES['default']['ENGINE'] must be a non-empty string"
            )

        name = default_db.get("NAME")
        url = default_db.get("URL")
        if not (
            (isinstance(name, str) and bool(name.strip()))
            or (isinstance(url, str) and bool(url.strip()))
        ):
            raise ImproperlyConfigured(
                "DATABASES['default'] must define a non-empty NAME or URL"
            )

        port = getattr(self, "PORT", None)
        if isinstance(port, bool) or not isinstance(port, int) or port <= 0:
            raise ImproperlyConfigured("PORT must be a positive integer")


class LazySettings:
    def __init__(self) -> None:
        self._wrapped: Settings | None = None

    def _setup(self) -> None:
        settings_module = os.environ.get(ENVIRONMENT_VARIABLE)
        if not settings_module:
            raise ImproperlyConfigured(
                f"{ENVIRONMENT_VARIABLE} is not set. "
                "Set it to '<project>.settings' before using Ferrum."
            )
        self._wrapped = Settings(settings_module)

    def configure(self, *, settings_module: str) -> None:
        os.environ[ENVIRONMENT_VARIABLE] = settings_module
        self._wrapped = Settings(settings_module)

    def reset(self) -> None:
        self._wrapped = None

    def __getattr__(self, name: str) -> Any:
        if self._wrapped is None:
            self._setup()
        return getattr(self._wrapped, name)

    @property
    def configured(self) -> bool:
        return self._wrapped is not None


settings = LazySettings()

__all__ = [
    "ENVIRONMENT_VARIABLE",
    "ImproperlyConfigured",
    "LazySettings",
    "Settings",
    "settings",
]
