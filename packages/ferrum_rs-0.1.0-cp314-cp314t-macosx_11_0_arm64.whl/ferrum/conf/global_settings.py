"""Default settings for Ferrum projects."""

DEBUG = True
PORT = 8000

INSTALLED_APPS: list[str] = []
MIDDLEWARE: list[str] = []
ROOT_URLCONF = "urls"

DATABASES = {
    "default": {
        "ENGINE": "ferrum.db.backends.sqlite3",
        "NAME": "ferrum.sqlite",
    }
}
