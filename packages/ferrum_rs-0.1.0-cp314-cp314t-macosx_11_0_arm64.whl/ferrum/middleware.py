"""Middleware pipeline utilities for Ferrum request handling."""

from __future__ import annotations

import importlib
from collections.abc import Callable, Iterable
from typing import Any

from ferrum.http import HttpResponse

_REQUEST_CONTEXTS: dict[int, dict[str, object]] = {}


def clear_request_context(request: Any) -> None:
    _REQUEST_CONTEXTS.pop(id(request), None)
    if hasattr(request, "context"):
        try:
            request.context = {}
        except Exception:
            pass


def attach_request_context(
    request: Any, path_params: dict[str, object] | None = None
) -> None:
    params = dict(path_params or {})
    context = {
        "method": getattr(request, "method", None),
        "path": getattr(request, "path", None),
        "headers": dict(getattr(request, "headers", {}) or {}),
        "query_params": dict(getattr(request, "query_params", {}) or {}),
        "path_params": params,
    }
    try:
        request.context = context
    except Exception:
        _REQUEST_CONTEXTS[id(request)] = context


def get_request_context(request: Any) -> dict[str, object]:
    direct = getattr(request, "context", None)
    if isinstance(direct, dict):
        return direct
    return dict(_REQUEST_CONTEXTS.get(id(request), {}))


def load_middleware(middleware_paths: Iterable[str]) -> list[object]:
    loaded: list[object] = []
    for entry in middleware_paths:
        module_path, separator, attr = entry.rpartition(".")
        if not separator:
            raise RuntimeError(
                f"invalid middleware path '{entry}'; expected 'module.Class'"
            )

        try:
            module = importlib.import_module(module_path)
        except ModuleNotFoundError as err:
            if err.name == module_path:
                raise RuntimeError(
                    f"middleware module '{module_path}' could not be imported"
                ) from err
            raise RuntimeError(
                f"failed importing middleware module '{module_path}': {err}"
            ) from err

        middleware_type = getattr(module, attr, None)
        if middleware_type is None:
            raise RuntimeError(f"middleware '{entry}' does not define '{attr}'")
        if not isinstance(middleware_type, type):
            raise RuntimeError(f"middleware '{entry}' must reference a class")

        try:
            loaded.append(middleware_type())
        except Exception as err:
            raise RuntimeError(
                f"failed to instantiate middleware '{entry}': {err}"
            ) from err

    return loaded


def build_middleware_chain(
    view: Callable[..., Any],
    middleware_stack: Iterable[object],
) -> Callable[..., Any]:
    middlewares = list(middleware_stack)

    def execute(request: Any, **path_params: object) -> Any:
        attach_request_context(request, path_params)
        called: list[object] = []

        try:
            response: Any | None = None
            for middleware in middlewares:
                called.append(middleware)
                process_request = getattr(middleware, "process_request", None)
                if callable(process_request):
                    maybe_response = process_request(request)
                    if maybe_response is not None:
                        response = _coerce_response(maybe_response)
                        break

            if response is None:
                response = _coerce_response(view(request, **path_params))
        except Exception as err:
            handled: Any | None = None
            for middleware in reversed(called):
                process_exception = getattr(middleware, "process_exception", None)
                if not callable(process_exception):
                    continue
                maybe_response = process_exception(request, err)
                if maybe_response is not None:
                    handled = _coerce_response(maybe_response)
                    break

            if handled is None:
                raise
            response = handled
        finally:
            clear_request_context(request)

        for middleware in reversed(called):
            process_response = getattr(middleware, "process_response", None)
            if callable(process_response):
                response = _coerce_response(process_response(request, response))

        return response

    return execute


def _coerce_response(value: Any) -> HttpResponse:
    if isinstance(value, HttpResponse):
        return value
    return HttpResponse(str(value))


__all__ = [
    "attach_request_context",
    "build_middleware_chain",
    "clear_request_context",
    "get_request_context",
    "load_middleware",
]
