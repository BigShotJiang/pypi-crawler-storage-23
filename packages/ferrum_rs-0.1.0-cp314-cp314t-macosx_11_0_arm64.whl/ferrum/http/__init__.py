"""High-fidelity HTTP primitives for Ferrum."""

from __future__ import annotations

import json
from typing import Mapping


class HttpResponse:
    def __init__(
        self,
        body: str = "",
        *,
        status: int = 200,
        headers: Mapping[str, str] | None = None,
        content_type: str = "text/plain; charset=utf-8",
    ) -> None:
        self.body = str(body)
        self.status_code = int(status)
        self.headers = dict(headers or {})
        self.headers.setdefault("Content-Type", content_type)


class JsonResponse(HttpResponse):
    def __init__(
        self,
        data: object,
        *,
        status: int = 200,
        headers: Mapping[str, str] | None = None,
    ) -> None:
        body = json.dumps(data, separators=(",", ":"), sort_keys=True)
        super().__init__(
            body=body,
            status=status,
            headers=headers,
            content_type="application/json",
        )


__all__ = ["HttpResponse", "JsonResponse"]
