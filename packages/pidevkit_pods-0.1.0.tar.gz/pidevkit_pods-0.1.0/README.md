# pidevkit-pods

CLI package for pod management and model lifecycle operations.

## Install

```bash
pip install pidevkit-pods
```

## CLI

```bash
pi --help
# or
pi-pods --help
```
