import mitsuba as mi

import mitsuba_scene_description as msd

mi.set_variant("cuda_ad_rgb")

blended = msd.BlendedMaterial(
    weight=0.5,
    bsdf=[
        msd.SmoothDiffuseMaterial(reflectance=msd.SrgbSpectrum(color=[0.8, 0.2, 0.2])),
        msd.RoughConductorMaterial(),
    ],
)
sun = msd.Sphere(
    radius=1.0,
    bsdf=blended,
    to_world=msd.Transform().translate(0, 0, 3).scale(0.4),
)

cam = msd.OrthographicCamera(
    to_world=msd.Transform().look_at(origin=[0, 0, -6], target=[0, 0, 0], up=[0, 1, 0])
)

integrator = msd.DirectIlluminationIntegrator()
emitter = msd.ConstantEnvironmentEmitter()

scene = (
    msd.SceneBuilder()
    .integrator(integrator)
    .sensor(cam)
    .shape("sun", sun)
    .emitter("emitter", emitter)
    .build()
)

__import__("pprint").pprint(scene)

mi_scene = mi.load_dict(scene.to_dict())
rndr = mi.render(mi_scene)
mi.util.write_bitmap("test.png", rndr)
