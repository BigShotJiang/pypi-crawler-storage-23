"""
Analytics submodule - Analytics-specific report components
"""
# Import analytics classes as they're defined


