DEFAULT_SETTING: str = "unchanged default"
EXPLICIT_SETTING: str = "unchanged explicit"
ENV_SETTING: int = 0
EXPLICIT_OVERRIDDEN_SETTING: str = "default value"
NULLABLE_SETTING: int | None = None
