# -*- coding: utf-8 -*-
import uuid
from ddans.dbase.field import DBField
from ddans.dbase.model import DBModel


class DBase(DBModel):

    _fields = {
        'id':
        DBField('INTEGER',
                primary_key=True,
                autoincrement=True,
                nullable=False),
        'rid':
        DBField('TEXT', nullable=False),
        'tag':
        DBField('TEXT', default="''"),
        'desc':
        DBField('TEXT', default="''"),
        'memo':
        DBField('TEXT', default="''"),
        'created':
        DBField('TIMESTAMP'),
        'updated':
        DBField('TIMESTAMP')
    }

    def __init__(self, **kwargs):
        self.rid = str(uuid.uuid4())
        for key, value in kwargs.items():
            if key in self._fields:
                setattr(self, key, value)
        for field_name, field in self._fields.items():
            if not hasattr(self, field_name):
                setattr(self, field_name, field.default)
