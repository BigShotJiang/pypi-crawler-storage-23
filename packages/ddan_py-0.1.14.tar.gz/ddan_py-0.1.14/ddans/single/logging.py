# -*- coding: utf-8 -*-
import logging
import sys
from time import strftime

from ddans.native.system import NSystem
from ddans.descriptor.singleton import singleton

# 设置日志格式#和时间格式
FMT = '[%(asctime)s] [%(levelname)s] [%(filename)s] [%(funcName)s]: \
%(message)s'

DATEFMT = '%Y-%m-%d %H:%M:%S'


@singleton
class SLogging(object):

    def __init__(self):
        self.logger = logging.getLogger()
        self.formatter = logging.Formatter(fmt=FMT, datefmt=DATEFMT)
        self.log_filename = NSystem.get_full_path(
            "logs", '%s.log' % strftime("%Y-%m-%d"))
        NSystem.ensure_dir(self.log_filename)
        self.logger.addHandler(self.get_file_handler(self.log_filename))
        # self.logger.addHandler(self.get_console_handler())
        # 设置日志的默认级别
        self.logger.setLevel(logging.DEBUG)

    # 输出到文件handler的函数定义
    def get_file_handler(self, filename):
        filehandler = logging.FileHandler(filename, encoding="utf-8")
        filehandler.setFormatter(self.formatter)
        return filehandler

    # 输出到控制台handler的函数定义
    def get_console_handler(self):
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(self.formatter)
        return console_handler


# SLogger: logging.RootLogger = SLogging().logger
