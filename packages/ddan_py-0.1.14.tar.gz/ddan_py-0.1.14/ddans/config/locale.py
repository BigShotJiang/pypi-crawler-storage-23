LANG_DICT = {
    "zh-CN": "zh-CN",
    "en": "en-US",
    "ru": "ru-RU",
    "vi": "vi-VN",
    "pt": "pt-BR",
    "es": "es-LA",
    "tr": "tr-TR",
    "th": "th-TH",
    "uk": "uk-UA",
    "hi": "hi-IN",
    "it": "it-IT",
    "id": "id-ID",
    "ja": "ja-JP",
    "fr": "fr-FR",
    "zh-TW": "zh-TW"
}

LANG_BASE_DICT = {
    "zh-CN": "简体中文",
    "en": "英文",
    "ru": "俄语",
    "vi": "越南语",
    "pt": "葡萄牙语",
    "es": "西班牙语",
    "tr": "土耳其语",
    "th": "泰语",
    "uk": "乌克兰语",
    "hi": "印地语",
    "it": "意大利语",
    "id": "印尼语",
    "ja": "日语",
    "fr": "法语",
    "zh-TW": "繁体中文"
}

LANG_DESC_DICT = {
    "zh-CN": "简体中文",
    "en": "英文 English",
    "ru": "俄语 Русский",
    "vi": "越南语 Tiếng Việt",
    "pt": "葡萄牙语 Português",
    "es": "西班牙语 Español",
    "tr": "土耳其语 Türkçe",
    "th": "泰语 แบบไทย",
    "uk": "乌克兰语 Yкраїнська",
    "hi": "印地语 हिंदी",
    "it": "意大利语 Italiano",
    "id": "印尼语 Bahasa Indonesia",
    "ja": "日语 日本語",
    "fr": "法语",
    "zh-TW": "繁体中文 繁體中文",
}

DEFAULT_LANG = 'zh-CN'
