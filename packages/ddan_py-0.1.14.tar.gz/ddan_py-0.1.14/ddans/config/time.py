# -*- coding: utf-8 -*-

EXPIRATION_TIME = "2026-11-01T00:00:00"
