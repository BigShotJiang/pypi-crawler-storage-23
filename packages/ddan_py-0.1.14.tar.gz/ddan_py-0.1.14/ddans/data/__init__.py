"""Data module"""

from . import color

__all__ = ["color"]
