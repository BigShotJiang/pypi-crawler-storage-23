# -*- coding: utf-8 -*-

class StaticProperty:
    def __init__(self, fget=None, fset=None):
        self.fget = fget
        self.fset = fset

    def __get__(self, instance, owner):
        if self.fget is None:
            # raise AttributeError("Unreadable attribute")
            return None
        return self.fget(owner)

    def __set__(self, instance, value):
        if self.fset is None:
            # raise AttributeError("Can't set attribute")
            return
        self.fset(instance.__class__, value)

    def getter(self, fget):
        self.fget = fget
        return self

    def setter(self, fset):
        self.fset = fset
        return self
