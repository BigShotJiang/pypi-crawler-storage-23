# -*- coding: utf-8 -*-

from typing import Dict, List, Literal, Optional, Union

from ddans.common.type import Element
from ddans.native.html import NHtml


class DHtml:

    def __init__(self):
        self._content = ""

    def list(self,
             list: List[str],
             style: Optional[Dict[str, str | int]] = None,
             el: Literal["ol", "ul"] = "ul",
             type: Literal["1", "i", "a", "A", "i", "I"] = "1"):
        self._content += NHtml.list(list, style, el, type)
        return self

    def element(self,
                content: Union[str, List[str]],
                style: Optional[Dict[str, str | int]] = None,
                attribute: Optional[Dict[str, str]] = None,
                order: Optional[Literal["numeric", "alpha", "chinese"]] = None,
                el: Element = "p"):
        self._content += NHtml.line(content, style, attribute, order, el)
        return self

    def reset(self):
        self._content = ""

    @property
    def content(self):
        return self._content

    @property
    def body(self):
        return NHtml.element(self.content, "body")

    @property
    def html(self):
        return NHtml.element(self.body, "html")
