# -*- coding: utf-8 -*-

from ddans.native.system import NSystem


class NConfig():

    @staticmethod
    def app_data(path: str = ""):
        appData = NSystem.get_app_data()
        return NSystem.join(appData, 'ddan-py', path)
