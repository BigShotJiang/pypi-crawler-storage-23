"""
agentcents catalog.py
Pricing catalog — syncs from OpenRouter/LiteLLM, caches locally.

Local cache: ~/.agentcents/models.json
Auto-updates every 24h on agentcents sync or proxy startup.
"""

import json
import re
import time
import httpx
from pathlib import Path
from agentcents.db import get_connection, init_db

OPENROUTER_MODELS_URL  = "https://openrouter.ai/api/v1/models"
LITELLM_PRICES_URL     = "https://raw.githubusercontent.com/BerriAI/litellm/main/model_prices_and_context_window.json"
LABHAM_MODELS_URL      = "https://labham-agentcents.github.io/api/models.json"

FALLBACK_PATH          = Path(__file__).parent / "data" / "fallback.json"
LOCAL_MODELS_PATH      = Path.home() / ".agentcents" / "models.json"
CACHE_TTL_SECONDS      = 86400  # 24 hours


# ---------------------------------------------------------------------------
# Local models.json cache
# ---------------------------------------------------------------------------

def _ensure_config_dir():
    LOCAL_MODELS_PATH.parent.mkdir(parents=True, exist_ok=True)


def _load_local_models() -> list:
    """Load models from ~/.agentcents/models.json if fresh enough."""
    try:
        if not LOCAL_MODELS_PATH.exists():
            return []
        stat = LOCAL_MODELS_PATH.stat()
        age  = time.time() - stat.st_mtime
        if age > CACHE_TTL_SECONDS:
            return []
        with open(LOCAL_MODELS_PATH) as f:
            data = json.load(f)
            return data.get("models", [])
    except Exception:
        return []


def _save_local_models(models: list, source: str):
    """Write models to ~/.agentcents/models.json."""
    try:
        _ensure_config_dir()
        with open(LOCAL_MODELS_PATH, "w") as f:
            json.dump({
                "_version": "1.0.0",
                "_updated": time.strftime("%Y-%m-%d %H:%M:%S"),
                "_source":  source,
                "models":   models,
            }, f, indent=2)
    except Exception as e:
        import logging
        logging.getLogger("agentcents.catalog").warning(f"Could not save models.json: {e}")


# ---------------------------------------------------------------------------
# Sync check
# ---------------------------------------------------------------------------

def needs_sync():
    # Check local JSON first — faster than DB query
    if LOCAL_MODELS_PATH.exists():
        age = time.time() - LOCAL_MODELS_PATH.stat().st_mtime
        if age < CACHE_TTL_SECONDS:
            return False

    conn = get_connection()
    row  = conn.execute(
        "SELECT synced_at FROM sync_log WHERE success=1 ORDER BY synced_at DESC LIMIT 1"
    ).fetchone()
    conn.close()
    if not row:
        return True
    age = time.time() - time.mktime(time.strptime(row["synced_at"], "%Y-%m-%d %H:%M:%S"))
    return age > CACHE_TTL_SECONDS


# ---------------------------------------------------------------------------
# Fetchers
# ---------------------------------------------------------------------------

def fetch_openrouter():
    try:
        r = httpx.get(OPENROUTER_MODELS_URL, timeout=10)
        r.raise_for_status()
        models  = r.json().get("data", [])
        results = []
        for m in models:
            pricing      = m.get("pricing", {})
            input_price  = float(pricing.get("prompt", 0)) * 1_000_000
            output_price = float(pricing.get("completion", 0)) * 1_000_000
            if input_price < 0 or output_price < 0:
                continue
            results.append({
                "model_id":       m.get("id"),
                "provider":       m.get("id", "").split("/")[0],
                "display_name":   m.get("name", ""),
                "input_price":    input_price,
                "output_price":   output_price,
                "context_window": m.get("context_length", 0),
                "source":         "openrouter"
            })
        return results
    except Exception:
        return None


def fetch_litellm():
    try:
        r = httpx.get(LITELLM_PRICES_URL, timeout=10)
        r.raise_for_status()
        data    = r.json()
        results = []
        for model_id, info in data.items():
            if not isinstance(info, dict):
                continue
            input_price  = info.get("input_cost_per_token", 0)
            output_price = info.get("output_cost_per_token", 0)
            if not input_price and not output_price:
                continue
            results.append({
                "model_id":       model_id,
                "provider":       model_id.split("/")[0] if "/" in model_id else "unknown",
                "display_name":   model_id,
                "input_price":    float(input_price) * 1_000_000,
                "output_price":   float(output_price) * 1_000_000,
                "context_window": info.get("max_tokens", 0),
                "source":         "litellm"
            })
        return results
    except Exception:
        return None


def fetch_fallback():
    try:
        with open(FALLBACK_PATH) as f:
            return json.load(f)
    except Exception:
        return []


# ---------------------------------------------------------------------------
# Save to DB
# ---------------------------------------------------------------------------

def save_models(models, source):
    conn = get_connection()
    for m in models:
        conn.execute("""
            INSERT INTO models (model_id, provider, display_name,
                input_price, output_price, context_window, source)
            VALUES (:model_id, :provider, :display_name,
                :input_price, :output_price, :context_window, :source)
            ON CONFLICT(model_id) DO UPDATE SET
                input_price    = excluded.input_price,
                output_price   = excluded.output_price,
                context_window = excluded.context_window,
                source         = excluded.source,
                updated_at     = CURRENT_TIMESTAMP
        """, m)
        conn.execute("""
            INSERT INTO price_history (model_id, input_price, output_price, source)
            VALUES (:model_id, :input_price, :output_price, :source)
        """, m)
    conn.execute("""
        INSERT INTO sync_log (source, success, record_count)
        VALUES (?, 1, ?)
    """, (source, len(models)))
    conn.commit()
    conn.close()


# ---------------------------------------------------------------------------
# Main sync
# ---------------------------------------------------------------------------

def sync_catalog():
    init_db()
    if not needs_sync():
        return

    for fetch_fn, source in [
        (fetch_openrouter, "openrouter"),
        (fetch_litellm,    "litellm"),
        (fetch_fallback,   "fallback"),
    ]:
        models = fetch_fn()
        if models:
            save_models(models, source)
            _save_local_models(models, source)
            return


# ---------------------------------------------------------------------------
# Model ID normalization
# ---------------------------------------------------------------------------

def normalize_model_id(model_id: str) -> str:
    """
    Map provider-native model IDs to OpenRouter-style 'provider/model' IDs.

    Examples:
        claude-3-haiku-20240307      -> anthropic/claude-3-haiku
        claude-opus-4-20250514       -> anthropic/claude-opus-4
        gpt-4o                       -> openai/gpt-4o
        claude-sonnet-4-6            -> anthropic/claude-sonnet-4-6
    """
    if "/" in model_id:
        return model_id

    # Strip trailing date stamps like -20250514
    normalized = re.sub(r"-\d{8}$", "", model_id)

    PROVIDER_PREFIXES = [
        ("claude-",  "anthropic"),
        ("gpt-",     "openai"),
        ("o1",       "openai"),
        ("o3",       "openai"),
        ("gemini-",  "google"),
        ("grok-",    "xai"),
        ("llama-",   "meta-llama"),
        ("mistral-", "mistralai"),
        ("command-", "cohere"),
    ]

    for prefix, provider in PROVIDER_PREFIXES:
        if normalized.startswith(prefix) or normalized == prefix.rstrip("-"):
            if provider == "anthropic":
                # Handle claude-3-5 → claude-3.5 style normalization
                normalized = re.sub(r"^claude-3-5-", "claude-3.5-", normalized)
                normalized = re.sub(r"^claude-3-7-", "claude-3.7-", normalized)
            return f"{provider}/{normalized}"

    return model_id


# ---------------------------------------------------------------------------
# Price lookup — checks local JSON first, then DB
# ---------------------------------------------------------------------------

def get_model_price(model_id: str) -> dict:
    normalized = normalize_model_id(model_id)

    # 1. Try local models.json (fast, no DB)
    local = _load_local_models()
    if local:
        for m in local:
            if m.get("model_id") == normalized or m.get("model_id") == model_id:
                return {"input": m["input_price"], "output": m["output_price"]}

    # 2. Fall back to DB
    conn = get_connection()
    row  = conn.execute(
        "SELECT input_price, output_price FROM models WHERE model_id=?",
        (normalized,)
    ).fetchone()
    if not row and normalized != model_id:
        row = conn.execute(
            "SELECT input_price, output_price FROM models WHERE model_id=?",
            (model_id,)
        ).fetchone()
    conn.close()

    if row:
        return {"input": row["input_price"], "output": row["output_price"]}
    return {"input": 0.0, "output": 0.0}
