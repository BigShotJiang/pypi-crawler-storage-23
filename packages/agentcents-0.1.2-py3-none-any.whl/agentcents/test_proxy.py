"""
test_proxy.py — smoke test Phase 2 proxy without a real provider.

Run with:  python test_proxy.py
Requires:  pip install httpx
"""

import json
import httpx

PROXY = "http://localhost:8082"

# Simulate an OpenAI-style request routed through the proxy
# (using httpbin as a mock "provider" that just echoes the request)
MOCK_PROVIDER = "https://httpbin.org"

payload = {
    "model": "openai/gpt-4o",
    "messages": [{"role": "user", "content": "hello"}],
    "stream": False,
}

print("Sending test request through agentcents proxy...")
try:
    resp = httpx.post(
        f"{PROXY}/post",                          # httpbin echoes POST to /post
        headers={
            "X-Agentcents-Target": MOCK_PROVIDER,
            "X-Agentcents-Tag":    "smoke-test",
            "Content-Type":        "application/json",
            "Authorization":       "Bearer sk-fake",
        },
        json=payload,
        timeout=15,
    )
    print(f"Status: {resp.status_code}")
    print(json.dumps(resp.json(), indent=2)[:500])
except httpx.ConnectError:
    print("Proxy not running — start it with: uvicorn proxy:app --port 8082 --reload")
