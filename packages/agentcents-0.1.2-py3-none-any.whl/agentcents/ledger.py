"""
agentcents ledger.py — Phase 6
Records every proxied call to SQLite for cost reporting.
Adds session_id for multi-agent tracking and rolling budget queries.
"""

import sqlite3
import time
from pathlib import Path
from typing import Optional

DB_PATH = Path(__file__).parent / "data" / "ledger.db"


def _conn() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with _conn() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS calls (
                id                INTEGER PRIMARY KEY AUTOINCREMENT,
                ts                REAL    NOT NULL,
                model_id          TEXT,
                tag               TEXT    DEFAULT 'default',
                session_id        TEXT    DEFAULT 'default',
                prompt_tokens     INTEGER,
                completion_tokens INTEGER,
                cost_usd          REAL,
                elapsed_s         REAL,
                status            INTEGER,
                streamed          INTEGER DEFAULT 0
            )
        """)
        # Migrate: add session_id if upgrading from older schema
        try:
            conn.execute("ALTER TABLE calls ADD COLUMN session_id TEXT DEFAULT 'default'")
        except Exception:
            pass  # column already exists

        conn.execute("CREATE INDEX IF NOT EXISTS idx_calls_ts         ON calls(ts)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_calls_model      ON calls(model_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_calls_tag        ON calls(tag)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_calls_session    ON calls(session_id)")
        conn.commit()


def record_call(
    *,
    model_id: Optional[str],
    tag: str = "default",
    session_id: str = "default",
    prompt_tokens: Optional[int],
    completion_tokens: Optional[int],
    cost_usd: Optional[float],
    elapsed_s: float,
    status: int,
    streamed: bool = False,
):
    init_db()
    with _conn() as conn:
        conn.execute("""
            INSERT INTO calls
              (ts, model_id, tag, session_id, prompt_tokens, completion_tokens,
               cost_usd, elapsed_s, status, streamed)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            time.time(), model_id, tag, session_id, prompt_tokens, completion_tokens,
            cost_usd, elapsed_s, status, int(streamed)
        ))
        conn.commit()

    # Check budget thresholds after every successful call
    if status < 400 and cost_usd is not None:
        try:
            from agentcents.alerts import check_budgets
            check_budgets(tag=tag)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Basic reporting (Phase 3)
# ---------------------------------------------------------------------------

def summary(tag: Optional[str] = None, since_hours: float = 24):
    """Cost summary for the last N hours, optionally filtered by tag."""
    init_db()
    since_ts = time.time() - since_hours * 3600
    where = "WHERE ts >= ?"
    params = [since_ts]
    if tag:
        where += " AND tag = ?"
        params.append(tag)

    with _conn() as conn:
        rows = conn.execute(f"""
            SELECT
                model_id,
                tag,
                COUNT(*)                        AS calls,
                SUM(prompt_tokens)              AS total_prompt,
                SUM(completion_tokens)          AS total_completion,
                SUM(cost_usd)                   AS total_cost,
                AVG(elapsed_s)                  AS avg_latency,
                SUM(CASE WHEN status >= 400 THEN 1 ELSE 0 END) AS errors
            FROM calls
            {where}
            GROUP BY model_id, tag
            ORDER BY total_cost DESC
        """, params).fetchall()
    return [dict(r) for r in rows]


def recent(n: int = 20):
    """Return the N most recent calls."""
    init_db()
    with _conn() as conn:
        rows = conn.execute("""
            SELECT * FROM calls ORDER BY ts DESC LIMIT ?
        """, (n,)).fetchall()
    return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# Phase 6: Rolling budgets
# ---------------------------------------------------------------------------

def rolling_spend(days: int = 30, tag: Optional[str] = None) -> float:
    """Total spend over the last N days (rolling window)."""
    init_db()
    since = time.time() - days * 86400
    with _conn() as conn:
        q = "SELECT SUM(cost_usd) FROM calls WHERE ts >= ? AND cost_usd IS NOT NULL"
        params = [since]
        if tag:
            q += " AND tag = ?"
            params.append(tag)
        row = conn.execute(q, params).fetchone()
    return row[0] or 0.0


def rolling_summary(days: int = 30):
    """Day-by-day cost breakdown for the last N days."""
    init_db()
    since = time.time() - days * 86400
    with _conn() as conn:
        rows = conn.execute("""
            SELECT
                date(ts, 'unixepoch', 'localtime') AS day,
                COUNT(*)                            AS calls,
                SUM(cost_usd)                       AS total_cost,
                SUM(prompt_tokens)                  AS total_prompt,
                SUM(completion_tokens)              AS total_completion
            FROM calls
            WHERE ts >= ? AND cost_usd IS NOT NULL
            GROUP BY day
            ORDER BY day DESC
        """, (since,)).fetchall()
    return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# Phase 6: Multi-agent tracking
# ---------------------------------------------------------------------------

def agent_summary(since_hours: float = 24):
    """Per-session cost breakdown — one row per agent/session."""
    init_db()
    since = time.time() - since_hours * 3600
    with _conn() as conn:
        rows = conn.execute("""
            SELECT
                session_id,
                tag,
                COUNT(*)                        AS calls,
                SUM(prompt_tokens)              AS total_prompt,
                SUM(completion_tokens)          AS total_completion,
                SUM(cost_usd)                   AS total_cost,
                AVG(elapsed_s)                  AS avg_latency,
                MIN(ts)                         AS first_call,
                MAX(ts)                         AS last_call,
                SUM(CASE WHEN status >= 400 THEN 1 ELSE 0 END) AS errors
            FROM calls
            WHERE ts >= ?
            GROUP BY session_id, tag
            ORDER BY total_cost DESC
        """, (since,)).fetchall()
    return [dict(r) for r in rows]


def agent_recent(session_id: str, n: int = 20):
    """Recent calls for a specific session/agent."""
    init_db()
    with _conn() as conn:
        rows = conn.execute("""
            SELECT * FROM calls
            WHERE session_id = ?
            ORDER BY ts DESC LIMIT ?
        """, (session_id, n)).fetchall()
    return [dict(r) for r in rows]
