"""
agentcents cache.py — Phase 9
Semantic deduplication cache using fastembed + sqlite-vec.

Flow:
  1. Prompt → embed with fastembed (local CPU, BAAI/bge-small-en-v1.5)
  2. Search sqlite-vec for similar past prompts
  3. Hit (similarity > threshold) → return cached response, $0 cost
  4. Miss → forward to provider, store embedding + response

Requires:
  pip install fastembed sqlite-vec

Premium feature — gated by features.py
"""

import json
import time
import struct
import logging
import hashlib
from pathlib import Path
from typing import Optional

logger = logging.getLogger("agentcents.cache")

DB_PATH    = Path(__file__).parent / "data" / "ledger.db"
MODEL_NAME = "BAAI/bge-small-en-v1.5"   # 33MB, fast on CPU
DIMENSION  = 384

DEFAULT_THRESHOLD = 0.85   # cosine similarity — tune per use case(was 92)
DEFAULT_TTL_HOURS = 24


# ---------------------------------------------------------------------------
# DB + sqlite-vec setup
# ---------------------------------------------------------------------------

def _conn():
    import sqlite3
    DB_PATH.parent.mkdir(exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    _load_vec(conn)
    return conn


def _load_vec(conn):
    try:
        import sqlite_vec
        conn.enable_load_extension(True)
        sqlite_vec.load(conn)
        conn.enable_load_extension(False)
    except Exception as e:
        logger.warning(f"sqlite-vec not available: {e}")


def init_cache_tables():
    """Call once at proxy startup to ensure tables exist."""
    try:
        conn = _conn()
        conn.execute("""
            CREATE TABLE IF NOT EXISTS cache_entries (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                ts            REAL    NOT NULL,
                model_id      TEXT    NOT NULL,
                prompt_hash   TEXT    NOT NULL,
                prompt_text   TEXT    NOT NULL,
                response_json TEXT    NOT NULL,
                hit_count     INTEGER DEFAULT 0,
                cost_saved    REAL    DEFAULT 0.0
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_cache_model ON cache_entries(model_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_cache_hash  ON cache_entries(prompt_hash)")
        conn.execute(f"""
            CREATE VIRTUAL TABLE IF NOT EXISTS cache_vectors
            USING vec0(embedding FLOAT[{DIMENSION}])
        """)
        conn.commit()
        conn.close()
        logger.info("Semantic cache tables ready")
    except Exception as e:
        logger.warning(f"Semantic cache init failed: {e}")


# ---------------------------------------------------------------------------
# Embedder (lazy singleton)
# ---------------------------------------------------------------------------

_embedder = None

def _get_embedder():
    global _embedder
    if _embedder is None:
        try:
            from fastembed import TextEmbedding
            _embedder = TextEmbedding(model_name=MODEL_NAME)
            logger.info(f"Loaded embedding model: {MODEL_NAME}")
        except ImportError:
            logger.warning("fastembed not installed — pip install fastembed")
        except Exception as e:
            logger.warning(f"Embedding model load failed: {e}")
    return _embedder


def _embed(text: str) -> Optional[list]:
    embedder = _get_embedder()
    if not embedder:
        return None
    try:
        return list(embedder.embed([text]))[0].tolist()
    except Exception as e:
        logger.warning(f"Embed failed: {e}")
        return None


# ---------------------------------------------------------------------------
# Prompt extraction
# ---------------------------------------------------------------------------

def _extract_prompt(body_json: dict) -> Optional[str]:
    """Extract prompt text from OpenAI or Anthropic request body."""
    if not body_json:
        return None
    messages = body_json.get("messages", [])
    if messages:
        parts = []
        for m in messages:
            content = m.get("content", "")
            if isinstance(content, str):
                parts.append(content)
            elif isinstance(content, list):
                for c in content:
                    if isinstance(c, dict) and c.get("type") == "text":
                        parts.append(c.get("text", ""))
        return " ".join(parts) if parts else None
    return body_json.get("prompt")


def _prompt_hash(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()[:16]


# ---------------------------------------------------------------------------
# Cache lookup
# ---------------------------------------------------------------------------

def lookup(
    body_json: dict,
    model_id: str,
    threshold: float = DEFAULT_THRESHOLD,
    ttl_hours: float = DEFAULT_TTL_HOURS,
) -> Optional[dict]:
    """
    Look up a semantically similar cached response.
    Returns cached response dict or None on miss.
    """
    prompt = _extract_prompt(body_json)
    if not prompt:
        return None

    vec = _embed(prompt)
    if vec is None:
        return None

    vec_bytes = struct.pack(f"{DIMENSION}f", *vec)
    since_ts  = time.time() - ttl_hours * 3600

    try:
        conn = _conn()
        rows = conn.execute(f"""
            SELECT
                ce.id,
                ce.response_json,
                cv.distance
            FROM cache_vectors cv
            JOIN cache_entries ce ON ce.rowid = cv.rowid
            WHERE cv.embedding MATCH ?
              AND ce.model_id = ?
              AND ce.ts >= ?
              AND k = 1
            ORDER BY cv.distance
        """, (vec_bytes, model_id, since_ts)).fetchall()

        if not rows:
            conn.close()
            return None

        row        = rows[0]
        distance   = row["distance"]
        similarity = 1.0 / (1.0 + distance)

        if similarity < threshold:
            conn.close()
            return None

        conn.execute(
            "UPDATE cache_entries SET hit_count = hit_count + 1 WHERE id = ?",
            (row["id"],)
        )
        conn.commit()
        conn.close()

        logger.info(f"Semantic HIT  model={model_id}  similarity={similarity:.3f}")
        return json.loads(row["response_json"])

    except Exception as e:
        logger.warning(f"Semantic lookup failed: {e}")
        return None


# ---------------------------------------------------------------------------
# Cache store
# ---------------------------------------------------------------------------

def store(
    body_json: dict,
    model_id: str,
    response_json: dict,
    cost_usd: float = 0.0,
):
    """Store a prompt+response in the semantic cache."""
    prompt = _extract_prompt(body_json)
    if not prompt:
        return

    vec = _embed(prompt)
    if vec is None:
        return

    vec_bytes = struct.pack(f"{DIMENSION}f", *vec)
    ph        = _prompt_hash(prompt)

    try:
        conn = _conn()
        cur  = conn.execute("""
            INSERT INTO cache_entries
              (ts, model_id, prompt_hash, prompt_text, response_json, cost_saved)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (time.time(), model_id, ph, prompt[:500], json.dumps(response_json), cost_usd))
        rowid = cur.lastrowid
        conn.execute(
            "INSERT INTO cache_vectors(rowid, embedding) VALUES (?, ?)",
            (rowid, vec_bytes)
        )
        conn.commit()
        conn.close()
        logger.info(f"Semantic STORE  model={model_id}  rowid={rowid}")
    except Exception as e:
        logger.warning(f"Semantic store failed: {e}")


# ---------------------------------------------------------------------------
# Stats
# ---------------------------------------------------------------------------

def cache_stats() -> dict:
    try:
        conn = _conn()
        row  = conn.execute("""
            SELECT
                COUNT(*)        AS total_entries,
                SUM(hit_count)  AS total_hits,
                SUM(cost_saved) AS total_saved
            FROM cache_entries
        """).fetchone()
        conn.close()
        return dict(row) if row else {}
    except Exception:
        return {}
