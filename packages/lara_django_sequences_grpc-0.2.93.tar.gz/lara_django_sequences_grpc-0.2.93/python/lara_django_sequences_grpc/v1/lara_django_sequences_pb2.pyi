from collections.abc import Iterable as _Iterable
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar

from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from google.protobuf import struct_pb2 as _struct_pb2
from google.protobuf.internal import containers as _containers

DESCRIPTOR: _descriptor.FileDescriptor

class ExtraDataDestroyRequest(_message.Message):
    __slots__ = ("extradata_id",)
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    def __init__(self, extradata_id: str | None = ...) -> None: ...

class ExtraDataListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ExtraDataListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[ExtraDataResponse]
    def __init__(self, results: _Iterable[ExtraDataResponse | _Mapping] | None = ...) -> None: ...

class ExtraDataPartialUpdateRequest(_message.Message):
    __slots__ = (
        "_partial_update_fields",
        "data_json",
        "data_type",
        "datetime_created",
        "datetime_last_modified",
        "description",
        "extradata_id",
        "file",
        "hash_sha256",
        "image",
        "iri",
        "media_type",
        "name",
        "name_display",
        "name_full",
        "namespace",
        "search_vector",
        "url",
        "version",
    )
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_FULL_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    DATA_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    FILE_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    data_type: str
    namespace: str
    media_type: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    name_full: str
    version: str
    hash_sha256: str
    data_json: _struct_pb2.Struct
    iri: str
    url: str
    datetime_created: str
    datetime_last_modified: str
    description: str
    search_vector: str
    image: str
    file: str
    def __init__(
        self,
        extradata_id: str | None = ...,
        data_type: str | None = ...,
        namespace: str | None = ...,
        media_type: str | None = ...,
        _partial_update_fields: _Iterable[str] | None = ...,
        name_display: str | None = ...,
        name: str | None = ...,
        name_full: str | None = ...,
        version: str | None = ...,
        hash_sha256: str | None = ...,
        data_json: _struct_pb2.Struct | _Mapping | None = ...,
        iri: str | None = ...,
        url: str | None = ...,
        datetime_created: str | None = ...,
        datetime_last_modified: str | None = ...,
        description: str | None = ...,
        search_vector: str | None = ...,
        image: str | None = ...,
        file: str | None = ...,
    ) -> None: ...

class ExtraDataRequest(_message.Message):
    __slots__ = (
        "data_json",
        "data_type",
        "datetime_created",
        "datetime_last_modified",
        "description",
        "extradata_id",
        "file",
        "hash_sha256",
        "image",
        "iri",
        "media_type",
        "name",
        "name_display",
        "name_full",
        "namespace",
        "search_vector",
        "url",
        "version",
    )
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_FULL_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    DATA_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    FILE_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    data_type: str
    namespace: str
    media_type: str
    name_display: str
    name: str
    name_full: str
    version: str
    hash_sha256: str
    data_json: _struct_pb2.Struct
    iri: str
    url: str
    datetime_created: str
    datetime_last_modified: str
    description: str
    search_vector: str
    image: str
    file: str
    def __init__(
        self,
        extradata_id: str | None = ...,
        data_type: str | None = ...,
        namespace: str | None = ...,
        media_type: str | None = ...,
        name_display: str | None = ...,
        name: str | None = ...,
        name_full: str | None = ...,
        version: str | None = ...,
        hash_sha256: str | None = ...,
        data_json: _struct_pb2.Struct | _Mapping | None = ...,
        iri: str | None = ...,
        url: str | None = ...,
        datetime_created: str | None = ...,
        datetime_last_modified: str | None = ...,
        description: str | None = ...,
        search_vector: str | None = ...,
        image: str | None = ...,
        file: str | None = ...,
    ) -> None: ...

class ExtraDataResponse(_message.Message):
    __slots__ = (
        "data_json",
        "data_type",
        "datetime_created",
        "datetime_last_modified",
        "description",
        "extradata_id",
        "file",
        "hash_sha256",
        "image",
        "iri",
        "media_type",
        "name",
        "name_display",
        "name_full",
        "namespace",
        "search_vector",
        "url",
        "version",
    )
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_FULL_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    DATA_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    FILE_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    data_type: str
    namespace: str
    media_type: str
    name_display: str
    name: str
    name_full: str
    version: str
    hash_sha256: str
    data_json: _struct_pb2.Struct
    iri: str
    url: str
    datetime_created: str
    datetime_last_modified: str
    description: str
    search_vector: str
    image: str
    file: str
    def __init__(
        self,
        extradata_id: str | None = ...,
        data_type: str | None = ...,
        namespace: str | None = ...,
        media_type: str | None = ...,
        name_display: str | None = ...,
        name: str | None = ...,
        name_full: str | None = ...,
        version: str | None = ...,
        hash_sha256: str | None = ...,
        data_json: _struct_pb2.Struct | _Mapping | None = ...,
        iri: str | None = ...,
        url: str | None = ...,
        datetime_created: str | None = ...,
        datetime_last_modified: str | None = ...,
        description: str | None = ...,
        search_vector: str | None = ...,
        image: str | None = ...,
        file: str | None = ...,
    ) -> None: ...

class ExtraDataRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: str | None = ..., namespace_uri: str | None = ...) -> None: ...

class ExtraDataRetrieveRequest(_message.Message):
    __slots__ = ("extradata_id",)
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    def __init__(self, extradata_id: str | None = ...) -> None: ...

class ExtraDataStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class FileDownloadChunk(_message.Message):
    __slots__ = ("data", "filename", "success")
    FILENAME_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    filename: str
    data: bytes
    success: bool
    def __init__(self, filename: str | None = ..., data: bytes | None = ..., success: bool = ...) -> None: ...

class FileDownloadInfo(_message.Message):
    __slots__ = ("chunk_size", "item_id")
    ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    CHUNK_SIZE_FIELD_NUMBER: _ClassVar[int]
    item_id: str
    chunk_size: int
    def __init__(self, item_id: str | None = ..., chunk_size: int | None = ...) -> None: ...

class FileUploadChunk(_message.Message):
    __slots__ = ("data", "filename", "update_item_id")
    FILENAME_FIELD_NUMBER: _ClassVar[int]
    UPDATE_ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    filename: str
    update_item_id: str
    data: bytes
    def __init__(
        self, filename: str | None = ..., update_item_id: str | None = ..., data: bytes | None = ...
    ) -> None: ...

class FileUploadInfo(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class ImageDownloadChunk(_message.Message):
    __slots__ = ("data", "filename_image", "success")
    FILENAME_IMAGE_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    filename_image: str
    data: bytes
    success: bool
    def __init__(self, filename_image: str | None = ..., data: bytes | None = ..., success: bool = ...) -> None: ...

class ImageDownloadInfo(_message.Message):
    __slots__ = ("chunk_size", "item_id")
    ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    CHUNK_SIZE_FIELD_NUMBER: _ClassVar[int]
    item_id: str
    chunk_size: int
    def __init__(self, item_id: str | None = ..., chunk_size: int | None = ...) -> None: ...

class ImageUploadChunk(_message.Message):
    __slots__ = ("data", "filename", "update_item_id")
    FILENAME_FIELD_NUMBER: _ClassVar[int]
    UPDATE_ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    filename: str
    update_item_id: str
    data: bytes
    def __init__(
        self, filename: str | None = ..., update_item_id: str | None = ..., data: bytes | None = ...
    ) -> None: ...

class ImageUploadInfo(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class ItemStatusResponse(_message.Message):
    __slots__ = ("color", "description", "iri", "itemstatus_id", "status", "tags", "value")
    ITEMSTATUS_ID_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    itemstatus_id: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    status: str
    iri: str
    color: str
    value: float
    description: str
    def __init__(
        self,
        itemstatus_id: str | None = ...,
        tags: _Iterable[str] | None = ...,
        status: str | None = ...,
        iri: str | None = ...,
        color: str | None = ...,
        value: float | None = ...,
        description: str | None = ...,
    ) -> None: ...

class MediaTypeResponse(_message.Message):
    __slots__ = ("def_filename_extension_regex", "description", "iri", "media_type", "mediatype_id", "name")
    MEDIATYPE_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    DEF_FILENAME_EXTENSION_REGEX_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    mediatype_id: str
    name: str
    media_type: str
    def_filename_extension_regex: str
    iri: str
    description: str
    def __init__(
        self,
        mediatype_id: str | None = ...,
        name: str | None = ...,
        media_type: str | None = ...,
        def_filename_extension_regex: str | None = ...,
        iri: str | None = ...,
        description: str | None = ...,
    ) -> None: ...

class NamespaceResponse(_message.Message):
    __slots__ = ("description", "namespace_id", "uri")
    NAMESPACE_ID_FIELD_NUMBER: _ClassVar[int]
    URI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    namespace_id: str
    uri: str
    description: str
    def __init__(
        self, namespace_id: str | None = ..., uri: str | None = ..., description: str | None = ...
    ) -> None: ...

class SequenceClassDestroyRequest(_message.Message):
    __slots__ = ("sequenceclass_id",)
    SEQUENCECLASS_ID_FIELD_NUMBER: _ClassVar[int]
    sequenceclass_id: str
    def __init__(self, sequenceclass_id: str | None = ...) -> None: ...

class SequenceClassListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SequenceClassListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[SequenceClassResponse]
    def __init__(self, results: _Iterable[SequenceClassResponse | _Mapping] | None = ...) -> None: ...

class SequenceClassPartialUpdateRequest(_message.Message):
    __slots__ = ("_partial_update_fields", "description", "encoding", "iri", "name", "sequenceclass_id")
    SEQUENCECLASS_ID_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ENCODING_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    sequenceclass_id: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    encoding: _struct_pb2.Struct
    iri: str
    description: str
    def __init__(
        self,
        sequenceclass_id: str | None = ...,
        _partial_update_fields: _Iterable[str] | None = ...,
        name: str | None = ...,
        encoding: _struct_pb2.Struct | _Mapping | None = ...,
        iri: str | None = ...,
        description: str | None = ...,
    ) -> None: ...

class SequenceClassRequest(_message.Message):
    __slots__ = ("description", "encoding", "iri", "name", "sequenceclass_id")
    SEQUENCECLASS_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ENCODING_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    sequenceclass_id: str
    name: str
    encoding: _struct_pb2.Struct
    iri: str
    description: str
    def __init__(
        self,
        sequenceclass_id: str | None = ...,
        name: str | None = ...,
        encoding: _struct_pb2.Struct | _Mapping | None = ...,
        iri: str | None = ...,
        description: str | None = ...,
    ) -> None: ...

class SequenceClassResponse(_message.Message):
    __slots__ = ("description", "encoding", "iri", "name", "sequenceclass_id")
    SEQUENCECLASS_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ENCODING_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    sequenceclass_id: str
    name: str
    encoding: _struct_pb2.Struct
    iri: str
    description: str
    def __init__(
        self,
        sequenceclass_id: str | None = ...,
        name: str | None = ...,
        encoding: _struct_pb2.Struct | _Mapping | None = ...,
        iri: str | None = ...,
        description: str | None = ...,
    ) -> None: ...

class SequenceClassRetrieveRequest(_message.Message):
    __slots__ = ("sequenceclass_id",)
    SEQUENCECLASS_ID_FIELD_NUMBER: _ClassVar[int]
    sequenceclass_id: str
    def __init__(self, sequenceclass_id: str | None = ...) -> None: ...

class SequenceClassStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SequenceDestroyRequest(_message.Message):
    __slots__ = ("sequence_id",)
    SEQUENCE_ID_FIELD_NUMBER: _ClassVar[int]
    sequence_id: str
    def __init__(self, sequence_id: str | None = ...) -> None: ...

class SequenceFullDestroyRequest(_message.Message):
    __slots__ = ("sequence_id",)
    SEQUENCE_ID_FIELD_NUMBER: _ClassVar[int]
    sequence_id: str
    def __init__(self, sequence_id: str | None = ...) -> None: ...

class SequenceFullListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SequenceFullListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[SequenceFullResponse]
    def __init__(self, results: _Iterable[SequenceFullResponse | _Mapping] | None = ...) -> None: ...

class SequenceFullPartialUpdateRequest(_message.Message):
    __slots__ = (
        "_partial_update_fields",
        "datetime_last_modified",
        "description",
        "hash_blockchain",
        "hash_sha256",
        "iri",
        "name",
        "name_display",
        "ncbi_accession_version",
        "ncbi_gi",
        "properties",
        "sequence",
        "sequence_file",
        "sequence_id",
        "source_organism",
        "tags",
        "uniprot_accession",
        "version",
    )
    SEQUENCE_ID_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    HASH_BLOCKCHAIN_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    UNIPROT_ACCESSION_FIELD_NUMBER: _ClassVar[int]
    NCBI_GI_FIELD_NUMBER: _ClassVar[int]
    NCBI_ACCESSION_VERSION_FIELD_NUMBER: _ClassVar[int]
    SOURCE_ORGANISM_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_FILE_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    sequence_id: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    hash_sha256: str
    hash_blockchain: str
    sequence: str
    properties: _struct_pb2.Struct
    uniprot_accession: str
    ncbi_gi: str
    ncbi_accession_version: str
    source_organism: _struct_pb2.Struct
    sequence_file: str
    version: str
    description: str
    iri: str
    datetime_last_modified: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    def __init__(
        self,
        sequence_id: str | None = ...,
        _partial_update_fields: _Iterable[str] | None = ...,
        name_display: str | None = ...,
        name: str | None = ...,
        hash_sha256: str | None = ...,
        hash_blockchain: str | None = ...,
        sequence: str | None = ...,
        properties: _struct_pb2.Struct | _Mapping | None = ...,
        uniprot_accession: str | None = ...,
        ncbi_gi: str | None = ...,
        ncbi_accession_version: str | None = ...,
        source_organism: _struct_pb2.Struct | _Mapping | None = ...,
        sequence_file: str | None = ...,
        version: str | None = ...,
        description: str | None = ...,
        iri: str | None = ...,
        datetime_last_modified: str | None = ...,
        tags: _Iterable[str] | None = ...,
    ) -> None: ...

class SequenceFullRequest(_message.Message):
    __slots__ = (
        "datetime_last_modified",
        "description",
        "hash_blockchain",
        "hash_sha256",
        "iri",
        "name",
        "name_display",
        "ncbi_accession_version",
        "ncbi_gi",
        "properties",
        "sequence",
        "sequence_file",
        "sequence_id",
        "source_organism",
        "tags",
        "uniprot_accession",
        "version",
    )
    SEQUENCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    HASH_BLOCKCHAIN_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    UNIPROT_ACCESSION_FIELD_NUMBER: _ClassVar[int]
    NCBI_GI_FIELD_NUMBER: _ClassVar[int]
    NCBI_ACCESSION_VERSION_FIELD_NUMBER: _ClassVar[int]
    SOURCE_ORGANISM_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_FILE_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    sequence_id: str
    name_display: str
    name: str
    hash_sha256: str
    hash_blockchain: str
    sequence: str
    properties: _struct_pb2.Struct
    uniprot_accession: str
    ncbi_gi: str
    ncbi_accession_version: str
    source_organism: _struct_pb2.Struct
    sequence_file: str
    version: str
    description: str
    iri: str
    datetime_last_modified: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    def __init__(
        self,
        sequence_id: str | None = ...,
        name_display: str | None = ...,
        name: str | None = ...,
        hash_sha256: str | None = ...,
        hash_blockchain: str | None = ...,
        sequence: str | None = ...,
        properties: _struct_pb2.Struct | _Mapping | None = ...,
        uniprot_accession: str | None = ...,
        ncbi_gi: str | None = ...,
        ncbi_accession_version: str | None = ...,
        source_organism: _struct_pb2.Struct | _Mapping | None = ...,
        sequence_file: str | None = ...,
        version: str | None = ...,
        description: str | None = ...,
        iri: str | None = ...,
        datetime_last_modified: str | None = ...,
        tags: _Iterable[str] | None = ...,
    ) -> None: ...

class SequenceFullResponse(_message.Message):
    __slots__ = (
        "datetime_last_modified",
        "description",
        "hash_blockchain",
        "hash_sha256",
        "iri",
        "media_type",
        "name",
        "name_display",
        "namespace",
        "ncbi_accession_version",
        "ncbi_gi",
        "properties",
        "sequence",
        "sequence_class",
        "sequence_file",
        "sequence_id",
        "source_organism",
        "status",
        "tags",
        "uniprot_accession",
        "version",
    )
    SEQUENCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_CLASS_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    HASH_BLOCKCHAIN_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    UNIPROT_ACCESSION_FIELD_NUMBER: _ClassVar[int]
    NCBI_GI_FIELD_NUMBER: _ClassVar[int]
    NCBI_ACCESSION_VERSION_FIELD_NUMBER: _ClassVar[int]
    SOURCE_ORGANISM_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_FILE_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    sequence_id: str
    namespace: NamespaceResponse
    sequence_class: SequenceClassResponse
    media_type: MediaTypeResponse
    status: ItemStatusResponse
    name_display: str
    name: str
    hash_sha256: str
    hash_blockchain: str
    sequence: str
    properties: _struct_pb2.Struct
    uniprot_accession: str
    ncbi_gi: str
    ncbi_accession_version: str
    source_organism: _struct_pb2.Struct
    sequence_file: str
    version: str
    description: str
    iri: str
    datetime_last_modified: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    def __init__(
        self,
        sequence_id: str | None = ...,
        namespace: NamespaceResponse | _Mapping | None = ...,
        sequence_class: SequenceClassResponse | _Mapping | None = ...,
        media_type: MediaTypeResponse | _Mapping | None = ...,
        status: ItemStatusResponse | _Mapping | None = ...,
        name_display: str | None = ...,
        name: str | None = ...,
        hash_sha256: str | None = ...,
        hash_blockchain: str | None = ...,
        sequence: str | None = ...,
        properties: _struct_pb2.Struct | _Mapping | None = ...,
        uniprot_accession: str | None = ...,
        ncbi_gi: str | None = ...,
        ncbi_accession_version: str | None = ...,
        source_organism: _struct_pb2.Struct | _Mapping | None = ...,
        sequence_file: str | None = ...,
        version: str | None = ...,
        description: str | None = ...,
        iri: str | None = ...,
        datetime_last_modified: str | None = ...,
        tags: _Iterable[str] | None = ...,
    ) -> None: ...

class SequenceFullRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: str | None = ..., namespace_uri: str | None = ...) -> None: ...

class SequenceFullRetrieveRequest(_message.Message):
    __slots__ = ("sequence_id",)
    SEQUENCE_ID_FIELD_NUMBER: _ClassVar[int]
    sequence_id: str
    def __init__(self, sequence_id: str | None = ...) -> None: ...

class SequenceFullStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SequenceListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SequenceListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[SequenceResponse]
    def __init__(self, results: _Iterable[SequenceResponse | _Mapping] | None = ...) -> None: ...

class SequencePartialUpdateRequest(_message.Message):
    __slots__ = (
        "_partial_update_fields",
        "datetime_last_modified",
        "description",
        "hash_blockchain",
        "hash_sha256",
        "iri",
        "media_type",
        "name",
        "name_display",
        "namespace",
        "ncbi_accession_version",
        "ncbi_gi",
        "properties",
        "sequence",
        "sequence_class",
        "sequence_file",
        "sequence_id",
        "source_organism",
        "status",
        "tags",
        "uniprot_accession",
        "version",
    )
    SEQUENCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_CLASS_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    HASH_BLOCKCHAIN_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    UNIPROT_ACCESSION_FIELD_NUMBER: _ClassVar[int]
    NCBI_GI_FIELD_NUMBER: _ClassVar[int]
    NCBI_ACCESSION_VERSION_FIELD_NUMBER: _ClassVar[int]
    SOURCE_ORGANISM_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_FILE_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    sequence_id: str
    namespace: str
    sequence_class: str
    media_type: str
    status: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    hash_sha256: str
    hash_blockchain: str
    sequence: str
    properties: _struct_pb2.Struct
    uniprot_accession: str
    ncbi_gi: str
    ncbi_accession_version: str
    source_organism: _struct_pb2.Struct
    sequence_file: str
    version: str
    description: str
    iri: str
    datetime_last_modified: str
    def __init__(
        self,
        sequence_id: str | None = ...,
        namespace: str | None = ...,
        sequence_class: str | None = ...,
        media_type: str | None = ...,
        status: str | None = ...,
        tags: _Iterable[str] | None = ...,
        _partial_update_fields: _Iterable[str] | None = ...,
        name_display: str | None = ...,
        name: str | None = ...,
        hash_sha256: str | None = ...,
        hash_blockchain: str | None = ...,
        sequence: str | None = ...,
        properties: _struct_pb2.Struct | _Mapping | None = ...,
        uniprot_accession: str | None = ...,
        ncbi_gi: str | None = ...,
        ncbi_accession_version: str | None = ...,
        source_organism: _struct_pb2.Struct | _Mapping | None = ...,
        sequence_file: str | None = ...,
        version: str | None = ...,
        description: str | None = ...,
        iri: str | None = ...,
        datetime_last_modified: str | None = ...,
    ) -> None: ...

class SequenceRequest(_message.Message):
    __slots__ = (
        "datetime_last_modified",
        "description",
        "hash_blockchain",
        "hash_sha256",
        "iri",
        "media_type",
        "name",
        "name_display",
        "namespace",
        "ncbi_accession_version",
        "ncbi_gi",
        "properties",
        "sequence",
        "sequence_class",
        "sequence_file",
        "sequence_id",
        "source_organism",
        "status",
        "tags",
        "uniprot_accession",
        "version",
    )
    SEQUENCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_CLASS_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    HASH_BLOCKCHAIN_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    UNIPROT_ACCESSION_FIELD_NUMBER: _ClassVar[int]
    NCBI_GI_FIELD_NUMBER: _ClassVar[int]
    NCBI_ACCESSION_VERSION_FIELD_NUMBER: _ClassVar[int]
    SOURCE_ORGANISM_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_FILE_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    sequence_id: str
    namespace: str
    sequence_class: str
    media_type: str
    status: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    hash_sha256: str
    hash_blockchain: str
    sequence: str
    properties: _struct_pb2.Struct
    uniprot_accession: str
    ncbi_gi: str
    ncbi_accession_version: str
    source_organism: _struct_pb2.Struct
    sequence_file: str
    version: str
    description: str
    iri: str
    datetime_last_modified: str
    def __init__(
        self,
        sequence_id: str | None = ...,
        namespace: str | None = ...,
        sequence_class: str | None = ...,
        media_type: str | None = ...,
        status: str | None = ...,
        tags: _Iterable[str] | None = ...,
        name_display: str | None = ...,
        name: str | None = ...,
        hash_sha256: str | None = ...,
        hash_blockchain: str | None = ...,
        sequence: str | None = ...,
        properties: _struct_pb2.Struct | _Mapping | None = ...,
        uniprot_accession: str | None = ...,
        ncbi_gi: str | None = ...,
        ncbi_accession_version: str | None = ...,
        source_organism: _struct_pb2.Struct | _Mapping | None = ...,
        sequence_file: str | None = ...,
        version: str | None = ...,
        description: str | None = ...,
        iri: str | None = ...,
        datetime_last_modified: str | None = ...,
    ) -> None: ...

class SequenceResponse(_message.Message):
    __slots__ = (
        "datetime_last_modified",
        "description",
        "hash_blockchain",
        "hash_sha256",
        "iri",
        "media_type",
        "name",
        "name_display",
        "namespace",
        "ncbi_accession_version",
        "ncbi_gi",
        "properties",
        "sequence",
        "sequence_class",
        "sequence_file",
        "sequence_id",
        "source_organism",
        "status",
        "tags",
        "uniprot_accession",
        "version",
    )
    SEQUENCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_CLASS_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    HASH_BLOCKCHAIN_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    UNIPROT_ACCESSION_FIELD_NUMBER: _ClassVar[int]
    NCBI_GI_FIELD_NUMBER: _ClassVar[int]
    NCBI_ACCESSION_VERSION_FIELD_NUMBER: _ClassVar[int]
    SOURCE_ORGANISM_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_FILE_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    sequence_id: str
    namespace: str
    sequence_class: str
    media_type: str
    status: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    hash_sha256: str
    hash_blockchain: str
    sequence: str
    properties: _struct_pb2.Struct
    uniprot_accession: str
    ncbi_gi: str
    ncbi_accession_version: str
    source_organism: _struct_pb2.Struct
    sequence_file: str
    version: str
    description: str
    iri: str
    datetime_last_modified: str
    def __init__(
        self,
        sequence_id: str | None = ...,
        namespace: str | None = ...,
        sequence_class: str | None = ...,
        media_type: str | None = ...,
        status: str | None = ...,
        tags: _Iterable[str] | None = ...,
        name_display: str | None = ...,
        name: str | None = ...,
        hash_sha256: str | None = ...,
        hash_blockchain: str | None = ...,
        sequence: str | None = ...,
        properties: _struct_pb2.Struct | _Mapping | None = ...,
        uniprot_accession: str | None = ...,
        ncbi_gi: str | None = ...,
        ncbi_accession_version: str | None = ...,
        source_organism: _struct_pb2.Struct | _Mapping | None = ...,
        sequence_file: str | None = ...,
        version: str | None = ...,
        description: str | None = ...,
        iri: str | None = ...,
        datetime_last_modified: str | None = ...,
    ) -> None: ...

class SequenceRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: str | None = ..., namespace_uri: str | None = ...) -> None: ...

class SequenceRetrieveRequest(_message.Message):
    __slots__ = ("sequence_id",)
    SEQUENCE_ID_FIELD_NUMBER: _ClassVar[int]
    sequence_id: str
    def __init__(self, sequence_id: str | None = ...) -> None: ...

class SequenceStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SequencesSubsetDestroyRequest(_message.Message):
    __slots__ = ("sequencessubset_id",)
    SEQUENCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    sequencessubset_id: str
    def __init__(self, sequencessubset_id: str | None = ...) -> None: ...

class SequencesSubsetListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SequencesSubsetListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[SequencesSubsetResponse]
    def __init__(self, results: _Iterable[SequencesSubsetResponse | _Mapping] | None = ...) -> None: ...

class SequencesSubsetPartialUpdateRequest(_message.Message):
    __slots__ = (
        "_partial_update_fields",
        "datetime_last_modified",
        "description",
        "entity",
        "group",
        "name",
        "name_display",
        "namespace",
        "sequences",
        "sequencessubset_id",
        "tags",
    )
    SEQUENCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    SEQUENCES_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    sequencessubset_id: str
    namespace: str
    entity: str
    group: str
    sequences: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    description: str
    datetime_last_modified: str
    def __init__(
        self,
        sequencessubset_id: str | None = ...,
        namespace: str | None = ...,
        entity: str | None = ...,
        group: str | None = ...,
        sequences: _Iterable[str] | None = ...,
        tags: _Iterable[str] | None = ...,
        _partial_update_fields: _Iterable[str] | None = ...,
        name_display: str | None = ...,
        name: str | None = ...,
        description: str | None = ...,
        datetime_last_modified: str | None = ...,
    ) -> None: ...

class SequencesSubsetRequest(_message.Message):
    __slots__ = (
        "datetime_last_modified",
        "description",
        "entity",
        "group",
        "name",
        "name_display",
        "namespace",
        "sequences",
        "sequencessubset_id",
        "tags",
    )
    SEQUENCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    SEQUENCES_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    sequencessubset_id: str
    namespace: str
    entity: str
    group: str
    sequences: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    description: str
    datetime_last_modified: str
    def __init__(
        self,
        sequencessubset_id: str | None = ...,
        namespace: str | None = ...,
        entity: str | None = ...,
        group: str | None = ...,
        sequences: _Iterable[str] | None = ...,
        tags: _Iterable[str] | None = ...,
        name_display: str | None = ...,
        name: str | None = ...,
        description: str | None = ...,
        datetime_last_modified: str | None = ...,
    ) -> None: ...

class SequencesSubsetResponse(_message.Message):
    __slots__ = (
        "datetime_last_modified",
        "description",
        "entity",
        "group",
        "name",
        "name_display",
        "namespace",
        "sequences",
        "sequencessubset_id",
        "tags",
    )
    SEQUENCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    SEQUENCES_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    sequencessubset_id: str
    namespace: str
    entity: str
    group: str
    sequences: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    description: str
    datetime_last_modified: str
    def __init__(
        self,
        sequencessubset_id: str | None = ...,
        namespace: str | None = ...,
        entity: str | None = ...,
        group: str | None = ...,
        sequences: _Iterable[str] | None = ...,
        tags: _Iterable[str] | None = ...,
        name_display: str | None = ...,
        name: str | None = ...,
        description: str | None = ...,
        datetime_last_modified: str | None = ...,
    ) -> None: ...

class SequencesSubsetRetrieveRequest(_message.Message):
    __slots__ = ("sequencessubset_id",)
    SEQUENCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    sequencessubset_id: str
    def __init__(self, sequencessubset_id: str | None = ...) -> None: ...

class SequencesSubsetStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...
