"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_sequences high_level_interface *

:details: lara_django_sequences high_level_interface.
         - generated with 'lara-django-dev generate_high_level_interface lara_django_sequences
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

import json
import asyncio
import logging
import grpc
from typing import Union

from google.protobuf.struct_pb2 import Struct
from google.protobuf.json_format import MessageToDict

import lara_django_base_grpc.v1.lara_django_base_pb2 as lara_django_base_pb2
import lara_django_base_grpc.v1.lara_django_base_pb2_grpc as lara_django_base_pb2_grpc

import lara_django_sequences_grpc.v1.lara_django_sequences_pb2 as lara_django_sequences_pb2
import lara_django_sequences_grpc.v1.lara_django_sequences_pb2_grpc as lara_django_sequences_pb2_grpc

import  lara_django_base_grpc.lara_django_base_data_model as base_dm
import  lara_django_base_grpc.lara_django_base_interface as base_if
from  lara_django_base_grpc.abstract_interface import LARAInterface, GRPCChannelSingleton, import_model_instance_from_file, export_model_instance_to_file, upload_file, download_file, update_file, upload_image, update_image, download_image, id_cache

import  lara_django_sequences_grpc.lara_django_sequences_data_model as sequences_dm

logger = logging.getLogger(__name__)



#_________________  BlockchainHashes  ______________________


class BlockchainHashesInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.blockchainhashes_client = lara_django_sequences_pb2_grpc.BlockchainHashesControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  blockchainhashes:  list[sequences_dm.BlockchainHashes] = None,  ids_only: bool = False) -> Union[list[str], list[sequences_dm.BlockchainHashes]]:
        try:
            create_coroutines = ( self.blockchainhashes_client.Create(lara_django_sequences_pb2.BlockchainHashesRequest(**blockchainhashes.model_dump())) for blockchainhashes in blockchainhashes )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.blockchainhashes_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating blockchainhashes: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        blockchainhashes_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[sequences_dm.BlockchainHashes]:
        """ retrieve a list of blockchainhashes instances by blockchainhashes_id, name or filter_dict,
               returns a list of blockchainhashes data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  blockchainhashes_id is not None:
            try:
                res =  await self.blockchainhashes_client.Retrieve(
                    lara_django_sequences_pb2.BlockchainHashesRetrieveRequest(blockchainhashes_id=blockchainhashes_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( sequences_dm.BlockchainHashes(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving blockchainhashes_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.blockchainhashes_client.List(
                    lara_django_sequences_pb2.BlockchainHashesListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ sequences_dm.BlockchainHashes(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving blockchainhashes name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the blockchainhashes_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].blockchainhashes_id
        else:
            raise ValueError(f"Error retrieving blockchainhashes_id - no or too many results found.")
    
    async def get_by_id(self, blockchainhashes_id: str = None) -> sequences_dm.BlockchainHashes:
        """ retrieve a blockchainhashes data model by blockchainhashes_id """
        try:
            res = await self.blockchainhashes_client.Retrieve(
                lara_django_sequences_pb2.BlockchainHashesRetrieveRequest(blockchainhashes_id=blockchainhashes_id)
            )
            return sequences_dm.BlockchainHashes(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving blockchainhashes_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> sequences_dm.BlockchainHashes | str:
        """ retrieve a blockchainhashes data model by name """
        try:
            res = await self.blockchainhashes_client.RetrieveByNameNamespace(
                lara_django_sequences_pb2.BlockchainHashesRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["blockchainhashes_id"]
            else:
                return sequences_dm.BlockchainHashes(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving blockchainhashes name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all blockchainhashess """
        if filter_dict is None:
            res = await self.blockchainhashes_client.List(lara_django_sequences_pb2.BlockchainHashesListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.blockchainhashes_client.List(
                lara_django_sequences_pb2.BlockchainHashesListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.blockchainhashes_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all blockchainhashess """
        if self.blockchainhashes_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.blockchainhashes_full_client.List(
                lara_django_sequences_pb2.BlockchainHashesFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.blockchainhashes_full_client.List(
                lara_django_sequences_pb2.BlockchainHashesFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, blockchainhashes : sequences_dm.BlockchainHashes = None) -> None:
        """ update a blockchainhashes model instance """
        try:
            res = await self.blockchainhashes_client.Update(
                lara_django_sequences_pb2.BlockchainHashesRequest(**blockchainhashes.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating blockchainhashes_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a blockchainhashes by blockchainhashes_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.blockchainhashes_client.Destroy(lara_django_sequences_pb2.BlockchainHashesDestroyRequest(blockchainhashes_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting blockchainhashes_id: {e}")

#_________________  ExtraData  ______________________


class ExtraDataInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.extradata_class_client = (
        #     lara_django_sequences_pb2_grpc.ExtraDataclassByIRIControllerStub(channel)
        # )

        self.extradata_client = lara_django_sequences_pb2_grpc.ExtraDataControllerStub(channel)
        
        self.item_id = None
        self.update_item_id = "extradata_id"
        self.stub = self.extradata_client

        self.file_download_info = lara_django_sequences_pb2.FileDownloadInfo
        self.file_upload_chunk = lara_django_sequences_pb2.FileUploadChunk

        self.image_upload_chunk = lara_django_sequences_pb2.ImageUploadChunk


        # self.extradata_full_client = lara_django_sequences_pb2_grpc.ExtraDataFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file()
    @upload_file  # needed for file upload
    @upload_image  # needed for image upload
    async def create(self,  extradata:  list[sequences_dm.ExtraData] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[sequences_dm.ExtraData]]:
        """ create a list of extradata instances,
               returns a list of extradata data model objects or ids_only

        :param extradata: list of extradata data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of extradata data model objects or ids_only
        """
        extradataclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if extradata_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.extradata_class_client.Retrieve(
        #         lara_django_sequences_pb2.ExtraDataclassRetrieveRequest(iri=extradata_class_iri)
        #     )
        #     extradataclass_id = res.extradataclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving extradataclass_id: {e}")
        for extradata in extradata:
            if extradata.namespace == "" or extradata.namespace == "default":
                    extradata.namespace = namespace_id
            # extradata.extradata_class = extradataclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.extradata_client.Create(lara_django_sequences_pb2.ExtraDataRequest(**extradata.model_dump())) for extradata in extradata )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("extradata_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating extradata: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        extradata_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[sequences_dm.ExtraData]:
        """ retrieve a list of extradata instances by extradata_id, name or filter_dict,
               returns a list of extradata data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  extradata_id is not None:
            try:
                res =  await self.extradata_client.Retrieve(
                    lara_django_sequences_pb2.ExtraDataRetrieveRequest(extradata_id=extradata_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( sequences_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving extradata_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.extradata_client.List(
                    lara_django_sequences_pb2.ExtraDataListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ sequences_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving extradata name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the extradata_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1 :
            return results_list[0].extradata_id
        else:
            raise ValueError(f"Error retrieving extradata_id - no or too many results found.")
    
    @download_file  # needed for file download
    @download_image  # needed for image download
    async def get_by_id(self, extradata_id: str = None, id_only: bool = False) -> sequences_dm.ExtraData:
        """ retrieve a extradata data model by extradata_id """
        try:
            res = await self.extradata_client.Retrieve(
                lara_django_sequences_pb2.ExtraDataRetrieveRequest(extradata_id=extradata_id)
            )
            item = sequences_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.extradata_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving extradata_id: {e}")
    
    @download_file  # needed for file download
    @download_image  # needed for image download
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> sequences_dm.ExtraData | str:
        """ retrieve a extradata data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.extradata_client.RetrieveByNameNamespace(
                lara_django_sequences_pb2.ExtraDataRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["extradata_id"]
            if id_only:
                return self.item_id
            else:
                return sequences_dm.ExtraData(**item)
        except Exception as e:
            logger.error(f"Error retrieving extradata name: {e}")
   
    
    @download_file  # needed for file download
    async def get_file(self, extradata_id : str = None, id_only : bool = True ) -> bytes | None:
        """ retrieve a file by data_id """
        self.item_id = extradata_id
        
    
    async def get_file_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                filename_target : str = None,
                                as_byte_str : bool = None ) -> bytes | None:
        """ retrieve a file by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            # logger.warning(f"no namespace_uri provided, using default namespace: {namespace_uri}")
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            extradata_id = await self.get_by_name(name=name, namespace_uri=namespace_uri, id_only=True)
            return await self.get_file(extradata_id=extradata_id, filename_target=filename_target, as_byte_str=as_byte_str, get_file=True)
        except Exception as e:
            logger.error(f"Error retrieving extradata name: {e}")
        
    
    @download_image  # needed for image download
    async def get_image(self, extradata_id : str = None, id_only : bool = True) -> bytes | None:
        """ retrieve an image by data_id """
        self.item_id = extradata_id
        
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all extradatas """
        if filter_dict is None:
            res = await self.extradata_client.List(lara_django_sequences_pb2.ExtraDataListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.extradata_client.List(
                lara_django_sequences_pb2.ExtraDataListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.extradata_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all extradatas """
        if self.extradata_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.extradata_full_client.List(
                lara_django_sequences_pb2.ExtraDataFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.extradata_full_client.List(
                lara_django_sequences_pb2.ExtraDataFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    @update_file  # needed for file update
    @update_image  # needed for image update
    async def update(self, extradata : sequences_dm.ExtraData = None) -> None:
        """ update a extradata model instance """
        try:
            res = await self.extradata_client.Update(
                lara_django_sequences_pb2.ExtraDataRequest(**extradata.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating extradata_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a extradata by extradata_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.extradata_client.Destroy(lara_django_sequences_pb2.ExtraDataDestroyRequest(extradata_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting extradata_id: {e}")

#_________________  SequenceClass  ______________________


class SequenceClassInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.sequenceclass_client = lara_django_sequences_pb2_grpc.SequenceClassControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  sequenceclasses:  list[sequences_dm.SequenceClass] = None,  ids_only: bool = False) -> Union[list[str], list[sequences_dm.SequenceClass]]:

        for sequenceclass in sequenceclasses:
            if sequenceclass.encoding is not None:
                try:
                    data_struct = Struct()
                    data_json = sequenceclass.encoding
                    data_struct.update(data_json)
                    sequenceclass.encoding = data_struct
                except Exception as e:
                    logging.error(f"Error(SequenceClassInterface) - converting encoding to Struct: {e}")
        try:
            create_coroutines = ( self.sequenceclass_client.Create(lara_django_sequences_pb2.SequenceClassRequest(**sequenceclass.model_dump())) for sequenceclass in sequenceclasses )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.sequenceclass_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating sequenceclass: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        sequenceclass_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[sequences_dm.SequenceClass]:
        """ retrieve a list of sequenceclass instances by sequenceclass_id, name or filter_dict,
               returns a list of sequenceclass data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  sequenceclass_id is not None:
            try:
                res =  await self.sequenceclass_client.Retrieve(
                    lara_django_sequences_pb2.SequenceClassRetrieveRequest(sequenceclass_id=sequenceclass_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( sequences_dm.SequenceClass(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving sequenceclass_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.sequenceclass_client.List(
                    lara_django_sequences_pb2.SequenceClassListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ sequences_dm.SequenceClass(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving sequenceclass name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the sequenceclass_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].sequenceclass_id
        else:
            raise ValueError(f"Error retrieving sequenceclass_id - no or too many results found.")
    
    async def get_by_id(self, sequenceclass_id: str = None) -> sequences_dm.SequenceClass:
        """ retrieve a sequenceclass data model by sequenceclass_id """
        try:
            res = await self.sequenceclass_client.Retrieve(
                lara_django_sequences_pb2.SequenceClassRetrieveRequest(sequenceclass_id=sequenceclass_id)
            )
            return sequences_dm.SequenceClass(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving sequenceclass_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> sequences_dm.SequenceClass | str:
        """ retrieve a sequenceclass data model by name """
        try:
            res = await self.sequenceclass_client.RetrieveByNameNamespace(
                lara_django_sequences_pb2.SequenceClassRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["sequenceclass_id"]
            else:
                return sequences_dm.SequenceClass(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving sequenceclass name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all sequenceclasss """
        if filter_dict is None:
            res = await self.sequenceclass_client.List(lara_django_sequences_pb2.SequenceClassListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.sequenceclass_client.List(
                lara_django_sequences_pb2.SequenceClassListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.sequenceclass_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all sequenceclasss """
        if self.sequenceclass_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.sequenceclass_full_client.List(
                lara_django_sequences_pb2.SequenceClassFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.sequenceclass_full_client.List(
                lara_django_sequences_pb2.SequenceClassFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, sequenceclass : sequences_dm.SequenceClass = None) -> None:
        """ update a sequenceclass model instance """
        try:
            res = await self.sequenceclass_client.Update(
                lara_django_sequences_pb2.SequenceClassRequest(**sequenceclass.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating sequenceclass_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a sequenceclass by sequenceclass_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.sequenceclass_client.Destroy(lara_django_sequences_pb2.SequenceClassDestroyRequest(sequenceclass_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting sequenceclass_id: {e}")

#_________________  Sequence  ______________________


class SequenceInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.sequence_class_client = (
        #     lara_django_sequences_pb2_grpc.SequenceclassByIRIControllerStub(channel)
        # )

        self.sequence_client = lara_django_sequences_pb2_grpc.SequenceControllerStub(channel)
        
        self.item_id = None
        self.update_item_id = "sequence_id"
        self.stub = self.sequence_client

        self.file_download_info = lara_django_sequences_pb2.FileDownloadInfo
        self.file_upload_chunk = lara_django_sequences_pb2.FileUploadChunk


        # self.sequence_full_client = lara_django_sequences_pb2_grpc.SequenceFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file()
    @upload_file  # needed for file upload
    async def create(self,  sequences:  list[sequences_dm.Sequence] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[sequences_dm.Sequence]]:
        """ create a list of sequence instances,
               returns a list of sequence data model objects or ids_only

        :param sequences: list of sequence data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of sequence data model objects or ids_only
        """
        sequenceclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if sequence_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.sequence_class_client.Retrieve(
        #         lara_django_sequences_pb2.SequenceclassRetrieveRequest(iri=sequence_class_iri)
        #     )
        #     sequenceclass_id = res.sequenceclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving sequenceclass_id: {e}")
        for sequence in sequences:
            if sequence.namespace == "" or sequence.namespace == "default":
                    sequence.namespace = namespace_id
            # sequence.sequence_class = sequenceclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.sequence_client.Create(lara_django_sequences_pb2.SequenceRequest(**sequence.model_dump())) for sequence in sequences )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("sequence_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating sequence: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        sequence_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[sequences_dm.Sequence]:
        """ retrieve a list of sequence instances by sequence_id, name or filter_dict,
               returns a list of sequence data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  sequence_id is not None:
            try:
                res =  await self.sequence_client.Retrieve(
                    lara_django_sequences_pb2.SequenceRetrieveRequest(sequence_id=sequence_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( sequences_dm.Sequence(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving sequence_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.sequence_client.List(
                    lara_django_sequences_pb2.SequenceListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ sequences_dm.Sequence(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving sequence name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the sequence_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1 :
            return results_list[0].sequence_id
        else:
            raise ValueError(f"Error retrieving sequence_id - no or too many results found.")
    
    @download_file  # needed for file download
    async def get_by_id(self, sequence_id: str = None, id_only: bool = False) -> sequences_dm.Sequence:
        """ retrieve a sequence data model by sequence_id """
        try:
            res = await self.sequence_client.Retrieve(
                lara_django_sequences_pb2.SequenceRetrieveRequest(sequence_id=sequence_id)
            )
            item = sequences_dm.Sequence(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.sequence_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving sequence_id: {e}")
    
    @download_file  # needed for file download
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> sequences_dm.Sequence | str:
        """ retrieve a sequence data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.sequence_client.RetrieveByNameNamespace(
                lara_django_sequences_pb2.SequenceRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["sequence_id"]
            if id_only:
                return self.item_id
            else:
                return sequences_dm.Sequence(**item)
        except Exception as e:
            logger.error(f"Error retrieving sequence name: {e}")
   
    
    @download_file  # needed for file download
    async def get_file(self, sequence_id : str = None, id_only : bool = True ) -> bytes | None:
        """ retrieve a file by data_id """
        self.item_id = sequence_id
        
    
    async def get_file_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                filename_target : str = None,
                                as_byte_str : bool = None ) -> bytes | None:
        """ retrieve a file by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            # logger.warning(f"no namespace_uri provided, using default namespace: {namespace_uri}")
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            sequence_id = await self.get_by_name(name=name, namespace_uri=namespace_uri, id_only=True)
            return await self.get_file(sequence_id=sequence_id, filename_target=filename_target, as_byte_str=as_byte_str, get_file=True)
        except Exception as e:
            logger.error(f"Error retrieving sequence name: {e}")
        
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all sequences """
        if filter_dict is None:
            res = await self.sequence_client.List(lara_django_sequences_pb2.SequenceListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.sequence_client.List(
                lara_django_sequences_pb2.SequenceListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.sequence_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all sequences """
        if self.sequence_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.sequence_full_client.List(
                lara_django_sequences_pb2.SequenceFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.sequence_full_client.List(
                lara_django_sequences_pb2.SequenceFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    @update_file  # needed for file update
    async def update(self, sequence : sequences_dm.Sequence = None) -> None:
        """ update a sequence model instance """
        try:
            res = await self.sequence_client.Update(
                lara_django_sequences_pb2.SequenceRequest(**sequence.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating sequence_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a sequence by sequence_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.sequence_client.Destroy(lara_django_sequences_pb2.SequenceDestroyRequest(sequence_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting sequence_id: {e}")

#_________________  SequencesSubset  ______________________


class SequencesSubsetInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.sequencessubset_class_client = (
        #     lara_django_sequences_pb2_grpc.SequencesSubsetclassByIRIControllerStub(channel)
        # )

        self.sequencessubset_client = lara_django_sequences_pb2_grpc.SequencesSubsetControllerStub(channel)
        

        # self.sequencessubset_full_client = lara_django_sequences_pb2_grpc.SequencesSubsetFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file()
    async def create(self,  sequencessubsets:  list[sequences_dm.SequencesSubset] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[sequences_dm.SequencesSubset]]:
        """ create a list of sequencessubset instances,
               returns a list of sequencessubset data model objects or ids_only

        :param sequencessubsets: list of sequencessubset data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of sequencessubset data model objects or ids_only
        """
        sequencessubsetclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if sequencessubset_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.sequencessubset_class_client.Retrieve(
        #         lara_django_sequences_pb2.SequencesSubsetclassRetrieveRequest(iri=sequencessubset_class_iri)
        #     )
        #     sequencessubsetclass_id = res.sequencessubsetclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving sequencessubsetclass_id: {e}")
        for sequencessubset in sequencessubsets:
            if sequencessubset.namespace == "" or sequencessubset.namespace == "default":
                    sequencessubset.namespace = namespace_id
            # sequencessubset.sequencessubset_class = sequencessubsetclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.sequencessubset_client.Create(lara_django_sequences_pb2.SequencesSubsetRequest(**sequencessubset.model_dump())) for sequencessubset in sequencessubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("sequencessubset_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating sequencessubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        sequencessubset_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[sequences_dm.SequencesSubset]:
        """ retrieve a list of sequencessubset instances by sequencessubset_id, name or filter_dict,
               returns a list of sequencessubset data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  sequencessubset_id is not None:
            try:
                res =  await self.sequencessubset_client.Retrieve(
                    lara_django_sequences_pb2.SequencesSubsetRetrieveRequest(sequencessubset_id=sequencessubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( sequences_dm.SequencesSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving sequencessubset_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.sequencessubset_client.List(
                    lara_django_sequences_pb2.SequencesSubsetListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ sequences_dm.SequencesSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving sequencessubset name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the sequencessubset_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1 :
            return results_list[0].sequencessubset_id
        else:
            raise ValueError(f"Error retrieving sequencessubset_id - no or too many results found.")
    
    async def get_by_id(self, sequencessubset_id: str = None, id_only: bool = False) -> sequences_dm.SequencesSubset:
        """ retrieve a sequencessubset data model by sequencessubset_id """
        try:
            res = await self.sequencessubset_client.Retrieve(
                lara_django_sequences_pb2.SequencesSubsetRetrieveRequest(sequencessubset_id=sequencessubset_id)
            )
            item = sequences_dm.SequencesSubset(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.sequencessubset_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving sequencessubset_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> sequences_dm.SequencesSubset | str:
        """ retrieve a sequencessubset data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.sequencessubset_client.RetrieveByNameNamespace(
                lara_django_sequences_pb2.SequencesSubsetRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["sequencessubset_id"]
            if id_only:
                return self.item_id
            else:
                return sequences_dm.SequencesSubset(**item)
        except Exception as e:
            logger.error(f"Error retrieving sequencessubset name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all sequencessubsets """
        if filter_dict is None:
            res = await self.sequencessubset_client.List(lara_django_sequences_pb2.SequencesSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.sequencessubset_client.List(
                lara_django_sequences_pb2.SequencesSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.sequencessubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all sequencessubsets """
        if self.sequencessubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.sequencessubset_full_client.List(
                lara_django_sequences_pb2.SequencesSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.sequencessubset_full_client.List(
                lara_django_sequences_pb2.SequencesSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, sequencessubset : sequences_dm.SequencesSubset = None) -> None:
        """ update a sequencessubset model instance """
        try:
            res = await self.sequencessubset_client.Update(
                lara_django_sequences_pb2.SequencesSubsetRequest(**sequencessubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating sequencessubset_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a sequencessubset by sequencessubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.sequencessubset_client.Destroy(lara_django_sequences_pb2.SequencesSubsetDestroyRequest(sequencessubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting sequencessubset_id: {e}")

#_________________  OrderedSequencesSubset  ______________________


class OrderedSequencesSubsetInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.orderedsequencessubset_client = lara_django_sequences_pb2_grpc.OrderedSequencesSubsetControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  orderedsequencessubsets:  list[sequences_dm.OrderedSequencesSubset] = None,  ids_only: bool = False) -> Union[list[str], list[sequences_dm.OrderedSequencesSubset]]:
        try:
            create_coroutines = ( self.orderedsequencessubset_client.Create(lara_django_sequences_pb2.OrderedSequencesSubsetRequest(**orderedsequencessubset.model_dump())) for orderedsequencessubset in orderedsequencessubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.orderedsequencessubset_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating orderedsequencessubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        orderedsequencessubset_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[sequences_dm.OrderedSequencesSubset]:
        """ retrieve a list of orderedsequencessubset instances by orderedsequencessubset_id, name or filter_dict,
               returns a list of orderedsequencessubset data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  orderedsequencessubset_id is not None:
            try:
                res =  await self.orderedsequencessubset_client.Retrieve(
                    lara_django_sequences_pb2.OrderedSequencesSubsetRetrieveRequest(orderedsequencessubset_id=orderedsequencessubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( sequences_dm.OrderedSequencesSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving orderedsequencessubset_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.orderedsequencessubset_client.List(
                    lara_django_sequences_pb2.OrderedSequencesSubsetListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ sequences_dm.OrderedSequencesSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving orderedsequencessubset name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the orderedsequencessubset_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].orderedsequencessubset_id
        else:
            raise ValueError(f"Error retrieving orderedsequencessubset_id - no or too many results found.")
    
    async def get_by_id(self, orderedsequencessubset_id: str = None) -> sequences_dm.OrderedSequencesSubset:
        """ retrieve a orderedsequencessubset data model by orderedsequencessubset_id """
        try:
            res = await self.orderedsequencessubset_client.Retrieve(
                lara_django_sequences_pb2.OrderedSequencesSubsetRetrieveRequest(orderedsequencessubset_id=orderedsequencessubset_id)
            )
            return sequences_dm.OrderedSequencesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedsequencessubset_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> sequences_dm.OrderedSequencesSubset | str:
        """ retrieve a orderedsequencessubset data model by name """
        try:
            res = await self.orderedsequencessubset_client.RetrieveByNameNamespace(
                lara_django_sequences_pb2.OrderedSequencesSubsetRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["orderedsequencessubset_id"]
            else:
                return sequences_dm.OrderedSequencesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedsequencessubset name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all orderedsequencessubsets """
        if filter_dict is None:
            res = await self.orderedsequencessubset_client.List(lara_django_sequences_pb2.OrderedSequencesSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.orderedsequencessubset_client.List(
                lara_django_sequences_pb2.OrderedSequencesSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.orderedsequencessubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all orderedsequencessubsets """
        if self.orderedsequencessubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.orderedsequencessubset_full_client.List(
                lara_django_sequences_pb2.OrderedSequencesSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.orderedsequencessubset_full_client.List(
                lara_django_sequences_pb2.OrderedSequencesSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, orderedsequencessubset : sequences_dm.OrderedSequencesSubset = None) -> None:
        """ update a orderedsequencessubset model instance """
        try:
            res = await self.orderedsequencessubset_client.Update(
                lara_django_sequences_pb2.OrderedSequencesSubsetRequest(**orderedsequencessubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating orderedsequencessubset_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a orderedsequencessubset by orderedsequencessubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.orderedsequencessubset_client.Destroy(lara_django_sequences_pb2.OrderedSequencesSubsetDestroyRequest(orderedsequencessubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting orderedsequencessubset_id: {e}")

