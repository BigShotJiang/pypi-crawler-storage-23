from __future__ import annotations 

import re
import sys
from datetime import (
    date,
    datetime,
    time
)
from decimal import Decimal 
from enum import Enum 
from typing import (
    Any,
    ClassVar,
    Dict,
    List,
    Literal,
    Optional,
    Union
)

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    RootModel,
    field_validator
)


metamodel_version = "None"
version = "None"


class ConfiguredBaseModel(BaseModel):
    model_config = ConfigDict(
        validate_assignment = True,
        validate_default = True,
        extra = "forbid",
        arbitrary_types_allowed = True,
        use_enum_values = True,
        strict = False,
    )
    pass




class LinkMLMeta(RootModel):
    root: Dict[str, Any] = {}
    model_config = ConfigDict(frozen=True)

    def __getattr__(self, key:str):
        return getattr(self.root, key)

    def __getitem__(self, key:str):
        return self.root[key]

    def __setitem__(self, key:str, value):
        self.root[key] = value

    def __contains__(self, key:str) -> bool:
        return key in self.root


linkml_meta = LinkMLMeta({'default_prefix': 'lara',
     'default_range': 'string',
     'id': 'https://w3id.org/lara/lara_django_sequences',
     'imports': ['linkml:types'],
     'name': 'lara_django_sequences',
     'prefixes': {'lara': {'prefix_prefix': 'lara',
                           'prefix_reference': 'http://w3id.org/lara/'},
                  'linkml': {'prefix_prefix': 'linkml',
                             'prefix_reference': 'https://w3id.org/linkml/'},
                  'oso': {'prefix_prefix': 'oso',
                          'prefix_reference': 'http://w3id.org/oso/'}},
     'source_file': 'lara_django_sequences_schema.yaml',
     'types': {'FileField': {'base': 'str',
                             'description': 'A file field',
                             'from_schema': 'https://w3id.org/lara/lara_django_sequences',
                             'name': 'FileField',
                             'uri': 'https://w3id.org/lara/FileField'},
               'ImageField': {'base': 'str',
                              'description': 'An image field',
                              'from_schema': 'https://w3id.org/lara/lara_django_sequences',
                              'name': 'ImageField',
                              'uri': 'https://w3id.org/lara/ImageField'},
               'JSON': {'base': 'string',
                        'description': 'A JSON object',
                        'from_schema': 'https://w3id.org/lara/lara_django_sequences',
                        'name': 'JSON',
                        'repr': 'dict',
                        'uri': 'https://json.org'},
               'UUID': {'base': 'str',
                        'description': 'A UUID',
                        'from_schema': 'https://w3id.org/lara/lara_django_sequences',
                        'name': 'UUID',
                        'pattern': '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$',
                        'uri': 'https://datatracker.ietf.org/doc/html/rfc9562'}}} )


class Tag(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.Tag'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_sequences'})

    pass


class Namespace(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.Namespace'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_sequences'})

    pass


class Group(ConfiguredBaseModel):
    """
    <class 'lara_django_people.models.Group'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_sequences'})

    pass


class ItemStatus(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.ItemStatus'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_sequences'})

    pass


class DataType(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.DataType'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_sequences'})

    pass


class Entity(ConfiguredBaseModel):
    """
    <class 'lara_django_people.models.Entity'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_sequences'})

    pass


class MediaType(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.MediaType'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_sequences'})

    pass


class BlockchainHashes(ConfiguredBaseModel):
    """
    \" This class can be used to store hashes of data, which are stored in a blockchain.
        The hashes can be used to verify the integrity of the data.
        The hashes are stored in a separate table, to avoid circular dependencies.
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:data/BlockchainHashes',
         'from_schema': 'https://w3id.org/lara/lara_django_sequences'})

    blockchainhashes_id: Optional[str] = Field(None, description="""BlockchainHashes - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'blockchainhashes_id',
         'domain_of': ['BlockchainHashes'],
         'slot_uri': 'lara:data/BlockchainHashes/blockchainhashes_id'} })
    block_id: Optional[str] = Field(None, description="""Identifier of the data block for which the blockchain hash was currently calculated,e.g., data of a measurement series.""", json_schema_extra = { "linkml_meta": {'alias': 'block_id',
         'domain_of': ['BlockchainHashes'],
         'slot_uri': 'lara:data/BlockchainHashes/block_id'} })
    hash_sha256: Optional[str] = Field(None, description="""SHA256 hash of all data (JSON and XML)""", json_schema_extra = { "linkml_meta": {'alias': 'hash_sha256',
         'domain_of': ['BlockchainHashes', 'ExtraData', 'Sequence'],
         'slot_uri': 'lara:data/BlockchainHashes/hash_sha256'} })
    hash_sha512: Optional[str] = Field(None, description="""SHA512 hash of all data (JSON and XML)""", json_schema_extra = { "linkml_meta": {'alias': 'hash_sha512',
         'domain_of': ['BlockchainHashes'],
         'slot_uri': 'lara:data/BlockchainHashes/hash_sha512'} })
    timestamp: str = Field(..., description="""date and time when the blockchain hash was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'timestamp',
         'domain_of': ['BlockchainHashes'],
         'slot_uri': 'lara:data/BlockchainHashes/timestamp'} })


class ExtraData(ConfiguredBaseModel):
    """
    \" This class can be used to extend the Sequence data, by extra information,
        e.g.,  properties relevant only for certain sequences ...
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:sequences/ExtraData',
         'from_schema': 'https://w3id.org/lara/lara_django_sequences'})

    extradata_id: Optional[str] = Field(None, description="""ExtraData - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'extradata_id',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:sequences/ExtraData/extradata_id'} })
    data_type: Optional[str] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'data_type',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:base/DataType'} })
    namespace: str = Field(..., description="""namespace of data""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData', 'Sequence', 'SequencesSubset'],
         'slot_uri': 'lara:base/Namespace'} })
    name_display: Optional[str] = Field(None, description="""Human readable display name or title of extra data""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData', 'Sequence', 'SequencesSubset'],
         'slot_uri': 'lara:sequences/ExtraData/name_display'} })
    name: Optional[str] = Field(None, description="""name of extra data""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData', 'SequenceClass', 'Sequence', 'SequencesSubset'],
         'slot_uri': 'lara:sequences/ExtraData/name'} })
    name_full: Optional[str] = Field(None, description="""full name of extra data""", json_schema_extra = { "linkml_meta": {'alias': 'name_full',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:sequences/ExtraData/name_full'} })
    version: Optional[str] = Field(None, description="""version of extra data""", json_schema_extra = { "linkml_meta": {'alias': 'version',
         'domain_of': ['ExtraData', 'Sequence'],
         'slot_uri': 'lara:sequences/ExtraData/version'} })
    hash_sha256: Optional[str] = Field(None, description="""SHA256 hash of all data (JSON and XML)""", json_schema_extra = { "linkml_meta": {'alias': 'hash_sha256',
         'domain_of': ['BlockchainHashes', 'ExtraData', 'Sequence'],
         'slot_uri': 'lara:sequences/ExtraData/hash_sha256'} })
    data_json: Optional[dict] = Field(None, description="""generic JSON field""", json_schema_extra = { "linkml_meta": {'alias': 'data_json',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:sequences/ExtraData/data_json'} })
    media_type: Optional[str] = Field(None, description="""IANA media type of extra data file""", json_schema_extra = { "linkml_meta": {'alias': 'media_type',
         'domain_of': ['ExtraData', 'Sequence'],
         'slot_uri': 'lara:base/MediaType'} })
    iri: Optional[str] = Field(None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['ExtraData', 'SequenceClass', 'Sequence'],
         'slot_uri': 'lara:sequences/ExtraData/iri'} })
    url: Optional[str] = Field(None, description="""Universal Resource Locator - this can be used to link the data to external locations""", json_schema_extra = { "linkml_meta": {'alias': 'url',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:sequences/ExtraData/url'} })
    datetime_created: Optional[str] = Field(None, description="""date and time when data was created""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_created',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:sequences/ExtraData/datetime_created'} })
    datetime_last_modified: Optional[str] = Field(None, description="""date and time when data was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData', 'Sequence', 'SequencesSubset'],
         'slot_uri': 'lara:sequences/ExtraData/datetime_last_modified'} })
    description: Optional[str] = Field(None, description="""description of extra data""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData', 'SequenceClass', 'Sequence', 'SequencesSubset'],
         'slot_uri': 'lara:sequences/ExtraData/description'} })
    image: Optional[str] = Field(None, description="""extra sequence images""", json_schema_extra = { "linkml_meta": {'alias': 'image',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:sequences/ExtraData/image'} })
    file: Optional[str] = Field(None, description="""rel. path/filename""", json_schema_extra = { "linkml_meta": {'alias': 'file',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:sequences/ExtraData/file'} })


class SequenceClass(ConfiguredBaseModel):
    """
    \" classes  of sequences, like  DNA, RNA, PNA, XNA, peptide/protein ... \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:sequences/SequenceClass',
         'from_schema': 'https://w3id.org/lara/lara_django_sequences'})

    sequenceclass_id: Optional[str] = Field(None, description="""SequenceClass - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'sequenceclass_id',
         'domain_of': ['SequenceClass'],
         'slot_uri': 'lara:sequences/SequenceClass/sequenceclass_id'} })
    name: str = Field(..., description="""classes  of sequences, like  DNA, RNA, PNA, XNA, peptide/protein ..""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData', 'SequenceClass', 'Sequence', 'SequencesSubset'],
         'slot_uri': 'lara:sequences/SequenceClass/name'} })
    encoding: Optional[dict] = Field(None, description="""encoding of the binary sequence, e.g. 4 bit, bit1: A, bit2: C, bit3: G, bit4: T""", json_schema_extra = { "linkml_meta": {'alias': 'encoding',
         'domain_of': ['SequenceClass'],
         'slot_uri': 'lara:sequences/SequenceClass/encoding'} })
    iri: Optional[str] = Field(None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['ExtraData', 'SequenceClass', 'Sequence'],
         'slot_uri': 'lara:sequences/SequenceClass/iri'} })
    description: Optional[str] = Field(None, description="""description of the sequence class""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData', 'SequenceClass', 'Sequence', 'SequencesSubset'],
         'slot_uri': 'lara:sequences/SequenceClass/description'} })


class Sequence(ConfiguredBaseModel):
    """
    \" Sequence class describing, sequences of DNA, RNA, PNA, XNA, peptide/protein ... \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:sequences/Sequence',
         'from_schema': 'https://w3id.org/lara/lara_django_sequences'})

    sequence_id: Optional[str] = Field(None, description="""Sequence - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'sequence_id',
         'domain_of': ['Sequence'],
         'slot_uri': 'lara:sequences/Sequence/sequence_id'} })
    namespace: Optional[str] = Field(None, description="""namespace of sequence""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData', 'Sequence', 'SequencesSubset'],
         'slot_uri': 'lara:base/Namespace'} })
    name_display: Optional[str] = Field(None, description="""human readable title of sequence, can be different from name""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData', 'Sequence', 'SequencesSubset'],
         'slot_uri': 'lara:sequences/Sequence/name_display'} })
    name: str = Field(..., description="""short sequence name for reference""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData', 'SequenceClass', 'Sequence', 'SequencesSubset'],
         'slot_uri': 'lara:sequences/Sequence/name'} })
    hash_sha256: Optional[str] = Field(None, description="""SHA256 hash of item for identity/duplicate checking""", json_schema_extra = { "linkml_meta": {'alias': 'hash_sha256',
         'domain_of': ['BlockchainHashes', 'ExtraData', 'Sequence'],
         'slot_uri': 'lara:sequences/Sequence/hash_sha256'} })
    hash_blockchain: Optional[str] = Field(None, description="""hash of sequence item for blockchain""", json_schema_extra = { "linkml_meta": {'alias': 'hash_blockchain',
         'domain_of': ['Sequence'],
         'slot_uri': 'lara:sequences/Sequence/hash_blockchain'} })
    sequence_class: Optional[str] = Field(None, description="""sequence class, like  DNA, RNA, PNA, XNA, peptide/protein ... """, json_schema_extra = { "linkml_meta": {'alias': 'sequence_class',
         'domain_of': ['Sequence'],
         'slot_uri': 'lara:sequences/SequenceClass'} })
    sequence: Optional[str] = Field(None, description="""sequence data as text""", json_schema_extra = { "linkml_meta": {'alias': 'sequence',
         'domain_of': ['Sequence', 'OrderedSequencesSubset'],
         'slot_uri': 'lara:sequences/Sequence/sequence'} })
    properties: Optional[dict] = Field(None, description="""properties of the sequence, e.g., length, GC content, UniProt Accession, NCBI Accession, PDB ID ...""", json_schema_extra = { "linkml_meta": {'alias': 'properties',
         'domain_of': ['Sequence'],
         'slot_uri': 'lara:sequences/Sequence/properties'} })
    uniprot_accession: Optional[str] = Field(None, description="""UniProt Accession of the sequence""", json_schema_extra = { "linkml_meta": {'alias': 'uniprot_accession',
         'domain_of': ['Sequence'],
         'slot_uri': 'lara:sequences/Sequence/uniprot_accession'} })
    ncbi_gi: Optional[str] = Field(None, description="""NCBI GenInfo Identifier (GI)""", json_schema_extra = { "linkml_meta": {'alias': 'ncbi_gi',
         'domain_of': ['Sequence'],
         'slot_uri': 'lara:sequences/Sequence/ncbi_gi'} })
    ncbi_accession_version: Optional[str] = Field(None, description="""NCBI Accession Number.version identifier.""", json_schema_extra = { "linkml_meta": {'alias': 'ncbi_accession_version',
         'domain_of': ['Sequence'],
         'slot_uri': 'lara:sequences/Sequence/ncbi_accession_version'} })
    source_organism: Optional[dict] = Field(None, description="""organism from which the sequence originated - important for codon usage""", json_schema_extra = { "linkml_meta": {'alias': 'source_organism',
         'domain_of': ['Sequence'],
         'slot_uri': 'lara:sequences/Sequence/source_organism'} })
    media_type: Optional[str] = Field(None, description="""file type of sequence data (file)""", json_schema_extra = { "linkml_meta": {'alias': 'media_type',
         'domain_of': ['ExtraData', 'Sequence'],
         'slot_uri': 'lara:base/MediaType'} })
    sequence_file: Optional[str] = Field(None, description="""rel. path/filename""", json_schema_extra = { "linkml_meta": {'alias': 'sequence_file',
         'domain_of': ['Sequence'],
         'slot_uri': 'lara:sequences/Sequence/sequence_file'} })
    status: Optional[str] = Field(None, description="""status of sequence, e.g., selected, processed, synchronised ... """, json_schema_extra = { "linkml_meta": {'alias': 'status',
         'domain_of': ['Sequence'],
         'slot_uri': 'lara:base/ItemStatus'} })
    version: Optional[str] = Field(None, description="""version of the sequence""", json_schema_extra = { "linkml_meta": {'alias': 'version',
         'domain_of': ['ExtraData', 'Sequence'],
         'slot_uri': 'lara:sequences/Sequence/version'} })
    description: Optional[str] = Field(None, description="""description of the sequence""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData', 'SequenceClass', 'Sequence', 'SequencesSubset'],
         'slot_uri': 'lara:sequences/Sequence/description'} })
    iri: Optional[str] = Field(None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['ExtraData', 'SequenceClass', 'Sequence'],
         'slot_uri': 'lara:sequences/Sequence/iri'} })
    datetime_last_modified: Optional[str] = Field(None, description="""date and time when data was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData', 'Sequence', 'SequencesSubset'],
         'slot_uri': 'lara:sequences/Sequence/datetime_last_modified'} })
    tags: Optional[List[str]] = Field(None, description="""tags for sequence""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['Sequence', 'SequencesSubset'],
         'slot_uri': 'lara:base/Tag'} })


class SequencesSubset(ConfiguredBaseModel):
    """
    \" This class can be used to store a subset of sequences, e.g., a selection of sequences,
        which are relevant for a certain analysis, project, publication ...
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:sequences/SequencesSubset',
         'from_schema': 'https://w3id.org/lara/lara_django_sequences'})

    namespace: Optional[str] = Field(None, description="""namespace of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData', 'Sequence', 'SequencesSubset'],
         'slot_uri': 'lara:base/Namespace'} })
    name_display: Optional[str] = Field(None, description="""display name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData', 'Sequence', 'SequencesSubset'],
         'slot_uri': 'lara:sequences/SequencesSubset/name_display'} })
    name: Optional[str] = Field(None, description="""name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData', 'SequenceClass', 'Sequence', 'SequencesSubset'],
         'slot_uri': 'lara:sequences/SequencesSubset/name'} })
    entity: Optional[str] = Field(None, description="""user who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'entity',
         'domain_of': ['SequencesSubset'],
         'slot_uri': 'lara:people/Entity'} })
    group: Optional[str] = Field(None, description="""group who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'group',
         'domain_of': ['SequencesSubset'],
         'slot_uri': 'lara:people/Group'} })
    description: Optional[str] = Field(None, description="""description of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData', 'SequenceClass', 'Sequence', 'SequencesSubset'],
         'slot_uri': 'lara:sequences/SequencesSubset/description'} })
    datetime_last_modified: Optional[str] = Field(None, description="""datetime of last modification of the selection""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData', 'Sequence', 'SequencesSubset'],
         'slot_uri': 'lara:sequences/SequencesSubset/datetime_last_modified'} })
    sequencessubset_id: Optional[str] = Field(None, description="""SequencesSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'sequencessubset_id',
         'domain_of': ['SequencesSubset'],
         'slot_uri': 'lara:sequences/SequencesSubset/sequencessubset_id'} })
    tags: Optional[List[str]] = Field(None, description="""tags""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['Sequence', 'SequencesSubset'],
         'slot_uri': 'lara:base/Tag'} })
    sequences: Optional[List[str]] = Field(None, description="""sequences in the subset""", json_schema_extra = { "linkml_meta": {'alias': 'sequences',
         'domain_of': ['SequencesSubset', 'Container'],
         'slot_uri': 'lara:sequences/Sequence'} })


class OrderedSequencesSubset(ConfiguredBaseModel):
    """
    \" Through model for the many-to-many relationship between SequencesSubset and Sequence. 
        This class can be used to store the order of sequences in a subset
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:sequences/OrderedSequencesSubset',
         'from_schema': 'https://w3id.org/lara/lara_django_sequences'})

    orderedsequencessubset_id: Optional[str] = Field(None, description="""OrderedSequencesSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'orderedsequencessubset_id',
         'domain_of': ['OrderedSequencesSubset'],
         'slot_uri': 'lara:sequences/OrderedSequencesSubset/orderedsequencessubset_id'} })
    sequence: str = Field(..., description="""sequence in the subset""", json_schema_extra = { "linkml_meta": {'alias': 'sequence',
         'domain_of': ['Sequence', 'OrderedSequencesSubset'],
         'slot_uri': 'lara:sequences/Sequence'} })
    sequences_subset: str = Field(..., description="""subset of sequences""", json_schema_extra = { "linkml_meta": {'alias': 'sequences_subset',
         'domain_of': ['OrderedSequencesSubset'],
         'slot_uri': 'lara:sequences/SequencesSubset'} })
    order: int = Field(..., description="""order of sequence in subset""", json_schema_extra = { "linkml_meta": {'alias': 'order',
         'domain_of': ['OrderedSequencesSubset'],
         'slot_uri': 'lara:sequences/OrderedSequencesSubset/order'} })


class Container(ConfiguredBaseModel):
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_sequences',
         'tree_root': True})

    blockchainhashess: Optional[List[BlockchainHashes]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'blockchainhashess', 'domain_of': ['Container']} })
    extradatas: Optional[List[ExtraData]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'extradatas', 'domain_of': ['Container']} })
    sequenceclasss: Optional[List[SequenceClass]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'sequenceclasss', 'domain_of': ['Container']} })
    sequences: Optional[List[Sequence]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'sequences', 'domain_of': ['SequencesSubset', 'Container']} })
    sequencessubsets: Optional[List[SequencesSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'sequencessubsets', 'domain_of': ['Container']} })
    orderedsequencessubsets: Optional[List[OrderedSequencesSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'orderedsequencessubsets', 'domain_of': ['Container']} })


# Model rebuild
# see https://pydantic-docs.helpmanual.io/usage/models/#rebuilding-a-model
Tag.model_rebuild()
Namespace.model_rebuild()
Group.model_rebuild()
ItemStatus.model_rebuild()
DataType.model_rebuild()
Entity.model_rebuild()
MediaType.model_rebuild()
BlockchainHashes.model_rebuild()
ExtraData.model_rebuild()
SequenceClass.model_rebuild()
Sequence.model_rebuild()
SequencesSubset.model_rebuild()
OrderedSequencesSubset.model_rebuild()
Container.model_rebuild()

