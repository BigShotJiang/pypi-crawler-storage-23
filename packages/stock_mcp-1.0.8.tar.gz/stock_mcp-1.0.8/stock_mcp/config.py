"""配置文件"""

DEFAULT_DB_CONFIG = {
    "host": "localhost",
    "user": "aa",
    "password": "bb",
    "db": "ss",
    "port": 3306,
    "charset": "utf8mb4"
}

DEFAULT_SERVER_PORT = 30815