"""股票 MCP 服务器（集成Token权限管控+安全优化）"""

from http.server import HTTPServer, BaseHTTPRequestHandler
import json
import pymysql
import pymysql.cursors
from urllib.parse import urlparse
import os
import time
import hmac
import hashlib
import base64
import logging
import httpx
import httpcore
import urllib3
import time
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# 配置日志（方便排查问题）
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger(__name__)

# -------------------------- 核心配置（从环境变量读取，无硬编码） --------------------------
# Token加密私钥（仅服务器端知道，绝对保密！）
SECRET_KEY = os.getenv("QUANT_SECRET_KEY", "fengwei168168")  # 建议替换为随机复杂字符串
# Token有效期（秒），默认1年（和本地工具一致）
TOKEN_EXPIRE_SECONDS = int(os.getenv("QUANT_TOKEN_EXPIRE", 365 * 24 * 3600))
# 授权用户列表（可扩展到数据库/配置文件）
AUTHORIZED_USERS = {"user001", "user002", "user003"}  # 你分配的合法用户名

# -------------------------- Token生成/校验工具（同步修复：和本地工具逻辑一致） --------------------------
def generate_token(username: str) -> str:
    """基于用户名生成专属Token（管理员本地运行，分发给用户）"""
    if username not in AUTHORIZED_USERS:
        raise ValueError(f"用户{username}未授权，无法生成Token")

    # 1. 拼接用户名+时间戳（用于校验有效期）
    timestamp = str(int(time.time()))
    raw_str = f"{username}:{timestamp}"
    logger.debug(f"生成Token - 原始字符串：{raw_str}")

    # 2. HMAC-SHA256加密签名（URL安全Base64，去掉填充符）
    signature = hmac.new(
        SECRET_KEY.encode("utf-8"),
        raw_str.encode("utf-8"),
        digestmod=hashlib.sha256
    ).digest()
    signature_b64 = base64.urlsafe_b64encode(signature).decode("utf-8").rstrip("=")

    # 3. 拼接原始字符串+签名（改用|分隔，避免冲突）
    combined_str = f"{raw_str}|{signature_b64}"

    # 4. URL安全Base64编码，补全填充符
    token = base64.urlsafe_b64encode(combined_str.encode("utf-8")).decode("utf-8")
    token += "=" * ((4 - len(token) % 4) % 4)  # 补全填充符
    return token

def verify_token(token: str, username: str) -> bool:
    """校验Token合法性（接口调用时验证，和本地工具逻辑一致）"""
    try:
        # 1. 基础校验
        if not token or not username or username not in AUTHORIZED_USERS:
            logger.warning("基础校验失败：Token/用户名缺失或用户未授权")
            return False

        # 2. 补全填充符+URL安全Base64解码
        token = token.rstrip("=") + "=" * ((4 - len(token.rstrip("=")) % 4) % 4)
        decoded = base64.urlsafe_b64decode(token).decode("utf-8")
        logger.debug(f"Token解码后：{decoded}")

        # 3. 拆分原始字符串+签名（改用|分隔）
        if "|" not in decoded:
            logger.warning(f"Token格式错误：无分隔符|，解码内容：{decoded}")
            return False
        raw_str, signature_b64 = decoded.split("|", 1)

        # 4. 拆分用户名+时间戳
        if ":" not in raw_str:
            logger.warning(f"原始字符串格式错误：无分隔符:，内容：{raw_str}")
            return False
        token_username, timestamp = raw_str.split(":", 1)

        # 5. 校验用户名匹配
        if token_username != username:
            logger.warning(f"Token用户名不匹配：期望{username}，实际{token_username}")
            return False

        # 6. 校验有效期
        if int(time.time()) - int(timestamp) > TOKEN_EXPIRE_SECONDS:
            logger.warning(f"Token已过期：用户名{username}，时间戳{timestamp}")
            return False

        # 7. 校验签名（补全填充符后验证）
        signature_b64 += "=" * ((4 - len(signature_b64) % 4) % 4)
        signature = base64.urlsafe_b64decode(signature_b64)
        expected_signature = hmac.new(
            SECRET_KEY.encode("utf-8"),
            raw_str.encode("utf-8"),
            digestmod=hashlib.sha256
        ).digest()

        if signature != expected_signature:
            logger.warning(f"Token签名伪造：用户名{username}")
            return False

        return True
    except Exception as e:
        logger.error(f"Token校验失败：{str(e)}", exc_info=True)
        return False

# -------------------------- 数据库管理类（无修改） --------------------------
class DatabaseManager:
    """数据库管理类（优化连接管理+防注入）"""

    def __init__(self, config):
        """初始化

        Args:
            config: 数据库配置
        """
        self.config = config
        self.connection = None
        # 预定义合法的K线表名（防止SQL注入）
        self.valid_kline_tables = {f"day_kline_{i}" for i in range(10)}

    def get_connection(self):
        """获取数据库连接（自动重连）"""
        try:
            if self.connection and self.connection.open:
                return self.connection
            # 建立新连接（添加自动提交+字典游标）
            self.connection = pymysql.connect(
                **self.config,
                autocommit=True,
                cursorclass=pymysql.cursors.DictCursor
            )
            logger.info("数据库连接成功")
            return self.connection
        except Exception as e:
            logger.error(f"数据库连接失败：{str(e)}")
            raise

    def close(self):
        """关闭数据库连接（安全关闭）"""
        if self.connection and self.connection.open:
            try:
                self.connection.close()
                logger.info("数据库连接已关闭")
            except Exception as e:
                logger.error(f"关闭数据库连接失败：{str(e)}")
        self.connection = None

    def get_cursor(self):
        """获取游标（自动关联连接）"""
        return self.get_connection().cursor()

    def get_valid_kline_table(self, code: str) -> str:
        """获取合法的K线表名（防SQL注入）"""
        try:
            table_index = int(code[-1]) if code.isdigit() else 0
            table_name = f"day_kline_{table_index}"
            # 校验表名是否合法，防止注入
            if table_name not in self.valid_kline_tables:
                raise ValueError(f"非法的K线表名：{table_name}")
            return table_name
        except Exception as e:
            logger.error(f"获取K线表名失败：{str(e)}")
            raise

import urllib.request
import httpx

class FetchHttp:
    headers = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,'
                  'application/signed-exchange;v=b3;q=0.9',
        'Accept-Encoding': 'gzip, deflate, br',
        'Accept-Language': 'zh-CN,zh;q=0.9',
        'Cache-Control': 'max-age=0',
        'Connection': 'close',
        'Cookie': 'timezoneOffset=28800,0; _ga=GA1.2.2068924460.1568258364; browserid=1637567403399993326; '
                  'sessionid=0be65a169d686e464855602e; _gid=GA1.2.614169347.1590475272; '
                  'steamMachineAuth76561199007171441=CA87107A153BDC24FE6D54504A124395F9C36243; '
                  'deep_dive_carousel_focused_app=673750; deep_dive_carousel_method=gems; '
                  'steamCountry=HK%7C413cfd508f5a328ba1679f9252231a8e; '
                  'app_impressions=377530@1_7_7_topsellers_150_3|1245200@1_7_7_topsellers_150_3|632360'
                  '@1_7_7_topsellers_150_3|1245180@1_7_7_topsellers_150_3|1298590@1_7_7_topsellers_150_3|285900'
                  '@1_7_7_topsellers_150_3|632470@1_7_7_topsellers_150_2|813780@1_7_7_topsellers_150_2|1100600'
                  '@1_7_7_topsellers_150_2|1293820@1_7_7_topsellers_150_2|952860@1_7_7_topsellers_150_2|1209110'
                  '@1_7_7_topsellers_150_2|1015610@1_7_7_topsellers_150_3|1238440@1_7_7_topsellers_150_3|1042550'
                  '@1_7_7_topsellers_150_3|466560@1_7_7_topsellers_150_3|602960@1_7_7_topsellers_150_3|457140'
                  '@1_7_7_topsellers_150_3|793460@1_7_7_topsellers_150_3|512540@1_7_7_topsellers_150_3|619150'
                  '@1_7_7_topsellers_150_3|1100410@1_7_7_topsellers_150_3|1088780@1_7_7_topsellers_150_3|1100420'
                  '@1_7_7_topsellers_150_3|1201360@1_7_7_topsellers_150_3|642280@1_7_7_topsellers_150_3|673950'
                  '@1_7_7_topsellers_150_3|613830@1_7_7_topsellers_150_3|636480@1_7_7_topsellers_150_3|387990'
                  '@1_7_7_topsellers_150_3|414700@1_7_7_topsellers_150_3|382310@1_7_7_topsellers_150_3|1162520'
                  '@1_7_7_topsellers_150_2|289070@1_7_7_topsellers_150_2|307690@1_7_7_topsellers_150_2|973760'
                  '@1_7_7_topsellers_150_2|1273370@1_5_9__405; recentapps=%7B%22578080%22%3A1590476900%7D',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-User': '?1',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:52.0) Gecko/20210911 Firefox/52.0'
    }

    def __init__(self):
        pass

    def fetch(self,url,decode='utf-8'):
        stockDataResponse = urllib.request.urlopen(url)
        stockData = stockDataResponse.read()
        stockData = stockData.decode(decode)
        return stockData

    def craw(self,url):
        try:
            response = httpx.get(url, headers=self.headers, verify=False, timeout=5)
            return response.json()
        except:
            return False

# -------------------------- 请求处理器（无修改，仅复用修复后的verify_token） --------------------------
class MCPRequestHandler(BaseHTTPRequestHandler):
    headers = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,'
                  'application/signed-exchange;v=b3;q=0.9',
        'Accept-Encoding': 'gzip, deflate, br',
        'Accept-Language': 'zh-CN,zh;q=0.9',
        'Cache-Control': 'max-age=0',
        'Connection': 'close',
        'Cookie': 'timezoneOffset=28800,0; _ga=GA1.2.2068924460.1568258364; browserid=1637567403399993326; '
                  'sessionid=0be65a169d686e464855602e; _gid=GA1.2.614169347.1590475272; '
                  'steamMachineAuth76561199007171441=CA87107A153BDC24FE6D54504A124395F9C36243; '
                  'deep_dive_carousel_focused_app=673750; deep_dive_carousel_method=gems; '
                  'steamCountry=HK%7C413cfd508f5a328ba1679f9252231a8e; '
                  'app_impressions=377530@1_7_7_topsellers_150_3|1245200@1_7_7_topsellers_150_3|632360'
                  '@1_7_7_topsellers_150_3|1245180@1_7_7_topsellers_150_3|1298590@1_7_7_topsellers_150_3|285900'
                  '@1_7_7_topsellers_150_3|632470@1_7_7_topsellers_150_2|813780@1_7_7_topsellers_150_2|1100600'
                  '@1_7_7_topsellers_150_2|1293820@1_7_7_topsellers_150_2|952860@1_7_7_topsellers_150_2|1209110'
                  '@1_7_7_topsellers_150_2|1015610@1_7_7_topsellers_150_3|1238440@1_7_7_topsellers_150_3|1042550'
                  '@1_7_7_topsellers_150_3|466560@1_7_7_topsellers_150_3|602960@1_7_7_topsellers_150_3|457140'
                  '@1_7_7_topsellers_150_3|793460@1_7_7_topsellers_150_3|512540@1_7_7_topsellers_150_3|619150'
                  '@1_7_7_topsellers_150_3|1100410@1_7_7_topsellers_150_3|1088780@1_7_7_topsellers_150_3|1100420'
                  '@1_7_7_topsellers_150_3|1201360@1_7_7_topsellers_150_3|642280@1_7_7_topsellers_150_3|673950'
                  '@1_7_7_topsellers_150_3|613830@1_7_7_topsellers_150_3|636480@1_7_7_topsellers_150_3|387990'
                  '@1_7_7_topsellers_150_3|414700@1_7_7_topsellers_150_3|382310@1_7_7_topsellers_150_3|1162520'
                  '@1_7_7_topsellers_150_2|289070@1_7_7_topsellers_150_2|307690@1_7_7_topsellers_150_2|973760'
                  '@1_7_7_topsellers_150_2|1273370@1_5_9__405; recentapps=%7B%22578080%22%3A1590476900%7D',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-User': '?1',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:52.0) Gecko/20210911 Firefox/52.0'
    }
    """MCP 请求处理器（带Token权限校验）"""

    def __init__(self, *args, **kwargs):
        """初始化"""
        self.db_manager = kwargs.pop("db_manager")
        super().__init__(*args, **kwargs)

    def _send_response(self, status_code: int, data: dict):
        """统一响应格式（避免重复代码）"""
        self.send_response(status_code)
        self.send_header("Content-type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")  # 跨域支持（可选）
        self.end_headers()
        self.wfile.write(json.dumps(data, ensure_ascii=False).encode("utf-8"))

    def _validate_token(self, headers):
        """从请求头校验Token"""
        # 从请求头获取用户名和Token（推荐用X-开头的自定义头）
        username = headers.get("X-Quant-Username")
        token = headers.get("X-Quant-Token")

        # 基础校验
        if not username or not token:
            return False, {"error": "缺少用户名/Token，请在请求头配置 X-Quant-Username 和 X-Quant-Token"}

        # 校验Token合法性（复用修复后的verify_token）
        if not verify_token(token, username):
            return False, {"error": "Token非法/过期/用户名不匹配，请联系管理员"}

        return True, {"username": username}

    def do_GET(self):
        """处理 GET 请求（仅开放/tools和/health，且/health需Token校验）"""
        parsed_path = urlparse(self.path)

        # 处理工具列表请求（无需Token，公开）
        if parsed_path.path == "/tools":
            tools = {
                "tools": [
                    {
                        "name": "get_stock_info",
                        "description": "获取股票基本信息",
                        "parameters": {
                            "type": "object",
                            "properties": {
                                "code": {"type": "string", "description": "股票代码"}
                            },
                            "required": ["code"]
                        }
                    },
                    {
                        "name": "get_stock_price",
                        "description": "获取股票价格",
                        "parameters": {
                            "type": "object",
                            "properties": {
                                "code": {"type": "string", "description": "股票代码"}
                            },
                            "required": ["code"]
                        }
                    },
                    {
                        "name": "search_stocks_by_industry",
                        "description": "根据行业搜索股票",
                        "parameters": {
                            "type": "object",
                            "properties": {
                                "industry": {"type": "string", "description": "行业名称"},
                                "limit": {"type": "integer", "description": "返回结果数量限制", "default": 10}
                            },
                            "required": ["industry"]
                        }
                    },
                    {
                        "name": "get_day_kline",
                        "description": "获取股票日 K 线数据",
                        "parameters": {
                            "type": "object",
                            "properties": {
                                "code": {"type": "string", "description": "股票代码"},
                                "start_date": {"type": "string", "description": "开始日期 (YYYY-MM-DD)"},
                                "end_date": {"type": "string", "description": "结束日期 (YYYY-MM-DD)"},
                                "limit": {"type": "integer", "description": "返回结果数量限制", "default": 30}
                            },
                            "required": ["code"]
                        }
                    },
                    {
                        "name": "get_stock_list",
                        "description": "获取股票代码列表",
                        "parameters": {
                            "type": "object",
                            "properties": {
                                "limit": {"type": "integer", "description": "返回结果数量限制", "default": 50},
                                "offset": {"type": "integer", "description": "分页偏移量", "default": 0}
                            }
                        }
                    }
                ]
            }
            self._send_response(200, tools)
            return

        # 处理健康检查（需Token校验）
        if parsed_path.path == "/health":
            # 先校验Token
            is_valid, result = self._validate_token(self.headers)
            if not is_valid:
                self._send_response(401, result)
                return

            # 校验数据库连接
            try:
                cursor = self.db_manager.get_cursor()
                cursor.execute("SELECT 1")
                cursor.fetchone()
                health_status = {
                    "status": "healthy",
                    "service": "stock_data_service",
                    "database": "connected"
                }
            except Exception as e:
                health_status = {
                    "status": "unhealthy",
                    "service": "stock_data_service",
                    "database": f"disconnected: {str(e)}"
                }
            self._send_response(200, health_status)
            return

        # 其他路径返回 404
        self._send_response(404, {"error": "Not found"})

    def do_POST(self):
        """处理 POST 请求（/invoke需Token校验）"""
        # 仅处理/invoke接口
        if self.path != "/invoke":
            self._send_response(404, {"error": "Not found"})
            return

        # 第一步：校验Token（核心！无合法Token直接拒绝）
        is_valid, result = self._validate_token(self.headers)
        if not is_valid:
            self._send_response(401, result)
            return
        logger.info(f"授权用户{result['username']}调用接口")

        # 第二步：解析请求参数
        try:
            content_length = int(self.headers.get("Content-Length", 0))
            post_data = self.rfile.read(content_length).decode("utf-8") if content_length > 0 else "{}"
            data = json.loads(post_data)
        except json.JSONDecodeError as e:
            logger.error(f"JSON解析失败：{str(e)}")
            self._send_response(400, {"error": "Invalid JSON格式"})
            return

        # 第三步：处理工具调用
        tool_name = data.get("tool")
        tool_args = data.get("args", {})

        if not tool_name:
            self._send_response(400, {"error": "Tool name is required"})
            return

        # 调用相应的工具
        try:
            if tool_name == "get_stock_info":
                result = self._get_stock_info(tool_args.get("code"))
            elif tool_name == "get_stock_price":
                result = self._get_stock_price(tool_args.get("code"))
            elif tool_name == "search_stocks_by_industry":
                result = self._search_stocks_by_industry(
                    tool_args.get("industry"),
                    tool_args.get("limit", 10)
                )
            elif tool_name == "get_day_kline":
                result = self._get_day_kline(
                    tool_args.get("code"),
                    tool_args.get("start_date"),
                    tool_args.get("end_date"),
                    tool_args.get("limit", 30)
                )
            elif tool_name == "get_stock_list":
                result = self._get_stock_list(
                    tool_args.get("limit", 50),
                    tool_args.get("offset", 0)
                )
            else:
                result = {"success": False, "error": "Unknown tool"}
        except Exception as e:
            logger.error(f"工具调用失败：{str(e)}")
            result = {"success": False, "error": f"服务器内部错误：{str(e)}"}

        self._send_response(200, result)

    # -------------------------- 原有业务逻辑（无修改） --------------------------
    def _get_stock_info(self, code):
        """获取股票基本信息"""
        if not code:
            return {"success": False, "error": "Code is required"}

        try:
            cursor = self.db_manager.get_cursor()
            # 参数化查询（防注入）
            sql = "SELECT * FROM codes WHERE code = %s"
            cursor.execute(sql, (code,))
            result = cursor.fetchone()

            if result:
                return {"success": True, "data": result}
            else:
                return {"success": False, "message": f"未找到代码为 {code} 的股票"}
        except Exception as e:
            logger.error(f"获取股票信息失败：{str(e)}")
            return {"success": False, "message": f"查询失败: {str(e)}"}

    def _get_stock_price(self, code:str):
        """获取股票基本信息"""
        if not code:
            return {"success": False, "error": "Code is required"}

        try:
            fetch_http = FetchHttp()
            contents = fetch_http.fetch(
                "http://money.finance.sina.com.cn/quotes_service/api/json_v2.php/CN_MarketData.getKLineData?symbol=" + code.lower() + "&scale=5&ma=no&datalen=100", "gbk")
            if contents:
                return {"success": True, "data": contents}
            else:
                return {"success": False, "message": f"未找到代码为 {code} 的股票"}
        except Exception as e:
            logger.error(f"获取股票信息失败：{str(e)}")
            return {"success": False, "message": f"查询失败: {str(e)}"}

    def _search_stocks_by_industry(self, industry, limit=10):
        """根据行业搜索股票"""
        if not industry:
            return {"success": False, "error": "Industry is required"}

        try:
            cursor = self.db_manager.get_cursor()
            # 参数化查询（防注入）
            sql = "SELECT code, codename, industry FROM codes WHERE industry LIKE %s LIMIT %s"
            cursor.execute(sql, (f"%{industry}%", limit))
            results = cursor.fetchall()

            return {"success": True, "data": results}
        except Exception as e:
            logger.error(f"搜索行业股票失败：{str(e)}")
            return {"success": False, "message": f"查询失败: {str(e)}"}

    def _get_day_kline(self, code, start_date=None, end_date=None, limit=30):
        """获取股票日 K 线数据（防SQL注入）"""
        if not code:
            return {"success": False, "error": "Code is required"}

        try:
            # 获取合法的表名（防注入）
            table_name = self.db_manager.get_valid_kline_table(code)
            cursor = self.db_manager.get_cursor()

            # 动态拼接SQL，但表名已校验，参数全参数化
            sql_parts = [f"SELECT * FROM {table_name} WHERE code = %s"]
            params = [code]

            if start_date and end_date:
                sql_parts.append("AND trade_date BETWEEN %s AND %s")
                params.extend([start_date, end_date])
            elif start_date:
                sql_parts.append("AND trade_date >= %s")
                params.append(start_date)
            elif end_date:
                sql_parts.append("AND trade_date <= %s")
                params.append(end_date)

            sql_parts.append("ORDER BY trade_date DESC LIMIT %s")
            params.append(limit)

            sql = " ".join(sql_parts)
            cursor.execute(sql, tuple(params))
            results = cursor.fetchall()

            return {"success": True, "data": results}
        except Exception as e:
            logger.error(f"获取K线数据失败：{str(e)}")
            return {"success": False, "message": f"查询失败: {str(e)}"}

    def _get_stock_list(self, limit=50, offset=0):
        """获取股票代码列表"""
        try:
            cursor = self.db_manager.get_cursor()
            # 参数化查询（防注入）
            sql = "SELECT code, codename FROM codes ORDER BY id LIMIT %s OFFSET %s"
            cursor.execute(sql, (limit, offset))
            results = cursor.fetchall()

            return {"success": True, "data": results}
        except Exception as e:
            logger.error(f"获取股票列表失败：{str(e)}")
            return {"success": False, "message": f"查询失败: {str(e)}"}

# -------------------------- 服务器启动逻辑（无修改） --------------------------
def run_server(port=30815, db_config=None):
    """运行 MCP 服务器（从环境变量读取数据库配置，无硬编码）"""
    # 优先从环境变量读取数据库配置（避免硬编码）
    if db_config is None:
        db_config = {
            "host": os.getenv("QUANT_DB_HOST", "42.51.40.70"),
            "user": os.getenv("QUANT_DB_USER", ""),
            "password": os.getenv("QUANT_DB_PASSWORD", ""),
            "db": os.getenv("QUANT_DB_NAME", ""),
            "port": int(os.getenv("QUANT_DB_PORT", 3306)),
            "charset": "utf8mb4"
        }

    # 校验数据库配置
    required_db_keys = ["host", "user", "password", "db"]
    missing_keys = [k for k in required_db_keys if not db_config.get(k)]
    if missing_keys:
        logger.error(f"数据库配置缺失：{', '.join(missing_keys)}，请配置环境变量 QUANT_DB_*")
        raise ValueError(f"缺失数据库配置：{', '.join(missing_keys)}")

    # 创建数据库管理器
    db_manager = DatabaseManager(db_config)

    # 创建请求处理器类（绑定数据库管理器）
    class Handler(MCPRequestHandler):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, db_manager=db_manager, **kwargs)

    # 启动服务器（仅绑定0.0.0.0，生产环境建议加HTTPS）
    server_address = ("0.0.0.0", port)
    httpd = HTTPServer(server_address, Handler)
    logger.info(f"MCP 服务器启动在 http://0.0.0.0:{port}")
    logger.info(f"本地访问: http://localhost:{port}")
    logger.info(f"工具列表: http://localhost:{port}/tools")
    logger.info(f"健康检查: http://localhost:{port}/health（需Token）")
    logger.info("按 Ctrl+C 停止服务器")

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        logger.info("\n服务器正在停止...")
        httpd.shutdown()
        db_manager.close()
        logger.info("服务器已停止")

def main():
    """命令行入口（优先环境变量，参数为兜底）"""
    import argparse

    parser = argparse.ArgumentParser(description="股票 MCP 服务器（带Token权限管控）")
    parser.add_argument("--port", type=int, default=int(os.getenv("QUANT_SERVER_PORT", 30815)), help="服务端口")
    parser.add_argument("--host", default=os.getenv("QUANT_DB_HOST", ""), help="数据库主机（优先环境变量 QUANT_DB_HOST）")
    parser.add_argument("--user", default=os.getenv("QUANT_DB_USER", ""), help="数据库用户（优先环境变量 QUANT_DB_USER）")
    parser.add_argument("--password", default=os.getenv("QUANT_DB_PASSWORD", ""), help="数据库密码（优先环境变量 QUANT_DB_PASSWORD）")
    parser.add_argument("--db", default=os.getenv("QUANT_DB_NAME", ""), help="数据库名称（优先环境变量 QUANT_DB_NAME）")
    parser.add_argument("--db-port", type=int, default=int(os.getenv("QUANT_DB_PORT", 3306)), help="数据库端口（优先环境变量 QUANT_DB_PORT）")
    # 新增Token相关参数（优先环境变量）
    parser.add_argument("--secret-key", default=os.getenv("QUANT_SECRET_KEY", ""), help="Token加密私钥（优先环境变量 QUANT_SECRET_KEY）")
    parser.add_argument("--generate-token", default="", help="生成指定用户名的Token（仅管理员使用）")

    args = parser.parse_args()

    # 管理员生成Token（本地运行，不启动服务器）
    if args.generate_token:
        if not args.secret_key:
            logger.error("生成Token需配置 --secret-key 或环境变量 QUANT_SECRET_KEY")
            return
        global SECRET_KEY
        SECRET_KEY = args.secret_key
        try:
            token = generate_token(args.generate_token)
            logger.info(f"用户 {args.generate_token} 的Token：{token}")
            logger.info(f"Token有效期：{TOKEN_EXPIRE_SECONDS // 3600} 小时")
        except ValueError as e:
            logger.error(f"生成Token失败：{str(e)}")
        return

    # 配置数据库
    db_config = {
        "host": args.host,
        "user": args.user,
        "password": args.password,
        "db": args.db,
        "port": args.db_port,
        "charset": "utf8mb4"
    }

    # 启动服务器
    run_server(port=args.port, db_config=db_config)

if __name__ == "__main__":
    main()