"""测试股票数据 MCP 服务

此脚本用于测试 MCP 服务的各个功能，包括健康检查、工具列表获取、股票信息查询等。
适配server.py的Token权限管控，彻底解决中文/特殊字符编码问题。
"""
import json
import http.client

class MCPTestClient:
    """MCP 服务测试客户端（彻底解决编码问题+Token权限校验）"""

    def __init__(self, host='localhost', port=30815, username=None, token=None):
        """初始化客户端

        Args:
            host: 服务主机
            port: 服务端口
            username: 授权用户名（如user001）
            token: 对应用户名的合法Token
        """
        self.host = host
        self.port = port
        self.username = username
        self.token = token

    def _encode_header_value(self, value):
        """编码请求头值（兼容HTTP Latin-1规范）

        Args:
            value: 原始字符串

        Returns:
            Latin-1兼容的字符串
        """
        if not value:
            return ""
        # 先编码为UTF-8，再用Latin-1解码（忽略无法编码的字符）
        return value.encode('utf-8').decode('latin-1', 'ignore')

    def send_request(self, path, method='GET', body=None, require_token=False):
        """发送 HTTP 请求（彻底解决编码问题）

        Args:
            path: 请求路径
            method: 请求方法
            body: 请求体
            require_token: 是否需要携带Token请求头

        Returns:
            响应数据（包含状态码和响应体）
        """
        conn = http.client.HTTPConnection(self.host, self.port)

        # 基础请求头
        headers = {}
        request_body = None

        # 处理请求体（中文转UTF-8字节流）
        if body:
            headers['Content-Type'] = 'application/json; charset=utf-8'
            # 1. 保留中文序列化
            json_str = json.dumps(body, ensure_ascii=False)
            # 2. 编码为UTF-8字节流（避免Latin-1冲突）
            request_body = json_str.encode('utf-8')

        # 处理Token请求头（关键：编码为Latin-1兼容格式）
        if require_token:
            if not self.username or not self.token:
                raise ValueError("访问授权接口需要配置 username 和 token！")
            # 编码请求头值，兼容HTTP规范
            headers['X-Quant-Username'] = self._encode_header_value(self.username)
            headers['X-Quant-Token'] = self._encode_header_value(self.token)

        try:
            # 发送请求（body为UTF-8字节流，headers为Latin-1兼容）
            conn.request(method, path, request_body, headers)
            response = conn.getresponse()

            # 读取响应（强制UTF-8解码）
            data = response.read().decode('utf-8', 'ignore')
            status_code = response.status
            print(f"请求 {method} {path} | 状态码: {status_code}")

            # 解析JSON响应
            result_data = None
            if data:
                try:
                    result_data = json.loads(data)
                except json.JSONDecodeError:
                    result_data = data

            return {
                "status_code": status_code,
                "data": result_data
            }
        finally:
            conn.close()

    def test_health_check(self):
        """测试健康检查端点（需Token）"""
        print("\n=== 测试健康检查（需Token）===")
        result = self.send_request('/health', require_token=True)
        print("响应结果：")
        print(json.dumps(result['data'], indent=2, ensure_ascii=False))
        return result

    def test_tools_list(self):
        """测试工具列表端点（无需Token）"""
        print("\n=== 测试工具列表（无需Token）===")
        result = self.send_request('/tools', require_token=False)
        print("响应结果：")
        print(json.dumps(result['data'], indent=2, ensure_ascii=False))
        return result

    def test_get_stock_info(self, code):
        """测试获取股票基本信息（需Token）"""
        print(f"\n=== 测试获取股票信息: {code}（需Token）===")
        body = {
            "tool": "get_stock_info",
            "args": {
                "code": code
            }
        }
        result = self.send_request('/invoke', 'POST', body, require_token=True)
        print("响应结果：")
        print(json.dumps(result['data'], indent=2, ensure_ascii=False))
        return result

    def test_search_stocks_by_industry(self, industry, limit=5):
        """测试根据行业搜索股票（需Token，支持中文行业名）"""
        print(f"\n=== 测试根据行业搜索: {industry}（需Token）===")
        body = {
            "tool": "search_stocks_by_industry",
            "args": {
                "industry": industry,
                "limit": limit
            }
        }
        result = self.send_request('/invoke', 'POST', body, require_token=True)
        print("响应结果：")
        print(json.dumps(result['data'], indent=2, ensure_ascii=False))
        return result

    def test_get_day_kline(self, code, limit=5):
        """测试获取股票日 K 线数据（需Token）"""
        print(f"\n=== 测试获取日 K 线: {code}（需Token）===")
        body = {
            "tool": "get_day_kline",
            "args": {
                "code": code,
                "limit": limit
            }
        }
        result = self.send_request('/invoke', 'POST', body, require_token=True)
        print("响应结果：")
        print(json.dumps(result['data'], indent=2, ensure_ascii=False))
        return result

    def test_get_stock_list(self, limit=5):
        """测试获取股票列表（需Token）"""
        print(f"\n=== 测试获取股票列表（需Token）===")
        body = {
            "tool": "get_stock_list",
            "args": {
                "limit": limit
            }
        }
        result = self.send_request('/invoke', 'POST', body, require_token=True)
        print("响应结果：")
        print(json.dumps(result['data'], indent=2, ensure_ascii=False))
        return result

    def test_invalid_token(self, code='SZ300750'):
        """测试无效Token访问（验证权限管控，解决编码问题）"""
        print(f"\n=== 测试无效Token访问（验证权限管控）===")
        # 初始化无效Token客户端（特殊字符Token也能兼容）
        invalid_client = MCPTestClient(
            host=self.host,
            port=self.port,
            username=self.username,
            token="无效的Token字符串123456😜"  # 即使有特殊字符也不报错
        )
        body = {
            "tool": "get_stock_info",
            "args": {"code": code}
        }
        result = invalid_client.send_request('/invoke', 'POST', body, require_token=True)
        print("响应结果：")
        print(json.dumps(result['data'], indent=2, ensure_ascii=False))
        return result

def main():
    """主测试函数（替换为你的实际Token）"""
    print("开始测试股票数据 MCP 服务（彻底解决编码问题）...")

    # ===================== 配置项（替换为你的实际信息）=====================
    HOST = "42.51.40.70"
    PORT = 30815
    USERNAME = "user001"
    TOKEN = "dXNlcjAwMToxNzcwNDU1NTU5fE5zQXhiVUQzc1VpZWFhM0c0czFHU3pOQW5BbXpIS0gtSnJnZi1MTlFLYzA="
    # ====================================================================

    client = MCPTestClient(
        host=HOST,
        port=PORT,
        username=USERNAME,
        token=TOKEN
    )

    # 运行所有测试（包含中文+无效Token场景）
    client.test_tools_list()
    client.test_health_check()
    client.test_get_stock_info('SZ300750')
    client.test_search_stocks_by_industry('电气设备', 3)
    client.test_get_day_kline('SZ300750', 3)
    client.test_get_stock_list(5)
    client.test_invalid_token('SZ300750')

    print("\n测试完成！")

if __name__ == '__main__':
    main()