# stock_mcp/core.py（组件内的核心客户端代码，无测试逻辑）
import requests

class StockMCPClient:
    """stock_mcp 组件核心客户端（纯业务调用，无测试冗余）"""
    def __init__(self, host="42.51.40.70", port=30815, username=None, token=None):
        self.base_url = f"http://{host}:{port}"
        self.headers = {
            "X-Quant-Username": username,
            "X-Quant-Token": token,
            "Content-Type": "application/json; charset=utf-8"
        }

    # 核心业务接口：获取单只股票信息
    def get_stock_info(self, code):
        """获取股票基本信息
        :param code: 股票代码（如 SZ300750）
        :return: 字典格式的股票数据（成功返回data，失败返回error）
        """
        try:
            resp = requests.post(
                url=f"{self.base_url}/invoke",
                headers=self.headers,
                json={"tool": "get_stock_info", "args": {"code": code}},
                timeout=10
            )
            resp.raise_for_status()
            return resp.json()
        except Exception as e:
            return {"success": False, "error": str(e)}

    # 核心业务接口：按行业搜索股票
    def search_by_industry(self, industry, limit=10):
        """按行业搜索股票
        :param industry: 行业名称（如 电气设备、电池）
        :param limit: 返回数量
        :return: 行业股票列表
        """
        try:
            resp = requests.post(
                url=f"{self.base_url}/invoke",
                headers=self.headers,
                json={"tool": "search_stocks_by_industry", "args": {"industry": industry, "limit": limit}},
                timeout=10
            )
            resp.raise_for_status()
            return resp.json()
        except Exception as e:
            return {"success": False, "error": str(e)}

    # 核心业务接口：获取日K线数据
    def get_day_kline(self, code, limit=10):
        """获取股票日K线数据
        :param code: 股票代码
        :param limit: 返回K线数量
        :return: K线数据列表
        """
        try:
            resp = requests.post(
                url=f"{self.base_url}/invoke",
                headers=self.headers,
                json={"tool": "get_day_kline", "args": {"code": code, "limit": limit}},
                timeout=10
            )
            resp.raise_for_status()
            return resp.json()
        except Exception as e:
            return {"success": False, "error": str(e)}

    # 核心业务接口：获取股票列表
    def get_stock_list(self, limit=10, offset=0):
        """获取股票列表（分页）
        :param limit: 返回数量
        :param offset: 偏移量
        :return: 股票列表
        """
        try:
            resp = requests.post(
                url=f"{self.base_url}/invoke",
                headers=self.headers,
                json={"tool": "get_stock_list", "args": {"limit": limit, "offset": offset}},
                timeout=10
            )
            resp.raise_for_status()
            return resp.json()
        except Exception as e:
            return {"success": False, "error": str(e)}

if __name__ == "__main__":
    main()