from setuptools import setup, find_packages

setup(
    name="stock_mcp",
    version="1.0.8",
    description="股票数据 MCP 服务",
    long_description=open("README.md",encoding='utf-8').read(),
    long_description_content_type="text/markdown",
    author="fengwei168",
    author_email="fengwei168@aliyun.com",
    url="https://github.com/fengwei168/stock-mcp",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "pymysql>=1.1.2",
        "httpcore>=1.0.9",
        "httpx>=0.28.1"
    ],
    entry_points={
        "console_scripts": [
            "stock-mcp-server=stock_mcp.server:main",
            "stock-mcp-client=stock_mcp.client:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
)