# stock-mcp

股票数据 MCP (Model Context Protocol) 服务，提供股票代码和日 K 线数据的查询功能。

## 功能特性

- 股票基本信息查询
- 按行业搜索股票
- 股票日 K 线数据查询
- 股票代码列表获取
- 基于 HTTP 的 MCP 服务接口
- 简单易用的 Python 客户端

## 快速开始

### 安装

```bash
pip install stock-mcp
```

### 启动服务器

```bash
# 使用默认配置启动
stock-mcp-server

# 自定义配置启动
stock-mcp-server --port 30815 --host 42.51.40.70 --user xx --password xxx --db xx --db-port 3306
```

### 使用客户端

```python
from stock_mcp import StockMCPClient

# 初始化客户端
client = StockMCPClient(
    host="42.51.40.70",
    port=30815,
    username="user001",
    token="token"  # 替换为实际生成的Token
)

# 纯业务调用（无任何冗余）
stock_info = client.get_stock_info("SZ300750")
print("宁德时代信息：", stock_info)
```

### 命令行客户端

```bash
# 获取股票信息
stock-mcp-client info --code SZ300750

# 获取日 K 线数据
stock-mcp-client kline --code SZ300750 --limit 10

# 健康检查
stock-mcp-client health
```

## API 接口

### 健康检查
- **端点**: GET /health
- **功能**: 检查服务和数据库连接状态

### 工具列表
- **端点**: GET /tools
- **功能**: 获取所有可用工具的定义

### 工具调用
- **端点**: POST /invoke
- **功能**: 调用具体的工具执行操作
- **请求格式**:
  ```json
  {
    "tool": "工具名称",
    "args": {
      "参数1": "值1",
      "参数2": "值2"
    }
  }
  ```

## 依赖项

- Python 3.8+
- PyMySQL 1.1.2+

## 许可证

MIT