"""Allow running as `python -m sprout`."""

from sprout.server import main

main()
