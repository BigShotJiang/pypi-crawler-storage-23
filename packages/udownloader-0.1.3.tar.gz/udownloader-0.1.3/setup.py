#!/usr/bin/env python3
"""
Setup script for uDownloader.
Modern approach using pyproject.toml is preferred.
This file exists for compatibility.
"""

from setuptools import setup

setup()
