# Legacy worker registration code for backward compatibility with older Hatchet engines
# that do not support the slot_config-based registration (pre v0.76.0).
