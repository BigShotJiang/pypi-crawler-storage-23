# sage_setup: distribution = sagemath-flint

from sage.all__sagemath_flint import *
