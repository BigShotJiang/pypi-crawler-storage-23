# sage_setup: distribution = sagemath-flint

from sage.rings.number_field.number_field import GaussianField

I = GaussianField().gen()
