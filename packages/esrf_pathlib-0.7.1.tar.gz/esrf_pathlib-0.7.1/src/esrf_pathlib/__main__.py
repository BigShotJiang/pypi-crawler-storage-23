"""Print ESRF path information

.. code-block:: bash

    esrf-pathlib esrf=3 tomo=1
    esrf-pathlib esrf=3 --fallback-depth=1
"""

import argparse
import json
import logging
from typing import List

from ._schemas.registry import get_schema_registry
from .core import ESRFPath


def _parse_cli_schemas(schemas_list: List[str]):
    """Convert list like ['esrf=3', 'tomo=1'] to dict."""
    result = {}
    for s in schemas_list or []:
        key, value = s.split("=")
        result[key] = json.loads(value)
    if not result:
        return ESRFPath._SCHEMAS
    return result


def main():
    parser = argparse.ArgumentParser(description="Print ESRF path information.")
    parser.add_argument(
        "schemas",
        nargs="*",
        default=[],
        help="Schema versions, e.g. esrf=3 tomo=1",
    )
    parser.add_argument(
        "--fallback-depth",
        type=int,
        default=0,
        help="Include previous schema versions as fallback",
    )
    args = parser.parse_args()

    logging.basicConfig(level=logging.DEBUG)

    schema_kwargs = _parse_cli_schemas(args.schemas)

    registry = get_schema_registry(**schema_kwargs, fallback_depth=args.fallback_depth)
    print(registry.__info__())


if __name__ == "__main__":
    main()
