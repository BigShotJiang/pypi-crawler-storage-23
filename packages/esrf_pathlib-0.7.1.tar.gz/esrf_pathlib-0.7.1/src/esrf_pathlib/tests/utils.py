import os

from .._schemas import constants

_BASE_PATH = "X:\\" if constants.IS_WINDOWS else "/data"


def make_path(*parts) -> str:
    return os.path.join(_BASE_PATH, *parts)
