from typing import Union

import pytest

from ..._schemas import errors
from ..._schemas.fields.concept import PathConcept
from ..._schemas.identifier import SchemaIdentifier


def test_init_and_properties():
    concept = PathConcept("test", "A test concept", SchemaIdentifier(test=1), r"[a-z]+")
    assert concept.name == "test"
    assert concept.description == "A test concept"
    assert concept.schema_identifier == SchemaIdentifier(test=1)
    assert concept.regex == r"[a-z]+"


def test_deserialize_success():
    concept = PathConcept(
        "test", "A test concept", SchemaIdentifier(test=1), r"\d+deg", deserializer=int
    )
    assert concept.deserialize("42") == 42


def test_serialize_success():
    def _serializer_tomo_angle(py_value: Union[str, int, float]) -> str:
        return f"{py_value}deg"

    concept = PathConcept(
        "test",
        "A test concept",
        SchemaIdentifier(test=1),
        r"\d+deg",
        serializer=_serializer_tomo_angle,
    )
    assert concept.serialize(10) == "10deg"


def test_deserialize_none_returns_none():
    concept = PathConcept("test", "A test concept", SchemaIdentifier(test=1), r"\w+")
    assert concept.deserialize(None) is None


def test_serialize_none_wildcard():
    concept = PathConcept("test", "A test concept", SchemaIdentifier(test=1), r"\w+")
    assert concept.serialize(None, raise_on_missing=False) == "*"


def test_serialize_none_raises():
    concept = PathConcept("test", "A test concept", SchemaIdentifier(test=1), r"\w+")
    with pytest.raises(errors.PathConceptWithoutValue):
        concept.serialize(None)


def test_serialize_failure():
    def bad_serializer(_):
        raise RuntimeError("nope")

    concept = PathConcept(
        "test",
        "A test concept",
        SchemaIdentifier(test=1),
        r"\w+",
        serializer=bad_serializer,
    )
    with pytest.raises(errors.PathConceptMatchError) as exc:
        concept.serialize("bad")
    assert "serialization failed" in str(exc.value)


def test_deserialize_failure():
    def bad_deserializer(_):
        raise RuntimeError("boom")

    concept = PathConcept(
        "test",
        "A test concept",
        SchemaIdentifier(test=1),
        r"\w+",
        deserializer=bad_deserializer,
    )
    with pytest.raises(errors.PathConceptMatchError) as exc:
        concept.deserialize("bad")
    assert "deserialization failed" in str(exc.value)
