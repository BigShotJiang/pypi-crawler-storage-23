from ..._schemas.fields.derived import DerivedConcept
from ..._schemas.identifier import SchemaIdentifier


def test_init_and_properties():
    def derive_func(d):
        return None

    concept = DerivedConcept(
        "test", "A test concept", SchemaIdentifier(test=1), derive_func, []
    )
    assert concept.name == "test"
    assert concept.description == "A test concept"
    assert concept.schema_identifier == SchemaIdentifier(test=1)


def test_derive():
    def derive_func(d) -> str:
        return d["first"] + " " + d["last"]

    concept = DerivedConcept(
        "test",
        "A test concept",
        SchemaIdentifier(test=1),
        derive_func,
        ["first", "last"],
    )
    assert concept.derive({"first": "John", "last": "Doe", "unused": 11}) == "John Doe"
