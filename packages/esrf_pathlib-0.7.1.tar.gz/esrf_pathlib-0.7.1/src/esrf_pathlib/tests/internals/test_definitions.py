import datetime

import pytest

from ..._schemas.definitions import load
from ..._schemas.definitions import types
from ..utils import make_path


@pytest.mark.parametrize(
    "name,version",
    [
        (name, version)
        for name, versions in load._ALL_VERSIONS.items()
        for version in versions
    ],
)
def test_info(name, version):
    schema = load.get_schema(name, version)
    info = schema.__info__()
    assert str(schema.identifier) in info

    for fields in (schema.concepts, schema.derived_concepts, schema.templates):
        for name in fields:
            assert f"{name}:" in info, name


_CONCEPT_VALUES = {
    "unknown_part": "something",
    "data_root": make_path("visitor"),
    "proposal": "hg123",
    "beamline": "id00",
    "session_date": datetime.date(2025, 5, 9),
    "collection": "sample",
    "dataset": "0001",
    "data_type": types.DataType.RAW,
    "tomo_angle": 90,
    "tomo_technique": "phase",
    "tomo_type": "stitched",
    "tomo_slicing_direction": "xy",
    "tomo_slice_number": 10,
    "tomo_dtype": "16Bit",
    "tomo_result_type": types.TomoResultType.SLICE,
    "tomo_extension": "tiff",
    "tomo_application": "ewokstomo",
    "thumbnail_file_type": "jpg",
    "note_type": "txt",
}


@pytest.mark.parametrize(
    "name,version",
    [
        (name, version)
        for name, versions in load._ALL_VERSIONS.items()
        for version in versions
    ],
)
def test_concepts(name, version):
    schema = load.get_schema(name, version)
    concepts = schema.concepts
    for cname, concept in concepts.items():
        if cname not in _CONCEPT_VALUES:
            raise RuntimeError(f"Concept {cname!r} does not have a test value")
        py_value = _CONCEPT_VALUES[cname]

        # Round-trip
        string_value = concept.serialize(py_value)
        py_value2 = concept.deserialize(string_value)
        assert py_value == py_value2, cname

        # None pass-through
        assert concept.serialize(None, raise_on_missing=False) == "*", cname
        assert concept.deserialize(None) is None, cname


_PATH_VALUES_UNKNOWN_V1 = {
    "unknown_path": make_path("visitor", "hg123", "id00"),
}

_PATH_VALUES_ESRF_V1 = {
    **_PATH_VALUES_UNKNOWN_V1,
    "session_path": make_path("visitor", "hg123", "id00", "20251201"),
    "raw_data_path": make_path("visitor", "hg123", "id00", "20251201"),
    "raw_proposal_file": make_path(
        "visitor", "hg123", "id00", "20251201", "hg123_id00.h5"
    ),
    "raw_collection_path": make_path("visitor", "hg123", "id00", "20251201", "sample"),
    "raw_collection_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "sample",
        "hg123_sample.h5",
    ),
    "raw_dataset_path": make_path(
        "visitor", "hg123", "id00", "20251201", "sample", "sample_0001"
    ),
    "raw_dataset_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "sample",
        "sample_0001",
        "sample_0001.h5",
    ),
    "raw_gallery_path": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "sample",
        "sample_0001",
        "gallery",
    ),
    "raw_metadata_path": make_path("visitor", "hg123", "id00", "20251201", "__icat__"),
    "raw_metadata_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "__icat__",
        "sample_0001.xml",
    ),
}

_PATH_VALUES_ESRF_V2 = {
    **_PATH_VALUES_UNKNOWN_V1,
    "session_path": make_path("visitor", "hg123", "id00", "20251201"),
    "raw_data_path": make_path("visitor", "hg123", "id00", "20251201", "raw"),
    "raw_proposal_file": make_path(
        "visitor", "hg123", "id00", "20251201", "raw", "hg123_id00.h5"
    ),
    "raw_collection_path": make_path(
        "visitor", "hg123", "id00", "20251201", "raw", "sample"
    ),
    "raw_collection_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "raw",
        "sample",
        "hg123_sample.h5",
    ),
    "raw_dataset_path": make_path(
        "visitor", "hg123", "id00", "20251201", "raw", "sample", "sample_0001"
    ),
    "raw_dataset_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "raw",
        "sample",
        "sample_0001",
        "sample_0001.h5",
    ),
    "raw_gallery_path": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "raw",
        "sample",
        "sample_0001",
        "gallery",
    ),
    "raw_metadata_path": make_path(
        "visitor", "hg123", "id00", "20251201", "raw", "__icat__"
    ),
    "raw_metadata_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "raw",
        "__icat__",
        "sample_0001.xml",
    ),
    "processed_data_path": make_path(
        "visitor", "hg123", "id00", "20251201", "processed"
    ),
    "processed_proposal_file": make_path(
        "visitor", "hg123", "id00", "20251201", "processed", "hg123_id00.h5"
    ),
    "processed_collection_path": make_path(
        "visitor", "hg123", "id00", "20251201", "processed", "sample"
    ),
    "processed_collection_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "processed",
        "sample",
        "hg123_sample.h5",
    ),
    "processed_dataset_path": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "processed",
        "sample",
        "sample_0001",
    ),
    "processed_dataset_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "processed",
        "sample",
        "sample_0001",
        "sample_0001.h5",
    ),
    "processed_gallery_path": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "processed",
        "sample",
        "sample_0001",
        "gallery",
    ),
    "processed_metadata_path": make_path(
        "visitor", "hg123", "id00", "20251201", "processed", "__icat__"
    ),
    "processed_metadata_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "processed",
        "__icat__",
        "sample_0001.xml",
    ),
    "nobackup_path": make_path("visitor", "hg123", "id00", "20251201", "_nobackup"),
    "nobackup_proposal_file": make_path(
        "visitor", "hg123", "id00", "20251201", "_nobackup", "hg123_id00.h5"
    ),
    "nobackup_collection_path": make_path(
        "visitor", "hg123", "id00", "20251201", "_nobackup", "sample"
    ),
    "nobackup_collection_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "_nobackup",
        "sample",
        "hg123_sample.h5",
    ),
    "nobackup_dataset_path": make_path(
        "visitor", "hg123", "id00", "20251201", "_nobackup", "sample", "sample_0001"
    ),
    "nobackup_dataset_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "_nobackup",
        "sample",
        "sample_0001",
        "sample_0001.h5",
    ),
    "nobackup_gallery_path": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "_nobackup",
        "sample",
        "sample_0001",
        "gallery",
    ),
    "nobackup_metadata_path": make_path(
        "visitor", "hg123", "id00", "20251201", "_nobackup", "__icat__"
    ),
    "nobackup_metadata_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "_nobackup",
        "__icat__",
        "sample_0001.xml",
    ),
    "scripts_path": make_path("visitor", "hg123", "id00", "20251201", "SCRIPTS"),
    "gallery_path": make_path("visitor", "hg123", "id00", "20251201", "GALLERY"),
    "notes_path": make_path("visitor", "hg123", "id00", "20251201", "NOTES"),
}


_PATH_VALUES_ESRF_V3 = {
    **_PATH_VALUES_UNKNOWN_V1,
    "session_path": make_path("visitor", "hg123", "id00", "20251201"),
    "raw_data_path": make_path("visitor", "hg123", "id00", "20251201", "RAW_DATA"),
    "raw_proposal_file": make_path(
        "visitor", "hg123", "id00", "20251201", "RAW_DATA", "hg123_id00.h5"
    ),
    "raw_collection_path": make_path(
        "visitor", "hg123", "id00", "20251201", "RAW_DATA", "sample"
    ),
    "raw_collection_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "RAW_DATA",
        "sample",
        "hg123_sample.h5",
    ),
    "raw_dataset_path": make_path(
        "visitor", "hg123", "id00", "20251201", "RAW_DATA", "sample", "sample_0001"
    ),
    "raw_dataset_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "RAW_DATA",
        "sample",
        "sample_0001",
        "sample_0001.h5",
    ),
    "raw_gallery_path": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "RAW_DATA",
        "sample",
        "sample_0001",
        "gallery",
    ),
    "raw_metadata_path": make_path(
        "visitor", "hg123", "id00", "20251201", "RAW_DATA", "__icat__"
    ),
    "raw_metadata_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "RAW_DATA",
        "__icat__",
        "sample_0001.xml",
    ),
    "processed_data_path": make_path(
        "visitor", "hg123", "id00", "20251201", "PROCESSED_DATA"
    ),
    "processed_proposal_file": make_path(
        "visitor", "hg123", "id00", "20251201", "PROCESSED_DATA", "hg123_id00.h5"
    ),
    "processed_collection_path": make_path(
        "visitor", "hg123", "id00", "20251201", "PROCESSED_DATA", "sample"
    ),
    "processed_collection_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "hg123_sample.h5",
    ),
    "processed_dataset_path": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "sample_0001",
    ),
    "processed_dataset_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "sample_0001",
        "sample_0001.h5",
    ),
    "processed_gallery_path": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "sample_0001",
        "gallery",
    ),
    "processed_metadata_path": make_path(
        "visitor", "hg123", "id00", "20251201", "PROCESSED_DATA", "__icat__"
    ),
    "processed_metadata_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "__icat__",
        "sample_0001.xml",
    ),
    "nobackup_path": make_path("visitor", "hg123", "id00", "20251201", "NOBACKUP"),
    "nobackup_proposal_file": make_path(
        "visitor", "hg123", "id00", "20251201", "NOBACKUP", "hg123_id00.h5"
    ),
    "nobackup_collection_path": make_path(
        "visitor", "hg123", "id00", "20251201", "NOBACKUP", "sample"
    ),
    "nobackup_collection_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "NOBACKUP",
        "sample",
        "hg123_sample.h5",
    ),
    "nobackup_dataset_path": make_path(
        "visitor", "hg123", "id00", "20251201", "NOBACKUP", "sample", "sample_0001"
    ),
    "nobackup_dataset_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "NOBACKUP",
        "sample",
        "sample_0001",
        "sample_0001.h5",
    ),
    "nobackup_gallery_path": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "NOBACKUP",
        "sample",
        "sample_0001",
        "gallery",
    ),
    "nobackup_metadata_path": make_path(
        "visitor", "hg123", "id00", "20251201", "NOBACKUP", "__icat__"
    ),
    "nobackup_metadata_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "NOBACKUP",
        "__icat__",
        "sample_0001.xml",
    ),
    "scripts_path": make_path("visitor", "hg123", "id00", "20251201", "SCRIPTS"),
    "gallery_path": make_path("visitor", "hg123", "id00", "20251201", "GALLERY"),
    "notes_path": make_path("visitor", "hg123", "id00", "20251201", "NOTES"),
}

_PATH_VALUES_TOMO_V1 = {
    **_PATH_VALUES_ESRF_V3,
    "references_path": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "sample_0001",
        "references",
    ),
    "references_dark": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "sample_0001",
        "references",
        "sample_0001_darks.hdf5",
    ),
    "references_flat": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "sample_0001",
        "references",
        "sample_0001_flats.hdf5",
    ),
    "projections_path": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "sample_0001",
        "projections",
    ),
    "projections_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "sample_0001",
        "projections",
        "sample_0001.nx",
    ),
    "projections_gallery_path": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "sample_0001",
        "projections",
        "gallery",
    ),
    "projections_metadata_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "sample_0001",
        "projections",
        "gallery",
        "metadata.json",
    ),
    "projections_thumbnail": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "sample_0001",
        "projections",
        "gallery",
        "sample_0001_90deg_large.jpg",
    ),
    "projections_preview": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "sample_0001",
        "projections",
        "gallery",
        "sample_0001_90deg.jpg",
    ),
    "slices_path": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "sample_0001",
        "slices",
    ),
    "slices_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "sample_0001",
        "slices",
        "sample_0001_phase_xy_00001.tiff",
    ),
    "slices_gallery_path": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "sample_0001",
        "slices",
        "gallery",
    ),
    "slices_metadata_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "sample_0001",
        "slices",
        "gallery",
        "metadata.json",
    ),
    "slices_thumbnail": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "sample_0001",
        "slices",
        "gallery",
        "sample_0001_phase_xy_00001_large.jpg",
    ),
    "slices_preview": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "sample_0001",
        "slices",
        "gallery",
        "sample_0001_phase_xy_00001.jpg",
    ),
    "volumes_path": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "sample_0001",
        "volumes",
    ),
    "volumes_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "sample_0001",
        "volumes",
        "sample_0001_phase_16Bit_vol",
    ),
    "volumes_slice_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "sample_0001",
        "volumes",
        "sample_0001_phase_16Bit_vol",
        "sample_0001_00001.vol",
    ),
    "volumes_gallery_path": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "sample_0001",
        "volumes",
        "sample_0001_phase_16Bit_vol",
        "gallery",
    ),
    "volumes_metadata_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "sample_0001",
        "volumes",
        "sample_0001_phase_16Bit_vol",
        "gallery",
        "metadata.json",
    ),
    "volumes_thumbnail": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "sample_0001",
        "volumes",
        "sample_0001_phase_16Bit_vol",
        "gallery",
        "sample_0001_phase_xy_00001_large.jpg",
    ),
    "volumes_preview": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "sample_0001",
        "volumes",
        "sample_0001_phase_16Bit_vol",
        "gallery",
        "sample_0001_phase_xy_00001.jpg",
    ),
    "volumes_custom_type_path": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "sample_0001",
        "volumes_stitched",
    ),
    "volumes_custom_type_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "sample_0001",
        "volumes_stitched",
        "sample_0001_phase_stitched_16Bit_vol",
    ),
    "volumes_custom_type_slice_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "sample_0001",
        "volumes_stitched",
        "sample_0001_phase_stitched_16Bit_vol",
        "sample_0001_00001.vol",
    ),
    "volumes_custom_type_gallery_path": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "sample_0001",
        "volumes_stitched",
        "sample_0001_phase_stitched_16Bit_vol",
        "gallery",
    ),
    "volumes_custom_type_metadata_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "sample_0001",
        "volumes_stitched",
        "sample_0001_phase_stitched_16Bit_vol",
        "gallery",
        "metadata.json",
    ),
    "volumes_custom_type_thumbnail": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "sample_0001",
        "volumes_stitched",
        "sample_0001_phase_stitched_16Bit_vol",
        "gallery",
        "sample_0001_phase_stitched_xy_00001_large.jpg",
    ),
    "volumes_custom_type_preview": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "sample_0001",
        "volumes_stitched",
        "sample_0001_phase_stitched_16Bit_vol",
        "gallery",
        "sample_0001_phase_stitched_xy_00001.jpg",
    ),
    "tomo_log_path": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "sample_0001",
        "logs",
    ),
    "tomo_log_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "sample_0001",
        "logs",
        "sample_0001_ewokstomo.log",
    ),
    "workflows_path": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "sample_0001",
        "workflows",
    ),
    "workflows_gallery_path": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "sample_0001",
        "workflows",
        "gallery",
    ),
    "workflows_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "sample_0001",
        "workflows",
        "gallery",
        "sample_0001.json",
    ),
    "slices_link_collection_path": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "SLICES",
    ),
    "slices_link_root_path": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "SLICES",
    ),
    "slices_link_collection_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "SLICES",
        "sample_0001_phase_xy_00001.tiff",
    ),
    "slices_link_root_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "SLICES",
        "sample_0001_phase_xy_00001.tiff",
    ),
    "volumes_link_collection_path": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "VOLUMES",
    ),
    "volumes_link_root_path": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "VOLUMES",
    ),
    "volumes_link_collection_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "VOLUMES",
        "sample_0001_phase_16Bit_vol",
    ),
    "volumes_link_root_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "VOLUMES",
        "sample_0001_phase_16Bit_vol",
    ),
    "volumes_link_collection_slice_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "sample",
        "VOLUMES",
        "sample_0001_phase_16Bit_vol",
        "sample_0001_00001.vol",
    ),
    "volumes_link_root_slice_file": make_path(
        "visitor",
        "hg123",
        "id00",
        "20251201",
        "PROCESSED_DATA",
        "VOLUMES",
        "sample_0001_phase_16Bit_vol",
        "sample_0001_00001.vol",
    ),
}

_PATH_VALUES = {
    "unknown_v1": _PATH_VALUES_UNKNOWN_V1,
    "esrf_v1": _PATH_VALUES_ESRF_V1,
    "esrf_v2": _PATH_VALUES_ESRF_V2,
    "esrf_v3": _PATH_VALUES_ESRF_V3,
    "tomo_v1": _PATH_VALUES_TOMO_V1,
}


@pytest.mark.parametrize(
    "name,version",
    [
        (name, version)
        for name, versions in load._ALL_VERSIONS.items()
        for version in versions
    ],
)
def test_path_templates(name, version):
    schema = load.get_schema(name, version)
    key = str(schema.identifier)
    if key not in _PATH_VALUES:
        raise RuntimeError(f"Schema {key!r} does not have test values")
    paths = _PATH_VALUES[key]

    for tname, template in schema.templates.items():
        if tname not in paths:
            raise RuntimeError(
                f"Template {tname!r} does not have a test value for schema '{schema.identifier}'"
            )
        path = paths[tname]

        # Round-trip
        concept_values = template.parse(path)
        path2 = template.render(concept_values)
        assert path == path2, tname
