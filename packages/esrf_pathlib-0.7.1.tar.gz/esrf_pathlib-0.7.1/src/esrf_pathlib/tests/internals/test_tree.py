from ..._schemas.fields.tree import PathTemplateArguments
from ..._schemas.fields.tree import SegmentTemplate
from ..._schemas.fields.tree import parse_template_tree
from ..._schemas.fields.tree import tree_as_strings

_STRING_TREE = """
{root}/{noname}/
 ├── {project}/
 │    └── {category}/
 │         ├── {name}.txt
 │         ├── metadata.json
 │         └── {dataset}/
 │              ├── images/
 │              │    └── {image_id}.png
 │              └── logs/
 │                   └── {log_name}.txt
 └── archive/ [*]
      └── {year}/
           └── {month}/
                └── {file_name}.zip
"""

_DICT_TREE = {
    ("{root}", "root_path"): {
        "{noname}": {
            ("{project}", "project_path"): {
                ("{category}", "category_path"): {
                    ("{name}.txt", "text_file_path"): None,
                    ("metadata.json", "metadata_file_path"): None,
                    ("{dataset}", "dataset_path"): {
                        ("images", "images_path"): {
                            ("{image_id}.png", "image_file_path"): None,
                        },
                        ("logs", "logs_path"): {
                            ("{log_name}.txt", "log_file_path"): None,
                        },
                    },
                },
            },
            ("archive", "archive_path", False): {
                ("{year}", "year_path"): {
                    ("{month}", "month_path"): {
                        ("{file_name}.zip", "archive_file_path"): None,
                    },
                },
            },
        }
    }
}


def test_parse_template_tree():
    segments = parse_template_tree(_DICT_TREE)

    nodes = {
        "{root}": SegmentTemplate(template="{root}", mandatory=True),
        "{noname}": SegmentTemplate(template="{noname}", mandatory=True),
        "{project}": SegmentTemplate(template="{project}", mandatory=True),
        "{category}": SegmentTemplate(template="{category}", mandatory=True),
        "{name}.txt": SegmentTemplate(template="{name}.txt", mandatory=True),
        "metadata.json": SegmentTemplate(template="metadata.json", mandatory=True),
        "{dataset}": SegmentTemplate(template="{dataset}", mandatory=True),
        "images": SegmentTemplate(template="images", mandatory=True),
        "{image_id}.png": SegmentTemplate(template="{image_id}.png", mandatory=True),
        "logs": SegmentTemplate(template="logs", mandatory=True),
        "{log_name}.txt": SegmentTemplate(template="{log_name}.txt", mandatory=True),
        "archive": SegmentTemplate(template="archive", mandatory=False),
        "{year}": SegmentTemplate(template="{year}", mandatory=True),
        "{month}": SegmentTemplate(template="{month}", mandatory=True),
        "{file_name}.zip": SegmentTemplate(template="{file_name}.zip", mandatory=True),
    }

    expected = [
        PathTemplateArguments(name="root_path", segments=[nodes["{root}"]]),
        PathTemplateArguments(
            name="project_path",
            segments=[nodes["{root}"], nodes["{noname}"], nodes["{project}"]],
        ),
        PathTemplateArguments(
            name="category_path",
            segments=[
                nodes["{root}"],
                nodes["{noname}"],
                nodes["{project}"],
                nodes["{category}"],
            ],
        ),
        PathTemplateArguments(
            name="text_file_path",
            segments=[
                nodes["{root}"],
                nodes["{noname}"],
                nodes["{project}"],
                nodes["{category}"],
                nodes["{name}.txt"],
            ],
        ),
        PathTemplateArguments(
            name="metadata_file_path",
            segments=[
                nodes["{root}"],
                nodes["{noname}"],
                nodes["{project}"],
                nodes["{category}"],
                nodes["metadata.json"],
            ],
        ),
        PathTemplateArguments(
            name="dataset_path",
            segments=[
                nodes["{root}"],
                nodes["{noname}"],
                nodes["{project}"],
                nodes["{category}"],
                nodes["{dataset}"],
            ],
        ),
        PathTemplateArguments(
            name="images_path",
            segments=[
                nodes["{root}"],
                nodes["{noname}"],
                nodes["{project}"],
                nodes["{category}"],
                nodes["{dataset}"],
                nodes["images"],
            ],
        ),
        PathTemplateArguments(
            name="image_file_path",
            segments=[
                nodes["{root}"],
                nodes["{noname}"],
                nodes["{project}"],
                nodes["{category}"],
                nodes["{dataset}"],
                nodes["images"],
                nodes["{image_id}.png"],
            ],
        ),
        PathTemplateArguments(
            name="logs_path",
            segments=[
                nodes["{root}"],
                nodes["{noname}"],
                nodes["{project}"],
                nodes["{category}"],
                nodes["{dataset}"],
                nodes["logs"],
            ],
        ),
        PathTemplateArguments(
            name="log_file_path",
            segments=[
                nodes["{root}"],
                nodes["{noname}"],
                nodes["{project}"],
                nodes["{category}"],
                nodes["{dataset}"],
                nodes["logs"],
                nodes["{log_name}.txt"],
            ],
        ),
        PathTemplateArguments(
            name="archive_path",
            segments=[nodes["{root}"], nodes["{noname}"], nodes["archive"]],
        ),
        PathTemplateArguments(
            name="year_path",
            segments=[
                nodes["{root}"],
                nodes["{noname}"],
                nodes["archive"],
                nodes["{year}"],
            ],
        ),
        PathTemplateArguments(
            name="month_path",
            segments=[
                nodes["{root}"],
                nodes["{noname}"],
                nodes["archive"],
                nodes["{year}"],
                nodes["{month}"],
            ],
        ),
        PathTemplateArguments(
            name="archive_file_path",
            segments=[
                nodes["{root}"],
                nodes["{noname}"],
                nodes["archive"],
                nodes["{year}"],
                nodes["{month}"],
                nodes["{file_name}.zip"],
            ],
        ),
    ]
    assert segments == expected


def test_parse_template_tree_string():
    arguments = parse_template_tree(_DICT_TREE)
    lines = tree_as_strings([arg.segments for arg in arguments])
    text = "\n".join(lines)
    assert f"\n{text}\n" == _STRING_TREE


def test_parse_template_tree_single_branch():
    segments = [
        SegmentTemplate(template="{root}", mandatory=True),
        SegmentTemplate(template="archive", mandatory=False),
        SegmentTemplate(template="{year}", mandatory=True),
        SegmentTemplate(template="{month}", mandatory=True),
        SegmentTemplate(template="{file_name}.zip", mandatory=True),
    ]
    lines = tree_as_strings([segments])
    text = "\n".join(lines)

    expected = """
{root}/archive [*]/{year}/{month}/
 └── {file_name}.zip
"""
    assert f"\n{text}\n" == expected
