from .._schemas.constants import IS_WINDOWS
from ..core import ESRFPath
from .utils import make_path


class TomoPath(ESRFPath, tomo=1):
    pass


def test_replace_fields():
    path_in = make_path(
        "visitor",
        "ma1234",
        "id23eh1",
        "20250509",
        "RAW_DATA",
        "sample",
        "sample_dataset",
        "sample_dataset.h5",
    )
    expected_out = make_path(
        "visitor",
        "ma1234",
        "id23eh1",
        "20250509",
        "PROCESSED_DATA",
        "sample",
        "SLICES",
        "sample_dataset_absorption_xz_00001.tiff",
    )

    path = TomoPath(path_in)

    xz_slice_1 = path.replace_fields(
        data_type="processed",
        tomo_technique="absorption",
        tomo_type="denoised",
        tomo_slicing_direction="xz",
        tomo_slice_number=1,
        tomo_result_type="slice",
        tomo_extension="tiff",
    )

    assert str(xz_slice_1) == expected_out, xz_slice_1


def test_from_fields():
    if IS_WINDOWS:
        data_root = "X:\\visitor"
    else:
        data_root = None

    xz_slice_1 = ESRFPath.from_fields(
        data_root=data_root,
        schema_name="tomo",
        proposal="ma1234",
        beamline="id23eh1",
        session_date="20250509",
        data_type="processed",
        collection="sample",
        dataset="dataset",
        tomo_technique="absorption",
        tomo_type="denoised",
        tomo_slicing_direction="xz",
        tomo_slice_number=1,
        tomo_result_type="slice",
        tomo_extension="tiff",
    )

    expected_out = make_path(
        "visitor",
        "ma1234",
        "id23eh1",
        "20250509",
        "PROCESSED_DATA",
        "sample",
        "SLICES",
        "sample_dataset_absorption_xz_00001.tiff",
    )

    assert str(xz_slice_1) == expected_out, xz_slice_1
