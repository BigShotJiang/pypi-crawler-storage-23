"""Path schema system for matching, parsing and rendering ESRF filesystem paths.

A *schema registry* is the top-level API.
"""
