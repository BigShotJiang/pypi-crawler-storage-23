"""ESRF filesystem path schema definitions."""
