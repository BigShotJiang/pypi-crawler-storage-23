"""
Unknown Path Schema v1

Represents a placeholder for paths or path segments that are not yet known.

Path hierarchy::

    /
     └── {unknown_part}
"""

import os

from .. import constants
from ..schema.path import PathSchema

_ROOT_TREE = {
    (f"{{{constants.UNKNOWN_PART_NAME}}}", "unknown_path"): None,
}


def as_os_path(unknown_part: str) -> str:
    return unknown_part.replace("/", os.sep)


_CONCEPTS = {
    constants.UNKNOWN_PART_NAME: dict(
        description="Unknown path or path segment (placeholder for unmapped directories or files)",
        regex=r".+",
        score=0,
        deserializer=as_os_path,
        serializer=as_os_path,
    )
}


_SCHEMA = None


def get_schema() -> PathSchema:
    global _SCHEMA
    if _SCHEMA is None:
        _SCHEMA = PathSchema(
            name=constants.UNKNOWN_SCHEMA_NAME,
            version=1,
            description=__doc__,
            concepts=_CONCEPTS,
            template_tree=_ROOT_TREE,
        )
    return _SCHEMA
