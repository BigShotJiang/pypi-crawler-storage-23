import datetime
from enum import Enum
from typing import Union


class DataType(str, Enum):
    RAW = "raw"
    PROCESSED = "processed"
    NOBACKUP = "nobackup"
    SCRIPT = "script"
    GALLERY = "gallery"
    NOTE = "note"


class TomoResultType(str, Enum):
    SLICE = "slice"
    VOLUME = "volume"


ConceptValueType = Union[str, datetime.date, DataType, TomoResultType, None]
