from collections.abc import Hashable
from typing import Any
from typing import Union


class SchemaIdentifier(Hashable):
    """Identifier of a single schema or the merger of several schemas."""

    def __init__(self, **schema_versions: int) -> None:
        if not schema_versions:
            raise ValueError("At least one schema must be provided")
        self._schema_versions = schema_versions

        names = list(schema_versions)
        versions = list(schema_versions.values())
        full_names = [
            f"{sname}_v{sversion}" for sname, sversion in schema_versions.items()
        ]

        if len(names) == 1:
            self._name = names[0]
            self._version = versions[0]
            self._full_name = full_names[0]
        else:
            self._name = "+".join(names)
            self._version = 0
            self._full_name = "+".join(full_names)

        self._names = names
        self._full_names = full_names

        self._hash = hash(tuple(sorted(schema_versions.items())))

    def __hash__(self) -> int:
        return self._hash

    def __eq__(self, value: Any) -> bool:
        if isinstance(value, (str, SchemaIdentifier)):
            return str(self) == str(value)
        return super().__eq__(value)

    @property
    def name(self) -> str:
        return self._name

    @property
    def version(self) -> int:
        return self._version

    def __repr__(self) -> str:
        return f"<{type(self).__name__} {self._full_name!r}>"

    def __str__(self) -> str:
        return self._full_name

    def has_identifier(self, identifier: Union[str, "SchemaIdentifier"]) -> bool:
        return str(identifier) in self._full_names
