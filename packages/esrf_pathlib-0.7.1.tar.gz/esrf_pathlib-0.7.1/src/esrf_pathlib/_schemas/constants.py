import os
import sys

IS_WINDOWS = sys.platform == "win32"
DEFAULT_DATA_ROOT = None if IS_WINDOWS else os.path.join(os.sep, "data", "visitor")

UNKNOWN_SCHEMA_NAME = "unknown"
UNKNOWN_PART_NAME = "unknown_part"
