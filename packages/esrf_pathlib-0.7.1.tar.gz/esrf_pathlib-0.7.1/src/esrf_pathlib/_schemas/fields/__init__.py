"""Fields are components of an ESRF filesystem path schema.

- **Path concepts**: typed components extracted from paths.
- **Derived concepts**: computed from one or more path concepts.
- **Path templates**: patterns of concepts that describe a filesystem path.
"""
