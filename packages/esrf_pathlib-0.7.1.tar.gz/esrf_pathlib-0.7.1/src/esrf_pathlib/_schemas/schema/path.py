from typing import Any
from typing import Dict
from typing import List
from typing import Optional

from ..fields.concept import PathConcept
from ..fields.derived import DerivedConcept
from ..fields.path import PathTemplate
from ..fields.tree import SegmentTemplate
from ..fields.tree import parse_template_tree
from .base import BasePathSchema


class PathSchema(BasePathSchema):
    """A versioned collection of path concepts, derived concepts and path templates."""

    def __init__(
        self,
        name: str,
        version: int,
        description: str,
        concepts: Optional[Dict[str, Dict[str, Any]]] = None,
        derived_concepts: Optional[Dict[str, Dict[str, Any]]] = None,
        template_tree: Optional[Dict[str, str]] = None,
        extends: Optional[List["PathSchema"]] = None,
    ) -> None:
        """
        :raises FieldNameError:
        :raises PathSchemaCollision:
        """
        identifier = self._create_identifier(
            name=name, version=version, schemas=extends
        )
        super().__init__(identifier, description)

        for schema in extends or []:
            self._merge_fields_from(schema)

        for name, kwargs in (concepts or {}).items():
            concept = PathConcept(
                name=name, schema_identifier=self.identifier, **kwargs
            )
            self._add_field(concept)

        for name, kwargs in (derived_concepts or {}).items():
            derived = DerivedConcept(
                name=name, schema_identifier=self.identifier, **kwargs
            )
            self._add_field(derived)

        arguments = parse_template_tree(template_tree or {})
        all_path_segments: List[List[SegmentTemplate]] = []
        for args in arguments:
            all_path_segments.append(args.segments)
            template = PathTemplate(
                name=args.name,
                schema_identifier=self.identifier,
                segments=args.segments,
                concepts=self.concepts,
            )
            self._add_field(template)

        self._all_path_segments = all_path_segments
