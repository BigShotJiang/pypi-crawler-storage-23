from typing import List

from .base import BasePathSchema
from .path import PathSchema


class MergedPathSchema(BasePathSchema):
    """A collection of path concepts, derived concepts and path templates merged from different path schema's."""

    def __init__(self, schemas: List[PathSchema]):
        """
        :raises FieldNameError:
        :raises PathSchemaCollision:
        """
        identifier = self._create_identifier(schemas=schemas)
        super().__init__(identifier, "Merged schema")

        for schema in schemas:
            self._merge_fields_from(schema)

        self._all_path_segments = [
            lst for schema in schemas for lst in schema._all_path_segments
        ]
