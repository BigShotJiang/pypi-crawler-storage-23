"""An ESRF filesystem path schema is defined by several *path templates* describing a hierarchical
directory structure and *path concepts* that are the components that make up a template.

Schemas are used to match path strings, *parse* path strings (extract path concept values)
and *render* path strings from a dictionary of concepts (the inverse of parsing).
"""
