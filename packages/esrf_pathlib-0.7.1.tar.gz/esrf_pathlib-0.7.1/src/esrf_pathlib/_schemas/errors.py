class EsrfPathlibError(Exception):
    pass


class FieldNameError(EsrfPathlibError):
    """Field (concept or template) cannot be called this way."""


class ForbiddenFieldName(FieldNameError):
    """Field (concept or template) has a reserved name."""


class FieldNameCollision(FieldNameError):
    """Field (concept or template) already exists."""


class PathSchemaCollision(EsrfPathlibError):
    """Schema already exists."""


class UnknownPathConcept(EsrfPathlibError):
    """Path concept is not known."""


class PathConceptValueError(EsrfPathlibError):
    """Path concept is known but its value is not known."""


class PathConceptMatchError(PathConceptValueError):
    """Path concept is known but its value is wrong."""


class PathConceptWithoutValue(PathConceptValueError):
    """Path concept is known but its value is not known."""


class UnknownPathTemplate(EsrfPathlibError):
    """Path template is not known."""


class UnknownField(EsrfPathlibError):
    """Path field (concept or template) is not known."""


class UnknownPathSchema(EsrfPathlibError):
    """Schema is not known."""


class PathTemplateMatchError(EsrfPathlibError):
    """Path does not match a path template."""


class PathSchemaMatchError(PathTemplateMatchError):
    """Path does not match the schema. It did not match any of the enabled path templates."""


class SchemaAttributeError(AttributeError):
    pass
