import json
import setuptools

kwargs = json.loads(
    """
{
    "name": "cdktn-provider-newrelic",
    "version": "14.0.0",
    "description": "Prebuilt newrelic Provider for CDK Terrain (cdktn)",
    "license": "MPL-2.0",
    "url": "https://github.com/cdktn-io/cdktn-provider-newrelic.git",
    "long_description_content_type": "text/markdown",
    "author": "CDK Terrain Maintainers",
    "bdist_wheel": {
        "universal": true
    },
    "project_urls": {
        "Source": "https://github.com/cdktn-io/cdktn-provider-newrelic.git"
    },
    "package_dir": {
        "": "src"
    },
    "packages": [
        "cdktn_provider_newrelic",
        "cdktn_provider_newrelic._jsii",
        "cdktn_provider_newrelic.account_management",
        "cdktn_provider_newrelic.alert_channel",
        "cdktn_provider_newrelic.alert_compound_condition",
        "cdktn_provider_newrelic.alert_condition",
        "cdktn_provider_newrelic.alert_muting_rule",
        "cdktn_provider_newrelic.alert_policy",
        "cdktn_provider_newrelic.alert_policy_channel",
        "cdktn_provider_newrelic.api_access_key",
        "cdktn_provider_newrelic.application_settings",
        "cdktn_provider_newrelic.browser_application",
        "cdktn_provider_newrelic.cloud_aws_eu_sovereign_integrations",
        "cdktn_provider_newrelic.cloud_aws_eu_sovereign_link_account",
        "cdktn_provider_newrelic.cloud_aws_govcloud_integrations",
        "cdktn_provider_newrelic.cloud_aws_govcloud_link_account",
        "cdktn_provider_newrelic.cloud_aws_integrations",
        "cdktn_provider_newrelic.cloud_aws_link_account",
        "cdktn_provider_newrelic.cloud_azure_integrations",
        "cdktn_provider_newrelic.cloud_azure_link_account",
        "cdktn_provider_newrelic.cloud_gcp_integrations",
        "cdktn_provider_newrelic.cloud_gcp_link_account",
        "cdktn_provider_newrelic.cloud_oci_link_account",
        "cdktn_provider_newrelic.data_newrelic_account",
        "cdktn_provider_newrelic.data_newrelic_alert_channel",
        "cdktn_provider_newrelic.data_newrelic_alert_policy",
        "cdktn_provider_newrelic.data_newrelic_application",
        "cdktn_provider_newrelic.data_newrelic_authentication_domain",
        "cdktn_provider_newrelic.data_newrelic_cloud_account",
        "cdktn_provider_newrelic.data_newrelic_entity",
        "cdktn_provider_newrelic.data_newrelic_group",
        "cdktn_provider_newrelic.data_newrelic_key_transaction",
        "cdktn_provider_newrelic.data_newrelic_notification_destination",
        "cdktn_provider_newrelic.data_newrelic_obfuscation_expression",
        "cdktn_provider_newrelic.data_newrelic_service_level_alert_helper",
        "cdktn_provider_newrelic.data_newrelic_synthetics_private_location",
        "cdktn_provider_newrelic.data_newrelic_synthetics_secure_credential",
        "cdktn_provider_newrelic.data_newrelic_test_grok_pattern",
        "cdktn_provider_newrelic.data_newrelic_user",
        "cdktn_provider_newrelic.data_partition_rule",
        "cdktn_provider_newrelic.entity_tags",
        "cdktn_provider_newrelic.events_to_metrics_rule",
        "cdktn_provider_newrelic.group",
        "cdktn_provider_newrelic.infra_alert_condition",
        "cdktn_provider_newrelic.insights_event",
        "cdktn_provider_newrelic.key_transaction",
        "cdktn_provider_newrelic.log_parsing_rule",
        "cdktn_provider_newrelic.monitor_downtime",
        "cdktn_provider_newrelic.notification_channel",
        "cdktn_provider_newrelic.notification_destination",
        "cdktn_provider_newrelic.nrql_alert_condition",
        "cdktn_provider_newrelic.nrql_drop_rule",
        "cdktn_provider_newrelic.obfuscation_expression",
        "cdktn_provider_newrelic.obfuscation_rule",
        "cdktn_provider_newrelic.one_dashboard",
        "cdktn_provider_newrelic.one_dashboard_json",
        "cdktn_provider_newrelic.one_dashboard_raw",
        "cdktn_provider_newrelic.pipeline_cloud_rule",
        "cdktn_provider_newrelic.provider",
        "cdktn_provider_newrelic.service_level",
        "cdktn_provider_newrelic.synthetics_alert_condition",
        "cdktn_provider_newrelic.synthetics_broken_links_monitor",
        "cdktn_provider_newrelic.synthetics_cert_check_monitor",
        "cdktn_provider_newrelic.synthetics_monitor",
        "cdktn_provider_newrelic.synthetics_multilocation_alert_condition",
        "cdktn_provider_newrelic.synthetics_private_location",
        "cdktn_provider_newrelic.synthetics_script_monitor",
        "cdktn_provider_newrelic.synthetics_secure_credential",
        "cdktn_provider_newrelic.synthetics_step_monitor",
        "cdktn_provider_newrelic.user",
        "cdktn_provider_newrelic.workflow",
        "cdktn_provider_newrelic.workload"
    ],
    "package_data": {
        "cdktn_provider_newrelic._jsii": [
            "provider-newrelic@14.0.0.jsii.tgz"
        ],
        "cdktn_provider_newrelic": [
            "py.typed"
        ]
    },
    "python_requires": "~=3.9",
    "install_requires": [
        "cdktn>=0.22.0, <0.23.0",
        "constructs>=10.4.2, <11.0.0",
        "jsii>=1.119.0, <2.0.0",
        "publication>=0.0.3",
        "typeguard>=2.13.3,<4.3.0"
    ],
    "classifiers": [
        "Intended Audience :: Developers",
        "Operating System :: OS Independent",
        "Programming Language :: JavaScript",
        "Programming Language :: Python :: 3 :: Only",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Typing :: Typed",
        "Development Status :: 5 - Production/Stable",
        "License :: OSI Approved"
    ],
    "scripts": []
}
"""
)

with open("README.md", encoding="utf8") as fp:
    kwargs["long_description"] = fp.read()


setuptools.setup(**kwargs)
