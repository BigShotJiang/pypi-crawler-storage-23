r'''
# `newrelic_nrql_alert_condition`

Refer to the Terraform Registry for docs: [`newrelic_nrql_alert_condition`](https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition).
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import cdktn as _cdktn_78ede62e
import constructs as _constructs_77d1e7e8


class NrqlAlertCondition(
    _cdktn_78ede62e.TerraformResource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.nrqlAlertCondition.NrqlAlertCondition",
):
    '''Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition newrelic_nrql_alert_condition}.'''

    def __init__(
        self,
        scope: _constructs_77d1e7e8.Construct,
        id_: builtins.str,
        *,
        name: builtins.str,
        nrql: typing.Union["NrqlAlertConditionNrql", typing.Dict[builtins.str, typing.Any]],
        policy_id: jsii.Number,
        account_id: typing.Optional[jsii.Number] = None,
        aggregation_delay: typing.Optional[builtins.str] = None,
        aggregation_method: typing.Optional[builtins.str] = None,
        aggregation_timer: typing.Optional[builtins.str] = None,
        aggregation_window: typing.Optional[jsii.Number] = None,
        baseline_direction: typing.Optional[builtins.str] = None,
        close_violations_on_expiration: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        critical: typing.Optional[typing.Union["NrqlAlertConditionCritical", typing.Dict[builtins.str, typing.Any]]] = None,
        description: typing.Optional[builtins.str] = None,
        enabled: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        evaluation_delay: typing.Optional[jsii.Number] = None,
        expiration_duration: typing.Optional[jsii.Number] = None,
        fill_option: typing.Optional[builtins.str] = None,
        fill_value: typing.Optional[jsii.Number] = None,
        id: typing.Optional[builtins.str] = None,
        ignore_on_expected_termination: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        open_violation_on_expiration: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        outlier_configuration: typing.Optional[typing.Union["NrqlAlertConditionOutlierConfiguration", typing.Dict[builtins.str, typing.Any]]] = None,
        runbook_url: typing.Optional[builtins.str] = None,
        signal_seasonality: typing.Optional[builtins.str] = None,
        slide_by: typing.Optional[jsii.Number] = None,
        target_entity: typing.Optional[builtins.str] = None,
        term: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["NrqlAlertConditionTerm", typing.Dict[builtins.str, typing.Any]]]]] = None,
        timeouts: typing.Optional[typing.Union["NrqlAlertConditionTimeouts", typing.Dict[builtins.str, typing.Any]]] = None,
        title_template: typing.Optional[builtins.str] = None,
        type: typing.Optional[builtins.str] = None,
        violation_time_limit: typing.Optional[builtins.str] = None,
        violation_time_limit_seconds: typing.Optional[jsii.Number] = None,
        warning: typing.Optional[typing.Union["NrqlAlertConditionWarning", typing.Dict[builtins.str, typing.Any]]] = None,
        connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition newrelic_nrql_alert_condition} Resource.

        :param scope: The scope in which to define this construct.
        :param id_: The scoped construct ID. Must be unique amongst siblings in the same scope
        :param name: The title of the condition. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#name NrqlAlertCondition#name}
        :param nrql: nrql block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#nrql NrqlAlertCondition#nrql}
        :param policy_id: The ID of the policy where this condition should be used. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#policy_id NrqlAlertCondition#policy_id}
        :param account_id: The New Relic account ID for managing your NRQL alert conditions. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#account_id NrqlAlertCondition#account_id}
        :param aggregation_delay: How long we wait for data that belongs in each aggregation window. Depending on your data, a longer delay may increase accuracy but delay notifications. Use aggregationDelay with the EVENT_FLOW and CADENCE aggregation methods. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#aggregation_delay NrqlAlertCondition#aggregation_delay}
        :param aggregation_method: The method that determines when we consider an aggregation window to be complete so that we can evaluate the signal for incidents. Default is EVENT_FLOW. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#aggregation_method NrqlAlertCondition#aggregation_method}
        :param aggregation_timer: How long we wait after each data point arrives to make sure we've processed the whole batch. Use aggregationTimer with the EVENT_TIMER aggregation method. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#aggregation_timer NrqlAlertCondition#aggregation_timer}
        :param aggregation_window: The duration of the time window used to evaluate the NRQL query, in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#aggregation_window NrqlAlertCondition#aggregation_window}
        :param baseline_direction: The baseline direction of a baseline NRQL alert condition. Valid values are: 'LOWER_ONLY', 'UPPER_AND_LOWER', 'UPPER_ONLY' (case insensitive). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#baseline_direction NrqlAlertCondition#baseline_direction}
        :param close_violations_on_expiration: Whether to close all open incidents when the signal expires. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#close_violations_on_expiration NrqlAlertCondition#close_violations_on_expiration}
        :param critical: critical block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#critical NrqlAlertCondition#critical}
        :param description: The description of the NRQL alert condition. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#description NrqlAlertCondition#description}
        :param enabled: Whether or not to enable the alert condition. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#enabled NrqlAlertCondition#enabled}
        :param evaluation_delay: How long we wait until the signal starts evaluating. The maximum delay is 7200 seconds (120 minutes). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#evaluation_delay NrqlAlertCondition#evaluation_delay}
        :param expiration_duration: The amount of time (in seconds) to wait before considering the signal expired. Must be in the range of 30 to 172800 (inclusive) Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#expiration_duration NrqlAlertCondition#expiration_duration}
        :param fill_option: Which strategy to use when filling gaps in the signal. If static, the 'fill value' will be used for filling gaps in the signal. Valid values are: 'NONE', 'LAST_VALUE', or 'STATIC' (case insensitive). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#fill_option NrqlAlertCondition#fill_option}
        :param fill_value: If using the 'static' fill option, this value will be used for filling gaps in the signal. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#fill_value NrqlAlertCondition#fill_value}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#id NrqlAlertCondition#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param ignore_on_expected_termination: Whether to ignore expected termination of a signal when considering whether to create a loss of signal incident. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#ignore_on_expected_termination NrqlAlertCondition#ignore_on_expected_termination}
        :param open_violation_on_expiration: Whether to create a new incident to capture that the signal expired. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#open_violation_on_expiration NrqlAlertCondition#open_violation_on_expiration}
        :param outlier_configuration: outlier_configuration block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#outlier_configuration NrqlAlertCondition#outlier_configuration}
        :param runbook_url: Runbook URL to display in notifications. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#runbook_url NrqlAlertCondition#runbook_url}
        :param signal_seasonality: Seasonality under which a condition's signal(s) are evaluated. Valid values are: 'NEW_RELIC_CALCULATION', 'HOURLY', 'DAILY', 'WEEKLY', or 'NONE'. To have New Relic calculate seasonality automatically, set to 'NEW_RELIC_CALCULATION' (default). To turn off seasonality completely, set to 'NONE'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#signal_seasonality NrqlAlertCondition#signal_seasonality}
        :param slide_by: The duration of overlapping time windows used to smooth the chart line, in seconds. Must be a factor of ``aggregation_window`` and less than the aggregation window. If ``aggregation_window`` is less than or equal to 3600 seconds, it should be greater or equal to 30 seconds. If ``aggregation_window`` is greater than 3600 seconds but less than 7200 seconds, it should be greater or equal to ``aggregation_window / 120``. If ``aggregation_window`` is greater than 7200 seconds, it should be greater or equal to `aggregation_window / 24 Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#slide_by NrqlAlertCondition#slide_by}
        :param target_entity: BETA PREVIEW: the ``target_entity`` field is in limited release and only enabled for preview on a per-account basis. - The GUID of the entity explicitly targeted by the condition. Issues triggered by this condition will affect the health status of this entity instead of having the affected entity detected automatically Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#target_entity NrqlAlertCondition#target_entity}
        :param term: term block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#term NrqlAlertCondition#term}
        :param timeouts: timeouts block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#timeouts NrqlAlertCondition#timeouts}
        :param title_template: This field allows you to create a custom title to be used when incidents are opened by the condition. Setting this field will override the default title. Must be Handlebars format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#title_template NrqlAlertCondition#title_template}
        :param type: The type of NRQL alert condition to create. Valid values are: 'static', 'baseline', 'outlier'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#type NrqlAlertCondition#type}
        :param violation_time_limit: Sets a time limit, in hours, that will automatically force-close a long-lasting incident after the time limit you select. Possible values are 'ONE_HOUR', 'TWO_HOURS', 'FOUR_HOURS', 'EIGHT_HOURS', 'TWELVE_HOURS', 'TWENTY_FOUR_HOURS', 'THIRTY_DAYS' (case insensitive). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#violation_time_limit NrqlAlertCondition#violation_time_limit}
        :param violation_time_limit_seconds: Sets a time limit, in seconds, that will automatically force-close a long-lasting incident after the time limit you select. Must be in the range of 300 to 2592000 (inclusive) Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#violation_time_limit_seconds NrqlAlertCondition#violation_time_limit_seconds}
        :param warning: warning block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#warning NrqlAlertCondition#warning}
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__95a540cc8650063bf33e8fbdf7365f3313036931733ae93fb851494e75d27a97)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id_", value=id_, expected_type=type_hints["id_"])
        config = NrqlAlertConditionConfig(
            name=name,
            nrql=nrql,
            policy_id=policy_id,
            account_id=account_id,
            aggregation_delay=aggregation_delay,
            aggregation_method=aggregation_method,
            aggregation_timer=aggregation_timer,
            aggregation_window=aggregation_window,
            baseline_direction=baseline_direction,
            close_violations_on_expiration=close_violations_on_expiration,
            critical=critical,
            description=description,
            enabled=enabled,
            evaluation_delay=evaluation_delay,
            expiration_duration=expiration_duration,
            fill_option=fill_option,
            fill_value=fill_value,
            id=id,
            ignore_on_expected_termination=ignore_on_expected_termination,
            open_violation_on_expiration=open_violation_on_expiration,
            outlier_configuration=outlier_configuration,
            runbook_url=runbook_url,
            signal_seasonality=signal_seasonality,
            slide_by=slide_by,
            target_entity=target_entity,
            term=term,
            timeouts=timeouts,
            title_template=title_template,
            type=type,
            violation_time_limit=violation_time_limit,
            violation_time_limit_seconds=violation_time_limit_seconds,
            warning=warning,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        jsii.create(self.__class__, self, [scope, id_, config])

    @jsii.member(jsii_name="generateConfigForImport")
    @builtins.classmethod
    def generate_config_for_import(
        cls,
        scope: _constructs_77d1e7e8.Construct,
        import_to_id: builtins.str,
        import_from_id: builtins.str,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    ) -> _cdktn_78ede62e.ImportableResource:
        '''Generates CDKTN code for importing a NrqlAlertCondition resource upon running "cdktn plan ".

        :param scope: The scope in which to define this construct.
        :param import_to_id: The construct id used in the generated config for the NrqlAlertCondition to import.
        :param import_from_id: The id of the existing NrqlAlertCondition that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#import import section} in the documentation of this resource for the id to use
        :param provider: ? Optional instance of the provider where the NrqlAlertCondition to import is found.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ee490c911bdb19557d8e51372b4f7c3b877189bd409883ab742f34bec343bb2f)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument import_to_id", value=import_to_id, expected_type=type_hints["import_to_id"])
            check_type(argname="argument import_from_id", value=import_from_id, expected_type=type_hints["import_from_id"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
        return typing.cast(_cdktn_78ede62e.ImportableResource, jsii.sinvoke(cls, "generateConfigForImport", [scope, import_to_id, import_from_id, provider]))

    @jsii.member(jsii_name="putCritical")
    def put_critical(
        self,
        *,
        threshold: jsii.Number,
        disable_health_status_reporting: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        duration: typing.Optional[jsii.Number] = None,
        operator: typing.Optional[builtins.str] = None,
        prediction: typing.Optional[typing.Union["NrqlAlertConditionCriticalPrediction", typing.Dict[builtins.str, typing.Any]]] = None,
        threshold_duration: typing.Optional[jsii.Number] = None,
        threshold_occurrences: typing.Optional[builtins.str] = None,
        time_function: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param threshold: For baseline conditions must be in range [1, 1000]. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#threshold NrqlAlertCondition#threshold}
        :param disable_health_status_reporting: Violations will not change system health status for this term. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#disable_health_status_reporting NrqlAlertCondition#disable_health_status_reporting}
        :param duration: In minutes, must be in the range of 1 to 120 (inclusive). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#duration NrqlAlertCondition#duration}
        :param operator: One of (above, above_or_equals, below, below_or_equals, equals, not_equals). Defaults to 'equals'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#operator NrqlAlertCondition#operator}
        :param prediction: prediction block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#prediction NrqlAlertCondition#prediction}
        :param threshold_duration: The duration, in seconds, that the threshold must violate in order to create an incident. Value must be a multiple of the 'aggregation_window' (which has a default of 60 seconds). Value must be within 120-86400 seconds for baseline conditions, and within 60-86400 seconds for static conditions Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#threshold_duration NrqlAlertCondition#threshold_duration}
        :param threshold_occurrences: The criteria for how many data points must be in violation for the specified threshold duration. Valid values are: 'ALL' or 'AT_LEAST_ONCE' (case insensitive). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#threshold_occurrences NrqlAlertCondition#threshold_occurrences}
        :param time_function: Valid values are: 'all' or 'any'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#time_function NrqlAlertCondition#time_function}
        '''
        value = NrqlAlertConditionCritical(
            threshold=threshold,
            disable_health_status_reporting=disable_health_status_reporting,
            duration=duration,
            operator=operator,
            prediction=prediction,
            threshold_duration=threshold_duration,
            threshold_occurrences=threshold_occurrences,
            time_function=time_function,
        )

        return typing.cast(None, jsii.invoke(self, "putCritical", [value]))

    @jsii.member(jsii_name="putNrql")
    def put_nrql(
        self,
        *,
        query: builtins.str,
        data_account_id: typing.Optional[jsii.Number] = None,
        evaluation_offset: typing.Optional[jsii.Number] = None,
        since_value: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param query: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#query NrqlAlertCondition#query}.
        :param data_account_id: The New Relic account ID to use as the basis for the NRQL alert condition's ``query``; will default to ``account_id`` if unspecified. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#data_account_id NrqlAlertCondition#data_account_id}
        :param evaluation_offset: NRQL queries are evaluated in one-minute time windows. The start time depends on the value you provide in the NRQL condition's ``evaluation_offset``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#evaluation_offset NrqlAlertCondition#evaluation_offset}
        :param since_value: NRQL queries are evaluated in one-minute time windows. The start time depends on the value you provide in the NRQL condition's ``since_value``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#since_value NrqlAlertCondition#since_value}
        '''
        value = NrqlAlertConditionNrql(
            query=query,
            data_account_id=data_account_id,
            evaluation_offset=evaluation_offset,
            since_value=since_value,
        )

        return typing.cast(None, jsii.invoke(self, "putNrql", [value]))

    @jsii.member(jsii_name="putOutlierConfiguration")
    def put_outlier_configuration(
        self,
        *,
        dbscan: typing.Union["NrqlAlertConditionOutlierConfigurationDbscan", typing.Dict[builtins.str, typing.Any]],
    ) -> None:
        '''
        :param dbscan: dbscan block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#dbscan NrqlAlertCondition#dbscan}
        '''
        value = NrqlAlertConditionOutlierConfiguration(dbscan=dbscan)

        return typing.cast(None, jsii.invoke(self, "putOutlierConfiguration", [value]))

    @jsii.member(jsii_name="putTerm")
    def put_term(
        self,
        value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["NrqlAlertConditionTerm", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__20015e238bf0aec599a01ff19948eeac03262d48bcbd5023378933e0f334c980)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putTerm", [value]))

    @jsii.member(jsii_name="putTimeouts")
    def put_timeouts(self, *, create: typing.Optional[builtins.str] = None) -> None:
        '''
        :param create: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#create NrqlAlertCondition#create}.
        '''
        value = NrqlAlertConditionTimeouts(create=create)

        return typing.cast(None, jsii.invoke(self, "putTimeouts", [value]))

    @jsii.member(jsii_name="putWarning")
    def put_warning(
        self,
        *,
        threshold: jsii.Number,
        disable_health_status_reporting: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        duration: typing.Optional[jsii.Number] = None,
        operator: typing.Optional[builtins.str] = None,
        prediction: typing.Optional[typing.Union["NrqlAlertConditionWarningPrediction", typing.Dict[builtins.str, typing.Any]]] = None,
        threshold_duration: typing.Optional[jsii.Number] = None,
        threshold_occurrences: typing.Optional[builtins.str] = None,
        time_function: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param threshold: For baseline conditions must be in range [1, 1000]. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#threshold NrqlAlertCondition#threshold}
        :param disable_health_status_reporting: Violations will not change system health status for this term. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#disable_health_status_reporting NrqlAlertCondition#disable_health_status_reporting}
        :param duration: In minutes, must be in the range of 1 to 120 (inclusive). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#duration NrqlAlertCondition#duration}
        :param operator: One of (above, above_or_equals, below, below_or_equals, equals, not_equals). Defaults to 'equals'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#operator NrqlAlertCondition#operator}
        :param prediction: prediction block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#prediction NrqlAlertCondition#prediction}
        :param threshold_duration: The duration, in seconds, that the threshold must violate in order to create an incident. Value must be a multiple of the 'aggregation_window' (which has a default of 60 seconds). Value must be within 120-86400 seconds for baseline conditions, and within 60-86400 seconds for static conditions Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#threshold_duration NrqlAlertCondition#threshold_duration}
        :param threshold_occurrences: The criteria for how many data points must be in violation for the specified threshold duration. Valid values are: 'ALL' or 'AT_LEAST_ONCE' (case insensitive). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#threshold_occurrences NrqlAlertCondition#threshold_occurrences}
        :param time_function: Valid values are: 'all' or 'any'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#time_function NrqlAlertCondition#time_function}
        '''
        value = NrqlAlertConditionWarning(
            threshold=threshold,
            disable_health_status_reporting=disable_health_status_reporting,
            duration=duration,
            operator=operator,
            prediction=prediction,
            threshold_duration=threshold_duration,
            threshold_occurrences=threshold_occurrences,
            time_function=time_function,
        )

        return typing.cast(None, jsii.invoke(self, "putWarning", [value]))

    @jsii.member(jsii_name="resetAccountId")
    def reset_account_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAccountId", []))

    @jsii.member(jsii_name="resetAggregationDelay")
    def reset_aggregation_delay(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAggregationDelay", []))

    @jsii.member(jsii_name="resetAggregationMethod")
    def reset_aggregation_method(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAggregationMethod", []))

    @jsii.member(jsii_name="resetAggregationTimer")
    def reset_aggregation_timer(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAggregationTimer", []))

    @jsii.member(jsii_name="resetAggregationWindow")
    def reset_aggregation_window(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAggregationWindow", []))

    @jsii.member(jsii_name="resetBaselineDirection")
    def reset_baseline_direction(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetBaselineDirection", []))

    @jsii.member(jsii_name="resetCloseViolationsOnExpiration")
    def reset_close_violations_on_expiration(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCloseViolationsOnExpiration", []))

    @jsii.member(jsii_name="resetCritical")
    def reset_critical(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCritical", []))

    @jsii.member(jsii_name="resetDescription")
    def reset_description(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDescription", []))

    @jsii.member(jsii_name="resetEnabled")
    def reset_enabled(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEnabled", []))

    @jsii.member(jsii_name="resetEvaluationDelay")
    def reset_evaluation_delay(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEvaluationDelay", []))

    @jsii.member(jsii_name="resetExpirationDuration")
    def reset_expiration_duration(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetExpirationDuration", []))

    @jsii.member(jsii_name="resetFillOption")
    def reset_fill_option(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFillOption", []))

    @jsii.member(jsii_name="resetFillValue")
    def reset_fill_value(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFillValue", []))

    @jsii.member(jsii_name="resetId")
    def reset_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetId", []))

    @jsii.member(jsii_name="resetIgnoreOnExpectedTermination")
    def reset_ignore_on_expected_termination(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetIgnoreOnExpectedTermination", []))

    @jsii.member(jsii_name="resetOpenViolationOnExpiration")
    def reset_open_violation_on_expiration(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOpenViolationOnExpiration", []))

    @jsii.member(jsii_name="resetOutlierConfiguration")
    def reset_outlier_configuration(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOutlierConfiguration", []))

    @jsii.member(jsii_name="resetRunbookUrl")
    def reset_runbook_url(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRunbookUrl", []))

    @jsii.member(jsii_name="resetSignalSeasonality")
    def reset_signal_seasonality(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSignalSeasonality", []))

    @jsii.member(jsii_name="resetSlideBy")
    def reset_slide_by(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSlideBy", []))

    @jsii.member(jsii_name="resetTargetEntity")
    def reset_target_entity(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTargetEntity", []))

    @jsii.member(jsii_name="resetTerm")
    def reset_term(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTerm", []))

    @jsii.member(jsii_name="resetTimeouts")
    def reset_timeouts(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTimeouts", []))

    @jsii.member(jsii_name="resetTitleTemplate")
    def reset_title_template(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTitleTemplate", []))

    @jsii.member(jsii_name="resetType")
    def reset_type(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetType", []))

    @jsii.member(jsii_name="resetViolationTimeLimit")
    def reset_violation_time_limit(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetViolationTimeLimit", []))

    @jsii.member(jsii_name="resetViolationTimeLimitSeconds")
    def reset_violation_time_limit_seconds(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetViolationTimeLimitSeconds", []))

    @jsii.member(jsii_name="resetWarning")
    def reset_warning(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetWarning", []))

    @jsii.member(jsii_name="synthesizeAttributes")
    def _synthesize_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeAttributes", []))

    @jsii.member(jsii_name="synthesizeHclAttributes")
    def _synthesize_hcl_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeHclAttributes", []))

    @jsii.python.classproperty
    @jsii.member(jsii_name="tfResourceType")
    def TF_RESOURCE_TYPE(cls) -> builtins.str:
        return typing.cast(builtins.str, jsii.sget(cls, "tfResourceType"))

    @builtins.property
    @jsii.member(jsii_name="critical")
    def critical(self) -> "NrqlAlertConditionCriticalOutputReference":
        return typing.cast("NrqlAlertConditionCriticalOutputReference", jsii.get(self, "critical"))

    @builtins.property
    @jsii.member(jsii_name="entityGuid")
    def entity_guid(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "entityGuid"))

    @builtins.property
    @jsii.member(jsii_name="nrql")
    def nrql(self) -> "NrqlAlertConditionNrqlOutputReference":
        return typing.cast("NrqlAlertConditionNrqlOutputReference", jsii.get(self, "nrql"))

    @builtins.property
    @jsii.member(jsii_name="outlierConfiguration")
    def outlier_configuration(
        self,
    ) -> "NrqlAlertConditionOutlierConfigurationOutputReference":
        return typing.cast("NrqlAlertConditionOutlierConfigurationOutputReference", jsii.get(self, "outlierConfiguration"))

    @builtins.property
    @jsii.member(jsii_name="term")
    def term(self) -> "NrqlAlertConditionTermList":
        return typing.cast("NrqlAlertConditionTermList", jsii.get(self, "term"))

    @builtins.property
    @jsii.member(jsii_name="timeouts")
    def timeouts(self) -> "NrqlAlertConditionTimeoutsOutputReference":
        return typing.cast("NrqlAlertConditionTimeoutsOutputReference", jsii.get(self, "timeouts"))

    @builtins.property
    @jsii.member(jsii_name="warning")
    def warning(self) -> "NrqlAlertConditionWarningOutputReference":
        return typing.cast("NrqlAlertConditionWarningOutputReference", jsii.get(self, "warning"))

    @builtins.property
    @jsii.member(jsii_name="accountIdInput")
    def account_id_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "accountIdInput"))

    @builtins.property
    @jsii.member(jsii_name="aggregationDelayInput")
    def aggregation_delay_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "aggregationDelayInput"))

    @builtins.property
    @jsii.member(jsii_name="aggregationMethodInput")
    def aggregation_method_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "aggregationMethodInput"))

    @builtins.property
    @jsii.member(jsii_name="aggregationTimerInput")
    def aggregation_timer_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "aggregationTimerInput"))

    @builtins.property
    @jsii.member(jsii_name="aggregationWindowInput")
    def aggregation_window_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "aggregationWindowInput"))

    @builtins.property
    @jsii.member(jsii_name="baselineDirectionInput")
    def baseline_direction_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "baselineDirectionInput"))

    @builtins.property
    @jsii.member(jsii_name="closeViolationsOnExpirationInput")
    def close_violations_on_expiration_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "closeViolationsOnExpirationInput"))

    @builtins.property
    @jsii.member(jsii_name="criticalInput")
    def critical_input(self) -> typing.Optional["NrqlAlertConditionCritical"]:
        return typing.cast(typing.Optional["NrqlAlertConditionCritical"], jsii.get(self, "criticalInput"))

    @builtins.property
    @jsii.member(jsii_name="descriptionInput")
    def description_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "descriptionInput"))

    @builtins.property
    @jsii.member(jsii_name="enabledInput")
    def enabled_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "enabledInput"))

    @builtins.property
    @jsii.member(jsii_name="evaluationDelayInput")
    def evaluation_delay_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "evaluationDelayInput"))

    @builtins.property
    @jsii.member(jsii_name="expirationDurationInput")
    def expiration_duration_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "expirationDurationInput"))

    @builtins.property
    @jsii.member(jsii_name="fillOptionInput")
    def fill_option_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "fillOptionInput"))

    @builtins.property
    @jsii.member(jsii_name="fillValueInput")
    def fill_value_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "fillValueInput"))

    @builtins.property
    @jsii.member(jsii_name="idInput")
    def id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "idInput"))

    @builtins.property
    @jsii.member(jsii_name="ignoreOnExpectedTerminationInput")
    def ignore_on_expected_termination_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "ignoreOnExpectedTerminationInput"))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="nrqlInput")
    def nrql_input(self) -> typing.Optional["NrqlAlertConditionNrql"]:
        return typing.cast(typing.Optional["NrqlAlertConditionNrql"], jsii.get(self, "nrqlInput"))

    @builtins.property
    @jsii.member(jsii_name="openViolationOnExpirationInput")
    def open_violation_on_expiration_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "openViolationOnExpirationInput"))

    @builtins.property
    @jsii.member(jsii_name="outlierConfigurationInput")
    def outlier_configuration_input(
        self,
    ) -> typing.Optional["NrqlAlertConditionOutlierConfiguration"]:
        return typing.cast(typing.Optional["NrqlAlertConditionOutlierConfiguration"], jsii.get(self, "outlierConfigurationInput"))

    @builtins.property
    @jsii.member(jsii_name="policyIdInput")
    def policy_id_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "policyIdInput"))

    @builtins.property
    @jsii.member(jsii_name="runbookUrlInput")
    def runbook_url_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "runbookUrlInput"))

    @builtins.property
    @jsii.member(jsii_name="signalSeasonalityInput")
    def signal_seasonality_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "signalSeasonalityInput"))

    @builtins.property
    @jsii.member(jsii_name="slideByInput")
    def slide_by_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "slideByInput"))

    @builtins.property
    @jsii.member(jsii_name="targetEntityInput")
    def target_entity_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "targetEntityInput"))

    @builtins.property
    @jsii.member(jsii_name="termInput")
    def term_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["NrqlAlertConditionTerm"]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["NrqlAlertConditionTerm"]]], jsii.get(self, "termInput"))

    @builtins.property
    @jsii.member(jsii_name="timeoutsInput")
    def timeouts_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, "NrqlAlertConditionTimeouts"]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, "NrqlAlertConditionTimeouts"]], jsii.get(self, "timeoutsInput"))

    @builtins.property
    @jsii.member(jsii_name="titleTemplateInput")
    def title_template_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "titleTemplateInput"))

    @builtins.property
    @jsii.member(jsii_name="typeInput")
    def type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "typeInput"))

    @builtins.property
    @jsii.member(jsii_name="violationTimeLimitInput")
    def violation_time_limit_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "violationTimeLimitInput"))

    @builtins.property
    @jsii.member(jsii_name="violationTimeLimitSecondsInput")
    def violation_time_limit_seconds_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "violationTimeLimitSecondsInput"))

    @builtins.property
    @jsii.member(jsii_name="warningInput")
    def warning_input(self) -> typing.Optional["NrqlAlertConditionWarning"]:
        return typing.cast(typing.Optional["NrqlAlertConditionWarning"], jsii.get(self, "warningInput"))

    @builtins.property
    @jsii.member(jsii_name="accountId")
    def account_id(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "accountId"))

    @account_id.setter
    def account_id(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c3119da889de282307dfe9c24de24d09ea76e48cb691fd7e43d31c52dcf3e1ce)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "accountId", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="aggregationDelay")
    def aggregation_delay(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "aggregationDelay"))

    @aggregation_delay.setter
    def aggregation_delay(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__46e075e066ca0a472db69ce090d3f69302d39c8fd83a12c8ae3c8c0150732c0f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "aggregationDelay", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="aggregationMethod")
    def aggregation_method(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "aggregationMethod"))

    @aggregation_method.setter
    def aggregation_method(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a6a5786e008ac2a91694db025866dbbce076c910388c48d966f0fbf6552d1c92)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "aggregationMethod", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="aggregationTimer")
    def aggregation_timer(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "aggregationTimer"))

    @aggregation_timer.setter
    def aggregation_timer(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7a93660c8bbdc06cc635656ab37d6e0a808eef4995d667f92e8f1614c3675196)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "aggregationTimer", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="aggregationWindow")
    def aggregation_window(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "aggregationWindow"))

    @aggregation_window.setter
    def aggregation_window(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c5cfeddd94144ab8d140497786a2d46af69c4ca142a6acae649299d21fd1faef)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "aggregationWindow", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="baselineDirection")
    def baseline_direction(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "baselineDirection"))

    @baseline_direction.setter
    def baseline_direction(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__50c514d4847f6ad602b547ed66d519d27d3a0b8631454954dc94d3750826231b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "baselineDirection", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="closeViolationsOnExpiration")
    def close_violations_on_expiration(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "closeViolationsOnExpiration"))

    @close_violations_on_expiration.setter
    def close_violations_on_expiration(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1a73664c2e30e1e7814d312be8944b890d56c7b5052dfc1d5c189bd6cf3fdcca)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "closeViolationsOnExpiration", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="description")
    def description(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "description"))

    @description.setter
    def description(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fae3d7700f19fc6af2f9907696055116d5ff7254deb3d26d615e3399762a3a6b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "description", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="enabled")
    def enabled(self) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "enabled"))

    @enabled.setter
    def enabled(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__692fc4406773b62c40b30123379fcfc30304b583b89f80937b8bd769c0c7d74c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "enabled", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="evaluationDelay")
    def evaluation_delay(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "evaluationDelay"))

    @evaluation_delay.setter
    def evaluation_delay(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__566e267f68dcba7986fd53c41f3ee694c468774a7894be664edece1d0e4474bc)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "evaluationDelay", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="expirationDuration")
    def expiration_duration(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "expirationDuration"))

    @expiration_duration.setter
    def expiration_duration(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__94a1544c52a3883fc973b2eedec1e1bbef7dbf42bc7c624cfaf30b2caf7b325e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "expirationDuration", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="fillOption")
    def fill_option(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "fillOption"))

    @fill_option.setter
    def fill_option(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bf30755d24c53b95677388a1a18842142e7a763afa8164acee55381c0da3260e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "fillOption", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="fillValue")
    def fill_value(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "fillValue"))

    @fill_value.setter
    def fill_value(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__40b58d5b65aa0e1147bafc8c85334e9880cb894455864f7094f4eedc8c65f272)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "fillValue", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @id.setter
    def id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e23230b61248ee0315eb0540e9d89c43bd401f77cbd535ae0853dd662d352efe)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "id", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="ignoreOnExpectedTermination")
    def ignore_on_expected_termination(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "ignoreOnExpectedTermination"))

    @ignore_on_expected_termination.setter
    def ignore_on_expected_termination(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ccf34e43b47986261574a9afc3cac55a1ec5cbaa7de99df3db0eb111c87723ce)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "ignoreOnExpectedTermination", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__47fcee801258fdf7ddfc21f947405087befd2214d49c0a03387edbeaf53cfcbe)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="openViolationOnExpiration")
    def open_violation_on_expiration(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "openViolationOnExpiration"))

    @open_violation_on_expiration.setter
    def open_violation_on_expiration(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6c091cc9b75d08d3d0006324685cc8794314f4c3c06490b5bfe9780aa9ab1a90)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "openViolationOnExpiration", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="policyId")
    def policy_id(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "policyId"))

    @policy_id.setter
    def policy_id(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__69c1345e8901a0713c1918e3f5557110f3c50e736a5b5f26c48b4571ebfadf29)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "policyId", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="runbookUrl")
    def runbook_url(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "runbookUrl"))

    @runbook_url.setter
    def runbook_url(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__00839ba6176d59ddfb179a1e76a66950cee67cc230d14b287c8d750bdcf5e460)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "runbookUrl", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="signalSeasonality")
    def signal_seasonality(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "signalSeasonality"))

    @signal_seasonality.setter
    def signal_seasonality(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__333e02607190ad4f1abbdc86221a310c511c749377695d60d619392bdd355074)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "signalSeasonality", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="slideBy")
    def slide_by(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "slideBy"))

    @slide_by.setter
    def slide_by(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9c9518147346ebd876bd4ab19e759d0270c0f27a33b6839cda3bf3f8e783145b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "slideBy", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="targetEntity")
    def target_entity(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "targetEntity"))

    @target_entity.setter
    def target_entity(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__72c20bbf618e7d783265106ad43daa7b28359d9a2166d552c2de5e9bda2c2217)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "targetEntity", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="titleTemplate")
    def title_template(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "titleTemplate"))

    @title_template.setter
    def title_template(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5f76e9dd4e16b305c7a597c481c2cfe75ffe57dea47bb482bc1a5b6d3399cd93)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "titleTemplate", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @type.setter
    def type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1778d1eee226b845d8b2e6f68e971a582481baf3525f49bab520d9defd3a9bc3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "type", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="violationTimeLimit")
    def violation_time_limit(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "violationTimeLimit"))

    @violation_time_limit.setter
    def violation_time_limit(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__717c16f358cc0ab02342c0ae8a1f27daa3d7c03b8907ed681a5c4a62c513f26e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "violationTimeLimit", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="violationTimeLimitSeconds")
    def violation_time_limit_seconds(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "violationTimeLimitSeconds"))

    @violation_time_limit_seconds.setter
    def violation_time_limit_seconds(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__98a8803f319a230828e131932f5bd927ac603568d8da5aec87f7f03edce66b28)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "violationTimeLimitSeconds", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.nrqlAlertCondition.NrqlAlertConditionConfig",
    jsii_struct_bases=[_cdktn_78ede62e.TerraformMetaArguments],
    name_mapping={
        "connection": "connection",
        "count": "count",
        "depends_on": "dependsOn",
        "for_each": "forEach",
        "lifecycle": "lifecycle",
        "provider": "provider",
        "provisioners": "provisioners",
        "name": "name",
        "nrql": "nrql",
        "policy_id": "policyId",
        "account_id": "accountId",
        "aggregation_delay": "aggregationDelay",
        "aggregation_method": "aggregationMethod",
        "aggregation_timer": "aggregationTimer",
        "aggregation_window": "aggregationWindow",
        "baseline_direction": "baselineDirection",
        "close_violations_on_expiration": "closeViolationsOnExpiration",
        "critical": "critical",
        "description": "description",
        "enabled": "enabled",
        "evaluation_delay": "evaluationDelay",
        "expiration_duration": "expirationDuration",
        "fill_option": "fillOption",
        "fill_value": "fillValue",
        "id": "id",
        "ignore_on_expected_termination": "ignoreOnExpectedTermination",
        "open_violation_on_expiration": "openViolationOnExpiration",
        "outlier_configuration": "outlierConfiguration",
        "runbook_url": "runbookUrl",
        "signal_seasonality": "signalSeasonality",
        "slide_by": "slideBy",
        "target_entity": "targetEntity",
        "term": "term",
        "timeouts": "timeouts",
        "title_template": "titleTemplate",
        "type": "type",
        "violation_time_limit": "violationTimeLimit",
        "violation_time_limit_seconds": "violationTimeLimitSeconds",
        "warning": "warning",
    },
)
class NrqlAlertConditionConfig(_cdktn_78ede62e.TerraformMetaArguments):
    def __init__(
        self,
        *,
        connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
        name: builtins.str,
        nrql: typing.Union["NrqlAlertConditionNrql", typing.Dict[builtins.str, typing.Any]],
        policy_id: jsii.Number,
        account_id: typing.Optional[jsii.Number] = None,
        aggregation_delay: typing.Optional[builtins.str] = None,
        aggregation_method: typing.Optional[builtins.str] = None,
        aggregation_timer: typing.Optional[builtins.str] = None,
        aggregation_window: typing.Optional[jsii.Number] = None,
        baseline_direction: typing.Optional[builtins.str] = None,
        close_violations_on_expiration: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        critical: typing.Optional[typing.Union["NrqlAlertConditionCritical", typing.Dict[builtins.str, typing.Any]]] = None,
        description: typing.Optional[builtins.str] = None,
        enabled: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        evaluation_delay: typing.Optional[jsii.Number] = None,
        expiration_duration: typing.Optional[jsii.Number] = None,
        fill_option: typing.Optional[builtins.str] = None,
        fill_value: typing.Optional[jsii.Number] = None,
        id: typing.Optional[builtins.str] = None,
        ignore_on_expected_termination: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        open_violation_on_expiration: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        outlier_configuration: typing.Optional[typing.Union["NrqlAlertConditionOutlierConfiguration", typing.Dict[builtins.str, typing.Any]]] = None,
        runbook_url: typing.Optional[builtins.str] = None,
        signal_seasonality: typing.Optional[builtins.str] = None,
        slide_by: typing.Optional[jsii.Number] = None,
        target_entity: typing.Optional[builtins.str] = None,
        term: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["NrqlAlertConditionTerm", typing.Dict[builtins.str, typing.Any]]]]] = None,
        timeouts: typing.Optional[typing.Union["NrqlAlertConditionTimeouts", typing.Dict[builtins.str, typing.Any]]] = None,
        title_template: typing.Optional[builtins.str] = None,
        type: typing.Optional[builtins.str] = None,
        violation_time_limit: typing.Optional[builtins.str] = None,
        violation_time_limit_seconds: typing.Optional[jsii.Number] = None,
        warning: typing.Optional[typing.Union["NrqlAlertConditionWarning", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        :param name: The title of the condition. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#name NrqlAlertCondition#name}
        :param nrql: nrql block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#nrql NrqlAlertCondition#nrql}
        :param policy_id: The ID of the policy where this condition should be used. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#policy_id NrqlAlertCondition#policy_id}
        :param account_id: The New Relic account ID for managing your NRQL alert conditions. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#account_id NrqlAlertCondition#account_id}
        :param aggregation_delay: How long we wait for data that belongs in each aggregation window. Depending on your data, a longer delay may increase accuracy but delay notifications. Use aggregationDelay with the EVENT_FLOW and CADENCE aggregation methods. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#aggregation_delay NrqlAlertCondition#aggregation_delay}
        :param aggregation_method: The method that determines when we consider an aggregation window to be complete so that we can evaluate the signal for incidents. Default is EVENT_FLOW. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#aggregation_method NrqlAlertCondition#aggregation_method}
        :param aggregation_timer: How long we wait after each data point arrives to make sure we've processed the whole batch. Use aggregationTimer with the EVENT_TIMER aggregation method. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#aggregation_timer NrqlAlertCondition#aggregation_timer}
        :param aggregation_window: The duration of the time window used to evaluate the NRQL query, in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#aggregation_window NrqlAlertCondition#aggregation_window}
        :param baseline_direction: The baseline direction of a baseline NRQL alert condition. Valid values are: 'LOWER_ONLY', 'UPPER_AND_LOWER', 'UPPER_ONLY' (case insensitive). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#baseline_direction NrqlAlertCondition#baseline_direction}
        :param close_violations_on_expiration: Whether to close all open incidents when the signal expires. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#close_violations_on_expiration NrqlAlertCondition#close_violations_on_expiration}
        :param critical: critical block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#critical NrqlAlertCondition#critical}
        :param description: The description of the NRQL alert condition. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#description NrqlAlertCondition#description}
        :param enabled: Whether or not to enable the alert condition. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#enabled NrqlAlertCondition#enabled}
        :param evaluation_delay: How long we wait until the signal starts evaluating. The maximum delay is 7200 seconds (120 minutes). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#evaluation_delay NrqlAlertCondition#evaluation_delay}
        :param expiration_duration: The amount of time (in seconds) to wait before considering the signal expired. Must be in the range of 30 to 172800 (inclusive) Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#expiration_duration NrqlAlertCondition#expiration_duration}
        :param fill_option: Which strategy to use when filling gaps in the signal. If static, the 'fill value' will be used for filling gaps in the signal. Valid values are: 'NONE', 'LAST_VALUE', or 'STATIC' (case insensitive). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#fill_option NrqlAlertCondition#fill_option}
        :param fill_value: If using the 'static' fill option, this value will be used for filling gaps in the signal. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#fill_value NrqlAlertCondition#fill_value}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#id NrqlAlertCondition#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param ignore_on_expected_termination: Whether to ignore expected termination of a signal when considering whether to create a loss of signal incident. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#ignore_on_expected_termination NrqlAlertCondition#ignore_on_expected_termination}
        :param open_violation_on_expiration: Whether to create a new incident to capture that the signal expired. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#open_violation_on_expiration NrqlAlertCondition#open_violation_on_expiration}
        :param outlier_configuration: outlier_configuration block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#outlier_configuration NrqlAlertCondition#outlier_configuration}
        :param runbook_url: Runbook URL to display in notifications. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#runbook_url NrqlAlertCondition#runbook_url}
        :param signal_seasonality: Seasonality under which a condition's signal(s) are evaluated. Valid values are: 'NEW_RELIC_CALCULATION', 'HOURLY', 'DAILY', 'WEEKLY', or 'NONE'. To have New Relic calculate seasonality automatically, set to 'NEW_RELIC_CALCULATION' (default). To turn off seasonality completely, set to 'NONE'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#signal_seasonality NrqlAlertCondition#signal_seasonality}
        :param slide_by: The duration of overlapping time windows used to smooth the chart line, in seconds. Must be a factor of ``aggregation_window`` and less than the aggregation window. If ``aggregation_window`` is less than or equal to 3600 seconds, it should be greater or equal to 30 seconds. If ``aggregation_window`` is greater than 3600 seconds but less than 7200 seconds, it should be greater or equal to ``aggregation_window / 120``. If ``aggregation_window`` is greater than 7200 seconds, it should be greater or equal to `aggregation_window / 24 Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#slide_by NrqlAlertCondition#slide_by}
        :param target_entity: BETA PREVIEW: the ``target_entity`` field is in limited release and only enabled for preview on a per-account basis. - The GUID of the entity explicitly targeted by the condition. Issues triggered by this condition will affect the health status of this entity instead of having the affected entity detected automatically Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#target_entity NrqlAlertCondition#target_entity}
        :param term: term block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#term NrqlAlertCondition#term}
        :param timeouts: timeouts block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#timeouts NrqlAlertCondition#timeouts}
        :param title_template: This field allows you to create a custom title to be used when incidents are opened by the condition. Setting this field will override the default title. Must be Handlebars format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#title_template NrqlAlertCondition#title_template}
        :param type: The type of NRQL alert condition to create. Valid values are: 'static', 'baseline', 'outlier'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#type NrqlAlertCondition#type}
        :param violation_time_limit: Sets a time limit, in hours, that will automatically force-close a long-lasting incident after the time limit you select. Possible values are 'ONE_HOUR', 'TWO_HOURS', 'FOUR_HOURS', 'EIGHT_HOURS', 'TWELVE_HOURS', 'TWENTY_FOUR_HOURS', 'THIRTY_DAYS' (case insensitive). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#violation_time_limit NrqlAlertCondition#violation_time_limit}
        :param violation_time_limit_seconds: Sets a time limit, in seconds, that will automatically force-close a long-lasting incident after the time limit you select. Must be in the range of 300 to 2592000 (inclusive) Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#violation_time_limit_seconds NrqlAlertCondition#violation_time_limit_seconds}
        :param warning: warning block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#warning NrqlAlertCondition#warning}
        '''
        if isinstance(lifecycle, dict):
            lifecycle = _cdktn_78ede62e.TerraformResourceLifecycle(**lifecycle)
        if isinstance(nrql, dict):
            nrql = NrqlAlertConditionNrql(**nrql)
        if isinstance(critical, dict):
            critical = NrqlAlertConditionCritical(**critical)
        if isinstance(outlier_configuration, dict):
            outlier_configuration = NrqlAlertConditionOutlierConfiguration(**outlier_configuration)
        if isinstance(timeouts, dict):
            timeouts = NrqlAlertConditionTimeouts(**timeouts)
        if isinstance(warning, dict):
            warning = NrqlAlertConditionWarning(**warning)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5ee4631d5b004ecf5bd1c30fef10ef7a523ee9df5944b277717ce44f1015cdea)
            check_type(argname="argument connection", value=connection, expected_type=type_hints["connection"])
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument for_each", value=for_each, expected_type=type_hints["for_each"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
            check_type(argname="argument provisioners", value=provisioners, expected_type=type_hints["provisioners"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument nrql", value=nrql, expected_type=type_hints["nrql"])
            check_type(argname="argument policy_id", value=policy_id, expected_type=type_hints["policy_id"])
            check_type(argname="argument account_id", value=account_id, expected_type=type_hints["account_id"])
            check_type(argname="argument aggregation_delay", value=aggregation_delay, expected_type=type_hints["aggregation_delay"])
            check_type(argname="argument aggregation_method", value=aggregation_method, expected_type=type_hints["aggregation_method"])
            check_type(argname="argument aggregation_timer", value=aggregation_timer, expected_type=type_hints["aggregation_timer"])
            check_type(argname="argument aggregation_window", value=aggregation_window, expected_type=type_hints["aggregation_window"])
            check_type(argname="argument baseline_direction", value=baseline_direction, expected_type=type_hints["baseline_direction"])
            check_type(argname="argument close_violations_on_expiration", value=close_violations_on_expiration, expected_type=type_hints["close_violations_on_expiration"])
            check_type(argname="argument critical", value=critical, expected_type=type_hints["critical"])
            check_type(argname="argument description", value=description, expected_type=type_hints["description"])
            check_type(argname="argument enabled", value=enabled, expected_type=type_hints["enabled"])
            check_type(argname="argument evaluation_delay", value=evaluation_delay, expected_type=type_hints["evaluation_delay"])
            check_type(argname="argument expiration_duration", value=expiration_duration, expected_type=type_hints["expiration_duration"])
            check_type(argname="argument fill_option", value=fill_option, expected_type=type_hints["fill_option"])
            check_type(argname="argument fill_value", value=fill_value, expected_type=type_hints["fill_value"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
            check_type(argname="argument ignore_on_expected_termination", value=ignore_on_expected_termination, expected_type=type_hints["ignore_on_expected_termination"])
            check_type(argname="argument open_violation_on_expiration", value=open_violation_on_expiration, expected_type=type_hints["open_violation_on_expiration"])
            check_type(argname="argument outlier_configuration", value=outlier_configuration, expected_type=type_hints["outlier_configuration"])
            check_type(argname="argument runbook_url", value=runbook_url, expected_type=type_hints["runbook_url"])
            check_type(argname="argument signal_seasonality", value=signal_seasonality, expected_type=type_hints["signal_seasonality"])
            check_type(argname="argument slide_by", value=slide_by, expected_type=type_hints["slide_by"])
            check_type(argname="argument target_entity", value=target_entity, expected_type=type_hints["target_entity"])
            check_type(argname="argument term", value=term, expected_type=type_hints["term"])
            check_type(argname="argument timeouts", value=timeouts, expected_type=type_hints["timeouts"])
            check_type(argname="argument title_template", value=title_template, expected_type=type_hints["title_template"])
            check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            check_type(argname="argument violation_time_limit", value=violation_time_limit, expected_type=type_hints["violation_time_limit"])
            check_type(argname="argument violation_time_limit_seconds", value=violation_time_limit_seconds, expected_type=type_hints["violation_time_limit_seconds"])
            check_type(argname="argument warning", value=warning, expected_type=type_hints["warning"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "name": name,
            "nrql": nrql,
            "policy_id": policy_id,
        }
        if connection is not None:
            self._values["connection"] = connection
        if count is not None:
            self._values["count"] = count
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if for_each is not None:
            self._values["for_each"] = for_each
        if lifecycle is not None:
            self._values["lifecycle"] = lifecycle
        if provider is not None:
            self._values["provider"] = provider
        if provisioners is not None:
            self._values["provisioners"] = provisioners
        if account_id is not None:
            self._values["account_id"] = account_id
        if aggregation_delay is not None:
            self._values["aggregation_delay"] = aggregation_delay
        if aggregation_method is not None:
            self._values["aggregation_method"] = aggregation_method
        if aggregation_timer is not None:
            self._values["aggregation_timer"] = aggregation_timer
        if aggregation_window is not None:
            self._values["aggregation_window"] = aggregation_window
        if baseline_direction is not None:
            self._values["baseline_direction"] = baseline_direction
        if close_violations_on_expiration is not None:
            self._values["close_violations_on_expiration"] = close_violations_on_expiration
        if critical is not None:
            self._values["critical"] = critical
        if description is not None:
            self._values["description"] = description
        if enabled is not None:
            self._values["enabled"] = enabled
        if evaluation_delay is not None:
            self._values["evaluation_delay"] = evaluation_delay
        if expiration_duration is not None:
            self._values["expiration_duration"] = expiration_duration
        if fill_option is not None:
            self._values["fill_option"] = fill_option
        if fill_value is not None:
            self._values["fill_value"] = fill_value
        if id is not None:
            self._values["id"] = id
        if ignore_on_expected_termination is not None:
            self._values["ignore_on_expected_termination"] = ignore_on_expected_termination
        if open_violation_on_expiration is not None:
            self._values["open_violation_on_expiration"] = open_violation_on_expiration
        if outlier_configuration is not None:
            self._values["outlier_configuration"] = outlier_configuration
        if runbook_url is not None:
            self._values["runbook_url"] = runbook_url
        if signal_seasonality is not None:
            self._values["signal_seasonality"] = signal_seasonality
        if slide_by is not None:
            self._values["slide_by"] = slide_by
        if target_entity is not None:
            self._values["target_entity"] = target_entity
        if term is not None:
            self._values["term"] = term
        if timeouts is not None:
            self._values["timeouts"] = timeouts
        if title_template is not None:
            self._values["title_template"] = title_template
        if type is not None:
            self._values["type"] = type
        if violation_time_limit is not None:
            self._values["violation_time_limit"] = violation_time_limit
        if violation_time_limit_seconds is not None:
            self._values["violation_time_limit_seconds"] = violation_time_limit_seconds
        if warning is not None:
            self._values["warning"] = warning

    @builtins.property
    def connection(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, _cdktn_78ede62e.WinrmProvisionerConnection]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("connection")
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, _cdktn_78ede62e.WinrmProvisionerConnection]], result)

    @builtins.property
    def count(
        self,
    ) -> typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("count")
        return typing.cast(typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]], result)

    @builtins.property
    def depends_on(
        self,
    ) -> typing.Optional[typing.List[_cdktn_78ede62e.ITerraformDependable]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List[_cdktn_78ede62e.ITerraformDependable]], result)

    @builtins.property
    def for_each(self) -> typing.Optional[_cdktn_78ede62e.ITerraformIterator]:
        '''
        :stability: experimental
        '''
        result = self._values.get("for_each")
        return typing.cast(typing.Optional[_cdktn_78ede62e.ITerraformIterator], result)

    @builtins.property
    def lifecycle(self) -> typing.Optional[_cdktn_78ede62e.TerraformResourceLifecycle]:
        '''
        :stability: experimental
        '''
        result = self._values.get("lifecycle")
        return typing.cast(typing.Optional[_cdktn_78ede62e.TerraformResourceLifecycle], result)

    @builtins.property
    def provider(self) -> typing.Optional[_cdktn_78ede62e.TerraformProvider]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provider")
        return typing.cast(typing.Optional[_cdktn_78ede62e.TerraformProvider], result)

    @builtins.property
    def provisioners(
        self,
    ) -> typing.Optional[typing.List[typing.Union[_cdktn_78ede62e.FileProvisioner, _cdktn_78ede62e.LocalExecProvisioner, _cdktn_78ede62e.RemoteExecProvisioner]]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provisioners")
        return typing.cast(typing.Optional[typing.List[typing.Union[_cdktn_78ede62e.FileProvisioner, _cdktn_78ede62e.LocalExecProvisioner, _cdktn_78ede62e.RemoteExecProvisioner]]], result)

    @builtins.property
    def name(self) -> builtins.str:
        '''The title of the condition.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#name NrqlAlertCondition#name}
        '''
        result = self._values.get("name")
        assert result is not None, "Required property 'name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def nrql(self) -> "NrqlAlertConditionNrql":
        '''nrql block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#nrql NrqlAlertCondition#nrql}
        '''
        result = self._values.get("nrql")
        assert result is not None, "Required property 'nrql' is missing"
        return typing.cast("NrqlAlertConditionNrql", result)

    @builtins.property
    def policy_id(self) -> jsii.Number:
        '''The ID of the policy where this condition should be used.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#policy_id NrqlAlertCondition#policy_id}
        '''
        result = self._values.get("policy_id")
        assert result is not None, "Required property 'policy_id' is missing"
        return typing.cast(jsii.Number, result)

    @builtins.property
    def account_id(self) -> typing.Optional[jsii.Number]:
        '''The New Relic account ID for managing your NRQL alert conditions.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#account_id NrqlAlertCondition#account_id}
        '''
        result = self._values.get("account_id")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def aggregation_delay(self) -> typing.Optional[builtins.str]:
        '''How long we wait for data that belongs in each aggregation window.

        Depending on your data, a longer delay may increase accuracy but delay notifications. Use aggregationDelay with the EVENT_FLOW and CADENCE aggregation methods.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#aggregation_delay NrqlAlertCondition#aggregation_delay}
        '''
        result = self._values.get("aggregation_delay")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def aggregation_method(self) -> typing.Optional[builtins.str]:
        '''The method that determines when we consider an aggregation window to be complete so that we can evaluate the signal for incidents.

        Default is EVENT_FLOW.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#aggregation_method NrqlAlertCondition#aggregation_method}
        '''
        result = self._values.get("aggregation_method")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def aggregation_timer(self) -> typing.Optional[builtins.str]:
        '''How long we wait after each data point arrives to make sure we've processed the whole batch.

        Use aggregationTimer with the EVENT_TIMER aggregation method.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#aggregation_timer NrqlAlertCondition#aggregation_timer}
        '''
        result = self._values.get("aggregation_timer")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def aggregation_window(self) -> typing.Optional[jsii.Number]:
        '''The duration of the time window used to evaluate the NRQL query, in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#aggregation_window NrqlAlertCondition#aggregation_window}
        '''
        result = self._values.get("aggregation_window")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def baseline_direction(self) -> typing.Optional[builtins.str]:
        '''The baseline direction of a baseline NRQL alert condition. Valid values are: 'LOWER_ONLY', 'UPPER_AND_LOWER', 'UPPER_ONLY' (case insensitive).

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#baseline_direction NrqlAlertCondition#baseline_direction}
        '''
        result = self._values.get("baseline_direction")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def close_violations_on_expiration(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Whether to close all open incidents when the signal expires.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#close_violations_on_expiration NrqlAlertCondition#close_violations_on_expiration}
        '''
        result = self._values.get("close_violations_on_expiration")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def critical(self) -> typing.Optional["NrqlAlertConditionCritical"]:
        '''critical block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#critical NrqlAlertCondition#critical}
        '''
        result = self._values.get("critical")
        return typing.cast(typing.Optional["NrqlAlertConditionCritical"], result)

    @builtins.property
    def description(self) -> typing.Optional[builtins.str]:
        '''The description of the NRQL alert condition.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#description NrqlAlertCondition#description}
        '''
        result = self._values.get("description")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def enabled(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Whether or not to enable the alert condition.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#enabled NrqlAlertCondition#enabled}
        '''
        result = self._values.get("enabled")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def evaluation_delay(self) -> typing.Optional[jsii.Number]:
        '''How long we wait until the signal starts evaluating. The maximum delay is 7200 seconds (120 minutes).

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#evaluation_delay NrqlAlertCondition#evaluation_delay}
        '''
        result = self._values.get("evaluation_delay")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def expiration_duration(self) -> typing.Optional[jsii.Number]:
        '''The amount of time (in seconds) to wait before considering the signal expired.

        Must be in the range of 30 to 172800 (inclusive)

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#expiration_duration NrqlAlertCondition#expiration_duration}
        '''
        result = self._values.get("expiration_duration")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def fill_option(self) -> typing.Optional[builtins.str]:
        '''Which strategy to use when filling gaps in the signal.

        If static, the 'fill value' will be used for filling gaps in the signal. Valid values are: 'NONE', 'LAST_VALUE', or 'STATIC' (case insensitive).

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#fill_option NrqlAlertCondition#fill_option}
        '''
        result = self._values.get("fill_option")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def fill_value(self) -> typing.Optional[jsii.Number]:
        '''If using the 'static' fill option, this value will be used for filling gaps in the signal.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#fill_value NrqlAlertCondition#fill_value}
        '''
        result = self._values.get("fill_value")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def id(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#id NrqlAlertCondition#id}.

        Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        '''
        result = self._values.get("id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def ignore_on_expected_termination(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Whether to ignore expected termination of a signal when considering whether to create a loss of signal incident.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#ignore_on_expected_termination NrqlAlertCondition#ignore_on_expected_termination}
        '''
        result = self._values.get("ignore_on_expected_termination")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def open_violation_on_expiration(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Whether to create a new incident to capture that the signal expired.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#open_violation_on_expiration NrqlAlertCondition#open_violation_on_expiration}
        '''
        result = self._values.get("open_violation_on_expiration")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def outlier_configuration(
        self,
    ) -> typing.Optional["NrqlAlertConditionOutlierConfiguration"]:
        '''outlier_configuration block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#outlier_configuration NrqlAlertCondition#outlier_configuration}
        '''
        result = self._values.get("outlier_configuration")
        return typing.cast(typing.Optional["NrqlAlertConditionOutlierConfiguration"], result)

    @builtins.property
    def runbook_url(self) -> typing.Optional[builtins.str]:
        '''Runbook URL to display in notifications.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#runbook_url NrqlAlertCondition#runbook_url}
        '''
        result = self._values.get("runbook_url")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def signal_seasonality(self) -> typing.Optional[builtins.str]:
        '''Seasonality under which a condition's signal(s) are evaluated.

        Valid values are: 'NEW_RELIC_CALCULATION', 'HOURLY', 'DAILY', 'WEEKLY', or 'NONE'. To have New Relic calculate seasonality automatically, set to 'NEW_RELIC_CALCULATION' (default). To turn off seasonality completely, set to 'NONE'.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#signal_seasonality NrqlAlertCondition#signal_seasonality}
        '''
        result = self._values.get("signal_seasonality")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def slide_by(self) -> typing.Optional[jsii.Number]:
        '''The duration of overlapping time windows used to smooth the chart line, in seconds.

        Must be a factor of ``aggregation_window`` and less than the aggregation window. If ``aggregation_window`` is less than or equal to 3600 seconds, it should be greater or equal to 30 seconds. If ``aggregation_window`` is greater than 3600 seconds but less than 7200 seconds, it should be greater or equal to ``aggregation_window / 120``.  If ``aggregation_window`` is greater than 7200 seconds, it should be greater or equal to `aggregation_window / 24

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#slide_by NrqlAlertCondition#slide_by}
        '''
        result = self._values.get("slide_by")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def target_entity(self) -> typing.Optional[builtins.str]:
        '''BETA PREVIEW: the ``target_entity`` field is in limited release and only enabled for preview on a per-account basis.

        - The GUID of the entity explicitly targeted by the condition. Issues triggered by this condition will affect the health status of this entity instead of having the affected entity detected automatically

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#target_entity NrqlAlertCondition#target_entity}
        '''
        result = self._values.get("target_entity")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def term(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["NrqlAlertConditionTerm"]]]:
        '''term block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#term NrqlAlertCondition#term}
        '''
        result = self._values.get("term")
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["NrqlAlertConditionTerm"]]], result)

    @builtins.property
    def timeouts(self) -> typing.Optional["NrqlAlertConditionTimeouts"]:
        '''timeouts block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#timeouts NrqlAlertCondition#timeouts}
        '''
        result = self._values.get("timeouts")
        return typing.cast(typing.Optional["NrqlAlertConditionTimeouts"], result)

    @builtins.property
    def title_template(self) -> typing.Optional[builtins.str]:
        '''This field allows you to create a custom title to be used when incidents are opened by the condition.

        Setting this field will override the default title. Must be Handlebars format.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#title_template NrqlAlertCondition#title_template}
        '''
        result = self._values.get("title_template")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def type(self) -> typing.Optional[builtins.str]:
        '''The type of NRQL alert condition to create. Valid values are: 'static', 'baseline', 'outlier'.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#type NrqlAlertCondition#type}
        '''
        result = self._values.get("type")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def violation_time_limit(self) -> typing.Optional[builtins.str]:
        '''Sets a time limit, in hours, that will automatically force-close a long-lasting incident after the time limit you select.

        Possible values are 'ONE_HOUR', 'TWO_HOURS', 'FOUR_HOURS', 'EIGHT_HOURS', 'TWELVE_HOURS', 'TWENTY_FOUR_HOURS', 'THIRTY_DAYS' (case insensitive).

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#violation_time_limit NrqlAlertCondition#violation_time_limit}
        '''
        result = self._values.get("violation_time_limit")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def violation_time_limit_seconds(self) -> typing.Optional[jsii.Number]:
        '''Sets a time limit, in seconds, that will automatically force-close a long-lasting incident after the time limit you select.

        Must be in the range of 300 to 2592000 (inclusive)

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#violation_time_limit_seconds NrqlAlertCondition#violation_time_limit_seconds}
        '''
        result = self._values.get("violation_time_limit_seconds")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def warning(self) -> typing.Optional["NrqlAlertConditionWarning"]:
        '''warning block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#warning NrqlAlertCondition#warning}
        '''
        result = self._values.get("warning")
        return typing.cast(typing.Optional["NrqlAlertConditionWarning"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "NrqlAlertConditionConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.nrqlAlertCondition.NrqlAlertConditionCritical",
    jsii_struct_bases=[],
    name_mapping={
        "threshold": "threshold",
        "disable_health_status_reporting": "disableHealthStatusReporting",
        "duration": "duration",
        "operator": "operator",
        "prediction": "prediction",
        "threshold_duration": "thresholdDuration",
        "threshold_occurrences": "thresholdOccurrences",
        "time_function": "timeFunction",
    },
)
class NrqlAlertConditionCritical:
    def __init__(
        self,
        *,
        threshold: jsii.Number,
        disable_health_status_reporting: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        duration: typing.Optional[jsii.Number] = None,
        operator: typing.Optional[builtins.str] = None,
        prediction: typing.Optional[typing.Union["NrqlAlertConditionCriticalPrediction", typing.Dict[builtins.str, typing.Any]]] = None,
        threshold_duration: typing.Optional[jsii.Number] = None,
        threshold_occurrences: typing.Optional[builtins.str] = None,
        time_function: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param threshold: For baseline conditions must be in range [1, 1000]. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#threshold NrqlAlertCondition#threshold}
        :param disable_health_status_reporting: Violations will not change system health status for this term. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#disable_health_status_reporting NrqlAlertCondition#disable_health_status_reporting}
        :param duration: In minutes, must be in the range of 1 to 120 (inclusive). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#duration NrqlAlertCondition#duration}
        :param operator: One of (above, above_or_equals, below, below_or_equals, equals, not_equals). Defaults to 'equals'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#operator NrqlAlertCondition#operator}
        :param prediction: prediction block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#prediction NrqlAlertCondition#prediction}
        :param threshold_duration: The duration, in seconds, that the threshold must violate in order to create an incident. Value must be a multiple of the 'aggregation_window' (which has a default of 60 seconds). Value must be within 120-86400 seconds for baseline conditions, and within 60-86400 seconds for static conditions Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#threshold_duration NrqlAlertCondition#threshold_duration}
        :param threshold_occurrences: The criteria for how many data points must be in violation for the specified threshold duration. Valid values are: 'ALL' or 'AT_LEAST_ONCE' (case insensitive). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#threshold_occurrences NrqlAlertCondition#threshold_occurrences}
        :param time_function: Valid values are: 'all' or 'any'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#time_function NrqlAlertCondition#time_function}
        '''
        if isinstance(prediction, dict):
            prediction = NrqlAlertConditionCriticalPrediction(**prediction)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0e11bdadd688e56b61ace66f998ba22f906832c15399dfe5a4e979fa5c04050a)
            check_type(argname="argument threshold", value=threshold, expected_type=type_hints["threshold"])
            check_type(argname="argument disable_health_status_reporting", value=disable_health_status_reporting, expected_type=type_hints["disable_health_status_reporting"])
            check_type(argname="argument duration", value=duration, expected_type=type_hints["duration"])
            check_type(argname="argument operator", value=operator, expected_type=type_hints["operator"])
            check_type(argname="argument prediction", value=prediction, expected_type=type_hints["prediction"])
            check_type(argname="argument threshold_duration", value=threshold_duration, expected_type=type_hints["threshold_duration"])
            check_type(argname="argument threshold_occurrences", value=threshold_occurrences, expected_type=type_hints["threshold_occurrences"])
            check_type(argname="argument time_function", value=time_function, expected_type=type_hints["time_function"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "threshold": threshold,
        }
        if disable_health_status_reporting is not None:
            self._values["disable_health_status_reporting"] = disable_health_status_reporting
        if duration is not None:
            self._values["duration"] = duration
        if operator is not None:
            self._values["operator"] = operator
        if prediction is not None:
            self._values["prediction"] = prediction
        if threshold_duration is not None:
            self._values["threshold_duration"] = threshold_duration
        if threshold_occurrences is not None:
            self._values["threshold_occurrences"] = threshold_occurrences
        if time_function is not None:
            self._values["time_function"] = time_function

    @builtins.property
    def threshold(self) -> jsii.Number:
        '''For baseline conditions must be in range [1, 1000].

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#threshold NrqlAlertCondition#threshold}
        '''
        result = self._values.get("threshold")
        assert result is not None, "Required property 'threshold' is missing"
        return typing.cast(jsii.Number, result)

    @builtins.property
    def disable_health_status_reporting(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Violations will not change system health status for this term.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#disable_health_status_reporting NrqlAlertCondition#disable_health_status_reporting}
        '''
        result = self._values.get("disable_health_status_reporting")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def duration(self) -> typing.Optional[jsii.Number]:
        '''In minutes, must be in the range of 1 to 120 (inclusive).

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#duration NrqlAlertCondition#duration}
        '''
        result = self._values.get("duration")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def operator(self) -> typing.Optional[builtins.str]:
        '''One of (above, above_or_equals, below, below_or_equals, equals, not_equals). Defaults to 'equals'.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#operator NrqlAlertCondition#operator}
        '''
        result = self._values.get("operator")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def prediction(self) -> typing.Optional["NrqlAlertConditionCriticalPrediction"]:
        '''prediction block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#prediction NrqlAlertCondition#prediction}
        '''
        result = self._values.get("prediction")
        return typing.cast(typing.Optional["NrqlAlertConditionCriticalPrediction"], result)

    @builtins.property
    def threshold_duration(self) -> typing.Optional[jsii.Number]:
        '''The duration, in seconds, that the threshold must violate in order to create an incident.

        Value must be a multiple of the 'aggregation_window' (which has a default of 60 seconds). Value must be within 120-86400 seconds for baseline conditions, and within 60-86400 seconds for static conditions

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#threshold_duration NrqlAlertCondition#threshold_duration}
        '''
        result = self._values.get("threshold_duration")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def threshold_occurrences(self) -> typing.Optional[builtins.str]:
        '''The criteria for how many data points must be in violation for the specified threshold duration.

        Valid values are: 'ALL' or 'AT_LEAST_ONCE' (case insensitive).

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#threshold_occurrences NrqlAlertCondition#threshold_occurrences}
        '''
        result = self._values.get("threshold_occurrences")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def time_function(self) -> typing.Optional[builtins.str]:
        '''Valid values are: 'all' or 'any'.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#time_function NrqlAlertCondition#time_function}
        '''
        result = self._values.get("time_function")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "NrqlAlertConditionCritical(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class NrqlAlertConditionCriticalOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.nrqlAlertCondition.NrqlAlertConditionCriticalOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6fa748d9227fc8f36fb2059d51d1d6975b6589522be48fe602d3952b05b32100)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putPrediction")
    def put_prediction(
        self,
        *,
        predict_by: typing.Optional[jsii.Number] = None,
        prefer_prediction_violation: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    ) -> None:
        '''
        :param predict_by: BETA PREVIEW: the ``predict_by`` field is in limited release and only enabled for preview on a per-account basis. - The duration, in seconds, that the prediction should look into the future. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#predict_by NrqlAlertCondition#predict_by}
        :param prefer_prediction_violation: BETA PREVIEW: the ``prefer_prediction_violation`` field is in limited release and only enabled for preview on a per-account basis. - If a prediction incident is open when a term's static threshold is breached by the actual signal, default behavior is to close the prediction incident and open a static incident. Setting ``prefer_prediction_violation`` to ``true`` overrides this behavior leaving the prediction incident open and preventing a static incident from opening. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#prefer_prediction_violation NrqlAlertCondition#prefer_prediction_violation}
        '''
        value = NrqlAlertConditionCriticalPrediction(
            predict_by=predict_by,
            prefer_prediction_violation=prefer_prediction_violation,
        )

        return typing.cast(None, jsii.invoke(self, "putPrediction", [value]))

    @jsii.member(jsii_name="resetDisableHealthStatusReporting")
    def reset_disable_health_status_reporting(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDisableHealthStatusReporting", []))

    @jsii.member(jsii_name="resetDuration")
    def reset_duration(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDuration", []))

    @jsii.member(jsii_name="resetOperator")
    def reset_operator(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOperator", []))

    @jsii.member(jsii_name="resetPrediction")
    def reset_prediction(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPrediction", []))

    @jsii.member(jsii_name="resetThresholdDuration")
    def reset_threshold_duration(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetThresholdDuration", []))

    @jsii.member(jsii_name="resetThresholdOccurrences")
    def reset_threshold_occurrences(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetThresholdOccurrences", []))

    @jsii.member(jsii_name="resetTimeFunction")
    def reset_time_function(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTimeFunction", []))

    @builtins.property
    @jsii.member(jsii_name="prediction")
    def prediction(self) -> "NrqlAlertConditionCriticalPredictionOutputReference":
        return typing.cast("NrqlAlertConditionCriticalPredictionOutputReference", jsii.get(self, "prediction"))

    @builtins.property
    @jsii.member(jsii_name="disableHealthStatusReportingInput")
    def disable_health_status_reporting_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "disableHealthStatusReportingInput"))

    @builtins.property
    @jsii.member(jsii_name="durationInput")
    def duration_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "durationInput"))

    @builtins.property
    @jsii.member(jsii_name="operatorInput")
    def operator_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "operatorInput"))

    @builtins.property
    @jsii.member(jsii_name="predictionInput")
    def prediction_input(
        self,
    ) -> typing.Optional["NrqlAlertConditionCriticalPrediction"]:
        return typing.cast(typing.Optional["NrqlAlertConditionCriticalPrediction"], jsii.get(self, "predictionInput"))

    @builtins.property
    @jsii.member(jsii_name="thresholdDurationInput")
    def threshold_duration_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "thresholdDurationInput"))

    @builtins.property
    @jsii.member(jsii_name="thresholdInput")
    def threshold_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "thresholdInput"))

    @builtins.property
    @jsii.member(jsii_name="thresholdOccurrencesInput")
    def threshold_occurrences_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "thresholdOccurrencesInput"))

    @builtins.property
    @jsii.member(jsii_name="timeFunctionInput")
    def time_function_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "timeFunctionInput"))

    @builtins.property
    @jsii.member(jsii_name="disableHealthStatusReporting")
    def disable_health_status_reporting(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "disableHealthStatusReporting"))

    @disable_health_status_reporting.setter
    def disable_health_status_reporting(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d2652b9ae39f976aee9fda8f840c03b627164e01a9a087b3293bf1dd91e29ee0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "disableHealthStatusReporting", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="duration")
    def duration(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "duration"))

    @duration.setter
    def duration(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cbece5818226cb0a7ed0c4ba6f695d3db5dac48d6b5c821ca1044ce5965207e2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "duration", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operator")
    def operator(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "operator"))

    @operator.setter
    def operator(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6cb26b220b498f834f674218360265211541cacb67f080e5595c836a2f409794)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operator", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="threshold")
    def threshold(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "threshold"))

    @threshold.setter
    def threshold(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d8a8049ed9db83476f7c3b3064a9121558ef3b85bf093d7287f1ee3958afc745)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "threshold", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="thresholdDuration")
    def threshold_duration(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "thresholdDuration"))

    @threshold_duration.setter
    def threshold_duration(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__029b01fdfcdadc6802ec8dadbf0287f485fe8ff61106d84f5ca58684c59c967f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "thresholdDuration", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="thresholdOccurrences")
    def threshold_occurrences(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "thresholdOccurrences"))

    @threshold_occurrences.setter
    def threshold_occurrences(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__32d0db28395b70b839d1f4aada60e1585a8fab044b198183e20b5c4809ae7b74)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "thresholdOccurrences", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="timeFunction")
    def time_function(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "timeFunction"))

    @time_function.setter
    def time_function(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__02b8b916e879d559782b46776398c0c681b3e5ed4504a836cff9281e634f152c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "timeFunction", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[NrqlAlertConditionCritical]:
        return typing.cast(typing.Optional[NrqlAlertConditionCritical], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[NrqlAlertConditionCritical],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1dfa3bcd6558d32d7b3adfd4f1f729b53265b09b58feb8769e940e11ea2085f7)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.nrqlAlertCondition.NrqlAlertConditionCriticalPrediction",
    jsii_struct_bases=[],
    name_mapping={
        "predict_by": "predictBy",
        "prefer_prediction_violation": "preferPredictionViolation",
    },
)
class NrqlAlertConditionCriticalPrediction:
    def __init__(
        self,
        *,
        predict_by: typing.Optional[jsii.Number] = None,
        prefer_prediction_violation: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    ) -> None:
        '''
        :param predict_by: BETA PREVIEW: the ``predict_by`` field is in limited release and only enabled for preview on a per-account basis. - The duration, in seconds, that the prediction should look into the future. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#predict_by NrqlAlertCondition#predict_by}
        :param prefer_prediction_violation: BETA PREVIEW: the ``prefer_prediction_violation`` field is in limited release and only enabled for preview on a per-account basis. - If a prediction incident is open when a term's static threshold is breached by the actual signal, default behavior is to close the prediction incident and open a static incident. Setting ``prefer_prediction_violation`` to ``true`` overrides this behavior leaving the prediction incident open and preventing a static incident from opening. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#prefer_prediction_violation NrqlAlertCondition#prefer_prediction_violation}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b5abdaef8a740ec866aaecf222650e10aa9ee84bf954f1d4e5cc588b00667cee)
            check_type(argname="argument predict_by", value=predict_by, expected_type=type_hints["predict_by"])
            check_type(argname="argument prefer_prediction_violation", value=prefer_prediction_violation, expected_type=type_hints["prefer_prediction_violation"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if predict_by is not None:
            self._values["predict_by"] = predict_by
        if prefer_prediction_violation is not None:
            self._values["prefer_prediction_violation"] = prefer_prediction_violation

    @builtins.property
    def predict_by(self) -> typing.Optional[jsii.Number]:
        '''BETA PREVIEW: the ``predict_by`` field is in limited release and only enabled for preview on a per-account basis.

        - The duration, in seconds, that the prediction should look into the future.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#predict_by NrqlAlertCondition#predict_by}
        '''
        result = self._values.get("predict_by")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def prefer_prediction_violation(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''BETA PREVIEW: the ``prefer_prediction_violation`` field is in limited release and only enabled for preview on a per-account basis.

        - If a prediction incident is open when a term's static threshold is breached by the actual signal, default behavior is to close the prediction incident and open a static incident. Setting ``prefer_prediction_violation`` to ``true`` overrides this behavior leaving the prediction incident open and preventing a static incident from opening.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#prefer_prediction_violation NrqlAlertCondition#prefer_prediction_violation}
        '''
        result = self._values.get("prefer_prediction_violation")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "NrqlAlertConditionCriticalPrediction(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class NrqlAlertConditionCriticalPredictionOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.nrqlAlertCondition.NrqlAlertConditionCriticalPredictionOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__70ccc2e056084d3d141fdb672f3d99ea12c047cc5bb51065e55615248d3eda04)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetPredictBy")
    def reset_predict_by(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPredictBy", []))

    @jsii.member(jsii_name="resetPreferPredictionViolation")
    def reset_prefer_prediction_violation(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPreferPredictionViolation", []))

    @builtins.property
    @jsii.member(jsii_name="predictByInput")
    def predict_by_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "predictByInput"))

    @builtins.property
    @jsii.member(jsii_name="preferPredictionViolationInput")
    def prefer_prediction_violation_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "preferPredictionViolationInput"))

    @builtins.property
    @jsii.member(jsii_name="predictBy")
    def predict_by(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "predictBy"))

    @predict_by.setter
    def predict_by(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ea99ab430be81dfc417cff3f0928f8115f5ea2b4dc498d78b8e132d53a536e2d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "predictBy", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="preferPredictionViolation")
    def prefer_prediction_violation(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "preferPredictionViolation"))

    @prefer_prediction_violation.setter
    def prefer_prediction_violation(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__287fe47f24e8014d74033775167d96415a9730dacbb83eca6232a2c583573b10)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "preferPredictionViolation", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[NrqlAlertConditionCriticalPrediction]:
        return typing.cast(typing.Optional[NrqlAlertConditionCriticalPrediction], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[NrqlAlertConditionCriticalPrediction],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__eb6e3acd343f312ba2fa6657cbeae8a8b3bbc5db6d793d2399b5419845774f0e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.nrqlAlertCondition.NrqlAlertConditionNrql",
    jsii_struct_bases=[],
    name_mapping={
        "query": "query",
        "data_account_id": "dataAccountId",
        "evaluation_offset": "evaluationOffset",
        "since_value": "sinceValue",
    },
)
class NrqlAlertConditionNrql:
    def __init__(
        self,
        *,
        query: builtins.str,
        data_account_id: typing.Optional[jsii.Number] = None,
        evaluation_offset: typing.Optional[jsii.Number] = None,
        since_value: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param query: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#query NrqlAlertCondition#query}.
        :param data_account_id: The New Relic account ID to use as the basis for the NRQL alert condition's ``query``; will default to ``account_id`` if unspecified. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#data_account_id NrqlAlertCondition#data_account_id}
        :param evaluation_offset: NRQL queries are evaluated in one-minute time windows. The start time depends on the value you provide in the NRQL condition's ``evaluation_offset``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#evaluation_offset NrqlAlertCondition#evaluation_offset}
        :param since_value: NRQL queries are evaluated in one-minute time windows. The start time depends on the value you provide in the NRQL condition's ``since_value``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#since_value NrqlAlertCondition#since_value}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d1bb273a3917be40db18ae73718455f7ec73de222ca6484049761eb2fa422955)
            check_type(argname="argument query", value=query, expected_type=type_hints["query"])
            check_type(argname="argument data_account_id", value=data_account_id, expected_type=type_hints["data_account_id"])
            check_type(argname="argument evaluation_offset", value=evaluation_offset, expected_type=type_hints["evaluation_offset"])
            check_type(argname="argument since_value", value=since_value, expected_type=type_hints["since_value"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "query": query,
        }
        if data_account_id is not None:
            self._values["data_account_id"] = data_account_id
        if evaluation_offset is not None:
            self._values["evaluation_offset"] = evaluation_offset
        if since_value is not None:
            self._values["since_value"] = since_value

    @builtins.property
    def query(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#query NrqlAlertCondition#query}.'''
        result = self._values.get("query")
        assert result is not None, "Required property 'query' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def data_account_id(self) -> typing.Optional[jsii.Number]:
        '''The New Relic account ID to use as the basis for the NRQL alert condition's ``query``;

        will default to ``account_id`` if unspecified.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#data_account_id NrqlAlertCondition#data_account_id}
        '''
        result = self._values.get("data_account_id")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def evaluation_offset(self) -> typing.Optional[jsii.Number]:
        '''NRQL queries are evaluated in one-minute time windows.

        The start time depends on the value you provide in the NRQL condition's ``evaluation_offset``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#evaluation_offset NrqlAlertCondition#evaluation_offset}
        '''
        result = self._values.get("evaluation_offset")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def since_value(self) -> typing.Optional[builtins.str]:
        '''NRQL queries are evaluated in one-minute time windows.

        The start time depends on the value you provide in the NRQL condition's ``since_value``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#since_value NrqlAlertCondition#since_value}
        '''
        result = self._values.get("since_value")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "NrqlAlertConditionNrql(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class NrqlAlertConditionNrqlOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.nrqlAlertCondition.NrqlAlertConditionNrqlOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cfa973b4b29259be8ec81bec79c693d31a2cb7da244a7af8e73e968202454a35)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetDataAccountId")
    def reset_data_account_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDataAccountId", []))

    @jsii.member(jsii_name="resetEvaluationOffset")
    def reset_evaluation_offset(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEvaluationOffset", []))

    @jsii.member(jsii_name="resetSinceValue")
    def reset_since_value(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSinceValue", []))

    @builtins.property
    @jsii.member(jsii_name="dataAccountIdInput")
    def data_account_id_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "dataAccountIdInput"))

    @builtins.property
    @jsii.member(jsii_name="evaluationOffsetInput")
    def evaluation_offset_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "evaluationOffsetInput"))

    @builtins.property
    @jsii.member(jsii_name="queryInput")
    def query_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "queryInput"))

    @builtins.property
    @jsii.member(jsii_name="sinceValueInput")
    def since_value_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "sinceValueInput"))

    @builtins.property
    @jsii.member(jsii_name="dataAccountId")
    def data_account_id(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "dataAccountId"))

    @data_account_id.setter
    def data_account_id(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__68a37b4461055ae8f69b8428780b20530cc0a812b6ceac0df27884c0487bd6ef)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "dataAccountId", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="evaluationOffset")
    def evaluation_offset(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "evaluationOffset"))

    @evaluation_offset.setter
    def evaluation_offset(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c7bfa1bbf2773055d3413767cceb3a20e4fc658280788864621d7b734bde4ce3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "evaluationOffset", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="query")
    def query(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "query"))

    @query.setter
    def query(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__780c32f31703c64b45be2b4675ebe28626e6ec63764070216de60fbe3a1fd762)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "query", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="sinceValue")
    def since_value(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "sinceValue"))

    @since_value.setter
    def since_value(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__dbc957983599da427de4a598d4f042506738b9f5df62066dfea1a26d286ea2be)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "sinceValue", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[NrqlAlertConditionNrql]:
        return typing.cast(typing.Optional[NrqlAlertConditionNrql], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(self, value: typing.Optional[NrqlAlertConditionNrql]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__454502e00174eb70f8e86ede9834caf593a21a8a93cb78118c8b856c3398a872)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.nrqlAlertCondition.NrqlAlertConditionOutlierConfiguration",
    jsii_struct_bases=[],
    name_mapping={"dbscan": "dbscan"},
)
class NrqlAlertConditionOutlierConfiguration:
    def __init__(
        self,
        *,
        dbscan: typing.Union["NrqlAlertConditionOutlierConfigurationDbscan", typing.Dict[builtins.str, typing.Any]],
    ) -> None:
        '''
        :param dbscan: dbscan block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#dbscan NrqlAlertCondition#dbscan}
        '''
        if isinstance(dbscan, dict):
            dbscan = NrqlAlertConditionOutlierConfigurationDbscan(**dbscan)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a52be57545add34991fef21bf1ac258d829750afd21f7f82d3b06386d964f97c)
            check_type(argname="argument dbscan", value=dbscan, expected_type=type_hints["dbscan"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "dbscan": dbscan,
        }

    @builtins.property
    def dbscan(self) -> "NrqlAlertConditionOutlierConfigurationDbscan":
        '''dbscan block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#dbscan NrqlAlertCondition#dbscan}
        '''
        result = self._values.get("dbscan")
        assert result is not None, "Required property 'dbscan' is missing"
        return typing.cast("NrqlAlertConditionOutlierConfigurationDbscan", result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "NrqlAlertConditionOutlierConfiguration(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.nrqlAlertCondition.NrqlAlertConditionOutlierConfigurationDbscan",
    jsii_struct_bases=[],
    name_mapping={
        "epsilon": "epsilon",
        "minimum_points": "minimumPoints",
        "evaluation_group_facet": "evaluationGroupFacet",
    },
)
class NrqlAlertConditionOutlierConfigurationDbscan:
    def __init__(
        self,
        *,
        epsilon: jsii.Number,
        minimum_points: jsii.Number,
        evaluation_group_facet: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param epsilon: BETA PREVIEW: the ``epsilon`` field is in limited release and only enabled for preview on a per-account basis. - Radius (distance threshold) for DBSCAN in the units of the query result. Smaller values tighten clusters; larger values broaden them. Must be > 0. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#epsilon NrqlAlertCondition#epsilon}
        :param minimum_points: BETA PREVIEW: the ``minimum_points`` field is in limited release and only enabled for preview on a per-account basis. - Minimum number of neighboring points needed to form a cluster. Must be >= 1. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#minimum_points NrqlAlertCondition#minimum_points}
        :param evaluation_group_facet: BETA PREVIEW: the ``evaluation_group_facet`` field is in limited release and only enabled for preview on a per-account basis. - Optional NRQL facet attribute used to segment data into groups (e.g. ``host``, ``region``) before running outlier detection. Omit to evaluate all results together. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#evaluation_group_facet NrqlAlertCondition#evaluation_group_facet}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d95aee2740972f9d9dd5c26a03a7faef58dca702065cdf075367431a82cb49c6)
            check_type(argname="argument epsilon", value=epsilon, expected_type=type_hints["epsilon"])
            check_type(argname="argument minimum_points", value=minimum_points, expected_type=type_hints["minimum_points"])
            check_type(argname="argument evaluation_group_facet", value=evaluation_group_facet, expected_type=type_hints["evaluation_group_facet"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "epsilon": epsilon,
            "minimum_points": minimum_points,
        }
        if evaluation_group_facet is not None:
            self._values["evaluation_group_facet"] = evaluation_group_facet

    @builtins.property
    def epsilon(self) -> jsii.Number:
        '''BETA PREVIEW: the ``epsilon`` field is in limited release and only enabled for preview on a per-account basis.

        - Radius (distance threshold) for DBSCAN in the units of the query result. Smaller values tighten clusters; larger values broaden them. Must be > 0.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#epsilon NrqlAlertCondition#epsilon}
        '''
        result = self._values.get("epsilon")
        assert result is not None, "Required property 'epsilon' is missing"
        return typing.cast(jsii.Number, result)

    @builtins.property
    def minimum_points(self) -> jsii.Number:
        '''BETA PREVIEW: the ``minimum_points`` field is in limited release and only enabled for preview on a per-account basis.

        - Minimum number of neighboring points needed to form a cluster. Must be >= 1.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#minimum_points NrqlAlertCondition#minimum_points}
        '''
        result = self._values.get("minimum_points")
        assert result is not None, "Required property 'minimum_points' is missing"
        return typing.cast(jsii.Number, result)

    @builtins.property
    def evaluation_group_facet(self) -> typing.Optional[builtins.str]:
        '''BETA PREVIEW: the ``evaluation_group_facet`` field is in limited release and only enabled for preview on a per-account basis.

        - Optional NRQL facet attribute used to segment data into groups (e.g. ``host``, ``region``) before running outlier detection. Omit to evaluate all results together.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#evaluation_group_facet NrqlAlertCondition#evaluation_group_facet}
        '''
        result = self._values.get("evaluation_group_facet")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "NrqlAlertConditionOutlierConfigurationDbscan(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class NrqlAlertConditionOutlierConfigurationDbscanOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.nrqlAlertCondition.NrqlAlertConditionOutlierConfigurationDbscanOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__61b3c7418e0032ccf50b28eb57c7cd0e990e85f8c9e74d5907dc60bcd40f39b5)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetEvaluationGroupFacet")
    def reset_evaluation_group_facet(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEvaluationGroupFacet", []))

    @builtins.property
    @jsii.member(jsii_name="epsilonInput")
    def epsilon_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "epsilonInput"))

    @builtins.property
    @jsii.member(jsii_name="evaluationGroupFacetInput")
    def evaluation_group_facet_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "evaluationGroupFacetInput"))

    @builtins.property
    @jsii.member(jsii_name="minimumPointsInput")
    def minimum_points_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "minimumPointsInput"))

    @builtins.property
    @jsii.member(jsii_name="epsilon")
    def epsilon(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "epsilon"))

    @epsilon.setter
    def epsilon(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1b7663a4211fb93cab6e2a5cfa22b430e2a5b9138fec5c54afa72b50d6c3ac9d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "epsilon", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="evaluationGroupFacet")
    def evaluation_group_facet(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "evaluationGroupFacet"))

    @evaluation_group_facet.setter
    def evaluation_group_facet(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5139d9220653c36e464fca6408570e3d5f8a4e77d99368647608e3b5f22a28ca)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "evaluationGroupFacet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="minimumPoints")
    def minimum_points(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "minimumPoints"))

    @minimum_points.setter
    def minimum_points(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bf6cf0b81394d8981e3ecea9d89be0fa73f412dc34e780c90412f0aeec4024f7)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "minimumPoints", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[NrqlAlertConditionOutlierConfigurationDbscan]:
        return typing.cast(typing.Optional[NrqlAlertConditionOutlierConfigurationDbscan], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[NrqlAlertConditionOutlierConfigurationDbscan],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__787dff4678b3f88979cd9ac4351334ec0d2653fd3e82be15e87407c462baa7e5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class NrqlAlertConditionOutlierConfigurationOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.nrqlAlertCondition.NrqlAlertConditionOutlierConfigurationOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7b0fd821671674f4e7f6fcb8433d15b8ade4a341105eddb2c09ead713f0fb5cc)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putDbscan")
    def put_dbscan(
        self,
        *,
        epsilon: jsii.Number,
        minimum_points: jsii.Number,
        evaluation_group_facet: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param epsilon: BETA PREVIEW: the ``epsilon`` field is in limited release and only enabled for preview on a per-account basis. - Radius (distance threshold) for DBSCAN in the units of the query result. Smaller values tighten clusters; larger values broaden them. Must be > 0. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#epsilon NrqlAlertCondition#epsilon}
        :param minimum_points: BETA PREVIEW: the ``minimum_points`` field is in limited release and only enabled for preview on a per-account basis. - Minimum number of neighboring points needed to form a cluster. Must be >= 1. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#minimum_points NrqlAlertCondition#minimum_points}
        :param evaluation_group_facet: BETA PREVIEW: the ``evaluation_group_facet`` field is in limited release and only enabled for preview on a per-account basis. - Optional NRQL facet attribute used to segment data into groups (e.g. ``host``, ``region``) before running outlier detection. Omit to evaluate all results together. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#evaluation_group_facet NrqlAlertCondition#evaluation_group_facet}
        '''
        value = NrqlAlertConditionOutlierConfigurationDbscan(
            epsilon=epsilon,
            minimum_points=minimum_points,
            evaluation_group_facet=evaluation_group_facet,
        )

        return typing.cast(None, jsii.invoke(self, "putDbscan", [value]))

    @builtins.property
    @jsii.member(jsii_name="dbscan")
    def dbscan(self) -> NrqlAlertConditionOutlierConfigurationDbscanOutputReference:
        return typing.cast(NrqlAlertConditionOutlierConfigurationDbscanOutputReference, jsii.get(self, "dbscan"))

    @builtins.property
    @jsii.member(jsii_name="dbscanInput")
    def dbscan_input(
        self,
    ) -> typing.Optional[NrqlAlertConditionOutlierConfigurationDbscan]:
        return typing.cast(typing.Optional[NrqlAlertConditionOutlierConfigurationDbscan], jsii.get(self, "dbscanInput"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[NrqlAlertConditionOutlierConfiguration]:
        return typing.cast(typing.Optional[NrqlAlertConditionOutlierConfiguration], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[NrqlAlertConditionOutlierConfiguration],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ce6761f84e704ee54514fa80c390b29f0f51e72cd8b3efacdcfce04242aebf3d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.nrqlAlertCondition.NrqlAlertConditionTerm",
    jsii_struct_bases=[],
    name_mapping={
        "threshold": "threshold",
        "disable_health_status_reporting": "disableHealthStatusReporting",
        "duration": "duration",
        "operator": "operator",
        "prediction": "prediction",
        "priority": "priority",
        "threshold_duration": "thresholdDuration",
        "threshold_occurrences": "thresholdOccurrences",
        "time_function": "timeFunction",
    },
)
class NrqlAlertConditionTerm:
    def __init__(
        self,
        *,
        threshold: jsii.Number,
        disable_health_status_reporting: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        duration: typing.Optional[jsii.Number] = None,
        operator: typing.Optional[builtins.str] = None,
        prediction: typing.Optional[typing.Union["NrqlAlertConditionTermPrediction", typing.Dict[builtins.str, typing.Any]]] = None,
        priority: typing.Optional[builtins.str] = None,
        threshold_duration: typing.Optional[jsii.Number] = None,
        threshold_occurrences: typing.Optional[builtins.str] = None,
        time_function: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param threshold: For baseline conditions must be in range [1, 1000]. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#threshold NrqlAlertCondition#threshold}
        :param disable_health_status_reporting: Violations will not change system health status for this term. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#disable_health_status_reporting NrqlAlertCondition#disable_health_status_reporting}
        :param duration: In minutes, must be in the range of 1 to 120 (inclusive). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#duration NrqlAlertCondition#duration}
        :param operator: One of (above, above_or_equals, below, below_or_equals, equals, not_equals). Defaults to 'equals'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#operator NrqlAlertCondition#operator}
        :param prediction: prediction block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#prediction NrqlAlertCondition#prediction}
        :param priority: One of (critical, warning). Defaults to 'critical'. At least one condition term must have priority set to 'critical'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#priority NrqlAlertCondition#priority}
        :param threshold_duration: The duration, in seconds, that the threshold must violate in order to create an incident. Value must be a multiple of the 'aggregation_window' (which has a default of 60 seconds). Value must be within 120-86400 seconds for baseline conditions, and within 60-86400 seconds for static conditions Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#threshold_duration NrqlAlertCondition#threshold_duration}
        :param threshold_occurrences: The criteria for how many data points must be in violation for the specified threshold duration. Valid values are: 'ALL' or 'AT_LEAST_ONCE' (case insensitive). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#threshold_occurrences NrqlAlertCondition#threshold_occurrences}
        :param time_function: Valid values are: 'all' or 'any'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#time_function NrqlAlertCondition#time_function}
        '''
        if isinstance(prediction, dict):
            prediction = NrqlAlertConditionTermPrediction(**prediction)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__92a5fbed515deeb578f2a4b34f2cb6bf7a05dfab211ec1885702f354f2258783)
            check_type(argname="argument threshold", value=threshold, expected_type=type_hints["threshold"])
            check_type(argname="argument disable_health_status_reporting", value=disable_health_status_reporting, expected_type=type_hints["disable_health_status_reporting"])
            check_type(argname="argument duration", value=duration, expected_type=type_hints["duration"])
            check_type(argname="argument operator", value=operator, expected_type=type_hints["operator"])
            check_type(argname="argument prediction", value=prediction, expected_type=type_hints["prediction"])
            check_type(argname="argument priority", value=priority, expected_type=type_hints["priority"])
            check_type(argname="argument threshold_duration", value=threshold_duration, expected_type=type_hints["threshold_duration"])
            check_type(argname="argument threshold_occurrences", value=threshold_occurrences, expected_type=type_hints["threshold_occurrences"])
            check_type(argname="argument time_function", value=time_function, expected_type=type_hints["time_function"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "threshold": threshold,
        }
        if disable_health_status_reporting is not None:
            self._values["disable_health_status_reporting"] = disable_health_status_reporting
        if duration is not None:
            self._values["duration"] = duration
        if operator is not None:
            self._values["operator"] = operator
        if prediction is not None:
            self._values["prediction"] = prediction
        if priority is not None:
            self._values["priority"] = priority
        if threshold_duration is not None:
            self._values["threshold_duration"] = threshold_duration
        if threshold_occurrences is not None:
            self._values["threshold_occurrences"] = threshold_occurrences
        if time_function is not None:
            self._values["time_function"] = time_function

    @builtins.property
    def threshold(self) -> jsii.Number:
        '''For baseline conditions must be in range [1, 1000].

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#threshold NrqlAlertCondition#threshold}
        '''
        result = self._values.get("threshold")
        assert result is not None, "Required property 'threshold' is missing"
        return typing.cast(jsii.Number, result)

    @builtins.property
    def disable_health_status_reporting(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Violations will not change system health status for this term.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#disable_health_status_reporting NrqlAlertCondition#disable_health_status_reporting}
        '''
        result = self._values.get("disable_health_status_reporting")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def duration(self) -> typing.Optional[jsii.Number]:
        '''In minutes, must be in the range of 1 to 120 (inclusive).

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#duration NrqlAlertCondition#duration}
        '''
        result = self._values.get("duration")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def operator(self) -> typing.Optional[builtins.str]:
        '''One of (above, above_or_equals, below, below_or_equals, equals, not_equals). Defaults to 'equals'.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#operator NrqlAlertCondition#operator}
        '''
        result = self._values.get("operator")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def prediction(self) -> typing.Optional["NrqlAlertConditionTermPrediction"]:
        '''prediction block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#prediction NrqlAlertCondition#prediction}
        '''
        result = self._values.get("prediction")
        return typing.cast(typing.Optional["NrqlAlertConditionTermPrediction"], result)

    @builtins.property
    def priority(self) -> typing.Optional[builtins.str]:
        '''One of (critical, warning). Defaults to 'critical'. At least one condition term must have priority set to 'critical'.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#priority NrqlAlertCondition#priority}
        '''
        result = self._values.get("priority")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def threshold_duration(self) -> typing.Optional[jsii.Number]:
        '''The duration, in seconds, that the threshold must violate in order to create an incident.

        Value must be a multiple of the 'aggregation_window' (which has a default of 60 seconds). Value must be within 120-86400 seconds for baseline conditions, and within 60-86400 seconds for static conditions

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#threshold_duration NrqlAlertCondition#threshold_duration}
        '''
        result = self._values.get("threshold_duration")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def threshold_occurrences(self) -> typing.Optional[builtins.str]:
        '''The criteria for how many data points must be in violation for the specified threshold duration.

        Valid values are: 'ALL' or 'AT_LEAST_ONCE' (case insensitive).

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#threshold_occurrences NrqlAlertCondition#threshold_occurrences}
        '''
        result = self._values.get("threshold_occurrences")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def time_function(self) -> typing.Optional[builtins.str]:
        '''Valid values are: 'all' or 'any'.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#time_function NrqlAlertCondition#time_function}
        '''
        result = self._values.get("time_function")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "NrqlAlertConditionTerm(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class NrqlAlertConditionTermList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.nrqlAlertCondition.NrqlAlertConditionTermList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__587ebabfe7ddf78c460a8b397255117ae39be54cc132c0240c825b592be8a744)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(self, index: jsii.Number) -> "NrqlAlertConditionTermOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f7b2445a2f9ac1b58a9dbce58ed04704a471411d07152ce7f0088b233532ea2e)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("NrqlAlertConditionTermOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a9f238e1b15c3760bbbf588740c2a02f0d3560046719bf5eac7d8f6ba419da2f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d474505f9423ba8830afb8d7babd1b4659d3b81f087b97ee34cddd6a5faea52a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__28cd7df6e2c52141bd0bd543f5edbcd07741422d6b79127e2ac4729c75d2ff4b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[NrqlAlertConditionTerm]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[NrqlAlertConditionTerm]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[NrqlAlertConditionTerm]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ab2369aaa63ad70890aa98d98728ae942c62103c916271dc3f98694d76627082)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class NrqlAlertConditionTermOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.nrqlAlertCondition.NrqlAlertConditionTermOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__66b60600807bddd34bd4961a8ba06c66a73fa2e4638f43363cc75be66c4a9f88)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="putPrediction")
    def put_prediction(
        self,
        *,
        predict_by: typing.Optional[jsii.Number] = None,
        prefer_prediction_violation: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    ) -> None:
        '''
        :param predict_by: BETA PREVIEW: the ``predict_by`` field is in limited release and only enabled for preview on a per-account basis. - The duration, in seconds, that the prediction should look into the future. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#predict_by NrqlAlertCondition#predict_by}
        :param prefer_prediction_violation: BETA PREVIEW: the ``prefer_prediction_violation`` field is in limited release and only enabled for preview on a per-account basis. - If a prediction incident is open when a term's static threshold is breached by the actual signal, default behavior is to close the prediction incident and open a static incident. Setting ``prefer_prediction_violation`` to ``true`` overrides this behavior leaving the prediction incident open and preventing a static incident from opening. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#prefer_prediction_violation NrqlAlertCondition#prefer_prediction_violation}
        '''
        value = NrqlAlertConditionTermPrediction(
            predict_by=predict_by,
            prefer_prediction_violation=prefer_prediction_violation,
        )

        return typing.cast(None, jsii.invoke(self, "putPrediction", [value]))

    @jsii.member(jsii_name="resetDisableHealthStatusReporting")
    def reset_disable_health_status_reporting(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDisableHealthStatusReporting", []))

    @jsii.member(jsii_name="resetDuration")
    def reset_duration(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDuration", []))

    @jsii.member(jsii_name="resetOperator")
    def reset_operator(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOperator", []))

    @jsii.member(jsii_name="resetPrediction")
    def reset_prediction(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPrediction", []))

    @jsii.member(jsii_name="resetPriority")
    def reset_priority(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPriority", []))

    @jsii.member(jsii_name="resetThresholdDuration")
    def reset_threshold_duration(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetThresholdDuration", []))

    @jsii.member(jsii_name="resetThresholdOccurrences")
    def reset_threshold_occurrences(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetThresholdOccurrences", []))

    @jsii.member(jsii_name="resetTimeFunction")
    def reset_time_function(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTimeFunction", []))

    @builtins.property
    @jsii.member(jsii_name="prediction")
    def prediction(self) -> "NrqlAlertConditionTermPredictionOutputReference":
        return typing.cast("NrqlAlertConditionTermPredictionOutputReference", jsii.get(self, "prediction"))

    @builtins.property
    @jsii.member(jsii_name="disableHealthStatusReportingInput")
    def disable_health_status_reporting_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "disableHealthStatusReportingInput"))

    @builtins.property
    @jsii.member(jsii_name="durationInput")
    def duration_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "durationInput"))

    @builtins.property
    @jsii.member(jsii_name="operatorInput")
    def operator_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "operatorInput"))

    @builtins.property
    @jsii.member(jsii_name="predictionInput")
    def prediction_input(self) -> typing.Optional["NrqlAlertConditionTermPrediction"]:
        return typing.cast(typing.Optional["NrqlAlertConditionTermPrediction"], jsii.get(self, "predictionInput"))

    @builtins.property
    @jsii.member(jsii_name="priorityInput")
    def priority_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "priorityInput"))

    @builtins.property
    @jsii.member(jsii_name="thresholdDurationInput")
    def threshold_duration_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "thresholdDurationInput"))

    @builtins.property
    @jsii.member(jsii_name="thresholdInput")
    def threshold_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "thresholdInput"))

    @builtins.property
    @jsii.member(jsii_name="thresholdOccurrencesInput")
    def threshold_occurrences_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "thresholdOccurrencesInput"))

    @builtins.property
    @jsii.member(jsii_name="timeFunctionInput")
    def time_function_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "timeFunctionInput"))

    @builtins.property
    @jsii.member(jsii_name="disableHealthStatusReporting")
    def disable_health_status_reporting(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "disableHealthStatusReporting"))

    @disable_health_status_reporting.setter
    def disable_health_status_reporting(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d06131863d9932d06d366081470f823b29997d5258a13c336b005b5a5712a516)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "disableHealthStatusReporting", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="duration")
    def duration(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "duration"))

    @duration.setter
    def duration(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__edaae66750732d489643679bbfb90ae0df4aeab01a041021a5e0f73cc3e37c4d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "duration", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operator")
    def operator(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "operator"))

    @operator.setter
    def operator(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__15fdea9be13005f76dd66064a8a4993a46115047e1f5d5a3abe2cbe3a329d218)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operator", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="priority")
    def priority(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "priority"))

    @priority.setter
    def priority(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f9195c02ec594fa37733a244fc8f29e43077d7782ebc7a8a0a677882347197a1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "priority", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="threshold")
    def threshold(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "threshold"))

    @threshold.setter
    def threshold(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a2bbb0ba4ab650046e800d18a2e3809c633bda37c9820d06463eedc901aa4a2d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "threshold", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="thresholdDuration")
    def threshold_duration(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "thresholdDuration"))

    @threshold_duration.setter
    def threshold_duration(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c6b467afc3d1291265689869c473506199359eb0f664ac7e437b27bf1b3f58b2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "thresholdDuration", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="thresholdOccurrences")
    def threshold_occurrences(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "thresholdOccurrences"))

    @threshold_occurrences.setter
    def threshold_occurrences(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__76eebe53c1ef61920df39f24132140a73aca732214e9e3f3fde222823f7f568c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "thresholdOccurrences", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="timeFunction")
    def time_function(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "timeFunction"))

    @time_function.setter
    def time_function(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e314b1e29e9f1965d8c4023d4ea7a2fbffe4d6f7290f41d6ea4023465453c0ea)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "timeFunction", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, NrqlAlertConditionTerm]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, NrqlAlertConditionTerm]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, NrqlAlertConditionTerm]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f26af64d42e0451ec772ebe511ea003b5c12e661ace6a6243ce8c39af74c080a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.nrqlAlertCondition.NrqlAlertConditionTermPrediction",
    jsii_struct_bases=[],
    name_mapping={
        "predict_by": "predictBy",
        "prefer_prediction_violation": "preferPredictionViolation",
    },
)
class NrqlAlertConditionTermPrediction:
    def __init__(
        self,
        *,
        predict_by: typing.Optional[jsii.Number] = None,
        prefer_prediction_violation: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    ) -> None:
        '''
        :param predict_by: BETA PREVIEW: the ``predict_by`` field is in limited release and only enabled for preview on a per-account basis. - The duration, in seconds, that the prediction should look into the future. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#predict_by NrqlAlertCondition#predict_by}
        :param prefer_prediction_violation: BETA PREVIEW: the ``prefer_prediction_violation`` field is in limited release and only enabled for preview on a per-account basis. - If a prediction incident is open when a term's static threshold is breached by the actual signal, default behavior is to close the prediction incident and open a static incident. Setting ``prefer_prediction_violation`` to ``true`` overrides this behavior leaving the prediction incident open and preventing a static incident from opening. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#prefer_prediction_violation NrqlAlertCondition#prefer_prediction_violation}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__aa5127bb8601ca046ce854528052a55de5d67096e3ade8db55415420405f7149)
            check_type(argname="argument predict_by", value=predict_by, expected_type=type_hints["predict_by"])
            check_type(argname="argument prefer_prediction_violation", value=prefer_prediction_violation, expected_type=type_hints["prefer_prediction_violation"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if predict_by is not None:
            self._values["predict_by"] = predict_by
        if prefer_prediction_violation is not None:
            self._values["prefer_prediction_violation"] = prefer_prediction_violation

    @builtins.property
    def predict_by(self) -> typing.Optional[jsii.Number]:
        '''BETA PREVIEW: the ``predict_by`` field is in limited release and only enabled for preview on a per-account basis.

        - The duration, in seconds, that the prediction should look into the future.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#predict_by NrqlAlertCondition#predict_by}
        '''
        result = self._values.get("predict_by")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def prefer_prediction_violation(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''BETA PREVIEW: the ``prefer_prediction_violation`` field is in limited release and only enabled for preview on a per-account basis.

        - If a prediction incident is open when a term's static threshold is breached by the actual signal, default behavior is to close the prediction incident and open a static incident. Setting ``prefer_prediction_violation`` to ``true`` overrides this behavior leaving the prediction incident open and preventing a static incident from opening.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#prefer_prediction_violation NrqlAlertCondition#prefer_prediction_violation}
        '''
        result = self._values.get("prefer_prediction_violation")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "NrqlAlertConditionTermPrediction(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class NrqlAlertConditionTermPredictionOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.nrqlAlertCondition.NrqlAlertConditionTermPredictionOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6ebf2962fc6b532795fa1285263548c0b9d9540d820b21e7103f1b9ce230c620)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetPredictBy")
    def reset_predict_by(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPredictBy", []))

    @jsii.member(jsii_name="resetPreferPredictionViolation")
    def reset_prefer_prediction_violation(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPreferPredictionViolation", []))

    @builtins.property
    @jsii.member(jsii_name="predictByInput")
    def predict_by_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "predictByInput"))

    @builtins.property
    @jsii.member(jsii_name="preferPredictionViolationInput")
    def prefer_prediction_violation_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "preferPredictionViolationInput"))

    @builtins.property
    @jsii.member(jsii_name="predictBy")
    def predict_by(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "predictBy"))

    @predict_by.setter
    def predict_by(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e9c33de09cd07a3f590e52a319593f95bc1e017ebb768de96bcfdcc09f6eae3c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "predictBy", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="preferPredictionViolation")
    def prefer_prediction_violation(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "preferPredictionViolation"))

    @prefer_prediction_violation.setter
    def prefer_prediction_violation(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ffbc8b0ddad74094e10490dee8f078dbf57aff0004eb09e935e4c8279ced7aa2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "preferPredictionViolation", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[NrqlAlertConditionTermPrediction]:
        return typing.cast(typing.Optional[NrqlAlertConditionTermPrediction], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[NrqlAlertConditionTermPrediction],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c59b2d55e4afe05b1854640e81644c56bab23659ed089927a58271aa1fcdcc31)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.nrqlAlertCondition.NrqlAlertConditionTimeouts",
    jsii_struct_bases=[],
    name_mapping={"create": "create"},
)
class NrqlAlertConditionTimeouts:
    def __init__(self, *, create: typing.Optional[builtins.str] = None) -> None:
        '''
        :param create: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#create NrqlAlertCondition#create}.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ca33ad7c5b376b21396a6d9b2024fbedad4d17318a0c50abf5872b6867ca49f2)
            check_type(argname="argument create", value=create, expected_type=type_hints["create"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if create is not None:
            self._values["create"] = create

    @builtins.property
    def create(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#create NrqlAlertCondition#create}.'''
        result = self._values.get("create")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "NrqlAlertConditionTimeouts(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class NrqlAlertConditionTimeoutsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.nrqlAlertCondition.NrqlAlertConditionTimeoutsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__76fb96e1519d39576afb5ebb4fbff9ea602098b897b7cbfef63ad01e8399b418)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetCreate")
    def reset_create(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCreate", []))

    @builtins.property
    @jsii.member(jsii_name="createInput")
    def create_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "createInput"))

    @builtins.property
    @jsii.member(jsii_name="create")
    def create(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "create"))

    @create.setter
    def create(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e990d18ea3a76bb0d06e9f5a6b1fcd7540ae117f815da01a1a5c3fafcc7fc5d8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "create", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, NrqlAlertConditionTimeouts]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, NrqlAlertConditionTimeouts]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, NrqlAlertConditionTimeouts]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__30c84676783a5c688e9bdc7ac8bb2bf4ab76c5952e0330096e49eff63aed6c99)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.nrqlAlertCondition.NrqlAlertConditionWarning",
    jsii_struct_bases=[],
    name_mapping={
        "threshold": "threshold",
        "disable_health_status_reporting": "disableHealthStatusReporting",
        "duration": "duration",
        "operator": "operator",
        "prediction": "prediction",
        "threshold_duration": "thresholdDuration",
        "threshold_occurrences": "thresholdOccurrences",
        "time_function": "timeFunction",
    },
)
class NrqlAlertConditionWarning:
    def __init__(
        self,
        *,
        threshold: jsii.Number,
        disable_health_status_reporting: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        duration: typing.Optional[jsii.Number] = None,
        operator: typing.Optional[builtins.str] = None,
        prediction: typing.Optional[typing.Union["NrqlAlertConditionWarningPrediction", typing.Dict[builtins.str, typing.Any]]] = None,
        threshold_duration: typing.Optional[jsii.Number] = None,
        threshold_occurrences: typing.Optional[builtins.str] = None,
        time_function: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param threshold: For baseline conditions must be in range [1, 1000]. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#threshold NrqlAlertCondition#threshold}
        :param disable_health_status_reporting: Violations will not change system health status for this term. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#disable_health_status_reporting NrqlAlertCondition#disable_health_status_reporting}
        :param duration: In minutes, must be in the range of 1 to 120 (inclusive). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#duration NrqlAlertCondition#duration}
        :param operator: One of (above, above_or_equals, below, below_or_equals, equals, not_equals). Defaults to 'equals'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#operator NrqlAlertCondition#operator}
        :param prediction: prediction block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#prediction NrqlAlertCondition#prediction}
        :param threshold_duration: The duration, in seconds, that the threshold must violate in order to create an incident. Value must be a multiple of the 'aggregation_window' (which has a default of 60 seconds). Value must be within 120-86400 seconds for baseline conditions, and within 60-86400 seconds for static conditions Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#threshold_duration NrqlAlertCondition#threshold_duration}
        :param threshold_occurrences: The criteria for how many data points must be in violation for the specified threshold duration. Valid values are: 'ALL' or 'AT_LEAST_ONCE' (case insensitive). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#threshold_occurrences NrqlAlertCondition#threshold_occurrences}
        :param time_function: Valid values are: 'all' or 'any'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#time_function NrqlAlertCondition#time_function}
        '''
        if isinstance(prediction, dict):
            prediction = NrqlAlertConditionWarningPrediction(**prediction)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e967137d2b85f57b871cea500e48c3f9c2aa9f597d4c5f6eef2b3b94f301d447)
            check_type(argname="argument threshold", value=threshold, expected_type=type_hints["threshold"])
            check_type(argname="argument disable_health_status_reporting", value=disable_health_status_reporting, expected_type=type_hints["disable_health_status_reporting"])
            check_type(argname="argument duration", value=duration, expected_type=type_hints["duration"])
            check_type(argname="argument operator", value=operator, expected_type=type_hints["operator"])
            check_type(argname="argument prediction", value=prediction, expected_type=type_hints["prediction"])
            check_type(argname="argument threshold_duration", value=threshold_duration, expected_type=type_hints["threshold_duration"])
            check_type(argname="argument threshold_occurrences", value=threshold_occurrences, expected_type=type_hints["threshold_occurrences"])
            check_type(argname="argument time_function", value=time_function, expected_type=type_hints["time_function"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "threshold": threshold,
        }
        if disable_health_status_reporting is not None:
            self._values["disable_health_status_reporting"] = disable_health_status_reporting
        if duration is not None:
            self._values["duration"] = duration
        if operator is not None:
            self._values["operator"] = operator
        if prediction is not None:
            self._values["prediction"] = prediction
        if threshold_duration is not None:
            self._values["threshold_duration"] = threshold_duration
        if threshold_occurrences is not None:
            self._values["threshold_occurrences"] = threshold_occurrences
        if time_function is not None:
            self._values["time_function"] = time_function

    @builtins.property
    def threshold(self) -> jsii.Number:
        '''For baseline conditions must be in range [1, 1000].

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#threshold NrqlAlertCondition#threshold}
        '''
        result = self._values.get("threshold")
        assert result is not None, "Required property 'threshold' is missing"
        return typing.cast(jsii.Number, result)

    @builtins.property
    def disable_health_status_reporting(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Violations will not change system health status for this term.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#disable_health_status_reporting NrqlAlertCondition#disable_health_status_reporting}
        '''
        result = self._values.get("disable_health_status_reporting")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def duration(self) -> typing.Optional[jsii.Number]:
        '''In minutes, must be in the range of 1 to 120 (inclusive).

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#duration NrqlAlertCondition#duration}
        '''
        result = self._values.get("duration")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def operator(self) -> typing.Optional[builtins.str]:
        '''One of (above, above_or_equals, below, below_or_equals, equals, not_equals). Defaults to 'equals'.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#operator NrqlAlertCondition#operator}
        '''
        result = self._values.get("operator")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def prediction(self) -> typing.Optional["NrqlAlertConditionWarningPrediction"]:
        '''prediction block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#prediction NrqlAlertCondition#prediction}
        '''
        result = self._values.get("prediction")
        return typing.cast(typing.Optional["NrqlAlertConditionWarningPrediction"], result)

    @builtins.property
    def threshold_duration(self) -> typing.Optional[jsii.Number]:
        '''The duration, in seconds, that the threshold must violate in order to create an incident.

        Value must be a multiple of the 'aggregation_window' (which has a default of 60 seconds). Value must be within 120-86400 seconds for baseline conditions, and within 60-86400 seconds for static conditions

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#threshold_duration NrqlAlertCondition#threshold_duration}
        '''
        result = self._values.get("threshold_duration")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def threshold_occurrences(self) -> typing.Optional[builtins.str]:
        '''The criteria for how many data points must be in violation for the specified threshold duration.

        Valid values are: 'ALL' or 'AT_LEAST_ONCE' (case insensitive).

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#threshold_occurrences NrqlAlertCondition#threshold_occurrences}
        '''
        result = self._values.get("threshold_occurrences")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def time_function(self) -> typing.Optional[builtins.str]:
        '''Valid values are: 'all' or 'any'.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#time_function NrqlAlertCondition#time_function}
        '''
        result = self._values.get("time_function")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "NrqlAlertConditionWarning(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class NrqlAlertConditionWarningOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.nrqlAlertCondition.NrqlAlertConditionWarningOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fcb765864ec03641ad25dcfdd38e424baf12d1b8df8e50066adf79ac638e1fdf)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putPrediction")
    def put_prediction(
        self,
        *,
        predict_by: typing.Optional[jsii.Number] = None,
        prefer_prediction_violation: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    ) -> None:
        '''
        :param predict_by: BETA PREVIEW: the ``predict_by`` field is in limited release and only enabled for preview on a per-account basis. - The duration, in seconds, that the prediction should look into the future. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#predict_by NrqlAlertCondition#predict_by}
        :param prefer_prediction_violation: BETA PREVIEW: the ``prefer_prediction_violation`` field is in limited release and only enabled for preview on a per-account basis. - If a prediction incident is open when a term's static threshold is breached by the actual signal, default behavior is to close the prediction incident and open a static incident. Setting ``prefer_prediction_violation`` to ``true`` overrides this behavior leaving the prediction incident open and preventing a static incident from opening. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#prefer_prediction_violation NrqlAlertCondition#prefer_prediction_violation}
        '''
        value = NrqlAlertConditionWarningPrediction(
            predict_by=predict_by,
            prefer_prediction_violation=prefer_prediction_violation,
        )

        return typing.cast(None, jsii.invoke(self, "putPrediction", [value]))

    @jsii.member(jsii_name="resetDisableHealthStatusReporting")
    def reset_disable_health_status_reporting(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDisableHealthStatusReporting", []))

    @jsii.member(jsii_name="resetDuration")
    def reset_duration(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDuration", []))

    @jsii.member(jsii_name="resetOperator")
    def reset_operator(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOperator", []))

    @jsii.member(jsii_name="resetPrediction")
    def reset_prediction(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPrediction", []))

    @jsii.member(jsii_name="resetThresholdDuration")
    def reset_threshold_duration(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetThresholdDuration", []))

    @jsii.member(jsii_name="resetThresholdOccurrences")
    def reset_threshold_occurrences(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetThresholdOccurrences", []))

    @jsii.member(jsii_name="resetTimeFunction")
    def reset_time_function(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTimeFunction", []))

    @builtins.property
    @jsii.member(jsii_name="prediction")
    def prediction(self) -> "NrqlAlertConditionWarningPredictionOutputReference":
        return typing.cast("NrqlAlertConditionWarningPredictionOutputReference", jsii.get(self, "prediction"))

    @builtins.property
    @jsii.member(jsii_name="disableHealthStatusReportingInput")
    def disable_health_status_reporting_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "disableHealthStatusReportingInput"))

    @builtins.property
    @jsii.member(jsii_name="durationInput")
    def duration_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "durationInput"))

    @builtins.property
    @jsii.member(jsii_name="operatorInput")
    def operator_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "operatorInput"))

    @builtins.property
    @jsii.member(jsii_name="predictionInput")
    def prediction_input(
        self,
    ) -> typing.Optional["NrqlAlertConditionWarningPrediction"]:
        return typing.cast(typing.Optional["NrqlAlertConditionWarningPrediction"], jsii.get(self, "predictionInput"))

    @builtins.property
    @jsii.member(jsii_name="thresholdDurationInput")
    def threshold_duration_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "thresholdDurationInput"))

    @builtins.property
    @jsii.member(jsii_name="thresholdInput")
    def threshold_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "thresholdInput"))

    @builtins.property
    @jsii.member(jsii_name="thresholdOccurrencesInput")
    def threshold_occurrences_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "thresholdOccurrencesInput"))

    @builtins.property
    @jsii.member(jsii_name="timeFunctionInput")
    def time_function_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "timeFunctionInput"))

    @builtins.property
    @jsii.member(jsii_name="disableHealthStatusReporting")
    def disable_health_status_reporting(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "disableHealthStatusReporting"))

    @disable_health_status_reporting.setter
    def disable_health_status_reporting(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9d963e7f8a197f714d8eba2e55a025cdea54f0cf9e92f2cca08abe3bd3a73b5e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "disableHealthStatusReporting", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="duration")
    def duration(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "duration"))

    @duration.setter
    def duration(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__11ca4f8d8db31e99ed6337a33ea047be8ff33907b668399e67df7b12d216326f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "duration", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operator")
    def operator(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "operator"))

    @operator.setter
    def operator(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__80a51434fb32662e9be179760109d4365b153833594eba75e304f3e3b0eb8466)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operator", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="threshold")
    def threshold(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "threshold"))

    @threshold.setter
    def threshold(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__38061671382db99efd8f6242d7490d2fced4789bdff3f326e116f9d8e3950a24)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "threshold", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="thresholdDuration")
    def threshold_duration(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "thresholdDuration"))

    @threshold_duration.setter
    def threshold_duration(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3cb00f61b76c7ffecd953f58838ae13fbfae06a816aaf8d281ab9e8bc5142533)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "thresholdDuration", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="thresholdOccurrences")
    def threshold_occurrences(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "thresholdOccurrences"))

    @threshold_occurrences.setter
    def threshold_occurrences(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6bfb348ed12d119fb280eb16d2429e7a537d221305054ec30188a6e772cb3f16)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "thresholdOccurrences", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="timeFunction")
    def time_function(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "timeFunction"))

    @time_function.setter
    def time_function(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7c6a701bba1a82708c8654f05113cf1a15360f5ec0782cd7435be36252bebf46)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "timeFunction", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[NrqlAlertConditionWarning]:
        return typing.cast(typing.Optional[NrqlAlertConditionWarning], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(self, value: typing.Optional[NrqlAlertConditionWarning]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bc6baf88bb30df7eccec854887666378bd7f74f294582c49b7b43f64c51af8b8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.nrqlAlertCondition.NrqlAlertConditionWarningPrediction",
    jsii_struct_bases=[],
    name_mapping={
        "predict_by": "predictBy",
        "prefer_prediction_violation": "preferPredictionViolation",
    },
)
class NrqlAlertConditionWarningPrediction:
    def __init__(
        self,
        *,
        predict_by: typing.Optional[jsii.Number] = None,
        prefer_prediction_violation: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    ) -> None:
        '''
        :param predict_by: BETA PREVIEW: the ``predict_by`` field is in limited release and only enabled for preview on a per-account basis. - The duration, in seconds, that the prediction should look into the future. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#predict_by NrqlAlertCondition#predict_by}
        :param prefer_prediction_violation: BETA PREVIEW: the ``prefer_prediction_violation`` field is in limited release and only enabled for preview on a per-account basis. - If a prediction incident is open when a term's static threshold is breached by the actual signal, default behavior is to close the prediction incident and open a static incident. Setting ``prefer_prediction_violation`` to ``true`` overrides this behavior leaving the prediction incident open and preventing a static incident from opening. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#prefer_prediction_violation NrqlAlertCondition#prefer_prediction_violation}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8e380bfb6a859e342882cf04598f93affaadd4c619d2019ecd6462fd54fa2fca)
            check_type(argname="argument predict_by", value=predict_by, expected_type=type_hints["predict_by"])
            check_type(argname="argument prefer_prediction_violation", value=prefer_prediction_violation, expected_type=type_hints["prefer_prediction_violation"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if predict_by is not None:
            self._values["predict_by"] = predict_by
        if prefer_prediction_violation is not None:
            self._values["prefer_prediction_violation"] = prefer_prediction_violation

    @builtins.property
    def predict_by(self) -> typing.Optional[jsii.Number]:
        '''BETA PREVIEW: the ``predict_by`` field is in limited release and only enabled for preview on a per-account basis.

        - The duration, in seconds, that the prediction should look into the future.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#predict_by NrqlAlertCondition#predict_by}
        '''
        result = self._values.get("predict_by")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def prefer_prediction_violation(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''BETA PREVIEW: the ``prefer_prediction_violation`` field is in limited release and only enabled for preview on a per-account basis.

        - If a prediction incident is open when a term's static threshold is breached by the actual signal, default behavior is to close the prediction incident and open a static incident. Setting ``prefer_prediction_violation`` to ``true`` overrides this behavior leaving the prediction incident open and preventing a static incident from opening.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/nrql_alert_condition#prefer_prediction_violation NrqlAlertCondition#prefer_prediction_violation}
        '''
        result = self._values.get("prefer_prediction_violation")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "NrqlAlertConditionWarningPrediction(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class NrqlAlertConditionWarningPredictionOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.nrqlAlertCondition.NrqlAlertConditionWarningPredictionOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__dd773ea6a1687a804a4adc4df40c43d13bebebef7f34677df03f451cf5105b5e)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetPredictBy")
    def reset_predict_by(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPredictBy", []))

    @jsii.member(jsii_name="resetPreferPredictionViolation")
    def reset_prefer_prediction_violation(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPreferPredictionViolation", []))

    @builtins.property
    @jsii.member(jsii_name="predictByInput")
    def predict_by_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "predictByInput"))

    @builtins.property
    @jsii.member(jsii_name="preferPredictionViolationInput")
    def prefer_prediction_violation_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "preferPredictionViolationInput"))

    @builtins.property
    @jsii.member(jsii_name="predictBy")
    def predict_by(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "predictBy"))

    @predict_by.setter
    def predict_by(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a35797cdece2b9c6dcecb422c2569b8f11bbf2c9af83d8a6fea431ee5a65b63c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "predictBy", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="preferPredictionViolation")
    def prefer_prediction_violation(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "preferPredictionViolation"))

    @prefer_prediction_violation.setter
    def prefer_prediction_violation(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__91920a3f2beb344656e9943fe5403125bff888be0719d43e685102ded3554042)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "preferPredictionViolation", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[NrqlAlertConditionWarningPrediction]:
        return typing.cast(typing.Optional[NrqlAlertConditionWarningPrediction], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[NrqlAlertConditionWarningPrediction],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__501309441c3b1ff44dfbc9622b769c96cf13faf848bb2d112b0100680639c7b0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


__all__ = [
    "NrqlAlertCondition",
    "NrqlAlertConditionConfig",
    "NrqlAlertConditionCritical",
    "NrqlAlertConditionCriticalOutputReference",
    "NrqlAlertConditionCriticalPrediction",
    "NrqlAlertConditionCriticalPredictionOutputReference",
    "NrqlAlertConditionNrql",
    "NrqlAlertConditionNrqlOutputReference",
    "NrqlAlertConditionOutlierConfiguration",
    "NrqlAlertConditionOutlierConfigurationDbscan",
    "NrqlAlertConditionOutlierConfigurationDbscanOutputReference",
    "NrqlAlertConditionOutlierConfigurationOutputReference",
    "NrqlAlertConditionTerm",
    "NrqlAlertConditionTermList",
    "NrqlAlertConditionTermOutputReference",
    "NrqlAlertConditionTermPrediction",
    "NrqlAlertConditionTermPredictionOutputReference",
    "NrqlAlertConditionTimeouts",
    "NrqlAlertConditionTimeoutsOutputReference",
    "NrqlAlertConditionWarning",
    "NrqlAlertConditionWarningOutputReference",
    "NrqlAlertConditionWarningPrediction",
    "NrqlAlertConditionWarningPredictionOutputReference",
]

publication.publish()

def _typecheckingstub__95a540cc8650063bf33e8fbdf7365f3313036931733ae93fb851494e75d27a97(
    scope: _constructs_77d1e7e8.Construct,
    id_: builtins.str,
    *,
    name: builtins.str,
    nrql: typing.Union[NrqlAlertConditionNrql, typing.Dict[builtins.str, typing.Any]],
    policy_id: jsii.Number,
    account_id: typing.Optional[jsii.Number] = None,
    aggregation_delay: typing.Optional[builtins.str] = None,
    aggregation_method: typing.Optional[builtins.str] = None,
    aggregation_timer: typing.Optional[builtins.str] = None,
    aggregation_window: typing.Optional[jsii.Number] = None,
    baseline_direction: typing.Optional[builtins.str] = None,
    close_violations_on_expiration: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    critical: typing.Optional[typing.Union[NrqlAlertConditionCritical, typing.Dict[builtins.str, typing.Any]]] = None,
    description: typing.Optional[builtins.str] = None,
    enabled: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    evaluation_delay: typing.Optional[jsii.Number] = None,
    expiration_duration: typing.Optional[jsii.Number] = None,
    fill_option: typing.Optional[builtins.str] = None,
    fill_value: typing.Optional[jsii.Number] = None,
    id: typing.Optional[builtins.str] = None,
    ignore_on_expected_termination: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    open_violation_on_expiration: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    outlier_configuration: typing.Optional[typing.Union[NrqlAlertConditionOutlierConfiguration, typing.Dict[builtins.str, typing.Any]]] = None,
    runbook_url: typing.Optional[builtins.str] = None,
    signal_seasonality: typing.Optional[builtins.str] = None,
    slide_by: typing.Optional[jsii.Number] = None,
    target_entity: typing.Optional[builtins.str] = None,
    term: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[NrqlAlertConditionTerm, typing.Dict[builtins.str, typing.Any]]]]] = None,
    timeouts: typing.Optional[typing.Union[NrqlAlertConditionTimeouts, typing.Dict[builtins.str, typing.Any]]] = None,
    title_template: typing.Optional[builtins.str] = None,
    type: typing.Optional[builtins.str] = None,
    violation_time_limit: typing.Optional[builtins.str] = None,
    violation_time_limit_seconds: typing.Optional[jsii.Number] = None,
    warning: typing.Optional[typing.Union[NrqlAlertConditionWarning, typing.Dict[builtins.str, typing.Any]]] = None,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ee490c911bdb19557d8e51372b4f7c3b877189bd409883ab742f34bec343bb2f(
    scope: _constructs_77d1e7e8.Construct,
    import_to_id: builtins.str,
    import_from_id: builtins.str,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__20015e238bf0aec599a01ff19948eeac03262d48bcbd5023378933e0f334c980(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[NrqlAlertConditionTerm, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c3119da889de282307dfe9c24de24d09ea76e48cb691fd7e43d31c52dcf3e1ce(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__46e075e066ca0a472db69ce090d3f69302d39c8fd83a12c8ae3c8c0150732c0f(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a6a5786e008ac2a91694db025866dbbce076c910388c48d966f0fbf6552d1c92(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7a93660c8bbdc06cc635656ab37d6e0a808eef4995d667f92e8f1614c3675196(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c5cfeddd94144ab8d140497786a2d46af69c4ca142a6acae649299d21fd1faef(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__50c514d4847f6ad602b547ed66d519d27d3a0b8631454954dc94d3750826231b(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1a73664c2e30e1e7814d312be8944b890d56c7b5052dfc1d5c189bd6cf3fdcca(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fae3d7700f19fc6af2f9907696055116d5ff7254deb3d26d615e3399762a3a6b(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__692fc4406773b62c40b30123379fcfc30304b583b89f80937b8bd769c0c7d74c(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__566e267f68dcba7986fd53c41f3ee694c468774a7894be664edece1d0e4474bc(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__94a1544c52a3883fc973b2eedec1e1bbef7dbf42bc7c624cfaf30b2caf7b325e(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bf30755d24c53b95677388a1a18842142e7a763afa8164acee55381c0da3260e(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__40b58d5b65aa0e1147bafc8c85334e9880cb894455864f7094f4eedc8c65f272(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e23230b61248ee0315eb0540e9d89c43bd401f77cbd535ae0853dd662d352efe(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ccf34e43b47986261574a9afc3cac55a1ec5cbaa7de99df3db0eb111c87723ce(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__47fcee801258fdf7ddfc21f947405087befd2214d49c0a03387edbeaf53cfcbe(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6c091cc9b75d08d3d0006324685cc8794314f4c3c06490b5bfe9780aa9ab1a90(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__69c1345e8901a0713c1918e3f5557110f3c50e736a5b5f26c48b4571ebfadf29(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__00839ba6176d59ddfb179a1e76a66950cee67cc230d14b287c8d750bdcf5e460(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__333e02607190ad4f1abbdc86221a310c511c749377695d60d619392bdd355074(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9c9518147346ebd876bd4ab19e759d0270c0f27a33b6839cda3bf3f8e783145b(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__72c20bbf618e7d783265106ad43daa7b28359d9a2166d552c2de5e9bda2c2217(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5f76e9dd4e16b305c7a597c481c2cfe75ffe57dea47bb482bc1a5b6d3399cd93(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1778d1eee226b845d8b2e6f68e971a582481baf3525f49bab520d9defd3a9bc3(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__717c16f358cc0ab02342c0ae8a1f27daa3d7c03b8907ed681a5c4a62c513f26e(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__98a8803f319a230828e131932f5bd927ac603568d8da5aec87f7f03edce66b28(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5ee4631d5b004ecf5bd1c30fef10ef7a523ee9df5944b277717ce44f1015cdea(
    *,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    name: builtins.str,
    nrql: typing.Union[NrqlAlertConditionNrql, typing.Dict[builtins.str, typing.Any]],
    policy_id: jsii.Number,
    account_id: typing.Optional[jsii.Number] = None,
    aggregation_delay: typing.Optional[builtins.str] = None,
    aggregation_method: typing.Optional[builtins.str] = None,
    aggregation_timer: typing.Optional[builtins.str] = None,
    aggregation_window: typing.Optional[jsii.Number] = None,
    baseline_direction: typing.Optional[builtins.str] = None,
    close_violations_on_expiration: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    critical: typing.Optional[typing.Union[NrqlAlertConditionCritical, typing.Dict[builtins.str, typing.Any]]] = None,
    description: typing.Optional[builtins.str] = None,
    enabled: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    evaluation_delay: typing.Optional[jsii.Number] = None,
    expiration_duration: typing.Optional[jsii.Number] = None,
    fill_option: typing.Optional[builtins.str] = None,
    fill_value: typing.Optional[jsii.Number] = None,
    id: typing.Optional[builtins.str] = None,
    ignore_on_expected_termination: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    open_violation_on_expiration: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    outlier_configuration: typing.Optional[typing.Union[NrqlAlertConditionOutlierConfiguration, typing.Dict[builtins.str, typing.Any]]] = None,
    runbook_url: typing.Optional[builtins.str] = None,
    signal_seasonality: typing.Optional[builtins.str] = None,
    slide_by: typing.Optional[jsii.Number] = None,
    target_entity: typing.Optional[builtins.str] = None,
    term: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[NrqlAlertConditionTerm, typing.Dict[builtins.str, typing.Any]]]]] = None,
    timeouts: typing.Optional[typing.Union[NrqlAlertConditionTimeouts, typing.Dict[builtins.str, typing.Any]]] = None,
    title_template: typing.Optional[builtins.str] = None,
    type: typing.Optional[builtins.str] = None,
    violation_time_limit: typing.Optional[builtins.str] = None,
    violation_time_limit_seconds: typing.Optional[jsii.Number] = None,
    warning: typing.Optional[typing.Union[NrqlAlertConditionWarning, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0e11bdadd688e56b61ace66f998ba22f906832c15399dfe5a4e979fa5c04050a(
    *,
    threshold: jsii.Number,
    disable_health_status_reporting: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    duration: typing.Optional[jsii.Number] = None,
    operator: typing.Optional[builtins.str] = None,
    prediction: typing.Optional[typing.Union[NrqlAlertConditionCriticalPrediction, typing.Dict[builtins.str, typing.Any]]] = None,
    threshold_duration: typing.Optional[jsii.Number] = None,
    threshold_occurrences: typing.Optional[builtins.str] = None,
    time_function: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6fa748d9227fc8f36fb2059d51d1d6975b6589522be48fe602d3952b05b32100(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d2652b9ae39f976aee9fda8f840c03b627164e01a9a087b3293bf1dd91e29ee0(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cbece5818226cb0a7ed0c4ba6f695d3db5dac48d6b5c821ca1044ce5965207e2(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6cb26b220b498f834f674218360265211541cacb67f080e5595c836a2f409794(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d8a8049ed9db83476f7c3b3064a9121558ef3b85bf093d7287f1ee3958afc745(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__029b01fdfcdadc6802ec8dadbf0287f485fe8ff61106d84f5ca58684c59c967f(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__32d0db28395b70b839d1f4aada60e1585a8fab044b198183e20b5c4809ae7b74(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__02b8b916e879d559782b46776398c0c681b3e5ed4504a836cff9281e634f152c(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1dfa3bcd6558d32d7b3adfd4f1f729b53265b09b58feb8769e940e11ea2085f7(
    value: typing.Optional[NrqlAlertConditionCritical],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b5abdaef8a740ec866aaecf222650e10aa9ee84bf954f1d4e5cc588b00667cee(
    *,
    predict_by: typing.Optional[jsii.Number] = None,
    prefer_prediction_violation: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__70ccc2e056084d3d141fdb672f3d99ea12c047cc5bb51065e55615248d3eda04(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ea99ab430be81dfc417cff3f0928f8115f5ea2b4dc498d78b8e132d53a536e2d(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__287fe47f24e8014d74033775167d96415a9730dacbb83eca6232a2c583573b10(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__eb6e3acd343f312ba2fa6657cbeae8a8b3bbc5db6d793d2399b5419845774f0e(
    value: typing.Optional[NrqlAlertConditionCriticalPrediction],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d1bb273a3917be40db18ae73718455f7ec73de222ca6484049761eb2fa422955(
    *,
    query: builtins.str,
    data_account_id: typing.Optional[jsii.Number] = None,
    evaluation_offset: typing.Optional[jsii.Number] = None,
    since_value: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cfa973b4b29259be8ec81bec79c693d31a2cb7da244a7af8e73e968202454a35(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__68a37b4461055ae8f69b8428780b20530cc0a812b6ceac0df27884c0487bd6ef(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c7bfa1bbf2773055d3413767cceb3a20e4fc658280788864621d7b734bde4ce3(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__780c32f31703c64b45be2b4675ebe28626e6ec63764070216de60fbe3a1fd762(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dbc957983599da427de4a598d4f042506738b9f5df62066dfea1a26d286ea2be(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__454502e00174eb70f8e86ede9834caf593a21a8a93cb78118c8b856c3398a872(
    value: typing.Optional[NrqlAlertConditionNrql],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a52be57545add34991fef21bf1ac258d829750afd21f7f82d3b06386d964f97c(
    *,
    dbscan: typing.Union[NrqlAlertConditionOutlierConfigurationDbscan, typing.Dict[builtins.str, typing.Any]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d95aee2740972f9d9dd5c26a03a7faef58dca702065cdf075367431a82cb49c6(
    *,
    epsilon: jsii.Number,
    minimum_points: jsii.Number,
    evaluation_group_facet: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__61b3c7418e0032ccf50b28eb57c7cd0e990e85f8c9e74d5907dc60bcd40f39b5(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1b7663a4211fb93cab6e2a5cfa22b430e2a5b9138fec5c54afa72b50d6c3ac9d(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5139d9220653c36e464fca6408570e3d5f8a4e77d99368647608e3b5f22a28ca(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bf6cf0b81394d8981e3ecea9d89be0fa73f412dc34e780c90412f0aeec4024f7(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__787dff4678b3f88979cd9ac4351334ec0d2653fd3e82be15e87407c462baa7e5(
    value: typing.Optional[NrqlAlertConditionOutlierConfigurationDbscan],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7b0fd821671674f4e7f6fcb8433d15b8ade4a341105eddb2c09ead713f0fb5cc(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ce6761f84e704ee54514fa80c390b29f0f51e72cd8b3efacdcfce04242aebf3d(
    value: typing.Optional[NrqlAlertConditionOutlierConfiguration],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__92a5fbed515deeb578f2a4b34f2cb6bf7a05dfab211ec1885702f354f2258783(
    *,
    threshold: jsii.Number,
    disable_health_status_reporting: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    duration: typing.Optional[jsii.Number] = None,
    operator: typing.Optional[builtins.str] = None,
    prediction: typing.Optional[typing.Union[NrqlAlertConditionTermPrediction, typing.Dict[builtins.str, typing.Any]]] = None,
    priority: typing.Optional[builtins.str] = None,
    threshold_duration: typing.Optional[jsii.Number] = None,
    threshold_occurrences: typing.Optional[builtins.str] = None,
    time_function: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__587ebabfe7ddf78c460a8b397255117ae39be54cc132c0240c825b592be8a744(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f7b2445a2f9ac1b58a9dbce58ed04704a471411d07152ce7f0088b233532ea2e(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a9f238e1b15c3760bbbf588740c2a02f0d3560046719bf5eac7d8f6ba419da2f(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d474505f9423ba8830afb8d7babd1b4659d3b81f087b97ee34cddd6a5faea52a(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__28cd7df6e2c52141bd0bd543f5edbcd07741422d6b79127e2ac4729c75d2ff4b(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ab2369aaa63ad70890aa98d98728ae942c62103c916271dc3f98694d76627082(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[NrqlAlertConditionTerm]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__66b60600807bddd34bd4961a8ba06c66a73fa2e4638f43363cc75be66c4a9f88(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d06131863d9932d06d366081470f823b29997d5258a13c336b005b5a5712a516(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__edaae66750732d489643679bbfb90ae0df4aeab01a041021a5e0f73cc3e37c4d(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__15fdea9be13005f76dd66064a8a4993a46115047e1f5d5a3abe2cbe3a329d218(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f9195c02ec594fa37733a244fc8f29e43077d7782ebc7a8a0a677882347197a1(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a2bbb0ba4ab650046e800d18a2e3809c633bda37c9820d06463eedc901aa4a2d(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c6b467afc3d1291265689869c473506199359eb0f664ac7e437b27bf1b3f58b2(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__76eebe53c1ef61920df39f24132140a73aca732214e9e3f3fde222823f7f568c(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e314b1e29e9f1965d8c4023d4ea7a2fbffe4d6f7290f41d6ea4023465453c0ea(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f26af64d42e0451ec772ebe511ea003b5c12e661ace6a6243ce8c39af74c080a(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, NrqlAlertConditionTerm]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__aa5127bb8601ca046ce854528052a55de5d67096e3ade8db55415420405f7149(
    *,
    predict_by: typing.Optional[jsii.Number] = None,
    prefer_prediction_violation: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6ebf2962fc6b532795fa1285263548c0b9d9540d820b21e7103f1b9ce230c620(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e9c33de09cd07a3f590e52a319593f95bc1e017ebb768de96bcfdcc09f6eae3c(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ffbc8b0ddad74094e10490dee8f078dbf57aff0004eb09e935e4c8279ced7aa2(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c59b2d55e4afe05b1854640e81644c56bab23659ed089927a58271aa1fcdcc31(
    value: typing.Optional[NrqlAlertConditionTermPrediction],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ca33ad7c5b376b21396a6d9b2024fbedad4d17318a0c50abf5872b6867ca49f2(
    *,
    create: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__76fb96e1519d39576afb5ebb4fbff9ea602098b897b7cbfef63ad01e8399b418(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e990d18ea3a76bb0d06e9f5a6b1fcd7540ae117f815da01a1a5c3fafcc7fc5d8(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__30c84676783a5c688e9bdc7ac8bb2bf4ab76c5952e0330096e49eff63aed6c99(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, NrqlAlertConditionTimeouts]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e967137d2b85f57b871cea500e48c3f9c2aa9f597d4c5f6eef2b3b94f301d447(
    *,
    threshold: jsii.Number,
    disable_health_status_reporting: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    duration: typing.Optional[jsii.Number] = None,
    operator: typing.Optional[builtins.str] = None,
    prediction: typing.Optional[typing.Union[NrqlAlertConditionWarningPrediction, typing.Dict[builtins.str, typing.Any]]] = None,
    threshold_duration: typing.Optional[jsii.Number] = None,
    threshold_occurrences: typing.Optional[builtins.str] = None,
    time_function: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fcb765864ec03641ad25dcfdd38e424baf12d1b8df8e50066adf79ac638e1fdf(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9d963e7f8a197f714d8eba2e55a025cdea54f0cf9e92f2cca08abe3bd3a73b5e(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__11ca4f8d8db31e99ed6337a33ea047be8ff33907b668399e67df7b12d216326f(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__80a51434fb32662e9be179760109d4365b153833594eba75e304f3e3b0eb8466(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__38061671382db99efd8f6242d7490d2fced4789bdff3f326e116f9d8e3950a24(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3cb00f61b76c7ffecd953f58838ae13fbfae06a816aaf8d281ab9e8bc5142533(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6bfb348ed12d119fb280eb16d2429e7a537d221305054ec30188a6e772cb3f16(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7c6a701bba1a82708c8654f05113cf1a15360f5ec0782cd7435be36252bebf46(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bc6baf88bb30df7eccec854887666378bd7f74f294582c49b7b43f64c51af8b8(
    value: typing.Optional[NrqlAlertConditionWarning],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8e380bfb6a859e342882cf04598f93affaadd4c619d2019ecd6462fd54fa2fca(
    *,
    predict_by: typing.Optional[jsii.Number] = None,
    prefer_prediction_violation: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dd773ea6a1687a804a4adc4df40c43d13bebebef7f34677df03f451cf5105b5e(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a35797cdece2b9c6dcecb422c2569b8f11bbf2c9af83d8a6fea431ee5a65b63c(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__91920a3f2beb344656e9943fe5403125bff888be0719d43e685102ded3554042(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__501309441c3b1ff44dfbc9622b769c96cf13faf848bb2d112b0100680639c7b0(
    value: typing.Optional[NrqlAlertConditionWarningPrediction],
) -> None:
    """Type checking stubs"""
    pass
