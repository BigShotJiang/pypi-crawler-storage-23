r'''
# `newrelic_workload`

Refer to the Terraform Registry for docs: [`newrelic_workload`](https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload).
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import cdktn as _cdktn_78ede62e
import constructs as _constructs_77d1e7e8


class Workload(
    _cdktn_78ede62e.TerraformResource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.workload.Workload",
):
    '''Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload newrelic_workload}.'''

    def __init__(
        self,
        scope: _constructs_77d1e7e8.Construct,
        id_: builtins.str,
        *,
        name: builtins.str,
        account_id: typing.Optional[jsii.Number] = None,
        description: typing.Optional[builtins.str] = None,
        entity_guids: typing.Optional[typing.Sequence[builtins.str]] = None,
        entity_search_query: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["WorkloadEntitySearchQuery", typing.Dict[builtins.str, typing.Any]]]]] = None,
        id: typing.Optional[builtins.str] = None,
        scope_account_ids: typing.Optional[typing.Sequence[jsii.Number]] = None,
        status_config_automatic: typing.Optional[typing.Union["WorkloadStatusConfigAutomatic", typing.Dict[builtins.str, typing.Any]]] = None,
        status_config_static: typing.Optional[typing.Union["WorkloadStatusConfigStatic", typing.Dict[builtins.str, typing.Any]]] = None,
        connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload newrelic_workload} Resource.

        :param scope: The scope in which to define this construct.
        :param id_: The scoped construct ID. Must be unique amongst siblings in the same scope
        :param name: The workload's name. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#name Workload#name}
        :param account_id: The New Relic account ID where you want to create the workload. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#account_id Workload#account_id}
        :param description: Relevant information about the workload. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#description Workload#description}
        :param entity_guids: A list of entity GUIDs manually assigned to this workload. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#entity_guids Workload#entity_guids}
        :param entity_search_query: entity_search_query block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#entity_search_query Workload#entity_search_query}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#id Workload#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param scope_account_ids: A list of account IDs that will be used to get entities from. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#scope_account_ids Workload#scope_account_ids}
        :param status_config_automatic: status_config_automatic block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#status_config_automatic Workload#status_config_automatic}
        :param status_config_static: status_config_static block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#status_config_static Workload#status_config_static}
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__01a617bbe7989ea5f878c1f156a2ac94a5977f060d5a5307a0bd9d5e906c39b3)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id_", value=id_, expected_type=type_hints["id_"])
        config = WorkloadConfig(
            name=name,
            account_id=account_id,
            description=description,
            entity_guids=entity_guids,
            entity_search_query=entity_search_query,
            id=id,
            scope_account_ids=scope_account_ids,
            status_config_automatic=status_config_automatic,
            status_config_static=status_config_static,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        jsii.create(self.__class__, self, [scope, id_, config])

    @jsii.member(jsii_name="generateConfigForImport")
    @builtins.classmethod
    def generate_config_for_import(
        cls,
        scope: _constructs_77d1e7e8.Construct,
        import_to_id: builtins.str,
        import_from_id: builtins.str,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    ) -> _cdktn_78ede62e.ImportableResource:
        '''Generates CDKTN code for importing a Workload resource upon running "cdktn plan ".

        :param scope: The scope in which to define this construct.
        :param import_to_id: The construct id used in the generated config for the Workload to import.
        :param import_from_id: The id of the existing Workload that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#import import section} in the documentation of this resource for the id to use
        :param provider: ? Optional instance of the provider where the Workload to import is found.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__82935d61c603d60c47768d13b03451b056b74251fe2ef9f911f634323d7795eb)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument import_to_id", value=import_to_id, expected_type=type_hints["import_to_id"])
            check_type(argname="argument import_from_id", value=import_from_id, expected_type=type_hints["import_from_id"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
        return typing.cast(_cdktn_78ede62e.ImportableResource, jsii.sinvoke(cls, "generateConfigForImport", [scope, import_to_id, import_from_id, provider]))

    @jsii.member(jsii_name="putEntitySearchQuery")
    def put_entity_search_query(
        self,
        value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["WorkloadEntitySearchQuery", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__559d030b898e312b3ff58645e7082df658bcccfdf199df1da108d942f24d1985)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putEntitySearchQuery", [value]))

    @jsii.member(jsii_name="putStatusConfigAutomatic")
    def put_status_config_automatic(
        self,
        *,
        enabled: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
        remaining_entities_rule: typing.Optional[typing.Union["WorkloadStatusConfigAutomaticRemainingEntitiesRule", typing.Dict[builtins.str, typing.Any]]] = None,
        rule: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["WorkloadStatusConfigAutomaticRule", typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''
        :param enabled: Whether the automatic status configuration is enabled or not. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#enabled Workload#enabled}
        :param remaining_entities_rule: remaining_entities_rule block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#remaining_entities_rule Workload#remaining_entities_rule}
        :param rule: rule block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#rule Workload#rule}
        '''
        value = WorkloadStatusConfigAutomatic(
            enabled=enabled, remaining_entities_rule=remaining_entities_rule, rule=rule
        )

        return typing.cast(None, jsii.invoke(self, "putStatusConfigAutomatic", [value]))

    @jsii.member(jsii_name="putStatusConfigStatic")
    def put_status_config_static(
        self,
        *,
        enabled: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
        status: builtins.str,
        description: typing.Optional[builtins.str] = None,
        summary: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param enabled: Whether the static status configuration is enabled or not. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#enabled Workload#enabled}
        :param status: The status of the workload. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#status Workload#status}
        :param description: A description that provides additional details about the status of the workload. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#description Workload#description}
        :param summary: A short description of the status of the workload. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#summary Workload#summary}
        '''
        value = WorkloadStatusConfigStatic(
            enabled=enabled, status=status, description=description, summary=summary
        )

        return typing.cast(None, jsii.invoke(self, "putStatusConfigStatic", [value]))

    @jsii.member(jsii_name="resetAccountId")
    def reset_account_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAccountId", []))

    @jsii.member(jsii_name="resetDescription")
    def reset_description(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDescription", []))

    @jsii.member(jsii_name="resetEntityGuids")
    def reset_entity_guids(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEntityGuids", []))

    @jsii.member(jsii_name="resetEntitySearchQuery")
    def reset_entity_search_query(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEntitySearchQuery", []))

    @jsii.member(jsii_name="resetId")
    def reset_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetId", []))

    @jsii.member(jsii_name="resetScopeAccountIds")
    def reset_scope_account_ids(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetScopeAccountIds", []))

    @jsii.member(jsii_name="resetStatusConfigAutomatic")
    def reset_status_config_automatic(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetStatusConfigAutomatic", []))

    @jsii.member(jsii_name="resetStatusConfigStatic")
    def reset_status_config_static(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetStatusConfigStatic", []))

    @jsii.member(jsii_name="synthesizeAttributes")
    def _synthesize_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeAttributes", []))

    @jsii.member(jsii_name="synthesizeHclAttributes")
    def _synthesize_hcl_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeHclAttributes", []))

    @jsii.python.classproperty
    @jsii.member(jsii_name="tfResourceType")
    def TF_RESOURCE_TYPE(cls) -> builtins.str:
        return typing.cast(builtins.str, jsii.sget(cls, "tfResourceType"))

    @builtins.property
    @jsii.member(jsii_name="compositeEntitySearchQuery")
    def composite_entity_search_query(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "compositeEntitySearchQuery"))

    @builtins.property
    @jsii.member(jsii_name="entitySearchQuery")
    def entity_search_query(self) -> "WorkloadEntitySearchQueryList":
        return typing.cast("WorkloadEntitySearchQueryList", jsii.get(self, "entitySearchQuery"))

    @builtins.property
    @jsii.member(jsii_name="guid")
    def guid(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "guid"))

    @builtins.property
    @jsii.member(jsii_name="permalink")
    def permalink(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "permalink"))

    @builtins.property
    @jsii.member(jsii_name="statusConfigAutomatic")
    def status_config_automatic(self) -> "WorkloadStatusConfigAutomaticOutputReference":
        return typing.cast("WorkloadStatusConfigAutomaticOutputReference", jsii.get(self, "statusConfigAutomatic"))

    @builtins.property
    @jsii.member(jsii_name="statusConfigStatic")
    def status_config_static(self) -> "WorkloadStatusConfigStaticOutputReference":
        return typing.cast("WorkloadStatusConfigStaticOutputReference", jsii.get(self, "statusConfigStatic"))

    @builtins.property
    @jsii.member(jsii_name="workloadId")
    def workload_id(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "workloadId"))

    @builtins.property
    @jsii.member(jsii_name="accountIdInput")
    def account_id_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "accountIdInput"))

    @builtins.property
    @jsii.member(jsii_name="descriptionInput")
    def description_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "descriptionInput"))

    @builtins.property
    @jsii.member(jsii_name="entityGuidsInput")
    def entity_guids_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "entityGuidsInput"))

    @builtins.property
    @jsii.member(jsii_name="entitySearchQueryInput")
    def entity_search_query_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["WorkloadEntitySearchQuery"]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["WorkloadEntitySearchQuery"]]], jsii.get(self, "entitySearchQueryInput"))

    @builtins.property
    @jsii.member(jsii_name="idInput")
    def id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "idInput"))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="scopeAccountIdsInput")
    def scope_account_ids_input(self) -> typing.Optional[typing.List[jsii.Number]]:
        return typing.cast(typing.Optional[typing.List[jsii.Number]], jsii.get(self, "scopeAccountIdsInput"))

    @builtins.property
    @jsii.member(jsii_name="statusConfigAutomaticInput")
    def status_config_automatic_input(
        self,
    ) -> typing.Optional["WorkloadStatusConfigAutomatic"]:
        return typing.cast(typing.Optional["WorkloadStatusConfigAutomatic"], jsii.get(self, "statusConfigAutomaticInput"))

    @builtins.property
    @jsii.member(jsii_name="statusConfigStaticInput")
    def status_config_static_input(
        self,
    ) -> typing.Optional["WorkloadStatusConfigStatic"]:
        return typing.cast(typing.Optional["WorkloadStatusConfigStatic"], jsii.get(self, "statusConfigStaticInput"))

    @builtins.property
    @jsii.member(jsii_name="accountId")
    def account_id(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "accountId"))

    @account_id.setter
    def account_id(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a081dc3f50c87436f6aaa016c04c02632c974aa6006d3fac1a77441018eb9e03)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "accountId", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="description")
    def description(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "description"))

    @description.setter
    def description(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__088a40317ebcf089ea5db07856923f953a37558bf262db9a6bd8c6cc6447dfb2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "description", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="entityGuids")
    def entity_guids(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "entityGuids"))

    @entity_guids.setter
    def entity_guids(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1dd6b661758a123714cb557494efd8bed50eae2d932cc3784c717ebafaa8d900)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "entityGuids", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @id.setter
    def id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a1913675f5b5182ebe71007a11f9a1948d346af0c972f1383f20317c9fe7cbea)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "id", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__92fb6ae847f7d66ba12cbe6887b8243229331a2e8b977aee2aea876fb402af2d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="scopeAccountIds")
    def scope_account_ids(self) -> typing.List[jsii.Number]:
        return typing.cast(typing.List[jsii.Number], jsii.get(self, "scopeAccountIds"))

    @scope_account_ids.setter
    def scope_account_ids(self, value: typing.List[jsii.Number]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4e6d61a9b1654c8d14054f788f3f8b594e99e93c68028e48a45ba6adecab68dc)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "scopeAccountIds", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.workload.WorkloadConfig",
    jsii_struct_bases=[_cdktn_78ede62e.TerraformMetaArguments],
    name_mapping={
        "connection": "connection",
        "count": "count",
        "depends_on": "dependsOn",
        "for_each": "forEach",
        "lifecycle": "lifecycle",
        "provider": "provider",
        "provisioners": "provisioners",
        "name": "name",
        "account_id": "accountId",
        "description": "description",
        "entity_guids": "entityGuids",
        "entity_search_query": "entitySearchQuery",
        "id": "id",
        "scope_account_ids": "scopeAccountIds",
        "status_config_automatic": "statusConfigAutomatic",
        "status_config_static": "statusConfigStatic",
    },
)
class WorkloadConfig(_cdktn_78ede62e.TerraformMetaArguments):
    def __init__(
        self,
        *,
        connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
        name: builtins.str,
        account_id: typing.Optional[jsii.Number] = None,
        description: typing.Optional[builtins.str] = None,
        entity_guids: typing.Optional[typing.Sequence[builtins.str]] = None,
        entity_search_query: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["WorkloadEntitySearchQuery", typing.Dict[builtins.str, typing.Any]]]]] = None,
        id: typing.Optional[builtins.str] = None,
        scope_account_ids: typing.Optional[typing.Sequence[jsii.Number]] = None,
        status_config_automatic: typing.Optional[typing.Union["WorkloadStatusConfigAutomatic", typing.Dict[builtins.str, typing.Any]]] = None,
        status_config_static: typing.Optional[typing.Union["WorkloadStatusConfigStatic", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        :param name: The workload's name. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#name Workload#name}
        :param account_id: The New Relic account ID where you want to create the workload. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#account_id Workload#account_id}
        :param description: Relevant information about the workload. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#description Workload#description}
        :param entity_guids: A list of entity GUIDs manually assigned to this workload. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#entity_guids Workload#entity_guids}
        :param entity_search_query: entity_search_query block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#entity_search_query Workload#entity_search_query}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#id Workload#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param scope_account_ids: A list of account IDs that will be used to get entities from. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#scope_account_ids Workload#scope_account_ids}
        :param status_config_automatic: status_config_automatic block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#status_config_automatic Workload#status_config_automatic}
        :param status_config_static: status_config_static block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#status_config_static Workload#status_config_static}
        '''
        if isinstance(lifecycle, dict):
            lifecycle = _cdktn_78ede62e.TerraformResourceLifecycle(**lifecycle)
        if isinstance(status_config_automatic, dict):
            status_config_automatic = WorkloadStatusConfigAutomatic(**status_config_automatic)
        if isinstance(status_config_static, dict):
            status_config_static = WorkloadStatusConfigStatic(**status_config_static)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__dfaf27131d7fbd22444dc861c45066ea5143dbbe75ddf036f751777630d0e924)
            check_type(argname="argument connection", value=connection, expected_type=type_hints["connection"])
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument for_each", value=for_each, expected_type=type_hints["for_each"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
            check_type(argname="argument provisioners", value=provisioners, expected_type=type_hints["provisioners"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument account_id", value=account_id, expected_type=type_hints["account_id"])
            check_type(argname="argument description", value=description, expected_type=type_hints["description"])
            check_type(argname="argument entity_guids", value=entity_guids, expected_type=type_hints["entity_guids"])
            check_type(argname="argument entity_search_query", value=entity_search_query, expected_type=type_hints["entity_search_query"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
            check_type(argname="argument scope_account_ids", value=scope_account_ids, expected_type=type_hints["scope_account_ids"])
            check_type(argname="argument status_config_automatic", value=status_config_automatic, expected_type=type_hints["status_config_automatic"])
            check_type(argname="argument status_config_static", value=status_config_static, expected_type=type_hints["status_config_static"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "name": name,
        }
        if connection is not None:
            self._values["connection"] = connection
        if count is not None:
            self._values["count"] = count
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if for_each is not None:
            self._values["for_each"] = for_each
        if lifecycle is not None:
            self._values["lifecycle"] = lifecycle
        if provider is not None:
            self._values["provider"] = provider
        if provisioners is not None:
            self._values["provisioners"] = provisioners
        if account_id is not None:
            self._values["account_id"] = account_id
        if description is not None:
            self._values["description"] = description
        if entity_guids is not None:
            self._values["entity_guids"] = entity_guids
        if entity_search_query is not None:
            self._values["entity_search_query"] = entity_search_query
        if id is not None:
            self._values["id"] = id
        if scope_account_ids is not None:
            self._values["scope_account_ids"] = scope_account_ids
        if status_config_automatic is not None:
            self._values["status_config_automatic"] = status_config_automatic
        if status_config_static is not None:
            self._values["status_config_static"] = status_config_static

    @builtins.property
    def connection(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, _cdktn_78ede62e.WinrmProvisionerConnection]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("connection")
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, _cdktn_78ede62e.WinrmProvisionerConnection]], result)

    @builtins.property
    def count(
        self,
    ) -> typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("count")
        return typing.cast(typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]], result)

    @builtins.property
    def depends_on(
        self,
    ) -> typing.Optional[typing.List[_cdktn_78ede62e.ITerraformDependable]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List[_cdktn_78ede62e.ITerraformDependable]], result)

    @builtins.property
    def for_each(self) -> typing.Optional[_cdktn_78ede62e.ITerraformIterator]:
        '''
        :stability: experimental
        '''
        result = self._values.get("for_each")
        return typing.cast(typing.Optional[_cdktn_78ede62e.ITerraformIterator], result)

    @builtins.property
    def lifecycle(self) -> typing.Optional[_cdktn_78ede62e.TerraformResourceLifecycle]:
        '''
        :stability: experimental
        '''
        result = self._values.get("lifecycle")
        return typing.cast(typing.Optional[_cdktn_78ede62e.TerraformResourceLifecycle], result)

    @builtins.property
    def provider(self) -> typing.Optional[_cdktn_78ede62e.TerraformProvider]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provider")
        return typing.cast(typing.Optional[_cdktn_78ede62e.TerraformProvider], result)

    @builtins.property
    def provisioners(
        self,
    ) -> typing.Optional[typing.List[typing.Union[_cdktn_78ede62e.FileProvisioner, _cdktn_78ede62e.LocalExecProvisioner, _cdktn_78ede62e.RemoteExecProvisioner]]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provisioners")
        return typing.cast(typing.Optional[typing.List[typing.Union[_cdktn_78ede62e.FileProvisioner, _cdktn_78ede62e.LocalExecProvisioner, _cdktn_78ede62e.RemoteExecProvisioner]]], result)

    @builtins.property
    def name(self) -> builtins.str:
        '''The workload's name.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#name Workload#name}
        '''
        result = self._values.get("name")
        assert result is not None, "Required property 'name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def account_id(self) -> typing.Optional[jsii.Number]:
        '''The New Relic account ID where you want to create the workload.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#account_id Workload#account_id}
        '''
        result = self._values.get("account_id")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def description(self) -> typing.Optional[builtins.str]:
        '''Relevant information about the workload.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#description Workload#description}
        '''
        result = self._values.get("description")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def entity_guids(self) -> typing.Optional[typing.List[builtins.str]]:
        '''A list of entity GUIDs manually assigned to this workload.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#entity_guids Workload#entity_guids}
        '''
        result = self._values.get("entity_guids")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def entity_search_query(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["WorkloadEntitySearchQuery"]]]:
        '''entity_search_query block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#entity_search_query Workload#entity_search_query}
        '''
        result = self._values.get("entity_search_query")
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["WorkloadEntitySearchQuery"]]], result)

    @builtins.property
    def id(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#id Workload#id}.

        Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        '''
        result = self._values.get("id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def scope_account_ids(self) -> typing.Optional[typing.List[jsii.Number]]:
        '''A list of account IDs that will be used to get entities from.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#scope_account_ids Workload#scope_account_ids}
        '''
        result = self._values.get("scope_account_ids")
        return typing.cast(typing.Optional[typing.List[jsii.Number]], result)

    @builtins.property
    def status_config_automatic(
        self,
    ) -> typing.Optional["WorkloadStatusConfigAutomatic"]:
        '''status_config_automatic block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#status_config_automatic Workload#status_config_automatic}
        '''
        result = self._values.get("status_config_automatic")
        return typing.cast(typing.Optional["WorkloadStatusConfigAutomatic"], result)

    @builtins.property
    def status_config_static(self) -> typing.Optional["WorkloadStatusConfigStatic"]:
        '''status_config_static block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#status_config_static Workload#status_config_static}
        '''
        result = self._values.get("status_config_static")
        return typing.cast(typing.Optional["WorkloadStatusConfigStatic"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "WorkloadConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.workload.WorkloadEntitySearchQuery",
    jsii_struct_bases=[],
    name_mapping={"query": "query"},
)
class WorkloadEntitySearchQuery:
    def __init__(self, *, query: builtins.str) -> None:
        '''
        :param query: A valid entity search query; empty, and null values are considered invalid. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#query Workload#query}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7ff9d887e51d76cefd4b1f2a46660f0ef99be8c824c2fe2f2ba46af4d30b2293)
            check_type(argname="argument query", value=query, expected_type=type_hints["query"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "query": query,
        }

    @builtins.property
    def query(self) -> builtins.str:
        '''A valid entity search query; empty, and null values are considered invalid.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#query Workload#query}
        '''
        result = self._values.get("query")
        assert result is not None, "Required property 'query' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "WorkloadEntitySearchQuery(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class WorkloadEntitySearchQueryList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.workload.WorkloadEntitySearchQueryList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fae8e13829ad72e9318f202c2512fb6e20a40ce636699227db4976e076ded789)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(self, index: jsii.Number) -> "WorkloadEntitySearchQueryOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a8a5e09ebe55049317899632b322d5261d8478f1c938fed2e4c6b4f64f883192)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("WorkloadEntitySearchQueryOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__56da9566a3841effd24fb113a3efcdca67b186b047e1959a7adc553081d4b634)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7c37741b3f8a7e382ada8f365a1f1963e0a82ca3ee00973f812841af62bd0f6b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5e8938f4b2b59b1bf805e64d6b3ec5f2e7c278934da3daf5514b32417dbb0ab9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[WorkloadEntitySearchQuery]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[WorkloadEntitySearchQuery]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[WorkloadEntitySearchQuery]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4eb55b83e9b876eb2b80af532bcbd21843c36b20b442ea8a1cabceffe2e98535)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class WorkloadEntitySearchQueryOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.workload.WorkloadEntitySearchQueryOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ea3de15a2aac77064978c56db65008bb0765f28fcd9966794b26e1ee9b268146)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="queryInput")
    def query_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "queryInput"))

    @builtins.property
    @jsii.member(jsii_name="query")
    def query(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "query"))

    @query.setter
    def query(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c330b07e6e74552d2831ae96f6347d7ec9342628b315ff5fe5a6d4f94de6a64f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "query", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, WorkloadEntitySearchQuery]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, WorkloadEntitySearchQuery]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, WorkloadEntitySearchQuery]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5e968d53d16dc45a859390f80b5eaf6a901c1ee8430cca0425b7ba5c21d1d059)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.workload.WorkloadStatusConfigAutomatic",
    jsii_struct_bases=[],
    name_mapping={
        "enabled": "enabled",
        "remaining_entities_rule": "remainingEntitiesRule",
        "rule": "rule",
    },
)
class WorkloadStatusConfigAutomatic:
    def __init__(
        self,
        *,
        enabled: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
        remaining_entities_rule: typing.Optional[typing.Union["WorkloadStatusConfigAutomaticRemainingEntitiesRule", typing.Dict[builtins.str, typing.Any]]] = None,
        rule: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["WorkloadStatusConfigAutomaticRule", typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''
        :param enabled: Whether the automatic status configuration is enabled or not. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#enabled Workload#enabled}
        :param remaining_entities_rule: remaining_entities_rule block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#remaining_entities_rule Workload#remaining_entities_rule}
        :param rule: rule block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#rule Workload#rule}
        '''
        if isinstance(remaining_entities_rule, dict):
            remaining_entities_rule = WorkloadStatusConfigAutomaticRemainingEntitiesRule(**remaining_entities_rule)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__55e619561777b95843679c9c5044008e80184f437ca42d2f9296c7fd622b6b74)
            check_type(argname="argument enabled", value=enabled, expected_type=type_hints["enabled"])
            check_type(argname="argument remaining_entities_rule", value=remaining_entities_rule, expected_type=type_hints["remaining_entities_rule"])
            check_type(argname="argument rule", value=rule, expected_type=type_hints["rule"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "enabled": enabled,
        }
        if remaining_entities_rule is not None:
            self._values["remaining_entities_rule"] = remaining_entities_rule
        if rule is not None:
            self._values["rule"] = rule

    @builtins.property
    def enabled(self) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        '''Whether the automatic status configuration is enabled or not.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#enabled Workload#enabled}
        '''
        result = self._values.get("enabled")
        assert result is not None, "Required property 'enabled' is missing"
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], result)

    @builtins.property
    def remaining_entities_rule(
        self,
    ) -> typing.Optional["WorkloadStatusConfigAutomaticRemainingEntitiesRule"]:
        '''remaining_entities_rule block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#remaining_entities_rule Workload#remaining_entities_rule}
        '''
        result = self._values.get("remaining_entities_rule")
        return typing.cast(typing.Optional["WorkloadStatusConfigAutomaticRemainingEntitiesRule"], result)

    @builtins.property
    def rule(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["WorkloadStatusConfigAutomaticRule"]]]:
        '''rule block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#rule Workload#rule}
        '''
        result = self._values.get("rule")
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["WorkloadStatusConfigAutomaticRule"]]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "WorkloadStatusConfigAutomatic(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class WorkloadStatusConfigAutomaticOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.workload.WorkloadStatusConfigAutomaticOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__303a8aabe76d639116dbf2b9dd660265791f6ecb42681a84699b33764269d019)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putRemainingEntitiesRule")
    def put_remaining_entities_rule(
        self,
        *,
        remaining_entities_rule_rollup: typing.Union["WorkloadStatusConfigAutomaticRemainingEntitiesRuleRemainingEntitiesRuleRollup", typing.Dict[builtins.str, typing.Any]],
    ) -> None:
        '''
        :param remaining_entities_rule_rollup: remaining_entities_rule_rollup block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#remaining_entities_rule_rollup Workload#remaining_entities_rule_rollup}
        '''
        value = WorkloadStatusConfigAutomaticRemainingEntitiesRule(
            remaining_entities_rule_rollup=remaining_entities_rule_rollup
        )

        return typing.cast(None, jsii.invoke(self, "putRemainingEntitiesRule", [value]))

    @jsii.member(jsii_name="putRule")
    def put_rule(
        self,
        value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["WorkloadStatusConfigAutomaticRule", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__86b06af48ce45b7758455215385f8b2b9c04e0e11d390ce8c58009fbac544e67)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putRule", [value]))

    @jsii.member(jsii_name="resetRemainingEntitiesRule")
    def reset_remaining_entities_rule(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRemainingEntitiesRule", []))

    @jsii.member(jsii_name="resetRule")
    def reset_rule(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRule", []))

    @builtins.property
    @jsii.member(jsii_name="remainingEntitiesRule")
    def remaining_entities_rule(
        self,
    ) -> "WorkloadStatusConfigAutomaticRemainingEntitiesRuleOutputReference":
        return typing.cast("WorkloadStatusConfigAutomaticRemainingEntitiesRuleOutputReference", jsii.get(self, "remainingEntitiesRule"))

    @builtins.property
    @jsii.member(jsii_name="rule")
    def rule(self) -> "WorkloadStatusConfigAutomaticRuleList":
        return typing.cast("WorkloadStatusConfigAutomaticRuleList", jsii.get(self, "rule"))

    @builtins.property
    @jsii.member(jsii_name="enabledInput")
    def enabled_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "enabledInput"))

    @builtins.property
    @jsii.member(jsii_name="remainingEntitiesRuleInput")
    def remaining_entities_rule_input(
        self,
    ) -> typing.Optional["WorkloadStatusConfigAutomaticRemainingEntitiesRule"]:
        return typing.cast(typing.Optional["WorkloadStatusConfigAutomaticRemainingEntitiesRule"], jsii.get(self, "remainingEntitiesRuleInput"))

    @builtins.property
    @jsii.member(jsii_name="ruleInput")
    def rule_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["WorkloadStatusConfigAutomaticRule"]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["WorkloadStatusConfigAutomaticRule"]]], jsii.get(self, "ruleInput"))

    @builtins.property
    @jsii.member(jsii_name="enabled")
    def enabled(self) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "enabled"))

    @enabled.setter
    def enabled(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d6fba85d95d3d016198d03a98b0d9122df32079f002f3862c414a68c857348bd)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "enabled", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[WorkloadStatusConfigAutomatic]:
        return typing.cast(typing.Optional[WorkloadStatusConfigAutomatic], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[WorkloadStatusConfigAutomatic],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__403769baa54dae79dd2f730db0a3f0b8887512be38791563dce23fb38b28f542)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.workload.WorkloadStatusConfigAutomaticRemainingEntitiesRule",
    jsii_struct_bases=[],
    name_mapping={"remaining_entities_rule_rollup": "remainingEntitiesRuleRollup"},
)
class WorkloadStatusConfigAutomaticRemainingEntitiesRule:
    def __init__(
        self,
        *,
        remaining_entities_rule_rollup: typing.Union["WorkloadStatusConfigAutomaticRemainingEntitiesRuleRemainingEntitiesRuleRollup", typing.Dict[builtins.str, typing.Any]],
    ) -> None:
        '''
        :param remaining_entities_rule_rollup: remaining_entities_rule_rollup block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#remaining_entities_rule_rollup Workload#remaining_entities_rule_rollup}
        '''
        if isinstance(remaining_entities_rule_rollup, dict):
            remaining_entities_rule_rollup = WorkloadStatusConfigAutomaticRemainingEntitiesRuleRemainingEntitiesRuleRollup(**remaining_entities_rule_rollup)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9a750c6e340ca4adcb56102b5d460b6317581a35866efe72cfbadf77961c63cb)
            check_type(argname="argument remaining_entities_rule_rollup", value=remaining_entities_rule_rollup, expected_type=type_hints["remaining_entities_rule_rollup"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "remaining_entities_rule_rollup": remaining_entities_rule_rollup,
        }

    @builtins.property
    def remaining_entities_rule_rollup(
        self,
    ) -> "WorkloadStatusConfigAutomaticRemainingEntitiesRuleRemainingEntitiesRuleRollup":
        '''remaining_entities_rule_rollup block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#remaining_entities_rule_rollup Workload#remaining_entities_rule_rollup}
        '''
        result = self._values.get("remaining_entities_rule_rollup")
        assert result is not None, "Required property 'remaining_entities_rule_rollup' is missing"
        return typing.cast("WorkloadStatusConfigAutomaticRemainingEntitiesRuleRemainingEntitiesRuleRollup", result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "WorkloadStatusConfigAutomaticRemainingEntitiesRule(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class WorkloadStatusConfigAutomaticRemainingEntitiesRuleOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.workload.WorkloadStatusConfigAutomaticRemainingEntitiesRuleOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fbeb39bff2fa2ee83cd2917342847b49924beb77ac2f374946f16893e25b502c)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putRemainingEntitiesRuleRollup")
    def put_remaining_entities_rule_rollup(
        self,
        *,
        group_by: builtins.str,
        strategy: builtins.str,
        threshold_type: typing.Optional[builtins.str] = None,
        threshold_value: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param group_by: The grouping to be applied to the remaining entities. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#group_by Workload#group_by}
        :param strategy: The rollup strategy that is applied to a group of entities. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#strategy Workload#strategy}
        :param threshold_type: Type of threshold defined for the rule. This is an optional field that only applies when strategy is WORST_STATUS_WINS. Use a threshold to roll up the worst status only after a certain amount of entities are not operational. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#threshold_type Workload#threshold_type}
        :param threshold_value: Threshold value defined for the rule. This optional field is used in combination with thresholdType. If the threshold type is null, the threshold value will be ignored. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#threshold_value Workload#threshold_value}
        '''
        value = WorkloadStatusConfigAutomaticRemainingEntitiesRuleRemainingEntitiesRuleRollup(
            group_by=group_by,
            strategy=strategy,
            threshold_type=threshold_type,
            threshold_value=threshold_value,
        )

        return typing.cast(None, jsii.invoke(self, "putRemainingEntitiesRuleRollup", [value]))

    @builtins.property
    @jsii.member(jsii_name="remainingEntitiesRuleRollup")
    def remaining_entities_rule_rollup(
        self,
    ) -> "WorkloadStatusConfigAutomaticRemainingEntitiesRuleRemainingEntitiesRuleRollupOutputReference":
        return typing.cast("WorkloadStatusConfigAutomaticRemainingEntitiesRuleRemainingEntitiesRuleRollupOutputReference", jsii.get(self, "remainingEntitiesRuleRollup"))

    @builtins.property
    @jsii.member(jsii_name="remainingEntitiesRuleRollupInput")
    def remaining_entities_rule_rollup_input(
        self,
    ) -> typing.Optional["WorkloadStatusConfigAutomaticRemainingEntitiesRuleRemainingEntitiesRuleRollup"]:
        return typing.cast(typing.Optional["WorkloadStatusConfigAutomaticRemainingEntitiesRuleRemainingEntitiesRuleRollup"], jsii.get(self, "remainingEntitiesRuleRollupInput"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[WorkloadStatusConfigAutomaticRemainingEntitiesRule]:
        return typing.cast(typing.Optional[WorkloadStatusConfigAutomaticRemainingEntitiesRule], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[WorkloadStatusConfigAutomaticRemainingEntitiesRule],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2b42e1e6a34f3c0739bc344abb4c2f7bc8645941716fedadda3aa26ffe02045b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.workload.WorkloadStatusConfigAutomaticRemainingEntitiesRuleRemainingEntitiesRuleRollup",
    jsii_struct_bases=[],
    name_mapping={
        "group_by": "groupBy",
        "strategy": "strategy",
        "threshold_type": "thresholdType",
        "threshold_value": "thresholdValue",
    },
)
class WorkloadStatusConfigAutomaticRemainingEntitiesRuleRemainingEntitiesRuleRollup:
    def __init__(
        self,
        *,
        group_by: builtins.str,
        strategy: builtins.str,
        threshold_type: typing.Optional[builtins.str] = None,
        threshold_value: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param group_by: The grouping to be applied to the remaining entities. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#group_by Workload#group_by}
        :param strategy: The rollup strategy that is applied to a group of entities. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#strategy Workload#strategy}
        :param threshold_type: Type of threshold defined for the rule. This is an optional field that only applies when strategy is WORST_STATUS_WINS. Use a threshold to roll up the worst status only after a certain amount of entities are not operational. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#threshold_type Workload#threshold_type}
        :param threshold_value: Threshold value defined for the rule. This optional field is used in combination with thresholdType. If the threshold type is null, the threshold value will be ignored. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#threshold_value Workload#threshold_value}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__71196a01e7b80f9a85f0519791cd4fee2e49d247af9f630b4cbdf7ea83edf159)
            check_type(argname="argument group_by", value=group_by, expected_type=type_hints["group_by"])
            check_type(argname="argument strategy", value=strategy, expected_type=type_hints["strategy"])
            check_type(argname="argument threshold_type", value=threshold_type, expected_type=type_hints["threshold_type"])
            check_type(argname="argument threshold_value", value=threshold_value, expected_type=type_hints["threshold_value"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "group_by": group_by,
            "strategy": strategy,
        }
        if threshold_type is not None:
            self._values["threshold_type"] = threshold_type
        if threshold_value is not None:
            self._values["threshold_value"] = threshold_value

    @builtins.property
    def group_by(self) -> builtins.str:
        '''The grouping to be applied to the remaining entities.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#group_by Workload#group_by}
        '''
        result = self._values.get("group_by")
        assert result is not None, "Required property 'group_by' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def strategy(self) -> builtins.str:
        '''The rollup strategy that is applied to a group of entities.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#strategy Workload#strategy}
        '''
        result = self._values.get("strategy")
        assert result is not None, "Required property 'strategy' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def threshold_type(self) -> typing.Optional[builtins.str]:
        '''Type of threshold defined for the rule.

        This is an optional field that only applies when strategy is WORST_STATUS_WINS. Use a threshold to roll up the worst status only after a certain amount of entities are not operational.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#threshold_type Workload#threshold_type}
        '''
        result = self._values.get("threshold_type")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def threshold_value(self) -> typing.Optional[jsii.Number]:
        '''Threshold value defined for the rule.

        This optional field is used in combination with thresholdType. If the threshold type is null, the threshold value will be ignored.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#threshold_value Workload#threshold_value}
        '''
        result = self._values.get("threshold_value")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "WorkloadStatusConfigAutomaticRemainingEntitiesRuleRemainingEntitiesRuleRollup(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class WorkloadStatusConfigAutomaticRemainingEntitiesRuleRemainingEntitiesRuleRollupOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.workload.WorkloadStatusConfigAutomaticRemainingEntitiesRuleRemainingEntitiesRuleRollupOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b491ce30378706ae60af2a54c935579cd79850c4623f3a5f45c357b32374d7e4)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetThresholdType")
    def reset_threshold_type(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetThresholdType", []))

    @jsii.member(jsii_name="resetThresholdValue")
    def reset_threshold_value(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetThresholdValue", []))

    @builtins.property
    @jsii.member(jsii_name="groupByInput")
    def group_by_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "groupByInput"))

    @builtins.property
    @jsii.member(jsii_name="strategyInput")
    def strategy_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "strategyInput"))

    @builtins.property
    @jsii.member(jsii_name="thresholdTypeInput")
    def threshold_type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "thresholdTypeInput"))

    @builtins.property
    @jsii.member(jsii_name="thresholdValueInput")
    def threshold_value_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "thresholdValueInput"))

    @builtins.property
    @jsii.member(jsii_name="groupBy")
    def group_by(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "groupBy"))

    @group_by.setter
    def group_by(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a23679c65367986d31e6cf8b41045b745709362a1c3ce4e00b201ffcf6e774b0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "groupBy", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="strategy")
    def strategy(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "strategy"))

    @strategy.setter
    def strategy(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e837bac31ee670948533bc9979d22a78c1b59d8f369715fbe94538c052fe8450)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "strategy", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="thresholdType")
    def threshold_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "thresholdType"))

    @threshold_type.setter
    def threshold_type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7045162d223ac3ffe55d19ad483f4bbd4f9f8f16d24611577cac29b919d44566)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "thresholdType", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="thresholdValue")
    def threshold_value(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "thresholdValue"))

    @threshold_value.setter
    def threshold_value(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4f9d49ec87375dfab6276168589f31777ab499db829f7c06236d3c3e10a57e38)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "thresholdValue", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[WorkloadStatusConfigAutomaticRemainingEntitiesRuleRemainingEntitiesRuleRollup]:
        return typing.cast(typing.Optional[WorkloadStatusConfigAutomaticRemainingEntitiesRuleRemainingEntitiesRuleRollup], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[WorkloadStatusConfigAutomaticRemainingEntitiesRuleRemainingEntitiesRuleRollup],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__08b4b778b95ce7d01893edbf88e52c570de5be28c5ab2dcfed6d6151c703fb23)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.workload.WorkloadStatusConfigAutomaticRule",
    jsii_struct_bases=[],
    name_mapping={
        "rollup": "rollup",
        "entity_guids": "entityGuids",
        "nrql_query": "nrqlQuery",
    },
)
class WorkloadStatusConfigAutomaticRule:
    def __init__(
        self,
        *,
        rollup: typing.Union["WorkloadStatusConfigAutomaticRuleRollup", typing.Dict[builtins.str, typing.Any]],
        entity_guids: typing.Optional[typing.Sequence[builtins.str]] = None,
        nrql_query: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["WorkloadStatusConfigAutomaticRuleNrqlQuery", typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''
        :param rollup: rollup block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#rollup Workload#rollup}
        :param entity_guids: A list of entity GUIDs composing the rule. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#entity_guids Workload#entity_guids}
        :param nrql_query: nrql_query block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#nrql_query Workload#nrql_query}
        '''
        if isinstance(rollup, dict):
            rollup = WorkloadStatusConfigAutomaticRuleRollup(**rollup)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__df726d4cc05dc1cac378405c76dad11270bbe38d6cbffc5442082c1315242199)
            check_type(argname="argument rollup", value=rollup, expected_type=type_hints["rollup"])
            check_type(argname="argument entity_guids", value=entity_guids, expected_type=type_hints["entity_guids"])
            check_type(argname="argument nrql_query", value=nrql_query, expected_type=type_hints["nrql_query"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "rollup": rollup,
        }
        if entity_guids is not None:
            self._values["entity_guids"] = entity_guids
        if nrql_query is not None:
            self._values["nrql_query"] = nrql_query

    @builtins.property
    def rollup(self) -> "WorkloadStatusConfigAutomaticRuleRollup":
        '''rollup block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#rollup Workload#rollup}
        '''
        result = self._values.get("rollup")
        assert result is not None, "Required property 'rollup' is missing"
        return typing.cast("WorkloadStatusConfigAutomaticRuleRollup", result)

    @builtins.property
    def entity_guids(self) -> typing.Optional[typing.List[builtins.str]]:
        '''A list of entity GUIDs composing the rule.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#entity_guids Workload#entity_guids}
        '''
        result = self._values.get("entity_guids")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def nrql_query(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["WorkloadStatusConfigAutomaticRuleNrqlQuery"]]]:
        '''nrql_query block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#nrql_query Workload#nrql_query}
        '''
        result = self._values.get("nrql_query")
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["WorkloadStatusConfigAutomaticRuleNrqlQuery"]]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "WorkloadStatusConfigAutomaticRule(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class WorkloadStatusConfigAutomaticRuleList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.workload.WorkloadStatusConfigAutomaticRuleList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7b3736430a54e881a6608171534275050399f28662d3860826148661b6286c0f)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "WorkloadStatusConfigAutomaticRuleOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f0e1467090e692ea54a62906d2643f5e7c2a849fa6935cbc934b0ba52db5dd58)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("WorkloadStatusConfigAutomaticRuleOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a2fff34782e37914e98478f3ce7047931eaa49d1972e6da82318520534c272c9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__89bc9427230e4b5ecaebff78c32cf7c0b6bd723b4ea1643799ecbd12d11d9047)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__988061789174950f89a8d2ba19de54b480721868f485d97cd2059e68fa067c67)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[WorkloadStatusConfigAutomaticRule]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[WorkloadStatusConfigAutomaticRule]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[WorkloadStatusConfigAutomaticRule]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2d97c96bc2a1e1b86851b51b0a6e9dfc4338e1220dddbbc7aba05003e7fd4316)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.workload.WorkloadStatusConfigAutomaticRuleNrqlQuery",
    jsii_struct_bases=[],
    name_mapping={"query": "query"},
)
class WorkloadStatusConfigAutomaticRuleNrqlQuery:
    def __init__(self, *, query: builtins.str) -> None:
        '''
        :param query: The entity search query that is used to perform the search of a group of entities. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#query Workload#query}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f53a76f27bc8a833eb4b84f306201ac92eb11127d40bdb580e417983dd17dfc0)
            check_type(argname="argument query", value=query, expected_type=type_hints["query"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "query": query,
        }

    @builtins.property
    def query(self) -> builtins.str:
        '''The entity search query that is used to perform the search of a group of entities.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#query Workload#query}
        '''
        result = self._values.get("query")
        assert result is not None, "Required property 'query' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "WorkloadStatusConfigAutomaticRuleNrqlQuery(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class WorkloadStatusConfigAutomaticRuleNrqlQueryList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.workload.WorkloadStatusConfigAutomaticRuleNrqlQueryList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__51fc805570b9ff57ffe19f4795ad05e012e82a3846247a9264051be4230c343b)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "WorkloadStatusConfigAutomaticRuleNrqlQueryOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__60d9b2390bae4a6483599ba9aeabdef1d2e298a654d8d08fe9503eaf3b5bd51c)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("WorkloadStatusConfigAutomaticRuleNrqlQueryOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e5891478438b6130f901e2f16eaa6105ab259097d2ffd8552d25cff3076c9e40)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__107b2e1fb4d88fddffb68710680a34d65db92fa746ce48ce43e5e9c9427b988a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1654589bcedc5e79db032274b0097acc78de2b9b0d45092d90573e88793ebb14)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[WorkloadStatusConfigAutomaticRuleNrqlQuery]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[WorkloadStatusConfigAutomaticRuleNrqlQuery]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[WorkloadStatusConfigAutomaticRuleNrqlQuery]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c9edc935efb062cdd4b0f771f1d09663e5a57ce621be9455ba9dc728d5733aef)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class WorkloadStatusConfigAutomaticRuleNrqlQueryOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.workload.WorkloadStatusConfigAutomaticRuleNrqlQueryOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fb67ece8726a7a4b4f4d93915ef7e98098b4d788c8fa6c644ff63faed65f9cb9)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="queryInput")
    def query_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "queryInput"))

    @builtins.property
    @jsii.member(jsii_name="query")
    def query(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "query"))

    @query.setter
    def query(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6f465f2148167b1f5fac1637a38e3d646e3cbc24647a4aa1774ee373e1e2beeb)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "query", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, WorkloadStatusConfigAutomaticRuleNrqlQuery]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, WorkloadStatusConfigAutomaticRuleNrqlQuery]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, WorkloadStatusConfigAutomaticRuleNrqlQuery]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__02349609303498b5b4f8aafe6459fd7a7d00b8ee65e2c4154d1d0b80800514e7)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class WorkloadStatusConfigAutomaticRuleOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.workload.WorkloadStatusConfigAutomaticRuleOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__87aa2c953b21bb7294a8b40357bfd8ca8432f88cfe4bfaf575a73c82f5ab5bf8)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="putNrqlQuery")
    def put_nrql_query(
        self,
        value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[WorkloadStatusConfigAutomaticRuleNrqlQuery, typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b382504e3e18044e0d02e4ccb27286fa163122766bf976d2c5a4d1e9a937699f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putNrqlQuery", [value]))

    @jsii.member(jsii_name="putRollup")
    def put_rollup(
        self,
        *,
        strategy: builtins.str,
        threshold_type: typing.Optional[builtins.str] = None,
        threshold_value: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param strategy: The rollup strategy that is applied to a group of entities. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#strategy Workload#strategy}
        :param threshold_type: Type of threshold defined for the rule. This is an optional field that only applies when strategy is WORST_STATUS_WINS. Use a threshold to roll up the worst status only after a certain amount of entities are not operational. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#threshold_type Workload#threshold_type}
        :param threshold_value: Threshold value defined for the rule. This optional field is used in combination with thresholdType. If the threshold type is null, the threshold value will be ignored. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#threshold_value Workload#threshold_value}
        '''
        value = WorkloadStatusConfigAutomaticRuleRollup(
            strategy=strategy,
            threshold_type=threshold_type,
            threshold_value=threshold_value,
        )

        return typing.cast(None, jsii.invoke(self, "putRollup", [value]))

    @jsii.member(jsii_name="resetEntityGuids")
    def reset_entity_guids(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEntityGuids", []))

    @jsii.member(jsii_name="resetNrqlQuery")
    def reset_nrql_query(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNrqlQuery", []))

    @builtins.property
    @jsii.member(jsii_name="nrqlQuery")
    def nrql_query(self) -> WorkloadStatusConfigAutomaticRuleNrqlQueryList:
        return typing.cast(WorkloadStatusConfigAutomaticRuleNrqlQueryList, jsii.get(self, "nrqlQuery"))

    @builtins.property
    @jsii.member(jsii_name="rollup")
    def rollup(self) -> "WorkloadStatusConfigAutomaticRuleRollupOutputReference":
        return typing.cast("WorkloadStatusConfigAutomaticRuleRollupOutputReference", jsii.get(self, "rollup"))

    @builtins.property
    @jsii.member(jsii_name="entityGuidsInput")
    def entity_guids_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "entityGuidsInput"))

    @builtins.property
    @jsii.member(jsii_name="nrqlQueryInput")
    def nrql_query_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[WorkloadStatusConfigAutomaticRuleNrqlQuery]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[WorkloadStatusConfigAutomaticRuleNrqlQuery]]], jsii.get(self, "nrqlQueryInput"))

    @builtins.property
    @jsii.member(jsii_name="rollupInput")
    def rollup_input(
        self,
    ) -> typing.Optional["WorkloadStatusConfigAutomaticRuleRollup"]:
        return typing.cast(typing.Optional["WorkloadStatusConfigAutomaticRuleRollup"], jsii.get(self, "rollupInput"))

    @builtins.property
    @jsii.member(jsii_name="entityGuids")
    def entity_guids(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "entityGuids"))

    @entity_guids.setter
    def entity_guids(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8bafacf1f2cf1bdd44918807fbb6b7788056baa86c296fb4c95b6413765ef3cf)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "entityGuids", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, WorkloadStatusConfigAutomaticRule]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, WorkloadStatusConfigAutomaticRule]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, WorkloadStatusConfigAutomaticRule]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__73584b51394bdf4417b1f50bf6f8288732424e104a2e8a54b0c9a516e468b770)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.workload.WorkloadStatusConfigAutomaticRuleRollup",
    jsii_struct_bases=[],
    name_mapping={
        "strategy": "strategy",
        "threshold_type": "thresholdType",
        "threshold_value": "thresholdValue",
    },
)
class WorkloadStatusConfigAutomaticRuleRollup:
    def __init__(
        self,
        *,
        strategy: builtins.str,
        threshold_type: typing.Optional[builtins.str] = None,
        threshold_value: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param strategy: The rollup strategy that is applied to a group of entities. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#strategy Workload#strategy}
        :param threshold_type: Type of threshold defined for the rule. This is an optional field that only applies when strategy is WORST_STATUS_WINS. Use a threshold to roll up the worst status only after a certain amount of entities are not operational. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#threshold_type Workload#threshold_type}
        :param threshold_value: Threshold value defined for the rule. This optional field is used in combination with thresholdType. If the threshold type is null, the threshold value will be ignored. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#threshold_value Workload#threshold_value}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8c4a612886ed41e52346e1e36d34705e5baf2d8829c13316fecec64769d91726)
            check_type(argname="argument strategy", value=strategy, expected_type=type_hints["strategy"])
            check_type(argname="argument threshold_type", value=threshold_type, expected_type=type_hints["threshold_type"])
            check_type(argname="argument threshold_value", value=threshold_value, expected_type=type_hints["threshold_value"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "strategy": strategy,
        }
        if threshold_type is not None:
            self._values["threshold_type"] = threshold_type
        if threshold_value is not None:
            self._values["threshold_value"] = threshold_value

    @builtins.property
    def strategy(self) -> builtins.str:
        '''The rollup strategy that is applied to a group of entities.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#strategy Workload#strategy}
        '''
        result = self._values.get("strategy")
        assert result is not None, "Required property 'strategy' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def threshold_type(self) -> typing.Optional[builtins.str]:
        '''Type of threshold defined for the rule.

        This is an optional field that only applies when strategy is WORST_STATUS_WINS. Use a threshold to roll up the worst status only after a certain amount of entities are not operational.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#threshold_type Workload#threshold_type}
        '''
        result = self._values.get("threshold_type")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def threshold_value(self) -> typing.Optional[jsii.Number]:
        '''Threshold value defined for the rule.

        This optional field is used in combination with thresholdType. If the threshold type is null, the threshold value will be ignored.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#threshold_value Workload#threshold_value}
        '''
        result = self._values.get("threshold_value")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "WorkloadStatusConfigAutomaticRuleRollup(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class WorkloadStatusConfigAutomaticRuleRollupOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.workload.WorkloadStatusConfigAutomaticRuleRollupOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2ffe17cdc75cbea4671739f0017670653eedc448536e37533b8aaeacf43b7d9f)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetThresholdType")
    def reset_threshold_type(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetThresholdType", []))

    @jsii.member(jsii_name="resetThresholdValue")
    def reset_threshold_value(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetThresholdValue", []))

    @builtins.property
    @jsii.member(jsii_name="strategyInput")
    def strategy_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "strategyInput"))

    @builtins.property
    @jsii.member(jsii_name="thresholdTypeInput")
    def threshold_type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "thresholdTypeInput"))

    @builtins.property
    @jsii.member(jsii_name="thresholdValueInput")
    def threshold_value_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "thresholdValueInput"))

    @builtins.property
    @jsii.member(jsii_name="strategy")
    def strategy(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "strategy"))

    @strategy.setter
    def strategy(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7591688d39bd762e306adfa31dcc45db32cfc4343f944aa71bf6ec1d2dac76ee)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "strategy", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="thresholdType")
    def threshold_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "thresholdType"))

    @threshold_type.setter
    def threshold_type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3611b6b91c69d99d174b256f09967549915e9d3ab4e403e47df5ce195d35a5c0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "thresholdType", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="thresholdValue")
    def threshold_value(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "thresholdValue"))

    @threshold_value.setter
    def threshold_value(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__93ffa372b857f96c0eb80d6d44a7a84682b010a23d6d12d1576fb752d46b4986)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "thresholdValue", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[WorkloadStatusConfigAutomaticRuleRollup]:
        return typing.cast(typing.Optional[WorkloadStatusConfigAutomaticRuleRollup], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[WorkloadStatusConfigAutomaticRuleRollup],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__458b7fb4f24c1302abf1014efea2b5f3523350c42253c3537d797d50d51a6424)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.workload.WorkloadStatusConfigStatic",
    jsii_struct_bases=[],
    name_mapping={
        "enabled": "enabled",
        "status": "status",
        "description": "description",
        "summary": "summary",
    },
)
class WorkloadStatusConfigStatic:
    def __init__(
        self,
        *,
        enabled: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
        status: builtins.str,
        description: typing.Optional[builtins.str] = None,
        summary: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param enabled: Whether the static status configuration is enabled or not. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#enabled Workload#enabled}
        :param status: The status of the workload. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#status Workload#status}
        :param description: A description that provides additional details about the status of the workload. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#description Workload#description}
        :param summary: A short description of the status of the workload. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#summary Workload#summary}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__69fe07e1fb6f25960e1c9402acfeed2a48240154a86354f0bece23b582505853)
            check_type(argname="argument enabled", value=enabled, expected_type=type_hints["enabled"])
            check_type(argname="argument status", value=status, expected_type=type_hints["status"])
            check_type(argname="argument description", value=description, expected_type=type_hints["description"])
            check_type(argname="argument summary", value=summary, expected_type=type_hints["summary"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "enabled": enabled,
            "status": status,
        }
        if description is not None:
            self._values["description"] = description
        if summary is not None:
            self._values["summary"] = summary

    @builtins.property
    def enabled(self) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        '''Whether the static status configuration is enabled or not.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#enabled Workload#enabled}
        '''
        result = self._values.get("enabled")
        assert result is not None, "Required property 'enabled' is missing"
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], result)

    @builtins.property
    def status(self) -> builtins.str:
        '''The status of the workload.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#status Workload#status}
        '''
        result = self._values.get("status")
        assert result is not None, "Required property 'status' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def description(self) -> typing.Optional[builtins.str]:
        '''A description that provides additional details about the status of the workload.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#description Workload#description}
        '''
        result = self._values.get("description")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def summary(self) -> typing.Optional[builtins.str]:
        '''A short description of the status of the workload.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/workload#summary Workload#summary}
        '''
        result = self._values.get("summary")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "WorkloadStatusConfigStatic(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class WorkloadStatusConfigStaticOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.workload.WorkloadStatusConfigStaticOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c2b01d527114e0910d6e4af04999f3e7021e12a6fe6d16fae6e950261daef93d)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetDescription")
    def reset_description(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDescription", []))

    @jsii.member(jsii_name="resetSummary")
    def reset_summary(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSummary", []))

    @builtins.property
    @jsii.member(jsii_name="descriptionInput")
    def description_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "descriptionInput"))

    @builtins.property
    @jsii.member(jsii_name="enabledInput")
    def enabled_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "enabledInput"))

    @builtins.property
    @jsii.member(jsii_name="statusInput")
    def status_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "statusInput"))

    @builtins.property
    @jsii.member(jsii_name="summaryInput")
    def summary_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "summaryInput"))

    @builtins.property
    @jsii.member(jsii_name="description")
    def description(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "description"))

    @description.setter
    def description(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__38837c1d1cbc5025f7eac74608a7c8c5378dba40aebb2626578864c1555f3e2d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "description", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="enabled")
    def enabled(self) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "enabled"))

    @enabled.setter
    def enabled(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__65de3d2e21b55eecd96b060436c7a630a8322f5984639228faa7882728ba84f8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "enabled", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="status")
    def status(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "status"))

    @status.setter
    def status(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5a0a0962c49c4e68d106697df2e7b07282d6af04a09453be724709fdb6622e52)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "status", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="summary")
    def summary(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "summary"))

    @summary.setter
    def summary(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6c5b9254cc37781a65e7922a8aa08c86f1a8d236b291287224c0f7c93a0d026f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "summary", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[WorkloadStatusConfigStatic]:
        return typing.cast(typing.Optional[WorkloadStatusConfigStatic], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[WorkloadStatusConfigStatic],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f9239d86da40640316d619728d56ea2a50048aceda58cb3b644f1c999a58c3a3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


__all__ = [
    "Workload",
    "WorkloadConfig",
    "WorkloadEntitySearchQuery",
    "WorkloadEntitySearchQueryList",
    "WorkloadEntitySearchQueryOutputReference",
    "WorkloadStatusConfigAutomatic",
    "WorkloadStatusConfigAutomaticOutputReference",
    "WorkloadStatusConfigAutomaticRemainingEntitiesRule",
    "WorkloadStatusConfigAutomaticRemainingEntitiesRuleOutputReference",
    "WorkloadStatusConfigAutomaticRemainingEntitiesRuleRemainingEntitiesRuleRollup",
    "WorkloadStatusConfigAutomaticRemainingEntitiesRuleRemainingEntitiesRuleRollupOutputReference",
    "WorkloadStatusConfigAutomaticRule",
    "WorkloadStatusConfigAutomaticRuleList",
    "WorkloadStatusConfigAutomaticRuleNrqlQuery",
    "WorkloadStatusConfigAutomaticRuleNrqlQueryList",
    "WorkloadStatusConfigAutomaticRuleNrqlQueryOutputReference",
    "WorkloadStatusConfigAutomaticRuleOutputReference",
    "WorkloadStatusConfigAutomaticRuleRollup",
    "WorkloadStatusConfigAutomaticRuleRollupOutputReference",
    "WorkloadStatusConfigStatic",
    "WorkloadStatusConfigStaticOutputReference",
]

publication.publish()

def _typecheckingstub__01a617bbe7989ea5f878c1f156a2ac94a5977f060d5a5307a0bd9d5e906c39b3(
    scope: _constructs_77d1e7e8.Construct,
    id_: builtins.str,
    *,
    name: builtins.str,
    account_id: typing.Optional[jsii.Number] = None,
    description: typing.Optional[builtins.str] = None,
    entity_guids: typing.Optional[typing.Sequence[builtins.str]] = None,
    entity_search_query: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[WorkloadEntitySearchQuery, typing.Dict[builtins.str, typing.Any]]]]] = None,
    id: typing.Optional[builtins.str] = None,
    scope_account_ids: typing.Optional[typing.Sequence[jsii.Number]] = None,
    status_config_automatic: typing.Optional[typing.Union[WorkloadStatusConfigAutomatic, typing.Dict[builtins.str, typing.Any]]] = None,
    status_config_static: typing.Optional[typing.Union[WorkloadStatusConfigStatic, typing.Dict[builtins.str, typing.Any]]] = None,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__82935d61c603d60c47768d13b03451b056b74251fe2ef9f911f634323d7795eb(
    scope: _constructs_77d1e7e8.Construct,
    import_to_id: builtins.str,
    import_from_id: builtins.str,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__559d030b898e312b3ff58645e7082df658bcccfdf199df1da108d942f24d1985(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[WorkloadEntitySearchQuery, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a081dc3f50c87436f6aaa016c04c02632c974aa6006d3fac1a77441018eb9e03(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__088a40317ebcf089ea5db07856923f953a37558bf262db9a6bd8c6cc6447dfb2(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1dd6b661758a123714cb557494efd8bed50eae2d932cc3784c717ebafaa8d900(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a1913675f5b5182ebe71007a11f9a1948d346af0c972f1383f20317c9fe7cbea(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__92fb6ae847f7d66ba12cbe6887b8243229331a2e8b977aee2aea876fb402af2d(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4e6d61a9b1654c8d14054f788f3f8b594e99e93c68028e48a45ba6adecab68dc(
    value: typing.List[jsii.Number],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dfaf27131d7fbd22444dc861c45066ea5143dbbe75ddf036f751777630d0e924(
    *,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    name: builtins.str,
    account_id: typing.Optional[jsii.Number] = None,
    description: typing.Optional[builtins.str] = None,
    entity_guids: typing.Optional[typing.Sequence[builtins.str]] = None,
    entity_search_query: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[WorkloadEntitySearchQuery, typing.Dict[builtins.str, typing.Any]]]]] = None,
    id: typing.Optional[builtins.str] = None,
    scope_account_ids: typing.Optional[typing.Sequence[jsii.Number]] = None,
    status_config_automatic: typing.Optional[typing.Union[WorkloadStatusConfigAutomatic, typing.Dict[builtins.str, typing.Any]]] = None,
    status_config_static: typing.Optional[typing.Union[WorkloadStatusConfigStatic, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7ff9d887e51d76cefd4b1f2a46660f0ef99be8c824c2fe2f2ba46af4d30b2293(
    *,
    query: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fae8e13829ad72e9318f202c2512fb6e20a40ce636699227db4976e076ded789(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a8a5e09ebe55049317899632b322d5261d8478f1c938fed2e4c6b4f64f883192(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__56da9566a3841effd24fb113a3efcdca67b186b047e1959a7adc553081d4b634(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7c37741b3f8a7e382ada8f365a1f1963e0a82ca3ee00973f812841af62bd0f6b(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5e8938f4b2b59b1bf805e64d6b3ec5f2e7c278934da3daf5514b32417dbb0ab9(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4eb55b83e9b876eb2b80af532bcbd21843c36b20b442ea8a1cabceffe2e98535(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[WorkloadEntitySearchQuery]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ea3de15a2aac77064978c56db65008bb0765f28fcd9966794b26e1ee9b268146(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c330b07e6e74552d2831ae96f6347d7ec9342628b315ff5fe5a6d4f94de6a64f(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5e968d53d16dc45a859390f80b5eaf6a901c1ee8430cca0425b7ba5c21d1d059(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, WorkloadEntitySearchQuery]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__55e619561777b95843679c9c5044008e80184f437ca42d2f9296c7fd622b6b74(
    *,
    enabled: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    remaining_entities_rule: typing.Optional[typing.Union[WorkloadStatusConfigAutomaticRemainingEntitiesRule, typing.Dict[builtins.str, typing.Any]]] = None,
    rule: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[WorkloadStatusConfigAutomaticRule, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__303a8aabe76d639116dbf2b9dd660265791f6ecb42681a84699b33764269d019(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__86b06af48ce45b7758455215385f8b2b9c04e0e11d390ce8c58009fbac544e67(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[WorkloadStatusConfigAutomaticRule, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d6fba85d95d3d016198d03a98b0d9122df32079f002f3862c414a68c857348bd(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__403769baa54dae79dd2f730db0a3f0b8887512be38791563dce23fb38b28f542(
    value: typing.Optional[WorkloadStatusConfigAutomatic],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9a750c6e340ca4adcb56102b5d460b6317581a35866efe72cfbadf77961c63cb(
    *,
    remaining_entities_rule_rollup: typing.Union[WorkloadStatusConfigAutomaticRemainingEntitiesRuleRemainingEntitiesRuleRollup, typing.Dict[builtins.str, typing.Any]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fbeb39bff2fa2ee83cd2917342847b49924beb77ac2f374946f16893e25b502c(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2b42e1e6a34f3c0739bc344abb4c2f7bc8645941716fedadda3aa26ffe02045b(
    value: typing.Optional[WorkloadStatusConfigAutomaticRemainingEntitiesRule],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__71196a01e7b80f9a85f0519791cd4fee2e49d247af9f630b4cbdf7ea83edf159(
    *,
    group_by: builtins.str,
    strategy: builtins.str,
    threshold_type: typing.Optional[builtins.str] = None,
    threshold_value: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b491ce30378706ae60af2a54c935579cd79850c4623f3a5f45c357b32374d7e4(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a23679c65367986d31e6cf8b41045b745709362a1c3ce4e00b201ffcf6e774b0(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e837bac31ee670948533bc9979d22a78c1b59d8f369715fbe94538c052fe8450(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7045162d223ac3ffe55d19ad483f4bbd4f9f8f16d24611577cac29b919d44566(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4f9d49ec87375dfab6276168589f31777ab499db829f7c06236d3c3e10a57e38(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__08b4b778b95ce7d01893edbf88e52c570de5be28c5ab2dcfed6d6151c703fb23(
    value: typing.Optional[WorkloadStatusConfigAutomaticRemainingEntitiesRuleRemainingEntitiesRuleRollup],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__df726d4cc05dc1cac378405c76dad11270bbe38d6cbffc5442082c1315242199(
    *,
    rollup: typing.Union[WorkloadStatusConfigAutomaticRuleRollup, typing.Dict[builtins.str, typing.Any]],
    entity_guids: typing.Optional[typing.Sequence[builtins.str]] = None,
    nrql_query: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[WorkloadStatusConfigAutomaticRuleNrqlQuery, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7b3736430a54e881a6608171534275050399f28662d3860826148661b6286c0f(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f0e1467090e692ea54a62906d2643f5e7c2a849fa6935cbc934b0ba52db5dd58(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a2fff34782e37914e98478f3ce7047931eaa49d1972e6da82318520534c272c9(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__89bc9427230e4b5ecaebff78c32cf7c0b6bd723b4ea1643799ecbd12d11d9047(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__988061789174950f89a8d2ba19de54b480721868f485d97cd2059e68fa067c67(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2d97c96bc2a1e1b86851b51b0a6e9dfc4338e1220dddbbc7aba05003e7fd4316(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[WorkloadStatusConfigAutomaticRule]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f53a76f27bc8a833eb4b84f306201ac92eb11127d40bdb580e417983dd17dfc0(
    *,
    query: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__51fc805570b9ff57ffe19f4795ad05e012e82a3846247a9264051be4230c343b(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__60d9b2390bae4a6483599ba9aeabdef1d2e298a654d8d08fe9503eaf3b5bd51c(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e5891478438b6130f901e2f16eaa6105ab259097d2ffd8552d25cff3076c9e40(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__107b2e1fb4d88fddffb68710680a34d65db92fa746ce48ce43e5e9c9427b988a(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1654589bcedc5e79db032274b0097acc78de2b9b0d45092d90573e88793ebb14(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c9edc935efb062cdd4b0f771f1d09663e5a57ce621be9455ba9dc728d5733aef(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[WorkloadStatusConfigAutomaticRuleNrqlQuery]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fb67ece8726a7a4b4f4d93915ef7e98098b4d788c8fa6c644ff63faed65f9cb9(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6f465f2148167b1f5fac1637a38e3d646e3cbc24647a4aa1774ee373e1e2beeb(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__02349609303498b5b4f8aafe6459fd7a7d00b8ee65e2c4154d1d0b80800514e7(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, WorkloadStatusConfigAutomaticRuleNrqlQuery]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__87aa2c953b21bb7294a8b40357bfd8ca8432f88cfe4bfaf575a73c82f5ab5bf8(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b382504e3e18044e0d02e4ccb27286fa163122766bf976d2c5a4d1e9a937699f(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[WorkloadStatusConfigAutomaticRuleNrqlQuery, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8bafacf1f2cf1bdd44918807fbb6b7788056baa86c296fb4c95b6413765ef3cf(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__73584b51394bdf4417b1f50bf6f8288732424e104a2e8a54b0c9a516e468b770(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, WorkloadStatusConfigAutomaticRule]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8c4a612886ed41e52346e1e36d34705e5baf2d8829c13316fecec64769d91726(
    *,
    strategy: builtins.str,
    threshold_type: typing.Optional[builtins.str] = None,
    threshold_value: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2ffe17cdc75cbea4671739f0017670653eedc448536e37533b8aaeacf43b7d9f(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7591688d39bd762e306adfa31dcc45db32cfc4343f944aa71bf6ec1d2dac76ee(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3611b6b91c69d99d174b256f09967549915e9d3ab4e403e47df5ce195d35a5c0(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__93ffa372b857f96c0eb80d6d44a7a84682b010a23d6d12d1576fb752d46b4986(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__458b7fb4f24c1302abf1014efea2b5f3523350c42253c3537d797d50d51a6424(
    value: typing.Optional[WorkloadStatusConfigAutomaticRuleRollup],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__69fe07e1fb6f25960e1c9402acfeed2a48240154a86354f0bece23b582505853(
    *,
    enabled: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    status: builtins.str,
    description: typing.Optional[builtins.str] = None,
    summary: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c2b01d527114e0910d6e4af04999f3e7021e12a6fe6d16fae6e950261daef93d(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__38837c1d1cbc5025f7eac74608a7c8c5378dba40aebb2626578864c1555f3e2d(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__65de3d2e21b55eecd96b060436c7a630a8322f5984639228faa7882728ba84f8(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5a0a0962c49c4e68d106697df2e7b07282d6af04a09453be724709fdb6622e52(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6c5b9254cc37781a65e7922a8aa08c86f1a8d236b291287224c0f7c93a0d026f(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f9239d86da40640316d619728d56ea2a50048aceda58cb3b644f1c999a58c3a3(
    value: typing.Optional[WorkloadStatusConfigStatic],
) -> None:
    """Type checking stubs"""
    pass
