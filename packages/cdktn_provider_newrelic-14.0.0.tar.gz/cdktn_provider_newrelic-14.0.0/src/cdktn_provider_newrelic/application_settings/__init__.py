r'''
# `newrelic_application_settings`

Refer to the Terraform Registry for docs: [`newrelic_application_settings`](https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings).
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import cdktn as _cdktn_78ede62e
import constructs as _constructs_77d1e7e8


class ApplicationSettings(
    _cdktn_78ede62e.TerraformResource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.applicationSettings.ApplicationSettings",
):
    '''Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings newrelic_application_settings}.'''

    def __init__(
        self,
        scope: _constructs_77d1e7e8.Construct,
        id_: builtins.str,
        *,
        app_apdex_threshold: typing.Optional[jsii.Number] = None,
        enable_real_user_monitoring: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        enable_slow_sql: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        enable_thread_profiler: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        end_user_apdex_threshold: typing.Optional[jsii.Number] = None,
        error_collector: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["ApplicationSettingsErrorCollector", typing.Dict[builtins.str, typing.Any]]]]] = None,
        guid: typing.Optional[builtins.str] = None,
        id: typing.Optional[builtins.str] = None,
        name: typing.Optional[builtins.str] = None,
        tracer_type: typing.Optional[builtins.str] = None,
        transaction_tracer: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["ApplicationSettingsTransactionTracer", typing.Dict[builtins.str, typing.Any]]]]] = None,
        use_server_side_config: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings newrelic_application_settings} Resource.

        :param scope: The scope in which to define this construct.
        :param id_: The scoped construct ID. Must be unique amongst siblings in the same scope
        :param app_apdex_threshold: The response time threshold value for Apdex score calculation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#app_apdex_threshold ApplicationSettings#app_apdex_threshold}
        :param enable_real_user_monitoring: Dummy field to support backward compatibility of previous version.should be removed with next major version. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#enable_real_user_monitoring ApplicationSettings#enable_real_user_monitoring}
        :param enable_slow_sql: Samples and reports the slowest database queries in your traces. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#enable_slow_sql ApplicationSettings#enable_slow_sql}
        :param enable_thread_profiler: Enable or disable the thread profiler. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#enable_thread_profiler ApplicationSettings#enable_thread_profiler}
        :param end_user_apdex_threshold: Dummy field to support backward compatibility of previous version.should be removed with next major version. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#end_user_apdex_threshold ApplicationSettings#end_user_apdex_threshold}
        :param error_collector: error_collector block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#error_collector ApplicationSettings#error_collector}
        :param guid: The GUID of the application in New Relic. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#guid ApplicationSettings#guid}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#id ApplicationSettings#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param name: The name of the application in New Relic. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#name ApplicationSettings#name}
        :param tracer_type: The type of tracer to use, either 'CROSS_APPLICATION_TRACER', 'DISTRIBUTED_TRACING', 'NONE', or 'OPT_OUT'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#tracer_type ApplicationSettings#tracer_type}
        :param transaction_tracer: transaction_tracer block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#transaction_tracer ApplicationSettings#transaction_tracer}
        :param use_server_side_config: Enable or disable server side monitoring. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#use_server_side_config ApplicationSettings#use_server_side_config}
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f779ae9efc3bfa562a057b167ceb40f7373620adb99bda24dc86497a5a990b68)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id_", value=id_, expected_type=type_hints["id_"])
        config = ApplicationSettingsConfig(
            app_apdex_threshold=app_apdex_threshold,
            enable_real_user_monitoring=enable_real_user_monitoring,
            enable_slow_sql=enable_slow_sql,
            enable_thread_profiler=enable_thread_profiler,
            end_user_apdex_threshold=end_user_apdex_threshold,
            error_collector=error_collector,
            guid=guid,
            id=id,
            name=name,
            tracer_type=tracer_type,
            transaction_tracer=transaction_tracer,
            use_server_side_config=use_server_side_config,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        jsii.create(self.__class__, self, [scope, id_, config])

    @jsii.member(jsii_name="generateConfigForImport")
    @builtins.classmethod
    def generate_config_for_import(
        cls,
        scope: _constructs_77d1e7e8.Construct,
        import_to_id: builtins.str,
        import_from_id: builtins.str,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    ) -> _cdktn_78ede62e.ImportableResource:
        '''Generates CDKTN code for importing a ApplicationSettings resource upon running "cdktn plan ".

        :param scope: The scope in which to define this construct.
        :param import_to_id: The construct id used in the generated config for the ApplicationSettings to import.
        :param import_from_id: The id of the existing ApplicationSettings that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#import import section} in the documentation of this resource for the id to use
        :param provider: ? Optional instance of the provider where the ApplicationSettings to import is found.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9b5d87fa5b92b73169e19294857e09078f8b690e0fe47901d14389bd316bff2f)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument import_to_id", value=import_to_id, expected_type=type_hints["import_to_id"])
            check_type(argname="argument import_from_id", value=import_from_id, expected_type=type_hints["import_from_id"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
        return typing.cast(_cdktn_78ede62e.ImportableResource, jsii.sinvoke(cls, "generateConfigForImport", [scope, import_to_id, import_from_id, provider]))

    @jsii.member(jsii_name="putErrorCollector")
    def put_error_collector(
        self,
        value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["ApplicationSettingsErrorCollector", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__20a3b3d3ad5e8c72d109cde844b8d3c20a9f39937d9fe0d3fe38167b29e5d3af)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putErrorCollector", [value]))

    @jsii.member(jsii_name="putTransactionTracer")
    def put_transaction_tracer(
        self,
        value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["ApplicationSettingsTransactionTracer", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c8b7af03f5362586573564a5e3addf27fbf66ebf9ac34f01981d039f11bdb2ed)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putTransactionTracer", [value]))

    @jsii.member(jsii_name="resetAppApdexThreshold")
    def reset_app_apdex_threshold(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAppApdexThreshold", []))

    @jsii.member(jsii_name="resetEnableRealUserMonitoring")
    def reset_enable_real_user_monitoring(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEnableRealUserMonitoring", []))

    @jsii.member(jsii_name="resetEnableSlowSql")
    def reset_enable_slow_sql(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEnableSlowSql", []))

    @jsii.member(jsii_name="resetEnableThreadProfiler")
    def reset_enable_thread_profiler(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEnableThreadProfiler", []))

    @jsii.member(jsii_name="resetEndUserApdexThreshold")
    def reset_end_user_apdex_threshold(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEndUserApdexThreshold", []))

    @jsii.member(jsii_name="resetErrorCollector")
    def reset_error_collector(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetErrorCollector", []))

    @jsii.member(jsii_name="resetGuid")
    def reset_guid(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetGuid", []))

    @jsii.member(jsii_name="resetId")
    def reset_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetId", []))

    @jsii.member(jsii_name="resetName")
    def reset_name(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetName", []))

    @jsii.member(jsii_name="resetTracerType")
    def reset_tracer_type(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTracerType", []))

    @jsii.member(jsii_name="resetTransactionTracer")
    def reset_transaction_tracer(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTransactionTracer", []))

    @jsii.member(jsii_name="resetUseServerSideConfig")
    def reset_use_server_side_config(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetUseServerSideConfig", []))

    @jsii.member(jsii_name="synthesizeAttributes")
    def _synthesize_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeAttributes", []))

    @jsii.member(jsii_name="synthesizeHclAttributes")
    def _synthesize_hcl_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeHclAttributes", []))

    @jsii.python.classproperty
    @jsii.member(jsii_name="tfResourceType")
    def TF_RESOURCE_TYPE(cls) -> builtins.str:
        return typing.cast(builtins.str, jsii.sget(cls, "tfResourceType"))

    @builtins.property
    @jsii.member(jsii_name="errorCollector")
    def error_collector(self) -> "ApplicationSettingsErrorCollectorList":
        return typing.cast("ApplicationSettingsErrorCollectorList", jsii.get(self, "errorCollector"))

    @builtins.property
    @jsii.member(jsii_name="isImported")
    def is_imported(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "isImported"))

    @builtins.property
    @jsii.member(jsii_name="transactionTracer")
    def transaction_tracer(self) -> "ApplicationSettingsTransactionTracerList":
        return typing.cast("ApplicationSettingsTransactionTracerList", jsii.get(self, "transactionTracer"))

    @builtins.property
    @jsii.member(jsii_name="appApdexThresholdInput")
    def app_apdex_threshold_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "appApdexThresholdInput"))

    @builtins.property
    @jsii.member(jsii_name="enableRealUserMonitoringInput")
    def enable_real_user_monitoring_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "enableRealUserMonitoringInput"))

    @builtins.property
    @jsii.member(jsii_name="enableSlowSqlInput")
    def enable_slow_sql_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "enableSlowSqlInput"))

    @builtins.property
    @jsii.member(jsii_name="enableThreadProfilerInput")
    def enable_thread_profiler_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "enableThreadProfilerInput"))

    @builtins.property
    @jsii.member(jsii_name="endUserApdexThresholdInput")
    def end_user_apdex_threshold_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "endUserApdexThresholdInput"))

    @builtins.property
    @jsii.member(jsii_name="errorCollectorInput")
    def error_collector_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["ApplicationSettingsErrorCollector"]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["ApplicationSettingsErrorCollector"]]], jsii.get(self, "errorCollectorInput"))

    @builtins.property
    @jsii.member(jsii_name="guidInput")
    def guid_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "guidInput"))

    @builtins.property
    @jsii.member(jsii_name="idInput")
    def id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "idInput"))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="tracerTypeInput")
    def tracer_type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "tracerTypeInput"))

    @builtins.property
    @jsii.member(jsii_name="transactionTracerInput")
    def transaction_tracer_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["ApplicationSettingsTransactionTracer"]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["ApplicationSettingsTransactionTracer"]]], jsii.get(self, "transactionTracerInput"))

    @builtins.property
    @jsii.member(jsii_name="useServerSideConfigInput")
    def use_server_side_config_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "useServerSideConfigInput"))

    @builtins.property
    @jsii.member(jsii_name="appApdexThreshold")
    def app_apdex_threshold(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "appApdexThreshold"))

    @app_apdex_threshold.setter
    def app_apdex_threshold(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__80ebe786d8cd1b89ad7d252758210995c0008bd92a695d4c54747dea3585631e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "appApdexThreshold", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="enableRealUserMonitoring")
    def enable_real_user_monitoring(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "enableRealUserMonitoring"))

    @enable_real_user_monitoring.setter
    def enable_real_user_monitoring(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bb7b9c783793b6af03173f2665f52905148166aeb52fc0ec86949b2b4edaac4a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "enableRealUserMonitoring", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="enableSlowSql")
    def enable_slow_sql(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "enableSlowSql"))

    @enable_slow_sql.setter
    def enable_slow_sql(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3f64f6e25d6806915ce4d016c0f7f8fb0681c8142747846a5f926473d231c049)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "enableSlowSql", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="enableThreadProfiler")
    def enable_thread_profiler(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "enableThreadProfiler"))

    @enable_thread_profiler.setter
    def enable_thread_profiler(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b89a1bd11ab480ba12867b4ad57d9d5acd319ca6ea82b1b1e66c72f425d17af7)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "enableThreadProfiler", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="endUserApdexThreshold")
    def end_user_apdex_threshold(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "endUserApdexThreshold"))

    @end_user_apdex_threshold.setter
    def end_user_apdex_threshold(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__17db063130feaa5509225194d471e9d66c1b9973c84eff6d9b16f339d20bf270)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "endUserApdexThreshold", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="guid")
    def guid(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "guid"))

    @guid.setter
    def guid(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__de65c759350baaf3987c78b0a46d7cb5f2bae0c3254f5f1305605f5f63bce6fd)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "guid", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @id.setter
    def id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__52d2dd5a777ee9c6d8f4f183c9f1022ab897e786e42b18003791601c7fc0b9e6)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "id", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1a9f79cfd0da99b983e4ace05bc113140189172e0cd06db2d4e881872483a354)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="tracerType")
    def tracer_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "tracerType"))

    @tracer_type.setter
    def tracer_type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__43c92916ffb3c33ef6a8f4df64048475b5c3ee00c3fd99689e5a30660f098399)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "tracerType", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="useServerSideConfig")
    def use_server_side_config(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "useServerSideConfig"))

    @use_server_side_config.setter
    def use_server_side_config(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__aaf0d6a15fc606ae418ffab94f87af80eca5c7c44be5c4b5ecf0b4940d105b84)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "useServerSideConfig", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.applicationSettings.ApplicationSettingsConfig",
    jsii_struct_bases=[_cdktn_78ede62e.TerraformMetaArguments],
    name_mapping={
        "connection": "connection",
        "count": "count",
        "depends_on": "dependsOn",
        "for_each": "forEach",
        "lifecycle": "lifecycle",
        "provider": "provider",
        "provisioners": "provisioners",
        "app_apdex_threshold": "appApdexThreshold",
        "enable_real_user_monitoring": "enableRealUserMonitoring",
        "enable_slow_sql": "enableSlowSql",
        "enable_thread_profiler": "enableThreadProfiler",
        "end_user_apdex_threshold": "endUserApdexThreshold",
        "error_collector": "errorCollector",
        "guid": "guid",
        "id": "id",
        "name": "name",
        "tracer_type": "tracerType",
        "transaction_tracer": "transactionTracer",
        "use_server_side_config": "useServerSideConfig",
    },
)
class ApplicationSettingsConfig(_cdktn_78ede62e.TerraformMetaArguments):
    def __init__(
        self,
        *,
        connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
        app_apdex_threshold: typing.Optional[jsii.Number] = None,
        enable_real_user_monitoring: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        enable_slow_sql: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        enable_thread_profiler: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        end_user_apdex_threshold: typing.Optional[jsii.Number] = None,
        error_collector: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["ApplicationSettingsErrorCollector", typing.Dict[builtins.str, typing.Any]]]]] = None,
        guid: typing.Optional[builtins.str] = None,
        id: typing.Optional[builtins.str] = None,
        name: typing.Optional[builtins.str] = None,
        tracer_type: typing.Optional[builtins.str] = None,
        transaction_tracer: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["ApplicationSettingsTransactionTracer", typing.Dict[builtins.str, typing.Any]]]]] = None,
        use_server_side_config: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    ) -> None:
        '''
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        :param app_apdex_threshold: The response time threshold value for Apdex score calculation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#app_apdex_threshold ApplicationSettings#app_apdex_threshold}
        :param enable_real_user_monitoring: Dummy field to support backward compatibility of previous version.should be removed with next major version. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#enable_real_user_monitoring ApplicationSettings#enable_real_user_monitoring}
        :param enable_slow_sql: Samples and reports the slowest database queries in your traces. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#enable_slow_sql ApplicationSettings#enable_slow_sql}
        :param enable_thread_profiler: Enable or disable the thread profiler. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#enable_thread_profiler ApplicationSettings#enable_thread_profiler}
        :param end_user_apdex_threshold: Dummy field to support backward compatibility of previous version.should be removed with next major version. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#end_user_apdex_threshold ApplicationSettings#end_user_apdex_threshold}
        :param error_collector: error_collector block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#error_collector ApplicationSettings#error_collector}
        :param guid: The GUID of the application in New Relic. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#guid ApplicationSettings#guid}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#id ApplicationSettings#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param name: The name of the application in New Relic. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#name ApplicationSettings#name}
        :param tracer_type: The type of tracer to use, either 'CROSS_APPLICATION_TRACER', 'DISTRIBUTED_TRACING', 'NONE', or 'OPT_OUT'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#tracer_type ApplicationSettings#tracer_type}
        :param transaction_tracer: transaction_tracer block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#transaction_tracer ApplicationSettings#transaction_tracer}
        :param use_server_side_config: Enable or disable server side monitoring. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#use_server_side_config ApplicationSettings#use_server_side_config}
        '''
        if isinstance(lifecycle, dict):
            lifecycle = _cdktn_78ede62e.TerraformResourceLifecycle(**lifecycle)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__aaccc56e8aef2f97c14a8073e611ff73b5c060fd09cbfa28b050ee701c15f186)
            check_type(argname="argument connection", value=connection, expected_type=type_hints["connection"])
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument for_each", value=for_each, expected_type=type_hints["for_each"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
            check_type(argname="argument provisioners", value=provisioners, expected_type=type_hints["provisioners"])
            check_type(argname="argument app_apdex_threshold", value=app_apdex_threshold, expected_type=type_hints["app_apdex_threshold"])
            check_type(argname="argument enable_real_user_monitoring", value=enable_real_user_monitoring, expected_type=type_hints["enable_real_user_monitoring"])
            check_type(argname="argument enable_slow_sql", value=enable_slow_sql, expected_type=type_hints["enable_slow_sql"])
            check_type(argname="argument enable_thread_profiler", value=enable_thread_profiler, expected_type=type_hints["enable_thread_profiler"])
            check_type(argname="argument end_user_apdex_threshold", value=end_user_apdex_threshold, expected_type=type_hints["end_user_apdex_threshold"])
            check_type(argname="argument error_collector", value=error_collector, expected_type=type_hints["error_collector"])
            check_type(argname="argument guid", value=guid, expected_type=type_hints["guid"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument tracer_type", value=tracer_type, expected_type=type_hints["tracer_type"])
            check_type(argname="argument transaction_tracer", value=transaction_tracer, expected_type=type_hints["transaction_tracer"])
            check_type(argname="argument use_server_side_config", value=use_server_side_config, expected_type=type_hints["use_server_side_config"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if connection is not None:
            self._values["connection"] = connection
        if count is not None:
            self._values["count"] = count
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if for_each is not None:
            self._values["for_each"] = for_each
        if lifecycle is not None:
            self._values["lifecycle"] = lifecycle
        if provider is not None:
            self._values["provider"] = provider
        if provisioners is not None:
            self._values["provisioners"] = provisioners
        if app_apdex_threshold is not None:
            self._values["app_apdex_threshold"] = app_apdex_threshold
        if enable_real_user_monitoring is not None:
            self._values["enable_real_user_monitoring"] = enable_real_user_monitoring
        if enable_slow_sql is not None:
            self._values["enable_slow_sql"] = enable_slow_sql
        if enable_thread_profiler is not None:
            self._values["enable_thread_profiler"] = enable_thread_profiler
        if end_user_apdex_threshold is not None:
            self._values["end_user_apdex_threshold"] = end_user_apdex_threshold
        if error_collector is not None:
            self._values["error_collector"] = error_collector
        if guid is not None:
            self._values["guid"] = guid
        if id is not None:
            self._values["id"] = id
        if name is not None:
            self._values["name"] = name
        if tracer_type is not None:
            self._values["tracer_type"] = tracer_type
        if transaction_tracer is not None:
            self._values["transaction_tracer"] = transaction_tracer
        if use_server_side_config is not None:
            self._values["use_server_side_config"] = use_server_side_config

    @builtins.property
    def connection(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, _cdktn_78ede62e.WinrmProvisionerConnection]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("connection")
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, _cdktn_78ede62e.WinrmProvisionerConnection]], result)

    @builtins.property
    def count(
        self,
    ) -> typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("count")
        return typing.cast(typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]], result)

    @builtins.property
    def depends_on(
        self,
    ) -> typing.Optional[typing.List[_cdktn_78ede62e.ITerraformDependable]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List[_cdktn_78ede62e.ITerraformDependable]], result)

    @builtins.property
    def for_each(self) -> typing.Optional[_cdktn_78ede62e.ITerraformIterator]:
        '''
        :stability: experimental
        '''
        result = self._values.get("for_each")
        return typing.cast(typing.Optional[_cdktn_78ede62e.ITerraformIterator], result)

    @builtins.property
    def lifecycle(self) -> typing.Optional[_cdktn_78ede62e.TerraformResourceLifecycle]:
        '''
        :stability: experimental
        '''
        result = self._values.get("lifecycle")
        return typing.cast(typing.Optional[_cdktn_78ede62e.TerraformResourceLifecycle], result)

    @builtins.property
    def provider(self) -> typing.Optional[_cdktn_78ede62e.TerraformProvider]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provider")
        return typing.cast(typing.Optional[_cdktn_78ede62e.TerraformProvider], result)

    @builtins.property
    def provisioners(
        self,
    ) -> typing.Optional[typing.List[typing.Union[_cdktn_78ede62e.FileProvisioner, _cdktn_78ede62e.LocalExecProvisioner, _cdktn_78ede62e.RemoteExecProvisioner]]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provisioners")
        return typing.cast(typing.Optional[typing.List[typing.Union[_cdktn_78ede62e.FileProvisioner, _cdktn_78ede62e.LocalExecProvisioner, _cdktn_78ede62e.RemoteExecProvisioner]]], result)

    @builtins.property
    def app_apdex_threshold(self) -> typing.Optional[jsii.Number]:
        '''The response time threshold value for Apdex score calculation.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#app_apdex_threshold ApplicationSettings#app_apdex_threshold}
        '''
        result = self._values.get("app_apdex_threshold")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def enable_real_user_monitoring(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Dummy field to support backward compatibility of previous version.should be removed with next major version.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#enable_real_user_monitoring ApplicationSettings#enable_real_user_monitoring}
        '''
        result = self._values.get("enable_real_user_monitoring")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def enable_slow_sql(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Samples and reports the slowest database queries in your traces.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#enable_slow_sql ApplicationSettings#enable_slow_sql}
        '''
        result = self._values.get("enable_slow_sql")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def enable_thread_profiler(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Enable or disable the thread profiler.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#enable_thread_profiler ApplicationSettings#enable_thread_profiler}
        '''
        result = self._values.get("enable_thread_profiler")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def end_user_apdex_threshold(self) -> typing.Optional[jsii.Number]:
        '''Dummy field to support backward compatibility of previous version.should be removed with next major version.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#end_user_apdex_threshold ApplicationSettings#end_user_apdex_threshold}
        '''
        result = self._values.get("end_user_apdex_threshold")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def error_collector(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["ApplicationSettingsErrorCollector"]]]:
        '''error_collector block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#error_collector ApplicationSettings#error_collector}
        '''
        result = self._values.get("error_collector")
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["ApplicationSettingsErrorCollector"]]], result)

    @builtins.property
    def guid(self) -> typing.Optional[builtins.str]:
        '''The GUID of the application in New Relic.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#guid ApplicationSettings#guid}
        '''
        result = self._values.get("guid")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def id(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#id ApplicationSettings#id}.

        Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        '''
        result = self._values.get("id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def name(self) -> typing.Optional[builtins.str]:
        '''The name of the application in New Relic.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#name ApplicationSettings#name}
        '''
        result = self._values.get("name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def tracer_type(self) -> typing.Optional[builtins.str]:
        '''The type of tracer to use, either 'CROSS_APPLICATION_TRACER', 'DISTRIBUTED_TRACING', 'NONE', or 'OPT_OUT'.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#tracer_type ApplicationSettings#tracer_type}
        '''
        result = self._values.get("tracer_type")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def transaction_tracer(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["ApplicationSettingsTransactionTracer"]]]:
        '''transaction_tracer block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#transaction_tracer ApplicationSettings#transaction_tracer}
        '''
        result = self._values.get("transaction_tracer")
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["ApplicationSettingsTransactionTracer"]]], result)

    @builtins.property
    def use_server_side_config(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Enable or disable server side monitoring.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#use_server_side_config ApplicationSettings#use_server_side_config}
        '''
        result = self._values.get("use_server_side_config")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ApplicationSettingsConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.applicationSettings.ApplicationSettingsErrorCollector",
    jsii_struct_bases=[],
    name_mapping={
        "expected_error_classes": "expectedErrorClasses",
        "expected_error_codes": "expectedErrorCodes",
        "ignored_error_classes": "ignoredErrorClasses",
        "ignored_error_codes": "ignoredErrorCodes",
    },
)
class ApplicationSettingsErrorCollector:
    def __init__(
        self,
        *,
        expected_error_classes: typing.Optional[typing.Sequence[builtins.str]] = None,
        expected_error_codes: typing.Optional[typing.Sequence[builtins.str]] = None,
        ignored_error_classes: typing.Optional[typing.Sequence[builtins.str]] = None,
        ignored_error_codes: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param expected_error_classes: A list of error classes that are expected and should not trigger alerts. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#expected_error_classes ApplicationSettings#expected_error_classes}
        :param expected_error_codes: A list of error codes that are expected and should not trigger alerts. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#expected_error_codes ApplicationSettings#expected_error_codes}
        :param ignored_error_classes: A list of error classes that should be ignored. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#ignored_error_classes ApplicationSettings#ignored_error_classes}
        :param ignored_error_codes: A list of error codes that should be ignored. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#ignored_error_codes ApplicationSettings#ignored_error_codes}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__aefa850ff9f5ec908a909f5b8b0ee2fe257c15def474ff4fef21c8557d4d935c)
            check_type(argname="argument expected_error_classes", value=expected_error_classes, expected_type=type_hints["expected_error_classes"])
            check_type(argname="argument expected_error_codes", value=expected_error_codes, expected_type=type_hints["expected_error_codes"])
            check_type(argname="argument ignored_error_classes", value=ignored_error_classes, expected_type=type_hints["ignored_error_classes"])
            check_type(argname="argument ignored_error_codes", value=ignored_error_codes, expected_type=type_hints["ignored_error_codes"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if expected_error_classes is not None:
            self._values["expected_error_classes"] = expected_error_classes
        if expected_error_codes is not None:
            self._values["expected_error_codes"] = expected_error_codes
        if ignored_error_classes is not None:
            self._values["ignored_error_classes"] = ignored_error_classes
        if ignored_error_codes is not None:
            self._values["ignored_error_codes"] = ignored_error_codes

    @builtins.property
    def expected_error_classes(self) -> typing.Optional[typing.List[builtins.str]]:
        '''A list of error classes that are expected and should not trigger alerts.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#expected_error_classes ApplicationSettings#expected_error_classes}
        '''
        result = self._values.get("expected_error_classes")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def expected_error_codes(self) -> typing.Optional[typing.List[builtins.str]]:
        '''A list of error codes that are expected and should not trigger alerts.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#expected_error_codes ApplicationSettings#expected_error_codes}
        '''
        result = self._values.get("expected_error_codes")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def ignored_error_classes(self) -> typing.Optional[typing.List[builtins.str]]:
        '''A list of error classes that should be ignored.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#ignored_error_classes ApplicationSettings#ignored_error_classes}
        '''
        result = self._values.get("ignored_error_classes")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def ignored_error_codes(self) -> typing.Optional[typing.List[builtins.str]]:
        '''A list of error codes that should be ignored.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#ignored_error_codes ApplicationSettings#ignored_error_codes}
        '''
        result = self._values.get("ignored_error_codes")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ApplicationSettingsErrorCollector(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ApplicationSettingsErrorCollectorList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.applicationSettings.ApplicationSettingsErrorCollectorList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c5b380feab125227b8a800ec6d1a3971f3f0742b3634ae42f75970f72f9a1a50)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "ApplicationSettingsErrorCollectorOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__be65c0102d0547f82b5ef67a4826faa1eb7425189204894d0ae2d047eafee98a)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("ApplicationSettingsErrorCollectorOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1d920465f1f67793cc49c44b9072dac315af396892c1b766375781378557d6b7)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ebf2ed4a103b666cc17575ee28ca9024f31f5a8e39470e0e9a70b3854b6f2fac)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f34de26533131493864ef12f85d3d788bec34436e45f85211b36d0ebc7b58702)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[ApplicationSettingsErrorCollector]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[ApplicationSettingsErrorCollector]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[ApplicationSettingsErrorCollector]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bd5add74c929faf48a27f1efc7cfca68e3fc921dbef79e12b1f007ad4d64ff38)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class ApplicationSettingsErrorCollectorOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.applicationSettings.ApplicationSettingsErrorCollectorOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d65b3b41d2cfcc3618e43fd6c5eba568118fe9aee69c41e2cd198e4b45a93c62)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="resetExpectedErrorClasses")
    def reset_expected_error_classes(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetExpectedErrorClasses", []))

    @jsii.member(jsii_name="resetExpectedErrorCodes")
    def reset_expected_error_codes(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetExpectedErrorCodes", []))

    @jsii.member(jsii_name="resetIgnoredErrorClasses")
    def reset_ignored_error_classes(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetIgnoredErrorClasses", []))

    @jsii.member(jsii_name="resetIgnoredErrorCodes")
    def reset_ignored_error_codes(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetIgnoredErrorCodes", []))

    @builtins.property
    @jsii.member(jsii_name="expectedErrorClassesInput")
    def expected_error_classes_input(
        self,
    ) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "expectedErrorClassesInput"))

    @builtins.property
    @jsii.member(jsii_name="expectedErrorCodesInput")
    def expected_error_codes_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "expectedErrorCodesInput"))

    @builtins.property
    @jsii.member(jsii_name="ignoredErrorClassesInput")
    def ignored_error_classes_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "ignoredErrorClassesInput"))

    @builtins.property
    @jsii.member(jsii_name="ignoredErrorCodesInput")
    def ignored_error_codes_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "ignoredErrorCodesInput"))

    @builtins.property
    @jsii.member(jsii_name="expectedErrorClasses")
    def expected_error_classes(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "expectedErrorClasses"))

    @expected_error_classes.setter
    def expected_error_classes(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d649cfb67a78c2825d78fbd3bfaa5569a9a6929b4bffe080ed8d2090f7153677)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "expectedErrorClasses", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="expectedErrorCodes")
    def expected_error_codes(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "expectedErrorCodes"))

    @expected_error_codes.setter
    def expected_error_codes(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3a516dd8c97b05e11fe787be0d521f75f08f995ee4b867efbac8b81592ea9a4b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "expectedErrorCodes", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="ignoredErrorClasses")
    def ignored_error_classes(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "ignoredErrorClasses"))

    @ignored_error_classes.setter
    def ignored_error_classes(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5744590090eb9cbbdf16393fd4b389260af21e4fa57d66725ffe9d5838354ef9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "ignoredErrorClasses", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="ignoredErrorCodes")
    def ignored_error_codes(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "ignoredErrorCodes"))

    @ignored_error_codes.setter
    def ignored_error_codes(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2ec6acb3ae3356bc35c4765dca73da28274d713d42a14f85fc780caf8f20dc5e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "ignoredErrorCodes", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, ApplicationSettingsErrorCollector]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, ApplicationSettingsErrorCollector]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, ApplicationSettingsErrorCollector]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ff8bcac483ed050beacf05debe5b1dacfe31a6d31bc7b4d7401ba1efc93b920b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.applicationSettings.ApplicationSettingsTransactionTracer",
    jsii_struct_bases=[],
    name_mapping={
        "explain_query_plans": "explainQueryPlans",
        "sql": "sql",
        "stack_trace_threshold_value": "stackTraceThresholdValue",
        "transaction_threshold_type": "transactionThresholdType",
        "transaction_threshold_value": "transactionThresholdValue",
    },
)
class ApplicationSettingsTransactionTracer:
    def __init__(
        self,
        *,
        explain_query_plans: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["ApplicationSettingsTransactionTracerExplainQueryPlans", typing.Dict[builtins.str, typing.Any]]]]] = None,
        sql: typing.Optional[typing.Union["ApplicationSettingsTransactionTracerSql", typing.Dict[builtins.str, typing.Any]]] = None,
        stack_trace_threshold_value: typing.Optional[jsii.Number] = None,
        transaction_threshold_type: typing.Optional[builtins.str] = None,
        transaction_threshold_value: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param explain_query_plans: explain_query_plans block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#explain_query_plans ApplicationSettings#explain_query_plans}
        :param sql: sql block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#sql ApplicationSettings#sql}
        :param stack_trace_threshold_value: The response time threshold value for capturing stack traces of SQL queries. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#stack_trace_threshold_value ApplicationSettings#stack_trace_threshold_value}
        :param transaction_threshold_type: The type of threshold for transaction tracing, either 'APDEX_F' or 'VALUE'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#transaction_threshold_type ApplicationSettings#transaction_threshold_type}
        :param transaction_threshold_value: The threshold value for transaction tracing when 'transaction_threshold_type' is 'VALUE'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#transaction_threshold_value ApplicationSettings#transaction_threshold_value}
        '''
        if isinstance(sql, dict):
            sql = ApplicationSettingsTransactionTracerSql(**sql)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b3ff412a1213ccc1f3e6bb30d1487c4474c43b8d2beea834ef7f90fcf9d6f0e3)
            check_type(argname="argument explain_query_plans", value=explain_query_plans, expected_type=type_hints["explain_query_plans"])
            check_type(argname="argument sql", value=sql, expected_type=type_hints["sql"])
            check_type(argname="argument stack_trace_threshold_value", value=stack_trace_threshold_value, expected_type=type_hints["stack_trace_threshold_value"])
            check_type(argname="argument transaction_threshold_type", value=transaction_threshold_type, expected_type=type_hints["transaction_threshold_type"])
            check_type(argname="argument transaction_threshold_value", value=transaction_threshold_value, expected_type=type_hints["transaction_threshold_value"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if explain_query_plans is not None:
            self._values["explain_query_plans"] = explain_query_plans
        if sql is not None:
            self._values["sql"] = sql
        if stack_trace_threshold_value is not None:
            self._values["stack_trace_threshold_value"] = stack_trace_threshold_value
        if transaction_threshold_type is not None:
            self._values["transaction_threshold_type"] = transaction_threshold_type
        if transaction_threshold_value is not None:
            self._values["transaction_threshold_value"] = transaction_threshold_value

    @builtins.property
    def explain_query_plans(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["ApplicationSettingsTransactionTracerExplainQueryPlans"]]]:
        '''explain_query_plans block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#explain_query_plans ApplicationSettings#explain_query_plans}
        '''
        result = self._values.get("explain_query_plans")
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["ApplicationSettingsTransactionTracerExplainQueryPlans"]]], result)

    @builtins.property
    def sql(self) -> typing.Optional["ApplicationSettingsTransactionTracerSql"]:
        '''sql block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#sql ApplicationSettings#sql}
        '''
        result = self._values.get("sql")
        return typing.cast(typing.Optional["ApplicationSettingsTransactionTracerSql"], result)

    @builtins.property
    def stack_trace_threshold_value(self) -> typing.Optional[jsii.Number]:
        '''The response time threshold value for capturing stack traces of SQL queries.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#stack_trace_threshold_value ApplicationSettings#stack_trace_threshold_value}
        '''
        result = self._values.get("stack_trace_threshold_value")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def transaction_threshold_type(self) -> typing.Optional[builtins.str]:
        '''The type of threshold for transaction tracing, either 'APDEX_F' or 'VALUE'.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#transaction_threshold_type ApplicationSettings#transaction_threshold_type}
        '''
        result = self._values.get("transaction_threshold_type")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def transaction_threshold_value(self) -> typing.Optional[jsii.Number]:
        '''The threshold value for transaction tracing when 'transaction_threshold_type' is 'VALUE'.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#transaction_threshold_value ApplicationSettings#transaction_threshold_value}
        '''
        result = self._values.get("transaction_threshold_value")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ApplicationSettingsTransactionTracer(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.applicationSettings.ApplicationSettingsTransactionTracerExplainQueryPlans",
    jsii_struct_bases=[],
    name_mapping={
        "query_plan_threshold_type": "queryPlanThresholdType",
        "query_plan_threshold_value": "queryPlanThresholdValue",
    },
)
class ApplicationSettingsTransactionTracerExplainQueryPlans:
    def __init__(
        self,
        *,
        query_plan_threshold_type: typing.Optional[builtins.str] = None,
        query_plan_threshold_value: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param query_plan_threshold_type: The type of threshold for explain plans, either 'APDEX_F' or 'VALUE'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#query_plan_threshold_type ApplicationSettings#query_plan_threshold_type}
        :param query_plan_threshold_value: The threshold value for explain plans when 'query_plan_threshold_type' is 'VALUE'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#query_plan_threshold_value ApplicationSettings#query_plan_threshold_value}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__002a468e2db7389ee6faa06c207097d2d053824d223bfcae50f02abf97d30df2)
            check_type(argname="argument query_plan_threshold_type", value=query_plan_threshold_type, expected_type=type_hints["query_plan_threshold_type"])
            check_type(argname="argument query_plan_threshold_value", value=query_plan_threshold_value, expected_type=type_hints["query_plan_threshold_value"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if query_plan_threshold_type is not None:
            self._values["query_plan_threshold_type"] = query_plan_threshold_type
        if query_plan_threshold_value is not None:
            self._values["query_plan_threshold_value"] = query_plan_threshold_value

    @builtins.property
    def query_plan_threshold_type(self) -> typing.Optional[builtins.str]:
        '''The type of threshold for explain plans, either 'APDEX_F' or 'VALUE'.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#query_plan_threshold_type ApplicationSettings#query_plan_threshold_type}
        '''
        result = self._values.get("query_plan_threshold_type")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def query_plan_threshold_value(self) -> typing.Optional[jsii.Number]:
        '''The threshold value for explain plans when 'query_plan_threshold_type' is 'VALUE'.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#query_plan_threshold_value ApplicationSettings#query_plan_threshold_value}
        '''
        result = self._values.get("query_plan_threshold_value")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ApplicationSettingsTransactionTracerExplainQueryPlans(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ApplicationSettingsTransactionTracerExplainQueryPlansList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.applicationSettings.ApplicationSettingsTransactionTracerExplainQueryPlansList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__447be56dcaa10e534d78740ceafce09e7e0a0bc3ab67be5fe80f8d7a6924f4c7)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "ApplicationSettingsTransactionTracerExplainQueryPlansOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c7b6b628b1d419de27806d907d293bc87777fc7ab11fe3457203f52b96d11d4d)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("ApplicationSettingsTransactionTracerExplainQueryPlansOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5afba187ab790ee50f4878e72bcc5eec3a364ce8e29534756b5443cc0acc4f94)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__df6a03bd49e85ab5829916fae9080b9c9ea15640d72b4b9ace227c97ca752fa8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__73e4b1385a77ce4e29c19c42fe3668c79fcc8afb1616e617558e1a136e865b97)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[ApplicationSettingsTransactionTracerExplainQueryPlans]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[ApplicationSettingsTransactionTracerExplainQueryPlans]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[ApplicationSettingsTransactionTracerExplainQueryPlans]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ff322f31525324b07265bf3ae7e1398f3d4a6da2d0257e427c8ffa38e85d52cd)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class ApplicationSettingsTransactionTracerExplainQueryPlansOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.applicationSettings.ApplicationSettingsTransactionTracerExplainQueryPlansOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4b27505e39f1ca0e39081f694b5cb1861e4c021610438994a6dd9871bc1c4655)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="resetQueryPlanThresholdType")
    def reset_query_plan_threshold_type(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetQueryPlanThresholdType", []))

    @jsii.member(jsii_name="resetQueryPlanThresholdValue")
    def reset_query_plan_threshold_value(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetQueryPlanThresholdValue", []))

    @builtins.property
    @jsii.member(jsii_name="queryPlanThresholdTypeInput")
    def query_plan_threshold_type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "queryPlanThresholdTypeInput"))

    @builtins.property
    @jsii.member(jsii_name="queryPlanThresholdValueInput")
    def query_plan_threshold_value_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "queryPlanThresholdValueInput"))

    @builtins.property
    @jsii.member(jsii_name="queryPlanThresholdType")
    def query_plan_threshold_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "queryPlanThresholdType"))

    @query_plan_threshold_type.setter
    def query_plan_threshold_type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fc02a70ecfa9c2c8eaad7e7fc540dd3660fa475464c1d362262a50d7ab2ee91c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "queryPlanThresholdType", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="queryPlanThresholdValue")
    def query_plan_threshold_value(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "queryPlanThresholdValue"))

    @query_plan_threshold_value.setter
    def query_plan_threshold_value(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7541d077380ff73869d36c7c5a71504b77ed22ff88487f8fbf46acb834f41816)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "queryPlanThresholdValue", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, ApplicationSettingsTransactionTracerExplainQueryPlans]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, ApplicationSettingsTransactionTracerExplainQueryPlans]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, ApplicationSettingsTransactionTracerExplainQueryPlans]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cebfeb7de95275a1f3b8286dc44cb3da94f1270a895559468ff393e664732b68)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class ApplicationSettingsTransactionTracerList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.applicationSettings.ApplicationSettingsTransactionTracerList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c07cd290a53cdfe84628bc5ad092c9d595d3031abab3b46d37dcfb65158874b2)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "ApplicationSettingsTransactionTracerOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0fe10f5639e43d2a163d4779530cde6a3877eb70de1eec7515cb64010131b479)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("ApplicationSettingsTransactionTracerOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__81c0fdf27d94850e38abf89eafd385ef1637c5de3727689cf6051bacf169b20e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__82e4e84208277389a34285b607940bccd1f0a5ebde478f07946036e289f6da36)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d1f1e3192a30377515d7a7c944355500e946b23fcd91356441ff90bbff6970c6)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[ApplicationSettingsTransactionTracer]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[ApplicationSettingsTransactionTracer]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[ApplicationSettingsTransactionTracer]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__440449ceee5ff9014e8d13aaa813c8d4f809e0300ce76073cae9ccc5d2dd493e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class ApplicationSettingsTransactionTracerOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.applicationSettings.ApplicationSettingsTransactionTracerOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bf05bc75aa7912402a678de267f088c2b541ea0a1fdcf449a6a23942b9886d95)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="putExplainQueryPlans")
    def put_explain_query_plans(
        self,
        value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[ApplicationSettingsTransactionTracerExplainQueryPlans, typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c152cb9d967938634142eb8a4e6226c6693119a873068ec0761b5581e0e0a498)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putExplainQueryPlans", [value]))

    @jsii.member(jsii_name="putSql")
    def put_sql(self, *, record_sql: builtins.str) -> None:
        '''
        :param record_sql: The level of SQL recording, either 'OBFUSCATED', 'OFF', or 'RAW'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#record_sql ApplicationSettings#record_sql}
        '''
        value = ApplicationSettingsTransactionTracerSql(record_sql=record_sql)

        return typing.cast(None, jsii.invoke(self, "putSql", [value]))

    @jsii.member(jsii_name="resetExplainQueryPlans")
    def reset_explain_query_plans(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetExplainQueryPlans", []))

    @jsii.member(jsii_name="resetSql")
    def reset_sql(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSql", []))

    @jsii.member(jsii_name="resetStackTraceThresholdValue")
    def reset_stack_trace_threshold_value(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetStackTraceThresholdValue", []))

    @jsii.member(jsii_name="resetTransactionThresholdType")
    def reset_transaction_threshold_type(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTransactionThresholdType", []))

    @jsii.member(jsii_name="resetTransactionThresholdValue")
    def reset_transaction_threshold_value(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTransactionThresholdValue", []))

    @builtins.property
    @jsii.member(jsii_name="explainQueryPlans")
    def explain_query_plans(
        self,
    ) -> ApplicationSettingsTransactionTracerExplainQueryPlansList:
        return typing.cast(ApplicationSettingsTransactionTracerExplainQueryPlansList, jsii.get(self, "explainQueryPlans"))

    @builtins.property
    @jsii.member(jsii_name="sql")
    def sql(self) -> "ApplicationSettingsTransactionTracerSqlOutputReference":
        return typing.cast("ApplicationSettingsTransactionTracerSqlOutputReference", jsii.get(self, "sql"))

    @builtins.property
    @jsii.member(jsii_name="explainQueryPlansInput")
    def explain_query_plans_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[ApplicationSettingsTransactionTracerExplainQueryPlans]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[ApplicationSettingsTransactionTracerExplainQueryPlans]]], jsii.get(self, "explainQueryPlansInput"))

    @builtins.property
    @jsii.member(jsii_name="sqlInput")
    def sql_input(self) -> typing.Optional["ApplicationSettingsTransactionTracerSql"]:
        return typing.cast(typing.Optional["ApplicationSettingsTransactionTracerSql"], jsii.get(self, "sqlInput"))

    @builtins.property
    @jsii.member(jsii_name="stackTraceThresholdValueInput")
    def stack_trace_threshold_value_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "stackTraceThresholdValueInput"))

    @builtins.property
    @jsii.member(jsii_name="transactionThresholdTypeInput")
    def transaction_threshold_type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "transactionThresholdTypeInput"))

    @builtins.property
    @jsii.member(jsii_name="transactionThresholdValueInput")
    def transaction_threshold_value_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "transactionThresholdValueInput"))

    @builtins.property
    @jsii.member(jsii_name="stackTraceThresholdValue")
    def stack_trace_threshold_value(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "stackTraceThresholdValue"))

    @stack_trace_threshold_value.setter
    def stack_trace_threshold_value(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__82ee73f4554fe8472f718b110aa2646f525cb6f700351b025d925808b83e47e9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "stackTraceThresholdValue", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="transactionThresholdType")
    def transaction_threshold_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "transactionThresholdType"))

    @transaction_threshold_type.setter
    def transaction_threshold_type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6bcdfb5880c02621829d3c4634361b434859061d333aa739ba611976a41b4b93)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "transactionThresholdType", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="transactionThresholdValue")
    def transaction_threshold_value(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "transactionThresholdValue"))

    @transaction_threshold_value.setter
    def transaction_threshold_value(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__46ef2ac16cf8dfe48ba135fbf91002918dd09374a373bab6a62e3355beea8e63)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "transactionThresholdValue", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, ApplicationSettingsTransactionTracer]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, ApplicationSettingsTransactionTracer]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, ApplicationSettingsTransactionTracer]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b26b6fa5f850306fb0bfd157732002ed1a27c8ee02719b75c19aae37cbe617c0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.applicationSettings.ApplicationSettingsTransactionTracerSql",
    jsii_struct_bases=[],
    name_mapping={"record_sql": "recordSql"},
)
class ApplicationSettingsTransactionTracerSql:
    def __init__(self, *, record_sql: builtins.str) -> None:
        '''
        :param record_sql: The level of SQL recording, either 'OBFUSCATED', 'OFF', or 'RAW'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#record_sql ApplicationSettings#record_sql}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4f2d96e847a76c779c37e87831f01d21ce85d4f43155bca822035e230941f2d0)
            check_type(argname="argument record_sql", value=record_sql, expected_type=type_hints["record_sql"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "record_sql": record_sql,
        }

    @builtins.property
    def record_sql(self) -> builtins.str:
        '''The level of SQL recording, either 'OBFUSCATED', 'OFF', or 'RAW'.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/application_settings#record_sql ApplicationSettings#record_sql}
        '''
        result = self._values.get("record_sql")
        assert result is not None, "Required property 'record_sql' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ApplicationSettingsTransactionTracerSql(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ApplicationSettingsTransactionTracerSqlOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.applicationSettings.ApplicationSettingsTransactionTracerSqlOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1a50049d1fd4529e2c1c698a590a8444ceac52292e4baf729168cdfb2e74c20f)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @builtins.property
    @jsii.member(jsii_name="recordSqlInput")
    def record_sql_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "recordSqlInput"))

    @builtins.property
    @jsii.member(jsii_name="recordSql")
    def record_sql(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "recordSql"))

    @record_sql.setter
    def record_sql(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d48c7efa85a34346537ece8cb60dc9d04576d0224fd0881fc9cf1694633f8295)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "recordSql", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[ApplicationSettingsTransactionTracerSql]:
        return typing.cast(typing.Optional[ApplicationSettingsTransactionTracerSql], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[ApplicationSettingsTransactionTracerSql],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__634440e0bf9bf4fdac491ca3e950657cc7c4246dcdab40d5077afaee61d1a5fc)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


__all__ = [
    "ApplicationSettings",
    "ApplicationSettingsConfig",
    "ApplicationSettingsErrorCollector",
    "ApplicationSettingsErrorCollectorList",
    "ApplicationSettingsErrorCollectorOutputReference",
    "ApplicationSettingsTransactionTracer",
    "ApplicationSettingsTransactionTracerExplainQueryPlans",
    "ApplicationSettingsTransactionTracerExplainQueryPlansList",
    "ApplicationSettingsTransactionTracerExplainQueryPlansOutputReference",
    "ApplicationSettingsTransactionTracerList",
    "ApplicationSettingsTransactionTracerOutputReference",
    "ApplicationSettingsTransactionTracerSql",
    "ApplicationSettingsTransactionTracerSqlOutputReference",
]

publication.publish()

def _typecheckingstub__f779ae9efc3bfa562a057b167ceb40f7373620adb99bda24dc86497a5a990b68(
    scope: _constructs_77d1e7e8.Construct,
    id_: builtins.str,
    *,
    app_apdex_threshold: typing.Optional[jsii.Number] = None,
    enable_real_user_monitoring: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    enable_slow_sql: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    enable_thread_profiler: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    end_user_apdex_threshold: typing.Optional[jsii.Number] = None,
    error_collector: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[ApplicationSettingsErrorCollector, typing.Dict[builtins.str, typing.Any]]]]] = None,
    guid: typing.Optional[builtins.str] = None,
    id: typing.Optional[builtins.str] = None,
    name: typing.Optional[builtins.str] = None,
    tracer_type: typing.Optional[builtins.str] = None,
    transaction_tracer: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[ApplicationSettingsTransactionTracer, typing.Dict[builtins.str, typing.Any]]]]] = None,
    use_server_side_config: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9b5d87fa5b92b73169e19294857e09078f8b690e0fe47901d14389bd316bff2f(
    scope: _constructs_77d1e7e8.Construct,
    import_to_id: builtins.str,
    import_from_id: builtins.str,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__20a3b3d3ad5e8c72d109cde844b8d3c20a9f39937d9fe0d3fe38167b29e5d3af(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[ApplicationSettingsErrorCollector, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c8b7af03f5362586573564a5e3addf27fbf66ebf9ac34f01981d039f11bdb2ed(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[ApplicationSettingsTransactionTracer, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__80ebe786d8cd1b89ad7d252758210995c0008bd92a695d4c54747dea3585631e(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bb7b9c783793b6af03173f2665f52905148166aeb52fc0ec86949b2b4edaac4a(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3f64f6e25d6806915ce4d016c0f7f8fb0681c8142747846a5f926473d231c049(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b89a1bd11ab480ba12867b4ad57d9d5acd319ca6ea82b1b1e66c72f425d17af7(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__17db063130feaa5509225194d471e9d66c1b9973c84eff6d9b16f339d20bf270(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__de65c759350baaf3987c78b0a46d7cb5f2bae0c3254f5f1305605f5f63bce6fd(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__52d2dd5a777ee9c6d8f4f183c9f1022ab897e786e42b18003791601c7fc0b9e6(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1a9f79cfd0da99b983e4ace05bc113140189172e0cd06db2d4e881872483a354(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__43c92916ffb3c33ef6a8f4df64048475b5c3ee00c3fd99689e5a30660f098399(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__aaf0d6a15fc606ae418ffab94f87af80eca5c7c44be5c4b5ecf0b4940d105b84(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__aaccc56e8aef2f97c14a8073e611ff73b5c060fd09cbfa28b050ee701c15f186(
    *,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    app_apdex_threshold: typing.Optional[jsii.Number] = None,
    enable_real_user_monitoring: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    enable_slow_sql: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    enable_thread_profiler: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    end_user_apdex_threshold: typing.Optional[jsii.Number] = None,
    error_collector: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[ApplicationSettingsErrorCollector, typing.Dict[builtins.str, typing.Any]]]]] = None,
    guid: typing.Optional[builtins.str] = None,
    id: typing.Optional[builtins.str] = None,
    name: typing.Optional[builtins.str] = None,
    tracer_type: typing.Optional[builtins.str] = None,
    transaction_tracer: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[ApplicationSettingsTransactionTracer, typing.Dict[builtins.str, typing.Any]]]]] = None,
    use_server_side_config: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__aefa850ff9f5ec908a909f5b8b0ee2fe257c15def474ff4fef21c8557d4d935c(
    *,
    expected_error_classes: typing.Optional[typing.Sequence[builtins.str]] = None,
    expected_error_codes: typing.Optional[typing.Sequence[builtins.str]] = None,
    ignored_error_classes: typing.Optional[typing.Sequence[builtins.str]] = None,
    ignored_error_codes: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c5b380feab125227b8a800ec6d1a3971f3f0742b3634ae42f75970f72f9a1a50(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__be65c0102d0547f82b5ef67a4826faa1eb7425189204894d0ae2d047eafee98a(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1d920465f1f67793cc49c44b9072dac315af396892c1b766375781378557d6b7(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ebf2ed4a103b666cc17575ee28ca9024f31f5a8e39470e0e9a70b3854b6f2fac(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f34de26533131493864ef12f85d3d788bec34436e45f85211b36d0ebc7b58702(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bd5add74c929faf48a27f1efc7cfca68e3fc921dbef79e12b1f007ad4d64ff38(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[ApplicationSettingsErrorCollector]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d65b3b41d2cfcc3618e43fd6c5eba568118fe9aee69c41e2cd198e4b45a93c62(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d649cfb67a78c2825d78fbd3bfaa5569a9a6929b4bffe080ed8d2090f7153677(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3a516dd8c97b05e11fe787be0d521f75f08f995ee4b867efbac8b81592ea9a4b(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5744590090eb9cbbdf16393fd4b389260af21e4fa57d66725ffe9d5838354ef9(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2ec6acb3ae3356bc35c4765dca73da28274d713d42a14f85fc780caf8f20dc5e(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ff8bcac483ed050beacf05debe5b1dacfe31a6d31bc7b4d7401ba1efc93b920b(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, ApplicationSettingsErrorCollector]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b3ff412a1213ccc1f3e6bb30d1487c4474c43b8d2beea834ef7f90fcf9d6f0e3(
    *,
    explain_query_plans: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[ApplicationSettingsTransactionTracerExplainQueryPlans, typing.Dict[builtins.str, typing.Any]]]]] = None,
    sql: typing.Optional[typing.Union[ApplicationSettingsTransactionTracerSql, typing.Dict[builtins.str, typing.Any]]] = None,
    stack_trace_threshold_value: typing.Optional[jsii.Number] = None,
    transaction_threshold_type: typing.Optional[builtins.str] = None,
    transaction_threshold_value: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__002a468e2db7389ee6faa06c207097d2d053824d223bfcae50f02abf97d30df2(
    *,
    query_plan_threshold_type: typing.Optional[builtins.str] = None,
    query_plan_threshold_value: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__447be56dcaa10e534d78740ceafce09e7e0a0bc3ab67be5fe80f8d7a6924f4c7(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c7b6b628b1d419de27806d907d293bc87777fc7ab11fe3457203f52b96d11d4d(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5afba187ab790ee50f4878e72bcc5eec3a364ce8e29534756b5443cc0acc4f94(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__df6a03bd49e85ab5829916fae9080b9c9ea15640d72b4b9ace227c97ca752fa8(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__73e4b1385a77ce4e29c19c42fe3668c79fcc8afb1616e617558e1a136e865b97(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ff322f31525324b07265bf3ae7e1398f3d4a6da2d0257e427c8ffa38e85d52cd(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[ApplicationSettingsTransactionTracerExplainQueryPlans]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4b27505e39f1ca0e39081f694b5cb1861e4c021610438994a6dd9871bc1c4655(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fc02a70ecfa9c2c8eaad7e7fc540dd3660fa475464c1d362262a50d7ab2ee91c(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7541d077380ff73869d36c7c5a71504b77ed22ff88487f8fbf46acb834f41816(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cebfeb7de95275a1f3b8286dc44cb3da94f1270a895559468ff393e664732b68(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, ApplicationSettingsTransactionTracerExplainQueryPlans]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c07cd290a53cdfe84628bc5ad092c9d595d3031abab3b46d37dcfb65158874b2(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0fe10f5639e43d2a163d4779530cde6a3877eb70de1eec7515cb64010131b479(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__81c0fdf27d94850e38abf89eafd385ef1637c5de3727689cf6051bacf169b20e(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__82e4e84208277389a34285b607940bccd1f0a5ebde478f07946036e289f6da36(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d1f1e3192a30377515d7a7c944355500e946b23fcd91356441ff90bbff6970c6(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__440449ceee5ff9014e8d13aaa813c8d4f809e0300ce76073cae9ccc5d2dd493e(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[ApplicationSettingsTransactionTracer]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bf05bc75aa7912402a678de267f088c2b541ea0a1fdcf449a6a23942b9886d95(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c152cb9d967938634142eb8a4e6226c6693119a873068ec0761b5581e0e0a498(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[ApplicationSettingsTransactionTracerExplainQueryPlans, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__82ee73f4554fe8472f718b110aa2646f525cb6f700351b025d925808b83e47e9(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6bcdfb5880c02621829d3c4634361b434859061d333aa739ba611976a41b4b93(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__46ef2ac16cf8dfe48ba135fbf91002918dd09374a373bab6a62e3355beea8e63(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b26b6fa5f850306fb0bfd157732002ed1a27c8ee02719b75c19aae37cbe617c0(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, ApplicationSettingsTransactionTracer]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4f2d96e847a76c779c37e87831f01d21ce85d4f43155bca822035e230941f2d0(
    *,
    record_sql: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1a50049d1fd4529e2c1c698a590a8444ceac52292e4baf729168cdfb2e74c20f(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d48c7efa85a34346537ece8cb60dc9d04576d0224fd0881fc9cf1694633f8295(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__634440e0bf9bf4fdac491ca3e950657cc7c4246dcdab40d5077afaee61d1a5fc(
    value: typing.Optional[ApplicationSettingsTransactionTracerSql],
) -> None:
    """Type checking stubs"""
    pass
