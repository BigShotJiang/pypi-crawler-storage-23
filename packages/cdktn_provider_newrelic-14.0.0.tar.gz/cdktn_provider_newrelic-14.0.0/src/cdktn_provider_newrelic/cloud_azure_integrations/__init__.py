r'''
# `newrelic_cloud_azure_integrations`

Refer to the Terraform Registry for docs: [`newrelic_cloud_azure_integrations`](https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations).
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import cdktn as _cdktn_78ede62e
import constructs as _constructs_77d1e7e8


class CloudAzureIntegrations(
    _cdktn_78ede62e.TerraformResource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrations",
):
    '''Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations newrelic_cloud_azure_integrations}.'''

    def __init__(
        self,
        scope: _constructs_77d1e7e8.Construct,
        id_: builtins.str,
        *,
        linked_account_id: jsii.Number,
        account_id: typing.Optional[jsii.Number] = None,
        api_management: typing.Optional[typing.Union["CloudAzureIntegrationsApiManagement", typing.Dict[builtins.str, typing.Any]]] = None,
        app_gateway: typing.Optional[typing.Union["CloudAzureIntegrationsAppGateway", typing.Dict[builtins.str, typing.Any]]] = None,
        app_service: typing.Optional[typing.Union["CloudAzureIntegrationsAppService", typing.Dict[builtins.str, typing.Any]]] = None,
        auto_discovery: typing.Optional[typing.Union["CloudAzureIntegrationsAutoDiscovery", typing.Dict[builtins.str, typing.Any]]] = None,
        containers: typing.Optional[typing.Union["CloudAzureIntegrationsContainers", typing.Dict[builtins.str, typing.Any]]] = None,
        cosmos_db: typing.Optional[typing.Union["CloudAzureIntegrationsCosmosDb", typing.Dict[builtins.str, typing.Any]]] = None,
        cost_management: typing.Optional[typing.Union["CloudAzureIntegrationsCostManagement", typing.Dict[builtins.str, typing.Any]]] = None,
        data_factory: typing.Optional[typing.Union["CloudAzureIntegrationsDataFactory", typing.Dict[builtins.str, typing.Any]]] = None,
        event_hub: typing.Optional[typing.Union["CloudAzureIntegrationsEventHub", typing.Dict[builtins.str, typing.Any]]] = None,
        express_route: typing.Optional[typing.Union["CloudAzureIntegrationsExpressRoute", typing.Dict[builtins.str, typing.Any]]] = None,
        firewalls: typing.Optional[typing.Union["CloudAzureIntegrationsFirewalls", typing.Dict[builtins.str, typing.Any]]] = None,
        front_door: typing.Optional[typing.Union["CloudAzureIntegrationsFrontDoor", typing.Dict[builtins.str, typing.Any]]] = None,
        functions: typing.Optional[typing.Union["CloudAzureIntegrationsFunctions", typing.Dict[builtins.str, typing.Any]]] = None,
        id: typing.Optional[builtins.str] = None,
        key_vault: typing.Optional[typing.Union["CloudAzureIntegrationsKeyVault", typing.Dict[builtins.str, typing.Any]]] = None,
        load_balancer: typing.Optional[typing.Union["CloudAzureIntegrationsLoadBalancer", typing.Dict[builtins.str, typing.Any]]] = None,
        logic_apps: typing.Optional[typing.Union["CloudAzureIntegrationsLogicApps", typing.Dict[builtins.str, typing.Any]]] = None,
        machine_learning: typing.Optional[typing.Union["CloudAzureIntegrationsMachineLearning", typing.Dict[builtins.str, typing.Any]]] = None,
        maria_db: typing.Optional[typing.Union["CloudAzureIntegrationsMariaDb", typing.Dict[builtins.str, typing.Any]]] = None,
        monitor: typing.Optional[typing.Union["CloudAzureIntegrationsMonitor", typing.Dict[builtins.str, typing.Any]]] = None,
        mysql: typing.Optional[typing.Union["CloudAzureIntegrationsMysql", typing.Dict[builtins.str, typing.Any]]] = None,
        mysql_flexible: typing.Optional[typing.Union["CloudAzureIntegrationsMysqlFlexible", typing.Dict[builtins.str, typing.Any]]] = None,
        postgresql: typing.Optional[typing.Union["CloudAzureIntegrationsPostgresql", typing.Dict[builtins.str, typing.Any]]] = None,
        postgresql_flexible: typing.Optional[typing.Union["CloudAzureIntegrationsPostgresqlFlexible", typing.Dict[builtins.str, typing.Any]]] = None,
        power_bi_dedicated: typing.Optional[typing.Union["CloudAzureIntegrationsPowerBiDedicated", typing.Dict[builtins.str, typing.Any]]] = None,
        redis_cache: typing.Optional[typing.Union["CloudAzureIntegrationsRedisCache", typing.Dict[builtins.str, typing.Any]]] = None,
        service_bus: typing.Optional[typing.Union["CloudAzureIntegrationsServiceBus", typing.Dict[builtins.str, typing.Any]]] = None,
        sql: typing.Optional[typing.Union["CloudAzureIntegrationsSql", typing.Dict[builtins.str, typing.Any]]] = None,
        sql_managed: typing.Optional[typing.Union["CloudAzureIntegrationsSqlManaged", typing.Dict[builtins.str, typing.Any]]] = None,
        storage: typing.Optional[typing.Union["CloudAzureIntegrationsStorage", typing.Dict[builtins.str, typing.Any]]] = None,
        virtual_machine: typing.Optional[typing.Union["CloudAzureIntegrationsVirtualMachine", typing.Dict[builtins.str, typing.Any]]] = None,
        virtual_networks: typing.Optional[typing.Union["CloudAzureIntegrationsVirtualNetworks", typing.Dict[builtins.str, typing.Any]]] = None,
        vms: typing.Optional[typing.Union["CloudAzureIntegrationsVms", typing.Dict[builtins.str, typing.Any]]] = None,
        vpn_gateway: typing.Optional[typing.Union["CloudAzureIntegrationsVpnGateway", typing.Dict[builtins.str, typing.Any]]] = None,
        connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations newrelic_cloud_azure_integrations} Resource.

        :param scope: The scope in which to define this construct.
        :param id_: The scoped construct ID. Must be unique amongst siblings in the same scope
        :param linked_account_id: The ID of the linked Azure account in New Relic. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#linked_account_id CloudAzureIntegrations#linked_account_id}
        :param account_id: The ID of the account in New Relic. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#account_id CloudAzureIntegrations#account_id}
        :param api_management: api_management block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#api_management CloudAzureIntegrations#api_management}
        :param app_gateway: app_gateway block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#app_gateway CloudAzureIntegrations#app_gateway}
        :param app_service: app_service block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#app_service CloudAzureIntegrations#app_service}
        :param auto_discovery: auto_discovery block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#auto_discovery CloudAzureIntegrations#auto_discovery}
        :param containers: containers block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#containers CloudAzureIntegrations#containers}
        :param cosmos_db: cosmos_db block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#cosmos_db CloudAzureIntegrations#cosmos_db}
        :param cost_management: cost_management block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#cost_management CloudAzureIntegrations#cost_management}
        :param data_factory: data_factory block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#data_factory CloudAzureIntegrations#data_factory}
        :param event_hub: event_hub block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#event_hub CloudAzureIntegrations#event_hub}
        :param express_route: express_route block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#express_route CloudAzureIntegrations#express_route}
        :param firewalls: firewalls block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#firewalls CloudAzureIntegrations#firewalls}
        :param front_door: front_door block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#front_door CloudAzureIntegrations#front_door}
        :param functions: functions block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#functions CloudAzureIntegrations#functions}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#id CloudAzureIntegrations#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param key_vault: key_vault block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#key_vault CloudAzureIntegrations#key_vault}
        :param load_balancer: load_balancer block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#load_balancer CloudAzureIntegrations#load_balancer}
        :param logic_apps: logic_apps block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#logic_apps CloudAzureIntegrations#logic_apps}
        :param machine_learning: machine_learning block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#machine_learning CloudAzureIntegrations#machine_learning}
        :param maria_db: maria_db block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#maria_db CloudAzureIntegrations#maria_db}
        :param monitor: monitor block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#monitor CloudAzureIntegrations#monitor}
        :param mysql: mysql block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#mysql CloudAzureIntegrations#mysql}
        :param mysql_flexible: mysql_flexible block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#mysql_flexible CloudAzureIntegrations#mysql_flexible}
        :param postgresql: postgresql block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#postgresql CloudAzureIntegrations#postgresql}
        :param postgresql_flexible: postgresql_flexible block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#postgresql_flexible CloudAzureIntegrations#postgresql_flexible}
        :param power_bi_dedicated: power_bi_dedicated block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#power_bi_dedicated CloudAzureIntegrations#power_bi_dedicated}
        :param redis_cache: redis_cache block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#redis_cache CloudAzureIntegrations#redis_cache}
        :param service_bus: service_bus block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#service_bus CloudAzureIntegrations#service_bus}
        :param sql: sql block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#sql CloudAzureIntegrations#sql}
        :param sql_managed: sql_managed block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#sql_managed CloudAzureIntegrations#sql_managed}
        :param storage: storage block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#storage CloudAzureIntegrations#storage}
        :param virtual_machine: virtual_machine block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#virtual_machine CloudAzureIntegrations#virtual_machine}
        :param virtual_networks: virtual_networks block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#virtual_networks CloudAzureIntegrations#virtual_networks}
        :param vms: vms block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#vms CloudAzureIntegrations#vms}
        :param vpn_gateway: vpn_gateway block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#vpn_gateway CloudAzureIntegrations#vpn_gateway}
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fa1c16ddacdfc4e867337420a229a3d3ef587a8bd4ef090f9d7c96767a5bb6e7)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id_", value=id_, expected_type=type_hints["id_"])
        config = CloudAzureIntegrationsConfig(
            linked_account_id=linked_account_id,
            account_id=account_id,
            api_management=api_management,
            app_gateway=app_gateway,
            app_service=app_service,
            auto_discovery=auto_discovery,
            containers=containers,
            cosmos_db=cosmos_db,
            cost_management=cost_management,
            data_factory=data_factory,
            event_hub=event_hub,
            express_route=express_route,
            firewalls=firewalls,
            front_door=front_door,
            functions=functions,
            id=id,
            key_vault=key_vault,
            load_balancer=load_balancer,
            logic_apps=logic_apps,
            machine_learning=machine_learning,
            maria_db=maria_db,
            monitor=monitor,
            mysql=mysql,
            mysql_flexible=mysql_flexible,
            postgresql=postgresql,
            postgresql_flexible=postgresql_flexible,
            power_bi_dedicated=power_bi_dedicated,
            redis_cache=redis_cache,
            service_bus=service_bus,
            sql=sql,
            sql_managed=sql_managed,
            storage=storage,
            virtual_machine=virtual_machine,
            virtual_networks=virtual_networks,
            vms=vms,
            vpn_gateway=vpn_gateway,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        jsii.create(self.__class__, self, [scope, id_, config])

    @jsii.member(jsii_name="generateConfigForImport")
    @builtins.classmethod
    def generate_config_for_import(
        cls,
        scope: _constructs_77d1e7e8.Construct,
        import_to_id: builtins.str,
        import_from_id: builtins.str,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    ) -> _cdktn_78ede62e.ImportableResource:
        '''Generates CDKTN code for importing a CloudAzureIntegrations resource upon running "cdktn plan ".

        :param scope: The scope in which to define this construct.
        :param import_to_id: The construct id used in the generated config for the CloudAzureIntegrations to import.
        :param import_from_id: The id of the existing CloudAzureIntegrations that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#import import section} in the documentation of this resource for the id to use
        :param provider: ? Optional instance of the provider where the CloudAzureIntegrations to import is found.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4eb92b80c10d8681166269e03a2aa5feec0929a1fb345c30838d86f6d8acd4e2)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument import_to_id", value=import_to_id, expected_type=type_hints["import_to_id"])
            check_type(argname="argument import_from_id", value=import_from_id, expected_type=type_hints["import_from_id"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
        return typing.cast(_cdktn_78ede62e.ImportableResource, jsii.sinvoke(cls, "generateConfigForImport", [scope, import_to_id, import_from_id, provider]))

    @jsii.member(jsii_name="putApiManagement")
    def put_api_management(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        value = CloudAzureIntegrationsApiManagement(
            metrics_polling_interval=metrics_polling_interval,
            resource_groups=resource_groups,
        )

        return typing.cast(None, jsii.invoke(self, "putApiManagement", [value]))

    @jsii.member(jsii_name="putAppGateway")
    def put_app_gateway(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        value = CloudAzureIntegrationsAppGateway(
            metrics_polling_interval=metrics_polling_interval,
            resource_groups=resource_groups,
        )

        return typing.cast(None, jsii.invoke(self, "putAppGateway", [value]))

    @jsii.member(jsii_name="putAppService")
    def put_app_service(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        value = CloudAzureIntegrationsAppService(
            metrics_polling_interval=metrics_polling_interval,
            resource_groups=resource_groups,
        )

        return typing.cast(None, jsii.invoke(self, "putAppService", [value]))

    @jsii.member(jsii_name="putAutoDiscovery")
    def put_auto_discovery(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        value = CloudAzureIntegrationsAutoDiscovery(
            metrics_polling_interval=metrics_polling_interval,
            resource_groups=resource_groups,
        )

        return typing.cast(None, jsii.invoke(self, "putAutoDiscovery", [value]))

    @jsii.member(jsii_name="putContainers")
    def put_containers(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        value = CloudAzureIntegrationsContainers(
            metrics_polling_interval=metrics_polling_interval,
            resource_groups=resource_groups,
        )

        return typing.cast(None, jsii.invoke(self, "putContainers", [value]))

    @jsii.member(jsii_name="putCosmosDb")
    def put_cosmos_db(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        value = CloudAzureIntegrationsCosmosDb(
            metrics_polling_interval=metrics_polling_interval,
            resource_groups=resource_groups,
        )

        return typing.cast(None, jsii.invoke(self, "putCosmosDb", [value]))

    @jsii.member(jsii_name="putCostManagement")
    def put_cost_management(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        tag_keys: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param tag_keys: Specify if additional cost data per tag should be collected. This field is case sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#tag_keys CloudAzureIntegrations#tag_keys}
        '''
        value = CloudAzureIntegrationsCostManagement(
            metrics_polling_interval=metrics_polling_interval, tag_keys=tag_keys
        )

        return typing.cast(None, jsii.invoke(self, "putCostManagement", [value]))

    @jsii.member(jsii_name="putDataFactory")
    def put_data_factory(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        value = CloudAzureIntegrationsDataFactory(
            metrics_polling_interval=metrics_polling_interval,
            resource_groups=resource_groups,
        )

        return typing.cast(None, jsii.invoke(self, "putDataFactory", [value]))

    @jsii.member(jsii_name="putEventHub")
    def put_event_hub(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        value = CloudAzureIntegrationsEventHub(
            metrics_polling_interval=metrics_polling_interval,
            resource_groups=resource_groups,
        )

        return typing.cast(None, jsii.invoke(self, "putEventHub", [value]))

    @jsii.member(jsii_name="putExpressRoute")
    def put_express_route(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        value = CloudAzureIntegrationsExpressRoute(
            metrics_polling_interval=metrics_polling_interval,
            resource_groups=resource_groups,
        )

        return typing.cast(None, jsii.invoke(self, "putExpressRoute", [value]))

    @jsii.member(jsii_name="putFirewalls")
    def put_firewalls(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        value = CloudAzureIntegrationsFirewalls(
            metrics_polling_interval=metrics_polling_interval,
            resource_groups=resource_groups,
        )

        return typing.cast(None, jsii.invoke(self, "putFirewalls", [value]))

    @jsii.member(jsii_name="putFrontDoor")
    def put_front_door(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        value = CloudAzureIntegrationsFrontDoor(
            metrics_polling_interval=metrics_polling_interval,
            resource_groups=resource_groups,
        )

        return typing.cast(None, jsii.invoke(self, "putFrontDoor", [value]))

    @jsii.member(jsii_name="putFunctions")
    def put_functions(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        value = CloudAzureIntegrationsFunctions(
            metrics_polling_interval=metrics_polling_interval,
            resource_groups=resource_groups,
        )

        return typing.cast(None, jsii.invoke(self, "putFunctions", [value]))

    @jsii.member(jsii_name="putKeyVault")
    def put_key_vault(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        value = CloudAzureIntegrationsKeyVault(
            metrics_polling_interval=metrics_polling_interval,
            resource_groups=resource_groups,
        )

        return typing.cast(None, jsii.invoke(self, "putKeyVault", [value]))

    @jsii.member(jsii_name="putLoadBalancer")
    def put_load_balancer(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        value = CloudAzureIntegrationsLoadBalancer(
            metrics_polling_interval=metrics_polling_interval,
            resource_groups=resource_groups,
        )

        return typing.cast(None, jsii.invoke(self, "putLoadBalancer", [value]))

    @jsii.member(jsii_name="putLogicApps")
    def put_logic_apps(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        value = CloudAzureIntegrationsLogicApps(
            metrics_polling_interval=metrics_polling_interval,
            resource_groups=resource_groups,
        )

        return typing.cast(None, jsii.invoke(self, "putLogicApps", [value]))

    @jsii.member(jsii_name="putMachineLearning")
    def put_machine_learning(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        value = CloudAzureIntegrationsMachineLearning(
            metrics_polling_interval=metrics_polling_interval,
            resource_groups=resource_groups,
        )

        return typing.cast(None, jsii.invoke(self, "putMachineLearning", [value]))

    @jsii.member(jsii_name="putMariaDb")
    def put_maria_db(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        value = CloudAzureIntegrationsMariaDb(
            metrics_polling_interval=metrics_polling_interval,
            resource_groups=resource_groups,
        )

        return typing.cast(None, jsii.invoke(self, "putMariaDb", [value]))

    @jsii.member(jsii_name="putMonitor")
    def put_monitor(
        self,
        *,
        enabled: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        exclude_tags: typing.Optional[typing.Sequence[builtins.str]] = None,
        include_tags: typing.Optional[typing.Sequence[builtins.str]] = None,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
        resource_types: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param enabled: A flag that specifies if the integration is active. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#enabled CloudAzureIntegrations#enabled}
        :param exclude_tags: Specify resource tags in 'key:value' form to be excluded from monitoring. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#exclude_tags CloudAzureIntegrations#exclude_tags}
        :param include_tags: Specify resource tags in 'key:value' form to be monitored. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#include_tags CloudAzureIntegrations#include_tags}
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        :param resource_types: Specify each Azure resource type that needs to be monitored. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_types CloudAzureIntegrations#resource_types}
        '''
        value = CloudAzureIntegrationsMonitor(
            enabled=enabled,
            exclude_tags=exclude_tags,
            include_tags=include_tags,
            metrics_polling_interval=metrics_polling_interval,
            resource_groups=resource_groups,
            resource_types=resource_types,
        )

        return typing.cast(None, jsii.invoke(self, "putMonitor", [value]))

    @jsii.member(jsii_name="putMysql")
    def put_mysql(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        value = CloudAzureIntegrationsMysql(
            metrics_polling_interval=metrics_polling_interval,
            resource_groups=resource_groups,
        )

        return typing.cast(None, jsii.invoke(self, "putMysql", [value]))

    @jsii.member(jsii_name="putMysqlFlexible")
    def put_mysql_flexible(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        value = CloudAzureIntegrationsMysqlFlexible(
            metrics_polling_interval=metrics_polling_interval,
            resource_groups=resource_groups,
        )

        return typing.cast(None, jsii.invoke(self, "putMysqlFlexible", [value]))

    @jsii.member(jsii_name="putPostgresql")
    def put_postgresql(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        value = CloudAzureIntegrationsPostgresql(
            metrics_polling_interval=metrics_polling_interval,
            resource_groups=resource_groups,
        )

        return typing.cast(None, jsii.invoke(self, "putPostgresql", [value]))

    @jsii.member(jsii_name="putPostgresqlFlexible")
    def put_postgresql_flexible(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        value = CloudAzureIntegrationsPostgresqlFlexible(
            metrics_polling_interval=metrics_polling_interval,
            resource_groups=resource_groups,
        )

        return typing.cast(None, jsii.invoke(self, "putPostgresqlFlexible", [value]))

    @jsii.member(jsii_name="putPowerBiDedicated")
    def put_power_bi_dedicated(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        value = CloudAzureIntegrationsPowerBiDedicated(
            metrics_polling_interval=metrics_polling_interval,
            resource_groups=resource_groups,
        )

        return typing.cast(None, jsii.invoke(self, "putPowerBiDedicated", [value]))

    @jsii.member(jsii_name="putRedisCache")
    def put_redis_cache(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        value = CloudAzureIntegrationsRedisCache(
            metrics_polling_interval=metrics_polling_interval,
            resource_groups=resource_groups,
        )

        return typing.cast(None, jsii.invoke(self, "putRedisCache", [value]))

    @jsii.member(jsii_name="putServiceBus")
    def put_service_bus(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        value = CloudAzureIntegrationsServiceBus(
            metrics_polling_interval=metrics_polling_interval,
            resource_groups=resource_groups,
        )

        return typing.cast(None, jsii.invoke(self, "putServiceBus", [value]))

    @jsii.member(jsii_name="putSql")
    def put_sql(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        value = CloudAzureIntegrationsSql(
            metrics_polling_interval=metrics_polling_interval,
            resource_groups=resource_groups,
        )

        return typing.cast(None, jsii.invoke(self, "putSql", [value]))

    @jsii.member(jsii_name="putSqlManaged")
    def put_sql_managed(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        value = CloudAzureIntegrationsSqlManaged(
            metrics_polling_interval=metrics_polling_interval,
            resource_groups=resource_groups,
        )

        return typing.cast(None, jsii.invoke(self, "putSqlManaged", [value]))

    @jsii.member(jsii_name="putStorage")
    def put_storage(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        value = CloudAzureIntegrationsStorage(
            metrics_polling_interval=metrics_polling_interval,
            resource_groups=resource_groups,
        )

        return typing.cast(None, jsii.invoke(self, "putStorage", [value]))

    @jsii.member(jsii_name="putVirtualMachine")
    def put_virtual_machine(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        value = CloudAzureIntegrationsVirtualMachine(
            metrics_polling_interval=metrics_polling_interval,
            resource_groups=resource_groups,
        )

        return typing.cast(None, jsii.invoke(self, "putVirtualMachine", [value]))

    @jsii.member(jsii_name="putVirtualNetworks")
    def put_virtual_networks(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        value = CloudAzureIntegrationsVirtualNetworks(
            metrics_polling_interval=metrics_polling_interval,
            resource_groups=resource_groups,
        )

        return typing.cast(None, jsii.invoke(self, "putVirtualNetworks", [value]))

    @jsii.member(jsii_name="putVms")
    def put_vms(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        value = CloudAzureIntegrationsVms(
            metrics_polling_interval=metrics_polling_interval,
            resource_groups=resource_groups,
        )

        return typing.cast(None, jsii.invoke(self, "putVms", [value]))

    @jsii.member(jsii_name="putVpnGateway")
    def put_vpn_gateway(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        value = CloudAzureIntegrationsVpnGateway(
            metrics_polling_interval=metrics_polling_interval,
            resource_groups=resource_groups,
        )

        return typing.cast(None, jsii.invoke(self, "putVpnGateway", [value]))

    @jsii.member(jsii_name="resetAccountId")
    def reset_account_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAccountId", []))

    @jsii.member(jsii_name="resetApiManagement")
    def reset_api_management(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetApiManagement", []))

    @jsii.member(jsii_name="resetAppGateway")
    def reset_app_gateway(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAppGateway", []))

    @jsii.member(jsii_name="resetAppService")
    def reset_app_service(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAppService", []))

    @jsii.member(jsii_name="resetAutoDiscovery")
    def reset_auto_discovery(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAutoDiscovery", []))

    @jsii.member(jsii_name="resetContainers")
    def reset_containers(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetContainers", []))

    @jsii.member(jsii_name="resetCosmosDb")
    def reset_cosmos_db(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCosmosDb", []))

    @jsii.member(jsii_name="resetCostManagement")
    def reset_cost_management(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCostManagement", []))

    @jsii.member(jsii_name="resetDataFactory")
    def reset_data_factory(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDataFactory", []))

    @jsii.member(jsii_name="resetEventHub")
    def reset_event_hub(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEventHub", []))

    @jsii.member(jsii_name="resetExpressRoute")
    def reset_express_route(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetExpressRoute", []))

    @jsii.member(jsii_name="resetFirewalls")
    def reset_firewalls(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFirewalls", []))

    @jsii.member(jsii_name="resetFrontDoor")
    def reset_front_door(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFrontDoor", []))

    @jsii.member(jsii_name="resetFunctions")
    def reset_functions(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFunctions", []))

    @jsii.member(jsii_name="resetId")
    def reset_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetId", []))

    @jsii.member(jsii_name="resetKeyVault")
    def reset_key_vault(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetKeyVault", []))

    @jsii.member(jsii_name="resetLoadBalancer")
    def reset_load_balancer(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetLoadBalancer", []))

    @jsii.member(jsii_name="resetLogicApps")
    def reset_logic_apps(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetLogicApps", []))

    @jsii.member(jsii_name="resetMachineLearning")
    def reset_machine_learning(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMachineLearning", []))

    @jsii.member(jsii_name="resetMariaDb")
    def reset_maria_db(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMariaDb", []))

    @jsii.member(jsii_name="resetMonitor")
    def reset_monitor(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMonitor", []))

    @jsii.member(jsii_name="resetMysql")
    def reset_mysql(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMysql", []))

    @jsii.member(jsii_name="resetMysqlFlexible")
    def reset_mysql_flexible(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMysqlFlexible", []))

    @jsii.member(jsii_name="resetPostgresql")
    def reset_postgresql(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPostgresql", []))

    @jsii.member(jsii_name="resetPostgresqlFlexible")
    def reset_postgresql_flexible(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPostgresqlFlexible", []))

    @jsii.member(jsii_name="resetPowerBiDedicated")
    def reset_power_bi_dedicated(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPowerBiDedicated", []))

    @jsii.member(jsii_name="resetRedisCache")
    def reset_redis_cache(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRedisCache", []))

    @jsii.member(jsii_name="resetServiceBus")
    def reset_service_bus(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetServiceBus", []))

    @jsii.member(jsii_name="resetSql")
    def reset_sql(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSql", []))

    @jsii.member(jsii_name="resetSqlManaged")
    def reset_sql_managed(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSqlManaged", []))

    @jsii.member(jsii_name="resetStorage")
    def reset_storage(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetStorage", []))

    @jsii.member(jsii_name="resetVirtualMachine")
    def reset_virtual_machine(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetVirtualMachine", []))

    @jsii.member(jsii_name="resetVirtualNetworks")
    def reset_virtual_networks(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetVirtualNetworks", []))

    @jsii.member(jsii_name="resetVms")
    def reset_vms(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetVms", []))

    @jsii.member(jsii_name="resetVpnGateway")
    def reset_vpn_gateway(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetVpnGateway", []))

    @jsii.member(jsii_name="synthesizeAttributes")
    def _synthesize_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeAttributes", []))

    @jsii.member(jsii_name="synthesizeHclAttributes")
    def _synthesize_hcl_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeHclAttributes", []))

    @jsii.python.classproperty
    @jsii.member(jsii_name="tfResourceType")
    def TF_RESOURCE_TYPE(cls) -> builtins.str:
        return typing.cast(builtins.str, jsii.sget(cls, "tfResourceType"))

    @builtins.property
    @jsii.member(jsii_name="apiManagement")
    def api_management(self) -> "CloudAzureIntegrationsApiManagementOutputReference":
        return typing.cast("CloudAzureIntegrationsApiManagementOutputReference", jsii.get(self, "apiManagement"))

    @builtins.property
    @jsii.member(jsii_name="appGateway")
    def app_gateway(self) -> "CloudAzureIntegrationsAppGatewayOutputReference":
        return typing.cast("CloudAzureIntegrationsAppGatewayOutputReference", jsii.get(self, "appGateway"))

    @builtins.property
    @jsii.member(jsii_name="appService")
    def app_service(self) -> "CloudAzureIntegrationsAppServiceOutputReference":
        return typing.cast("CloudAzureIntegrationsAppServiceOutputReference", jsii.get(self, "appService"))

    @builtins.property
    @jsii.member(jsii_name="autoDiscovery")
    def auto_discovery(self) -> "CloudAzureIntegrationsAutoDiscoveryOutputReference":
        return typing.cast("CloudAzureIntegrationsAutoDiscoveryOutputReference", jsii.get(self, "autoDiscovery"))

    @builtins.property
    @jsii.member(jsii_name="containers")
    def containers(self) -> "CloudAzureIntegrationsContainersOutputReference":
        return typing.cast("CloudAzureIntegrationsContainersOutputReference", jsii.get(self, "containers"))

    @builtins.property
    @jsii.member(jsii_name="cosmosDb")
    def cosmos_db(self) -> "CloudAzureIntegrationsCosmosDbOutputReference":
        return typing.cast("CloudAzureIntegrationsCosmosDbOutputReference", jsii.get(self, "cosmosDb"))

    @builtins.property
    @jsii.member(jsii_name="costManagement")
    def cost_management(self) -> "CloudAzureIntegrationsCostManagementOutputReference":
        return typing.cast("CloudAzureIntegrationsCostManagementOutputReference", jsii.get(self, "costManagement"))

    @builtins.property
    @jsii.member(jsii_name="dataFactory")
    def data_factory(self) -> "CloudAzureIntegrationsDataFactoryOutputReference":
        return typing.cast("CloudAzureIntegrationsDataFactoryOutputReference", jsii.get(self, "dataFactory"))

    @builtins.property
    @jsii.member(jsii_name="eventHub")
    def event_hub(self) -> "CloudAzureIntegrationsEventHubOutputReference":
        return typing.cast("CloudAzureIntegrationsEventHubOutputReference", jsii.get(self, "eventHub"))

    @builtins.property
    @jsii.member(jsii_name="expressRoute")
    def express_route(self) -> "CloudAzureIntegrationsExpressRouteOutputReference":
        return typing.cast("CloudAzureIntegrationsExpressRouteOutputReference", jsii.get(self, "expressRoute"))

    @builtins.property
    @jsii.member(jsii_name="firewalls")
    def firewalls(self) -> "CloudAzureIntegrationsFirewallsOutputReference":
        return typing.cast("CloudAzureIntegrationsFirewallsOutputReference", jsii.get(self, "firewalls"))

    @builtins.property
    @jsii.member(jsii_name="frontDoor")
    def front_door(self) -> "CloudAzureIntegrationsFrontDoorOutputReference":
        return typing.cast("CloudAzureIntegrationsFrontDoorOutputReference", jsii.get(self, "frontDoor"))

    @builtins.property
    @jsii.member(jsii_name="functions")
    def functions(self) -> "CloudAzureIntegrationsFunctionsOutputReference":
        return typing.cast("CloudAzureIntegrationsFunctionsOutputReference", jsii.get(self, "functions"))

    @builtins.property
    @jsii.member(jsii_name="keyVault")
    def key_vault(self) -> "CloudAzureIntegrationsKeyVaultOutputReference":
        return typing.cast("CloudAzureIntegrationsKeyVaultOutputReference", jsii.get(self, "keyVault"))

    @builtins.property
    @jsii.member(jsii_name="loadBalancer")
    def load_balancer(self) -> "CloudAzureIntegrationsLoadBalancerOutputReference":
        return typing.cast("CloudAzureIntegrationsLoadBalancerOutputReference", jsii.get(self, "loadBalancer"))

    @builtins.property
    @jsii.member(jsii_name="logicApps")
    def logic_apps(self) -> "CloudAzureIntegrationsLogicAppsOutputReference":
        return typing.cast("CloudAzureIntegrationsLogicAppsOutputReference", jsii.get(self, "logicApps"))

    @builtins.property
    @jsii.member(jsii_name="machineLearning")
    def machine_learning(
        self,
    ) -> "CloudAzureIntegrationsMachineLearningOutputReference":
        return typing.cast("CloudAzureIntegrationsMachineLearningOutputReference", jsii.get(self, "machineLearning"))

    @builtins.property
    @jsii.member(jsii_name="mariaDb")
    def maria_db(self) -> "CloudAzureIntegrationsMariaDbOutputReference":
        return typing.cast("CloudAzureIntegrationsMariaDbOutputReference", jsii.get(self, "mariaDb"))

    @builtins.property
    @jsii.member(jsii_name="monitor")
    def monitor(self) -> "CloudAzureIntegrationsMonitorOutputReference":
        return typing.cast("CloudAzureIntegrationsMonitorOutputReference", jsii.get(self, "monitor"))

    @builtins.property
    @jsii.member(jsii_name="mysql")
    def mysql(self) -> "CloudAzureIntegrationsMysqlOutputReference":
        return typing.cast("CloudAzureIntegrationsMysqlOutputReference", jsii.get(self, "mysql"))

    @builtins.property
    @jsii.member(jsii_name="mysqlFlexible")
    def mysql_flexible(self) -> "CloudAzureIntegrationsMysqlFlexibleOutputReference":
        return typing.cast("CloudAzureIntegrationsMysqlFlexibleOutputReference", jsii.get(self, "mysqlFlexible"))

    @builtins.property
    @jsii.member(jsii_name="postgresql")
    def postgresql(self) -> "CloudAzureIntegrationsPostgresqlOutputReference":
        return typing.cast("CloudAzureIntegrationsPostgresqlOutputReference", jsii.get(self, "postgresql"))

    @builtins.property
    @jsii.member(jsii_name="postgresqlFlexible")
    def postgresql_flexible(
        self,
    ) -> "CloudAzureIntegrationsPostgresqlFlexibleOutputReference":
        return typing.cast("CloudAzureIntegrationsPostgresqlFlexibleOutputReference", jsii.get(self, "postgresqlFlexible"))

    @builtins.property
    @jsii.member(jsii_name="powerBiDedicated")
    def power_bi_dedicated(
        self,
    ) -> "CloudAzureIntegrationsPowerBiDedicatedOutputReference":
        return typing.cast("CloudAzureIntegrationsPowerBiDedicatedOutputReference", jsii.get(self, "powerBiDedicated"))

    @builtins.property
    @jsii.member(jsii_name="redisCache")
    def redis_cache(self) -> "CloudAzureIntegrationsRedisCacheOutputReference":
        return typing.cast("CloudAzureIntegrationsRedisCacheOutputReference", jsii.get(self, "redisCache"))

    @builtins.property
    @jsii.member(jsii_name="serviceBus")
    def service_bus(self) -> "CloudAzureIntegrationsServiceBusOutputReference":
        return typing.cast("CloudAzureIntegrationsServiceBusOutputReference", jsii.get(self, "serviceBus"))

    @builtins.property
    @jsii.member(jsii_name="sql")
    def sql(self) -> "CloudAzureIntegrationsSqlOutputReference":
        return typing.cast("CloudAzureIntegrationsSqlOutputReference", jsii.get(self, "sql"))

    @builtins.property
    @jsii.member(jsii_name="sqlManaged")
    def sql_managed(self) -> "CloudAzureIntegrationsSqlManagedOutputReference":
        return typing.cast("CloudAzureIntegrationsSqlManagedOutputReference", jsii.get(self, "sqlManaged"))

    @builtins.property
    @jsii.member(jsii_name="storage")
    def storage(self) -> "CloudAzureIntegrationsStorageOutputReference":
        return typing.cast("CloudAzureIntegrationsStorageOutputReference", jsii.get(self, "storage"))

    @builtins.property
    @jsii.member(jsii_name="virtualMachine")
    def virtual_machine(self) -> "CloudAzureIntegrationsVirtualMachineOutputReference":
        return typing.cast("CloudAzureIntegrationsVirtualMachineOutputReference", jsii.get(self, "virtualMachine"))

    @builtins.property
    @jsii.member(jsii_name="virtualNetworks")
    def virtual_networks(
        self,
    ) -> "CloudAzureIntegrationsVirtualNetworksOutputReference":
        return typing.cast("CloudAzureIntegrationsVirtualNetworksOutputReference", jsii.get(self, "virtualNetworks"))

    @builtins.property
    @jsii.member(jsii_name="vms")
    def vms(self) -> "CloudAzureIntegrationsVmsOutputReference":
        return typing.cast("CloudAzureIntegrationsVmsOutputReference", jsii.get(self, "vms"))

    @builtins.property
    @jsii.member(jsii_name="vpnGateway")
    def vpn_gateway(self) -> "CloudAzureIntegrationsVpnGatewayOutputReference":
        return typing.cast("CloudAzureIntegrationsVpnGatewayOutputReference", jsii.get(self, "vpnGateway"))

    @builtins.property
    @jsii.member(jsii_name="accountIdInput")
    def account_id_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "accountIdInput"))

    @builtins.property
    @jsii.member(jsii_name="apiManagementInput")
    def api_management_input(
        self,
    ) -> typing.Optional["CloudAzureIntegrationsApiManagement"]:
        return typing.cast(typing.Optional["CloudAzureIntegrationsApiManagement"], jsii.get(self, "apiManagementInput"))

    @builtins.property
    @jsii.member(jsii_name="appGatewayInput")
    def app_gateway_input(self) -> typing.Optional["CloudAzureIntegrationsAppGateway"]:
        return typing.cast(typing.Optional["CloudAzureIntegrationsAppGateway"], jsii.get(self, "appGatewayInput"))

    @builtins.property
    @jsii.member(jsii_name="appServiceInput")
    def app_service_input(self) -> typing.Optional["CloudAzureIntegrationsAppService"]:
        return typing.cast(typing.Optional["CloudAzureIntegrationsAppService"], jsii.get(self, "appServiceInput"))

    @builtins.property
    @jsii.member(jsii_name="autoDiscoveryInput")
    def auto_discovery_input(
        self,
    ) -> typing.Optional["CloudAzureIntegrationsAutoDiscovery"]:
        return typing.cast(typing.Optional["CloudAzureIntegrationsAutoDiscovery"], jsii.get(self, "autoDiscoveryInput"))

    @builtins.property
    @jsii.member(jsii_name="containersInput")
    def containers_input(self) -> typing.Optional["CloudAzureIntegrationsContainers"]:
        return typing.cast(typing.Optional["CloudAzureIntegrationsContainers"], jsii.get(self, "containersInput"))

    @builtins.property
    @jsii.member(jsii_name="cosmosDbInput")
    def cosmos_db_input(self) -> typing.Optional["CloudAzureIntegrationsCosmosDb"]:
        return typing.cast(typing.Optional["CloudAzureIntegrationsCosmosDb"], jsii.get(self, "cosmosDbInput"))

    @builtins.property
    @jsii.member(jsii_name="costManagementInput")
    def cost_management_input(
        self,
    ) -> typing.Optional["CloudAzureIntegrationsCostManagement"]:
        return typing.cast(typing.Optional["CloudAzureIntegrationsCostManagement"], jsii.get(self, "costManagementInput"))

    @builtins.property
    @jsii.member(jsii_name="dataFactoryInput")
    def data_factory_input(
        self,
    ) -> typing.Optional["CloudAzureIntegrationsDataFactory"]:
        return typing.cast(typing.Optional["CloudAzureIntegrationsDataFactory"], jsii.get(self, "dataFactoryInput"))

    @builtins.property
    @jsii.member(jsii_name="eventHubInput")
    def event_hub_input(self) -> typing.Optional["CloudAzureIntegrationsEventHub"]:
        return typing.cast(typing.Optional["CloudAzureIntegrationsEventHub"], jsii.get(self, "eventHubInput"))

    @builtins.property
    @jsii.member(jsii_name="expressRouteInput")
    def express_route_input(
        self,
    ) -> typing.Optional["CloudAzureIntegrationsExpressRoute"]:
        return typing.cast(typing.Optional["CloudAzureIntegrationsExpressRoute"], jsii.get(self, "expressRouteInput"))

    @builtins.property
    @jsii.member(jsii_name="firewallsInput")
    def firewalls_input(self) -> typing.Optional["CloudAzureIntegrationsFirewalls"]:
        return typing.cast(typing.Optional["CloudAzureIntegrationsFirewalls"], jsii.get(self, "firewallsInput"))

    @builtins.property
    @jsii.member(jsii_name="frontDoorInput")
    def front_door_input(self) -> typing.Optional["CloudAzureIntegrationsFrontDoor"]:
        return typing.cast(typing.Optional["CloudAzureIntegrationsFrontDoor"], jsii.get(self, "frontDoorInput"))

    @builtins.property
    @jsii.member(jsii_name="functionsInput")
    def functions_input(self) -> typing.Optional["CloudAzureIntegrationsFunctions"]:
        return typing.cast(typing.Optional["CloudAzureIntegrationsFunctions"], jsii.get(self, "functionsInput"))

    @builtins.property
    @jsii.member(jsii_name="idInput")
    def id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "idInput"))

    @builtins.property
    @jsii.member(jsii_name="keyVaultInput")
    def key_vault_input(self) -> typing.Optional["CloudAzureIntegrationsKeyVault"]:
        return typing.cast(typing.Optional["CloudAzureIntegrationsKeyVault"], jsii.get(self, "keyVaultInput"))

    @builtins.property
    @jsii.member(jsii_name="linkedAccountIdInput")
    def linked_account_id_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "linkedAccountIdInput"))

    @builtins.property
    @jsii.member(jsii_name="loadBalancerInput")
    def load_balancer_input(
        self,
    ) -> typing.Optional["CloudAzureIntegrationsLoadBalancer"]:
        return typing.cast(typing.Optional["CloudAzureIntegrationsLoadBalancer"], jsii.get(self, "loadBalancerInput"))

    @builtins.property
    @jsii.member(jsii_name="logicAppsInput")
    def logic_apps_input(self) -> typing.Optional["CloudAzureIntegrationsLogicApps"]:
        return typing.cast(typing.Optional["CloudAzureIntegrationsLogicApps"], jsii.get(self, "logicAppsInput"))

    @builtins.property
    @jsii.member(jsii_name="machineLearningInput")
    def machine_learning_input(
        self,
    ) -> typing.Optional["CloudAzureIntegrationsMachineLearning"]:
        return typing.cast(typing.Optional["CloudAzureIntegrationsMachineLearning"], jsii.get(self, "machineLearningInput"))

    @builtins.property
    @jsii.member(jsii_name="mariaDbInput")
    def maria_db_input(self) -> typing.Optional["CloudAzureIntegrationsMariaDb"]:
        return typing.cast(typing.Optional["CloudAzureIntegrationsMariaDb"], jsii.get(self, "mariaDbInput"))

    @builtins.property
    @jsii.member(jsii_name="monitorInput")
    def monitor_input(self) -> typing.Optional["CloudAzureIntegrationsMonitor"]:
        return typing.cast(typing.Optional["CloudAzureIntegrationsMonitor"], jsii.get(self, "monitorInput"))

    @builtins.property
    @jsii.member(jsii_name="mysqlFlexibleInput")
    def mysql_flexible_input(
        self,
    ) -> typing.Optional["CloudAzureIntegrationsMysqlFlexible"]:
        return typing.cast(typing.Optional["CloudAzureIntegrationsMysqlFlexible"], jsii.get(self, "mysqlFlexibleInput"))

    @builtins.property
    @jsii.member(jsii_name="mysqlInput")
    def mysql_input(self) -> typing.Optional["CloudAzureIntegrationsMysql"]:
        return typing.cast(typing.Optional["CloudAzureIntegrationsMysql"], jsii.get(self, "mysqlInput"))

    @builtins.property
    @jsii.member(jsii_name="postgresqlFlexibleInput")
    def postgresql_flexible_input(
        self,
    ) -> typing.Optional["CloudAzureIntegrationsPostgresqlFlexible"]:
        return typing.cast(typing.Optional["CloudAzureIntegrationsPostgresqlFlexible"], jsii.get(self, "postgresqlFlexibleInput"))

    @builtins.property
    @jsii.member(jsii_name="postgresqlInput")
    def postgresql_input(self) -> typing.Optional["CloudAzureIntegrationsPostgresql"]:
        return typing.cast(typing.Optional["CloudAzureIntegrationsPostgresql"], jsii.get(self, "postgresqlInput"))

    @builtins.property
    @jsii.member(jsii_name="powerBiDedicatedInput")
    def power_bi_dedicated_input(
        self,
    ) -> typing.Optional["CloudAzureIntegrationsPowerBiDedicated"]:
        return typing.cast(typing.Optional["CloudAzureIntegrationsPowerBiDedicated"], jsii.get(self, "powerBiDedicatedInput"))

    @builtins.property
    @jsii.member(jsii_name="redisCacheInput")
    def redis_cache_input(self) -> typing.Optional["CloudAzureIntegrationsRedisCache"]:
        return typing.cast(typing.Optional["CloudAzureIntegrationsRedisCache"], jsii.get(self, "redisCacheInput"))

    @builtins.property
    @jsii.member(jsii_name="serviceBusInput")
    def service_bus_input(self) -> typing.Optional["CloudAzureIntegrationsServiceBus"]:
        return typing.cast(typing.Optional["CloudAzureIntegrationsServiceBus"], jsii.get(self, "serviceBusInput"))

    @builtins.property
    @jsii.member(jsii_name="sqlInput")
    def sql_input(self) -> typing.Optional["CloudAzureIntegrationsSql"]:
        return typing.cast(typing.Optional["CloudAzureIntegrationsSql"], jsii.get(self, "sqlInput"))

    @builtins.property
    @jsii.member(jsii_name="sqlManagedInput")
    def sql_managed_input(self) -> typing.Optional["CloudAzureIntegrationsSqlManaged"]:
        return typing.cast(typing.Optional["CloudAzureIntegrationsSqlManaged"], jsii.get(self, "sqlManagedInput"))

    @builtins.property
    @jsii.member(jsii_name="storageInput")
    def storage_input(self) -> typing.Optional["CloudAzureIntegrationsStorage"]:
        return typing.cast(typing.Optional["CloudAzureIntegrationsStorage"], jsii.get(self, "storageInput"))

    @builtins.property
    @jsii.member(jsii_name="virtualMachineInput")
    def virtual_machine_input(
        self,
    ) -> typing.Optional["CloudAzureIntegrationsVirtualMachine"]:
        return typing.cast(typing.Optional["CloudAzureIntegrationsVirtualMachine"], jsii.get(self, "virtualMachineInput"))

    @builtins.property
    @jsii.member(jsii_name="virtualNetworksInput")
    def virtual_networks_input(
        self,
    ) -> typing.Optional["CloudAzureIntegrationsVirtualNetworks"]:
        return typing.cast(typing.Optional["CloudAzureIntegrationsVirtualNetworks"], jsii.get(self, "virtualNetworksInput"))

    @builtins.property
    @jsii.member(jsii_name="vmsInput")
    def vms_input(self) -> typing.Optional["CloudAzureIntegrationsVms"]:
        return typing.cast(typing.Optional["CloudAzureIntegrationsVms"], jsii.get(self, "vmsInput"))

    @builtins.property
    @jsii.member(jsii_name="vpnGatewayInput")
    def vpn_gateway_input(self) -> typing.Optional["CloudAzureIntegrationsVpnGateway"]:
        return typing.cast(typing.Optional["CloudAzureIntegrationsVpnGateway"], jsii.get(self, "vpnGatewayInput"))

    @builtins.property
    @jsii.member(jsii_name="accountId")
    def account_id(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "accountId"))

    @account_id.setter
    def account_id(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6958cffc63ece4b9724bc400fe5db593eea13170610ce7cf4e212d5171aab1f2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "accountId", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @id.setter
    def id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c7eeb986e96695083d56b407050b7785423d9da01da84d3eceedc7c0ad6837ce)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "id", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="linkedAccountId")
    def linked_account_id(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "linkedAccountId"))

    @linked_account_id.setter
    def linked_account_id(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f6c5b25d6613fd23519c375c58616d6f3ab22b00cf183505de7075b1cd4b30d2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "linkedAccountId", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsApiManagement",
    jsii_struct_bases=[],
    name_mapping={
        "metrics_polling_interval": "metricsPollingInterval",
        "resource_groups": "resourceGroups",
    },
)
class CloudAzureIntegrationsApiManagement:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__90788633a50eb5bf71958700bc6aa4b7840b80affcc1fd757aee2060e740732a)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
            check_type(argname="argument resource_groups", value=resource_groups, expected_type=type_hints["resource_groups"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval
        if resource_groups is not None:
            self._values["resource_groups"] = resource_groups

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''The data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def resource_groups(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        result = self._values.get("resource_groups")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudAzureIntegrationsApiManagement(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudAzureIntegrationsApiManagementOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsApiManagementOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1093e851e8ea30f551c4fb762ff4360a5760ae0f5aa32aa9ba140716291b4bf8)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @jsii.member(jsii_name="resetResourceGroups")
    def reset_resource_groups(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResourceGroups", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="resourceGroupsInput")
    def resource_groups_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "resourceGroupsInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ed3f608b50668d72aa9c7593b094bcd974e6c8adcda527e207c944bff7bfd532)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="resourceGroups")
    def resource_groups(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "resourceGroups"))

    @resource_groups.setter
    def resource_groups(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d89c9549882c07f17b0b1ad73949ac8859222dec1ddf25cd44ac241caac7adf0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "resourceGroups", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudAzureIntegrationsApiManagement]:
        return typing.cast(typing.Optional[CloudAzureIntegrationsApiManagement], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudAzureIntegrationsApiManagement],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__18c5b8ca08b92cf9a85f541ee12e3f8312b1467435734f5c49db94c21375a8e1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsAppGateway",
    jsii_struct_bases=[],
    name_mapping={
        "metrics_polling_interval": "metricsPollingInterval",
        "resource_groups": "resourceGroups",
    },
)
class CloudAzureIntegrationsAppGateway:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e0cb57de35c742c3508fe01501ca35caed50267f5ce3bf94ccfc7aba84cb3e7c)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
            check_type(argname="argument resource_groups", value=resource_groups, expected_type=type_hints["resource_groups"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval
        if resource_groups is not None:
            self._values["resource_groups"] = resource_groups

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''The data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def resource_groups(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        result = self._values.get("resource_groups")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudAzureIntegrationsAppGateway(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudAzureIntegrationsAppGatewayOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsAppGatewayOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__70ddab697be7a7d9d05b419989c61cc0b9d62c84564bb24c4548440ca86f81a2)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @jsii.member(jsii_name="resetResourceGroups")
    def reset_resource_groups(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResourceGroups", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="resourceGroupsInput")
    def resource_groups_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "resourceGroupsInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__92e230b607c7128a8c9f1cfe30763ab007a588ca7701f997606755df08a9d158)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="resourceGroups")
    def resource_groups(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "resourceGroups"))

    @resource_groups.setter
    def resource_groups(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__95c72b935ef77ef8da220e49d082fef3e510a8018547456876696afb637bb236)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "resourceGroups", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudAzureIntegrationsAppGateway]:
        return typing.cast(typing.Optional[CloudAzureIntegrationsAppGateway], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudAzureIntegrationsAppGateway],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c80f786ec5f5f693e3386bf356356c987dd431e61afa33fb6e93bb26000e9a03)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsAppService",
    jsii_struct_bases=[],
    name_mapping={
        "metrics_polling_interval": "metricsPollingInterval",
        "resource_groups": "resourceGroups",
    },
)
class CloudAzureIntegrationsAppService:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b3f5a9b68fdc7ba057642cdbfe12d21bb6b9559b51e6cddfdb23e5f58f147510)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
            check_type(argname="argument resource_groups", value=resource_groups, expected_type=type_hints["resource_groups"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval
        if resource_groups is not None:
            self._values["resource_groups"] = resource_groups

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''The data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def resource_groups(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        result = self._values.get("resource_groups")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudAzureIntegrationsAppService(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudAzureIntegrationsAppServiceOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsAppServiceOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__dd5d9656a8721590834678a5cc1d0312ac34c42391397806f04bc20e93fb365a)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @jsii.member(jsii_name="resetResourceGroups")
    def reset_resource_groups(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResourceGroups", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="resourceGroupsInput")
    def resource_groups_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "resourceGroupsInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d706d411f163d543df6dfdcdc063bba1b33a81b355511a83c6e361e2338f83d7)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="resourceGroups")
    def resource_groups(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "resourceGroups"))

    @resource_groups.setter
    def resource_groups(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__67a8f5c170c8d527d26ecc9f7e7e5e43ee570fdf3f4bb7ac21534b72618c0450)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "resourceGroups", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudAzureIntegrationsAppService]:
        return typing.cast(typing.Optional[CloudAzureIntegrationsAppService], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudAzureIntegrationsAppService],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__372bc59c78eb8bbfa89cac9c6c8665a864be79a73baf69a1bee206b6e730fa31)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsAutoDiscovery",
    jsii_struct_bases=[],
    name_mapping={
        "metrics_polling_interval": "metricsPollingInterval",
        "resource_groups": "resourceGroups",
    },
)
class CloudAzureIntegrationsAutoDiscovery:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6dbd011eb7d8d77033dfb5b279e6951a329cd3f5e8e36bb4baaa2fece63e8b4c)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
            check_type(argname="argument resource_groups", value=resource_groups, expected_type=type_hints["resource_groups"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval
        if resource_groups is not None:
            self._values["resource_groups"] = resource_groups

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''The data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def resource_groups(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        result = self._values.get("resource_groups")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudAzureIntegrationsAutoDiscovery(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudAzureIntegrationsAutoDiscoveryOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsAutoDiscoveryOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__18b12b15bb7c673692801b22a5b3a8480cae5f61d6951f26a57bccc7d981b7cd)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @jsii.member(jsii_name="resetResourceGroups")
    def reset_resource_groups(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResourceGroups", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="resourceGroupsInput")
    def resource_groups_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "resourceGroupsInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9bdf5b8ab024c266d6c844a6c3a81930e5b92cb831d5449066951774ba9c3873)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="resourceGroups")
    def resource_groups(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "resourceGroups"))

    @resource_groups.setter
    def resource_groups(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__500da98d788bdcd122a60d7697b0e0ae0ab7f642ee018281ec4cfacbf34d5cd7)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "resourceGroups", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudAzureIntegrationsAutoDiscovery]:
        return typing.cast(typing.Optional[CloudAzureIntegrationsAutoDiscovery], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudAzureIntegrationsAutoDiscovery],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5f394e8eaf92208be6b3d8cc2bfb27f967177e15213f06d26495a61409e16ee9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsConfig",
    jsii_struct_bases=[_cdktn_78ede62e.TerraformMetaArguments],
    name_mapping={
        "connection": "connection",
        "count": "count",
        "depends_on": "dependsOn",
        "for_each": "forEach",
        "lifecycle": "lifecycle",
        "provider": "provider",
        "provisioners": "provisioners",
        "linked_account_id": "linkedAccountId",
        "account_id": "accountId",
        "api_management": "apiManagement",
        "app_gateway": "appGateway",
        "app_service": "appService",
        "auto_discovery": "autoDiscovery",
        "containers": "containers",
        "cosmos_db": "cosmosDb",
        "cost_management": "costManagement",
        "data_factory": "dataFactory",
        "event_hub": "eventHub",
        "express_route": "expressRoute",
        "firewalls": "firewalls",
        "front_door": "frontDoor",
        "functions": "functions",
        "id": "id",
        "key_vault": "keyVault",
        "load_balancer": "loadBalancer",
        "logic_apps": "logicApps",
        "machine_learning": "machineLearning",
        "maria_db": "mariaDb",
        "monitor": "monitor",
        "mysql": "mysql",
        "mysql_flexible": "mysqlFlexible",
        "postgresql": "postgresql",
        "postgresql_flexible": "postgresqlFlexible",
        "power_bi_dedicated": "powerBiDedicated",
        "redis_cache": "redisCache",
        "service_bus": "serviceBus",
        "sql": "sql",
        "sql_managed": "sqlManaged",
        "storage": "storage",
        "virtual_machine": "virtualMachine",
        "virtual_networks": "virtualNetworks",
        "vms": "vms",
        "vpn_gateway": "vpnGateway",
    },
)
class CloudAzureIntegrationsConfig(_cdktn_78ede62e.TerraformMetaArguments):
    def __init__(
        self,
        *,
        connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
        linked_account_id: jsii.Number,
        account_id: typing.Optional[jsii.Number] = None,
        api_management: typing.Optional[typing.Union[CloudAzureIntegrationsApiManagement, typing.Dict[builtins.str, typing.Any]]] = None,
        app_gateway: typing.Optional[typing.Union[CloudAzureIntegrationsAppGateway, typing.Dict[builtins.str, typing.Any]]] = None,
        app_service: typing.Optional[typing.Union[CloudAzureIntegrationsAppService, typing.Dict[builtins.str, typing.Any]]] = None,
        auto_discovery: typing.Optional[typing.Union[CloudAzureIntegrationsAutoDiscovery, typing.Dict[builtins.str, typing.Any]]] = None,
        containers: typing.Optional[typing.Union["CloudAzureIntegrationsContainers", typing.Dict[builtins.str, typing.Any]]] = None,
        cosmos_db: typing.Optional[typing.Union["CloudAzureIntegrationsCosmosDb", typing.Dict[builtins.str, typing.Any]]] = None,
        cost_management: typing.Optional[typing.Union["CloudAzureIntegrationsCostManagement", typing.Dict[builtins.str, typing.Any]]] = None,
        data_factory: typing.Optional[typing.Union["CloudAzureIntegrationsDataFactory", typing.Dict[builtins.str, typing.Any]]] = None,
        event_hub: typing.Optional[typing.Union["CloudAzureIntegrationsEventHub", typing.Dict[builtins.str, typing.Any]]] = None,
        express_route: typing.Optional[typing.Union["CloudAzureIntegrationsExpressRoute", typing.Dict[builtins.str, typing.Any]]] = None,
        firewalls: typing.Optional[typing.Union["CloudAzureIntegrationsFirewalls", typing.Dict[builtins.str, typing.Any]]] = None,
        front_door: typing.Optional[typing.Union["CloudAzureIntegrationsFrontDoor", typing.Dict[builtins.str, typing.Any]]] = None,
        functions: typing.Optional[typing.Union["CloudAzureIntegrationsFunctions", typing.Dict[builtins.str, typing.Any]]] = None,
        id: typing.Optional[builtins.str] = None,
        key_vault: typing.Optional[typing.Union["CloudAzureIntegrationsKeyVault", typing.Dict[builtins.str, typing.Any]]] = None,
        load_balancer: typing.Optional[typing.Union["CloudAzureIntegrationsLoadBalancer", typing.Dict[builtins.str, typing.Any]]] = None,
        logic_apps: typing.Optional[typing.Union["CloudAzureIntegrationsLogicApps", typing.Dict[builtins.str, typing.Any]]] = None,
        machine_learning: typing.Optional[typing.Union["CloudAzureIntegrationsMachineLearning", typing.Dict[builtins.str, typing.Any]]] = None,
        maria_db: typing.Optional[typing.Union["CloudAzureIntegrationsMariaDb", typing.Dict[builtins.str, typing.Any]]] = None,
        monitor: typing.Optional[typing.Union["CloudAzureIntegrationsMonitor", typing.Dict[builtins.str, typing.Any]]] = None,
        mysql: typing.Optional[typing.Union["CloudAzureIntegrationsMysql", typing.Dict[builtins.str, typing.Any]]] = None,
        mysql_flexible: typing.Optional[typing.Union["CloudAzureIntegrationsMysqlFlexible", typing.Dict[builtins.str, typing.Any]]] = None,
        postgresql: typing.Optional[typing.Union["CloudAzureIntegrationsPostgresql", typing.Dict[builtins.str, typing.Any]]] = None,
        postgresql_flexible: typing.Optional[typing.Union["CloudAzureIntegrationsPostgresqlFlexible", typing.Dict[builtins.str, typing.Any]]] = None,
        power_bi_dedicated: typing.Optional[typing.Union["CloudAzureIntegrationsPowerBiDedicated", typing.Dict[builtins.str, typing.Any]]] = None,
        redis_cache: typing.Optional[typing.Union["CloudAzureIntegrationsRedisCache", typing.Dict[builtins.str, typing.Any]]] = None,
        service_bus: typing.Optional[typing.Union["CloudAzureIntegrationsServiceBus", typing.Dict[builtins.str, typing.Any]]] = None,
        sql: typing.Optional[typing.Union["CloudAzureIntegrationsSql", typing.Dict[builtins.str, typing.Any]]] = None,
        sql_managed: typing.Optional[typing.Union["CloudAzureIntegrationsSqlManaged", typing.Dict[builtins.str, typing.Any]]] = None,
        storage: typing.Optional[typing.Union["CloudAzureIntegrationsStorage", typing.Dict[builtins.str, typing.Any]]] = None,
        virtual_machine: typing.Optional[typing.Union["CloudAzureIntegrationsVirtualMachine", typing.Dict[builtins.str, typing.Any]]] = None,
        virtual_networks: typing.Optional[typing.Union["CloudAzureIntegrationsVirtualNetworks", typing.Dict[builtins.str, typing.Any]]] = None,
        vms: typing.Optional[typing.Union["CloudAzureIntegrationsVms", typing.Dict[builtins.str, typing.Any]]] = None,
        vpn_gateway: typing.Optional[typing.Union["CloudAzureIntegrationsVpnGateway", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        :param linked_account_id: The ID of the linked Azure account in New Relic. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#linked_account_id CloudAzureIntegrations#linked_account_id}
        :param account_id: The ID of the account in New Relic. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#account_id CloudAzureIntegrations#account_id}
        :param api_management: api_management block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#api_management CloudAzureIntegrations#api_management}
        :param app_gateway: app_gateway block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#app_gateway CloudAzureIntegrations#app_gateway}
        :param app_service: app_service block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#app_service CloudAzureIntegrations#app_service}
        :param auto_discovery: auto_discovery block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#auto_discovery CloudAzureIntegrations#auto_discovery}
        :param containers: containers block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#containers CloudAzureIntegrations#containers}
        :param cosmos_db: cosmos_db block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#cosmos_db CloudAzureIntegrations#cosmos_db}
        :param cost_management: cost_management block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#cost_management CloudAzureIntegrations#cost_management}
        :param data_factory: data_factory block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#data_factory CloudAzureIntegrations#data_factory}
        :param event_hub: event_hub block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#event_hub CloudAzureIntegrations#event_hub}
        :param express_route: express_route block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#express_route CloudAzureIntegrations#express_route}
        :param firewalls: firewalls block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#firewalls CloudAzureIntegrations#firewalls}
        :param front_door: front_door block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#front_door CloudAzureIntegrations#front_door}
        :param functions: functions block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#functions CloudAzureIntegrations#functions}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#id CloudAzureIntegrations#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param key_vault: key_vault block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#key_vault CloudAzureIntegrations#key_vault}
        :param load_balancer: load_balancer block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#load_balancer CloudAzureIntegrations#load_balancer}
        :param logic_apps: logic_apps block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#logic_apps CloudAzureIntegrations#logic_apps}
        :param machine_learning: machine_learning block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#machine_learning CloudAzureIntegrations#machine_learning}
        :param maria_db: maria_db block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#maria_db CloudAzureIntegrations#maria_db}
        :param monitor: monitor block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#monitor CloudAzureIntegrations#monitor}
        :param mysql: mysql block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#mysql CloudAzureIntegrations#mysql}
        :param mysql_flexible: mysql_flexible block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#mysql_flexible CloudAzureIntegrations#mysql_flexible}
        :param postgresql: postgresql block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#postgresql CloudAzureIntegrations#postgresql}
        :param postgresql_flexible: postgresql_flexible block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#postgresql_flexible CloudAzureIntegrations#postgresql_flexible}
        :param power_bi_dedicated: power_bi_dedicated block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#power_bi_dedicated CloudAzureIntegrations#power_bi_dedicated}
        :param redis_cache: redis_cache block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#redis_cache CloudAzureIntegrations#redis_cache}
        :param service_bus: service_bus block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#service_bus CloudAzureIntegrations#service_bus}
        :param sql: sql block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#sql CloudAzureIntegrations#sql}
        :param sql_managed: sql_managed block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#sql_managed CloudAzureIntegrations#sql_managed}
        :param storage: storage block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#storage CloudAzureIntegrations#storage}
        :param virtual_machine: virtual_machine block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#virtual_machine CloudAzureIntegrations#virtual_machine}
        :param virtual_networks: virtual_networks block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#virtual_networks CloudAzureIntegrations#virtual_networks}
        :param vms: vms block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#vms CloudAzureIntegrations#vms}
        :param vpn_gateway: vpn_gateway block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#vpn_gateway CloudAzureIntegrations#vpn_gateway}
        '''
        if isinstance(lifecycle, dict):
            lifecycle = _cdktn_78ede62e.TerraformResourceLifecycle(**lifecycle)
        if isinstance(api_management, dict):
            api_management = CloudAzureIntegrationsApiManagement(**api_management)
        if isinstance(app_gateway, dict):
            app_gateway = CloudAzureIntegrationsAppGateway(**app_gateway)
        if isinstance(app_service, dict):
            app_service = CloudAzureIntegrationsAppService(**app_service)
        if isinstance(auto_discovery, dict):
            auto_discovery = CloudAzureIntegrationsAutoDiscovery(**auto_discovery)
        if isinstance(containers, dict):
            containers = CloudAzureIntegrationsContainers(**containers)
        if isinstance(cosmos_db, dict):
            cosmos_db = CloudAzureIntegrationsCosmosDb(**cosmos_db)
        if isinstance(cost_management, dict):
            cost_management = CloudAzureIntegrationsCostManagement(**cost_management)
        if isinstance(data_factory, dict):
            data_factory = CloudAzureIntegrationsDataFactory(**data_factory)
        if isinstance(event_hub, dict):
            event_hub = CloudAzureIntegrationsEventHub(**event_hub)
        if isinstance(express_route, dict):
            express_route = CloudAzureIntegrationsExpressRoute(**express_route)
        if isinstance(firewalls, dict):
            firewalls = CloudAzureIntegrationsFirewalls(**firewalls)
        if isinstance(front_door, dict):
            front_door = CloudAzureIntegrationsFrontDoor(**front_door)
        if isinstance(functions, dict):
            functions = CloudAzureIntegrationsFunctions(**functions)
        if isinstance(key_vault, dict):
            key_vault = CloudAzureIntegrationsKeyVault(**key_vault)
        if isinstance(load_balancer, dict):
            load_balancer = CloudAzureIntegrationsLoadBalancer(**load_balancer)
        if isinstance(logic_apps, dict):
            logic_apps = CloudAzureIntegrationsLogicApps(**logic_apps)
        if isinstance(machine_learning, dict):
            machine_learning = CloudAzureIntegrationsMachineLearning(**machine_learning)
        if isinstance(maria_db, dict):
            maria_db = CloudAzureIntegrationsMariaDb(**maria_db)
        if isinstance(monitor, dict):
            monitor = CloudAzureIntegrationsMonitor(**monitor)
        if isinstance(mysql, dict):
            mysql = CloudAzureIntegrationsMysql(**mysql)
        if isinstance(mysql_flexible, dict):
            mysql_flexible = CloudAzureIntegrationsMysqlFlexible(**mysql_flexible)
        if isinstance(postgresql, dict):
            postgresql = CloudAzureIntegrationsPostgresql(**postgresql)
        if isinstance(postgresql_flexible, dict):
            postgresql_flexible = CloudAzureIntegrationsPostgresqlFlexible(**postgresql_flexible)
        if isinstance(power_bi_dedicated, dict):
            power_bi_dedicated = CloudAzureIntegrationsPowerBiDedicated(**power_bi_dedicated)
        if isinstance(redis_cache, dict):
            redis_cache = CloudAzureIntegrationsRedisCache(**redis_cache)
        if isinstance(service_bus, dict):
            service_bus = CloudAzureIntegrationsServiceBus(**service_bus)
        if isinstance(sql, dict):
            sql = CloudAzureIntegrationsSql(**sql)
        if isinstance(sql_managed, dict):
            sql_managed = CloudAzureIntegrationsSqlManaged(**sql_managed)
        if isinstance(storage, dict):
            storage = CloudAzureIntegrationsStorage(**storage)
        if isinstance(virtual_machine, dict):
            virtual_machine = CloudAzureIntegrationsVirtualMachine(**virtual_machine)
        if isinstance(virtual_networks, dict):
            virtual_networks = CloudAzureIntegrationsVirtualNetworks(**virtual_networks)
        if isinstance(vms, dict):
            vms = CloudAzureIntegrationsVms(**vms)
        if isinstance(vpn_gateway, dict):
            vpn_gateway = CloudAzureIntegrationsVpnGateway(**vpn_gateway)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__13ee2fa476895d6263cfb79e1ae2a10a954506372138d7384bc3536db760b713)
            check_type(argname="argument connection", value=connection, expected_type=type_hints["connection"])
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument for_each", value=for_each, expected_type=type_hints["for_each"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
            check_type(argname="argument provisioners", value=provisioners, expected_type=type_hints["provisioners"])
            check_type(argname="argument linked_account_id", value=linked_account_id, expected_type=type_hints["linked_account_id"])
            check_type(argname="argument account_id", value=account_id, expected_type=type_hints["account_id"])
            check_type(argname="argument api_management", value=api_management, expected_type=type_hints["api_management"])
            check_type(argname="argument app_gateway", value=app_gateway, expected_type=type_hints["app_gateway"])
            check_type(argname="argument app_service", value=app_service, expected_type=type_hints["app_service"])
            check_type(argname="argument auto_discovery", value=auto_discovery, expected_type=type_hints["auto_discovery"])
            check_type(argname="argument containers", value=containers, expected_type=type_hints["containers"])
            check_type(argname="argument cosmos_db", value=cosmos_db, expected_type=type_hints["cosmos_db"])
            check_type(argname="argument cost_management", value=cost_management, expected_type=type_hints["cost_management"])
            check_type(argname="argument data_factory", value=data_factory, expected_type=type_hints["data_factory"])
            check_type(argname="argument event_hub", value=event_hub, expected_type=type_hints["event_hub"])
            check_type(argname="argument express_route", value=express_route, expected_type=type_hints["express_route"])
            check_type(argname="argument firewalls", value=firewalls, expected_type=type_hints["firewalls"])
            check_type(argname="argument front_door", value=front_door, expected_type=type_hints["front_door"])
            check_type(argname="argument functions", value=functions, expected_type=type_hints["functions"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
            check_type(argname="argument key_vault", value=key_vault, expected_type=type_hints["key_vault"])
            check_type(argname="argument load_balancer", value=load_balancer, expected_type=type_hints["load_balancer"])
            check_type(argname="argument logic_apps", value=logic_apps, expected_type=type_hints["logic_apps"])
            check_type(argname="argument machine_learning", value=machine_learning, expected_type=type_hints["machine_learning"])
            check_type(argname="argument maria_db", value=maria_db, expected_type=type_hints["maria_db"])
            check_type(argname="argument monitor", value=monitor, expected_type=type_hints["monitor"])
            check_type(argname="argument mysql", value=mysql, expected_type=type_hints["mysql"])
            check_type(argname="argument mysql_flexible", value=mysql_flexible, expected_type=type_hints["mysql_flexible"])
            check_type(argname="argument postgresql", value=postgresql, expected_type=type_hints["postgresql"])
            check_type(argname="argument postgresql_flexible", value=postgresql_flexible, expected_type=type_hints["postgresql_flexible"])
            check_type(argname="argument power_bi_dedicated", value=power_bi_dedicated, expected_type=type_hints["power_bi_dedicated"])
            check_type(argname="argument redis_cache", value=redis_cache, expected_type=type_hints["redis_cache"])
            check_type(argname="argument service_bus", value=service_bus, expected_type=type_hints["service_bus"])
            check_type(argname="argument sql", value=sql, expected_type=type_hints["sql"])
            check_type(argname="argument sql_managed", value=sql_managed, expected_type=type_hints["sql_managed"])
            check_type(argname="argument storage", value=storage, expected_type=type_hints["storage"])
            check_type(argname="argument virtual_machine", value=virtual_machine, expected_type=type_hints["virtual_machine"])
            check_type(argname="argument virtual_networks", value=virtual_networks, expected_type=type_hints["virtual_networks"])
            check_type(argname="argument vms", value=vms, expected_type=type_hints["vms"])
            check_type(argname="argument vpn_gateway", value=vpn_gateway, expected_type=type_hints["vpn_gateway"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "linked_account_id": linked_account_id,
        }
        if connection is not None:
            self._values["connection"] = connection
        if count is not None:
            self._values["count"] = count
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if for_each is not None:
            self._values["for_each"] = for_each
        if lifecycle is not None:
            self._values["lifecycle"] = lifecycle
        if provider is not None:
            self._values["provider"] = provider
        if provisioners is not None:
            self._values["provisioners"] = provisioners
        if account_id is not None:
            self._values["account_id"] = account_id
        if api_management is not None:
            self._values["api_management"] = api_management
        if app_gateway is not None:
            self._values["app_gateway"] = app_gateway
        if app_service is not None:
            self._values["app_service"] = app_service
        if auto_discovery is not None:
            self._values["auto_discovery"] = auto_discovery
        if containers is not None:
            self._values["containers"] = containers
        if cosmos_db is not None:
            self._values["cosmos_db"] = cosmos_db
        if cost_management is not None:
            self._values["cost_management"] = cost_management
        if data_factory is not None:
            self._values["data_factory"] = data_factory
        if event_hub is not None:
            self._values["event_hub"] = event_hub
        if express_route is not None:
            self._values["express_route"] = express_route
        if firewalls is not None:
            self._values["firewalls"] = firewalls
        if front_door is not None:
            self._values["front_door"] = front_door
        if functions is not None:
            self._values["functions"] = functions
        if id is not None:
            self._values["id"] = id
        if key_vault is not None:
            self._values["key_vault"] = key_vault
        if load_balancer is not None:
            self._values["load_balancer"] = load_balancer
        if logic_apps is not None:
            self._values["logic_apps"] = logic_apps
        if machine_learning is not None:
            self._values["machine_learning"] = machine_learning
        if maria_db is not None:
            self._values["maria_db"] = maria_db
        if monitor is not None:
            self._values["monitor"] = monitor
        if mysql is not None:
            self._values["mysql"] = mysql
        if mysql_flexible is not None:
            self._values["mysql_flexible"] = mysql_flexible
        if postgresql is not None:
            self._values["postgresql"] = postgresql
        if postgresql_flexible is not None:
            self._values["postgresql_flexible"] = postgresql_flexible
        if power_bi_dedicated is not None:
            self._values["power_bi_dedicated"] = power_bi_dedicated
        if redis_cache is not None:
            self._values["redis_cache"] = redis_cache
        if service_bus is not None:
            self._values["service_bus"] = service_bus
        if sql is not None:
            self._values["sql"] = sql
        if sql_managed is not None:
            self._values["sql_managed"] = sql_managed
        if storage is not None:
            self._values["storage"] = storage
        if virtual_machine is not None:
            self._values["virtual_machine"] = virtual_machine
        if virtual_networks is not None:
            self._values["virtual_networks"] = virtual_networks
        if vms is not None:
            self._values["vms"] = vms
        if vpn_gateway is not None:
            self._values["vpn_gateway"] = vpn_gateway

    @builtins.property
    def connection(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, _cdktn_78ede62e.WinrmProvisionerConnection]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("connection")
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, _cdktn_78ede62e.WinrmProvisionerConnection]], result)

    @builtins.property
    def count(
        self,
    ) -> typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("count")
        return typing.cast(typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]], result)

    @builtins.property
    def depends_on(
        self,
    ) -> typing.Optional[typing.List[_cdktn_78ede62e.ITerraformDependable]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List[_cdktn_78ede62e.ITerraformDependable]], result)

    @builtins.property
    def for_each(self) -> typing.Optional[_cdktn_78ede62e.ITerraformIterator]:
        '''
        :stability: experimental
        '''
        result = self._values.get("for_each")
        return typing.cast(typing.Optional[_cdktn_78ede62e.ITerraformIterator], result)

    @builtins.property
    def lifecycle(self) -> typing.Optional[_cdktn_78ede62e.TerraformResourceLifecycle]:
        '''
        :stability: experimental
        '''
        result = self._values.get("lifecycle")
        return typing.cast(typing.Optional[_cdktn_78ede62e.TerraformResourceLifecycle], result)

    @builtins.property
    def provider(self) -> typing.Optional[_cdktn_78ede62e.TerraformProvider]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provider")
        return typing.cast(typing.Optional[_cdktn_78ede62e.TerraformProvider], result)

    @builtins.property
    def provisioners(
        self,
    ) -> typing.Optional[typing.List[typing.Union[_cdktn_78ede62e.FileProvisioner, _cdktn_78ede62e.LocalExecProvisioner, _cdktn_78ede62e.RemoteExecProvisioner]]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provisioners")
        return typing.cast(typing.Optional[typing.List[typing.Union[_cdktn_78ede62e.FileProvisioner, _cdktn_78ede62e.LocalExecProvisioner, _cdktn_78ede62e.RemoteExecProvisioner]]], result)

    @builtins.property
    def linked_account_id(self) -> jsii.Number:
        '''The ID of the linked Azure account in New Relic.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#linked_account_id CloudAzureIntegrations#linked_account_id}
        '''
        result = self._values.get("linked_account_id")
        assert result is not None, "Required property 'linked_account_id' is missing"
        return typing.cast(jsii.Number, result)

    @builtins.property
    def account_id(self) -> typing.Optional[jsii.Number]:
        '''The ID of the account in New Relic.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#account_id CloudAzureIntegrations#account_id}
        '''
        result = self._values.get("account_id")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def api_management(self) -> typing.Optional[CloudAzureIntegrationsApiManagement]:
        '''api_management block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#api_management CloudAzureIntegrations#api_management}
        '''
        result = self._values.get("api_management")
        return typing.cast(typing.Optional[CloudAzureIntegrationsApiManagement], result)

    @builtins.property
    def app_gateway(self) -> typing.Optional[CloudAzureIntegrationsAppGateway]:
        '''app_gateway block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#app_gateway CloudAzureIntegrations#app_gateway}
        '''
        result = self._values.get("app_gateway")
        return typing.cast(typing.Optional[CloudAzureIntegrationsAppGateway], result)

    @builtins.property
    def app_service(self) -> typing.Optional[CloudAzureIntegrationsAppService]:
        '''app_service block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#app_service CloudAzureIntegrations#app_service}
        '''
        result = self._values.get("app_service")
        return typing.cast(typing.Optional[CloudAzureIntegrationsAppService], result)

    @builtins.property
    def auto_discovery(self) -> typing.Optional[CloudAzureIntegrationsAutoDiscovery]:
        '''auto_discovery block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#auto_discovery CloudAzureIntegrations#auto_discovery}
        '''
        result = self._values.get("auto_discovery")
        return typing.cast(typing.Optional[CloudAzureIntegrationsAutoDiscovery], result)

    @builtins.property
    def containers(self) -> typing.Optional["CloudAzureIntegrationsContainers"]:
        '''containers block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#containers CloudAzureIntegrations#containers}
        '''
        result = self._values.get("containers")
        return typing.cast(typing.Optional["CloudAzureIntegrationsContainers"], result)

    @builtins.property
    def cosmos_db(self) -> typing.Optional["CloudAzureIntegrationsCosmosDb"]:
        '''cosmos_db block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#cosmos_db CloudAzureIntegrations#cosmos_db}
        '''
        result = self._values.get("cosmos_db")
        return typing.cast(typing.Optional["CloudAzureIntegrationsCosmosDb"], result)

    @builtins.property
    def cost_management(
        self,
    ) -> typing.Optional["CloudAzureIntegrationsCostManagement"]:
        '''cost_management block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#cost_management CloudAzureIntegrations#cost_management}
        '''
        result = self._values.get("cost_management")
        return typing.cast(typing.Optional["CloudAzureIntegrationsCostManagement"], result)

    @builtins.property
    def data_factory(self) -> typing.Optional["CloudAzureIntegrationsDataFactory"]:
        '''data_factory block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#data_factory CloudAzureIntegrations#data_factory}
        '''
        result = self._values.get("data_factory")
        return typing.cast(typing.Optional["CloudAzureIntegrationsDataFactory"], result)

    @builtins.property
    def event_hub(self) -> typing.Optional["CloudAzureIntegrationsEventHub"]:
        '''event_hub block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#event_hub CloudAzureIntegrations#event_hub}
        '''
        result = self._values.get("event_hub")
        return typing.cast(typing.Optional["CloudAzureIntegrationsEventHub"], result)

    @builtins.property
    def express_route(self) -> typing.Optional["CloudAzureIntegrationsExpressRoute"]:
        '''express_route block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#express_route CloudAzureIntegrations#express_route}
        '''
        result = self._values.get("express_route")
        return typing.cast(typing.Optional["CloudAzureIntegrationsExpressRoute"], result)

    @builtins.property
    def firewalls(self) -> typing.Optional["CloudAzureIntegrationsFirewalls"]:
        '''firewalls block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#firewalls CloudAzureIntegrations#firewalls}
        '''
        result = self._values.get("firewalls")
        return typing.cast(typing.Optional["CloudAzureIntegrationsFirewalls"], result)

    @builtins.property
    def front_door(self) -> typing.Optional["CloudAzureIntegrationsFrontDoor"]:
        '''front_door block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#front_door CloudAzureIntegrations#front_door}
        '''
        result = self._values.get("front_door")
        return typing.cast(typing.Optional["CloudAzureIntegrationsFrontDoor"], result)

    @builtins.property
    def functions(self) -> typing.Optional["CloudAzureIntegrationsFunctions"]:
        '''functions block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#functions CloudAzureIntegrations#functions}
        '''
        result = self._values.get("functions")
        return typing.cast(typing.Optional["CloudAzureIntegrationsFunctions"], result)

    @builtins.property
    def id(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#id CloudAzureIntegrations#id}.

        Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        '''
        result = self._values.get("id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def key_vault(self) -> typing.Optional["CloudAzureIntegrationsKeyVault"]:
        '''key_vault block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#key_vault CloudAzureIntegrations#key_vault}
        '''
        result = self._values.get("key_vault")
        return typing.cast(typing.Optional["CloudAzureIntegrationsKeyVault"], result)

    @builtins.property
    def load_balancer(self) -> typing.Optional["CloudAzureIntegrationsLoadBalancer"]:
        '''load_balancer block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#load_balancer CloudAzureIntegrations#load_balancer}
        '''
        result = self._values.get("load_balancer")
        return typing.cast(typing.Optional["CloudAzureIntegrationsLoadBalancer"], result)

    @builtins.property
    def logic_apps(self) -> typing.Optional["CloudAzureIntegrationsLogicApps"]:
        '''logic_apps block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#logic_apps CloudAzureIntegrations#logic_apps}
        '''
        result = self._values.get("logic_apps")
        return typing.cast(typing.Optional["CloudAzureIntegrationsLogicApps"], result)

    @builtins.property
    def machine_learning(
        self,
    ) -> typing.Optional["CloudAzureIntegrationsMachineLearning"]:
        '''machine_learning block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#machine_learning CloudAzureIntegrations#machine_learning}
        '''
        result = self._values.get("machine_learning")
        return typing.cast(typing.Optional["CloudAzureIntegrationsMachineLearning"], result)

    @builtins.property
    def maria_db(self) -> typing.Optional["CloudAzureIntegrationsMariaDb"]:
        '''maria_db block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#maria_db CloudAzureIntegrations#maria_db}
        '''
        result = self._values.get("maria_db")
        return typing.cast(typing.Optional["CloudAzureIntegrationsMariaDb"], result)

    @builtins.property
    def monitor(self) -> typing.Optional["CloudAzureIntegrationsMonitor"]:
        '''monitor block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#monitor CloudAzureIntegrations#monitor}
        '''
        result = self._values.get("monitor")
        return typing.cast(typing.Optional["CloudAzureIntegrationsMonitor"], result)

    @builtins.property
    def mysql(self) -> typing.Optional["CloudAzureIntegrationsMysql"]:
        '''mysql block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#mysql CloudAzureIntegrations#mysql}
        '''
        result = self._values.get("mysql")
        return typing.cast(typing.Optional["CloudAzureIntegrationsMysql"], result)

    @builtins.property
    def mysql_flexible(self) -> typing.Optional["CloudAzureIntegrationsMysqlFlexible"]:
        '''mysql_flexible block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#mysql_flexible CloudAzureIntegrations#mysql_flexible}
        '''
        result = self._values.get("mysql_flexible")
        return typing.cast(typing.Optional["CloudAzureIntegrationsMysqlFlexible"], result)

    @builtins.property
    def postgresql(self) -> typing.Optional["CloudAzureIntegrationsPostgresql"]:
        '''postgresql block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#postgresql CloudAzureIntegrations#postgresql}
        '''
        result = self._values.get("postgresql")
        return typing.cast(typing.Optional["CloudAzureIntegrationsPostgresql"], result)

    @builtins.property
    def postgresql_flexible(
        self,
    ) -> typing.Optional["CloudAzureIntegrationsPostgresqlFlexible"]:
        '''postgresql_flexible block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#postgresql_flexible CloudAzureIntegrations#postgresql_flexible}
        '''
        result = self._values.get("postgresql_flexible")
        return typing.cast(typing.Optional["CloudAzureIntegrationsPostgresqlFlexible"], result)

    @builtins.property
    def power_bi_dedicated(
        self,
    ) -> typing.Optional["CloudAzureIntegrationsPowerBiDedicated"]:
        '''power_bi_dedicated block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#power_bi_dedicated CloudAzureIntegrations#power_bi_dedicated}
        '''
        result = self._values.get("power_bi_dedicated")
        return typing.cast(typing.Optional["CloudAzureIntegrationsPowerBiDedicated"], result)

    @builtins.property
    def redis_cache(self) -> typing.Optional["CloudAzureIntegrationsRedisCache"]:
        '''redis_cache block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#redis_cache CloudAzureIntegrations#redis_cache}
        '''
        result = self._values.get("redis_cache")
        return typing.cast(typing.Optional["CloudAzureIntegrationsRedisCache"], result)

    @builtins.property
    def service_bus(self) -> typing.Optional["CloudAzureIntegrationsServiceBus"]:
        '''service_bus block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#service_bus CloudAzureIntegrations#service_bus}
        '''
        result = self._values.get("service_bus")
        return typing.cast(typing.Optional["CloudAzureIntegrationsServiceBus"], result)

    @builtins.property
    def sql(self) -> typing.Optional["CloudAzureIntegrationsSql"]:
        '''sql block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#sql CloudAzureIntegrations#sql}
        '''
        result = self._values.get("sql")
        return typing.cast(typing.Optional["CloudAzureIntegrationsSql"], result)

    @builtins.property
    def sql_managed(self) -> typing.Optional["CloudAzureIntegrationsSqlManaged"]:
        '''sql_managed block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#sql_managed CloudAzureIntegrations#sql_managed}
        '''
        result = self._values.get("sql_managed")
        return typing.cast(typing.Optional["CloudAzureIntegrationsSqlManaged"], result)

    @builtins.property
    def storage(self) -> typing.Optional["CloudAzureIntegrationsStorage"]:
        '''storage block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#storage CloudAzureIntegrations#storage}
        '''
        result = self._values.get("storage")
        return typing.cast(typing.Optional["CloudAzureIntegrationsStorage"], result)

    @builtins.property
    def virtual_machine(
        self,
    ) -> typing.Optional["CloudAzureIntegrationsVirtualMachine"]:
        '''virtual_machine block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#virtual_machine CloudAzureIntegrations#virtual_machine}
        '''
        result = self._values.get("virtual_machine")
        return typing.cast(typing.Optional["CloudAzureIntegrationsVirtualMachine"], result)

    @builtins.property
    def virtual_networks(
        self,
    ) -> typing.Optional["CloudAzureIntegrationsVirtualNetworks"]:
        '''virtual_networks block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#virtual_networks CloudAzureIntegrations#virtual_networks}
        '''
        result = self._values.get("virtual_networks")
        return typing.cast(typing.Optional["CloudAzureIntegrationsVirtualNetworks"], result)

    @builtins.property
    def vms(self) -> typing.Optional["CloudAzureIntegrationsVms"]:
        '''vms block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#vms CloudAzureIntegrations#vms}
        '''
        result = self._values.get("vms")
        return typing.cast(typing.Optional["CloudAzureIntegrationsVms"], result)

    @builtins.property
    def vpn_gateway(self) -> typing.Optional["CloudAzureIntegrationsVpnGateway"]:
        '''vpn_gateway block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#vpn_gateway CloudAzureIntegrations#vpn_gateway}
        '''
        result = self._values.get("vpn_gateway")
        return typing.cast(typing.Optional["CloudAzureIntegrationsVpnGateway"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudAzureIntegrationsConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsContainers",
    jsii_struct_bases=[],
    name_mapping={
        "metrics_polling_interval": "metricsPollingInterval",
        "resource_groups": "resourceGroups",
    },
)
class CloudAzureIntegrationsContainers:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cf450332e153c6c577c8e60ba02a0932652011337e4ec967f85a95b212daf17d)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
            check_type(argname="argument resource_groups", value=resource_groups, expected_type=type_hints["resource_groups"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval
        if resource_groups is not None:
            self._values["resource_groups"] = resource_groups

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''The data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def resource_groups(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        result = self._values.get("resource_groups")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudAzureIntegrationsContainers(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudAzureIntegrationsContainersOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsContainersOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2f9eb7eee0b268abcd8f0f82b0801a042e233f47495565a567628ea6cd41f994)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @jsii.member(jsii_name="resetResourceGroups")
    def reset_resource_groups(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResourceGroups", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="resourceGroupsInput")
    def resource_groups_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "resourceGroupsInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5692206aa258f36dba8e8e8fcc635abc8c6e406f12881b8b77129b05eb19cd19)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="resourceGroups")
    def resource_groups(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "resourceGroups"))

    @resource_groups.setter
    def resource_groups(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7470f8140f0fe9cc791c4066a902ccf612e89b96436070c93a1fc3efb25649b2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "resourceGroups", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudAzureIntegrationsContainers]:
        return typing.cast(typing.Optional[CloudAzureIntegrationsContainers], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudAzureIntegrationsContainers],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f5a0aa1859f86c70d9da30cd586278cc80104541e1cfd941b4601661bc6e160f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsCosmosDb",
    jsii_struct_bases=[],
    name_mapping={
        "metrics_polling_interval": "metricsPollingInterval",
        "resource_groups": "resourceGroups",
    },
)
class CloudAzureIntegrationsCosmosDb:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e5387d1fae751015c396fa30465f8072a546b633411f46b0de0f95788e35fd9f)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
            check_type(argname="argument resource_groups", value=resource_groups, expected_type=type_hints["resource_groups"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval
        if resource_groups is not None:
            self._values["resource_groups"] = resource_groups

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''The data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def resource_groups(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        result = self._values.get("resource_groups")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudAzureIntegrationsCosmosDb(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudAzureIntegrationsCosmosDbOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsCosmosDbOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c04891dc81464d3bf5af83225d61fa174e1bd48fe7cd5658c9368c12dd07b0e8)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @jsii.member(jsii_name="resetResourceGroups")
    def reset_resource_groups(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResourceGroups", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="resourceGroupsInput")
    def resource_groups_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "resourceGroupsInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0a6b9901c40e7a3493846f6b9d39287acb7f877b925911c6f84e5f71b14a9c50)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="resourceGroups")
    def resource_groups(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "resourceGroups"))

    @resource_groups.setter
    def resource_groups(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9514f6770e4d642da2d878ece2f27e8ca571151f86356a8363044627015ce6e8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "resourceGroups", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudAzureIntegrationsCosmosDb]:
        return typing.cast(typing.Optional[CloudAzureIntegrationsCosmosDb], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudAzureIntegrationsCosmosDb],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__db5282d2cc9482cc965ca9f4ee203682f63851101db4c2bacb724dbd03935511)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsCostManagement",
    jsii_struct_bases=[],
    name_mapping={
        "metrics_polling_interval": "metricsPollingInterval",
        "tag_keys": "tagKeys",
    },
)
class CloudAzureIntegrationsCostManagement:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        tag_keys: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param tag_keys: Specify if additional cost data per tag should be collected. This field is case sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#tag_keys CloudAzureIntegrations#tag_keys}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ff20aa41ceb7c437a074cdfd8e84b2105562eeadd2c52e8a8d5ab86d1bda1c04)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
            check_type(argname="argument tag_keys", value=tag_keys, expected_type=type_hints["tag_keys"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval
        if tag_keys is not None:
            self._values["tag_keys"] = tag_keys

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''The data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def tag_keys(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Specify if additional cost data per tag should be collected. This field is case sensitive.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#tag_keys CloudAzureIntegrations#tag_keys}
        '''
        result = self._values.get("tag_keys")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudAzureIntegrationsCostManagement(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudAzureIntegrationsCostManagementOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsCostManagementOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a5757dbc963b54c5b6f2aec69e380697f87ad0d894bb2a2deb4ff38fd8ff5d1b)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @jsii.member(jsii_name="resetTagKeys")
    def reset_tag_keys(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTagKeys", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="tagKeysInput")
    def tag_keys_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "tagKeysInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__721a967a67544a56dd6baab8f2953a785e1c1e00ab82613527a4573f0e33bf8e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="tagKeys")
    def tag_keys(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "tagKeys"))

    @tag_keys.setter
    def tag_keys(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__85860f0af79cdcc6889320167c31d214a3a2bb1be9cd2966263929de53dcc71f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "tagKeys", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudAzureIntegrationsCostManagement]:
        return typing.cast(typing.Optional[CloudAzureIntegrationsCostManagement], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudAzureIntegrationsCostManagement],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9076299edc07bee6cc7b689a17fd34d28d0b40fd8fc700484035bf68697352b0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsDataFactory",
    jsii_struct_bases=[],
    name_mapping={
        "metrics_polling_interval": "metricsPollingInterval",
        "resource_groups": "resourceGroups",
    },
)
class CloudAzureIntegrationsDataFactory:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cbb741771987085085e5603019836c85d94d5b558832c69cf18ceca0a7d59c55)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
            check_type(argname="argument resource_groups", value=resource_groups, expected_type=type_hints["resource_groups"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval
        if resource_groups is not None:
            self._values["resource_groups"] = resource_groups

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''The data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def resource_groups(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        result = self._values.get("resource_groups")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudAzureIntegrationsDataFactory(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudAzureIntegrationsDataFactoryOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsDataFactoryOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e792134c5d07e06ba9063d1da0b15249e9214809806a8392a87758e22842bb24)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @jsii.member(jsii_name="resetResourceGroups")
    def reset_resource_groups(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResourceGroups", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="resourceGroupsInput")
    def resource_groups_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "resourceGroupsInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ec4e00d63d58952a5e0e8d538791eb2068bf01307ca532bffc1ff9a0b8401de0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="resourceGroups")
    def resource_groups(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "resourceGroups"))

    @resource_groups.setter
    def resource_groups(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d8be53212fbbfad8c2ff10f1e6a6099edc0b205eeaf2e83d635d85ad095af2f9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "resourceGroups", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudAzureIntegrationsDataFactory]:
        return typing.cast(typing.Optional[CloudAzureIntegrationsDataFactory], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudAzureIntegrationsDataFactory],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d1c6a3e442add69cce0bc19c79ccb122d5e749f4f6ad4c3143fa6a0da2ea4228)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsEventHub",
    jsii_struct_bases=[],
    name_mapping={
        "metrics_polling_interval": "metricsPollingInterval",
        "resource_groups": "resourceGroups",
    },
)
class CloudAzureIntegrationsEventHub:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c93af68616d672c0f7df34b7797e8fa7ef2f59f2aed6b5178a9b28edd62dee3b)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
            check_type(argname="argument resource_groups", value=resource_groups, expected_type=type_hints["resource_groups"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval
        if resource_groups is not None:
            self._values["resource_groups"] = resource_groups

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''The data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def resource_groups(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        result = self._values.get("resource_groups")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudAzureIntegrationsEventHub(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudAzureIntegrationsEventHubOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsEventHubOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5d7e846943539b05784ebf05ac20e2bd2e06126668e7299214d5e19bfdf06c35)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @jsii.member(jsii_name="resetResourceGroups")
    def reset_resource_groups(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResourceGroups", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="resourceGroupsInput")
    def resource_groups_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "resourceGroupsInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__10a3190277db50d6c8ef7b5eae48ade16a5e679e51b8a36f50db064ab41f910f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="resourceGroups")
    def resource_groups(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "resourceGroups"))

    @resource_groups.setter
    def resource_groups(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c2026eb074526e7a27d8a1791baa0a5c854e98addf9792a160aff960f686f56e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "resourceGroups", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudAzureIntegrationsEventHub]:
        return typing.cast(typing.Optional[CloudAzureIntegrationsEventHub], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudAzureIntegrationsEventHub],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2e37e91814da95e5bd401bf64842a684b34468e0c512befc7e9f1ba58d4bce7e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsExpressRoute",
    jsii_struct_bases=[],
    name_mapping={
        "metrics_polling_interval": "metricsPollingInterval",
        "resource_groups": "resourceGroups",
    },
)
class CloudAzureIntegrationsExpressRoute:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9a46d4b82da78271744d384be44fa7bbafb2c1ca25cc7d0472a3e2aacc8b1917)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
            check_type(argname="argument resource_groups", value=resource_groups, expected_type=type_hints["resource_groups"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval
        if resource_groups is not None:
            self._values["resource_groups"] = resource_groups

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''The data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def resource_groups(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        result = self._values.get("resource_groups")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudAzureIntegrationsExpressRoute(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudAzureIntegrationsExpressRouteOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsExpressRouteOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b573c13f720b2156148cadff991c0a06ff5b03e0eb8d1dca22fe8783e79df6ba)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @jsii.member(jsii_name="resetResourceGroups")
    def reset_resource_groups(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResourceGroups", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="resourceGroupsInput")
    def resource_groups_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "resourceGroupsInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8b5a8412368dc1a7da93695e2b8c2e3598f8a0b1824d7a282d9c9b966773eabf)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="resourceGroups")
    def resource_groups(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "resourceGroups"))

    @resource_groups.setter
    def resource_groups(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6ad6fe50b65e5767d87208f8eb4f9f8a6afbd1cf3c8c82ba56de81792d8de54e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "resourceGroups", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudAzureIntegrationsExpressRoute]:
        return typing.cast(typing.Optional[CloudAzureIntegrationsExpressRoute], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudAzureIntegrationsExpressRoute],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2a22bf753a9c79382a0e4bace51fc1876e6124b9400ac1496c88df41997f0ab1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsFirewalls",
    jsii_struct_bases=[],
    name_mapping={
        "metrics_polling_interval": "metricsPollingInterval",
        "resource_groups": "resourceGroups",
    },
)
class CloudAzureIntegrationsFirewalls:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c34908c20f266c29e6557ed65cee6969f3111c7f2345e840f452dfe912e3e69b)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
            check_type(argname="argument resource_groups", value=resource_groups, expected_type=type_hints["resource_groups"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval
        if resource_groups is not None:
            self._values["resource_groups"] = resource_groups

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''The data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def resource_groups(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        result = self._values.get("resource_groups")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudAzureIntegrationsFirewalls(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudAzureIntegrationsFirewallsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsFirewallsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e5c9a387e4118d302e3de059489f2f3fb117eb91bea41a40e3c0ababe1529e16)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @jsii.member(jsii_name="resetResourceGroups")
    def reset_resource_groups(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResourceGroups", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="resourceGroupsInput")
    def resource_groups_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "resourceGroupsInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3229a82f6a066d8925f858be60ce1b601715cee59e54a80f06fe5ee096a9eb49)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="resourceGroups")
    def resource_groups(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "resourceGroups"))

    @resource_groups.setter
    def resource_groups(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d18a5d6a118b7ceae66b8f7673cf274a28748f562d7fe746ae13732924757dad)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "resourceGroups", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudAzureIntegrationsFirewalls]:
        return typing.cast(typing.Optional[CloudAzureIntegrationsFirewalls], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudAzureIntegrationsFirewalls],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fca4fbf0977ef60bc37ea25710e4bf986225c086a95a16abbe775b0f4a59077a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsFrontDoor",
    jsii_struct_bases=[],
    name_mapping={
        "metrics_polling_interval": "metricsPollingInterval",
        "resource_groups": "resourceGroups",
    },
)
class CloudAzureIntegrationsFrontDoor:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2867efacd48908e2b0f19b960188417cf6e0f982e89531f23c7530ad1ad10d08)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
            check_type(argname="argument resource_groups", value=resource_groups, expected_type=type_hints["resource_groups"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval
        if resource_groups is not None:
            self._values["resource_groups"] = resource_groups

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''The data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def resource_groups(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        result = self._values.get("resource_groups")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudAzureIntegrationsFrontDoor(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudAzureIntegrationsFrontDoorOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsFrontDoorOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9b7230a3ded9e0000e4dbe024c4a5a6fd6a815c68681ea047c51862571163d61)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @jsii.member(jsii_name="resetResourceGroups")
    def reset_resource_groups(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResourceGroups", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="resourceGroupsInput")
    def resource_groups_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "resourceGroupsInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f8be3b0da87229b5cb8d745de75d39a140ac54a062e07d662982efbfa4c27824)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="resourceGroups")
    def resource_groups(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "resourceGroups"))

    @resource_groups.setter
    def resource_groups(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d6572fb8e3538dcb610b63b1b74351eb16d4b8ee4b86bab2b0e17d0be4a4bf22)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "resourceGroups", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudAzureIntegrationsFrontDoor]:
        return typing.cast(typing.Optional[CloudAzureIntegrationsFrontDoor], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudAzureIntegrationsFrontDoor],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3eb2472079a62c15f0c5bd701de63c0e9a4a7daacaa47e2b6fdc77f551a18c3d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsFunctions",
    jsii_struct_bases=[],
    name_mapping={
        "metrics_polling_interval": "metricsPollingInterval",
        "resource_groups": "resourceGroups",
    },
)
class CloudAzureIntegrationsFunctions:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b7fa9a7cea7145dbbe4b6aef60bcdf07e7c242760b96ed2fb6b7b60c844e9886)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
            check_type(argname="argument resource_groups", value=resource_groups, expected_type=type_hints["resource_groups"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval
        if resource_groups is not None:
            self._values["resource_groups"] = resource_groups

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''The data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def resource_groups(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        result = self._values.get("resource_groups")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudAzureIntegrationsFunctions(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudAzureIntegrationsFunctionsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsFunctionsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1370771f7dbc8f42aaa78a7b6ad3e4880551d2da07a7c1e35398fd3db8bc101c)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @jsii.member(jsii_name="resetResourceGroups")
    def reset_resource_groups(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResourceGroups", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="resourceGroupsInput")
    def resource_groups_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "resourceGroupsInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fbb6b2cde2de9acd7dddeb50d732ab4bb9eaa2025a4171f30b5e0e4bfbb7ab1c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="resourceGroups")
    def resource_groups(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "resourceGroups"))

    @resource_groups.setter
    def resource_groups(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__236eb60ac7c3324ed30677830dcd812177e238a29a844289a8c8802070a83ac6)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "resourceGroups", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudAzureIntegrationsFunctions]:
        return typing.cast(typing.Optional[CloudAzureIntegrationsFunctions], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudAzureIntegrationsFunctions],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__163e65269a52ab99515e514b6aa22c1f922bcdd5e89252892a7ea36154641b60)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsKeyVault",
    jsii_struct_bases=[],
    name_mapping={
        "metrics_polling_interval": "metricsPollingInterval",
        "resource_groups": "resourceGroups",
    },
)
class CloudAzureIntegrationsKeyVault:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__85a02622620a904bf92cb1a78804be557ae2053a3f16bcd6b3aa8b0131a6aece)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
            check_type(argname="argument resource_groups", value=resource_groups, expected_type=type_hints["resource_groups"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval
        if resource_groups is not None:
            self._values["resource_groups"] = resource_groups

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''The data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def resource_groups(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        result = self._values.get("resource_groups")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudAzureIntegrationsKeyVault(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudAzureIntegrationsKeyVaultOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsKeyVaultOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d6ac8376a4f19f1cabb25d22af9f67074cb5cd59a846e36f35b51162395082fc)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @jsii.member(jsii_name="resetResourceGroups")
    def reset_resource_groups(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResourceGroups", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="resourceGroupsInput")
    def resource_groups_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "resourceGroupsInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8973d3f9933706cbe378b561264a05752dbcb83d23197f2071bd85c0bb4462db)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="resourceGroups")
    def resource_groups(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "resourceGroups"))

    @resource_groups.setter
    def resource_groups(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ed8f5f45641b09202e8e309698d017d0633787f15efac88771c9adc86b2280f8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "resourceGroups", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudAzureIntegrationsKeyVault]:
        return typing.cast(typing.Optional[CloudAzureIntegrationsKeyVault], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudAzureIntegrationsKeyVault],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1c9ae8f9134bb8f1bf3599c009b2fe22c813cce78d2210a6e4d834da7f48f6a7)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsLoadBalancer",
    jsii_struct_bases=[],
    name_mapping={
        "metrics_polling_interval": "metricsPollingInterval",
        "resource_groups": "resourceGroups",
    },
)
class CloudAzureIntegrationsLoadBalancer:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c74f65b062d1c45cf8f17eca8980683c9f7c10e41ec7eb7b19ef56ff368ce267)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
            check_type(argname="argument resource_groups", value=resource_groups, expected_type=type_hints["resource_groups"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval
        if resource_groups is not None:
            self._values["resource_groups"] = resource_groups

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''The data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def resource_groups(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        result = self._values.get("resource_groups")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudAzureIntegrationsLoadBalancer(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudAzureIntegrationsLoadBalancerOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsLoadBalancerOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a200845db3a559880a75bbaba89328a449db109b0cc1926b1b2c0fd02106f561)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @jsii.member(jsii_name="resetResourceGroups")
    def reset_resource_groups(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResourceGroups", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="resourceGroupsInput")
    def resource_groups_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "resourceGroupsInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7f2ae95bb3e7238607caed88ec1921fff5e12a879421517d7392d1600c710cce)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="resourceGroups")
    def resource_groups(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "resourceGroups"))

    @resource_groups.setter
    def resource_groups(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__33146af7ea9fb2e3bf4d013c4a2bb60b65d222e4c0ad752527ca7c0390e1f9f4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "resourceGroups", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudAzureIntegrationsLoadBalancer]:
        return typing.cast(typing.Optional[CloudAzureIntegrationsLoadBalancer], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudAzureIntegrationsLoadBalancer],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__710dfbc8727eb2daf941ff03b2ee97de13192948db01114b87f15cc81e2ed717)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsLogicApps",
    jsii_struct_bases=[],
    name_mapping={
        "metrics_polling_interval": "metricsPollingInterval",
        "resource_groups": "resourceGroups",
    },
)
class CloudAzureIntegrationsLogicApps:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5f04393b0ff24e1bea35b4b0bfba022a98410c8f84f353048cf6b8a937d496a8)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
            check_type(argname="argument resource_groups", value=resource_groups, expected_type=type_hints["resource_groups"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval
        if resource_groups is not None:
            self._values["resource_groups"] = resource_groups

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''The data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def resource_groups(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        result = self._values.get("resource_groups")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudAzureIntegrationsLogicApps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudAzureIntegrationsLogicAppsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsLogicAppsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1806c466a6908ab61a78d8dd7b0cfca83e5c2cb271b01e2190af01eabac0079b)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @jsii.member(jsii_name="resetResourceGroups")
    def reset_resource_groups(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResourceGroups", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="resourceGroupsInput")
    def resource_groups_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "resourceGroupsInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__17b803f5eeec789fb6734a816d21ec1f3eeb6388bcab445960a9efbc65af9a66)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="resourceGroups")
    def resource_groups(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "resourceGroups"))

    @resource_groups.setter
    def resource_groups(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d3c4dfafbc950029ba140945a944fb4ff5f2dbe410a7c6c9208287a47f917319)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "resourceGroups", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudAzureIntegrationsLogicApps]:
        return typing.cast(typing.Optional[CloudAzureIntegrationsLogicApps], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudAzureIntegrationsLogicApps],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__33ce535e4b071ddffed40912a79f60e4a308384b835ac93aebe1c6786099ed01)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsMachineLearning",
    jsii_struct_bases=[],
    name_mapping={
        "metrics_polling_interval": "metricsPollingInterval",
        "resource_groups": "resourceGroups",
    },
)
class CloudAzureIntegrationsMachineLearning:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2c1f2289768d89825f6bb53409cb963aaafa08fd49f413a7953bd634342cceeb)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
            check_type(argname="argument resource_groups", value=resource_groups, expected_type=type_hints["resource_groups"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval
        if resource_groups is not None:
            self._values["resource_groups"] = resource_groups

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''The data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def resource_groups(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        result = self._values.get("resource_groups")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudAzureIntegrationsMachineLearning(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudAzureIntegrationsMachineLearningOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsMachineLearningOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b540a17a925ab11a2a584ce4b591c7f75ad20e80fab3f358acbf8786e2c12314)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @jsii.member(jsii_name="resetResourceGroups")
    def reset_resource_groups(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResourceGroups", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="resourceGroupsInput")
    def resource_groups_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "resourceGroupsInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9db70352f1cc80d580f2e855ff2e426de4df9c5840cb95b7831ecdf98bb8a22a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="resourceGroups")
    def resource_groups(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "resourceGroups"))

    @resource_groups.setter
    def resource_groups(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cc7c8b630b76c8ce241322b412b430121d1fd93ab22b9b37d9d2e7a07f6c1730)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "resourceGroups", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudAzureIntegrationsMachineLearning]:
        return typing.cast(typing.Optional[CloudAzureIntegrationsMachineLearning], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudAzureIntegrationsMachineLearning],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3ec946dcadcbafe599f68e746c4602fb12b7224bc7d9c1a6e48c28a94820d9c3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsMariaDb",
    jsii_struct_bases=[],
    name_mapping={
        "metrics_polling_interval": "metricsPollingInterval",
        "resource_groups": "resourceGroups",
    },
)
class CloudAzureIntegrationsMariaDb:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__908818a94981e64e1b9e0c64de7cc7c4af8efdcf119b3016cd5d07ee7afd92fd)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
            check_type(argname="argument resource_groups", value=resource_groups, expected_type=type_hints["resource_groups"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval
        if resource_groups is not None:
            self._values["resource_groups"] = resource_groups

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''The data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def resource_groups(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        result = self._values.get("resource_groups")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudAzureIntegrationsMariaDb(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudAzureIntegrationsMariaDbOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsMariaDbOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__89539dcdbb7d23effaa170c83c218ca3f38f692adeaddfe0e4d869c1a9534a8b)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @jsii.member(jsii_name="resetResourceGroups")
    def reset_resource_groups(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResourceGroups", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="resourceGroupsInput")
    def resource_groups_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "resourceGroupsInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0364ce608003ea0d6a748d587e128e98d98470cbd7b8273deb1d62672100666e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="resourceGroups")
    def resource_groups(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "resourceGroups"))

    @resource_groups.setter
    def resource_groups(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d91cc43de552dab06bdcc7f537095151dbcab91e9a2f301af1b9cb80efc8501a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "resourceGroups", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudAzureIntegrationsMariaDb]:
        return typing.cast(typing.Optional[CloudAzureIntegrationsMariaDb], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudAzureIntegrationsMariaDb],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__567ef7803384794f4ada99d401372942e778e13c9e74f785e5b26fe2d1f14808)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsMonitor",
    jsii_struct_bases=[],
    name_mapping={
        "enabled": "enabled",
        "exclude_tags": "excludeTags",
        "include_tags": "includeTags",
        "metrics_polling_interval": "metricsPollingInterval",
        "resource_groups": "resourceGroups",
        "resource_types": "resourceTypes",
    },
)
class CloudAzureIntegrationsMonitor:
    def __init__(
        self,
        *,
        enabled: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        exclude_tags: typing.Optional[typing.Sequence[builtins.str]] = None,
        include_tags: typing.Optional[typing.Sequence[builtins.str]] = None,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
        resource_types: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param enabled: A flag that specifies if the integration is active. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#enabled CloudAzureIntegrations#enabled}
        :param exclude_tags: Specify resource tags in 'key:value' form to be excluded from monitoring. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#exclude_tags CloudAzureIntegrations#exclude_tags}
        :param include_tags: Specify resource tags in 'key:value' form to be monitored. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#include_tags CloudAzureIntegrations#include_tags}
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        :param resource_types: Specify each Azure resource type that needs to be monitored. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_types CloudAzureIntegrations#resource_types}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7cdc65d90751bd10e293a9b6758811939538b9f111eaae5d289561fc8d3d77af)
            check_type(argname="argument enabled", value=enabled, expected_type=type_hints["enabled"])
            check_type(argname="argument exclude_tags", value=exclude_tags, expected_type=type_hints["exclude_tags"])
            check_type(argname="argument include_tags", value=include_tags, expected_type=type_hints["include_tags"])
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
            check_type(argname="argument resource_groups", value=resource_groups, expected_type=type_hints["resource_groups"])
            check_type(argname="argument resource_types", value=resource_types, expected_type=type_hints["resource_types"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if enabled is not None:
            self._values["enabled"] = enabled
        if exclude_tags is not None:
            self._values["exclude_tags"] = exclude_tags
        if include_tags is not None:
            self._values["include_tags"] = include_tags
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval
        if resource_groups is not None:
            self._values["resource_groups"] = resource_groups
        if resource_types is not None:
            self._values["resource_types"] = resource_types

    @builtins.property
    def enabled(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''A flag that specifies if the integration is active.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#enabled CloudAzureIntegrations#enabled}
        '''
        result = self._values.get("enabled")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def exclude_tags(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Specify resource tags in 'key:value' form to be excluded from monitoring.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#exclude_tags CloudAzureIntegrations#exclude_tags}
        '''
        result = self._values.get("exclude_tags")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def include_tags(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Specify resource tags in 'key:value' form to be monitored.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#include_tags CloudAzureIntegrations#include_tags}
        '''
        result = self._values.get("include_tags")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''The data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def resource_groups(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        result = self._values.get("resource_groups")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def resource_types(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Specify each Azure resource type that needs to be monitored.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_types CloudAzureIntegrations#resource_types}
        '''
        result = self._values.get("resource_types")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudAzureIntegrationsMonitor(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudAzureIntegrationsMonitorOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsMonitorOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d66ed4b98d7e68075bd769ac29af72f1343528b3b58df5e931e0bc484725d68b)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetEnabled")
    def reset_enabled(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEnabled", []))

    @jsii.member(jsii_name="resetExcludeTags")
    def reset_exclude_tags(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetExcludeTags", []))

    @jsii.member(jsii_name="resetIncludeTags")
    def reset_include_tags(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetIncludeTags", []))

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @jsii.member(jsii_name="resetResourceGroups")
    def reset_resource_groups(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResourceGroups", []))

    @jsii.member(jsii_name="resetResourceTypes")
    def reset_resource_types(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResourceTypes", []))

    @builtins.property
    @jsii.member(jsii_name="enabledInput")
    def enabled_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "enabledInput"))

    @builtins.property
    @jsii.member(jsii_name="excludeTagsInput")
    def exclude_tags_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "excludeTagsInput"))

    @builtins.property
    @jsii.member(jsii_name="includeTagsInput")
    def include_tags_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "includeTagsInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="resourceGroupsInput")
    def resource_groups_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "resourceGroupsInput"))

    @builtins.property
    @jsii.member(jsii_name="resourceTypesInput")
    def resource_types_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "resourceTypesInput"))

    @builtins.property
    @jsii.member(jsii_name="enabled")
    def enabled(self) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "enabled"))

    @enabled.setter
    def enabled(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bf7699741b3b1fdcc2105441e8fd6870bfd973a7867926ce5a6abce17b4b07ce)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "enabled", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="excludeTags")
    def exclude_tags(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "excludeTags"))

    @exclude_tags.setter
    def exclude_tags(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__37cbd1a354b3a57be9a8c71ff84d3f01162d1c33c2cde9d2da02f994a5676b01)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "excludeTags", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="includeTags")
    def include_tags(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "includeTags"))

    @include_tags.setter
    def include_tags(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fdbe81faaa69b12970113db0ebfa7ccd2b3ab9dfef5ec124f0ea98edc805cce0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "includeTags", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__04f2f0c14459a59e3db2a7f5c55a7fc41ece7603933dd59875d44b67e6ed9535)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="resourceGroups")
    def resource_groups(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "resourceGroups"))

    @resource_groups.setter
    def resource_groups(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1465b2d515ea556913f02979f20b2f4df81fc0b7b0b722fe72248fbae9bad909)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "resourceGroups", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="resourceTypes")
    def resource_types(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "resourceTypes"))

    @resource_types.setter
    def resource_types(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b6815fc6eba3a603160d59005b46f8251eb9f5458b66a3cbc86c69bef73345d6)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "resourceTypes", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudAzureIntegrationsMonitor]:
        return typing.cast(typing.Optional[CloudAzureIntegrationsMonitor], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudAzureIntegrationsMonitor],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7e18fe11d98b6a4ac84694fdf3fc80c46d7f1e0fb7bb9adc93299b0805fcb651)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsMysql",
    jsii_struct_bases=[],
    name_mapping={
        "metrics_polling_interval": "metricsPollingInterval",
        "resource_groups": "resourceGroups",
    },
)
class CloudAzureIntegrationsMysql:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__442e0cc997bcbe3da8f56d3fb7982600907977b0bf2b91fc9181cb4eac411af6)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
            check_type(argname="argument resource_groups", value=resource_groups, expected_type=type_hints["resource_groups"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval
        if resource_groups is not None:
            self._values["resource_groups"] = resource_groups

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''The data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def resource_groups(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        result = self._values.get("resource_groups")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudAzureIntegrationsMysql(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsMysqlFlexible",
    jsii_struct_bases=[],
    name_mapping={
        "metrics_polling_interval": "metricsPollingInterval",
        "resource_groups": "resourceGroups",
    },
)
class CloudAzureIntegrationsMysqlFlexible:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__70e493d011b8eb5d23908259c8cc332c615590a0474ddf33a412771cd77137d8)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
            check_type(argname="argument resource_groups", value=resource_groups, expected_type=type_hints["resource_groups"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval
        if resource_groups is not None:
            self._values["resource_groups"] = resource_groups

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''The data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def resource_groups(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        result = self._values.get("resource_groups")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudAzureIntegrationsMysqlFlexible(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudAzureIntegrationsMysqlFlexibleOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsMysqlFlexibleOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__514a5f2fe06e7f7b6c5c3d170a83402cce4c79bd7f7275b7381b566d3f42a8c9)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @jsii.member(jsii_name="resetResourceGroups")
    def reset_resource_groups(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResourceGroups", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="resourceGroupsInput")
    def resource_groups_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "resourceGroupsInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__397c7c64b2a6a756d7f7833f4c58c9c78347f60ce6c2eb5ebe617c92ce0568ca)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="resourceGroups")
    def resource_groups(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "resourceGroups"))

    @resource_groups.setter
    def resource_groups(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4a9a5c621ab02fc7962b53ef33c24944dbc3bcc882ff83338835b8c81ce25963)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "resourceGroups", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudAzureIntegrationsMysqlFlexible]:
        return typing.cast(typing.Optional[CloudAzureIntegrationsMysqlFlexible], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudAzureIntegrationsMysqlFlexible],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__34fa2a0e3a4b9468d521ae4c9dfc1851b90293d1fd9690bc4b372d39d1b36288)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class CloudAzureIntegrationsMysqlOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsMysqlOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__737643009f66712be580e072f496fc1cdb4541dd05c08429b6f1fd2527df1221)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @jsii.member(jsii_name="resetResourceGroups")
    def reset_resource_groups(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResourceGroups", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="resourceGroupsInput")
    def resource_groups_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "resourceGroupsInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4fbcaed02336e98a7763a8a61e02aafc1ce9f063697703145331f83695dc44a5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="resourceGroups")
    def resource_groups(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "resourceGroups"))

    @resource_groups.setter
    def resource_groups(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ecf1bba189b95f8be242044acdcce950d3463396e1f84a94dbcd6660b95b6334)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "resourceGroups", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudAzureIntegrationsMysql]:
        return typing.cast(typing.Optional[CloudAzureIntegrationsMysql], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudAzureIntegrationsMysql],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fe1d9dee05c1605757f944bb7e4391555b3ece6f0eddbc6cc6a77d996db6a387)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsPostgresql",
    jsii_struct_bases=[],
    name_mapping={
        "metrics_polling_interval": "metricsPollingInterval",
        "resource_groups": "resourceGroups",
    },
)
class CloudAzureIntegrationsPostgresql:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__56baa5b4dc3fef377114ec06f65fa7777273b827983ef114998735c684132696)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
            check_type(argname="argument resource_groups", value=resource_groups, expected_type=type_hints["resource_groups"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval
        if resource_groups is not None:
            self._values["resource_groups"] = resource_groups

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''The data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def resource_groups(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        result = self._values.get("resource_groups")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudAzureIntegrationsPostgresql(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsPostgresqlFlexible",
    jsii_struct_bases=[],
    name_mapping={
        "metrics_polling_interval": "metricsPollingInterval",
        "resource_groups": "resourceGroups",
    },
)
class CloudAzureIntegrationsPostgresqlFlexible:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__57a003182e8f0464222f11c684dce9d392e84efee125f1ef165c6b001d544fee)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
            check_type(argname="argument resource_groups", value=resource_groups, expected_type=type_hints["resource_groups"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval
        if resource_groups is not None:
            self._values["resource_groups"] = resource_groups

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''The data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def resource_groups(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        result = self._values.get("resource_groups")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudAzureIntegrationsPostgresqlFlexible(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudAzureIntegrationsPostgresqlFlexibleOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsPostgresqlFlexibleOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7e5aefff9be9f325d733af726a0c117a08fc529eb45840884a40cda378189b59)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @jsii.member(jsii_name="resetResourceGroups")
    def reset_resource_groups(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResourceGroups", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="resourceGroupsInput")
    def resource_groups_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "resourceGroupsInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__acb95db99753993d679a39e719724de725e3b99b1a1a10cf3deddde125539d4c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="resourceGroups")
    def resource_groups(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "resourceGroups"))

    @resource_groups.setter
    def resource_groups(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b3ca602e46bc4a242eab0f5732d8b1deafbc6482f90fc8ab4735c670227a6bfd)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "resourceGroups", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[CloudAzureIntegrationsPostgresqlFlexible]:
        return typing.cast(typing.Optional[CloudAzureIntegrationsPostgresqlFlexible], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudAzureIntegrationsPostgresqlFlexible],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cd50a1ba123739f0be59aa0e7d32f69cd77c1eabf202cfbc9dd99ded77e48ab6)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class CloudAzureIntegrationsPostgresqlOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsPostgresqlOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__91dd6d1ab1c3c9ff6b080b7374338eabd274e56be40f895f1b5c804c81652a5b)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @jsii.member(jsii_name="resetResourceGroups")
    def reset_resource_groups(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResourceGroups", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="resourceGroupsInput")
    def resource_groups_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "resourceGroupsInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__109e3c37d3e41c5ddc3247da5d3c7cbcde6a5a4a2d0d868756ea04dec7736102)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="resourceGroups")
    def resource_groups(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "resourceGroups"))

    @resource_groups.setter
    def resource_groups(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ffa8ee0f6fce2014cd1eb0b39f27ccc25552255f1d5ad18cd62ece78d1eeda6b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "resourceGroups", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudAzureIntegrationsPostgresql]:
        return typing.cast(typing.Optional[CloudAzureIntegrationsPostgresql], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudAzureIntegrationsPostgresql],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7fd3164af9890d9deb08aca469323d1a8bdbd26a6710d524e9a275ccd17e8f9d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsPowerBiDedicated",
    jsii_struct_bases=[],
    name_mapping={
        "metrics_polling_interval": "metricsPollingInterval",
        "resource_groups": "resourceGroups",
    },
)
class CloudAzureIntegrationsPowerBiDedicated:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__16933a0cde7609bb2d08dd9e908352e3aae22aa004bdae7092a931d40a899d96)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
            check_type(argname="argument resource_groups", value=resource_groups, expected_type=type_hints["resource_groups"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval
        if resource_groups is not None:
            self._values["resource_groups"] = resource_groups

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''The data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def resource_groups(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        result = self._values.get("resource_groups")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudAzureIntegrationsPowerBiDedicated(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudAzureIntegrationsPowerBiDedicatedOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsPowerBiDedicatedOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2c2a156b3f5514b2a31b7fd022e2c6b6a99bc728e59cffd2fa3fd5a39704b4cd)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @jsii.member(jsii_name="resetResourceGroups")
    def reset_resource_groups(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResourceGroups", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="resourceGroupsInput")
    def resource_groups_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "resourceGroupsInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4b7d757f69b023385317f4c61c0f90416b5ea8ef7b7e03d62d15becaf025522c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="resourceGroups")
    def resource_groups(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "resourceGroups"))

    @resource_groups.setter
    def resource_groups(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__48c5b8980bfa9af554c0efefacfda35c4f561d0242f52d27fc3f3d44f6e5da39)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "resourceGroups", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudAzureIntegrationsPowerBiDedicated]:
        return typing.cast(typing.Optional[CloudAzureIntegrationsPowerBiDedicated], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudAzureIntegrationsPowerBiDedicated],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6bbcae35322bc57017b38b0c6f1548c4ecec59fe5179db433c2011f7577ccbb2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsRedisCache",
    jsii_struct_bases=[],
    name_mapping={
        "metrics_polling_interval": "metricsPollingInterval",
        "resource_groups": "resourceGroups",
    },
)
class CloudAzureIntegrationsRedisCache:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7895c51ab3aa2965d3b322c41a134828e84320d470d648e4b627183466e7110b)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
            check_type(argname="argument resource_groups", value=resource_groups, expected_type=type_hints["resource_groups"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval
        if resource_groups is not None:
            self._values["resource_groups"] = resource_groups

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''The data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def resource_groups(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        result = self._values.get("resource_groups")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudAzureIntegrationsRedisCache(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudAzureIntegrationsRedisCacheOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsRedisCacheOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e01494200d1ba2ddfb89e1338f9066bc982f6f9ce00d58acde5b8fcab906db57)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @jsii.member(jsii_name="resetResourceGroups")
    def reset_resource_groups(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResourceGroups", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="resourceGroupsInput")
    def resource_groups_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "resourceGroupsInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__79f90ac4a98ca985defd083cae7c26b81e2197086664ac494d5616292c1438a1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="resourceGroups")
    def resource_groups(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "resourceGroups"))

    @resource_groups.setter
    def resource_groups(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__751146aa32087a88c393743bd5f640d6d06ec0da0387b1d2016bfbbe29a2ce43)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "resourceGroups", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudAzureIntegrationsRedisCache]:
        return typing.cast(typing.Optional[CloudAzureIntegrationsRedisCache], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudAzureIntegrationsRedisCache],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__db98a5865cedfa29f5de0841a8b4e77a6408728352dd63a885cf121bf48df838)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsServiceBus",
    jsii_struct_bases=[],
    name_mapping={
        "metrics_polling_interval": "metricsPollingInterval",
        "resource_groups": "resourceGroups",
    },
)
class CloudAzureIntegrationsServiceBus:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e3aac7092400f2151e1565226abc2b4f72c40da1c87fd7ac2a6970bf5ff439c7)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
            check_type(argname="argument resource_groups", value=resource_groups, expected_type=type_hints["resource_groups"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval
        if resource_groups is not None:
            self._values["resource_groups"] = resource_groups

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''The data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def resource_groups(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        result = self._values.get("resource_groups")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudAzureIntegrationsServiceBus(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudAzureIntegrationsServiceBusOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsServiceBusOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__651c024040bda26b84809c2dabab7a2c0ca61a272c47636c03b8cacbfa48ca6b)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @jsii.member(jsii_name="resetResourceGroups")
    def reset_resource_groups(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResourceGroups", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="resourceGroupsInput")
    def resource_groups_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "resourceGroupsInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f1afb0664829f433898d4104983fa4da3c795e8b680638c3f9a81651285e328e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="resourceGroups")
    def resource_groups(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "resourceGroups"))

    @resource_groups.setter
    def resource_groups(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__38065bb715df301311d11da9ffefdc52ce68a8d4f668ee390dbda1f999d7f3e7)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "resourceGroups", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudAzureIntegrationsServiceBus]:
        return typing.cast(typing.Optional[CloudAzureIntegrationsServiceBus], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudAzureIntegrationsServiceBus],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b3062be6c59cb17e74eda729cb91af65f91899d4021d216f559d15660fd5e146)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsSql",
    jsii_struct_bases=[],
    name_mapping={
        "metrics_polling_interval": "metricsPollingInterval",
        "resource_groups": "resourceGroups",
    },
)
class CloudAzureIntegrationsSql:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__60f63f3a345e4f35568184c50a4925050ef4bca13e82f32bffa4333d169f8da1)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
            check_type(argname="argument resource_groups", value=resource_groups, expected_type=type_hints["resource_groups"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval
        if resource_groups is not None:
            self._values["resource_groups"] = resource_groups

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''The data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def resource_groups(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        result = self._values.get("resource_groups")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudAzureIntegrationsSql(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsSqlManaged",
    jsii_struct_bases=[],
    name_mapping={
        "metrics_polling_interval": "metricsPollingInterval",
        "resource_groups": "resourceGroups",
    },
)
class CloudAzureIntegrationsSqlManaged:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__666d4143cc2d3bf394fb047aa39816c7d23beecab5928b9da2e35cc3027494a8)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
            check_type(argname="argument resource_groups", value=resource_groups, expected_type=type_hints["resource_groups"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval
        if resource_groups is not None:
            self._values["resource_groups"] = resource_groups

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''The data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def resource_groups(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        result = self._values.get("resource_groups")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudAzureIntegrationsSqlManaged(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudAzureIntegrationsSqlManagedOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsSqlManagedOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__54ead7b27ee24f6cc601fca870817200e87eca39c46f46277222587be9cf51cb)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @jsii.member(jsii_name="resetResourceGroups")
    def reset_resource_groups(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResourceGroups", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="resourceGroupsInput")
    def resource_groups_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "resourceGroupsInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__249f6586ed52513c82fce50a1865f94098d982118ae85744024bfb8f5706e7ae)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="resourceGroups")
    def resource_groups(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "resourceGroups"))

    @resource_groups.setter
    def resource_groups(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f2e8627c88c3ab514308cdddf0e2804e688cb2e81d77e38753edbf7dab3f4107)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "resourceGroups", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudAzureIntegrationsSqlManaged]:
        return typing.cast(typing.Optional[CloudAzureIntegrationsSqlManaged], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudAzureIntegrationsSqlManaged],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7dc07c1a93e39b185810198fab585fbaeab224297a97ed3b11a615ecec98d281)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class CloudAzureIntegrationsSqlOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsSqlOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__aff7574b4151c02221e51640d1ddff3484e6da2cab55c68cb5032db27ae5c52d)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @jsii.member(jsii_name="resetResourceGroups")
    def reset_resource_groups(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResourceGroups", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="resourceGroupsInput")
    def resource_groups_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "resourceGroupsInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__882032c9802ed4b19928f5d999bce691d90deb359a3fe248e512c1d3ed69e548)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="resourceGroups")
    def resource_groups(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "resourceGroups"))

    @resource_groups.setter
    def resource_groups(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__89035171fafea7a0851c6cda392234900abc3d7dde971fab81557ec84b90244d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "resourceGroups", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudAzureIntegrationsSql]:
        return typing.cast(typing.Optional[CloudAzureIntegrationsSql], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(self, value: typing.Optional[CloudAzureIntegrationsSql]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__385bf22977080288c75178ff16b9a65a93fee522c3a8d577bdd352ee374396db)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsStorage",
    jsii_struct_bases=[],
    name_mapping={
        "metrics_polling_interval": "metricsPollingInterval",
        "resource_groups": "resourceGroups",
    },
)
class CloudAzureIntegrationsStorage:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3b506cf923f9643b6d5b949991bac563de1d783645fad3f18f05a6f32ee2e4df)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
            check_type(argname="argument resource_groups", value=resource_groups, expected_type=type_hints["resource_groups"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval
        if resource_groups is not None:
            self._values["resource_groups"] = resource_groups

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''The data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def resource_groups(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        result = self._values.get("resource_groups")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudAzureIntegrationsStorage(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudAzureIntegrationsStorageOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsStorageOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5ac989656f823e3766aa4db68043dd28c87ee0025159b94cb0589a6f9cf6b32f)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @jsii.member(jsii_name="resetResourceGroups")
    def reset_resource_groups(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResourceGroups", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="resourceGroupsInput")
    def resource_groups_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "resourceGroupsInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__637e89e70b3091db36345d6d4fcf3544b8c5e8becd5c96cb6a13e4c261b699d8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="resourceGroups")
    def resource_groups(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "resourceGroups"))

    @resource_groups.setter
    def resource_groups(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__85662c2cf2c1f2a74b494df24c1daae28e6986d299f2ed07220cecd0108a0128)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "resourceGroups", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudAzureIntegrationsStorage]:
        return typing.cast(typing.Optional[CloudAzureIntegrationsStorage], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudAzureIntegrationsStorage],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ecceb035138c7425875281a4f02ad4b9ccb2007f80fd039b8bec1fce23afa342)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsVirtualMachine",
    jsii_struct_bases=[],
    name_mapping={
        "metrics_polling_interval": "metricsPollingInterval",
        "resource_groups": "resourceGroups",
    },
)
class CloudAzureIntegrationsVirtualMachine:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5c6784d5466f7429d5a3f3ab61a893ce5b09d47b73dbee66beafc04a40f0cd72)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
            check_type(argname="argument resource_groups", value=resource_groups, expected_type=type_hints["resource_groups"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval
        if resource_groups is not None:
            self._values["resource_groups"] = resource_groups

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''The data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def resource_groups(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        result = self._values.get("resource_groups")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudAzureIntegrationsVirtualMachine(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudAzureIntegrationsVirtualMachineOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsVirtualMachineOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__96b9b069b55bc1b04b6fab160fbf625806aba37c7e4a0812b9721f7728f0b825)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @jsii.member(jsii_name="resetResourceGroups")
    def reset_resource_groups(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResourceGroups", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="resourceGroupsInput")
    def resource_groups_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "resourceGroupsInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a37c8d28250af75293fe4ef4e01f25722f6ebc092f2202f3d0aede1254b22429)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="resourceGroups")
    def resource_groups(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "resourceGroups"))

    @resource_groups.setter
    def resource_groups(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e306949b51674385803dccd93667f05fb2472213b45770859bec4458e2769783)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "resourceGroups", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudAzureIntegrationsVirtualMachine]:
        return typing.cast(typing.Optional[CloudAzureIntegrationsVirtualMachine], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudAzureIntegrationsVirtualMachine],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__29d0d8b6a4a033a36d10c73e23494c429273b558f5890a03f706bf3657fd65d2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsVirtualNetworks",
    jsii_struct_bases=[],
    name_mapping={
        "metrics_polling_interval": "metricsPollingInterval",
        "resource_groups": "resourceGroups",
    },
)
class CloudAzureIntegrationsVirtualNetworks:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__650bbca5ccbea1951e7e4ef4eeb5566c92411e9f477fd60ddb62560e9b56ab92)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
            check_type(argname="argument resource_groups", value=resource_groups, expected_type=type_hints["resource_groups"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval
        if resource_groups is not None:
            self._values["resource_groups"] = resource_groups

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''The data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def resource_groups(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        result = self._values.get("resource_groups")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudAzureIntegrationsVirtualNetworks(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudAzureIntegrationsVirtualNetworksOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsVirtualNetworksOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b6321e33e6d8cb8423a496f9fd9d7528749879ff7d0cb3236c6cdd4684ab8741)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @jsii.member(jsii_name="resetResourceGroups")
    def reset_resource_groups(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResourceGroups", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="resourceGroupsInput")
    def resource_groups_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "resourceGroupsInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e3c79db99ccd28beddc3de6feb9ff5da0af222c5095170334df49d04afd49726)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="resourceGroups")
    def resource_groups(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "resourceGroups"))

    @resource_groups.setter
    def resource_groups(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ef77a18206f119e59f1a4740bb1b51e562149b94a63b030b9e50cdccb56cc2f7)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "resourceGroups", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudAzureIntegrationsVirtualNetworks]:
        return typing.cast(typing.Optional[CloudAzureIntegrationsVirtualNetworks], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudAzureIntegrationsVirtualNetworks],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2cae43b2749e43d0a9b05dc03953b44d42e2d35bbfe8310b33fb386c3b3cdc6e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsVms",
    jsii_struct_bases=[],
    name_mapping={
        "metrics_polling_interval": "metricsPollingInterval",
        "resource_groups": "resourceGroups",
    },
)
class CloudAzureIntegrationsVms:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__37be300443db60f02bd6113db95ce5c724c9e94927bd58994bd9b4c2e0c20820)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
            check_type(argname="argument resource_groups", value=resource_groups, expected_type=type_hints["resource_groups"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval
        if resource_groups is not None:
            self._values["resource_groups"] = resource_groups

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''The data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def resource_groups(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        result = self._values.get("resource_groups")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudAzureIntegrationsVms(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudAzureIntegrationsVmsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsVmsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2fbb02b14598ed0982d5abe74be4125b6f46c492e31411e486a4d726f4531ff1)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @jsii.member(jsii_name="resetResourceGroups")
    def reset_resource_groups(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResourceGroups", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="resourceGroupsInput")
    def resource_groups_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "resourceGroupsInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f2cf8be5af84ee0e34a90f7494554d08b8b68e99862b168801431b49904c8305)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="resourceGroups")
    def resource_groups(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "resourceGroups"))

    @resource_groups.setter
    def resource_groups(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d7018cb3fede56ae1c854bae8942f23b5b633e9e81c18f6c5e9d60f3a69790a2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "resourceGroups", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudAzureIntegrationsVms]:
        return typing.cast(typing.Optional[CloudAzureIntegrationsVms], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(self, value: typing.Optional[CloudAzureIntegrationsVms]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__43f323b1067d805302f2f0e18ea7e8b96726271e9689116e6715afde3a78a59c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsVpnGateway",
    jsii_struct_bases=[],
    name_mapping={
        "metrics_polling_interval": "metricsPollingInterval",
        "resource_groups": "resourceGroups",
    },
)
class CloudAzureIntegrationsVpnGateway:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
        resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: The data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        :param resource_groups: Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__04b4f5807cfc5b156bf1792e82d825b8b2e4024af394014ca7324bcead7ca383)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
            check_type(argname="argument resource_groups", value=resource_groups, expected_type=type_hints["resource_groups"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval
        if resource_groups is not None:
            self._values["resource_groups"] = resource_groups

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''The data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#metrics_polling_interval CloudAzureIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def resource_groups(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Specify each Resource group associated with the resources that you want to monitor. Filter values are case-sensitive.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_azure_integrations#resource_groups CloudAzureIntegrations#resource_groups}
        '''
        result = self._values.get("resource_groups")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudAzureIntegrationsVpnGateway(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudAzureIntegrationsVpnGatewayOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudAzureIntegrations.CloudAzureIntegrationsVpnGatewayOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__49ea9a328fef13e943d04080ab674c6d025a6f57830e9301921eb0de4c382be7)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @jsii.member(jsii_name="resetResourceGroups")
    def reset_resource_groups(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResourceGroups", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="resourceGroupsInput")
    def resource_groups_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "resourceGroupsInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9af4a2de28f7628428f5ad3d4d448fa459b524b1bc32d5e69465c3383c21e944)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="resourceGroups")
    def resource_groups(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "resourceGroups"))

    @resource_groups.setter
    def resource_groups(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__873866b2eac617299e27029a4fa5b62e05b4b83e5b6141283218edf99667349c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "resourceGroups", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudAzureIntegrationsVpnGateway]:
        return typing.cast(typing.Optional[CloudAzureIntegrationsVpnGateway], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudAzureIntegrationsVpnGateway],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5962256e8bd3739dc087520875fbb3b61097b4af38a52aa3fec2e6a641fb68d3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


__all__ = [
    "CloudAzureIntegrations",
    "CloudAzureIntegrationsApiManagement",
    "CloudAzureIntegrationsApiManagementOutputReference",
    "CloudAzureIntegrationsAppGateway",
    "CloudAzureIntegrationsAppGatewayOutputReference",
    "CloudAzureIntegrationsAppService",
    "CloudAzureIntegrationsAppServiceOutputReference",
    "CloudAzureIntegrationsAutoDiscovery",
    "CloudAzureIntegrationsAutoDiscoveryOutputReference",
    "CloudAzureIntegrationsConfig",
    "CloudAzureIntegrationsContainers",
    "CloudAzureIntegrationsContainersOutputReference",
    "CloudAzureIntegrationsCosmosDb",
    "CloudAzureIntegrationsCosmosDbOutputReference",
    "CloudAzureIntegrationsCostManagement",
    "CloudAzureIntegrationsCostManagementOutputReference",
    "CloudAzureIntegrationsDataFactory",
    "CloudAzureIntegrationsDataFactoryOutputReference",
    "CloudAzureIntegrationsEventHub",
    "CloudAzureIntegrationsEventHubOutputReference",
    "CloudAzureIntegrationsExpressRoute",
    "CloudAzureIntegrationsExpressRouteOutputReference",
    "CloudAzureIntegrationsFirewalls",
    "CloudAzureIntegrationsFirewallsOutputReference",
    "CloudAzureIntegrationsFrontDoor",
    "CloudAzureIntegrationsFrontDoorOutputReference",
    "CloudAzureIntegrationsFunctions",
    "CloudAzureIntegrationsFunctionsOutputReference",
    "CloudAzureIntegrationsKeyVault",
    "CloudAzureIntegrationsKeyVaultOutputReference",
    "CloudAzureIntegrationsLoadBalancer",
    "CloudAzureIntegrationsLoadBalancerOutputReference",
    "CloudAzureIntegrationsLogicApps",
    "CloudAzureIntegrationsLogicAppsOutputReference",
    "CloudAzureIntegrationsMachineLearning",
    "CloudAzureIntegrationsMachineLearningOutputReference",
    "CloudAzureIntegrationsMariaDb",
    "CloudAzureIntegrationsMariaDbOutputReference",
    "CloudAzureIntegrationsMonitor",
    "CloudAzureIntegrationsMonitorOutputReference",
    "CloudAzureIntegrationsMysql",
    "CloudAzureIntegrationsMysqlFlexible",
    "CloudAzureIntegrationsMysqlFlexibleOutputReference",
    "CloudAzureIntegrationsMysqlOutputReference",
    "CloudAzureIntegrationsPostgresql",
    "CloudAzureIntegrationsPostgresqlFlexible",
    "CloudAzureIntegrationsPostgresqlFlexibleOutputReference",
    "CloudAzureIntegrationsPostgresqlOutputReference",
    "CloudAzureIntegrationsPowerBiDedicated",
    "CloudAzureIntegrationsPowerBiDedicatedOutputReference",
    "CloudAzureIntegrationsRedisCache",
    "CloudAzureIntegrationsRedisCacheOutputReference",
    "CloudAzureIntegrationsServiceBus",
    "CloudAzureIntegrationsServiceBusOutputReference",
    "CloudAzureIntegrationsSql",
    "CloudAzureIntegrationsSqlManaged",
    "CloudAzureIntegrationsSqlManagedOutputReference",
    "CloudAzureIntegrationsSqlOutputReference",
    "CloudAzureIntegrationsStorage",
    "CloudAzureIntegrationsStorageOutputReference",
    "CloudAzureIntegrationsVirtualMachine",
    "CloudAzureIntegrationsVirtualMachineOutputReference",
    "CloudAzureIntegrationsVirtualNetworks",
    "CloudAzureIntegrationsVirtualNetworksOutputReference",
    "CloudAzureIntegrationsVms",
    "CloudAzureIntegrationsVmsOutputReference",
    "CloudAzureIntegrationsVpnGateway",
    "CloudAzureIntegrationsVpnGatewayOutputReference",
]

publication.publish()

def _typecheckingstub__fa1c16ddacdfc4e867337420a229a3d3ef587a8bd4ef090f9d7c96767a5bb6e7(
    scope: _constructs_77d1e7e8.Construct,
    id_: builtins.str,
    *,
    linked_account_id: jsii.Number,
    account_id: typing.Optional[jsii.Number] = None,
    api_management: typing.Optional[typing.Union[CloudAzureIntegrationsApiManagement, typing.Dict[builtins.str, typing.Any]]] = None,
    app_gateway: typing.Optional[typing.Union[CloudAzureIntegrationsAppGateway, typing.Dict[builtins.str, typing.Any]]] = None,
    app_service: typing.Optional[typing.Union[CloudAzureIntegrationsAppService, typing.Dict[builtins.str, typing.Any]]] = None,
    auto_discovery: typing.Optional[typing.Union[CloudAzureIntegrationsAutoDiscovery, typing.Dict[builtins.str, typing.Any]]] = None,
    containers: typing.Optional[typing.Union[CloudAzureIntegrationsContainers, typing.Dict[builtins.str, typing.Any]]] = None,
    cosmos_db: typing.Optional[typing.Union[CloudAzureIntegrationsCosmosDb, typing.Dict[builtins.str, typing.Any]]] = None,
    cost_management: typing.Optional[typing.Union[CloudAzureIntegrationsCostManagement, typing.Dict[builtins.str, typing.Any]]] = None,
    data_factory: typing.Optional[typing.Union[CloudAzureIntegrationsDataFactory, typing.Dict[builtins.str, typing.Any]]] = None,
    event_hub: typing.Optional[typing.Union[CloudAzureIntegrationsEventHub, typing.Dict[builtins.str, typing.Any]]] = None,
    express_route: typing.Optional[typing.Union[CloudAzureIntegrationsExpressRoute, typing.Dict[builtins.str, typing.Any]]] = None,
    firewalls: typing.Optional[typing.Union[CloudAzureIntegrationsFirewalls, typing.Dict[builtins.str, typing.Any]]] = None,
    front_door: typing.Optional[typing.Union[CloudAzureIntegrationsFrontDoor, typing.Dict[builtins.str, typing.Any]]] = None,
    functions: typing.Optional[typing.Union[CloudAzureIntegrationsFunctions, typing.Dict[builtins.str, typing.Any]]] = None,
    id: typing.Optional[builtins.str] = None,
    key_vault: typing.Optional[typing.Union[CloudAzureIntegrationsKeyVault, typing.Dict[builtins.str, typing.Any]]] = None,
    load_balancer: typing.Optional[typing.Union[CloudAzureIntegrationsLoadBalancer, typing.Dict[builtins.str, typing.Any]]] = None,
    logic_apps: typing.Optional[typing.Union[CloudAzureIntegrationsLogicApps, typing.Dict[builtins.str, typing.Any]]] = None,
    machine_learning: typing.Optional[typing.Union[CloudAzureIntegrationsMachineLearning, typing.Dict[builtins.str, typing.Any]]] = None,
    maria_db: typing.Optional[typing.Union[CloudAzureIntegrationsMariaDb, typing.Dict[builtins.str, typing.Any]]] = None,
    monitor: typing.Optional[typing.Union[CloudAzureIntegrationsMonitor, typing.Dict[builtins.str, typing.Any]]] = None,
    mysql: typing.Optional[typing.Union[CloudAzureIntegrationsMysql, typing.Dict[builtins.str, typing.Any]]] = None,
    mysql_flexible: typing.Optional[typing.Union[CloudAzureIntegrationsMysqlFlexible, typing.Dict[builtins.str, typing.Any]]] = None,
    postgresql: typing.Optional[typing.Union[CloudAzureIntegrationsPostgresql, typing.Dict[builtins.str, typing.Any]]] = None,
    postgresql_flexible: typing.Optional[typing.Union[CloudAzureIntegrationsPostgresqlFlexible, typing.Dict[builtins.str, typing.Any]]] = None,
    power_bi_dedicated: typing.Optional[typing.Union[CloudAzureIntegrationsPowerBiDedicated, typing.Dict[builtins.str, typing.Any]]] = None,
    redis_cache: typing.Optional[typing.Union[CloudAzureIntegrationsRedisCache, typing.Dict[builtins.str, typing.Any]]] = None,
    service_bus: typing.Optional[typing.Union[CloudAzureIntegrationsServiceBus, typing.Dict[builtins.str, typing.Any]]] = None,
    sql: typing.Optional[typing.Union[CloudAzureIntegrationsSql, typing.Dict[builtins.str, typing.Any]]] = None,
    sql_managed: typing.Optional[typing.Union[CloudAzureIntegrationsSqlManaged, typing.Dict[builtins.str, typing.Any]]] = None,
    storage: typing.Optional[typing.Union[CloudAzureIntegrationsStorage, typing.Dict[builtins.str, typing.Any]]] = None,
    virtual_machine: typing.Optional[typing.Union[CloudAzureIntegrationsVirtualMachine, typing.Dict[builtins.str, typing.Any]]] = None,
    virtual_networks: typing.Optional[typing.Union[CloudAzureIntegrationsVirtualNetworks, typing.Dict[builtins.str, typing.Any]]] = None,
    vms: typing.Optional[typing.Union[CloudAzureIntegrationsVms, typing.Dict[builtins.str, typing.Any]]] = None,
    vpn_gateway: typing.Optional[typing.Union[CloudAzureIntegrationsVpnGateway, typing.Dict[builtins.str, typing.Any]]] = None,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4eb92b80c10d8681166269e03a2aa5feec0929a1fb345c30838d86f6d8acd4e2(
    scope: _constructs_77d1e7e8.Construct,
    import_to_id: builtins.str,
    import_from_id: builtins.str,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6958cffc63ece4b9724bc400fe5db593eea13170610ce7cf4e212d5171aab1f2(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c7eeb986e96695083d56b407050b7785423d9da01da84d3eceedc7c0ad6837ce(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f6c5b25d6613fd23519c375c58616d6f3ab22b00cf183505de7075b1cd4b30d2(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__90788633a50eb5bf71958700bc6aa4b7840b80affcc1fd757aee2060e740732a(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
    resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1093e851e8ea30f551c4fb762ff4360a5760ae0f5aa32aa9ba140716291b4bf8(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ed3f608b50668d72aa9c7593b094bcd974e6c8adcda527e207c944bff7bfd532(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d89c9549882c07f17b0b1ad73949ac8859222dec1ddf25cd44ac241caac7adf0(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__18c5b8ca08b92cf9a85f541ee12e3f8312b1467435734f5c49db94c21375a8e1(
    value: typing.Optional[CloudAzureIntegrationsApiManagement],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e0cb57de35c742c3508fe01501ca35caed50267f5ce3bf94ccfc7aba84cb3e7c(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
    resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__70ddab697be7a7d9d05b419989c61cc0b9d62c84564bb24c4548440ca86f81a2(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__92e230b607c7128a8c9f1cfe30763ab007a588ca7701f997606755df08a9d158(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__95c72b935ef77ef8da220e49d082fef3e510a8018547456876696afb637bb236(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c80f786ec5f5f693e3386bf356356c987dd431e61afa33fb6e93bb26000e9a03(
    value: typing.Optional[CloudAzureIntegrationsAppGateway],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b3f5a9b68fdc7ba057642cdbfe12d21bb6b9559b51e6cddfdb23e5f58f147510(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
    resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dd5d9656a8721590834678a5cc1d0312ac34c42391397806f04bc20e93fb365a(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d706d411f163d543df6dfdcdc063bba1b33a81b355511a83c6e361e2338f83d7(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__67a8f5c170c8d527d26ecc9f7e7e5e43ee570fdf3f4bb7ac21534b72618c0450(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__372bc59c78eb8bbfa89cac9c6c8665a864be79a73baf69a1bee206b6e730fa31(
    value: typing.Optional[CloudAzureIntegrationsAppService],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6dbd011eb7d8d77033dfb5b279e6951a329cd3f5e8e36bb4baaa2fece63e8b4c(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
    resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__18b12b15bb7c673692801b22a5b3a8480cae5f61d6951f26a57bccc7d981b7cd(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9bdf5b8ab024c266d6c844a6c3a81930e5b92cb831d5449066951774ba9c3873(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__500da98d788bdcd122a60d7697b0e0ae0ab7f642ee018281ec4cfacbf34d5cd7(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5f394e8eaf92208be6b3d8cc2bfb27f967177e15213f06d26495a61409e16ee9(
    value: typing.Optional[CloudAzureIntegrationsAutoDiscovery],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__13ee2fa476895d6263cfb79e1ae2a10a954506372138d7384bc3536db760b713(
    *,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    linked_account_id: jsii.Number,
    account_id: typing.Optional[jsii.Number] = None,
    api_management: typing.Optional[typing.Union[CloudAzureIntegrationsApiManagement, typing.Dict[builtins.str, typing.Any]]] = None,
    app_gateway: typing.Optional[typing.Union[CloudAzureIntegrationsAppGateway, typing.Dict[builtins.str, typing.Any]]] = None,
    app_service: typing.Optional[typing.Union[CloudAzureIntegrationsAppService, typing.Dict[builtins.str, typing.Any]]] = None,
    auto_discovery: typing.Optional[typing.Union[CloudAzureIntegrationsAutoDiscovery, typing.Dict[builtins.str, typing.Any]]] = None,
    containers: typing.Optional[typing.Union[CloudAzureIntegrationsContainers, typing.Dict[builtins.str, typing.Any]]] = None,
    cosmos_db: typing.Optional[typing.Union[CloudAzureIntegrationsCosmosDb, typing.Dict[builtins.str, typing.Any]]] = None,
    cost_management: typing.Optional[typing.Union[CloudAzureIntegrationsCostManagement, typing.Dict[builtins.str, typing.Any]]] = None,
    data_factory: typing.Optional[typing.Union[CloudAzureIntegrationsDataFactory, typing.Dict[builtins.str, typing.Any]]] = None,
    event_hub: typing.Optional[typing.Union[CloudAzureIntegrationsEventHub, typing.Dict[builtins.str, typing.Any]]] = None,
    express_route: typing.Optional[typing.Union[CloudAzureIntegrationsExpressRoute, typing.Dict[builtins.str, typing.Any]]] = None,
    firewalls: typing.Optional[typing.Union[CloudAzureIntegrationsFirewalls, typing.Dict[builtins.str, typing.Any]]] = None,
    front_door: typing.Optional[typing.Union[CloudAzureIntegrationsFrontDoor, typing.Dict[builtins.str, typing.Any]]] = None,
    functions: typing.Optional[typing.Union[CloudAzureIntegrationsFunctions, typing.Dict[builtins.str, typing.Any]]] = None,
    id: typing.Optional[builtins.str] = None,
    key_vault: typing.Optional[typing.Union[CloudAzureIntegrationsKeyVault, typing.Dict[builtins.str, typing.Any]]] = None,
    load_balancer: typing.Optional[typing.Union[CloudAzureIntegrationsLoadBalancer, typing.Dict[builtins.str, typing.Any]]] = None,
    logic_apps: typing.Optional[typing.Union[CloudAzureIntegrationsLogicApps, typing.Dict[builtins.str, typing.Any]]] = None,
    machine_learning: typing.Optional[typing.Union[CloudAzureIntegrationsMachineLearning, typing.Dict[builtins.str, typing.Any]]] = None,
    maria_db: typing.Optional[typing.Union[CloudAzureIntegrationsMariaDb, typing.Dict[builtins.str, typing.Any]]] = None,
    monitor: typing.Optional[typing.Union[CloudAzureIntegrationsMonitor, typing.Dict[builtins.str, typing.Any]]] = None,
    mysql: typing.Optional[typing.Union[CloudAzureIntegrationsMysql, typing.Dict[builtins.str, typing.Any]]] = None,
    mysql_flexible: typing.Optional[typing.Union[CloudAzureIntegrationsMysqlFlexible, typing.Dict[builtins.str, typing.Any]]] = None,
    postgresql: typing.Optional[typing.Union[CloudAzureIntegrationsPostgresql, typing.Dict[builtins.str, typing.Any]]] = None,
    postgresql_flexible: typing.Optional[typing.Union[CloudAzureIntegrationsPostgresqlFlexible, typing.Dict[builtins.str, typing.Any]]] = None,
    power_bi_dedicated: typing.Optional[typing.Union[CloudAzureIntegrationsPowerBiDedicated, typing.Dict[builtins.str, typing.Any]]] = None,
    redis_cache: typing.Optional[typing.Union[CloudAzureIntegrationsRedisCache, typing.Dict[builtins.str, typing.Any]]] = None,
    service_bus: typing.Optional[typing.Union[CloudAzureIntegrationsServiceBus, typing.Dict[builtins.str, typing.Any]]] = None,
    sql: typing.Optional[typing.Union[CloudAzureIntegrationsSql, typing.Dict[builtins.str, typing.Any]]] = None,
    sql_managed: typing.Optional[typing.Union[CloudAzureIntegrationsSqlManaged, typing.Dict[builtins.str, typing.Any]]] = None,
    storage: typing.Optional[typing.Union[CloudAzureIntegrationsStorage, typing.Dict[builtins.str, typing.Any]]] = None,
    virtual_machine: typing.Optional[typing.Union[CloudAzureIntegrationsVirtualMachine, typing.Dict[builtins.str, typing.Any]]] = None,
    virtual_networks: typing.Optional[typing.Union[CloudAzureIntegrationsVirtualNetworks, typing.Dict[builtins.str, typing.Any]]] = None,
    vms: typing.Optional[typing.Union[CloudAzureIntegrationsVms, typing.Dict[builtins.str, typing.Any]]] = None,
    vpn_gateway: typing.Optional[typing.Union[CloudAzureIntegrationsVpnGateway, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cf450332e153c6c577c8e60ba02a0932652011337e4ec967f85a95b212daf17d(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
    resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2f9eb7eee0b268abcd8f0f82b0801a042e233f47495565a567628ea6cd41f994(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5692206aa258f36dba8e8e8fcc635abc8c6e406f12881b8b77129b05eb19cd19(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7470f8140f0fe9cc791c4066a902ccf612e89b96436070c93a1fc3efb25649b2(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f5a0aa1859f86c70d9da30cd586278cc80104541e1cfd941b4601661bc6e160f(
    value: typing.Optional[CloudAzureIntegrationsContainers],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e5387d1fae751015c396fa30465f8072a546b633411f46b0de0f95788e35fd9f(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
    resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c04891dc81464d3bf5af83225d61fa174e1bd48fe7cd5658c9368c12dd07b0e8(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0a6b9901c40e7a3493846f6b9d39287acb7f877b925911c6f84e5f71b14a9c50(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9514f6770e4d642da2d878ece2f27e8ca571151f86356a8363044627015ce6e8(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__db5282d2cc9482cc965ca9f4ee203682f63851101db4c2bacb724dbd03935511(
    value: typing.Optional[CloudAzureIntegrationsCosmosDb],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ff20aa41ceb7c437a074cdfd8e84b2105562eeadd2c52e8a8d5ab86d1bda1c04(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
    tag_keys: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a5757dbc963b54c5b6f2aec69e380697f87ad0d894bb2a2deb4ff38fd8ff5d1b(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__721a967a67544a56dd6baab8f2953a785e1c1e00ab82613527a4573f0e33bf8e(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__85860f0af79cdcc6889320167c31d214a3a2bb1be9cd2966263929de53dcc71f(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9076299edc07bee6cc7b689a17fd34d28d0b40fd8fc700484035bf68697352b0(
    value: typing.Optional[CloudAzureIntegrationsCostManagement],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cbb741771987085085e5603019836c85d94d5b558832c69cf18ceca0a7d59c55(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
    resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e792134c5d07e06ba9063d1da0b15249e9214809806a8392a87758e22842bb24(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ec4e00d63d58952a5e0e8d538791eb2068bf01307ca532bffc1ff9a0b8401de0(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d8be53212fbbfad8c2ff10f1e6a6099edc0b205eeaf2e83d635d85ad095af2f9(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d1c6a3e442add69cce0bc19c79ccb122d5e749f4f6ad4c3143fa6a0da2ea4228(
    value: typing.Optional[CloudAzureIntegrationsDataFactory],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c93af68616d672c0f7df34b7797e8fa7ef2f59f2aed6b5178a9b28edd62dee3b(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
    resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5d7e846943539b05784ebf05ac20e2bd2e06126668e7299214d5e19bfdf06c35(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__10a3190277db50d6c8ef7b5eae48ade16a5e679e51b8a36f50db064ab41f910f(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c2026eb074526e7a27d8a1791baa0a5c854e98addf9792a160aff960f686f56e(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2e37e91814da95e5bd401bf64842a684b34468e0c512befc7e9f1ba58d4bce7e(
    value: typing.Optional[CloudAzureIntegrationsEventHub],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9a46d4b82da78271744d384be44fa7bbafb2c1ca25cc7d0472a3e2aacc8b1917(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
    resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b573c13f720b2156148cadff991c0a06ff5b03e0eb8d1dca22fe8783e79df6ba(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8b5a8412368dc1a7da93695e2b8c2e3598f8a0b1824d7a282d9c9b966773eabf(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6ad6fe50b65e5767d87208f8eb4f9f8a6afbd1cf3c8c82ba56de81792d8de54e(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2a22bf753a9c79382a0e4bace51fc1876e6124b9400ac1496c88df41997f0ab1(
    value: typing.Optional[CloudAzureIntegrationsExpressRoute],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c34908c20f266c29e6557ed65cee6969f3111c7f2345e840f452dfe912e3e69b(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
    resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e5c9a387e4118d302e3de059489f2f3fb117eb91bea41a40e3c0ababe1529e16(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3229a82f6a066d8925f858be60ce1b601715cee59e54a80f06fe5ee096a9eb49(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d18a5d6a118b7ceae66b8f7673cf274a28748f562d7fe746ae13732924757dad(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fca4fbf0977ef60bc37ea25710e4bf986225c086a95a16abbe775b0f4a59077a(
    value: typing.Optional[CloudAzureIntegrationsFirewalls],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2867efacd48908e2b0f19b960188417cf6e0f982e89531f23c7530ad1ad10d08(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
    resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9b7230a3ded9e0000e4dbe024c4a5a6fd6a815c68681ea047c51862571163d61(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f8be3b0da87229b5cb8d745de75d39a140ac54a062e07d662982efbfa4c27824(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d6572fb8e3538dcb610b63b1b74351eb16d4b8ee4b86bab2b0e17d0be4a4bf22(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3eb2472079a62c15f0c5bd701de63c0e9a4a7daacaa47e2b6fdc77f551a18c3d(
    value: typing.Optional[CloudAzureIntegrationsFrontDoor],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b7fa9a7cea7145dbbe4b6aef60bcdf07e7c242760b96ed2fb6b7b60c844e9886(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
    resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1370771f7dbc8f42aaa78a7b6ad3e4880551d2da07a7c1e35398fd3db8bc101c(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fbb6b2cde2de9acd7dddeb50d732ab4bb9eaa2025a4171f30b5e0e4bfbb7ab1c(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__236eb60ac7c3324ed30677830dcd812177e238a29a844289a8c8802070a83ac6(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__163e65269a52ab99515e514b6aa22c1f922bcdd5e89252892a7ea36154641b60(
    value: typing.Optional[CloudAzureIntegrationsFunctions],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__85a02622620a904bf92cb1a78804be557ae2053a3f16bcd6b3aa8b0131a6aece(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
    resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d6ac8376a4f19f1cabb25d22af9f67074cb5cd59a846e36f35b51162395082fc(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8973d3f9933706cbe378b561264a05752dbcb83d23197f2071bd85c0bb4462db(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ed8f5f45641b09202e8e309698d017d0633787f15efac88771c9adc86b2280f8(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1c9ae8f9134bb8f1bf3599c009b2fe22c813cce78d2210a6e4d834da7f48f6a7(
    value: typing.Optional[CloudAzureIntegrationsKeyVault],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c74f65b062d1c45cf8f17eca8980683c9f7c10e41ec7eb7b19ef56ff368ce267(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
    resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a200845db3a559880a75bbaba89328a449db109b0cc1926b1b2c0fd02106f561(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7f2ae95bb3e7238607caed88ec1921fff5e12a879421517d7392d1600c710cce(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__33146af7ea9fb2e3bf4d013c4a2bb60b65d222e4c0ad752527ca7c0390e1f9f4(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__710dfbc8727eb2daf941ff03b2ee97de13192948db01114b87f15cc81e2ed717(
    value: typing.Optional[CloudAzureIntegrationsLoadBalancer],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5f04393b0ff24e1bea35b4b0bfba022a98410c8f84f353048cf6b8a937d496a8(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
    resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1806c466a6908ab61a78d8dd7b0cfca83e5c2cb271b01e2190af01eabac0079b(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__17b803f5eeec789fb6734a816d21ec1f3eeb6388bcab445960a9efbc65af9a66(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d3c4dfafbc950029ba140945a944fb4ff5f2dbe410a7c6c9208287a47f917319(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__33ce535e4b071ddffed40912a79f60e4a308384b835ac93aebe1c6786099ed01(
    value: typing.Optional[CloudAzureIntegrationsLogicApps],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2c1f2289768d89825f6bb53409cb963aaafa08fd49f413a7953bd634342cceeb(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
    resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b540a17a925ab11a2a584ce4b591c7f75ad20e80fab3f358acbf8786e2c12314(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9db70352f1cc80d580f2e855ff2e426de4df9c5840cb95b7831ecdf98bb8a22a(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cc7c8b630b76c8ce241322b412b430121d1fd93ab22b9b37d9d2e7a07f6c1730(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3ec946dcadcbafe599f68e746c4602fb12b7224bc7d9c1a6e48c28a94820d9c3(
    value: typing.Optional[CloudAzureIntegrationsMachineLearning],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__908818a94981e64e1b9e0c64de7cc7c4af8efdcf119b3016cd5d07ee7afd92fd(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
    resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__89539dcdbb7d23effaa170c83c218ca3f38f692adeaddfe0e4d869c1a9534a8b(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0364ce608003ea0d6a748d587e128e98d98470cbd7b8273deb1d62672100666e(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d91cc43de552dab06bdcc7f537095151dbcab91e9a2f301af1b9cb80efc8501a(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__567ef7803384794f4ada99d401372942e778e13c9e74f785e5b26fe2d1f14808(
    value: typing.Optional[CloudAzureIntegrationsMariaDb],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7cdc65d90751bd10e293a9b6758811939538b9f111eaae5d289561fc8d3d77af(
    *,
    enabled: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    exclude_tags: typing.Optional[typing.Sequence[builtins.str]] = None,
    include_tags: typing.Optional[typing.Sequence[builtins.str]] = None,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
    resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    resource_types: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d66ed4b98d7e68075bd769ac29af72f1343528b3b58df5e931e0bc484725d68b(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bf7699741b3b1fdcc2105441e8fd6870bfd973a7867926ce5a6abce17b4b07ce(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__37cbd1a354b3a57be9a8c71ff84d3f01162d1c33c2cde9d2da02f994a5676b01(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fdbe81faaa69b12970113db0ebfa7ccd2b3ab9dfef5ec124f0ea98edc805cce0(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__04f2f0c14459a59e3db2a7f5c55a7fc41ece7603933dd59875d44b67e6ed9535(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1465b2d515ea556913f02979f20b2f4df81fc0b7b0b722fe72248fbae9bad909(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b6815fc6eba3a603160d59005b46f8251eb9f5458b66a3cbc86c69bef73345d6(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7e18fe11d98b6a4ac84694fdf3fc80c46d7f1e0fb7bb9adc93299b0805fcb651(
    value: typing.Optional[CloudAzureIntegrationsMonitor],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__442e0cc997bcbe3da8f56d3fb7982600907977b0bf2b91fc9181cb4eac411af6(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
    resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__70e493d011b8eb5d23908259c8cc332c615590a0474ddf33a412771cd77137d8(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
    resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__514a5f2fe06e7f7b6c5c3d170a83402cce4c79bd7f7275b7381b566d3f42a8c9(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__397c7c64b2a6a756d7f7833f4c58c9c78347f60ce6c2eb5ebe617c92ce0568ca(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4a9a5c621ab02fc7962b53ef33c24944dbc3bcc882ff83338835b8c81ce25963(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__34fa2a0e3a4b9468d521ae4c9dfc1851b90293d1fd9690bc4b372d39d1b36288(
    value: typing.Optional[CloudAzureIntegrationsMysqlFlexible],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__737643009f66712be580e072f496fc1cdb4541dd05c08429b6f1fd2527df1221(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4fbcaed02336e98a7763a8a61e02aafc1ce9f063697703145331f83695dc44a5(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ecf1bba189b95f8be242044acdcce950d3463396e1f84a94dbcd6660b95b6334(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fe1d9dee05c1605757f944bb7e4391555b3ece6f0eddbc6cc6a77d996db6a387(
    value: typing.Optional[CloudAzureIntegrationsMysql],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__56baa5b4dc3fef377114ec06f65fa7777273b827983ef114998735c684132696(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
    resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__57a003182e8f0464222f11c684dce9d392e84efee125f1ef165c6b001d544fee(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
    resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7e5aefff9be9f325d733af726a0c117a08fc529eb45840884a40cda378189b59(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__acb95db99753993d679a39e719724de725e3b99b1a1a10cf3deddde125539d4c(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b3ca602e46bc4a242eab0f5732d8b1deafbc6482f90fc8ab4735c670227a6bfd(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cd50a1ba123739f0be59aa0e7d32f69cd77c1eabf202cfbc9dd99ded77e48ab6(
    value: typing.Optional[CloudAzureIntegrationsPostgresqlFlexible],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__91dd6d1ab1c3c9ff6b080b7374338eabd274e56be40f895f1b5c804c81652a5b(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__109e3c37d3e41c5ddc3247da5d3c7cbcde6a5a4a2d0d868756ea04dec7736102(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ffa8ee0f6fce2014cd1eb0b39f27ccc25552255f1d5ad18cd62ece78d1eeda6b(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7fd3164af9890d9deb08aca469323d1a8bdbd26a6710d524e9a275ccd17e8f9d(
    value: typing.Optional[CloudAzureIntegrationsPostgresql],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__16933a0cde7609bb2d08dd9e908352e3aae22aa004bdae7092a931d40a899d96(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
    resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2c2a156b3f5514b2a31b7fd022e2c6b6a99bc728e59cffd2fa3fd5a39704b4cd(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4b7d757f69b023385317f4c61c0f90416b5ea8ef7b7e03d62d15becaf025522c(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__48c5b8980bfa9af554c0efefacfda35c4f561d0242f52d27fc3f3d44f6e5da39(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6bbcae35322bc57017b38b0c6f1548c4ecec59fe5179db433c2011f7577ccbb2(
    value: typing.Optional[CloudAzureIntegrationsPowerBiDedicated],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7895c51ab3aa2965d3b322c41a134828e84320d470d648e4b627183466e7110b(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
    resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e01494200d1ba2ddfb89e1338f9066bc982f6f9ce00d58acde5b8fcab906db57(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__79f90ac4a98ca985defd083cae7c26b81e2197086664ac494d5616292c1438a1(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__751146aa32087a88c393743bd5f640d6d06ec0da0387b1d2016bfbbe29a2ce43(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__db98a5865cedfa29f5de0841a8b4e77a6408728352dd63a885cf121bf48df838(
    value: typing.Optional[CloudAzureIntegrationsRedisCache],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e3aac7092400f2151e1565226abc2b4f72c40da1c87fd7ac2a6970bf5ff439c7(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
    resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__651c024040bda26b84809c2dabab7a2c0ca61a272c47636c03b8cacbfa48ca6b(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f1afb0664829f433898d4104983fa4da3c795e8b680638c3f9a81651285e328e(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__38065bb715df301311d11da9ffefdc52ce68a8d4f668ee390dbda1f999d7f3e7(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b3062be6c59cb17e74eda729cb91af65f91899d4021d216f559d15660fd5e146(
    value: typing.Optional[CloudAzureIntegrationsServiceBus],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__60f63f3a345e4f35568184c50a4925050ef4bca13e82f32bffa4333d169f8da1(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
    resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__666d4143cc2d3bf394fb047aa39816c7d23beecab5928b9da2e35cc3027494a8(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
    resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__54ead7b27ee24f6cc601fca870817200e87eca39c46f46277222587be9cf51cb(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__249f6586ed52513c82fce50a1865f94098d982118ae85744024bfb8f5706e7ae(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f2e8627c88c3ab514308cdddf0e2804e688cb2e81d77e38753edbf7dab3f4107(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7dc07c1a93e39b185810198fab585fbaeab224297a97ed3b11a615ecec98d281(
    value: typing.Optional[CloudAzureIntegrationsSqlManaged],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__aff7574b4151c02221e51640d1ddff3484e6da2cab55c68cb5032db27ae5c52d(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__882032c9802ed4b19928f5d999bce691d90deb359a3fe248e512c1d3ed69e548(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__89035171fafea7a0851c6cda392234900abc3d7dde971fab81557ec84b90244d(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__385bf22977080288c75178ff16b9a65a93fee522c3a8d577bdd352ee374396db(
    value: typing.Optional[CloudAzureIntegrationsSql],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3b506cf923f9643b6d5b949991bac563de1d783645fad3f18f05a6f32ee2e4df(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
    resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5ac989656f823e3766aa4db68043dd28c87ee0025159b94cb0589a6f9cf6b32f(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__637e89e70b3091db36345d6d4fcf3544b8c5e8becd5c96cb6a13e4c261b699d8(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__85662c2cf2c1f2a74b494df24c1daae28e6986d299f2ed07220cecd0108a0128(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ecceb035138c7425875281a4f02ad4b9ccb2007f80fd039b8bec1fce23afa342(
    value: typing.Optional[CloudAzureIntegrationsStorage],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5c6784d5466f7429d5a3f3ab61a893ce5b09d47b73dbee66beafc04a40f0cd72(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
    resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__96b9b069b55bc1b04b6fab160fbf625806aba37c7e4a0812b9721f7728f0b825(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a37c8d28250af75293fe4ef4e01f25722f6ebc092f2202f3d0aede1254b22429(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e306949b51674385803dccd93667f05fb2472213b45770859bec4458e2769783(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__29d0d8b6a4a033a36d10c73e23494c429273b558f5890a03f706bf3657fd65d2(
    value: typing.Optional[CloudAzureIntegrationsVirtualMachine],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__650bbca5ccbea1951e7e4ef4eeb5566c92411e9f477fd60ddb62560e9b56ab92(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
    resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b6321e33e6d8cb8423a496f9fd9d7528749879ff7d0cb3236c6cdd4684ab8741(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e3c79db99ccd28beddc3de6feb9ff5da0af222c5095170334df49d04afd49726(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ef77a18206f119e59f1a4740bb1b51e562149b94a63b030b9e50cdccb56cc2f7(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2cae43b2749e43d0a9b05dc03953b44d42e2d35bbfe8310b33fb386c3b3cdc6e(
    value: typing.Optional[CloudAzureIntegrationsVirtualNetworks],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__37be300443db60f02bd6113db95ce5c724c9e94927bd58994bd9b4c2e0c20820(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
    resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2fbb02b14598ed0982d5abe74be4125b6f46c492e31411e486a4d726f4531ff1(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f2cf8be5af84ee0e34a90f7494554d08b8b68e99862b168801431b49904c8305(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d7018cb3fede56ae1c854bae8942f23b5b633e9e81c18f6c5e9d60f3a69790a2(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__43f323b1067d805302f2f0e18ea7e8b96726271e9689116e6715afde3a78a59c(
    value: typing.Optional[CloudAzureIntegrationsVms],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__04b4f5807cfc5b156bf1792e82d825b8b2e4024af394014ca7324bcead7ca383(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
    resource_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__49ea9a328fef13e943d04080ab674c6d025a6f57830e9301921eb0de4c382be7(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9af4a2de28f7628428f5ad3d4d448fa459b524b1bc32d5e69465c3383c21e944(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__873866b2eac617299e27029a4fa5b62e05b4b83e5b6141283218edf99667349c(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5962256e8bd3739dc087520875fbb3b61097b4af38a52aa3fec2e6a641fb68d3(
    value: typing.Optional[CloudAzureIntegrationsVpnGateway],
) -> None:
    """Type checking stubs"""
    pass
