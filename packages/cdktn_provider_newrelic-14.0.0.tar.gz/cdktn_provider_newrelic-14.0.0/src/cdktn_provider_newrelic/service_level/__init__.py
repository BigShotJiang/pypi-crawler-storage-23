r'''
# `newrelic_service_level`

Refer to the Terraform Registry for docs: [`newrelic_service_level`](https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level).
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import cdktn as _cdktn_78ede62e
import constructs as _constructs_77d1e7e8


class ServiceLevel(
    _cdktn_78ede62e.TerraformResource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.serviceLevel.ServiceLevel",
):
    '''Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level newrelic_service_level}.'''

    def __init__(
        self,
        scope: _constructs_77d1e7e8.Construct,
        id_: builtins.str,
        *,
        events: typing.Union["ServiceLevelEvents", typing.Dict[builtins.str, typing.Any]],
        guid: builtins.str,
        name: builtins.str,
        objective: typing.Union["ServiceLevelObjective", typing.Dict[builtins.str, typing.Any]],
        description: typing.Optional[builtins.str] = None,
        id: typing.Optional[builtins.str] = None,
        connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level newrelic_service_level} Resource.

        :param scope: The scope in which to define this construct.
        :param id_: The scoped construct ID. Must be unique amongst siblings in the same scope
        :param events: events block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#events ServiceLevel#events}
        :param guid: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#guid ServiceLevel#guid}.
        :param name: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#name ServiceLevel#name}.
        :param objective: objective block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#objective ServiceLevel#objective}
        :param description: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#description ServiceLevel#description}.
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#id ServiceLevel#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0f68114bb92cb507c4135d2b5eadbb46fac0c300d3762d63ed74a1060ba57738)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id_", value=id_, expected_type=type_hints["id_"])
        config = ServiceLevelConfig(
            events=events,
            guid=guid,
            name=name,
            objective=objective,
            description=description,
            id=id,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        jsii.create(self.__class__, self, [scope, id_, config])

    @jsii.member(jsii_name="generateConfigForImport")
    @builtins.classmethod
    def generate_config_for_import(
        cls,
        scope: _constructs_77d1e7e8.Construct,
        import_to_id: builtins.str,
        import_from_id: builtins.str,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    ) -> _cdktn_78ede62e.ImportableResource:
        '''Generates CDKTN code for importing a ServiceLevel resource upon running "cdktn plan ".

        :param scope: The scope in which to define this construct.
        :param import_to_id: The construct id used in the generated config for the ServiceLevel to import.
        :param import_from_id: The id of the existing ServiceLevel that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#import import section} in the documentation of this resource for the id to use
        :param provider: ? Optional instance of the provider where the ServiceLevel to import is found.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__61c58c0084d8f33441e5278febb0d3dfb4d65ded2838edefbd960b75fdc376e4)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument import_to_id", value=import_to_id, expected_type=type_hints["import_to_id"])
            check_type(argname="argument import_from_id", value=import_from_id, expected_type=type_hints["import_from_id"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
        return typing.cast(_cdktn_78ede62e.ImportableResource, jsii.sinvoke(cls, "generateConfigForImport", [scope, import_to_id, import_from_id, provider]))

    @jsii.member(jsii_name="putEvents")
    def put_events(
        self,
        *,
        account_id: jsii.Number,
        valid_events: typing.Union["ServiceLevelEventsValidEvents", typing.Dict[builtins.str, typing.Any]],
        bad_events: typing.Optional[typing.Union["ServiceLevelEventsBadEvents", typing.Dict[builtins.str, typing.Any]]] = None,
        good_events: typing.Optional[typing.Union["ServiceLevelEventsGoodEvents", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param account_id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#account_id ServiceLevel#account_id}.
        :param valid_events: valid_events block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#valid_events ServiceLevel#valid_events}
        :param bad_events: bad_events block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#bad_events ServiceLevel#bad_events}
        :param good_events: good_events block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#good_events ServiceLevel#good_events}
        '''
        value = ServiceLevelEvents(
            account_id=account_id,
            valid_events=valid_events,
            bad_events=bad_events,
            good_events=good_events,
        )

        return typing.cast(None, jsii.invoke(self, "putEvents", [value]))

    @jsii.member(jsii_name="putObjective")
    def put_objective(
        self,
        *,
        target: jsii.Number,
        time_window: typing.Union["ServiceLevelObjectiveTimeWindow", typing.Dict[builtins.str, typing.Any]],
        description: typing.Optional[builtins.str] = None,
        name: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param target: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#target ServiceLevel#target}.
        :param time_window: time_window block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#time_window ServiceLevel#time_window}
        :param description: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#description ServiceLevel#description}.
        :param name: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#name ServiceLevel#name}.
        '''
        value = ServiceLevelObjective(
            target=target, time_window=time_window, description=description, name=name
        )

        return typing.cast(None, jsii.invoke(self, "putObjective", [value]))

    @jsii.member(jsii_name="resetDescription")
    def reset_description(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDescription", []))

    @jsii.member(jsii_name="resetId")
    def reset_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetId", []))

    @jsii.member(jsii_name="synthesizeAttributes")
    def _synthesize_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeAttributes", []))

    @jsii.member(jsii_name="synthesizeHclAttributes")
    def _synthesize_hcl_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeHclAttributes", []))

    @jsii.python.classproperty
    @jsii.member(jsii_name="tfResourceType")
    def TF_RESOURCE_TYPE(cls) -> builtins.str:
        return typing.cast(builtins.str, jsii.sget(cls, "tfResourceType"))

    @builtins.property
    @jsii.member(jsii_name="events")
    def events(self) -> "ServiceLevelEventsOutputReference":
        return typing.cast("ServiceLevelEventsOutputReference", jsii.get(self, "events"))

    @builtins.property
    @jsii.member(jsii_name="objective")
    def objective(self) -> "ServiceLevelObjectiveOutputReference":
        return typing.cast("ServiceLevelObjectiveOutputReference", jsii.get(self, "objective"))

    @builtins.property
    @jsii.member(jsii_name="sliGuid")
    def sli_guid(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "sliGuid"))

    @builtins.property
    @jsii.member(jsii_name="sliId")
    def sli_id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "sliId"))

    @builtins.property
    @jsii.member(jsii_name="descriptionInput")
    def description_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "descriptionInput"))

    @builtins.property
    @jsii.member(jsii_name="eventsInput")
    def events_input(self) -> typing.Optional["ServiceLevelEvents"]:
        return typing.cast(typing.Optional["ServiceLevelEvents"], jsii.get(self, "eventsInput"))

    @builtins.property
    @jsii.member(jsii_name="guidInput")
    def guid_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "guidInput"))

    @builtins.property
    @jsii.member(jsii_name="idInput")
    def id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "idInput"))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="objectiveInput")
    def objective_input(self) -> typing.Optional["ServiceLevelObjective"]:
        return typing.cast(typing.Optional["ServiceLevelObjective"], jsii.get(self, "objectiveInput"))

    @builtins.property
    @jsii.member(jsii_name="description")
    def description(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "description"))

    @description.setter
    def description(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2c5a00fc4de58f8b99192bd1fc13091eca70f077f137328194011513aad3566b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "description", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="guid")
    def guid(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "guid"))

    @guid.setter
    def guid(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c2990996fbf12d2dd4bd6c08c5a7353d68415e94c5d85603efa476fe815e48e4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "guid", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @id.setter
    def id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a63132391882f92a98e70a71c9f819441d69e75553d86f10292d2598d0e5d3d8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "id", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9159d3cdfcfe0af7d93292d4512cc64eacc39331dfe0354ca30acb0b19883467)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.serviceLevel.ServiceLevelConfig",
    jsii_struct_bases=[_cdktn_78ede62e.TerraformMetaArguments],
    name_mapping={
        "connection": "connection",
        "count": "count",
        "depends_on": "dependsOn",
        "for_each": "forEach",
        "lifecycle": "lifecycle",
        "provider": "provider",
        "provisioners": "provisioners",
        "events": "events",
        "guid": "guid",
        "name": "name",
        "objective": "objective",
        "description": "description",
        "id": "id",
    },
)
class ServiceLevelConfig(_cdktn_78ede62e.TerraformMetaArguments):
    def __init__(
        self,
        *,
        connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
        events: typing.Union["ServiceLevelEvents", typing.Dict[builtins.str, typing.Any]],
        guid: builtins.str,
        name: builtins.str,
        objective: typing.Union["ServiceLevelObjective", typing.Dict[builtins.str, typing.Any]],
        description: typing.Optional[builtins.str] = None,
        id: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        :param events: events block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#events ServiceLevel#events}
        :param guid: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#guid ServiceLevel#guid}.
        :param name: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#name ServiceLevel#name}.
        :param objective: objective block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#objective ServiceLevel#objective}
        :param description: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#description ServiceLevel#description}.
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#id ServiceLevel#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        '''
        if isinstance(lifecycle, dict):
            lifecycle = _cdktn_78ede62e.TerraformResourceLifecycle(**lifecycle)
        if isinstance(events, dict):
            events = ServiceLevelEvents(**events)
        if isinstance(objective, dict):
            objective = ServiceLevelObjective(**objective)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f678733af0606bef9f6f924149e3e5919d0fccef4ce59015388f381640ae14a2)
            check_type(argname="argument connection", value=connection, expected_type=type_hints["connection"])
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument for_each", value=for_each, expected_type=type_hints["for_each"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
            check_type(argname="argument provisioners", value=provisioners, expected_type=type_hints["provisioners"])
            check_type(argname="argument events", value=events, expected_type=type_hints["events"])
            check_type(argname="argument guid", value=guid, expected_type=type_hints["guid"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument objective", value=objective, expected_type=type_hints["objective"])
            check_type(argname="argument description", value=description, expected_type=type_hints["description"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "events": events,
            "guid": guid,
            "name": name,
            "objective": objective,
        }
        if connection is not None:
            self._values["connection"] = connection
        if count is not None:
            self._values["count"] = count
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if for_each is not None:
            self._values["for_each"] = for_each
        if lifecycle is not None:
            self._values["lifecycle"] = lifecycle
        if provider is not None:
            self._values["provider"] = provider
        if provisioners is not None:
            self._values["provisioners"] = provisioners
        if description is not None:
            self._values["description"] = description
        if id is not None:
            self._values["id"] = id

    @builtins.property
    def connection(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, _cdktn_78ede62e.WinrmProvisionerConnection]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("connection")
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, _cdktn_78ede62e.WinrmProvisionerConnection]], result)

    @builtins.property
    def count(
        self,
    ) -> typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("count")
        return typing.cast(typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]], result)

    @builtins.property
    def depends_on(
        self,
    ) -> typing.Optional[typing.List[_cdktn_78ede62e.ITerraformDependable]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List[_cdktn_78ede62e.ITerraformDependable]], result)

    @builtins.property
    def for_each(self) -> typing.Optional[_cdktn_78ede62e.ITerraformIterator]:
        '''
        :stability: experimental
        '''
        result = self._values.get("for_each")
        return typing.cast(typing.Optional[_cdktn_78ede62e.ITerraformIterator], result)

    @builtins.property
    def lifecycle(self) -> typing.Optional[_cdktn_78ede62e.TerraformResourceLifecycle]:
        '''
        :stability: experimental
        '''
        result = self._values.get("lifecycle")
        return typing.cast(typing.Optional[_cdktn_78ede62e.TerraformResourceLifecycle], result)

    @builtins.property
    def provider(self) -> typing.Optional[_cdktn_78ede62e.TerraformProvider]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provider")
        return typing.cast(typing.Optional[_cdktn_78ede62e.TerraformProvider], result)

    @builtins.property
    def provisioners(
        self,
    ) -> typing.Optional[typing.List[typing.Union[_cdktn_78ede62e.FileProvisioner, _cdktn_78ede62e.LocalExecProvisioner, _cdktn_78ede62e.RemoteExecProvisioner]]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provisioners")
        return typing.cast(typing.Optional[typing.List[typing.Union[_cdktn_78ede62e.FileProvisioner, _cdktn_78ede62e.LocalExecProvisioner, _cdktn_78ede62e.RemoteExecProvisioner]]], result)

    @builtins.property
    def events(self) -> "ServiceLevelEvents":
        '''events block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#events ServiceLevel#events}
        '''
        result = self._values.get("events")
        assert result is not None, "Required property 'events' is missing"
        return typing.cast("ServiceLevelEvents", result)

    @builtins.property
    def guid(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#guid ServiceLevel#guid}.'''
        result = self._values.get("guid")
        assert result is not None, "Required property 'guid' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def name(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#name ServiceLevel#name}.'''
        result = self._values.get("name")
        assert result is not None, "Required property 'name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def objective(self) -> "ServiceLevelObjective":
        '''objective block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#objective ServiceLevel#objective}
        '''
        result = self._values.get("objective")
        assert result is not None, "Required property 'objective' is missing"
        return typing.cast("ServiceLevelObjective", result)

    @builtins.property
    def description(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#description ServiceLevel#description}.'''
        result = self._values.get("description")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def id(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#id ServiceLevel#id}.

        Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        '''
        result = self._values.get("id")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ServiceLevelConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.serviceLevel.ServiceLevelEvents",
    jsii_struct_bases=[],
    name_mapping={
        "account_id": "accountId",
        "valid_events": "validEvents",
        "bad_events": "badEvents",
        "good_events": "goodEvents",
    },
)
class ServiceLevelEvents:
    def __init__(
        self,
        *,
        account_id: jsii.Number,
        valid_events: typing.Union["ServiceLevelEventsValidEvents", typing.Dict[builtins.str, typing.Any]],
        bad_events: typing.Optional[typing.Union["ServiceLevelEventsBadEvents", typing.Dict[builtins.str, typing.Any]]] = None,
        good_events: typing.Optional[typing.Union["ServiceLevelEventsGoodEvents", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param account_id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#account_id ServiceLevel#account_id}.
        :param valid_events: valid_events block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#valid_events ServiceLevel#valid_events}
        :param bad_events: bad_events block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#bad_events ServiceLevel#bad_events}
        :param good_events: good_events block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#good_events ServiceLevel#good_events}
        '''
        if isinstance(valid_events, dict):
            valid_events = ServiceLevelEventsValidEvents(**valid_events)
        if isinstance(bad_events, dict):
            bad_events = ServiceLevelEventsBadEvents(**bad_events)
        if isinstance(good_events, dict):
            good_events = ServiceLevelEventsGoodEvents(**good_events)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8302114798cf13bbbb618e59bea38a6982241b520542b297e1ab913543b62880)
            check_type(argname="argument account_id", value=account_id, expected_type=type_hints["account_id"])
            check_type(argname="argument valid_events", value=valid_events, expected_type=type_hints["valid_events"])
            check_type(argname="argument bad_events", value=bad_events, expected_type=type_hints["bad_events"])
            check_type(argname="argument good_events", value=good_events, expected_type=type_hints["good_events"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "account_id": account_id,
            "valid_events": valid_events,
        }
        if bad_events is not None:
            self._values["bad_events"] = bad_events
        if good_events is not None:
            self._values["good_events"] = good_events

    @builtins.property
    def account_id(self) -> jsii.Number:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#account_id ServiceLevel#account_id}.'''
        result = self._values.get("account_id")
        assert result is not None, "Required property 'account_id' is missing"
        return typing.cast(jsii.Number, result)

    @builtins.property
    def valid_events(self) -> "ServiceLevelEventsValidEvents":
        '''valid_events block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#valid_events ServiceLevel#valid_events}
        '''
        result = self._values.get("valid_events")
        assert result is not None, "Required property 'valid_events' is missing"
        return typing.cast("ServiceLevelEventsValidEvents", result)

    @builtins.property
    def bad_events(self) -> typing.Optional["ServiceLevelEventsBadEvents"]:
        '''bad_events block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#bad_events ServiceLevel#bad_events}
        '''
        result = self._values.get("bad_events")
        return typing.cast(typing.Optional["ServiceLevelEventsBadEvents"], result)

    @builtins.property
    def good_events(self) -> typing.Optional["ServiceLevelEventsGoodEvents"]:
        '''good_events block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#good_events ServiceLevel#good_events}
        '''
        result = self._values.get("good_events")
        return typing.cast(typing.Optional["ServiceLevelEventsGoodEvents"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ServiceLevelEvents(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.serviceLevel.ServiceLevelEventsBadEvents",
    jsii_struct_bases=[],
    name_mapping={"from_": "from", "select": "select", "where": "where"},
)
class ServiceLevelEventsBadEvents:
    def __init__(
        self,
        *,
        from_: builtins.str,
        select: typing.Optional[typing.Union["ServiceLevelEventsBadEventsSelect", typing.Dict[builtins.str, typing.Any]]] = None,
        where: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param from_: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#from ServiceLevel#from}.
        :param select: select block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#select ServiceLevel#select}
        :param where: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#where ServiceLevel#where}.
        '''
        if isinstance(select, dict):
            select = ServiceLevelEventsBadEventsSelect(**select)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__29b8d44ebe63c44068940b22e58befa1a0027d278208be7da373899761f4e42b)
            check_type(argname="argument from_", value=from_, expected_type=type_hints["from_"])
            check_type(argname="argument select", value=select, expected_type=type_hints["select"])
            check_type(argname="argument where", value=where, expected_type=type_hints["where"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "from_": from_,
        }
        if select is not None:
            self._values["select"] = select
        if where is not None:
            self._values["where"] = where

    @builtins.property
    def from_(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#from ServiceLevel#from}.'''
        result = self._values.get("from_")
        assert result is not None, "Required property 'from_' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def select(self) -> typing.Optional["ServiceLevelEventsBadEventsSelect"]:
        '''select block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#select ServiceLevel#select}
        '''
        result = self._values.get("select")
        return typing.cast(typing.Optional["ServiceLevelEventsBadEventsSelect"], result)

    @builtins.property
    def where(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#where ServiceLevel#where}.'''
        result = self._values.get("where")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ServiceLevelEventsBadEvents(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ServiceLevelEventsBadEventsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.serviceLevel.ServiceLevelEventsBadEventsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e9a574e5ba1d7631640243160f2f105cb5ccfc4cf4db3c15ae07e816531a2bc3)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putSelect")
    def put_select(
        self,
        *,
        function: builtins.str,
        attribute: typing.Optional[builtins.str] = None,
        threshold: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param function: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#function ServiceLevel#function}.
        :param attribute: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#attribute ServiceLevel#attribute}.
        :param threshold: The event threshold to use in the SELECT clause. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#threshold ServiceLevel#threshold}
        '''
        value = ServiceLevelEventsBadEventsSelect(
            function=function, attribute=attribute, threshold=threshold
        )

        return typing.cast(None, jsii.invoke(self, "putSelect", [value]))

    @jsii.member(jsii_name="resetSelect")
    def reset_select(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSelect", []))

    @jsii.member(jsii_name="resetWhere")
    def reset_where(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetWhere", []))

    @builtins.property
    @jsii.member(jsii_name="select")
    def select(self) -> "ServiceLevelEventsBadEventsSelectOutputReference":
        return typing.cast("ServiceLevelEventsBadEventsSelectOutputReference", jsii.get(self, "select"))

    @builtins.property
    @jsii.member(jsii_name="fromInput")
    def from_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "fromInput"))

    @builtins.property
    @jsii.member(jsii_name="selectInput")
    def select_input(self) -> typing.Optional["ServiceLevelEventsBadEventsSelect"]:
        return typing.cast(typing.Optional["ServiceLevelEventsBadEventsSelect"], jsii.get(self, "selectInput"))

    @builtins.property
    @jsii.member(jsii_name="whereInput")
    def where_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "whereInput"))

    @builtins.property
    @jsii.member(jsii_name="from")
    def from_(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "from"))

    @from_.setter
    def from_(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__89748af393f72ac1ee579a7fa438f18fe3e3f2457b5345bc26be4d7c1d3d64f0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "from", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="where")
    def where(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "where"))

    @where.setter
    def where(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__51dc0c8132cc7e6b9c4d6cbd09a2d401257926e00654119cbaca1338ea21d620)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "where", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[ServiceLevelEventsBadEvents]:
        return typing.cast(typing.Optional[ServiceLevelEventsBadEvents], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[ServiceLevelEventsBadEvents],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f11a3cae7cf54a67f4bf18360bf435e94d50369936a8fec7c965216b8d835d4e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.serviceLevel.ServiceLevelEventsBadEventsSelect",
    jsii_struct_bases=[],
    name_mapping={
        "function": "function",
        "attribute": "attribute",
        "threshold": "threshold",
    },
)
class ServiceLevelEventsBadEventsSelect:
    def __init__(
        self,
        *,
        function: builtins.str,
        attribute: typing.Optional[builtins.str] = None,
        threshold: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param function: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#function ServiceLevel#function}.
        :param attribute: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#attribute ServiceLevel#attribute}.
        :param threshold: The event threshold to use in the SELECT clause. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#threshold ServiceLevel#threshold}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7ee5b5a227f13bff4dc2e612ba0794d85a7c444b79957cd7b242ffda3a2a1387)
            check_type(argname="argument function", value=function, expected_type=type_hints["function"])
            check_type(argname="argument attribute", value=attribute, expected_type=type_hints["attribute"])
            check_type(argname="argument threshold", value=threshold, expected_type=type_hints["threshold"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "function": function,
        }
        if attribute is not None:
            self._values["attribute"] = attribute
        if threshold is not None:
            self._values["threshold"] = threshold

    @builtins.property
    def function(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#function ServiceLevel#function}.'''
        result = self._values.get("function")
        assert result is not None, "Required property 'function' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def attribute(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#attribute ServiceLevel#attribute}.'''
        result = self._values.get("attribute")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def threshold(self) -> typing.Optional[jsii.Number]:
        '''The event threshold to use in the SELECT clause.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#threshold ServiceLevel#threshold}
        '''
        result = self._values.get("threshold")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ServiceLevelEventsBadEventsSelect(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ServiceLevelEventsBadEventsSelectOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.serviceLevel.ServiceLevelEventsBadEventsSelectOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__be3ea709ede5b604873824a7d0db6069ad3eb9d688e8094cbfe761a54b453ee9)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetAttribute")
    def reset_attribute(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAttribute", []))

    @jsii.member(jsii_name="resetThreshold")
    def reset_threshold(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetThreshold", []))

    @builtins.property
    @jsii.member(jsii_name="attributeInput")
    def attribute_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "attributeInput"))

    @builtins.property
    @jsii.member(jsii_name="functionInput")
    def function_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "functionInput"))

    @builtins.property
    @jsii.member(jsii_name="thresholdInput")
    def threshold_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "thresholdInput"))

    @builtins.property
    @jsii.member(jsii_name="attribute")
    def attribute(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "attribute"))

    @attribute.setter
    def attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d728663774265e90eb71ad28b8dec739734edb6a71dd3d0c2c3d30c5a619035f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "attribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="function")
    def function(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "function"))

    @function.setter
    def function(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1b1cd9dbc5cb75328dffcb14e8c64bfc8efc95db0872518d99ed5ddafffdc2e4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "function", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="threshold")
    def threshold(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "threshold"))

    @threshold.setter
    def threshold(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__62391510db760563b497c978d50f0154802c6acd73bdef0b1aff2bd884c90f7b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "threshold", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[ServiceLevelEventsBadEventsSelect]:
        return typing.cast(typing.Optional[ServiceLevelEventsBadEventsSelect], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[ServiceLevelEventsBadEventsSelect],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8aefc5f68168e2edd52e65e338c329b9a1ab1898d7863aa03d72782765aee3c0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.serviceLevel.ServiceLevelEventsGoodEvents",
    jsii_struct_bases=[],
    name_mapping={"from_": "from", "select": "select", "where": "where"},
)
class ServiceLevelEventsGoodEvents:
    def __init__(
        self,
        *,
        from_: builtins.str,
        select: typing.Optional[typing.Union["ServiceLevelEventsGoodEventsSelect", typing.Dict[builtins.str, typing.Any]]] = None,
        where: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param from_: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#from ServiceLevel#from}.
        :param select: select block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#select ServiceLevel#select}
        :param where: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#where ServiceLevel#where}.
        '''
        if isinstance(select, dict):
            select = ServiceLevelEventsGoodEventsSelect(**select)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__45d2f81bf5cabb156b3345c0e548869baeb256278ff19b74010154bb3f59fed2)
            check_type(argname="argument from_", value=from_, expected_type=type_hints["from_"])
            check_type(argname="argument select", value=select, expected_type=type_hints["select"])
            check_type(argname="argument where", value=where, expected_type=type_hints["where"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "from_": from_,
        }
        if select is not None:
            self._values["select"] = select
        if where is not None:
            self._values["where"] = where

    @builtins.property
    def from_(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#from ServiceLevel#from}.'''
        result = self._values.get("from_")
        assert result is not None, "Required property 'from_' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def select(self) -> typing.Optional["ServiceLevelEventsGoodEventsSelect"]:
        '''select block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#select ServiceLevel#select}
        '''
        result = self._values.get("select")
        return typing.cast(typing.Optional["ServiceLevelEventsGoodEventsSelect"], result)

    @builtins.property
    def where(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#where ServiceLevel#where}.'''
        result = self._values.get("where")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ServiceLevelEventsGoodEvents(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ServiceLevelEventsGoodEventsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.serviceLevel.ServiceLevelEventsGoodEventsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bb576b8c928edbc83c3219e952ae0ea5d6c9460175020e79e56d858d5e06fd7e)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putSelect")
    def put_select(
        self,
        *,
        function: builtins.str,
        attribute: typing.Optional[builtins.str] = None,
        threshold: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param function: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#function ServiceLevel#function}.
        :param attribute: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#attribute ServiceLevel#attribute}.
        :param threshold: The event threshold to use in the SELECT clause. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#threshold ServiceLevel#threshold}
        '''
        value = ServiceLevelEventsGoodEventsSelect(
            function=function, attribute=attribute, threshold=threshold
        )

        return typing.cast(None, jsii.invoke(self, "putSelect", [value]))

    @jsii.member(jsii_name="resetSelect")
    def reset_select(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSelect", []))

    @jsii.member(jsii_name="resetWhere")
    def reset_where(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetWhere", []))

    @builtins.property
    @jsii.member(jsii_name="select")
    def select(self) -> "ServiceLevelEventsGoodEventsSelectOutputReference":
        return typing.cast("ServiceLevelEventsGoodEventsSelectOutputReference", jsii.get(self, "select"))

    @builtins.property
    @jsii.member(jsii_name="fromInput")
    def from_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "fromInput"))

    @builtins.property
    @jsii.member(jsii_name="selectInput")
    def select_input(self) -> typing.Optional["ServiceLevelEventsGoodEventsSelect"]:
        return typing.cast(typing.Optional["ServiceLevelEventsGoodEventsSelect"], jsii.get(self, "selectInput"))

    @builtins.property
    @jsii.member(jsii_name="whereInput")
    def where_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "whereInput"))

    @builtins.property
    @jsii.member(jsii_name="from")
    def from_(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "from"))

    @from_.setter
    def from_(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4f48793c14f6cacaa466ba1bc3afa44e3192490d77fc93161d0a5c4cf0bf58ec)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "from", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="where")
    def where(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "where"))

    @where.setter
    def where(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8c5f1f3d1d14eeece3d52189a8c301deddbe3a588ed860c8a75b555f8fa2f17c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "where", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[ServiceLevelEventsGoodEvents]:
        return typing.cast(typing.Optional[ServiceLevelEventsGoodEvents], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[ServiceLevelEventsGoodEvents],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b6f871cfc882b315a2df758711c7c5ad00c865d640c98baa200eb41a3c31339d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.serviceLevel.ServiceLevelEventsGoodEventsSelect",
    jsii_struct_bases=[],
    name_mapping={
        "function": "function",
        "attribute": "attribute",
        "threshold": "threshold",
    },
)
class ServiceLevelEventsGoodEventsSelect:
    def __init__(
        self,
        *,
        function: builtins.str,
        attribute: typing.Optional[builtins.str] = None,
        threshold: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param function: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#function ServiceLevel#function}.
        :param attribute: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#attribute ServiceLevel#attribute}.
        :param threshold: The event threshold to use in the SELECT clause. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#threshold ServiceLevel#threshold}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__140993205abda77a1eff0010c35b0ed7e7e51c77a537071f3fbc4b857dff7837)
            check_type(argname="argument function", value=function, expected_type=type_hints["function"])
            check_type(argname="argument attribute", value=attribute, expected_type=type_hints["attribute"])
            check_type(argname="argument threshold", value=threshold, expected_type=type_hints["threshold"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "function": function,
        }
        if attribute is not None:
            self._values["attribute"] = attribute
        if threshold is not None:
            self._values["threshold"] = threshold

    @builtins.property
    def function(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#function ServiceLevel#function}.'''
        result = self._values.get("function")
        assert result is not None, "Required property 'function' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def attribute(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#attribute ServiceLevel#attribute}.'''
        result = self._values.get("attribute")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def threshold(self) -> typing.Optional[jsii.Number]:
        '''The event threshold to use in the SELECT clause.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#threshold ServiceLevel#threshold}
        '''
        result = self._values.get("threshold")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ServiceLevelEventsGoodEventsSelect(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ServiceLevelEventsGoodEventsSelectOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.serviceLevel.ServiceLevelEventsGoodEventsSelectOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0b479428f4013fc244eb815e75410b30204630c0a1aedc775f7f9efb7c5555da)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetAttribute")
    def reset_attribute(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAttribute", []))

    @jsii.member(jsii_name="resetThreshold")
    def reset_threshold(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetThreshold", []))

    @builtins.property
    @jsii.member(jsii_name="attributeInput")
    def attribute_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "attributeInput"))

    @builtins.property
    @jsii.member(jsii_name="functionInput")
    def function_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "functionInput"))

    @builtins.property
    @jsii.member(jsii_name="thresholdInput")
    def threshold_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "thresholdInput"))

    @builtins.property
    @jsii.member(jsii_name="attribute")
    def attribute(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "attribute"))

    @attribute.setter
    def attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a769568e17feaed82ffd746a6d35c980c4651e8f7dc010dc7c812da4692c1a94)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "attribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="function")
    def function(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "function"))

    @function.setter
    def function(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__63a634e2fcec0efb1b928b7f2836f2f82adbcebeaea11e9d3f91ed63bfd42fcf)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "function", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="threshold")
    def threshold(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "threshold"))

    @threshold.setter
    def threshold(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4ef2ed5db18f96efe922ff69b4a8bf49440ae0094ac8d6b2ac91a0ac3315582e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "threshold", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[ServiceLevelEventsGoodEventsSelect]:
        return typing.cast(typing.Optional[ServiceLevelEventsGoodEventsSelect], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[ServiceLevelEventsGoodEventsSelect],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9c8dba89be2799b20c04f919ed3bf9f7b739661582588f7a6df62bd4425550cd)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class ServiceLevelEventsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.serviceLevel.ServiceLevelEventsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c3cabbeb5b0884b55cb700ec1fcb9ab8b6083498695691ac5e33f02e81833a0d)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putBadEvents")
    def put_bad_events(
        self,
        *,
        from_: builtins.str,
        select: typing.Optional[typing.Union[ServiceLevelEventsBadEventsSelect, typing.Dict[builtins.str, typing.Any]]] = None,
        where: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param from_: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#from ServiceLevel#from}.
        :param select: select block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#select ServiceLevel#select}
        :param where: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#where ServiceLevel#where}.
        '''
        value = ServiceLevelEventsBadEvents(from_=from_, select=select, where=where)

        return typing.cast(None, jsii.invoke(self, "putBadEvents", [value]))

    @jsii.member(jsii_name="putGoodEvents")
    def put_good_events(
        self,
        *,
        from_: builtins.str,
        select: typing.Optional[typing.Union[ServiceLevelEventsGoodEventsSelect, typing.Dict[builtins.str, typing.Any]]] = None,
        where: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param from_: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#from ServiceLevel#from}.
        :param select: select block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#select ServiceLevel#select}
        :param where: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#where ServiceLevel#where}.
        '''
        value = ServiceLevelEventsGoodEvents(from_=from_, select=select, where=where)

        return typing.cast(None, jsii.invoke(self, "putGoodEvents", [value]))

    @jsii.member(jsii_name="putValidEvents")
    def put_valid_events(
        self,
        *,
        from_: builtins.str,
        select: typing.Optional[typing.Union["ServiceLevelEventsValidEventsSelect", typing.Dict[builtins.str, typing.Any]]] = None,
        where: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param from_: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#from ServiceLevel#from}.
        :param select: select block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#select ServiceLevel#select}
        :param where: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#where ServiceLevel#where}.
        '''
        value = ServiceLevelEventsValidEvents(from_=from_, select=select, where=where)

        return typing.cast(None, jsii.invoke(self, "putValidEvents", [value]))

    @jsii.member(jsii_name="resetBadEvents")
    def reset_bad_events(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetBadEvents", []))

    @jsii.member(jsii_name="resetGoodEvents")
    def reset_good_events(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetGoodEvents", []))

    @builtins.property
    @jsii.member(jsii_name="badEvents")
    def bad_events(self) -> ServiceLevelEventsBadEventsOutputReference:
        return typing.cast(ServiceLevelEventsBadEventsOutputReference, jsii.get(self, "badEvents"))

    @builtins.property
    @jsii.member(jsii_name="goodEvents")
    def good_events(self) -> ServiceLevelEventsGoodEventsOutputReference:
        return typing.cast(ServiceLevelEventsGoodEventsOutputReference, jsii.get(self, "goodEvents"))

    @builtins.property
    @jsii.member(jsii_name="validEvents")
    def valid_events(self) -> "ServiceLevelEventsValidEventsOutputReference":
        return typing.cast("ServiceLevelEventsValidEventsOutputReference", jsii.get(self, "validEvents"))

    @builtins.property
    @jsii.member(jsii_name="accountIdInput")
    def account_id_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "accountIdInput"))

    @builtins.property
    @jsii.member(jsii_name="badEventsInput")
    def bad_events_input(self) -> typing.Optional[ServiceLevelEventsBadEvents]:
        return typing.cast(typing.Optional[ServiceLevelEventsBadEvents], jsii.get(self, "badEventsInput"))

    @builtins.property
    @jsii.member(jsii_name="goodEventsInput")
    def good_events_input(self) -> typing.Optional[ServiceLevelEventsGoodEvents]:
        return typing.cast(typing.Optional[ServiceLevelEventsGoodEvents], jsii.get(self, "goodEventsInput"))

    @builtins.property
    @jsii.member(jsii_name="validEventsInput")
    def valid_events_input(self) -> typing.Optional["ServiceLevelEventsValidEvents"]:
        return typing.cast(typing.Optional["ServiceLevelEventsValidEvents"], jsii.get(self, "validEventsInput"))

    @builtins.property
    @jsii.member(jsii_name="accountId")
    def account_id(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "accountId"))

    @account_id.setter
    def account_id(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__120f1d78f80942cdb6bf38511bdd0a3317e642a7e13d57b8eb15080eae4773a1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "accountId", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[ServiceLevelEvents]:
        return typing.cast(typing.Optional[ServiceLevelEvents], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(self, value: typing.Optional[ServiceLevelEvents]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__14a47bb9fb76cd4c496777014340d2b780ec0dba52353165b064e6c76a831bc5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.serviceLevel.ServiceLevelEventsValidEvents",
    jsii_struct_bases=[],
    name_mapping={"from_": "from", "select": "select", "where": "where"},
)
class ServiceLevelEventsValidEvents:
    def __init__(
        self,
        *,
        from_: builtins.str,
        select: typing.Optional[typing.Union["ServiceLevelEventsValidEventsSelect", typing.Dict[builtins.str, typing.Any]]] = None,
        where: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param from_: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#from ServiceLevel#from}.
        :param select: select block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#select ServiceLevel#select}
        :param where: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#where ServiceLevel#where}.
        '''
        if isinstance(select, dict):
            select = ServiceLevelEventsValidEventsSelect(**select)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e38569e6b5ee301ae8ae48272378b483126f9c61b140f7168ce58959baa06870)
            check_type(argname="argument from_", value=from_, expected_type=type_hints["from_"])
            check_type(argname="argument select", value=select, expected_type=type_hints["select"])
            check_type(argname="argument where", value=where, expected_type=type_hints["where"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "from_": from_,
        }
        if select is not None:
            self._values["select"] = select
        if where is not None:
            self._values["where"] = where

    @builtins.property
    def from_(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#from ServiceLevel#from}.'''
        result = self._values.get("from_")
        assert result is not None, "Required property 'from_' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def select(self) -> typing.Optional["ServiceLevelEventsValidEventsSelect"]:
        '''select block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#select ServiceLevel#select}
        '''
        result = self._values.get("select")
        return typing.cast(typing.Optional["ServiceLevelEventsValidEventsSelect"], result)

    @builtins.property
    def where(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#where ServiceLevel#where}.'''
        result = self._values.get("where")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ServiceLevelEventsValidEvents(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ServiceLevelEventsValidEventsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.serviceLevel.ServiceLevelEventsValidEventsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__73966807c80379ac604faa140399718ecae9c4643fff1b9a5000514f0acf6d40)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putSelect")
    def put_select(
        self,
        *,
        function: builtins.str,
        attribute: typing.Optional[builtins.str] = None,
        threshold: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param function: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#function ServiceLevel#function}.
        :param attribute: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#attribute ServiceLevel#attribute}.
        :param threshold: The event threshold to use in the SELECT clause. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#threshold ServiceLevel#threshold}
        '''
        value = ServiceLevelEventsValidEventsSelect(
            function=function, attribute=attribute, threshold=threshold
        )

        return typing.cast(None, jsii.invoke(self, "putSelect", [value]))

    @jsii.member(jsii_name="resetSelect")
    def reset_select(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSelect", []))

    @jsii.member(jsii_name="resetWhere")
    def reset_where(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetWhere", []))

    @builtins.property
    @jsii.member(jsii_name="select")
    def select(self) -> "ServiceLevelEventsValidEventsSelectOutputReference":
        return typing.cast("ServiceLevelEventsValidEventsSelectOutputReference", jsii.get(self, "select"))

    @builtins.property
    @jsii.member(jsii_name="fromInput")
    def from_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "fromInput"))

    @builtins.property
    @jsii.member(jsii_name="selectInput")
    def select_input(self) -> typing.Optional["ServiceLevelEventsValidEventsSelect"]:
        return typing.cast(typing.Optional["ServiceLevelEventsValidEventsSelect"], jsii.get(self, "selectInput"))

    @builtins.property
    @jsii.member(jsii_name="whereInput")
    def where_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "whereInput"))

    @builtins.property
    @jsii.member(jsii_name="from")
    def from_(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "from"))

    @from_.setter
    def from_(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__940a5a7117b2d6061d25b2c1f48282bb71a961b44bfd4e5818c567aa6424f7b8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "from", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="where")
    def where(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "where"))

    @where.setter
    def where(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__45f1f66bfd6957eed2e8553647239ffdf06f0f9941001aacba8c2158d2daf3c9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "where", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[ServiceLevelEventsValidEvents]:
        return typing.cast(typing.Optional[ServiceLevelEventsValidEvents], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[ServiceLevelEventsValidEvents],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4c6d9c5a2b23f638b435bf8649a0d345f7630e0f8dc675750604ec0103b26e34)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.serviceLevel.ServiceLevelEventsValidEventsSelect",
    jsii_struct_bases=[],
    name_mapping={
        "function": "function",
        "attribute": "attribute",
        "threshold": "threshold",
    },
)
class ServiceLevelEventsValidEventsSelect:
    def __init__(
        self,
        *,
        function: builtins.str,
        attribute: typing.Optional[builtins.str] = None,
        threshold: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param function: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#function ServiceLevel#function}.
        :param attribute: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#attribute ServiceLevel#attribute}.
        :param threshold: The event threshold to use in the SELECT clause. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#threshold ServiceLevel#threshold}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__523a1c89d6aaaa4e2483b50e388769630ffaf9d2132e055c4de7c98dc4c1b6ed)
            check_type(argname="argument function", value=function, expected_type=type_hints["function"])
            check_type(argname="argument attribute", value=attribute, expected_type=type_hints["attribute"])
            check_type(argname="argument threshold", value=threshold, expected_type=type_hints["threshold"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "function": function,
        }
        if attribute is not None:
            self._values["attribute"] = attribute
        if threshold is not None:
            self._values["threshold"] = threshold

    @builtins.property
    def function(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#function ServiceLevel#function}.'''
        result = self._values.get("function")
        assert result is not None, "Required property 'function' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def attribute(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#attribute ServiceLevel#attribute}.'''
        result = self._values.get("attribute")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def threshold(self) -> typing.Optional[jsii.Number]:
        '''The event threshold to use in the SELECT clause.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#threshold ServiceLevel#threshold}
        '''
        result = self._values.get("threshold")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ServiceLevelEventsValidEventsSelect(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ServiceLevelEventsValidEventsSelectOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.serviceLevel.ServiceLevelEventsValidEventsSelectOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cf8a9ba772215bdaf2d701decb56e40dae725493f240c7e317e87ef9a0439b9e)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetAttribute")
    def reset_attribute(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAttribute", []))

    @jsii.member(jsii_name="resetThreshold")
    def reset_threshold(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetThreshold", []))

    @builtins.property
    @jsii.member(jsii_name="attributeInput")
    def attribute_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "attributeInput"))

    @builtins.property
    @jsii.member(jsii_name="functionInput")
    def function_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "functionInput"))

    @builtins.property
    @jsii.member(jsii_name="thresholdInput")
    def threshold_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "thresholdInput"))

    @builtins.property
    @jsii.member(jsii_name="attribute")
    def attribute(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "attribute"))

    @attribute.setter
    def attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__274438120c5657b48a7a46a167030a324117f1224346398bd5aa51bfbb691efb)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "attribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="function")
    def function(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "function"))

    @function.setter
    def function(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2c269e56d00fdcfd2482ff674fdefcf1b37726c42eb8a473a750aa954d45a079)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "function", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="threshold")
    def threshold(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "threshold"))

    @threshold.setter
    def threshold(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f6169cae00ad553307fbbf00385f6df71f67656442642d0455e2ee741d7062b5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "threshold", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[ServiceLevelEventsValidEventsSelect]:
        return typing.cast(typing.Optional[ServiceLevelEventsValidEventsSelect], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[ServiceLevelEventsValidEventsSelect],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__52b760da20b45ea259caf6480cd9396897f150b43905291b7e81fcf649511f4f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.serviceLevel.ServiceLevelObjective",
    jsii_struct_bases=[],
    name_mapping={
        "target": "target",
        "time_window": "timeWindow",
        "description": "description",
        "name": "name",
    },
)
class ServiceLevelObjective:
    def __init__(
        self,
        *,
        target: jsii.Number,
        time_window: typing.Union["ServiceLevelObjectiveTimeWindow", typing.Dict[builtins.str, typing.Any]],
        description: typing.Optional[builtins.str] = None,
        name: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param target: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#target ServiceLevel#target}.
        :param time_window: time_window block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#time_window ServiceLevel#time_window}
        :param description: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#description ServiceLevel#description}.
        :param name: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#name ServiceLevel#name}.
        '''
        if isinstance(time_window, dict):
            time_window = ServiceLevelObjectiveTimeWindow(**time_window)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3f8cdc108d782f4d84ce82e789bdc955438163f2d74a150d193ebe58c7fb4d04)
            check_type(argname="argument target", value=target, expected_type=type_hints["target"])
            check_type(argname="argument time_window", value=time_window, expected_type=type_hints["time_window"])
            check_type(argname="argument description", value=description, expected_type=type_hints["description"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "target": target,
            "time_window": time_window,
        }
        if description is not None:
            self._values["description"] = description
        if name is not None:
            self._values["name"] = name

    @builtins.property
    def target(self) -> jsii.Number:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#target ServiceLevel#target}.'''
        result = self._values.get("target")
        assert result is not None, "Required property 'target' is missing"
        return typing.cast(jsii.Number, result)

    @builtins.property
    def time_window(self) -> "ServiceLevelObjectiveTimeWindow":
        '''time_window block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#time_window ServiceLevel#time_window}
        '''
        result = self._values.get("time_window")
        assert result is not None, "Required property 'time_window' is missing"
        return typing.cast("ServiceLevelObjectiveTimeWindow", result)

    @builtins.property
    def description(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#description ServiceLevel#description}.'''
        result = self._values.get("description")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def name(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#name ServiceLevel#name}.'''
        result = self._values.get("name")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ServiceLevelObjective(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ServiceLevelObjectiveOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.serviceLevel.ServiceLevelObjectiveOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a7ad719009a8d01d823f67b05a70e7b3cdb295f11c86e11cda3f6cfbac68afdb)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putTimeWindow")
    def put_time_window(
        self,
        *,
        rolling: typing.Union["ServiceLevelObjectiveTimeWindowRolling", typing.Dict[builtins.str, typing.Any]],
    ) -> None:
        '''
        :param rolling: rolling block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#rolling ServiceLevel#rolling}
        '''
        value = ServiceLevelObjectiveTimeWindow(rolling=rolling)

        return typing.cast(None, jsii.invoke(self, "putTimeWindow", [value]))

    @jsii.member(jsii_name="resetDescription")
    def reset_description(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDescription", []))

    @jsii.member(jsii_name="resetName")
    def reset_name(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetName", []))

    @builtins.property
    @jsii.member(jsii_name="timeWindow")
    def time_window(self) -> "ServiceLevelObjectiveTimeWindowOutputReference":
        return typing.cast("ServiceLevelObjectiveTimeWindowOutputReference", jsii.get(self, "timeWindow"))

    @builtins.property
    @jsii.member(jsii_name="descriptionInput")
    def description_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "descriptionInput"))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="targetInput")
    def target_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "targetInput"))

    @builtins.property
    @jsii.member(jsii_name="timeWindowInput")
    def time_window_input(self) -> typing.Optional["ServiceLevelObjectiveTimeWindow"]:
        return typing.cast(typing.Optional["ServiceLevelObjectiveTimeWindow"], jsii.get(self, "timeWindowInput"))

    @builtins.property
    @jsii.member(jsii_name="description")
    def description(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "description"))

    @description.setter
    def description(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7fe4a2e957116b7bff1f4b33266d85de220f850fe3c12af22531cf885b0dee5c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "description", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8f938f565971e0652d4fe564c5c794f436595bccecbce905871bbd94c3d5bad3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="target")
    def target(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "target"))

    @target.setter
    def target(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a3b136d5c23126d5438a8b9c2afe31cd55ddfd79035aa44f52275d2f244230ac)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "target", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[ServiceLevelObjective]:
        return typing.cast(typing.Optional[ServiceLevelObjective], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(self, value: typing.Optional[ServiceLevelObjective]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3f870e6879335436f3c5cffa63d5259f7a2e6789f46ec7a5bdaff86c7449115b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.serviceLevel.ServiceLevelObjectiveTimeWindow",
    jsii_struct_bases=[],
    name_mapping={"rolling": "rolling"},
)
class ServiceLevelObjectiveTimeWindow:
    def __init__(
        self,
        *,
        rolling: typing.Union["ServiceLevelObjectiveTimeWindowRolling", typing.Dict[builtins.str, typing.Any]],
    ) -> None:
        '''
        :param rolling: rolling block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#rolling ServiceLevel#rolling}
        '''
        if isinstance(rolling, dict):
            rolling = ServiceLevelObjectiveTimeWindowRolling(**rolling)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f53affb60bc009815cfebdb1a79bac9dbddb04f25be9d30994b9143b035f85e7)
            check_type(argname="argument rolling", value=rolling, expected_type=type_hints["rolling"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "rolling": rolling,
        }

    @builtins.property
    def rolling(self) -> "ServiceLevelObjectiveTimeWindowRolling":
        '''rolling block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#rolling ServiceLevel#rolling}
        '''
        result = self._values.get("rolling")
        assert result is not None, "Required property 'rolling' is missing"
        return typing.cast("ServiceLevelObjectiveTimeWindowRolling", result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ServiceLevelObjectiveTimeWindow(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ServiceLevelObjectiveTimeWindowOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.serviceLevel.ServiceLevelObjectiveTimeWindowOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4226423bebd9f442a4b34c99d69ba1b6216f09465ee5e45bdd2a54de054ea881)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putRolling")
    def put_rolling(self, *, count: jsii.Number, unit: builtins.str) -> None:
        '''
        :param count: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#count ServiceLevel#count}.
        :param unit: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#unit ServiceLevel#unit}.
        '''
        value = ServiceLevelObjectiveTimeWindowRolling(count=count, unit=unit)

        return typing.cast(None, jsii.invoke(self, "putRolling", [value]))

    @builtins.property
    @jsii.member(jsii_name="rolling")
    def rolling(self) -> "ServiceLevelObjectiveTimeWindowRollingOutputReference":
        return typing.cast("ServiceLevelObjectiveTimeWindowRollingOutputReference", jsii.get(self, "rolling"))

    @builtins.property
    @jsii.member(jsii_name="rollingInput")
    def rolling_input(
        self,
    ) -> typing.Optional["ServiceLevelObjectiveTimeWindowRolling"]:
        return typing.cast(typing.Optional["ServiceLevelObjectiveTimeWindowRolling"], jsii.get(self, "rollingInput"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[ServiceLevelObjectiveTimeWindow]:
        return typing.cast(typing.Optional[ServiceLevelObjectiveTimeWindow], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[ServiceLevelObjectiveTimeWindow],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2ddf624c849ae63789143b32ea92e409752d26445735ef9f32e9d63f54125eeb)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.serviceLevel.ServiceLevelObjectiveTimeWindowRolling",
    jsii_struct_bases=[],
    name_mapping={"count": "count", "unit": "unit"},
)
class ServiceLevelObjectiveTimeWindowRolling:
    def __init__(self, *, count: jsii.Number, unit: builtins.str) -> None:
        '''
        :param count: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#count ServiceLevel#count}.
        :param unit: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#unit ServiceLevel#unit}.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__733c87123c9a2cbb373336b18d89dba68f0ef12fccf8371db9014333bd5c4084)
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument unit", value=unit, expected_type=type_hints["unit"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "count": count,
            "unit": unit,
        }

    @builtins.property
    def count(self) -> jsii.Number:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#count ServiceLevel#count}.'''
        result = self._values.get("count")
        assert result is not None, "Required property 'count' is missing"
        return typing.cast(jsii.Number, result)

    @builtins.property
    def unit(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/service_level#unit ServiceLevel#unit}.'''
        result = self._values.get("unit")
        assert result is not None, "Required property 'unit' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ServiceLevelObjectiveTimeWindowRolling(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ServiceLevelObjectiveTimeWindowRollingOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.serviceLevel.ServiceLevelObjectiveTimeWindowRollingOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4df89e87f9e6c274e41ad73173c76e6ff116b2fc2e5cc35d823110431826c5b0)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @builtins.property
    @jsii.member(jsii_name="countInput")
    def count_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "countInput"))

    @builtins.property
    @jsii.member(jsii_name="unitInput")
    def unit_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "unitInput"))

    @builtins.property
    @jsii.member(jsii_name="count")
    def count(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "count"))

    @count.setter
    def count(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7fd032e9757c390c1c05a334ac1388ac1225225f1079af0658185e68b545ca76)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "count", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="unit")
    def unit(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "unit"))

    @unit.setter
    def unit(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__779aeb4dabccaf1e66faf74c17aa1a867cc16ff821fa72d3d8647d3868121b2c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "unit", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[ServiceLevelObjectiveTimeWindowRolling]:
        return typing.cast(typing.Optional[ServiceLevelObjectiveTimeWindowRolling], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[ServiceLevelObjectiveTimeWindowRolling],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b043f0494e1d08eaadd6cbaa09f3c6c044a89bbb8b65baa76879cd43592b6b09)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


__all__ = [
    "ServiceLevel",
    "ServiceLevelConfig",
    "ServiceLevelEvents",
    "ServiceLevelEventsBadEvents",
    "ServiceLevelEventsBadEventsOutputReference",
    "ServiceLevelEventsBadEventsSelect",
    "ServiceLevelEventsBadEventsSelectOutputReference",
    "ServiceLevelEventsGoodEvents",
    "ServiceLevelEventsGoodEventsOutputReference",
    "ServiceLevelEventsGoodEventsSelect",
    "ServiceLevelEventsGoodEventsSelectOutputReference",
    "ServiceLevelEventsOutputReference",
    "ServiceLevelEventsValidEvents",
    "ServiceLevelEventsValidEventsOutputReference",
    "ServiceLevelEventsValidEventsSelect",
    "ServiceLevelEventsValidEventsSelectOutputReference",
    "ServiceLevelObjective",
    "ServiceLevelObjectiveOutputReference",
    "ServiceLevelObjectiveTimeWindow",
    "ServiceLevelObjectiveTimeWindowOutputReference",
    "ServiceLevelObjectiveTimeWindowRolling",
    "ServiceLevelObjectiveTimeWindowRollingOutputReference",
]

publication.publish()

def _typecheckingstub__0f68114bb92cb507c4135d2b5eadbb46fac0c300d3762d63ed74a1060ba57738(
    scope: _constructs_77d1e7e8.Construct,
    id_: builtins.str,
    *,
    events: typing.Union[ServiceLevelEvents, typing.Dict[builtins.str, typing.Any]],
    guid: builtins.str,
    name: builtins.str,
    objective: typing.Union[ServiceLevelObjective, typing.Dict[builtins.str, typing.Any]],
    description: typing.Optional[builtins.str] = None,
    id: typing.Optional[builtins.str] = None,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__61c58c0084d8f33441e5278febb0d3dfb4d65ded2838edefbd960b75fdc376e4(
    scope: _constructs_77d1e7e8.Construct,
    import_to_id: builtins.str,
    import_from_id: builtins.str,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2c5a00fc4de58f8b99192bd1fc13091eca70f077f137328194011513aad3566b(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c2990996fbf12d2dd4bd6c08c5a7353d68415e94c5d85603efa476fe815e48e4(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a63132391882f92a98e70a71c9f819441d69e75553d86f10292d2598d0e5d3d8(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9159d3cdfcfe0af7d93292d4512cc64eacc39331dfe0354ca30acb0b19883467(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f678733af0606bef9f6f924149e3e5919d0fccef4ce59015388f381640ae14a2(
    *,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    events: typing.Union[ServiceLevelEvents, typing.Dict[builtins.str, typing.Any]],
    guid: builtins.str,
    name: builtins.str,
    objective: typing.Union[ServiceLevelObjective, typing.Dict[builtins.str, typing.Any]],
    description: typing.Optional[builtins.str] = None,
    id: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8302114798cf13bbbb618e59bea38a6982241b520542b297e1ab913543b62880(
    *,
    account_id: jsii.Number,
    valid_events: typing.Union[ServiceLevelEventsValidEvents, typing.Dict[builtins.str, typing.Any]],
    bad_events: typing.Optional[typing.Union[ServiceLevelEventsBadEvents, typing.Dict[builtins.str, typing.Any]]] = None,
    good_events: typing.Optional[typing.Union[ServiceLevelEventsGoodEvents, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__29b8d44ebe63c44068940b22e58befa1a0027d278208be7da373899761f4e42b(
    *,
    from_: builtins.str,
    select: typing.Optional[typing.Union[ServiceLevelEventsBadEventsSelect, typing.Dict[builtins.str, typing.Any]]] = None,
    where: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e9a574e5ba1d7631640243160f2f105cb5ccfc4cf4db3c15ae07e816531a2bc3(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__89748af393f72ac1ee579a7fa438f18fe3e3f2457b5345bc26be4d7c1d3d64f0(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__51dc0c8132cc7e6b9c4d6cbd09a2d401257926e00654119cbaca1338ea21d620(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f11a3cae7cf54a67f4bf18360bf435e94d50369936a8fec7c965216b8d835d4e(
    value: typing.Optional[ServiceLevelEventsBadEvents],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7ee5b5a227f13bff4dc2e612ba0794d85a7c444b79957cd7b242ffda3a2a1387(
    *,
    function: builtins.str,
    attribute: typing.Optional[builtins.str] = None,
    threshold: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__be3ea709ede5b604873824a7d0db6069ad3eb9d688e8094cbfe761a54b453ee9(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d728663774265e90eb71ad28b8dec739734edb6a71dd3d0c2c3d30c5a619035f(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1b1cd9dbc5cb75328dffcb14e8c64bfc8efc95db0872518d99ed5ddafffdc2e4(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__62391510db760563b497c978d50f0154802c6acd73bdef0b1aff2bd884c90f7b(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8aefc5f68168e2edd52e65e338c329b9a1ab1898d7863aa03d72782765aee3c0(
    value: typing.Optional[ServiceLevelEventsBadEventsSelect],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__45d2f81bf5cabb156b3345c0e548869baeb256278ff19b74010154bb3f59fed2(
    *,
    from_: builtins.str,
    select: typing.Optional[typing.Union[ServiceLevelEventsGoodEventsSelect, typing.Dict[builtins.str, typing.Any]]] = None,
    where: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bb576b8c928edbc83c3219e952ae0ea5d6c9460175020e79e56d858d5e06fd7e(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4f48793c14f6cacaa466ba1bc3afa44e3192490d77fc93161d0a5c4cf0bf58ec(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8c5f1f3d1d14eeece3d52189a8c301deddbe3a588ed860c8a75b555f8fa2f17c(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b6f871cfc882b315a2df758711c7c5ad00c865d640c98baa200eb41a3c31339d(
    value: typing.Optional[ServiceLevelEventsGoodEvents],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__140993205abda77a1eff0010c35b0ed7e7e51c77a537071f3fbc4b857dff7837(
    *,
    function: builtins.str,
    attribute: typing.Optional[builtins.str] = None,
    threshold: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0b479428f4013fc244eb815e75410b30204630c0a1aedc775f7f9efb7c5555da(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a769568e17feaed82ffd746a6d35c980c4651e8f7dc010dc7c812da4692c1a94(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__63a634e2fcec0efb1b928b7f2836f2f82adbcebeaea11e9d3f91ed63bfd42fcf(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4ef2ed5db18f96efe922ff69b4a8bf49440ae0094ac8d6b2ac91a0ac3315582e(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9c8dba89be2799b20c04f919ed3bf9f7b739661582588f7a6df62bd4425550cd(
    value: typing.Optional[ServiceLevelEventsGoodEventsSelect],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c3cabbeb5b0884b55cb700ec1fcb9ab8b6083498695691ac5e33f02e81833a0d(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__120f1d78f80942cdb6bf38511bdd0a3317e642a7e13d57b8eb15080eae4773a1(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__14a47bb9fb76cd4c496777014340d2b780ec0dba52353165b064e6c76a831bc5(
    value: typing.Optional[ServiceLevelEvents],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e38569e6b5ee301ae8ae48272378b483126f9c61b140f7168ce58959baa06870(
    *,
    from_: builtins.str,
    select: typing.Optional[typing.Union[ServiceLevelEventsValidEventsSelect, typing.Dict[builtins.str, typing.Any]]] = None,
    where: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__73966807c80379ac604faa140399718ecae9c4643fff1b9a5000514f0acf6d40(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__940a5a7117b2d6061d25b2c1f48282bb71a961b44bfd4e5818c567aa6424f7b8(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__45f1f66bfd6957eed2e8553647239ffdf06f0f9941001aacba8c2158d2daf3c9(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4c6d9c5a2b23f638b435bf8649a0d345f7630e0f8dc675750604ec0103b26e34(
    value: typing.Optional[ServiceLevelEventsValidEvents],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__523a1c89d6aaaa4e2483b50e388769630ffaf9d2132e055c4de7c98dc4c1b6ed(
    *,
    function: builtins.str,
    attribute: typing.Optional[builtins.str] = None,
    threshold: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cf8a9ba772215bdaf2d701decb56e40dae725493f240c7e317e87ef9a0439b9e(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__274438120c5657b48a7a46a167030a324117f1224346398bd5aa51bfbb691efb(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2c269e56d00fdcfd2482ff674fdefcf1b37726c42eb8a473a750aa954d45a079(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f6169cae00ad553307fbbf00385f6df71f67656442642d0455e2ee741d7062b5(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__52b760da20b45ea259caf6480cd9396897f150b43905291b7e81fcf649511f4f(
    value: typing.Optional[ServiceLevelEventsValidEventsSelect],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3f8cdc108d782f4d84ce82e789bdc955438163f2d74a150d193ebe58c7fb4d04(
    *,
    target: jsii.Number,
    time_window: typing.Union[ServiceLevelObjectiveTimeWindow, typing.Dict[builtins.str, typing.Any]],
    description: typing.Optional[builtins.str] = None,
    name: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a7ad719009a8d01d823f67b05a70e7b3cdb295f11c86e11cda3f6cfbac68afdb(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7fe4a2e957116b7bff1f4b33266d85de220f850fe3c12af22531cf885b0dee5c(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8f938f565971e0652d4fe564c5c794f436595bccecbce905871bbd94c3d5bad3(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a3b136d5c23126d5438a8b9c2afe31cd55ddfd79035aa44f52275d2f244230ac(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3f870e6879335436f3c5cffa63d5259f7a2e6789f46ec7a5bdaff86c7449115b(
    value: typing.Optional[ServiceLevelObjective],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f53affb60bc009815cfebdb1a79bac9dbddb04f25be9d30994b9143b035f85e7(
    *,
    rolling: typing.Union[ServiceLevelObjectiveTimeWindowRolling, typing.Dict[builtins.str, typing.Any]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4226423bebd9f442a4b34c99d69ba1b6216f09465ee5e45bdd2a54de054ea881(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2ddf624c849ae63789143b32ea92e409752d26445735ef9f32e9d63f54125eeb(
    value: typing.Optional[ServiceLevelObjectiveTimeWindow],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__733c87123c9a2cbb373336b18d89dba68f0ef12fccf8371db9014333bd5c4084(
    *,
    count: jsii.Number,
    unit: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4df89e87f9e6c274e41ad73173c76e6ff116b2fc2e5cc35d823110431826c5b0(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7fd032e9757c390c1c05a334ac1388ac1225225f1079af0658185e68b545ca76(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__779aeb4dabccaf1e66faf74c17aa1a867cc16ff821fa72d3d8647d3868121b2c(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b043f0494e1d08eaadd6cbaa09f3c6c044a89bbb8b65baa76879cd43592b6b09(
    value: typing.Optional[ServiceLevelObjectiveTimeWindowRolling],
) -> None:
    """Type checking stubs"""
    pass
