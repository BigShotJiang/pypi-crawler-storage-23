r'''
# `newrelic_cloud_gcp_integrations`

Refer to the Terraform Registry for docs: [`newrelic_cloud_gcp_integrations`](https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations).
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import cdktn as _cdktn_78ede62e
import constructs as _constructs_77d1e7e8


class CloudGcpIntegrations(
    _cdktn_78ede62e.TerraformResource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrations",
):
    '''Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations newrelic_cloud_gcp_integrations}.'''

    def __init__(
        self,
        scope: _constructs_77d1e7e8.Construct,
        id_: builtins.str,
        *,
        linked_account_id: jsii.Number,
        account_id: typing.Optional[jsii.Number] = None,
        alloy_db: typing.Optional[typing.Union["CloudGcpIntegrationsAlloyDb", typing.Dict[builtins.str, typing.Any]]] = None,
        app_engine: typing.Optional[typing.Union["CloudGcpIntegrationsAppEngine", typing.Dict[builtins.str, typing.Any]]] = None,
        big_query: typing.Optional[typing.Union["CloudGcpIntegrationsBigQuery", typing.Dict[builtins.str, typing.Any]]] = None,
        big_table: typing.Optional[typing.Union["CloudGcpIntegrationsBigTable", typing.Dict[builtins.str, typing.Any]]] = None,
        composer: typing.Optional[typing.Union["CloudGcpIntegrationsComposer", typing.Dict[builtins.str, typing.Any]]] = None,
        data_flow: typing.Optional[typing.Union["CloudGcpIntegrationsDataFlow", typing.Dict[builtins.str, typing.Any]]] = None,
        data_proc: typing.Optional[typing.Union["CloudGcpIntegrationsDataProc", typing.Dict[builtins.str, typing.Any]]] = None,
        data_store: typing.Optional[typing.Union["CloudGcpIntegrationsDataStore", typing.Dict[builtins.str, typing.Any]]] = None,
        fire_base_database: typing.Optional[typing.Union["CloudGcpIntegrationsFireBaseDatabase", typing.Dict[builtins.str, typing.Any]]] = None,
        fire_base_hosting: typing.Optional[typing.Union["CloudGcpIntegrationsFireBaseHosting", typing.Dict[builtins.str, typing.Any]]] = None,
        fire_base_storage: typing.Optional[typing.Union["CloudGcpIntegrationsFireBaseStorage", typing.Dict[builtins.str, typing.Any]]] = None,
        fire_store: typing.Optional[typing.Union["CloudGcpIntegrationsFireStore", typing.Dict[builtins.str, typing.Any]]] = None,
        functions: typing.Optional[typing.Union["CloudGcpIntegrationsFunctions", typing.Dict[builtins.str, typing.Any]]] = None,
        id: typing.Optional[builtins.str] = None,
        interconnect: typing.Optional[typing.Union["CloudGcpIntegrationsInterconnect", typing.Dict[builtins.str, typing.Any]]] = None,
        kubernetes: typing.Optional[typing.Union["CloudGcpIntegrationsKubernetes", typing.Dict[builtins.str, typing.Any]]] = None,
        load_balancing: typing.Optional[typing.Union["CloudGcpIntegrationsLoadBalancing", typing.Dict[builtins.str, typing.Any]]] = None,
        mem_cache: typing.Optional[typing.Union["CloudGcpIntegrationsMemCache", typing.Dict[builtins.str, typing.Any]]] = None,
        pub_sub: typing.Optional[typing.Union["CloudGcpIntegrationsPubSub", typing.Dict[builtins.str, typing.Any]]] = None,
        redis: typing.Optional[typing.Union["CloudGcpIntegrationsRedis", typing.Dict[builtins.str, typing.Any]]] = None,
        router: typing.Optional[typing.Union["CloudGcpIntegrationsRouter", typing.Dict[builtins.str, typing.Any]]] = None,
        run: typing.Optional[typing.Union["CloudGcpIntegrationsRun", typing.Dict[builtins.str, typing.Any]]] = None,
        spanner: typing.Optional[typing.Union["CloudGcpIntegrationsSpanner", typing.Dict[builtins.str, typing.Any]]] = None,
        sql: typing.Optional[typing.Union["CloudGcpIntegrationsSql", typing.Dict[builtins.str, typing.Any]]] = None,
        storage: typing.Optional[typing.Union["CloudGcpIntegrationsStorage", typing.Dict[builtins.str, typing.Any]]] = None,
        virtual_machines: typing.Optional[typing.Union["CloudGcpIntegrationsVirtualMachines", typing.Dict[builtins.str, typing.Any]]] = None,
        vpc_access: typing.Optional[typing.Union["CloudGcpIntegrationsVpcAccess", typing.Dict[builtins.str, typing.Any]]] = None,
        connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations newrelic_cloud_gcp_integrations} Resource.

        :param scope: The scope in which to define this construct.
        :param id_: The scoped construct ID. Must be unique amongst siblings in the same scope
        :param linked_account_id: Id of the linked gcp account in New Relic. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#linked_account_id CloudGcpIntegrations#linked_account_id}
        :param account_id: ID of the newrelic account. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#account_id CloudGcpIntegrations#account_id}
        :param alloy_db: alloy_db block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#alloy_db CloudGcpIntegrations#alloy_db}
        :param app_engine: app_engine block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#app_engine CloudGcpIntegrations#app_engine}
        :param big_query: big_query block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#big_query CloudGcpIntegrations#big_query}
        :param big_table: big_table block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#big_table CloudGcpIntegrations#big_table}
        :param composer: composer block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#composer CloudGcpIntegrations#composer}
        :param data_flow: data_flow block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#data_flow CloudGcpIntegrations#data_flow}
        :param data_proc: data_proc block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#data_proc CloudGcpIntegrations#data_proc}
        :param data_store: data_store block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#data_store CloudGcpIntegrations#data_store}
        :param fire_base_database: fire_base_database block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#fire_base_database CloudGcpIntegrations#fire_base_database}
        :param fire_base_hosting: fire_base_hosting block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#fire_base_hosting CloudGcpIntegrations#fire_base_hosting}
        :param fire_base_storage: fire_base_storage block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#fire_base_storage CloudGcpIntegrations#fire_base_storage}
        :param fire_store: fire_store block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#fire_store CloudGcpIntegrations#fire_store}
        :param functions: functions block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#functions CloudGcpIntegrations#functions}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#id CloudGcpIntegrations#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param interconnect: interconnect block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#interconnect CloudGcpIntegrations#interconnect}
        :param kubernetes: kubernetes block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#kubernetes CloudGcpIntegrations#kubernetes}
        :param load_balancing: load_balancing block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#load_balancing CloudGcpIntegrations#load_balancing}
        :param mem_cache: mem_cache block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#mem_cache CloudGcpIntegrations#mem_cache}
        :param pub_sub: pub_sub block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#pub_sub CloudGcpIntegrations#pub_sub}
        :param redis: redis block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#redis CloudGcpIntegrations#redis}
        :param router: router block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#router CloudGcpIntegrations#router}
        :param run: run block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#run CloudGcpIntegrations#run}
        :param spanner: spanner block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#spanner CloudGcpIntegrations#spanner}
        :param sql: sql block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#sql CloudGcpIntegrations#sql}
        :param storage: storage block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#storage CloudGcpIntegrations#storage}
        :param virtual_machines: virtual_machines block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#virtual_machines CloudGcpIntegrations#virtual_machines}
        :param vpc_access: vpc_access block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#vpc_access CloudGcpIntegrations#vpc_access}
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ffd1472025c1d6780cebc75980a67d1aedcc8e61697adb6430f8af8623af40d3)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id_", value=id_, expected_type=type_hints["id_"])
        config = CloudGcpIntegrationsConfig(
            linked_account_id=linked_account_id,
            account_id=account_id,
            alloy_db=alloy_db,
            app_engine=app_engine,
            big_query=big_query,
            big_table=big_table,
            composer=composer,
            data_flow=data_flow,
            data_proc=data_proc,
            data_store=data_store,
            fire_base_database=fire_base_database,
            fire_base_hosting=fire_base_hosting,
            fire_base_storage=fire_base_storage,
            fire_store=fire_store,
            functions=functions,
            id=id,
            interconnect=interconnect,
            kubernetes=kubernetes,
            load_balancing=load_balancing,
            mem_cache=mem_cache,
            pub_sub=pub_sub,
            redis=redis,
            router=router,
            run=run,
            spanner=spanner,
            sql=sql,
            storage=storage,
            virtual_machines=virtual_machines,
            vpc_access=vpc_access,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        jsii.create(self.__class__, self, [scope, id_, config])

    @jsii.member(jsii_name="generateConfigForImport")
    @builtins.classmethod
    def generate_config_for_import(
        cls,
        scope: _constructs_77d1e7e8.Construct,
        import_to_id: builtins.str,
        import_from_id: builtins.str,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    ) -> _cdktn_78ede62e.ImportableResource:
        '''Generates CDKTN code for importing a CloudGcpIntegrations resource upon running "cdktn plan ".

        :param scope: The scope in which to define this construct.
        :param import_to_id: The construct id used in the generated config for the CloudGcpIntegrations to import.
        :param import_from_id: The id of the existing CloudGcpIntegrations that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#import import section} in the documentation of this resource for the id to use
        :param provider: ? Optional instance of the provider where the CloudGcpIntegrations to import is found.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__71cbc4136fbf6cdeea8b0d6ab5401f4f4668f7011e436e10ad92e6e4cc05d2ba)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument import_to_id", value=import_to_id, expected_type=type_hints["import_to_id"])
            check_type(argname="argument import_from_id", value=import_from_id, expected_type=type_hints["import_from_id"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
        return typing.cast(_cdktn_78ede62e.ImportableResource, jsii.sinvoke(cls, "generateConfigForImport", [scope, import_to_id, import_from_id, provider]))

    @jsii.member(jsii_name="putAlloyDb")
    def put_alloy_db(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        value = CloudGcpIntegrationsAlloyDb(
            metrics_polling_interval=metrics_polling_interval
        )

        return typing.cast(None, jsii.invoke(self, "putAlloyDb", [value]))

    @jsii.member(jsii_name="putAppEngine")
    def put_app_engine(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        value = CloudGcpIntegrationsAppEngine(
            metrics_polling_interval=metrics_polling_interval
        )

        return typing.cast(None, jsii.invoke(self, "putAppEngine", [value]))

    @jsii.member(jsii_name="putBigQuery")
    def put_big_query(
        self,
        *,
        fetch_tags: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param fetch_tags: to fetch tags of the resource. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#fetch_tags CloudGcpIntegrations#fetch_tags}
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        value = CloudGcpIntegrationsBigQuery(
            fetch_tags=fetch_tags, metrics_polling_interval=metrics_polling_interval
        )

        return typing.cast(None, jsii.invoke(self, "putBigQuery", [value]))

    @jsii.member(jsii_name="putBigTable")
    def put_big_table(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        value = CloudGcpIntegrationsBigTable(
            metrics_polling_interval=metrics_polling_interval
        )

        return typing.cast(None, jsii.invoke(self, "putBigTable", [value]))

    @jsii.member(jsii_name="putComposer")
    def put_composer(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        value = CloudGcpIntegrationsComposer(
            metrics_polling_interval=metrics_polling_interval
        )

        return typing.cast(None, jsii.invoke(self, "putComposer", [value]))

    @jsii.member(jsii_name="putDataFlow")
    def put_data_flow(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        value = CloudGcpIntegrationsDataFlow(
            metrics_polling_interval=metrics_polling_interval
        )

        return typing.cast(None, jsii.invoke(self, "putDataFlow", [value]))

    @jsii.member(jsii_name="putDataProc")
    def put_data_proc(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        value = CloudGcpIntegrationsDataProc(
            metrics_polling_interval=metrics_polling_interval
        )

        return typing.cast(None, jsii.invoke(self, "putDataProc", [value]))

    @jsii.member(jsii_name="putDataStore")
    def put_data_store(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        value = CloudGcpIntegrationsDataStore(
            metrics_polling_interval=metrics_polling_interval
        )

        return typing.cast(None, jsii.invoke(self, "putDataStore", [value]))

    @jsii.member(jsii_name="putFireBaseDatabase")
    def put_fire_base_database(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        value = CloudGcpIntegrationsFireBaseDatabase(
            metrics_polling_interval=metrics_polling_interval
        )

        return typing.cast(None, jsii.invoke(self, "putFireBaseDatabase", [value]))

    @jsii.member(jsii_name="putFireBaseHosting")
    def put_fire_base_hosting(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        value = CloudGcpIntegrationsFireBaseHosting(
            metrics_polling_interval=metrics_polling_interval
        )

        return typing.cast(None, jsii.invoke(self, "putFireBaseHosting", [value]))

    @jsii.member(jsii_name="putFireBaseStorage")
    def put_fire_base_storage(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        value = CloudGcpIntegrationsFireBaseStorage(
            metrics_polling_interval=metrics_polling_interval
        )

        return typing.cast(None, jsii.invoke(self, "putFireBaseStorage", [value]))

    @jsii.member(jsii_name="putFireStore")
    def put_fire_store(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        value = CloudGcpIntegrationsFireStore(
            metrics_polling_interval=metrics_polling_interval
        )

        return typing.cast(None, jsii.invoke(self, "putFireStore", [value]))

    @jsii.member(jsii_name="putFunctions")
    def put_functions(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        value = CloudGcpIntegrationsFunctions(
            metrics_polling_interval=metrics_polling_interval
        )

        return typing.cast(None, jsii.invoke(self, "putFunctions", [value]))

    @jsii.member(jsii_name="putInterconnect")
    def put_interconnect(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        value = CloudGcpIntegrationsInterconnect(
            metrics_polling_interval=metrics_polling_interval
        )

        return typing.cast(None, jsii.invoke(self, "putInterconnect", [value]))

    @jsii.member(jsii_name="putKubernetes")
    def put_kubernetes(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        value = CloudGcpIntegrationsKubernetes(
            metrics_polling_interval=metrics_polling_interval
        )

        return typing.cast(None, jsii.invoke(self, "putKubernetes", [value]))

    @jsii.member(jsii_name="putLoadBalancing")
    def put_load_balancing(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        value = CloudGcpIntegrationsLoadBalancing(
            metrics_polling_interval=metrics_polling_interval
        )

        return typing.cast(None, jsii.invoke(self, "putLoadBalancing", [value]))

    @jsii.member(jsii_name="putMemCache")
    def put_mem_cache(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        value = CloudGcpIntegrationsMemCache(
            metrics_polling_interval=metrics_polling_interval
        )

        return typing.cast(None, jsii.invoke(self, "putMemCache", [value]))

    @jsii.member(jsii_name="putPubSub")
    def put_pub_sub(
        self,
        *,
        fetch_tags: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param fetch_tags: to fetch tags of the resource. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#fetch_tags CloudGcpIntegrations#fetch_tags}
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        value = CloudGcpIntegrationsPubSub(
            fetch_tags=fetch_tags, metrics_polling_interval=metrics_polling_interval
        )

        return typing.cast(None, jsii.invoke(self, "putPubSub", [value]))

    @jsii.member(jsii_name="putRedis")
    def put_redis(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        value = CloudGcpIntegrationsRedis(
            metrics_polling_interval=metrics_polling_interval
        )

        return typing.cast(None, jsii.invoke(self, "putRedis", [value]))

    @jsii.member(jsii_name="putRouter")
    def put_router(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        value = CloudGcpIntegrationsRouter(
            metrics_polling_interval=metrics_polling_interval
        )

        return typing.cast(None, jsii.invoke(self, "putRouter", [value]))

    @jsii.member(jsii_name="putRun")
    def put_run(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        value = CloudGcpIntegrationsRun(
            metrics_polling_interval=metrics_polling_interval
        )

        return typing.cast(None, jsii.invoke(self, "putRun", [value]))

    @jsii.member(jsii_name="putSpanner")
    def put_spanner(
        self,
        *,
        fetch_tags: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param fetch_tags: to fetch tags of the resource. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#fetch_tags CloudGcpIntegrations#fetch_tags}
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        value = CloudGcpIntegrationsSpanner(
            fetch_tags=fetch_tags, metrics_polling_interval=metrics_polling_interval
        )

        return typing.cast(None, jsii.invoke(self, "putSpanner", [value]))

    @jsii.member(jsii_name="putSql")
    def put_sql(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        value = CloudGcpIntegrationsSql(
            metrics_polling_interval=metrics_polling_interval
        )

        return typing.cast(None, jsii.invoke(self, "putSql", [value]))

    @jsii.member(jsii_name="putStorage")
    def put_storage(
        self,
        *,
        fetch_tags: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param fetch_tags: to fetch tags of the resource. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#fetch_tags CloudGcpIntegrations#fetch_tags}
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        value = CloudGcpIntegrationsStorage(
            fetch_tags=fetch_tags, metrics_polling_interval=metrics_polling_interval
        )

        return typing.cast(None, jsii.invoke(self, "putStorage", [value]))

    @jsii.member(jsii_name="putVirtualMachines")
    def put_virtual_machines(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        value = CloudGcpIntegrationsVirtualMachines(
            metrics_polling_interval=metrics_polling_interval
        )

        return typing.cast(None, jsii.invoke(self, "putVirtualMachines", [value]))

    @jsii.member(jsii_name="putVpcAccess")
    def put_vpc_access(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        value = CloudGcpIntegrationsVpcAccess(
            metrics_polling_interval=metrics_polling_interval
        )

        return typing.cast(None, jsii.invoke(self, "putVpcAccess", [value]))

    @jsii.member(jsii_name="resetAccountId")
    def reset_account_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAccountId", []))

    @jsii.member(jsii_name="resetAlloyDb")
    def reset_alloy_db(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAlloyDb", []))

    @jsii.member(jsii_name="resetAppEngine")
    def reset_app_engine(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAppEngine", []))

    @jsii.member(jsii_name="resetBigQuery")
    def reset_big_query(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetBigQuery", []))

    @jsii.member(jsii_name="resetBigTable")
    def reset_big_table(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetBigTable", []))

    @jsii.member(jsii_name="resetComposer")
    def reset_composer(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetComposer", []))

    @jsii.member(jsii_name="resetDataFlow")
    def reset_data_flow(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDataFlow", []))

    @jsii.member(jsii_name="resetDataProc")
    def reset_data_proc(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDataProc", []))

    @jsii.member(jsii_name="resetDataStore")
    def reset_data_store(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDataStore", []))

    @jsii.member(jsii_name="resetFireBaseDatabase")
    def reset_fire_base_database(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFireBaseDatabase", []))

    @jsii.member(jsii_name="resetFireBaseHosting")
    def reset_fire_base_hosting(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFireBaseHosting", []))

    @jsii.member(jsii_name="resetFireBaseStorage")
    def reset_fire_base_storage(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFireBaseStorage", []))

    @jsii.member(jsii_name="resetFireStore")
    def reset_fire_store(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFireStore", []))

    @jsii.member(jsii_name="resetFunctions")
    def reset_functions(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFunctions", []))

    @jsii.member(jsii_name="resetId")
    def reset_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetId", []))

    @jsii.member(jsii_name="resetInterconnect")
    def reset_interconnect(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetInterconnect", []))

    @jsii.member(jsii_name="resetKubernetes")
    def reset_kubernetes(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetKubernetes", []))

    @jsii.member(jsii_name="resetLoadBalancing")
    def reset_load_balancing(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetLoadBalancing", []))

    @jsii.member(jsii_name="resetMemCache")
    def reset_mem_cache(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMemCache", []))

    @jsii.member(jsii_name="resetPubSub")
    def reset_pub_sub(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPubSub", []))

    @jsii.member(jsii_name="resetRedis")
    def reset_redis(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRedis", []))

    @jsii.member(jsii_name="resetRouter")
    def reset_router(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRouter", []))

    @jsii.member(jsii_name="resetRun")
    def reset_run(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRun", []))

    @jsii.member(jsii_name="resetSpanner")
    def reset_spanner(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSpanner", []))

    @jsii.member(jsii_name="resetSql")
    def reset_sql(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSql", []))

    @jsii.member(jsii_name="resetStorage")
    def reset_storage(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetStorage", []))

    @jsii.member(jsii_name="resetVirtualMachines")
    def reset_virtual_machines(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetVirtualMachines", []))

    @jsii.member(jsii_name="resetVpcAccess")
    def reset_vpc_access(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetVpcAccess", []))

    @jsii.member(jsii_name="synthesizeAttributes")
    def _synthesize_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeAttributes", []))

    @jsii.member(jsii_name="synthesizeHclAttributes")
    def _synthesize_hcl_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeHclAttributes", []))

    @jsii.python.classproperty
    @jsii.member(jsii_name="tfResourceType")
    def TF_RESOURCE_TYPE(cls) -> builtins.str:
        return typing.cast(builtins.str, jsii.sget(cls, "tfResourceType"))

    @builtins.property
    @jsii.member(jsii_name="alloyDb")
    def alloy_db(self) -> "CloudGcpIntegrationsAlloyDbOutputReference":
        return typing.cast("CloudGcpIntegrationsAlloyDbOutputReference", jsii.get(self, "alloyDb"))

    @builtins.property
    @jsii.member(jsii_name="appEngine")
    def app_engine(self) -> "CloudGcpIntegrationsAppEngineOutputReference":
        return typing.cast("CloudGcpIntegrationsAppEngineOutputReference", jsii.get(self, "appEngine"))

    @builtins.property
    @jsii.member(jsii_name="bigQuery")
    def big_query(self) -> "CloudGcpIntegrationsBigQueryOutputReference":
        return typing.cast("CloudGcpIntegrationsBigQueryOutputReference", jsii.get(self, "bigQuery"))

    @builtins.property
    @jsii.member(jsii_name="bigTable")
    def big_table(self) -> "CloudGcpIntegrationsBigTableOutputReference":
        return typing.cast("CloudGcpIntegrationsBigTableOutputReference", jsii.get(self, "bigTable"))

    @builtins.property
    @jsii.member(jsii_name="composer")
    def composer(self) -> "CloudGcpIntegrationsComposerOutputReference":
        return typing.cast("CloudGcpIntegrationsComposerOutputReference", jsii.get(self, "composer"))

    @builtins.property
    @jsii.member(jsii_name="dataFlow")
    def data_flow(self) -> "CloudGcpIntegrationsDataFlowOutputReference":
        return typing.cast("CloudGcpIntegrationsDataFlowOutputReference", jsii.get(self, "dataFlow"))

    @builtins.property
    @jsii.member(jsii_name="dataProc")
    def data_proc(self) -> "CloudGcpIntegrationsDataProcOutputReference":
        return typing.cast("CloudGcpIntegrationsDataProcOutputReference", jsii.get(self, "dataProc"))

    @builtins.property
    @jsii.member(jsii_name="dataStore")
    def data_store(self) -> "CloudGcpIntegrationsDataStoreOutputReference":
        return typing.cast("CloudGcpIntegrationsDataStoreOutputReference", jsii.get(self, "dataStore"))

    @builtins.property
    @jsii.member(jsii_name="fireBaseDatabase")
    def fire_base_database(
        self,
    ) -> "CloudGcpIntegrationsFireBaseDatabaseOutputReference":
        return typing.cast("CloudGcpIntegrationsFireBaseDatabaseOutputReference", jsii.get(self, "fireBaseDatabase"))

    @builtins.property
    @jsii.member(jsii_name="fireBaseHosting")
    def fire_base_hosting(self) -> "CloudGcpIntegrationsFireBaseHostingOutputReference":
        return typing.cast("CloudGcpIntegrationsFireBaseHostingOutputReference", jsii.get(self, "fireBaseHosting"))

    @builtins.property
    @jsii.member(jsii_name="fireBaseStorage")
    def fire_base_storage(self) -> "CloudGcpIntegrationsFireBaseStorageOutputReference":
        return typing.cast("CloudGcpIntegrationsFireBaseStorageOutputReference", jsii.get(self, "fireBaseStorage"))

    @builtins.property
    @jsii.member(jsii_name="fireStore")
    def fire_store(self) -> "CloudGcpIntegrationsFireStoreOutputReference":
        return typing.cast("CloudGcpIntegrationsFireStoreOutputReference", jsii.get(self, "fireStore"))

    @builtins.property
    @jsii.member(jsii_name="functions")
    def functions(self) -> "CloudGcpIntegrationsFunctionsOutputReference":
        return typing.cast("CloudGcpIntegrationsFunctionsOutputReference", jsii.get(self, "functions"))

    @builtins.property
    @jsii.member(jsii_name="interconnect")
    def interconnect(self) -> "CloudGcpIntegrationsInterconnectOutputReference":
        return typing.cast("CloudGcpIntegrationsInterconnectOutputReference", jsii.get(self, "interconnect"))

    @builtins.property
    @jsii.member(jsii_name="kubernetes")
    def kubernetes(self) -> "CloudGcpIntegrationsKubernetesOutputReference":
        return typing.cast("CloudGcpIntegrationsKubernetesOutputReference", jsii.get(self, "kubernetes"))

    @builtins.property
    @jsii.member(jsii_name="loadBalancing")
    def load_balancing(self) -> "CloudGcpIntegrationsLoadBalancingOutputReference":
        return typing.cast("CloudGcpIntegrationsLoadBalancingOutputReference", jsii.get(self, "loadBalancing"))

    @builtins.property
    @jsii.member(jsii_name="memCache")
    def mem_cache(self) -> "CloudGcpIntegrationsMemCacheOutputReference":
        return typing.cast("CloudGcpIntegrationsMemCacheOutputReference", jsii.get(self, "memCache"))

    @builtins.property
    @jsii.member(jsii_name="pubSub")
    def pub_sub(self) -> "CloudGcpIntegrationsPubSubOutputReference":
        return typing.cast("CloudGcpIntegrationsPubSubOutputReference", jsii.get(self, "pubSub"))

    @builtins.property
    @jsii.member(jsii_name="redis")
    def redis(self) -> "CloudGcpIntegrationsRedisOutputReference":
        return typing.cast("CloudGcpIntegrationsRedisOutputReference", jsii.get(self, "redis"))

    @builtins.property
    @jsii.member(jsii_name="router")
    def router(self) -> "CloudGcpIntegrationsRouterOutputReference":
        return typing.cast("CloudGcpIntegrationsRouterOutputReference", jsii.get(self, "router"))

    @builtins.property
    @jsii.member(jsii_name="run")
    def run(self) -> "CloudGcpIntegrationsRunOutputReference":
        return typing.cast("CloudGcpIntegrationsRunOutputReference", jsii.get(self, "run"))

    @builtins.property
    @jsii.member(jsii_name="spanner")
    def spanner(self) -> "CloudGcpIntegrationsSpannerOutputReference":
        return typing.cast("CloudGcpIntegrationsSpannerOutputReference", jsii.get(self, "spanner"))

    @builtins.property
    @jsii.member(jsii_name="sql")
    def sql(self) -> "CloudGcpIntegrationsSqlOutputReference":
        return typing.cast("CloudGcpIntegrationsSqlOutputReference", jsii.get(self, "sql"))

    @builtins.property
    @jsii.member(jsii_name="storage")
    def storage(self) -> "CloudGcpIntegrationsStorageOutputReference":
        return typing.cast("CloudGcpIntegrationsStorageOutputReference", jsii.get(self, "storage"))

    @builtins.property
    @jsii.member(jsii_name="virtualMachines")
    def virtual_machines(self) -> "CloudGcpIntegrationsVirtualMachinesOutputReference":
        return typing.cast("CloudGcpIntegrationsVirtualMachinesOutputReference", jsii.get(self, "virtualMachines"))

    @builtins.property
    @jsii.member(jsii_name="vpcAccess")
    def vpc_access(self) -> "CloudGcpIntegrationsVpcAccessOutputReference":
        return typing.cast("CloudGcpIntegrationsVpcAccessOutputReference", jsii.get(self, "vpcAccess"))

    @builtins.property
    @jsii.member(jsii_name="accountIdInput")
    def account_id_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "accountIdInput"))

    @builtins.property
    @jsii.member(jsii_name="alloyDbInput")
    def alloy_db_input(self) -> typing.Optional["CloudGcpIntegrationsAlloyDb"]:
        return typing.cast(typing.Optional["CloudGcpIntegrationsAlloyDb"], jsii.get(self, "alloyDbInput"))

    @builtins.property
    @jsii.member(jsii_name="appEngineInput")
    def app_engine_input(self) -> typing.Optional["CloudGcpIntegrationsAppEngine"]:
        return typing.cast(typing.Optional["CloudGcpIntegrationsAppEngine"], jsii.get(self, "appEngineInput"))

    @builtins.property
    @jsii.member(jsii_name="bigQueryInput")
    def big_query_input(self) -> typing.Optional["CloudGcpIntegrationsBigQuery"]:
        return typing.cast(typing.Optional["CloudGcpIntegrationsBigQuery"], jsii.get(self, "bigQueryInput"))

    @builtins.property
    @jsii.member(jsii_name="bigTableInput")
    def big_table_input(self) -> typing.Optional["CloudGcpIntegrationsBigTable"]:
        return typing.cast(typing.Optional["CloudGcpIntegrationsBigTable"], jsii.get(self, "bigTableInput"))

    @builtins.property
    @jsii.member(jsii_name="composerInput")
    def composer_input(self) -> typing.Optional["CloudGcpIntegrationsComposer"]:
        return typing.cast(typing.Optional["CloudGcpIntegrationsComposer"], jsii.get(self, "composerInput"))

    @builtins.property
    @jsii.member(jsii_name="dataFlowInput")
    def data_flow_input(self) -> typing.Optional["CloudGcpIntegrationsDataFlow"]:
        return typing.cast(typing.Optional["CloudGcpIntegrationsDataFlow"], jsii.get(self, "dataFlowInput"))

    @builtins.property
    @jsii.member(jsii_name="dataProcInput")
    def data_proc_input(self) -> typing.Optional["CloudGcpIntegrationsDataProc"]:
        return typing.cast(typing.Optional["CloudGcpIntegrationsDataProc"], jsii.get(self, "dataProcInput"))

    @builtins.property
    @jsii.member(jsii_name="dataStoreInput")
    def data_store_input(self) -> typing.Optional["CloudGcpIntegrationsDataStore"]:
        return typing.cast(typing.Optional["CloudGcpIntegrationsDataStore"], jsii.get(self, "dataStoreInput"))

    @builtins.property
    @jsii.member(jsii_name="fireBaseDatabaseInput")
    def fire_base_database_input(
        self,
    ) -> typing.Optional["CloudGcpIntegrationsFireBaseDatabase"]:
        return typing.cast(typing.Optional["CloudGcpIntegrationsFireBaseDatabase"], jsii.get(self, "fireBaseDatabaseInput"))

    @builtins.property
    @jsii.member(jsii_name="fireBaseHostingInput")
    def fire_base_hosting_input(
        self,
    ) -> typing.Optional["CloudGcpIntegrationsFireBaseHosting"]:
        return typing.cast(typing.Optional["CloudGcpIntegrationsFireBaseHosting"], jsii.get(self, "fireBaseHostingInput"))

    @builtins.property
    @jsii.member(jsii_name="fireBaseStorageInput")
    def fire_base_storage_input(
        self,
    ) -> typing.Optional["CloudGcpIntegrationsFireBaseStorage"]:
        return typing.cast(typing.Optional["CloudGcpIntegrationsFireBaseStorage"], jsii.get(self, "fireBaseStorageInput"))

    @builtins.property
    @jsii.member(jsii_name="fireStoreInput")
    def fire_store_input(self) -> typing.Optional["CloudGcpIntegrationsFireStore"]:
        return typing.cast(typing.Optional["CloudGcpIntegrationsFireStore"], jsii.get(self, "fireStoreInput"))

    @builtins.property
    @jsii.member(jsii_name="functionsInput")
    def functions_input(self) -> typing.Optional["CloudGcpIntegrationsFunctions"]:
        return typing.cast(typing.Optional["CloudGcpIntegrationsFunctions"], jsii.get(self, "functionsInput"))

    @builtins.property
    @jsii.member(jsii_name="idInput")
    def id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "idInput"))

    @builtins.property
    @jsii.member(jsii_name="interconnectInput")
    def interconnect_input(self) -> typing.Optional["CloudGcpIntegrationsInterconnect"]:
        return typing.cast(typing.Optional["CloudGcpIntegrationsInterconnect"], jsii.get(self, "interconnectInput"))

    @builtins.property
    @jsii.member(jsii_name="kubernetesInput")
    def kubernetes_input(self) -> typing.Optional["CloudGcpIntegrationsKubernetes"]:
        return typing.cast(typing.Optional["CloudGcpIntegrationsKubernetes"], jsii.get(self, "kubernetesInput"))

    @builtins.property
    @jsii.member(jsii_name="linkedAccountIdInput")
    def linked_account_id_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "linkedAccountIdInput"))

    @builtins.property
    @jsii.member(jsii_name="loadBalancingInput")
    def load_balancing_input(
        self,
    ) -> typing.Optional["CloudGcpIntegrationsLoadBalancing"]:
        return typing.cast(typing.Optional["CloudGcpIntegrationsLoadBalancing"], jsii.get(self, "loadBalancingInput"))

    @builtins.property
    @jsii.member(jsii_name="memCacheInput")
    def mem_cache_input(self) -> typing.Optional["CloudGcpIntegrationsMemCache"]:
        return typing.cast(typing.Optional["CloudGcpIntegrationsMemCache"], jsii.get(self, "memCacheInput"))

    @builtins.property
    @jsii.member(jsii_name="pubSubInput")
    def pub_sub_input(self) -> typing.Optional["CloudGcpIntegrationsPubSub"]:
        return typing.cast(typing.Optional["CloudGcpIntegrationsPubSub"], jsii.get(self, "pubSubInput"))

    @builtins.property
    @jsii.member(jsii_name="redisInput")
    def redis_input(self) -> typing.Optional["CloudGcpIntegrationsRedis"]:
        return typing.cast(typing.Optional["CloudGcpIntegrationsRedis"], jsii.get(self, "redisInput"))

    @builtins.property
    @jsii.member(jsii_name="routerInput")
    def router_input(self) -> typing.Optional["CloudGcpIntegrationsRouter"]:
        return typing.cast(typing.Optional["CloudGcpIntegrationsRouter"], jsii.get(self, "routerInput"))

    @builtins.property
    @jsii.member(jsii_name="runInput")
    def run_input(self) -> typing.Optional["CloudGcpIntegrationsRun"]:
        return typing.cast(typing.Optional["CloudGcpIntegrationsRun"], jsii.get(self, "runInput"))

    @builtins.property
    @jsii.member(jsii_name="spannerInput")
    def spanner_input(self) -> typing.Optional["CloudGcpIntegrationsSpanner"]:
        return typing.cast(typing.Optional["CloudGcpIntegrationsSpanner"], jsii.get(self, "spannerInput"))

    @builtins.property
    @jsii.member(jsii_name="sqlInput")
    def sql_input(self) -> typing.Optional["CloudGcpIntegrationsSql"]:
        return typing.cast(typing.Optional["CloudGcpIntegrationsSql"], jsii.get(self, "sqlInput"))

    @builtins.property
    @jsii.member(jsii_name="storageInput")
    def storage_input(self) -> typing.Optional["CloudGcpIntegrationsStorage"]:
        return typing.cast(typing.Optional["CloudGcpIntegrationsStorage"], jsii.get(self, "storageInput"))

    @builtins.property
    @jsii.member(jsii_name="virtualMachinesInput")
    def virtual_machines_input(
        self,
    ) -> typing.Optional["CloudGcpIntegrationsVirtualMachines"]:
        return typing.cast(typing.Optional["CloudGcpIntegrationsVirtualMachines"], jsii.get(self, "virtualMachinesInput"))

    @builtins.property
    @jsii.member(jsii_name="vpcAccessInput")
    def vpc_access_input(self) -> typing.Optional["CloudGcpIntegrationsVpcAccess"]:
        return typing.cast(typing.Optional["CloudGcpIntegrationsVpcAccess"], jsii.get(self, "vpcAccessInput"))

    @builtins.property
    @jsii.member(jsii_name="accountId")
    def account_id(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "accountId"))

    @account_id.setter
    def account_id(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4fc05dbb1c0dea7eb3713bd3cb671ad2bfcf72019e2fdf989a6b2eca71c33d84)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "accountId", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @id.setter
    def id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8104a1a04d98ee1a775e1678d6ce04e8b4d58ef8b44ba17be95f876dae8b8178)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "id", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="linkedAccountId")
    def linked_account_id(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "linkedAccountId"))

    @linked_account_id.setter
    def linked_account_id(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4fd2af3256ab1f52f438b27f51f2b8d22ebbbefe7c45f66bc5798bddfe877f88)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "linkedAccountId", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsAlloyDb",
    jsii_struct_bases=[],
    name_mapping={"metrics_polling_interval": "metricsPollingInterval"},
)
class CloudGcpIntegrationsAlloyDb:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1735dffd38b60c32f9ba9bab6a50902d92f421c1f0370c1df54b87107ce9dd38)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''the data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudGcpIntegrationsAlloyDb(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudGcpIntegrationsAlloyDbOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsAlloyDbOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__593edc3eda9588b74c7fc34abf3b9621d81fd147371b52b5e034b2babf22980b)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2f2d7d918e329861fc56e890630c31a193fa64fbad408dabfb3bf4f35084aeea)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudGcpIntegrationsAlloyDb]:
        return typing.cast(typing.Optional[CloudGcpIntegrationsAlloyDb], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudGcpIntegrationsAlloyDb],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e37ca1b972f0e19601808623ce3ec3c2f625f474c1e4f213e3d78b7522ab58d0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsAppEngine",
    jsii_struct_bases=[],
    name_mapping={"metrics_polling_interval": "metricsPollingInterval"},
)
class CloudGcpIntegrationsAppEngine:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a848491eb6bc5e82ed3d4107263025654084e6de0d50f61b024937e34b98da36)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''the data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudGcpIntegrationsAppEngine(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudGcpIntegrationsAppEngineOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsAppEngineOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__be49ae75dfd49275ba9771a9c1ae31cbfc88e2a3a74b9937d3a8ef8ab464f164)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8a36f647260558fb7583075c40708f993e55dff211dbcd5b721257a7ff3bfbc1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudGcpIntegrationsAppEngine]:
        return typing.cast(typing.Optional[CloudGcpIntegrationsAppEngine], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudGcpIntegrationsAppEngine],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cb46584b7c29de7f5c7003a2d3ed3f0b0e58e2ffbe9b6e04989ab435bc8c643c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsBigQuery",
    jsii_struct_bases=[],
    name_mapping={
        "fetch_tags": "fetchTags",
        "metrics_polling_interval": "metricsPollingInterval",
    },
)
class CloudGcpIntegrationsBigQuery:
    def __init__(
        self,
        *,
        fetch_tags: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param fetch_tags: to fetch tags of the resource. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#fetch_tags CloudGcpIntegrations#fetch_tags}
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cd26bbc3dcf62913b1f56d3854467a31701d0337c7ba37bf032349905cf2b5fd)
            check_type(argname="argument fetch_tags", value=fetch_tags, expected_type=type_hints["fetch_tags"])
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if fetch_tags is not None:
            self._values["fetch_tags"] = fetch_tags
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval

    @builtins.property
    def fetch_tags(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''to fetch tags of the resource.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#fetch_tags CloudGcpIntegrations#fetch_tags}
        '''
        result = self._values.get("fetch_tags")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''the data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudGcpIntegrationsBigQuery(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudGcpIntegrationsBigQueryOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsBigQueryOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a42e7e6befebcdfb19afb827861f4be52de8e5ea04e67ecf3029c29f8b713a3a)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetFetchTags")
    def reset_fetch_tags(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFetchTags", []))

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @builtins.property
    @jsii.member(jsii_name="fetchTagsInput")
    def fetch_tags_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "fetchTagsInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="fetchTags")
    def fetch_tags(self) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "fetchTags"))

    @fetch_tags.setter
    def fetch_tags(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c89d9b5335abfdbe0920cbe0222c69f64e743c9dab09c82ac10d94e3a8c5a310)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "fetchTags", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7500769be7407cb4a913d33bc9e870842d459c42ac738189e27691b0c07058f1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudGcpIntegrationsBigQuery]:
        return typing.cast(typing.Optional[CloudGcpIntegrationsBigQuery], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudGcpIntegrationsBigQuery],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8eb6add486053c9fa7009b77252cd0fa63c046ccb31ac8aad5d8af44a588255b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsBigTable",
    jsii_struct_bases=[],
    name_mapping={"metrics_polling_interval": "metricsPollingInterval"},
)
class CloudGcpIntegrationsBigTable:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9846343744741859821cb3dfdacedd1b385bacb7377a7cc398c7cca7c6cd5089)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''the data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudGcpIntegrationsBigTable(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudGcpIntegrationsBigTableOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsBigTableOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__93e35c8a171260518232e931d8f58d8ba53a1182d66ef9dc6c41a2fe970bf6b4)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__dcd5cc1df1f635554a17f56428ae516eea667901056f8e666f5ac8d613c0e5e0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudGcpIntegrationsBigTable]:
        return typing.cast(typing.Optional[CloudGcpIntegrationsBigTable], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudGcpIntegrationsBigTable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2feff80015c7849e3c61c3a9ad3f494e6aa05c87592bb71125185cdefba407ee)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsComposer",
    jsii_struct_bases=[],
    name_mapping={"metrics_polling_interval": "metricsPollingInterval"},
)
class CloudGcpIntegrationsComposer:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a49806ec92cd9c96825298ac768d180ef16dce28863f7403918ee1426120949b)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''the data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudGcpIntegrationsComposer(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudGcpIntegrationsComposerOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsComposerOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9b045883568f08d0e0443b4c0fa4425c0550fdd212df5c424da64db3da6e1368)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ef1b1fb55b615ecf38f5e0bad6dc917a71dfa6ea88a72e0a74bc2f5160b24f59)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudGcpIntegrationsComposer]:
        return typing.cast(typing.Optional[CloudGcpIntegrationsComposer], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudGcpIntegrationsComposer],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__dfa3439b93a7a9dd34b4b565585c741c2c30b9cc715d0bfeb46ba000b8f1c122)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsConfig",
    jsii_struct_bases=[_cdktn_78ede62e.TerraformMetaArguments],
    name_mapping={
        "connection": "connection",
        "count": "count",
        "depends_on": "dependsOn",
        "for_each": "forEach",
        "lifecycle": "lifecycle",
        "provider": "provider",
        "provisioners": "provisioners",
        "linked_account_id": "linkedAccountId",
        "account_id": "accountId",
        "alloy_db": "alloyDb",
        "app_engine": "appEngine",
        "big_query": "bigQuery",
        "big_table": "bigTable",
        "composer": "composer",
        "data_flow": "dataFlow",
        "data_proc": "dataProc",
        "data_store": "dataStore",
        "fire_base_database": "fireBaseDatabase",
        "fire_base_hosting": "fireBaseHosting",
        "fire_base_storage": "fireBaseStorage",
        "fire_store": "fireStore",
        "functions": "functions",
        "id": "id",
        "interconnect": "interconnect",
        "kubernetes": "kubernetes",
        "load_balancing": "loadBalancing",
        "mem_cache": "memCache",
        "pub_sub": "pubSub",
        "redis": "redis",
        "router": "router",
        "run": "run",
        "spanner": "spanner",
        "sql": "sql",
        "storage": "storage",
        "virtual_machines": "virtualMachines",
        "vpc_access": "vpcAccess",
    },
)
class CloudGcpIntegrationsConfig(_cdktn_78ede62e.TerraformMetaArguments):
    def __init__(
        self,
        *,
        connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
        linked_account_id: jsii.Number,
        account_id: typing.Optional[jsii.Number] = None,
        alloy_db: typing.Optional[typing.Union[CloudGcpIntegrationsAlloyDb, typing.Dict[builtins.str, typing.Any]]] = None,
        app_engine: typing.Optional[typing.Union[CloudGcpIntegrationsAppEngine, typing.Dict[builtins.str, typing.Any]]] = None,
        big_query: typing.Optional[typing.Union[CloudGcpIntegrationsBigQuery, typing.Dict[builtins.str, typing.Any]]] = None,
        big_table: typing.Optional[typing.Union[CloudGcpIntegrationsBigTable, typing.Dict[builtins.str, typing.Any]]] = None,
        composer: typing.Optional[typing.Union[CloudGcpIntegrationsComposer, typing.Dict[builtins.str, typing.Any]]] = None,
        data_flow: typing.Optional[typing.Union["CloudGcpIntegrationsDataFlow", typing.Dict[builtins.str, typing.Any]]] = None,
        data_proc: typing.Optional[typing.Union["CloudGcpIntegrationsDataProc", typing.Dict[builtins.str, typing.Any]]] = None,
        data_store: typing.Optional[typing.Union["CloudGcpIntegrationsDataStore", typing.Dict[builtins.str, typing.Any]]] = None,
        fire_base_database: typing.Optional[typing.Union["CloudGcpIntegrationsFireBaseDatabase", typing.Dict[builtins.str, typing.Any]]] = None,
        fire_base_hosting: typing.Optional[typing.Union["CloudGcpIntegrationsFireBaseHosting", typing.Dict[builtins.str, typing.Any]]] = None,
        fire_base_storage: typing.Optional[typing.Union["CloudGcpIntegrationsFireBaseStorage", typing.Dict[builtins.str, typing.Any]]] = None,
        fire_store: typing.Optional[typing.Union["CloudGcpIntegrationsFireStore", typing.Dict[builtins.str, typing.Any]]] = None,
        functions: typing.Optional[typing.Union["CloudGcpIntegrationsFunctions", typing.Dict[builtins.str, typing.Any]]] = None,
        id: typing.Optional[builtins.str] = None,
        interconnect: typing.Optional[typing.Union["CloudGcpIntegrationsInterconnect", typing.Dict[builtins.str, typing.Any]]] = None,
        kubernetes: typing.Optional[typing.Union["CloudGcpIntegrationsKubernetes", typing.Dict[builtins.str, typing.Any]]] = None,
        load_balancing: typing.Optional[typing.Union["CloudGcpIntegrationsLoadBalancing", typing.Dict[builtins.str, typing.Any]]] = None,
        mem_cache: typing.Optional[typing.Union["CloudGcpIntegrationsMemCache", typing.Dict[builtins.str, typing.Any]]] = None,
        pub_sub: typing.Optional[typing.Union["CloudGcpIntegrationsPubSub", typing.Dict[builtins.str, typing.Any]]] = None,
        redis: typing.Optional[typing.Union["CloudGcpIntegrationsRedis", typing.Dict[builtins.str, typing.Any]]] = None,
        router: typing.Optional[typing.Union["CloudGcpIntegrationsRouter", typing.Dict[builtins.str, typing.Any]]] = None,
        run: typing.Optional[typing.Union["CloudGcpIntegrationsRun", typing.Dict[builtins.str, typing.Any]]] = None,
        spanner: typing.Optional[typing.Union["CloudGcpIntegrationsSpanner", typing.Dict[builtins.str, typing.Any]]] = None,
        sql: typing.Optional[typing.Union["CloudGcpIntegrationsSql", typing.Dict[builtins.str, typing.Any]]] = None,
        storage: typing.Optional[typing.Union["CloudGcpIntegrationsStorage", typing.Dict[builtins.str, typing.Any]]] = None,
        virtual_machines: typing.Optional[typing.Union["CloudGcpIntegrationsVirtualMachines", typing.Dict[builtins.str, typing.Any]]] = None,
        vpc_access: typing.Optional[typing.Union["CloudGcpIntegrationsVpcAccess", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        :param linked_account_id: Id of the linked gcp account in New Relic. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#linked_account_id CloudGcpIntegrations#linked_account_id}
        :param account_id: ID of the newrelic account. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#account_id CloudGcpIntegrations#account_id}
        :param alloy_db: alloy_db block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#alloy_db CloudGcpIntegrations#alloy_db}
        :param app_engine: app_engine block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#app_engine CloudGcpIntegrations#app_engine}
        :param big_query: big_query block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#big_query CloudGcpIntegrations#big_query}
        :param big_table: big_table block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#big_table CloudGcpIntegrations#big_table}
        :param composer: composer block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#composer CloudGcpIntegrations#composer}
        :param data_flow: data_flow block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#data_flow CloudGcpIntegrations#data_flow}
        :param data_proc: data_proc block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#data_proc CloudGcpIntegrations#data_proc}
        :param data_store: data_store block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#data_store CloudGcpIntegrations#data_store}
        :param fire_base_database: fire_base_database block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#fire_base_database CloudGcpIntegrations#fire_base_database}
        :param fire_base_hosting: fire_base_hosting block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#fire_base_hosting CloudGcpIntegrations#fire_base_hosting}
        :param fire_base_storage: fire_base_storage block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#fire_base_storage CloudGcpIntegrations#fire_base_storage}
        :param fire_store: fire_store block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#fire_store CloudGcpIntegrations#fire_store}
        :param functions: functions block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#functions CloudGcpIntegrations#functions}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#id CloudGcpIntegrations#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param interconnect: interconnect block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#interconnect CloudGcpIntegrations#interconnect}
        :param kubernetes: kubernetes block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#kubernetes CloudGcpIntegrations#kubernetes}
        :param load_balancing: load_balancing block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#load_balancing CloudGcpIntegrations#load_balancing}
        :param mem_cache: mem_cache block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#mem_cache CloudGcpIntegrations#mem_cache}
        :param pub_sub: pub_sub block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#pub_sub CloudGcpIntegrations#pub_sub}
        :param redis: redis block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#redis CloudGcpIntegrations#redis}
        :param router: router block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#router CloudGcpIntegrations#router}
        :param run: run block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#run CloudGcpIntegrations#run}
        :param spanner: spanner block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#spanner CloudGcpIntegrations#spanner}
        :param sql: sql block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#sql CloudGcpIntegrations#sql}
        :param storage: storage block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#storage CloudGcpIntegrations#storage}
        :param virtual_machines: virtual_machines block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#virtual_machines CloudGcpIntegrations#virtual_machines}
        :param vpc_access: vpc_access block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#vpc_access CloudGcpIntegrations#vpc_access}
        '''
        if isinstance(lifecycle, dict):
            lifecycle = _cdktn_78ede62e.TerraformResourceLifecycle(**lifecycle)
        if isinstance(alloy_db, dict):
            alloy_db = CloudGcpIntegrationsAlloyDb(**alloy_db)
        if isinstance(app_engine, dict):
            app_engine = CloudGcpIntegrationsAppEngine(**app_engine)
        if isinstance(big_query, dict):
            big_query = CloudGcpIntegrationsBigQuery(**big_query)
        if isinstance(big_table, dict):
            big_table = CloudGcpIntegrationsBigTable(**big_table)
        if isinstance(composer, dict):
            composer = CloudGcpIntegrationsComposer(**composer)
        if isinstance(data_flow, dict):
            data_flow = CloudGcpIntegrationsDataFlow(**data_flow)
        if isinstance(data_proc, dict):
            data_proc = CloudGcpIntegrationsDataProc(**data_proc)
        if isinstance(data_store, dict):
            data_store = CloudGcpIntegrationsDataStore(**data_store)
        if isinstance(fire_base_database, dict):
            fire_base_database = CloudGcpIntegrationsFireBaseDatabase(**fire_base_database)
        if isinstance(fire_base_hosting, dict):
            fire_base_hosting = CloudGcpIntegrationsFireBaseHosting(**fire_base_hosting)
        if isinstance(fire_base_storage, dict):
            fire_base_storage = CloudGcpIntegrationsFireBaseStorage(**fire_base_storage)
        if isinstance(fire_store, dict):
            fire_store = CloudGcpIntegrationsFireStore(**fire_store)
        if isinstance(functions, dict):
            functions = CloudGcpIntegrationsFunctions(**functions)
        if isinstance(interconnect, dict):
            interconnect = CloudGcpIntegrationsInterconnect(**interconnect)
        if isinstance(kubernetes, dict):
            kubernetes = CloudGcpIntegrationsKubernetes(**kubernetes)
        if isinstance(load_balancing, dict):
            load_balancing = CloudGcpIntegrationsLoadBalancing(**load_balancing)
        if isinstance(mem_cache, dict):
            mem_cache = CloudGcpIntegrationsMemCache(**mem_cache)
        if isinstance(pub_sub, dict):
            pub_sub = CloudGcpIntegrationsPubSub(**pub_sub)
        if isinstance(redis, dict):
            redis = CloudGcpIntegrationsRedis(**redis)
        if isinstance(router, dict):
            router = CloudGcpIntegrationsRouter(**router)
        if isinstance(run, dict):
            run = CloudGcpIntegrationsRun(**run)
        if isinstance(spanner, dict):
            spanner = CloudGcpIntegrationsSpanner(**spanner)
        if isinstance(sql, dict):
            sql = CloudGcpIntegrationsSql(**sql)
        if isinstance(storage, dict):
            storage = CloudGcpIntegrationsStorage(**storage)
        if isinstance(virtual_machines, dict):
            virtual_machines = CloudGcpIntegrationsVirtualMachines(**virtual_machines)
        if isinstance(vpc_access, dict):
            vpc_access = CloudGcpIntegrationsVpcAccess(**vpc_access)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__307f9e2f0182862caa8a868e69b3070ea2277ea8daeb2565fba35c58e06425ff)
            check_type(argname="argument connection", value=connection, expected_type=type_hints["connection"])
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument for_each", value=for_each, expected_type=type_hints["for_each"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
            check_type(argname="argument provisioners", value=provisioners, expected_type=type_hints["provisioners"])
            check_type(argname="argument linked_account_id", value=linked_account_id, expected_type=type_hints["linked_account_id"])
            check_type(argname="argument account_id", value=account_id, expected_type=type_hints["account_id"])
            check_type(argname="argument alloy_db", value=alloy_db, expected_type=type_hints["alloy_db"])
            check_type(argname="argument app_engine", value=app_engine, expected_type=type_hints["app_engine"])
            check_type(argname="argument big_query", value=big_query, expected_type=type_hints["big_query"])
            check_type(argname="argument big_table", value=big_table, expected_type=type_hints["big_table"])
            check_type(argname="argument composer", value=composer, expected_type=type_hints["composer"])
            check_type(argname="argument data_flow", value=data_flow, expected_type=type_hints["data_flow"])
            check_type(argname="argument data_proc", value=data_proc, expected_type=type_hints["data_proc"])
            check_type(argname="argument data_store", value=data_store, expected_type=type_hints["data_store"])
            check_type(argname="argument fire_base_database", value=fire_base_database, expected_type=type_hints["fire_base_database"])
            check_type(argname="argument fire_base_hosting", value=fire_base_hosting, expected_type=type_hints["fire_base_hosting"])
            check_type(argname="argument fire_base_storage", value=fire_base_storage, expected_type=type_hints["fire_base_storage"])
            check_type(argname="argument fire_store", value=fire_store, expected_type=type_hints["fire_store"])
            check_type(argname="argument functions", value=functions, expected_type=type_hints["functions"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
            check_type(argname="argument interconnect", value=interconnect, expected_type=type_hints["interconnect"])
            check_type(argname="argument kubernetes", value=kubernetes, expected_type=type_hints["kubernetes"])
            check_type(argname="argument load_balancing", value=load_balancing, expected_type=type_hints["load_balancing"])
            check_type(argname="argument mem_cache", value=mem_cache, expected_type=type_hints["mem_cache"])
            check_type(argname="argument pub_sub", value=pub_sub, expected_type=type_hints["pub_sub"])
            check_type(argname="argument redis", value=redis, expected_type=type_hints["redis"])
            check_type(argname="argument router", value=router, expected_type=type_hints["router"])
            check_type(argname="argument run", value=run, expected_type=type_hints["run"])
            check_type(argname="argument spanner", value=spanner, expected_type=type_hints["spanner"])
            check_type(argname="argument sql", value=sql, expected_type=type_hints["sql"])
            check_type(argname="argument storage", value=storage, expected_type=type_hints["storage"])
            check_type(argname="argument virtual_machines", value=virtual_machines, expected_type=type_hints["virtual_machines"])
            check_type(argname="argument vpc_access", value=vpc_access, expected_type=type_hints["vpc_access"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "linked_account_id": linked_account_id,
        }
        if connection is not None:
            self._values["connection"] = connection
        if count is not None:
            self._values["count"] = count
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if for_each is not None:
            self._values["for_each"] = for_each
        if lifecycle is not None:
            self._values["lifecycle"] = lifecycle
        if provider is not None:
            self._values["provider"] = provider
        if provisioners is not None:
            self._values["provisioners"] = provisioners
        if account_id is not None:
            self._values["account_id"] = account_id
        if alloy_db is not None:
            self._values["alloy_db"] = alloy_db
        if app_engine is not None:
            self._values["app_engine"] = app_engine
        if big_query is not None:
            self._values["big_query"] = big_query
        if big_table is not None:
            self._values["big_table"] = big_table
        if composer is not None:
            self._values["composer"] = composer
        if data_flow is not None:
            self._values["data_flow"] = data_flow
        if data_proc is not None:
            self._values["data_proc"] = data_proc
        if data_store is not None:
            self._values["data_store"] = data_store
        if fire_base_database is not None:
            self._values["fire_base_database"] = fire_base_database
        if fire_base_hosting is not None:
            self._values["fire_base_hosting"] = fire_base_hosting
        if fire_base_storage is not None:
            self._values["fire_base_storage"] = fire_base_storage
        if fire_store is not None:
            self._values["fire_store"] = fire_store
        if functions is not None:
            self._values["functions"] = functions
        if id is not None:
            self._values["id"] = id
        if interconnect is not None:
            self._values["interconnect"] = interconnect
        if kubernetes is not None:
            self._values["kubernetes"] = kubernetes
        if load_balancing is not None:
            self._values["load_balancing"] = load_balancing
        if mem_cache is not None:
            self._values["mem_cache"] = mem_cache
        if pub_sub is not None:
            self._values["pub_sub"] = pub_sub
        if redis is not None:
            self._values["redis"] = redis
        if router is not None:
            self._values["router"] = router
        if run is not None:
            self._values["run"] = run
        if spanner is not None:
            self._values["spanner"] = spanner
        if sql is not None:
            self._values["sql"] = sql
        if storage is not None:
            self._values["storage"] = storage
        if virtual_machines is not None:
            self._values["virtual_machines"] = virtual_machines
        if vpc_access is not None:
            self._values["vpc_access"] = vpc_access

    @builtins.property
    def connection(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, _cdktn_78ede62e.WinrmProvisionerConnection]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("connection")
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, _cdktn_78ede62e.WinrmProvisionerConnection]], result)

    @builtins.property
    def count(
        self,
    ) -> typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("count")
        return typing.cast(typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]], result)

    @builtins.property
    def depends_on(
        self,
    ) -> typing.Optional[typing.List[_cdktn_78ede62e.ITerraformDependable]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List[_cdktn_78ede62e.ITerraformDependable]], result)

    @builtins.property
    def for_each(self) -> typing.Optional[_cdktn_78ede62e.ITerraformIterator]:
        '''
        :stability: experimental
        '''
        result = self._values.get("for_each")
        return typing.cast(typing.Optional[_cdktn_78ede62e.ITerraformIterator], result)

    @builtins.property
    def lifecycle(self) -> typing.Optional[_cdktn_78ede62e.TerraformResourceLifecycle]:
        '''
        :stability: experimental
        '''
        result = self._values.get("lifecycle")
        return typing.cast(typing.Optional[_cdktn_78ede62e.TerraformResourceLifecycle], result)

    @builtins.property
    def provider(self) -> typing.Optional[_cdktn_78ede62e.TerraformProvider]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provider")
        return typing.cast(typing.Optional[_cdktn_78ede62e.TerraformProvider], result)

    @builtins.property
    def provisioners(
        self,
    ) -> typing.Optional[typing.List[typing.Union[_cdktn_78ede62e.FileProvisioner, _cdktn_78ede62e.LocalExecProvisioner, _cdktn_78ede62e.RemoteExecProvisioner]]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provisioners")
        return typing.cast(typing.Optional[typing.List[typing.Union[_cdktn_78ede62e.FileProvisioner, _cdktn_78ede62e.LocalExecProvisioner, _cdktn_78ede62e.RemoteExecProvisioner]]], result)

    @builtins.property
    def linked_account_id(self) -> jsii.Number:
        '''Id of the linked gcp account in New Relic.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#linked_account_id CloudGcpIntegrations#linked_account_id}
        '''
        result = self._values.get("linked_account_id")
        assert result is not None, "Required property 'linked_account_id' is missing"
        return typing.cast(jsii.Number, result)

    @builtins.property
    def account_id(self) -> typing.Optional[jsii.Number]:
        '''ID of the newrelic account.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#account_id CloudGcpIntegrations#account_id}
        '''
        result = self._values.get("account_id")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def alloy_db(self) -> typing.Optional[CloudGcpIntegrationsAlloyDb]:
        '''alloy_db block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#alloy_db CloudGcpIntegrations#alloy_db}
        '''
        result = self._values.get("alloy_db")
        return typing.cast(typing.Optional[CloudGcpIntegrationsAlloyDb], result)

    @builtins.property
    def app_engine(self) -> typing.Optional[CloudGcpIntegrationsAppEngine]:
        '''app_engine block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#app_engine CloudGcpIntegrations#app_engine}
        '''
        result = self._values.get("app_engine")
        return typing.cast(typing.Optional[CloudGcpIntegrationsAppEngine], result)

    @builtins.property
    def big_query(self) -> typing.Optional[CloudGcpIntegrationsBigQuery]:
        '''big_query block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#big_query CloudGcpIntegrations#big_query}
        '''
        result = self._values.get("big_query")
        return typing.cast(typing.Optional[CloudGcpIntegrationsBigQuery], result)

    @builtins.property
    def big_table(self) -> typing.Optional[CloudGcpIntegrationsBigTable]:
        '''big_table block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#big_table CloudGcpIntegrations#big_table}
        '''
        result = self._values.get("big_table")
        return typing.cast(typing.Optional[CloudGcpIntegrationsBigTable], result)

    @builtins.property
    def composer(self) -> typing.Optional[CloudGcpIntegrationsComposer]:
        '''composer block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#composer CloudGcpIntegrations#composer}
        '''
        result = self._values.get("composer")
        return typing.cast(typing.Optional[CloudGcpIntegrationsComposer], result)

    @builtins.property
    def data_flow(self) -> typing.Optional["CloudGcpIntegrationsDataFlow"]:
        '''data_flow block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#data_flow CloudGcpIntegrations#data_flow}
        '''
        result = self._values.get("data_flow")
        return typing.cast(typing.Optional["CloudGcpIntegrationsDataFlow"], result)

    @builtins.property
    def data_proc(self) -> typing.Optional["CloudGcpIntegrationsDataProc"]:
        '''data_proc block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#data_proc CloudGcpIntegrations#data_proc}
        '''
        result = self._values.get("data_proc")
        return typing.cast(typing.Optional["CloudGcpIntegrationsDataProc"], result)

    @builtins.property
    def data_store(self) -> typing.Optional["CloudGcpIntegrationsDataStore"]:
        '''data_store block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#data_store CloudGcpIntegrations#data_store}
        '''
        result = self._values.get("data_store")
        return typing.cast(typing.Optional["CloudGcpIntegrationsDataStore"], result)

    @builtins.property
    def fire_base_database(
        self,
    ) -> typing.Optional["CloudGcpIntegrationsFireBaseDatabase"]:
        '''fire_base_database block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#fire_base_database CloudGcpIntegrations#fire_base_database}
        '''
        result = self._values.get("fire_base_database")
        return typing.cast(typing.Optional["CloudGcpIntegrationsFireBaseDatabase"], result)

    @builtins.property
    def fire_base_hosting(
        self,
    ) -> typing.Optional["CloudGcpIntegrationsFireBaseHosting"]:
        '''fire_base_hosting block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#fire_base_hosting CloudGcpIntegrations#fire_base_hosting}
        '''
        result = self._values.get("fire_base_hosting")
        return typing.cast(typing.Optional["CloudGcpIntegrationsFireBaseHosting"], result)

    @builtins.property
    def fire_base_storage(
        self,
    ) -> typing.Optional["CloudGcpIntegrationsFireBaseStorage"]:
        '''fire_base_storage block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#fire_base_storage CloudGcpIntegrations#fire_base_storage}
        '''
        result = self._values.get("fire_base_storage")
        return typing.cast(typing.Optional["CloudGcpIntegrationsFireBaseStorage"], result)

    @builtins.property
    def fire_store(self) -> typing.Optional["CloudGcpIntegrationsFireStore"]:
        '''fire_store block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#fire_store CloudGcpIntegrations#fire_store}
        '''
        result = self._values.get("fire_store")
        return typing.cast(typing.Optional["CloudGcpIntegrationsFireStore"], result)

    @builtins.property
    def functions(self) -> typing.Optional["CloudGcpIntegrationsFunctions"]:
        '''functions block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#functions CloudGcpIntegrations#functions}
        '''
        result = self._values.get("functions")
        return typing.cast(typing.Optional["CloudGcpIntegrationsFunctions"], result)

    @builtins.property
    def id(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#id CloudGcpIntegrations#id}.

        Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        '''
        result = self._values.get("id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def interconnect(self) -> typing.Optional["CloudGcpIntegrationsInterconnect"]:
        '''interconnect block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#interconnect CloudGcpIntegrations#interconnect}
        '''
        result = self._values.get("interconnect")
        return typing.cast(typing.Optional["CloudGcpIntegrationsInterconnect"], result)

    @builtins.property
    def kubernetes(self) -> typing.Optional["CloudGcpIntegrationsKubernetes"]:
        '''kubernetes block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#kubernetes CloudGcpIntegrations#kubernetes}
        '''
        result = self._values.get("kubernetes")
        return typing.cast(typing.Optional["CloudGcpIntegrationsKubernetes"], result)

    @builtins.property
    def load_balancing(self) -> typing.Optional["CloudGcpIntegrationsLoadBalancing"]:
        '''load_balancing block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#load_balancing CloudGcpIntegrations#load_balancing}
        '''
        result = self._values.get("load_balancing")
        return typing.cast(typing.Optional["CloudGcpIntegrationsLoadBalancing"], result)

    @builtins.property
    def mem_cache(self) -> typing.Optional["CloudGcpIntegrationsMemCache"]:
        '''mem_cache block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#mem_cache CloudGcpIntegrations#mem_cache}
        '''
        result = self._values.get("mem_cache")
        return typing.cast(typing.Optional["CloudGcpIntegrationsMemCache"], result)

    @builtins.property
    def pub_sub(self) -> typing.Optional["CloudGcpIntegrationsPubSub"]:
        '''pub_sub block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#pub_sub CloudGcpIntegrations#pub_sub}
        '''
        result = self._values.get("pub_sub")
        return typing.cast(typing.Optional["CloudGcpIntegrationsPubSub"], result)

    @builtins.property
    def redis(self) -> typing.Optional["CloudGcpIntegrationsRedis"]:
        '''redis block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#redis CloudGcpIntegrations#redis}
        '''
        result = self._values.get("redis")
        return typing.cast(typing.Optional["CloudGcpIntegrationsRedis"], result)

    @builtins.property
    def router(self) -> typing.Optional["CloudGcpIntegrationsRouter"]:
        '''router block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#router CloudGcpIntegrations#router}
        '''
        result = self._values.get("router")
        return typing.cast(typing.Optional["CloudGcpIntegrationsRouter"], result)

    @builtins.property
    def run(self) -> typing.Optional["CloudGcpIntegrationsRun"]:
        '''run block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#run CloudGcpIntegrations#run}
        '''
        result = self._values.get("run")
        return typing.cast(typing.Optional["CloudGcpIntegrationsRun"], result)

    @builtins.property
    def spanner(self) -> typing.Optional["CloudGcpIntegrationsSpanner"]:
        '''spanner block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#spanner CloudGcpIntegrations#spanner}
        '''
        result = self._values.get("spanner")
        return typing.cast(typing.Optional["CloudGcpIntegrationsSpanner"], result)

    @builtins.property
    def sql(self) -> typing.Optional["CloudGcpIntegrationsSql"]:
        '''sql block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#sql CloudGcpIntegrations#sql}
        '''
        result = self._values.get("sql")
        return typing.cast(typing.Optional["CloudGcpIntegrationsSql"], result)

    @builtins.property
    def storage(self) -> typing.Optional["CloudGcpIntegrationsStorage"]:
        '''storage block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#storage CloudGcpIntegrations#storage}
        '''
        result = self._values.get("storage")
        return typing.cast(typing.Optional["CloudGcpIntegrationsStorage"], result)

    @builtins.property
    def virtual_machines(
        self,
    ) -> typing.Optional["CloudGcpIntegrationsVirtualMachines"]:
        '''virtual_machines block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#virtual_machines CloudGcpIntegrations#virtual_machines}
        '''
        result = self._values.get("virtual_machines")
        return typing.cast(typing.Optional["CloudGcpIntegrationsVirtualMachines"], result)

    @builtins.property
    def vpc_access(self) -> typing.Optional["CloudGcpIntegrationsVpcAccess"]:
        '''vpc_access block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#vpc_access CloudGcpIntegrations#vpc_access}
        '''
        result = self._values.get("vpc_access")
        return typing.cast(typing.Optional["CloudGcpIntegrationsVpcAccess"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudGcpIntegrationsConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsDataFlow",
    jsii_struct_bases=[],
    name_mapping={"metrics_polling_interval": "metricsPollingInterval"},
)
class CloudGcpIntegrationsDataFlow:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__68cfd8dd073a854d8d286af45a6fc903885491b9862fe9c37aeeacb4efa28658)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''the data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudGcpIntegrationsDataFlow(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudGcpIntegrationsDataFlowOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsDataFlowOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9bfa25c16c90af9123dbc113edcbcb062c499842789f0a3bfcf5751e5a499109)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__69d0e396c0bd725de074f7dd4f3ab7e910dc350afbc3197f4e43a2ec4d4d1de4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudGcpIntegrationsDataFlow]:
        return typing.cast(typing.Optional[CloudGcpIntegrationsDataFlow], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudGcpIntegrationsDataFlow],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ed66c9b3102a74013f9fd943bb9a3c162d54e71d006f92f4ddf4e89350485b1e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsDataProc",
    jsii_struct_bases=[],
    name_mapping={"metrics_polling_interval": "metricsPollingInterval"},
)
class CloudGcpIntegrationsDataProc:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6b7aede5cb1231afb93bcf85b095b819a606f9c939b3ef066887058e193b19ed)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''the data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudGcpIntegrationsDataProc(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudGcpIntegrationsDataProcOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsDataProcOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0b2f72c709d7556323d6bd35d80b0d8b19bafd02901eaaabe8a58956024f6c59)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ba8ae28fa4f2049e18a86a0d4cd68b164c5a2c5e0535332024e69f48cdbb75fd)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudGcpIntegrationsDataProc]:
        return typing.cast(typing.Optional[CloudGcpIntegrationsDataProc], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudGcpIntegrationsDataProc],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__636c83034d0a01188d54ba4fa0af82529601b07dac0be3744a5ca2b909964e0b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsDataStore",
    jsii_struct_bases=[],
    name_mapping={"metrics_polling_interval": "metricsPollingInterval"},
)
class CloudGcpIntegrationsDataStore:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c85f02ecdf05d624c70dc24c32e0bc6955918d4c134ee75975293671f6a44572)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''the data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudGcpIntegrationsDataStore(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudGcpIntegrationsDataStoreOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsDataStoreOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d225cba84093b8364a90ccd1161bd87375f63f272c393dfbf36bf9daf5ea4f81)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__79ea12a140734b25a427461457da01c4a8a516e64e51e625195f7625028f8f51)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudGcpIntegrationsDataStore]:
        return typing.cast(typing.Optional[CloudGcpIntegrationsDataStore], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudGcpIntegrationsDataStore],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__287ac913b85fc5e7f949bbf3cc3a4c74f6fa59f39799e6c924ee6a165b154263)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsFireBaseDatabase",
    jsii_struct_bases=[],
    name_mapping={"metrics_polling_interval": "metricsPollingInterval"},
)
class CloudGcpIntegrationsFireBaseDatabase:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e414b5857359724499810c7dc0463438437deb3e4bac56b14d2a084af3a6eb67)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''the data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudGcpIntegrationsFireBaseDatabase(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudGcpIntegrationsFireBaseDatabaseOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsFireBaseDatabaseOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c7cd8876832a3875b43debf7d090e0b136c5ccc523b5b3c2d6e1ac70098e8208)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4d83d0fc01655bd9ac174fdb214c5a07f5ec667712c7d65240c009c6987759be)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudGcpIntegrationsFireBaseDatabase]:
        return typing.cast(typing.Optional[CloudGcpIntegrationsFireBaseDatabase], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudGcpIntegrationsFireBaseDatabase],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0f872f651b0a226e43f4ffadaa532b0ea6fd6d4fa503a5e27a9d35087b350746)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsFireBaseHosting",
    jsii_struct_bases=[],
    name_mapping={"metrics_polling_interval": "metricsPollingInterval"},
)
class CloudGcpIntegrationsFireBaseHosting:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__877bb4d98be234138b964594470cdfc2791f406c6ba245fc2103b55a0b25d559)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''the data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudGcpIntegrationsFireBaseHosting(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudGcpIntegrationsFireBaseHostingOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsFireBaseHostingOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__18995e46d5b70c8acf643304e74bb2c1510c1023040c679fa24729f8a80bba23)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2ab5346bd84696e5e929cb40bd08419cc00bb36c668872553e4fe30995f0c23c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudGcpIntegrationsFireBaseHosting]:
        return typing.cast(typing.Optional[CloudGcpIntegrationsFireBaseHosting], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudGcpIntegrationsFireBaseHosting],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__20ebf7d93f3a9bcfa78a688f18a0d5ec061a210ca09eb7ce233f424c6d78da84)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsFireBaseStorage",
    jsii_struct_bases=[],
    name_mapping={"metrics_polling_interval": "metricsPollingInterval"},
)
class CloudGcpIntegrationsFireBaseStorage:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b3dc85c097e9c23c55bdb0e3fce4dc1ccf5243a84c52de7ee255b14d20ce745d)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''the data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudGcpIntegrationsFireBaseStorage(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudGcpIntegrationsFireBaseStorageOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsFireBaseStorageOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6c32630b8423d2bb2183eb567b65520558bb27b66073f34260cd574a6da7f0e6)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8f67ea4427fc83b8e9d910a7ba66ab02e5172a948b583cd203d689aafa0fd64e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudGcpIntegrationsFireBaseStorage]:
        return typing.cast(typing.Optional[CloudGcpIntegrationsFireBaseStorage], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudGcpIntegrationsFireBaseStorage],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e416e69e49d76f6c6672b418468f5061aa3088b14a04c391973fe01433df35fa)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsFireStore",
    jsii_struct_bases=[],
    name_mapping={"metrics_polling_interval": "metricsPollingInterval"},
)
class CloudGcpIntegrationsFireStore:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0cc0fca973f0ca72e8be72201553eecdf4cd0771a4409e7d948473a710663554)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''the data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudGcpIntegrationsFireStore(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudGcpIntegrationsFireStoreOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsFireStoreOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__30384628f98536de30aedb638fe02683650f0d47f90cf0a38f82fd66efd16eb1)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4f889408139a1df1538b5e2a8b0b8669998eb1c76b657b508c7d1a613f9f3e07)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudGcpIntegrationsFireStore]:
        return typing.cast(typing.Optional[CloudGcpIntegrationsFireStore], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudGcpIntegrationsFireStore],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f5e1f4aadbdc807cfb9d50deb8f4cddd59ce2bc99fece4dc89493d05dcc19c58)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsFunctions",
    jsii_struct_bases=[],
    name_mapping={"metrics_polling_interval": "metricsPollingInterval"},
)
class CloudGcpIntegrationsFunctions:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4e63364b969085bca9cd1157ae72e8f4267812bc0e4692b3184507f945a730ce)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''the data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudGcpIntegrationsFunctions(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudGcpIntegrationsFunctionsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsFunctionsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4a5cdaebb905f16779063cdc4f7ff93e75ac4eec893fbac29514757023212a9a)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__18db71059cadf4b3e73930454a034307ffddffc8f4364ebdc6b0a35c0b0c39a8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudGcpIntegrationsFunctions]:
        return typing.cast(typing.Optional[CloudGcpIntegrationsFunctions], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudGcpIntegrationsFunctions],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0d4056e6abaaa7ad95c9635433c9e38dc85a009b4e85187b8b046b9346279830)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsInterconnect",
    jsii_struct_bases=[],
    name_mapping={"metrics_polling_interval": "metricsPollingInterval"},
)
class CloudGcpIntegrationsInterconnect:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0f2313799f20af2cdd0e05b76199aeba800fd52936ce090a102e1eb62b73f2a6)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''the data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudGcpIntegrationsInterconnect(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudGcpIntegrationsInterconnectOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsInterconnectOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__28451c9e0d0f95c2a6b646d93c02508ed166efea61a2da4e20f4610e08c6e927)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0aef21b75a369dd69e252fa9d2f37b3719869ccf5ca5c91dd5e1bb3792e22ddf)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudGcpIntegrationsInterconnect]:
        return typing.cast(typing.Optional[CloudGcpIntegrationsInterconnect], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudGcpIntegrationsInterconnect],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7658419518f0f4fbd8bc3e76d1a0755511961669eaf9209d30aa82b3d7dea65e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsKubernetes",
    jsii_struct_bases=[],
    name_mapping={"metrics_polling_interval": "metricsPollingInterval"},
)
class CloudGcpIntegrationsKubernetes:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__acf488c3991680dd3fd640dc898e77ecf12029f38695cd3c1dd7da1bd9af3c4b)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''the data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudGcpIntegrationsKubernetes(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudGcpIntegrationsKubernetesOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsKubernetesOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6203582803d1041d59910a34434d2317490452e10e8746b75eaa41da88b1611d)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__28ec6c427fb4b4b49eab9d7e963e7145f72854898a8a0c5cf0f4f858b4c9c03c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudGcpIntegrationsKubernetes]:
        return typing.cast(typing.Optional[CloudGcpIntegrationsKubernetes], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudGcpIntegrationsKubernetes],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__eeadd51e7a10e4868e9b1045325df33bc5c75f598f67223f9fe09afc581f8713)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsLoadBalancing",
    jsii_struct_bases=[],
    name_mapping={"metrics_polling_interval": "metricsPollingInterval"},
)
class CloudGcpIntegrationsLoadBalancing:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a5ab4e812f4ee7f6ae87ea7cf22b077901cabf08bc888c7af0db2acc9816b35a)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''the data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudGcpIntegrationsLoadBalancing(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudGcpIntegrationsLoadBalancingOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsLoadBalancingOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5e84a16fb8f28a802011d15af95112ee5fba8b66ae08d94767867352b672445d)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9f8d9674cbddeb3460940da2eec66b57030848bf05db6633eda7a428f30d4af8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudGcpIntegrationsLoadBalancing]:
        return typing.cast(typing.Optional[CloudGcpIntegrationsLoadBalancing], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudGcpIntegrationsLoadBalancing],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4a785fc2d8974315d3ddebf4979aabac89986765e467a287c8b42ceff2d939df)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsMemCache",
    jsii_struct_bases=[],
    name_mapping={"metrics_polling_interval": "metricsPollingInterval"},
)
class CloudGcpIntegrationsMemCache:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__38b98890b995775f17385aff92da7308e8caac70bf3e3bdd2f5cd844e6647f7f)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''the data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudGcpIntegrationsMemCache(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudGcpIntegrationsMemCacheOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsMemCacheOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__31ab31f82d68ee187d904f0171981b61edf8606980e95599e8458f98e53613e3)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7c58a0809de49b8b04c408ebefa219cf0c90f10fa5e55cc4b80ec9cb1a0ac3e4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudGcpIntegrationsMemCache]:
        return typing.cast(typing.Optional[CloudGcpIntegrationsMemCache], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudGcpIntegrationsMemCache],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__39cbeae23bd2764cd1008d5c2d84d28f4c8e218f85bbfde098278b98419ac093)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsPubSub",
    jsii_struct_bases=[],
    name_mapping={
        "fetch_tags": "fetchTags",
        "metrics_polling_interval": "metricsPollingInterval",
    },
)
class CloudGcpIntegrationsPubSub:
    def __init__(
        self,
        *,
        fetch_tags: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param fetch_tags: to fetch tags of the resource. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#fetch_tags CloudGcpIntegrations#fetch_tags}
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6b0ec246448c6785482fb080cbf2922333353b1005462790691031c116a68add)
            check_type(argname="argument fetch_tags", value=fetch_tags, expected_type=type_hints["fetch_tags"])
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if fetch_tags is not None:
            self._values["fetch_tags"] = fetch_tags
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval

    @builtins.property
    def fetch_tags(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''to fetch tags of the resource.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#fetch_tags CloudGcpIntegrations#fetch_tags}
        '''
        result = self._values.get("fetch_tags")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''the data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudGcpIntegrationsPubSub(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudGcpIntegrationsPubSubOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsPubSubOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__193508869b8c29121e9bfcbd9959a4cdc5f7702b4a51398e21cf3e5ff78fdfa7)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetFetchTags")
    def reset_fetch_tags(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFetchTags", []))

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @builtins.property
    @jsii.member(jsii_name="fetchTagsInput")
    def fetch_tags_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "fetchTagsInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="fetchTags")
    def fetch_tags(self) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "fetchTags"))

    @fetch_tags.setter
    def fetch_tags(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b307557260fcf4dc05982efe798cab26576efae8b135ab2dc231d5b4aa1a56ce)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "fetchTags", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2a7fce212a46a1bb551a6e07a6200987085457ec06ecdd7b2b2b6b3c34f015a9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudGcpIntegrationsPubSub]:
        return typing.cast(typing.Optional[CloudGcpIntegrationsPubSub], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudGcpIntegrationsPubSub],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5742ffa96d073f2312653ef62c93a870987f38b75f9b23e757765ebb20189dcd)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsRedis",
    jsii_struct_bases=[],
    name_mapping={"metrics_polling_interval": "metricsPollingInterval"},
)
class CloudGcpIntegrationsRedis:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__956b4d6bbb9c6fc48ac65adf78c228b858931278086b3588614e6fb4e072c89a)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''the data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudGcpIntegrationsRedis(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudGcpIntegrationsRedisOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsRedisOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2d1c57ad504f928b84afe6e4000eceaf760d8eb515b5d930ae8f24a06711c72c)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ebb04fb9a81769a3489c0310bc4a6c0e309fc7a8f4d04966c0524281e9f1e638)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudGcpIntegrationsRedis]:
        return typing.cast(typing.Optional[CloudGcpIntegrationsRedis], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(self, value: typing.Optional[CloudGcpIntegrationsRedis]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__52a287ff01ecf6f39e8373e2671ea8255702c5205490494ad4a87dd48ab04208)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsRouter",
    jsii_struct_bases=[],
    name_mapping={"metrics_polling_interval": "metricsPollingInterval"},
)
class CloudGcpIntegrationsRouter:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4b1af71adca717beaac75030bf1cd6686bfa885190a9721306880a5ce882f533)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''the data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudGcpIntegrationsRouter(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudGcpIntegrationsRouterOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsRouterOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__466c268b6f7e72054af0475e08d4c60fdf568a879b097e0e21aa6a903f8378e7)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d13fe58d6c8fce398ed5c7ddc986021600dda3ed15cda21a983410844c5e10cd)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudGcpIntegrationsRouter]:
        return typing.cast(typing.Optional[CloudGcpIntegrationsRouter], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudGcpIntegrationsRouter],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b7f6cd9f9c3d448831873da58c050e08845ce64acd4b7121baccba05f148134f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsRun",
    jsii_struct_bases=[],
    name_mapping={"metrics_polling_interval": "metricsPollingInterval"},
)
class CloudGcpIntegrationsRun:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3f21fadca55a410cfc406ad6a3b7d3a76782d7ca0e5835f64261e1b96bbc1e97)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''the data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudGcpIntegrationsRun(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudGcpIntegrationsRunOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsRunOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__01c580ddcf9c8874235187553a224ae8d22d164f15f261765ecaaf9f68dd096f)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__53e4e2ae470c2a5249d65fd587112bd0b6cbfc7eb2a0539732248c6e2fb72713)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudGcpIntegrationsRun]:
        return typing.cast(typing.Optional[CloudGcpIntegrationsRun], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(self, value: typing.Optional[CloudGcpIntegrationsRun]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3cc3e88e7fb34cd287e24ce66fe0d3c44794711996f78bf53eb31e592dc5f513)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsSpanner",
    jsii_struct_bases=[],
    name_mapping={
        "fetch_tags": "fetchTags",
        "metrics_polling_interval": "metricsPollingInterval",
    },
)
class CloudGcpIntegrationsSpanner:
    def __init__(
        self,
        *,
        fetch_tags: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param fetch_tags: to fetch tags of the resource. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#fetch_tags CloudGcpIntegrations#fetch_tags}
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4c001c0122fc6b480c2ef25ef8dba2e158df287463d7c67541b950998cefff1b)
            check_type(argname="argument fetch_tags", value=fetch_tags, expected_type=type_hints["fetch_tags"])
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if fetch_tags is not None:
            self._values["fetch_tags"] = fetch_tags
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval

    @builtins.property
    def fetch_tags(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''to fetch tags of the resource.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#fetch_tags CloudGcpIntegrations#fetch_tags}
        '''
        result = self._values.get("fetch_tags")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''the data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudGcpIntegrationsSpanner(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudGcpIntegrationsSpannerOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsSpannerOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__763b82a101c8b1ee3020df1da5b86e60bbc3eb3bdb77379b6def1067ea5948c2)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetFetchTags")
    def reset_fetch_tags(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFetchTags", []))

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @builtins.property
    @jsii.member(jsii_name="fetchTagsInput")
    def fetch_tags_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "fetchTagsInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="fetchTags")
    def fetch_tags(self) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "fetchTags"))

    @fetch_tags.setter
    def fetch_tags(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8016276d4ca726987e995eea66db8dcc2f457d51f223046bef7f6048260bb55c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "fetchTags", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c4d90bddcc79a75d686c692bfe3120c1065cac92818c434904e8f37fcd91c27a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudGcpIntegrationsSpanner]:
        return typing.cast(typing.Optional[CloudGcpIntegrationsSpanner], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudGcpIntegrationsSpanner],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__79fd4081d320ebddc23c7f91f543ea4f1015ab8df2e381e7ec205cb8d88e7ec2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsSql",
    jsii_struct_bases=[],
    name_mapping={"metrics_polling_interval": "metricsPollingInterval"},
)
class CloudGcpIntegrationsSql:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8767e3d616f297fe9ac948486b65a2cff1619b2086922c2c3f8df0d805a7c2dd)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''the data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudGcpIntegrationsSql(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudGcpIntegrationsSqlOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsSqlOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f960a7eb1598c8da3c662e9424e409e2d57ae6b727b8ecf46058cc5c265015ec)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__282dc397a2b71851e8f3c8682af9c04f608c44ae4744ef706a3add404d927f1f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudGcpIntegrationsSql]:
        return typing.cast(typing.Optional[CloudGcpIntegrationsSql], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(self, value: typing.Optional[CloudGcpIntegrationsSql]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__14251424e42f931cd6afccdb55b4c67f74c157e7555a078a7bc913ab52c8029d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsStorage",
    jsii_struct_bases=[],
    name_mapping={
        "fetch_tags": "fetchTags",
        "metrics_polling_interval": "metricsPollingInterval",
    },
)
class CloudGcpIntegrationsStorage:
    def __init__(
        self,
        *,
        fetch_tags: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param fetch_tags: to fetch tags of the resource. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#fetch_tags CloudGcpIntegrations#fetch_tags}
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__663d3446397014038f2fd9d55fe82a47bae6b7bba8535c08e4f0c79ceb4b9fb6)
            check_type(argname="argument fetch_tags", value=fetch_tags, expected_type=type_hints["fetch_tags"])
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if fetch_tags is not None:
            self._values["fetch_tags"] = fetch_tags
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval

    @builtins.property
    def fetch_tags(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''to fetch tags of the resource.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#fetch_tags CloudGcpIntegrations#fetch_tags}
        '''
        result = self._values.get("fetch_tags")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''the data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudGcpIntegrationsStorage(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudGcpIntegrationsStorageOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsStorageOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a3b7590b5685316e4aace992f47f2800dce0f2c0daebfeb09add2dc3914d2e3f)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetFetchTags")
    def reset_fetch_tags(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFetchTags", []))

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @builtins.property
    @jsii.member(jsii_name="fetchTagsInput")
    def fetch_tags_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "fetchTagsInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="fetchTags")
    def fetch_tags(self) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "fetchTags"))

    @fetch_tags.setter
    def fetch_tags(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cee953718357ee2becf0ca02837957811b1bb6bcea09e33925499c6936c60e0c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "fetchTags", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__408846694f671ac44acd1e08a9b057835a6485a5019aced1e8cf19ef9dcbde82)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudGcpIntegrationsStorage]:
        return typing.cast(typing.Optional[CloudGcpIntegrationsStorage], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudGcpIntegrationsStorage],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__57b2e2a188c1dc709f58b3f566f7f6017de916ad18fd0cd95be0ac1c61dfffed)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsVirtualMachines",
    jsii_struct_bases=[],
    name_mapping={"metrics_polling_interval": "metricsPollingInterval"},
)
class CloudGcpIntegrationsVirtualMachines:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__95b488f0a54947739f902cf97dfd1d551d010ccf097df6ab7ee32a947092d56b)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''the data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudGcpIntegrationsVirtualMachines(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudGcpIntegrationsVirtualMachinesOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsVirtualMachinesOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a77d8899744ac27377aa36eb2754721a535b6585bef77925018cb9cd59b11218)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8180634f6e47a3c5971940cf346fd33582b0313d868c303791edea93363119e0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudGcpIntegrationsVirtualMachines]:
        return typing.cast(typing.Optional[CloudGcpIntegrationsVirtualMachines], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudGcpIntegrationsVirtualMachines],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ad0a1f2d2cd68c8120c3212c507c2d3fb962bbd22066eecf1032ecc396ad1a9c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsVpcAccess",
    jsii_struct_bases=[],
    name_mapping={"metrics_polling_interval": "metricsPollingInterval"},
)
class CloudGcpIntegrationsVpcAccess:
    def __init__(
        self,
        *,
        metrics_polling_interval: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param metrics_polling_interval: the data polling interval in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8ac2d3a2ea899d18e3c20a0aa8ce5b30ce0ee6ee47bca10f0b31e8d2b15d6aef)
            check_type(argname="argument metrics_polling_interval", value=metrics_polling_interval, expected_type=type_hints["metrics_polling_interval"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metrics_polling_interval is not None:
            self._values["metrics_polling_interval"] = metrics_polling_interval

    @builtins.property
    def metrics_polling_interval(self) -> typing.Optional[jsii.Number]:
        '''the data polling interval in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.2/docs/resources/cloud_gcp_integrations#metrics_polling_interval CloudGcpIntegrations#metrics_polling_interval}
        '''
        result = self._values.get("metrics_polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudGcpIntegrationsVpcAccess(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CloudGcpIntegrationsVpcAccessOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-newrelic.cloudGcpIntegrations.CloudGcpIntegrationsVpcAccessOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6c18eddee059eceae52df60cc524b9431e79dea07c3c719c9b79cfed8ede2709)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetMetricsPollingInterval")
    def reset_metrics_polling_interval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetricsPollingInterval", []))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingIntervalInput")
    def metrics_polling_interval_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "metricsPollingIntervalInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsPollingInterval")
    def metrics_polling_interval(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "metricsPollingInterval"))

    @metrics_polling_interval.setter
    def metrics_polling_interval(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b704777fd37ac434e4a73d02f9af768f2e136c519489d89417a34a22e9bed6bf)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "metricsPollingInterval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[CloudGcpIntegrationsVpcAccess]:
        return typing.cast(typing.Optional[CloudGcpIntegrationsVpcAccess], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[CloudGcpIntegrationsVpcAccess],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1b0c2476f53e01a361179f810e39355845311d6b1c8812cac13512d7398fa239)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


__all__ = [
    "CloudGcpIntegrations",
    "CloudGcpIntegrationsAlloyDb",
    "CloudGcpIntegrationsAlloyDbOutputReference",
    "CloudGcpIntegrationsAppEngine",
    "CloudGcpIntegrationsAppEngineOutputReference",
    "CloudGcpIntegrationsBigQuery",
    "CloudGcpIntegrationsBigQueryOutputReference",
    "CloudGcpIntegrationsBigTable",
    "CloudGcpIntegrationsBigTableOutputReference",
    "CloudGcpIntegrationsComposer",
    "CloudGcpIntegrationsComposerOutputReference",
    "CloudGcpIntegrationsConfig",
    "CloudGcpIntegrationsDataFlow",
    "CloudGcpIntegrationsDataFlowOutputReference",
    "CloudGcpIntegrationsDataProc",
    "CloudGcpIntegrationsDataProcOutputReference",
    "CloudGcpIntegrationsDataStore",
    "CloudGcpIntegrationsDataStoreOutputReference",
    "CloudGcpIntegrationsFireBaseDatabase",
    "CloudGcpIntegrationsFireBaseDatabaseOutputReference",
    "CloudGcpIntegrationsFireBaseHosting",
    "CloudGcpIntegrationsFireBaseHostingOutputReference",
    "CloudGcpIntegrationsFireBaseStorage",
    "CloudGcpIntegrationsFireBaseStorageOutputReference",
    "CloudGcpIntegrationsFireStore",
    "CloudGcpIntegrationsFireStoreOutputReference",
    "CloudGcpIntegrationsFunctions",
    "CloudGcpIntegrationsFunctionsOutputReference",
    "CloudGcpIntegrationsInterconnect",
    "CloudGcpIntegrationsInterconnectOutputReference",
    "CloudGcpIntegrationsKubernetes",
    "CloudGcpIntegrationsKubernetesOutputReference",
    "CloudGcpIntegrationsLoadBalancing",
    "CloudGcpIntegrationsLoadBalancingOutputReference",
    "CloudGcpIntegrationsMemCache",
    "CloudGcpIntegrationsMemCacheOutputReference",
    "CloudGcpIntegrationsPubSub",
    "CloudGcpIntegrationsPubSubOutputReference",
    "CloudGcpIntegrationsRedis",
    "CloudGcpIntegrationsRedisOutputReference",
    "CloudGcpIntegrationsRouter",
    "CloudGcpIntegrationsRouterOutputReference",
    "CloudGcpIntegrationsRun",
    "CloudGcpIntegrationsRunOutputReference",
    "CloudGcpIntegrationsSpanner",
    "CloudGcpIntegrationsSpannerOutputReference",
    "CloudGcpIntegrationsSql",
    "CloudGcpIntegrationsSqlOutputReference",
    "CloudGcpIntegrationsStorage",
    "CloudGcpIntegrationsStorageOutputReference",
    "CloudGcpIntegrationsVirtualMachines",
    "CloudGcpIntegrationsVirtualMachinesOutputReference",
    "CloudGcpIntegrationsVpcAccess",
    "CloudGcpIntegrationsVpcAccessOutputReference",
]

publication.publish()

def _typecheckingstub__ffd1472025c1d6780cebc75980a67d1aedcc8e61697adb6430f8af8623af40d3(
    scope: _constructs_77d1e7e8.Construct,
    id_: builtins.str,
    *,
    linked_account_id: jsii.Number,
    account_id: typing.Optional[jsii.Number] = None,
    alloy_db: typing.Optional[typing.Union[CloudGcpIntegrationsAlloyDb, typing.Dict[builtins.str, typing.Any]]] = None,
    app_engine: typing.Optional[typing.Union[CloudGcpIntegrationsAppEngine, typing.Dict[builtins.str, typing.Any]]] = None,
    big_query: typing.Optional[typing.Union[CloudGcpIntegrationsBigQuery, typing.Dict[builtins.str, typing.Any]]] = None,
    big_table: typing.Optional[typing.Union[CloudGcpIntegrationsBigTable, typing.Dict[builtins.str, typing.Any]]] = None,
    composer: typing.Optional[typing.Union[CloudGcpIntegrationsComposer, typing.Dict[builtins.str, typing.Any]]] = None,
    data_flow: typing.Optional[typing.Union[CloudGcpIntegrationsDataFlow, typing.Dict[builtins.str, typing.Any]]] = None,
    data_proc: typing.Optional[typing.Union[CloudGcpIntegrationsDataProc, typing.Dict[builtins.str, typing.Any]]] = None,
    data_store: typing.Optional[typing.Union[CloudGcpIntegrationsDataStore, typing.Dict[builtins.str, typing.Any]]] = None,
    fire_base_database: typing.Optional[typing.Union[CloudGcpIntegrationsFireBaseDatabase, typing.Dict[builtins.str, typing.Any]]] = None,
    fire_base_hosting: typing.Optional[typing.Union[CloudGcpIntegrationsFireBaseHosting, typing.Dict[builtins.str, typing.Any]]] = None,
    fire_base_storage: typing.Optional[typing.Union[CloudGcpIntegrationsFireBaseStorage, typing.Dict[builtins.str, typing.Any]]] = None,
    fire_store: typing.Optional[typing.Union[CloudGcpIntegrationsFireStore, typing.Dict[builtins.str, typing.Any]]] = None,
    functions: typing.Optional[typing.Union[CloudGcpIntegrationsFunctions, typing.Dict[builtins.str, typing.Any]]] = None,
    id: typing.Optional[builtins.str] = None,
    interconnect: typing.Optional[typing.Union[CloudGcpIntegrationsInterconnect, typing.Dict[builtins.str, typing.Any]]] = None,
    kubernetes: typing.Optional[typing.Union[CloudGcpIntegrationsKubernetes, typing.Dict[builtins.str, typing.Any]]] = None,
    load_balancing: typing.Optional[typing.Union[CloudGcpIntegrationsLoadBalancing, typing.Dict[builtins.str, typing.Any]]] = None,
    mem_cache: typing.Optional[typing.Union[CloudGcpIntegrationsMemCache, typing.Dict[builtins.str, typing.Any]]] = None,
    pub_sub: typing.Optional[typing.Union[CloudGcpIntegrationsPubSub, typing.Dict[builtins.str, typing.Any]]] = None,
    redis: typing.Optional[typing.Union[CloudGcpIntegrationsRedis, typing.Dict[builtins.str, typing.Any]]] = None,
    router: typing.Optional[typing.Union[CloudGcpIntegrationsRouter, typing.Dict[builtins.str, typing.Any]]] = None,
    run: typing.Optional[typing.Union[CloudGcpIntegrationsRun, typing.Dict[builtins.str, typing.Any]]] = None,
    spanner: typing.Optional[typing.Union[CloudGcpIntegrationsSpanner, typing.Dict[builtins.str, typing.Any]]] = None,
    sql: typing.Optional[typing.Union[CloudGcpIntegrationsSql, typing.Dict[builtins.str, typing.Any]]] = None,
    storage: typing.Optional[typing.Union[CloudGcpIntegrationsStorage, typing.Dict[builtins.str, typing.Any]]] = None,
    virtual_machines: typing.Optional[typing.Union[CloudGcpIntegrationsVirtualMachines, typing.Dict[builtins.str, typing.Any]]] = None,
    vpc_access: typing.Optional[typing.Union[CloudGcpIntegrationsVpcAccess, typing.Dict[builtins.str, typing.Any]]] = None,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__71cbc4136fbf6cdeea8b0d6ab5401f4f4668f7011e436e10ad92e6e4cc05d2ba(
    scope: _constructs_77d1e7e8.Construct,
    import_to_id: builtins.str,
    import_from_id: builtins.str,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4fc05dbb1c0dea7eb3713bd3cb671ad2bfcf72019e2fdf989a6b2eca71c33d84(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8104a1a04d98ee1a775e1678d6ce04e8b4d58ef8b44ba17be95f876dae8b8178(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4fd2af3256ab1f52f438b27f51f2b8d22ebbbefe7c45f66bc5798bddfe877f88(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1735dffd38b60c32f9ba9bab6a50902d92f421c1f0370c1df54b87107ce9dd38(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__593edc3eda9588b74c7fc34abf3b9621d81fd147371b52b5e034b2babf22980b(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2f2d7d918e329861fc56e890630c31a193fa64fbad408dabfb3bf4f35084aeea(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e37ca1b972f0e19601808623ce3ec3c2f625f474c1e4f213e3d78b7522ab58d0(
    value: typing.Optional[CloudGcpIntegrationsAlloyDb],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a848491eb6bc5e82ed3d4107263025654084e6de0d50f61b024937e34b98da36(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__be49ae75dfd49275ba9771a9c1ae31cbfc88e2a3a74b9937d3a8ef8ab464f164(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8a36f647260558fb7583075c40708f993e55dff211dbcd5b721257a7ff3bfbc1(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cb46584b7c29de7f5c7003a2d3ed3f0b0e58e2ffbe9b6e04989ab435bc8c643c(
    value: typing.Optional[CloudGcpIntegrationsAppEngine],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cd26bbc3dcf62913b1f56d3854467a31701d0337c7ba37bf032349905cf2b5fd(
    *,
    fetch_tags: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a42e7e6befebcdfb19afb827861f4be52de8e5ea04e67ecf3029c29f8b713a3a(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c89d9b5335abfdbe0920cbe0222c69f64e743c9dab09c82ac10d94e3a8c5a310(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7500769be7407cb4a913d33bc9e870842d459c42ac738189e27691b0c07058f1(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8eb6add486053c9fa7009b77252cd0fa63c046ccb31ac8aad5d8af44a588255b(
    value: typing.Optional[CloudGcpIntegrationsBigQuery],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9846343744741859821cb3dfdacedd1b385bacb7377a7cc398c7cca7c6cd5089(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__93e35c8a171260518232e931d8f58d8ba53a1182d66ef9dc6c41a2fe970bf6b4(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dcd5cc1df1f635554a17f56428ae516eea667901056f8e666f5ac8d613c0e5e0(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2feff80015c7849e3c61c3a9ad3f494e6aa05c87592bb71125185cdefba407ee(
    value: typing.Optional[CloudGcpIntegrationsBigTable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a49806ec92cd9c96825298ac768d180ef16dce28863f7403918ee1426120949b(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9b045883568f08d0e0443b4c0fa4425c0550fdd212df5c424da64db3da6e1368(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ef1b1fb55b615ecf38f5e0bad6dc917a71dfa6ea88a72e0a74bc2f5160b24f59(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dfa3439b93a7a9dd34b4b565585c741c2c30b9cc715d0bfeb46ba000b8f1c122(
    value: typing.Optional[CloudGcpIntegrationsComposer],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__307f9e2f0182862caa8a868e69b3070ea2277ea8daeb2565fba35c58e06425ff(
    *,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    linked_account_id: jsii.Number,
    account_id: typing.Optional[jsii.Number] = None,
    alloy_db: typing.Optional[typing.Union[CloudGcpIntegrationsAlloyDb, typing.Dict[builtins.str, typing.Any]]] = None,
    app_engine: typing.Optional[typing.Union[CloudGcpIntegrationsAppEngine, typing.Dict[builtins.str, typing.Any]]] = None,
    big_query: typing.Optional[typing.Union[CloudGcpIntegrationsBigQuery, typing.Dict[builtins.str, typing.Any]]] = None,
    big_table: typing.Optional[typing.Union[CloudGcpIntegrationsBigTable, typing.Dict[builtins.str, typing.Any]]] = None,
    composer: typing.Optional[typing.Union[CloudGcpIntegrationsComposer, typing.Dict[builtins.str, typing.Any]]] = None,
    data_flow: typing.Optional[typing.Union[CloudGcpIntegrationsDataFlow, typing.Dict[builtins.str, typing.Any]]] = None,
    data_proc: typing.Optional[typing.Union[CloudGcpIntegrationsDataProc, typing.Dict[builtins.str, typing.Any]]] = None,
    data_store: typing.Optional[typing.Union[CloudGcpIntegrationsDataStore, typing.Dict[builtins.str, typing.Any]]] = None,
    fire_base_database: typing.Optional[typing.Union[CloudGcpIntegrationsFireBaseDatabase, typing.Dict[builtins.str, typing.Any]]] = None,
    fire_base_hosting: typing.Optional[typing.Union[CloudGcpIntegrationsFireBaseHosting, typing.Dict[builtins.str, typing.Any]]] = None,
    fire_base_storage: typing.Optional[typing.Union[CloudGcpIntegrationsFireBaseStorage, typing.Dict[builtins.str, typing.Any]]] = None,
    fire_store: typing.Optional[typing.Union[CloudGcpIntegrationsFireStore, typing.Dict[builtins.str, typing.Any]]] = None,
    functions: typing.Optional[typing.Union[CloudGcpIntegrationsFunctions, typing.Dict[builtins.str, typing.Any]]] = None,
    id: typing.Optional[builtins.str] = None,
    interconnect: typing.Optional[typing.Union[CloudGcpIntegrationsInterconnect, typing.Dict[builtins.str, typing.Any]]] = None,
    kubernetes: typing.Optional[typing.Union[CloudGcpIntegrationsKubernetes, typing.Dict[builtins.str, typing.Any]]] = None,
    load_balancing: typing.Optional[typing.Union[CloudGcpIntegrationsLoadBalancing, typing.Dict[builtins.str, typing.Any]]] = None,
    mem_cache: typing.Optional[typing.Union[CloudGcpIntegrationsMemCache, typing.Dict[builtins.str, typing.Any]]] = None,
    pub_sub: typing.Optional[typing.Union[CloudGcpIntegrationsPubSub, typing.Dict[builtins.str, typing.Any]]] = None,
    redis: typing.Optional[typing.Union[CloudGcpIntegrationsRedis, typing.Dict[builtins.str, typing.Any]]] = None,
    router: typing.Optional[typing.Union[CloudGcpIntegrationsRouter, typing.Dict[builtins.str, typing.Any]]] = None,
    run: typing.Optional[typing.Union[CloudGcpIntegrationsRun, typing.Dict[builtins.str, typing.Any]]] = None,
    spanner: typing.Optional[typing.Union[CloudGcpIntegrationsSpanner, typing.Dict[builtins.str, typing.Any]]] = None,
    sql: typing.Optional[typing.Union[CloudGcpIntegrationsSql, typing.Dict[builtins.str, typing.Any]]] = None,
    storage: typing.Optional[typing.Union[CloudGcpIntegrationsStorage, typing.Dict[builtins.str, typing.Any]]] = None,
    virtual_machines: typing.Optional[typing.Union[CloudGcpIntegrationsVirtualMachines, typing.Dict[builtins.str, typing.Any]]] = None,
    vpc_access: typing.Optional[typing.Union[CloudGcpIntegrationsVpcAccess, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__68cfd8dd073a854d8d286af45a6fc903885491b9862fe9c37aeeacb4efa28658(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9bfa25c16c90af9123dbc113edcbcb062c499842789f0a3bfcf5751e5a499109(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__69d0e396c0bd725de074f7dd4f3ab7e910dc350afbc3197f4e43a2ec4d4d1de4(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ed66c9b3102a74013f9fd943bb9a3c162d54e71d006f92f4ddf4e89350485b1e(
    value: typing.Optional[CloudGcpIntegrationsDataFlow],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6b7aede5cb1231afb93bcf85b095b819a606f9c939b3ef066887058e193b19ed(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0b2f72c709d7556323d6bd35d80b0d8b19bafd02901eaaabe8a58956024f6c59(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ba8ae28fa4f2049e18a86a0d4cd68b164c5a2c5e0535332024e69f48cdbb75fd(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__636c83034d0a01188d54ba4fa0af82529601b07dac0be3744a5ca2b909964e0b(
    value: typing.Optional[CloudGcpIntegrationsDataProc],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c85f02ecdf05d624c70dc24c32e0bc6955918d4c134ee75975293671f6a44572(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d225cba84093b8364a90ccd1161bd87375f63f272c393dfbf36bf9daf5ea4f81(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__79ea12a140734b25a427461457da01c4a8a516e64e51e625195f7625028f8f51(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__287ac913b85fc5e7f949bbf3cc3a4c74f6fa59f39799e6c924ee6a165b154263(
    value: typing.Optional[CloudGcpIntegrationsDataStore],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e414b5857359724499810c7dc0463438437deb3e4bac56b14d2a084af3a6eb67(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c7cd8876832a3875b43debf7d090e0b136c5ccc523b5b3c2d6e1ac70098e8208(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4d83d0fc01655bd9ac174fdb214c5a07f5ec667712c7d65240c009c6987759be(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0f872f651b0a226e43f4ffadaa532b0ea6fd6d4fa503a5e27a9d35087b350746(
    value: typing.Optional[CloudGcpIntegrationsFireBaseDatabase],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__877bb4d98be234138b964594470cdfc2791f406c6ba245fc2103b55a0b25d559(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__18995e46d5b70c8acf643304e74bb2c1510c1023040c679fa24729f8a80bba23(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2ab5346bd84696e5e929cb40bd08419cc00bb36c668872553e4fe30995f0c23c(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__20ebf7d93f3a9bcfa78a688f18a0d5ec061a210ca09eb7ce233f424c6d78da84(
    value: typing.Optional[CloudGcpIntegrationsFireBaseHosting],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b3dc85c097e9c23c55bdb0e3fce4dc1ccf5243a84c52de7ee255b14d20ce745d(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6c32630b8423d2bb2183eb567b65520558bb27b66073f34260cd574a6da7f0e6(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8f67ea4427fc83b8e9d910a7ba66ab02e5172a948b583cd203d689aafa0fd64e(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e416e69e49d76f6c6672b418468f5061aa3088b14a04c391973fe01433df35fa(
    value: typing.Optional[CloudGcpIntegrationsFireBaseStorage],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0cc0fca973f0ca72e8be72201553eecdf4cd0771a4409e7d948473a710663554(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__30384628f98536de30aedb638fe02683650f0d47f90cf0a38f82fd66efd16eb1(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4f889408139a1df1538b5e2a8b0b8669998eb1c76b657b508c7d1a613f9f3e07(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f5e1f4aadbdc807cfb9d50deb8f4cddd59ce2bc99fece4dc89493d05dcc19c58(
    value: typing.Optional[CloudGcpIntegrationsFireStore],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4e63364b969085bca9cd1157ae72e8f4267812bc0e4692b3184507f945a730ce(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4a5cdaebb905f16779063cdc4f7ff93e75ac4eec893fbac29514757023212a9a(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__18db71059cadf4b3e73930454a034307ffddffc8f4364ebdc6b0a35c0b0c39a8(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0d4056e6abaaa7ad95c9635433c9e38dc85a009b4e85187b8b046b9346279830(
    value: typing.Optional[CloudGcpIntegrationsFunctions],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0f2313799f20af2cdd0e05b76199aeba800fd52936ce090a102e1eb62b73f2a6(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__28451c9e0d0f95c2a6b646d93c02508ed166efea61a2da4e20f4610e08c6e927(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0aef21b75a369dd69e252fa9d2f37b3719869ccf5ca5c91dd5e1bb3792e22ddf(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7658419518f0f4fbd8bc3e76d1a0755511961669eaf9209d30aa82b3d7dea65e(
    value: typing.Optional[CloudGcpIntegrationsInterconnect],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__acf488c3991680dd3fd640dc898e77ecf12029f38695cd3c1dd7da1bd9af3c4b(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6203582803d1041d59910a34434d2317490452e10e8746b75eaa41da88b1611d(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__28ec6c427fb4b4b49eab9d7e963e7145f72854898a8a0c5cf0f4f858b4c9c03c(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__eeadd51e7a10e4868e9b1045325df33bc5c75f598f67223f9fe09afc581f8713(
    value: typing.Optional[CloudGcpIntegrationsKubernetes],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a5ab4e812f4ee7f6ae87ea7cf22b077901cabf08bc888c7af0db2acc9816b35a(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5e84a16fb8f28a802011d15af95112ee5fba8b66ae08d94767867352b672445d(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9f8d9674cbddeb3460940da2eec66b57030848bf05db6633eda7a428f30d4af8(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4a785fc2d8974315d3ddebf4979aabac89986765e467a287c8b42ceff2d939df(
    value: typing.Optional[CloudGcpIntegrationsLoadBalancing],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__38b98890b995775f17385aff92da7308e8caac70bf3e3bdd2f5cd844e6647f7f(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__31ab31f82d68ee187d904f0171981b61edf8606980e95599e8458f98e53613e3(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7c58a0809de49b8b04c408ebefa219cf0c90f10fa5e55cc4b80ec9cb1a0ac3e4(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__39cbeae23bd2764cd1008d5c2d84d28f4c8e218f85bbfde098278b98419ac093(
    value: typing.Optional[CloudGcpIntegrationsMemCache],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6b0ec246448c6785482fb080cbf2922333353b1005462790691031c116a68add(
    *,
    fetch_tags: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__193508869b8c29121e9bfcbd9959a4cdc5f7702b4a51398e21cf3e5ff78fdfa7(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b307557260fcf4dc05982efe798cab26576efae8b135ab2dc231d5b4aa1a56ce(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2a7fce212a46a1bb551a6e07a6200987085457ec06ecdd7b2b2b6b3c34f015a9(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5742ffa96d073f2312653ef62c93a870987f38b75f9b23e757765ebb20189dcd(
    value: typing.Optional[CloudGcpIntegrationsPubSub],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__956b4d6bbb9c6fc48ac65adf78c228b858931278086b3588614e6fb4e072c89a(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2d1c57ad504f928b84afe6e4000eceaf760d8eb515b5d930ae8f24a06711c72c(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ebb04fb9a81769a3489c0310bc4a6c0e309fc7a8f4d04966c0524281e9f1e638(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__52a287ff01ecf6f39e8373e2671ea8255702c5205490494ad4a87dd48ab04208(
    value: typing.Optional[CloudGcpIntegrationsRedis],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4b1af71adca717beaac75030bf1cd6686bfa885190a9721306880a5ce882f533(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__466c268b6f7e72054af0475e08d4c60fdf568a879b097e0e21aa6a903f8378e7(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d13fe58d6c8fce398ed5c7ddc986021600dda3ed15cda21a983410844c5e10cd(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b7f6cd9f9c3d448831873da58c050e08845ce64acd4b7121baccba05f148134f(
    value: typing.Optional[CloudGcpIntegrationsRouter],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3f21fadca55a410cfc406ad6a3b7d3a76782d7ca0e5835f64261e1b96bbc1e97(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__01c580ddcf9c8874235187553a224ae8d22d164f15f261765ecaaf9f68dd096f(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__53e4e2ae470c2a5249d65fd587112bd0b6cbfc7eb2a0539732248c6e2fb72713(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3cc3e88e7fb34cd287e24ce66fe0d3c44794711996f78bf53eb31e592dc5f513(
    value: typing.Optional[CloudGcpIntegrationsRun],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4c001c0122fc6b480c2ef25ef8dba2e158df287463d7c67541b950998cefff1b(
    *,
    fetch_tags: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__763b82a101c8b1ee3020df1da5b86e60bbc3eb3bdb77379b6def1067ea5948c2(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8016276d4ca726987e995eea66db8dcc2f457d51f223046bef7f6048260bb55c(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c4d90bddcc79a75d686c692bfe3120c1065cac92818c434904e8f37fcd91c27a(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__79fd4081d320ebddc23c7f91f543ea4f1015ab8df2e381e7ec205cb8d88e7ec2(
    value: typing.Optional[CloudGcpIntegrationsSpanner],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8767e3d616f297fe9ac948486b65a2cff1619b2086922c2c3f8df0d805a7c2dd(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f960a7eb1598c8da3c662e9424e409e2d57ae6b727b8ecf46058cc5c265015ec(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__282dc397a2b71851e8f3c8682af9c04f608c44ae4744ef706a3add404d927f1f(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__14251424e42f931cd6afccdb55b4c67f74c157e7555a078a7bc913ab52c8029d(
    value: typing.Optional[CloudGcpIntegrationsSql],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__663d3446397014038f2fd9d55fe82a47bae6b7bba8535c08e4f0c79ceb4b9fb6(
    *,
    fetch_tags: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a3b7590b5685316e4aace992f47f2800dce0f2c0daebfeb09add2dc3914d2e3f(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cee953718357ee2becf0ca02837957811b1bb6bcea09e33925499c6936c60e0c(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__408846694f671ac44acd1e08a9b057835a6485a5019aced1e8cf19ef9dcbde82(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__57b2e2a188c1dc709f58b3f566f7f6017de916ad18fd0cd95be0ac1c61dfffed(
    value: typing.Optional[CloudGcpIntegrationsStorage],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__95b488f0a54947739f902cf97dfd1d551d010ccf097df6ab7ee32a947092d56b(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a77d8899744ac27377aa36eb2754721a535b6585bef77925018cb9cd59b11218(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8180634f6e47a3c5971940cf346fd33582b0313d868c303791edea93363119e0(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ad0a1f2d2cd68c8120c3212c507c2d3fb962bbd22066eecf1032ecc396ad1a9c(
    value: typing.Optional[CloudGcpIntegrationsVirtualMachines],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8ac2d3a2ea899d18e3c20a0aa8ce5b30ce0ee6ee47bca10f0b31e8d2b15d6aef(
    *,
    metrics_polling_interval: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6c18eddee059eceae52df60cc524b9431e79dea07c3c719c9b79cfed8ede2709(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b704777fd37ac434e4a73d02f9af768f2e136c519489d89417a34a22e9bed6bf(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1b0c2476f53e01a361179f810e39355845311d6b1c8812cac13512d7398fa239(
    value: typing.Optional[CloudGcpIntegrationsVpcAccess],
) -> None:
    """Type checking stubs"""
    pass
