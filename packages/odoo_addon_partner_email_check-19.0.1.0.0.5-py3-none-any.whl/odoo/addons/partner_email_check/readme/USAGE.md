This module integrate automatically in all of the view `res.partner`
