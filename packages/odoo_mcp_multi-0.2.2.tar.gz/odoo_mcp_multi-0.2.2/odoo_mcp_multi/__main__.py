"""Entry point for running as python -m odoo_mcp_multi."""

from odoo_mcp_multi.cli import main

if __name__ == "__main__":
    main()
