from ._strategies import openapis
