# nutrifyi

Nutrition data and food composition API client — [nutrifyi.com](https://nutrifyi.com)

## Install

```bash
pip install nutrifyi
```

## Quick Start

```python
from nutrifyi.api import NutriFYI

with NutriFYI() as api:
    results = api.search("banana")
    print(results)
```

## License

MIT
