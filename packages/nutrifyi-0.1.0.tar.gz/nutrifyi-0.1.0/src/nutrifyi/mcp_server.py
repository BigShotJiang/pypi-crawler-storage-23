"""MCP server for nutrifyi."""

from __future__ import annotations

from typing import Any

from mcp.server.fastmcp import FastMCP

from nutrifyi.api import NutriFYI

mcp = FastMCP("nutrifyi")


@mcp.tool()
def search_nutrifyi(query: str) -> dict[str, Any]:
    """Search nutrifyi.com for content matching the query."""
    with NutriFYI() as api:
        return api.search(query)
