"""Command-line interface for nutrifyi."""

from __future__ import annotations

import json

import typer

from nutrifyi.api import NutriFYI

app = typer.Typer(help="NutriFYI — Nutrition data and food composition API client.")


@app.command()
def search(query: str) -> None:
    """Search nutrifyi.com."""
    with NutriFYI() as api:
        result = api.search(query)
        typer.echo(json.dumps(result, indent=2))
