#[cfg(test)]
mod tests {
    use crate::tests::integration::common::{first_text, setup_real_db};

    #[test]
    fn app_users_basic_query() {
        let db = setup_real_db().unwrap();
        let Some(app_id) = first_text(&db, "SELECT id FROM okta_applications LIMIT 1") else {
            return;
        };

        let mut stmt = db
            .prepare("SELECT app_id, id FROM okta_app_users WHERE app_id = ?1 LIMIT 1")
            .unwrap();

        let mut rows = stmt.query([app_id.clone()]).unwrap();
        if let Some(row) = rows.next().unwrap() {
            let row_app_id: String = row.get(0).unwrap();
            let user_id: String = row.get(1).unwrap();
            assert_eq!(row_app_id, app_id);
            assert!(!user_id.is_empty());
        }
    }
}
