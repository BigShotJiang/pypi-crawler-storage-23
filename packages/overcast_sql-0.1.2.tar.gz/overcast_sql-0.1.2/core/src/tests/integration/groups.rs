use crate::tests::integration::common::setup_real_db;

#[test]
fn groups_basic_query() {
    let db = setup_real_db().unwrap();
    let mut stmt = db
        .prepare("SELECT id, name FROM okta_groups LIMIT 1")
        .unwrap();

    let mut rows = stmt.query([]).unwrap();
    if let Some(row) = rows.next().unwrap() {
        let id: String = row.get(0).unwrap();
        let name: String = row.get(1).unwrap();
        assert!(!id.is_empty());
        assert!(!name.is_empty());
    }
}
