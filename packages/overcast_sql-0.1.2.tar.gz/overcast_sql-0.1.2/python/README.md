# overcast-sql

Python bindings for querying Okta data with SQL, powered by a Rust engine.

## Installation

```bash
pip install overcast-sql
```

## Quick start

```python
from overcast_sql import Client

client = Client(
    base_url="https://your-org.okta.com",
    ssws_token="your-ssws-token",
)

rows = client.query("SELECT id, status FROM okta_users LIMIT 5")
print(rows)
```

## Example: applications assigned per user

Runnable in [this notebook](https://github.com/overcast-ai/overcast-sql/blob/main/examples/applications_assigned_per_user.ipynb).

```python
df_direct_user_apps = client.query(
    "SELECT "
    "  user.login AS user_login, "
    "  application.label AS app_label, "
    "  app_user.status AS assignment_status "
    "FROM okta_app_users app_user "
    "JOIN okta_users user ON user.id = app_user.id "
    "JOIN okta_applications application ON application.id = app_user.app_id "
    "ORDER BY user.login, application.label"
)
print(df_direct_user_apps.head(20))
```

Supported formats:

- `json`
- `jsonl`
- `table`
- `pandas`

## Using a `.env` file

Credential loading is handled by your application, not the library. Example:

```python
import os
from dotenv import load_dotenv
from overcast_sql import Client

load_dotenv()

client = Client(
    base_url=os.environ["OKTA_BASE_URL"],
    ssws_token=os.environ["OKTA_SSWS_TOKEN"],
)
```
