"""Command-line interface for TrigDroid."""

from .main import main, cli

__all__ = ['main', 'cli']