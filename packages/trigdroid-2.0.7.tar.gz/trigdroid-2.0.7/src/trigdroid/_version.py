# Version file for build-time import
# This file should have no dependencies to avoid import issues during build
__version__ = "2.0.7"
