#
# Copyright (c) Microsoft Corporation. All Rights Reserved.
#
"""
Module with general Ivy classes
"""


# Exceptions

class IvyError(Exception):
    pass
