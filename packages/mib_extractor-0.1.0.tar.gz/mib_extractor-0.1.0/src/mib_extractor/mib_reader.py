from __future__ import annotations

import logging
from pathlib import Path

import pandas as pd

from .file_loader import file_to_df


class MibDb_Essential:
    """Minimal MIB reader with lazy table loading."""

    def __init__(
        self,
        mib_folder: Path,
        log: logging.Logger | None = None,
    ) -> None:
        self.mib_folder = Path(mib_folder)
        self.log = log or logging.getLogger(__name__)
        self._tables: dict[str, pd.DataFrame] = {}

    def load_table(self, table_name: str) -> None:
        file_path = self.mib_folder / f"{table_name.lower()}.dat"
        self.log.debug("Loading table %s from %s", table_name, file_path)
        table = file_to_df(file_path)
        self._tables[table_name.upper()] = table

    def get_table(self, table_name: str) -> pd.DataFrame:
        name = table_name.upper()
        if name not in self._tables:
            self.load_table(name)
        return self._tables[name]


def get_parametrs_by_spid(mib: MibDb_Essential, spid: int) -> pd.DataFrame:
    plf = mib.get_table("PLF").query(f"SPID == {spid}")
    pcf = mib.get_table("PCF")
    merged = pd.merge(plf, pcf, on="NAME")
    return merged[
        [
            "DESCR",
            "NAME",
            "OFFBY",
            "OFFBI",
            "WIDTH",
            "UNIT",
            "CATEG",
            "CURTX",
            "NATUR",
            "PTC",
            "PFC",
        ]
    ]
