import pandas as pd
# from dev_tools.mib.mib_headers import HEADERS
from pathlib import Path
from .mib_headers import headDict

def file_to_df(fileName: Path) -> pd.DataFrame:
     # log.debug('File name is ' + fileName)
    myShortFileName = fileName.name #(
    #     fileName if fileName.find("/") == -1 else fileName.rsplit("/", 1)[1]
    # )

    myExt = fileName.suffix[1:] #fileName.rsplit(".", 1)[1]
    mySep = ";"
    if myExt == "dat":
        mySep = "\t"
    
    
    # log.debug('Short file name is ' + myShortFileName)
    myHeader = headDict.get(myShortFileName)
    if myHeader is None:
        # log.debug('Header is None ')
        if myExt == "dat":
            df = pd.read_csv(
                fileName, header=None, sep=mySep, encoding="ISO-8859-1", na_filter=False
            )
        else:
            df = pd.read_csv(fileName, sep=mySep, encoding="ISO-8859-1")
    else:
        myCols = [x[0] for x in myHeader[0:]]
        myDtype = [x[1] for x in myHeader[0:]]
        myVal = [x[2] for x in myHeader[0:]]
        if myDtype is None:
            df = pd.read_csv(
                fileName,
                names=myCols,
                sep=mySep,
                encoding="ISO-8859-1",
                na_filter=False,
            )
        else:
            typesDict = dict(zip(myCols, myDtype))
            df = pd.read_csv(
                fileName,
                names=myCols,
                dtype=typesDict,
                sep=mySep,
                encoding="ISO-8859-1",
                na_filter=True,
            )
            for i in range(len(myDtype)):
                # log.debug("Column {0} type {1}, val = {2}".format(myCols[i], myDtype[i], myVal[i]))
                val = myVal[i]

                df[myCols[i]] = df[myCols[i]].fillna(val)
    #            df = df.astype({myCols[i]: myDtype[i]})
    return df

