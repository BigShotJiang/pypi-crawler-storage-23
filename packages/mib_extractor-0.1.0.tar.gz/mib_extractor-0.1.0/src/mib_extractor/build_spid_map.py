from __future__ import annotations

import logging
from pathlib import Path

import pandas as pd

from .time_converter import has_spicepy, scet_to_utc


def build_spid_map_table(mib: object, spids: list[int]) -> pd.DataFrame:
    """Build a serializable table for selected SPIDs."""
    unique_spids = sorted(set(spids))
    if not unique_spids:
        raise ValueError("At least one SPID is required.")

    frames: list[pd.DataFrame] = []
    missing_spids: list[int] = []

    for spid in unique_spids:
        from .mib_reader import get_parametrs_by_spid

        params = get_parametrs_by_spid(mib, spid)
        if params.empty:
            missing_spids.append(spid)
            continue

        ordered = params.sort_values(by=["OFFBY", "OFFBI"]).copy()
        ordered.insert(0, "SPID", spid)
        frames.append(ordered)

    if missing_spids:
        missing = ", ".join(str(item) for item in missing_spids)
        raise ValueError(f"SPID not found in MIB definition: {missing}")
    if not frames:
        raise ValueError("No SPID definitions extracted.")

    return pd.concat(frames, ignore_index=True)


def enrich_scet_metadata(spid_table: pd.DataFrame, date_zero: str) -> pd.DataFrame:
    """Attach SCET conversion metadata using spicepy or date-zero fallback."""
    enriched = spid_table.copy()
    enriched["SCET_MODE"] = ""
    enriched["SCET_ZERO_UTC"] = ""

    mask = (enriched["PTC"] == 9) & (enriched["PFC"] == 17)
    if not mask.any():
        return enriched

    mode = "spicepy" if has_spicepy() else "date_zero_fallback"
    zero_utc = scet_to_utc("0:0", date_zero=date_zero)
    enriched.loc[mask, "SCET_MODE"] = mode
    enriched.loc[mask, "SCET_ZERO_UTC"] = zero_utc
    return enriched


def save_spid_map_table(
    spid_table: pd.DataFrame,
    output_file: Path,
    output_format: str,
) -> Path:
    """Persist SPID definition table in parquet or pickle format."""
    fmt = output_format.lower()
    if fmt not in {"parquet", "pickle"}:
        raise ValueError("Unsupported format. Use 'parquet' or 'pickle'.")

    target = Path(output_file).expanduser().resolve()
    target.parent.mkdir(parents=True, exist_ok=True)

    if fmt == "parquet":
        spid_table.to_parquet(target, index=False)
    else:
        spid_table.to_pickle(target)
    return target


def build_and_save_spid_map(
    mib_folder: Path,
    spids: list[int],
    output_file: Path,
    output_format: str,
    date_zero: str,
) -> Path:
    from .mib_reader import MibDb_Essential

    logger = logging.getLogger(__name__)
    mib = MibDb_Essential(mib_folder=mib_folder, log=logger)
    table = build_spid_map_table(mib=mib, spids=spids)
    table = enrich_scet_metadata(spid_table=table, date_zero=date_zero)
    return save_spid_map_table(
        spid_table=table,
        output_file=output_file,
        output_format=output_format,
    )
