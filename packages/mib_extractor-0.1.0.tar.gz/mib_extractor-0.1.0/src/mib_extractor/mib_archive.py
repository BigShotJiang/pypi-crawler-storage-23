from __future__ import annotations

import csv
import json
import re
import shutil
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Iterable


@dataclass(frozen=True)
class MibRecord:
    code: str
    source_path: str
    cache_path: str
    added_at: str
    dat_files: int


@dataclass(frozen=True)
class SpidRecord:
    spid: int
    descr: str


class MibArchive:
    """Simple local registry + cache for imported MIB folders."""

    def __init__(self, root: Path | None = None) -> None:
        base = Path(root) if root is not None else Path.cwd() / ".mib_archive"
        self.root = base
        self.cache_dir = self.root / "mibs"
        self.registry_path = self.root / "registry.json"
        self.root.mkdir(parents=True, exist_ok=True)
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def add(self, mib_path: Path, code: str | None = None) -> MibRecord:
        source = Path(mib_path).expanduser().resolve()
        if not source.exists() or not source.is_dir():
            raise ValueError(f"MIB path not found or not a directory: {source}")

        dat_files = sorted(source.glob("*.dat"))
        if not dat_files:
            raise ValueError(f"No .dat files found in: {source}")

        registry = self._load_registry()
        resolved_code = code or self._generate_code(source=source, existing_codes=registry.keys())
        if resolved_code in registry:
            raise ValueError(f"Code already exists: {resolved_code}")

        target = self.cache_dir / resolved_code
        if target.exists():
            raise ValueError(f"Cache directory already exists for code: {resolved_code}")

        shutil.copytree(source, target)
        record = MibRecord(
            code=resolved_code,
            source_path=str(source),
            cache_path=str(target.resolve()),
            added_at=datetime.now(UTC).isoformat(timespec="seconds"),
            dat_files=len(dat_files),
        )
        registry[resolved_code] = record.__dict__
        self._save_registry(registry)
        return record

    def remove(self, code: str) -> MibRecord:
        registry = self._load_registry()
        resolved_code = self.resolve_code(code=code, existing_codes=registry.keys())

        record = MibRecord(**registry[resolved_code])
        cache_path = Path(record.cache_path)
        if cache_path.exists():
            shutil.rmtree(cache_path)

        del registry[resolved_code]
        self._save_registry(registry)
        return record

    def rename(self, code: str, new_code: str) -> MibRecord:
        registry = self._load_registry()
        resolved_code = self.resolve_code(code=code, existing_codes=registry.keys())
        if new_code in registry:
            raise ValueError(f"Code already exists: {new_code}")

        record = MibRecord(**registry[resolved_code])
        old_cache = Path(record.cache_path)
        new_cache = self.cache_dir / new_code
        if new_cache.exists():
            raise ValueError(f"Cache directory already exists for code: {new_code}")

        if old_cache.exists():
            old_cache.rename(new_cache)

        updated = MibRecord(
            code=new_code,
            source_path=record.source_path,
            cache_path=str(new_cache.resolve()),
            added_at=record.added_at,
            dat_files=record.dat_files,
        )
        del registry[resolved_code]
        registry[new_code] = updated.__dict__
        self._save_registry(registry)
        return updated

    def list(self) -> list[MibRecord]:
        registry = self._load_registry()
        return [MibRecord(**raw) for raw in registry.values()]

    def get(self, code: str) -> MibRecord:
        registry = self._load_registry()
        resolved_code = self.resolve_code(code=code, existing_codes=registry.keys())
        return MibRecord(**registry[resolved_code])

    def list_spids(self, code: str) -> list[SpidRecord]:
        registry = self._load_registry()
        resolved_code = self.resolve_code(code=code, existing_codes=registry.keys())

        record = MibRecord(**registry[resolved_code])
        pid_file = Path(record.cache_path) / "pid.dat"
        if not pid_file.exists():
            raise ValueError(f"pid.dat not found for code: {resolved_code}")

        spids: dict[int, str] = {}
        with pid_file.open("r", encoding="ISO-8859-1", newline="") as stream:
            reader = csv.reader(stream, delimiter="\t")
            for row in reader:
                if len(row) < 7:
                    continue
                raw_spid = row[5].strip()
                raw_descr = row[6].strip()
                try:
                    spid = int(raw_spid)
                except ValueError:
                    continue
                if spid < 0:
                    continue
                if spid not in spids or (not spids[spid] and raw_descr):
                    spids[spid] = raw_descr

        return [SpidRecord(spid=spid, descr=spids[spid]) for spid in sorted(spids)]

    def resolve_code(self, code: str, existing_codes: Iterable[str] | None = None) -> str:
        codes = list(existing_codes) if existing_codes is not None else list(self._load_registry().keys())
        if code in codes:
            return code

        candidates = sorted(item for item in codes if item.startswith(code))
        if len(candidates) == 1:
            return candidates[0]
        if len(candidates) > 1:
            options = ", ".join(candidates)
            raise ValueError(
                f"Ambiguous code '{code}'. Possible matches: {options}"
            )
        raise ValueError(f"Unknown code: {code}")

    def _generate_code(self, source: Path, existing_codes: Iterable[str]) -> str:
        mission, version = self._extract_mission_and_version(source)
        base_code = f"{self._slugify(mission)}-{self._slugify(version)}"

        existing = set(existing_codes)
        if base_code not in existing:
            return base_code

        suffix = 2
        while f"{base_code}-{suffix}" in existing:
            suffix += 1
        return f"{base_code}-{suffix}"

    def _extract_mission_and_version(self, source: Path) -> tuple[str, str]:
        vdf = source / "vdf.dat"
        if not vdf.exists():
            return source.name, "unknown"

        for line in vdf.read_text(encoding="ISO-8859-1").splitlines():
            if not line.strip():
                continue
            cols = line.split("\t")
            mission = cols[0].strip() if len(cols) > 0 and cols[0].strip() else source.name
            release = cols[3].strip() if len(cols) > 3 else ""
            issue = cols[4].strip() if len(cols) > 4 else ""
            if release and issue:
                version = f"{release}.{issue}"
            elif release:
                version = release
            elif issue:
                version = issue
            else:
                version = cols[1].strip() if len(cols) > 1 and cols[1].strip() else "unknown"
            return mission, version

        return source.name, "unknown"

    def _slugify(self, text: str) -> str:
        return re.sub(r"[^a-z0-9]+", "-", text.strip().lower()).strip("-") or "unknown"

    def _load_registry(self) -> dict[str, dict]:
        if not self.registry_path.exists():
            return {}
        return json.loads(self.registry_path.read_text(encoding="utf-8"))

    def _save_registry(self, registry: dict[str, dict]) -> None:
        content = json.dumps(registry, indent=2, sort_keys=True)
        self.registry_path.write_text(content + "\n", encoding="utf-8")
