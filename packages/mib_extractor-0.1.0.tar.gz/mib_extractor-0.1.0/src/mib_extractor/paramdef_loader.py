from __future__ import annotations

from typing import Any

import pandas as pd

from .parameter_definition import ParamDef


_COLUMN_ALIASES: dict[str, list[str]] = {
    "identifier": ["DESCR", "identifier"],
    "mnemonic": ["NAME", "mnemonic"],
    "byte_location": ["OFFBY", "byte_location"],
    "bit_location": ["OFFBI", "bit_location"],
    "bit_length": ["WIDTH", "bit_length"],
    "unit": ["UNIT", "unit"],
    "category": ["CATEG", "category"],
    "curtx": ["CURTX", "curtx"],
    "natur": ["NATUR", "natur"],
    "ptc": ["PTC", "ptc"],
    "pfc": ["PFC", "pfc"],
}


def _read_field(row: dict[str, Any], logical_name: str) -> Any:
    for candidate in _COLUMN_ALIASES[logical_name]:
        if candidate in row:
            return row[candidate]
    raise ValueError(f"Missing required column for field '{logical_name}'.")


def _as_int(value: Any, field: str) -> int:
    if pd.isna(value):
        raise ValueError(f"Field '{field}' cannot be null.")
    try:
        return int(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"Field '{field}' must be an integer. Got: {value!r}") from exc


def _as_text(value: Any, default: str = "") -> str:
    if pd.isna(value):
        return default
    text = str(value).strip()
    return text if text else default


def dataframe_to_paramdefs(
    dataframe: pd.DataFrame,
    *,
    sort_by_offset: bool = True,
) -> list[ParamDef]:
    """Build a list of ParamDef objects from a SPID-definition DataFrame."""
    if dataframe.empty:
        return []

    rows = dataframe
    if sort_by_offset:
        sort_cols = [col for col in ("OFFBY", "OFFBI", "byte_location", "bit_location") if col in dataframe.columns]
        if sort_cols:
            rows = dataframe.sort_values(by=sort_cols)

    paramdefs: list[ParamDef] = []
    for _, series in rows.iterrows():
        row = series.to_dict()
        paramdefs.append(
            ParamDef(
                identifier=_as_text(_read_field(row, "identifier")),
                mnemonic=_as_text(_read_field(row, "mnemonic")),
                byte_location=_as_int(_read_field(row, "byte_location"), "byte_location"),
                bit_location=_as_int(_read_field(row, "bit_location"), "bit_location"),
                bit_length=_as_int(_read_field(row, "bit_length"), "bit_length"),
                unit=_as_text(_read_field(row, "unit"), default="-"),
                category=_as_text(_read_field(row, "category"), default=""),
                curtx=_as_text(_read_field(row, "curtx"), default=""),
                natur=_as_text(_read_field(row, "natur"), default=""),
                ptc=_as_int(_read_field(row, "ptc"), "ptc"),
                pfc=_as_int(_read_field(row, "pfc"), "pfc"),
            )
        )
    return paramdefs
