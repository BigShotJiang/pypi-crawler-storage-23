from __future__ import annotations

from datetime import UTC, datetime, timedelta
import re


try:
    import spicepy as spice
except ModuleNotFoundError:
    spice = None


def _parse_date_zero(date_zero: str) -> datetime:
    text = date_zero.strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    dt = datetime.fromisoformat(text)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    return dt.astimezone(UTC)


def _parse_scet(scet: str) -> tuple[int, int]:
    cleaned = scet.strip()
    # Accept legacy format like "1/0000000123:45"
    if "/" in cleaned:
        cleaned = cleaned.split("/", 1)[1]

    match = re.fullmatch(r"(\d+):(\d+)", cleaned)
    if not match:
        raise ValueError(f"Invalid SCET format: {scet!r}. Expected 'coarse:fine'.")
    coarse = int(match.group(1))
    fine = int(match.group(2))
    return coarse, fine


def scet_to_utc(scet: str, date_zero: str, spacecraft_id: int = -121) -> str:
    """Convert SCET to UTC using spicepy if available, else date-zero fallback."""
    if spice is not None:
        try:
            et = spice.scs2e(spacecraft_id, scet)
            return spice.et2utc(et, "ISOC", 5) + "Z"
        except Exception:
            # Fallback if kernels are not loaded or scet is unsupported.
            pass

    coarse, fine = _parse_scet(scet)
    epoch = _parse_date_zero(date_zero)
    # Fine ticks are interpreted at 1/65536 second resolution.
    instant = epoch + timedelta(seconds=coarse + (fine / 65536.0))
    return instant.isoformat().replace("+00:00", "Z")


def has_spicepy() -> bool:
    return spice is not None
