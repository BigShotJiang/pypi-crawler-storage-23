from dataclasses import dataclass

from typing import Optional
from .calibration_strategy import CalibrationStrategy

try:
    from bitstring import BitStream
except ModuleNotFoundError:
    BitStream = object  # type: ignore[assignment]

@dataclass(slots=True)
class ParamDef:
    identifier: str
    mnemonic: str
    byte_location: int
    bit_location: int
    bit_length: int
    unit: str
    category: str
    curtx: str
    natur: str
    ptc: int
    pfc: int

    # embedded calibration function
    calibrator: Optional[CalibrationStrategy] = None

    # --- Legacy runtime fields ---
    value: int | None | str = None
    calibrated: float | None | str = None

    # --------------------------------

    @property
    def bit_offset(self) -> int:
        return self.byte_location * 8 + self.bit_location

    @property
    def is_signed(self) -> bool:
        return self.ptc in (2, 4)

    @property
    def is_float(self) -> bool:
        return self.ptc in (5,)

    def build_unpack_format(self) -> str:
        if self.ptc == 2:
            return f"int:{self.bit_length}"      # signed integer
        if self.ptc == 1:
            return f"uint:{self.bit_length}"     # unsigned integer
        if self.ptc == 5:
            if self.bit_length == 32:
                return "float:32"
            if self.bit_length == 64:
                return "float:64"
        return f"uint:{self.bit_length}"


    def reset_runtime(self):
        """
        Utility for cleaning state when reusing object.
        """
        self.value = None
        self.calibrated = None

    def calibrate(self):
        if self.calibrator is None:
            self.calibrated = self.value
        else:
            self.calibrated = self.calibrator(self.value)  # type: ignore

    # =========================================================
    # CORE EXTRACTION METHOD
    # =========================================================

    # def extract(self, packet_hex:str, elem: str) -> int:
    # def extract(self, packet_bytes:bytes, build_unpack_format: str,base_byte_offset: int = 0) -> int | str:
    def extract(self, packet_bytes:BitStream, build_unpack_format: str,base_byte_offset: int = 0) -> int | str:
        """
        Extract raw value from packet bytes.
        """


        # breakpoint()
        # binary = BitStream(bytes=packet_bytes)
        # binary = BitStream(hex=packet_hex)
        bit_offset = (base_byte_offset * 8) + (self.byte_location * 8) + self.bit_location

        val = packet_bytes.unpack(f"bits:{bit_offset},{build_unpack_format}")[1:]
        # breakpoint()
        match len(val):
            case 1:
                val = val[0]
            case 2:
                if self.ptc == 9 and self.pfc == 17:
                    val = f"1/{val[0]:010}:{val[1]}"

        self.value = val # type: ignore
        return val # type: ignore
