from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class CalibrationStrategy(ABC):
    @abstractmethod
    def __call__(self, raw: int) -> Any:
        raise NotImplementedError


class LinearCalibration(CalibrationStrategy):
    __slots__ = ("a", "b")

    def __init__(self, dn1: float, dn2: float, eng1: float, eng2: float) -> None:
        self.a = (eng2 - eng1) / (dn2 - dn1)
        self.b = eng1 - self.a * dn1

    def __call__(self, raw: int) -> float:
        return self.a * raw + self.b


class PolynomialCalibration(CalibrationStrategy):
    __slots__ = ("coeffs",)

    def __init__(self, coeffs: tuple[float, ...] | list[float]) -> None:
        self.coeffs = coeffs

    def __call__(self, raw: int) -> float:
        result = 0.0
        for i, coeff in enumerate(self.coeffs):
            result += coeff * (raw**i)
        return result


class SymbolicCalibration(CalibrationStrategy):
    __slots__ = ("mapping",)

    def __init__(self, mapping: dict[int, str]) -> None:
        self.mapping = mapping

    def __call__(self, raw: int) -> str:
        return self.mapping.get(raw, "UNKNOWN")
