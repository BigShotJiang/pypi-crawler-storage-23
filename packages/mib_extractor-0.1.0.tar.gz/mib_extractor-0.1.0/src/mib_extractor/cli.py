import rich_click as click
import re
from pathlib import Path
from rich.console import Console
from rich.table import Table
from rich.text import Text

from .build_spid_map import build_and_save_spid_map
from .mib_archive import MibArchive

click.rich_click.USE_RICH_MARKDOWN = True
click.rich_click.USE_RICH_TRACEBACK = True
click.rich_click.USE_RICH_ARGUMENTS = True

CONTEXT_SETTINGS = dict(
    help_option_names=['-h', '--help']
    )

@click.group(context_settings=CONTEXT_SETTINGS)
def cli():
    pass


def _archive() -> MibArchive:
    return MibArchive()


def _complete_codes(
    _ctx: click.Context, _param: click.Parameter, incomplete: str
) -> list[str]:
    try:
        rows = _archive().list()
    except Exception:
        return []

    return [
        row.code for row in rows if row.code.startswith(incomplete)
    ]


def _normalize_filter_terms(filters: tuple[str, ...]) -> list[str]:
    terms: list[str] = []
    for value in filters:
        for item in value.split():
            term = item.strip()
            if term:
                terms.append(term)
    return terms


def _description_matches_filters(description: str, terms: list[str]) -> bool:
    if not terms:
        return True
    lowered = description.lower()
    return any(term.lower() in lowered for term in terms)


def _highlight_description(description: str, terms: list[str]) -> Text:
    styled = Text(description)
    for term in terms:
        if not term:
            continue
        for match in re.finditer(re.escape(term), description, flags=re.IGNORECASE):
            styled.stylize("bold yellow", match.start(), match.end())
    return styled


def _normalize_spid_values(raw_spids: tuple[str, ...]) -> list[int]:
    values: list[int] = []
    for raw in raw_spids:
        for item in raw.split(","):
            token = item.strip()
            if not token:
                continue
            try:
                values.append(int(token))
            except ValueError as exc:
                raise click.BadParameter(
                    f"Invalid SPID value '{token}'. Use integer values."
                ) from exc
    unique = sorted(set(values))
    if not unique:
        raise click.BadParameter("At least one SPID is required.")
    return unique


@cli.command(name="add")
@click.argument("mib_path", type=click.Path(path_type=str, exists=True, file_okay=False))
@click.option("--code", help="Unique code to assign to this MIB.")
def add_mib(mib_path: str, code: str | None) -> None:
    """Add a MIB folder to the local archive and cache."""
    try:
        record = _archive().add(mib_path=mib_path, code=code)
    except ValueError as exc:
        raise click.ClickException(str(exc)) from exc
    click.echo(f"Added MIB code={record.code} dat_files={record.dat_files}")
    click.echo(f"Cache: {record.cache_path}")


@cli.command(name="remove")
@click.argument("code", shell_complete=_complete_codes)
def remove_mib(code: str) -> None:
    """Remove a MIB from local archive and delete cached copy."""
    try:
        record = _archive().remove(code=code)
    except ValueError as exc:
        raise click.ClickException(str(exc)) from exc
    click.echo(f"Removed MIB code={record.code}")


@cli.command(name="rename")
@click.argument("code", shell_complete=_complete_codes)
@click.argument("new_code")
def rename_mib(code: str, new_code: str) -> None:
    """Change the code of a MIB entry in the local archive."""
    try:
        record = _archive().rename(code=code, new_code=new_code)
    except ValueError as exc:
        raise click.ClickException(str(exc)) from exc
    click.echo(f"Renamed MIB {code} -> {record.code}")


@cli.command(name="list")
def list_mibs() -> None:
    """List MIB entries stored in the local archive."""
    rows = _archive().list()
    if not rows:
        click.echo("No MIBs in archive.")
        return

    table = Table(title="MIB Archive")
    table.add_column("Code", style="cyan", no_wrap=True)
    table.add_column("DAT files", justify="right")
    table.add_column("Added at", no_wrap=True)
    table.add_column("Source path")
    table.add_column("Cache path")

    for row in rows:
        table.add_row(
            row.code,
            str(row.dat_files),
            row.added_at,
            row.source_path,
            row.cache_path,
        )
    Console().print(table)


@cli.command(name="spids")
@click.argument("code", shell_complete=_complete_codes)
@click.option(
    "--filter",
    "filters",
    multiple=True,
    help="Filter descriptions by keyword. Repeat option for multiple terms.",
)
def list_spids(code: str, filters: tuple[str, ...]) -> None:
    """List SPID and description from pid.dat for a stored MIB."""
    _print_spids(code=code, filters=filters)


@cli.command(name="spid")
@click.argument("code", shell_complete=_complete_codes)
@click.argument("spid", type=int)
def show_spid(code: str, spid: int) -> None:
    """Show one SPID entry by numeric identifier."""
    try:
        archive = _archive()
        resolved_code = archive.resolve_code(code=code)
        rows = archive.list_spids(code=resolved_code)
    except ValueError as exc:
        raise click.ClickException(str(exc)) from exc

    selected = [row for row in rows if row.spid == spid]
    if not selected:
        click.echo(f"SPID {spid} not found for code={resolved_code}")
        return

    table = Table(title=f"SPID {spid} for {resolved_code}")
    table.add_column("SPID", justify="right", style="cyan", no_wrap=True)
    table.add_column("Description")
    for row in selected:
        table.add_row(str(row.spid), row.descr)
    Console().print(table)


def _print_spids(code: str, filters: tuple[str, ...]) -> None:
    try:
        archive = _archive()
        resolved_code = archive.resolve_code(code=code)
        rows = archive.list_spids(code=resolved_code)
    except ValueError as exc:
        raise click.ClickException(str(exc)) from exc

    filter_terms = _normalize_filter_terms(filters)
    filtered_rows = [
        row for row in rows if _description_matches_filters(row.descr, filter_terms)
    ]

    if not filtered_rows:
        if filter_terms:
            click.echo(f"No SPIDs found for code={resolved_code} with the given filter.")
        else:
            click.echo(f"No SPIDs found for code={resolved_code}")
        return

    table = Table(title=f"SPIDs for {resolved_code}")
    table.add_column("SPID", justify="right", style="cyan", no_wrap=True)
    table.add_column("Description")
    for row in filtered_rows:
        table.add_row(str(row.spid), _highlight_description(row.descr, filter_terms))
    Console().print(table)


@cli.command(name="build-spid-map")
@click.argument("code", shell_complete=_complete_codes)
@click.option(
    "--spid",
    "raw_spids",
    multiple=True,
    required=True,
    help="SPID to extract. Repeat option or pass comma-separated values.",
)
@click.option(
    "--output",
    "output_file",
    type=click.Path(path_type=Path, dir_okay=False),
    required=True,
    help="Output file path.",
)
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["parquet", "pickle"], case_sensitive=False),
    required=True,
    help="Output format.",
)
@click.option(
    "--date-zero",
    required=True,
    help="Reference UTC datetime for SCET fallback conversion (ISO, e.g. 2025-01-01T00:00:00Z).",
)
def build_spid_map_command(
    code: str,
    raw_spids: tuple[str, ...],
    output_file: Path,
    output_format: str,
    date_zero: str,
) -> None:
    """Extract selected SPIDs and save a serializable map table."""
    try:
        archive = _archive()
        resolved_code = archive.resolve_code(code=code)
        record = archive.get(code=resolved_code)
        spids = _normalize_spid_values(raw_spids)
        saved_to = build_and_save_spid_map(
            mib_folder=Path(record.cache_path),
            spids=spids,
            output_file=output_file,
            output_format=output_format,
            date_zero=date_zero,
        )
    except ValueError as exc:
        raise click.ClickException(str(exc)) from exc
    click.echo(
        f"Saved SPID map for {resolved_code} ({len(spids)} SPID) to {saved_to} [{output_format.lower()}]"
    )
