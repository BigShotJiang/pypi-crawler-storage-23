header_vdf = [
        ["NAME", "str", ""],
        ["COMMENT", "str", ""],
        ["DOMAINID", "Int64", -9999],
        ["RELEASE", "Int64", 0],
        ["ISSUE", "Int64", 0],
    ]

header_pcf = [
    ["NAME", "str", ""],
    ["DESCR", "str", ""],
    ["PID", "Int64", 0],
    ["UNIT", "str", ""],
    ["PTC", "Int64", 0],
    ["PFC", "Int64", 0],
    ["WIDTH", "Int64", 0],
    ["VALID", "str", ""],
    ["RELATED", "str", ""],
    ["CATEG", "str", "X"],
    ["NATUR", "str", "X"],
    ["CURTX", "str", ""],
    ["INTER", "str", "F"],
    ["USCON", "str", "N"],
    ["DECIM", "Int64", -9999],
    ["PARVAL", "str", ""],
    ["SUBSYS", "str", ""],
    ["VALPAR", "Int64", 1],
    ["SPTYPE", "str", "R"],
    ["CORR", "str", "Y"],
    ["OBTID", "Int64", -9999],
    ["DARC", "str", "0"],
    ["ENDIAN", "str", "B"],
    ["DESCR2", "str", ""],
]

header_cur = [
    ["PNAME", "str", ""],
    ["POS", "Int64", -9999],
    ["RLCHK", "str", ""],
    ["VALPAR", "Int64", -9999],
    ["SELECT", "str", ""],
]

header_caf = [
    ["NUMBR", "str", ""],
    ["DESCR", "str", ""],
    ["ENGFMT", "str", ""],
    ["RAWFMT", "str", ""],
    ["RADIX", "str", ""],
    ["UNIT", "str", ""],
    ["NCURVE", "Int64", -9999],
    ["INTER", "str", "F"],
]

header_cap = [["NUMBR", "str", ""], ["XVALS", "Float64", "0"], ["YVALS", "Float64", "0"]]

header_txf = [
    ["NUMBR", "str", ""],
    ["DESCR", "str", ""],
    ["RAWFMT", "str", ""],
    ["NALIAS", "Int64", -9999],
]

header_txp = [
    ["NUMBR", "str", ""],
    ["FROM", "str", ""],
    ["TO", "str", ""],
    ["ALTXT", "str", ""],
]

header_mcf = [
    ["IDENT", "str", ""],
    ["DESCR", "str", ""],
    ["POL1", "float64", 0.0],
    ["POL2", "float64", 0.0],
    ["POL3", "float64", 0.0],
    ["POL4", "float64", 0.0],
    ["POL5", "float64", 0.0],
]

header_lgf = [
    ["IDENT", "str", ""],
    ["DESCR", "str", ""],
    ["POL1", "float64", 0.0],
    ["POL2", "float64", 0.0],
    ["POL3", "float64", 0.0],
    ["POL4", "float64", 0.0],
    ["POL5", "float64", 0.0],
]

header_ocf = [
    ["NAME", "str", ""],
    ["NBCHCK", "Int64", -9999],
    ["NBOOL", "Int64", -9999],
    ["INTER", "str", ""],
    ["CODIN", "str", ""],
]

header_ocp = [
    ["NAME", "str", ""],
    ["POS", "Int64", -9999],
    ["TYPE", "str", ""],
    ["LVALU", "str", ""],
    ["HVALU", "str", ""],
    ["RLCHK", "str", ""],
    ["VALPAR", "Int64", 1],
]

header_pid = [
    ["TYPE", "Int64", -9999],
    ["STYPE", "Int64", -9999],
    ["APID", "Int64", -9999],
    ["PI1_VAL", "Int64", 0],
    ["PI2_VAL", "Int64", 0],
    ["SPID", "Int64", -9999],
    ["DESCR", "str", ""],
    ["UNIT", "str", ""],
    ["TPSD", "Int64", -1],
    ["DFHSIZE", "Int64", -9999],
    ["TIME", "str", "N"],
    ["INTER", "Int64", -9999],
    ["VALID", "str", "Y"],
    ["CHECK", "Int64", 0],
    ["EVENT", "str", "N"],
    ["EVID", "str", ""],
]

header_pic = [
    ["TYPE", "Int64", -9999],
    ["STYPE", "Int64", -9999],
    ["PI1_OFF", "Int64", -9999],
    ["PI1_WID", "Int64", -9999],
    ["PI2_OFF", "Int64", -9999],
    ["PI2_WID", "Int64", -9999],
    ["APID", "Int64", 99999],
]

header_tpcf = [
    ["SPID", "Int64", -9999],
    ["NAME", "str", ""],
    [" SIZE", "Int64", -9999],
]

header_plf = [
    ["NAME", "str", ""],
    ["SPID", "Int64", -9999],
    ["OFFBY", "Int64", -9999],
    ["OFFBI", "Int64", -9999],
    ["NBOCC", "Int64", 1],
    ["LGOCC", "Int64", 0],
    ["TIME", "Int64", 0],
    ["TDOCC", "Int64", 1],
]

header_vpd = [
    ["TPSD", "Int64", -9999],
    ["POS", "Int64", -9999],
    ["NAME", "str", ""],
    ["GRPSIZE", "Int64", 0],
    ["FIXREP", "Int64", 0],
    ["CHOICE", "str", "N"],
    ["PIDREF", "str", "N"],
    ["DISDESC", "str", ""],
    ["WIDTH", "Int64", -9999],
    ["JUSTIFY", "str", "L"],
    ["NEWLINE", "str", "N"],
    ["DCHAR", "Int64", 0],
    ["FORM", "str", "N"],
    ["OFFSET", "Int64", 0],
]

header_grp = [["NAME", "str", ""], ["DESCR", "str", ""], ["GTYPE", "str", ""]]

header_grpa = [["GNAME", "str", ""], ["PANAME", "str", ""]]

header_grpk = [["GNAME", "str", ""], ["PKSPID", "Int64", -9999]]

header_dpf = [["NUMBE", "str", ""], ["TYPE", "str", ""], ["HEAD", "str", ""]]

header_dpc = [
    ["NUMBE", "str", ""],
    ["NAME", "str", ""],
    ["FLDN", "Int64", -9999],
    ["COMM", "Int64", 0],
    ["MODE", "str", "Y"],
    ["FORM", "str", "N"],
    ["TEXT", "str", ""],
]

header_gpf = [
    ["NUMBE", "str", ""],
    ["TYPE", "str", ""],
    ["HEAD", "str", ""],
    ["SCROL", "str", "N"],
    ["HCOPY", "str", "N"],
    ["DAYS", "Int64", -9999],
    ["HOURS", "Int64", -9999],
    ["MINUT", "Int64", -9999],
    ["AXCLR", "str", ""],
    ["XTICK", "Int64", -9999],
    ["YTICK", "Int64", -9999],
    ["XGRID", "Int64", -9999],
    ["YGRID", "Int64", -9999],
    ["UPUN", "Int64", -9999],
]

header_gpc = [
    ["NUMBE", "str", ""],
    ["POS", "Int64", -9999],
    ["WHERE", "str", ""],
    ["NAME", "str", ""],
    ["RAW", "str", "C"],
    ["MINIM", "str", ""],
    ["MAXIM", "str", ""],
    ["PRCLR", "str", ""],
    ["SYMB0", "str", "0"],
    ["LINE", "str", "0"],
    ["DOMAIN", "Int64", -9999],
]

header_spf = [
    ["NUMBE", "str", ""],
    ["HEAD", "str", ""],
    ["NPAR", "Int64", -9999],
    ["UPUN", "Int64", -9999],
]

header_spc = [
    ["NUMBE", "str", ""],
    ["POS", "Int64", -9999],
    ["NAME", "str", ""],
    ["UPDT", "str", ""],
    ["MODE", "str", ""],
    ["FORM", "str", "N"],
    ["BACK", "str", "0"],
    ["FORE", "str", ""],
]

header_ppf = [["NUMBE", "str", ""], ["HEAD", "str", ""], ["NBPR", "Int64", -9999]]

header_ppc = [
    ["NUMBE", "str", ""],
    ["POS", "Int64", -9999],
    ["NAME", "str", ""],
    ["FORM", "str", "N"],
]

header_tcp = [["ID", "str", ""], ["DESC", "str", ""]]

header_pcpc = [["PNAME", "str", ""], ["DESC", "str", ""], ["CODE", "str", "U"]]

header_pcdf = [
    ["TCNAME", "str", ""],
    ["DESC", "str", ""],
    ["TYPE", "str", ""],
    ["LEN", "Int64", -9999],
    ["BIT", "Int64", -9999],
    ["PNAME", "str", ""],
    ["VALUE", "str", ""],
    ["RADIX", "str", "H"],
]

header_ccf = [
    ["CNAME", "str", ""],
    ["DESCR", "str", ""],
    ["DESCR2", "str", ""],
    ["CTYPE", "str", ""],
    ["CRITICAL", "str", "N"],
    ["PKTID", "str", ""],
    ["TYPE", "Int64", -9999],
    ["STYPE", "Int64", -9999],
    ["APID", "Int64", -9999],
    ["NPARS", "Int64", -9999],
    ["PLAN", "str", "N"],
    ["EXEC", "str", "Y"],
    ["ILSCOPE", "str", "N"],
    ["ILSTAGE", "str", "C"],
    ["SUBSYS", "Int64", -9999],
    ["HIPRI", "str", "N"],
    ["MAPID", "Int64", -9999],
    ["DEFSET", "str", ""],
    ["RAPID", "Int64", -9999],
    ["ACK", "Int64", -9999],
    ["SUBSCHEDID", "Int64", -9999],
]

header_dst = [["APID", "Int64", -9999], ["ROUTE", "str", ""]]

header_cpc = [
    ["PNAME", "str", ""],
    ["DESC", "str", ""],
    ["PTC", "Int64", -9999],
    ["PFC", "Int64", -9999],
    ["DISPFMT", "str", "R"],
    ["RADIX", "str", "D"],
    ["UNIT", "str", ""],
    ["CATEG", "str", "N"],
    ["PRFREF", "str", ""],
    ["CCAREF", "str", ""],
    ["PAFREF", "str", ""],
    ["INTER", "str", "R"],
    ["DEFVAL", "str", ""],
    ["CORR", "str", "Y"],
    ["OBTID", "str", "N"],
    ["DESCR2", "str", ""],
    ["ENDIAN", "str", "B"],
]

header_cdf = [
    ["CNAME", "str", ""],
    ["ELTYPE", "str", ""],
    ["DESCR", "str", ""],
    ["ELLEN", "Int64", -9999],
    ["BIT", "Int64", -9999],
    ["GRPSIZE", "Int64", 0],
    ["PNAME", "str", ""],
    ["INTER", "str", ""],
    ["VALUE", "str", ""],
    ["TMID", "str", ""],
]

header_ptv = [
    ["CNAME", "str", ""],
    ["PARNAM", "str", ""],
    ["INTER", "str", "R"],
    ["VAL", "str", ""],
]

header_csf = [
    ["NAME", "str", ""],
    ["DESC", "str", ""],
    ["DESCR2", "str", ""],
    ["IFTT", "str", "N"],
    ["NFPARS", "Int64", -9999],
    ["ELEMS", "Int64", -9999],
    ["CRITICAL", "str", "N"],
    ["PLAN", "str", "N"],
    ["EXEC", "str", "Y"],
    ["SUBSYS", "Int64", -9999],
    ["GENTIME", "str", ""],
    ["DOCNAME", "str", ""],
    ["ISSUE", "str", ""],
    ["DATE", "str", ""],
    ["DEFSET", "str", ""],
    ["SUBSCHEDID", "Int64", -9999],
]

header_css = [
    ["SQNAME", "str", ""],
    ["COMM", "str", ""],
    ["ENTRY", "Int64", -9999],
    ["TYPE", "str", ""],
    ["ELEMID", "str", ""],
    ["NPARS", "Int64", -9999],
    ["MANDISP", "str", "N"],
    ["RELTYPE", "str", "R"],
    ["RELTIME", "str", ""],
    ["EXTIME", "str", ""],
    ["PREVREL", "str", "R"],
    ["GROUP", "str", ""],
    ["BLOCK", "str", ""],
    ["ILSCOPE", "str", ""],
    ["ILSTAGE", "str", ""],
    ["DYNPTV", "str", "N"],
    ["STAPTV", "str", "N"],
    ["CEV", "str", "N"],
]

header_sdf = [
    ["SQNAME", "str", ""],
    ["ENTRY", "Int64", -9999],
    ["ELEMID", "str", ""],
    ["POS", "Int64", -9999],
    ["PNAME", "str", ""],
    ["FTYPE", "str", "E"],
    ["VTYPE", "str", ""],
    ["VALUE", "str", ""],
    ["VALSET", "str", ""],
    ["REPPOS", "Int64", -9999],
]

header_csp = [
    ["SQNAME", "str", ""],
    ["FPNAME", "str", ""],
    ["FPNUM", "Int64", -9999],
    ["DESCR", "str", ""],
    ["PTC", "Int64", -9999],
    ["PFC", "Int64", -9999],
    ["DISPFMT", "str", "R"],
    ["RADIX", "str", "D"],
    ["TYPE", "str", ""],
    ["VTYPE", "str", ""],
    ["DEFVAL", "str", ""],
    ["CATEG", "str", "N"],
    ["PRFREF", "str", ""],
    ["CCAREF", "str", ""],
    ["PAFREF", "str", ""],
    ["UNIT", "str", ""],
]

header_cvs = [
    ["ID", "Int64", -9999],
    ["TYPE", "str", ""],
    ["SOURCE", "str", ""],
    ["START", "Int64", -9999],
    ["INTERVAL", "Int64", -9999],
    ["SPID", "Int64", -9999],
    ["UNCERTAINTY", "Int64", -9999],
]

header_cve = [
    ["CVSID", "Int64", -9999],
    ["PARNAM", "str", ""],
    ["INTER", "str", "R"],
    ["VAL", "str", ""],
    ["TOL", "str", ""],
    ["CHECK", "str", "B"],
]

header_cvp = [["TASK", "str", ""], ["TYPE", "str", ""], ["CVSID", "Int64", -9999]]

header_pst = [["NAME", "str", ""], ["DESC", "str", ""]]

header_psv = [["NAME", "str", ""], ["PVSID", "str", ""], ["DESC", "str", ""]]

header_cps = [["NAME", "str", ""], ["PAR", "str", ""], ["BIT", "Int64", -9999]]

header_pvs = [
    ["ID", "str", ""],
    ["PSID", "str", ""],
    ["PNAME", "str", ""],
    ["INTER", "str", "R"],
    ["VALS", "str", ""],
    ["BIT", "Int64", -9999],
]

header_psm = [["NAME", "str", ""], ["TYPE", "str", ""], ["PARSET", "str", ""]]

header_cca = [
    ["NUMBR", "str", ""],
    ["DESCR", "str", ""],
    ["ENGFMT", "str", "R"],
    ["RAWFMT", "str", "U"],
    ["RADIX", "str", "D"],
    ["UNIT", "str", ""],
    ["NCURVE", "Int64", -9999],
]

header_ccs = [["NUMBR", "str", ""], ["XVALS", "Int64", ""], ["YVALS", "Int64", ""]]

header_paf = [
    ["NUMBR", "str", ""],
    ["DESCR", "str", ""],
    ["RAWFMT", "str", "U"],
    ["NALIAS", "Int64", -9999],
]

header_pas = [["NUMBR", "str", ""], ["ALTXT", "str", ""], ["ALVAL", "str", ""]]

header_prf = [
    ["NUMBR", "str", ""],
    ["DESCR", "str", ""],
    ["INTER", "str", "R"],
    ["DSPFMT", "str", "U"],
    ["RADIX", "str", "D"],
    ["NRANGE", "Int64", -9999],
    ["UNIT", "str", ""],
]

header_prv = [["NUMBR", "str", ""], ["MINVAL", "str", ""], ["MAXVAL", "str", ""]]

headDict = {
    "vdf.dat": header_vdf,
    "pcf.dat": header_pcf,
    "cur.dat": header_cur,
    "caf.dat": header_caf,
    "cap.dat": header_cap,
    "txf.dat": header_txf,
    "txp.dat": header_txp,
    "mcf.dat": header_mcf,
    "lgf.dat": header_lgf,
    "ocf.dat": header_ocf,
    "ocp.dat": header_ocp,
    "pid.dat": header_pid,
    "pic.dat": header_pic,
    "tpcf.dat": header_tpcf,
    "plf.dat": header_plf,
    "vpd.dat": header_vpd,
    "grp.dat": header_grp,
    "grpa.dat": header_grpa,
    "grpk.dat": header_grpk,
    "dpf.dat": header_dpf,
    "dpc.dat": header_dpc,
    "gpf.dat": header_gpf,
    "gpc.dat": header_gpc,
    "spf.dat": header_spf,
    "spc.dat": header_spc,
    "ppf.dat": header_ppf,
    "ppc.dat": header_ppc,
    "tcp.dat": header_tcp,
    "pcpc.dat": header_pcpc,
    "pcdf.dat": header_pcdf,
    "ccf.dat": header_ccf,
    "dst.dat": header_dst,
    "cpc.dat": header_cpc,
    "cdf.dat": header_cdf,
    "ptv.dat": header_ptv,
    "csf.dat": header_csf,
    "css.dat": header_css,
    "sdf.dat": header_sdf,
    "csp.dat": header_csp,
    "cvs.dat": header_cvs,
    "cve.dat": header_cve,
    "cvp.dat": header_cvp,
    "pst.dat": header_pst,
    "psv.dat": header_psv,
    "cps.dat": header_cps,
    "pvs.dat": header_pvs,
    "psm.dat": header_psm,
    "cca.dat": header_cca,
    "ccs.dat": header_ccs,
    "paf.dat": header_paf,
    "pas.dat": header_pas,
    "prf.dat": header_prf,
    "prv.dat": header_prv,
}