"""Allow ``python -m cvc`` to start the CLI."""
from cvc.cli import main

main()
