"""
The module `yaw_rail` implements utilities and data handles for the
*yet_another_wizz* wrapper in `rail.estimation.algos.cc_yaw.py`.
"""

from rail.estimation.algos.cc_yaw import *

from ._version import __version__
