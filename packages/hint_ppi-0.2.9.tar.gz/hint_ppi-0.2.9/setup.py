"""Install script for setuptools."""
from setuptools import find_packages
from setuptools import setup

setup(
    name='HInt-ppi',
    version='0.2.9',
    description=(
        'A tool to find homologous interactions and speed up AlphaFold-based structural modeling.'
    ),
    author='Quentin Rouger',
    author_email='quentin.rouger@univ-rennes.fr',
    license='GPL-3.0 license',
    url='https://github.com/Qrouger/HInt',
    include_package_data=True,
    packages=find_packages(),
    install_requires=[
        'alphapulldown==2.1.8',
        'matplotlib',
        'nvidia-ml-py',
        'torch==2.4.0',
        'ihm',
        'scipy==1.16.0',
        #'colabfold[alphafold-minus-jax] @ git+https://github.com/sokrypton/ColabFold',
        'jax[cuda12]==0.5.3',
        'numpy==1.26.4',
        'torchdata==0.9.0',
        'pandas',
        'pydantic',
        'packaging',
        'opt_einsum',
        'torch-geometric'
    ],
    entry_points={'console_scripts': ['HInt=HInt.HInt:main',],}
)
