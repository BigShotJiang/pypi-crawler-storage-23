"""
The index.html file has been uploaded to 'danialcalayt' >
yta_resources > otros > web_resources > animation'
"""
from yta_web_resources import _WebResourceAnimatable


class _AnimationWebResource(_WebResourceAnimatable):
    """
    *For internal use only*

    Web resource to create a simple animation with
    different consecutive frames.

    This is associated with the `web.animation.index.html`
    resource.
    """

    _element_id: str = 'container'

# Instances to export here below
AnimationWebResource = lambda do_use_local_url = True, do_use_gui = False: _AnimationWebResource(
    local_path = 'src/yta_web_resources/web/animation/index.html',
    google_drive_direct_download_url = 'https://drive.google.com/file/d/1jf0RvU326_p7r3rXOT0REbd2jqESu445/view?usp=sharing',
    do_use_local_url = do_use_local_url,
    do_use_gui = do_use_gui
)