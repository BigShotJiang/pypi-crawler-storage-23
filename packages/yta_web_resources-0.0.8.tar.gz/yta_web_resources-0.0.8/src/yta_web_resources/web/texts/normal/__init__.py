from yta_web_resources import _WebResource
from yta_general_utils.url.dataclasses import UrlParameters, UrlParameter


class _TextNormalQuizzWebResource(_WebResource):
    """
    *For internal use only*

    Web resource to create a quizz and download the
    different elements.
    """

    _element_id: str = 'capture'

    # TODO: Add 'color' to be more customizable

# Instances to export here below
TextNormalQuizzWebResource = lambda do_use_local_url = True, do_use_gui = False: _TextNormalQuizzWebResource(
    local_path = 'src/yta_web_resources/web/text/normal/index.html',
    # TODO: This is not the real one
    google_drive_direct_download_url = 'https://drive.google.com/file/d/1iHkWSqQ1Fbc9wzd1B3NweHc25VDwnUl7/view?usp=sharing',
    do_use_local_url = do_use_local_url,
    do_use_gui = do_use_gui
)