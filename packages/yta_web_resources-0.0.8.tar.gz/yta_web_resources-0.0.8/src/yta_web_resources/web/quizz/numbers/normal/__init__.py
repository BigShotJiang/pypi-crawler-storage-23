from yta_web_resources import _WebResource
from yta_general_utils.url.dataclasses import UrlParameters, UrlParameter
from typing import Union


class _NumberNormalQuizzWebResource(_WebResource):
    """
    *For internal use only*

    Web resource to create a quizz and download the
    different elements.
    """

    _element_id: str = 'capture'

    # TODO: I should limitate it to a specific width (?)
    def get_frame(
        self,
        number: str,
        do_include_alpha: bool = True,
        output_filename: Union[str, None] = None
    ) -> Union[str, bytes]:
        parameters = UrlParameters([
            UrlParameter('n', number)
        ])

        return self._get_frame(
            parameters = parameters,
            do_include_alpha = do_include_alpha,
            output_filename = output_filename
        )

# Instances to export here below
NumberNormalQuizzWebResource = lambda do_use_local_url = True, do_use_gui = False: _NumberNormalQuizzWebResource(
    local_path = 'src/yta_web_resources/web/quizz/numbers/normal/index.html',
    # TODO: This is not the real one
    google_drive_direct_download_url = 'https://drive.google.com/file/d/1iHkWSqQ1Fbc9wzd1B3NweHc25VDwnUl7/view?usp=sharing',
    do_use_local_url = do_use_local_url,
    do_use_gui = do_use_gui
)