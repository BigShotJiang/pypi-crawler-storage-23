#
# Copyright (c) 2019 - 2026 Geode-solutions. All rights reserved.
#

import opengeode
import geode_common

from .lib64.geode_conversion_py_model import *

ConversionModelLibrary.initialize()
