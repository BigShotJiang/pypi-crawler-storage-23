#!/usr/bin/env bash

MYDIR="${0%/*}"
CONFIG_BASE=~/.config/bscli
API_CONFIG_PATH=${CONFIG_BASE}/bsapi.json
TOKEN_PATH=${CONFIG_BASE}/token.json

# Do quick check to see if dependencies are installed
if ! command -v virtualenv >/dev/null 2>&1
then
    echo FATAL ERROR: virtualenv not found
    exit 1
fi

if ! command -v python3 >/dev/null 2>&1
then
    echo FATAL ERROR: python3 not found
    exit 1
fi

pushd ${MYDIR}

echo [+] Creating venv...
virtualenv venv
cd venv
source bin/activate

echo
echo [+] Installing dependencies...
if ! python3 -m pip install brightspace-api;
then
    echo FATAL ERROR: could not install brightspace-api
    popd
    exit 2
fi

if ! python3 -m pip install bscli;
then
    echo FATAL ERROR: could not install bscli
    popd
    exit 2
fi

echo
echo [+] Running upload script

if [ -f "${API_CONFIG_PATH}" ] && [ -f "${TOKEN_PATH}" ] && [ "$1" != "--force-local" ]; then
    echo [i] Using persistent API access
    bscli feedback upload ../..
else
    echo [i] Using local API access
    if [ "$1" != "--force-local" ]; then
        echo [i] Run ./data/persist_token.sh afterwards for persistent API access
    fi
    bscli feedback upload ../.. --config-dir ..
fi

echo
echo [+] Removing venv
deactivate
cd ..
rm -rf venv/

popd
