"""FastAPI application for pen test framework."""
