"""This module contains common Pytest fixtures and hooks for CB Kit Pytest unit tests."""

# from cloudbeat_pytest.plugin import
# pytest_plugins = ["pytester", "cloudbeat_pytest"]
pytest_plugins = 'pytester'
