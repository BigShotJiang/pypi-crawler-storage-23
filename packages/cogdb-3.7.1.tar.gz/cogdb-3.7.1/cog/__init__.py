def cog():
	return "Cog is alive."
