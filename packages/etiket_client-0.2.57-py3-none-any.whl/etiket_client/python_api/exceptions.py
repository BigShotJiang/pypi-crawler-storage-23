class DatasetNotFoundException(Exception):
    pass