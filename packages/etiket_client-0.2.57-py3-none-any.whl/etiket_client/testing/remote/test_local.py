# from etiket_client.remote.endpoints.user import user_read_me

# from etiket_client.remote.authenticate import login, logout
# from etiket_client.remote.endpoints.scope import scope_read, scope_read_many

from etiket_client.local.models.dataset import DatasetCreate, DatasetUpdate, DatasetRead, DatasetSearch, DatasetSelection
from etiket_client.local.dao.dataset import dao_dataset


from etiket_client.local.dao.dataset import dao_dataset
from etiket_client.local.dao.schema import dao_schema

import uuid, datetime

from etiket_client.local.database import Session
from etiket_client.sync.native.sync_scopes import sync_scopes

from etiket_client.remote.endpoints.version import api_version

with Session() as session:
    # dc = DatasetCreate(uuid=uuid.uuid4(), collected=datetime.datetime.now(), name="new ds", 
    #               creator="qDrive", keywords=[], ranking=0, scope_uuid='3fa85f64-5717-4562-b3fc-2c963f66afa6',
    #               attributes={"setup" : "XLD"}, notes='test')
    # dao_dataset.create(dc, session)


    # ds= DatasetSearch(has_notes = True)
    # out  = dao_dataset.search(ds, limit=10, session= session)

    sync_scopes(session)
    # for o in out:
    #     print(o.name)
    #     print(o.notes)

    # schema = dao_schema.read_all(session)
    # print(schema)

    print(api_version())

from qdrive.dataset.dataset import dataset
dsq = dataset("6dd78b51-5b9d-4784-9896-f1e81d3279c2")
dsx = dsq['measured_data_ct'].xarray

