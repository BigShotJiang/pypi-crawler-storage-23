from etiket_client.remote.endpoints.user import user_read_me

from etiket_client.remote.authenticate import login, logout
from etiket_client.remote.endpoints.scope import scope_read, scope_list

from etiket_client.remote.endpoints.models.dataset import DatasetCreate, DatasetUpdate, DatasetRead, DatasetSearch, DatasetSelection
from etiket_client.remote.endpoints.dataset import dataset_create, dataset_read, dataset_update, dataset_search,dataset_attributes

import uuid, datetime
print('doing things')
# login(username = "test_user", password = "test")

user = user_read_me()

# print(user)

# scope = scope_read('3fa85f64-5717-4562-b3fc-2c963f66afa6')

# print(scope)

# scopes = scope_read_many()

# print(scopes)

# u = uuid.uuid4()
# dc = DatasetCreate(uuid=u, collected=datetime.datetime.now(), name="new ds", 
#               creator="qDrive", keywords=[], ranking=0, scope_uuid='3fa85f64-5717-4562-b3fc-2c963f66afa6',
#               attributes={"setup" : "XLD"})
# dataset_create(dc)

dc = DatasetCreate(uuid=uuid.uuid4(), collected=datetime.datetime.now(), name="new ds", 
              creator="qDrive", keywords=[], ranking=0, scope_uuid='3fa85f64-5717-4562-b3fc-2c963f66afa6',
              attributes={"setup" : "XLD"}, notes='test')
dataset_create(dc)

# u = uuid.UUID("37e333ed-97f3-41f4-bd70-56f31b077a90")

# read = dataset_read(u)

# du = DatasetUpdate(description="test12356")

# dataset_update(dc.uuid, du)

# read = dataset_read(dc.uuid)

ds= DatasetSearch(has_notes = True)
out  = dataset_search(ds, limit=10)
# dss = DatasetSelection()

# out = dataset_attributes(dss)
# print(out)

ds= DatasetSearch(ranking=10, 
    # scope_uuids=["3fa89f64-5717-4562-b3fc-2c963f68afa6"], 
    attributes={
    # "sample": ["SQ23-52-3-7"], 
    # "set-up": ["OxfordF006"]
    },
    search_query="rabi qubit 3"
    )
out  = dataset_search(ds, limit=1)
print(out)
for o in out:
    print(o.name)
    print(o.notes)
