import pytest
from etiket_client.local.dao.dataset_utitlity import format_search_query_for_sqlite

def test_basic_search():
    """Test basic word searching"""
    assert format_search_query_for_sqlite("word") == "word*"
    assert format_search_query_for_sqlite("word1 word2") == "word1* word2*"
    assert format_search_query_for_sqlite("  word1   word2  ") == "word1* word2*"

def test_quoted_phrases():
    """Test handling of quoted phrases"""
    assert format_search_query_for_sqlite('"exact phrase"') == '"exact phrase"*'
    assert format_search_query_for_sqlite('"exact phrase" word') == '"exact phrase"* word*'
    assert format_search_query_for_sqlite('word "exact phrase"') == 'word* "exact phrase"*'
    assert format_search_query_for_sqlite('"phrase1" "phrase2"') == 'phrase1* phrase2*'

def test_special_characters():
    """Test handling of special characters"""
    assert format_search_query_for_sqlite("word-with-dash") == '"word with dash"*'
    assert format_search_query_for_sqlite("word_with_underscore") == '"word with underscore"*'
    assert format_search_query_for_sqlite("two.words") == '"two words"*'
    assert format_search_query_for_sqlite("word1-word2 word3") == '"word1 word2"* word3*'

def test_empty_inputs():
    """Test handling of empty or null inputs"""
    assert format_search_query_for_sqlite("") is None
    assert format_search_query_for_sqlite(None) is None
    assert format_search_query_for_sqlite("   ") is None
    assert format_search_query_for_sqlite('"""') is None  # Only quotes

def test_special_chars_only():
    """Test strings with only special characters"""
    assert format_search_query_for_sqlite("---") is None
    assert format_search_query_for_sqlite(".,;!?") is None
    assert format_search_query_for_sqlite('"-"') is None

def test_mixed_cases():
    """Test complex mixed cases"""
    assert format_search_query_for_sqlite('keyword1 keyword2 "exact-phrase with.symbols" another-word word') == 'keyword1* keyword2* "exact phrase with symbols"* "another word"* word*'
    assert format_search_query_for_sqlite('"first phrase" middle-word "last phrase"') == '"first phrase"* "middle word"* "last phrase"*'

def test_numbers_and_alphanumeric():
    """Test numbers and alphanumeric strings"""
    assert format_search_query_for_sqlite("abc123") == "abc123*"
    assert format_search_query_for_sqlite("123") == "123*"
    assert format_search_query_for_sqlite("test-123") == '"test 123"*'

def test_unicode_characters():
    """Test handling of unicode/non-ASCII characters"""
    assert format_search_query_for_sqlite("café") == 'café*'  # Note: non-ASCII chars become spaces
    assert format_search_query_for_sqlite("résumé") == 'résumé*'

def test_unbalanced_quotes():
    """Test behavior with unbalanced quotes"""
    assert format_search_query_for_sqlite('"unclosed quote') == 'unclosed* quote*'
    assert format_search_query_for_sqlite('start quote"') == 'start* quote*'
    assert format_search_query_for_sqlite('before "middle words after') == 'before* middle* words* after*'

def test_consecutive_quotes():
    """Test with consecutive quotes"""
    assert format_search_query_for_sqlite('"phrase1""phrase2"') == 'phrase1* phrase2*'
    assert format_search_query_for_sqlite('"one""two""three"') == 'one* two* three*'
    assert format_search_query_for_sqlite('"phrase1""""phrase2"') == 'phrase1* phrase2*'

def test_mixed_edge_cases():
    """Test combinations of edge cases"""
    # Unbalanced + consecutive
    assert format_search_query_for_sqlite('"phrase1""phrase2') == 'phrase1* phrase2*'
    
    # Special characters + unbalanced quotes
    assert format_search_query_for_sqlite('"special-chars" "unclosed') == '"special chars"* unclosed*'
    
    # Multiple spaces + quotes
    assert format_search_query_for_sqlite('  "  spaced  "  ') == 'spaced*'