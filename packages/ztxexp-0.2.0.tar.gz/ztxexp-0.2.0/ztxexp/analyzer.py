"""Result analysis and cleanup for ztxexp v0.2 artifact format.

The analyzer reads run directories and converts run/config/metrics files into
flat records suitable for tabular analysis.
"""

from __future__ import annotations

import shutil
from pathlib import Path
from typing import Any, Callable, Sequence

import pandas as pd

from ztxexp import utils
from ztxexp.constants import (
    RUN_SCHEMA_VERSION,
    RUN_STATUS_FAILED,
    RUN_STATUS_RUNNING,
    RUN_STATUS_SKIPPED,
    RUN_STATUS_SUCCEEDED,
)

# Predicate signature used in clean_results for custom deletion logic.
RecordPredicate = Callable[[dict[str, Any]], bool]


class ResultAnalyzer:
    """Reads and manages experiment artifacts in the v2 run directory format."""

    def __init__(self, results_path: str | Path):
        # Normalize path once for all downstream operations.
        self.results_path = Path(results_path)

        # Fail early when root does not exist.
        if not self.results_path.exists():
            raise FileNotFoundError(f"Results path does not exist: {self.results_path}")

    def to_records(
        self,
        statuses: Sequence[str] | None = (RUN_STATUS_SUCCEEDED,),
        metrics_filename: str = "metrics.json",
    ) -> list[dict[str, Any]]:
        """Loads run records by merging config, run metadata, and metrics.

        Args:
            statuses: Allowed status values. Use None to include all statuses.
            metrics_filename: Metrics file name to merge (defaults to metrics.json).
        """
        records: list[dict[str, Any]] = []

        # Convert to set for O(1) status lookup.
        target_statuses = set(statuses) if statuses is not None else None

        # Iterate every immediate run directory under root.
        for run_dir in utils.get_subdirectories(self.results_path):
            # Skip directories that are not valid v2 run folders.
            record = self._load_record(run_dir, metrics_filename)
            if record is None:
                continue

            # Apply status filter when provided.
            status = record.get("status")
            if target_statuses is not None and status not in target_statuses:
                continue

            records.append(record)

        return records

    def to_dataframe(
        self,
        statuses: Sequence[str] | None = (RUN_STATUS_SUCCEEDED,),
        metrics_filename: str = "metrics.json",
    ) -> pd.DataFrame:
        """Converts records into a pandas DataFrame."""
        records = self.to_records(statuses=statuses, metrics_filename=metrics_filename)

        # Keep empty result as empty DataFrame for downstream safety.
        if not records:
            return pd.DataFrame()

        return pd.DataFrame.from_records(records)

    def to_csv(
        self,
        output_path: str | Path,
        sort_by: Sequence[str] | None = None,
        statuses: Sequence[str] | None = (RUN_STATUS_SUCCEEDED,),
        metrics_filename: str = "metrics.json",
    ) -> pd.DataFrame:
        """Exports filtered records to CSV and returns the DataFrame used."""
        df = self.to_dataframe(statuses=statuses, metrics_filename=metrics_filename)

        if df.empty:
            print("No records found to export.")
            return df

        # Apply sort only on existing columns to avoid key errors.
        if sort_by:
            valid_keys = [key for key in sort_by if key in df.columns]
            if valid_keys:
                df = df.sort_values(by=valid_keys).reset_index(drop=True)

        # Persist CSV output.
        df.to_csv(output_path, index=False)
        print(f"Saved CSV to {output_path}")
        return df

    def to_pivot_excel(
        self,
        output_path: str | Path,
        df: pd.DataFrame,
        index_cols: Sequence[str],
        column_cols: Sequence[str],
        value_cols: Sequence[str],
        add_ranking: bool = True,
        ranking_ascending: bool = False,
    ) -> None:
        """Creates and saves a pivot table from the input DataFrame."""
        if df.empty:
            print("DataFrame is empty, cannot generate pivot table.")
            return

        try:
            # Build base pivot structure first.
            pivot_df = df.pivot_table(index=index_cols, columns=column_cols, values=value_cols)
        except Exception as exc:
            print(f"Failed to create pivot table: {exc}")
            return

        if not add_ranking:
            try:
                # Direct export path without rank labels.
                pivot_df.to_excel(output_path)
            except ImportError:
                print(
                    "openpyxl is required for Excel export. "
                    "Install with: pip install openpyxl"
                )
                return
            print(f"Saved pivot table to {output_path}")
            return

        # Rank values per column (dense semantics via method='min').
        rank_df = pivot_df.rank(method="min", ascending=ranking_ascending)

        # Convert to string frame so we can append rank labels.
        final_pivot = pivot_df.astype(str)
        rank_labels = {1.0: " (1st)", 2.0: " (2nd)", 3.0: " (3rd)"}

        for col in final_pivot.columns:
            for idx in final_pivot.index:
                value = pivot_df.at[idx, col]
                if pd.notna(value):
                    # Attach top-3 labels when applicable.
                    rank = rank_df.at[idx, col]
                    final_pivot.at[idx, col] = f"{value:.4f}{rank_labels.get(rank, '')}"
                else:
                    # Keep empty cell presentation for missing values.
                    final_pivot.at[idx, col] = ""

        try:
            # Export ranked pivot table.
            final_pivot.to_excel(output_path)
        except ImportError:
            print(
                "openpyxl is required for Excel export. "
                "Install with: pip install openpyxl"
            )
            return
        print(f"Saved ranked pivot table to {output_path}")

    def clean_results(
        self,
        statuses: Sequence[str] | None = (
            RUN_STATUS_FAILED,
            RUN_STATUS_RUNNING,
            RUN_STATUS_SKIPPED,
        ),
        predicate: RecordPredicate | None = None,
        dry_run: bool = True,
        metrics_filename: str = "metrics.json",
        confirm: bool = True,
    ) -> list[Path]:
        """Deletes run folders that match status and/or custom predicate.

        Deletion condition is OR logic:
        - status in statuses (when statuses is not None)
        - predicate(record) is True (when predicate is provided)
        """
        # Convert status filter to set once.
        target_statuses = set(statuses) if statuses is not None else None

        # Keep explicit delete list for reporting and optional dry-run return.
        to_delete: list[Path] = []

        for run_dir in utils.get_subdirectories(self.results_path):
            # Skip malformed or incompatible run folders.
            record = self._load_record(run_dir, metrics_filename)
            if record is None:
                continue

            should_delete = False

            # Built-in status-driven cleanup.
            if target_statuses is not None and record.get("status") in target_statuses:
                should_delete = True

            # User-provided cleanup logic.
            if predicate and predicate(record):
                should_delete = True

            if should_delete:
                to_delete.append(run_dir)

        if not to_delete:
            print("No folders matched cleanup criteria.")
            return []

        print(f"Found {len(to_delete)} folders to delete.")
        for run_dir in to_delete:
            print(f"  - {run_dir.name}")

        if dry_run:
            print("Dry run enabled. Nothing was deleted.")
            return to_delete

        if confirm:
            # Interactive safety gate for destructive operations.
            answer = input(f"Delete these {len(to_delete)} folders permanently? (yes/no): ")
            if answer.strip().lower() != "yes":
                print("Deletion canceled.")
                return []

        deleted: list[Path] = []
        for run_dir in to_delete:
            try:
                shutil.rmtree(run_dir)
                deleted.append(run_dir)
            except Exception as exc:  # pragma: no cover
                print(f"Failed to delete {run_dir}: {exc}")

        print(f"Deleted {len(deleted)} folders.")
        return deleted

    def _load_record(self, run_dir: Path, metrics_filename: str) -> dict[str, Any] | None:
        """Loads and merges one run directory into a flat record dict."""
        # Load run metadata first; it determines schema compatibility.
        run_meta = utils.load_json(run_dir / "run.json")
        if not run_meta:
            return None

        # Enforce schema-v2 only.
        if run_meta.get("schema_version") != RUN_SCHEMA_VERSION:
            return None

        # Load config payload (must be a dict).
        config = utils.load_json(run_dir / "config.json") or {}
        if not isinstance(config, dict):
            return None

        # Load metrics payload (optional dict).
        metrics = utils.load_json(run_dir / metrics_filename) or {}
        if not isinstance(metrics, dict):
            metrics = {}

        # Merge order: config -> metrics -> run metadata.
        record: dict[str, Any] = {}
        record.update(config)
        record.update(metrics)
        record.update(run_meta)

        # Include absolute path for easier downstream tooling.
        record["run_dir"] = str(run_dir.resolve())
        return record
