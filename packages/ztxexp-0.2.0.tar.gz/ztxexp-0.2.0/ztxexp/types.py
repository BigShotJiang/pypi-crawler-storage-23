"""Public dataclasses used by the experiment runtime."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(slots=True)
class RunContext:
    """Runtime context passed to each experiment function.

    The runner creates one instance per run and passes it into user code.
    """

    # Stable run identifier (also used as run directory name).
    run_id: str

    # Absolute path to the current run directory.
    run_dir: Path

    # Final resolved configuration dictionary used for this run.
    config: dict[str, Any]

    # Per-run logger writing to run.log.
    logger: logging.Logger


@dataclass(slots=True)
class RunSummary:
    """Aggregated execution summary for one runner invocation."""

    # Number of configs received by this run invocation.
    total: int

    # Number of runs that ended with status=succeeded.
    succeeded: int

    # Number of runs that ended with status=failed.
    failed: int

    # Number of runs that ended with status=skipped.
    skipped: int

    # End-to-end elapsed wall-clock time in seconds.
    duration_sec: float

    # Run IDs for failed runs, useful for retry workflows.
    failed_run_ids: list[str]
