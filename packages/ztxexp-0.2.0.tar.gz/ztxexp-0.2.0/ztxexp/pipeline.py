"""High-level experiment pipeline facade for ztxexp v0.2."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from ztxexp.manager import ExpManager
from ztxexp.runner import ExpRunner
from ztxexp.types import RunContext, RunSummary


class ExperimentPipeline:
    """Facade API that combines config building and execution.

    This class is designed for users who want one fluent chain from parameter
    generation to run execution.
    """

    def __init__(
        self,
        results_root: str | Path,
        base_config: Mapping[str, Any] | None = None,
    ):
        # Persist output root path in Path form for consistent file operations.
        self.results_root = Path(results_root)

        # Delegate configuration generation to ExpManager.
        self._manager = ExpManager(base_config)

        # Flag toggled by `.exclude_completed()`.
        self._exclude_completed = False

    def grid(self, param_grid: Mapping[str, Sequence[Any]]) -> "ExperimentPipeline":
        """Adds a Cartesian-product parameter grid stage."""
        self._manager.grid(param_grid)
        return self

    def variants(self, variants: Sequence[Mapping[str, Any]]) -> "ExperimentPipeline":
        """Adds an independent variants stage."""
        self._manager.variants(variants)
        return self

    def modify(self, fn: Callable[[dict[str, Any]], dict[str, Any] | None]) -> "ExperimentPipeline":
        """Adds a config modifier function."""
        self._manager.modify(fn)
        return self

    def where(self, fn: Callable[[dict[str, Any]], bool]) -> "ExperimentPipeline":
        """Adds a predicate filter function."""
        self._manager.where(fn)
        return self

    def exclude_completed(self) -> "ExperimentPipeline":
        """Enables exclusion of already succeeded configs."""
        self._exclude_completed = True
        return self

    def build(self) -> list[dict[str, Any]]:
        """Builds final configuration dictionaries."""
        # Configure completion exclusion only at build time so users can still
        # adjust root path before build/run.
        if self._exclude_completed:
            self._manager.exclude_completed(self.results_root)

        # Return immutable-by-convention plain dict configs.
        return self._manager.build()

    def run(
        self,
        exp_fn: Callable[[RunContext], dict[str, Any] | None],
        mode: str = "sequential",
        workers: int = 1,
        cpu_threshold: int = 80,
    ) -> RunSummary:
        """Builds configs and runs them with `ExpRunner`."""
        # Build configs immediately before execution to capture latest chain state.
        configs = self.build()

        # Instantiate runner with resolved config list and output root.
        runner = ExpRunner(configs=configs, results_root=self.results_root)

        # Forward execution controls to runner.
        return runner.run(
            exp_function=exp_fn,
            mode=mode,
            workers=workers,
            cpu_threshold=cpu_threshold,
        )
