"""Experiment execution runtime for ztxexp v0.2.

This module owns run lifecycle transitions and runtime artifact writing.
"""

from __future__ import annotations

import copy
import datetime as dt
import time
import traceback
import uuid
from collections import deque
from concurrent.futures import FIRST_COMPLETED, ProcessPoolExecutor, as_completed, wait
from pathlib import Path
from typing import Any, Callable

import psutil
from joblib import Parallel, delayed

from ztxexp import utils
from ztxexp.constants import (
    RUN_SCHEMA_VERSION,
    RUN_STATUS_FAILED,
    RUN_STATUS_RUNNING,
    RUN_STATUS_SKIPPED,
    RUN_STATUS_SUCCEEDED,
)
from ztxexp.types import RunContext, RunSummary

# Experiment function contract used by runner and pipeline.
ExperimentFn = Callable[[RunContext], dict[str, Any] | None]


class SkipRun(Exception):
    """Raise from experiment code to mark a run as skipped."""


def _utc_now_iso() -> str:
    """Returns timezone-aware UTC timestamp in ISO8601 format."""
    return dt.datetime.now(dt.timezone.utc).isoformat()


def _new_run_id() -> str:
    """Builds a readable + unique run id based on timestamp and random suffix."""
    timestamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    return f"{timestamp}_{uuid.uuid4().hex[:8]}"


def _run_payload(run_id: str, status: str) -> dict[str, Any]:
    """Creates the initial run.json payload."""
    now = _utc_now_iso()
    return {
        "schema_version": RUN_SCHEMA_VERSION,
        "run_id": run_id,
        "status": status,
        "started_at": now,
        "finished_at": None,
        "duration_sec": None,
        "error_type": None,
        "error_message": None,
    }


def _write_error_log(run_dir: Path, stack_trace: str) -> None:
    """Writes traceback text into run_dir/error.log."""
    with open(run_dir / "error.log", "w", encoding="utf-8") as handle:
        handle.write(stack_trace)


def _failure_record_from_exception(exc: Exception) -> dict[str, Any]:
    """Builds a synthetic failure record when worker-level errors occur."""
    return {
        "run_id": f"unstarted_{uuid.uuid4().hex[:8]}",
        "status": RUN_STATUS_FAILED,
        "error_type": type(exc).__name__,
        "error_message": str(exc),
    }


def _execute_single_run(
    config: dict[str, Any],
    exp_function: ExperimentFn,
    results_root: str | Path,
) -> dict[str, Any]:
    """Runs one experiment and writes v2 runtime artifacts.

    Artifact layout:
        run_dir/
          config.json
          run.json
          metrics.json (optional)
          artifacts/
          run.log
          error.log (failed only)
    """
    # Record start time for duration metrics.
    start = time.time()

    # Allocate stable run identity and folder path.
    run_id = _new_run_id()
    run_dir = Path(results_root) / run_id
    artifacts_dir = run_dir / "artifacts"

    # Ensure required directories exist before writing files.
    utils.create_dir(run_dir)
    utils.create_dir(artifacts_dir)

    # Create a per-run logger writing to run.log.
    logger = utils.setup_logger(f"ztxexp.run.{run_id}", str(run_dir / "run.log"))

    # Initialize run metadata as running state.
    run_meta = _run_payload(run_id, RUN_STATUS_RUNNING)

    # Copy config so user code can't mutate original manager output by reference.
    config_payload = copy.deepcopy(config)

    # Persist initial artifacts before user code starts.
    utils.save_json(config_payload, run_dir / "config.json")
    utils.save_json(run_meta, run_dir / "run.json")

    # Build runtime context passed into user function.
    ctx = RunContext(
        run_id=run_id,
        run_dir=run_dir,
        config=config_payload,
        logger=logger,
    )

    # Default final status is success unless exceptions override it.
    status = RUN_STATUS_SUCCEEDED
    error_type: str | None = None
    error_message: str | None = None

    try:
        # Execute user experiment code.
        result = exp_function(ctx)

        # Contract enforcement: only dict or None is allowed.
        if result is not None and not isinstance(result, dict):
            raise TypeError("Experiment function must return dict or None.")

        # Dict return value is treated as structured metrics payload.
        if isinstance(result, dict):
            utils.save_json(result, run_dir / "metrics.json")

    except SkipRun as exc:
        # Explicit skip path from user code.
        status = RUN_STATUS_SKIPPED
        error_type = type(exc).__name__
        error_message = str(exc)
        logger.warning("Run %s skipped: %s", run_id, exc)

    except Exception as exc:  # pragma: no cover - exercised via integration tests
        # Generic failure path.
        status = RUN_STATUS_FAILED
        error_type = type(exc).__name__
        error_message = str(exc)

        # Persist traceback for offline debugging.
        stack_trace = traceback.format_exc()
        _write_error_log(run_dir, stack_trace)
        logger.exception("Run %s failed", run_id)

    finally:
        # Finalize run metadata for all outcomes.
        run_meta["status"] = status
        run_meta["finished_at"] = _utc_now_iso()
        run_meta["duration_sec"] = round(time.time() - start, 6)
        run_meta["error_type"] = error_type
        run_meta["error_message"] = error_message
        utils.save_json(run_meta, run_dir / "run.json")

        # Close and detach handlers to avoid file-handle leaks on Windows.
        for handler in list(logger.handlers):
            handler.close()
            logger.removeHandler(handler)

    # Return a compact record consumed by summary aggregation.
    return {
        "run_id": run_id,
        "status": status,
        "error_type": error_type,
        "error_message": error_message,
    }


class ExpRunner:
    """Executes experiment functions against configuration dictionaries."""

    def __init__(
        self,
        configs: list[dict[str, Any]],
        results_root: str | Path,
        exp_function: ExperimentFn | None = None,
    ):
        # Copy input config list to avoid outside mutation side effects.
        self.configs = [dict(config) for config in configs]

        # Normalize output root path.
        self.results_root = Path(results_root)

        # Optional default experiment function.
        self.exp_function = exp_function

        # Ensure output root exists.
        utils.create_dir(self.results_root)

    def run(
        self,
        exp_function: ExperimentFn | None = None,
        mode: str = "sequential",
        workers: int = 1,
        cpu_threshold: int = 80,
        execution_mode: str | None = None,
        num_workers: int | None = None,
        dynamic_cpu_threshold: int | None = None,
    ) -> RunSummary:
        """Runs all configs and returns a `RunSummary`.

        Legacy keyword names are still accepted to preserve backward compatibility.
        """
        # Map legacy aliases into canonical parameter names.
        if execution_mode is not None:
            mode = execution_mode
        if num_workers is not None:
            workers = num_workers
        if dynamic_cpu_threshold is not None:
            cpu_threshold = dynamic_cpu_threshold

        # Resolve callable from explicit argument or constructor default.
        experiment = exp_function or self.exp_function
        if experiment is None:
            raise ValueError("exp_function is required.")

        # Snapshot config count and timer baseline.
        total = len(self.configs)
        start = time.time()

        # Fast path for empty workload.
        if total == 0:
            return RunSummary(
                total=0,
                succeeded=0,
                failed=0,
                skipped=0,
                duration_sec=0.0,
                failed_run_ids=[],
            )

        # Dispatch by execution mode.
        if mode == "sequential":
            records = [
                _execute_single_run(config, experiment, self.results_root)
                for config in self.configs
            ]
        elif mode == "process_pool":
            records = self._run_process_pool(experiment, workers)
        elif mode == "joblib":
            records = self._run_joblib(experiment, workers)
        elif mode == "dynamic":
            records = self._run_dynamic(experiment, workers, cpu_threshold)
        else:
            raise ValueError(
                f"Invalid mode '{mode}'. Choose from sequential/process_pool/joblib/dynamic."
            )

        # Summarize final records.
        duration = round(time.time() - start, 6)
        return self._summarize(records, total, duration)

    def _run_process_pool(self, exp_function: ExperimentFn, workers: int) -> list[dict[str, Any]]:
        """Runs with ProcessPoolExecutor and collects completion records."""
        records: list[dict[str, Any]] = []
        with ProcessPoolExecutor(max_workers=workers) as executor:
            # Submit all tasks immediately.
            future_map = {
                executor.submit(
                    _execute_single_run,
                    config,
                    exp_function,
                    self.results_root,
                ): config
                for config in self.configs
            }

            # Consume results as futures complete.
            for future in as_completed(future_map):
                try:
                    records.append(future.result())
                except Exception as exc:  # pragma: no cover
                    # Worker-level failure that prevented normal run record.
                    records.append(_failure_record_from_exception(exc))
        return records

    def _run_joblib(self, exp_function: ExperimentFn, workers: int) -> list[dict[str, Any]]:
        """Runs with joblib.Parallel and collects records."""
        try:
            return Parallel(n_jobs=workers, prefer="processes")(
                delayed(_execute_single_run)(config, exp_function, self.results_root)
                for config in self.configs
            )
        except Exception as exc:  # pragma: no cover
            # If joblib-level execution fails globally, synthesize failures.
            return [_failure_record_from_exception(exc) for _ in self.configs]

    def _run_dynamic(
        self,
        exp_function: ExperimentFn,
        workers: int,
        cpu_threshold: int,
    ) -> list[dict[str, Any]]:
        """Experimental mode that throttles task submission by CPU usage.

        Behavior:
        - Keep at most `workers` in-flight futures.
        - Submit new tasks only when current CPU usage is below threshold.
        """
        # Queue of configs not yet submitted.
        pending = deque(self.configs)

        # Map: future -> config for currently running tasks.
        in_flight: dict[Any, dict[str, Any]] = {}

        # Final completion records.
        records: list[dict[str, Any]] = []

        with ProcessPoolExecutor(max_workers=workers) as executor:
            while pending or in_flight:
                # Sample CPU usage before submission loop.
                cpu_usage = psutil.cpu_percent(interval=0.2)

                # Submit while there is capacity and CPU pressure is acceptable.
                while pending and len(in_flight) < workers and cpu_usage < cpu_threshold:
                    config = pending.popleft()
                    future = executor.submit(
                        _execute_single_run,
                        config,
                        exp_function,
                        self.results_root,
                    )
                    in_flight[future] = config

                    # Re-sample quickly after submission burst.
                    cpu_usage = psutil.cpu_percent(interval=0.0)

                # If nothing running yet, wait a short interval and retry.
                if not in_flight:
                    time.sleep(0.2)
                    continue

                # Wait until at least one future completes (or timeout).
                done, _ = wait(
                    in_flight.keys(),
                    timeout=0.5,
                    return_when=FIRST_COMPLETED,
                )

                # Drain completed futures into records.
                for future in done:
                    in_flight.pop(future, None)
                    try:
                        records.append(future.result())
                    except Exception as exc:  # pragma: no cover
                        records.append(_failure_record_from_exception(exc))

        return records

    def _summarize(
        self,
        records: list[dict[str, Any]],
        total: int,
        duration_sec: float,
    ) -> RunSummary:
        """Aggregates record list into RunSummary."""
        # Count each final status.
        succeeded = sum(1 for record in records if record.get("status") == RUN_STATUS_SUCCEEDED)
        failed = sum(1 for record in records if record.get("status") == RUN_STATUS_FAILED)
        skipped = sum(1 for record in records if record.get("status") == RUN_STATUS_SKIPPED)

        # Collect failed run IDs for fast retry/debug workflows.
        failed_run_ids = [
            str(record.get("run_id"))
            for record in records
            if record.get("status") == RUN_STATUS_FAILED
        ]

        # Return immutable summary object.
        return RunSummary(
            total=total,
            succeeded=succeeded,
            failed=failed,
            skipped=skipped,
            duration_sec=duration_sec,
            failed_run_ids=failed_run_ids,
        )
