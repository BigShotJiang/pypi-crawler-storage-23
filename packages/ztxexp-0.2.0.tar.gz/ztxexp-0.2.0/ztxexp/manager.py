"""Experiment configuration manager.

The manager is responsible only for creating a list of config dictionaries.
It does not execute experiments.
"""

from __future__ import annotations

import argparse
import copy
import itertools
import random
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping, Sequence

from ztxexp import utils
from ztxexp.constants import RUN_SCHEMA_VERSION, RUN_STATUS_SUCCEEDED

# Canonical config type used across manager/runner/pipeline.
ConfigDict = dict[str, Any]

# Modifier can mutate-and-return, return a new dict, or return None to keep in-place edits.
Modifier = Callable[[ConfigDict], ConfigDict | None]

# Predicate returns True when config should be kept.
Predicate = Callable[[ConfigDict], bool]


def _namespace_to_dict(value: argparse.Namespace | Mapping[str, Any]) -> ConfigDict:
    """Normalizes Namespace or Mapping into a plain dict copy."""
    if isinstance(value, argparse.Namespace):
        # Namespace -> dict copy avoids accidental sharing.
        return vars(value).copy()

    # Generic mapping -> dict copy.
    return dict(value)


class ExpManager:
    """Builds experiment configuration dictionaries using chainable operations.

    Typical flow:
        manager.grid(...).variants(...).modify(...).where(...).build()
    """

    def __init__(self, base_config: argparse.Namespace | Mapping[str, Any] | None = None):
        # Default to empty config when base is not provided.
        base = {} if base_config is None else _namespace_to_dict(base_config)

        # Internal working set; every stage transforms this list.
        self._configs: list[ConfigDict] = [base]

        # Deferred transform/filter stages executed in build().
        self._modifiers: list[Modifier] = []
        self._predicates: list[Predicate] = []

        # Optional exclusion settings for already completed runs.
        self._exclude_completed_root: Path | None = None
        self._exclude_ignore_keys: set[str] = set()

        # Optional final shuffle switch.
        self._should_shuffle = False

    def grid(self, param_grid: Mapping[str, Sequence[Any]]) -> "ExpManager":
        """Expands configs by Cartesian product of the provided param grid."""
        # Empty grid should be a no-op for chainability.
        if not param_grid:
            return self

        # Cache grid keys and candidate value sequences.
        keys = list(param_grid.keys())
        value_lists = [list(param_grid[key]) for key in keys]

        # Build every possible combination once.
        combos = list(itertools.product(*value_lists))

        expanded: list[ConfigDict] = []

        # Apply each combination to each existing base config.
        for base_config in self._configs:
            for combo in combos:
                # Deep copy to keep configs independent.
                next_config = copy.deepcopy(base_config)
                for key, value in zip(keys, combo):
                    next_config[key] = value
                expanded.append(next_config)

        # Replace current set with expanded result.
        self._configs = expanded
        return self

    def variants(
        self,
        variants: Sequence[Mapping[str, Any]] | Mapping[str, Sequence[Any]],
    ) -> "ExpManager":
        """Adds independent variants on top of current configs.

        Preferred input:
            [{"model": "resnet"}, {"model": "transformer", "layers": 6}]

        Compatibility input:
            {"model": ["resnet", "transformer"]}
        """
        # Empty variant collection should be a no-op.
        if not variants:
            return self

        variant_dicts: list[ConfigDict] = []

        # Backward-compatible path for dict-of-lists input.
        if isinstance(variants, Mapping):
            for key, values in variants.items():
                for value in values:
                    variant_dicts.append({key: value})
        else:
            # Preferred path: list of dict-like variant blocks.
            variant_dicts = [dict(item) for item in variants]

        expanded: list[ConfigDict] = []

        # Each variant is merged independently into each base config.
        for base_config in self._configs:
            for variant in variant_dicts:
                merged = copy.deepcopy(base_config)
                merged.update(copy.deepcopy(variant))
                expanded.append(merged)

        # Replace current set with variant-expanded result.
        self._configs = expanded
        return self

    def modify(self, modifier: Modifier) -> "ExpManager":
        """Registers a modifier function."""
        self._modifiers.append(modifier)
        return self

    def where(self, predicate: Predicate) -> "ExpManager":
        """Registers a predicate filter function."""
        self._predicates.append(predicate)
        return self

    def exclude_completed(
        self,
        results_root: str | Path,
        ignore_keys: Sequence[str] | None = None,
    ) -> "ExpManager":
        """Excludes configs that already succeeded in v2 artifact directories."""
        # Normalize root path once.
        self._exclude_completed_root = Path(results_root)

        # Keys listed here are ignored when comparing config equivalence.
        self._exclude_ignore_keys = set(ignore_keys or [])
        return self

    def shuffle(self) -> "ExpManager":
        """Shuffles final generated config order."""
        self._should_shuffle = True
        return self

    def build(self) -> list[ConfigDict]:
        """Builds final config dictionaries by applying all registered stages."""
        # Start from defensive deep copies so build output is isolated.
        configs = [copy.deepcopy(config) for config in self._configs]

        # Apply every modifier in registration order.
        if self._modifiers:
            modified_configs: list[ConfigDict] = []
            for config in configs:
                next_config = config
                for modifier in self._modifiers:
                    result = modifier(next_config)

                    # None means modifier mutated in place.
                    if result is None:
                        result = next_config

                    # Enforce strict output type for predictable pipeline behavior.
                    if not isinstance(result, dict):
                        raise TypeError("Modifier must return dict or None.")

                    next_config = result
                modified_configs.append(next_config)
            configs = modified_configs

        # Apply every predicate; config survives only if all are True.
        if self._predicates:
            filtered = []
            for config in configs:
                if all(predicate(config) for predicate in self._predicates):
                    filtered.append(config)
            configs = filtered

        # Exclude configs that already exist as succeeded runs.
        if self._exclude_completed_root:
            completed_configs = self._load_completed_configs(self._exclude_completed_root)
            configs = [
                config
                for config in configs
                if not any(
                    self._configs_equal(config, completed, self._exclude_ignore_keys)
                    for completed in completed_configs
                )
            ]

        # Shuffle only at the end so all filtering/comparison is deterministic first.
        if self._should_shuffle:
            random.shuffle(configs)

        return configs

    # ---- Backward-compatible aliases (v0.1 -> v0.2) ----

    def add_grid_search(self, param_grid: Mapping[str, Sequence[Any]]) -> "ExpManager":
        """Backward-compatible alias for `grid`."""
        return self.grid(param_grid)

    def add_variants(
        self,
        variant_space: Sequence[Mapping[str, Any]] | Mapping[str, Sequence[Any]],
    ) -> "ExpManager":
        """Backward-compatible alias for `variants`."""
        return self.variants(variant_space)

    def add_modifier(self, modifier_func: Modifier) -> "ExpManager":
        """Backward-compatible alias for `modify`."""
        return self.modify(modifier_func)

    def add_filter(self, filter_func: Predicate) -> "ExpManager":
        """Backward-compatible alias for `where`."""
        return self.where(filter_func)

    def filter_completed(
        self,
        results_path: str | Path,
        ignore_keys: Sequence[str] | None = None,
    ) -> "ExpManager":
        """Backward-compatible alias for `exclude_completed`."""
        return self.exclude_completed(results_path, ignore_keys=ignore_keys)

    def get_configs(self) -> list[ConfigDict]:
        """Backward-compatible alias for `build`."""
        return self.build()

    # ---- Internal helpers ----

    def _load_completed_configs(self, results_root: Path) -> list[ConfigDict]:
        """Loads configs from succeeded runs under results_root."""
        # Missing root means nothing to exclude.
        if not results_root.exists():
            return []

        completed: list[ConfigDict] = []

        # Iterate each run folder and keep only schema-v2 + succeeded runs.
        for run_dir in utils.get_subdirectories(results_root):
            run_meta = utils.load_json(run_dir / "run.json")
            if not run_meta:
                continue
            if run_meta.get("schema_version") != RUN_SCHEMA_VERSION:
                continue
            if run_meta.get("status") != RUN_STATUS_SUCCEEDED:
                continue

            # Collect the corresponding config payload for equivalence checks.
            config = utils.load_json(run_dir / "config.json")
            if isinstance(config, dict):
                completed.append(config)

        return completed

    def _configs_equal(self, a: ConfigDict, b: ConfigDict, ignore_keys: Iterable[str]) -> bool:
        """Compares two config dicts with strict keyset and normalized values."""
        # Convert ignore keys once for O(1) lookups.
        ignore = set(ignore_keys)

        # Remove ignored keys from both sides before comparison.
        left_keys = set(a.keys()) - ignore
        right_keys = set(b.keys()) - ignore

        # Strict keyset match prevents false positives from missing keys.
        if left_keys != right_keys:
            return False

        # Compare normalized values field by field.
        for key in left_keys:
            if self._normalize_value(a[key]) != self._normalize_value(b[key]):
                return False
        return True

    def _normalize_value(self, value: Any) -> Any:
        """Normalizes nested structures for stable comparisons."""
        if isinstance(value, dict):
            # Dict keys are sorted so ordering differences do not matter.
            return {k: self._normalize_value(v) for k, v in sorted(value.items())}

        if isinstance(value, (list, tuple)):
            # List/tuple are treated as equivalent sequence containers.
            return [self._normalize_value(item) for item in value]

        # Primitive values pass through unchanged.
        return value
