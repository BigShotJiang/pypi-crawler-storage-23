"""Environment helpers for deep learning experiments.

This module keeps environment setup logic isolated from core experiment flow.
"""

from __future__ import annotations

import os
import random

import numpy as np
import psutil


def _require_torch():
    """Imports torch lazily and raises a clear install hint when missing."""
    try:
        import torch

        return torch
    except ImportError as exc:  # pragma: no cover
        raise ImportError(
            "PyTorch is required for init_torch_env. Install with: pip install ztxexp[torch]"
        ) from exc


def init_torch_env(
    seed: int = 3407,
    use_gpu: bool = True,
    gpu_id: int = 0,
    deterministic: bool = False,
    benchmark: bool = False,
):
    """Initializes deterministic state and optional CUDA settings."""
    # Delay torch import so the package can be used without torch installed.
    torch = _require_torch()

    # Align Python/NumPy/Torch random states for better reproducibility.
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    # GPU path: configure CUDA-related deterministic knobs.
    if torch.cuda.is_available() and use_gpu:
        torch.cuda.manual_seed_all(seed)
        torch.cuda.set_device(gpu_id)
        torch.backends.cudnn.deterministic = deterministic
        torch.backends.cudnn.benchmark = benchmark
        print(f"Using GPU: {gpu_id}")
        return torch.device(f"cuda:{gpu_id}")

    # CPU fallback path.
    print("Using CPU")
    return torch.device("cpu")


def set_process_priority(priority: str = "high") -> None:
    """Sets process priority. Valid values: high/normal/low."""
    # Locate current process object once.
    process = psutil.Process(os.getpid())

    # Normalize user input so casing/whitespace do not matter.
    selected = priority.strip().lower()

    try:
        # Windows uses priority classes instead of numeric nice values.
        if os.name == "nt":
            if selected == "high":
                process.nice(psutil.HIGH_PRIORITY_CLASS)
            elif selected == "low":
                process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
            else:
                process.nice(psutil.NORMAL_PRIORITY_CLASS)
        else:
            # POSIX uses lower nice value for higher priority.
            if selected == "high":
                process.nice(-10)
            elif selected == "low":
                process.nice(10)
            else:
                process.nice(0)

    except (psutil.AccessDenied, PermissionError) as exc:  # pragma: no cover
        # Provide actionable guidance instead of raw system exception only.
        raise PermissionError(
            "Insufficient permission to change process priority. "
            "Try running with elevated privileges or use 'normal'."
        ) from exc
