"""Shared constants for runtime artifact schema and run status values."""

# Global schema version for every run.json produced by this package.
RUN_SCHEMA_VERSION = 2

# Status emitted when a run has started but not yet finished.
RUN_STATUS_RUNNING = "running"

# Status emitted when a run finishes without any exception.
RUN_STATUS_SUCCEEDED = "succeeded"

# Status emitted when a run fails with an exception.
RUN_STATUS_FAILED = "failed"

# Status emitted when user code explicitly skips a run.
RUN_STATUS_SKIPPED = "skipped"

# Set form is convenient for fast membership checks in validators.
VALID_RUN_STATUSES = {
    RUN_STATUS_RUNNING,
    RUN_STATUS_SUCCEEDED,
    RUN_STATUS_FAILED,
    RUN_STATUS_SKIPPED,
}
