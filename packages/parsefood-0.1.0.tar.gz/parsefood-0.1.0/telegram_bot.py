#!/usr/bin/env python3
"""
Telegram bot that processes food logs and sends a summary.

Two modes:
1. Interactive bot: Run with --bot to start a bot that responds to /report command
2. One-time: Run without args to send summary once (for cron jobs)
"""

import asyncio
import json
import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path

from dotenv import load_dotenv
from telegram import Bot, Update
from telegram.ext import Application, CommandHandler, ContextTypes

# Load environment variables
load_dotenv()

# Configuration
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")
DATA_PATH = os.getenv("DATA_PATH", "data")
DATA_FILE = Path(DATA_PATH) / "date_messages_map.json"


def run_main_processing():
    """Run the main.py script to process food logs."""
    print("Running main.py to process food logs...")

    # Get absolute path to script directory
    script_dir = Path(__file__).parent.absolute()

    # Use the same Python interpreter that's running this script
    # This works whether running via uv, venv, or system Python
    result = subprocess.run(
        [sys.executable, "main.py"],
        capture_output=True,
        text=True,
        cwd=str(script_dir),
        start_new_session=True,  # Prevent inheriting parent process group
        close_fds=True,  # Close file descriptors for daemon compatibility
        env=os.environ.copy()  # Explicitly copy environment
    )

    if result.returncode != 0:
        print(f"Error running main.py: {result.stderr}")
        raise Exception(f"main.py failed with return code {result.returncode}")

    print("Processing completed successfully")
    return result.stdout


def load_processed_data():
    """Load the processed food log data."""
    if not DATA_FILE.exists():
        raise FileNotFoundError(f"Data file not found: {DATA_FILE}")

    with open(DATA_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def generate_summary(data):
    """Generate a calorie progress bar for today."""
    # Get today's date
    today = datetime.now().strftime("%Y-%m-%d")

    # Get target calories from environment
    target_calories = int(os.getenv("TARGET_CALORIES", 2000))

    # Get today's calories
    today_data = data.get(today, {})
    current_calories = today_data.get("total", 0)

    # Calculate percentage
    percentage = (current_calories / target_calories * 100) if target_calories > 0 else 0

    # Create progress bar (20 blocks) with colored emojis
    filled_blocks = int(percentage / 5)  # Each block = 5%
    filled_blocks = min(filled_blocks, 20)  # Cap at 20 blocks

    # Use green squares for progress, gray for remaining
    bar = "🟩" * filled_blocks + "⬜" * (20 - filled_blocks)

    # Choose emoji and message based on progress
    if percentage < 30:
        emoji = "🌱"
        message = "Just getting started!"
    elif percentage < 50:
        emoji = "💪"
        message = "Keep going!"
    elif percentage < 75:
        emoji = "🔥"
        message = "Great progress!"
    elif percentage < 90:
        emoji = "⭐"
        message = "Almost there!"
    elif percentage < 100:
        emoji = "🎯"
        message = "So close!"
    elif percentage == 100:
        emoji = "✨"
        message = "Perfect! Goal reached!"
    else:
        emoji = "⚠️"
        message = "Over target!"

    # Build message
    return f"{emoji} *{current_calories}/{target_calories} kcal* ({percentage:.0f}%)\n{bar}\n_{message}_"


async def send_summary_to_chat(chat_id: int):
    """Process logs and send summary to specified chat."""
    # Run processing
    run_main_processing()

    # Load processed data
    data = load_processed_data()

    # Generate summary
    summary = generate_summary(data)

    # Send via Telegram
    bot = Bot(token=TELEGRAM_BOT_TOKEN)
    await bot.send_message(
        chat_id=chat_id,
        text=summary,
        parse_mode="Markdown"
    )

    print(f"Summary sent to chat {chat_id}")


async def report_command(update: Update, _context: ContextTypes.DEFAULT_TYPE):
    """Handle /report command."""
    try:
        # Send "processing" message
        await update.message.reply_text("⏳ Processing your food log...")

        # Run processing
        run_main_processing()

        # Load processed data
        data = load_processed_data()

        # Generate summary
        summary = generate_summary(data)

        # Send summary
        await update.message.reply_text(summary, parse_mode="Markdown")

    except Exception as e:
        await update.message.reply_text(f"❌ Error: {e}")
        raise


async def start_command(update: Update, _context: ContextTypes.DEFAULT_TYPE):
    """Handle /start command."""
    await update.message.reply_text(
        "👋 Welcome to Food Log Bot!\n\n"
        "Commands:\n"
        "/report - Get today's calorie progress report"
    )


def start_bot():
    """Start the interactive bot."""
    if not TELEGRAM_BOT_TOKEN:
        raise ValueError("TELEGRAM_BOT_TOKEN not set in .env file")

    print("Starting bot in interactive mode...")
    print("Press Ctrl+C to stop")

    # Create application
    app = Application.builder().token(TELEGRAM_BOT_TOKEN).build()

    # Add command handlers
    app.add_handler(CommandHandler("start", start_command))
    app.add_handler(CommandHandler("report", report_command))

    # Start polling
    app.run_polling(allowed_updates=Update.ALL_TYPES)


async def send_summary_once():
    """Send summary once to configured chat (for cron)."""
    if not TELEGRAM_BOT_TOKEN:
        raise ValueError("TELEGRAM_BOT_TOKEN not set in .env file")
    if not TELEGRAM_CHAT_ID:
        raise ValueError("TELEGRAM_CHAT_ID not set in .env file")

    await send_summary_to_chat(int(TELEGRAM_CHAT_ID))


def main():
    """Main entry point."""
    try:
        # Check if running in bot mode
        if len(sys.argv) > 1 and sys.argv[1] == "--bot":
            start_bot()
        else:
            # One-time send mode
            asyncio.run(send_summary_once())
    except Exception as e:
        print(f"Error: {e}")
        raise


if __name__ == "__main__":
    main()
