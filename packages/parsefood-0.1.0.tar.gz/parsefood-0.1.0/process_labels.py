#!/usr/bin/env python3
"""
Process product label images and automatically add to food database.

This script:
1. Groups images by product name (e.g., naturevalley_1.jpg, naturevalley_2.jpg)
2. Converts AVIF/WEBP images to JPEG for API compatibility
3. Sends all images of a product to OpenRouter vision API (uses MODEL_ID from .env)
4. Generates multiple entries per product (per unit, per package, per 100g, etc.)
5. Creates timestamped backup of food_database.json
6. Automatically merges new entries into food_database.json (skips duplicates)

Usage:
    python process_labels.py

Requirements:
    - Place label images in labels/ folder
    - Set OPENROUTER_API_KEY and MODEL_ID in .env file
    - Images can be: .jpg, .jpeg, .png, .avif, .webp
    - Use naming pattern: productname_1.jpg, productname_2.jpg for multiple images

Output:
    - Updates food_database.json with new entries
    - Creates backup: food_database.backup_YYYYMMDD_HHMMSS.json
"""

import base64
import io
import logging
import re
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Tuple

from food_log import (
    FOOD_DATABASE_PATH,
    MODEL_ID,
    OPENROUTER_API_KEY,
    create_backup,
    load_database,
    merge_entries,
    save_database,
)
from food_log.llm import create_openrouter_client
from food_log.llm.prompts import create_vision_prompt
from food_log.utils import parse_json_response

try:
    from PIL import Image
    HAS_PILLOW = True
except ImportError:
    HAS_PILLOW = False
    logging.warning("Pillow not installed - AVIF/WEBP conversion will not be available")

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
logger = logging.getLogger(__name__)

# Configuration
LABELS_DIR = Path("labels")


def group_images_by_product() -> Dict[str, List[Path]]:
    """
    Group label images by product name.

    Files like 'naturevalley_1.jpg', 'naturevalley_2.jpg' are grouped under 'naturevalley'.

    Returns:
        Dictionary mapping product name to list of image paths
    """
    if not LABELS_DIR.exists():
        logger.error(f"Labels directory not found: {LABELS_DIR}")
        return {}

    products = defaultdict(list)

    # Pattern to match: productname_N.ext or productname.ext
    pattern = re.compile(r'^(.+?)(?:_\d+)?\.(?:jpg|jpeg|png|avif|webp)$', re.IGNORECASE)

    for image_path in sorted(LABELS_DIR.glob("*")):
        if not image_path.is_file():
            continue

        match = pattern.match(image_path.name)
        if match:
            product_name = match.group(1)
            products[product_name].append(image_path)
            logger.info(f"Found image for product '{product_name}': {image_path.name}")

    return dict(products)


def encode_image(image_path: Path) -> Tuple[str, str]:
    """
    Encode image to base64 string, converting to JPEG if needed.

    Args:
        image_path: Path to image file

    Returns:
        Tuple of (base64 encoded string, mime type)
    """
    ext = image_path.suffix.lower()

    # If AVIF or WEBP, convert to JPEG using Pillow
    if ext in ['.avif', '.webp'] and HAS_PILLOW:
        try:
            logger.info(f"    Converting {ext} to JPEG...")
            img = Image.open(image_path)
            # Convert to RGB if needed (AVIF might be in different color space)
            if img.mode not in ('RGB', 'L'):
                img = img.convert('RGB')

            # Save to bytes buffer as JPEG
            buffer = io.BytesIO()
            img.save(buffer, format='JPEG', quality=95)
            buffer.seek(0)

            encoded = base64.b64encode(buffer.read()).decode('utf-8')
            return encoded, 'image/jpeg'
        except Exception as e:
            logger.warning(f"    Failed to convert {ext}: {e}, trying direct encoding")

    # Direct encoding for standard formats
    with open(image_path, "rb") as image_file:
        encoded = base64.b64encode(image_file.read()).decode('utf-8')
        mime_type = get_image_mime_type(image_path)
        return encoded, mime_type


def get_image_mime_type(image_path: Path) -> str:
    """
    Get MIME type from file extension.

    Args:
        image_path: Path to image file

    Returns:
        MIME type string
    """
    ext = image_path.suffix.lower()
    mime_types = {
        '.jpg': 'image/jpeg',
        '.jpeg': 'image/jpeg',
        '.png': 'image/png',
        '.avif': 'image/avif',
        '.webp': 'image/webp'
    }
    return mime_types.get(ext, 'image/jpeg')


def extract_nutrition_from_labels(
    product_name: str,
    image_paths: List[Path],
) -> Dict:
    """
    Extract nutrition data from product label images using vision model.

    Args:
        product_name: Name of the product
        image_paths: List of image paths for this product

    Returns:
        Dictionary with extracted nutrition data matching food_database.json schema
    """
    logger.info(f"Processing {len(image_paths)} image(s) for product: {product_name}")

    # Initialize OpenRouter client
    client = create_openrouter_client()

    # Prepare messages with images
    content = []

    for image_path in image_paths:
        try:
            encoded_image, mime_type = encode_image(image_path)

            content.append({
                "type": "image_url",
                "image_url": {
                    "url": f"data:{mime_type};base64,{encoded_image}"
                }
            })
            logger.info(f"  Encoded image: {image_path.name} ({mime_type})")
        except Exception as e:
            logger.error(f"  Failed to encode {image_path.name}: {e}")
            continue

    if not content:
        logger.error(f"No valid images for {product_name}")
        return {}

    # Add text prompt
    content.append({
        "type": "text",
        "text": create_vision_prompt()
    })

    messages = [
        {
            "role": "user",
            "content": content
        }
    ]

    try:
        logger.info(f"  Sending request to OpenRouter with model: {MODEL_ID}")
        # Add extra headers for vision support
        extra_headers = {
            "HTTP-Referer": "https://github.com/your-username/parsefood",
            "X-Title": "Food Log Parser - Label Extractor"
        }
        response = client.chat.completions.create(
            model=MODEL_ID,
            messages=messages,
            temperature=0.0,
            max_tokens=8000,
            extra_headers=extra_headers
        )

        response_text = response.choices[0].message.content.strip()
        logger.info(f"  Received response ({len(response_text)} chars)")

        # Parse JSON from response
        nutrition_data = parse_json_response(response_text, array=False)
        if nutrition_data:
            logger.info(f"  Successfully extracted {len(nutrition_data)} entries")
            return nutrition_data
        else:
            logger.error(f"  Failed to parse JSON response")
            logger.error(f"  Full response:\n{response_text}")
            return {}

    except Exception as e:
        logger.error(f"  Error calling OpenRouter API: {e}")
        return {}


def validate_nutrition_entry(entry: Dict) -> bool:
    """
    Validate that a nutrition entry has the required schema.

    Args:
        entry: Dictionary representing a food entry

    Returns:
        True if valid, False otherwise
    """
    required_fields = ['name', 'grams_per_unit', 'nutrition_per_100g']

    if not all(field in entry for field in required_fields):
        logger.warning(f"Entry missing required fields: {entry.get('name', 'unknown')}")
        return False

    if not isinstance(entry['grams_per_unit'], dict):
        logger.warning(f"grams_per_unit must be a dict: {entry.get('name')}")
        return False

    if not isinstance(entry['nutrition_per_100g'], dict):
        logger.warning(f"nutrition_per_100g must be a dict: {entry.get('name')}")
        return False

    required_nutrition = ['calories', 'proteins', 'carbs', 'fats']
    if not all(field in entry['nutrition_per_100g'] for field in required_nutrition):
        logger.warning(f"nutrition_per_100g missing fields: {entry.get('name')}")
        return False

    return True


def main():
    """Main execution function."""

    logger.info("=" * 60)
    logger.info("Product Label Nutrition Extractor")
    logger.info("=" * 60)

    # Validate configuration
    if not OPENROUTER_API_KEY:
        logger.error("OPENROUTER_API_KEY not found in environment variables")
        logger.error("Please set it in your .env file")
        return 1

    # Group images by product
    logger.info("\nGrouping images by product...")
    products = group_images_by_product()

    if not products:
        logger.error("No product images found in labels directory")
        return 1

    logger.info(f"Found {len(products)} product(s)")

    # Process each product
    all_nutrition_data = {}

    for product_name, image_paths in products.items():
        logger.info(f"\n{'=' * 60}")
        logger.info(f"Product: {product_name}")
        logger.info(f"{'=' * 60}")

        nutrition_data = extract_nutrition_from_labels(
            product_name,
            image_paths,
        )

        # Validate and merge entries
        for entry_name, entry_data in nutrition_data.items():
            if validate_nutrition_entry(entry_data):
                all_nutrition_data[entry_name] = entry_data
                logger.info(f"  Added entry: {entry_name}")
            else:
                logger.warning(f"  Skipped invalid entry: {entry_name}")

    # Check if we extracted any entries
    if not all_nutrition_data:
        logger.warning("\nNo valid entries extracted")
        return 0

    # Load existing database
    logger.info(f"\n{'=' * 60}")
    logger.info("Merging with existing database")
    logger.info(f"{'=' * 60}")

    existing_db = load_database(FOOD_DATABASE_PATH)

    # Create backup before modifying
    if existing_db:
        logger.info("\nCreating backup...")
        try:
            create_backup(FOOD_DATABASE_PATH)
        except Exception as e:
            logger.error(f"Failed to create backup: {e} - aborting")
            return 1

    # Merge entries (don't overwrite existing by default)
    logger.info("\nMerging entries...")
    merged_db, num_added, num_skipped = merge_entries(
        existing_db,
        all_nutrition_data,
        overwrite=False
    )

    # Save updated database
    logger.info(f"\n{'=' * 60}")
    logger.info("Saving to food database")
    logger.info(f"{'=' * 60}")

    if save_database(merged_db, FOOD_DATABASE_PATH):
        logger.info(f"\n{'=' * 60}")
        logger.info("SUCCESS")
        logger.info(f"{'=' * 60}")
        logger.info(f"  Added: {num_added} new entries")
        if num_skipped > 0:
            logger.info(f"  Skipped: {num_skipped} duplicates")
        logger.info(f"  Total entries in database: {len(merged_db)}")
        logger.info(f"\n  Food database updated: {FOOD_DATABASE_PATH}")
        return 0
    else:
        logger.error("\nFailed to save food database")
        return 1


if __name__ == "__main__":
    exit(main())
