#!/usr/bin/env python3
"""
Food Database Review Tool

A Gradio-based interface for reviewing and curating the food database.
Navigate items one-by-one, verify/edit nutrition data, scrape from URLs,
and track review status.

Usage:
    uv run python review_database.py

Opens a web interface at http://localhost:7860
"""

import traceback
from concurrent.futures import ThreadPoolExecutor

import gradio as gr

from food_log import FOOD_DATABASE_PATH
from food_log.database import load_database, save_database, create_backup
from scrapers import CeleiroScraper, ContinenteScraper, registry

# Register scrapers
registry.register(CeleiroScraper())
registry.register(ContinenteScraper())

# JavaScript for keyboard shortcuts
KEYBOARD_JS = """
<script>
document.addEventListener('keydown', (e) => {
    // Don't trigger if typing in an input field
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;

    const key = e.key.toLowerCase();
    const buttons = {
        'a': 'accept-btn',
        'r': 'reject-btn',
        's': 'skip-btn'
    };

    if (buttons[key]) {
        const btn = document.getElementById(buttons[key]);
        if (btn && !btn.disabled) {
            btn.click();
        }
    }
});
</script>
"""


def format_value(val, precision=1):
    """Format a numeric value for display."""
    if val is None:
        return "-"
    if isinstance(val, float):
        return f"{val:.{precision}f}"
    return str(val)


def build_units_table(units: dict) -> str:
    """Build a markdown table showing supported units and their gram values."""
    if not units:
        return "*No units defined*"

    rows = [
        "| Unit | Grams |",
        "|------|-------|",
    ]

    for unit, grams in sorted(units.items()):
        rows.append(f"| {unit} | {grams:.1f}g |")

    return "\n".join(rows)


def build_nutrition_table(current: dict, previous: dict | None = None) -> str:
    """Build a markdown table showing current values, optionally with previous comparison."""
    if previous:
        rows = [
            "| Field | New | Previous | Diff |",
            "|-------|-----|----------|------|",
        ]
    else:
        rows = [
            "| Field | Value |",
            "|-------|-------|",
        ]

    fields = [
        ("Calories", "calories", 0),
        ("Proteins", "proteins", 1),
        ("Carbs", "carbs", 1),
        ("Fats", "fats", 1),
        ("Fiber", "fiber", 1),
        ("Sodium", "sodium", 3),
    ]

    for label, key, precision in fields:
        curr_val = current.get(key)
        curr_str = format_value(curr_val, precision)

        if previous:
            prev_val = previous.get(key)
            prev_str = format_value(prev_val, precision)

            # Calculate diff
            diff_str = ""
            if curr_val is not None and prev_val is not None:
                try:
                    diff = float(curr_val) - float(prev_val)
                    if abs(diff) > 0.01:
                        sign = "+" if diff > 0 else ""
                        diff_str = f"{sign}{diff:.{precision}f}"
                except (ValueError, TypeError):
                    pass

            rows.append(f"| {label} | {curr_str} | {prev_str} | {diff_str} |")
        else:
            rows.append(f"| {label} | {curr_str} |")

    return "\n".join(rows)


def get_item_order(database: dict, filter_status: str = "all") -> list[str]:
    """Build ordered list of food names based on filter.

    Unreviewed items come first, then sorted alphabetically within each group.
    """
    unreviewed = []
    accepted = []
    rejected = []
    skipped = []

    for name, item in database.items():
        status = item.get("_review_status", "pending")
        if status == "accepted":
            accepted.append(name)
        elif status == "rejected":
            rejected.append(name)
        elif status == "skipped":
            skipped.append(name)
        else:
            unreviewed.append(name)

    # Sort each group alphabetically
    unreviewed.sort()
    accepted.sort()
    rejected.sort()
    skipped.sort()

    # Apply filter
    if filter_status == "unreviewed":
        return unreviewed
    elif filter_status == "accepted":
        return accepted
    elif filter_status == "rejected":
        return rejected
    elif filter_status == "skipped":
        return skipped
    else:  # "all" - unreviewed first, then others
        return unreviewed + skipped + rejected + accepted


def get_progress_text(database: dict, current_index: int, item_order: list[str]) -> str:
    """Generate progress text showing current position and review stats."""
    total = len(database)
    reviewed = sum(
        1 for item in database.values()
        if item.get("_review_status") in ["accepted", "rejected"]
    )

    if not item_order:
        return f"**No items to review** | Total: {total}"

    current = current_index + 1
    return f"**Item {current}/{len(item_order)}** | Reviewed: {reviewed}/{total}"


def load_item_to_form(database: dict, name: str) -> tuple:
    """Load a database item into form field values."""
    if not name or name not in database:
        return ("", "", "pending", "", False, 0, 0.0, 0.0, 0.0, None, None, [])

    item = database[name]
    nutrition = item.get("nutrition_per_100g", {})
    units = item.get("grams_per_unit", {})

    # Convert units dict to dataframe format
    units_data = [[unit, grams] for unit, grams in units.items()]

    return (
        f"## {name}",  # food_name display
        item.get("url", ""),  # url
        item.get("_review_status", "pending"),  # status
        item.get("url", ""),  # url_display for link
        item.get("_bad_url", False),  # bad_url flag
        nutrition.get("calories", 0),
        nutrition.get("proteins", 0.0),
        nutrition.get("carbs", 0.0),
        nutrition.get("fats", 0.0),
        nutrition.get("fiber"),  # Can be None
        nutrition.get("sodium"),  # Can be None
        units_data,
    )


def save_item_to_database(
    database: dict,
    name: str,
    url: str,
    status: str,
    calories: int,
    proteins: float,
    carbs: float,
    fats: float,
    fiber: float | None,
    sodium: float | None,
    units_data: list,
) -> dict:
    """Save form values back to database dict."""
    # Get the actual name from the markdown header
    actual_name = name.replace("## ", "").strip() if name.startswith("## ") else name

    if not actual_name or actual_name not in database:
        return database

    # Build new entry preserving existing fields
    new_db = dict(database)
    entry = dict(new_db[actual_name])

    # Update URL if provided
    if url:
        entry["url"] = url

    # Update review status
    entry["_review_status"] = status

    # Update nutrition
    nutrition = {
        "calories": int(calories) if calories else 0,
        "proteins": float(proteins) if proteins else 0.0,
        "carbs": float(carbs) if carbs else 0.0,
        "fats": float(fats) if fats else 0.0,
    }
    if fiber is not None and fiber != "":
        nutrition["fiber"] = float(fiber)
    if sodium is not None and sodium != "":
        nutrition["sodium"] = float(sodium)
    entry["nutrition_per_100g"] = nutrition

    # Update units from dataframe
    units = {}
    if units_data is not None:
        try:
            rows = units_data.values.tolist() if hasattr(units_data, 'values') else units_data
            for row in rows:
                if len(row) >= 2 and row[0] and row[1]:
                    unit_name = str(row[0]).strip()
                    try:
                        unit_grams = float(row[1])
                        if unit_name and unit_grams > 0:
                            units[unit_name] = unit_grams
                    except (ValueError, TypeError):
                        pass
        except Exception:
            pass
    if units:
        entry["grams_per_unit"] = units

    new_db[actual_name] = entry
    return new_db


def review_nutrition_with_llm(food_name: str, nutrition: dict) -> tuple[str, str]:
    """Ask LLM to review if nutrition values seem accurate for the food item.

    Returns:
        Tuple of (response, prompt) so both can be displayed.
    """
    from food_log.config import MODEL_ID
    from food_log.llm.client import create_openrouter_client

    # Build nutrition lines, skipping None/undefined values
    nutrition_lines = []
    if nutrition.get('calories') is not None:
        nutrition_lines.append(f"- Calories: {nutrition['calories']} kcal")
    if nutrition.get('proteins') is not None:
        nutrition_lines.append(f"- Proteins: {nutrition['proteins']} g")
    if nutrition.get('carbs') is not None:
        nutrition_lines.append(f"- Carbs: {nutrition['carbs']} g")
    if nutrition.get('fats') is not None:
        nutrition_lines.append(f"- Fats: {nutrition['fats']} g")
    if nutrition.get('fiber') is not None:
        nutrition_lines.append(f"- Fiber: {nutrition['fiber']} g")
    if nutrition.get('sodium') is not None:
        nutrition_lines.append(f"- Sodium: {nutrition['sodium']} g")

    nutrition_text = "\n".join(nutrition_lines) if nutrition_lines else "No nutrition data available"

    prompt = f"""You are a nutrition expert. Review the following nutrition data for "{food_name}" and assess if the values seem reasonable and accurate.

Nutrition per 100g:
{nutrition_text}

Provide a brief assessment (2-3 sentences):
1. Do these values seem reasonable for this type of food?
2. Are there any values that look suspicious or incorrect?
3. Any concerns?

Be concise and direct."""

    try:
        client = create_openrouter_client()

        response = client.chat.completions.create(
            model=MODEL_ID,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.3,
            max_tokens=300,
        )
        return response.choices[0].message.content.strip(), prompt
    except Exception as e:
        return f"Error: {str(e)}", prompt


def _do_scrape(url: str) -> tuple[dict | None, str]:
    """Internal scrape function that runs the actual scraping."""
    scraper = registry.get_scraper(url)
    if not scraper:
        return None, "No scraper available for this URL"

    result = scraper.scrape(url)

    if not result.success:
        return None, f"Scrape failed: {result.error}"

    entry = result.entry
    return {
        "calories": entry.nutrition_per_100g.calories,
        "proteins": entry.nutrition_per_100g.proteins,
        "carbs": entry.nutrition_per_100g.carbs,
        "fats": entry.nutrition_per_100g.fats,
        "fiber": entry.nutrition_per_100g.fiber,
        "sodium": entry.nutrition_per_100g.sodium,
        "grams_per_unit": entry.grams_per_unit,
    }, "Scraped successfully!"


def scrape_url(url: str) -> tuple[dict | None, str]:
    """Scrape URL and return nutrition data or error message.

    Runs scraping in a separate thread to avoid Gradio event loop issues.
    """
    if not url:
        return None, "No URL provided"

    try:
        # Run in a separate thread to isolate from Gradio's event loop
        with ThreadPoolExecutor(max_workers=1) as executor:
            future = executor.submit(_do_scrape, url)
            return future.result(timeout=120)  # 2 minute timeout
    except Exception as e:
        tb = traceback.format_exc()
        print(f"Scrape error: {e}\n{tb}")
        return None, f"Scrape error: {str(e)}"


def create_app():
    """Create and configure the Gradio interface."""

    # Track if we've created a backup this session
    backup_created = {"value": False}

    with gr.Blocks(title="Food Database Review") as demo:

        # State
        database = gr.State({})
        item_order = gr.State([])
        current_index = gr.State(0)
        # Store original values for comparison after scrape
        original_nutrition = gr.State({})

        # Header
        gr.Markdown("# Food Database Review Tool")
        progress_text = gr.Markdown("Loading...")

        # Item header
        food_name = gr.Markdown("## Loading...")
        with gr.Row() as url_row:
            url_display = gr.Textbox(label="URL", interactive=True, scale=10, placeholder="Enter product URL...")
            open_url_btn = gr.Button("Open", size="sm", scale=0, min_width=60)
            scrape_btn = gr.Button("Scrape", size="sm", variant="secondary", scale=0, min_width=70)
        bad_url_warning = gr.Markdown("**Warning:** URL marked as bad", visible=False)
        scrape_status = gr.Markdown("")

        # Hidden fields to store current values (needed for saving)
        with gr.Row(visible=False):
            review_status = gr.Textbox(value="pending")
            calories = gr.Number(value=0)
            proteins = gr.Number(value=0)
            carbs = gr.Number(value=0)
            fats = gr.Number(value=0)
            fiber = gr.Number(value=0)
            sodium = gr.Number(value=0)
            units_table = gr.Dataframe(
                headers=["Unit", "Grams"],
                datatype=["str", "number"],
            )

        # Keyboard shortcuts JavaScript
        gr.HTML(KEYBOARD_JS)

        # === Nutrition display ===
        gr.Markdown("---")
        scrape_error_msg = gr.Markdown("", visible=False)
        with gr.Row():
            with gr.Column(scale=1):
                gr.Markdown("### Nutrition per 100g")
                nutrition_comparison = gr.Markdown("")
                gr.Markdown("### Supported Units")
                units_display = gr.Markdown("*No units defined*")
            with gr.Column(scale=1):
                with gr.Row():
                    gr.Markdown("### LLM Review")
                    review_btn = gr.Button("Review", size="sm", variant="secondary", scale=0, min_width=70)
                llm_review_output = gr.Textbox(
                    label="",
                    show_label=False,
                    interactive=False,
                    lines=10,
                    placeholder="Click 'Review' to check if nutrition values seem accurate...",
                )
        gr.Markdown("---")

        # Action buttons (bottom)
        with gr.Row():
            reject_btn = gr.Button("Reject (R)", elem_id="reject-btn", variant="stop")
            skip_btn = gr.Button("Skip (S)", elem_id="skip-btn", variant="secondary")
            accept_btn = gr.Button("Accept (A)", elem_id="accept-btn", variant="primary")

        # Status message and keyboard hints
        status_msg = gr.Markdown("")
        gr.Markdown("*Keys: A=Accept, R=Reject, S=Skip*")

        # === Helper functions ===
        def get_current_name(food_name_md: str) -> str:
            """Extract name from markdown header."""
            return food_name_md.replace("## ", "").strip() if food_name_md else ""

        # === Event Handlers ===
        def initialize():
            """Load database and populate first item."""
            db = load_database()
            order = get_item_order(db, "unreviewed")
            idx = 0

            if order:
                values = load_item_to_form(db, order[0])
                progress = get_progress_text(db, idx, order)

                # Build current nutrition dict and table
                current_nutrition = {
                    "calories": values[5],
                    "proteins": values[6],
                    "carbs": values[7],
                    "fats": values[8],
                    "fiber": values[9],
                    "sodium": values[10],
                }
                nutrition_table = build_nutrition_table(current_nutrition)

                # Build units display from units data
                units_data = values[11]
                units_dict = {row[0]: row[1] for row in units_data if len(row) >= 2}
                units_table_md = build_units_table(units_dict)

                return (
                    db, order, idx,
                    current_nutrition,  # original_nutrition
                    progress,
                    values[0],  # food_name
                    gr.update(),  # url_row (always visible)
                    values[1],  # url
                    values[2],  # status
                    gr.update(visible=values[4]),  # bad_url_warning
                    "",  # scrape_status
                    values[5],  # calories
                    values[6],  # proteins
                    values[7],  # carbs
                    values[8],  # fats
                    values[9],  # fiber
                    values[10],  # sodium
                    values[11],  # units_table
                    nutrition_table,  # nutrition_comparison
                    units_table_md,  # units_display
                    "",  # llm_review_output
                    "",  # status_msg
                )
            else:
                return (
                    db, order, idx,
                    {},  # original_nutrition
                    "**No items to review**",
                    "## All done!",
                    gr.update(),  # url_row (always visible)
                    "",
                    "pending",
                    gr.update(visible=False),
                    "",  # scrape_status
                    0, 0.0, 0.0, 0.0, None, None,
                    [],
                    "",  # nutrition_comparison
                    "*No units defined*",  # units_display
                    "",  # llm_review_output
                    "All items have been reviewed!",
                )

        def review_item(
            database: dict,
            _item_order: list,
            _current_index: int,
            food_name: str,
            url: str,
            new_status: str,
            calories: int,
            proteins: float,
            carbs: float,
            fats: float,
            fiber: float | None,
            sodium: float | None,
            units_data: list,
        ):
            """Save review status and advance to next unreviewed item."""
            # Create backup on first save
            if not backup_created["value"]:
                create_backup(FOOD_DATABASE_PATH)
                backup_created["value"] = True

            # Save to database
            new_db = save_item_to_database(
                database, food_name, url, new_status,
                calories, proteins, carbs, fats, fiber, sodium, units_data
            )
            save_database(new_db)

            actual_name = get_current_name(food_name)
            msg = f"Marked **{actual_name}** as **{new_status}**"

            # Rebuild order with only unreviewed items
            new_order = get_item_order(new_db, "unreviewed")

            # If no more items to review
            if not new_order:
                return (
                    new_db,
                    new_order,  # item_order (empty)
                    0,
                    {},  # original_nutrition
                    "**All done!**",
                    "## All items reviewed!",
                    gr.update(),  # url_row (always visible)
                    "",
                    "pending",
                    gr.update(visible=False),
                    "",  # scrape_status
                    0, 0.0, 0.0, 0.0, None, None,
                    [],
                    "",  # nutrition_comparison
                    "*No units defined*",  # units_display
                    "",  # llm_review_output
                    msg + " - All items reviewed!",
                )

            # Load first unreviewed item
            new_idx = 0
            name = new_order[new_idx]
            values = load_item_to_form(new_db, name)
            progress = get_progress_text(new_db, new_idx, new_order)

            # Build current nutrition dict and table
            current_nutrition = {
                "calories": values[5],
                "proteins": values[6],
                "carbs": values[7],
                "fats": values[8],
                "fiber": values[9],
                "sodium": values[10],
            }
            nutrition_table = build_nutrition_table(current_nutrition)

            # Build units display from units data
            units_data = values[11]
            units_dict = {row[0]: row[1] for row in units_data if len(row) >= 2}
            units_table_md = build_units_table(units_dict)

            return (
                new_db,
                new_order,  # item_order (updated)
                new_idx,
                current_nutrition,  # original_nutrition (reset for new item)
                progress,
                values[0],  # food_name
                gr.update(),  # url_row (always visible)
                values[1],  # url
                values[2],  # status
                gr.update(visible=values[4]),  # bad_url_warning
                "",  # scrape_status
                values[5],  # calories
                values[6],  # proteins
                values[7],  # carbs
                values[8],  # fats
                values[9],  # fiber
                values[10],  # sodium
                values[11],  # units_table
                nutrition_table,  # nutrition_comparison
                units_table_md,  # units_display
                "",  # llm_review_output
                msg,
            )

        def do_scrape(url: str, orig_nutrition: dict):
            """Scrape URL and update form fields with scraped values."""
            if not url:
                return (
                    gr.update(),  # calories
                    gr.update(),  # proteins
                    gr.update(),  # carbs
                    gr.update(),  # fats
                    gr.update(),  # fiber
                    gr.update(),  # sodium
                    gr.update(),  # nutrition_comparison
                    gr.update(visible=False),  # scrape_error_msg
                    "No URL to scrape",  # scrape_status
                )

            data, msg = scrape_url(url)

            if data is None:
                return (
                    gr.update(),
                    gr.update(),
                    gr.update(),
                    gr.update(),
                    gr.update(),
                    gr.update(),
                    gr.update(),
                    gr.update(visible=True, value=f"**Error:** {msg}"),
                    "",
                )

            # Build comparison table showing new (scraped) vs previous (original)
            scraped_nutrition = {
                "calories": data["calories"],
                "proteins": data["proteins"],
                "carbs": data["carbs"],
                "fats": data["fats"],
                "fiber": data.get("fiber"),
                "sodium": data.get("sodium"),
            }
            nutrition_table = build_nutrition_table(scraped_nutrition, orig_nutrition)

            return (
                data["calories"],  # calories - update form field
                data["proteins"],  # proteins
                data["carbs"],  # carbs
                data["fats"],  # fats
                data.get("fiber"),  # fiber
                data.get("sodium"),  # sodium
                nutrition_table,  # nutrition_comparison (scraped vs original)
                gr.update(visible=False),  # scrape_error_msg
                "Scraped! Values updated.",  # scrape_status
            )

        # === Wire up events ===

        # Initialize outputs
        init_outputs = [
            database, item_order, current_index,
            original_nutrition,
            progress_text,
            food_name,
            url_row,
            url_display,
            review_status,
            bad_url_warning,
            scrape_status,
            calories, proteins, carbs, fats, fiber, sodium,
            units_table,
            nutrition_comparison,
            units_display,
            llm_review_output,
            status_msg,
        ]

        # On load
        demo.load(fn=initialize, outputs=init_outputs)

        # Review outputs (same as init)
        review_outputs = init_outputs

        review_inputs = [
            database, item_order, current_index,
            food_name, url_display,
        ]

        form_inputs = [calories, proteins, carbs, fats, fiber, sodium, units_table]

        # Accept button - saves current form values
        accept_btn.click(
            fn=lambda db, order, idx, name, url, cal, pro, carb, fat, fib, sod, units:
                review_item(db, order, idx, name, url, "accepted", cal, pro, carb, fat, fib, sod, units),
            inputs=review_inputs + form_inputs,
            outputs=review_outputs,
        )

        # Reject button
        reject_btn.click(
            fn=lambda db, order, idx, name, url, cal, pro, carb, fat, fib, sod, units:
                review_item(db, order, idx, name, url, "rejected", cal, pro, carb, fat, fib, sod, units),
            inputs=review_inputs + form_inputs,
            outputs=review_outputs,
        )

        # Skip button
        skip_btn.click(
            fn=lambda db, order, idx, name, url, cal, pro, carb, fat, fib, sod, units:
                review_item(db, order, idx, name, url, "skipped", cal, pro, carb, fat, fib, sod, units),
            inputs=review_inputs + form_inputs,
            outputs=review_outputs,
        )

        # === Scrape blocking helpers ===
        def disable_actions():
            """Disable all action buttons while scraping."""
            return (
                gr.update(interactive=False),  # accept_btn
                gr.update(interactive=False),  # reject_btn
                gr.update(interactive=False),  # skip_btn
                gr.update(interactive=False),  # scrape_btn
                gr.update(interactive=False),  # review_btn
                gr.update(interactive=False),  # open_url_btn
                "Scraping...",  # scrape_status
            )

        def enable_actions():
            """Re-enable all action buttons after scraping."""
            return (
                gr.update(interactive=True),  # accept_btn
                gr.update(interactive=True),  # reject_btn
                gr.update(interactive=True),  # skip_btn
                gr.update(interactive=True),  # scrape_btn
                gr.update(interactive=True),  # review_btn
                gr.update(interactive=True),  # open_url_btn
            )

        # Scrape button - updates form fields with scraped values
        # Chain: disable buttons -> scrape -> enable buttons
        scrape_btn.click(
            fn=disable_actions,
            outputs=[accept_btn, reject_btn, skip_btn, scrape_btn, review_btn, open_url_btn, scrape_status],
        ).then(
            fn=do_scrape,
            inputs=[url_display, original_nutrition],
            outputs=[
                calories, proteins, carbs, fats, fiber, sodium,
                nutrition_comparison, scrape_error_msg, scrape_status
            ],
        ).then(
            fn=enable_actions,
            outputs=[accept_btn, reject_btn, skip_btn, scrape_btn, review_btn, open_url_btn],
        )

        # URL open - use JavaScript
        open_url_btn.click(
            fn=None,
            inputs=[url_display],
            outputs=None,
            js="(url) => { if(url) window.open(url, '_blank'); }",
        )

        # LLM Review button - uses current form values (which may be scraped)
        def do_llm_review(name_md: str, cal, pro, carb, fat, fib, sod):
            """Send current nutrition values to LLM for review."""
            name = name_md.replace("## ", "").strip() if name_md else "Unknown"
            nutrition = {
                "calories": cal,
                "proteins": pro,
                "carbs": carb,
                "fats": fat,
                "fiber": fib,
                "sodium": sod,
            }
            response, prompt = review_nutrition_with_llm(name, nutrition)
            # Combine with clear delimiters
            combined = f"""=== RESPONSE ===
{response}

=== PROMPT ===
{prompt}"""
            return combined

        review_btn.click(
            fn=do_llm_review,
            inputs=[food_name, calories, proteins, carbs, fats, fiber, sodium],
            outputs=[llm_review_output],
        )

    return demo


if __name__ == "__main__":
    app = create_app()
    app.launch()
