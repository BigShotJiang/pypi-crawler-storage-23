#!/usr/bin/env python3
"""
Scrape nutrition data from product URLs and add to food database.

This script provides a CLI for scraping product pages and optionally
adding the extracted nutrition data to the food database.

Usage:
    # Scrape and display (dry-run)
    uv run python scrape_food.py URL

    # Scrape and add to database
    uv run python scrape_food.py --add URL

    # Validate against existing entry
    uv run python scrape_food.py --validate URL

    # Override product name
    uv run python scrape_food.py --add --name "custom name" URL

    # List supported sites
    uv run python scrape_food.py --list-scrapers

Examples:
    uv run python scrape_food.py https://www.continente.pt/produto/cereais-fitness-trigo-e-aveia-integral-fitness-2161310.html
    uv run python scrape_food.py --add --name "cereais fitness" https://www.continente.pt/produto/cereais-fitness-trigo-e-aveia-integral-fitness-2161310.html
"""

import argparse
import logging
import sys

from food_log import FOOD_DATABASE_PATH
from scrapers import (
    CeleiroScraper,
    ContinenteScraper,
    PingoDoceScraper,
    create_backup,
    load_database,
    merge_entry,
    registry,
    save_database,
    validate_against_existing,
)

# Configure logging
logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)

# Register all available scrapers
registry.register(CeleiroScraper())
registry.register(ContinenteScraper())
registry.register(PingoDoceScraper())


def main_cli(args) -> int:
    """Core CLI logic, accepts a pre-parsed argparse namespace."""
    # Handle --list-scrapers
    if args.list_scrapers:
        print("Supported sites:")
        for name in registry.list_scrapers():
            print(f"  - {name}")
        return 0

    # Require URL for scraping operations
    if not args.url:
        parser.print_help()
        return 1

    # Find appropriate scraper
    scraper = registry.get_scraper(args.url)
    if not scraper:
        logger.error(f"No scraper available for URL: {args.url}")
        logger.info("Use --list-scrapers to see supported sites")
        return 1

    logger.info(f"Using {scraper.name} scraper")

    # Scrape the URL
    result = scraper.scrape(args.url)

    if not result.success:
        logger.error(f"Scrape failed: {result.error}")
        return 1

    entry = result.entry

    # Override name if provided
    if args.name:
        entry = entry.model_copy(update={"name": args.name.strip().lower()})

    # Display scraped data
    print(f"\nScraped data for: {entry.name}")
    print(f"URL: {entry.url}")

    # Show unit weight if available
    package_weight = entry.grams_per_unit.get("unit")
    if package_weight:
        print(f"Package weight: {package_weight}g")

    print(f"Nutrition per 100g:")
    print(f"  Calories: {entry.nutrition_per_100g.calories} kcal")
    print(f"  Proteins: {entry.nutrition_per_100g.proteins} g")
    print(f"  Carbs: {entry.nutrition_per_100g.carbs} g")
    print(f"  Fats: {entry.nutrition_per_100g.fats} g")
    if entry.nutrition_per_100g.fiber is not None:
        print(f"  Fiber: {entry.nutrition_per_100g.fiber} g")
    if entry.nutrition_per_100g.sodium is not None:
        print(f"  Sodium: {entry.nutrition_per_100g.sodium} g")

    # Prompt for number of items in package to calculate per-unit weight
    if package_weight and (args.add or args.validate):
        print(f"\nThe scraped weight ({package_weight}g) is the total package weight.")
        try:
            num_items = input("How many items are in the package? (press Enter to skip): ").strip()
            if num_items:
                num_items = int(num_items)
                if num_items > 0:
                    unit_weight = round(package_weight / num_items, 2)
                    print(f"Calculated unit weight: {package_weight}g / {num_items} = {unit_weight}g per unit")
                    # Update the entry with calculated unit weight
                    new_grams = dict(entry.grams_per_unit)
                    new_grams["unit"] = unit_weight
                    entry = entry.model_copy(update={"grams_per_unit": new_grams})
        except ValueError:
            logger.warning("Invalid number, using package weight as-is")
        except EOFError:
            # Non-interactive mode, skip
            pass

    # Validate if requested
    if args.validate:
        existing = load_database()
        validation = validate_against_existing(entry.model_dump(), existing)

        if validation["match"]:
            print(f"\nValidation against existing entry:")
            all_ok = True
            for field, diff in validation["differences"].items():
                status = "OK" if diff["diff_pct"] <= 5 else "DIFF"
                if status == "DIFF":
                    all_ok = False
                print(
                    f"  {field}: scraped={diff['scraped']} vs existing={diff['existing']} "
                    f"({diff['diff_pct']:.1f}% diff) [{status}]"
                )
            if all_ok:
                print("All values within 5% tolerance")
            else:
                print("WARNING: Some values differ by more than 5%")
        else:
            print(f"\nNo existing entry found for '{entry.name}' to validate against")

    # Add to database if requested
    if args.add:
        existing = load_database()

        # Create backup before modifying
        create_backup(FOOD_DATABASE_PATH)

        # Merge the entry
        merged, added, skipped = merge_entry(
            existing, entry.model_dump(), overwrite=args.overwrite
        )

        if added:
            save_database(merged)
            logger.info(f"Added '{entry.name}' to database")
        else:
            logger.info(f"Entry '{entry.name}' already exists (use --overwrite to replace)")

    return 0


def main() -> int:
    """Main entry point with argument parsing."""
    parser = argparse.ArgumentParser(
        description="Scrape nutrition data from product URLs",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument("url", nargs="?", help="Product URL to scrape")
    parser.add_argument("--add", action="store_true", help="Add to food database")
    parser.add_argument(
        "--validate", action="store_true", help="Validate against existing entry"
    )
    parser.add_argument(
        "--overwrite", action="store_true", help="Overwrite existing entries"
    )
    parser.add_argument("--list-scrapers", action="store_true", help="List supported sites")
    parser.add_argument("--name", type=str, help="Override product name")

    args = parser.parse_args()
    return main_cli(args)


if __name__ == "__main__":
    sys.exit(main())
