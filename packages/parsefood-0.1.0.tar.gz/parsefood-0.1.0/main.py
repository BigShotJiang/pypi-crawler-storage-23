"""
Food Log Parser - Main entry point.

Processes Telegram food logs, extracts food data using LLM,
calculates nutrition, and generates visualizations.
"""

import argparse
import logging
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

# Import from food_log package
from food_log import (
    PATHS,
    TARGET_CALORIES,
    create_backup,
    get_runtime_config,
    list_profiles,
    load_json,
    load_profile,
    save_json,
)
from food_log.processing import (
    group_messages_by_date,
    load_messages,
    process_date_messages_map,
    run_validation,
    validate_and_migrate_existing_data,
)
from food_log.processing.nutrition import NutritionCalculator
from food_log.visualization import plot_calories

# External integrations
from s3_storage import create_s3_storage
from scripts.telegram_sync import sync_from_env

# Configure logging
logging.basicConfig(level=logging.INFO, stream=sys.stdout)
logger = logging.getLogger(__name__)


def format_macro_breakdown(proteins: float, carbs: float, fats: float, fiber: float) -> str:
    """Format macros as 'Protein Xg (Y%) | Carbs Xg (Y%) | Fat Xg (Y%) | Fiber Xg (Y%)'"""
    total = proteins + carbs + fats + fiber
    if total == 0:
        return ""

    p_pct = (proteins / total) * 100
    c_pct = (carbs / total) * 100
    f_pct = (fats / total) * 100
    fiber_pct = (fiber / total) * 100

    result = f"Protein {proteins:.0f}g ({p_pct:.0f}%) | Carbs {carbs:.0f}g ({c_pct:.0f}%) | Fat {fats:.0f}g ({f_pct:.0f}%)"
    if fiber > 0:
        result += f" | Fiber {fiber:.0f}g ({fiber_pct:.0f}%)"
    return result


def get_progress_color(progress: float) -> str:
    """Return ANSI color code based on progress toward goal.

    Red when low, transitions to green as goal is achieved.
    """
    if progress >= 1.0:
        return "\033[92m"  # Bright green - goal met
    elif progress >= 0.67:
        return "\033[32m"  # Green - close to goal
    elif progress >= 0.33:
        return "\033[93m"  # Yellow - making progress
    else:
        return "\033[91m"  # Red - far from goal


def render_progress_bar(calories: int, target: int, bar_width: int = 20) -> str:
    """Render a colored progress bar string with percentage and remaining text."""
    progress = min(calories / target, 1.0) if target > 0 else 0
    filled = int(bar_width * progress)
    empty = bar_width - filled
    bar_color = get_progress_color(progress)
    reset = "\033[0m"
    bar = f"{bar_color}{'█' * filled}{reset}{'░' * empty}"

    remaining = target - calories
    remaining_text = f"({remaining} kcal remaining)" if remaining > 0 else f"({abs(remaining)} kcal over)"

    return f"{calories} / {target} kcal [{bar}] {progress * 100:.0f}% {remaining_text}"


def parse_and_display_foods(processed_items: list, calculator: Optional[NutritionCalculator] = None) -> list:
    """Parse semicolon-delimited food items, print each, and return unmatched info.

    Returns list of dicts with 'ingredient', 'unit', and 'reason' keys for items with 0 calories.
    """
    dim = "\033[90m"
    reset = "\033[0m"
    # Suppress nutrition logger warnings during display-time matching
    nutrition_logger = logging.getLogger('food_log.processing.nutrition')
    prev_level = nutrition_logger.level
    nutrition_logger.setLevel(logging.ERROR)
    unmatched = []
    for item in processed_items:
        parts = item.split(';')
        if len(parts) != 4:
            continue
        ingredient, quantity, unit, cal_str = parts
        cal = int(cal_str) if cal_str.isdigit() else 0
        desc = f"{quantity} {unit} {ingredient}"
        line = f"  {desc:<50} {cal:>4} kcal"
        if calculator:
            food_id = calculator.match_ingredient(ingredient)
            db_label = food_id if food_id else "?"
            line += f"  {dim}[{db_label}]{reset}"
        print(line)
        if cal == 0 and calculator:
            food_id = calculator.match_ingredient(ingredient)
            if not food_id:
                unmatched.append({'ingredient': ingredient, 'unit': unit, 'reason': 'ingredient not in database'})
            else:
                food_data = calculator.database[food_id]
                available_units = list(food_data.get('grams_per_unit', {}).keys()) + ['g']
                unmatched.append({'ingredient': ingredient, 'unit': unit, 'reason': f'unit "{unit}" not found (available: {", ".join(available_units)})'})
        elif cal == 0:
            unmatched.append({'ingredient': ingredient, 'unit': unit, 'reason': 'unknown'})
    nutrition_logger.setLevel(prev_level)
    return unmatched


def display_macros(data: Dict[str, Any]) -> None:
    """Display macro breakdown from a date data dict if available."""
    proteins = data.get('proteins', 0) or 0
    carbs = data.get('carbs', 0) or 0
    fats = data.get('fats', 0) or 0
    fiber = data.get('fiber', 0) or 0

    if proteins or carbs or fats:
        macro_text = format_macro_breakdown(proteins, carbs, fats, fiber)
        print(f"\nMacros: {macro_text}")


def backup_file(file_path: Path, file_type: str):
    """Create a timestamped backup of a file in DATA_PATH/backups."""
    if not file_path.exists():
        logger.info(f"No {file_type} found at {file_path}, skipping backup")
        return None
    backup_dir = file_path.parent / 'backups'
    return create_backup(file_path, backup_dir)


def backup_result_file(config: Optional[Dict[str, Any]] = None):
    """Create a timestamped backup of result.json."""
    paths = config["paths"] if config else PATHS
    return backup_file(Path(paths['input']), 'result.json')


def backup_messages_file(config: Optional[Dict[str, Any]] = None):
    """Create a timestamped backup of date_messages_map.json."""
    paths = config["paths"] if config else PATHS
    return backup_file(Path(paths['messages']), 'date_messages_map.json')


def sync_telegram(config: Optional[Dict[str, Any]] = None):
    """Sync messages from Telegram to DATA_PATH/result.json."""
    paths = config["paths"] if config else PATHS
    target_file = paths['input']
    logger.info(f"Syncing messages from Telegram to {target_file}...")

    try:
        result = sync_from_env(output_file=target_file, verbose=True)

        if result.get('skipped'):
            logger.info("Telegram sync skipped (not configured)")
            return False

        if not result.get('success'):
            logger.warning(f"Telegram sync failed: {result.get('error', 'Unknown error')}")
            return False

        if result.get('new', 0) > 0 or result.get('updated', 0) > 0:
            logger.info(
                f"Synced {result['new']} new and {result['updated']} updated "
                f"messages to {target_file}"
            )
            return True
        else:
            logger.info(f"Already up to date ({result.get('total', 0)} messages)")
            return False

    except Exception as e:
        logger.warning(f"Telegram sync error: {e}")
        return False


def print_daily_summary(
    date_messages_map: Dict[str, Any],
    target_date: str = None,
    config: Optional[Dict[str, Any]] = None
):
    """Print a summary for a specific date with progress bar."""
    target_calories = config["target_calories"] if config else TARGET_CALORIES

    if target_date is None:
        target_date = datetime.now().strftime('%Y-%m-%d')

    if target_date not in date_messages_map:
        print(f"\n  No data found for {target_date}")
        return

    data = date_messages_map[target_date]
    calories = data.get('total', 0)

    print(f"\n{'─' * 50}")
    print(f"  Date: {target_date}")
    print(f"  {render_progress_bar(calories, target_calories, bar_width=30)}")
    print(f"{'─' * 50}\n")


def show_today_status(config: Optional[Dict[str, Any]] = None):
    """Quick read-only view of today's food log with details."""
    paths = config["paths"] if config else PATHS
    target_calories = config["target_calories"] if config else TARGET_CALORIES
    profile_name = config["name"] if config else None

    today = datetime.now().strftime('%Y-%m-%d')

    # Load existing data without processing
    if not os.path.exists(paths['messages']):
        print(f"No data file found at {paths['messages']}")
        print("Run 'python main.py' first to process your food logs.")
        return

    date_messages_map = load_json(paths['messages'])

    if today not in date_messages_map:
        print(f"\nNo data for today ({today})")
        # Show most recent date instead
        dates = sorted(date_messages_map.keys(), reverse=True)
        if dates:
            print(f"Most recent: {dates[0]}")
        return

    data = date_messages_map[today]
    calories = data.get('total', 0)

    header = f"{profile_name} - " if profile_name else ""
    print(f"\n{header}Today ({today}): {render_progress_bar(calories, target_calories)}")
    print()

    calculator = NutritionCalculator()
    unmatched = parse_and_display_foods(data.get('processed', []), calculator)
    if unmatched:
        for u in unmatched:
            print(f"\033[93m  ! {u['ingredient']}: {u['reason']}\033[0m")

    display_macros(data)

    # Calculate 7-day average
    dates = sorted(date_messages_map.keys(), reverse=True)
    recent_dates = [d for d in dates if d <= today][:7]
    if len(recent_dates) > 1:
        totals = [date_messages_map[d].get('total', 0) for d in recent_dates]
        avg = sum(totals) / len(totals)
        print(f"\n7-day avg: {avg:.0f} kcal")
    print()


def show_recent_status(
    date_messages_map: Dict[str, Any],
    days: int = 1,
    config: Optional[Dict[str, Any]] = None
):
    """Show detailed status for the last N days.

    Args:
        date_messages_map: The processed data map.
        days: Number of recent days to display.
        config: Optional runtime config dict.
    """
    target_calories = config["target_calories"] if config else TARGET_CALORIES
    profile_name = config["name"] if config else None

    today = datetime.now().strftime('%Y-%m-%d')

    # Get the last N days with data (oldest first, most recent last)
    all_dates = sorted(date_messages_map.keys(), reverse=True)
    recent_dates = [d for d in all_dates if d <= today][:days]
    recent_dates.reverse()  # Show oldest first, most recent last

    if not recent_dates:
        print(f"\nNo data found")
        return

    calculator = NutritionCalculator()

    # Display each day
    for date in recent_dates:
        data = date_messages_map[date]
        calories = data.get('total', 0)

        label = "Today" if date == today else date
        header = f"{profile_name} - " if profile_name else ""
        print(f"\n{header}{label} ({date}): {render_progress_bar(calories, target_calories)}")
        print()

        unmatched = parse_and_display_foods(data.get('processed', []), calculator)
        if unmatched:
            for u in unmatched:
                print(f"\033[93m  ! {u['ingredient']}: {u['reason']}\033[0m")

        display_macros(data)

    # Calculate N-day average (use max of requested days and available data)
    avg_dates = [d for d in all_dates if d <= today][:max(days, 7)]
    if len(avg_dates) > 1:
        totals = [date_messages_map[d].get('total', 0) for d in avg_dates]
        avg = sum(totals) / len(totals)
        print(f"\n{len(avg_dates)}-day avg: {avg:.0f} kcal")
    print()


def run(
    use_consistency: bool = True,
    force_regen: bool = False,
    report_days: int = 1,
    config: Optional[Dict[str, Any]] = None
):
    """Main processing pipeline.

    Args:
        use_consistency: Whether to use self-consistency checking for extraction.
        force_regen: Whether to force regeneration of the last N days (controlled by report_days).
        report_days: Number of recent days to show in the final report (and to regenerate with --regen).
        config: Optional runtime config dict. Uses defaults if not provided.
    """
    paths = config["paths"] if config else PATHS
    data_path = config["data_path"] if config else os.getenv("DATA_PATH", "data")
    profile_name = config["name"] if config else None

    logger.info("Starting process")
    if profile_name:
        logger.info(f"Profile: {profile_name}")
    logger.info(f"DATA_PATH: {data_path}")
    if use_consistency:
        logger.info("Self-consistency checking: enabled")
    logger.info(f"Input file: {paths['input']}")

    # Initialize S3 storage
    s3 = create_s3_storage()

    # Step 1: Backup existing result.json before syncing
    backup_result_file(config)

    # Step 2: Sync messages from Telegram
    sync_telegram(config)

    # Step 3: Download latest date_messages_map.json from S3 (if enabled)
    s3.sync_down('date_messages_map.json', paths['messages'])

    # Step 4: Backup existing date_messages_map.json before processing
    backup_messages_file(config)

    # Step 5: Load and group messages
    messages = load_messages(config)
    logger.info(f"Loaded {len(messages)} messages")
    date_messages_map = group_messages_by_date(messages, config)

    # Step 6: Load previously processed messages
    if not os.path.exists(paths['messages']):
        save_json(paths['messages'], date_messages_map)
    existing_date_messages_map = load_json(paths['messages'])

    # Step 6b: Force regeneration of last N days if requested
    if force_regen:
        today = datetime.now().strftime('%Y-%m-%d')
        all_dates = sorted(
            [d for d in existing_date_messages_map if d <= today],
            reverse=True
        )[:report_days]
        for date in all_dates:
            if "processed" in existing_date_messages_map[date]:
                logger.info(f"Forcing regeneration of {date}")
                del existing_date_messages_map[date]["processed"]

    # Step 7: Check for changes in existing dates and mark for reprocessing
    for date in date_messages_map:
        if date in existing_date_messages_map:
            previous_text = "\n".join(existing_date_messages_map[date]["original"])
            current_text = "\n".join(date_messages_map[date]["original"])
            if (current_text and previous_text != current_text
                    and "processed" in existing_date_messages_map[date]):
                logger.info(f"Reprocessing {date}")
                existing_date_messages_map[date]["original"] = date_messages_map[date]["original"]
                del existing_date_messages_map[date]["processed"]

    # Step 8: Process unprocessed messages
    date_messages_map = {**date_messages_map, **existing_date_messages_map}
    date_messages_map = validate_and_migrate_existing_data(date_messages_map)

    process_dates = [
        date for date in date_messages_map
        if "processed" not in date_messages_map[date]
    ]
    logger.info(f"Dates to process: {len(process_dates)} - {process_dates}")
    date_messages_map = process_date_messages_map(
        date_messages_map,
        process_dates,
        use_consistency=use_consistency
    )

    # Step 9: Save and plot
    save_json(paths['messages'], date_messages_map)
    plot_calories(date_messages_map)

    # Step 10: Upload updated date_messages_map.json to S3 (if enabled)
    s3.sync_up(paths['messages'], 'date_messages_map.json')

    # Step 11: Show recent status (detailed view)
    show_recent_status(date_messages_map, report_days, config)

    logger.info("Finished process")


def create_parser() -> argparse.ArgumentParser:
    """Create the argument parser with subcommands."""
    parser = argparse.ArgumentParser(
        description="Food Log Parser - Process and analyze food logs from Telegram"
    )

    # Profile options (top-level)
    parser.add_argument(
        "--profile", "-p",
        help="Use a specific profile (e.g., cristina)"
    )
    parser.add_argument(
        "--list-profiles",
        action="store_true",
        help="List available profiles and exit"
    )

    # Processing options (for default command)
    parser.add_argument(
        "--today", "-t",
        action="store_true",
        help="Show today's food log (read-only, no sync/processing)"
    )
    parser.add_argument(
        "--no-consistency",
        action="store_true",
        help="Disable self-consistency checking (faster, cheaper)"
    )
    parser.add_argument(
        "--regen",
        action="store_true",
        help="Force regeneration of the last N days (use --days to control window, default: 1)"
    )
    parser.add_argument(
        "--days",
        type=int,
        default=1,
        help="Show last N days in final report (default: 1)"
    )

    # Subcommands
    subparsers = parser.add_subparsers(dest="command")

    # validate subcommand
    validate_parser = subparsers.add_parser("validate", help="Validate processed data")
    validate_parser.add_argument("file", help="Data file to validate")
    validate_parser.add_argument("date", nargs="?", help="Specific date to inspect")

    # scrape subcommand
    scrape_parser = subparsers.add_parser(
        "scrape", help="Scrape nutrition data from product URLs"
    )
    scrape_parser.add_argument("url", nargs="?", help="Product URL to scrape")
    scrape_parser.add_argument("--add", action="store_true", help="Add to food database")
    scrape_parser.add_argument(
        "--validate", action="store_true", help="Validate against existing entry"
    )
    scrape_parser.add_argument(
        "--overwrite", action="store_true", help="Overwrite existing entries"
    )
    scrape_parser.add_argument(
        "--list-scrapers", action="store_true", help="List supported sites"
    )
    scrape_parser.add_argument("--name", type=str, help="Override product name")

    # labels subcommand
    subparsers.add_parser("labels", help="Process product label images")

    return parser


def load_config(args):
    """Load profile config from parsed args. Returns config dict."""
    if args.profile:
        try:
            profile = load_profile(args.profile)
            return get_runtime_config(profile)
        except FileNotFoundError:
            print(f"Error: Profile '{args.profile}' not found")
            print("Available profiles:")
            for p in list_profiles():
                print(f"  - {p}")
            sys.exit(1)
        except ValueError as e:
            print(f"Error loading profile: {e}")
            sys.exit(1)
    return get_runtime_config()


def main():
    parser = create_parser()
    args = parser.parse_args()

    # Handle --list-profiles
    if args.list_profiles:
        profiles = list_profiles()
        if not profiles:
            print("No profiles found. Create one in profiles/")
        else:
            print("Available profiles:")
            for p in profiles:
                print(f"  - {p}")
        sys.exit(0)

    # Dispatch subcommands
    if args.command == "scrape":
        from scrape_food import main_cli as scrape_main_cli
        sys.exit(scrape_main_cli(args))

    if args.command == "labels":
        from process_labels import main as labels_main
        sys.exit(labels_main())

    if args.command == "validate":
        run_validation(args.file, args.date)
        return

    # Default: main processing pipeline
    config = load_config(args)

    if args.today:
        show_today_status(config)
    else:
        run(
            use_consistency=not args.no_consistency,
            force_regen=args.regen,
            report_days=args.days,
            config=config
        )


if __name__ == "__main__":
    main()
