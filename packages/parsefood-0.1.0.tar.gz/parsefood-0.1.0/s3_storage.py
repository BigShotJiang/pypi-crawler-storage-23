"""
S3 Storage Module for Food Log Parser

Handles synchronization of data files with AWS S3.
Supports both local (AWS credentials) and EC2 (IAM role) authentication.
"""

import os
import boto3
from botocore.exceptions import ClientError, NoCredentialsError
from pathlib import Path
from typing import Optional


class S3Storage:
    """Handles S3 upload/download operations for data files."""

    def __init__(self):
        """Initialize S3 client with configuration from environment variables."""
        self.enabled = os.getenv('S3_ENABLED', 'false').lower() == 'true'
        self.bucket = os.getenv('S3_BUCKET', '')
        self.region = os.getenv('S3_REGION', 'us-east-1')

        if self.enabled:
            if not self.bucket:
                raise ValueError("S3_BUCKET must be set when S3_ENABLED=true")

            # boto3 automatically handles both IAM role (EC2) and credentials file (local)
            self.client = boto3.client('s3', region_name=self.region)
            print(f"S3 storage enabled: bucket={self.bucket}, region={self.region}")
        else:
            self.client = None
            print("S3 storage disabled - using local files only")

    def download_file(self, s3_key: str, local_path: str) -> bool:
        """
        Download a file from S3 to local path.

        Args:
            s3_key: S3 object key (e.g., 'date_messages_map.json')
            local_path: Local file path to save to

        Returns:
            True if successful, False if file doesn't exist or S3 disabled
        """
        if not self.enabled:
            return False

        try:
            # Ensure local directory exists
            Path(local_path).parent.mkdir(parents=True, exist_ok=True)

            print(f"Downloading s3://{self.bucket}/{s3_key} -> {local_path}")
            self.client.download_file(self.bucket, s3_key, local_path)
            print(f"✓ Downloaded {s3_key}")
            return True

        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', '')
            if error_code == '404':
                print(f"ℹ File not found in S3: {s3_key} (will be created on first upload)")
                return False
            else:
                print(f"✗ Error downloading from S3: {e}")
                return False
        except NoCredentialsError:
            print("✗ AWS credentials not found. Configure credentials with:")
            print("  - EC2: Attach IAM role with S3 access")
            print("  - Local: Run 'aws configure' or set AWS_ACCESS_KEY_ID/AWS_SECRET_ACCESS_KEY")
            raise
        except Exception as e:
            print(f"✗ Unexpected error downloading from S3: {e}")
            return False

    def upload_file(self, local_path: str, s3_key: str) -> bool:
        """
        Upload a local file to S3.

        Args:
            local_path: Local file path to upload
            s3_key: S3 object key (e.g., 'date_messages_map.json')

        Returns:
            True if successful, False if S3 disabled or error occurred
        """
        if not self.enabled:
            return False

        if not os.path.exists(local_path):
            print(f"✗ Local file not found: {local_path}")
            return False

        try:
            print(f"Uploading {local_path} -> s3://{self.bucket}/{s3_key}")
            self.client.upload_file(local_path, self.bucket, s3_key)
            print(f"✓ Uploaded {s3_key}")
            return True

        except NoCredentialsError:
            print("✗ AWS credentials not found. Configure credentials with:")
            print("  - EC2: Attach IAM role with S3 access")
            print("  - Local: Run 'aws configure' or set AWS_ACCESS_KEY_ID/AWS_SECRET_ACCESS_KEY")
            raise
        except Exception as e:
            print(f"✗ Error uploading to S3: {e}")
            return False

    def sync_down(self, s3_key: str, local_path: str) -> None:
        """
        Sync file from S3 to local (download if S3 enabled and file exists).

        Args:
            s3_key: S3 object key
            local_path: Local file path
        """
        if self.enabled:
            self.download_file(s3_key, local_path)

    def sync_up(self, local_path: str, s3_key: str) -> None:
        """
        Sync file from local to S3 (upload if S3 enabled).

        Args:
            local_path: Local file path
            s3_key: S3 object key
        """
        if self.enabled:
            self.upload_file(local_path, s3_key)


def create_s3_storage() -> S3Storage:
    """Factory function to create S3Storage instance."""
    return S3Storage()
