# Food Log Processing Pipeline

> **Keep this doc updated when modifying the pipeline.**

## Quick Overview

```
Telegram → Backup → Load → Group → Detect Changes → LLM Extract → Calc Nutrition → Save → Plot
```

## Pipeline Steps

### 1. Backup Result File
- Backup existing `data/result.json` to `data/backups/result_TIMESTAMP.json`
- Ensures raw data is preserved before any modifications

### 2. Telegram Sync
- Sync latest messages from Telegram API to `data/result.json`
- Uses `scripts/telegram_sync.py` via `sync_from_env()`
- Skipped if Telegram credentials not configured
- Reports new/updated message counts

### 3. S3 Sync Down (Optional)
- Download latest `date_messages_map.json` from S3
- Ensures local state matches cloud state before processing
- Uses `s3_storage.py` module
- Skipped if S3 not configured

### 4. Backup Messages File
- Backup existing `data/date_messages_map.json` to `data/backups/date_messages_map_TIMESTAMP.json`
- Preserves processed data before modifications

### 5. Load Messages
- Read `data/result.json` (Telegram JSON export format)
- Filter messages by sender (`from` field contains "Cristina")
- Filter by type (`type == "message"`)
- Extract text content (handles both string and entity list formats)

### 6. Group by Date
- Group messages by date (YYYY-MM-DD from timestamp)
- Apply blacklist: skip messages with IDs in `BLACKLISTED_IDS`
- Apply date rewrites: override timestamps for IDs in `REWRITE_ID_DATES`
- Filter: ignore messages before `START_DATE` (2023-08-30)
- Output: `{date: {"original": [messages]}}`

### 7. Detect Changes
- Compare current messages against existing processed data
- For each date with existing processed data:
  - If original message text changed → delete `processed` field → mark for reprocessing
  - If unchanged → skip reprocessing
- Merge new dates with existing data

### 8. Validate Existing Data
- Run `validate_and_migrate_existing_data()` on merged dataset
- Parse legacy format entries to verify they're valid
- Log validation results without modifying stored format

### 9. LLM Food Extraction
- Process dates without `processed` field
- For each date's combined message text:
  - Send to OpenRouter API (configurable model via `MODEL_ID`)
  - Prompt includes available foods from `food_database.json`
  - LLM extracts: `{ingredient, quantity, unit}`
  - Map Portuguese units to standard: `tbsp`, `tsp`, `cup`, `unit`, `g`
  - Handle "com" (with) expressions as separate items
- Validate with Pydantic `FoodEntry` model
- Parallel processing: 2 workers (rate limit friendly)

### 10. Nutrition Calculation
- For each extracted `FoodEntry`:
  - Match ingredient to `food_database.json`
  - Look up `grams_per_unit` for the specified unit
  - Calculate calories from `nutrition_per_100g`
  - Calculate macros: proteins, carbs, fats
- Track issues:
  - `no_match`: ingredient not in database
  - `missing_unit`: unit not defined for ingredient
- Set `calories = 0` for failed calculations

### 11. Format & Save
- Convert to legacy format: `ingredient;quantity;unit;calories`
- Store in `date_messages_map.json`:
```json
{
  "YYYY-MM-DD": {
    "original": ["raw message 1", "raw message 2"],
    "processed": ["ingredient;quantity;unit;calories", ...],
    "total": total_calories_int
  }
}
```
- Print processing summary with issues (unmatched foods, missing units)

### 12. S3 Sync Up (Optional)
- Upload updated `date_messages_map.json` to S3
- Keeps cloud state in sync with local processing

### 13. Generate Plot
- Create polynomial regression (degree 2) of calories over time
- X-axis: dates (converted to ordinal)
- Y-axis: daily calories
- Calculate R-squared fit metric
- Save to `data/plot.png`

### 14. Daily Summary
- Print today's calorie summary with progress bar
- Compare against `TARGET_CALORIES` from environment
- Color-coded: green if under target, red if over

## Data Flow Diagram

```
┌─────────────────┐     ┌─────────────────┐
│  Telegram API   │────▶│  result.json    │
└─────────────────┘     └────────┬────────┘
                                 │
                    ┌────────────▼────────────┐
                    │  Filter & Group by Date │
                    └────────────┬────────────┘
                                 │
              ┌──────────────────▼──────────────────┐
              │  Detect changes vs existing data    │
              └──────────────────┬──────────────────┘
                                 │
                    ┌────────────▼────────────┐
                    │   OpenRouter LLM API    │
                    │   (Food Extraction)     │
                    └────────────┬────────────┘
                                 │
              ┌──────────────────▼──────────────────┐
              │  food_database.json                 │
              │  (Nutrition Lookup & Calculation)   │
              └──────────────────┬──────────────────┘
                                 │
                    ┌────────────▼────────────┐
                    │ date_messages_map.json  │
                    └────────────┬────────────┘
                                 │
              ┌──────────┬───────┴───────┬──────────┐
              ▼          ▼               ▼          ▼
         plot.png    S3 Sync      Daily Summary   Logs
```

## Key Files

| File | Purpose |
|------|---------|
| `main.py` | Pipeline orchestration entry point (~200 lines) |
| `food_log/` | Main package with all core functionality |
| `food_log/config.py` | Centralized configuration (paths, units, dates) |
| `food_log/database.py` | Database operations (load/save/backup/merge) |
| `food_log/models.py` | Pydantic models (FoodEntry, FoodLogEntry, etc.) |
| `food_log/llm/extractor.py` | LLM-based food data extraction |
| `food_log/processing/nutrition.py` | Deterministic nutrition calculation from database |
| `food_log/processing/messages.py` | Message loading and grouping |
| `food_log/processing/validation.py` | Data validation logic |
| `food_log/visualization/plots.py` | Calorie trend plotting |
| `scripts/telegram_sync.py` | Telegram API integration for message sync |
| `s3_storage.py` | S3 cloud storage sync |
| `food_database.json` | Structured nutrition database (foods, units, calories) |
| `data/result.json` | Raw Telegram export / synced messages |
| `data/date_messages_map.json` | Processed food log data |
| `data/plot.png` | Generated calorie trend visualization |

## Configuration

| Variable | Purpose |
|----------|---------|
| `MODEL_ID` | OpenRouter model for extraction (e.g., `google/gemini-2.5-flash`) |
| `OPENROUTER_API_KEY` | API key for LLM access |
| `DATA_PATH` | Data directory (default: `data`) |
| `TARGET_CALORIES` | Daily calorie target for summary (default: 2000) |

## Reprocessing Behavior

- **New dates**: Always processed
- **Unchanged dates**: Skipped (use existing `processed` data)
- **Modified dates**: Reprocessed when original message text differs
- **Force reprocess**: Delete `processed` field from `date_messages_map.json` for target date
