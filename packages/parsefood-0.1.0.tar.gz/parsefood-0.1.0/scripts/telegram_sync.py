"""
Telegram sync module for downloading messages from Telegram.
Supports incremental downloads and change detection.
"""

import os
import json
import asyncio
from pathlib import Path
from telethon import TelegramClient
from telethon.tl.types import Message


async def sync_telegram_messages(
    api_id: str,
    api_hash: str,
    phone: str,
    chat_name: str,
    output_file: str,
    session_file: str = 'telegram_session',
    verbose: bool = True
) -> dict:
    """
    Download messages from Telegram chat with incremental sync support.

    Args:
        api_id: Telegram API ID
        api_hash: Telegram API hash
        phone: Phone number with country code
        chat_name: Chat/channel name or ID
        output_file: Path to save messages JSON
        session_file: Session file path (default: 'telegram_session')
        verbose: Print progress messages (default: True)

    Returns:
        dict with keys: 'total', 'new', 'updated', 'success'
    """

    def log(msg: str):
        if verbose:
            print(msg)

    try:
        # Create client
        client = TelegramClient(session_file, int(api_id), api_hash)
        await client.start(phone=phone)

        # Get the chat entity
        chat = None
        try:
            # First, try direct lookup
            chat = await client.get_entity(chat_name)
        except Exception:
            # Search through dialogs
            log(f"🔍 Searching for chat matching '{chat_name}'...")
            async for dialog in client.iter_dialogs():
                dialog_name = getattr(dialog.entity, 'title', None) or getattr(dialog.entity, 'first_name', '')
                if chat_name.lower() in dialog_name.lower():
                    chat = dialog.entity
                    log(f"✅ Found chat: {dialog_name}")
                    break

            if not chat:
                log(f"❌ Could not find chat '{chat_name}'")
                return {'success': False, 'error': f"Chat '{chat_name}' not found"}

        # Check for existing messages
        output_path = Path(output_file)
        existing_messages_map = {}
        max_existing_id = None

        if output_path.exists():
            try:
                with open(output_path, 'r', encoding='utf-8') as f:
                    existing_data = json.load(f)
                    existing_messages = existing_data.get('messages', [])

                    for msg in existing_messages:
                        existing_messages_map[msg['id']] = msg

                    if existing_messages:
                        max_existing_id = max(msg['id'] for msg in existing_messages)
                        log(f"📂 Found {len(existing_messages)} existing messages (newest ID: {max_existing_id})")
            except Exception as e:
                log(f"⚠️  Could not read existing file: {e}")

        # Download messages
        downloaded_messages = {}
        message_count = 0
        new_count = 0
        updated_count = 0

        # Download from last 100 messages to catch edits
        if max_existing_id:
            min_id = max(0, max_existing_id - 100)
            log(f"⏬ Syncing messages after ID {min_id}...")
            messages_iter = client.iter_messages(chat, min_id=min_id)
        else:
            log(f"⏬ Downloading all messages from '{getattr(chat, 'title', chat_name)}'...")
            messages_iter = client.iter_messages(chat)

        async for message in messages_iter:
            if not isinstance(message, Message):
                continue

            # Extract sender name
            sender_name = None
            if message.sender:
                sender_name = getattr(message.sender, 'first_name', None) or \
                             getattr(message.sender, 'title', None) or \
                             'Unknown'

            # Extract text content (skip media)
            text_content = message.text or ""
            if not text_content:
                continue

            # Build message object
            msg_obj = {
                "id": message.id,
                "type": "message",
                "date": message.date.isoformat() if message.date else None,
                "date_unixtime": str(int(message.date.timestamp())) if message.date else None,
                "from": sender_name,
                "from_id": f"user{message.sender_id}" if message.sender_id else None,
                "text": text_content,
                "text_entities": []
            }

            # Check if new or updated
            if message.id in existing_messages_map:
                existing = existing_messages_map[message.id]
                if existing.get('text') != text_content or existing.get('date') != msg_obj['date']:
                    updated_count += 1
            else:
                new_count += 1

            downloaded_messages[message.id] = msg_obj
            message_count += 1

            if verbose and message_count % 500 == 0:
                log(f"  Downloaded {message_count} messages...")

        # Merge with existing messages
        for msg_id, msg in existing_messages_map.items():
            if msg_id not in downloaded_messages:
                downloaded_messages[msg_id] = msg

        # Sort by ID
        all_messages = sorted(downloaded_messages.values(), key=lambda m: m['id'])
        total_count = len(all_messages)

        # Save to file
        output_data = {
            "name": getattr(chat, 'title', chat_name),
            "type": "personal_chat",
            "id": chat.id,
            "messages": all_messages
        }

        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(output_data, f, ensure_ascii=False, indent=2)

        await client.disconnect()

        if new_count > 0 or updated_count > 0:
            log(f"✅ Synced {total_count} messages ({new_count} new, {updated_count} updated)")
        else:
            log(f"✅ Already up to date ({total_count} messages)")

        return {
            'success': True,
            'total': total_count,
            'new': new_count,
            'updated': updated_count
        }

    except Exception as e:
        log(f"❌ Error: {e}")
        return {'success': False, 'error': str(e)}


def sync_from_env(output_file: str = None, verbose: bool = True) -> dict:
    """
    Sync messages using configuration from environment variables.

    Requires:
        TELEGRAM_API_ID
        TELEGRAM_API_HASH
        TELEGRAM_PHONE
        TELEGRAM_CHAT
        TELEGRAM_OUTPUT_FILE (optional if output_file parameter is provided)

    Returns:
        dict with sync results
    """
    from dotenv import load_dotenv
    load_dotenv()

    api_id = os.getenv('TELEGRAM_API_ID')
    api_hash = os.getenv('TELEGRAM_API_HASH')
    phone = os.getenv('TELEGRAM_PHONE')
    chat_name = os.getenv('TELEGRAM_CHAT')

    if not output_file:
        output_file = os.getenv('TELEGRAM_OUTPUT_FILE', 'data/result.json')

    if not all([api_id, api_hash, phone, chat_name]):
        if verbose:
            print("⚠️  Telegram sync disabled: Missing environment variables")
            print("   Set TELEGRAM_API_ID, TELEGRAM_API_HASH, TELEGRAM_PHONE, and TELEGRAM_CHAT to enable")
        return {'success': False, 'error': 'Missing environment variables', 'skipped': True}

    return asyncio.run(sync_telegram_messages(
        api_id=api_id,
        api_hash=api_hash,
        phone=phone,
        chat_name=chat_name,
        output_file=output_file,
        verbose=verbose
    ))
