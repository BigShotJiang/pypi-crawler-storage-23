"""
Migration Comparison Script

This script compares precomputed entries in date_messages_map.json with
regenerated entries using the new codebase (food_database.json).

Two modes:
- Full mode (default): Re-extracts food data using LLM, generates markdown reports
- Quick mode (--quick): Recalculates from existing processed entries, prints to console
"""

import argparse
import json
import logging
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# Add parent directory to path to import main module
sys.path.insert(0, str(Path(__file__).parent.parent))

from dotenv import load_dotenv

from food_log.llm import FoodDataExtractor, parse_legacy_format
from food_log.models import FoodEntry
from food_log.processing import NutritionCalculator
from food_log.utils import normalize_unit

load_dotenv(override=True)

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


class MigrationComparator:
    """Compare old and new food log processing results."""

    def __init__(self, date_messages_map_path: str, food_database_path: str):
        """
        Initialize the comparator.

        Args:
            date_messages_map_path: Path to date_messages_map.json
            food_database_path: Path to food_database.json
        """
        self.date_messages_map_path = Path(date_messages_map_path)
        self.food_database_path = Path(food_database_path)

        # Load data
        with open(self.date_messages_map_path, 'r', encoding='utf-8') as f:
            self.date_messages_map = json.load(f)

        # Initialize extractor and calculator
        api_key = os.getenv("OPENROUTER_API_KEY")
        model = os.getenv("MODEL_ID")

        if not api_key or not model:
            raise ValueError("OPENROUTER_API_KEY and MODEL_ID must be set in environment")

        self.extractor = FoodDataExtractor(api_key=api_key, model=model, temp=0.0)
        self.calculator = NutritionCalculator(str(self.food_database_path))
        self.available_foods = "\n".join(self.calculator.get_available_food_names())

    def parse_old_entry(self, line: str) -> Optional[Dict[str, Any]]:
        """
        Parse old format entry: ingredient;quantity;unit;calories

        Returns dict with keys: ingredient, quantity, unit, calories
        """
        entry = parse_legacy_format(line)
        if entry:
            return {
                'ingredient': entry.ingredient,
                'quantity': entry.quantity,
                'unit': entry.unit,
                'calories': entry.calories
            }
        return None

    def normalize_food_entry(self, entry: FoodEntry) -> Dict[str, Any]:
        """Normalize food entry to dict for comparison."""
        return {
            'ingredient': entry.ingredient.lower().strip(),
            'quantity': entry.quantity,
            'unit': entry.unit.lower().strip(),
            'calories': entry.calories
        }

    def regenerate_date_entry(self, date: str) -> Tuple[List[FoodEntry], int]:
        """
        Regenerate food entries for a date using new codebase.

        Returns:
            Tuple of (food_entries, total_calories)
        """
        if date not in self.date_messages_map:
            raise ValueError(f"Date {date} not found in date_messages_map")

        data = self.date_messages_map[date]
        original_messages = data.get('original', [])

        if not original_messages:
            logging.warning(f"No original messages for date {date}")
            return [], 0

        # Combine all messages
        ingredients_text = '\n'.join(original_messages)

        # Extract food data using LLM
        food_entries, success = self.extractor.extract_food_data(
            ingredients_text, self.available_foods
        )

        if not food_entries:
            logging.warning(f"No food entries extracted for date {date}")
            return [], 0

        # Calculate nutrition for each entry
        for food in food_entries:
            nutrition = self.calculator.calculate_nutrition(
                food.ingredient,
                food.quantity,
                food.unit
            )
            for key in ('proteins', 'carbs', 'fats', 'grams', 'matched_food_id'):
                setattr(food, key, nutrition[key])
            food.calories = nutrition['calories'] or 0

        total_calories = sum(food.calories for food in food_entries)

        return food_entries, total_calories

    def compare_entries(
        self,
        old_entries: List[str],
        new_entries: List[FoodEntry]
    ) -> Dict[str, Any]:
        """
        Compare old and new entries.

        Returns dict with comparison results:
        - exact_matches: entries that match exactly
        - discrepancies: entries with differences
        - only_old: entries only in old
        - only_new: entries only in new
        """
        # Normalize new entries for comparison
        new_normalized = [self.normalize_food_entry(e) for e in new_entries]

        # Parse old entries
        old_normalized = []
        for line in old_entries:
            parsed = self.parse_old_entry(line)
            if parsed:
                old_normalized.append({
                    'ingredient': parsed['ingredient'].lower().strip(),
                    'quantity': parsed['quantity'],
                    'unit': parsed['unit'].lower().strip(),
                    'calories': parsed['calories']
                })

        # Compare
        exact_matches = []
        discrepancies = []
        only_old = []
        only_new = []

        # Create lookup maps for faster comparison
        old_map = {
            f"{e['ingredient']}|{e['quantity']}|{e['unit']}": e
            for e in old_normalized
        }
        new_map = {
            f"{e['ingredient']}|{e['quantity']}|{e['unit']}": e
            for e in new_normalized
        }

        # Find exact matches and discrepancies
        all_keys = set(old_map.keys()) | set(new_map.keys())

        for key in all_keys:
            old_entry = old_map.get(key)
            new_entry = new_map.get(key)

            if old_entry and new_entry:
                # Same ingredient, quantity, unit - compare calories
                if abs(old_entry['calories'] - new_entry['calories']) < 0.01:
                    exact_matches.append(new_entry)
                else:
                    discrepancies.append({
                        'match_key': key,
                        'old': old_entry,
                        'new': new_entry,
                        'calorie_diff': new_entry['calories'] - old_entry['calories']
                    })
            elif old_entry:
                only_old.append(old_entry)
            else:
                only_new.append(new_entry)

        # Track which entries have been matched (for similar entries detection)
        matched_old_keys = set()
        matched_new_keys = set()
        for disc in discrepancies:
            match_key = f"{disc['old']['ingredient']}|{disc['old']['quantity']}|{disc['old']['unit']}"
            matched_old_keys.add(match_key)
            match_key = f"{disc['new']['ingredient']}|{disc['new']['quantity']}|{disc['new']['unit']}"
            matched_new_keys.add(match_key)
        for match in exact_matches:
            match_key = f"{match['ingredient']}|{match['quantity']}|{match['unit']}"
            matched_old_keys.add(match_key)
            matched_new_keys.add(match_key)

        # Find similar entries (same ingredient, different qty/unit)
        for old_e in old_normalized:
            match_key_old = f"{old_e['ingredient']}|{old_e['quantity']}|{old_e['unit']}"
            if match_key_old in matched_old_keys:
                continue  # Already matched

            for new_e in new_normalized:
                match_key_new = f"{new_e['ingredient']}|{new_e['quantity']}|{new_e['unit']}"
                if match_key_new in matched_new_keys:
                    continue  # Already matched

                # Same ingredient but different quantity/unit
                if (old_e['ingredient'] == new_e['ingredient'] and
                        (old_e['quantity'] != new_e['quantity'] or
                         old_e['unit'] != new_e['unit'])):
                    discrepancies.append({
                        'match_key': f"similar_{old_e['ingredient']}",
                        'old': old_e,
                        'new': new_e,
                        'calorie_diff': new_e['calories'] - old_e['calories'],
                        'note': 'Same ingredient but different quantity/unit'
                    })
                    matched_old_keys.add(match_key_old)
                    matched_new_keys.add(match_key_new)
                    break  # Match one old entry to one new entry

        return {
            'exact_matches': exact_matches,
            'discrepancies': discrepancies,
            'only_old': only_old,
            'only_new': only_new
        }

    def generate_report(
        self,
        date: str,
        comparison: Dict[str, Any],
        old_total: int,
        new_total: int
    ) -> str:
        """
        Generate markdown report for a date.

        Args:
            date: The date being compared
            comparison: Result from compare_entries
            old_total: Total calories from old processing
            new_total: Total calories from new processing

        Returns:
            Markdown formatted report string
        """
        lines = []
        lines.append(f"# Migration Comparison Report: {date}\n")
        lines.append(f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        lines.append("---\n")

        # Summary
        lines.append("## Summary\n")
        lines.append(f"- **Old Total Calories:** {old_total}")
        lines.append(f"- **New Total Calories:** {new_total}")
        diff_pct = ((new_total - old_total) / old_total * 100) if old_total > 0 else 0
        lines.append(f"- **Difference:** {new_total - old_total} ({diff_pct:.1f}%)")
        lines.append(f"- **Exact Matches:** {len(comparison['exact_matches'])}")
        lines.append(f"- **Discrepancies:** {len(comparison['discrepancies'])}")
        lines.append(f"- **Only in Old:** {len(comparison['only_old'])}")
        lines.append(f"- **Only in New:** {len(comparison['only_new'])}")
        lines.append("")

        # Exact matches
        if comparison['exact_matches']:
            lines.append("## Exact Matches\n")
            lines.append("These entries match exactly between old and new processing:\n")
            for entry in comparison['exact_matches']:
                lines.append(
                    f"- `{entry['ingredient']}` - {entry['quantity']} "
                    f"{entry['unit']} - {entry['calories']} cal"
                )
            lines.append("")

        # Discrepancies
        if comparison['discrepancies']:
            lines.append("## Discrepancies\n")
            lines.append("These entries differ between old and new processing:\n")
            for disc in comparison['discrepancies']:
                old = disc['old']
                new = disc['new']
                note = disc.get('note', '')

                lines.append(f"### {old['ingredient']}\n")
                lines.append("| | Old | New | Diff |")
                lines.append("|---|---|---|---|")
                lines.append(
                    f"| Quantity | {old['quantity']} | {new['quantity']} | "
                    f"{new['quantity'] - old['quantity']} |"
                )
                lines.append(f"| Unit | `{old['unit']}` | `{new['unit']}` | - |")
                lines.append(
                    f"| Calories | {old['calories']} | {new['calories']} | "
                    f"{disc['calorie_diff']:+d} |"
                )
                if note:
                    lines.append(f"\n**Note:** {note}")
                lines.append("")

        # Only in old
        if comparison['only_old']:
            lines.append("## Only in Old Processing\n")
            lines.append("These entries were found in old processing but not in new:\n")
            for entry in comparison['only_old']:
                lines.append(
                    f"- `{entry['ingredient']}` - {entry['quantity']} "
                    f"{entry['unit']} - {entry['calories']} cal"
                )
            lines.append("")

        # Only in new
        if comparison['only_new']:
            lines.append("## Only in New Processing\n")
            lines.append("These entries were found in new processing but not in old:\n")
            for entry in comparison['only_new']:
                lines.append(
                    f"- `{entry['ingredient']}` - {entry['quantity']} "
                    f"{entry['unit']} - {entry['calories']} cal"
                )
            lines.append("")

        return '\n'.join(lines)

    def process_date(self, date: str, output_dir: Path) -> bool:
        """
        Process a single date and generate report.

        Returns:
            True if successful, False otherwise
        """
        try:
            logging.info(f"Processing date {date}...")

            # Get old data
            data = self.date_messages_map[date]
            old_processed = data.get('processed', [])
            old_total = data.get('total', 0)

            if not old_processed:
                logging.warning(f"No processed data for date {date}")
                return False

            # Regenerate using new codebase
            new_entries, new_total = self.regenerate_date_entry(date)

            # Compare
            comparison = self.compare_entries(old_processed, new_entries)

            # Check if there are any differences
            has_differences = (
                len(comparison['discrepancies']) > 0 or
                len(comparison['only_old']) > 0 or
                len(comparison['only_new']) > 0 or
                abs(old_total - new_total) > 0.01
            )

            if not has_differences:
                logging.info(f"No differences found for date {date}, skipping report")
                return True

            # Generate report
            report = self.generate_report(date, comparison, old_total, new_total)

            # Write report to file
            output_file = output_dir / f"{date}.md"
            output_file.write_text(report, encoding='utf-8')

            logging.info(f"Report written to {output_file}")
            return True

        except Exception as e:
            logging.error(f"Error processing date {date}: {e}")
            import traceback
            traceback.print_exc()
            return False

    def run(self, n_dates: int, output_dir: str):
        """
        Run comparison for N latest dates.

        Args:
            n_dates: Number of dates to process (from latest to earliest)
            output_dir: Directory to write report files
        """
        # Get all dates sorted from latest to earliest
        dates = sorted(self.date_messages_map.keys(), reverse=True)

        # Filter dates that have processed data
        dates_with_data = [
            d for d in dates
            if 'processed' in self.date_messages_map[d]
        ]

        # Take N dates
        dates_to_process = dates_with_data[:n_dates]

        if not dates_to_process:
            logging.error("No dates with processed data found")
            return

        logging.info(f"Processing {len(dates_to_process)} dates: {dates_to_process}")

        # Create output directory
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        # Process each date
        for date in dates_to_process:
            self.process_date(date, output_path)

        logging.info(f"Completed processing. Reports written to {output_path}")


def quick_validate(date_messages_map_path: str, food_database_path: str, sample_size: int):
    """
    Quick validation mode: Recalculate from existing processed entries.

    This mode doesn't use LLM - it takes already-parsed entries and recalculates
    their nutrition using the current food_database.json.
    """
    # Load data
    if not Path(date_messages_map_path).exists():
        print(f"Error: {date_messages_map_path} not found")
        print("Run 'python main.py' first to process your food logs.")
        return

    with open(date_messages_map_path, 'r', encoding='utf-8') as f:
        date_map = json.load(f)

    calculator = NutritionCalculator(food_database_path)

    # Get dates with processed data
    dates = sorted(
        [d for d in date_map.keys() if 'processed' in date_map[d]],
        reverse=True
    )[:sample_size]

    print(f"Quick validation: {len(dates)} dates from {date_messages_map_path}")
    print("=" * 80)

    mismatches = []
    total_items = 0
    failed_matches = 0
    significant_diffs = 0

    for date in dates:
        entry = date_map[date]
        processed = entry.get("processed", [])
        old_total = entry.get("total", 0)

        new_total = 0
        date_mismatches = []

        for item in processed:
            total_items += 1
            parts = item.split(';')
            if len(parts) != 4:
                continue

            ingredient, quantity_str, unit, old_calories_str = parts

            try:
                quantity = float(quantity_str)
                old_calories = int(old_calories_str)
            except ValueError:
                continue

            # Normalize unit to standard form
            std_unit = normalize_unit(unit)

            # Calculate with new system
            nutrition = calculator.calculate_nutrition(
                ingredient.strip(),
                quantity,
                std_unit
            )

            new_calories = nutrition.get('calories', 0) or 0
            matched_food = nutrition.get('matched_food_id')
            new_total += new_calories

            # Calculate difference
            diff = new_calories - old_calories
            diff_pct = (diff / old_calories * 100) if old_calories > 0 else 0

            if matched_food is None:
                failed_matches += 1

            if abs(diff_pct) >= 10:  # Significant difference
                significant_diffs += 1
                date_mismatches.append({
                    'ingredient': ingredient,
                    'quantity': quantity,
                    'unit': unit,
                    'std_unit': std_unit,
                    'old_calories': old_calories,
                    'new_calories': new_calories,
                    'diff': diff,
                    'diff_pct': diff_pct,
                    'matched': matched_food
                })

        # Check total difference
        total_diff = new_total - old_total
        total_diff_pct = (total_diff / old_total * 100) if old_total > 0 else 0

        # Tiered status
        status = "OK" if abs(total_diff_pct) < 5 else "WARN" if abs(total_diff_pct) < 10 else "ERR"

        print(f"\n{status} {date}")
        print(f"   Old total: {old_total} kcal")
        print(f"   New total: {new_total} kcal")
        print(f"   Difference: {total_diff:+d} kcal ({total_diff_pct:+.1f}%)")

        if date_mismatches:
            print(f"   Items with >=10% difference:")
            for item in date_mismatches[:5]:
                match_status = "Y" if item['matched'] else "N"
                print(f"      {match_status} {item['quantity']} {item['unit']} {item['ingredient']}")
                print(f"         Old: {item['old_calories']} kcal -> New: {item['new_calories']} kcal ({item['diff_pct']:+.1f}%)")
                if not item['matched']:
                    print(f"         Not matched in database!")

        if abs(total_diff_pct) >= 5:
            mismatches.append({
                'date': date,
                'old_total': old_total,
                'new_total': new_total,
                'diff': total_diff,
                'diff_pct': total_diff_pct,
                'item_count': len(processed),
                'mismatch_count': len(date_mismatches)
            })

    # Summary
    print("\n" + "=" * 80)
    print("VALIDATION SUMMARY")
    print("=" * 80)
    print(f"Dates validated: {len(dates)}")
    print(f"Total food items: {total_items}")
    print(f"Items with significant difference (>=10%): {significant_diffs}")
    print(f"Items not matched in database: {failed_matches}")
    print(f"Days with significant total difference (>=5%): {len(mismatches)}")

    if mismatches:
        print("\n  Days requiring attention:")
        for m in sorted(mismatches, key=lambda x: abs(x['diff_pct']), reverse=True):
            print(f"  {m['date']}: {m['old_total']} -> {m['new_total']} ({m['diff_pct']:+.1f}%) - {m['mismatch_count']}/{m['item_count']} items differ")


def main():
    # Get default path from environment
    data_path = os.getenv("DATA_PATH", "data")
    default_messages_path = f'{data_path}/date_messages_map.json'

    parser = argparse.ArgumentParser(
        description='Compare precomputed entries with regenerated entries using new codebase'
    )
    parser.add_argument(
        '-n', '--num-dates',
        type=int,
        required=True,
        help='Number of dates to process (from latest to earliest)'
    )
    parser.add_argument(
        '-o', '--output-dir',
        type=str,
        default='reports',
        help='Directory to write report files (default: reports)'
    )
    parser.add_argument(
        '--date-messages-map',
        type=str,
        default=default_messages_path,
        help=f'Path to date_messages_map.json (default: {default_messages_path})'
    )
    parser.add_argument(
        '--food-database',
        type=str,
        default='food_database.json',
        help='Path to food_database.json (default: food_database.json)'
    )
    parser.add_argument(
        '--quick',
        action='store_true',
        help='Quick validation mode: recalculate from existing processed entries (no LLM)'
    )

    args = parser.parse_args()

    if args.quick:
        # Quick validation mode - no LLM, just recalculate from parsed entries
        quick_validate(
            date_messages_map_path=args.date_messages_map,
            food_database_path=args.food_database,
            sample_size=args.num_dates
        )
    else:
        # Full comparison mode - requires LLM to re-extract food data
        comparator = MigrationComparator(
            date_messages_map_path=args.date_messages_map,
            food_database_path=args.food_database
        )
        comparator.run(n_dates=args.num_dates, output_dir=args.output_dir)


if __name__ == "__main__":
    main()
