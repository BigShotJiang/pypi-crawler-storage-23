"""
Test script for the new food database system.

This tests the integration of:
- FoodDataExtractor (LLM-based extraction)
- NutritionCalculator (deterministic calculation)
- Updated data models
"""

import logging
import os
import sys
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from dotenv import load_dotenv

from food_log.llm import FoodDataExtractor
from food_log.models import FoodEntry, FoodLogEntry
from food_log.processing import NutritionCalculator

load_dotenv(override=True)

logging.basicConfig(level=logging.INFO)

# Test data - sample Portuguese food log entries
TEST_MESSAGES = [
    "2 colheres de sopa de arroz",
    "1 lata de atum",
    "3 bolachas maria",
    "1 iogurte grego light",
    "1 fatia de pao",
    "10 gramas de amendoa laminada"
]


def test_nutrition_calculator():
    """Test the NutritionCalculator directly."""
    print("=" * 60)
    print("TESTING NUTRITION CALCULATOR")
    print("=" * 60)

    calculator = NutritionCalculator(Path(__file__).parent.parent / "food_database.json")

    # Test with STANDARD units (tbsp, tsp, cup, unit, g)
    test_cases = [
        ("arroz", 2, "tbsp"),
        ("atum", 1, "unit"),
        ("bolacha maria", 1, "unit"),
        ("amendoa laminada", 10, "g"),
    ]

    for ingredient, quantity, unit in test_cases:
        nutrition = calculator.calculate_nutrition(ingredient, quantity, unit)
        print(f"\n{quantity} {unit} of {ingredient}:")
        print(f"  Calories: {nutrition['calories']}")
        print(f"  Grams: {nutrition['grams']}")
        print(f"  Matched food: {nutrition['matched_food_id']}")
        if nutrition['proteins']:
            print(f"  Proteins: {nutrition['proteins']}g")


def test_extractor_with_calculator():
    """Test the full pipeline: LLM extraction + nutrition calculation."""
    print("\n" + "=" * 60)
    print("TESTING FULL PIPELINE (LLM + CALCULATOR)")
    print("=" * 60)

    # Check for API key
    api_key = os.getenv("OPENROUTER_API_KEY")
    model = os.getenv("MODEL_ID")

    if not api_key or not model:
        print("\nSkipping LLM test - OPENROUTER_API_KEY or MODEL_ID not set")
        return

    # Initialize components
    extractor = FoodDataExtractor(api_key=api_key, model=model, temp=0.0)
    calculator = NutritionCalculator(Path(__file__).parent.parent / "food_database.json")

    # Get available foods for prompt
    available_foods = "\n".join(calculator.get_available_food_names())

    # Test with sample text
    test_text = "\n".join(TEST_MESSAGES)
    print(f"\nInput text:\n{test_text}\n")

    # Step 1: Extract with LLM
    print("Step 1: Extracting foods with LLM...")
    food_entries, success = extractor.extract_food_data(test_text, available_foods)
    print(f"Extracted {len(food_entries)} food entries")

    # Step 2: Calculate nutrition
    print("\nStep 2: Calculating nutrition...")
    for food in food_entries:
        nutrition = calculator.calculate_nutrition(
            food.ingredient,
            food.quantity,
            food.unit
        )

        # Update food entry
        food.calories = nutrition['calories'] or 0
        food.proteins = nutrition['proteins']
        food.carbs = nutrition['carbs']
        food.fats = nutrition['fats']
        food.grams = nutrition['grams']
        food.matched_food_id = nutrition['matched_food_id']

    # Step 3: Create FoodLogEntry
    print("\nStep 3: Creating FoodLogEntry...")
    food_log = FoodLogEntry(
        date="2024-01-01",
        raw_text=test_text,
        foods=food_entries
    )

    # Display results
    print("\n" + "=" * 60)
    print("RESULTS")
    print("=" * 60)
    print(f"Date: {food_log.date}")
    print(f"Total calories: {food_log.total_calories}")
    if food_log.total_proteins:
        print(f"Total proteins: {food_log.total_proteins}g")
    if food_log.total_carbs:
        print(f"Total carbs: {food_log.total_carbs}g")
    if food_log.total_fats:
        print(f"Total fats: {food_log.total_fats}g")

    print(f"\nIndividual foods:")
    for i, food in enumerate(food_log.foods, 1):
        print(f"\n{i}. {food.ingredient}")
        print(f"   Quantity: {food.quantity} {food.unit}")
        print(f"   Calories: {food.calories}")
        if food.grams:
            print(f"   Grams: {food.grams}g")
        if food.matched_food_id:
            print(f"   Matched to: {food.matched_food_id}")

    print("\n" + "=" * 60)
    print("TEST COMPLETED SUCCESSFULLY!")
    print("=" * 60)


if __name__ == "__main__":
    # Test nutrition calculator
    test_nutrition_calculator()

    # Test full pipeline
    test_extractor_with_calculator()
