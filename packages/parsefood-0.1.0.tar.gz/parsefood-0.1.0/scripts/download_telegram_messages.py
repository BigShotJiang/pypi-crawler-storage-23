#!/usr/bin/env python3
"""
Script to download all messages from a Telegram channel/chat using Telethon API.
Exports messages to JSON format compatible with the existing parsefood.

Usage:
    python scripts/download_telegram_messages.py

Configuration:
    Set the following in your .env file:
    - TELEGRAM_API_ID: Your Telegram API ID from https://my.telegram.org/apps
    - TELEGRAM_API_HASH: Your Telegram API hash
    - TELEGRAM_PHONE: Your phone number (with country code, e.g., +351123456789)
    - TELEGRAM_CHAT: Chat/channel name or ID to download from
"""

import os
import json
import asyncio
from pathlib import Path
from dotenv import load_dotenv
from telethon import TelegramClient
from telethon.tl.types import Message

# Load environment variables
load_dotenv()

# Configuration from environment
API_ID = os.getenv('TELEGRAM_API_ID')
API_HASH = os.getenv('TELEGRAM_API_HASH')
PHONE = os.getenv('TELEGRAM_PHONE')
CHAT_NAME = os.getenv('TELEGRAM_CHAT', 'me')  # 'me' for Saved Messages, or channel/chat name
OUTPUT_FILE = os.getenv('TELEGRAM_OUTPUT_FILE', 'data/result.json')

# Session file location
SESSION_FILE = 'telegram_session'


async def download_messages():
    """Download all messages from specified Telegram chat."""

    # Validate configuration
    if not API_ID or not API_HASH or not PHONE:
        print("❌ Missing required environment variables!")
        print("Please set TELEGRAM_API_ID, TELEGRAM_API_HASH, and TELEGRAM_PHONE in your .env file")
        print("\nGet your API credentials from: https://my.telegram.org/apps")
        return

    print(f"📱 Connecting to Telegram as {PHONE}...")
    print(f"📥 Downloading messages from: {CHAT_NAME}")

    # Create client
    client = TelegramClient(SESSION_FILE, int(API_ID), API_HASH)

    try:
        # Connect and authenticate
        await client.start(phone=PHONE)
        print("✅ Connected successfully!")

        # Get the chat entity
        chat = None
        try:
            # First, try direct lookup (works for usernames with @, or numeric IDs)
            chat = await client.get_entity(CHAT_NAME)
            print(f"✅ Found chat: {getattr(chat, 'title', CHAT_NAME)}")
        except Exception:
            # If that fails, search through dialogs (for group chats, channels, etc.)
            print(f"🔍 Searching for chat matching '{CHAT_NAME}' in your dialogs...")
            async for dialog in client.iter_dialogs():
                dialog_name = getattr(dialog.entity, 'title', None) or getattr(dialog.entity, 'first_name', '')
                if CHAT_NAME.lower() in dialog_name.lower():
                    chat = dialog.entity
                    print(f"✅ Found chat: {dialog_name} (ID: {dialog.id})")
                    break

            if not chat:
                print(f"\n❌ Could not find chat matching '{CHAT_NAME}'")
                print("\nAvailable chats/channels:")
                async for dialog in client.iter_dialogs(limit=20):
                    name = getattr(dialog.entity, 'title', None) or getattr(dialog.entity, 'first_name', 'Unknown')
                    print(f"  - {name} (ID: {dialog.id})")
                print("\nTip: Update TELEGRAM_CHAT in .env with one of the names above")
                return

        # Check for existing messages to enable incremental download
        output_path = Path(OUTPUT_FILE)
        existing_messages_map = {}
        max_existing_id = None

        if output_path.exists():
            print(f"\n📂 Found existing file: {OUTPUT_FILE}")
            try:
                with open(output_path, 'r', encoding='utf-8') as f:
                    existing_data = json.load(f)
                    existing_messages = existing_data.get('messages', [])

                    # Build map of existing messages by ID for quick lookup
                    for msg in existing_messages:
                        existing_messages_map[msg['id']] = msg

                    if existing_messages:
                        print(f"   Total existing messages: {len(existing_messages)}")
                        # Find the highest message ID (newest message)
                        max_existing_id = max(msg['id'] for msg in existing_messages)
                        print(f"   Newest message ID: {max_existing_id}")
            except Exception as e:
                print(f"   ⚠️  Could not read existing file: {e}")
                print(f"   Will download all messages...")

        # Download messages
        downloaded_messages = {}
        message_count = 0
        new_count = 0
        updated_count = 0

        # Download strategy:
        # - If we have existing messages: download from (max_id - 100) to catch recent edits
        # - Otherwise: download all messages
        if max_existing_id:
            # Download from 100 messages before the last known message to catch edits
            min_id = max(0, max_existing_id - 100)
            print(f"\n⏬ Downloading messages after ID {min_id} (to catch edits and new messages)...")
            messages_iter = client.iter_messages(chat, min_id=min_id)
        else:
            print("\n⏬ Downloading ALL messages...")
            messages_iter = client.iter_messages(chat)

        async for message in messages_iter:
            if not isinstance(message, Message):
                continue

            # Extract sender name
            sender_name = None
            if message.sender:
                sender_name = getattr(message.sender, 'first_name', None) or \
                             getattr(message.sender, 'title', None) or \
                             'Unknown'

            # Extract text content (skip media for now)
            text_content = message.text or ""

            # Only include text messages (skip photos, videos, etc.)
            if not text_content:
                continue

            # Build message object matching Telegram export format
            msg_obj = {
                "id": message.id,
                "type": "message",
                "date": message.date.isoformat() if message.date else None,
                "date_unixtime": str(int(message.date.timestamp())) if message.date else None,
                "from": sender_name,
                "from_id": f"user{message.sender_id}" if message.sender_id else None,
                "text": text_content,
                "text_entities": []
            }

            # Check if this is new or updated
            if message.id in existing_messages_map:
                # Check if content changed
                existing = existing_messages_map[message.id]
                if existing.get('text') != text_content or existing.get('date') != msg_obj['date']:
                    updated_count += 1
            else:
                new_count += 1

            downloaded_messages[message.id] = msg_obj
            message_count += 1

            # Progress indicator
            if message_count % 100 == 0:
                print(f"  Downloaded {message_count} messages...")

        print(f"\n✅ Downloaded {message_count} messages")
        if new_count > 0 or updated_count > 0:
            print(f"   📝 {new_count} new, {updated_count} updated")

        # Merge: keep old messages that weren't re-downloaded, add/update downloaded ones
        for msg_id, msg in existing_messages_map.items():
            if msg_id not in downloaded_messages:
                downloaded_messages[msg_id] = msg

        # Sort messages by ID to maintain chronological order
        all_messages = sorted(downloaded_messages.values(), key=lambda m: m['id'])
        total_count = len(all_messages)

        # Create output structure matching Telegram export format
        output_data = {
            "name": getattr(chat, 'title', CHAT_NAME),
            "type": "personal_chat",
            "id": chat.id,
            "messages": all_messages
        }

        # Save to file
        output_path.parent.mkdir(parents=True, exist_ok=True)

        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(output_data, f, ensure_ascii=False, indent=2)

        if new_count > 0 or updated_count > 0:
            print(f"\n💾 Saved {total_count} total messages to: {OUTPUT_FILE}")
            print(f"   ({new_count} new, {updated_count} updated)")
            print(f"\n🎉 Done! You can now run: uv run python main.py")
        else:
            print(f"\n💾 File is up to date with {total_count} messages")
            print(f"   (No new or edited messages found)")

    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()

    finally:
        await client.disconnect()


def main():
    """Main entry point."""
    print("=" * 60)
    print("Telegram Message Downloader for Food Log Parser")
    print("=" * 60)
    print()

    # Run the async function
    asyncio.run(download_messages())


if __name__ == '__main__':
    main()
