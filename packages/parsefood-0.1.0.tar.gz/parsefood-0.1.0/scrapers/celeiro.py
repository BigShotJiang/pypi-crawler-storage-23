"""Scraper for Celeiro.pt product pages."""

import logging
import re
from typing import Optional

from playwright.sync_api import Page, TimeoutError as PlaywrightTimeout, sync_playwright

from .models import NutritionPer100g, ScrapedFoodEntry, ScrapeResult

logger = logging.getLogger(__name__)


class CeleiroScraper:
    """Scraper for Celeiro.pt product pages.

    Uses Playwright for JavaScript rendering since the nutrition
    data may be loaded dynamically.
    """

    name = "Celeiro"
    url_pattern = r"https?://(?:www\.)?celeiro\.pt/\d+-.+"

    # Selectors for page elements
    SELECTORS = {
        "product_name": "h1.product-name, h1",
        "nutrition_container": ".product-nutricional-info",
    }

    def can_handle(self, url: str) -> bool:
        """Check if this scraper can handle the given URL."""
        return bool(re.match(self.url_pattern, url))

    def scrape(self, url: str) -> ScrapeResult:
        """Scrape nutrition data using Playwright for JS rendering."""
        logger.info(f"Scraping {url}")

        try:
            with sync_playwright() as p:
                browser = p.chromium.launch(headless=True)
                context = browser.new_context(
                    user_agent=(
                        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                        "AppleWebKit/537.36 (KHTML, like Gecko) "
                        "Chrome/120.0.0.0 Safari/537.36"
                    ),
                    locale="pt-PT",
                )
                page = context.new_page()

                # Navigate to page
                logger.info("Loading page...")
                page.goto(url, wait_until="domcontentloaded", timeout=30000)

                # Wait for product name to appear
                page.wait_for_selector(self.SELECTORS["product_name"], timeout=10000)

                # Scroll down to load lazy content and wait for page to settle
                page.evaluate("window.scrollTo(0, document.body.scrollHeight / 2)")
                page.wait_for_timeout(2000)

                # Extract data
                entry = self._extract_nutrition(page, url)
                browser.close()

                if entry:
                    return ScrapeResult(success=True, entry=entry, source_url=url)
                else:
                    return ScrapeResult(
                        success=False,
                        error="Failed to extract nutrition data",
                        source_url=url,
                    )

        except PlaywrightTimeout as e:
            logger.error(f"Timeout: {e}")
            return ScrapeResult(
                success=False, error=f"Timeout waiting for page content: {e}", source_url=url
            )
        except Exception as e:
            logger.error(f"Error scraping {url}: {e}")
            return ScrapeResult(success=False, error=str(e), source_url=url)

    def _extract_nutrition(self, page: Page, url: str) -> Optional[ScrapedFoodEntry]:
        """Extract nutrition data from the loaded page."""
        # Get product name
        name = self._extract_product_name(page)
        if not name:
            logger.error("Could not find product name")
            return None

        logger.info(f"Product name: {name}")

        # Extract nutrition values
        nutrition = self._extract_nutrition_values(page)
        if not nutrition:
            logger.error("Could not extract nutrition values")
            return None

        logger.info(f"Extracted nutrition: {nutrition}")

        # Extract unit weight from page title or URL
        grams_per_unit = {"g": 1}
        unit_weight = self._extract_unit_weight(page, url)
        if unit_weight:
            grams_per_unit["unit"] = unit_weight
            logger.info(f"Extracted unit weight: {unit_weight}g")

        return ScrapedFoodEntry(
            name=name,
            url=url,
            grams_per_unit=grams_per_unit,
            nutrition_per_100g=NutritionPer100g(**nutrition),
        )

    def _extract_product_name(self, page: Page) -> Optional[str]:
        """Extract the product name from the page."""
        try:
            name_elem = page.locator(self.SELECTORS["product_name"]).first
            if name_elem.count() > 0:
                return name_elem.inner_text().strip()
        except Exception as e:
            logger.warning(f"Error extracting product name: {e}")
        return None

    def _extract_unit_weight(self, page: Page, url: str) -> Optional[float]:
        """Extract unit/package weight from the page or URL.

        Looks for weight info in:
        1. URL (e.g., "30-gramas")
        2. Page title
        3. Product name
        """
        try:
            # Patterns for weight extraction
            weight_patterns = [
                r"(\d+(?:[.,]\d+)?)[-\s]*(?:gramas?|gr?)\b",  # 30 gramas, 30g, 30-gramas
                r"(\d+(?:[.,]\d+)?)[-\s]*(?:ml)\b",  # 250 ml, 250-ml
            ]

            # Try URL first
            for pattern in weight_patterns:
                match = re.search(pattern, url, re.IGNORECASE)
                if match:
                    weight_str = match.group(1).replace(",", ".")
                    weight = float(weight_str)
                    if 1 <= weight <= 10000:  # Sanity check
                        return weight

            # Try page title
            title = page.title()
            if title:
                for pattern in weight_patterns:
                    match = re.search(pattern, title, re.IGNORECASE)
                    if match:
                        weight_str = match.group(1).replace(",", ".")
                        weight = float(weight_str)
                        if 1 <= weight <= 10000:
                            return weight

            # Try product name element
            name_elem = page.locator(self.SELECTORS["product_name"]).first
            if name_elem.count() > 0:
                name_text = name_elem.inner_text()
                for pattern in weight_patterns:
                    match = re.search(pattern, name_text, re.IGNORECASE)
                    if match:
                        weight_str = match.group(1).replace(",", ".")
                        weight = float(weight_str)
                        if 1 <= weight <= 10000:
                            return weight

        except Exception as e:
            logger.debug(f"Could not extract unit weight: {e}")

        return None

    def _extract_nutrition_values(self, page: Page) -> Optional[dict]:
        """Extract nutrition values from the page using LLM.

        Extracts raw text from the .product-nutricional-info container
        and uses an LLM to parse the nutrition data.
        """
        try:
            # Target the nutrition info container
            container = page.locator(self.SELECTORS["nutrition_container"]).first

            if container.count() == 0:
                # Fallback: try to find any element containing nutrition text
                logger.warning("No .product-nutricional-info container found, trying fallback")
                fallback_selectors = [
                    "dl:has(dt:has-text('energia'))",
                    "div:has-text('Declaração Nutricional')",
                    "section:has-text('Declaração Nutricional')",
                ]
                for selector in fallback_selectors:
                    container = page.locator(selector).first
                    if container.count() > 0:
                        logger.info(f"Found nutrition data with fallback selector: {selector}")
                        break
                else:
                    logger.error("Could not find nutrition container with any selector")
                    return None

            # Extract all text from the container
            raw_text = container.inner_text()

            if not raw_text or len(raw_text.strip()) < 20:
                logger.warning(
                    f"Insufficient text in nutrition container: "
                    f"{raw_text[:50] if raw_text else 'empty'}"
                )
                return None

            logger.info(f"Extracted {len(raw_text)} chars from nutrition container")
            logger.debug(f"Raw text: {raw_text[:500]}...")

            # Use LLM to extract structured data
            from .llm_extraction import NutritionExtractionError, extract_nutrition_with_llm

            try:
                nutrition = extract_nutrition_with_llm(raw_text)
            except NutritionExtractionError as e:
                logger.error(f"LLM extraction failed: {e}")
                return None

            if nutrition is None:
                logger.warning("LLM extraction returned None (possibly only per 100ml data)")
                return None

            # Convert Pydantic model to dict for compatibility with existing code
            return nutrition.model_dump()

        except Exception as e:
            logger.error(f"Error extracting nutrition values: {e}")
            return None
