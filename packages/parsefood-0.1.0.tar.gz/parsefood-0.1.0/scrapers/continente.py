"""Scraper for Continente.pt product pages."""

import logging
import re
from typing import Optional

from playwright.sync_api import Page, TimeoutError as PlaywrightTimeout, sync_playwright

from .models import NutritionPer100g, ScrapedFoodEntry, ScrapeResult

logger = logging.getLogger(__name__)


class ContinenteScraper:
    """Scraper for Continente.pt product pages.

    Uses Playwright for JavaScript rendering since the nutrition
    data is loaded dynamically in collapsible sections.
    """

    name = "Continente"
    url_pattern = r"https?://(?:www\.)?continente\.pt/produto/.+\.html"

    # Selectors for page elements
    SELECTORS = {
        "product_name": "h1.product-name, [data-testid='product-title'], h1",
        "nutrition_tab": "#collapsible-description-nutritional-table",
        "nutrition_table": ".ct-nutritional-table, .nutritional-table, table",
    }

    def can_handle(self, url: str) -> bool:
        """Check if this scraper can handle the given URL."""
        return bool(re.match(self.url_pattern, url))

    def scrape(self, url: str) -> ScrapeResult:
        """Scrape nutrition data using Playwright for JS rendering."""
        logger.info(f"Scraping {url}")

        try:
            with sync_playwright() as p:
                browser = p.chromium.launch(headless=True)
                context = browser.new_context(
                    user_agent=(
                        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                        "AppleWebKit/537.36 (KHTML, like Gecko) "
                        "Chrome/120.0.0.0 Safari/537.36"
                    ),
                    locale="pt-PT",
                )
                page = context.new_page()

                # Navigate to page
                logger.info("Loading page...")
                page.goto(url, wait_until="domcontentloaded", timeout=30000)

                # Wait for product name to appear
                page.wait_for_selector(self.SELECTORS["product_name"], timeout=10000)

                # Scroll down to load lazy content and wait for page to settle
                page.evaluate("window.scrollTo(0, document.body.scrollHeight / 2)")
                page.wait_for_timeout(2000)

                # Try to expand nutrition table
                self._expand_nutrition_section(page)

                # Extract data
                entry = self._extract_nutrition(page, url)
                browser.close()

                if entry:
                    return ScrapeResult(success=True, entry=entry, source_url=url)
                else:
                    return ScrapeResult(
                        success=False,
                        error="Failed to extract nutrition data",
                        source_url=url,
                    )

        except PlaywrightTimeout as e:
            logger.error(f"Timeout: {e}")
            return ScrapeResult(
                success=False, error=f"Timeout waiting for page content: {e}", source_url=url
            )
        except Exception as e:
            logger.error(f"Error scraping {url}: {e}")
            return ScrapeResult(success=False, error=str(e), source_url=url)

    def _expand_nutrition_section(self, page: Page) -> None:
        """Try to expand the nutrition information section.

        The Continente site uses a tabbed interface where the nutrition
        table is hidden by default. We need to click the tab button
        to reveal it.
        """
        try:
            # The tab content has id="collapsible-description-nutritional-table"
            # We need to find and click the tab button that shows this content
            # Common patterns: data-target, aria-controls, or text content

            tab_button_selectors = [
                # Button that targets the nutrition table by ID
                '[data-target="#collapsible-description-nutritional-table"]',
                '[href="#collapsible-description-nutritional-table"]',
                '[aria-controls="collapsible-description-nutritional-table"]',
                # Button with data attribute pointing to nutrition tab
                '[data-tabindex="s4"]',
                'button[data-tabindex="s4"]',
                # Text-based selectors for Portuguese
                'button:has-text("Tabela Nutricional")',
                'a:has-text("Tabela Nutricional")',
                '[role="tab"]:has-text("Tabela Nutricional")',
                # Generic tab selectors that might contain nutrition
                '.nav-tabs button:has-text("Nutri")',
                '.tab-list button:has-text("Nutri")',
            ]

            clicked = False
            for selector in tab_button_selectors:
                try:
                    button = page.locator(selector).first
                    if button.count() > 0:
                        logger.info(f"Found tab button with selector: {selector}")
                        # Scroll the button into view first
                        button.scroll_into_view_if_needed()
                        page.wait_for_timeout(300)
                        # Now try to click
                        button.click(force=True)
                        page.wait_for_timeout(500)
                        clicked = True
                        break
                except Exception as e:
                    logger.debug(f"Could not click {selector}: {e}")
                    continue

            if not clicked:
                # Try finding any tab/button containing "nutri" text
                logger.info("Trying to find nutrition tab by text content...")
                # Debug: log all visible text on tab-like elements
                all_buttons = page.locator("button, a, [role='tab'], .tab, .nav-link").all()
                logger.info(f"Found {len(all_buttons)} potential clickable elements")
                for i, btn in enumerate(all_buttons[:20]):  # Limit to first 20
                    try:
                        text = btn.inner_text().strip()
                        if text and len(text) < 100:
                            is_visible = btn.is_visible()
                            logger.debug(f"  Button {i}: '{text[:50]}' visible={is_visible}")
                            if ("nutri" in text.lower() or "tabela" in text.lower()) and is_visible:
                                logger.info(f"Found button with text: {text[:50]}")
                                btn.click()
                                page.wait_for_timeout(500)
                                clicked = True
                                break
                    except Exception:
                        continue

            if clicked:
                # Wait for the content to become visible
                page.wait_for_timeout(1000)
                logger.info("Clicked nutrition tab")
            else:
                logger.warning("Could not find nutrition tab button")

        except Exception as e:
            logger.warning(f"Could not expand nutrition section: {e}")

    def _extract_nutrition(self, page: Page, url: str) -> Optional[ScrapedFoodEntry]:
        """Extract nutrition data from the loaded page."""
        # Get product name
        name = self._extract_product_name(page)
        if not name:
            logger.error("Could not find product name")
            return None

        logger.info(f"Product name: {name}")

        # Extract nutrition values
        nutrition = self._extract_nutrition_values(page)
        if not nutrition:
            logger.error("Could not extract nutrition values")
            return None

        logger.info(f"Extracted nutrition: {nutrition}")

        # Extract unit weight from page title
        grams_per_unit = {"g": 1}
        unit_weight = self._extract_unit_weight(page)
        if unit_weight:
            grams_per_unit["unit"] = unit_weight
            logger.info(f"Extracted unit weight: {unit_weight}g")

        return ScrapedFoodEntry(
            name=name,
            url=url,
            grams_per_unit=grams_per_unit,
            nutrition_per_100g=NutritionPer100g(**nutrition),
        )

    def _extract_product_name(self, page: Page) -> Optional[str]:
        """Extract the product name from the page."""
        try:
            name_elem = page.locator(self.SELECTORS["product_name"]).first
            if name_elem.count() > 0:
                return name_elem.inner_text().strip()
        except Exception as e:
            logger.warning(f"Error extracting product name: {e}")
        return None

    def _extract_unit_weight(self, page: Page) -> Optional[float]:
        """Extract unit/package weight from the page.

        Looks for weight info in:
        1. Page title (e.g., "Product - emb. 65 gr | Continente")
        2. Product format/weight elements
        """
        try:
            # Try page title first - most reliable
            title = page.title()
            if title:
                # Patterns: "emb. 65 gr", "65 g", "65g", "65 gr", "500 ml"
                # Look for pattern before "| Continente"
                patterns = [
                    r"emb\.?\s*(\d+(?:[.,]\d+)?)\s*(?:gr?|ml)",  # emb. 65 gr
                    r"(\d+(?:[.,]\d+)?)\s*(?:gr?|ml)\s*\|",  # 65 g |
                    r"-\s*(\d+(?:[.,]\d+)?)\s*(?:gr?|ml)",  # - 65 gr
                    r"(\d+(?:[.,]\d+)?)\s*(?:gr?|ml)(?:\s|$)",  # 65 g or 65g
                ]
                for pattern in patterns:
                    match = re.search(pattern, title, re.IGNORECASE)
                    if match:
                        weight_str = match.group(1).replace(",", ".")
                        weight = float(weight_str)
                        if 1 <= weight <= 10000:  # Sanity check
                            return weight

            # Fallback: look for weight in product info elements
            weight_selectors = [
                ".product-format",
                ".ct-product-format",
                "[class*='weight']",
                "[class*='format']",
            ]
            for sel in weight_selectors:
                elem = page.locator(sel).first
                if elem.count() > 0:
                    text = elem.inner_text()
                    match = re.search(r"(\d+(?:[.,]\d+)?)\s*(?:gr?|ml)", text, re.IGNORECASE)
                    if match:
                        weight_str = match.group(1).replace(",", ".")
                        weight = float(weight_str)
                        if 1 <= weight <= 10000:
                            return weight

        except Exception as e:
            logger.debug(f"Could not extract unit weight: {e}")

        return None

    def _extract_nutrition_values(self, page: Page) -> Optional[dict]:
        """Extract nutrition values from the page using LLM.

        Extracts raw text from the .nutriInfo-group container and
        uses an LLM to parse the nutrition data.
        """
        try:
            # Target the nutrition group container
            container = page.locator(".nutriInfo-group").first

            if container.count() == 0:
                logger.warning("No .nutriInfo-group container found")
                return None

            # Extract all text from the container
            raw_text = container.inner_text()

            if not raw_text or len(raw_text.strip()) < 20:
                logger.warning(
                    f"Insufficient text in nutrition container: "
                    f"{raw_text[:50] if raw_text else 'empty'}"
                )
                return None

            logger.info(f"Extracted {len(raw_text)} chars from nutrition container")
            logger.debug(f"Raw text: {raw_text[:500]}...")

            # Use LLM to extract structured data
            from .llm_extraction import NutritionExtractionError, extract_nutrition_with_llm

            try:
                nutrition = extract_nutrition_with_llm(raw_text)
            except NutritionExtractionError as e:
                logger.error(f"LLM extraction failed: {e}")
                return None

            if nutrition is None:
                logger.warning("LLM extraction returned None (possibly only per 100ml data)")
                return None

            # Convert Pydantic model to dict for compatibility with existing code
            return nutrition.model_dump()

        except Exception as e:
            logger.error(f"Error extracting nutrition values: {e}")
            return None
