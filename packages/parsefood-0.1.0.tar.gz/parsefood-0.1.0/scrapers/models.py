"""Pydantic models for scraped food data."""

from typing import Dict, Optional

from pydantic import BaseModel, Field, field_validator

from food_log.models import NutritionPer100g


class ScrapedFoodEntry(BaseModel):
    """A food entry scraped from a product URL."""

    name: str = Field(..., min_length=1, description="Product name in Portuguese, lowercase")
    url: str = Field(..., description="Source URL")
    grams_per_unit: Dict[str, float] = Field(
        default_factory=lambda: {"g": 1}, description="Unit conversions"
    )
    nutrition_per_100g: NutritionPer100g

    @field_validator("name")
    @classmethod
    def normalize_name(cls, v: str) -> str:
        """Normalize name to lowercase and strip whitespace."""
        return v.strip().lower()


class ScrapeResult(BaseModel):
    """Result of a scrape operation."""

    success: bool
    entry: Optional[ScrapedFoodEntry] = None
    error: Optional[str] = None
    source_url: str
